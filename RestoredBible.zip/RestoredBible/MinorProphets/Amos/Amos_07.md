# Amos 7: Visions and Confrontation

*From the Hebrew: כֹּה הִרְאַנִי אֲדֹנָי יֱהוִה (Koh Hir'ani Adonai YHWH) — Thus the Lord YHWH Showed Me*

---

## Vision of the Locusts (7:1-3)

**7:1** Thus the Lord YHWH showed me; and, behold, he formed locusts in the beginning of the shooting up of the latter growth; and, lo, it was the latter growth after the king's mowings.

**7:2** And it came to pass that, when they made an end of eating the grass of the land, then I said: "O Lord YHWH, forgive, I beseech you; how shall Jacob stand? For he is small."

**7:3** YHWH repented concerning this; "It shall not be," says YHWH.

---

## Vision of the Fire (7:4-6)

**7:4** Thus the Lord YHWH showed me; and, behold, the Lord YHWH called to contend by fire; and it devoured the great deep, and would have eaten up the land.

**7:5** Then said I: "O Lord YHWH, cease, I beseech you; how shall Jacob stand? For he is small."

**7:6** YHWH repented concerning this; "This also shall not be," says the Lord YHWH.

---

## Vision of the Plumb Line (7:7-9)

**7:7** Thus he showed me; and, behold, the Lord stood beside a wall made by a plumb-line, with a plumb-line in his hand.

**7:8** And YHWH said unto me: "Amos, what do you see?" And I said: "A plumb-line." Then said the Lord: "Behold, I will set a plumb-line in the midst of my people Israel; I will not again pass by them any more;

**7:9** "And the high places of Isaac shall be desolate, and the sanctuaries of Israel shall be laid waste; and I will rise against the house of Jeroboam with the sword."

---

## Confrontation with Amaziah (7:10-17)

**7:10** Then Amaziah the priest of Bethel sent to Jeroboam king of Israel, saying: "Amos has conspired against you in the midst of the house of Israel; the land is not able to bear all his words.

**7:11** "For thus Amos says: 'Jeroboam shall die by the sword, and Israel shall surely be led away captive out of his land.'"

**7:12** Also Amaziah said unto Amos: "O you seer, go, flee away into the land of Judah, and there eat bread, and prophesy there;

**7:13** "But prophesy not again any more at Bethel; for it is the king's sanctuary, and it is a royal house."

**7:14** Then answered Amos, and said to Amaziah: "I was no prophet, neither was I a prophet's son; but I was a herdsman, and a dresser of sycamore-trees;

**7:15** "And YHWH took me from following the flock, and YHWH said unto me: 'Go, prophesy unto my people Israel.'

**7:16** "Now therefore hear the word of YHWH: You say: 'Prophesy not against Israel, and preach not against the house of Isaac.'

**7:17** "Therefore thus says YHWH: 'Your wife shall be a harlot in the city, and your sons and your daughters shall fall by the sword, and your land shall be divided by line; and you yourself shall die in an unclean land, and Israel shall surely be led away captive out of his land.'"

---

## Synthesis Notes

**Key Restorations:**

**Vision of the Locusts (7:1-3):**
**The Key Verses (7:1-3):**
"'Thus the Lord YHWH showed me.'"

*Koh hir'ani Adonai YHWH*—YHWH showed.

"'He formed locusts in the beginning of the shooting up of the latter growth.'"

*Ve-hinneh yotzer govai bi-techillat alot ha-leqesh*—locust formation.

"'It was the latter growth after the king's mowings.'"

*Ve-hinneh leqesh achar gizzei ha-melekh*—after king's mowings.

"'When they made an end of eating the grass of the land.'"

*Ve-hayah im-killah le'ekhol et-esev ha-aretz*—finished eating.

"''O Lord YHWH, forgive, I beseech you.''"

*Adonai YHWH selach-na*—forgive.

"''How shall Jacob stand? For he is small.''"

*Mi yaqum Ya'aqov ki qaton hu*—Jacob is small.

"'YHWH repented concerning this.'"

*Nicham YHWH al-zot*—YHWH relented.

"''It shall not be.''"

*Lo tihyeh*—not happen.

**Vision of the Fire (7:4-6):**
**The Key Verses (7:4-6):**
"'The Lord YHWH called to contend by fire.'"

*Qore lariv ba-esh Adonai YHWH*—contend by fire.

"'It devoured the great deep.'"

*Va-tokhal et-tehom rabbah*—devoured deep.

"'Would have eaten up the land.'"

*Ve-akhelah et-ha-cheleq*—eaten land.

"''O Lord YHWH, cease, I beseech you.''"

*Adonai YHWH chadal-na*—cease.

"''How shall Jacob stand? For he is small.''"

*Mi yaqum Ya'aqov ki qaton hu*—small.

"'YHWH repented concerning this.'"

*Nicham YHWH al-zot*—relented.

"''This also shall not be.''"

*Gam-hi lo tihyeh*—not happen.

**Prophetic Intercession:**
Amos intercedes; YHWH relents—twice.

**Vision of the Plumb Line (7:7-9):**
**The Key Verses (7:7-9):**
"'The Lord stood beside a wall made by a plumb-line.'"

*Ve-hinneh Adonai nitzav al-chomat anakh*—plumb-line wall.

"'With a plumb-line in his hand.'"

*U-ve-yado anakh*—plumb-line in hand.

**Anakh:**
"Plumb-line"—measuring for straightness; Israel is crooked.

"''Amos, what do you see?''"

*Mah-attah ro'eh Amos*—what do you see?

"''A plumb-line.''"

*Anakh*—plumb-line.

"''I will set a plumb-line in the midst of my people Israel.''"

*Hineni sam anakh be-qerev ammi Yisra'el*—plumb-line in midst.

"''I will not again pass by them any more.''"

*Lo-osif od avor lo*—no more passing by.

"''The high places of Isaac shall be desolate.''"

*Ve-nashammו bamot Yitzchaq*—high places desolate.

"''The sanctuaries of Israel shall be laid waste.''"

*U-miqdeshei Yisra'el yecheravu*—sanctuaries waste.

"''I will rise against the house of Jeroboam with the sword.''"

*Ve-qamti al-beit Yarov'am be-charev*—sword against Jeroboam.

**No Intercession:**
This time Amos doesn't intercede—judgment is final.

**Confrontation with Amaziah (7:10-17):**
**The Key Verses (7:10-13):**
"'Amaziah the priest of Bethel sent to Jeroboam king of Israel.'"

*Va-yishlach Amazyah kohen Beit-El el-Yarov'am melekh-Yisra'el*—Amaziah reports.

"''Amos has conspired against you in the midst of the house of Israel.''"

*Qashar alekha Amos be-qerev beit Yisra'el*—conspiracy.

"''The land is not able to bear all his words.''"

*Lo-tukhal ha-aretz le-hakhil et-kol-devarav*—can't bear words.

"''Jeroboam shall die by the sword.''"

*Be-cherev yamut Yarov'am*—die by sword.

"''Israel shall surely be led away captive.''"

*Ve-Yisra'el galoh yigleh me-al admato*—exile.

"''O you seer, go, flee away into the land of Judah.''"

*Chozeh lekh berach-lekha el-eretz Yehudah*—flee to Judah.

"''There eat bread, and prophesy there.''"

*Ve-ekhol-sham lechem ve-sham tinnave*—earn living there.

"''Prophesy not again any more at Bethel.''"

*U-Vet-El lo-tosif od le-hinnave*—don't prophesy here.

"''It is the king's sanctuary, and it is a royal house.''"

*Ki miqdash-melekh hu u-veit mamlakhah hu*—king's sanctuary.

**The Key Verses (7:14-17):**
"''I was no prophet, neither was I a prophet's son.''"

*Lo-navi anokhi ve-lo ven-navi anokhi*—not professional prophet.

"''I was a herdsman, and a dresser of sycamore-trees.''"

*Ki-voqer anokhi u-voles shiqmim*—herdsman, sycamore dresser.

"''YHWH took me from following the flock.''"

*Va-yiqqacheni YHWH me-acharei ha-tzon*—YHWH took me.

"''YHWH said unto me: Go, prophesy unto my people Israel.''"

*Va-yomer elai YHWH lekh hinnave el-ammi Yisra'el*—go prophesy.

"''Now therefore hear the word of YHWH.''"

*Ve-attah shema devar-YHWH*—hear YHWH.

"''You say: Prophesy not against Israel.''"

*Attah omer lo tinnave al-Yisra'el*—you forbid.

"''Your wife shall be a harlot in the city.''"

*Ishtekha ba-ir tizneh*—wife a harlot.

"''Your sons and your daughters shall fall by the sword.''"

*U-vanekha u-venotekha ba-cherev yippolu*—children die.

"''Your land shall be divided by line.''"

*Ve-admatekha ba-chevel techalleq*—land divided.

"''You yourself shall die in an unclean land.''"

*Ve-attah al-adamah teme'ah tamut*—die unclean.

"''Israel shall surely be led away captive out of his land.''"

*Ve-Yisra'el galoh yigleh me-al admato*—exile.

**Archetypal Layer:** Amos 7 contains **three visions**: locusts (7:1-3), fire (7:4-6), plumb-line (7:7-9), **Amos's intercession: "How shall Jacob stand? For he is small" (7:2, 5)**, **YHWH relents twice (7:3, 6)**, **the plumb-line: "I will not again pass by them any more" (7:8)**—no intercession, **"I will rise against the house of Jeroboam with the sword" (7:9)**, the **confrontation with Amaziah priest of Bethel (7:10-17)**, **Amos's defense: "I was no prophet... but I was a herdsman" (7:14)**, **"YHWH took me from following the flock" (7:15)**, and **judgment on Amaziah's family (7:17)**.

**Ethical Inversion Applied:**
- "'Thus the Lord YHWH showed me'"—vision
- "'He formed locusts'"—locusts
- "'They made an end of eating the grass'"—destruction
- "''O Lord YHWH, forgive''"—intercession
- "''How shall Jacob stand? For he is small''"—small
- "'YHWH repented concerning this'"—relented
- "''It shall not be''"—averted
- "'The Lord YHWH called to contend by fire'"—fire
- "'It devoured the great deep'"—devoured
- "''O Lord YHWH, cease''"—intercession
- "'YHWH repented concerning this'"—relented
- "'The Lord stood beside a wall made by a plumb-line'"—plumb-line
- "''Amos, what do you see?''"—question
- "''A plumb-line''"—answer
- "''I will set a plumb-line in the midst of my people Israel''"—measure
- "''I will not again pass by them any more''"—no more passing
- "''The high places of Isaac shall be desolate''"—desolate
- "''I will rise against the house of Jeroboam with the sword''"—sword
- "'Amaziah the priest of Bethel sent to Jeroboam'"—report
- "''Amos has conspired against you''"—conspiracy charge
- "''The land is not able to bear all his words''"—can't bear
- "''O you seer, go, flee away into the land of Judah''"—go away
- "''Prophesy not again any more at Bethel''"—forbidden
- "''It is the king's sanctuary''"—royal sanctuary
- "''I was no prophet, neither was I a prophet's son''"—not professional
- "''I was a herdsman, and a dresser of sycamore-trees''"—occupation
- "''YHWH took me from following the flock''"—divine call
- "''YHWH said unto me: Go, prophesy''"—commission
- "''Your wife shall be a harlot''"—judgment on Amaziah
- "''Your sons and your daughters shall fall by the sword''"—children die
- "''You yourself shall die in an unclean land''"—unclean death
- "''Israel shall surely be led away captive''"—exile

**Modern Equivalent:** Amos 7 shows prophetic intercession—Amos pleads for Israel ("he is small") and YHWH relents twice. But the plumb-line vision brings no intercession—Israel is crooked beyond repair. Amaziah the establishment priest expels Amos from the royal sanctuary. Amos's response is classic: "I was no prophet"—not a professional, but divinely called from his flocks. His oracle against Amaziah's family is devastating.

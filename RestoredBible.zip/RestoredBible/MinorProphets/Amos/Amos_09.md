# Amos 9: Vision of Destruction and Promise of Restoration

*From the Hebrew: רָאִיתִי אֶת־אֲדֹנָי נִצָּב עַל־הַמִּזְבֵּחַ (Ra'iti Et-Adonai Nitzav Al-Ha-Mizbe'ach) — I Saw the Lord Standing Beside the Altar*

---

## Vision of the Altar (9:1-4)

**9:1** I saw the Lord standing beside the altar; and he said: "Smite the capitals, that the thresholds may shake; and break them in pieces on the head of all of them; and I will slay the last of them with the sword; there shall not one of them flee away, and there shall not one of them escape.

**9:2** "Though they dig into the nether-world, thence shall my hand take them; and though they climb up to heaven, thence will I bring them down.

**9:3** "And though they hide themselves in the top of Carmel, I will search and take them out thence; and though they be hid from my sight in the bottom of the sea, thence will I command the serpent, and it shall bite them.

**9:4** "And though they go into captivity before their enemies, thence will I command the sword, and it shall slay them; and I will set my eyes upon them for evil, and not for good."

---

## Third Doxology (9:5-6)

**9:5** For the Lord, YHWH of hosts, is he that touches the land and it melts, and all that dwell therein mourn; and it rises up wholly like the River, and sinks again, like the River of Egypt;

**9:6** It is he that builds his upper chambers in the heaven, and has founded his vault upon the earth; he that calls for the waters of the sea, and pours them out upon the face of the earth; YHWH is his name.

---

## Israel Among the Nations (9:7-10)

**9:7** "Are you not as the children of the Ethiopians unto me, O children of Israel?" says YHWH. "Have not I brought up Israel out of the land of Egypt, and the Philistines from Caphtor, and Aram from Kir?

**9:8** "Behold, the eyes of the Lord YHWH are upon the sinful kingdom, and I will destroy it from off the face of the earth; saving that I will not utterly destroy the house of Jacob," says YHWH.

**9:9** "For, lo, I will command, and I will sift the house of Israel among all the nations, like as grain is sifted in a sieve, yet shall not the least grain fall upon the earth.

**9:10** "All the sinners of my people shall die by the sword, that say: 'The evil shall not overtake nor confront us.'"

---

## Restoration of David's Booth (9:11-15)

**9:11** In that day will I raise up the tabernacle of David that is fallen, and close up the breaches thereof, and I will raise up its ruins, and I will build it as in the days of old;

**9:12** That they may possess the remnant of Edom, and all the nations, upon whom my name is called, says YHWH that does this.

**9:13** Behold, the days come, says YHWH, that the plowman shall overtake the reaper, and the treader of grapes him that sows seed; and the mountains shall drop sweet wine, and all the hills shall melt.

**9:14** And I will turn the captivity of my people Israel, and they shall build the waste cities, and inhabit them; and they shall plant vineyards, and drink the wine thereof; they shall also make gardens, and eat the fruit of them.

**9:15** And I will plant them upon their land, and they shall no more be plucked up out of their land which I have given them, says YHWH your God.

---

## Synthesis Notes

**Key Restorations:**

**Vision of the Altar (9:1-4):**
**The Key Verse (9:1):**
"'I saw the Lord standing beside the altar.'"

*Ra'iti et-Adonai nitzav al-ha-mizbe'ach*—standing at altar.

"''Smite the capitals, that the thresholds may shake.''"

*Hakh ha-kaftor ve-yir'ashu ha-sippim*—smite capitals.

"''Break them in pieces on the head of all of them.''"

*U-vetza'am be-rosh kullam*—break on heads.

"''I will slay the last of them with the sword.''"

*Ve-acharitam ba-cherev eherog*—slay last.

"''There shall not one of them flee away.''"

*Lo-yanus lahem nas*—none flee.

"''There shall not one of them escape.''"

*Ve-lo-yimmalet lahem palit*—none escape.

**The Key Verses (9:2-4):**
"''Though they dig into the nether-world, thence shall my hand take them.''"

*Im-yachteru vi-She'ol mi-sham yadi tiqqachem*—Sheol.

"''Though they climb up to heaven, thence will I bring them down.''"

*Ve-im-ya'alu ha-shamayim mi-sham oridem*—heaven.

"''Though they hide themselves in the top of Carmel, I will search and take them out thence.''"

*Ve-im-yechavv'u be-rosh ha-Karmel mi-sham achappes ve-leqachtim*—Carmel.

"''Though they be hid from my sight in the bottom of the sea, thence will I command the serpent, and it shall bite them.''"

*Ve-im-yissateru mi-neged einai be-qarqa ha-yam mi-sham atzavveh et-ha-nachash u-neshakham*—sea serpent.

"''Though they go into captivity before their enemies, thence will I command the sword.''"

*Ve-im-yelekhu va-shevi lifnei oyeveihem mi-sham atzavveh et-ha-cherev va-haragatam*—captivity.

"''I will set my eyes upon them for evil, and not for good.''"

*Ve-samti eini aleihem le-ra'ah ve-lo le-tovah*—eyes for evil.

**No Escape:**
From Sheol to heaven, from Carmel to sea floor—no escape from YHWH.

**Third Doxology (9:5-6):**
**The Key Verses (9:5-6):**
"'The Lord, YHWH of hosts, is he that touches the land and it melts.'"

*Va-Adonai YHWH ha-tzeva'ot ha-noge'a ba-aretz va-tamog*—touches, melts.

"'All that dwell therein mourn.'"

*Ve-avelu kol-yoshevei vah*—all mourn.

"'It rises up wholly like the River, and sinks again.'"

*Ve-aletah kha-ye'or kullah ve-shaq'ah ke-ye'or Mitzrayim*—like Nile.

"'He that builds his upper chambers in the heaven.'"

*Ha-boneh va-shamayim ma'alotav*—upper chambers.

"'Has founded his vault upon the earth.'"

*Va-aguddato al-eretz yesadah*—vault on earth.

"'He that calls for the waters of the sea, and pours them out upon the face of the earth.'"

*Ha-qore le-mei-ha-yam va-yishpekhem al-penei ha-aretz*—pours sea.

"'YHWH is his name.'"

*YHWH shemo*—YHWH his name.

**Third Doxology:**
Final hymnic praise of YHWH's cosmic sovereignty.

**Israel Among the Nations (9:7-10):**
**The Key Verse (9:7):**
"''Are you not as the children of the Ethiopians unto me, O children of Israel?''"

*Ha-lo ki-venei Khushיim attem li benei Yisra'el*—like Ethiopians.

"''Have not I brought up Israel out of the land of Egypt?''"

*Ha-lo et-Yisra'el he'eleiti me-eretz Mitzrayim*—brought up Israel.

"''The Philistines from Caphtor, and Aram from Kir?''"

*U-Felishtיim mi-Khaftor va-Aram mi-Qir*—also moved Philistines, Aram.

**Revolutionary:**
YHWH directed other nations' migrations too—Israel is not unique in that respect.

**The Key Verses (9:8-10):**
"''The eyes of the Lord YHWH are upon the sinful kingdom.''"

*Hinneh einei Adonai YHWH ba-mamlakhah ha-chatta'ah*—sinful kingdom.

"''I will destroy it from off the face of the earth.''"

*Ve-hishmadti otah me-al penei ha-adamah*—destroy.

"''Saving that I will not utterly destroy the house of Jacob.''"

*Efes ki lo hashmid ashmid et-beit Ya'aqov*—not utterly destroy.

"''I will sift the house of Israel among all the nations, like as grain is sifted in a sieve.''"

*Ki hineh anokhi metzavveh va-hani'oti ve-khol-ha-goyim et-beit Yisra'el ka-asher yinua ba-kevarah*—sift.

"''Yet shall not the least grain fall upon the earth.''"

*Ve-lo-yippol tzeror aretz*—not one grain.

"''All the sinners of my people shall die by the sword.''"

*Ba-cherev yamutu kol chatta'ei ammi*—sinners die.

"''The evil shall not overtake nor confront us.''"

*Lo-taggish ve-taqdim ba'adenu ha-ra'ah*—false security.

**Restoration of David's Booth (9:11-15):**
**The Key Verse (9:11):**
"''In that day will I raise up the tabernacle of David that is fallen.''"

*Ba-yom ha-hu aqim et-sukkat David ha-nofelet*—David's booth.

**Sukkat David:**
"Tabernacle/booth of David"—the fallen Davidic dynasty, restored.

"''Close up the breaches thereof.''"

*Ve-gadarti et-pirtzeihen*—close breaches.

"''I will raise up its ruins.''"

*Va-harisotav aqim*—raise ruins.

"''I will build it as in the days of old.''"

*U-venitiha ki-yemei olam*—as of old.

**The Key Verse (9:12):**
"''That they may possess the remnant of Edom, and all the nations.''"

*Lema'an yireshu et-she'erit Edom ve-khol-ha-goyim*—possess Edom.

"''Upon whom my name is called.''"

*Asher-niqra shemi aleihem*—my name called.

**Acts 15:16-17:**
James quotes this at the Jerusalem Council for Gentile inclusion.

**The Key Verses (9:13-15):**
"''The days come... that the plowman shall overtake the reaper.''"

*Hinneh yamim ba'im... ve-niggash choresh ba-qotzer*—plowman overtakes reaper.

"''The treader of grapes him that sows seed.''"

*Ve-dorekh anavim be-moshekh ha-zara*—treader overtakes sower.

"''The mountains shall drop sweet wine, and all the hills shall melt.''"

*Ve-hittifu he-harim asis ve-khol-ha-geva'ot titmogagnah*—mountains drop wine.

**Abundant Fertility:**
Harvests so abundant they overlap—no end to plenty.

"''I will turn the captivity of my people Israel.''"

*Ve-shavti et-shevut ammi Yisra'el*—turn captivity.

"''They shall build the waste cities, and inhabit them.''"

*U-vanu arim neshammot ve-yashavu*—rebuild.

"''They shall plant vineyards, and drink the wine thereof.''"

*Ve-nat'u keramim ve-shatu et-yeinam*—plant, drink.

"''They shall also make gardens, and eat the fruit of them.''"

*Ve-asu gannot ve-akhelu et-peryhem*—gardens, fruit.

"''I will plant them upon their land.''"

*U-neta'tim al-admatam*—plant on land.

"''They shall no more be plucked up out of their land.''"

*Ve-lo yinnateshu od me-al admatam*—never uprooted.

"''Which I have given them, says YHWH your God.''"

*Asher natatti lahem amar YHWH Elohekha*—given by YHWH.

**Archetypal Layer:** Amos 9 contains **the vision at the altar (9:1)**, **no escape: Sheol, heaven, Carmel, sea, captivity (9:2-4)**, **"I will set my eyes upon them for evil, and not for good" (9:4)**, **the third doxology (9:5-6)**, **"Are you not as the children of the Ethiopians unto me?" (9:7)**—YHWH guides all nations, **"I will not utterly destroy the house of Jacob" (9:8)**, **"I will sift the house of Israel... yet shall not the least grain fall" (9:9)**, **"In that day will I raise up the tabernacle of David that is fallen" (9:11)**—quoted in Acts 15, **abundant fertility: plowman overtakes reaper (9:13)**, **"I will turn the captivity of my people Israel" (9:14)**, and **"they shall no more be plucked up out of their land" (9:15)**.

**Ethical Inversion Applied:**
- "'I saw the Lord standing beside the altar'"—standing at altar
- "''Smite the capitals, that the thresholds may shake''"—smite
- "''I will slay the last of them with the sword''"—slay
- "''There shall not one of them flee away''"—none flee
- "''Though they dig into the nether-world... my hand take them''"—Sheol
- "''Though they climb up to heaven... I bring them down''"—heaven
- "''Though they hide themselves in the top of Carmel''"—Carmel
- "''Though they be hid... in the bottom of the sea... the serpent... bite them''"—sea
- "''Though they go into captivity... the sword... slay them''"—captivity
- "''I will set my eyes upon them for evil''"—eyes for evil
- "'He that touches the land and it melts'"—touches, melts
- "'All that dwell therein mourn'"—mourn
- "'He that builds his upper chambers in the heaven'"—upper chambers
- "'YHWH is his name'"—YHWH
- "''Are you not as the children of the Ethiopians unto me?''"—like Ethiopians
- "''Have not I brought up Israel out of... Egypt?''"—Exodus
- "''The Philistines from Caphtor, and Aram from Kir?''"—other migrations
- "''The eyes of the Lord YHWH are upon the sinful kingdom''"—sinful kingdom
- "''I will destroy it from off the face of the earth''"—destroy
- "''I will not utterly destroy the house of Jacob''"—not utterly
- "''I will sift the house of Israel among all the nations''"—sift
- "''Yet shall not the least grain fall upon the earth''"—not one grain
- "''All the sinners of my people shall die by the sword''"—sinners die
- "''In that day will I raise up the tabernacle of David that is fallen''"—raise David's booth
- "''Close up the breaches thereof''"—close breaches
- "''I will build it as in the days of old''"—as of old
- "''That they may possess the remnant of Edom, and all the nations''"—possess Edom
- "''Upon whom my name is called''"—name called
- "''The plowman shall overtake the reaper''"—abundant
- "''The mountains shall drop sweet wine''"—wine
- "''I will turn the captivity of my people Israel''"—turn captivity
- "''They shall build the waste cities, and inhabit them''"—rebuild
- "''They shall plant vineyards, and drink the wine thereof''"—plant
- "''I will plant them upon their land''"—plant
- "''They shall no more be plucked up out of their land''"—never uprooted

**Modern Equivalent:** Amos 9 moves from total judgment to ultimate hope. No escape from YHWH (9:2-4). The revolutionary 9:7—Israel is like Ethiopia; YHWH guided Philistine and Aramean migrations too. Yet God won't utterly destroy (9:8); He sifts but preserves (9:9). "David's fallen booth" (9:11) will be raised—James quotes this in Acts 15:16-17 for Gentile inclusion. The closing vision (9:13-15) of abundant fertility and permanent restoration ends the book on hope.

# Amos 5: Lamentation and Call to Seek YHWH

*From the Hebrew: שִׁמְעוּ אֶת־הַדָּבָר הַזֶּה (Shim'u Et-Ha-Davar Ha-Zeh) — Hear This Word*

---

## Lamentation over Israel (5:1-3)

**5:1** Hear this word which I take up for a lamentation over you, O house of Israel:

**5:2** The virgin of Israel is fallen, she shall no more rise; she is cast down upon her land, there is none to raise her up.

**5:3** For thus says the Lord YHWH: The city that went forth a thousand shall have a hundred left, and that which went forth a hundred shall have ten left, of the house of Israel.

---

## Seek YHWH and Live (5:4-17)

**5:4** For thus says YHWH unto the house of Israel: Seek me, and live;

**5:5** But seek not Bethel, nor enter into Gilgal, and pass not to Beer-sheba; for Gilgal shall surely go into captivity, and Bethel shall come to nought.

**5:6** Seek YHWH, and live; lest he break out like fire in the house of Joseph, and it devour, and there be none to quench it in Bethel.

**5:7** You who turn justice to wormwood, and cast down righteousness to the earth!

**5:8** Him that makes the Pleiades and Orion, and turns the shadow of death into the morning, and makes the day dark with night; that calls for the waters of the sea, and pours them out upon the face of the earth; YHWH is his name;

**5:9** That causes destruction to flash upon the strong, so that destruction comes upon the fortress.

**5:10** They hate him that reproves in the gate, and they abhor him that speaks uprightly.

**5:11** Therefore, because you trample upon the poor, and take from him exactions of wheat; you have built houses of hewn stone, but you shall not dwell in them, you have planted pleasant vineyards, but you shall not drink the wine thereof.

**5:12** For I know how manifold are your transgressions, and how mighty are your sins; you that afflict the just, that take a ransom, and that turn aside the needy in the gate.

**5:13** Therefore the prudent does keep silence in such a time; for it is an evil time.

**5:14** Seek good, and not evil, that you may live; and so YHWH, the God of hosts, will be with you, as you say.

**5:15** Hate evil, and love good, and establish justice in the gate; it may be that YHWH, the God of hosts, will be gracious unto the remnant of Joseph.

**5:16** Therefore thus says YHWH, the God of hosts, the Lord: Lamentation shall be in all the broad places, and they shall say in all the streets: "Alas! Alas!" And they shall call the husbandman to mourning, and such as are skilful of lamentation to wailing.

**5:17** And in all vineyards shall be lamentation; for I will pass through the midst of you, says YHWH.

---

## The Day of YHWH (5:18-27)

**5:18** Woe unto you that desire the day of YHWH! Wherefore would you have the day of YHWH? It is darkness, and not light.

**5:19** As if a man did flee from a lion, and a bear met him; or went into the house and leaned his hand on the wall, and a serpent bit him.

**5:20** Shall not the day of YHWH be darkness, and not light? Even very dark, and no brightness in it?

**5:21** I hate, I despise your feasts, and I will take no delight in your solemn assemblies.

**5:22** Yea, though you offer me burnt-offerings and your meal-offerings, I will not accept them; neither will I regard the peace-offerings of your fat beasts.

**5:23** Take away from me the noise of your songs; and let me not hear the melody of your psalteries.

**5:24** But let justice roll down as waters, and righteousness as a mighty stream.

**5:25** Did you bring unto me sacrifices and offerings in the wilderness forty years, O house of Israel?

**5:26** So shall you take up Sikkuth your king and Chiun your images, the star of your god, which you made to yourselves.

**5:27** Therefore will I cause you to go into captivity beyond Damascus, says YHWH, whose name is the God of hosts.

---

## Synthesis Notes

**Key Restorations:**

**Lamentation over Israel (5:1-3):**
**The Key Verses (5:1-3):**
"'Hear this word which I take up for a lamentation over you.'"

*Shim'u et-ha-davar ha-zeh asher anokhi nose aleikhem qinah*—lamentation.

**Qinah:**
"Lamentation"—funeral dirge meter.

"'The virgin of Israel is fallen, she shall no more rise.'"

*Nafelah lo-tosif qum betulat Yisra'el*—fallen virgin.

"'She is cast down upon her land, there is none to raise her up.'"

*Nitteshshah al-admatah ein meqimah*—abandoned.

"'The city that went forth a thousand shall have a hundred left.'"

*Ha-ir ha-yotzet elef tash'ir me'ah*—90% loss.

"'That which went forth a hundred shall have ten left.'"

*Ve-ha-yotzet me'ah tash'ir asarah le-veit Yisra'el*—90% loss.

**Seek YHWH and Live (5:4-17):**
**The Key Verses (5:4-6):**
"'Seek me, and live.'"

*Direshuni vi-chyu*—seek and live.

"'Seek not Bethel, nor enter into Gilgal, and pass not to Beer-sheba.'"

*Ve-al-tidreshu Beit-El ve-ha-Gilgal lo tavo'u u-Ve'er Sheva lo ta'avoru*—avoid shrines.

"'Gilgal shall surely go into captivity.'"

*Ki ha-Gilgal galoh yigleh*—wordplay: Gilgal → galoh (exile).

"'Bethel shall come to nought.'"

*U-Beit-El yihyeh le-aven*—wordplay: Bethel → aven (nothing/wickedness).

"'Seek YHWH, and live.'"

*Direshu et-YHWH vi-chyu*—seek and live.

"'Lest he break out like fire in the house of Joseph.'"

*Pen-yitzlach ka-esh beit Yosef*—fire on Joseph.

**The Key Verses (5:7-9):**
"'You who turn justice to wormwood.'"

*Ha-hofkhim le-la'anah mishpat*—justice to wormwood.

"'Cast down righteousness to the earth.'"

*U-tzedaqah la-aretz hinnichu*—cast down righteousness.

"'Him that makes the Pleiades and Orion.'"

*Oseh khimah u-khesil*—Pleiades, Orion.

"'Turns the shadow of death into the morning.'"

*Ve-hofekh la-boqer tzalmavet*—death-shadow to morning.

"'Makes the day dark with night.'"

*Ve-yom laylah hechshikh*—day to night.

"'Calls for the waters of the sea, and pours them out upon the face of the earth.'"

*Ha-qore le-mei-ha-yam va-yishpekhem al-penei ha-aretz*—pours sea.

"'YHWH is his name.'"

*YHWH shemo*—YHWH his name.

**Second Doxology:**
Praising YHWH's cosmic power.

**The Key Verses (5:10-13):**
"'They hate him that reproves in the gate.'"

*Sane'u va-sha'ar mokhiach*—hate reprover.

"'They abhor him that speaks uprightly.'"

*Ve-dover tamim yeta'evu*—abhor upright.

"'Because you trample upon the poor.'"

*Lakhen ya'an boshasekhem al-dal*—trample poor.

"'Take from him exactions of wheat.'"

*U-mas'at-bar tiqqechu mimmennו*—grain tax.

"'You have built houses of hewn stone, but you shall not dwell in them.'"

*Battei gazit benitem ve-lo-teshvu vam*—won't dwell.

"'You have planted pleasant vineyards, but you shall not drink the wine thereof.'"

*Karmei-chemed neta'tem ve-lo tishtu et-yeinam*—won't drink.

"'I know how manifold are your transgressions.'"

*Ki yada'ti rabbim pish'eikhem*—many transgressions.

"'How mighty are your sins.'"

*Va-atzumim chattoteikhem*—mighty sins.

"'You that afflict the just, that take a ransom.'"

*Tzorerei tzaddiq loqechei kofer*—afflict just, take bribes.

"'Turn aside the needy in the gate.'"

*Ve-evyonim ba-sha'ar hittו*—pervert justice.

"'The prudent does keep silence... for it is an evil time.'"

*Lakhen ha-maskil ba-et ha-hi yiddom ki et ra'ah hi*—evil time.

**The Key Verses (5:14-15):**
"'Seek good, and not evil, that you may live.'"

*Direshu-tov ve-al-ra lema'an tichyu*—seek good.

"'So YHWH, the God of hosts, will be with you, as you say.'"

*Vi-yhi-khen YHWH Elohei-tzeva'ot ittekhem ka-asher amartem*—be with you.

"'Hate evil, and love good.'"

*Sin'u-ra ve-ehevu tov*—hate evil, love good.

"'Establish justice in the gate.'"

*Ve-hatzzigu va-sha'ar mishpat*—establish justice.

"'It may be that YHWH... will be gracious unto the remnant of Joseph.'"

*Ulai yechannen YHWH... she'erit Yosef*—perhaps gracious.

**The Key Verses (5:16-17):**
"'Lamentation shall be in all the broad places.'"

*Be-khol-rechevot misped*—lamentation everywhere.

"'They shall say in all the streets: Alas! Alas!'"

*U-ve-khol-chutzot yomeru ho-ho*—alas.

"'They shall call the husbandman to mourning.'"

*Ve-qare'u ikkar el-evel*—farmers mourn.

"'In all vineyards shall be lamentation.'"

*U-ve-khol-keramim misped*—vineyards mourn.

"'For I will pass through the midst of you.'"

*Ki-e'evor be-qirbeka*—pass through.

**Day of YHWH (5:18-27):**
**The Key Verses (5:18-20):**
"'Woe unto you that desire the day of YHWH!'"

*Hoy ha-mit'avvim et-yom YHWH*—woe to desirers.

"'Wherefore would you have the day of YHWH?'"

*Lammah-zeh lakhem yom YHWH*—why desire it?

"'It is darkness, and not light.'"

*Hu-choshekh ve-lo-or*—darkness.

"'As if a man did flee from a lion, and a bear met him.'"

*Ka-asher yanus ish mippenei ha-ari u-fega'o ha-dov*—lion to bear.

"'Went into the house and leaned his hand on the wall, and a serpent bit him.'"

*U-va ha-bayit ve-samakh yado al-ha-qir u-neshakho ha-nachash*—serpent bites.

"'Shall not the day of YHWH be darkness, and not light?'"

*Ha-lo-choshekh yom YHWH ve-lo-or*—darkness.

"'Even very dark, and no brightness in it?'"

*Ve-afel ve-lo-nogah lo*—no brightness.

**The Key Verses (5:21-24):**
"'I hate, I despise your feasts.'"

*Saneti ma'asti chaggeikem*—hate feasts.

"'I will take no delight in your solemn assemblies.'"

*Ve-lo ariach be-atzzrotekhem*—no delight.

"'Though you offer me burnt-offerings and your meal-offerings, I will not accept them.'"

*Ki im-ta'alu-li olot u-minchotekhem lo ertzeh*—not accept.

"'Neither will I regard the peace-offerings of your fat beasts.'"

*Ve-shelem meri'eikhem lo abbit*—not regard.

"'Take away from me the noise of your songs.'"

*Haser me-alai hamon shirekha*—remove songs.

"'Let me not hear the melody of your psalteries.'"

*Ve-zimrat nevalekha lo eshma*—not hear melody.

"'But let justice roll down as waters.'"

*Ve-yiggal ka-mayim mishpat*—justice roll.

"'And righteousness as a mighty stream.'"

*U-tzedaqah ke-nachal eitan*—mighty stream.

**Mishpat... Tzedaqah:**
Justice and righteousness—the heart of prophetic ethics.

**The Key Verses (5:25-27):**
"'Did you bring unto me sacrifices and offerings in the wilderness forty years?'"

*Ha-zevachim u-minchah higgashtem-li va-midbar arba'im shanah beit Yisra'el*—wilderness sacrifices?

"'So shall you take up Sikkuth your king and Chiun your images.'"

*U-nesa'tem et Sikkut malkekhem ve-et Kiyyun tzalmekhem*—idols.

"'The star of your god, which you made to yourselves.'"

*Kokhav Eloheikhem asher asitem lakhem*—star god.

"'I will cause you to go into captivity beyond Damascus.'"

*Ve-higleiti etkhem me-hal'ah le-Dammeseq*—exile beyond Damascus.

**Archetypal Layer:** Amos 5 contains **the funeral dirge over Israel (5:1-3)**, **"Seek me, and live" (5:4)**, **avoid corrupt shrines: Bethel, Gilgal, Beer-sheba (5:5)**, **"you who turn justice to wormwood" (5:7)**, **the second doxology: Pleiades, Orion (5:8-9)**, **"they hate him that reproves in the gate" (5:10)**, **"you trample upon the poor" (5:11)**, **"Seek good, and not evil, that you may live" (5:14)**, **"hate evil, and love good, and establish justice in the gate" (5:15)**, **"Woe unto you that desire the day of YHWH! It is darkness, and not light" (5:18-20)**, **"I hate, I despise your feasts" (5:21)**, and **"let justice roll down as waters, and righteousness as a mighty stream" (5:24)**.

**Ethical Inversion Applied:**
- "'Hear this word which I take up for a lamentation'"—funeral dirge
- "'The virgin of Israel is fallen, she shall no more rise'"—fallen
- "'The city that went forth a thousand shall have a hundred left'"—90% loss
- "'Seek me, and live'"—seek and live
- "'Seek not Bethel'"—avoid Bethel
- "'Gilgal shall surely go into captivity'"—Gilgal exiled
- "'Bethel shall come to nought'"—Bethel nothing
- "'Seek YHWH, and live'"—seek and live
- "'You who turn justice to wormwood'"—wormwood
- "'Cast down righteousness to the earth'"—cast down
- "'Him that makes the Pleiades and Orion'"—cosmic power
- "'They hate him that reproves in the gate'"—hate reprover
- "'They abhor him that speaks uprightly'"—abhor upright
- "'Because you trample upon the poor'"—trample poor
- "'You have built houses of hewn stone, but you shall not dwell in them'"—futility
- "'I know how manifold are your transgressions'"—many sins
- "'You that afflict the just, that take a ransom'"—bribery
- "'Turn aside the needy in the gate'"—pervert justice
- "'The prudent does keep silence... for it is an evil time'"—evil time
- "'Seek good, and not evil, that you may live'"—seek good
- "'Hate evil, and love good'"—hate evil
- "'Establish justice in the gate'"—establish justice
- "'It may be that YHWH... will be gracious'"—perhaps
- "'Lamentation shall be in all the broad places'"—lamentation
- "'Woe unto you that desire the day of YHWH!'"—woe
- "'It is darkness, and not light'"—darkness
- "'As if a man did flee from a lion, and a bear met him'"—no escape
- "'I hate, I despise your feasts'"—hate feasts
- "'I will not accept them'"—not accept
- "'Take away from me the noise of your songs'"—remove songs
- "'Let justice roll down as waters'"—justice roll
- "'And righteousness as a mighty stream'"—mighty stream
- "'Did you bring unto me sacrifices... in the wilderness?'"—wilderness
- "'I will cause you to go into captivity beyond Damascus'"—exile

**Modern Equivalent:** Amos 5 is central to prophetic ethics. "Seek me, and live" (5:4, 6) offers hope. The Day of YHWH reversal (5:18-20) shatters false hope—it will be darkness, not light. "I hate, I despise your feasts" (5:21) shows worship without justice is abhorrent. "Let justice roll down as waters" (5:24) is the prophetic call—Martin Luther King Jr. quoted this passage.

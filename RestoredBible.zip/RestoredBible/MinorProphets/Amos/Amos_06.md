# Amos 6: Woe to the Complacent

*From the Hebrew: הוֹי הַשַּׁאֲנַנִּים בְּצִיּוֹן (Hoy Ha-Sha'anannim Be-Tziyon) — Woe to Them That Are at Ease in Zion*

---

## Woe to the Complacent (6:1-7)

**6:1** Woe to them that are at ease in Zion, and to them that are secure in the mountain of Samaria, the notable men of the first of the nations, to whom the house of Israel come!

**6:2** Pass unto Calneh, and see, and from thence go to Hamath the great; then go down to Gath of the Philistines; are they better than these kingdoms? Or is their border greater than your border?

**6:3** You that put far away the evil day, and cause the seat of violence to come near;

**6:4** That lie upon beds of ivory, and stretch themselves upon their couches, and eat the lambs out of the flock, and the calves out of the midst of the stall;

**6:5** That chant to the sound of the psaltery, and invent to themselves instruments of music, like David;

**6:6** That drink wine in bowls, and anoint themselves with the chief ointments; but they are not grieved for the hurt of Joseph.

**6:7** Therefore now shall they go captive at the head of them that go captive, and the revelry of them that stretched themselves shall pass away.

---

## YHWH's Oath and Judgment (6:8-14)

**6:8** The Lord YHWH has sworn by himself, says YHWH, the God of hosts: I abhor the pride of Jacob, and hate his palaces; and I will deliver up the city with all that is therein.

**6:9** And it shall come to pass, if there remain ten men in one house, that they shall die.

**6:10** And when a man's kinsman shall take him up, even he that burns him, to bring out the bones out of the house, and shall say unto him that is in the innermost parts of the house: "Is there yet any with you?" And he shall say: "No"; then shall he say: "Hold your peace; for we must not make mention of the name of YHWH."

**6:11** For, behold, YHWH commands, and the great house shall be smitten into splinters, and the little house into chips.

**6:12** Do horses run upon the rocks? Does one plow there with oxen? That you have turned justice into gall, and the fruit of righteousness into wormwood;

**6:13** You that rejoice in a thing of nought, that say: "Have we not taken to us horns by our own strength?"

**6:14** For, behold, I will raise up against you a nation, O house of Israel, says YHWH, the God of hosts; and they shall afflict you from the entrance of Hamath unto the brook of the Arabah.

---

## Synthesis Notes

**Key Restorations:**

**Woe to the Complacent (6:1-7):**
**The Key Verse (6:1):**
"'Woe to them that are at ease in Zion.'"

*Hoy ha-sha'anannim be-Tziyon*—at ease in Zion.

"'To them that are secure in the mountain of Samaria.'"

*Ve-ha-botchim be-har Shomeron*—secure in Samaria.

"'The notable men of the first of the nations.'"

*Nequvei reshit ha-goyim*—notable men.

"'To whom the house of Israel come.'"

*U-va'u lahem beit Yisra'el*—Israel comes.

**The Key Verse (6:2):**
"'Pass unto Calneh, and see, and from thence go to Hamath the great.'"

*Ivru Khalneh u-re'u u-lekhu mi-sham Chamat rabbah*—see fallen cities.

"'Then go down to Gath of the Philistines.'"

*U-redu Gat Pelishtim*—Gath.

"'Are they better than these kingdoms?'"

*Ha-tovim min-ha-mamlakhot ha-elleh*—better?

"'Or is their border greater than your border?'"

*Im-rav gevulam mi-gevulkhem*—greater border?

**The Key Verses (6:3-6):**
"'You that put far away the evil day.'"

*Ha-menadim le-yom ra*—put off evil day.

"'Cause the seat of violence to come near.'"

*Va-taggishun shevet chamas*—bring violence.

"'That lie upon beds of ivory.'"

*Ha-shokevim al-mittot shen*—ivory beds.

"'Stretch themselves upon their couches.'"

*U-seruchim al-arsotam*—stretch on couches.

"'Eat the lambs out of the flock.'"

*Ve-okhelim karim mi-tzon*—choice lambs.

"'The calves out of the midst of the stall.'"

*Va-agalim mi-tokh marbeq*—stall-fed calves.

"'That chant to the sound of the psaltery.'"

*Ha-portim al-pi ha-navel*—chant to harp.

"'Invent to themselves instruments of music, like David.'"

*Ke-David chashvu lahem kelei-shir*—like David.

"'That drink wine in bowls.'"

*Ha-shotim be-mizraqei yayin*—wine in bowls.

"'Anoint themselves with the chief ointments.'"

*Ve-reshit shemanים yimשachu*—fine oils.

"'They are not grieved for the hurt of Joseph.'"

*Ve-lo nechlו al-shever Yosef*—not grieved.

**Shever Yosef:**
"The hurt/ruin of Joseph"—the northern kingdom's collapse.

**The Key Verse (6:7):**
"'Therefore now shall they go captive at the head of them that go captive.'"

*Lakhen attah yiglu be-rosh golim*—first exiled.

"'The revelry of them that stretched themselves shall pass away.'"

*Ve-sar mirzach seruchim*—revelry ends.

**YHWH's Oath and Judgment (6:8-14):**
**The Key Verse (6:8):**
"'The Lord YHWH has sworn by himself.'"

*Nishba Adonai YHWH be-nafsho*—sworn by self.

"'I abhor the pride of Jacob.'"

*Meta'ev anokhi et-ge'on Ya'aqov*—abhor pride.

"'Hate his palaces.'"

*Ve-armenotav saneti*—hate palaces.

"'I will deliver up the city with all that is therein.'"

*Ve-hisgarti ir u-melo'ah*—deliver up city.

**The Key Verses (6:9-10):**
"'If there remain ten men in one house, that they shall die.'"

*Ve-hayah im-yivvateru asarah anashim be-vayit echad va-metu*—ten die.

"'When a man's kinsman shall take him up, even he that burns him.'"

*U-nesa'o dodo u-mesarfo*—kinsman burns.

"'To bring out the bones out of the house.'"

*Le-hotzi atzamim min-ha-bayit*—bring bones.

"''Is there yet any with you?' And he shall say: 'No.''"

*Ha-od immakh va-amar efes*—none left.

"''Hold your peace; for we must not make mention of the name of YHWH.''"

*Ve-amar has ki lo le-hazkir be-shem YHWH*—silence.

**The Key Verse (6:11):**
"'YHWH commands, and the great house shall be smitten into splinters.'"

*Ki-hinneh YHWH metzavveh ve-hikkah ha-bayit ha-gadol resisim*—great house splinters.

"'The little house into chips.'"

*Ve-ha-bayit ha-qatan beqi'im*—little house chips.

**The Key Verses (6:12-14):**
"'Do horses run upon the rocks? Does one plow there with oxen?'"

*Ha-yerutzun ba-sela susim im-yacharosh ba-beqarim*—absurd.

"'That you have turned justice into gall.'"

*Ki-hafakhtem le-rosh mishpat*—justice to gall.

"'The fruit of righteousness into wormwood.'"

*U-feri tzedaqah la-la'anah*—righteousness to wormwood.

"'You that rejoice in a thing of nought.'"

*Ha-semechim le-lo davar*—rejoice in nothing.

"'Have we not taken to us horns by our own strength?'"

*Ha-lo ve-chozqenu laqachnu lanu qarnayim*—our strength.

"'I will raise up against you a nation.'"

*Ki hineni meqim aleikhem... goy*—nation against you.

"'They shall afflict you from the entrance of Hamath unto the brook of the Arabah.'"

*Ve-lachatzו etkhem mi-levo Chamat ad-nachal ha-Aravah*—whole land.

**Archetypal Layer:** Amos 6 contains **"Woe to them that are at ease in Zion" (6:1)**, **complacent luxury: ivory beds, choice meat, music, wine, fine oils (6:4-6)**, **"they are not grieved for the hurt of Joseph" (6:6)**, **"they shall go captive at the head of them that go captive" (6:7)**, **"I abhor the pride of Jacob, and hate his palaces" (6:8)**, **the eerie scene of collecting bones in silence (6:9-10)**, **"you have turned justice into gall, and the fruit of righteousness into wormwood" (6:12)**, and **"I will raise up against you a nation" (6:14)**.

**Ethical Inversion Applied:**
- "'Woe to them that are at ease in Zion'"—at ease
- "'To them that are secure in the mountain of Samaria'"—secure
- "'The notable men of the first of the nations'"—notable
- "'Pass unto Calneh, and see'"—learn from fallen
- "'Are they better than these kingdoms?'"—not better
- "'You that put far away the evil day'"—denial
- "'Cause the seat of violence to come near'"—violence
- "'That lie upon beds of ivory'"—luxury
- "'Stretch themselves upon their couches'"—indolence
- "'Eat the lambs out of the flock'"—choice food
- "'The calves out of the midst of the stall'"—stall-fed
- "'That chant to the sound of the psaltery'"—music
- "'Invent to themselves instruments of music, like David'"—like David
- "'That drink wine in bowls'"—excessive wine
- "'Anoint themselves with the chief ointments'"—fine oils
- "'They are not grieved for the hurt of Joseph'"—unconcerned
- "'They shall go captive at the head of them that go captive'"—first exiled
- "'The revelry... shall pass away'"—revelry ends
- "'The Lord YHWH has sworn by himself'"—oath
- "'I abhor the pride of Jacob'"—abhor pride
- "'Hate his palaces'"—hate palaces
- "'I will deliver up the city'"—deliver up
- "'If there remain ten men in one house, that they shall die'"—all die
- "''Is there yet any with you?' 'No''"—none left
- "''Hold your peace; for we must not make mention of the name of YHWH''"—silence
- "'The great house shall be smitten into splinters'"—splinters
- "'Do horses run upon the rocks?'"—absurd
- "'You have turned justice into gall'"—gall
- "'The fruit of righteousness into wormwood'"—wormwood
- "'You that rejoice in a thing of nought'"—rejoice in nothing
- "''Have we not taken to us horns by our own strength?''"—pride
- "'I will raise up against you a nation'"—nation against
- "'They shall afflict you from... Hamath unto... the Arabah'"—whole land

**Modern Equivalent:** Amos 6 attacks the wealthy elite's complacency. They live in luxury—ivory beds, fine food, music, wine, oils (6:4-6)—"but they are not grieved for the hurt of Joseph" (6:6). Social collapse doesn't disturb their parties. Therefore they'll lead the exile procession (6:7). The rhetorical question (6:12)—horses on rocks, oxen plowing stone—shows their perversion of justice is absurd.

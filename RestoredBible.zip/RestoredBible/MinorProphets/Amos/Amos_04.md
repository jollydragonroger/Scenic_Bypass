# Amos 4: Cows of Bashan and Failed Warnings

*From the Hebrew: שִׁמְעוּ הַדָּבָר הַזֶּה פָּרוֹת הַבָּשָׁן (Shim'u Ha-Davar Ha-Zeh Parot Ha-Bashan) — Hear This Word, You Cows of Bashan*

---

## Indictment of the Wealthy Women (4:1-3)

**4:1** Hear this word, you cows of Bashan, that are in the mountain of Samaria, that oppress the poor, that crush the needy, that say unto their lords: "Bring, and let us drink."

**4:2** The Lord YHWH has sworn by his holiness: Lo, surely the days shall come upon you, that you shall be taken away with hooks, and your residue with fish-hooks.

**4:3** And you shall go out at the breaches, every one straight before her; and you shall be cast forth toward Harmon, says YHWH.

---

## Sarcastic Call to Worship (4:4-5)

**4:4** Come to Bethel, and transgress; to Gilgal, and multiply transgression; and bring your sacrifices in the morning, and your tithes after three days;

**4:5** And offer a sacrifice of thanksgiving of that which is leavened, and proclaim freewill-offerings, publish them; for so you love to do, O you children of Israel, says the Lord YHWH.

---

## Five Warnings Ignored (4:6-11)

**4:6** And I also have given you cleanness of teeth in all your cities, and want of bread in all your places; yet have you not returned unto me, says YHWH.

**4:7** And I also have withholden the rain from you, when there were yet three months to the harvest; and I caused it to rain upon one city, and caused it not to rain upon another city; one piece was rained upon, and the piece whereupon it rained not withered.

**4:8** So two or three cities wandered unto one city to drink water, and were not satisfied; yet have you not returned unto me, says YHWH.

**4:9** I have smitten you with blasting and mildew; the multitude of your gardens and your vineyards and your fig-trees and your olive-trees has the palmerworm devoured; yet have you not returned unto me, says YHWH.

**4:10** I have sent among you the pestilence after the manner of Egypt; your young men have I slain with the sword, and have carried away your horses; and I have made the stench of your camp to come up even into your nostrils; yet have you not returned unto me, says YHWH.

**4:11** I have overthrown some of you, as God overthrew Sodom and Gomorrah, and you were as a brand plucked out of the burning; yet have you not returned unto me, says YHWH.

---

## Prepare to Meet Your God (4:12-13)

**4:12** Therefore thus will I do unto you, O Israel; because I will do this unto you, prepare to meet your God, O Israel.

**4:13** For, lo, he that forms the mountains, and creates the wind, and declares unto man what is his thought, that makes the morning darkness, and treads upon the high places of the earth; YHWH, the God of hosts, is his name.

---

## Synthesis Notes

**Key Restorations:**

**Indictment of the Wealthy Women (4:1-3):**
**The Key Verse (4:1):**
"'Hear this word, you cows of Bashan.'"

*Shim'u ha-davar ha-zeh parot ha-Bashan*—cows of Bashan.

**Parot Ha-Bashan:**
"Cows of Bashan"—well-fed cattle from the lush Bashan region; here, wealthy women of Samaria.

"'That are in the mountain of Samaria.'"

*Asher be-har Shomeron*—Samaria.

"'That oppress the poor, that crush the needy.'"

*Ha-oshqot dallim ha-rotzetzot evyonim*—oppress, crush.

"'That say unto their lords: Bring, and let us drink.'"

*Ha-omerot la-adoneihem havi'ah ve-nishteh*—bring drink.

**The Key Verses (4:2-3):**
"'The Lord YHWH has sworn by his holiness.'"

*Nishba Adonai YHWH be-qodsho*—sworn by holiness.

"'The days shall come upon you, that you shall be taken away with hooks.'"

*Ki hinneh yamim ba'im aleikhem ve-nissa etkhem be-tzinnot*—taken with hooks.

"'Your residue with fish-hooks.'"

*Ve-acharitekhen be-sirot dugah*—fish-hooks.

"'You shall go out at the breaches.'"

*U-feratzot tetzenah*—through breaches.

"'You shall be cast forth toward Harmon.'"

*Ve-hishlakhtenah ha-Harmonah*—to Harmon.

**Sarcastic Call to Worship (4:4-5):**
**The Key Verses (4:4-5):**
"'Come to Bethel, and transgress.'"

*Bo'u Beit-El u-fish'u*—transgress at Bethel.

"'To Gilgal, and multiply transgression.'"

*Ha-Gilgal harbu lifshoa*—multiply transgression.

"'Bring your sacrifices in the morning.'"

*Ve-havi'u la-boqer zivhheikhem*—morning sacrifices.

"'Your tithes after three days.'"

*Li-shloshet yamim ma'aseroteikhem*—tithes.

"'Offer a sacrifice of thanksgiving of that which is leavened.'"

*Ve-qatter me-chametz todah*—leavened offering.

"'Proclaim freewill-offerings, publish them.'"

*Ve-qir'u nedavot hashmi'u*—proclaim.

"'For so you love to do, O you children of Israel.'"

*Ki khen ahavtem benei Yisra'el*—you love this.

**Sarcasm:**
Amos mockingly invites them to worship—their worship is sin because they oppress the poor.

**Five Warnings Ignored (4:6-11):**
**The Key Verse (4:6):**
"'I also have given you cleanness of teeth in all your cities.'"

*Ve-gam-ani natatti lakhem niqqayon shinnayim be-khol-areikhem*—clean teeth = no food.

"'Want of bread in all your places.'"

*Ve-choser lechem be-khol-meqomoteikhem*—no bread.

"'Yet have you not returned unto me.'"

*Ve-lo-shavtem adai*—didn't return.

**Refrain:**
"Yet have you not returned unto me" appears five times (4:6, 8, 9, 10, 11).

**The Key Verses (4:7-8):**
"'I have withholden the rain from you.'"

*Ve-gam anokhi mana'ti mikkem et-ha-geshem*—withheld rain.

"'When there were yet three months to the harvest.'"

*Be-od sheloshah chodashim la-qatzir*—3 months before harvest.

"'I caused it to rain upon one city, and caused it not to rain upon another city.'"

*Ve-himtarti al-ir achat ve-al-ir achat lo amtir*—selective rain.

"'Two or three cities wandered unto one city to drink water.'"

*Ve-nad'u shetayim shalosh arim el-ir achat lishtot mayim*—water shortage.

"'Were not satisfied.'"

*Ve-lo yisba'u*—not satisfied.

"'Yet have you not returned unto me.'"

*Ve-lo-shavtem adai*—didn't return.

**The Key Verse (4:9):**
"'I have smitten you with blasting and mildew.'"

*Hikkeiti etkhem ba-shiddafon u-va-yerakon*—blasting, mildew.

"'The multitude of your gardens and your vineyards and your fig-trees and your olive-trees has the palmerworm devoured.'"

*Harbot gannotekhem ve-kharmeikhem u-te'eneikhem ve-zeitेikhem yokhal ha-gazam*—locusts.

"'Yet have you not returned unto me.'"

*Ve-lo-shavtem adai*—didn't return.

**The Key Verse (4:10):**
"'I have sent among you the pestilence after the manner of Egypt.'"

*Shillachti vakhem dever be-derekh Mitzrayim*—Egyptian pestilence.

"'Your young men have I slain with the sword.'"

*Haragti va-cherev bachureikhem*—slain youth.

"'Have carried away your horses.'"

*Im shebi suseikhem*—horses taken.

"'I have made the stench of your camp to come up even into your nostrils.'"

*Va-a'aleh be'osh machanekhem u-ve-appekhem*—stench.

"'Yet have you not returned unto me.'"

*Ve-lo-shavtem adai*—didn't return.

**The Key Verse (4:11):**
"'I have overthrown some of you, as God overthrew Sodom and Gomorrah.'"

*Hafakhti vakhem ke-mahpekat Elohim et-Sedom ve-et-Amorah*—like Sodom.

"'You were as a brand plucked out of the burning.'"

*Va-tihyu ke-ud mutzal mi-serefah*—brand from fire.

"'Yet have you not returned unto me.'"

*Ve-lo-shavtem adai*—didn't return.

**Prepare to Meet Your God (4:12-13):**
**The Key Verse (4:12):**
"'Therefore thus will I do unto you, O Israel.'"

*Lakhen koh e'eseh-lekha Yisra'el*—I will do.

"'Because I will do this unto you, prepare to meet your God, O Israel.'"

*Eqev ki-zot e'eseh-lekha hikkon liqrat-Elohekha Yisra'el*—prepare to meet God.

**Hikkon Liqrat-Elohekha:**
"Prepare to meet your God"—ominous summons to judgment.

**The Key Verse (4:13):**
"'He that forms the mountains, and creates the wind.'"

*Ki hinneh yotzer harim u-vore ru'ach*—forms mountains.

"'Declares unto man what is his thought.'"

*U-maggid le-adam mah-seho*—declares thought.

"'Makes the morning darkness.'"

*Oseh shachar eifah*—makes dawn dark.

"'Treads upon the high places of the earth.'"

*Ve-dorekh al-bamotei aretz*—treads high places.

"'YHWH, the God of hosts, is his name.'"

*YHWH Elohei-tzeva'ot shemo*—YHWH of hosts.

**First Doxology:**
One of three hymnic passages praising YHWH's cosmic power (cf. 5:8-9; 9:5-6).

**Archetypal Layer:** Amos 4 contains **"Hear this word, you cows of Bashan" (4:1)**—wealthy women who oppress the poor, **sarcastic invitation to worship at Bethel and Gilgal (4:4-5)**, **the fivefold refrain "yet have you not returned unto me" (4:6, 8, 9, 10, 11)** after famine, drought, blight, pestilence, and overthrow, **"prepare to meet your God, O Israel" (4:12)**, and the **first doxology praising YHWH's cosmic power (4:13)**.

**Ethical Inversion Applied:**
- "'Hear this word, you cows of Bashan'"—wealthy women
- "'That oppress the poor, that crush the needy'"—oppression
- "'That say unto their lords: Bring, and let us drink'"—demand luxury
- "'You shall be taken away with hooks'"—hooks
- "'Your residue with fish-hooks'"—fish-hooks
- "'Come to Bethel, and transgress'"—sarcasm
- "'To Gilgal, and multiply transgression'"—multiply sin
- "'Bring your sacrifices in the morning'"—mock invitation
- "'For so you love to do'"—you love this
- "'I have given you cleanness of teeth'"—famine
- "'Want of bread in all your places'"—no bread
- "'Yet have you not returned unto me'"—refrain
- "'I have withholden the rain'"—drought
- "'I caused it to rain upon one city'"—selective rain
- "'Two or three cities wandered... to drink water'"—water crisis
- "'Yet have you not returned unto me'"—refrain
- "'I have smitten you with blasting and mildew'"—crop disease
- "'The palmerworm devoured'"—locusts
- "'Yet have you not returned unto me'"—refrain
- "'I have sent among you the pestilence'"—pestilence
- "'Your young men have I slain'"—slain youth
- "'Yet have you not returned unto me'"—refrain
- "'I have overthrown some of you, as God overthrew Sodom'"—like Sodom
- "'You were as a brand plucked out of the burning'"—barely survived
- "'Yet have you not returned unto me'"—refrain
- "'Prepare to meet your God, O Israel'"—prepare
- "'He that forms the mountains'"—cosmic power
- "'Creates the wind'"—wind
- "'Declares unto man what is his thought'"—knows thoughts
- "'YHWH, the God of hosts, is his name'"—YHWH of hosts

**Modern Equivalent:** Amos 4 attacks wealthy women ("cows of Bashan") who drive their husbands to oppress others to fund luxury (4:1). The sarcastic invitation to worship (4:4-5) shows that religious ritual without justice is sin. The fivefold "yet have you not returned" (4:6-11) shows ignored warnings. "Prepare to meet your God" (4:12) is ominous—not comfort but judgment.

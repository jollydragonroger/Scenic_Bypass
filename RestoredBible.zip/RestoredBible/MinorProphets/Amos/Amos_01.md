# Amos 1: Oracles Against the Nations

*From the Hebrew: דִּבְרֵי עָמוֹס (Divrei Amos) — The Words of Amos*

---

## Title and Introduction (1:1-2)

**1:1** The words of Amos, who was among the herdmen of Tekoa, which he saw concerning Israel in the days of Uzziah king of Judah, and in the days of Jeroboam the son of Joash king of Israel, two years before the earthquake.

**1:2** And he said: YHWH roars from Zion, and utters his voice from Jerusalem; and the pastures of the shepherds shall mourn, and the top of Carmel shall wither.

---

## Oracle Against Damascus (1:3-5)

**1:3** Thus says YHWH: For three transgressions of Damascus, yea, for four, I will not reverse it: because they have threshed Gilead with threshing-instruments of iron.

**1:4** So will I send a fire into the house of Hazael, and it shall devour the palaces of Ben-hadad.

**1:5** And I will break the bar of Damascus, and cut off the inhabitant from Bikath-aven, and him that holds the sceptre from Beth-eden; and the people of Aram shall go into captivity unto Kir, says YHWH.

---

## Oracle Against Philistia (1:6-8)

**1:6** Thus says YHWH: For three transgressions of Gaza, yea, for four, I will not reverse it: because they carried away captive a whole captivity, to deliver them up to Edom.

**1:7** So will I send a fire on the wall of Gaza, and it shall devour the palaces thereof.

**1:8** And I will cut off the inhabitant from Ashdod, and him that holds the sceptre from Ashkelon; and I will turn my hand against Ekron, and the remnant of the Philistines shall perish, says the Lord YHWH.

---

## Oracle Against Tyre (1:9-10)

**1:9** Thus says YHWH: For three transgressions of Tyre, yea, for four, I will not reverse it: because they delivered up a whole captivity to Edom, and remembered not the brotherly covenant.

**1:10** So will I send a fire on the wall of Tyre, and it shall devour the palaces thereof.

---

## Oracle Against Edom (1:11-12)

**1:11** Thus says YHWH: For three transgressions of Edom, yea, for four, I will not reverse it: because he did pursue his brother with the sword, and did cast off all pity, and his anger did tear perpetually, and he kept his wrath for ever.

**1:12** So will I send a fire upon Teman, and it shall devour the palaces of Bozrah.

---

## Oracle Against Ammon (1:13-15)

**1:13** Thus says YHWH: For three transgressions of the children of Ammon, yea, for four, I will not reverse it: because they have ripped up the women with child of Gilead, that they might enlarge their border.

**1:14** So will I kindle a fire in the wall of Rabbah, and it shall devour the palaces thereof, with shouting in the day of battle, with a tempest in the day of the whirlwind.

**1:15** And their king shall go into captivity, he and his princes together, says YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Title and Introduction (1:1-2):**
**The Key Verse (1:1):**
"The words of Amos, who was among the herdmen of Tekoa."

*Divrei Amos asher-hayah va-noqdim mi-Teqo'a*—Amos of Tekoa.

**Noqdim:**
"Herdmen" or "sheep-breeders"—Amos was not a professional prophet.

"Which he saw concerning Israel in the days of Uzziah king of Judah."

*Asher chazah al-Yisra'el bi-yemei Uzziyah melekh-Yehudah*—Uzziah's reign.

"In the days of Jeroboam the son of Joash king of Israel."

*U-vi-yemei Yarov'am ben-Yo'ash melekh Yisra'el*—Jeroboam II.

"Two years before the earthquake."

*Shеnatayim lifnei ha-ra'ash*—before earthquake.

**The Earthquake:**
A major earthquake remembered for centuries (Zechariah 14:5).

**The Key Verse (1:2):**
"'YHWH roars from Zion.'"

*YHWH mi-Tziyon yish'ag*—roars from Zion.

"'Utters his voice from Jerusalem.'"

*U-mi-Yrushalayim yitten qolo*—voice from Jerusalem.

"'The pastures of the shepherds shall mourn.'"

*Ve-avelu ne'ot ha-ro'im*—pastures mourn.

"'The top of Carmel shall wither.'"

*Ve-yavesh rosh ha-Karmel*—Carmel withers.

**Oracle Against Damascus (1:3-5):**
**The Key Verses (1:3-5):**
"'For three transgressions of Damascus, yea, for four, I will not reverse it.'"

*Al-sheloshah pish'ei Dammeseq ve-al-arba'ah lo ashivennu*—3+1 formula.

**Three... Four Formula:**
"For three... for four" = climactic enumeration, the last transgression being the final straw.

"'Because they have threshed Gilead with threshing-instruments of iron.'"

*Al-dusham ba-charutzot ha-barzel et-ha-Gil'ad*—threshed Gilead.

"'I will send a fire into the house of Hazael.'"

*Ve-shillachti esh be-veit Chaza'el*—fire on Hazael.

"'It shall devour the palaces of Ben-hadad.'"

*Ve-akhelah armenot Ben-Hadad*—palaces devoured.

"'I will break the bar of Damascus.'"

*Ve-shavarti beriach Dammeseq*—break bar.

"'The people of Aram shall go into captivity unto Kir.'"

*Ve-galu am-Aram Qirah*—exile to Kir.

**Oracle Against Philistia (1:6-8):**
**The Key Verses (1:6-8):**
"'For three transgressions of Gaza, yea, for four, I will not reverse it.'"

*Al-sheloshah pish'ei Azzah ve-al-arba'ah lo ashivennu*—Gaza.

"'Because they carried away captive a whole captivity, to deliver them up to Edom.'"

*Al-haglotam galut shelemah le-hasgir le-Edom*—slave trade.

"'I will send a fire on the wall of Gaza.'"

*Ve-shillachti esh be-chomat Azzah*—fire on Gaza.

"'I will cut off the inhabitant from Ashdod.'"

*Ve-hikhrati yoshev me-Ashdod*—cut off Ashdod.

"'Him that holds the sceptre from Ashkelon.'"

*Ve-tomekh shevet me-Ashqelon*—Ashkelon.

"'I will turn my hand against Ekron.'"

*Va-hashivoti yadi al-Eqron*—Ekron.

"'The remnant of the Philistines shall perish.'"

*Ve-avdu she'erit Pelishtim*—Philistines perish.

**Oracle Against Tyre (1:9-10):**
**The Key Verses (1:9-10):**
"'For three transgressions of Tyre, yea, for four, I will not reverse it.'"

*Al-sheloshah pish'ei Tzor ve-al-arba'ah lo ashivennu*—Tyre.

"'Because they delivered up a whole captivity to Edom.'"

*Al-hasgيram galut shelemah le-Edom*—slave trade.

"'Remembered not the brotherly covenant.'"

*Ve-lo zakheru berit achim*—forgot covenant.

**Berit Achim:**
"Brotherly covenant"—possibly David-Solomon's alliance with Hiram.

"'I will send a fire on the wall of Tyre.'"

*Ve-shillachti esh be-chomat Tzor*—fire on Tyre.

**Oracle Against Edom (1:11-12):**
**The Key Verses (1:11-12):**
"'For three transgressions of Edom, yea, for four, I will not reverse it.'"

*Al-sheloshah pish'ei Edom ve-al-arba'ah lo ashivennu*—Edom.

"'Because he did pursue his brother with the sword.'"

*Al-rodfo va-cherev achiv*—pursued brother.

"'Did cast off all pity.'"

*Ve-shichet rachamav*—no pity.

"'His anger did tear perpetually.'"

*Va-yitrof la-ad appo*—anger forever.

"'He kept his wrath for ever.'"

*Ve-evrato shemarah netzach*—wrath forever.

"'I will send a fire upon Teman.'"

*Ve-shillachti esh be-Teiman*—fire on Teman.

"'It shall devour the palaces of Bozrah.'"

*Ve-akhelah armenot Botzrah*—Bozrah devoured.

**Oracle Against Ammon (1:13-15):**
**The Key Verses (1:13-15):**
"'For three transgressions of the children of Ammon, yea, for four, I will not reverse it.'"

*Al-sheloshah pish'ei venei-Ammon ve-al-arba'ah lo ashivennu*—Ammon.

"'Because they have ripped up the women with child of Gilead.'"

*Al-biq'am harot ha-Gil'ad*—ripped pregnant women.

"'That they might enlarge their border.'"

*Lema'an harchiv et-gevulam*—enlarge border.

"'I will kindle a fire in the wall of Rabbah.'"

*Ve-hitzatti esh be-chomat Rabbah*—fire on Rabbah.

"'With shouting in the day of battle.'"

*Bi-teru'ah be-yom milchamah*—battle shout.

"'With a tempest in the day of the whirlwind.'"

*Be-sa'ar be-yom sufah*—whirlwind.

"'Their king shall go into captivity, he and his princes together.'"

*Ve-halakh malkam ba-golah hu ve-sarav yachdav*—king exiled.

**Archetypal Layer:** Amos 1 introduces the **prophet from Tekoa**, containing **"YHWH roars from Zion" (1:2)**, **"two years before the earthquake" (1:1)**, the **"for three... for four" formula** for climactic judgment, and **oracles against surrounding nations**: Damascus (1:3-5) for threshing Gilead, Gaza/Philistia (1:6-8) for slave trade, Tyre (1:9-10) for slave trade and forgetting covenant, Edom (1:11-12) for perpetual hostility to brother, Ammon (1:13-15) for war atrocities.

**Ethical Inversion Applied:**
- "The words of Amos, who was among the herdmen of Tekoa"—shepherd prophet
- "In the days of Uzziah... and... Jeroboam"—8th century BCE
- "Two years before the earthquake"—dated
- "'YHWH roars from Zion'"—roars
- "'The pastures of the shepherds shall mourn'"—pastures mourn
- "'The top of Carmel shall wither'"—Carmel withers
- "'For three transgressions... for four'"—climactic formula
- "'I will not reverse it'"—irreversible
- "'They have threshed Gilead with threshing-instruments of iron'"—brutality
- "'I will send a fire'"—fire judgment
- "'It shall devour the palaces'"—palaces devoured
- "'I will break the bar of Damascus'"—break bar
- "'The people of Aram shall go into captivity'"—exile
- "'They carried away captive a whole captivity'"—slave trade
- "'To deliver them up to Edom'"—to Edom
- "'I will cut off the inhabitant'"—cut off
- "'The remnant of the Philistines shall perish'"—perish
- "'They delivered up a whole captivity to Edom'"—slave trade
- "'Remembered not the brotherly covenant'"—forgot covenant
- "'He did pursue his brother with the sword'"—pursued brother
- "'Did cast off all pity'"—no pity
- "'His anger did tear perpetually'"—perpetual anger
- "'They have ripped up the women with child'"—atrocity
- "'That they might enlarge their border'"—territory
- "'With shouting in the day of battle'"—battle
- "'Their king shall go into captivity'"—king exiled

**Modern Equivalent:** Amos 1 opens with oracles against Israel's neighbors—Damascus, Philistia, Tyre, Edom, Ammon. The "for three... for four" formula emphasizes accumulated guilt. Sins condemned are humanitarian crimes: brutality (1:3), slave trade (1:6, 9), forgetting covenants (1:9), perpetual hatred (1:11), and war atrocities (1:13). The audience would applaud—until Amos turns to Israel.

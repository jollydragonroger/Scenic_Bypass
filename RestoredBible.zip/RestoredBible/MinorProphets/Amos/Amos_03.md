# Amos 3: Election Means Greater Accountability

*From the Hebrew: שִׁמְעוּ אֶת־הַדָּבָר הַזֶּה (Shim'u Et-Ha-Davar Ha-Zeh) — Hear This Word*

---

## Election and Accountability (3:1-2)

**3:1** Hear this word that YHWH has spoken against you, O children of Israel, against the whole family which I brought up out of the land of Egypt, saying:

**3:2** You only have I known of all the families of the earth; therefore I will visit upon you all your iniquities.

---

## Cause and Effect (3:3-8)

**3:3** Will two walk together, except they have agreed?

**3:4** Will a lion roar in the forest, when he has no prey? Will a young lion give forth his voice out of his den, if he have taken nothing?

**3:5** Will a bird fall in a snare upon the earth, where there is no lure for it? Will a snare spring up from the ground, and have taken nothing at all?

**3:6** Shall the horn be blown in a city, and the people not tremble? Shall evil befall a city, and YHWH has not done it?

**3:7** For the Lord YHWH will do nothing, but he reveals his secret unto his servants the prophets.

**3:8** The lion has roared, who will not fear? The Lord YHWH has spoken, who can but prophesy?

---

## Witness Against Samaria (3:9-15)

**3:9** Proclaim it upon the palaces in Ashdod, and upon the palaces in the land of Egypt, and say: "Assemble yourselves upon the mountains of Samaria, and behold the great confusions therein, and the oppressions in the midst thereof."

**3:10** For they know not to do right, says YHWH, who store up violence and robbery in their palaces.

**3:11** Therefore thus says the Lord YHWH: An adversary, even round about the land! And he shall bring down your strength from you, and your palaces shall be spoiled.

**3:12** Thus says YHWH: As the shepherd rescues out of the mouth of the lion two legs, or a piece of an ear, so shall the children of Israel that dwell in Samaria escape with the corner of a couch, and the leg of a bed.

**3:13** Hear, and testify against the house of Jacob, says the Lord YHWH, the God of hosts.

**3:14** For in the day that I shall visit the transgressions of Israel upon him, I will also punish the altars of Bethel, and the horns of the altar shall be cut off, and fall to the ground.

**3:15** And I will smite the winter-house with the summer-house; and the houses of ivory shall perish, and the great houses shall have an end, says YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Election and Accountability (3:1-2):**
**The Key Verse (3:1):**
"'Hear this word that YHWH has spoken against you, O children of Israel.'"

*Shim'u et-ha-davar ha-zeh asher dibber YHWH aleikhem benei Yisra'el*—hear.

"'Against the whole family which I brought up out of the land of Egypt.'"

*Al kol-ha-mishpachah asher he'eleiti me-eretz Mitzrayim*—whole family.

**The Key Verse (3:2):**
"'You only have I known of all the families of the earth.'"

*Raq etkhem yada'ti mi-kol mishpechot ha-adamah*—only you I knew.

"'Therefore I will visit upon you all your iniquities.'"

*Al-ken efqod aleikhem et kol-avonotekhem*—visit iniquities.

**Yada'ti:**
"I have known" = chosen, covenanted with. Election brings greater accountability, not privilege.

**Cause and Effect (3:3-8):**
**The Key Verses (3:3-6):**
"'Will two walk together, except they have agreed?'"

*Ha-yelekhu shenayim yachdav bilti im-no'adu*—agreed to walk.

"'Will a lion roar in the forest, when he has no prey?'"

*Ha-yish'ag aryeh ba-ya'ar ve-teref ein lo*—lion roars with prey.

"'Will a young lion give forth his voice out of his den, if he have taken nothing?'"

*Ha-yitten kefir qolo mi-me'onato bilti im-lakhad*—young lion.

"'Will a bird fall in a snare upon the earth, where there is no lure for it?'"

*Ha-tippol tzippor al-pach ha-aretz u-moqesh ein lah*—bird in snare.

"'Will a snare spring up from the ground, and have taken nothing at all?'"

*Ha-ya'aleh pach min-ha-adamah ve-lakhod lo yilkod*—snare springs.

"'Shall the horn be blown in a city, and the people not tremble?'"

*Im-yittaqa shofar be-ir ve-am lo yecheradu*—horn, tremble.

"'Shall evil befall a city, and YHWH has not done it?'"

*Im-tihyeh ra'ah be-ir va-YHWH lo asah*—YHWH does it.

**Rhetorical Questions:**
Every effect has a cause—Amos's prophecy has a cause (YHWH spoke).

**The Key Verses (3:7-8):**
"'The Lord YHWH will do nothing, but he reveals his secret unto his servants the prophets.'"

*Ki lo ya'aseh Adonai YHWH davar ki im-galah sodo el-avadav ha-nevi'im*—reveals secret.

**Sodo:**
"His secret" / "His council"—prophets are privy to divine plans.

"'The lion has roared, who will not fear?'"

*Aryeh sha'ag mi lo yira*—lion roared.

"'The Lord YHWH has spoken, who can but prophesy?'"

*Adonai YHWH dibber mi lo yinnave*—must prophesy.

**Witness Against Samaria (3:9-15):**
**The Key Verses (3:9-10):**
"'Proclaim it upon the palaces in Ashdod, and upon the palaces in the land of Egypt.'"

*Hashmi'u al-armenot be-Ashdod ve-al-armenot be-eretz Mitzrayim*—summon witnesses.

"'Assemble yourselves upon the mountains of Samaria.'"

*Ve-imru he'asefu al-harei Shomeron*—assemble.

"'Behold the great confusions therein, and the oppressions in the midst thereof.'"

*U-re'u mehumot rabbot be-tokhah va-ashuqim be-qirbah*—confusions, oppressions.

"'They know not to do right.'"

*Ve-lo yade'u asot-nekhochah*—don't know right.

"'Who store up violence and robbery in their palaces.'"

*Ha-otzrim chamas va-shod be-armenoteihem*—store violence.

**The Key Verses (3:11-12):**
"'An adversary, even round about the land!'"

*Tzar u-seviv ha-aretz*—adversary surrounds.

"'He shall bring down your strength from you.'"

*Ve-horid mimmekh uzzekh*—strength brought down.

"'Your palaces shall be spoiled.'"

*Ve-navוzzu armenotayikh*—palaces spoiled.

"'As the shepherd rescues out of the mouth of the lion two legs, or a piece of an ear.'"

*Ka-asher yatzil ha-ro'eh mi-pi ha-ari shetei khera'ayim o bedal-ozen*—shepherd rescues scraps.

"'So shall the children of Israel... escape with the corner of a couch, and the leg of a bed.'"

*Ken yinnatzeו benei Yisra'el... bi-fe'at mittah u-vi-demeseq ares*—couch corner.

**Minimal Survival:**
Like a shepherd showing only scraps to prove the animal was killed—almost nothing left.

**The Key Verses (3:13-15):**
"'Hear, and testify against the house of Jacob.'"

*Shim'u ve-ha'idu be-veit Ya'aqov*—testify.

"'I will also punish the altars of Bethel.'"

*U-faqadti al-mizbechot Beit-El*—Bethel altars.

"'The horns of the altar shall be cut off.'"

*Ve-nigde'u qarnot ha-mizbe'ach*—horns cut.

"'Fall to the ground.'"

*Ve-nafelu la-aretz*—fall.

"'I will smite the winter-house with the summer-house.'"

*Ve-hikketi beit-ha-choref al-beit ha-qayitz*—winter, summer houses.

"'The houses of ivory shall perish.'"

*Ve-avdu battei ha-shen*—ivory houses.

"'The great houses shall have an end.'"

*Ve-saffu battim rabbim*—great houses end.

**Archetypal Layer:** Amos 3 contains **"You only have I known of all the families of the earth; therefore I will visit upon you all your iniquities" (3:2)**—election means greater accountability, **the cause-and-effect rhetorical questions (3:3-6)**, **"the Lord YHWH will do nothing, but he reveals his secret unto his servants the prophets" (3:7)**, **"The lion has roared, who will not fear? The Lord YHWH has spoken, who can but prophesy?" (3:8)**, **Ashdod and Egypt summoned as witnesses (3:9)**, **"they know not to do right... who store up violence and robbery" (3:10)**, **the shepherd's scraps metaphor (3:12)**, and **judgment on Bethel's altars and ivory houses (3:14-15)**.

**Ethical Inversion Applied:**
- "'Hear this word that YHWH has spoken against you'"—hear
- "'Against the whole family which I brought up out of... Egypt'"—whole family
- "'You only have I known of all the families of the earth'"—only you
- "'Therefore I will visit upon you all your iniquities'"—visit iniquities
- "'Will two walk together, except they have agreed?'"—agreement
- "'Will a lion roar in the forest, when he has no prey?'"—cause-effect
- "'Will a bird fall in a snare... where there is no lure?'"—cause-effect
- "'Shall the horn be blown in a city, and the people not tremble?'"—tremble
- "'Shall evil befall a city, and YHWH has not done it?'"—YHWH does
- "'The Lord YHWH will do nothing, but he reveals his secret'"—reveals secret
- "'Unto his servants the prophets'"—prophets
- "'The lion has roared, who will not fear?'"—lion roared
- "'The Lord YHWH has spoken, who can but prophesy?'"—must prophesy
- "'Proclaim it upon the palaces in Ashdod'"—witnesses
- "'Behold the great confusions... and the oppressions'"—confusions
- "'They know not to do right'"—don't know right
- "'Who store up violence and robbery in their palaces'"—violence stored
- "'An adversary, even round about the land'"—adversary
- "'Your palaces shall be spoiled'"—spoiled
- "'As the shepherd rescues out of the mouth of the lion two legs'"—scraps
- "'So shall the children of Israel... escape'"—minimal survival
- "'Hear, and testify against the house of Jacob'"—testify
- "'I will also punish the altars of Bethel'"—Bethel altars
- "'The horns of the altar shall be cut off'"—cut off
- "'I will smite the winter-house with the summer-house'"—houses
- "'The houses of ivory shall perish'"—ivory perishes
- "'The great houses shall have an end'"—great houses end

**Modern Equivalent:** Amos 3:2 is revolutionary—election brings greater judgment, not privilege. The rhetorical questions (3:3-8) build to: "YHWH has spoken, who can but prophesy?" Even pagan nations are summoned as witnesses against Samaria (3:9). The shepherd's scraps (3:12) show minimal survival. Ivory houses (3:15) indicate wealth built on injustice.

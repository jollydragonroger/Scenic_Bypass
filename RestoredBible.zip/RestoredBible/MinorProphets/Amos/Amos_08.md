# Amos 8: Vision of Summer Fruit

*From the Hebrew: כֹּה הִרְאַנִי אֲדֹנָי יֱהוִה (Koh Hir'ani Adonai YHWH) — Thus the Lord YHWH Showed Me*

---

## Vision of the Summer Fruit (8:1-3)

**8:1** Thus the Lord YHWH showed me; and behold a basket of summer fruit.

**8:2** And he said: "Amos, what do you see?" And I said: "A basket of summer fruit." Then said YHWH unto me: "The end is come upon my people Israel; I will not again pass by them any more.

**8:3** "And the songs of the temple shall be wailings in that day," says the Lord YHWH; "the dead bodies shall be many; in every place silence shall be cast."

---

## Indictment of the Oppressors (8:4-10)

**8:4** Hear this, O you that would swallow the needy, and destroy the poor of the land,

**8:5** Saying: "When will the new moon be gone, that we may sell grain? And the sabbath, that we may set forth wheat, making the ephah small, and the shekel great, and falsifying the balances of deceit;

**8:6** "That we may buy the poor for silver, and the needy for a pair of shoes, and sell the refuse of the wheat?"

**8:7** YHWH has sworn by the pride of Jacob: "Surely I will never forget any of their works."

**8:8** Shall not the land tremble for this, and every one mourn that dwells therein? Yea, it shall rise up wholly like the River; and it shall be troubled and sink again, like the River of Egypt.

**8:9** And it shall come to pass in that day, says the Lord YHWH, that I will cause the sun to go down at noon, and I will darken the earth in the clear day.

**8:10** And I will turn your feasts into mourning, and all your songs into lamentation; and I will bring up sackcloth upon all loins, and baldness upon every head; and I will make it as the mourning for an only son, and the end thereof as a bitter day.

---

## Famine of the Word (8:11-14)

**8:11** Behold, the days come, says the Lord YHWH, that I will send a famine in the land, not a famine of bread, nor a thirst for water, but of hearing the words of YHWH.

**8:12** And they shall wander from sea to sea, and from the north even to the east; they shall run to and fro to seek the word of YHWH, and shall not find it.

**8:13** In that day shall the fair virgins and the young men faint for thirst.

**8:14** They that swear by the sin of Samaria, and say: "As your God, O Dan, lives"; and: "As the way of Beer-sheba lives"; even they shall fall, and never rise up again.

---

## Synthesis Notes

**Key Restorations:**

**Vision of the Summer Fruit (8:1-3):**
**The Key Verses (8:1-3):**
"'Thus the Lord YHWH showed me; and behold a basket of summer fruit.'"

*Koh hir'ani Adonai YHWH ve-hinneh kelub qayitz*—summer fruit.

"''Amos, what do you see?''"

*Mah-attah ro'eh Amos*—what do you see?

"''A basket of summer fruit.''"

*Kelub qayitz*—summer fruit basket.

"''The end is come upon my people Israel.''"

*Ba ha-qetz el-ammi Yisra'el*—end has come.

**Qayitz / Qetz Wordplay:**
"Summer fruit" (qayitz) sounds like "end" (qetz)—the harvest is ripe for judgment.

"''I will not again pass by them any more.''"

*Lo-osif od avor lo*—no more passing by.

"''The songs of the temple shall be wailings in that day.''"

*Ve-heililu shirot heikhal ba-yom ha-hu*—songs to wailings.

"''The dead bodies shall be many.''"

*Rav ha-peger*—many corpses.

"''In every place silence shall be cast.''"

*Be-khol-maqom hishlikh has*—silence everywhere.

**Indictment of the Oppressors (8:4-10):**
**The Key Verses (8:4-6):**
"'Hear this, O you that would swallow the needy.'"

*Shim'u-zot ha-sho'afim evyon*—swallow needy.

"'Destroy the poor of the land.'"

*Ve-la-shbit aniyyei-aretz*—destroy poor.

"''When will the new moon be gone, that we may sell grain?''"

*Matai ya'avor ha-chodesh ve-nashbirah shever*—impatient to trade.

"''And the sabbath, that we may set forth wheat.''"

*Ve-ha-shabbat ve-niftechah bar*—open on Sabbath.

"''Making the ephah small, and the shekel great.''"

*Le-haqtin eifah u-le-hagdil sheqel*—cheat measures.

"''Falsifying the balances of deceit.''"

*U-le-avvet moznei mirmah*—false scales.

"''That we may buy the poor for silver.''"

*Liqnot ba-kesef dallim*—buy poor.

"''The needy for a pair of shoes.''"

*Ve-evyon ba-avur na'alayim*—for shoes.

"''Sell the refuse of the wheat.''"

*U-mapphal bar nashbir*—sell refuse.

**The Key Verses (8:7-8):**
"'YHWH has sworn by the pride of Jacob.'"

*Nishba YHWH bi-ge'on Ya'aqov*—sworn.

"''Surely I will never forget any of their works.''"

*Im-eshkach la-netzach kol-ma'aseihem*—never forget.

"'Shall not the land tremble for this?'"

*Ha-al zot lo-tirgaz ha-aretz*—land trembles.

"'Every one mourn that dwells therein?'"

*Ve-aval kol-yoshev bah*—all mourn.

"'It shall rise up wholly like the River.'"

*Ve-aletah kha-ye'or kullah*—like Nile.

"'Sink again, like the River of Egypt.'"

*Ve-nishqe'ah ke-ye'or Mitzrayim*—like Nile.

**The Key Verses (8:9-10):**
"''I will cause the sun to go down at noon.''"

*Ve-heveti ha-shemesh ba-tzohorayim*—sun at noon.

"''I will darken the earth in the clear day.''"

*Ve-hachashakhti la-aretz be-yom or*—dark in daylight.

"''I will turn your feasts into mourning.''"

*Ve-hafakhti chaggeikem le-evel*—feasts to mourning.

"''All your songs into lamentation.''"

*Ve-khol-shireikhem le-qinah*—songs to dirge.

"''I will bring up sackcloth upon all loins, and baldness upon every head.''"

*Ve-ha'aleiti al-kol-motnayim saq ve-al-kol-rosh qorchah*—mourning signs.

"''I will make it as the mourning for an only son.''"

*Ve-samtיha ke-evel yachid*—mourning only son.

"''The end thereof as a bitter day.''"

*Ve-acharitah ke-yom mar*—bitter day.

**Famine of the Word (8:11-14):**
**The Key Verses (8:11-12):**
"''Behold, the days come... that I will send a famine in the land.''"

*Hinneh yamim ba'im... ve-hishlachti ra'av ba-aretz*—famine coming.

"''Not a famine of bread, nor a thirst for water.''"

*Lo-ra'av la-lechem ve-lo-tzama la-mayim*—not bread, water.

"''But of hearing the words of YHWH.''"

*Ki im-lishmoa et divrei YHWH*—hearing YHWH's words.

**Famine of the Word:**
The most devastating famine—God's silence.

"''They shall wander from sea to sea, and from the north even to the east.''"

*Ve-na'u mi-yam ad-yam u-mi-tzafon ve-ad-mizrach*—wander.

"''They shall run to and fro to seek the word of YHWH.''"

*Yeshotetu le-vaqqesh et-devar YHWH*—seek.

"''And shall not find it.''"

*Ve-lo yimtza'u*—not find.

**The Key Verses (8:13-14):**
"'In that day shall the fair virgins and the young men faint for thirst.'"

*Ba-yom ha-hu tit'alafnah ha-betulot ha-yafot ve-ha-bachurim ba-tzama*—faint.

"'They that swear by the sin of Samaria.'"

*Ha-nishba'im be-ashmat Shomeron*—swear by sin.

"''As your God, O Dan, lives.''"

*Chai Elohekha Dan*—Dan's god.

"''As the way of Beer-sheba lives.''"

*Ve-chai derekh Be'er-Shava*—Beer-sheba's way.

"'They shall fall, and never rise up again.'"

*Ve-nafelu ve-lo-yaqumu od*—fall, not rise.

**Archetypal Layer:** Amos 8 contains **the vision of summer fruit with qayitz/qetz wordplay (8:1-2)**, **"The end is come upon my people Israel" (8:2)**, **"the songs of the temple shall be wailings" (8:3)**, **indictment of commercial oppressors (8:4-6)**: impatient for Sabbath to end, cheating with measures and scales, buying the poor, **"I will never forget any of their works" (8:7)**, **cosmic signs: sun at noon goes down, earth darkened (8:9)**, **"feasts into mourning... songs into lamentation" (8:10)**, **"the famine... of hearing the words of YHWH" (8:11)**—God's silence, **"they shall run to and fro to seek the word of YHWH, and shall not find it" (8:12)**, and **"they shall fall, and never rise up again" (8:14)**.

**Ethical Inversion Applied:**
- "'Thus the Lord YHWH showed me; and behold a basket of summer fruit'"—vision
- "''A basket of summer fruit''"—qayitz
- "''The end is come upon my people Israel''"—qetz
- "''I will not again pass by them any more''"—no more passing
- "''The songs of the temple shall be wailings''"—songs to wailings
- "''The dead bodies shall be many''"—many dead
- "''In every place silence shall be cast''"—silence
- "'Hear this, O you that would swallow the needy'"—swallow needy
- "'Destroy the poor of the land'"—destroy poor
- "''When will the new moon be gone, that we may sell grain?''"—impatient
- "''And the sabbath, that we may set forth wheat''"—eager to trade
- "''Making the ephah small, and the shekel great''"—cheat measures
- "''Falsifying the balances of deceit''"—false scales
- "''That we may buy the poor for silver''"—buy poor
- "''The needy for a pair of shoes''"—shoes
- "''Sell the refuse of the wheat''"—sell refuse
- "'YHWH has sworn by the pride of Jacob'"—sworn
- "''I will never forget any of their works''"—never forget
- "'Shall not the land tremble for this?'"—land trembles
- "'It shall rise up wholly like the River'"—like Nile
- "''I will cause the sun to go down at noon''"—sun at noon
- "''I will darken the earth in the clear day''"—dark daylight
- "''I will turn your feasts into mourning''"—feasts to mourning
- "''All your songs into lamentation''"—songs to dirge
- "''I will bring up sackcloth upon all loins''"—sackcloth
- "''I will make it as the mourning for an only son''"—only son
- "''The end thereof as a bitter day''"—bitter
- "''I will send a famine in the land''"—famine
- "''Not a famine of bread, nor a thirst for water''"—not bread
- "''But of hearing the words of YHWH''"—famine of word
- "''They shall wander from sea to sea''"—wander
- "''They shall run to and fro to seek the word of YHWH''"—seek
- "''And shall not find it''"—not find
- "'The fair virgins and the young men faint for thirst'"—faint
- "'They that swear by the sin of Samaria'"—swear by sin
- "'They shall fall, and never rise up again'"—fall

**Modern Equivalent:** Amos 8's wordplay (qayitz/qetz) announces Israel's end. The indictment (8:4-6) targets merchants who can't wait for Sabbath to end so they can cheat customers. The "famine of hearing the words of YHWH" (8:11-12) is terrifying—they ignored prophets, so God will be silent. They'll desperately seek God's word and not find it.

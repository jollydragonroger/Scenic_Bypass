# Amos 2: Oracles Against Moab, Judah, and Israel

*From the Hebrew: כֹּה אָמַר יְהוָה (Koh Amar YHWH) — Thus Says YHWH*

---

## Oracle Against Moab (2:1-3)

**2:1** Thus says YHWH: For three transgressions of Moab, yea, for four, I will not reverse it: because he burned the bones of the king of Edom into lime.

**2:2** So will I send a fire upon Moab, and it shall devour the palaces of Kerioth; and Moab shall die with tumult, with shouting, and with the sound of the horn.

**2:3** And I will cut off the judge from the midst thereof, and will slay all the princes thereof with him, says YHWH.

---

## Oracle Against Judah (2:4-5)

**2:4** Thus says YHWH: For three transgressions of Judah, yea, for four, I will not reverse it: because they have rejected the law of YHWH, and have not kept his statutes, and their lies have caused them to err, after which their fathers did walk.

**2:5** So will I send a fire upon Judah, and it shall devour the palaces of Jerusalem.

---

## Oracle Against Israel (2:6-16)

**2:6** Thus says YHWH: For three transgressions of Israel, yea, for four, I will not reverse it: because they sell the righteous for silver, and the needy for a pair of shoes;

**2:7** That pant after the dust of the earth on the head of the poor, and turn aside the way of the humble; and a man and his father go unto the same maiden, to profane my holy name;

**2:8** And they lay themselves down beside every altar upon clothes taken in pledge, and in the house of their God they drink the wine of them that have been fined.

**2:9** Yet destroyed I the Amorite before them, whose height was like the height of the cedars, and he was strong as the oaks; yet I destroyed his fruit from above, and his roots from beneath.

**2:10** Also I brought you up out of the land of Egypt, and led you forty years in the wilderness, to possess the land of the Amorite.

**2:11** And I raised up of your sons for prophets, and of your young men for Nazirites. Is it not even thus, O you children of Israel? says YHWH.

**2:12** But you gave the Nazirites wine to drink; and commanded the prophets, saying: "Prophesy not."

**2:13** Behold, I will make it creak under you, as a cart creaks that is full of sheaves.

**2:14** And flight shall fail the swift, and the strong shall not exert his strength, neither shall the mighty deliver himself;

**2:15** Neither shall he stand that handles the bow; and he that is swift of foot shall not deliver himself; neither shall he that rides the horse deliver himself;

**2:16** And he that is courageous among the mighty shall flee away naked in that day, says YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Oracle Against Moab (2:1-3):**
**The Key Verses (2:1-3):**
"'For three transgressions of Moab, yea, for four, I will not reverse it.'"

*Al-sheloshah pish'ei Mo'av ve-al-arba'ah lo ashivennu*—Moab.

"'Because he burned the bones of the king of Edom into lime.'"

*Al-sorfo atzmot melekh-Edom la-sid*—burned bones.

**Burned Bones:**
Desecration of the dead—even enemy corpses deserve respect.

"'I will send a fire upon Moab.'"

*Ve-shillachti esh be-Mo'av*—fire on Moab.

"'It shall devour the palaces of Kerioth.'"

*Ve-akhelah armenot ha-Qeriyot*—Kerioth.

"'Moab shall die with tumult, with shouting, and with the sound of the horn.'"

*U-met be-sha'on Mo'av bi-teru'ah be-qol shofar*—die in tumult.

"'I will cut off the judge from the midst thereof.'"

*Ve-hikhrati shofet mi-qirbah*—cut off judge.

**Oracle Against Judah (2:4-5):**
**The Key Verses (2:4-5):**
"'For three transgressions of Judah, yea, for four, I will not reverse it.'"

*Al-sheloshah pish'ei Yehudah ve-al-arba'ah lo ashivennu*—Judah.

"'Because they have rejected the law of YHWH.'"

*Al-mo'asam et-torat YHWH*—rejected Torah.

"'Have not kept his statutes.'"

*Ve-chuqqav lo shamaru*—not kept statutes.

"'Their lies have caused them to err.'"

*Va-yat'um kizvehem*—lies caused error.

"'After which their fathers did walk.'"

*Asher-halekhu avotam achareihem*—fathers walked.

"'I will send a fire upon Judah.'"

*Ve-shillachti esh bi-Yhudah*—fire on Judah.

"'It shall devour the palaces of Jerusalem.'"

*Ve-akhelah armenot Yerushalayim*—Jerusalem's palaces.

**Oracle Against Israel (2:6-16):**
**The Key Verses (2:6-8):**
"'For three transgressions of Israel, yea, for four, I will not reverse it.'"

*Al-sheloshah pish'ei Yisra'el ve-al-arba'ah lo ashivennu*—Israel.

"'Because they sell the righteous for silver.'"

*Al-mikhram ba-kesef tzaddiq*—sell righteous.

"'The needy for a pair of shoes.'"

*Ve-evyon ba-avur na'alayim*—needy for shoes.

**Sell for Silver... Shoes:**
Corrupt courts convict innocent for bribes.

"'That pant after the dust of the earth on the head of the poor.'"

*Ha-sho'afim al-afar-eretz be-rosh dallim*—trample poor.

"'Turn aside the way of the humble.'"

*Ve-derekh anavim yattו*—pervert justice.

"'A man and his father go unto the same maiden.'"

*Ve-ish ve-aviv yelekhu el-ha-na'arah*—sexual sin.

"'To profane my holy name.'"

*Lema'an challel et-shem qodshi*—profane name.

"'They lay themselves down beside every altar upon clothes taken in pledge.'"

*Ve-al-begadim chavulim yattו etzel kol-mizbe'ach*—pledged garments.

**Pledged Garments:**
Exodus 22:26-27 forbids keeping a poor person's cloak overnight.

"'In the house of their God they drink the wine of them that have been fined.'"

*Ve-yein anushim yishtu beit Eloheihem*—wine of fines.

**The Key Verses (2:9-12):**
"'Yet destroyed I the Amorite before them.'"

*Ve-anokhi hishmadti et-ha-Emori mi-peneihem*—destroyed Amorite.

"'Whose height was like the height of the cedars.'"

*Asher ke-govah arazim govho*—tall as cedars.

"'He was strong as the oaks.'"

*Ve-chason hu ka-allonim*—strong as oaks.

"'I destroyed his fruit from above, and his roots from beneath.'"

*Va-ashmid piryo mi-ma'al ve-shorashav mi-tachat*—totally destroyed.

"'I brought you up out of the land of Egypt.'"

*Ve-anokhi he'eleiti etkhem me-eretz Mitzrayim*—Exodus.

"'Led you forty years in the wilderness.'"

*Va-olekh etkhem ba-midbar arba'im shanah*—40 years.

"'To possess the land of the Amorite.'"

*La-reshet et-eretz ha-Emori*—possess land.

"'I raised up of your sons for prophets.'"

*Va-aqim mi-beneikhem li-nevi'im*—prophets.

"'Of your young men for Nazirites.'"

*U-mi-bachureikhem li-nezirim*—Nazirites.

"'Is it not even thus, O you children of Israel?'"

*Ha-af ein-zot benei Yisra'el*—is it not so?

"'You gave the Nazirites wine to drink.'"

*Va-tashqu et-ha-nezirim yayin*—gave wine.

"'Commanded the prophets, saying: Prophesy not.'"

*Ve-al-ha-nevi'im tzivvitem lemor lo tinnave'u*—silenced prophets.

**The Key Verses (2:13-16):**
"'I will make it creak under you, as a cart creaks that is full of sheaves.'"

*Hinneh anokhi me'iq tachteikhem ka-asher ta'iq ha-agalah ha-male'ah lah amir*—cart creaking.

"'Flight shall fail the swift.'"

*Ve-avad manos mi-qal*—swift can't flee.

"'The strong shall not exert his strength.'"

*Ve-chazaq lo-ye'ammetz kocho*—strong weakened.

"'The mighty deliver himself.'"

*Ve-gibbor lo-yemallet nafsho*—mighty won't escape.

"'He stand that handles the bow.'"

*Ve-tofes ha-qeshet lo ya'amod*—archer falls.

"'He that is swift of foot shall not deliver himself.'"

*Ve-qal be-raglav lo yemallet*—runner fails.

"'He that rides the horse deliver himself.'"

*Ve-rokhev ha-sus lo yemallet nafsho*—horseman fails.

"'He that is courageous among the mighty shall flee away naked in that day.'"

*Ve-ammitz libbo ba-gibborim arom yanus ba-yom ha-hu*—courageous flee naked.

**Archetypal Layer:** Amos 2 completes the **oracles against nations** and **turns to Israel**, containing **Moab condemned for desecrating corpses (2:1)**, **Judah for rejecting YHWH's law (2:4)**, then the **extended oracle against Israel (2:6-16)**: selling righteous for silver (2:6), trampling the poor (2:7), sexual immorality (2:7), exploiting the vulnerable (2:8), **contrast with YHWH's saving acts: destroyed Amorites, Exodus, wilderness, prophets, Nazirites (2:9-11)**, **Israel's response: gave Nazirites wine, silenced prophets (2:12)**, and **complete military collapse (2:13-16)**.

**Ethical Inversion Applied:**
- "'For three transgressions of Moab'"—Moab
- "'Because he burned the bones of the king of Edom into lime'"—desecration
- "'I will send a fire upon Moab'"—fire
- "'Moab shall die with tumult'"—tumult
- "'For three transgressions of Judah'"—Judah
- "'Because they have rejected the law of YHWH'"—rejected Torah
- "'Have not kept his statutes'"—not kept
- "'Their lies have caused them to err'"—lies
- "'I will send a fire upon Judah'"—fire
- "'For three transgressions of Israel'"—Israel
- "'Because they sell the righteous for silver'"—sell righteous
- "'The needy for a pair of shoes'"—shoes
- "'That pant after the dust of the earth on the head of the poor'"—trample
- "'Turn aside the way of the humble'"—pervert
- "'A man and his father go unto the same maiden'"—sexual sin
- "'To profane my holy name'"—profane
- "'They lay themselves down beside every altar upon clothes taken in pledge'"—pledged garments
- "'In the house of their God they drink the wine of them that have been fined'"—wine of fines
- "'I destroyed the Amorite before them'"—destroyed Amorite
- "'I brought you up out of the land of Egypt'"—Exodus
- "'Led you forty years in the wilderness'"—wilderness
- "'I raised up of your sons for prophets'"—prophets
- "'Of your young men for Nazirites'"—Nazirites
- "'You gave the Nazirites wine to drink'"—gave wine
- "'Commanded the prophets, saying: Prophesy not'"—silenced prophets
- "'I will make it creak under you, as a cart creaks'"—creak
- "'Flight shall fail the swift'"—swift fails
- "'The strong shall not exert his strength'"—strong fails
- "'The mighty deliver himself'"—mighty fails
- "'He that is courageous among the mighty shall flee away naked'"—flee naked

**Modern Equivalent:** Amos 2 is the rhetorical climax. After condemning six nations, Amos pivots to Judah (briefly) then Israel at length. Israel's sins are social: selling the innocent, trampling the poor, sexual immorality at shrines, exploiting debtors. YHWH recounts His saving acts (2:9-11) and Israel's rejection of prophets and Nazirites (2:12). Military collapse follows (2:13-16).

# Zephaniah 1: The Day of YHWH

*From the Hebrew: דְּבַר־יְהוָה אֲשֶׁר הָיָה אֶל־צְפַנְיָה (Devar-YHWH Asher Hayah El-Tzefanyah) — The Word of YHWH Which Came unto Zephaniah*

---

## Title (1:1)

**1:1** The word of YHWH which came unto Zephaniah the son of Cushi, the son of Gedaliah, the son of Amariah, the son of Hezekiah, in the days of Josiah the son of Amon, king of Judah.

---

## Universal Judgment (1:2-6)

**1:2** I will utterly consume all things from off the face of the earth, says YHWH.

**1:3** I will consume man and beast, I will consume the fowls of the heaven, and the fishes of the sea, and the stumbling-blocks with the wicked; and I will cut off man from off the face of the earth, says YHWH.

**1:4** And I will stretch out my hand upon Judah, and upon all the inhabitants of Jerusalem; and I will cut off the remnant of Baal from this place, and the name of the idolatrous priests with the priests;

**1:5** And them that worship the host of heaven upon the housetops; and them that worship, that swear to YHWH and swear by Malcam;

**1:6** And them that are turned back from following YHWH; and those that have not sought YHWH, nor inquired after him.

---

## The Day of YHWH (1:7-18)

**1:7** Hold your peace at the presence of the Lord YHWH; for the day of YHWH is at hand; for YHWH has prepared a sacrifice, he has consecrated his guests.

**1:8** And it shall come to pass in the day of YHWH's sacrifice, that I will punish the princes, and the king's sons, and all such as are clothed with foreign apparel.

**1:9** In that day also will I punish all those that leap over the threshold, that fill their master's house with violence and deceit.

**1:10** And in that day, says YHWH, there shall be the noise of a cry from the fish gate, and a wailing from the second quarter, and a great crashing from the hills.

**1:11** Wail, you inhabitants of Maktesh, for all the merchant people are undone; all they that were laden with silver are cut off.

**1:12** And it shall come to pass at that time, that I will search Jerusalem with lamps; and I will punish the men that are settled on their lees, that say in their heart: "YHWH will not do good, neither will he do evil."

**1:13** And their wealth shall become a booty, and their houses a desolation; yea, they shall build houses, but shall not inhabit them, and they shall plant vineyards, but shall not drink the wine thereof.

**1:14** The great day of YHWH is near, it is near and hastes greatly, even the voice of the day of YHWH, wherein the mighty man cries bitterly.

**1:15** That day is a day of wrath, a day of trouble and distress, a day of wasteness and desolation, a day of darkness and gloominess, a day of clouds and thick darkness,

**1:16** A day of the horn and alarm, against the fortified cities, and against the high towers.

**1:17** And I will bring distress upon men, that they shall walk like blind men, because they have sinned against YHWH; and their blood shall be poured out as dust, and their flesh as dung.

**1:18** Neither their silver nor their gold shall be able to deliver them in the day of YHWH's wrath; but the whole earth shall be devoured by the fire of his jealousy; for he will make an end, yea, a terrible end, of all them that dwell in the earth.

---

## Synthesis Notes

**Key Restorations:**

**Title (1:1):**
**The Key Verse (1:1):**
"The word of YHWH which came unto Zephaniah the son of Cushi."

*Devar-YHWH asher hayah el-Tzefanyah ben-Kushi*—Zephaniah.

**Tzefanyah:**
"YHWH hides/protects."

"The son of Gedaliah, the son of Amariah, the son of Hezekiah."

*Ben-Gedalyah ben-Amaryah ben-Chizqiyyah*—four-generation genealogy.

**Hezekiah:**
Possibly King Hezekiah—unusual to trace genealogy four generations.

"In the days of Josiah the son of Amon, king of Judah."

*Bi-yemei Yoshiyyahu ven-Amon melekh Yehudah*—Josiah's reign, 640-609 BCE.

**Universal Judgment (1:2-6):**
**The Key Verses (1:2-3):**
"''I will utterly consume all things from off the face of the earth.''"

*Asof asef kol me-al penei ha-adamah*—consume all.

"''I will consume man and beast.''"

*Asef adam u-vehemah*—man, beast.

"''I will consume the fowls of the heaven, and the fishes of the sea.''"

*Asef of ha-shamayim u-degei ha-yam*—birds, fish.

"''The stumbling-blocks with the wicked.''"

*Ve-ha-makhshelot et-ha-resha'im*—stumbling blocks.

"''I will cut off man from off the face of the earth.''"

*Ve-hikhrati et-ha-adam me-al penei ha-adamah*—cut off man.

**Reverse Creation:**
Echoes Genesis—undoing creation order.

**The Key Verses (1:4-6):**
"''I will stretch out my hand upon Judah.''"

*Ve-natiti yadi al-Yehudah*—hand on Judah.

"''Upon all the inhabitants of Jerusalem.''"

*Ve-al kol-yoshevei Yerushalayim*—Jerusalem.

"''I will cut off the remnant of Baal from this place.''"

*Ve-hikhrati min-ha-maqom ha-zeh et-she'ar ha-Ba'al*—Baal remnant.

"''The name of the idolatrous priests with the priests.''"

*Et-shem ha-kemarim im-ha-kohanim*—idolatrous priests.

**Kemarim:**
"Idolatrous priests"—distinct from legitimate priests.

"''Them that worship the host of heaven upon the housetops.''"

*Ve-et-ha-mishtachavim al-ha-gaggot li-tzeva ha-shamayim*—astral worship.

"''Them that swear to YHWH and swear by Malcam.''"

*Ve-et-ha-mishtachavim ha-nishba'im la-YHWH ve-ha-nishba'im be-Malkam*—syncretism.

**Malcam:**
"Their king" or the god Milcom/Molech.

"''Them that are turned back from following YHWH.''"

*Ve-et-ha-nesogim me-acharei YHWH*—turned back.

"''Those that have not sought YHWH, nor inquired after him.''"

*Va-asher lo-viqshu et-YHWH ve-lo derashuhu*—not sought.

**Day of YHWH (1:7-18):**
**The Key Verses (1:7-9):**
"''Hold your peace at the presence of the Lord YHWH.''"

*Has mi-penei Adonai YHWH*—silence.

"''For the day of YHWH is at hand.''"

*Ki qarov yom YHWH*—day near.

"''YHWH has prepared a sacrifice.''"

*Ki hekhin YHWH zavach*—sacrifice prepared.

"''He has consecrated his guests.''"

*Hiqdish qeru'av*—guests consecrated.

"''I will punish the princes, and the king's sons.''"

*U-faqadti al-ha-sarim ve-al-benei ha-melekh*—punish princes.

"''All such as are clothed with foreign apparel.''"

*Ve-al kol-ha-loveshim malbush nokhri*—foreign clothing.

"''I will punish all those that leap over the threshold.''"

*U-faqadti al-kol-ha-doleig al-ha-miftan*—leap threshold.

"''That fill their master's house with violence and deceit.''"

*Ha-memالم'im beit adoneihem chamas u-mirmah*—violence, deceit.

**The Key Verses (1:10-13):**
"''There shall be the noise of a cry from the fish gate.''"

*Qol tze'aqah mi-sha'ar ha-dagim*—fish gate.

"''A wailing from the second quarter.''"

*Vi-yelalah min-ha-mishneh*—second quarter.

"''A great crashing from the hills.''"

*Ve-shever gadol me-ha-geva'ot*—crashing.

"''Wail, you inhabitants of Maktesh.''"

*Heililu yoshevei ha-Makhtesh*—Maktesh.

**Maktesh:**
"Mortar"—a market district in Jerusalem.

"''All the merchant people are undone.''"

*Ki nidmah kol-am Kena'an*—merchants undone.

"''All they that were laden with silver are cut off.''"

*Nikhretu kol-netilei khasef*—silver laden cut off.

"''I will search Jerusalem with lamps.''"

*Va-chapasti et-Yerushalayim ba-nerot*—search with lamps.

"''I will punish the men that are settled on their lees.''"

*U-faqadti al-ha-anashim ha-qofe'im al-shimreihem*—settled on lees.

**Settled on Lees:**
Wine left undisturbed becomes thick and sluggish—spiritual complacency.

"''That say in their heart: YHWH will not do good, neither will he do evil.''"

*Ha-omerim bi-levavam lo-yeitiv YHWH ve-lo yare'a*—YHWH inactive.

"''Their wealth shall become a booty.''"

*Ve-hayah cheilam li-meshissah*—booty.

"''Their houses a desolation.''"

*U-vatteihem li-shemamah*—desolation.

"''They shall build houses, but shall not inhabit them.''"

*U-vanu vattim ve-lo yeshevu*—build, not inhabit.

"''Plant vineyards, but shall not drink the wine.''"

*Ve-nat'u kheramim ve-lo yishtu et-yeinam*—plant, not drink.

**The Key Verses (1:14-18):**
"''The great day of YHWH is near.''"

*Qarov yom-YHWH ha-gadol*—great day near.

"''It is near and hastes greatly.''"

*Qarov u-maher me'od*—hastens.

"''The voice of the day of YHWH, wherein the mighty man cries bitterly.''"

*Qol yom YHWH mar tzoreach sham gibbor*—mighty cries.

"''That day is a day of wrath.''"

*Yom evrah ha-yom ha-hu*—day of wrath.

"''A day of trouble and distress.''"

*Yom tzarah u-metzuqah*—trouble, distress.

"''A day of wasteness and desolation.''"

*Yom sho'ah u-mesho'ah*—wasteness, desolation.

"''A day of darkness and gloominess.''"

*Yom choshekh va-afelah*—darkness, gloom.

"''A day of clouds and thick darkness.''"

*Yom anan va-arafel*—clouds, thick darkness.

"''A day of the horn and alarm.''"

*Yom shofar u-teru'ah*—horn, alarm.

"''Against the fortified cities, and against the high towers.''"

*Al he-arim ha-betzurot ve-al ha-pinnot ha-gevohot*—cities, towers.

**Dies Irae:**
Medieval Latin hymn "Dies Irae" (Day of Wrath) is based on 1:15-16.

"''I will bring distress upon men.''"

*Va-hatzaroti la-adam*—distress.

"''They shall walk like blind men.''"

*Ve-halekhu ka-ivrim*—like blind.

"''Because they have sinned against YHWH.''"

*Ki la-YHWH chata'u*—sinned.

"''Their blood shall be poured out as dust.''"

*Ve-shuppakh damam ke-afar*—blood like dust.

"''Their flesh as dung.''"

*U-lechumam ka-gelalim*—flesh like dung.

"''Neither their silver nor their gold shall be able to deliver them.''"

*Gam-kaspam gam-zehabam lo-yukhal le-hatzilam*—can't deliver.

"''The whole earth shall be devoured by the fire of his jealousy.''"

*U-ve-esh qin'ato te'akhel kol-ha-aretz*—fire consumes.

"''He will make an end, yea, a terrible end, of all them that dwell in the earth.''"

*Ki-khalah akh-nivhalah ya'aseh et kol-yoshevei ha-aretz*—terrible end.

**Archetypal Layer:** Zephaniah 1 contains **the title with four-generation genealogy possibly reaching to King Hezekiah (1:1)**, **reverse creation: "I will consume man and beast... fowls... fishes" (1:2-3)**, **judgment on syncretism: Baal, astral worship, Malcam (1:4-5)**, **"the day of YHWH is at hand; for YHWH has prepared a sacrifice" (1:7)**, **"I will search Jerusalem with lamps" (1:12)**, **men "settled on their lees... that say in their heart: YHWH will not do good, neither will he do evil" (1:12)**, and the **famous Dies Irae passage (1:14-18)**: "a day of wrath, a day of trouble and distress, a day of wasteness and desolation, a day of darkness and gloominess."

**Ethical Inversion Applied:**
- "The word of YHWH which came unto Zephaniah"—prophetic call
- "In the days of Josiah"—Josiah's reign
- "''I will utterly consume all things''"—consume all
- "''I will consume man and beast''"—man, beast
- "''I will consume the fowls of the heaven, and the fishes of the sea''"—reverse creation
- "''I will cut off man from off the face of the earth''"—cut off
- "''I will stretch out my hand upon Judah''"—hand on Judah
- "''I will cut off the remnant of Baal''"—Baal
- "''The name of the idolatrous priests''"—kemarim
- "''Them that worship the host of heaven''"—astral worship
- "''Them that swear to YHWH and swear by Malcam''"—syncretism
- "''Them that are turned back from following YHWH''"—turned back
- "''Those that have not sought YHWH''"—not sought
- "''Hold your peace at the presence of the Lord YHWH''"—silence
- "''For the day of YHWH is at hand''"—day near
- "''YHWH has prepared a sacrifice''"—sacrifice
- "''I will punish the princes, and the king's sons''"—punish
- "''All such as are clothed with foreign apparel''"—foreign clothing
- "''I will punish all those that leap over the threshold''"—threshold
- "''I will search Jerusalem with lamps''"—search
- "''I will punish the men that are settled on their lees''"—lees
- "''YHWH will not do good, neither will he do evil''"—YHWH inactive
- "''They shall build houses, but shall not inhabit them''"—build, not inhabit
- "''The great day of YHWH is near''"—great day
- "''That day is a day of wrath''"—wrath
- "''A day of trouble and distress''"—trouble
- "''A day of wasteness and desolation''"—desolation
- "''A day of darkness and gloominess''"—darkness
- "''A day of clouds and thick darkness''"—clouds
- "''A day of the horn and alarm''"—horn
- "''I will bring distress upon men''"—distress
- "''They shall walk like blind men''"—blind
- "''Their blood shall be poured out as dust''"—blood
- "''Neither their silver nor their gold shall be able to deliver them''"—can't deliver
- "''The whole earth shall be devoured''"—devoured
- "''He will make an end, yea, a terrible end''"—terrible end

**Modern Equivalent:** Zephaniah 1 is dominated by the Day of YHWH. The judgment reverses creation (1:2-3). The condemnation targets syncretism—worship of Baal, stars, and Malcam alongside YHWH (1:4-5). "I will search Jerusalem with lamps" (1:12) finds the complacent who think YHWH is inactive. The Dies Irae passage (1:14-18) inspired the medieval Latin hymn and countless artistic works on judgment.

# Zephaniah 2: Oracles Against the Nations

*From the Hebrew: הִתְקוֹשְׁשׁוּ וָקוֹשּׁוּ (Hitqosheshu Va-Qoshshu) — Gather Yourselves Together*

---

## Call to Repentance (2:1-3)

**2:1** Gather yourselves together, yea, gather together, O nation that has no shame;

**2:2** Before the decree bring forth—the day passes as the chaff—before the fierce anger of YHWH come upon you, before the day of YHWH's anger come upon you.

**2:3** Seek YHWH, all you humble of the land, that have executed his ordinance; seek righteousness, seek humility; it may be you shall be hid in the day of YHWH's anger.

---

## Oracle Against Philistia (2:4-7)

**2:4** For Gaza shall be forsaken, and Ashkelon a desolation; they shall drive out Ashdod at the noonday, and Ekron shall be rooted up.

**2:5** Woe unto the inhabitants of the sea-coast, the nation of the Cherethites! The word of YHWH is against you, O Canaan, the land of the Philistines: "I will destroy you, that there shall be no inhabitant."

**2:6** And the sea-coast shall be pastures, even meadows for shepherds, and folds for flocks.

**2:7** And it shall be a portion for the remnant of the house of Judah, whereon they shall feed; in the houses of Ashkelon shall they lie down in the evening; for YHWH their God will remember them, and turn their captivity.

---

## Oracle Against Moab and Ammon (2:8-11)

**2:8** I have heard the taunting of Moab, and the revilings of the children of Ammon, wherewith they have taunted my people, and magnified themselves against their border.

**2:9** Therefore as I live, says YHWH of hosts, the God of Israel: Surely Moab shall be as Sodom, and the children of Ammon as Gomorrah, even the breeding-place of nettles, and salt-pits, and a desolation for ever; the residue of my people shall spoil them, and the remnant of my nation shall inherit them.

**2:10** This shall they have for their pride, because they have taunted and magnified themselves against the people of YHWH of hosts.

**2:11** YHWH will be terrible unto them; for he will famish all the gods of the earth; and all the isles of the nations shall worship him, every one from his place.

---

## Oracle Against Ethiopia and Assyria (2:12-15)

**2:12** You Ethiopians also, you shall be slain by my sword.

**2:13** And he will stretch out his hand against the north, and destroy Assyria; and will make Nineveh a desolation, and dry like the wilderness.

**2:14** And herds shall lie down in the midst of her, all the beasts of the nations; both the pelican and the bittern shall lodge in the capitals thereof; voices shall sing in the windows; desolation shall be in the thresholds; for the cedar-work thereof shall be laid bare.

**2:15** This is the joyous city that dwelt carelessly, that said in her heart: "I am, and there is none beside me." How is she become a desolation, a place for beasts to lie down in! Every one that passes by her shall hiss, and wag his hand.

---

## Synthesis Notes

**Key Restorations:**

**Call to Repentance (2:1-3):**
**The Key Verses (2:1-2):**
"'Gather yourselves together, yea, gather together.'"

*Hitqosheshu va-qoshshu*—gather.

"'O nation that has no shame.'"

*Ha-goy lo nikhsaf*—shameless nation.

"'Before the decree bring forth—the day passes as the chaff.'"

*Be-terem ledet choq ke-motz avar yom*—before decree.

"'Before the fierce anger of YHWH come upon you.'"

*Be-terem lo-yavo aleikhem charon af-YHWH*—before anger.

"'Before the day of YHWH's anger come upon you.'"

*Be-terem lo-yavo aleikhem yom af-YHWH*—before day.

**The Key Verse (2:3):**
"'Seek YHWH, all you humble of the land.'"

*Baqqeshu et-YHWH kol-anvei ha-aretz*—seek YHWH.

"'That have executed his ordinance.'"

*Asher mishpato pa'alu*—executed ordinance.

"'Seek righteousness, seek humility.'"

*Baqqeshu tzedeq baqqeshu anavah*—righteousness, humility.

"'It may be you shall be hid in the day of YHWH's anger.'"

*Ulai tissateru be-yom af-YHWH*—perhaps hidden.

**Anvei Ha-Aretz:**
"The humble of the land"—a key concept in Zephaniah.

**Oracle Against Philistia (2:4-7):**
**The Key Verses (2:4-5):**
"'Gaza shall be forsaken.'"

*Ki Azzah azuvah tihyeh*—wordplay: Gaza/forsaken.

"'Ashkelon a desolation.'"

*Ve-Ashqelon li-shemamah*—desolation.

"'They shall drive out Ashdod at the noonday.'"

*Ashdod ba-tzohorayim yegareshuha*—noonday.

"'Ekron shall be rooted up.'"

*Ve-Eqron te'aqer*—wordplay: Ekron/rooted up.

"'Woe unto the inhabitants of the sea-coast.'"

*Hoy yoshevei chevel ha-yam*—sea-coast.

"'The nation of the Cherethites!'"

*Goy Keretim*—Cherethites.

"'The word of YHWH is against you, O Canaan, the land of the Philistines.'"

*Devar-YHWH aleikhem Kena'an eretz Pelishtim*—against Philistia.

"''I will destroy you, that there shall be no inhabitant.''"

*Ve-ha'avadtikh me-ein yoshev*—destroy.

**The Key Verses (2:6-7):**
"'The sea-coast shall be pastures.'"

*Ve-hayetah chevel ha-yam nevot*—pastures.

"'Even meadows for shepherds, and folds for flocks.'"

*Kerot ro'im ve-giderot tzon*—shepherds, flocks.

"'It shall be a portion for the remnant of the house of Judah.'"

*Ve-hayah chevel li-she'erit beit-Yehudah*—Judah's remnant.

"'Whereon they shall feed.'"

*Aleihem yir'un*—feed.

"'In the houses of Ashkelon shall they lie down in the evening.'"

*Be-vattei Ashqelon ba-erev yirबatzun*—Ashkelon.

"'YHWH their God will remember them.'"

*Ki yifqodem YHWH Eloheihem*—remember.

"'Turn their captivity.'"

*Ve-shav shevutam*—turn captivity.

**Oracle Against Moab and Ammon (2:8-11):**
**The Key Verses (2:8-10):**
"''I have heard the taunting of Moab.''"

*Shama'ti cherpat Mo'av*—taunting.

"''The revilings of the children of Ammon.''"

*Ve-giddufei benei Ammon*—revilings.

"''Wherewith they have taunted my people.''"

*Asher cherefu et-ammi*—taunted.

"''Magnified themselves against their border.''"

*Va-yagdilu al-gevulam*—magnified.

"''As I live... Moab shall be as Sodom.''"

*Chai-ani... ki-Mo'av ki-Sedom tihyeh*—like Sodom.

"''The children of Ammon as Gomorrah.''"

*U-venei Ammon ka-Amorah*—like Gomorrah.

"''Even the breeding-place of nettles, and salt-pits.''"

*Mimשaq charul u-mikhרeh-melach*—nettles, salt.

"''A desolation for ever.''"

*U-shemamah ad-olam*—forever desolation.

"''The residue of my people shall spoil them.''"

*She'erit ammi yevozzum*—spoil.

"''The remnant of my nation shall inherit them.''"

*Ve-yeter goyi yinchalum*—inherit.

"''This shall they have for their pride.''"

*Zot lahem tachat ge'onam*—for pride.

"''They have taunted and magnified themselves against the people of YHWH.''"

*Ki cherefu va-yagdelu al-am YHWH tzeva'ot*—taunted YHWH's people.

**The Key Verse (2:11):**
"''YHWH will be terrible unto them.''"

*Nora YHWH aleihem*—terrible.

"''He will famish all the gods of the earth.''"

*Ki razah et kol-elohei ha-aretz*—famish gods.

"''All the isles of the nations shall worship him.''"

*Ve-yishtachavu lo ish mi-meqomo kol iyyei ha-goyim*—nations worship.

"''Every one from his place.''"

*Ish mi-meqomo*—from his place.

**Oracle Against Ethiopia and Assyria (2:12-15):**
**The Key Verses (2:12-13):**
"''You Ethiopians also, you shall be slain by my sword.''"

*Gam-attem Kushיim chalelei charbi hemmah*—Ethiopians slain.

"''He will stretch out his hand against the north.''"

*Ve-yet yado al-tzafon*—hand against north.

"''Destroy Assyria.''"

*Vi-y'abbed et-Ashur*—destroy Assyria.

"''Make Nineveh a desolation, and dry like the wilderness.''"

*Ve-yasem et-Nineveh li-shemamah tziyyah ka-midbar*—Nineveh desolate.

**The Key Verses (2:14-15):**
"''Herds shall lie down in the midst of her.''"

*Ve-ravetzu ve-tokhah adarim*—herds.

"''All the beasts of the nations.''"

*Kol-chayeto-goy*—beasts.

"''Both the pelican and the bittern shall lodge in the capitals thereof.''"

*Gam-qa'at gam-qippod bi-khtoreteiha yalinu*—pelican, bittern.

"''Voices shall sing in the windows.''"

*Qol yeshorer ba-challon*—voices.

"''Desolation shall be in the thresholds.''"

*Chorev ba-saf*—desolation.

"''The cedar-work thereof shall be laid bare.''"

*Ki arzah erah*—cedar bare.

"''This is the joyous city that dwelt carelessly.''"

*Zot ha-ir ha-allizan ha-yoshevet la-vetach*—joyous, careless.

"''That said in her heart: I am, and there is none beside me.''"

*Ha-omerah bi-levavah ani ve-afsi od*—I am, none beside.

**Divine Claim:**
"I am, and there is none beside me"—a divine claim used by a city.

"''How is she become a desolation, a place for beasts to lie down in!''"

*Eikh hayetah le-shammah marvetz le-chayyah*—desolation.

"''Every one that passes by her shall hiss, and wag his hand.''"

*Kol over aleiha yishroq yani'a yado*—hiss, wag hand.

**Archetypal Layer:** Zephaniah 2 contains **"Seek YHWH, all you humble of the land... seek righteousness, seek humility; it may be you shall be hid in the day of YHWH's anger" (2:3)**, **oracles against Philistia (2:4-7)** with wordplays on Gaza and Ekron, **Moab and Ammon "shall be as Sodom... and Gomorrah" (2:9)**, **"YHWH will be terrible unto them; for he will famish all the gods of the earth" (2:11)**, **"all the isles of the nations shall worship him, every one from his place" (2:11)**, **Assyria/Nineveh destroyed (2:13-15)**, and **Nineveh's arrogant claim: "I am, and there is none beside me" (2:15)**.

**Ethical Inversion Applied:**
- "'Gather yourselves together'"—gather
- "'O nation that has no shame'"—shameless
- "'Before the fierce anger of YHWH'"—before anger
- "'Seek YHWH, all you humble of the land'"—seek YHWH
- "'Seek righteousness, seek humility'"—seek
- "'It may be you shall be hid'"—perhaps hidden
- "'Gaza shall be forsaken'"—wordplay
- "'Ashkelon a desolation'"—desolation
- "'Ekron shall be rooted up'"—wordplay
- "'Woe unto the inhabitants of the sea-coast'"—woe
- "'I will destroy you, that there shall be no inhabitant'"—destroy
- "'The sea-coast shall be pastures'"—pastures
- "'It shall be a portion for the remnant of the house of Judah'"—Judah's remnant
- "'YHWH their God will remember them'"—remember
- "'I have heard the taunting of Moab'"—taunting
- "'The revilings of the children of Ammon'"—revilings
- "'Moab shall be as Sodom'"—Sodom
- "'The children of Ammon as Gomorrah'"—Gomorrah
- "'A desolation for ever'"—forever
- "'This shall they have for their pride'"—pride
- "'YHWH will be terrible unto them'"—terrible
- "'He will famish all the gods of the earth'"—famish gods
- "'All the isles of the nations shall worship him'"—nations worship
- "'You Ethiopians also, you shall be slain'"—slain
- "'He will stretch out his hand against the north'"—north
- "'Destroy Assyria'"—destroy
- "'Make Nineveh a desolation'"—desolation
- "'Herds shall lie down in the midst of her'"—herds
- "'The pelican and the bittern shall lodge'"—birds
- "'This is the joyous city that dwelt carelessly'"—careless
- "''I am, and there is none beside me''"—arrogance
- "'How is she become a desolation'"—desolation
- "'Every one that passes by her shall hiss'"—hiss

**Modern Equivalent:** Zephaniah 2 opens with a crucial call: "Seek YHWH... seek righteousness, seek humility; it may be you shall be hid" (2:3)—the "humble of the land" theme. Oracles against surrounding nations follow: Philistia (with wordplays), Moab and Ammon (like Sodom and Gomorrah), Ethiopia, and Assyria. Nineveh's arrogant "I am, and there is none beside me" (2:15) echoes YHWH's self-designation—ultimate hubris.

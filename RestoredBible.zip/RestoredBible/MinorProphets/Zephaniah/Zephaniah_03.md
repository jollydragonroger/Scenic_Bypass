# Zephaniah 3: Jerusalem's Sin and Restoration

*From the Hebrew: הוֹי מֹרְאָה וְנִגְאָלָה (Hoy Mor'ah Ve-Nig'alah) — Woe to Her That Is Rebellious and Polluted*

---

## Jerusalem Indicted (3:1-7)

**3:1** Woe to her that is rebellious and polluted, to the oppressing city!

**3:2** She hearkened not to the voice; she received not correction; she trusted not in YHWH; she drew not near to her God.

**3:3** Her princes in the midst of her are roaring lions; her judges are wolves of the desert, they leave not a bone for the morrow.

**3:4** Her prophets are wanton and treacherous persons; her priests have profaned that which is holy, they have done violence to the law.

**3:5** YHWH in the midst of her is righteous, he will not do unrighteousness; every morning he brings his justice to light, it fails not; but the unrighteous knows no shame.

**3:6** I have cut off nations, their corners are desolate; I have made their streets waste, so that none passes by; their cities are destroyed, so that there is no man, so that there is no inhabitant.

**3:7** I said: "Surely you will fear me, you will receive correction"; so her dwelling should not be cut off, according to all that I have appointed concerning her; but they rose early and corrupted all their doings.

---

## The Nations Judged (3:8)

**3:8** Therefore wait for me, says YHWH, until the day that I rise up to the prey; for my determination is to gather the nations, that I may assemble the kingdoms, to pour upon them my indignation, even all my fierce anger; for all the earth shall be devoured with the fire of my jealousy.

---

## Restoration of the Remnant (3:9-20)

**3:9** For then will I turn to the peoples a pure language, that they may all call upon the name of YHWH, to serve him with one consent.

**3:10** From beyond the rivers of Ethiopia shall they bring my suppliants, even the daughter of my dispersed, as my offering.

**3:11** In that day shall you not be put to shame for all your doings, wherein you have transgressed against me; for then I will take away out of the midst of you your proudly exulting ones, and you shall no more be haughty in my holy mountain.

**3:12** And I will leave in the midst of you an afflicted and poor people, and they shall take refuge in the name of YHWH.

**3:13** The remnant of Israel shall not do iniquity, nor speak lies, neither shall a deceitful tongue be found in their mouth; for they shall feed and lie down, and none shall make them afraid.

**3:14** Sing, O daughter of Zion, shout, O Israel; be glad and rejoice with all the heart, O daughter of Jerusalem.

**3:15** YHWH has taken away your judgments, he has cast out your enemy; the King of Israel, even YHWH, is in the midst of you; you shall not fear evil any more.

**3:16** In that day it shall be said to Jerusalem: "Fear not; O Zion, let not your hands be slack."

**3:17** YHWH your God is in the midst of you, a mighty one who will save; he will rejoice over you with joy, he will be silent in his love, he will exult over you with singing.

**3:18** I will gather them that are far from the solemn assembly, who are of you, that bore for her sake the burden of reproach.

**3:19** Behold, at that time I will deal with all them that afflict you; and I will save her that is lame, and gather her that was driven away; and I will make them a praise and a name, whose shame was in all the earth.

**3:20** At that time will I bring you in, and at that time will I gather you; for I will make you a name and a praise among all the peoples of the earth, when I turn your captivity before your eyes, says YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Jerusalem Indicted (3:1-7):**
**The Key Verses (3:1-2):**
"'Woe to her that is rebellious and polluted.'"

*Hoy mor'ah ve-nig'alah*—rebellious, polluted.

"'To the oppressing city!'"

*Ha-ir ha-yonah*—oppressing city.

"'She hearkened not to the voice.'"

*Lo sham'ah be-qol*—didn't hearken.

"'She received not correction.'"

*Lo laqchah musar*—no correction.

"'She trusted not in YHWH.'"

*Ba-YHWH lo vatachah*—didn't trust.

"'She drew not near to her God.'"

*El-Eloheiha lo qarevah*—didn't draw near.

**The Key Verses (3:3-5):**
"'Her princes in the midst of her are roaring lions.'"

*Sareiha be-qirbah arayot sho'agim*—princes as lions.

"'Her judges are wolves of the desert.'"

*Shofeteiha ze'evei erev*—judges as wolves.

"'They leave not a bone for the morrow.'"

*Lo garemu la-boqer*—nothing left.

"'Her prophets are wanton and treacherous persons.'"

*Nevi'eiha pochazim anshei bogedot*—wanton prophets.

"'Her priests have profaned that which is holy.'"

*Kohaneiha chilelu qodesh*—priests profane.

"'They have done violence to the law.'"

*Chamsu torah*—violence to Torah.

"'YHWH in the midst of her is righteous.'"

*YHWH tzaddiq be-qirbah*—YHWH righteous.

"'He will not do unrighteousness.'"

*Lo ya'aseh avlah*—no unrighteousness.

"'Every morning he brings his justice to light.'"

*Ba-boqer ba-boqer mishpato yitten la-or*—justice every morning.

"'It fails not.'"

*Lo ne'dar*—doesn't fail.

"'The unrighteous knows no shame.'"

*Ve-lo-yode'a avval boshet*—no shame.

**The Key Verses (3:6-7):**
"''I have cut off nations.''"

*Hikhrati goyim*—cut off nations.

"''Their corners are desolate.''"

*Nashammu pinnotam*—desolate.

"''I have made their streets waste.''"

*Heחravti chutzotam*—streets waste.

"''Their cities are destroyed.''"

*Nitzdu areihem*—cities destroyed.

"''I said: Surely you will fear me.''"

*Amarti akh-tire'י oti*—will fear me.

"''You will receive correction.''"

*Tiqchi musar*—receive correction.

"''So her dwelling should not be cut off.''"

*Ve-lo-yikkaret me'onah*—not cut off.

"''But they rose early and corrupted all their doings.''"

*Akhen hishkimu hishchitu kol alilotam*—corrupted doings.

**Nations Judged (3:8):**
**The Key Verse (3:8):**
"''Therefore wait for me.''"

*Lakhen chakku-li*—wait.

"''Until the day that I rise up to the prey.''"

*Le-yom qumi le-ad*—rise up.

"''My determination is to gather the nations.''"

*Ki mishpati le'esof goyim*—gather nations.

"''To assemble the kingdoms.''"

*Le-qobtzi mamlakhot*—assemble kingdoms.

"''To pour upon them my indignation.''"

*Lishpokh aleihem za'mi*—pour indignation.

"''All my fierce anger.''"

*Kol charon appi*—fierce anger.

"''All the earth shall be devoured with the fire of my jealousy.''"

*Ki be-esh qin'ati te'akhel kol-ha-aretz*—fire of jealousy.

**Restoration of the Remnant (3:9-20):**
**The Key Verses (3:9-10):**
"''Then will I turn to the peoples a pure language.''"

*Ki-az ehepokh el-ammim safah verurah*—pure language.

**Safah Verurah:**
"Pure language/lip"—unified worship.

"''That they may all call upon the name of YHWH.''"

*Liqro khullam be-shem YHWH*—call on YHWH.

"''To serve him with one consent.''"

*Le-ovdo shekhem echad*—one shoulder.

"''From beyond the rivers of Ethiopia shall they bring my suppliants.''"

*Me-ever le-naharei-Kush atarai bat-futzai yovilun minchat י*—Ethiopia.

"''Even the daughter of my dispersed, as my offering.''"

*Bat-putzai*—dispersed daughter.

**The Key Verses (3:11-13):**
"''In that day shall you not be put to shame.''"

*Ba-yom ha-hu lo tevoshi*—not shamed.

"''For all your doings, wherein you have transgressed against me.''"

*Mi-kol alilotayikh asher pasha't bi*—transgressions.

"''I will take away out of the midst of you your proudly exulting ones.''"

*Ki-az asir mi-qirbekh alliזei ga'avatekh*—remove proud.

"''You shall no more be haughty in my holy mountain.''"

*Ve-lo-tosifi le-govhah od be-har qodshi*—no more haughty.

"''I will leave in the midst of you an afflicted and poor people.''"

*Ve-hish'arti be-qirbekh am ani va-dal*—afflicted, poor.

"''They shall take refuge in the name of YHWH.''"

*Ve-chasu be-shem YHWH*—refuge in YHWH.

"''The remnant of Israel shall not do iniquity.''"

*She'erit Yisra'el lo-ya'asu avlah*—no iniquity.

"''Nor speak lies.''"

*Ve-lo-yedabberu khazav*—no lies.

"''Neither shall a deceitful tongue be found in their mouth.''"

*Ve-lo-yimmatze be-fihem leshon tarmit*—no deceit.

"''They shall feed and lie down, and none shall make them afraid.''"

*Ki-hemmah yir'u ve-ravetzu ve-ein machrid*—none afraid.

**The Key Verses (3:14-17):**
"''Sing, O daughter of Zion, shout, O Israel.''"

*Ronni bat-Tziyon hari'u Yisra'el*—sing, shout.

"''Be glad and rejoice with all the heart, O daughter of Jerusalem.''"

*Simchi ve-ozi be-khol-lev bat-Yerushalayim*—rejoice.

"''YHWH has taken away your judgments.''"

*Hesir YHWH mishpatayikh*—judgments removed.

"''He has cast out your enemy.''"

*Pinnah oyevekh*—enemy cast out.

"''The King of Israel, even YHWH, is in the midst of you.''"

*Melekh Yisra'el YHWH be-qirbekh*—King in midst.

"''You shall not fear evil any more.''"

*Lo-tire'י ra od*—no more fear.

"''Fear not; O Zion, let not your hands be slack.''"

*Al-tire'י Tziyon al-yirpu yadayikh*—fear not.

"''YHWH your God is in the midst of you, a mighty one who will save.''"

*YHWH Elohayikh be-qirbekh gibbor yoshi'a*—mighty savior.

"''He will rejoice over you with joy.''"

*Yasis alayikh be-simchah*—rejoices.

"''He will be silent in his love.''"

*Yacharish be-ahavato*—silent in love.

"''He will exult over you with singing.''"

*Yagil alayikh be-rinnah*—exults with singing.

**Famous Verse:**
God singing over His people with joy.

**The Key Verses (3:18-20):**
"''I will gather them that are far from the solemn assembly.''"

*Nugei mi-mo'ed asafti*—gather.

"''Who are of you, that bore for her sake the burden of reproach.''"

*Mimmekh hayu masa'et aleiha cherpah*—burden.

"''I will deal with all them that afflict you.''"

*Hineni oseh et-kol-me'annayikh*—deal with afflicters.

"''I will save her that is lame.''"

*Ve-hosha'ti et-ha-tzolea*—save lame.

"''Gather her that was driven away.''"

*Ve-ha-nidachah aqabbetz*—gather driven.

"''I will make them a praise and a name.''"

*Ve-samtim li-tehillah u-le-shem*—praise, name.

"''Whose shame was in all the earth.''"

*Be-khol-ha-aretz boshhtam*—former shame.

"''At that time will I bring you in.''"

*Ba-et ha-hi avi etkhem*—bring in.

"''At that time will I gather you.''"

*U-va-et qabbetzi etkhem*—gather.

"''I will make you a name and a praise among all the peoples of the earth.''"

*Ki-etten etkhem le-shem ve-li-tehillah be-khol ammei ha-aretz*—praise among all.

"''When I turn your captivity before your eyes.''"

*Be-shuvi et-shevuteikhem le-eineikhem*—turn captivity.

**Archetypal Layer:** Zephaniah 3 moves from **judgment to restoration**, containing **"Woe to her that is rebellious and polluted, to the oppressing city!" (3:1)**, **indictment of Jerusalem's leaders: princes as lions, judges as wolves, wanton prophets, profaning priests (3:3-4)**, **"YHWH in the midst of her is righteous... every morning he brings his justice to light" (3:5)**, **"wait for me... my determination is to gather the nations" (3:8)**, **"I will turn to the peoples a pure language, that they may all call upon the name of YHWH" (3:9)**, **"I will leave in the midst of you an afflicted and poor people" (3:12)**, **"Sing, O daughter of Zion... YHWH has taken away your judgments" (3:14-15)**, **"YHWH your God is in the midst of you, a mighty one who will save; he will rejoice over you with joy... he will exult over you with singing" (3:17)**, and **"I will make you a name and a praise among all the peoples of the earth" (3:20)**.

**Ethical Inversion Applied:**
- "'Woe to her that is rebellious and polluted'"—woe
- "'To the oppressing city!'"—oppressing
- "'She hearkened not to the voice'"—didn't hearken
- "'She received not correction'"—no correction
- "'She trusted not in YHWH'"—didn't trust
- "'Her princes... are roaring lions'"—lions
- "'Her judges are wolves of the desert'"—wolves
- "'Her prophets are wanton and treacherous'"—wanton
- "'Her priests have profaned that which is holy'"—profaned
- "'They have done violence to the law'"—violence to Torah
- "'YHWH in the midst of her is righteous'"—righteous
- "'Every morning he brings his justice to light'"—justice
- "'The unrighteous knows no shame'"—no shame
- "''I have cut off nations''"—cut off
- "''Surely you will fear me''"—fear
- "''But they rose early and corrupted all their doings''"—corrupted
- "''Wait for me''"—wait
- "''My determination is to gather the nations''"—gather
- "''I will turn to the peoples a pure language''"—pure language
- "''That they may all call upon the name of YHWH''"—call on YHWH
- "''From beyond the rivers of Ethiopia''"—Ethiopia
- "''In that day shall you not be put to shame''"—not shamed
- "''I will take away... your proudly exulting ones''"—remove proud
- "''I will leave... an afflicted and poor people''"—humble remnant
- "''They shall take refuge in the name of YHWH''"—refuge
- "''The remnant of Israel shall not do iniquity''"—no iniquity
- "''None shall make them afraid''"—none afraid
- "''Sing, O daughter of Zion''"—sing
- "''YHWH has taken away your judgments''"—judgments removed
- "''The King of Israel, even YHWH, is in the midst of you''"—King in midst
- "''You shall not fear evil any more''"—no fear
- "''YHWH your God is in the midst of you''"—in midst
- "''A mighty one who will save''"—mighty savior
- "''He will rejoice over you with joy''"—rejoices
- "''He will be silent in his love''"—silent in love
- "''He will exult over you with singing''"—exults
- "''I will save her that is lame''"—save lame
- "''I will make them a praise and a name''"—praise, name
- "''I will make you a name and a praise among all the peoples''"—name among all

**Modern Equivalent:** Zephaniah 3 moves from judgment to glorious restoration. Jerusalem's leaders are condemned as predators (3:3-4). But YHWH remains righteous in her midst (3:5). The restoration vision (3:9-20) features "a pure language" for unified worship (3:9), a humble remnant (3:12), and climaxes with the beautiful 3:17: "YHWH your God is in the midst of you, a mighty one who will save; he will rejoice over you with joy... he will exult over you with singing." God singing over His people is one of Scripture's most tender images.

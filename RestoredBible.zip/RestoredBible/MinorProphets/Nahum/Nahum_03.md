# Nahum 3: Woe to the Bloody City

*From the Hebrew: הוֹי עִיר דָּמִים (Hoy Ir Damim) — Woe to the Bloody City*

---

## Woe to Nineveh (3:1-7)

**3:1** Woe to the bloody city! It is all full of lies and rapine; the prey departs not.

**3:2** The noise of the whip, and the noise of the rattling of wheels; and prancing horses, and bounding chariots!

**3:3** The horseman mounts, and the flashing sword, and the glittering spear; and a multitude of slain, and a great heap of carcasses; and there is no end of the corpses, they stumble upon their corpses;

**3:4** Because of the multitude of the harlotries of the well-favoured harlot, the mistress of witchcrafts, that sells nations through her harlotries, and families through her witchcrafts.

**3:5** Behold, I am against you, says YHWH of hosts, and I will uncover your skirts upon your face, and I will show the nations your nakedness, and the kingdoms your shame.

**3:6** And I will cast abominable filth upon you, and make you vile, and will make you a gazingstock.

**3:7** And it shall come to pass, that all they that look upon you shall flee from you, and say: "Nineveh is laid waste; who will bemoan her?" Whence shall I seek comforters for you?

---

## The Fate of Thebes (3:8-10)

**3:8** Are you better than No-amon, that was situate among the rivers, that had the waters round about her; whose rampart was the sea, and of the sea her wall?

**3:9** Ethiopia and Egypt were her strength, and it was infinite; Put and Lubim were your helpers.

**3:10** Yet was she carried away, she went into captivity; her young children also were dashed in pieces at the head of all the streets; and they cast lots for her honourable men, and all her great men were bound in chains.

---

## Nineveh's Doom (3:11-19)

**3:11** You also shall be drunken, you shall be hid; you also shall seek a stronghold because of the enemy.

**3:12** All your fortresses shall be like fig-trees with the first-ripe figs: if they be shaken, they fall into the mouth of the eater.

**3:13** Behold, your people in the midst of you are women; the gates of your land are set wide open unto your enemies; the fire has devoured your bars.

**3:14** Draw water for the siege, strengthen your fortresses; go into the clay, and tread the mortar; lay hold of the brick-mould.

**3:15** There shall the fire devour you; the sword shall cut you off; it shall devour you like the cankerworm; make yourself many as the cankerworm, make yourself many as the locust.

**3:16** You have multiplied your merchants above the stars of heaven; the cankerworm spreads itself, and flies away.

**3:17** Your princes are as the locusts, and your marshals as the swarms of grasshoppers, which camp in the walls in the cold day, but when the sun arises they flee away, and their place is not known where they are.

**3:18** Your shepherds slumber, O king of Assyria, your nobles are at rest; your people are scattered upon the mountains, and there is none to gather them.

**3:19** There is no assuaging of your hurt, your wound is grievous; all that hear the report of you clap their hands over you; for upon whom has not your wickedness passed continually?

---

## Synthesis Notes

**Key Restorations:**

**Woe to Nineveh (3:1-7):**
**The Key Verses (3:1-3):**
"'Woe to the bloody city!'"

*Hoy ir damim*—bloody city.

"'It is all full of lies and rapine.'"

*Kullah khachash pereq mele'ah*—lies, rapine.

"'The prey departs not.'"

*Lo yamish teref*—constant prey.

"'The noise of the whip, and the noise of the rattling of wheels.'"

*Qol shot ve-qol ra'ash ofan*—whip, wheels.

"'Prancing horses, and bounding chariots!'"

*Ve-sus doher u-merkavah meraqqedah*—horses, chariots.

"'The horseman mounts, and the flashing sword.'"

*Parash ma'aleh ve-lahav cherev*—horseman, sword.

"'The glittering spear.'"

*U-veraq chanit*—glittering spear.

"'A multitude of slain, and a great heap of carcasses.'"

*Ve-rov chalal ve-khoved peger*—corpses.

"'There is no end of the corpses, they stumble upon their corpses.'"

*Ve-ein qetzeh la-geviyyah yikashlu bi-geviyyatam*—stumble on corpses.

**The Key Verses (3:4-7):**
"'Because of the multitude of the harlotries of the well-favoured harlot.'"

*Me-rov zenunei zonah tovat chen*—harlot.

"'The mistress of witchcrafts.'"

*Ba'alat keshafim*—mistress of witchcraft.

"'That sells nations through her harlotries.'"

*Ha-mokheret goyim bi-znuneiha*—sells nations.

"'And families through her witchcrafts.'"

*U-mishpachot be-khashfeiha*—families by witchcraft.

**Harlot Metaphor:**
Nineveh as seductive, manipulative power.

"''Behold, I am against you,' says YHWH of hosts.'"

*Hineni elayikh ne'um YHWH tzeva'ot*—against you.

"''I will uncover your skirts upon your face.''"

*Ve-gilleiti shulayikh al-panayikh*—uncover skirts.

"''I will show the nations your nakedness.''"

*Ve-har'eiti goyim ma'rekh*—show nakedness.

"''The kingdoms your shame.''"

*U-mamlakhot qelonekh*—show shame.

"''I will cast abominable filth upon you.''"

*Ve-hishlakhti alayikh shiqqוtzim*—cast filth.

"''Make you vile, and will make you a gazingstock.''"

*Ve-nibbalitikh ve-samtikh ki-ro'י*—gazingstock.

"''All they that look upon you shall flee from you.''"

*Ve-hayah khol-ro'ayikh yiddod mimmekh*—flee.

"''Nineveh is laid waste; who will bemoan her?''"

*Shaddadah Nineveh mi yanud lah*—who bemoans?

"''Whence shall I seek comforters for you?''"

*Me-ayin avvaqqesh menachamim lakh*—no comforters.

**Fate of Thebes (3:8-10):**
**The Key Verses (3:8-10):**
"'Are you better than No-amon?'"

*Ha-titevi mi-No Amon*—better than Thebes?

**No-Amon:**
Thebes in Egypt, destroyed by Assyria in 663 BCE.

"'That was situate among the rivers.'"

*Ha-yoshevah ba-ye'orim*—among rivers.

"'That had the waters round about her.'"

*Mayim saviv lah*—waters around.

"'Whose rampart was the sea, and of the sea her wall.'"

*Asher-chel yam mi-yam chomatah*—sea as wall.

"'Ethiopia and Egypt were her strength, and it was infinite.'"

*Kush otzmatah u-Mitzrayim ve-ein qetzeh*—infinite strength.

"'Put and Lubim were your helpers.'"

*Put ve-Luvim hayu be-ezratekh*—Put, Libya helpers.

"'Yet was she carried away, she went into captivity.'"

*Gam-hi la-golah halkhah ba-shevi*—captivity.

"'Her young children also were dashed in pieces at the head of all the streets.'"

*Gam oleleiha yeruttashu be-rosh kol-chutzot*—children dashed.

"'They cast lots for her honourable men.'"

*Ve-al-nikhbaddeiha yaddו goral*—cast lots.

"'All her great men were bound in chains.'"

*Ve-khol-gedoleiha ruttqu ba-ziqim*—bound.

**Nineveh's Doom (3:11-19):**
**The Key Verses (3:11-13):**
"'You also shall be drunken.'"

*Gam-at tishkeri*—drunken.

"'You shall be hid.'"

*Tehi na'alamah*—hidden.

"'You also shall seek a stronghold because of the enemy.'"

*Gam-at tevaqqeshi ma'oz me-oyev*—seek stronghold.

"'All your fortresses shall be like fig-trees with the first-ripe figs.'"

*Kol-mivtzarayikh te'enim im-bikkurim*—like fig trees.

"'If they be shaken, they fall into the mouth of the eater.'"

*Im-yinno'u ve-nafelu al-pi okhel*—fall to eater.

"'Behold, your people in the midst of you are women.'"

*Hinneh ammekh nashim be-qirbekh*—people like women.

"'The gates of your land are set wide open unto your enemies.'"

*Le-oyevayikh patoach niftechu sha'arei artzekh*—gates open.

"'The fire has devoured your bars.'"

*Akhelah esh berichayikh*—fire devoured.

**The Key Verses (3:14-17):**
"'Draw water for the siege.'"

*Mei matzor sha'avi-lakh*—draw water.

"'Strengthen your fortresses.'"

*Chazzeqi mivtzarayikh*—strengthen.

"'Go into the clay, and tread the mortar.'"

*Bo'i va-tit ve-rimsi ba-chomer*—tread mortar.

"'Lay hold of the brick-mould.'"

*Hachziqi malben*—make bricks.

"'There shall the fire devour you.'"

*Sham tokhlekh esh*—fire devours.

"'The sword shall cut you off.'"

*Takhritkh cherev*—sword cuts.

"'It shall devour you like the cankerworm.'"

*Tokhlekh ka-yeleq*—like locust.

"'Make yourself many as the cankerworm, make yourself many as the locust.'"

*Hithkabbedi ka-yeleq hithkabbedi kha-arbeh*—multiply like locust.

"'You have multiplied your merchants above the stars of heaven.'"

*Hirbeit rokhlaיikh mi-kokhevei ha-shamayim*—merchants like stars.

"'The cankerworm spreads itself, and flies away.'"

*Yeleq pashat va-ya'of*—flies away.

"'Your princes are as the locusts.'"

*Minnezarayikh kha-arbeh*—princes like locusts.

"'Your marshals as the swarms of grasshoppers.'"

*Ve-tafserayikh ke-gov govai*—marshals like grasshoppers.

"'Which camp in the walls in the cold day.'"

*Ha-chonים ba-gederot be-yom qarah*—camp in cold.

"'But when the sun arises they flee away.'"

*Shemesh zarechah ve-nodad*—sun rises, flee.

"'Their place is not known where they are.'"

*Ve-lo-noda meqomo ayyam*—unknown.

**The Key Verses (3:18-19):**
"'Your shepherds slumber, O king of Assyria.'"

*Namu ro'ekha melekh Ashur*—shepherds slumber.

"'Your nobles are at rest.'"

*Yishkenu addirekha*—nobles rest.

"'Your people are scattered upon the mountains.'"

*Nafoshu ammekha al-he-harim*—scattered.

"'There is none to gather them.'"

*Ve-ein meqabbetz*—none gathers.

"'There is no assuaging of your hurt.'"

*Ein kehah le-shivrekha*—no healing.

"'Your wound is grievous.'"

*Nachlah makkatekha*—grievous wound.

"'All that hear the report of you clap their hands over you.'"

*Kol shome'ei shim'akha taq'u khaf alekha*—clap hands.

"'For upon whom has not your wickedness passed continually?'"

*Ki al-mi lo averah ra'atkha tamid*—your evil on all.

**Archetypal Layer:** Nahum 3 contains **"Woe to the bloody city! It is all full of lies and rapine" (3:1)**, **vivid battle sounds: whip, wheels, horses, chariots (3:2)**, **"a multitude of slain, and a great heap of carcasses" (3:3)**, **the harlot metaphor: "the mistress of witchcrafts, that sells nations" (3:4)**, **"Behold, I am against you... I will show the nations your nakedness" (3:5)**, **the example of Thebes: "Are you better than No-amon?" (3:8)**—Thebes fell despite strength, **"All your fortresses shall be like fig-trees with the first-ripe figs" (3:12)**, **locust imagery (3:15-17)**, **"Your shepherds slumber, O king of Assyria" (3:18)**, and **"all that hear the report of you clap their hands over you; for upon whom has not your wickedness passed continually?" (3:19)**.

**Ethical Inversion Applied:**
- "'Woe to the bloody city!'"—bloody city
- "'It is all full of lies and rapine'"—lies, rapine
- "'The prey departs not'"—constant prey
- "'The noise of the whip'"—whip
- "'Prancing horses, and bounding chariots!'"—horses, chariots
- "'The horseman mounts, and the flashing sword'"—sword
- "'A multitude of slain'"—slain
- "'There is no end of the corpses'"—endless corpses
- "'Because of the multitude of the harlotries'"—harlotries
- "'The mistress of witchcrafts'"—witchcraft
- "'That sells nations through her harlotries'"—sells nations
- "''Behold, I am against you''"—against
- "''I will uncover your skirts upon your face''"—uncover
- "''I will show the nations your nakedness''"—nakedness
- "''I will cast abominable filth upon you''"—filth
- "''Make you vile, and will make you a gazingstock''"—gazingstock
- "''Nineveh is laid waste; who will bemoan her?''"—who bemoans
- "'Are you better than No-amon?'"—Thebes
- "'Ethiopia and Egypt were her strength'"—strength
- "'Yet was she carried away'"—captivity
- "'Her young children also were dashed in pieces'"—children dashed
- "'You also shall be drunken'"—drunken
- "'All your fortresses shall be like fig-trees'"—fig trees
- "'If they be shaken, they fall'"—fall
- "'Your people in the midst of you are women'"—like women
- "'The gates of your land are set wide open'"—gates open
- "'Draw water for the siege'"—prepare
- "'The fire devour you'"—fire
- "'The sword shall cut you off'"—sword
- "'Make yourself many as the locust'"—locust
- "'You have multiplied your merchants'"—merchants
- "'Your princes are as the locusts'"—locusts
- "'When the sun arises they flee away'"—flee
- "'Your shepherds slumber, O king of Assyria'"—slumber
- "'Your people are scattered'"—scattered
- "'There is none to gather them'"—none gathers
- "'There is no assuaging of your hurt'"—no healing
- "'Your wound is grievous'"—grievous
- "'All that hear the report of you clap their hands'"—clap hands
- "'Upon whom has not your wickedness passed continually?'"—wickedness on all

**Modern Equivalent:** Nahum 3 concludes with devastating poetry. The "bloody city" is full of lies, violence, and witchcraft (3:1-4). The example of Thebes (3:8-10)—destroyed by Assyria itself—shows that no city is invincible. The locust imagery (3:15-17) depicts Nineveh's merchants and officials as insects that vanish. The book ends with universal applause at Nineveh's fall: "upon whom has not your wickedness passed continually?" (3:19).

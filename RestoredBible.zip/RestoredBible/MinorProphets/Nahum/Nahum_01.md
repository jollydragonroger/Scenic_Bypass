# Nahum 1: YHWH's Vengeance Against Nineveh

*From the Hebrew: מַשָּׂא נִינְוֵה (Massa Nineveh) — The Burden of Nineveh*

---

## Title (1:1)

**1:1** The burden of Nineveh. The book of the vision of Nahum the Elkoshite.

---

## Hymn of YHWH's Power (1:2-8)

**1:2** YHWH is a jealous God and avenges; YHWH avenges and is full of wrath; YHWH takes vengeance on his adversaries, and he reserves wrath for his enemies.

**1:3** YHWH is long-suffering, and great in power, and will by no means clear the guilty; YHWH, in the whirlwind and in the storm is his way, and the clouds are the dust of his feet.

**1:4** He rebukes the sea, and makes it dry, and dries up all the rivers; Bashan languishes, and Carmel, and the flower of Lebanon languishes.

**1:5** The mountains quake before him, and the hills melt; and the earth is upheaved at his presence, yea, the world, and all that dwell therein.

**1:6** Who can stand before his indignation? And who can abide in the fierceness of his anger? His fury is poured out like fire, and the rocks are broken asunder before him.

**1:7** YHWH is good, a stronghold in the day of trouble; and he knows them that take refuge in him.

**1:8** But with an overrunning flood he will make a full end of her place, and will pursue his enemies into darkness.

---

## Oracle Against Nineveh (1:9-14)

**1:9** What do you devise against YHWH? He will make a full end; trouble shall not rise up the second time.

**1:10** For though they be like tangled thorns, and be drunken according to their drink, they shall be devoured as stubble fully dry.

**1:11** Out of you is gone forth one that devises evil against YHWH, that counsels wickedness.

**1:12** Thus says YHWH: Though they be in full strength, and likewise many, even so shall they be cut down, and he shall pass away. And though I have afflicted you, I will afflict you no more.

**1:13** And now will I break his yoke from off you, and will burst your bonds in sunder.

**1:14** And YHWH has commanded concerning you: Your name shall no more be sown; out of the house of your god will I cut off the graven image and the molten image; I will make your grave; for you are vile.

---

## Good News for Judah (1:15)

**1:15** Behold upon the mountains the feet of him that brings good tidings, that publishes peace! Keep your feasts, O Judah, perform your vows; for the wicked one shall no more pass through you; he is utterly cut off.

---

## Synthesis Notes

**Key Restorations:**

**Title (1:1):**
**The Key Verse (1:1):**
"The burden of Nineveh."

*Massa Nineveh*—oracle against Nineveh.

"The book of the vision of Nahum the Elkoshite."

*Sefer chazon Nachum ha-Elqoshi*—Nahum's vision.

**Nachum:**
"Comfort"—ironic for a book of judgment.

**Elkoshite:**
From Elkosh, location unknown.

**Hymn of YHWH's Power (1:2-8):**
**The Key Verses (1:2-3):**
"'YHWH is a jealous God and avenges.'"

*El qanno ve-noqem YHWH*—jealous, avenging.

"'YHWH avenges and is full of wrath.'"

*Noqem YHWH u-va'al chemah*—full of wrath.

"'YHWH takes vengeance on his adversaries.'"

*Noqem YHWH le-tzarav*—vengeance on adversaries.

"'He reserves wrath for his enemies.'"

*Ve-noter hu le-oyevav*—reserves for enemies.

"'YHWH is long-suffering, and great in power.'"

*YHWH erekh appayim u-gedol-koach*—long-suffering, powerful.

"'Will by no means clear the guilty.'"

*Ve-naqqeh lo yenaqqeh*—won't clear guilty.

"'In the whirlwind and in the storm is his way.'"

*Ba-sufah u-vi-se'arah darkو*—whirlwind, storm.

"'The clouds are the dust of his feet.'"

*Ve-anan avaq raglav*—clouds are dust.

**The Key Verses (1:4-6):**
"'He rebukes the sea, and makes it dry.'"

*Go'er ba-yam va-yabeshehu*—rebukes sea.

"'Dries up all the rivers.'"

*Ve-khol-ha-neharot hecheriv*—dries rivers.

"'Bashan languishes, and Carmel.'"

*Umlal Bashan ve-Kharmel*—Bashan, Carmel languish.

"'The flower of Lebanon languishes.'"

*Ve-ferach Levanon umlal*—Lebanon fades.

"'The mountains quake before him, and the hills melt.'"

*Harim ra'ashu mimmennו ve-ha-geva'ot hitmogebu*—mountains quake.

"'The earth is upheaved at his presence.'"

*Va-tissa ha-aretz mi-panav*—earth upheaved.

"'The world, and all that dwell therein.'"

*Ve-tevel ve-khol-yoshevei vah*—world, all inhabitants.

"'Who can stand before his indignation?'"

*Lifnei za'mo mi ya'amod*—who can stand?

"'Who can abide in the fierceness of his anger?'"

*U-mi yaqum ba-charon appo*—who can abide?

"'His fury is poured out like fire.'"

*Chamato nittekhah ka-esh*—fury like fire.

"'The rocks are broken asunder before him.'"

*Ve-ha-tzurim nittetzו mimmennו*—rocks broken.

**The Key Verses (1:7-8):**
"'YHWH is good, a stronghold in the day of trouble.'"

*Tov YHWH le-ma'oz be-yom tzarah*—good, stronghold.

"'He knows them that take refuge in him.'"

*Ve-yode'a chosei vo*—knows those who trust.

"'With an overrunning flood he will make a full end of her place.'"

*U-ve-shetef over kalah ya'aseh meqomah*—flood ends her.

"'Will pursue his enemies into darkness.'"

*Ve-oyevav yeraddef choshekh*—pursue into darkness.

**Oracle Against Nineveh (1:9-14):**
**The Key Verses (1:9-11):**
"'What do you devise against YHWH?'"

*Mah-techashవun el-YHWH*—what do you devise?

"'He will make a full end.'"

*Kalah hu oseh*—full end.

"'Trouble shall not rise up the second time.'"

*Lo-taqum pa'amayim tzarah*—not twice.

"'Though they be like tangled thorns.'"

*Ki ad-sirim sevukhim*—tangled thorns.

"'Be drunken according to their drink.'"

*U-khe-sov'am sevu'im*—drunken.

"'They shall be devoured as stubble fully dry.'"

*Ukkelu ke-qash yavesh male*—devoured as stubble.

"'Out of you is gone forth one that devises evil against YHWH.'"

*Mimmekh yatza choshev al-YHWH ra'ah*—evil deviser.

"'That counsels wickedness.'"

*Yo'etz beliyya'al*—counsels wickedness.

**The Key Verses (1:12-14):**
"''Though they be in full strength, and likewise many.''"

*Koh amar YHWH im-shelemim ve-khen rabbim*—full strength.

"''Even so shall they be cut down.''"

*Ve-khen nagazzu ve-avar*—cut down.

"''Though I have afflicted you, I will afflict you no more.''"

*Ve-innitikh lo a'anneikh od*—no more affliction.

"''Now will I break his yoke from off you.''"

*Ve-attah eshbor mottehu me-alayikh*—break yoke.

"''Will burst your bonds in sunder.''"

*U-mosrotayikh anattiq*—burst bonds.

"''YHWH has commanded concerning you: Your name shall no more be sown.''"

*Ve-tzivvah alekha YHWH lo-yizzare'a mi-shimkha od*—name not sown.

"''Out of the house of your god will I cut off the graven image.''"

*Mi-beit elohekha akhrit pesel u-massekha*—cut off images.

"''I will make your grave; for you are vile.''"

*Asim qivrekha ki qallota*—grave, vile.

**Good News for Judah (1:15):**
**The Key Verse (1:15):**
"'Behold upon the mountains the feet of him that brings good tidings.'"

*Hinneh al-he-harim raglei mevasser*—feet of messenger.

"'That publishes peace!'"

*Mashmi'a shalom*—publishes peace.

"'Keep your feasts, O Judah, perform your vows.'"

*Choggi Yehudah chaggayikh shallemi nedarayikh*—keep feasts.

"'The wicked one shall no more pass through you.'"

*Ki lo yosif la'avor-bakh beliyya'al*—wicked no more.

"'He is utterly cut off.'"

*Kullo nikhrat*—utterly cut off.

**Quoted in Isaiah 52:7 and Romans 10:15.**

**Archetypal Layer:** Nahum 1 contains **the title (1:1)**, **the hymn of YHWH's power (1:2-8)**: "YHWH is a jealous God and avenges" (1:2), "YHWH is long-suffering, and great in power, and will by no means clear the guilty" (1:3), cosmic theophany with mountains quaking and earth upheaved (1:4-6), "YHWH is good, a stronghold in the day of trouble" (1:7), **oracle against Nineveh (1:9-14)**: "What do you devise against YHWH? He will make a full end" (1:9), "I will break his yoke from off you" (1:13), "I will make your grave" (1:14), and **good news for Judah (1:15)**: "Behold upon the mountains the feet of him that brings good tidings, that publishes peace!"

**Ethical Inversion Applied:**
- "The burden of Nineveh"—oracle
- "The book of the vision of Nahum"—Nahum's vision
- "'YHWH is a jealous God and avenges'"—jealous, avenging
- "'YHWH avenges and is full of wrath'"—wrath
- "'He reserves wrath for his enemies'"—reserves
- "'YHWH is long-suffering, and great in power'"—long-suffering
- "'Will by no means clear the guilty'"—won't clear
- "'In the whirlwind and in the storm is his way'"—theophany
- "'The clouds are the dust of his feet'"—clouds
- "'He rebukes the sea, and makes it dry'"—rebukes sea
- "'The mountains quake before him'"—mountains quake
- "'The earth is upheaved at his presence'"—upheaved
- "'Who can stand before his indignation?'"—who can stand
- "'His fury is poured out like fire'"—fury
- "'YHWH is good, a stronghold in the day of trouble'"—stronghold
- "'He knows them that take refuge in him'"—knows
- "'With an overrunning flood he will make a full end'"—flood
- "'What do you devise against YHWH?'"—devise
- "'He will make a full end'"—full end
- "'Trouble shall not rise up the second time'"—not twice
- "'They shall be devoured as stubble'"—devoured
- "'Out of you is gone forth one that devises evil'"—evil deviser
- "''Though they be in full strength... shall they be cut down''"—cut down
- "''I will afflict you no more''"—no more
- "''Now will I break his yoke from off you''"—break yoke
- "''Your name shall no more be sown''"—name ended
- "''I will make your grave'"—grave
- "'Behold upon the mountains the feet of him that brings good tidings'"—good tidings
- "'That publishes peace!'"—peace
- "'Keep your feasts, O Judah'"—feasts
- "'The wicked one shall no more pass through you'"—no more
- "'He is utterly cut off'"—cut off

**Modern Equivalent:** Nahum 1 opens with a powerful hymn celebrating YHWH as avenger. Unlike Jonah (where Nineveh repented), Nahum announces Nineveh's doom—about 150 years later. "YHWH is good, a stronghold in the day of trouble" (1:7) offers hope for Judah amid judgment on oppressors. "Behold upon the mountains the feet of him that brings good tidings" (1:15) is quoted in Isaiah 52:7 and Romans 10:15.

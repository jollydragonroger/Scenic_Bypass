# Nahum 2: The Fall of Nineveh

*From the Hebrew: עָלָה מֵפִיץ עַל־פָּנָיִךְ (Alah Mefitz Al-Panayikh) — A Shatterer Has Come Up Against You*

---

## The Attack (2:1-6)

**2:1** A shatterer has come up against you; guard the rampart, watch the way, make your loins strong, fortify your power mightily!

**2:2** For YHWH restores the pride of Jacob, as the pride of Israel; for the emptiers have emptied them out, and marred their vine-branches.

**2:3** The shield of his mighty men is made red, the valiant men are in scarlet; the chariots are fire of steel in the day of his preparation, and the cypress spears are made to quiver.

**2:4** The chariots rage in the streets, they rush to and fro in the broad places; the appearance of them is like torches, they run like the lightnings.

**2:5** He recalls his nobles; they stumble in their march; they make haste to the wall thereof, and the mantelet is prepared.

**2:6** The gates of the rivers are opened, and the palace is dissolved.

---

## Nineveh Plundered (2:7-13)

**2:7** And Huzzab is uncovered, she is carried away, and her handmaids moan as with the voice of doves, tabering upon their breasts.

**2:8** But Nineveh has been from of old like a pool of water; yet they flee away. "Stand, stand!" But none looks back.

**2:9** Take the spoil of silver, take the spoil of gold; for there is no end of the store, rich with all precious vessels.

**2:10** She is empty, and void, and waste; and the heart melts, and the knees smite together, and anguish is in all loins, and the faces of them all gather blackness.

**2:11** Where is the den of the lions, which was the feeding-place of the young lions, where the lion and the lioness walked, and the lion's whelp, and none made them afraid?

**2:12** The lion did tear in pieces enough for his whelps, and strangled for his lionesses, and filled his caves with prey, and his dens with ravin.

**2:13** Behold, I am against you, says YHWH of hosts, and I will burn her chariots in the smoke, and the sword shall devour your young lions; and I will cut off your prey from the earth, and the voice of your messengers shall no more be heard.

---

## Synthesis Notes

**Key Restorations:**

**The Attack (2:1-6):**
**The Key Verse (2:1):**
"'A shatterer has come up against you.'"

*Alah mefitz al-panayikh*—shatterer comes.

"'Guard the rampart, watch the way.'"

*Natzor metzurah tzappeh-derekh*—guard, watch.

"'Make your loins strong, fortify your power mightily!'"

*Chazzeq motnayim ammetz koach me'od*—strengthen.

**The Key Verse (2:2):**
"'YHWH restores the pride of Jacob, as the pride of Israel.'"

*Ki shav YHWH et-ge'on Ya'aqov ki-ge'on Yisra'el*—restores pride.

"'The emptiers have emptied them out.'"

*Ki vaqaqum boqeqim*—emptied.

"'Marred their vine-branches.'"

*U-zemoratam shichchetu*—marred vines.

**The Key Verses (2:3-4):**
"'The shield of his mighty men is made red.'"

*Magen gibboreihu me'addam*—red shields.

"'The valiant men are in scarlet.'"

*Anshei-chayil metulla'im*—scarlet.

"'The chariots are fire of steel in the day of his preparation.'"

*Be-esh peladot ha-rekhev be-yom hakhino*—steel fire.

"'The cypress spears are made to quiver.'"

*Ve-ha-beroshim hor'alu*—spears quiver.

"'The chariots rage in the streets.'"

*Ba-chutzot yithอlelu ha-rekhev*—chariots rage.

"'They rush to and fro in the broad places.'"

*Yishtaqשequn ba-rechovot*—rush.

"'The appearance of them is like torches.'"

*Mar'eihen ka-lappidim*—like torches.

"'They run like the lightnings.'"

*Ka-beraqim yerotzetzu*—like lightning.

**The Key Verses (2:5-6):**
"'He recalls his nobles; they stumble in their march.'"

*Yizkor addirav yikkashelu ba-halikhalam*—stumble.

"'They make haste to the wall thereof.'"

*Yemaharu chomatah*—haste to wall.

"'The mantelet is prepared.'"

*Ve-hukhan ha-sokhekh*—mantelet ready.

"'The gates of the rivers are opened.'"

*Sha'arei ha-neharot niftachu*—river gates open.

"'The palace is dissolved.'"

*Ve-ha-heikhal namog*—palace dissolved.

**Historical Note:**
Nineveh fell when river flooding undermined its walls.

**Nineveh Plundered (2:7-13):**
**The Key Verses (2:7-8):**
"'Huzzab is uncovered, she is carried away.'"

*Ve-Hutzav gulletah ho'aletah*—Huzzab uncovered.

**Huzzab:**
Possibly the queen or a goddess; meaning uncertain.

"'Her handmaids moan as with the voice of doves.'"

*Ve-amhoteiha menahagot ke-qol yonim*—moan like doves.

"'Tabering upon their breasts.'"

*Metofefot al-libbehen*—beating breasts.

"'Nineveh has been from of old like a pool of water.'"

*Ve-Nineveh ki-verekhat mayim hi mi-yemei hi*—like pool.

"'Yet they flee away.'"

*Ve-hemmah nasim*—fleeing.

"''Stand, stand!' But none looks back.'"

*Imdu imdu ve-ein mafneh*—none looks back.

**The Key Verses (2:9-10):**
"'Take the spoil of silver, take the spoil of gold.'"

*Bozzu khesef bozzu zahav*—plunder.

"'There is no end of the store.'"

*Ve-ein qetzeh la-tekhunah*—endless store.

"'Rich with all precious vessels.'"

*Kavod mi-kol keli chemdah*—precious vessels.

"'She is empty, and void, and waste.'"

*Buqah u-mevuqah u-mevullaqah*—empty, void, waste.

**Buqah U-Mevuqah U-Mevullaqah:**
Alliterative: "empty, emptied, emptied out."

"'The heart melts, and the knees smite together.'"

*Ve-lev names u-fiq birkayim*—heart melts.

"'Anguish is in all loins.'"

*Ve-chalchalah be-khol motnayim*—anguish.

"'The faces of them all gather blackness.'"

*U-fenei khullam qibbetzu fa'rur*—faces darken.

**The Key Verses (2:11-13):**
"'Where is the den of the lions?'"

*Ayyeh me'on arayot*—where is den?

"'Which was the feeding-place of the young lions.'"

*U-mir'eh hu la-kefirim*—feeding place.

"'Where the lion and the lioness walked.'"

*Asher halakh aryeh lavי sham*—lion walked.

"'And the lion's whelp, and none made them afraid.'"

*Gur aryeh ve-ein machrid*—none afraid.

"'The lion did tear in pieces enough for his whelps.'"

*Aryeh toref be-dei gorotav*—tore for whelps.

"'Strangled for his lionesses.'"

*U-mechaneq le-levi'otav*—strangled.

"'Filled his caves with prey, and his dens with ravin.'"

*Va-yemalle teref chorav u-me'onotav terefah*—filled dens.

**Lion Metaphor:**
Assyria as a predatory lion, now destroyed.

"''Behold, I am against you,' says YHWH of hosts.'"

*Hineni elayikh ne'um YHWH tzeva'ot*—against you.

"''I will burn her chariots in the smoke.''"

*Ve-hivarti ve-ashan rikhbah*—burn chariots.

"''The sword shall devour your young lions.''"

*U-khefirayikh tokhal cherev*—sword devours.

"''I will cut off your prey from the earth.''"

*Ve-hikhrati me-eretz tarfekh*—cut off prey.

"''The voice of your messengers shall no more be heard.''"

*Ve-lo-yishsha'ma od qol mal'akhayikh*—no messengers.

**Archetypal Layer:** Nahum 2 contains **"A shatterer has come up against you" (2:1)**, **"YHWH restores the pride of Jacob" (2:2)**, **vivid battle imagery: red shields, scarlet warriors, chariots like torches (2:3-4)**, **"the gates of the rivers are opened, and the palace is dissolved" (2:6)**—historical flooding, **plunder: "Take the spoil of silver, take the spoil of gold" (2:9)**, **"She is empty, and void, and waste" (2:10)**, **the lion metaphor: "Where is the den of the lions?" (2:11-12)**, and **"Behold, I am against you, says YHWH of hosts" (2:13)**.

**Ethical Inversion Applied:**
- "'A shatterer has come up against you'"—shatterer
- "'Guard the rampart, watch the way'"—guard
- "'Make your loins strong'"—strengthen
- "'YHWH restores the pride of Jacob'"—restores
- "'The emptiers have emptied them out'"—emptied
- "'The shield of his mighty men is made red'"—red shields
- "'The valiant men are in scarlet'"—scarlet
- "'The chariots are fire of steel'"—steel fire
- "'The chariots rage in the streets'"—rage
- "'They run like the lightnings'"—lightning
- "'He recalls his nobles; they stumble'"—stumble
- "'The gates of the rivers are opened'"—river gates
- "'The palace is dissolved'"—dissolved
- "'Huzzab is uncovered, she is carried away'"—carried away
- "'Her handmaids moan as with the voice of doves'"—moan
- "'Nineveh has been from of old like a pool of water'"—like pool
- "'Yet they flee away'"—flee
- "''Stand, stand!' But none looks back'"—none looks
- "'Take the spoil of silver, take the spoil of gold'"—plunder
- "'There is no end of the store'"—endless
- "'She is empty, and void, and waste'"—empty
- "'The heart melts'"—melts
- "'The faces of them all gather blackness'"—blackness
- "'Where is the den of the lions?'"—where
- "'The lion did tear in pieces enough for his whelps'"—tore
- "'Filled his caves with prey'"—filled
- "''Behold, I am against you''"—against
- "''I will burn her chariots in the smoke''"—burn
- "''The sword shall devour your young lions''"—devour
- "''I will cut off your prey from the earth''"—cut off
- "''The voice of your messengers shall no more be heard''"—no messengers

**Modern Equivalent:** Nahum 2 is vivid battle poetry. The attack on Nineveh features scarlet-clad warriors, lightning-fast chariots, and river gates opening (historically, the Tigris flood undermined Nineveh's walls in 612 BCE). The lion metaphor (2:11-12) mocks Assyria's predatory power—where are your dens now? "Behold, I am against you" (2:13) is YHWH's devastating pronouncement.

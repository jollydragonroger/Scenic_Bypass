# Habakkuk 2: The Righteous Shall Live by Faith

*From the Hebrew: עַל־מִשְׁמַרְתִּי אֶעֱמֹדָה (Al-Mishmarti E'emodah) — Upon My Watch I Will Stand*

---

## Waiting for YHWH's Answer (2:1)

**2:1** I will stand upon my watch, and set me upon the tower, and will look out to see what he will speak with me, and what I shall answer when I am reproved.

---

## YHWH's Second Answer (2:2-5)

**2:2** And YHWH answered me, and said: "Write the vision, and make it plain upon tablets, that he may run that reads it.

**2:3** "For the vision is yet for the appointed time, and it declares of the end, and does not lie; though it tarry, wait for it; because it will surely come, it will not delay.

**2:4** "Behold, his soul is puffed up, it is not upright in him; but the righteous shall live by his faith.

**2:5** "Yea, moreover, wine is a treacherous dealer; the haughty man abides not; he who enlarges his desire as the nether-world, and is as death, and cannot be satisfied, but gathers unto him all nations, and heaps unto him all peoples."

---

## Five Woes Against the Oppressor (2:6-20)

**2:6** Shall not all these take up a parable against him, and a taunting proverb against him, and say: "Woe to him that increases that which is not his! How long? And that loads himself with pledges!"

**2:7** Shall they not rise up suddenly that shall exact interest of you, and awake that shall violently shake you, and you shall be for booties unto them?

**2:8** Because you have spoiled many nations, all the remnant of the peoples shall spoil you; because of men's blood, and for the violence done to the land, to the city and to all that dwell therein.

**2:9** Woe to him that gets an evil gain for his house, that he may set his nest on high, that he may be delivered from the hand of evil!

**2:10** You have devised shame to your house, by cutting off many peoples, and have forfeited your life.

**2:11** For the stone shall cry out of the wall, and the beam out of the timber shall answer it.

**2:12** Woe to him that builds a town with blood, and establishes a city by iniquity!

**2:13** Behold, is it not of YHWH of hosts that the peoples labour only for fire, and the nations weary themselves for vanity?

**2:14** For the earth shall be filled with the knowledge of the glory of YHWH, as the waters cover the sea.

**2:15** Woe unto him that gives his neighbour drink, that adds your venom, and makes him drunken also, that you may look on their nakedness!

**2:16** You are filled with shame instead of glory; drink also, and be as one uncircumcised; the cup of YHWH's right hand shall be turned unto you, and filthiness shall be upon your glory.

**2:17** For the violence done to Lebanon shall cover you, and the destruction of the beasts, which made them afraid; because of men's blood, and for the violence done to the land, to the city and to all that dwell therein.

**2:18** What profits the graven image, that the maker thereof has graven it, even the molten image, and the teacher of lies; that the maker of his work trusts therein, to make dumb idols?

**2:19** Woe unto him that says to the wood: "Awake!" To the dumb stone: "Arise!" Can this teach? Behold, it is overlaid with gold and silver, and there is no breath at all in the midst of it.

**2:20** But YHWH is in his holy temple; let all the earth keep silence before him.

---

## Synthesis Notes

**Key Restorations:**

**Waiting for YHWH's Answer (2:1):**
**The Key Verse (2:1):**
"'I will stand upon my watch.'"

*Al-mishmarti e'emodah*—stand on watch.

"'Set me upon the tower.'"

*Ve-etyatzetzah al-matzor*—on tower.

"'Will look out to see what he will speak with me.'"

*Va-atzappeh lir'ot mah-yedabber-bi*—watch what He says.

"'What I shall answer when I am reproved.'"

*U-mah ashiv al-tokhachti*—answer reproof.

**YHWH's Second Answer (2:2-5):**
**The Key Verses (2:2-3):**
"''Write the vision, and make it plain upon tablets.''"

*Ketov chazon u-va'er al-ha-luchot*—write plainly.

"''That he may run that reads it.''"

*Lema'an yarutz qore vo*—run while reading.

"''The vision is yet for the appointed time.''"

*Ki od chazon la-mo'ed*—appointed time.

"''It declares of the end, and does not lie.''"

*Ve-yafe'ach la-qetz ve-lo yekhazzev*—doesn't lie.

"''Though it tarry, wait for it.''"

*Im-yitmahammah chakkeh-lo*—wait.

"''It will surely come, it will not delay.''"

*Ki-vo yavo lo ye'acher*—will come.

**The Key Verse (2:4):**
"''Behold, his soul is puffed up, it is not upright in him.''"

*Hinneh uppelah lo-yashrah nafsho bo*—puffed up.

"''But the righteous shall live by his faith.''"

*Ve-tzaddiq be-emunato yichyeh*—righteous lives by faith.

**Tzaddiq Be-Emunato Yichyeh:**
"The righteous shall live by his faith"—quoted in Romans 1:17, Galatians 3:11, Hebrews 10:38.

**The Key Verse (2:5):**
"''Wine is a treacherous dealer.''"

*Ve-af ki-ha-yayin boged*—wine treacherous.

"''The haughty man abides not.''"

*Gever yahir ve-lo yinveh*—haughty doesn't abide.

"''He who enlarges his desire as the nether-world.''"

*Asher hirchiv ki-She'ol nafsho*—desire like Sheol.

"''Is as death, and cannot be satisfied.''"

*Ve-hu ka-mavet ve-lo yisba*—unsatisfied.

"''Gathers unto him all nations.''"

*Va-ye'esof elav kol-ha-goyim*—gathers nations.

"''Heaps unto him all peoples.''"

*Va-yiqbotz elav kol-ha-ammim*—heaps peoples.

**Five Woes (2:6-20):**
**First Woe (2:6-8):**
"''Woe to him that increases that which is not his!''"

*Hoy ha-marbeh lo-lo*—woe to increaser.

"''How long?''"

*Ad-matai*—how long?

"''That loads himself with pledges!''"

*U-makhbid alav avtit*—loads pledges.

"''They rise up suddenly that shall exact interest of you.''"

*Ha-lo feta yaqumu noshekheikha*—creditors rise.

"''You shall be for booties unto them.''"

*Ve-hayita li-meshissot lamo*—booty.

"''Because you have spoiled many nations, all the remnant of the peoples shall spoil you.''"

*Ki attah shalolta goyim rabbim yeshalolukha kol-yeter ammim*—spoiled, spoiled.

"''Because of men's blood, and for the violence done to the land.''"

*Mi-demei adam va-chamas-eretz qiryah ve-khol-yoshevei vah*—blood, violence.

**Second Woe (2:9-11):**
"''Woe to him that gets an evil gain for his house.''"

*Hoy botzea betza ra le-veito*—evil gain.

"''That he may set his nest on high.''"

*La-sum ba-marom qinno*—nest on high.

"''That he may be delivered from the hand of evil!''"

*Le-hinnatzvel mi-kaf-ra*—delivered.

"''You have devised shame to your house.''"

*Ya'atzta boshet le-veitekha*—shame.

"''By cutting off many peoples.''"

*Qetzot ammim rabbim*—cutting off.

"''Have forfeited your life.''"

*Ve-chote nafshekha*—forfeit life.

"''The stone shall cry out of the wall.''"

*Ki-even mi-qir tiz'aq*—stone cries.

"''The beam out of the timber shall answer it.''"

*Ve-khafis me-etz ya'anennah*—beam answers.

**Third Woe (2:12-14):**
"''Woe to him that builds a town with blood.''"

*Hoy boneh ir be-damim*—blood.

"''Establishes a city by iniquity!''"

*Ve-khonen qiryah be-avlah*—iniquity.

"''Is it not of YHWH of hosts that the peoples labour only for fire?''"

*Ha-lo hinneh me-et YHWH tzeva'ot ve-yig'u ammim bedei-esh*—labour for fire.

"''The nations weary themselves for vanity?''"

*U-le'ummim bedei-riq yי'afu*—weary for vanity.

"''The earth shall be filled with the knowledge of the glory of YHWH.''"

*Ki-timmale ha-aretz la-da'at et-kevod YHWH*—filled with knowledge.

"''As the waters cover the sea.''"

*Ka-mayim yekhassו al-yam*—waters cover sea.

**Fourth Woe (2:15-17):**
"''Woe unto him that gives his neighbour drink.''"

*Hoy mashqeh re'ehu*—gives drink.

"''That adds your venom, and makes him drunken.''"

*Messafe'ach chamatekha ve-af shakker*—venom, drunken.

"''That you may look on their nakedness!''"

*Lema'an habbit al-me'oreihem*—look on nakedness.

"''You are filled with shame instead of glory.''"

*Sava'ta qalon mi-khavod*—shame, not glory.

"''Drink also, and be as one uncircumcised.''"

*Sheteh gam-attah ve-he'arel*—uncircumcised.

"''The cup of YHWH's right hand shall be turned unto you.''"

*Tissov alekha kos yemin YHWH*—YHWH's cup.

"''Filthiness shall be upon your glory.''"

*Ve-qiqalon al-kevodekha*—filthiness.

"''The violence done to Lebanon shall cover you.''"

*Ki chamas Levanon yekhassekkah*—Lebanon's violence.

"''The destruction of the beasts, which made them afraid.''"

*Ve-shod behemot yechittan*—beasts' destruction.

**Fifth Woe (2:18-20):**
"''What profits the graven image?''"

*Mah-ho'il pesel*—what profit?

"''That the maker thereof has graven it.''"

*Ki fesalo yotzro*—maker graved.

"''Even the molten image, and the teacher of lies.''"

*Massekah u-moreh shaqer*—molten, lies.

"''That the maker of his work trusts therein, to make dumb idols.''"

*Ki vatach yotzer yitzro alav la'asot elilim illemim*—dumb idols.

"''Woe unto him that says to the wood: Awake!''"

*Hoy omer la-etz haqitzah*—awake wood?

"''To the dumb stone: Arise!''"

*Uri le-even dumam*—arise stone?

"''Can this teach?''"

*Hu yoreh*—can teach?

"''Behold, it is overlaid with gold and silver.''"

*Hinneh hu tafus zahav va-khesef*—overlaid.

"''There is no breath at all in the midst of it.''"

*Ve-khol-ruach ein be-qirbo*—no breath.

"''But YHWH is in his holy temple.''"

*Va-YHWH be-heikhal qodsho*—in temple.

"''Let all the earth keep silence before him.''"

*Has mi-panav kol-ha-aretz*—silence.

**Archetypal Layer:** Habakkuk 2 contains **"I will stand upon my watch" (2:1)**, **"Write the vision, and make it plain upon tablets, that he may run that reads it" (2:2)**, **"the vision is yet for the appointed time... though it tarry, wait for it" (2:3)**, **"the righteous shall live by his faith" (2:4)**—quoted in Romans, Galatians, Hebrews, **five woes against the oppressor (2:6-20)**: increasing by plunder (2:6-8), evil gain (2:9-11), building with blood (2:12-14), debauching neighbors (2:15-17), idolatry (2:18-19), **"the earth shall be filled with the knowledge of the glory of YHWH, as the waters cover the sea" (2:14)**, and **"YHWH is in his holy temple; let all the earth keep silence before him" (2:20)**.

**Ethical Inversion Applied:**
- "'I will stand upon my watch'"—watch
- "'Will look out to see what he will speak'"—look
- "''Write the vision, and make it plain upon tablets''"—write
- "''That he may run that reads it''"—run while reading
- "''The vision is yet for the appointed time''"—appointed
- "''Though it tarry, wait for it''"—wait
- "''It will surely come, it will not delay''"—will come
- "''His soul is puffed up, it is not upright''"—puffed up
- "''The righteous shall live by his faith''"—live by faith
- "''Wine is a treacherous dealer''"—treacherous
- "''He who enlarges his desire as the nether-world''"—Sheol desire
- "''Cannot be satisfied''"—unsatisfied
- "''Woe to him that increases that which is not his!''"—woe
- "''Loads himself with pledges!''"—pledges
- "''You have spoiled many nations... shall spoil you''"—spoiled
- "''Because of men's blood''"—blood
- "''Woe to him that gets an evil gain''"—evil gain
- "''Set his nest on high''"—nest high
- "''The stone shall cry out of the wall''"—stone cries
- "''Woe to him that builds a town with blood''"—blood
- "''The earth shall be filled with the knowledge of the glory of YHWH''"—filled
- "''As the waters cover the sea''"—waters cover
- "''Woe unto him that gives his neighbour drink''"—gives drink
- "''The cup of YHWH's right hand shall be turned unto you''"—YHWH's cup
- "''What profits the graven image?''"—no profit
- "''Woe unto him that says to the wood: Awake!''"—woe
- "''There is no breath at all in the midst of it''"—no breath
- "''YHWH is in his holy temple''"—in temple
- "''Let all the earth keep silence before him''"—silence

**Modern Equivalent:** Habakkuk 2:4 is one of Scripture's most influential verses. "The righteous shall live by his faith" is quoted three times in the NT (Romans 1:17, Galatians 3:11, Hebrews 10:38). The five woes condemn Babylon's imperialism but apply universally. "The earth shall be filled with the knowledge of the glory of YHWH" (2:14) is eschatological hope. "YHWH is in his holy temple; let all the earth keep silence" (2:20) answers the theodicy question—God is sovereign.

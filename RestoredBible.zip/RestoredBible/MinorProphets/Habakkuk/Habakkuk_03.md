# Habakkuk 3: The Prophet's Prayer

*From the Hebrew: תְּפִלָּה לַחֲבַקּוּק הַנָּבִיא עַל שִׁגְיֹנוֹת (Tefillah La-Chavaquq Ha-Navi Al Shigionot) — A Prayer of Habakkuk the Prophet upon Shigionoth*

---

## Title (3:1)

**3:1** A prayer of Habakkuk the prophet upon Shigionoth.

---

## Theophany (3:2-15)

**3:2** O YHWH, I have heard the report of you, and am afraid; O YHWH, revive your work in the midst of the years, in the midst of the years make it known; in wrath remember mercy.

**3:3** God comes from Teman, and the Holy One from mount Paran. Selah. His glory covers the heavens, and the earth is full of his praise.

**3:4** And a brightness appears as the light; rays has he at his side; and there is the hiding of his power.

**3:5** Before him goes the pestilence, and fiery bolts go forth at his feet.

**3:6** He stands, and shakes the earth, he beholds, and makes the nations to tremble; and the everlasting mountains are dashed in pieces, the ancient hills do bow; his goings are as of old.

**3:7** I see the tents of Cushan in affliction; the curtains of the land of Midian do tremble.

**3:8** Is YHWH displeased against the rivers? Is your anger against the rivers, or your wrath against the sea, that you ride upon your horses, upon your chariots of victory?

**3:9** Your bow is made quite bare; sworn are the rods of the word. Selah. You cleave the earth with rivers.

**3:10** The mountains see you, and they tremble; the tempest of waters passes by; the deep utters its voice, and lifts up its hands on high.

**3:11** The sun and moon stand still in their habitation; at the light of your arrows as they go, at the shining of your glittering spear.

**3:12** You march through the earth in indignation, you thresh the nations in anger.

**3:13** You go forth for the salvation of your people, for the salvation of your anointed; you wound the head out of the house of the wicked, uncovering the foundation even unto the neck. Selah.

**3:14** You pierce with his own staves the head of his rulers, that come as a whirlwind to scatter me; whose rejoicing is as to devour the poor secretly.

**3:15** You tread the sea with your horses, the foaming of mighty waters.

---

## Faith Despite Circumstances (3:16-19)

**3:16** I heard, and my inward parts trembled, my lips quivered at the voice; rottenness enters into my bones, and I tremble where I stand; that I should wait for the day of trouble, when he comes up against the people that he invades.

**3:17** For though the fig-tree shall not blossom, neither shall fruit be in the vines; the labour of the olive shall fail, and the fields shall yield no food; the flock shall be cut off from the fold, and there shall be no herd in the stalls;

**3:18** Yet I will rejoice in YHWH, I will exult in the God of my salvation.

**3:19** God, the Lord, is my strength, and he makes my feet like hinds' feet, and he makes me to walk upon my high places. For the chief musician, on my stringed instruments.

---

## Synthesis Notes

**Key Restorations:**

**Title (3:1):**
**The Key Verse (3:1):**
"A prayer of Habakkuk the prophet upon Shigionoth."

*Tefillah la-Chavaquq ha-navi al shigionot*—prayer.

**Shigionoth:**
A musical term, possibly indicating a passionate, wandering style.

**Theophany (3:2-15):**
**The Key Verse (3:2):**
"'O YHWH, I have heard the report of you, and am afraid.'"

*YHWH shama'ti shim'akha yareti*—heard, afraid.

"'Revive your work in the midst of the years.'"

*YHWH po'olekha be-qerev shanim chayyeihu*—revive.

"'In the midst of the years make it known.'"

*Be-qerev shanim todi'a*—make known.

"'In wrath remember mercy.'"

*Be-rogez rachem tizkor*—in wrath, remember mercy.

**The Key Verses (3:3-5):**
"'God comes from Teman.'"

*Eloah mi-Teiman yavo*—from Teman.

"'The Holy One from mount Paran.'"

*Ve-Qadosh me-har Paran*—from Paran.

**Selah.**

"'His glory covers the heavens.'"

*Kissah shamayim hodo*—glory covers heavens.

"'The earth is full of his praise.'"

*U-tehillato male'ah ha-aretz*—full of praise.

"'A brightness appears as the light.'"

*Ve-nogah ka-or tihyeh*—brightness.

"'Rays has he at his side.'"

*Qarnayim mi-yado lo*—rays from hand.

"'There is the hiding of his power.'"

*Ve-sham chevyon uzzo*—hidden power.

"'Before him goes the pestilence.'"

*Lefanav yelekh daver*—pestilence before.

"'Fiery bolts go forth at his feet.'"

*Ve-yetze reshef le-raglav*—fiery bolts.

**The Key Verses (3:6-7):**
"'He stands, and shakes the earth.'"

*Amad va-yemodedארetz*—shakes earth.

"'He beholds, and makes the nations to tremble.'"

*Ra'ah va-yatter goyim*—nations tremble.

"'The everlasting mountains are dashed in pieces.'"

*Va-yitpotzzetzu harerei-ad*—mountains dashed.

"'The ancient hills do bow.'"

*Shachű giv'ot olam*—hills bow.

"'His goings are as of old.'"

*Halikhot olam lo*—ancient ways.

"'I see the tents of Cushan in affliction.'"

*Tachat aven ra'iti ohalei Khushan*—Cushan afflicted.

"'The curtains of the land of Midian do tremble.'"

*Yirgazun yeri'ot eretz Midyan*—Midian trembles.

**The Key Verses (3:8-11):**
"'Is YHWH displeased against the rivers?'"

*Ha-vi-neharim charah YHWH*—displeased at rivers?

"'Is your anger against the rivers, or your wrath against the sea?'"

*Im-ba-neharim appekha im-ba-yam evratekha*—anger at sea?

"'You ride upon your horses, upon your chariots of victory.'"

*Ki tirkav al-susekha markevotekha yeshu'ah*—victory chariots.

"'Your bow is made quite bare.'"

*Eryah te'or qashtekha*—bow bare.

"'Sworn are the rods of the word.'"

*Shevu'ot mattot omer*—sworn rods.

**Selah.**

"'You cleave the earth with rivers.'"

*Neharot tevaqqia-aretz*—cleave earth.

"'The mountains see you, and they tremble.'"

*Ra'ukha yachilu harim*—mountains tremble.

"'The tempest of waters passes by.'"

*Zerem mayim avar*—waters pass.

"'The deep utters its voice.'"

*Natan tehom qolo*—deep utters voice.

"'Lifts up its hands on high.'"

*Rom yadeihu nasa*—hands lifted.

"'The sun and moon stand still in their habitation.'"

*Shemesh yare'ach amad zevulah*—sun, moon still.

"'At the light of your arrows as they go.'"

*Le-or chitztzekha yehallekhו*—arrows' light.

"'At the shining of your glittering spear.'"

*Le-nogah beraq chaniteka*—spear's shining.

**The Key Verses (3:12-15):**
"'You march through the earth in indignation.'"

*Be-za'am titzad-aretz*—march in wrath.

"'You thresh the nations in anger.'"

*Be-af tadush goyim*—thresh nations.

"'You go forth for the salvation of your people.'"

*Yatzata le-yesha ammekha*—salvation of people.

"'For the salvation of your anointed.'"

*Le-yesha et-meshichekha*—salvation of anointed.

"'You wound the head out of the house of the wicked.'"

*Machatzta rosh mi-beit rasha*—wound head.

"'Uncovering the foundation even unto the neck.'"

*Arot yesod ad-tzavvar*—uncover foundation.

**Selah.**

"'You pierce with his own staves the head of his rulers.'"

*Naqavta ve-mattav rosh perazav*—pierce with staves.

"'That come as a whirlwind to scatter me.'"

*Yis'aru la-hafitzeni*—scatter me.

"'Whose rejoicing is as to devour the poor secretly.'"

*Alitzutam ke-mo le'ekhol ani ba-misstar*—devour poor.

"'You tread the sea with your horses.'"

*Darakhta va-yam susekha*—tread sea.

"'The foaming of mighty waters.'"

*Chomer mayim rabbim*—foaming waters.

**Faith Despite Circumstances (3:16-19):**
**The Key Verse (3:16):**
"'I heard, and my inward parts trembled.'"

*Shama'ti va-tirgaz bitni*—heard, trembled.

"'My lips quivered at the voice.'"

*Le-qol tzalelו sefatai*—lips quivered.

"'Rottenness enters into my bones.'"

*Yavo raqav ba-atzamai*—rottenness in bones.

"'I tremble where I stand.'"

*Ve-tachtai ergaz*—tremble.

"'That I should wait for the day of trouble.'"

*Asher anuach le-yom tzarah*—wait for trouble.

"'When he comes up against the people that he invades.'"

*La'alot le-am yegudennu*—invader comes.

**The Key Verses (3:17-19):**
"'Though the fig-tree shall not blossom.'"

*Ki te'enah lo-tifרach*—fig tree.

"'Neither shall fruit be in the vines.'"

*Ve-ein yevul ba-gefanim*—no grapes.

"'The labour of the olive shall fail.'"

*Kichesh ma'aseh-zayit*—olive fails.

"'The fields shall yield no food.'"

*U-shedmot lo-asah okhel*—no food.

"'The flock shall be cut off from the fold.'"

*Gazar mi-mikhlas tzon*—no flock.

"'There shall be no herd in the stalls.'"

*Ve-ein baqar ba-refatim*—no herd.

"'Yet I will rejoice in YHWH.'"

*Va-ani be-YHWH e'elozah*—rejoice in YHWH.

"'I will exult in the God of my salvation.'"

*Agilah be-Elohei yish'i*—exult.

"'God, the Lord, is my strength.'"

*YHWH Adonai cheili*—my strength.

"'He makes my feet like hinds' feet.'"

*Va-yasem raglai ka-ayyalot*—hinds' feet.

"'He makes me to walk upon my high places.'"

*Ve-al bamotai yadrkheni*—walk on heights.

"'For the chief musician, on my stringed instruments.'"

*La-menatze'ach bi-neginotai*—musical notation.

**Archetypal Layer:** Habakkuk 3 is a **theophanic prayer**, containing **"O YHWH, I have heard the report of you, and am afraid; revive your work in the midst of the years; in wrath remember mercy" (3:2)**, **"God comes from Teman, and the Holy One from mount Paran" (3:3)**, **cosmic imagery: glory covering heavens (3:3), pestilence and fiery bolts (3:5), mountains dashed (3:6), sun and moon standing still (3:11)**, **"You go forth for the salvation of your people, for the salvation of your anointed" (3:13)**, and the **famous confession of faith (3:17-19)**: "Though the fig-tree shall not blossom... Yet I will rejoice in YHWH."

**Ethical Inversion Applied:**
- "A prayer of Habakkuk the prophet upon Shigionoth"—prayer
- "'O YHWH, I have heard the report of you, and am afraid'"—heard, afraid
- "'Revive your work in the midst of the years'"—revive
- "'In wrath remember mercy'"—mercy
- "'God comes from Teman'"—from Teman
- "'The Holy One from mount Paran'"—Paran
- "'His glory covers the heavens'"—glory
- "'The earth is full of his praise'"—praise
- "'A brightness appears as the light'"—brightness
- "'Rays has he at his side'"—rays
- "'Before him goes the pestilence'"—pestilence
- "'He stands, and shakes the earth'"—shakes earth
- "'The everlasting mountains are dashed in pieces'"—mountains
- "'The ancient hills do bow'"—hills bow
- "'I see the tents of Cushan in affliction'"—Cushan
- "'Is YHWH displeased against the rivers?'"—rivers
- "'You ride upon your horses, upon your chariots of victory'"—victory
- "'Your bow is made quite bare'"—bow
- "'The mountains see you, and they tremble'"—tremble
- "'The sun and moon stand still'"—sun, moon still
- "'You march through the earth in indignation'"—march
- "'You thresh the nations in anger'"—thresh
- "'You go forth for the salvation of your people'"—salvation
- "'For the salvation of your anointed'"—anointed
- "'You wound the head out of the house of the wicked'"—wound
- "'You tread the sea with your horses'"—tread sea
- "'I heard, and my inward parts trembled'"—trembled
- "'Though the fig-tree shall not blossom'"—no figs
- "'Neither shall fruit be in the vines'"—no grapes
- "'The labour of the olive shall fail'"—no olives
- "'The fields shall yield no food'"—no food
- "'The flock shall be cut off from the fold'"—no flock
- "'There shall be no herd in the stalls'"—no herd
- "'Yet I will rejoice in YHWH'"—rejoice
- "'I will exult in the God of my salvation'"—exult
- "'God, the Lord, is my strength'"—strength
- "'He makes my feet like hinds' feet'"—hinds' feet
- "'He makes me to walk upon my high places'"—high places

**Modern Equivalent:** Habakkuk 3 is a theophanic psalm celebrating YHWH's warrior coming. The imagery echoes Sinai and the conquest. But the book's climax (3:17-19) is profound: even when everything fails—no figs, grapes, olives, food, flocks, herds—"yet I will rejoice in YHWH." This is faith without evidence, trust without circumstantial support. "God, the Lord, is my strength" concludes the theodicy dialogue—not with answers but with trust.

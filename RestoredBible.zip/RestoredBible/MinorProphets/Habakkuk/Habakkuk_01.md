# Habakkuk 1: The Prophet's Complaint and YHWH's Answer

*From the Hebrew: הַמַּשָּׂא אֲשֶׁר חָזָה חֲבַקּוּק הַנָּבִיא (Ha-Massa Asher Chazah Chavaquq Ha-Navi) — The Burden Which Habakkuk the Prophet Saw*

---

## Title (1:1)

**1:1** The burden which Habakkuk the prophet saw.

---

## First Complaint: Why Does Evil Go Unpunished? (1:2-4)

**1:2** How long, O YHWH, shall I cry, and you will not hear? I cry out unto you of violence, and you will not save.

**1:3** Why do you show me iniquity, and behold mischief? And why are spoiling and violence before me? So that there is strife, and contention arises.

**1:4** Therefore the law is slacked, and justice does never go forth; for the wicked does encompass the righteous; therefore justice goes forth perverted.

---

## YHWH's First Answer: The Chaldeans (1:5-11)

**1:5** Look among the nations, and behold, and wonder marvellously; for, behold, a work shall be wrought in your days, which you will not believe though it be told you.

**1:6** For, lo, I raise up the Chaldeans, that bitter and hasty nation, that march through the breadth of the earth, to possess dwelling-places that are not theirs.

**1:7** They are terrible and dreadful; their law and their majesty proceed from themselves.

**1:8** Their horses also are swifter than leopards, and are more fierce than the wolves of the desert; and their horsemen spread themselves; yea, their horsemen come from far, they fly as a vulture that hastes to devour.

**1:9** They come all of them for violence; their faces are set eagerly as the east wind; and they gather captives as the sand.

**1:10** And they scoff at kings, and princes are a derision unto them; they deride every stronghold, for they heap up earth, and take it.

**1:11** Then their spirit sweeps on, and they pass, and are guilty: even they whose might is their god.

---

## Second Complaint: Why Use the Wicked? (1:12-17)

**1:12** Are you not from everlasting, O YHWH my God, my Holy One? We shall not die. O YHWH, you have ordained them for judgment, and you, O Rock, have established them for correction.

**1:13** You that are of eyes too pure to behold evil, and that can not look on mischief, why do you look upon them that deal treacherously, and hold your peace when the wicked swallows up the man that is more righteous than he;

**1:14** And make men as the fishes of the sea, as the creeping things, that have no ruler over them?

**1:15** They take up all of them with the angle, they catch them in their net, and gather them in their drag; therefore they rejoice and exult.

**1:16** Therefore they sacrifice unto their net, and offer unto their drag; because by them their portion is fat, and their food plenteous.

**1:17** Shall they therefore empty their net, and not spare to slay the nations continually?

---

## Synthesis Notes

**Key Restorations:**

**Title (1:1):**
**The Key Verse (1:1):**
"The burden which Habakkuk the prophet saw."

*Ha-massa asher chazah Chavaquq ha-navi*—Habakkuk's burden.

**Chavaquq:**
Possibly "embrace" or a plant name.

**First Complaint (1:2-4):**
**The Key Verses (1:2-4):**
"'How long, O YHWH, shall I cry, and you will not hear?'"

*Ad-anah YHWH shivva'ti ve-lo tishma*—how long?

"'I cry out unto you of violence, and you will not save.'"

*Ez'aq elekha chamas ve-lo toshi'a*—violence, no salvation.

"'Why do you show me iniquity, and behold mischief?'"

*Lammah tar'eni aven ve-amal tabbית*—why show evil?

"'Why are spoiling and violence before me?'"

*Ve-shod ve-chamas le-negdi*—spoiling, violence.

"'There is strife, and contention arises.'"

*Va-yehi riv u-madon yissa*—strife, contention.

"'The law is slacked.'"

*Al-ken tafug torah*—law slacked.

"'Justice does never go forth.'"

*Ve-lo-yetze la-netzach mishpat*—no justice.

"'The wicked does encompass the righteous.'"

*Ki rasha mattir et-ha-tzaddiq*—wicked surrounds righteous.

"'Justice goes forth perverted.'"

*Al-ken yetze mishpat me'uqqal*—perverted justice.

**YHWH's First Answer (1:5-11):**
**The Key Verses (1:5-7):**
"'Look among the nations, and behold, and wonder marvellously.'"

*Re'u va-goyim ve-habbitu ve-hittammehu temahu*—look, wonder.

"'A work shall be wrought in your days, which you will not believe.'"

*Ki-fo'al po'el bi-yemeikhem lo ta'aminu ki yesuppar*—unbelievable.

"'I raise up the Chaldeans.'"

*Ki-hineni meqim et-ha-Kasdim*—raising Chaldeans.

"'That bitter and hasty nation.'"

*Ha-goy ha-mar ve-ha-nimhar*—bitter, hasty.

"'That march through the breadth of the earth.'"

*Ha-holekh le-merchavei-aretz*—march through earth.

"'To possess dwelling-places that are not theirs.'"

*La-reshet mishkanot lo-lo*—possess others'.

"'They are terrible and dreadful.'"

*Ayom ve-nora hu*—terrible, dreadful.

"'Their law and their majesty proceed from themselves.'"

*Mimmennו mishpato u-se'eto yetze*—law from themselves.

**The Key Verses (1:8-11):**
"'Their horses also are swifter than leopards.'"

*Ve-qallו mi-nemerim susav*—swifter than leopards.

"'More fierce than the wolves of the desert.'"

*Ve-chaddו mi-ze'evei erev*—fiercer than wolves.

"'Their horsemen spread themselves.'"

*U-fashu parashav*—spread.

"'Their horsemen come from far.'"

*U-farashav me-rachוq yavo'u*—from far.

"'They fly as a vulture that hastes to devour.'"

*Ya'ufu ke-nesher chash le'ekhol*—like vulture.

"'They come all of them for violence.'"

*Kullo le-chamas yavo*—for violence.

"'Their faces are set eagerly as the east wind.'"

*Megammat peneihem qadimah*—faces like east wind.

"'They gather captives as the sand.'"

*Va-ye'esof ka-chol shevi*—captives like sand.

"'They scoff at kings.'"

*Ve-hu ba-melakhim yitqallas*—scoff at kings.

"'Princes are a derision unto them.'"

*U-rozenim miscahaq lo*—princes derided.

"'They deride every stronghold.'"

*Hu le-khol-mivtzar yischaq*—deride strongholds.

"'They heap up earth, and take it.'"

*Va-yitzbor afar va-yilkedah*—siege ramps.

"'Then their spirit sweeps on, and they pass, and are guilty.'"

*Az chalaf ruach va-ya'avor ve-ashem*—guilty.

"'Even they whose might is their god.'"

*Zu kocho le-Eloho*—might is god.

**Second Complaint (1:12-17):**
**The Key Verses (1:12-14):**
"'Are you not from everlasting, O YHWH my God, my Holy One?'"

*Ha-lo attah mi-qedem YHWH Elohai qedoshi*—everlasting.

"'We shall not die.'"

*Lo namut*—won't die.

"'You have ordained them for judgment.'"

*YHWH le-mishpat samto*—ordained for judgment.

"'You, O Rock, have established them for correction.'"

*Ve-tzur le-hokhiach yesadto*—for correction.

"'You that are of eyes too pure to behold evil.'"

*Tehor einayim me-re'ot ra*—pure eyes.

"'Can not look on mischief.'"

*Ve-habbit el-amal lo tukhal*—can't look on mischief.

"'Why do you look upon them that deal treacherously?'"

*Lammah tabbית bogedim*—why look on treacherous?

"'Hold your peace when the wicked swallows up the man that is more righteous than he.'"

*Tacharish be-valla rasha tzaddiq mimmennו*—silent when wicked swallows.

"'Make men as the fishes of the sea.'"

*Va-ta'aseh adam ki-degei ha-yam*—men like fish.

"'As the creeping things, that have no ruler over them.'"

*Ke-remes lo-moshel bo*—no ruler.

**The Key Verses (1:15-17):**
"'They take up all of them with the angle.'"

*Kullo ba-chakkah he'alah*—with hook.

"'They catch them in their net.'"

*Yegorehu be-cherمo*—catch in net.

"'Gather them in their drag.'"

*Ve-ya'asfehu be-mikhmaרto*—gather in drag.

"'Therefore they rejoice and exult.'"

*Al-ken yismach ve-yagil*—rejoice.

"'They sacrifice unto their net.'"

*Al-ken yezabbach le-cherמo*—sacrifice to net.

"'Offer unto their drag.'"

*Vi-yaqtter le-mikhmarto*—offer to drag.

"'Because by them their portion is fat.'"

*Ki vahem shamen chelqo*—fat portion.

"'Their food plenteous.'"

*U-ma'akhalo beri'ah*—plenteous food.

"'Shall they therefore empty their net?'"

*Ha-al ken yariq cherמo*—empty net?

"'Not spare to slay the nations continually?'"

*Ve-tamid laharog goyim lo yachmol*—slay continually?

**Archetypal Layer:** Habakkuk 1 contains **the prophet's first complaint: "How long, O YHWH, shall I cry, and you will not hear?" (1:2)**, **"the law is slacked, and justice does never go forth" (1:4)**, **YHWH's shocking answer: "I raise up the Chaldeans" (1:6)**, **vivid description of Babylon: "bitter and hasty nation" (1:6), horses swifter than leopards (1:8), "they come all of them for violence" (1:9), "their might is their god" (1:11)**, **the prophet's second complaint: "You that are of eyes too pure to behold evil... why do you look upon them that deal treacherously?" (1:13)**, and **"Why does the wicked swallow up the man that is more righteous than he?" (1:13)**.

**Ethical Inversion Applied:**
- "The burden which Habakkuk the prophet saw"—burden
- "'How long, O YHWH, shall I cry, and you will not hear?'"—how long
- "'I cry out unto you of violence'"—violence
- "'Why do you show me iniquity?'"—why
- "'Spoiling and violence before me'"—violence
- "'There is strife, and contention arises'"—strife
- "'The law is slacked'"—law slacked
- "'Justice does never go forth'"—no justice
- "'The wicked does encompass the righteous'"—wicked surrounds
- "'Justice goes forth perverted'"—perverted
- "'Look among the nations, and behold, and wonder'"—look
- "'A work shall be wrought... which you will not believe'"—unbelievable
- "'I raise up the Chaldeans'"—Chaldeans
- "'That bitter and hasty nation'"—bitter
- "'They are terrible and dreadful'"—terrible
- "'Their law and their majesty proceed from themselves'"—self-law
- "'Their horses... are swifter than leopards'"—swift
- "'More fierce than the wolves'"—fierce
- "'They fly as a vulture'"—vulture
- "'They come all of them for violence'"—for violence
- "'They gather captives as the sand'"—captives
- "'They scoff at kings'"—scoff
- "'Their might is their god'"—might is god
- "'Are you not from everlasting, O YHWH?'"—everlasting
- "'We shall not die'"—won't die
- "'You have ordained them for judgment'"—ordained
- "'You that are of eyes too pure to behold evil'"—pure eyes
- "'Why do you look upon them that deal treacherously?'"—why
- "'When the wicked swallows up the man that is more righteous'"—swallows
- "'Make men as the fishes of the sea'"—like fish
- "'They take up all of them with the angle'"—hook
- "'They sacrifice unto their net'"—sacrifice to net
- "'Shall they... not spare to slay the nations continually?'"—slay continually

**Modern Equivalent:** Habakkuk 1 is a dialogue with God about theodicy. The prophet complains about injustice (1:2-4). YHWH's answer is shocking: He's raising Babylon to punish Judah (1:5-11). This leads to a deeper complaint: How can a holy God use wicked Babylon against less wicked Judah (1:12-17)? The question remains open for chapter 2.

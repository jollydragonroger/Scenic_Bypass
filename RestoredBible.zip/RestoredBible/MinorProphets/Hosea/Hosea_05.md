# Hosea 5: Judgment on Israel and Judah

*From the Hebrew: שִׁמְעוּ־זֹאת הַכֹּהֲנִים (Shim'u-Zot Ha-Kohanim) — Hear This, O Priests*

---

## Warning to Leaders (5:1-7)

**5:1** Hear this, O priests, and attend, O house of Israel, and give ear, O house of the king, for unto you pertains the judgment; for you have been a snare at Mizpah, and a net spread upon Tabor.

**5:2** And they that fall away are gone deep in making slaughter; and I am rejected of them all.

**5:3** I know Ephraim, and Israel is not hid from me; for now, O Ephraim, you have committed harlotry, Israel is defiled.

**5:4** Their doings will not suffer them to return unto their God; for the spirit of harlotry is within them, and they know not YHWH.

**5:5** And the pride of Israel does testify to his face; and Israel and Ephraim shall stumble in their iniquity, Judah also shall stumble with them.

**5:6** With their flocks and with their herds they shall go to seek YHWH; but they shall not find him; he has withdrawn himself from them.

**5:7** They have dealt treacherously against YHWH, for they have begotten strange children; now shall the new moon devour them with their portions.

---

## The Coming Judgment (5:8-15)

**5:8** Blow the horn in Gibeah, and the trumpet in Ramah; sound an alarm at Beth-aven: "Behind you, O Benjamin!"

**5:9** Ephraim shall become a desolation in the day of rebuke; among the tribes of Israel do I make known that which shall surely be.

**5:10** The princes of Judah are like them that remove the landmark; I will pour out my wrath upon them like water.

**5:11** Ephraim is oppressed, he is crushed in judgment; because he was content to walk after vanity.

**5:12** Therefore am I unto Ephraim as a moth, and to the house of Judah as rottenness.

**5:13** And when Ephraim saw his sickness, and Judah his wound, Ephraim went to Assyria, and sent to king Contentious; but he is not able to heal you, neither shall he cure you of your wound.

**5:14** For I will be unto Ephraim as a lion, and as a young lion to the house of Judah; I, even I, will tear and go away, I will carry off, and there shall be none to deliver.

**5:15** I will go and return to my place, till they acknowledge their guilt, and seek my face; in their trouble they will seek me earnestly.

---

## Synthesis Notes

**Key Restorations:**

**Warning to Leaders (5:1-7):**
**The Key Verse (5:1):**
"'Hear this, O priests, and attend, O house of Israel.'"

*Shim'u-zot ha-kohanim ve-haqshivu beit Yisra'el*—hear, priests.

"'Give ear, O house of the king.'"

*U-veit ha-melekh ha'azinu*—house of king.

"'Unto you pertains the judgment.'"

*Ki lakhem ha-mishpat*—judgment on you.

"'You have been a snare at Mizpah.'"

*Ki-fach heyitem le-Mitzpah*—snare at Mizpah.

"'A net spread upon Tabor.'"

*Ve-reshet peruسah al-Tavor*—net on Tabor.

**Mizpah and Tabor:**
Sites of apostasy or ambush.

**The Key Verses (5:3-4):**
"'I know Ephraim, and Israel is not hid from me.'"

*Ani yada'ti Efrayim ve-Yisra'el lo-nikhchad mimmenni*—YHWH knows.

"'O Ephraim, you have committed harlotry, Israel is defiled.'"

*Ki attah zanita Efrayim nitme Yisra'el*—harlotry, defiled.

"'Their doings will not suffer them to return unto their God.'"

*Lo yittenu ma'aleleihem lashuv el-Eloheihem*—can't return.

"'The spirit of harlotry is within them.'"

*Ki ruach zenunim be-qirbam*—spirit of harlotry.

"'They know not YHWH.'"

*Ve-et-YHWH lo yada'u*—don't know YHWH.

**The Key Verses (5:5-7):**
"'The pride of Israel does testify to his face.'"

*Ve-anah ge'on-Yisra'el be-fanav*—pride testifies.

"'Israel and Ephraim shall stumble in their iniquity.'"

*Ve-khashel Yisra'el ve-Efrayim ba-avonam*—stumble.

"'Judah also shall stumble with them.'"

*Kashal gam-Yehudah immam*—Judah too.

"'With their flocks and with their herds they shall go to seek YHWH.'"

*Be-tzonam u-vi-vqaram yelkhu le-vaqqesh et-YHWH*—seek with sacrifices.

"'But they shall not find him; he has withdrawn himself from them.'"

*Ve-lo yimtza'u chalatz mehem*—not find, withdrawn.

"'They have dealt treacherously against YHWH.'"

*Ba-YHWH bagadu*—treachery.

"'They have begotten strange children.'"

*Ki-vanim zarim yaladu*—strange children.

"'Now shall the new moon devour them with their portions.'"

*Attah yokhelem chodesh et-chelqeihem*—new moon devours.

**Coming Judgment (5:8-15):**
**The Key Verses (5:8-9):**
"'Blow the horn in Gibeah, and the trumpet in Ramah.'"

*Tiq'u shofar ba-Giv'ah chatzotzerah ba-Ramah*—alarm.

"'Sound an alarm at Beth-aven.'"

*Hari'u Beit-Aven*—Beth-aven alarm.

"''Behind you, O Benjamin!''"

*Acharekha Binyamin*—invasion warning.

"'Ephraim shall become a desolation in the day of rebuke.'"

*Efrayim le-shammah tihyeh be-yom tokhechah*—desolation.

"'Among the tribes of Israel do I make known that which shall surely be.'"

*Be-shivtei Yisra'el hoda'ti ne'emanah*—certain.

**The Key Verses (5:10-12):**
"'The princes of Judah are like them that remove the landmark.'"

*Hayu sarei Yehudah ke-massigei gevul*—remove landmark.

"'I will pour out my wrath upon them like water.'"

*Ashpokh kalayim evrati*—pour wrath.

"'Ephraim is oppressed, he is crushed in judgment.'"

*Ashuq Efrayim retzutz mishpat*—oppressed.

"'Because he was content to walk after vanity.'"

*Ki ho'il halakh acharei-tzav*—walked after vanity.

"'I am unto Ephraim as a moth.'"

*Va-ani kha-ash le-Efrayim*—like moth.

"'To the house of Judah as rottenness.'"

*Ve-kha-raqav le-veit Yehudah*—like rot.

**The Key Verse (5:13):**
"'When Ephraim saw his sickness, and Judah his wound.'"

*Va-yar Efrayim et-cholyo vi-Yhudah et-mezoro*—saw sickness.

"'Ephraim went to Assyria, and sent to king Contentious.'"

*Va-yelekh Efrayim el-Ashur va-yishlach el-melekh Yarev*—to Assyria.

**Melekh Yarev:**
"King Contentious" or "great king"—the Assyrian king.

"'He is not able to heal you, neither shall he cure you of your wound.'"

*Ve-hu lo yukhal lirpo lakhem ve-lo-yigheh mikkem mazor*—can't heal.

**The Key Verses (5:14-15):**
"'I will be unto Ephraim as a lion.'"

*Ki anokhi kha-shachal le-Efrayim*—like lion.

"'As a young lion to the house of Judah.'"

*Ve-kha-kefir le-veit Yehudah*—young lion.

"'I, even I, will tear and go away.'"

*Ani ani etrof ve-elekh*—tear and go.

"'I will carry off, and there shall be none to deliver.'"

*Essa ve-ein matzil*—none to deliver.

"'I will go and return to my place.'"

*Elekh ashuvah el-meqomi*—return to place.

"'Till they acknowledge their guilt.'"

*Ad asher-ye'shemu*—acknowledge guilt.

"'And seek my face.'"

*U-viqqeshu fanai*—seek face.

"'In their trouble they will seek me earnestly.'"

*Ba-tzar lahem yeshachrununni*—seek in trouble.

**Archetypal Layer:** Hosea 5 pronounces **judgment on leaders**, containing **"unto you pertains the judgment" (5:1)**, **"you have been a snare at Mizpah" (5:1)**, **"the spirit of harlotry is within them, and they know not YHWH" (5:4)**, **"the pride of Israel does testify to his face" (5:5)**, **"with their flocks and with their herds they shall go to seek YHWH; but they shall not find him" (5:6)**, **invasion warning: "Blow the horn in Gibeah" (5:8)**, **"Ephraim went to Assyria... but he is not able to heal you" (5:13)**, **"I will be unto Ephraim as a lion" (5:14)**, and **"I will go and return to my place, till they acknowledge their guilt" (5:15)**.

**Ethical Inversion Applied:**
- "'Hear this, O priests'"—addressed to priests
- "'Give ear, O house of the king'"—addressed to royalty
- "'Unto you pertains the judgment'"—leaders judged
- "'You have been a snare at Mizpah'"—trap
- "'A net spread upon Tabor'"—trap
- "'I know Ephraim'"—YHWH knows
- "'You have committed harlotry, Israel is defiled'"—defiled
- "'Their doings will not suffer them to return'"—can't return
- "'The spirit of harlotry is within them'"—spirit of harlotry
- "'They know not YHWH'"—don't know YHWH
- "'The pride of Israel does testify to his face'"—pride condemns
- "'Israel and Ephraim shall stumble'"—stumble
- "'Judah also shall stumble with them'"—Judah too
- "'With their flocks and with their herds they shall go to seek YHWH'"—seek with sacrifice
- "'They shall not find him'"—not find
- "'He has withdrawn himself from them'"—withdrawn
- "'They have dealt treacherously'"—treachery
- "'They have begotten strange children'"—strange children
- "'Blow the horn in Gibeah'"—alarm
- "'Sound an alarm at Beth-aven'"—alarm
- "''Behind you, O Benjamin!''"—invasion
- "'Ephraim shall become a desolation'"—desolation
- "'The princes of Judah are like them that remove the landmark'"—remove landmark
- "'I will pour out my wrath upon them like water'"—pour wrath
- "'Ephraim is oppressed, he is crushed'"—crushed
- "'He was content to walk after vanity'"—after vanity
- "'I am unto Ephraim as a moth'"—moth
- "'To the house of Judah as rottenness'"—rot
- "'Ephraim saw his sickness, and Judah his wound'"—saw sickness
- "'Ephraim went to Assyria'"—sought Assyria
- "'He is not able to heal you'"—can't heal
- "'I will be unto Ephraim as a lion'"—lion
- "'I, even I, will tear and go away'"—tear
- "'I will carry off, and there shall be none to deliver'"—none deliver
- "'I will go and return to my place'"—withdraw
- "'Till they acknowledge their guilt'"—acknowledge guilt
- "'And seek my face'"—seek face
- "'In their trouble they will seek me earnestly'"—seek in trouble

**Modern Equivalent:** Hosea 5 indicts leaders—priests, royalty, and people. The "spirit of harlotry" prevents return to YHWH. Seeking God with sacrifices while hearts are far fails—"they shall not find him" (5:6). Ephraim's appeal to Assyria (5:13) shows political rather than spiritual solutions fail. "I will go and return to my place" (5:15) depicts divine withdrawal until repentance comes.

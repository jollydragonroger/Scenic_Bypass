# Hosea 9: No Joy for Israel

*From the Hebrew: אַל־תִּשְׂמַח יִשְׂרָאֵל (Al-Tismach Yisra'el) — Rejoice Not, O Israel*

---

## Joy Turned to Mourning (9:1-9)

**9:1** Rejoice not, O Israel, unto exultation, like the peoples, for you have gone astray from your God; you have loved a harlot's hire upon every corn-floor.

**9:2** The threshing-floor and the winepress shall not feed them, and the new wine shall fail her.

**9:3** They shall not dwell in YHWH's land; but Ephraim shall return to Egypt, and they shall eat unclean food in Assyria.

**9:4** They shall not pour out wine-offerings to YHWH, neither shall their sacrifices be pleasing unto him; their bread shall be unto them as the bread of mourners, all that eat thereof shall be polluted; for their bread shall be for their appetite, it shall not come into the house of YHWH.

**9:5** What will you do in the day of the appointed season, and in the day of the feast of YHWH?

**9:6** For, lo, they are gone away from destruction, yet Egypt shall gather them up, Memphis shall bury them; their precious things of silver, nettles shall possess them, thorns shall be in their tents.

**9:7** The days of visitation are come, the days of recompense are come, Israel shall know it. The prophet is a fool, the man of the spirit is mad! For the abundance of your iniquity, the enmity is great.

**9:8** Ephraim is a watchman with my God; as for the prophet, a fowler's snare is in all his ways, and enmity in the house of his God.

**9:9** They have deeply corrupted themselves, as in the days of Gibeah; he will remember their iniquity, he will punish their sins.

---

## Israel's History of Rebellion (9:10-17)

**9:10** I found Israel like grapes in the wilderness; I saw your fathers as the first-ripe in the fig-tree at her first season; but so soon as they came to Baal-peor, they separated themselves unto the shameful thing, and became abominable like that which they loved.

**9:11** As for Ephraim, their glory shall fly away like a bird; there shall be no birth, and none with child, and no conception.

**9:12** Yea, though they bring up their children, yet will I bereave them, that there be not a man left; yea, woe also to them when I depart from them!

**9:13** Ephraim, as I have seen, is a Tyre planted in a pleasant place; but Ephraim shall bring forth his children to the slayer.

**9:14** Give them, O YHWH, whatsoever you will give; give them a miscarrying womb and dry breasts.

**9:15** All their wickedness is in Gilgal, for there I hated them; because of the wickedness of their doings I will drive them out of my house; I will love them no more; all their princes are rebellious.

**9:16** Ephraim is smitten, their root is dried up, they shall bear no fruit; yea, though they bring forth, yet will I slay the beloved fruit of their womb.

**9:17** My God will cast them away, because they did not hearken unto him; and they shall be wanderers among the nations.

---

## Synthesis Notes

**Key Restorations:**

**Joy Turned to Mourning (9:1-9):**
**The Key Verse (9:1):**
"'Rejoice not, O Israel, unto exultation, like the peoples.'"

*Al-tismach Yisra'el el-gil ka-ammim*—don't rejoice.

"'You have gone astray from your God.'"

*Ki zanita me-al Elohekha*—gone astray.

"'You have loved a harlot's hire upon every corn-floor.'"

*Ahavta etnan al kol-gornot dagan*—harlot's hire.

**Etnan:**
"Harlot's hire"—fertility cult payments at threshing floors.

**The Key Verses (9:2-4):**
"'The threshing-floor and the winepress shall not feed them.'"

*Goren va-yeqev lo yir'em*—no food.

"'The new wine shall fail her.'"

*Ve-tirosh yekhachesh bah*—wine fails.

"'They shall not dwell in YHWH's land.'"

*Lo yeshvu be-eretz YHWH*—not dwell.

"'Ephraim shall return to Egypt.'"

*Ve-shav Efrayim Mitzrayim*—return to Egypt.

"'They shall eat unclean food in Assyria.'"

*U-ve-Ashur tame yokhelu*—unclean food.

"'They shall not pour out wine-offerings to YHWH.'"

*Lo-yissekhu la-YHWH yayin*—no offerings.

"'Their sacrifices be... as the bread of mourners.'"

*Ke-lechem onim lahem*—mourners' bread.

"'All that eat thereof shall be polluted.'"

*Kol-okhlav yittammu*—polluted.

"'It shall not come into the house of YHWH.'"

*Ki lo-yavo beit YHWH*—not in temple.

**The Key Verses (9:5-7):**
"'What will you do in the day of the appointed season?'"

*Mah-ta'asu le-yom mo'ed*—what will you do?

"'In the day of the feast of YHWH?'"

*U-le-yom chag-YHWH*—feast day.

"'They are gone away from destruction.'"

*Ki-hinneh halekhu mi-shod*—gone from destruction.

"'Egypt shall gather them up, Memphis shall bury them.'"

*Mitzrayim teqabbetzem Mof teqabberem*—Egypt buries.

"'Their precious things of silver, nettles shall possess them.'"

*Machmad le-khaspam qimmosh yirrashem*—nettles possess.

"'Thorns shall be in their tents.'"

*Choach be-ohaleihem*—thorns in tents.

"'The days of visitation are come.'"

*Ba'u yemei ha-pequddah*—visitation comes.

"'The days of recompense are come.'"

*Ba'u yemei ha-shillum*—recompense comes.

"'Israel shall know it.'"

*Yeda Yisra'el*—Israel knows.

"'The prophet is a fool, the man of the spirit is mad!'"

*Evil ha-navi meshugga ish ha-ruach*—prophet fool, mad.

"'For the abundance of your iniquity, the enmity is great.'"

*Al rov avonekha ve-rabbah mastemah*—iniquity, enmity.

**The Key Verses (9:8-9):**
"'Ephraim is a watchman with my God.'"

*Tzofeh Efrayim im-Elohai*—watchman.

"'A fowler's snare is in all his ways.'"

*Navi pach yaqosh al-kol-derakhav*—snare.

"'Enmity in the house of his God.'"

*Mastemah be-veit Elohav*—enmity.

"'They have deeply corrupted themselves, as in the days of Gibeah.'"

*He'miqu shiחetu ki-mei ha-Giv'ah*—like Gibeah.

**Days of Gibeah:**
Judges 19-21—horrific violence.

"'He will remember their iniquity, he will punish their sins.'"

*Yizkor avonam yifqod chattotam*—remember, punish.

**Israel's History of Rebellion (9:10-17):**
**The Key Verse (9:10):**
"'I found Israel like grapes in the wilderness.'"

*Ka-anavim ba-midbar matzati Yisra'el*—grapes in wilderness.

"'I saw your fathers as the first-ripe in the fig-tree at her first season.'"

*Ke-vikkurah vi-te'enah be-reshitah ra'iti avoteikhem*—first figs.

"'So soon as they came to Baal-peor, they separated themselves unto the shameful thing.'"

*Hemmah ba'u Ba'al-Pe'or va-yinazeru la-boshet*—Baal-peor.

"'Became abominable like that which they loved.'"

*Va-yihyu shiqqutzim ke-ohavam*—became abominable.

**Baal-Peor:**
Numbers 25—Israel's first major idolatry.

**The Key Verses (9:11-13):**
"'Ephraim, their glory shall fly away like a bird.'"

*Efrayim ke-of yit'ofef kevodam*—glory flies away.

"'There shall be no birth, and none with child, and no conception.'"

*Mi-leidah u-mi-beten u-me-herayon*—no birth.

"'Though they bring up their children, yet will I bereave them.'"

*Ki im-yegaddelu et-beneihem ve-shikkaltim me-adam*—bereave.

"'Woe also to them when I depart from them!'"

*Ki-gam-oy lahem be-suri mehem*—woe when I depart.

"'Ephraim... is a Tyre planted in a pleasant place.'"

*Efrayim... ke-Tzor shetulah be-naveh*—like Tyre.

"'Ephraim shall bring forth his children to the slayer.'"

*Ve-Efrayim le-hotzi el-horeg banav*—children to slayer.

**The Key Verse (9:14):**
"'Give them, O YHWH, whatsoever you will give.'"

*Ten-lahem YHWH mah-titten*—give them.

"'Give them a miscarrying womb and dry breasts.'"

*Ten-lahem rechem mashkil ve-shadayim tzomeqim*—miscarrying womb.

**Hosea's Prayer:**
Shocking—asks for barrenness to spare children from slaughter.

**The Key Verses (9:15-17):**
"'All their wickedness is in Gilgal.'"

*Kol-ra'atam ba-Gilgal*—wickedness at Gilgal.

"'There I hated them.'"

*Ki-sham senetim*—hated.

"'Because of the wickedness of their doings I will drive them out of my house.'"

*Al ro'a ma'aleleihem mi-veiti agareshem*—drive out.

"'I will love them no more.'"

*Lo osif ahavatam*—no more love.

"'All their princes are rebellious.'"

*Kol-sareihem sorerim*—rebellious princes.

"'Ephraim is smitten, their root is dried up.'"

*Hukkah Efrayim shorsham yavesh*—smitten.

"'They shall bear no fruit.'"

*Peri beli-ya'asun*—no fruit.

"'Though they bring forth, yet will I slay the beloved fruit of their womb.'"

*Gam ki-yeledun ve-hematti machamaddei vitnam*—slay beloved.

"'My God will cast them away, because they did not hearken unto him.'"

*Yim'asem Elohai ki lo shame'u lo*—cast away.

"'They shall be wanderers among the nations.'"

*Ve-yihyu nodedim ba-goyim*—wanderers.

**Archetypal Layer:** Hosea 9 contains **"Rejoice not, O Israel" (9:1)**, **"you have loved a harlot's hire upon every corn-floor" (9:1)**, **"Ephraim shall return to Egypt, and they shall eat unclean food in Assyria" (9:3)**, **"the days of visitation are come, the days of recompense are come" (9:7)**, **"the prophet is a fool, the man of the spirit is mad!" (9:7)**, **"they have deeply corrupted themselves, as in the days of Gibeah" (9:9)**, **"I found Israel like grapes in the wilderness" (9:10)**, **"so soon as they came to Baal-peor" (9:10)**, **"give them a miscarrying womb and dry breasts" (9:14)**, **"all their wickedness is in Gilgal, for there I hated them" (9:15)**, **"I will love them no more" (9:15)**, and **"they shall be wanderers among the nations" (9:17)**.

**Ethical Inversion Applied:**
- "'Rejoice not, O Israel'"—don't rejoice
- "'You have gone astray from your God'"—astray
- "'You have loved a harlot's hire upon every corn-floor'"—fertility cult
- "'The threshing-floor and the winepress shall not feed them'"—no food
- "'They shall not dwell in YHWH's land'"—exile
- "'Ephraim shall return to Egypt'"—return to Egypt
- "'They shall eat unclean food in Assyria'"—unclean food
- "'They shall not pour out wine-offerings to YHWH'"—no offerings
- "'Their bread shall be unto them as the bread of mourners'"—mourners' bread
- "'What will you do in the day of the appointed season?'"—what then?
- "'Egypt shall gather them up, Memphis shall bury them'"—Egypt buries
- "'Nettles shall possess them'"—nettles
- "'The days of visitation are come'"—visitation
- "'The days of recompense are come'"—recompense
- "'The prophet is a fool, the man of the spirit is mad!'"—prophet mad
- "'They have deeply corrupted themselves, as in the days of Gibeah'"—like Gibeah
- "'He will remember their iniquity'"—remember
- "'I found Israel like grapes in the wilderness'"—grapes
- "'I saw your fathers as the first-ripe in the fig-tree'"—first figs
- "'They came to Baal-peor'"—Baal-peor
- "'Became abominable'"—abominable
- "'Their glory shall fly away like a bird'"—glory flies
- "'There shall be no birth'"—no birth
- "'Though they bring up their children, yet will I bereave them'"—bereave
- "'Woe also to them when I depart from them!'"—woe when I depart
- "'Ephraim shall bring forth his children to the slayer'"—to slayer
- "'Give them a miscarrying womb and dry breasts'"—barrenness
- "'All their wickedness is in Gilgal'"—Gilgal
- "'There I hated them'"—hated
- "'I will drive them out of my house'"—drive out
- "'I will love them no more'"—no more love
- "'Ephraim is smitten, their root is dried up'"—dried up
- "'They shall bear no fruit'"—no fruit
- "'My God will cast them away'"—cast away
- "'They shall be wanderers among the nations'"—wanderers

**Modern Equivalent:** Hosea 9 forbids harvest joy because the harvest itself was offered to Baal. Exile means eating "unclean food" (9:3)—unable to offer sacrifice. "Days of Gibeah" (9:9) recalls Judges 19's horror. Hosea's shocking prayer for barrenness (9:14) is mercy—better no children than children destined for slaughter. "Wanderers among the nations" (9:17) has been tragically fulfilled.

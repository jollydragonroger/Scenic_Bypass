# Hosea 1: The Prophet's Symbolic Marriage

*From the Hebrew: דְּבַר־יְהוָה אֲשֶׁר הָיָה אֶל־הוֹשֵׁעַ (Devar-YHWH Asher Hayah El-Hoshea) — The Word of YHWH That Came unto Hosea*

---

## Title and Call (1:1-2)

**1:1** The word of YHWH that came unto Hosea the son of Beeri, in the days of Uzziah, Jotham, Ahaz, and Hezekiah, kings of Judah, and in the days of Jeroboam the son of Joash, king of Israel.

**1:2** When YHWH spoke at first with Hosea, YHWH said unto Hosea: "Go, take unto yourself a wife of harlotry and children of harlotry; for the land does commit great harlotry, departing from YHWH."

---

## Hosea's Marriage and Children (1:3-9)

**1:3** So he went and took Gomer the daughter of Diblaim; and she conceived, and bore him a son.

**1:4** And YHWH said unto him: "Call his name Jezreel; for yet a little while, and I will visit the blood of Jezreel upon the house of Jehu, and will cause to cease the kingdom of the house of Israel.

**1:5** "And it shall come to pass at that day, that I will break the bow of Israel in the valley of Jezreel."

**1:6** And she conceived again, and bore a daughter. And he said unto him: "Call her name Lo-ruhamah; for I will no more have compassion upon the house of Israel, that I should in any wise pardon them.

**1:7** "But I will have compassion upon the house of Judah, and will save them by YHWH their God, and will not save them by bow, nor by sword, nor by battle, nor by horses, nor by horsemen."

**1:8** Now when she had weaned Lo-ruhamah, she conceived, and bore a son.

**1:9** And he said: "Call his name Lo-ammi; for you are not my people, and I will not be yours."

---

## Promise of Restoration (1:10-11)

**1:10** Yet the number of the children of Israel shall be as the sand of the sea, which cannot be measured nor numbered; and it shall come to pass that, instead of that which was said unto them: "You are not my people," it shall be said unto them: "You are the children of the living God."

**1:11** And the children of Judah and the children of Israel shall be gathered together, and they shall appoint themselves one head, and shall go up from the land; for great shall be the day of Jezreel.

---

## Synthesis Notes

**Key Restorations:**

**Title and Call (1:1-2):**
**The Key Verse (1:1):**
"The word of YHWH that came unto Hosea the son of Beeri."

*Devar-YHWH asher hayah el-Hoshea ben-Be'eri*—word to Hosea.

"In the days of Uzziah, Jotham, Ahaz, and Hezekiah, kings of Judah."

*Bi-yemei Uzziyyahu Yotam Achaz Yechizqiyyahu malkhei Yehudah*—Judean kings.

"In the days of Jeroboam the son of Joash, king of Israel."

*U-vi-yemei Yarov'am ben-Yo'ash melekh Yisra'el*—Jeroboam II.

**Dating:**
Mid-8th century BCE—contemporary with Amos, Isaiah, Micah.

**The Key Verse (1:2):**
"'Go, take unto yourself a wife of harlotry and children of harlotry.'"

*Lekh qach-lekha eshet zenunim ve-yaldei zenunim*—wife of harlotry.

"'For the land does commit great harlotry, departing from YHWH.'"

*Ki-zanoh tizneh ha-aretz me-acharei YHWH*—land commits harlotry.

**Eshet Zenunim:**
"Wife of harlotry"—Hosea's marriage embodies Israel's unfaithfulness.

**Hosea's Marriage and Children (1:3-9):**
**The Key Verse (1:3):**
"He went and took Gomer the daughter of Diblaim."

*Va-yelekh va-yiqqach et-Gomer bat-Divlayim*—married Gomer.

"She conceived, and bore him a son."

*Va-tahar va-teled-lo ben*—bore son.

**The Key Verses (1:4-5):**
"'Call his name Jezreel.'"

*Qera shemo Yizre'el*—Jezreel.

**Yizre'el:**
"God sows"—but also recalls Jehu's bloodbath at Jezreel (2 Kings 9-10).

"'I will visit the blood of Jezreel upon the house of Jehu.'"

*Ki-od me'at u-faqadti et-demei Yizre'el al-beit Yehu*—blood visited.

"'I will cause to cease the kingdom of the house of Israel.'"

*Ve-hishbatti mamlekhet beit Yisra'el*—kingdom ends.

"'I will break the bow of Israel in the valley of Jezreel.'"

*Ve-shavarti et-qeshet Yisra'el be-emeq Yizre'el*—bow broken.

**The Key Verses (1:6-7):**
"'Call her name Lo-ruhamah.'"

*Qeri shmah Lo-Ruchamah*—Lo-ruhamah.

**Lo-Ruchamah:**
"Not pitied" or "No compassion."

"'I will no more have compassion upon the house of Israel.'"

*Ki lo-osif od arachem et-beit Yisra'el*—no more compassion.

"'That I should in any wise pardon them.'"

*Ki-naso essa lahem*—not pardon.

"'But I will have compassion upon the house of Judah.'"

*Ve-et-beit Yehudah arachem*—Judah pitied.

"'I will save them by YHWH their God.'"

*Ve-hosha'tim ba-YHWH Eloheihem*—saved by YHWH.

"'Not save them by bow, nor by sword, nor by battle, nor by horses, nor by horsemen.'"

*Ve-lo oshi'em be-qeshet u-ve-cherev u-ve-milchamah be-susim u-ve-farashim*—not by arms.

**The Key Verses (1:8-9):**
"'Call his name Lo-ammi.'"

*Qera shemo Lo-Ammi*—Lo-ammi.

**Lo-Ammi:**
"Not my people."

"'You are not my people.'"

*Ki attem lo ammi*—not my people.

"'I will not be yours.'"

*Ve-anokhi lo-ehyeh lakhem*—not your God.

**Covenant Reversal:**
Reverses Exodus 6:7: "I will take you to me for a people, and I will be to you a God."

**Promise of Restoration (1:10-11):**
**The Key Verse (1:10):**
"'The number of the children of Israel shall be as the sand of the sea.'"

*Ve-hayah mispar benei-Yisra'el ke-chol ha-yam*—like sand.

"'Which cannot be measured nor numbered.'"

*Asher lo-yimmad ve-lo yissafer*—innumerable.

"'Instead of that which was said unto them: You are not my people.'"

*Ve-hayah bi-meqom asher-ye'amer lahem lo-ammi attem*—instead.

"'It shall be said unto them: You are the children of the living God.'"

*Ye'amer lahem benei El-chai*—children of living God.

**Reversal:**
Lo-ammi becomes Ammi; Lo-ruhamah becomes Ruhamah.

**The Key Verse (1:11):**
"'The children of Judah and the children of Israel shall be gathered together.'"

*Ve-niqבetzu benei-Yehudah u-venei Yisra'el yachdav*—gathered together.

"'They shall appoint themselves one head.'"

*Ve-samu lahem rosh echad*—one head.

"'Shall go up from the land.'"

*Ve-alu min-ha-aretz*—go up.

"'Great shall be the day of Jezreel.'"

*Ki gadol yom Yizre'el*—great day of Jezreel.

**Jezreel Transformed:**
From judgment to blessing—"God sows" becomes positive.

**Archetypal Layer:** Hosea 1 introduces the **marriage metaphor**, containing **"Go, take unto yourself a wife of harlotry" (1:2)**, **Gomer daughter of Diblaim (1:3)**, **three symbolically-named children**: **Jezreel (1:4)** = "God sows" (judgment on Jehu's house), **Lo-ruhamah (1:6)** = "Not pitied" (no more compassion on Israel), **Lo-ammi (1:9)** = "Not my people" (covenant reversal), **but restoration promised (1:10-11)**: Lo-ammi becomes "children of the living God," **"the children of Judah and the children of Israel shall be gathered together" (1:11)**.

**Ethical Inversion Applied:**
- "The word of YHWH that came unto Hosea"—prophetic call
- "In the days of Uzziah, Jotham, Ahaz, and Hezekiah"—Judean kings
- "In the days of Jeroboam... king of Israel"—Israelite king
- "'Go, take unto yourself a wife of harlotry'"—symbolic marriage
- "'Children of harlotry'"—symbolic children
- "'The land does commit great harlotry'"—land unfaithful
- "'Departing from YHWH'"—departure
- "He went and took Gomer the daughter of Diblaim"—married Gomer
- "'Call his name Jezreel'"—first child
- "'I will visit the blood of Jezreel upon the house of Jehu'"—judgment
- "'I will cause to cease the kingdom of the house of Israel'"—kingdom ends
- "'I will break the bow of Israel in the valley of Jezreel'"—military defeat
- "'Call her name Lo-ruhamah'"—second child
- "'I will no more have compassion upon the house of Israel'"—no compassion
- "'But I will have compassion upon the house of Judah'"—Judah spared
- "'I will save them by YHWH their God'"—divine salvation
- "'Not save them by bow, nor by sword'"—not by arms
- "'Call his name Lo-ammi'"—third child
- "'You are not my people'"—covenant broken
- "'I will not be yours'"—God withdraws
- "'The number of the children of Israel shall be as the sand of the sea'"—future multitude
- "'Instead of... You are not my people'"—reversal
- "'It shall be said unto them: You are the children of the living God'"—restoration
- "'The children of Judah and the children of Israel shall be gathered together'"—reunification
- "'They shall appoint themselves one head'"—one ruler
- "'Great shall be the day of Jezreel'"—Jezreel redeemed

**Modern Equivalent:** Hosea 1 introduces the prophet's shocking symbolic marriage. Hosea's family embodies Israel's relationship with YHWH—Gomer's infidelity mirrors Israel's idolatry. The children's names pronounce judgment: Jezreel (judgment), Lo-ruhamah (no pity), Lo-ammi (not my people). Yet restoration is promised—covenant reversal will be reversed.

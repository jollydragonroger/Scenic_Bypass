# Hosea 10: Israel the Luxuriant Vine

*From the Hebrew: גֶּפֶן בּוֹקֵק יִשְׂרָאֵל (Gefen Boqeq Yisra'el) — Israel Is a Luxuriant Vine*

---

## The Empty Vine (10:1-8)

**10:1** Israel is a luxuriant vine, which puts forth his fruit; the more his fruit increased, the more altars he made; the more his land prospered, the more goodly pillars he made.

**10:2** Their heart is divided; now shall they bear their guilt; he will break down their altars, he will spoil their pillars.

**10:3** Surely now shall they say: "We have no king; for we feared not YHWH; and the king, what can he do for us?"

**10:4** They speak words, swearing falsely, making covenants; thus judgment springs up as hemlock in the furrows of the field.

**10:5** The inhabitants of Samaria shall be in dread for the calves of Beth-aven; for the people thereof shall mourn over it, and the priests thereof shall tremble for it, for its glory, because it is departed from it.

**10:6** It also shall be carried unto Assyria, for a present to king Contentious; Ephraim shall receive shame, and Israel shall be ashamed of his own counsel.

**10:7** As for Samaria, her king is cut off, as foam upon the water.

**10:8** The high places also of Aven, the sin of Israel, shall be destroyed; the thorn and the thistle shall come up on their altars; and they shall say to the mountains: "Cover us," and to the hills: "Fall on us."

---

## Reaping What Was Sown (10:9-15)

**10:9** From the days of Gibeah you have sinned, O Israel; there they stood; the battle against the children of iniquity overtook them not in Gibeah.

**10:10** When it is my desire, I will chastise them; and the peoples shall be gathered against them, when they are yoked to their two transgressions.

**10:11** And Ephraim is a heifer well broken, that loves to thresh, and I passed over upon her fair neck; I will make Ephraim to ride, Judah shall plow, Jacob shall break his clods.

**10:12** Sow to yourselves in righteousness, reap according to mercy, break up your fallow ground; for it is time to seek YHWH, till he come and cause righteousness to rain upon you.

**10:13** You have plowed wickedness, you have reaped iniquity, you have eaten the fruit of lies; for you did trust in your way, in the multitude of your mighty men.

**10:14** Therefore shall a tumult arise among your peoples, and all your fortresses shall be spoiled, as Shalman spoiled Beth-arbel in the day of battle; the mother was dashed in pieces with her children.

**10:15** So shall Bethel do unto you because of your great wickedness; at dawn shall the king of Israel utterly be cut off.

---

## Synthesis Notes

**Key Restorations:**

**The Empty Vine (10:1-8):**
**The Key Verse (10:1):**
"'Israel is a luxuriant vine, which puts forth his fruit.'"

*Gefen boqeq Yisra'el peri yeshavveh-lo*—luxuriant vine.

"'The more his fruit increased, the more altars he made.'"

*Ke-rov le-firyo hirbah la-mizbechot*—more fruit, more altars.

"'The more his land prospered, the more goodly pillars he made.'"

*Ke-tov le-artzo heitיvu matztzevot*—prosperity = more idols.

**The Key Verse (10:2):**
"'Their heart is divided.'"

*Chalaq libbam*—divided heart.

"'Now shall they bear their guilt.'"

*Attah ye'shamu*—bear guilt.

"'He will break down their altars.'"

*Hu ya'arof mizbechotam*—break altars.

"'He will spoil their pillars.'"

*Yeshodded matzzevotam*—spoil pillars.

**The Key Verses (10:3-4):**
"''We have no king; for we feared not YHWH.''"

*Ki ein lanu melekh ki lo yarenu et-YHWH*—no king.

"''The king, what can he do for us?''"

*Ve-ha-melekh mah-ya'aseh-lanu*—king helpless.

"'They speak words, swearing falsely, making covenants.'"

*Dibberu devarim alot shav karot berit*—false oaths.

"'Judgment springs up as hemlock in the furrows of the field.'"

*U-farach ka-rosh mishpat al talmei sadai*—hemlock judgment.

**The Key Verses (10:5-8):**
"'The inhabitants of Samaria shall be in dread for the calves of Beth-aven.'"

*Le-eglot Beit-Aven yaguru shekhen Shomeron*—dread for calves.

"'The people thereof shall mourn over it.'"

*Ki-aval alav ammo*—mourn.

"'The priests thereof shall tremble for it, for its glory.'"

*U-khemarav alav yagilu al-kevodo*—priests tremble.

"'Because it is departed from it.'"

*Ki-galah mimmennו*—departed.

"'It also shall be carried unto Assyria, for a present to king Contentious.'"

*Gam-oto le-Ashur yuval minchah le-melekh Yarev*—carried to Assyria.

"'Ephraim shall receive shame.'"

*Boshnah Efrayim yiqqach*—shame.

"'Israel shall be ashamed of his own counsel.'"

*Ve-yevosh Yisra'el me-atzato*—ashamed.

"'As for Samaria, her king is cut off, as foam upon the water.'"

*Nidmeh Shomeron malkah ke-qetzef al-penei-mayim*—king like foam.

"'The high places also of Aven, the sin of Israel, shall be destroyed.'"

*Ve-nishmadu bamot Aven chattat Yisra'el*—high places destroyed.

"'The thorn and the thistle shall come up on their altars.'"

*Qotz ve-dardar ya'aleh al-mizbechotam*—thorns on altars.

"'They shall say to the mountains: Cover us, and to the hills: Fall on us.'"

*Ve-ameru la-harim kassu-nu ve-la-geva'ot niplu aleinu*—cover us, fall on us.

**Cover Us, Fall on Us:**
Quoted in Luke 23:30 and Revelation 6:16.

**Reaping What Was Sown (10:9-15):**
**The Key Verses (10:9-10):**
"'From the days of Gibeah you have sinned, O Israel.'"

*Mi-yemei ha-Giv'ah chatata Yisra'el*—since Gibeah.

"'There they stood.'"

*Sham amadu*—stood.

"'The battle against the children of iniquity overtook them not in Gibeah.'"

*Lo-tassigem ba-Giv'ah milchamah al-benei alvah*—not overtake.

"'When it is my desire, I will chastise them.'"

*Be-avvati ve-essarem*—I will chastise.

"'The peoples shall be gathered against them.'"

*Ve-ussefu aleihem ammim*—peoples gathered.

"'When they are yoked to their two transgressions.'"

*Be-osram li-shettei enotam*—two transgressions.

**The Key Verse (10:11):**
"'Ephraim is a heifer well broken, that loves to thresh.'"

*Ve-Efrayim eglah melummadah ohavti ladush*—trained heifer.

"'I passed over upon her fair neck.'"

*Va-ani avarti al-tov tzavvarah*—fair neck.

"'I will make Ephraim to ride.'"

*Arkiv Efrayim*—Ephraim ride.

"'Judah shall plow, Jacob shall break his clods.'"

*Yacharosh Yehudah yesadded-lo Ya'aqov*—Judah plow.

**The Key Verse (10:12):**
"'Sow to yourselves in righteousness.'"

*Zir'u lakhem li-tzedaqah*—sow righteousness.

"'Reap according to mercy.'"

*Qitzru le-fi-chesed*—reap mercy.

"'Break up your fallow ground.'"

*Niru lakhem nir*—break fallow.

"'For it is time to seek YHWH.'"

*Ve-et lidrosh et-YHWH*—seek YHWH.

"'Till he come and cause righteousness to rain upon you.'"

*Ad-yavo ve-yoreh tzedeq lakhem*—rain righteousness.

**The Key Verses (10:13-15):**
"'You have plowed wickedness.'"

*Charashtem resha*—plowed wickedness.

"'You have reaped iniquity.'"

*Avlata qetzartem*—reaped iniquity.

"'You have eaten the fruit of lies.'"

*Akhaltem peri-khachash*—ate lies.

"'You did trust in your way, in the multitude of your mighty men.'"

*Ki-vatachta ve-darkekkha be-rov gibborekha*—trusted way, might.

"'A tumult shall arise among your peoples.'"

*Ve-qam sha'on be-ammekha*—tumult.

"'All your fortresses shall be spoiled.'"

*Ve-khol-mivtzarekha yushShad*—fortresses spoiled.

"'As Shalman spoiled Beth-arbel in the day of battle.'"

*Ke-shod Shalman Beit Arbe'el be-yom milchamah*—Shalman's destruction.

"'The mother was dashed in pieces with her children.'"

*Em al-banim ruttashsha*—mother, children dashed.

"'So shall Bethel do unto you because of your great wickedness.'"

*Kakah asah lakhem Beit-El mippenei ra'at ra'atkhem*—Bethel's fate.

"'At dawn shall the king of Israel utterly be cut off.'"

*Ba-shachar nidmoh nidmah melekh Yisra'el*—king cut off at dawn.

**Archetypal Layer:** Hosea 10 contains **"Israel is a luxuriant vine" (10:1)**—but more fruit = more altars, **"their heart is divided" (10:2)**, **"we have no king; for we feared not YHWH" (10:3)**, **the calf carried to Assyria (10:6)**, **"Samaria, her king is cut off, as foam upon the water" (10:7)**, **"they shall say to the mountains: Cover us, and to the hills: Fall on us" (10:8)**—quoted by Jesus, **"sow to yourselves in righteousness, reap according to mercy" (10:12)**, **"break up your fallow ground; for it is time to seek YHWH" (10:12)**, **"you have plowed wickedness, you have reaped iniquity" (10:13)**, and **"the mother was dashed in pieces with her children" (10:14)**.

**Ethical Inversion Applied:**
- "'Israel is a luxuriant vine'"—luxuriant vine
- "'The more his fruit increased, the more altars he made'"—prosperity = idolatry
- "'Their heart is divided'"—divided heart
- "'Now shall they bear their guilt'"—bear guilt
- "'He will break down their altars'"—break altars
- "''We have no king; for we feared not YHWH''"—no king
- "'They speak words, swearing falsely'"—false oaths
- "'Judgment springs up as hemlock'"—hemlock judgment
- "'The inhabitants of Samaria shall be in dread for the calves'"—dread for calves
- "'The people thereof shall mourn over it'"—mourn
- "'It also shall be carried unto Assyria'"—carried away
- "'Ephraim shall receive shame'"—shame
- "'Samaria, her king is cut off, as foam upon the water'"—king like foam
- "'The high places... shall be destroyed'"—destroyed
- "'The thorn and the thistle shall come up on their altars'"—thorns
- "'They shall say to the mountains: Cover us'"—cover us
- "'And to the hills: Fall on us'"—fall on us
- "'From the days of Gibeah you have sinned'"—since Gibeah
- "'When it is my desire, I will chastise them'"—chastise
- "'Ephraim is a heifer well broken'"—trained heifer
- "'Sow to yourselves in righteousness'"—sow righteousness
- "'Reap according to mercy'"—reap mercy
- "'Break up your fallow ground'"—break fallow
- "'For it is time to seek YHWH'"—seek YHWH
- "'Till he come and cause righteousness to rain upon you'"—rain righteousness
- "'You have plowed wickedness'"—plowed wickedness
- "'You have reaped iniquity'"—reaped iniquity
- "'You have eaten the fruit of lies'"—ate lies
- "'You did trust in your way, in the multitude of your mighty men'"—trusted might
- "'A tumult shall arise among your peoples'"—tumult
- "'All your fortresses shall be spoiled'"—spoiled
- "'The mother was dashed in pieces with her children'"—dashed
- "'At dawn shall the king of Israel utterly be cut off'"—king cut off

**Modern Equivalent:** Hosea 10 shows prosperity fueling idolatry—more fruit, more altars (10:1). "Cover us... Fall on us" (10:8) appears in Luke 23:30 and Revelation 6:16 as ultimate despair. The agricultural call (10:12) to "sow righteousness, reap mercy, break up fallow ground" offers hope—but Israel plowed wickedness instead (10:13).

# Hosea 13: Death and Resurrection

*From the Hebrew: כְּדַבֵּר אֶפְרַיִם רְתֵת (Ke-Dabber Efrayim Retet) — When Ephraim Spoke, There Was Trembling*

---

## Ephraim's Fall (13:1-8)

**13:1** When Ephraim spoke, there was trembling; he exalted himself in Israel; but when he became guilty through Baal, he died.

**13:2** And now they sin more and more, and have made them molten images of their silver, according to their own understanding, even idols, all of them the work of the craftsmen; of them they say: "They that sacrifice men kiss calves."

**13:3** Therefore they shall be as the morning cloud, and as the dew that early passes away, as the chaff that is driven with the whirlwind out of the threshing-floor, and as the smoke out of the window.

**13:4** Yet I am YHWH your God from the land of Egypt; and you know no God but me, and beside me there is no saviour.

**13:5** I did know you in the wilderness, in the land of great drought.

**13:6** When they were fed, they became full, they were filled, and their heart was exalted; therefore have they forgotten me.

**13:7** Therefore am I become unto them as a lion; as a leopard will I watch by the way;

**13:8** I will meet them as a bear that is bereaved of her whelps, and will rend the enclosure of their heart; and there will I devour them like a lioness; the wild beast shall tear them.

---

## Israel's Destruction and Hope (13:9-16)

**13:9** It is your destruction, O Israel, that you are against me, against your help.

**13:10** Ho now your king, that he may save you in all your cities! And your judges, of whom you said: "Give me a king and princes"!

**13:11** I give you a king in my anger, and take him away in my wrath.

**13:12** The iniquity of Ephraim is bound up; his sin is laid up in store.

**13:13** The pangs of a travailing woman shall come upon him; he is an unwise son; for it is time he should not tarry in the place of the breaking forth of children.

**13:14** Shall I ransom them from the power of the nether-world? Shall I redeem them from death? Ho, your plagues, O death! Ho, your destruction, O nether-world! Repentance be hid from my eyes!

**13:15** For though he be fruitful among his brethren, an east wind shall come, the wind of YHWH coming up from the wilderness, and his spring shall become dry, and his fountain shall be dried up; he shall spoil the treasure of all precious vessels.

**13:16** Samaria shall bear her guilt, for she has rebelled against her God; they shall fall by the sword; their infants shall be dashed in pieces, and their women with child shall be ripped up.

---

## Synthesis Notes

**Key Restorations:**

**Ephraim's Fall (13:1-8):**
**The Key Verse (13:1):**
"'When Ephraim spoke, there was trembling.'"

*Ke-dabber Efrayim retet*—trembling.

"'He exalted himself in Israel.'"

*Nasa hu be-Yisra'el*—exalted.

"'When he became guilty through Baal, he died.'"

*Va-ye'sham ba-Ba'al va-yamot*—guilty, died.

**The Key Verse (13:2):**
"'Now they sin more and more.'"

*Ve-attah yosifu la-chato*—sin more.

"'Have made them molten images of their silver.'"

*Va-ya'asu lahem massekah mi-khaspam*—silver idols.

"'According to their own understanding, even idols.'"

*Ki-tevunatam atzabbim*—their own idols.

"'All of them the work of the craftsmen.'"

*Ma'aseh charashim kulloh*—craftsmen's work.

"''They that sacrifice men kiss calves.''"

*Zovechei adam agalim yishshaqun*—kiss calves.

**The Key Verse (13:3):**
"'They shall be as the morning cloud.'"

*Lakhen yihyu ka-anan-boqer*—morning cloud.

"'As the dew that early passes away.'"

*Ve-kha-tal mashkim holekh*—early dew.

"'As the chaff that is driven with the whirlwind out of the threshing-floor.'"

*Ke-motz yesoar mi-goren*—chaff.

"'As the smoke out of the window.'"

*U-khe-ashan me-arubbah*—smoke.

**The Key Verses (13:4-6):**
"'I am YHWH your God from the land of Egypt.'"

*Ve-anokhi YHWH Elohekha me-eretz Mitzrayim*—from Egypt.

"'You know no God but me.'"

*Ve-Elohim zulati lo teda*—no other God.

"'Beside me there is no saviour.'"

*U-moshi'a ayin bilti*—no saviour.

"'I did know you in the wilderness.'"

*Ani yeda'tikha ba-midbar*—knew in wilderness.

"'In the land of great drought.'"

*Be-eretz tal'uvot*—drought land.

"'When they were fed, they became full.'"

*Ke-mar'itam va-yisba'u*—fed, full.

"'Their heart was exalted.'"

*Ram libbam*—heart exalted.

"'Therefore have they forgotten me.'"

*Al-ken shekhechuni*—forgot me.

**The Key Verses (13:7-8):**
"'I become unto them as a lion.'"

*Va-ehi lahem kemo-shachal*—like lion.

"'As a leopard will I watch by the way.'"

*Ke-namer al-derekh ashur*—leopard watches.

"'I will meet them as a bear that is bereaved of her whelps.'"

*Efgeshem ke-dov shakkul*—bereaved bear.

"'Will rend the enclosure of their heart.'"

*Ve-eqra segor libbam*—rend heart.

"'There will I devour them like a lioness.'"

*Ve-okhleem sham ke-lavi*—devour.

"'The wild beast shall tear them.'"

*Chayyat ha-sadeh tevaqqe'em*—wild beast tears.

**Israel's Destruction and Hope (13:9-16):**
**The Key Verses (13:9-11):**
"'It is your destruction, O Israel, that you are against me.'"

*Shichatekha Yisra'el ki-vi ve-ezrekha*—destruction.

"'Against your help.'"

*Be-ezrekha*—against help.

"'Ho now your king, that he may save you in all your cities!'"

*Ehi malkekha efo ve-yoshia'kha be-khol-arekha*—where's your king?

"'Your judges, of whom you said: Give me a king and princes!'"

*U-shofetekha asher amarta tennah-li melekh ve-sarim*—give me king.

"'I give you a king in my anger.'"

*Etten-lekha melekh be-appi*—king in anger.

"'And take him away in my wrath.'"

*Ve-eqqach be-evrati*—take in wrath.

**The Key Verses (13:12-13):**
"'The iniquity of Ephraim is bound up.'"

*Tzarur avon Efrayim*—bound up.

"'His sin is laid up in store.'"

*Tzefunah chattato*—stored.

"'The pangs of a travailing woman shall come upon him.'"

*Chevlei yoledah yavo'u-lo*—labor pangs.

"'He is an unwise son.'"

*Hu ben lo-chakham*—unwise son.

"'It is time he should not tarry in the place of the breaking forth of children.'"

*Ki-et lo-ya'amod be-mishbar banim*—tarries at birth.

**The Key Verse (13:14):**
"'Shall I ransom them from the power of the nether-world?'"

*Mi-yad She'ol epdeim*—ransom from Sheol.

"'Shall I redeem them from death?'"

*Mi-mavet eg'alem*—redeem from death.

"'Ho, your plagues, O death!'"

*Ehi devarekha mavet*—plagues, O death.

"'Ho, your destruction, O nether-world!'"

*Ehi qotevkha She'ol*—destruction, O Sheol.

"'Repentance be hid from my eyes!'"

*Nocham yissater me-einai*—no repentance.

**1 Corinthians 15:55:**
Paul quotes this verse for resurrection hope.

**The Key Verses (13:15-16):**
"'Though he be fruitful among his brethren.'"

*Ki hu bein achim yafri*—fruitful (wordplay on "Ephraim").

"'An east wind shall come, the wind of YHWH.'"

*Yavo qadim ruach YHWH*—east wind.

"'Coming up from the wilderness.'"

*Mi-midbar oleh*—from wilderness.

"'His spring shall become dry, and his fountain shall be dried up.'"

*Ve-yevosh meqoro ve-yecherav ma'yano*—dried up.

"'He shall spoil the treasure of all precious vessels.'"

*Hu yishseh otzar kol-keli chemdah*—spoil treasure.

"'Samaria shall bear her guilt.'"

*Te'sham Shomeron*—bear guilt.

"'For she has rebelled against her God.'"

*Ki maretah be-Eloheyha*—rebelled.

"'They shall fall by the sword.'"

*Ba-cherev yippolu*—sword.

"'Their infants shall be dashed in pieces.'"

*Olleihem yerutashu*—infants dashed.

"'Their women with child shall be ripped up.'"

*Ve-hariyotav yevuqqa'u*—pregnant women ripped.

**Archetypal Layer:** Hosea 13 contains **"When Ephraim spoke, there was trembling... when he became guilty through Baal, he died" (13:1)**, **"they shall be as the morning cloud, and as the dew" (13:3)**, **"I am YHWH your God from the land of Egypt; and you know no God but me, and beside me there is no saviour" (13:4)**, **"when they were fed, they became full... therefore have they forgotten me" (13:6)**, **YHWH as lion, leopard, bear (13:7-8)**, **"I give you a king in my anger, and take him away in my wrath" (13:11)**, **"Shall I ransom them from... Sheol? Shall I redeem them from death? Ho, your plagues, O death! Ho, your destruction, O Sheol!" (13:14)**—quoted in 1 Corinthians 15:55, and **Samaria's destruction (13:16)**.

**Ethical Inversion Applied:**
- "'When Ephraim spoke, there was trembling'"—former glory
- "'He exalted himself in Israel'"—exalted
- "'When he became guilty through Baal, he died'"—died
- "'Now they sin more and more'"—more sin
- "'Have made them molten images of their silver'"—silver idols
- "''They that sacrifice men kiss calves''"—kiss calves
- "'They shall be as the morning cloud'"—transient
- "'As the dew that early passes away'"—passing
- "'As the chaff'"—chaff
- "'As the smoke'"—smoke
- "'I am YHWH your God from the land of Egypt'"—from Egypt
- "'You know no God but me'"—no other
- "'Beside me there is no saviour'"—no saviour
- "'I did know you in the wilderness'"—wilderness
- "'When they were fed, they became full'"—prosperity
- "'Their heart was exalted'"—pride
- "'Therefore have they forgotten me'"—forgot
- "'I become unto them as a lion'"—lion
- "'As a leopard will I watch'"—leopard
- "'I will meet them as a bear that is bereaved'"—bereaved bear
- "'Will rend the enclosure of their heart'"—rend heart
- "'The wild beast shall tear them'"—tear
- "'It is your destruction, O Israel'"—destruction
- "'Ho now your king, that he may save you'"—where's king
- "'I give you a king in my anger'"—king in anger
- "'And take him away in my wrath'"—taken
- "'The iniquity of Ephraim is bound up'"—bound
- "'His sin is laid up in store'"—stored
- "'The pangs of a travailing woman shall come'"—labor pangs
- "'He is an unwise son'"—unwise
- "'Shall I ransom them from... Sheol?'"—ransom
- "'Shall I redeem them from death?'"—redeem
- "'Ho, your plagues, O death!'"—plagues
- "'Ho, your destruction, O Sheol!'"—destruction
- "'An east wind shall come'"—east wind
- "'His spring shall become dry'"—dried
- "'Samaria shall bear her guilt'"—bear guilt
- "'She has rebelled against her God'"—rebelled
- "'They shall fall by the sword'"—sword
- "'Their infants shall be dashed'"—infants
- "'Their women with child shall be ripped up'"—women

**Modern Equivalent:** Hosea 13 moves from former glory to coming destruction. Prosperity led to pride and forgetting God (13:6). YHWH becomes predator—lion, leopard, bear (13:7-8). The famous verse 13:14 is ambiguous—threat or promise? Paul reads it as resurrection triumph (1 Corinthians 15:55). The chapter ends with horrific war descriptions (13:16).

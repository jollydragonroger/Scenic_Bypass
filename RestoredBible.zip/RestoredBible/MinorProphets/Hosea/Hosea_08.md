# Hosea 8: Reaping the Whirlwind

*From the Hebrew: אֶל־חִכְּךָ שֹׁפָר (El-Chikkekha Shofar) — Set the Horn to Your Mouth*

---

## The Alarm (8:1-6)

**8:1** Set the horn to your mouth. As a vulture he comes against the house of YHWH; because they have transgressed my covenant, and trespassed against my law.

**8:2** They cry unto me: "My God, we Israel know you."

**8:3** Israel has cast off that which is good; the enemy shall pursue him.

**8:4** They have set up kings, but not from me; they have made princes, and I knew it not; of their silver and their gold have they made them idols, that they may be cut off.

**8:5** Your calf, O Samaria, is cast off; my anger is kindled against them; how long will they be incapable of innocence?

**8:6** For from Israel is even this: the craftsman made it, and it is no God; yea, the calf of Samaria shall be broken in pieces.

---

## Sowing the Wind (8:7-10)

**8:7** For they sow the wind, and they shall reap the whirlwind; it has no stalk, the bud shall yield no meal; if so be it yield, strangers shall swallow it up.

**8:8** Israel is swallowed up; now are they become among the nations as a vessel wherein is no pleasure.

**8:9** For they are gone up to Assyria, like a wild ass alone by himself; Ephraim has hired lovers.

**8:10** Yea, though they hire among the nations, now will I gather them up; and they begin to be minished by reason of the burden of the king of princes.

---

## Forgotten Maker (8:11-14)

**8:11** For Ephraim has multiplied altars to sin; yea, altars have been unto him to sin.

**8:12** Though I write for him the great things of my law, they are counted as a strange thing.

**8:13** As for the sacrifices that are made by fire unto me, they sacrifice flesh and eat it, but YHWH accepts them not; now will he remember their iniquity, and punish their sins; they shall return to Egypt.

**8:14** For Israel has forgotten his Maker, and built palaces, and Judah has multiplied fortified cities; but I will send a fire upon his cities, and it shall devour the castles thereof.

---

## Synthesis Notes

**Key Restorations:**

**The Alarm (8:1-6):**
**The Key Verse (8:1):**
"'Set the horn to your mouth.'"

*El-chikkekha shofar*—sound alarm.

"'As a vulture he comes against the house of YHWH.'"

*Ka-nesher al-beit YHWH*—vulture attacks.

"'Because they have transgressed my covenant.'"

*Ya'an averu veriti*—transgressed covenant.

"'And trespassed against my law.'"

*Ve-al-torati pasha'u*—trespassed law.

**The Key Verses (8:2-3):**
"'They cry unto me: My God, we Israel know you.'"

*Li yiz'aqu Elohai yeda'anukha Yisra'el*—claim knowledge.

"'Israel has cast off that which is good.'"

*Zanach Yisra'el tov*—cast off good.

"'The enemy shall pursue him.'"

*Oyev yirdefo*—enemy pursues.

**The Key Verses (8:4-6):**
"'They have set up kings, but not from me.'"

*Hem himliku ve-lo mimmenni*—kings not from YHWH.

"'They have made princes, and I knew it not.'"

*Hesiru ve-lo yada'ti*—princes unknown to YHWH.

"'Of their silver and their gold have they made them idols.'"

*Kaspam u-zehavam asu lahem atzabbim*—silver/gold idols.

"'That they may be cut off.'"

*Lema'an yikkaret*—cut off.

"'Your calf, O Samaria, is cast off.'"

*Zanach eglekh Shomeron*—calf rejected.

"'My anger is kindled against them.'"

*Charah appi bam*—anger kindled.

"'How long will they be incapable of innocence?'"

*Ad-matai lo yukhlu niqqayon*—incapable of innocence.

"'The craftsman made it, and it is no God.'"

*Ki me-Yisra'el ve-hu charash asahu ve-lo Elohim hu*—craftsman-made, not God.

"'The calf of Samaria shall be broken in pieces.'"

*Ki shevavim yihyeh egel Shomeron*—broken pieces.

**Egel Shomeron:**
"Calf of Samaria"—the golden calf at Bethel.

**Sowing the Wind (8:7-10):**
**The Key Verse (8:7):**
"'They sow the wind, and they shall reap the whirlwind.'"

*Ki ruach yizra'u ve-sufatah yiqtzoru*—sow wind, reap whirlwind.

**Ruach... Sufatah:**
Famous proverb—actions produce magnified consequences.

"'It has no stalk, the bud shall yield no meal.'"

*Qamah ein-lo tzemach beli-ya'aseh qemach*—no harvest.

"'If so be it yield, strangers shall swallow it up.'"

*Ulai ya'aseh zarim yivla'uhu*—strangers swallow.

**The Key Verses (8:8-10):**
"'Israel is swallowed up.'"

*Nivla Yisra'el*—swallowed.

"'Now are they become among the nations as a vessel wherein is no pleasure.'"

*Attah hayu va-goyim ki-kheli ein-chefetz bo*—useless vessel.

"'They are gone up to Assyria, like a wild ass alone by himself.'"

*Ki-hemmah alu Ashur pere boded lo*—wild ass.

**Pere Boded:**
"Wild ass alone"—stubborn, isolated.

"'Ephraim has hired lovers.'"

*Efrayim hitnu aهavim*—hired lovers.

"'Though they hire among the nations, now will I gather them up.'"

*Gam ki-yitnu va-goyim attah aqabbetzem*—gather for judgment.

"'They begin to be minished by reason of the burden of the king of princes.'"

*Va-yachelu me'at mi-massa melekh sarim*—diminished.

**Forgotten Maker (8:11-14):**
**The Key Verses (8:11-12):**
"'Ephraim has multiplied altars to sin.'"

*Ki-hirbah Efrayim mizbechot la-chato*—altars to sin.

"'Altars have been unto him to sin.'"

*Hayu-lo mizbechot la-chato*—altars = sin.

"'Though I write for him the great things of my law.'"

*Ekhtav-lo rubbei torati*—wrote law.

"'They are counted as a strange thing.'"

*Kemo-zar nechשavu*—counted strange.

**The Key Verses (8:13-14):**
"'The sacrifices that are made by fire unto me, they sacrifice flesh and eat it.'"

*Zivchei havhavai yizbechu basar va-yokhelu*—sacrifice flesh.

"'YHWH accepts them not.'"

*YHWH lo ratzam*—not accepted.

"'Now will he remember their iniquity, and punish their sins.'"

*Attah yizkor avonam ve-yifqod chattotam*—remember, punish.

"'They shall return to Egypt.'"

*Hemmah Mitzrayim yashuvu*—return to Egypt.

**Return to Egypt:**
Reversal of Exodus—exile.

"'Israel has forgotten his Maker.'"

*Va-yishkach Yisra'el et-osehu*—forgot Maker.

"'Built palaces.'"

*Va-yiven heikhalot*—built palaces.

"'Judah has multiplied fortified cities.'"

*Vi-Yhudah hirbah arim betzurot*—fortified cities.

"'I will send a fire upon his cities.'"

*Ve-shillachti-esh be-arav*—fire on cities.

"'It shall devour the castles thereof.'"

*Ve-akhelah armenoteyha*—devour castles.

**Archetypal Layer:** Hosea 8 contains **the alarm: "Set the horn to your mouth" (8:1)**, **"they have transgressed my covenant, and trespassed against my law" (8:1)**, **"they cry unto me: My God, we Israel know you" (8:2)**—false claim, **"they have set up kings, but not from me" (8:4)**, **the calf of Samaria (8:5-6)**, **"they sow the wind, and they shall reap the whirlwind" (8:7)**—famous proverb, **"Israel is swallowed up... as a vessel wherein is no pleasure" (8:8)**, **"Ephraim has hired lovers" (8:9)**, **"though I write for him the great things of my law, they are counted as a strange thing" (8:12)**, **"they shall return to Egypt" (8:13)**, and **"Israel has forgotten his Maker" (8:14)**.

**Ethical Inversion Applied:**
- "'Set the horn to your mouth'"—alarm
- "'As a vulture he comes against the house of YHWH'"—vulture attacks
- "'They have transgressed my covenant'"—transgressed
- "'And trespassed against my law'"—trespassed
- "'They cry unto me: My God, we Israel know you'"—false claim
- "'Israel has cast off that which is good'"—cast off good
- "'The enemy shall pursue him'"—pursued
- "'They have set up kings, but not from me'"—kings not from YHWH
- "'They have made princes, and I knew it not'"—unknown to YHWH
- "'Of their silver and their gold have they made them idols'"—idols
- "'That they may be cut off'"—cut off
- "'Your calf, O Samaria, is cast off'"—calf rejected
- "'My anger is kindled against them'"—anger
- "'How long will they be incapable of innocence?'"—incapable
- "'The craftsman made it, and it is no God'"—not God
- "'The calf of Samaria shall be broken in pieces'"—broken
- "'They sow the wind, and they shall reap the whirlwind'"—sow wind, reap whirlwind
- "'It has no stalk, the bud shall yield no meal'"—no harvest
- "'If so be it yield, strangers shall swallow it up'"—strangers swallow
- "'Israel is swallowed up'"—swallowed
- "'As a vessel wherein is no pleasure'"—useless vessel
- "'They are gone up to Assyria, like a wild ass alone'"—wild ass
- "'Ephraim has hired lovers'"—hired lovers
- "'Now will I gather them up'"—gather for judgment
- "'Ephraim has multiplied altars to sin'"—altars to sin
- "'Though I write for him the great things of my law'"—wrote law
- "'They are counted as a strange thing'"—counted strange
- "'They sacrifice flesh and eat it'"—sacrifice
- "'YHWH accepts them not'"—not accepted
- "'Now will he remember their iniquity'"—remember
- "'They shall return to Egypt'"—return to Egypt
- "'Israel has forgotten his Maker'"—forgot Maker
- "'Built palaces'"—palaces
- "'Judah has multiplied fortified cities'"—fortified cities
- "'I will send a fire upon his cities'"—fire
- "'It shall devour the castles thereof'"—devour

**Modern Equivalent:** Hosea 8 is famous for "they sow the wind, and they shall reap the whirlwind" (8:7)—actions produce multiplied consequences. Israel claims to know God (8:2) but rejects His law as "a strange thing" (8:12). The calf worship at Samaria is condemned. "Return to Egypt" (8:13) means exile—Exodus reversed. Israel "forgot his Maker" (8:14) while building palaces.

# Hosea 2: Israel the Unfaithful Wife

*From the Hebrew: רִיבוּ בְאִמְּכֶם רִיבוּ (Rivu Ve-Immekhem Rivu) — Contend with Your Mother, Contend*

---

## The Charge Against Israel (2:1-5)

**2:1** Say unto your brethren: "Ammi"; and to your sisters: "Ruhamah."

**2:2** Contend with your mother, contend; for she is not my wife, neither am I her husband; and let her put away her harlotries from her face, and her adulteries from between her breasts;

**2:3** Lest I strip her naked, and set her as in the day that she was born, and make her as a wilderness, and set her like a dry land, and slay her with thirst.

**2:4** And I will not have compassion upon her children; for they are children of harlotry.

**2:5** For their mother has played the harlot; she that conceived them has done shamefully; for she said: "I will go after my lovers, that give me my bread and my water, my wool and my flax, my oil and my drink."

---

## YHWH's Response (2:6-13)

**2:6** Therefore, behold, I will hedge up your way with thorns, and I will make a wall against her, that she shall not find her paths.

**2:7** And she shall pursue her lovers, but she shall not overtake them; and she shall seek them, but shall not find them; then shall she say: "I will go and return to my first husband; for then was it better with me than now."

**2:8** For she did not know that it was I that gave her the grain, and the wine, and the oil, and multiplied unto her silver and gold, which they used for Baal.

**2:9** Therefore will I take back my grain in the time thereof, and my wine in the season thereof, and will snatch away my wool and my flax given to cover her nakedness.

**2:10** And now will I uncover her shame in the sight of her lovers, and none shall deliver her out of my hand.

**2:11** I will also cause all her mirth to cease, her feasts, her new moons, and her sabbaths, and all her appointed seasons.

**2:12** And I will lay waste her vines and her fig-trees, whereof she has said: "These are my hire that my lovers have given me"; and I will make them a forest, and the beasts of the field shall eat them.

**2:13** And I will visit upon her the days of the Baalim, wherein she offered unto them, and decked herself with her earrings and her jewels, and went after her lovers, and forgot me, says YHWH.

---

## The New Betrothal (2:14-23)

**2:14** Therefore, behold, I will allure her, and bring her into the wilderness, and speak tenderly unto her.

**2:15** And I will give her her vineyards from thence, and the valley of Achor for a door of hope; and she shall respond there, as in the days of her youth, and as in the day when she came up out of the land of Egypt.

**2:16** And it shall be at that day, says YHWH, that you shall call me Ishi, and shall call me no more Baali.

**2:17** For I will take away the names of the Baalim out of her mouth, and they shall no more be mentioned by their name.

**2:18** And in that day will I make a covenant for them with the beasts of the field, and with the fowls of heaven, and with the creeping things of the ground; and I will break the bow and the sword and the battle out of the land, and will make them to lie down safely.

**2:19** And I will betroth you unto me for ever; yea, I will betroth you unto me in righteousness, and in justice, and in lovingkindness, and in compassion.

**2:20** And I will betroth you unto me in faithfulness; and you shall know YHWH.

**2:21** And it shall come to pass in that day, I will respond, says YHWH, I will respond to the heavens, and they shall respond to the earth;

**2:22** And the earth shall respond to the grain, and the wine, and the oil; and they shall respond to Jezreel.

**2:23** And I will sow her unto me in the land; and I will have compassion upon Lo-ruhamah; and I will say to Lo-ammi: "You are my people"; and he shall say: "You are my God."

---

## Synthesis Notes

**Key Restorations:**

**Charge Against Israel (2:1-5):**
**The Key Verse (2:1):**
"'Say unto your brethren: Ammi; and to your sisters: Ruhamah.'"

*Imru la-acheikhem Ammi u-la-achotekhem Ruchamah*—names reversed.

**Name Reversals:**
Lo-ammi ("Not my people") → Ammi ("My people")
Lo-ruhamah ("Not pitied") → Ruhamah ("Pitied")

**The Key Verses (2:2-3):**
"'Contend with your mother, contend.'"

*Rivu ve-immekhem rivu*—contend.

"'She is not my wife, neither am I her husband.'"

*Ki-hi lo ishti ve-anokhi lo ishah*—not wife/husband.

"'Let her put away her harlotries from her face.'"

*Ve-taser zenuneyha mi-paneyha*—remove harlotries.

"'Her adulteries from between her breasts.'"

*Ve-na'afufeyha mi-bein shadeyha*—remove adulteries.

"'Lest I strip her naked.'"

*Pen-afshitenah arummah*—strip naked.

"'Set her as in the day that she was born.'"

*Ve-hitzagtihah ke-yom hivvaledah*—as when born.

"'Make her as a wilderness.'"

*Ve-samtiha kha-midbar*—as wilderness.

"'Set her like a dry land.'"

*Ve-shattiha ke-eretz tziyyah*—dry land.

"'Slay her with thirst.'"

*Va-hamittihah ba-tzama*—die of thirst.

**The Key Verses (2:4-5):**
"'I will not have compassion upon her children; for they are children of harlotry.'"

*Ve-et-baneha lo arachem ki-venei zenunim hemmah*—children of harlotry.

"'Their mother has played the harlot.'"

*Ki zanetah immam*—mother played harlot.

"'She that conceived them has done shamefully.'"

*Hovishah horatam*—conceived shamefully.

"''I will go after my lovers, that give me my bread and my water, my wool and my flax, my oil and my drink.''"

*Elkhah acharei me'ahavai notenei lachmi u-memai tzamri u-fishti shamni ve-shiqquyai*—go after lovers.

**Israel's Delusion:**
She credits Baal (fertility god) for agricultural gifts.

**YHWH's Response (2:6-13):**
**The Key Verses (2:6-7):**
"'I will hedge up your way with thorns.'"

*Lekhen hineni sakh et-darkekkah ba-sirim*—thorns.

"'I will make a wall against her, that she shall not find her paths.'"

*Ve-gadarti et-gederah ve-netivoteha lo timtza*—wall.

"'She shall pursue her lovers, but she shall not overtake them.'"

*Ve-riddefah et-me'ahaveha ve-lo-tasig otam*—not overtake.

"'She shall seek them, but shall not find them.'"

*U-viqqeshatam ve-lo timtza*—not find.

"''I will go and return to my first husband; for then was it better with me than now.''"

*Elkhah ve-ashuvah el-ishi ha-rishon ki tov li az me-attah*—return to first husband.

**The Key Verse (2:8):**
"'She did not know that it was I that gave her the grain, and the wine, and the oil.'"

*Ve-hi lo yad'ah ki anokhi natatti lah ha-dagan ve-ha-tirosh ve-ha-yitzhar*—I gave.

"'Multiplied unto her silver and gold, which they used for Baal.'"

*Ve-khesef hirbeti lah ve-zahav asu la-Ba'al*—used for Baal.

**The Key Verses (2:9-13):**
"'I will take back my grain in the time thereof.'"

*Lakhen ashuv ve-laqachti degani be-itto*—take back.

"'My wine in the season thereof.'"

*Ve-tiroshi be-mo'ado*—take back wine.

"'Will snatch away my wool and my flax given to cover her nakedness.'"

*Ve-hitzalti tzamri u-fishti le-khasot et-ervatah*—snatch away covering.

"'I will uncover her shame in the sight of her lovers.'"

*Ve-attah agalleh et-navlutah le-einei me'ahaveha*—uncover shame.

"'None shall deliver her out of my hand.'"

*Ve-ish lo-yatzzilenah mi-yadi*—none deliver.

"'I will also cause all her mirth to cease.'"

*Ve-hishbatti kol-mesosah*—mirth cease.

"'Her feasts, her new moons, and her sabbaths, and all her appointed seasons.'"

*Chaggah chodshah ve-shabbattah ve-khol mo'adah*—festivals cease.

"'I will lay waste her vines and her fig-trees.'"

*Va-hashimmoti gafnah u-te'enatah*—lay waste.

"''These are my hire that my lovers have given me.''"

*Asher amrah etna hemmah li asher natenu-li me'ahavai*—her "hire."

"'I will make them a forest, and the beasts of the field shall eat them.'"

*Ve-samtim le-ya'ar va-akhalatam chayyat ha-sadeh*—forest, beasts eat.

"'I will visit upon her the days of the Baalim.'"

*U-faqadti aleha et-yemei ha-be'alim*—visit for Baal worship.

"'Wherein she offered unto them.'"

*Asher taqtir lahem*—offered incense.

"'Decked herself with her earrings and her jewels.'"

*Va-ta'ad nizḿah va-cheliatah*—adorned.

"'Went after her lovers, and forgot me.'"

*Va-telekh acharei me'ahaveha ve-oti shakhechah*—forgot YHWH.

**New Betrothal (2:14-23):**
**The Key Verses (2:14-15):**
"'I will allure her, and bring her into the wilderness.'"

*Lakhen hineh anokhi mefatteha ve-holakhtiha ha-midbar*—allure to wilderness.

"'Speak tenderly unto her.'"

*Ve-dibbarti al-libbah*—speak to heart.

"'I will give her her vineyards from thence.'"

*Ve-natatti lah et-kerameha mi-sham*—give vineyards.

"'The valley of Achor for a door of hope.'"

*Ve-et-emeq Akhor le-petach tiqvah*—door of hope.

**Emeq Akhor:**
"Valley of Trouble" (Joshua 7) becomes "door of hope."

"'She shall respond there, as in the days of her youth.'"

*Ve-anetah shammah ki-ymei ne'ureha*—as in youth.

"'As in the day when she came up out of the land of Egypt.'"

*U-khe-yom alotah me-eretz Mitzrayim*—Exodus.

**The Key Verses (2:16-17):**
"'You shall call me Ishi, and shall call me no more Baali.'"

*Ve-hayah va-yom ha-hu... tiqre'i Ishi ve-lo-tiqre'i-li od Ba'ali*—Ishi not Baali.

**Ishi vs. Baali:**
Both mean "my husband," but *Ba'al* is also the name of the Canaanite god—so the term is eliminated.

"'I will take away the names of the Baalim out of her mouth.'"

*Va-hasiroti et-shemot ha-be'alim mi-piha*—remove names.

"'They shall no more be mentioned by their name.'"

*Ve-lo-yizzakheru od bi-shemam*—not mentioned.

**The Key Verse (2:18):**
"'I will make a covenant for them with the beasts of the field.'"

*Ve-kharati lahem berit... im-chayyat ha-sadeh*—cosmic covenant.

"'With the fowls of heaven, and with the creeping things of the ground.'"

*Ve-im-of ha-shamayim ve-remes ha-adamah*—birds, creeping things.

"'I will break the bow and the sword and the battle out of the land.'"

*Ve-qeshet ve-cherev u-milchamah eshbor min-ha-aretz*—break weapons.

"'Will make them to lie down safely.'"

*Ve-hishkavtim la-vetach*—lie safely.

**The Key Verses (2:19-20):**
"'I will betroth you unto me for ever.'"

*Ve-erastikh li le-olam*—betroth forever.

"'I will betroth you unto me in righteousness, and in justice, and in lovingkindness, and in compassion.'"

*Ve-erastikh li be-tzedeq u-ve-mishpat u-ve-chesed u-ve-rachamim*—bridal gifts.

"'I will betroth you unto me in faithfulness.'"

*Ve-erastikh li be-emunah*—faithfulness.

"'You shall know YHWH.'"

*Ve-yada'at et-YHWH*—know YHWH.

**The Key Verses (2:21-23):**
"'I will respond... I will respond to the heavens, and they shall respond to the earth.'"

*E'eneh... e'eneh et-ha-shamayim ve-hem ya'anu et-ha-aretz*—cosmic response.

"'The earth shall respond to the grain, and the wine, and the oil.'"

*Ve-ha-aretz ta'aneh et-ha-dagan ve-et-ha-tirosh ve-et-ha-yitzhar*—fertility.

"'They shall respond to Jezreel.'"

*Ve-hem ya'anu et-Yizre'el*—respond to Jezreel.

**Jezreel Restored:**
Now means "God sows" positively.

"'I will sow her unto me in the land.'"

*U-zera'tiha li ba-aretz*—sow in land.

"'I will have compassion upon Lo-ruhamah.'"

*Ve-richamti et-Lo Ruchamah*—compassion on "Not pitied."

"'I will say to Lo-ammi: You are my people.'"

*Ve-amarti le-Lo Ammi Ammi attah*—"You are my people."

"'He shall say: You are my God.'"

*Ve-hu yomar Elohai*—"My God."

**Archetypal Layer:** Hosea 2 develops the **marriage metaphor**, containing **name reversals: Ammi, Ruhamah (2:1)**, **"she is not my wife" (2:2)**, **"I will go after my lovers" (2:5)**—Israel credits Baal for fertility gifts, **"she did not know that it was I that gave her the grain" (2:8)**, **judgment through deprivation (2:9-13)**, **"I will allure her, and bring her into the wilderness" (2:14)**, **"the valley of Achor for a door of hope" (2:15)**, **"you shall call me Ishi, and shall call me no more Baali" (2:16)**, **the threefold betrothal: "I will betroth you unto me... in righteousness, in justice, in lovingkindness, in compassion, in faithfulness" (2:19-20)**, and **"I will say to Lo-ammi: You are my people" (2:23)**.

**Ethical Inversion Applied:**
- "'Say unto your brethren: Ammi; and to your sisters: Ruhamah'"—names restored
- "'Contend with your mother, contend'"—lawsuit
- "'She is not my wife, neither am I her husband'"—divorce
- "'Let her put away her harlotries'"—remove
- "'Lest I strip her naked'"—shame
- "'Make her as a wilderness'"—desolation
- "'I will not have compassion upon her children'"—no compassion
- "'Their mother has played the harlot'"—harlotry
- "''I will go after my lovers''"—pursues false gods
- "'I will hedge up your way with thorns'"—blocked paths
- "'She shall pursue her lovers, but she shall not overtake them'"—frustrated pursuit
- "''I will go and return to my first husband''"—return to YHWH
- "'She did not know that it was I that gave her the grain'"—ignorance
- "'Silver and gold, which they used for Baal'"—misused gifts
- "'I will take back my grain'"—deprivation
- "'I will uncover her shame'"—exposure
- "'I will cause all her mirth to cease'"—joy ends
- "'I will lay waste her vines'"—destruction
- "'I will visit upon her the days of the Baalim'"—punishment
- "'She... forgot me'"—forgot YHWH
- "'I will allure her, and bring her into the wilderness'"—new courtship
- "'Speak tenderly unto her'"—gentle words
- "'The valley of Achor for a door of hope'"—trouble becomes hope
- "'She shall respond there, as in the days of her youth'"—renewed youth
- "'You shall call me Ishi, and shall call me no more Baali'"—new name
- "'I will take away the names of the Baalim'"—Baal removed
- "'I will make a covenant for them with the beasts'"—cosmic peace
- "'I will break the bow and the sword'"—end warfare
- "'I will betroth you unto me for ever'"—eternal betrothal
- "'In righteousness, and in justice, and in lovingkindness, and in compassion'"—bridal gifts
- "'In faithfulness'"—faithfulness
- "'You shall know YHWH'"—know God
- "'I will respond to the heavens'"—cosmic fertility
- "'I will sow her unto me in the land'"—sow Jezreel
- "'I will have compassion upon Lo-ruhamah'"—compassion restored
- "'I will say to Lo-ammi: You are my people'"—covenant restored
- "'He shall say: You are my God'"—response

**Modern Equivalent:** Hosea 2 is powerful covenant theology. YHWH as betrayed husband will strip Israel bare—then allure her again. The bridal gifts (righteousness, justice, lovingkindness, compassion, faithfulness) define the renewed covenant. "Ishi" (my husband) replaces "Baali" (my lord/my Baal)—purging Baal's name. All three children's names are reversed: judgment becomes blessing.

# Hosea 12: Jacob's Example

*From the Hebrew: סְבָבֻנִי בְכַחַשׁ אֶפְרַיִם (Sevavuni Ve-Khachash Efrayim) — Ephraim Compasses Me About with Lies*

---

## Ephraim's Deceit (12:1-2)

**12:1** Ephraim compasses me about with lies, and the house of Israel with deceit; and Judah is yet wayward towards God, and towards the Holy One who is faithful.

**12:2** Ephraim pursues the wind, and follows after the east wind; all the day he multiplies lies and desolation; and they make a covenant with Assyria, and oil is carried into Egypt.

---

## The Jacob Precedent (12:3-6)

**12:3** YHWH has also a controversy with Judah, and will punish Jacob according to his ways, according to his doings will he recompense him.

**12:4** In the womb he took his brother by the heel, and by his strength he strove with God;

**12:5** Yea, he strove with an angel, and prevailed; he wept, and made supplication unto him; at Bethel he would find him, and there he would speak with us;

**12:6** Even YHWH, the God of hosts, YHWH is his memorial.

---

## Call to Return (12:7-11)

**12:7** Therefore turn you to your God; keep mercy and justice, and wait for your God continually.

**12:8** As for the trafficker, the balances of deceit are in his hand; he loves to oppress.

**12:9** And Ephraim said: "Surely I am become rich, I have found me wealth; in all my labours they shall find in me no iniquity that were sin."

**12:10** But I am YHWH your God from the land of Egypt; I will yet again make you to dwell in tents, as in the days of the appointed season.

**12:11** I have also spoken unto the prophets, and I have multiplied visions; and by the ministry of the prophets have I used similitudes.

---

## Gilead's Wickedness (12:12-14)

**12:12** If Gilead be iniquity, they become altogether vanity; in Gilgal they sacrifice unto bullocks; yea, their altars shall be as heaps in the furrows of the field.

**12:13** And Jacob fled into the field of Aram, and Israel served for a wife, and for a wife he kept sheep.

**12:14** And by a prophet YHWH brought Israel up out of Egypt, and by a prophet was he kept.

---

## Synthesis Notes

**Key Restorations:**

**Ephraim's Deceit (12:1-2):**
**The Key Verse (12:1):**
"'Ephraim compasses me about with lies.'"

*Sevavuni ve-khachash Efrayim*—lies surround.

"'The house of Israel with deceit.'"

*U-ve-mirmah beit Yisra'el*—deceit.

"'Judah is yet wayward towards God.'"

*Vi-Yhudah od rad im-El*—Judah wayward.

"'Towards the Holy One who is faithful.'"

*Ve-im-qedoshim ne'eman*—Holy One faithful.

**The Key Verse (12:2):**
"'Ephraim pursues the wind.'"

*Efrayim ro'eh ruach*—pursues wind.

"'Follows after the east wind.'"

*Ve-rodef qadim*—east wind.

"'All the day he multiplies lies and desolation.'"

*Kol-ha-yom kazav va-shod yarbeh*—lies, desolation.

"'They make a covenant with Assyria.'"

*U-verit im-Ashur yikhrotу*—Assyrian covenant.

"'Oil is carried into Egypt.'"

*Ve-shemen le-Mitzrayim yuval*—oil to Egypt.

**Jacob Precedent (12:3-6):**
**The Key Verse (12:3):**
"'YHWH has also a controversy with Judah.'"

*Ve-riv la-YHWH im-Yehudah*—controversy.

"'Will punish Jacob according to his ways.'"

*Ve-lifqod al-Ya'aqov ki-derakhav*—punish.

"'According to his doings will he recompense him.'"

*Ke-ma'alalav yashiv lo*—recompense.

**The Key Verses (12:4-5):**
"'In the womb he took his brother by the heel.'"

*Ba-beten aqav et-achiv*—heel in womb.

**Aqav:**
"Took by the heel"—etymology of Jacob's name.

"'By his strength he strove with God.'"

*U-ve-ono sarah et-Elohim*—strove with God.

"'Yea, he strove with an angel, and prevailed.'"

*Va-yasar el-mal'akh va-yukhal*—prevailed.

"'He wept, and made supplication unto him.'"

*Bakhah va-yitchannen-lo*—wept, supplicated.

"'At Bethel he would find him, and there he would speak with us.'"

*Beit-El yimtza'ennu ve-sham yedabber immanu*—Bethel.

**The Key Verse (12:6):**
"'Even YHWH, the God of hosts.'"

*Va-YHWH Elohei ha-tzeva'ot*—YHWH of hosts.

"'YHWH is his memorial.'"

*YHWH zikhro*—his memorial name.

**Call to Return (12:7-11):**
**The Key Verse (12:7):**
"'Turn you to your God.'"

*Ve-attah be-Elohekha tashuv*—return.

"'Keep mercy and justice.'"

*Chesed u-mishpat shemor*—keep chesed, justice.

"'Wait for your God continually.'"

*Ve-qavveh el-Elohekha tamid*—wait continually.

**The Key Verses (12:8-9):**
"'As for the trafficker, the balances of deceit are in his hand.'"

*Kena'an be-yado moznei mirmah la-ashoq ahev*—deceitful balances.

**Kena'an:**
"Trafficker" or "Canaanite"—Israel has become like the Canaanites.

"'He loves to oppress.'"

*La-ashoq ahev*—loves oppression.

"''Surely I am become rich, I have found me wealth.''"

*Akh asharti matzati on li*—I'm rich.

"''In all my labours they shall find in me no iniquity that were sin.''"

*Kol-yegi'ai lo-yimtze'u-li avon asher-chet*—no sin found.

**The Key Verses (12:10-11):**
"'I am YHWH your God from the land of Egypt.'"

*Ve-anokhi YHWH Elohekha me-eretz Mitzrayim*—YHWH from Egypt.

"'I will yet again make you to dwell in tents.'"

*Od oshivekha va-ohalim*—dwell in tents.

"'As in the days of the appointed season.'"

*Ki-yemei mo'ed*—as in festival days.

"'I have also spoken unto the prophets.'"

*Ve-dibbarti al-ha-nevi'im*—spoke to prophets.

"'I have multiplied visions.'"

*Ve-chazon hirbeti*—multiplied visions.

"'By the ministry of the prophets have I used similitudes.'"

*U-ve-yad ha-nevi'im adammeh*—similitudes.

**Gilead's Wickedness (12:12-14):**
**The Key Verses (12:12-14):**
"'If Gilead be iniquity, they become altogether vanity.'"

*Im-Gil'ad aven akh-shav hayu*—Gilead vanity.

"'In Gilgal they sacrifice unto bullocks.'"

*Ba-Gilgal shevarim zibbechu*—Gilgal sacrifices.

"'Their altars shall be as heaps in the furrows of the field.'"

*Gam mizbechotam ke-gallim al talmei sadai*—altars as heaps.

"'Jacob fled into the field of Aram.'"

*Va-yivrach Ya'aqov sedeh Aram*—Jacob fled.

"'Israel served for a wife, and for a wife he kept sheep.'"

*Va-ya'avod Yisra'el be-ishah u-ve-ishah shamar*—served for wife.

"'By a prophet YHWH brought Israel up out of Egypt.'"

*U-ve-navi he'elah YHWH et-Yisra'el mi-Mitzrayim*—prophet brought up.

"'By a prophet was he kept.'"

*U-ve-navi nishmar*—prophet kept.

**Archetypal Layer:** Hosea 12 contains **"Ephraim compasses me about with lies" (12:1)**, **"Ephraim pursues the wind, and follows after the east wind" (12:2)**, **Jacob's life as precedent: taking heel in womb, striving with God (12:3-5)**, **"at Bethel he would find him" (12:5)**, **"turn you to your God; keep mercy and justice, and wait for your God continually" (12:7)**, **"as for the trafficker, the balances of deceit are in his hand" (12:8)**, **Ephraim's boast: "I am become rich... no iniquity" (12:9)**, **"I am YHWH your God from the land of Egypt" (12:10)**, **"by the ministry of the prophets have I used similitudes" (12:11)**, and **"by a prophet YHWH brought Israel up out of Egypt" (12:14)**.

**Ethical Inversion Applied:**
- "'Ephraim compasses me about with lies'"—lies
- "'The house of Israel with deceit'"—deceit
- "'Judah is yet wayward towards God'"—wayward
- "'Ephraim pursues the wind'"—pursues wind
- "'Follows after the east wind'"—east wind
- "'All the day he multiplies lies and desolation'"—lies, desolation
- "'They make a covenant with Assyria'"—Assyrian covenant
- "'Oil is carried into Egypt'"—Egypt
- "'YHWH has also a controversy with Judah'"—controversy
- "'Will punish Jacob according to his ways'"—punish
- "'In the womb he took his brother by the heel'"—heel in womb
- "'By his strength he strove with God'"—strove
- "'He strove with an angel, and prevailed'"—prevailed
- "'He wept, and made supplication unto him'"—wept
- "'At Bethel he would find him'"—Bethel
- "'YHWH is his memorial'"—memorial name
- "'Turn you to your God'"—return
- "'Keep mercy and justice'"—chesed, justice
- "'Wait for your God continually'"—wait
- "'As for the trafficker, the balances of deceit are in his hand'"—deceit
- "'He loves to oppress'"—oppression
- "''I am become rich''"—rich
- "''In all my labours they shall find in me no iniquity''"—no sin
- "'I am YHWH your God from the land of Egypt'"—from Egypt
- "'I will yet again make you to dwell in tents'"—tents
- "'I have also spoken unto the prophets'"—prophets
- "'I have multiplied visions'"—visions
- "'By the ministry of the prophets have I used similitudes'"—similitudes
- "'If Gilead be iniquity'"—Gilead iniquity
- "'In Gilgal they sacrifice unto bullocks'"—Gilgal
- "'Their altars shall be as heaps'"—altars as heaps
- "'Jacob fled into the field of Aram'"—fled
- "'Israel served for a wife'"—served
- "'By a prophet YHWH brought Israel up out of Egypt'"—prophet
- "'By a prophet was he kept'"—prophet kept

**Modern Equivalent:** Hosea 12 invokes Jacob—their ancestor strove with God and prevailed through weeping and supplication (12:4-5). Israel should follow that example and "turn... keep mercy and justice... wait" (12:7). Instead, they've become "traffickers" with false balances (12:8), boasting of innocence while guilty (12:9). "By a prophet" God brought them up and keeps them (12:13-14)—prophetic authority.

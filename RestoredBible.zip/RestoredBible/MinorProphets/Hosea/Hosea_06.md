# Hosea 6: A Call to Return

*From the Hebrew: לְכוּ וְנָשׁוּבָה אֶל־יְהוָה (Lekhu Ve-Nashuvah El-YHWH) — Come, and Let Us Return unto YHWH*

---

## Israel's Shallow Repentance (6:1-3)

**6:1** "Come, and let us return unto YHWH; for he has torn, and he will heal us, he has smitten, and he will bind us up.

**6:2** "After two days will he revive us, on the third day he will raise us up, that we may live in his presence.

**6:3** "And let us know, let us follow on to know YHWH; his going forth is sure as the morning; and he shall come unto us as the rain, as the latter rain that waters the earth."

---

## YHWH's Response (6:4-11)

**6:4** O Ephraim, what shall I do unto you? O Judah, what shall I do unto you? For your goodness is as a morning cloud, and as the dew that early passes away.

**6:5** Therefore have I hewed them by the prophets, I have slain them by the words of my mouth; and your judgment goes forth as the light.

**6:6** For I desire mercy, and not sacrifice, and the knowledge of God rather than burnt-offerings.

**6:7** But they like Adam have transgressed the covenant; there have they dealt treacherously against me.

**6:8** Gilead is a city of them that work iniquity, it is covered with footprints of blood.

**6:9** And as troops of robbers wait for a man, so does the company of priests; they murder in the way toward Shechem; yea, they commit enormity.

**6:10** In the house of Israel I have seen a horrible thing; there harlotry is found in Ephraim, Israel is defiled.

**6:11** Also, O Judah, there is a harvest appointed for you! When I would turn the captivity of my people,

---

## Synthesis Notes

**Key Restorations:**

**Israel's Shallow Repentance (6:1-3):**
**The Key Verse (6:1):**
"'Come, and let us return unto YHWH.'"

*Lekhu ve-nashuvah el-YHWH*—let us return.

"'For he has torn, and he will heal us.'"

*Ki hu taraf ve-yirpa'enu*—torn, will heal.

"'He has smitten, and he will bind us up.'"

*Yakh vi-yachbeshenu*—smitten, will bind.

**The Key Verse (6:2):**
"'After two days will he revive us.'"

*Yechayenu mi-yomayim*—revive after two days.

"'On the third day he will raise us up.'"

*Ba-yom ha-shelishi yeqimenu*—raise on third day.

"'That we may live in his presence.'"

*Ve-nichyeh lefanav*—live before him.

**Third Day:**
Early Christians saw resurrection typology here.

**The Key Verse (6:3):**
"'Let us know, let us follow on to know YHWH.'"

*Ve-nede'ah nirdepah lada'at et-YHWH*—pursue knowing.

"'His going forth is sure as the morning.'"

*Ke-shachar nakhon motza'o*—sure as dawn.

"'He shall come unto us as the rain.'"

*Ve-yavo kha-geshem lanu*—like rain.

"'As the latter rain that waters the earth.'"

*Ke-malqosh yoreh aretz*—latter rain.

**YHWH's Response (6:4-11):**
**The Key Verse (6:4):**
"'O Ephraim, what shall I do unto you?'"

*Mah e'eseh-lekha Efrayim*—what shall I do?

"'O Judah, what shall I do unto you?'"

*Mah e'eseh-lekha Yehudah*—what shall I do?

"'Your goodness is as a morning cloud.'"

*Ve-chasdekhem ka-anan-boqer*—morning cloud.

"'As the dew that early passes away.'"

*Ve-kha-tal mashkim holekh*—dew passes.

**Morning Cloud and Dew:**
Beautiful but transient—Israel's piety is shallow and fleeting.

**The Key Verse (6:5):**
"'I have hewed them by the prophets.'"

*Al-ken chatzavti ba-nevi'im*—hewed by prophets.

"'I have slain them by the words of my mouth.'"

*Haragtim be-imrei-fi*—slain by words.

"'Your judgment goes forth as the light.'"

*U-mishpatekha or yetze*—judgment as light.

**The Key Verse (6:6):**
"'I desire mercy, and not sacrifice.'"

*Ki chesed chafatzti ve-lo-zevach*—mercy not sacrifice.

"'The knowledge of God rather than burnt-offerings.'"

*Ve-da'at Elohim me-olot*—knowledge over offerings.

**Chesed:**
"Mercy" / "lovingkindness" / "covenant loyalty"—what YHWH truly desires.

**The Key Verses (6:7-9):**
"'They like Adam have transgressed the covenant.'"

*Ve-hemmah ke-Adam averu verit*—like Adam.

"'There have they dealt treacherously against me.'"

*Sham bagdu vi*—treachery.

"'Gilead is a city of them that work iniquity.'"

*Gil'ad qiryat po'alei aven*—city of iniquity.

"'It is covered with footprints of blood.'"

*Aqubbah mi-dam*—bloody footprints.

"'As troops of robbers wait for a man.'"

*U-khe-chakkei ish gedudim*—like robbers.

"'So does the company of priests.'"

*Chever kohanim*—company of priests.

"'They murder in the way toward Shechem.'"

*Derekh yeratzechu Shekhemah*—murder on road.

"'They commit enormity.'"

*Ki zimmah asu*—enormity.

**The Key Verses (6:10-11):**
"'In the house of Israel I have seen a horrible thing.'"

*Be-veit Yisra'el ra'iti sha'aruriyyah*—horrible thing.

"'There harlotry is found in Ephraim.'"

*Shammah zenut le-Efrayim*—harlotry.

"'Israel is defiled.'"

*Nitme Yisra'el*—defiled.

"'Also, O Judah, there is a harvest appointed for you!'"

*Gam-Yehudah shat qatzir lakh*—harvest for Judah.

"'When I would turn the captivity of my people.'"

*Be-shuvi shevut ammi*—restore captivity.

**Archetypal Layer:** Hosea 6 contains **Israel's call to return (6:1-3)**—but perhaps superficial, **"after two days will he revive us, on the third day he will raise us up" (6:2)**, **"let us follow on to know YHWH" (6:3)**, **YHWH's lament: "what shall I do unto you?" (6:4)**, **"your goodness is as a morning cloud, and as the dew" (6:4)**—fleeting piety, **"I desire mercy, and not sacrifice, and the knowledge of God rather than burnt-offerings" (6:6)**—quoted by Jesus, **"they like Adam have transgressed the covenant" (6:7)**, **Gilead as city of iniquity (6:8)**, **priests as robbers and murderers (6:9)**, and **"also, O Judah, there is a harvest appointed for you" (6:11)**.

**Ethical Inversion Applied:**
- "'Come, and let us return unto YHWH'"—call to return
- "'He has torn, and he will heal us'"—torn, heal
- "'He has smitten, and he will bind us up'"—smitten, bind
- "'After two days will he revive us'"—two days
- "'On the third day he will raise us up'"—third day
- "'That we may live in his presence'"—live before him
- "'Let us know, let us follow on to know YHWH'"—pursue knowing
- "'His going forth is sure as the morning'"—sure as dawn
- "'He shall come unto us as the rain'"—like rain
- "'O Ephraim, what shall I do unto you?'"—divine lament
- "'O Judah, what shall I do unto you?'"—divine lament
- "'Your goodness is as a morning cloud'"—fleeting
- "'As the dew that early passes away'"—transient
- "'I have hewed them by the prophets'"—prophetic judgment
- "'I have slain them by the words of my mouth'"—slain by words
- "'Your judgment goes forth as the light'"—judgment
- "'I desire mercy, and not sacrifice'"—mercy over sacrifice
- "'The knowledge of God rather than burnt-offerings'"—knowledge over offerings
- "'They like Adam have transgressed the covenant'"—like Adam
- "'There have they dealt treacherously against me'"—treachery
- "'Gilead is a city of them that work iniquity'"—city of iniquity
- "'It is covered with footprints of blood'"—bloody
- "'As troops of robbers wait for a man, so does the company of priests'"—priests as robbers
- "'They murder in the way toward Shechem'"—murder
- "'They commit enormity'"—enormity
- "'In the house of Israel I have seen a horrible thing'"—horrible
- "'There harlotry is found in Ephraim'"—harlotry
- "'Israel is defiled'"—defiled
- "'Also, O Judah, there is a harvest appointed for you'"—harvest for Judah
- "'When I would turn the captivity of my people'"—restore

**Modern Equivalent:** Hosea 6 opens with what sounds like repentance (6:1-3) but YHWH's response (6:4) reveals it's shallow—"your goodness is as a morning cloud." "I desire mercy, and not sacrifice" (6:6) is quoted by Jesus (Matthew 9:13; 12:7). Chesed (covenant loyalty) and knowledge of God matter more than ritual. "After two days... on the third day" (6:2) was read as resurrection prophecy.

# Hosea 7: Israel's Corruption

*From the Hebrew: כְּרָפְאִי לְיִשְׂרָאֵל (Ke-Raf'i Le-Yisra'el) — When I Would Heal Israel*

---

## Domestic Corruption (7:1-7)

**7:1** When I would heal Israel, then is the iniquity of Ephraim uncovered, and the wickedness of Samaria, for they commit falsehood; and the thief enters in, and the troop of robbers makes a raid without.

**7:2** And they consider not in their hearts that I remember all their wickedness; now their own doings have beset them about, they are before my face.

**7:3** They make the king glad with their wickedness, and the princes with their lies.

**7:4** They are all adulterers, as an oven heated by the baker, who ceases to stir the fire, from the kneading of the dough until it be leavened.

**7:5** On the day of our king the princes make him sick with the heat of wine; he stretches out his hand with scorners.

**7:6** For they have made ready their heart like an oven, while they lie in wait; their baker sleeps all the night, in the morning it burns as a flaming fire.

**7:7** They are all hot as an oven, and devour their judges; all their kings are fallen; there is none among them that calls unto me.

---

## Foreign Alliances (7:8-16)

**7:8** Ephraim, he mixes himself among the peoples; Ephraim is a cake not turned.

**7:9** Strangers have devoured his strength, and he knows it not; yea, gray hairs are here and there upon him, and he knows it not.

**7:10** And the pride of Israel does testify to his face; but they have not returned unto YHWH their God, nor sought him, for all this.

**7:11** And Ephraim is become like a silly dove, without understanding; they call unto Egypt, they go to Assyria.

**7:12** When they shall go, I will spread my net upon them; I will bring them down as the fowls of the heaven; I will chastise them, as their congregation has been made to hear.

**7:13** Woe unto them! For they have strayed from me; destruction unto them! For they have transgressed against me; though I would redeem them, yet they have spoken lies against me.

**7:14** And they have not cried unto me with their heart, though they wail upon their beds; for grain and wine they assemble themselves, they rebel against me.

**7:15** Though I have trained and strengthened their arms, yet do they devise evil against me.

**7:16** They return, but not upward, they are become like a deceitful bow; their princes shall fall by the sword for the rage of their tongue; this shall be their derision in the land of Egypt.

---

## Synthesis Notes

**Key Restorations:**

**Domestic Corruption (7:1-7):**
**The Key Verse (7:1):**
"'When I would heal Israel, then is the iniquity of Ephraim uncovered.'"

*Ke-raf'i le-Yisra'el ve-niglah avon Efrayim*—healing reveals sin.

"'The wickedness of Samaria.'"

*Ve-ra'ot Shomeron*—Samaria's wickedness.

"'They commit falsehood.'"

*Ki fa'alu shaqer*—falsehood.

"'The thief enters in, and the troop of robbers makes a raid without.'"

*Ve-gannav yavo pashat gedud ba-chutz*—thieves, robbers.

**The Key Verse (7:2):**
"'They consider not in their hearts that I remember all their wickedness.'"

*U-val-yomeru li-levavam kol-ra'atam zakharti*—don't consider.

"'Their own doings have beset them about.'"

*Attah sevavum ma'aleleihem*—surrounded by deeds.

"'They are before my face.'"

*Neged panai hayu*—before YHWH.

**The Key Verses (7:3-4):**
"'They make the king glad with their wickedness.'"

*Be-ra'atam yesammechu melekh*—king glad with wickedness.

"'The princes with their lies.'"

*U-ve-khachasheihem sarim*—princes with lies.

"'They are all adulterers, as an oven heated by the baker.'"

*Kullam mena'afim kemo tannur bo'erah me-ofeh*—like heated oven.

"'Who ceases to stir the fire, from the kneading of the dough until it be leavened.'"

*Yishbot me-ir mi-lush batzeq ad-chumtzato*—ceases to stir.

**Oven Metaphor:**
Passion smoldering, ready to burst into flame.

**The Key Verses (7:5-7):**
"'On the day of our king the princes make him sick with the heat of wine.'"

*Yom malkenu hechelu sarim chamat mi-yayin*—sick with wine.

"'He stretches out his hand with scorners.'"

*Mashakh yado et-lotzetzim*—with scorners.

"'They have made ready their heart like an oven.'"

*Ki qerevu kha-tannur libbam*—heart like oven.

"'Their baker sleeps all the night, in the morning it burns as a flaming fire.'"

*Kol-ha-laylah yashen ofeihem boqer hu vo'er ke-esh lehavah*—burns by morning.

"'They are all hot as an oven, and devour their judges.'"

*Kullam yechemu kha-tannur ve-akhelu et-shofteihem*—devour judges.

"'All their kings are fallen.'"

*Kol-malkheihem nafalu*—kings fallen.

"'There is none among them that calls unto me.'"

*Ein-qore vahem elai*—none calls.

**Foreign Alliances (7:8-16):**
**The Key Verses (7:8-9):**
"'Ephraim, he mixes himself among the peoples.'"

*Efrayim ba-ammim hu yitbolal*—mixes with nations.

"'Ephraim is a cake not turned.'"

*Efrayim hayah uggah beli hafukhah*—cake not turned.

**Uggah Beli Hafukhah:**
"Cake not turned"—burned on one side, raw on the other—half-baked.

"'Strangers have devoured his strength, and he knows it not.'"

*Akhelu zarim kocho ve-hu lo yada*—devoured unknowingly.

"'Gray hairs are here and there upon him, and he knows it not.'"

*Gam seivah zarqah bo ve-hu lo yada*—aging unaware.

**The Key Verses (7:10-11):**
"'The pride of Israel does testify to his face.'"

*Ve-anah ge'on-Yisra'el be-fanav*—pride testifies.

"'They have not returned unto YHWH their God, nor sought him.'"

*Ve-lo-shavu el-YHWH Eloheihem ve-lo viqqeshuhu be-khol-zot*—didn't return.

"'Ephraim is become like a silly dove, without understanding.'"

*Va-yehi Efrayim ke-yonah potah ein lev*—silly dove.

"'They call unto Egypt, they go to Assyria.'"

*Mitzrayim qar'u Ashur halakhu*—call Egypt, go Assyria.

**Yonah Potah:**
"Silly dove"—easily deceived, flitting between powers.

**The Key Verses (7:12-13):**
"'When they shall go, I will spread my net upon them.'"

*Ka-asher yelekhu efros aleihem rishti*—spread net.

"'I will bring them down as the fowls of the heaven.'"

*Ke-of ha-shamayim orideim*—bring down.

"'I will chastise them, as their congregation has been made to hear.'"

*Ayyissarem ke-shemu'ah la-adatam*—chastise.

"'Woe unto them! For they have strayed from me.'"

*Oy lahem ki-naddu mimmenni*—woe, strayed.

"'Destruction unto them! For they have transgressed against me.'"

*Shod lahem ki-fash'u vi*—destruction, transgressed.

"'Though I would redeem them, yet they have spoken lies against me.'"

*Ve-anokhi efdeim ve-hemmah dibberu alai kezavim*—I redeem, they lie.

**The Key Verses (7:14-16):**
"'They have not cried unto me with their heart.'"

*Ve-lo-za'aqu elai be-libbam*—not cried with heart.

"'Though they wail upon their beds.'"

*Ki yeylilu al-mishkevotam*—wail on beds.

"'For grain and wine they assemble themselves.'"

*Al-dagan ve-tirosh yitgoraru*—for grain, wine.

"'They rebel against me.'"

*Yasuru vi*—rebel.

"'Though I have trained and strengthened their arms.'"

*Va-ani yissarti chizzaqti zero'otam*—trained, strengthened.

"'Yet do they devise evil against me.'"

*Ve-elai yechashşevu ra*—devise evil.

"'They return, but not upward.'"

*Yashuvu lo al*—not upward.

"'They are become like a deceitful bow.'"

*Hayu ke-qeshet remiyyah*—deceitful bow.

"'Their princes shall fall by the sword for the rage of their tongue.'"

*Yippelu va-cherev sareihem mi-za'am leshonam*—princes fall.

"'This shall be their derision in the land of Egypt.'"

*Zo la'agam be-eretz Mitzrayim*—derision in Egypt.

**Archetypal Layer:** Hosea 7 contains **domestic corruption with the oven metaphor (7:4-7)**, **"they make the king glad with their wickedness" (7:3)**, **"all their kings are fallen; there is none among them that calls unto me" (7:7)**, **"Ephraim is a cake not turned" (7:8)**—half-baked, **"strangers have devoured his strength, and he knows it not; gray hairs are here and there upon him, and he knows it not" (7:9)**, **"Ephraim is become like a silly dove, without understanding; they call unto Egypt, they go to Assyria" (7:11)**, **"woe unto them! For they have strayed from me" (7:13)**, **"though I would redeem them, yet they have spoken lies against me" (7:13)**, and **"they are become like a deceitful bow" (7:16)**.

**Ethical Inversion Applied:**
- "'When I would heal Israel, then is the iniquity of Ephraim uncovered'"—healing reveals sin
- "'They commit falsehood'"—falsehood
- "'The thief enters in'"—thieves
- "'They consider not in their hearts that I remember all their wickedness'"—don't consider
- "'Their own doings have beset them about'"—surrounded by deeds
- "'They make the king glad with their wickedness'"—glad with wickedness
- "'The princes with their lies'"—princes lie
- "'They are all adulterers, as an oven heated by the baker'"—heated oven
- "'On the day of our king the princes make him sick with the heat of wine'"—drunk
- "'He stretches out his hand with scorners'"—with scorners
- "'They have made ready their heart like an oven'"—heart like oven
- "'They are all hot as an oven, and devour their judges'"—devour judges
- "'All their kings are fallen'"—kings fallen
- "'There is none among them that calls unto me'"—none calls
- "'Ephraim, he mixes himself among the peoples'"—mixes
- "'Ephraim is a cake not turned'"—half-baked
- "'Strangers have devoured his strength, and he knows it not'"—devoured unknowingly
- "'Gray hairs are here and there upon him, and he knows it not'"—aging unaware
- "'The pride of Israel does testify to his face'"—pride testifies
- "'They have not returned unto YHWH'"—didn't return
- "'Ephraim is become like a silly dove, without understanding'"—silly dove
- "'They call unto Egypt, they go to Assyria'"—double alliance
- "'I will spread my net upon them'"—net
- "'I will bring them down as the fowls'"—bring down
- "'Woe unto them! For they have strayed from me'"—woe
- "'Destruction unto them! For they have transgressed'"—destruction
- "'Though I would redeem them, yet they have spoken lies against me'"—lies
- "'They have not cried unto me with their heart'"—not from heart
- "'For grain and wine they assemble themselves'"—material focus
- "'They rebel against me'"—rebel
- "'Though I have trained and strengthened their arms'"—trained
- "'Yet do they devise evil against me'"—devise evil
- "'They return, but not upward'"—not upward
- "'They are become like a deceitful bow'"—deceitful bow
- "'Their princes shall fall by the sword'"—princes fall
- "'This shall be their derision in the land of Egypt'"—derision

**Modern Equivalent:** Hosea 7 uses vivid imagery. The "oven" metaphor (7:4-7) pictures smoldering passion erupting in political violence—"all their kings are fallen" (7:7). "Cake not turned" (7:8)—half-baked religion. "Silly dove" (7:11)—flitting between Egypt and Assyria. "Deceitful bow" (7:16)—misfiring when aimed. Israel is unaware of its decay—"gray hairs... and he knows it not" (7:9).

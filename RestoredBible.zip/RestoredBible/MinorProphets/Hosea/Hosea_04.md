# Hosea 4: YHWH's Controversy with Israel

*From the Hebrew: שִׁמְעוּ דְבַר־יְהוָה בְּנֵי יִשְׂרָאֵל (Shim'u Devar-YHWH Benei Yisra'el) — Hear the Word of YHWH, O Children of Israel*

---

## The Indictment (4:1-3)

**4:1** Hear the word of YHWH, you children of Israel! For YHWH has a controversy with the inhabitants of the land, because there is no truth, nor mercy, nor knowledge of God in the land.

**4:2** Swearing and lying, and killing, and stealing, and committing adultery! They break all bounds, and blood touches blood.

**4:3** Therefore does the land mourn, and every one that dwells therein does languish, with the beasts of the field, and the fowls of heaven; yea, the fishes of the sea also are taken away.

---

## The Priests' Failure (4:4-10)

**4:4** Yet let no man strive, neither let any man reprove; for your people are as they that strive with the priest.

**4:5** Therefore shall you stumble in the day, and the prophet also shall stumble with you in the night; and I will destroy your mother.

**4:6** My people are destroyed for lack of knowledge; because you have rejected knowledge, I will also reject you, that you shall be no priest to me; seeing you have forgotten the law of your God, I also will forget your children.

**4:7** The more they were increased, the more they sinned against me; I will change their glory into shame.

**4:8** They feed on the sin of my people, and set their heart on their iniquity.

**4:9** And it shall be, like people, like priest; and I will punish them for their ways, and will recompense them their doings.

**4:10** And they shall eat, and not have enough, they shall commit harlotry, and shall not increase; because they have left off to take heed to YHWH.

---

## Spirit of Harlotry (4:11-19)

**4:11** Harlotry and wine and new wine take away the heart.

**4:12** My people ask counsel at their stock, and their staff declares unto them; for the spirit of harlotry has caused them to err, and they have gone astray from under their God.

**4:13** They sacrifice upon the tops of the mountains, and offer upon the hills, under oaks and poplars and terebinths, because the shadow thereof is good; therefore your daughters commit harlotry, and your brides commit adultery.

**4:14** I will not punish your daughters when they commit harlotry, nor your brides when they commit adultery; for they themselves go apart with harlots, and they sacrifice with the harlots of the shrines; and the people that does not understand is trodden down.

**4:15** Though you, Israel, play the harlot, yet let not Judah become guilty; and come not unto Gilgal, neither go up to Beth-aven, nor swear: "As YHWH lives."

**4:16** For Israel is stubborn like a stubborn heifer; now will YHWH feed them as a lamb in a large place?

**4:17** Ephraim is joined to idols; let him alone.

**4:18** When their carouse is over, they take to harlotry; her rulers deeply love dishonour.

**4:19** The wind has bound her up in its wings; and they shall be ashamed because of their sacrifices.

---

## Synthesis Notes

**Key Restorations:**

**The Indictment (4:1-3):**
**The Key Verse (4:1):**
"'Hear the word of YHWH, you children of Israel!'"

*Shim'u devar-YHWH benei Yisra'el*—hear.

"'YHWH has a controversy with the inhabitants of the land.'"

*Ki riv la-YHWH im-yoshevei ha-aretz*—controversy/lawsuit.

**Riv:**
Legal lawsuit—YHWH as prosecutor.

"'There is no truth, nor mercy, nor knowledge of God in the land.'"

*Ki ein emet ve-ein chesed ve-ein da'at Elohim ba-aretz*—no truth, mercy, knowledge.

**The Key Verse (4:2):**
"'Swearing and lying, and killing, and stealing, and committing adultery!'"

*Aloh ve-khachesh ve-ratzoach ve-ganov ve-na'of*—5 sins.

**Five Sins:**
Echo the Ten Commandments.

"'They break all bounds, and blood touches blood.'"

*Paratzu ve-damim be-damim naga'u*—violence.

**The Key Verse (4:3):**
"'The land mourns, and every one that dwells therein does languish.'"

*Al-ken te'eval ha-aretz ve-umlal kol-yoshev bah*—land mourns.

"'With the beasts of the field, and the fowls of heaven.'"

*Be-chayyat ha-sadeh u-ve-of ha-shamayim*—beasts, birds.

"'The fishes of the sea also are taken away.'"

*Ve-gam degei ha-yam ye'asefu*—fish taken.

**Cosmic Mourning:**
Creation suffers for human sin.

**Priests' Failure (4:4-10):**
**The Key Verse (4:6):**
"'My people are destroyed for lack of knowledge.'"

*Nidmu ammi mi-beli ha-da'at*—destroyed for ignorance.

"'Because you have rejected knowledge, I will also reject you.'"

*Ki-attah ha-da'at ma'asta ve-em'asekha mi-kahhen li*—rejected.

"'That you shall be no priest to me.'"

*Mi-kahhen li*—no priest.

"'Seeing you have forgotten the law of your God.'"

*Va-tishkach torat Elohekha*—forgot Torah.

"'I also will forget your children.'"

*Eshkach banekha gam-ani*—forget children.

**The Key Verses (4:7-9):**
"'The more they were increased, the more they sinned against me.'"

*Ke-rubbam ken chat'u-li*—more = more sin.

"'I will change their glory into shame.'"

*Kevodam be-qalon amir*—glory to shame.

"'They feed on the sin of my people.'"

*Chattat ammi yokhelu*—feed on sin.

"'Set their heart on their iniquity.'"

*Ve-el-avonam yis'u nafsham*—desire iniquity.

"'Like people, like priest.'"

*Ve-hayah khe-am ka-kohen*—people like priest.

"'I will punish them for their ways.'"

*U-faqadti alav derakhav*—punish.

**The Key Verse (4:10):**
"'They shall eat, and not have enough.'"

*Ve-akhelu ve-lo yisba'u*—eat, not satisfied.

"'They shall commit harlotry, and shall not increase.'"

*Hiznu ve-lo yifrotzu*—no increase.

"'They have left off to take heed to YHWH.'"

*Ki-et-YHWH azvu lishmor*—left YHWH.

**Spirit of Harlotry (4:11-19):**
**The Key Verses (4:11-12):**
"'Harlotry and wine and new wine take away the heart.'"

*Zenut ve-yayin ve-tirosh yiqqach-lev*—take heart.

"'My people ask counsel at their stock.'"

*Ammi be-etzo yish'al*—ask wood.

"'Their staff declares unto them.'"

*U-maqlo yaggid lo*—staff divines.

"'The spirit of harlotry has caused them to err.'"

*Ki ruach zenunim hit'ah*—spirit of harlotry.

"'They have gone astray from under their God.'"

*Va-yiznu mi-tachat Eloheihem*—gone astray.

**Ruach Zenunim:**
"Spirit of harlotry"—spiritual delusion driving idolatry.

**The Key Verses (4:13-14):**
"'They sacrifice upon the tops of the mountains.'"

*Al-rashei he-harim yezabbechו*—high places.

"'Under oaks and poplars and terebinths, because the shadow thereof is good.'"

*Tachat allon ve-livneh ve-elah ki tov tzillah*—sacred trees.

"'Your daughters commit harlotry, and your brides commit adultery.'"

*Al-ken tizneinah benotekhem ve-khallotekhem tena'afenah*—daughters, brides.

"'I will not punish your daughters... for they themselves go apart with harlots.'"

*Lo-efqod al-benotekhem... ki-hem im-ha-zonot yefaredu*—men guilty too.

"'They sacrifice with the harlots of the shrines.'"

*Ve-im-ha-qedeshot yezabbechу*—cult prostitutes.

"'The people that does not understand is trodden down.'"

*Ve-am lo-yavin yillaveת*—people ruined.

**The Key Verses (4:15-17):**
"'Though you, Israel, play the harlot, yet let not Judah become guilty.'"

*Im-zoneh attah Yisra'el al-ye'sham Yehudah*—Judah warned.

"'Come not unto Gilgal, neither go up to Beth-aven.'"

*Ve-al-tavo'u ha-Gilgal ve-al-ta'alu Beit-Aven*—avoid shrines.

**Beth-Aven:**
"House of wickedness"—derogatory name for Bethel ("House of God").

"'Nor swear: As YHWH lives.'"

*Ve-al-tishShav'u chai-YHWH*—don't invoke YHWH.

"'Israel is stubborn like a stubborn heifer.'"

*Ki ke-farah sorerah sarar Yisra'el*—stubborn heifer.

"'Ephraim is joined to idols; let him alone.'"

*Chavur atzabbim Efrayim hanach-lo*—joined to idols.

**The Key Verses (4:18-19):**
"'When their carouse is over, they take to harlotry.'"

*Sar sov'am hazno hiznu*—carouse then harlotry.

"'Her rulers deeply love dishonour.'"

*Ahavu hevu qalon maginneha*—love dishonor.

"'The wind has bound her up in its wings.'"

*Tzarar ruach otah bi-khnafeyha*—wind bound.

"'They shall be ashamed because of their sacrifices.'"

*Ve-yevoshu mi-zivcheihem*—ashamed.

**Archetypal Layer:** Hosea 4 contains **the divine lawsuit (riv)**, with **"there is no truth, nor mercy, nor knowledge of God in the land" (4:1)**, **five sins echoing the Decalogue (4:2)**, **cosmic mourning (4:3)**, **"My people are destroyed for lack of knowledge" (4:6)**, **"like people, like priest" (4:9)**, **"the spirit of harlotry has caused them to err" (4:12)**, **high place worship under sacred trees (4:13)**, **cult prostitution (4:14)**, **warning to Judah (4:15)**, and **"Ephraim is joined to idols; let him alone" (4:17)**.

**Ethical Inversion Applied:**
- "'Hear the word of YHWH'"—hear
- "'YHWH has a controversy with the inhabitants of the land'"—lawsuit
- "'There is no truth, nor mercy, nor knowledge of God'"—absence
- "'Swearing and lying, and killing, and stealing, and committing adultery'"—sins
- "'They break all bounds'"—lawlessness
- "'Blood touches blood'"—violence
- "'The land mourns'"—cosmic mourning
- "'Every one that dwells therein does languish'"—all suffer
- "'The beasts of the field, and the fowls of heaven... the fishes'"—creation suffers
- "'Your people are as they that strive with the priest'"—conflict
- "'I will destroy your mother'"—destroy nation
- "'My people are destroyed for lack of knowledge'"—ignorance
- "'You have rejected knowledge'"—rejected
- "'I will also reject you'"—rejected
- "'You have forgotten the law of your God'"—forgot Torah
- "'I also will forget your children'"—forget
- "'The more they were increased, the more they sinned'"—prosperity = sin
- "'I will change their glory into shame'"—glory to shame
- "'They feed on the sin of my people'"—profit from sin
- "'Like people, like priest'"—like people
- "'They shall eat, and not have enough'"—not satisfied
- "'They have left off to take heed to YHWH'"—abandoned
- "'Harlotry and wine and new wine take away the heart'"—intoxication
- "'My people ask counsel at their stock'"—wood divination
- "'The spirit of harlotry has caused them to err'"—spirit of harlotry
- "'They have gone astray from under their God'"—astray
- "'They sacrifice upon the tops of the mountains'"—high places
- "'Under oaks and poplars and terebinths'"—sacred trees
- "'Your daughters commit harlotry'"—daughters
- "'They sacrifice with the harlots of the shrines'"—cult prostitution
- "'The people that does not understand is trodden down'"—ruined
- "'Though you, Israel, play the harlot, yet let not Judah become guilty'"—Judah warned
- "'Come not unto Gilgal, neither go up to Beth-aven'"—avoid shrines
- "'Israel is stubborn like a stubborn heifer'"—stubborn
- "'Ephraim is joined to idols; let him alone'"—joined to idols
- "'Her rulers deeply love dishonour'"—love dishonor
- "'They shall be ashamed because of their sacrifices'"—ashamed

**Modern Equivalent:** Hosea 4 begins the oracles of judgment. The divine lawsuit (riv) charges Israel with covenant violations—no truth, mercy, or knowledge of God. "My people are destroyed for lack of knowledge" (4:6) indicts priests who failed to teach Torah. "Spirit of harlotry" (4:12) names the spiritual delusion driving idolatry. "Ephraim is joined to idols; let him alone" (4:17) is divine abandonment.

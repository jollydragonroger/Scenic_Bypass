# Hosea 14: Return to YHWH

*From the Hebrew: שׁוּבָה יִשְׂרָאֵל עַד יְהוָה אֱלֹהֶיךָ (Shuvah Yisra'el Ad YHWH Elohekha) — Return, O Israel, unto YHWH Your God*

---

## Call to Repentance (14:1-3)

**14:1** Return, O Israel, unto YHWH your God; for you have stumbled in your iniquity.

**14:2** Take with you words, and return unto YHWH; say unto him: "Forgive all iniquity, and accept that which is good; so will we render for bullocks the offering of our lips.

**14:3** "Assyria shall not save us; we will not ride upon horses; neither will we call any more the work of our hands our gods; for in you the fatherless finds mercy."

---

## YHWH's Promise of Healing (14:4-8)

**14:4** I will heal their backsliding, I will love them freely; for my anger is turned away from him.

**14:5** I will be as the dew unto Israel; he shall blossom as the lily, and cast forth his roots as Lebanon.

**14:6** His branches shall spread, and his beauty shall be as the olive-tree, and his fragrance as Lebanon.

**14:7** They that dwell under his shadow shall again make grain to grow, and shall blossom as the vine; the scent thereof shall be as the wine of Lebanon.

**14:8** Ephraim shall say: "What have I to do any more with idols?" As for me, I respond and look on him; I am like a leafy cypress-tree; from me is your fruit found.

---

## Epilogue (14:9)

**14:9** Whoso is wise, let him understand these things, whoso is prudent, let him know them. For the ways of YHWH are right, and the just do walk in them; but transgressors do stumble therein.

---

## Synthesis Notes

**Key Restorations:**

**Call to Repentance (14:1-3):**
**The Key Verse (14:1):**
"'Return, O Israel, unto YHWH your God.'"

*Shuvah Yisra'el ad YHWH Elohekha*—return.

"'For you have stumbled in your iniquity.'"

*Ki khashalta ba-avonekha*—stumbled.

**The Key Verse (14:2):**
"'Take with you words, and return unto YHWH.'"

*Qechu immakhem devarim ve-shuvu el-YHWH*—take words.

"'Say unto him: Forgive all iniquity.'"

*Imru elav kol-tissa avon*—forgive.

"'Accept that which is good.'"

*Ve-qach-tov*—accept good.

"'So will we render for bullocks the offering of our lips.'"

*U-neshالlemah farim sefateinu*—lips for bulls.

**Parim Sefateinu:**
"Bullocks of our lips"—words of repentance replace animal sacrifice.

**The Key Verse (14:3):**
"'Assyria shall not save us.'"

*Ashur lo yoshi'enu*—Assyria won't save.

"'We will not ride upon horses.'"

*Al-sus lo nirkav*—no horses.

"'Neither will we call any more the work of our hands our gods.'"

*Ve-lo-nomar od Eloheinu le-ma'aseh yadeinu*—no more idols.

"'For in you the fatherless finds mercy.'"

*Asher-bekha yeruham yatom*—mercy for fatherless.

**YHWH's Promise of Healing (14:4-8):**
**The Key Verse (14:4):**
"'I will heal their backsliding.'"

*Erpa meshuvalam*—heal backsliding.

"'I will love them freely.'"

*Ohavem nedavah*—love freely.

**Nedavah:**
"Freely" / "voluntarily"—grace.

"'For my anger is turned away from him.'"

*Ki shav appi mimmennו*—anger turned.

**The Key Verses (14:5-7):**
"'I will be as the dew unto Israel.'"

*Ehyeh kha-tal le-Yisra'el*—like dew.

"'He shall blossom as the lily.'"

*Yifrach ka-shoshanah*—blossom lily.

"'Cast forth his roots as Lebanon.'"

*Ve-yakh shorashav ka-Levanon*—roots like Lebanon.

"'His branches shall spread.'"

*Yelekhu yonoqotav*—branches spread.

"'His beauty shall be as the olive-tree.'"

*Vi-yhi khe-zayit hodo*—olive beauty.

"'His fragrance as Lebanon.'"

*Ve-re'ach lo ka-Levanon*—Lebanon fragrance.

"'They that dwell under his shadow shall again make grain to grow.'"

*Yashuvu yoshevei be-tzillo yechayyu dagan*—grain grows.

"'Shall blossom as the vine.'"

*Ve-yifrechu kha-gafen*—blossom vine.

"'The scent thereof shall be as the wine of Lebanon.'"

*Zikhro ke-yein Levanon*—Lebanon wine.

**The Key Verse (14:8):**
"'Ephraim shall say: What have I to do any more with idols?'"

*Efrayim mah-li od la-atzabbim*—no more idols.

"'As for me, I respond and look on him.'"

*Ani aniti va-ashурennи*—I respond.

"'I am like a leafy cypress-tree.'"

*Ani ki-verosh ra'anan*—leafy cypress.

"'From me is your fruit found.'"

*Mimmenni peryekha nimtza*—fruit from me.

**Epilogue (14:9):**
**The Key Verse (14:9):**
"'Whoso is wise, let him understand these things.'"

*Mi chakham ve-yaven elleh*—wise understand.

"'Whoso is prudent, let him know them.'"

*Navon ve-yeda'em*—prudent know.

"'For the ways of YHWH are right.'"

*Ki-yesharim darkhei YHWH*—ways right.

"'The just do walk in them.'"

*Ve-tzaddiqim yelkhu vam*—just walk.

"'But transgressors do stumble therein.'"

*U-fosh'im yikkashlu vam*—transgressors stumble.

**Archetypal Layer:** Hosea 14 is the **hopeful conclusion**, containing **"Return, O Israel, unto YHWH your God" (14:1)**, **"Take with you words, and return unto YHWH" (14:2)**, **"so will we render for bullocks the offering of our lips" (14:2)**—words replace sacrifice, **renunciation of Assyria, horses, and idols (14:3)**, **"I will heal their backsliding, I will love them freely" (14:4)**, **"I will be as the dew unto Israel; he shall blossom as the lily" (14:5)**, **tree imagery: roots like Lebanon, beauty like olive, fragrance like Lebanon (14:5-7)**, **"Ephraim shall say: What have I to do any more with idols?" (14:8)**, **"I am like a leafy cypress-tree; from me is your fruit found" (14:8)**, and the **wisdom epilogue: "the ways of YHWH are right, and the just do walk in them" (14:9)**.

**Ethical Inversion Applied:**
- "'Return, O Israel, unto YHWH your God'"—return
- "'For you have stumbled in your iniquity'"—stumbled
- "'Take with you words, and return unto YHWH'"—words
- "'Say unto him: Forgive all iniquity'"—forgive
- "'Accept that which is good'"—accept good
- "'So will we render for bullocks the offering of our lips'"—lips for bulls
- "'Assyria shall not save us'"—no Assyria
- "'We will not ride upon horses'"—no horses
- "'Neither will we call any more the work of our hands our gods'"—no idols
- "'For in you the fatherless finds mercy'"—mercy
- "'I will heal their backsliding'"—heal
- "'I will love them freely'"—love freely
- "'For my anger is turned away from him'"—anger turned
- "'I will be as the dew unto Israel'"—like dew
- "'He shall blossom as the lily'"—blossom
- "'Cast forth his roots as Lebanon'"—roots
- "'His branches shall spread'"—branches
- "'His beauty shall be as the olive-tree'"—olive beauty
- "'His fragrance as Lebanon'"—fragrance
- "'They that dwell under his shadow shall again make grain to grow'"—grain
- "'Shall blossom as the vine'"—vine
- "'The scent thereof shall be as the wine of Lebanon'"—wine
- "'Ephraim shall say: What have I to do any more with idols?'"—no idols
- "'As for me, I respond and look on him'"—I respond
- "'I am like a leafy cypress-tree'"—cypress
- "'From me is your fruit found'"—fruit from me
- "'Whoso is wise, let him understand these things'"—wise understand
- "'For the ways of YHWH are right'"—ways right
- "'The just do walk in them'"—just walk
- "'But transgressors do stumble therein'"—stumble

**Modern Equivalent:** Hosea 14 is the book's beautiful conclusion. "Take with you words" (14:2)—repentance requires only sincere speech. "Bullocks of our lips" (14:2) anticipates Hebrews 13:15's "sacrifice of praise." The renunciation (14:3) abandons false security (Assyria, horses) and idols. YHWH's response is lavish grace—healing, love, dew, blossoming. The wisdom epilogue (14:9) frames the whole book as instruction.

# Hosea 3: Hosea Redeems Gomer

*From the Hebrew: וַיֹּאמֶר יְהוָה אֵלַי (Va-Yomer YHWH Elai) — And YHWH Said unto Me*

---

## Hosea Buys Back His Wife (3:1-3)

**3:1** And YHWH said unto me: "Go yet, love a woman beloved of her friend and an adulteress, even as YHWH loves the children of Israel, though they turn to other gods, and love cakes of raisins."

**3:2** So I bought her to me for fifteen pieces of silver, and a homer of barley, and a half-homer of barley;

**3:3** And I said unto her: "You shall sit solitary for me many days; you shall not play the harlot, and you shall not be any man's wife; nor will I be unto you."

---

## The Interpretation (3:4-5)

**3:4** For the children of Israel shall sit solitary many days without king, and without prince, and without sacrifice, and without pillar, and without ephod or teraphim;

**3:5** Afterward shall the children of Israel return, and seek YHWH their God, and David their king; and shall come trembling unto YHWH and to his goodness in the end of days.

---

## Synthesis Notes

**Key Restorations:**

**Hosea Buys Back His Wife (3:1-3):**
**The Key Verse (3:1):**
"'Go yet, love a woman beloved of her friend and an adulteress.'"

*Lekh od ehav ishah ahuvat re'a u-mena'afet*—love adulteress.

"'Even as YHWH loves the children of Israel.'"

*Ke-ahavat YHWH et-benei Yisra'el*—as YHWH loves Israel.

"'Though they turn to other gods.'"

*Ve-hem ponim el-elohim acherim*—turn to other gods.

"'And love cakes of raisins.'"

*Ve-ohavei ashishei anavim*—love raisin cakes.

**Ashishei Anavim:**
"Raisin cakes"—associated with Canaanite fertility rituals.

**The Key Verse (3:2):**
"I bought her to me for fifteen pieces of silver."

*Va-ekkereha li ba-chamishah asar kasef*—15 silver.

"A homer of barley, and a half-homer of barley."

*Ve-chomer se'orim ve-lethekh se'orim*—1½ homer barley.

**Purchase Price:**
15 shekels + 1½ homer barley = approximately 30 shekels (slave's price, Exodus 21:32).

**The Key Verse (3:3):**
"'You shall sit solitary for me many days.'"

*Yamim rabbim teshevi li*—sit many days.

"'You shall not play the harlot.'"

*Lo tizneh*—no harlotry.

"'You shall not be any man's wife.'"

*Ve-lo tihyi le-ish*—no husband.

"'Nor will I be unto you.'"

*Ve-gam-ani elayikh*—nor I to you.

**Period of Discipline:**
No marital intimacy—a time of waiting and purification.

**The Interpretation (3:4-5):**
**The Key Verse (3:4):**
"'The children of Israel shall sit solitary many days.'"

*Ki yamim rabbim yeshbu benei Yisra'el*—sit many days.

"'Without king, and without prince.'"

*Ein melekh ve-ein sar*—no king, prince.

"'Without sacrifice.'"

*Ve-ein zevach*—no sacrifice.

"'Without pillar.'"

*Ve-ein matztzevah*—no sacred pillar.

"'Without ephod or teraphim.'"

*Ve-ein efod u-terafim*—no ephod, teraphim.

**National Deprivation:**
Israel will lose both legitimate worship (sacrifice, ephod) and illegitimate (pillar, teraphim).

**The Key Verse (3:5):**
"'Afterward shall the children of Israel return.'"

*Achar yashuvu benei Yisra'el*—return.

"'And seek YHWH their God.'"

*U-viqqeshu et-YHWH Eloheihem*—seek YHWH.

"'And David their king.'"

*Ve-et David malkam*—David their king.

**David:**
Messianic—the Davidic ruler to come.

"'Shall come trembling unto YHWH and to his goodness.'"

*U-fachadu el-YHWH ve-el-tuvo*—trembling.

"'In the end of days.'"

*Be-acharit ha-yamim*—end of days.

**Archetypal Layer:** Hosea 3 is the **redemption chapter**, containing **"Go yet, love a woman... an adulteress, even as YHWH loves the children of Israel" (3:1)**, **Hosea buys Gomer for 15 silver + 1½ homer barley = slave's price (3:2)**, **"You shall sit solitary for me many days" (3:3)**—period of discipline, **Israel's deprivation: "without king, and without prince, and without sacrifice, and without pillar, and without ephod or teraphim" (3:4)**, and **restoration: "Afterward shall the children of Israel return, and seek YHWH their God, and David their king... in the end of days" (3:5)**.

**Ethical Inversion Applied:**
- "'Go yet, love a woman beloved of her friend and an adulteress'"—love adulteress
- "'Even as YHWH loves the children of Israel'"—YHWH's love
- "'Though they turn to other gods'"—unfaithful
- "'And love cakes of raisins'"—pagan rituals
- "I bought her to me for fifteen pieces of silver"—purchased
- "A homer of barley, and a half-homer of barley"—barley
- "'You shall sit solitary for me many days'"—waiting period
- "'You shall not play the harlot'"—no harlotry
- "'You shall not be any man's wife'"—no husband
- "'Nor will I be unto you'"—no intimacy
- "'The children of Israel shall sit solitary many days'"—national discipline
- "'Without king, and without prince'"—no monarchy
- "'Without sacrifice'"—no worship
- "'Without pillar'"—no pagan objects
- "'Without ephod or teraphim'"—no divination
- "'Afterward shall the children of Israel return'"—return
- "'And seek YHWH their God'"—seek YHWH
- "'And David their king'"—messianic king
- "'Shall come trembling unto YHWH'"—trembling
- "'And to his goodness'"—goodness
- "'In the end of days'"—eschatological

**Modern Equivalent:** Hosea 3 is remarkably brief but profound. Hosea buys back his adulterous wife—love that pursues despite betrayal. The slave's price (30 shekels equivalent) foreshadows redemption. The "many days" without king, sacrifice, or worship describes exile. "David their king" points to messianic restoration "in the end of days."

# Hosea 11: YHWH's Love for Israel

*From the Hebrew: כִּי נַעַר יִשְׂרָאֵל וָאֹהֲבֵהוּ (Ki Na'ar Yisra'el Va-Ohavehu) — When Israel Was a Child, Then I Loved Him*

---

## YHWH's Paternal Love (11:1-4)

**11:1** When Israel was a child, then I loved him, and out of Egypt I called my son.

**11:2** The more they called them, the more they went from them; they sacrificed unto the Baalim, and offered to graven images.

**11:3** And I, I taught Ephraim to walk, I took them on my arms; but they knew not that I healed them.

**11:4** I drew them with cords of a man, with bands of love; and I was to them as they that lift up the yoke on their jaws; and I fed them gently.

---

## Judgment for Rebellion (11:5-7)

**11:5** He shall not return into the land of Egypt, but the Assyrian shall be his king, because they refused to return.

**11:6** And the sword shall fall upon his cities, and shall consume his bars, and devour them, because of their own counsels.

**11:7** And my people are bent on turning away from me; though they call them upward, none at all will lift himself up.

---

## YHWH's Compassion (11:8-11)

**11:8** How shall I give you up, Ephraim? How shall I surrender you, Israel? How shall I make you as Admah? How shall I set you as Zeboiim? My heart is turned within me, my compassions are kindled together.

**11:9** I will not execute the fierceness of my anger, I will not return to destroy Ephraim; for I am God, and not man, the Holy One in the midst of you; and I will not come in fury.

**11:10** They shall walk after YHWH, who shall roar like a lion; for he shall roar, and the children shall come trembling from the west.

**11:11** They shall come trembling as a bird out of Egypt, and as a dove out of the land of Assyria; and I will make them to dwell in their houses, says YHWH.

---

## Synthesis Notes

**Key Restorations:**

**YHWH's Paternal Love (11:1-4):**
**The Key Verse (11:1):**
"'When Israel was a child, then I loved him.'"

*Ki na'ar Yisra'el va-ohavehu*—loved as child.

"'Out of Egypt I called my son.'"

*U-mi-Mitzrayim qarati li-veni*—called from Egypt.

**Out of Egypt:**
Matthew 2:15 applies this to Jesus.

**The Key Verse (11:2):**
"'The more they called them, the more they went from them.'"

*Qar'u lahem ken halekhu mi-peneihem*—called, they departed.

"'They sacrificed unto the Baalim.'"

*La-be'alim yezabbechו*—to Baals.

"'Offered to graven images.'"

*Ve-la-pesilim yequatteru*—graven images.

**The Key Verse (11:3):**
"'I, I taught Ephraim to walk.'"

*Ve-anokhi tirgalti le-Efrayim*—taught to walk.

"'I took them on my arms.'"

*Qacham al-zero'otav*—on arms.

"'They knew not that I healed them.'"

*Ve-lo yade'u ki refa'tim*—didn't know healing.

**The Key Verse (11:4):**
"'I drew them with cords of a man, with bands of love.'"

*Be-chavlei adam emshekhem ba-avotot ahavah*—cords of love.

"'I was to them as they that lift up the yoke on their jaws.'"

*Va-ehyeh lahem ki-merimei ol al lecheihem*—lifted yoke.

"'I fed them gently.'"

*Ve-at elav okhil*—fed gently.

**Paternal Imagery:**
YHWH as parent teaching a child to walk.

**Judgment for Rebellion (11:5-7):**
**The Key Verses (11:5-7):**
"'He shall not return into the land of Egypt.'"

*Lo yashuv el-eretz Mitzrayim*—not to Egypt.

"'But the Assyrian shall be his king.'"

*Ve-Ashur hu malko*—Assyria king.

"'Because they refused to return.'"

*Ki me'anu lashuv*—refused return.

"'The sword shall fall upon his cities.'"

*Ve-chalah cherev be-arav*—sword falls.

"'Shall consume his bars, and devour them.'"

*Ve-khilleta baddav ve-akhalah*—consume.

"'Because of their own counsels.'"

*Mi-mo'atzoteihem*—their counsels.

"'My people are bent on turning away from me.'"

*Ve-ammi telu'im li-mshuvati*—bent on turning.

"'Though they call them upward, none at all will lift himself up.'"

*Ve-el-al yiqra'uhu yachad lo yeromem*—none lifts up.

**YHWH's Compassion (11:8-11):**
**The Key Verse (11:8):**
"'How shall I give you up, Ephraim?'"

*Eikh ettenekha Efrayim*—how give up?

"'How shall I surrender you, Israel?'"

*Amaggenekha Yisra'el*—how surrender?

"'How shall I make you as Admah?'"

*Eikh ettenekha khe-Admah*—like Admah.

"'How shall I set you as Zeboiim?'"

*Asimekha ki-Tzevoyim*—like Zeboiim.

**Admah and Zeboiim:**
Cities destroyed with Sodom and Gomorrah (Deuteronomy 29:23).

"'My heart is turned within me.'"

*Nehpakh alai libbi*—heart turned.

"'My compassions are kindled together.'"

*Yachad nikhmeru nichumay*—compassions kindled.

**The Key Verse (11:9):**
"'I will not execute the fierceness of my anger.'"

*Lo e'eseh charon appi*—not fierce anger.

"'I will not return to destroy Ephraim.'"

*Lo ashuv le-shachet Efrayim*—not destroy.

"'For I am God, and not man.'"

*Ki El anokhi ve-lo-ish*—God not man.

"'The Holy One in the midst of you.'"

*Be-qirbeka qadosh*—Holy One in midst.

"'I will not come in fury.'"

*Ve-lo avo be-ir*—not in fury.

**El Anokhi Ve-Lo-Ish:**
"I am God and not man"—divine love transcends human limits.

**The Key Verses (11:10-11):**
"'They shall walk after YHWH, who shall roar like a lion.'"

*Acharei YHWH yelekhu ke-aryeh yish'ag*—roar like lion.

"'The children shall come trembling from the west.'"

*Yecherdu vanim mi-yam*—from west.

"'They shall come trembling as a bird out of Egypt.'"

*Yecherdu khe-tzippor mi-Mitzrayim*—like bird from Egypt.

"'As a dove out of the land of Assyria.'"

*Ukhe-yonah me-eretz Ashur*—dove from Assyria.

"'I will make them to dwell in their houses.'"

*Ve-hoshabtim al-bateihem*—dwell in houses.

**Archetypal Layer:** Hosea 11 is the **most tender chapter**, containing **"When Israel was a child, then I loved him, and out of Egypt I called my son" (11:1)**—quoted in Matthew 2:15, **"I taught Ephraim to walk, I took them on my arms" (11:3)**, **"I drew them with cords of a man, with bands of love" (11:4)**, **"How shall I give you up, Ephraim?" (11:8)**, **"My heart is turned within me, my compassions are kindled together" (11:8)**, **"I will not execute the fierceness of my anger" (11:9)**, **"for I am God, and not man, the Holy One in the midst of you" (11:9)**, and **restoration: "they shall come trembling as a bird out of Egypt, and as a dove out of the land of Assyria" (11:11)**.

**Ethical Inversion Applied:**
- "'When Israel was a child, then I loved him'"—loved as child
- "'Out of Egypt I called my son'"—Exodus
- "'The more they called them, the more they went from them'"—departed
- "'They sacrificed unto the Baalim'"—to Baals
- "'I, I taught Ephraim to walk'"—taught to walk
- "'I took them on my arms'"—on arms
- "'They knew not that I healed them'"—didn't know
- "'I drew them with cords of a man, with bands of love'"—cords of love
- "'I was to them as they that lift up the yoke on their jaws'"—lifted yoke
- "'I fed them gently'"—fed gently
- "'He shall not return into the land of Egypt'"—not to Egypt
- "'The Assyrian shall be his king'"—Assyria
- "'Because they refused to return'"—refused
- "'The sword shall fall upon his cities'"—sword
- "'My people are bent on turning away from me'"—bent on turning
- "'None at all will lift himself up'"—none lifts
- "'How shall I give you up, Ephraim?'"—divine struggle
- "'How shall I surrender you, Israel?'"—divine struggle
- "'How shall I make you as Admah?'"—like destroyed cities
- "'How shall I set you as Zeboiim?'"—like destroyed cities
- "'My heart is turned within me'"—heart turned
- "'My compassions are kindled together'"—compassions kindled
- "'I will not execute the fierceness of my anger'"—not fierce
- "'I will not return to destroy Ephraim'"—not destroy
- "'For I am God, and not man'"—God not man
- "'The Holy One in the midst of you'"—Holy One
- "'I will not come in fury'"—not fury
- "'They shall walk after YHWH, who shall roar like a lion'"—like lion
- "'The children shall come trembling from the west'"—from west
- "'They shall come trembling as a bird out of Egypt'"—from Egypt
- "'As a dove out of the land of Assyria'"—from Assyria
- "'I will make them to dwell in their houses'"—dwell

**Modern Equivalent:** Hosea 11 is profoundly tender. YHWH as parent teaching a toddler to walk (11:3), drawing with "cords of love" (11:4). The anguished questions (11:8) show divine love wrestling with justice. "I am God, and not man" (11:9)—human parents might abandon; God's love transcends. Matthew 2:15 quotes 11:1 for Jesus's Egypt flight.

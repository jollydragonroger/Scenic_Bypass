# Micah 6: What Does YHWH Require?

*From the Hebrew: שִׁמְעוּ־נָא אֵת אֲשֶׁר יְהוָה אֹמֵר (Shim'u-Na Et Asher YHWH Omer) — Hear Now What YHWH Says*

---

## YHWH's Lawsuit (6:1-5)

**6:1** Hear now what YHWH says: Arise, contend before the mountains, and let the hills hear your voice.

**6:2** Hear, O mountains, YHWH's controversy, and you enduring rocks, the foundations of the earth; for YHWH has a controversy with his people, and he will plead with Israel.

**6:3** O my people, what have I done unto you? And wherein have I wearied you? Testify against me.

**6:4** For I brought you up out of the land of Egypt, and redeemed you out of the house of bondage, and I sent before you Moses, Aaron, and Miriam.

**6:5** O my people, remember now what Balak king of Moab devised, and what Balaam the son of Beor answered him; from Shittim unto Gilgal, that you may know the righteous acts of YHWH.

---

## What YHWH Requires (6:6-8)

**6:6** "Wherewith shall I come before YHWH, and bow myself before God on high? Shall I come before him with burnt-offerings, with calves of a year old?

**6:7** "Will YHWH be pleased with thousands of rams, with ten thousands of rivers of oil? Shall I give my first-born for my transgression, the fruit of my body for the sin of my soul?"

**6:8** It has been told you, O man, what is good, and what YHWH does require of you: only to do justly, and to love mercy, and to walk humbly with your God.

---

## Indictment of the City (6:9-16)

**6:9** The voice of YHWH cries unto the city—and it is sound wisdom to see your name—hear the rod, and who has appointed it.

**6:10** Are there yet the treasures of wickedness in the house of the wicked, and the scant measure that is abominable?

**6:11** "Shall I be pure with wicked balances, and with a bag of deceitful weights?"

**6:12** For the rich men thereof are full of violence, and the inhabitants thereof have spoken lies, and their tongue is deceitful in their mouth.

**6:13** Therefore I also do smite you with a grievous wound; I make you desolate because of your sins.

**6:14** You shall eat, but not be satisfied; and your hollowness shall be in the midst of you; and you shall take hold, but shall not save; and that which you save will I give up to the sword.

**6:15** You shall sow, but shall not reap; you shall tread the olives, but shall not anoint yourself with oil; and the vintage, but shall not drink wine.

**6:16** For the statutes of Omri are kept, and all the works of the house of Ahab, and you walk in their counsels; that I may make you a desolation, and the inhabitants thereof a hissing; and you shall bear the reproach of my people.

---

## Synthesis Notes

**Key Restorations:**

**YHWH's Lawsuit (6:1-5):**
**The Key Verses (6:1-2):**
"'Hear now what YHWH says.'"

*Shim'u-na et asher YHWH omer*—hear.

"'Arise, contend before the mountains.'"

*Qum riv et-he-harim*—contend.

"'Let the hills hear your voice.'"

*Ve-tishma'nah ha-geva'ot qolekha*—hills hear.

"'Hear, O mountains, YHWH's controversy.'"

*Shim'u harim et-riv YHWH*—mountains hear.

"'You enduring rocks, the foundations of the earth.'"

*Ve-ha-etanim moседei aretz*—enduring foundations.

"'YHWH has a controversy with his people.'"

*Ki riv la-YHWH im-ammo*—lawsuit.

"'He will plead with Israel.'"

*Ve-im-Yisra'el yitvakkach*—plead.

**The Key Verses (6:3-5):**
"'O my people, what have I done unto you?'"

*Ammi meh-asiti lakh*—what have I done?

"'Wherein have I wearied you?'"

*U-mah hel'etikha*—wearied you?

"'Testify against me.'"

*Aneh bi*—testify.

"'I brought you up out of the land of Egypt.'"

*Ki he'elitikha me-eretz Mitzrayim*—Exodus.

"'Redeemed you out of the house of bondage.'"

*U-mi-beit avadim peditikha*—redeemed.

"'I sent before you Moses, Aaron, and Miriam.'"

*Va-eshlach lefanekha et-Mosheh Aharon u-Miryam*—Moses, Aaron, Miriam.

"'Remember now what Balak king of Moab devised.'"

*Ammi zekhor-na mah-ya'atz Balaq melekh Mo'av*—Balak.

"'What Balaam the son of Beor answered him.'"

*U-meh-anah oto Bil'am ben-Be'or*—Balaam.

"'From Shittim unto Gilgal.'"

*Min-ha-Shittim ad-ha-Gilgal*—Shittim to Gilgal.

"'That you may know the righteous acts of YHWH.'"

*Lema'an da'at tzidqot YHWH*—righteous acts.

**What YHWH Requires (6:6-8):**
**The Key Verses (6:6-7):**
"''Wherewith shall I come before YHWH?''"

*Ba-mah aqaddem YHWH*—how approach?

"''Bow myself before God on high?''"

*Ikkaf le-Elohei marom*—bow.

"''Shall I come before him with burnt-offerings?''"

*Ha-aqadmennu ve-olot*—burnt offerings?

"''With calves of a year old?''"

*Ba-agalim benei shanah*—yearling calves?

"''Will YHWH be pleased with thousands of rams?''"

*Ha-yirtzeh YHWH be-alfei eilim*—thousands of rams?

"''With ten thousands of rivers of oil?''"

*Be-rivevot nachalei-shamen*—rivers of oil?

"''Shall I give my first-born for my transgression?''"

*Ha-etten bekhori pish'i*—firstborn?

"''The fruit of my body for the sin of my soul?''"

*Peri vitni chattat nafshi*—fruit of body?

**The Key Verse (6:8):**
"'It has been told you, O man, what is good.'"

*Higgid lekha adam mah-tov*—told you.

"'What YHWH does require of you.'"

*U-mah-YHWH doresh mimmekha*—YHWH requires.

"'Only to do justly.'"

*Ki im-asot mishpat*—do justice.

"'To love mercy.'"

*Ve-ahavat chesed*—love mercy.

"'To walk humbly with your God.'"

*Ve-hatzne'a lekhet im-Elohekha*—walk humbly.

**The Famous Verse:**
One of the Bible's most quoted ethical summaries.

**Indictment of the City (6:9-16):**
**The Key Verses (6:9-12):**
"'The voice of YHWH cries unto the city.'"

*Qol YHWH la-ir yiqra*—voice to city.

"'It is sound wisdom to see your name.'"

*Ve-tushiyyah yir'eh shemekha*—wisdom.

"'Hear the rod, and who has appointed it.'"

*Shim'u matteh u-mi ye'adah*—hear rod.

"'Are there yet the treasures of wickedness in the house of the wicked?'"

*Ha-od beit rasha otzrot resha*—treasures of wickedness?

"'The scant measure that is abominable?'"

*Ve-eifat razon ze'umah*—scant measure.

"''Shall I be pure with wicked balances?''"

*Ha-ezkeh be-moznei resha*—wicked balances?

"''With a bag of deceitful weights?''"

*U-ve-khis avnei mirmah*—deceitful weights.

"'The rich men thereof are full of violence.'"

*Asher ashireiha male'u chamas*—rich full of violence.

"'The inhabitants thereof have spoken lies.'"

*Ve-yosheveiha dibberu shaqer*—lies.

"'Their tongue is deceitful in their mouth.'"

*U-leshonam remiyyah be-fihem*—deceitful tongue.

**The Key Verses (6:13-16):**
"'I also do smite you with a grievous wound.'"

*Ve-gam-ani hecheleti hakkoteka*—smite.

"'I make you desolate because of your sins.'"

*Hashem al-chattotekha*—desolate.

"'You shall eat, but not be satisfied.'"

*Attah tokhal ve-lo tisba*—eat, not satisfied.

"'Your hollowness shall be in the midst of you.'"

*Ve-yeshchakha be-qirbeka*—hollowness.

"'You shall take hold, but shall not save.'"

*Ve-tasseg ve-lo taflit*—not save.

"'That which you save will I give up to the sword.'"

*Va-asher taflit la-cherev etten*—to sword.

"'You shall sow, but shall not reap.'"

*Attah tizra ve-lo tiqtzor*—sow, not reap.

"'You shall tread the olives, but shall not anoint yourself with oil.'"

*Attah tidrokh-zayit ve-lo-tasukh shemen*—tread, not anoint.

"'The vintage, but shall not drink wine.'"

*Ve-tirosh ve-lo tishteh-yayin*—vintage, no wine.

"'The statutes of Omri are kept.'"

*Ve-yishtammer chuqqot Omri*—Omri's statutes.

"'All the works of the house of Ahab.'"

*Ve-khol ma'aseh veit-Achav*—Ahab's works.

"'You walk in their counsels.'"

*Va-telekhu be-mo'atzotam*—walk in counsels.

"'That I may make you a desolation.'"

*Lema'an titti otkha le-shammah*—desolation.

"'The inhabitants thereof a hissing.'"

*Ve-yosheveiha li-shereqah*—hissing.

"'You shall bear the reproach of my people.'"

*Ve-cherpat ammi tissa'u*—bear reproach.

**Archetypal Layer:** Micah 6 contains **YHWH's lawsuit with mountains as witnesses (6:1-2)**, **"O my people, what have I done unto you? Wherein have I wearied you?" (6:3)**, **recounting salvation history: Exodus, Moses, Aaron, Miriam, Balak, Balaam (6:4-5)**, **the worshiper's question: "Wherewith shall I come before YHWH?" (6:6)**, **escalating offerings: burnt offerings, calves, thousands of rams, rivers of oil, even firstborn (6:6-7)**, **"It has been told you, O man, what is good... only to do justly, and to love mercy, and to walk humbly with your God" (6:8)**, **indictment: treasures of wickedness, scant measures, wicked balances, violence, lies (6:9-12)**, and **futility curses: eat but not satisfied, sow but not reap (6:14-15)**.

**Ethical Inversion Applied:**
- "'Hear now what YHWH says'"—hear
- "'Arise, contend before the mountains'"—mountains witness
- "'Let the hills hear your voice'"—hills hear
- "'YHWH has a controversy with his people'"—lawsuit
- "'O my people, what have I done unto you?'"—what have I done?
- "'Wherein have I wearied you?'"—wearied
- "'Testify against me'"—testify
- "'I brought you up out of the land of Egypt'"—Exodus
- "'Redeemed you out of the house of bondage'"—redeemed
- "'I sent before you Moses, Aaron, and Miriam'"—leaders
- "'Remember now what Balak... devised'"—Balak
- "'What Balaam... answered him'"—Balaam
- "'That you may know the righteous acts of YHWH'"—righteous acts
- "''Wherewith shall I come before YHWH?''"—how approach
- "''Shall I come before him with burnt-offerings?''"—offerings
- "''With calves of a year old?''"—calves
- "''Will YHWH be pleased with thousands of rams?''"—rams
- "''With ten thousands of rivers of oil?''"—oil
- "''Shall I give my first-born for my transgression?''"—firstborn
- "'It has been told you, O man, what is good'"—told
- "'What YHWH does require of you'"—requires
- "'Only to do justly'"—do justice
- "'To love mercy'"—love mercy
- "'To walk humbly with your God'"—walk humbly
- "'The voice of YHWH cries unto the city'"—voice to city
- "'Are there yet the treasures of wickedness?'"—treasures of wickedness
- "'The scant measure that is abominable?'"—scant measure
- "''Shall I be pure with wicked balances?''"—wicked balances
- "'The rich men thereof are full of violence'"—violence
- "'The inhabitants thereof have spoken lies'"—lies
- "'I also do smite you with a grievous wound'"—smite
- "'You shall eat, but not be satisfied'"—not satisfied
- "'You shall sow, but shall not reap'"—not reap
- "'The statutes of Omri are kept'"—Omri's statutes
- "'All the works of the house of Ahab'"—Ahab's works
- "'That I may make you a desolation'"—desolation

**Modern Equivalent:** Micah 6:8 is one of Scripture's most famous verses. The divine lawsuit (6:1-5) asks what YHWH has done wrong—nothing! The worshiper's question (6:6-7) escalates offerings absurdly: calves, thousands of rams, rivers of oil, even child sacrifice. The answer (6:8) cuts through ritual: "do justly, love mercy, walk humbly." The indictment (6:9-16) shows they've done the opposite.

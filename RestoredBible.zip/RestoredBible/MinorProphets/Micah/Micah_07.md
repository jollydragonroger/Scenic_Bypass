# Micah 7: From Lament to Hope

*From the Hebrew: אַלְלַי לִי (Allai Li) — Woe Is Me*

---

## Lament over Corruption (7:1-6)

**7:1** Woe is me! For I am as when the summer fruits have been gathered, as when the vintage grapes have been gleaned; there is no cluster to eat, nor first-ripe fig which my soul desires.

**7:2** The godly man is perished out of the earth, and the upright among men is no more; they all lie in wait for blood; they hunt every man his brother with a net.

**7:3** Their hands are upon that which is evil to do it diligently; the prince asks, and the judge is ready for a reward; and the great man, he utters the evil desire of his soul; thus they weave it together.

**7:4** The best of them is as a brier; the most upright is worse than a thorn hedge; the day of your watchmen, even your visitation, is come; now shall be their perplexity.

**7:5** Trust not in a friend, put no confidence in a familiar friend; keep the doors of your mouth from her that lies in your bosom.

**7:6** For the son dishonours the father, the daughter rises up against her mother, the daughter-in-law against her mother-in-law; a man's enemies are the men of his own house.

---

## Confidence in YHWH (7:7-13)

**7:7** But as for me, I will look unto YHWH; I will wait for the God of my salvation; my God will hear me.

**7:8** Rejoice not against me, O my enemy; though I am fallen, I shall arise; though I sit in darkness, YHWH shall be a light unto me.

**7:9** I will bear the indignation of YHWH, because I have sinned against him; until he plead my cause, and execute judgment for me; he will bring me forth to the light, and I shall behold his righteousness.

**7:10** Then my enemy shall see it, and shame shall cover her, who said unto me: "Where is YHWH your God?" My eyes shall gaze upon her; now shall she be trodden down as the mire of the streets.

**7:11** A day for building your walls! In that day shall the decree be far removed.

**7:12** In that day shall they come unto you, from Assyria even to Egypt, and from Egypt even to the River, and from sea to sea, and from mountain to mountain.

**7:13** And the earth shall be desolate because of them that dwell therein, for the fruit of their doings.

---

## Prayer and Promise (7:14-20)

**7:14** Shepherd your people with your rod, the flock of your heritage, that dwell solitarily, in the wood, in the midst of Carmel; let them feed in Bashan and Gilead, as in the days of old.

**7:15** As in the days of your coming forth out of the land of Egypt will I show unto them marvellous things.

**7:16** The nations shall see and be put to shame for all their might; they shall lay their hand upon their mouth, their ears shall be deaf.

**7:17** They shall lick the dust like a serpent; like crawling things of the earth they shall come trembling out of their close places; they shall come with fear unto YHWH our God, and shall be afraid of you.

**7:18** Who is a God like unto you, that pardons iniquity, and passes by the transgression of the remnant of his heritage? He retains not his anger for ever, because he delights in mercy.

**7:19** He will again have compassion upon us; he will tread our iniquities under foot; and you will cast all their sins into the depths of the sea.

**7:20** You will show faithfulness to Jacob, mercy to Abraham, as you have sworn unto our fathers from the days of old.

---

## Synthesis Notes

**Key Restorations:**

**Lament over Corruption (7:1-6):**
**The Key Verses (7:1-2):**
"'Woe is me!'"

*Allai li*—woe.

"'I am as when the summer fruits have been gathered.'"

*Ki hayiti ke-ospei qayitz*—like gleaned harvest.

"'As when the vintage grapes have been gleaned.'"

*Ke-olelot batzir*—vintage gleaned.

"'There is no cluster to eat.'"

*Ein eshkol le'ekhol*—no cluster.

"'Nor first-ripe fig which my soul desires.'"

*Bikkurah ivvetah nafshi*—no early fig.

"'The godly man is perished out of the earth.'"

*Avad chasid min-ha-aretz*—godly perished.

"'The upright among men is no more.'"

*Ve-yashar ba-adam ayin*—upright gone.

"'They all lie in wait for blood.'"

*Kullam le-damim ye'erovu*—wait for blood.

"'They hunt every man his brother with a net.'"

*Ish et-achiv yatzudu cherem*—hunt brother.

**The Key Verses (7:3-4):**
"'Their hands are upon that which is evil to do it diligently.'"

*Al-ha-ra kappayim le-heitiv*—hands on evil.

"'The prince asks, and the judge is ready for a reward.'"

*Ha-sar sho'el ve-ha-shofet ba-shillum*—prince asks, judge for reward.

"'The great man, he utters the evil desire of his soul.'"

*Ve-ha-gadol dover havvat nafsho*—great man's evil desire.

"'Thus they weave it together.'"

*Va-ye'abbtuha*—weave together.

"'The best of them is as a brier.'"

*Tovam ke-chédek*—best as brier.

"'The most upright is worse than a thorn hedge.'"

*Yashar mi-mesukhah*—upright as thorns.

"'The day of your watchmen, even your visitation, is come.'"

*Yom metzappekha pequddatekha va'ah*—visitation comes.

"'Now shall be their perplexity.'"

*Attah tihyeh mevukhatam*—perplexity.

**The Key Verses (7:5-6):**
"'Trust not in a friend.'"

*Al-ta'aminu ve-re'a*—don't trust friend.

"'Put no confidence in a familiar friend.'"

*Al-tivtechu be-alluf*—no confidence.

"'Keep the doors of your mouth from her that lies in your bosom.'"

*Mi-shوkhevet cheiqekha shemor pitchei-fikha*—guard speech.

"'The son dishonours the father.'"

*Ki-ven menabbel av*—son dishonors.

"'The daughter rises up against her mother.'"

*Bat qamah ve-immah*—daughter against mother.

"'The daughter-in-law against her mother-in-law.'"

*Kallah ba-chamotah*—daughter-in-law against mother-in-law.

"'A man's enemies are the men of his own house.'"

*Oyevei ish anshei veito*—enemies in house.

**Quoted by Jesus:**
Matthew 10:35-36 quotes this verse.

**Confidence in YHWH (7:7-13):**
**The Key Verses (7:7-10):**
"'But as for me, I will look unto YHWH.'"

*Va-ani be-YHWH atzappeh*—look to YHWH.

"'I will wait for the God of my salvation.'"

*Ochilah le-Elohei yish'i*—wait for God.

"'My God will hear me.'"

*Yishma'eni Elohai*—God hears.

"'Rejoice not against me, O my enemy.'"

*Al-tismachi oyavti li*—don't rejoice.

"'Though I am fallen, I shall arise.'"

*Ki nafalti qamti*—fallen, arise.

"'Though I sit in darkness, YHWH shall be a light unto me.'"

*Ki-eshev ba-choshekh YHWH or li*—YHWH is light.

"'I will bear the indignation of YHWH.'"

*Za'af YHWH essa*—bear indignation.

"'Because I have sinned against him.'"

*Ki chata'ti lo*—sinned.

"'Until he plead my cause, and execute judgment for me.'"

*Ad asher yariv rivi ve-asah mishpati*—plead cause.

"'He will bring me forth to the light.'"

*Yotzi'eni la-or*—bring to light.

"'I shall behold his righteousness.'"

*Er'eh be-tzidqato*—see righteousness.

"'Then my enemy shall see it, and shame shall cover her.'"

*Ve-tere oyavti u-tekhassehah bushah*—enemy shamed.

"''Where is YHWH your God?''"

*Ayyeh YHWH Elohayikh*—where is God?

"'Now shall she be trodden down as the mire of the streets.'"

*Attah tihyeh le-mirmas ke-tit chutzot*—trodden down.

**The Key Verses (7:11-13):**
"'A day for building your walls!'"

*Yom livnot gederayikh*—building walls.

"'In that day shall the decree be far removed.'"

*Yom ha-hu yirchaq-choq*—decree removed.

"'In that day shall they come unto you, from Assyria even to Egypt.'"

*Yom hu ve-adekha yavo le-mini Ashur ve-arei Matzor*—from Assyria to Egypt.

"'From Egypt even to the River.'"

*U-le-mini Matzor ve-ad-nahar*—to River.

"'From sea to sea, and from mountain to mountain.'"

*Ve-yam mi-yam ve-har ha-har*—sea to sea.

"'The earth shall be desolate because of them that dwell therein.'"

*Ve-hayetah ha-aretz li-shemamah al-yoshveiha*—desolate.

"'For the fruit of their doings.'"

*Mi-peri ma'aleleihem*—fruit of doings.

**Prayer and Promise (7:14-20):**
**The Key Verses (7:14-17):**
"'Shepherd your people with your rod.'"

*Re'eh ammekha ve-shivtekha*—shepherd.

"'The flock of your heritage.'"

*Tzon nachalatekha*—heritage flock.

"'That dwell solitarily, in the wood, in the midst of Carmel.'"

*Shokhenei levadad ya'ar be-tokh Karmel*—Carmel.

"'Let them feed in Bashan and Gilead, as in the days of old.'"

*Yir'u Vashan ve-Gil'ad ki-yemei olam*—Bashan, Gilead.

"'As in the days of your coming forth out of the land of Egypt will I show unto them marvellous things.'"

*Ki-yemei tzetekha me-eretz Mitzrayim ar'ennu nifla'ot*—marvelous things.

"'The nations shall see and be put to shame for all their might.'"

*Yir'u goyim ve-yevoshu mi-kol gevuratam*—nations shamed.

"'They shall lay their hand upon their mouth.'"

*Yasimu yad al-peh*—hand on mouth.

"'Their ears shall be deaf.'"

*Ozneihem techershנah*—ears deaf.

"'They shall lick the dust like a serpent.'"

*Yelachakhu afar ka-nachash*—lick dust.

"'Like crawling things of the earth they shall come trembling.'"

*Ke-zochalei eretz yirgezu mi-misgeroteihem*—trembling.

"'They shall come with fear unto YHWH our God.'"

*El-YHWH Eloheinu yifchadu*—fear YHWH.

"'Shall be afraid of you.'"

*Ve-yir'u mimmekka*—afraid.

**The Key Verses (7:18-20):**
"'Who is a God like unto you?'"

*Mi-El kamokha*—who like you?

**Mi-El Kamokha:**
Wordplay on "Micah"—who is like YHWH?

"'That pardons iniquity.'"

*Nose avon*—pardons.

"'Passes by the transgression of the remnant of his heritage.'"

*Ve-over al-pesha li-she'erit nachalato*—passes over.

"'He retains not his anger for ever.'"

*Lo-hecheziq la-ad appo*—not forever angry.

"'Because he delights in mercy.'"

*Ki-chafetz chesed hu*—delights in mercy.

"'He will again have compassion upon us.'"

*Yashuv yerachamenu*—compassion again.

"'He will tread our iniquities under foot.'"

*Yikhbosh avonotenu*—tread iniquities.

"'You will cast all their sins into the depths of the sea.'"

*Ve-tashלikh bi-metzulot yam kol-chattotam*—cast into sea.

"'You will show faithfulness to Jacob.'"

*Titten emet le-Ya'aqov*—faithfulness to Jacob.

"'Mercy to Abraham.'"

*Chesed le-Avraham*—mercy to Abraham.

"'As you have sworn unto our fathers from the days of old.'"

*Asher-nishba'ta la-avotenu mi-yemei qedem*—sworn to fathers.

**Archetypal Layer:** Micah 7 moves from **lament to hope**, containing **"Woe is me!" (7:1)**, **"The godly man is perished out of the earth" (7:2)**, **"they hunt every man his brother with a net" (7:2)**, **"a man's enemies are the men of his own house" (7:6)**—quoted by Jesus, **"But as for me, I will look unto YHWH" (7:7)**, **"though I am fallen, I shall arise; though I sit in darkness, YHWH shall be a light unto me" (7:8)**, **"I will bear the indignation of YHWH, because I have sinned against him" (7:9)**, **"Shepherd your people with your rod" (7:14)**, **"As in the days of your coming forth out of... Egypt will I show unto them marvellous things" (7:15)**, **"Who is a God like unto you, that pardons iniquity?" (7:18)**, **"He delights in mercy" (7:18)**, **"He will tread our iniquities under foot" (7:19)**, **"You will cast all their sins into the depths of the sea" (7:19)**, and **"faithfulness to Jacob, mercy to Abraham" (7:20)**.

**Ethical Inversion Applied:**
- "'Woe is me!'"—lament
- "'There is no cluster to eat'"—nothing left
- "'The godly man is perished out of the earth'"—godly gone
- "'The upright among men is no more'"—upright gone
- "'They all lie in wait for blood'"—wait for blood
- "'They hunt every man his brother'"—hunt brother
- "'The prince asks, and the judge is ready for a reward'"—corrupt
- "'The great man, he utters the evil desire'"—evil desire
- "'The best of them is as a brier'"—best as brier
- "'Trust not in a friend'"—don't trust
- "'A man's enemies are the men of his own house'"—enemies in house
- "'But as for me, I will look unto YHWH'"—look to YHWH
- "'I will wait for the God of my salvation'"—wait
- "'My God will hear me'"—God hears
- "'Though I am fallen, I shall arise'"—arise
- "'Though I sit in darkness, YHWH shall be a light unto me'"—YHWH is light
- "'I will bear the indignation of YHWH'"—bear indignation
- "'Because I have sinned against him'"—sinned
- "'He will bring me forth to the light'"—bring to light
- "'My enemy shall see it, and shame shall cover her'"—enemy shamed
- "'A day for building your walls!'"—building
- "'From Assyria even to Egypt'"—gathering
- "'Shepherd your people with your rod'"—shepherd
- "'As in the days of... Egypt will I show... marvellous things'"—marvelous things
- "'The nations shall see and be put to shame'"—nations shamed
- "'They shall lick the dust like a serpent'"—lick dust
- "'Who is a God like unto you?'"—who like YHWH?
- "'That pardons iniquity'"—pardons
- "'Passes by the transgression of the remnant'"—passes over
- "'He retains not his anger for ever'"—not forever
- "'He delights in mercy'"—delights in mercy
- "'He will again have compassion upon us'"—compassion
- "'He will tread our iniquities under foot'"—tread iniquities
- "'You will cast all their sins into the depths of the sea'"—cast into sea
- "'Faithfulness to Jacob'"—faithfulness
- "'Mercy to Abraham'"—mercy
- "'As you have sworn unto our fathers'"—oath to fathers

**Modern Equivalent:** Micah 7 moves from despair to hope. The lament (7:1-6) depicts social breakdown—even family members are enemies (Jesus quotes 7:6). The turning point (7:7): "But as for me, I will look unto YHWH." The book ends with one of Scripture's most beautiful passages (7:18-20): "Who is a God like unto you?"—a wordplay on Micah's name—celebrating God's mercy, compassion, and faithfulness. "Cast all their sins into the depths of the sea" (7:19) inspires the Tashlich ceremony.

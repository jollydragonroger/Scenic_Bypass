# Micah 4: The Mountain of YHWH

*From the Hebrew: וְהָיָה בְּאַחֲרִית הַיָּמִים (Ve-Hayah Be-Acharit Ha-Yamim) — And It Shall Come to Pass in the End of Days*

---

## Zion Exalted (4:1-5)

**4:1** But it shall come to pass in the end of days, that the mountain of YHWH's house shall be established as the top of the mountains, and it shall be exalted above the hills; and peoples shall flow unto it.

**4:2** And many nations shall go and say: "Come, and let us go up to the mountain of YHWH, and to the house of the God of Jacob; and he will teach us of his ways, and we will walk in his paths." For out of Zion shall go forth the law, and the word of YHWH from Jerusalem.

**4:3** And he shall judge between many peoples, and shall decide concerning mighty nations afar off; and they shall beat their swords into plowshares, and their spears into pruning-hooks; nation shall not lift up sword against nation, neither shall they learn war any more.

**4:4** But they shall sit every man under his vine and under his fig-tree; and none shall make them afraid; for the mouth of YHWH of hosts has spoken.

**4:5** For let all the peoples walk each one in the name of its god, but we will walk in the name of YHWH our God for ever and ever.

---

## The Remnant Gathered (4:6-8)

**4:6** In that day, says YHWH, will I assemble that which is lame, and I will gather that which is driven away, and that which I have afflicted;

**4:7** And I will make that which was lame a remnant, and that which was cast far off a mighty nation; and YHWH shall reign over them in mount Zion from henceforth even for ever.

**4:8** And you, O tower of the flock, hill of the daughter of Zion, unto you shall it come; yea, the former dominion shall come, the kingdom of the daughter of Jerusalem.

---

## Present Distress and Future Deliverance (4:9-13)

**4:9** Now why do you cry out aloud? Is there no king in you, is your counsellor perished, that pangs have taken hold of you as of a woman in travail?

**4:10** Be in pain, and labour to bring forth, O daughter of Zion, like a woman in travail; for now shall you go forth out of the city, and shall dwell in the field, and shall come even unto Babylon; there shall you be rescued; there shall YHWH redeem you from the hand of your enemies.

**4:11** And now many nations are assembled against you, that say: "Let her be defiled, and let our eye gaze upon Zion."

**4:12** But they know not the thoughts of YHWH, neither understand they his counsel; for he has gathered them as the sheaves to the threshing-floor.

**4:13** Arise and thresh, O daughter of Zion; for I will make your horn iron, and I will make your hoofs brass; and you shall beat in pieces many peoples; and you shall devote their gain unto YHWH, and their substance unto the Lord of the whole earth.

---

## Synthesis Notes

**Key Restorations:**

**Zion Exalted (4:1-5):**
**The Key Verses (4:1-2):**
"'It shall come to pass in the end of days.'"

*Ve-hayah be-acharit ha-yamim*—end of days.

"'The mountain of YHWH's house shall be established as the top of the mountains.'"

*Yihyeh har beit-YHWH nakhon be-rosh he-harim*—established.

"'It shall be exalted above the hills.'"

*Ve-nissa hu mi-geva'ot*—exalted.

"'Peoples shall flow unto it.'"

*Ve-naharu alav ammim*—peoples flow.

"'Many nations shall go and say: Come, and let us go up to the mountain of YHWH.'"

*Ve-halekhu goyim rabbim ve-ameru lekhu ve-na'aleh el-har YHWH*—nations come.

"'He will teach us of his ways, and we will walk in his paths.'"

*Ve-yorenu mi-derakhav ve-nelkhah be-orchotav*—teach ways.

"'For out of Zion shall go forth the law.'"

*Ki mi-Tziyon tetze torah*—Torah from Zion.

"'And the word of YHWH from Jerusalem.'"

*U-devar-YHWH mi-Yrushalayim*—word from Jerusalem.

**Parallel to Isaiah 2:2-4:**
Nearly identical to Isaiah's vision.

**The Key Verse (4:3):**
"'He shall judge between many peoples.'"

*Ve-shafat bein ammim rabbim*—judge nations.

"'Shall decide concerning mighty nations afar off.'"

*Ve-hokhiach le-goyim atzumim ad-rachok*—decide.

"'They shall beat their swords into plowshares.'"

*Ve-khittetu charvotam le-ittim*—swords to plowshares.

"'Their spears into pruning-hooks.'"

*Va-chanitoteihem le-mazmerot*—spears to pruning-hooks.

"'Nation shall not lift up sword against nation.'"

*Lo-yis'u goy el-goy cherev*—no war.

"'Neither shall they learn war any more.'"

*Ve-lo-yilmedu od milchamah*—learn war no more.

**The Key Verses (4:4-5):**
"'They shall sit every man under his vine and under his fig-tree.'"

*Ve-yashvu ish tachat gafno ve-tachat te'enato*—vine, fig tree.

"'None shall make them afraid.'"

*Ve-ein machrid*—none afraid.

"'For the mouth of YHWH of hosts has spoken.'"

*Ki fi YHWH tzeva'ot dibber*—YHWH has spoken.

"'Let all the peoples walk each one in the name of its god.'"

*Ki kol-ha-ammim yelekhu ish be-shem elohav*—peoples walk.

"'We will walk in the name of YHWH our God for ever and ever.'"

*Va-anachnu nelekh be-shem YHWH Eloheinu le-olam va-ed*—we walk in YHWH.

**Remnant Gathered (4:6-8):**
**The Key Verses (4:6-8):**
"'In that day... will I assemble that which is lame.'"

*Ba-yom ha-hu... osefah ha-tzolea*—assemble lame.

"'I will gather that which is driven away.'"

*Ve-ha-nidachah aqabbetzah*—gather driven.

"'That which I have afflicted.'"

*Va-asher hare'oti*—afflicted.

"'I will make that which was lame a remnant.'"

*Ve-samti et-ha-tzolea li-she'erit*—lame to remnant.

"'That which was cast far off a mighty nation.'"

*Ve-ha-nahala'ah le-goy atzum*—mighty nation.

"'YHWH shall reign over them in mount Zion.'"

*U-malakh YHWH aleihem be-har Tziyon*—YHWH reigns.

"'From henceforth even for ever.'"

*Me-attah ve-ad-olam*—forever.

"'O tower of the flock, hill of the daughter of Zion.'"

*Ve-attah migdal-eder ofel bat-Tziyon*—tower of flock.

**Migdal-Eder:**
"Tower of the flock"—near Bethlehem (Genesis 35:21).

"'Unto you shall it come; yea, the former dominion shall come.'"

*Adekha tavo u-va'ah ha-memshalah ha-rishonah*—former dominion.

"'The kingdom of the daughter of Jerusalem.'"

*Mamlekhet le-vat Yerushalayim*—Jerusalem's kingdom.

**Present Distress and Future Deliverance (4:9-13):**
**The Key Verses (4:9-10):**
"'Now why do you cry out aloud?'"

*Attah lammah tari'i rea*—why cry?

"'Is there no king in you?'"

*Ha-melekh ein bakh*—no king?

"'Is your counsellor perished?'"

*Im yo'atzeikh avad*—counsellor gone?

"'Pangs have taken hold of you as of a woman in travail.'"

*Ki-achazakh chil ka-yoledah*—birth pangs.

"'Be in pain, and labour to bring forth, O daughter of Zion.'"

*Chuli va-gochi bat-Tziyon ka-yoledah*—labor.

"'Now shall you go forth out of the city.'"

*Ki-attah tetze'i me-qiryah*—leave city.

"'Shall dwell in the field.'"

*Ve-shakant ba-sadeh*—dwell in field.

"'Shall come even unto Babylon.'"

*U-vat ad-Bavel*—to Babylon.

"'There shall you be rescued.'"

*Sham tinatzeli*—rescued there.

"'There shall YHWH redeem you from the hand of your enemies.'"

*Sham yig'alekh YHWH mi-kaf oyevayikh*—redeemed.

**The Key Verses (4:11-13):**
"'Now many nations are assembled against you.'"

*Ve-attah ne'esfu alayikh goyim rabbim*—nations assembled.

"''Let her be defiled.''"

*Techenaf*—defiled.

"''Let our eye gaze upon Zion.''"

*Ve-tachaz be-Tziyon einenu*—gaze.

"'But they know not the thoughts of YHWH.'"

*Ve-hemmah lo yade'u machshevot YHWH*—don't know.

"'Neither understand they his counsel.'"

*Ve-lo hevinu atzato*—don't understand.

"'He has gathered them as the sheaves to the threshing-floor.'"

*Ki qibbetzam ke-amir gornah*—sheaves.

"'Arise and thresh, O daughter of Zion.'"

*Qumi va-dushi bat-Tziyon*—thresh.

"'I will make your horn iron.'"

*Ki-qarnekh asim barzel*—iron horn.

"'I will make your hoofs brass.'"

*U-farסotayikh asim nechoshet*—brass hoofs.

"'You shall beat in pieces many peoples.'"

*Va-hadiqot ammim rabbim*—beat peoples.

"'You shall devote their gain unto YHWH.'"

*Ve-hacharamti la-YHWH bitz'am*—devote gain.

"'Their substance unto the Lord of the whole earth.'"

*Ve-cheilam la-Adon kol-ha-aretz*—to Lord of earth.

**Archetypal Layer:** Micah 4 contains **"in the end of days... the mountain of YHWH's house shall be established" (4:1)**, **"out of Zion shall go forth the law, and the word of YHWH from Jerusalem" (4:2)**, **"they shall beat their swords into plowshares, and their spears into pruning-hooks" (4:3)**, **"nation shall not lift up sword against nation, neither shall they learn war any more" (4:3)**, **"they shall sit every man under his vine and under his fig-tree; and none shall make them afraid" (4:4)**, **"I will assemble that which is lame... make that which was lame a remnant" (4:6-7)**, **"YHWH shall reign over them in mount Zion" (4:7)**, **"tower of the flock, hill of the daughter of Zion" (4:8)**, **"you shall come even unto Babylon; there shall you be rescued" (4:10)**, and **"arise and thresh, O daughter of Zion" (4:13)**.

**Ethical Inversion Applied:**
- "'It shall come to pass in the end of days'"—end of days
- "'The mountain of YHWH's house shall be established'"—established
- "'Peoples shall flow unto it'"—peoples flow
- "'Many nations shall go and say: Come, and let us go up'"—nations come
- "'He will teach us of his ways'"—teach ways
- "'Out of Zion shall go forth the law'"—Torah from Zion
- "'The word of YHWH from Jerusalem'"—word from Jerusalem
- "'He shall judge between many peoples'"—judge
- "'They shall beat their swords into plowshares'"—swords to plowshares
- "'Their spears into pruning-hooks'"—spears to pruning-hooks
- "'Nation shall not lift up sword against nation'"—no war
- "'Neither shall they learn war any more'"—learn war no more
- "'They shall sit every man under his vine and under his fig-tree'"—vine, fig tree
- "'None shall make them afraid'"—none afraid
- "'We will walk in the name of YHWH our God for ever'"—walk in YHWH
- "'I will assemble that which is lame'"—assemble lame
- "'I will gather that which is driven away'"—gather
- "'I will make that which was lame a remnant'"—lame to remnant
- "'YHWH shall reign over them in mount Zion'"—YHWH reigns
- "'O tower of the flock'"—tower of flock
- "'The former dominion shall come'"—former dominion
- "'Why do you cry out aloud?'"—why cry
- "'Is there no king in you?'"—no king
- "'Pangs have taken hold of you'"—birth pangs
- "'You shall come even unto Babylon'"—to Babylon
- "'There shall you be rescued'"—rescued
- "'Many nations are assembled against you'"—nations assembled
- "'They know not the thoughts of YHWH'"—don't know
- "'He has gathered them as the sheaves'"—sheaves
- "'Arise and thresh, O daughter of Zion'"—thresh
- "'I will make your horn iron'"—iron horn
- "'You shall beat in pieces many peoples'"—beat peoples
- "'You shall devote their gain unto YHWH'"—devote

**Modern Equivalent:** Micah 4 parallels Isaiah 2—the vision of Zion exalted, nations streaming to learn YHWH's ways. "Swords into plowshares" (4:3) is the iconic peace vision. "Every man under his vine and fig-tree" (4:4) adds domestic security. The chapter moves from eschatological hope to present distress (4:9-10) and back to future triumph (4:11-13).

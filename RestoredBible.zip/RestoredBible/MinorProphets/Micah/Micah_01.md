# Micah 1: Judgment on Samaria and Jerusalem

*From the Hebrew: דְּבַר־יְהוָה אֲשֶׁר הָיָה אֶל־מִיכָה (Devar-YHWH Asher Hayah El-Mikhah) — The Word of YHWH That Came to Micah*

---

## Title (1:1)

**1:1** The word of YHWH that came to Micah the Morashtite in the days of Jotham, Ahaz, and Hezekiah, kings of Judah, which he saw concerning Samaria and Jerusalem.

---

## Theophany and Judgment (1:2-7)

**1:2** Hear, you peoples, all of you; hearken, O earth, and all that therein is; and let the Lord YHWH be witness against you, the Lord from his holy temple.

**1:3** For, behold, YHWH comes forth out of his place, and will come down, and tread upon the high places of the earth.

**1:4** And the mountains shall be molten under him, and the valleys shall be cleft, as wax before the fire, as waters that are poured down a steep place.

**1:5** For the transgression of Jacob is all this, and for the sins of the house of Israel. What is the transgression of Jacob? Is it not Samaria? And what are the high places of Judah? Are they not Jerusalem?

**1:6** Therefore I will make Samaria as a heap of the field, and as plantings of a vineyard; and I will pour down the stones thereof into the valley, and I will uncover the foundations thereof.

**1:7** And all her graven images shall be beaten to pieces, and all her hires shall be burned with fire, and all her idols will I lay desolate; for of the hire of a harlot has she gathered them, and unto the hire of a harlot shall they return.

---

## Lamentation (1:8-16)

**1:8** For this will I wail and howl, I will go stripped and naked; I will make a wailing like the jackals, and a mourning like the ostriches.

**1:9** For her wound is incurable; for it is come even unto Judah; it reaches unto the gate of my people, even to Jerusalem.

**1:10** Tell it not in Gath, weep not at all; in Beth-le-aphrah roll yourself in the dust.

**1:11** Pass on your way, O inhabitant of Shaphir, in nakedness and shame; the inhabitant of Zaanan is not come forth; the wailing of Beth-ezel shall take from you its standing-place.

**1:12** For the inhabitant of Maroth waits anxiously for good; because evil is come down from YHWH unto the gate of Jerusalem.

**1:13** Bind the chariot to the swift steed, O inhabitant of Lachish; she was the beginning of sin to the daughter of Zion; for the transgressions of Israel were found in you.

**1:14** Therefore shall you give a parting gift to Moresheth-gath; the houses of Achzib shall be a deceitful thing unto the kings of Israel.

**1:15** I will yet bring a possessor unto you, O inhabitant of Mareshah; the glory of Israel shall come even unto Adullam.

**1:16** Make yourself bald, and poll yourself for the children of your delight; enlarge your baldness as the vulture; for they are gone into captivity from you.

---

## Synthesis Notes

**Key Restorations:**

**Title (1:1):**
**The Key Verse (1:1):**
"The word of YHWH that came to Micah the Morashtite."

*Devar-YHWH asher hayah el-Mikhah ha-Morashti*—Micah of Moresheth.

**Mikhah:**
"Who is like YHWH?" (short form of Mikhayahu).

**Ha-Morashti:**
From Moresheth-gath, a town in Judah's Shephelah.

"In the days of Jotham, Ahaz, and Hezekiah, kings of Judah."

*Bi-yemei Yotam Achaz Yechizqiyyahu malkhei Yehudah*—8th century BCE.

"Which he saw concerning Samaria and Jerusalem."

*Asher-chazah al-Shomeron vi-Yrushalayim*—both capitals.

**Theophany and Judgment (1:2-7):**
**The Key Verses (1:2-4):**
"'Hear, you peoples, all of you.'"

*Shim'u ammim kullam*—all peoples hear.

"'Hearken, O earth, and all that therein is.'"

*Haqshivi eretz u-melo'ah*—earth listen.

"'Let the Lord YHWH be witness against you.'"

*Vi-yhi Adonai YHWH vakhem le-ed*—YHWH witness.

"'The Lord from his holy temple.'"

*Adonai me-heikhal qodsho*—from temple.

"'YHWH comes forth out of his place.'"

*Ki-hinneh YHWH yotze mi-meqomo*—YHWH comes.

"'Will come down, and tread upon the high places of the earth.'"

*Ve-yarad ve-darakh al-bamotei aretz*—treads high places.

"'The mountains shall be molten under him.'"

*Ve-namassu he-harim tachtav*—mountains melt.

"'The valleys shall be cleft, as wax before the fire.'"

*Ve-ha-amaqim yitbaqqa'u ka-donag mippenei ha-esh*—valleys split.

"'As waters that are poured down a steep place.'"

*Ke-mayim muggarim be-morad*—waters poured.

**The Key Verses (1:5-7):**
"'For the transgression of Jacob is all this.'"

*Be-fesha Ya'aqov kol-zot*—Jacob's transgression.

"'For the sins of the house of Israel.'"

*U-ve-chattot beit Yisra'el*—Israel's sins.

"'What is the transgression of Jacob? Is it not Samaria?'"

*Mi-fesha Ya'aqov ha-lo Shomeron*—Samaria.

"'What are the high places of Judah? Are they not Jerusalem?'"

*U-mi bamot Yehudah ha-lo Yerushalayim*—Jerusalem.

"'I will make Samaria as a heap of the field.'"

*Ve-samti Shomeron le-i sadeh*—heap.

"'As plantings of a vineyard.'"

*Le-matta'ei karem*—vineyard plantings.

"'I will pour down the stones thereof into the valley.'"

*Ve-higgarti la-gai avaneiha*—stones poured.

"'I will uncover the foundations thereof.'"

*Ve-yesodeiha agalleh*—foundations uncovered.

"'All her graven images shall be beaten to pieces.'"

*Ve-khol-pesileiha yukkatu*—images beaten.

"'All her hires shall be burned with fire.'"

*Ve-khol-etnaneiha yissarefu va-esh*—hires burned.

**Etnan:**
"Hire"—of a prostitute; wealth from idolatrous cult prostitution.

"'All her idols will I lay desolate.'"

*Ve-khol-atzabbeiha asim shemamah*—idols desolate.

"'For of the hire of a harlot has she gathered them.'"

*Ki me-etnan zonah qibבtzah*—gathered from harlotry.

"'Unto the hire of a harlot shall they return.'"

*Ve-ad-etnan zonah yashuvu*—return to harlotry.

**Lamentation (1:8-16):**
**The Key Verses (1:8-9):**
"'For this will I wail and howl.'"

*Al-zot espedah ve-eilילה*—wail, howl.

"'I will go stripped and naked.'"

*Elkhah shol ve-arom*—stripped.

"'I will make a wailing like the jackals.'"

*E'eseh misped ka-tannim*—like jackals.

"'A mourning like the ostriches.'"

*Ve-evel ki-venot ya'anah*—like ostriches.

"'For her wound is incurable.'"

*Ki anushah makותeiha*—incurable.

"'For it is come even unto Judah.'"

*Ki-va'ah ad-Yehudah*—reached Judah.

"'It reaches unto the gate of my people, even to Jerusalem.'"

*Naga ad-sha'ar ammi ad-Yerushalayim*—to Jerusalem's gate.

**The Key Verses (1:10-16):**
"'Tell it not in Gath.'"

*Be-Gat al-taggidu*—don't tell in Gath.

**Wordplay Series:**
Many of the following verses contain wordplays on town names.

"'In Beth-le-aphrah roll yourself in the dust.'"

*Be-Beit le-Afrah afar hitpallashi*—Beth-le-aphrah = "house of dust."

"'Pass on your way, O inhabitant of Shaphir, in nakedness and shame.'"

*Ivri lakhem yoshevet Shafir eryah-boshet*—Shaphir = "beautiful."

"'The inhabitant of Zaanan is not come forth.'"

*Lo yatz'ah yoshevet Tza'anan*—Zaanan = "going out."

"'The wailing of Beth-ezel shall take from you its standing-place.'"

*Misped Beit-ha-Etzel yiqqach mikkem emdato*—Beth-ezel = "house of taking."

"'The inhabitant of Maroth waits anxiously for good.'"

*Ki-chalah le-tov yoshevet Marot*—Maroth = "bitterness."

"'Evil is come down from YHWH unto the gate of Jerusalem.'"

*Ki-yarad ra me-et YHWH le-sha'ar Yerushalayim*—evil descended.

"'Bind the chariot to the swift steed, O inhabitant of Lachish.'"

*Retom ha-merkavah la-rekhesh yoshevet Lakhish*—Lachish sounds like rekhesh (steed).

"'She was the beginning of sin to the daughter of Zion.'"

*Reshit chattat hi le-vat-Tziyon*—beginning of sin.

"'The transgressions of Israel were found in you.'"

*Ki-vakh nimtze'u pish'ei Yisra'el*—transgressions found.

"'You shall give a parting gift to Moresheth-gath.'"

*Lakhen titteni shilluchim al Moreshet Gat*—parting gift.

"'The houses of Achzib shall be a deceitful thing.'"

*Battei Akhziv le-akhzav le-malkhei Yisra'el*—Achzib = "deceit."

"'I will bring a possessor unto you, O inhabitant of Mareshah.'"

*Od ha-yoresh avi lakh yoshevet Mareshah*—Mareshah = "possession."

"'The glory of Israel shall come even unto Adullam.'"

*Ad-Adullam yavo kevod Yisra'el*—to Adullam.

"'Make yourself bald, and poll yourself for the children of your delight.'"

*Qorchi va-gozzi al-benei ta'anugayikh*—mourn for children.

"'Enlarge your baldness as the vulture.'"

*Harchivi qorchateikh ka-nasher*—baldness like vulture.

"'For they are gone into captivity from you.'"

*Ki galu mimmekh*—gone to exile.

**Archetypal Layer:** Micah 1 contains **the title (1:1)**, **theophany: YHWH coming forth, mountains melting, valleys splitting (1:2-4)**, **"What is the transgression of Jacob? Is it not Samaria? What are the high places of Judah? Are they not Jerusalem?" (1:5)**, **Samaria's destruction: heap, foundations uncovered (1:6)**, **images from harlotry (1:7)**, **the prophet's lament: stripped, wailing like jackals (1:8)**, **"her wound is incurable; for it is come even unto Judah" (1:9)**, **the wordplay series on town names (1:10-15)**, and **"make yourself bald... for they are gone into captivity" (1:16)**.

**Ethical Inversion Applied:**
- "The word of YHWH that came to Micah"—prophetic call
- "In the days of Jotham, Ahaz, and Hezekiah"—dated
- "Concerning Samaria and Jerusalem"—both capitals
- "'Hear, you peoples, all of you'"—universal call
- "'Let the Lord YHWH be witness against you'"—witness
- "'YHWH comes forth out of his place'"—theophany
- "'Will come down, and tread upon the high places'"—treads
- "'The mountains shall be molten under him'"—mountains melt
- "'The valleys shall be cleft'"—valleys split
- "'For the transgression of Jacob is all this'"—Jacob's sin
- "'What is the transgression of Jacob? Is it not Samaria?'"—Samaria
- "'What are the high places of Judah? Are they not Jerusalem?'"—Jerusalem
- "'I will make Samaria as a heap'"—heap
- "'I will uncover the foundations'"—foundations
- "'All her graven images shall be beaten'"—images
- "'All her hires shall be burned'"—hires
- "'Of the hire of a harlot has she gathered them'"—harlotry
- "'For this will I wail and howl'"—lament
- "'I will go stripped and naked'"—stripped
- "'I will make a wailing like the jackals'"—jackals
- "'Her wound is incurable'"—incurable
- "'It is come even unto Judah'"—reached Judah
- "'Tell it not in Gath'"—don't tell
- "'In Beth-le-aphrah roll yourself in the dust'"—wordplay
- "'Bind the chariot to the swift steed, O inhabitant of Lachish'"—Lachish
- "'She was the beginning of sin'"—beginning of sin
- "'Make yourself bald'"—mourn
- "'They are gone into captivity'"—exile

**Modern Equivalent:** Micah 1 opens with cosmic theophany—YHWH treading earth's high places, mountains melting. Both capitals (Samaria and Jerusalem) are condemned. The wordplay lament (1:10-15) uses town names: Beth-le-aphrah ("house of dust") rolls in dust; Achzib ("deceit") is deceitful; etc. The incurable wound spreading from Samaria to Jerusalem (1:9) shows judgment coming to Judah too.

# Micah 2: Woe to the Oppressors

*From the Hebrew: הוֹי חֹשְׁבֵי־אָוֶן (Hoy Choshevei-Aven) — Woe to Them That Devise Iniquity*

---

## Woe to the Land Grabbers (2:1-5)

**2:1** Woe to them that devise iniquity and work evil upon their beds! When the morning is light, they execute it, because it is in the power of their hand.

**2:2** And they covet fields, and seize them; and houses, and take them away; thus they oppress a man and his house, even a man and his heritage.

**2:3** Therefore thus says YHWH: Behold, against this family do I devise an evil, from which you shall not remove your necks, neither shall you walk upright; for it shall be an evil time.

**2:4** In that day shall they take up a parable against you, and lament with a doleful lamentation, and say: "We are utterly ruined; he changes the portion of my people; how does he remove it from me! To the rebellious he divides our fields."

**2:5** Therefore you shall have none that shall cast the line by lot in the assembly of YHWH.

---

## False Prophets (2:6-11)

**2:6** "Prophesy not," they prophesy. "They shall not prophesy of these things, that they may not be put to shame."

**2:7** Do I say, O house of Jacob: "Is the spirit of YHWH straitened? Are these his doings?" Do not my words do good to him that walks uprightly?

**2:8** But of late my people is risen up as an enemy; from off the garment you strip the mantle from them that pass by securely, that are averse from war.

**2:9** The women of my people you cast out from their pleasant houses; from their young children you take away my glory for ever.

**2:10** Arise, and depart; for this is not your resting-place; because of the uncleanness thereof, it shall destroy you, even with a sore destruction.

**2:11** If a man walking in wind and falsehood do lie: "I will prophesy unto you of wine and of strong drink"; he shall even be the prophet of this people.

---

## Promise of Restoration (2:12-13)

**2:12** I will surely assemble, O Jacob, all of you; I will surely gather the remnant of Israel; I will render them all as sheep in a fold; as a flock in the midst of their pasture; they shall make great noise by reason of the multitude of men.

**2:13** The breaker is gone up before them; they have broken forth and passed on, by the gate, and are gone out thereat; and their king is passed on before them, and YHWH at the head of them.

---

## Synthesis Notes

**Key Restorations:**

**Woe to the Land Grabbers (2:1-5):**
**The Key Verses (2:1-2):**
"'Woe to them that devise iniquity and work evil upon their beds!'"

*Hoy choshevei-aven u-fo'alei ra al-mishkevotam*—plan evil at night.

"'When the morning is light, they execute it.'"

*Be-or ha-boqer ya'asuha*—execute at dawn.

"'Because it is in the power of their hand.'"

*Ki yesh le-el yadam*—power to do it.

"'They covet fields, and seize them.'"

*Ve-chamedu sadot ve-gazalu*—covet fields.

"'Houses, and take them away.'"

*U-vattim ve-nasa'u*—take houses.

"'They oppress a man and his house.'"

*Ve-ashqu gever u-veito*—oppress.

"'Even a man and his heritage.'"

*Ve-ish ve-nachalato*—heritage.

**The Key Verses (2:3-5):**
"'Against this family do I devise an evil.'"

*Hineni choshev al-ha-mishpachah ha-zot ra'ah*—devise evil.

"'From which you shall not remove your necks.'"

*Asher lo-tamiशu mi-sham tzavv'roteikhem*—can't escape.

"'Neither shall you walk upright.'"

*Ve-lo telekhu romah*—not walk upright.

"'For it shall be an evil time.'"

*Ki et ra'ah hi*—evil time.

"'In that day shall they take up a parable against you.'"

*Ba-yom ha-hu yissa aleikhem mashal*—taunt.

"'Lament with a doleful lamentation.'"

*Ve-nahah nehi nihyah*—doleful lamentation.

"''We are utterly ruined.''"

*Shadod neshaddunu*—utterly ruined.

"''He changes the portion of my people.''"

*Cheleq ammi yamir*—portion changed.

"''How does he remove it from me!''"

*Eikh yamish li*—removed.

"''To the rebellious he divides our fields.''"

*Le-shoveiv sadenu yechalleq*—fields divided.

"'You shall have none that shall cast the line by lot.'"

*Lakhen lo-yihyeh lekha mashלikh chevel be-goral*—no land allotment.

"'In the assembly of YHWH.'"

*Bi-qehal YHWH*—YHWH's assembly.

**False Prophets (2:6-11):**
**The Key Verses (2:6-7):**
"''Prophesy not,' they prophesy.'"

*Al-tattifu yattifun*—don't prophesy.

"''They shall not prophesy of these things.''"

*Lo-yattifu la-elleh*—not these things.

"''That they may not be put to shame.''"

*Lo yissag keלimmot*—avoid shame.

"'Do I say, O house of Jacob: Is the spirit of YHWH straitened?'"

*He-amur beit-Ya'aqov ha-qatzar ruach YHWH*—spirit limited?

"'Are these his doings?'"

*Im-elleh ma'alalav*—his doings?

"'Do not my words do good to him that walks uprightly?'"

*Ha-lo devarai yeitיvu im ha-yashar holekh*—good to upright.

**The Key Verses (2:8-11):**
"'Of late my people is risen up as an enemy.'"

*Ve-etmol ammi le-oyev yeqomem*—people as enemy.

"'From off the garment you strip the mantle.'"

*Mi-mul salmah eder tafshitun*—strip garments.

"'From them that pass by securely.'"

*Me-overim betach*—passersby.

"'That are averse from war.'"

*Shuvei milchamah*—averse to war.

"'The women of my people you cast out from their pleasant houses.'"

*Neshei ammi tegareshun mi-beit ta'anugeiha*—cast out women.

"'From their young children you take away my glory for ever.'"

*Me-al oleleiha tiqqechu hadari le-olam*—take glory from children.

"'Arise, and depart; for this is not your resting-place.'"

*Qumu u-lekhu ki lo-zot ha-menuchah*—not resting place.

"'Because of the uncleanness thereof, it shall destroy you.'"

*Ba-avur tum'ah techabבel ve-chevel nimratz*—uncleanness destroys.

"'If a man walking in wind and falsehood do lie.'"

*Lu-ish holekh ruach va-sheqer kizzev*—wind and lies.

"''I will prophesy unto you of wine and of strong drink.''"

*Attif lekha la-yayin ve-la-shekhar*—prophesy wine.

"'He shall even be the prophet of this people.'"

*Ve-hayah mattif ha-am ha-zeh*—this people's prophet.

**Promise of Restoration (2:12-13):**
**The Key Verses (2:12-13):**
"'I will surely assemble, O Jacob, all of you.'"

*Asof e'esof Ya'aqov kullakh*—assemble.

"'I will surely gather the remnant of Israel.'"

*Qabbetz aqabbetz she'erit Yisra'el*—gather remnant.

"'I will render them all as sheep in a fold.'"

*Yachad asimennו ke-tzon Botzrah*—like sheep.

"'As a flock in the midst of their pasture.'"

*Ke-eder be-tokh hadבro*—flock in pasture.

"'They shall make great noise by reason of the multitude of men.'"

*Tehimenyah me-adam*—multitude.

"'The breaker is gone up before them.'"

*Alah ha-poretz lifneihem*—breaker goes up.

"'They have broken forth and passed on, by the gate.'"

*Partzu va-ya'avru sha'ar va-yetz'u vo*—broken through.

"'Their king is passed on before them.'"

*Va-ya'avor malkam lifneihem*—king before.

"'YHWH at the head of them.'"

*Va-YHWH be-rosham*—YHWH at head.

**Ha-Poretz:**
"The Breaker"—YHWH breaking open the way for His people.

**Archetypal Layer:** Micah 2 contains **"Woe to them that devise iniquity and work evil upon their beds" (2:1)**, **"they covet fields, and seize them; and houses, and take them away" (2:2)**, **"against this family do I devise an evil" (2:3)**, **"We are utterly ruined" (2:4)**, **"Prophesy not" (2:6)**—silencing prophets, **"If a man walking in wind and falsehood do lie: I will prophesy unto you of wine and of strong drink; he shall even be the prophet of this people" (2:11)**, **"I will surely assemble, O Jacob, all of you" (2:12)**, **"I will surely gather the remnant of Israel" (2:12)**, **"The breaker is gone up before them" (2:13)**, and **"YHWH at the head of them" (2:13)**.

**Ethical Inversion Applied:**
- "'Woe to them that devise iniquity'"—devise iniquity
- "'Work evil upon their beds'"—plan at night
- "'When the morning is light, they execute it'"—execute at dawn
- "'Because it is in the power of their hand'"—power
- "'They covet fields, and seize them'"—covet, seize
- "'Houses, and take them away'"—take houses
- "'They oppress a man and his house'"—oppress
- "'Even a man and his heritage'"—heritage
- "'Against this family do I devise an evil'"—YHWH devises
- "'From which you shall not remove your necks'"—can't escape
- "'In that day shall they take up a parable against you'"—taunt
- "''We are utterly ruined''"—ruined
- "''He changes the portion of my people''"—portion changed
- "'You shall have none that shall cast the line by lot'"—no allotment
- "''Prophesy not,' they prophesy'"—silence prophets
- "'Is the spirit of YHWH straitened?'"—spirit limited?
- "'Do not my words do good to him that walks uprightly?'"—good to upright
- "'Of late my people is risen up as an enemy'"—people as enemy
- "'From off the garment you strip the mantle'"—strip garments
- "'The women of my people you cast out'"—cast out women
- "'From their young children you take away my glory'"—take from children
- "'Arise, and depart; for this is not your resting-place'"—not rest
- "'If a man walking in wind and falsehood do lie'"—wind, lies
- "''I will prophesy unto you of wine''"—prophesy wine
- "'He shall even be the prophet of this people'"—false prophet
- "'I will surely assemble, O Jacob'"—assemble
- "'I will surely gather the remnant of Israel'"—gather remnant
- "'I will render them all as sheep in a fold'"—sheep
- "'The breaker is gone up before them'"—breaker
- "'Their king is passed on before them'"—king before
- "'YHWH at the head of them'"—YHWH leads

**Modern Equivalent:** Micah 2 condemns land grabbers who scheme at night and execute at dawn (2:1-2). They silence prophets (2:6) and prefer false prophets who promise wine (2:11). Yet YHWH promises to gather the remnant (2:12) with "the Breaker" going before them (2:13)—a messianic image of YHWH breaking open the way.

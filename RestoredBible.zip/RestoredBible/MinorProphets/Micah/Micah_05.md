# Micah 5: The Ruler from Bethlehem

*From the Hebrew: וְאַתָּה בֵּית־לֶחֶם אֶפְרָתָה (Ve-Attah Beit-Lechem Efratah) — But You, Bethlehem Ephrathah*

---

## The Siege and the Ruler (5:1-5)

**5:1** Now gather yourself in troops, O daughter of troops; he has laid siege against us; they smite the judge of Israel with a rod upon the cheek.

**5:2** But you, Bethlehem Ephrathah, which are little to be among the thousands of Judah, out of you shall one come forth unto me that is to be ruler in Israel; whose goings forth are from of old, from ancient days.

**5:3** Therefore will he give them up, until the time that she who travails has brought forth; then the residue of his brethren shall return with the children of Israel.

**5:4** And he shall stand, and shall feed his flock in the strength of YHWH, in the majesty of the name of YHWH his God; and they shall abide, for then shall he be great unto the ends of the earth.

**5:5** And this shall be peace: when the Assyrian shall come into our land, and when he shall tread in our palaces, then shall we raise against him seven shepherds, and eight princes among men.

---

## Deliverance from Enemies (5:6-9)

**5:6** And they shall waste the land of Assyria with the sword, and the land of Nimrod with the keen sword; and he shall deliver us from the Assyrian, when he comes into our land, and when he treads within our border.

**5:7** And the remnant of Jacob shall be in the midst of many peoples, as dew from YHWH, as showers upon the grass, that are not looked for from man, nor awaited at the hands of the sons of men.

**5:8** And the remnant of Jacob shall be among the nations, in the midst of many peoples, as a lion among the beasts of the forest, as a young lion among the flocks of sheep, who, if he go through, treads down and tears in pieces, and there is none to deliver.

**5:9** Let your hand be lifted up above your adversaries, and let all your enemies be cut off.

---

## Purification of Israel (5:10-15)

**5:10** And it shall come to pass in that day, says YHWH, that I will cut off your horses out of the midst of you, and will destroy your chariots;

**5:11** And I will cut off the cities of your land, and will throw down all your strongholds;

**5:12** And I will cut off witchcrafts out of your hand; and you shall have no more soothsayers;

**5:13** And I will cut off your graven images and your pillars out of the midst of you; and you shall no more worship the work of your hands;

**5:14** And I will pluck up your Asherim out of the midst of you; and I will destroy your cities.

**5:15** And I will execute vengeance in anger and fury upon the nations, because they hearkened not.

---

## Synthesis Notes

**Key Restorations:**

**The Siege and the Ruler (5:1-5):**
**The Key Verse (5:1):**
"'Now gather yourself in troops, O daughter of troops.'"

*Attah titgodedi bat-gedud*—gather troops.

"'He has laid siege against us.'"

*Matzor sam aleinu*—siege.

"'They smite the judge of Israel with a rod upon the cheek.'"

*Ba-shevet yakku al ha-lechi et shofet Yisra'el*—judge smitten.

**The Key Verse (5:2):**
"'But you, Bethlehem Ephrathah.'"

*Ve-attah Beit-Lechem Efratah*—Bethlehem.

**Beit-Lechem Efratah:**
"House of Bread" in the Ephrathah region—David's hometown.

"'Which are little to be among the thousands of Judah.'"

*Tza'ir lihyot be-alfei Yehudah*—small.

"'Out of you shall one come forth unto me that is to be ruler in Israel.'"

*Mimmekha li yetze lihyot moshel be-Yisra'el*—ruler from you.

"'Whose goings forth are from of old, from ancient days.'"

*U-motza'otav mi-qedem mi-yemei olam*—from ancient days.

**Messianic Prophecy:**
Matthew 2:6 quotes this for Jesus's birth in Bethlehem.

**The Key Verses (5:3-5):**
"'Therefore will he give them up, until the time that she who travails has brought forth.'"

*Lakhen yittnem ad-et yoledah yaladah*—until birth.

"'The residue of his brethren shall return with the children of Israel.'"

*Ve-yeter echav yeshuvun al-benei Yisra'el*—brothers return.

"'He shall stand, and shall feed his flock in the strength of YHWH.'"

*Ve-amad ve-ra'ah be-oz YHWH*—shepherd in YHWH's strength.

"'In the majesty of the name of YHWH his God.'"

*Bi-ge'on shem YHWH Elohav*—majesty.

"'They shall abide.'"

*Ve-yashavu*—abide.

"'He shall be great unto the ends of the earth.'"

*Ki-attah yigdal ad-afsei-aretz*—great to earth's ends.

"'This shall be peace.'"

*Ve-hayah zeh shalom*—this is peace.

"'When the Assyrian shall come into our land.'"

*Ashur ki-yavo be-artzenu*—Assyrian comes.

"'We shall raise against him seven shepherds, and eight princes among men.'"

*Va-haqemonu alav shiv'ah ro'im u-shemonah nesיkhei adam*—seven shepherds, eight princes.

**Deliverance from Enemies (5:6-9):**
**The Key Verses (5:6-9):**
"'They shall waste the land of Assyria with the sword.'"

*Ve-ra'u et-eretz Ashur ba-cherev*—waste Assyria.

"'The land of Nimrod with the keen sword.'"

*Ve-et-eretz Nimrod bi-fetacheiha*—Nimrod's land.

"'He shall deliver us from the Assyrian.'"

*Ve-hitzil me-Ashur*—deliver.

"'The remnant of Jacob shall be in the midst of many peoples.'"

*Ve-hayah she'erit Ya'aqov be-qerev ammim rabbim*—remnant among peoples.

"'As dew from YHWH.'"

*Ka-tal me-et YHWH*—like dew.

"'As showers upon the grass.'"

*Ki-revivim alei-esev*—like showers.

"'That are not looked for from man.'"

*Asher lo-yeqavveh le-ish*—not from man.

"'Nor awaited at the hands of the sons of men.'"

*Ve-lo yeyachel li-venei adam*—not awaited.

"'The remnant of Jacob shall be among the nations.'"

*Ve-hayah she'erit Ya'aqov ba-goyim*—remnant among nations.

"'As a lion among the beasts of the forest.'"

*Ke-aryeh be-vahamot ya'ar*—like lion.

"'As a young lion among the flocks of sheep.'"

*Ki-kefir be-edrei tzon*—like young lion.

"'Who, if he go through, treads down and tears in pieces.'"

*Asher im avar ve-ramas ve-taraf*—treads, tears.

"'There is none to deliver.'"

*Ve-ein matzil*—none to deliver.

"'Let your hand be lifted up above your adversaries.'"

*Tarom yadekha al-tzarekha*—hand lifted.

"'Let all your enemies be cut off.'"

*Ve-khol-oyevekha yikkaretu*—enemies cut off.

**Purification of Israel (5:10-15):**
**The Key Verses (5:10-14):**
"''I will cut off your horses out of the midst of you.''"

*Ve-hikhrati susekha mi-qirbeka*—cut off horses.

"''Will destroy your chariots.''"

*Ve-ha'avadti markevotekha*—destroy chariots.

"''I will cut off the cities of your land.''"

*Ve-hikhrati arei artzeka*—cut off cities.

"''Will throw down all your strongholds.''"

*Ve-harastי kol-mivtzarekha*—throw down strongholds.

"''I will cut off witchcrafts out of your hand.''"

*Ve-hikhrati kheshafim mi-yadeka*—cut off witchcraft.

"''You shall have no more soothsayers.''"

*U-me'onenim lo yihyu-lakh*—no soothsayers.

"''I will cut off your graven images and your pillars.''"

*Ve-hikhrati fesilekha u-matztzevotekha mi-qirbeka*—cut off images.

"''You shall no more worship the work of your hands.''"

*Ve-lo-tishtachaveh od le-ma'aseh yadekha*—no worship.

"''I will pluck up your Asherim out of the midst of you.''"

*Ve-natashti asherekha mi-qirbeka*—pluck Asherim.

"''I will destroy your cities.''"

*Ve-hishmadti arekha*—destroy cities.

**The Key Verse (5:15):**
"''I will execute vengeance in anger and fury upon the nations.''"

*Ve-asiti be-af u-ve-chemah naqam et-ha-goyim*—vengeance.

"''Because they hearkened not.''"

*Asher lo shame'u*—didn't listen.

**Archetypal Layer:** Micah 5 contains **"they smite the judge of Israel with a rod upon the cheek" (5:1)**, **"But you, Bethlehem Ephrathah, which are little... out of you shall one come forth unto me that is to be ruler in Israel; whose goings forth are from of old, from ancient days" (5:2)**—quoted in Matthew 2:6, **"he shall stand, and shall feed his flock in the strength of YHWH" (5:4)**, **"he shall be great unto the ends of the earth" (5:4)**, **"this shall be peace" (5:5)**, **"seven shepherds, and eight princes" (5:5)**, **"the remnant of Jacob shall be... as dew from YHWH" (5:7)** and **"as a lion among the beasts" (5:8)**, and **purification: cutting off horses, chariots, witchcraft, images, Asherim (5:10-14)**.

**Ethical Inversion Applied:**
- "'Gather yourself in troops'"—troops
- "'He has laid siege against us'"—siege
- "'They smite the judge of Israel'"—judge smitten
- "'But you, Bethlehem Ephrathah'"—Bethlehem
- "'Which are little to be among the thousands of Judah'"—small
- "'Out of you shall one come forth unto me that is to be ruler'"—ruler from Bethlehem
- "'Whose goings forth are from of old, from ancient days'"—ancient origins
- "'He give them up, until the time that she who travails has brought forth'"—until birth
- "'The residue of his brethren shall return'"—brothers return
- "'He shall stand, and shall feed his flock'"—shepherd
- "'In the strength of YHWH'"—YHWH's strength
- "'He shall be great unto the ends of the earth'"—great
- "'This shall be peace'"—peace
- "'When the Assyrian shall come into our land'"—Assyrian
- "'Seven shepherds, and eight princes'"—shepherds, princes
- "'They shall waste the land of Assyria'"—waste Assyria
- "'He shall deliver us from the Assyrian'"—deliver
- "'The remnant of Jacob shall be... as dew from YHWH'"—like dew
- "'As showers upon the grass'"—showers
- "'Not looked for from man'"—not from man
- "'The remnant of Jacob... as a lion'"—like lion
- "'Treads down and tears in pieces'"—tears
- "'There is none to deliver'"—none deliver
- "'Let your hand be lifted up above your adversaries'"—hand lifted
- "'I will cut off your horses'"—cut off horses
- "'Will destroy your chariots'"—chariots
- "'I will cut off the cities'"—cities
- "'Will throw down all your strongholds'"—strongholds
- "'I will cut off witchcrafts'"—witchcraft
- "'You shall have no more soothsayers'"—soothsayers
- "'I will cut off your graven images'"—images
- "'You shall no more worship the work of your hands'"—no worship
- "'I will pluck up your Asherim'"—Asherim
- "'I will execute vengeance... upon the nations'"—vengeance

**Modern Equivalent:** Micah 5:2 is the famous Bethlehem prophecy—the ruler whose origins are "from of old, from ancient days" will come from little Bethlehem. Matthew 2:6 applies this to Jesus. The ruler shepherds in YHWH's strength and brings peace (5:4-5). The remnant is both blessing (dew, 5:7) and power (lion, 5:8). The purification (5:10-14) removes military power, occult practices, and idolatry.

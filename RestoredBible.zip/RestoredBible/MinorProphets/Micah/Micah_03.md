# Micah 3: Against Corrupt Leaders

*From the Hebrew: וָאֹמַר שִׁמְעוּ־נָא רָאשֵׁי יַעֲקֹב (Va-Omar Shim'u-Na Rashei Ya'aqov) — And I Said: Hear, I Pray You, Heads of Jacob*

---

## Indictment of Rulers (3:1-4)

**3:1** And I said: Hear, I pray you, heads of Jacob, and rulers of the house of Israel: is it not for you to know justice?

**3:2** Who hate the good, and love the evil; who rob their skin from off them, and their flesh from off their bones;

**3:3** Who also eat the flesh of my people, and flay their skin from off them, and break their bones; yea, they chop them in pieces, as that which is in the pot, and as flesh within the caldron.

**3:4** Then shall they cry unto YHWH, but he will not answer them; yea, he will hide his face from them at that time, according as they have wrought evil in their doings.

---

## Indictment of False Prophets (3:5-8)

**3:5** Thus says YHWH concerning the prophets that make my people to err; that cry: "Peace," when their teeth have something to bite; and whoever puts not into their mouths, against him they prepare war:

**3:6** Therefore it shall be night unto you, that you shall have no vision; and it shall be dark unto you, that you shall not divine; and the sun shall go down upon the prophets, and the day shall be black over them.

**3:7** And the seers shall be put to shame, and the diviners confounded; yea, they shall all cover their upper lip; for there shall be no answer of God.

**3:8** But I truly am full of power by the spirit of YHWH, and of justice, and of might, to declare unto Jacob his transgression, and to Israel his sin.

---

## Jerusalem's Destruction Foretold (3:9-12)

**3:9** Hear this, I pray you, heads of the house of Jacob, and rulers of the house of Israel, that abhor justice, and pervert all equity;

**3:10** That build up Zion with blood, and Jerusalem with iniquity.

**3:11** The heads thereof judge for reward, and the priests thereof teach for hire, and the prophets thereof divine for money; yet will they lean upon YHWH, and say: "Is not YHWH in the midst of us? No evil shall come upon us."

**3:12** Therefore shall Zion for your sake be plowed as a field, and Jerusalem shall become heaps, and the mountain of the house as the high places of a forest.

---

## Synthesis Notes

**Key Restorations:**

**Indictment of Rulers (3:1-4):**
**The Key Verses (3:1-3):**
"'Hear, I pray you, heads of Jacob, and rulers of the house of Israel.'"

*Shim'u-na rashei Ya'aqov u-qetzinei beit Yisra'el*—heads, rulers.

"'Is it not for you to know justice?'"

*Ha-lo lakhem lada'at et-ha-mishpat*—know justice.

"'Who hate the good, and love the evil.'"

*Son'ei tov ve-ohavei ra'ah*—hate good, love evil.

"'Who rob their skin from off them.'"

*Gozlei oram me-aleihem*—rob skin.

"'Their flesh from off their bones.'"

*U-she'eram me-al atzmotam*—flesh from bones.

"'Who also eat the flesh of my people.'"

*Va-asher akhelu she'er ammi*—eat flesh.

"'Flay their skin from off them.'"

*Ve-oram me-aleihem hifshiתu*—flay skin.

"'Break their bones.'"

*Ve-et-atzmoteihem pitzechu*—break bones.

"'They chop them in pieces, as that which is in the pot.'"

*U-faresu ka-asher ba-sir*—chop for pot.

"'As flesh within the caldron.'"

*U-khe-vasar be-tokh qallachat*—flesh in caldron.

**Cannibalism Imagery:**
The rulers' exploitation is like eating the people.

**The Key Verse (3:4):**
"'Then shall they cry unto YHWH, but he will not answer them.'"

*Az yiz'aqu el-YHWH ve-lo ya'aneh otam*—won't answer.

"'He will hide his face from them at that time.'"

*Ve-yaster panav mehem ba-et ha-hi*—hide face.

"'According as they have wrought evil in their doings.'"

*Ka-asher here'u ma'aleleihem*—evil doings.

**Indictment of False Prophets (3:5-8):**
**The Key Verse (3:5):**
"'Thus says YHWH concerning the prophets that make my people to err.'"

*Koh amar YHWH al-ha-nevi'im ha-mat'im et-ammi*—lead astray.

"'That cry: Peace, when their teeth have something to bite.'"

*Ha-noshkhim be-shinneihem ve-qar'u shalom*—bite, cry peace.

"'Whoever puts not into their mouths, against him they prepare war.'"

*Va-asher lo-yitten al-pihem ve-qiddeshu alav milchamah*—no bribe, war.

**Pay-for-Prophecy:**
Prophets prophesy according to payment.

**The Key Verses (3:6-7):**
"'It shall be night unto you, that you shall have no vision.'"

*Lakhen laylah lakhem me-chazon*—night, no vision.

"'It shall be dark unto you, that you shall not divine.'"

*Ve-chashkhah lakhem mi-qesom*—dark, no divination.

"'The sun shall go down upon the prophets.'"

*U-va'ah ha-shemesh al-ha-nevi'im*—sun sets.

"'The day shall be black over them.'"

*Ve-qadar aleihem ha-yom*—day dark.

"'The seers shall be put to shame, and the diviners confounded.'"

*U-boshu ha-chozim ve-chafu ha-qosemim*—seers shamed.

"'They shall all cover their upper lip.'"

*Ve-atu al-safam kullam*—cover lip.

**Cover Upper Lip:**
Sign of mourning or shame.

"'For there shall be no answer of God.'"

*Ki ein ma'aneh Elohim*—no divine answer.

**The Key Verse (3:8):**
"'But I truly am full of power by the spirit of YHWH.'"

*Ve-ulam anokhi maleiti koach et-ruach YHWH*—full of power.

"'And of justice, and of might.'"

*U-mishpat u-gevurah*—justice, might.

"'To declare unto Jacob his transgression.'"

*Le-haggid le-Ya'aqov pish'o*—declare transgression.

"'And to Israel his sin.'"

*U-le-Yisra'el chattato*—declare sin.

**Jerusalem's Destruction Foretold (3:9-12):**
**The Key Verses (3:9-11):**
"'Hear this, I pray you, heads of the house of Jacob.'"

*Shim'u-na zot rashei beit-Ya'aqov*—hear, heads.

"'Rulers of the house of Israel.'"

*U-qetzinei beit Yisra'el*—rulers.

"'That abhor justice, and pervert all equity.'"

*Ha-meta'avim mishpat ve-et-kol-ha-yesharah ye'aqqeshu*—abhor justice.

"'That build up Zion with blood.'"

*Boneh Tziyon be-damim*—build with blood.

"'And Jerusalem with iniquity.'"

*Vi-Yrushalayim be-avlah*—with iniquity.

"'The heads thereof judge for reward.'"

*Rasheiha be-shochad yishpotu*—judge for bribes.

"'The priests thereof teach for hire.'"

*Ve-khaneiha bi-mechir yoru*—teach for pay.

"'The prophets thereof divine for money.'"

*U-nevi'eiha be-kesef yiqsomu*—divine for money.

"'Yet will they lean upon YHWH.'"

*Ve-al-YHWH yishsha'enu*—lean on YHWH.

"''Is not YHWH in the midst of us?''"

*Ha-lo YHWH be-qirbenu*—YHWH among us?

"''No evil shall come upon us.''"

*Lo-tavo aleinu ra'ah*—no evil.

**The Key Verse (3:12):**
"'Therefore shall Zion for your sake be plowed as a field.'"

*Lakhen biglalkhem Tziyon sadeh techaresh*—Zion plowed.

"'Jerusalem shall become heaps.'"

*Vi-Yrushalayim iyyim tihyeh*—Jerusalem heaps.

"'The mountain of the house as the high places of a forest.'"

*Ve-har ha-bayit le-vamot ya'ar*—temple mount forested.

**Famous Prophecy:**
Jeremiah 26:18 quotes this verse—it saved Jeremiah's life.

**Archetypal Layer:** Micah 3 contains **"is it not for you to know justice?" (3:1)**, **cannibalism imagery for rulers' exploitation (3:2-3)**, **"then shall they cry unto YHWH, but he will not answer them" (3:4)**, **false prophets who "cry Peace when their teeth have something to bite" (3:5)**, **"whoever puts not into their mouths, against him they prepare war" (3:5)**, **prophetic darkness: "it shall be night unto you, that you shall have no vision" (3:6)**, **Micah's contrast: "I truly am full of power by the spirit of YHWH" (3:8)**, **"that build up Zion with blood, and Jerusalem with iniquity" (3:10)**, **"the heads thereof judge for reward, and the priests thereof teach for hire, and the prophets thereof divine for money" (3:11)**, and **"Zion for your sake be plowed as a field, and Jerusalem shall become heaps" (3:12)**.

**Ethical Inversion Applied:**
- "'Hear, I pray you, heads of Jacob'"—address leaders
- "'Is it not for you to know justice?'"—know justice
- "'Who hate the good, and love the evil'"—hate good
- "'Who rob their skin from off them'"—rob skin
- "'Who also eat the flesh of my people'"—eat flesh
- "'They chop them in pieces, as that which is in the pot'"—chop
- "'Then shall they cry unto YHWH, but he will not answer them'"—no answer
- "'He will hide his face from them'"—hide face
- "'The prophets that make my people to err'"—lead astray
- "'That cry Peace when their teeth have something to bite'"—peace for pay
- "'Whoever puts not into their mouths, against him they prepare war'"—war if no pay
- "'It shall be night unto you, that you shall have no vision'"—night
- "'It shall be dark unto you, that you shall not divine'"—dark
- "'The sun shall go down upon the prophets'"—sun sets
- "'The seers shall be put to shame'"—shamed
- "'There shall be no answer of God'"—no answer
- "'I truly am full of power by the spirit of YHWH'"—full of power
- "'And of justice, and of might'"—justice, might
- "'To declare unto Jacob his transgression'"—declare sin
- "'That abhor justice, and pervert all equity'"—abhor justice
- "'That build up Zion with blood'"—blood
- "'Jerusalem with iniquity'"—iniquity
- "'The heads thereof judge for reward'"—bribes
- "'The priests thereof teach for hire'"—pay
- "'The prophets thereof divine for money'"—money
- "'Yet will they lean upon YHWH'"—lean on YHWH
- "''Is not YHWH in the midst of us?''"—false security
- "''No evil shall come upon us''"—false security
- "'Zion for your sake be plowed as a field'"—plowed
- "'Jerusalem shall become heaps'"—heaps
- "'The mountain of the house as the high places of a forest'"—forested

**Modern Equivalent:** Micah 3 is devastating. Rulers who should know justice instead devour the people (cannibalism imagery, 3:2-3). Prophets prophesy for pay—peace for the paying, war for the non-paying (3:5). Micah claims true prophetic authority (3:8). The indictment climaxes: leaders build Zion with blood, all are corrupt (3:9-11), yet claim YHWH's protection. Therefore Zion will be plowed (3:12)—a prophecy Jeremiah later cited to save his life.

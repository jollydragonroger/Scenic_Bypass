# Malachi 4: The Day of YHWH and Elijah's Return

*From the Hebrew: כִּי־הִנֵּה הַיּוֹם בָּא (Ki-Hinneh Ha-Yom Ba) — For, Behold, the Day Comes*

---

## The Day of YHWH (4:1-3)

**4:1** "For, behold, the day comes, it burns as a furnace; and all the proud, and all that work wickedness, shall be stubble; and the day that comes shall set them ablaze," says YHWH of hosts, "that it shall leave them neither root nor branch.

**4:2** "But unto you that fear my name shall the sun of righteousness arise with healing in its wings; and you shall go forth, and gambol as calves of the stall.

**4:3** "And you shall tread down the wicked; for they shall be ashes under the soles of your feet in the day that I do make," says YHWH of hosts.

---

## Remember the Torah and Elijah (4:4-6)

**4:4** "Remember the law of Moses my servant, which I commanded unto him in Horeb for all Israel, even statutes and ordinances.

**4:5** "Behold, I will send you Elijah the prophet before the coming of the great and terrible day of YHWH.

**4:6** "And he shall turn the heart of the fathers to the children, and the heart of the children to their fathers; lest I come and smite the land with a curse."

---

## Synthesis Notes

**Key Restorations:**

**The Day of YHWH (4:1-3):**
**The Key Verse (4:1):**
"''For, behold, the day comes, it burns as a furnace.''"

*Ki-hinneh ha-yom ba bo'er ka-tannur*—burns as furnace.

"''All the proud, and all that work wickedness, shall be stubble.''"

*Ve-hayu khol-zedim ve-khol-oseh rish'ah qash*—stubble.

"''The day that comes shall set them ablaze.''"

*Ve-lihat otam ha-yom ha-ba*—set ablaze.

"''It shall leave them neither root nor branch.''"

*Asher lo-ya'azov lahem shoresh ve-anaf*—no root, no branch.

**The Key Verse (4:2):**
"''Unto you that fear my name shall the sun of righteousness arise.''"

*Ve-zarechah lakhem yir'ei shemi shemesh tzedaqah*—sun of righteousness.

**Shemesh Tzedaqah:**
"Sun of righteousness"—messianic title.

"''With healing in its wings.''"

*U-marpe bi-khenafeiha*—healing in wings.

"''You shall go forth, and gambol as calves of the stall.''"

*Vi-ytzatem u-fishtem ke-eglei marbeq*—gambol like calves.

**The Key Verse (4:3):**
"''You shall tread down the wicked.''"

*Ve-assوtem resha'im*—tread down.

"''They shall be ashes under the soles of your feet.''"

*Ki-yihyu efer tachat kappot ragleikhem*—ashes.

"''In the day that I do make.''"

*Ba-yom asher ani oseh*—day I make.

**Remember the Torah and Elijah (4:4-6):**
**The Key Verse (4:4):**
"''Remember the law of Moses my servant.''"

*Zikhru torat Mosheh avdi*—remember Torah.

"''Which I commanded unto him in Horeb for all Israel.''"

*Asher tzivviti oto ve-Chorev al-kol-Yisra'el*—Horeb.

"''Even statutes and ordinances.''"

*Chuqqim u-mishpatim*—statutes, ordinances.

**The Key Verses (4:5-6):**
"''Behold, I will send you Elijah the prophet.''"

*Hinneh anokhi shole'ach lakhem et Eliyyah ha-navi*—send Elijah.

**Eliyyahu Ha-Navi:**
"Elijah the prophet"—applied to John the Baptist in Luke 1:17, Matthew 11:14.

"''Before the coming of the great and terrible day of YHWH.''"

*Lifnei bo yom YHWH ha-gadol ve-ha-nora*—before day of YHWH.

"''He shall turn the heart of the fathers to the children.''"

*Ve-heshiv lev-avot al-banim*—fathers to children.

"''And the heart of the children to their fathers.''"

*Ve-lev banim al-avotam*—children to fathers.

"''Lest I come and smite the land with a curse.''"

*Pen-avo ve-hikkeiti et-ha-aretz cherem*—lest curse.

**Cherem:**
"Curse" / "ban" / "devoted destruction."

**Final Words of the Hebrew Prophets:**
The last verse of the Prophetic section (Nevi'im) in the Hebrew Bible.

**Archetypal Layer:** Malachi 4 concludes the **Hebrew Prophets (Nevi'im)**, containing **"the day comes, it burns as a furnace" (4:1)**, **"all the proud, and all that work wickedness, shall be stubble" (4:1)**, **"it shall leave them neither root nor branch" (4:1)**, **"unto you that fear my name shall the sun of righteousness arise with healing in its wings" (4:2)**, **"you shall go forth, and gambol as calves of the stall" (4:2)**, **"Remember the law of Moses my servant" (4:4)**, **"Behold, I will send you Elijah the prophet before the coming of the great and terrible day of YHWH" (4:5)**—applied to John the Baptist, and **"he shall turn the heart of the fathers to the children, and the heart of the children to their fathers" (4:6)**.

**Ethical Inversion Applied:**
- "''For, behold, the day comes''"—day comes
- "''It burns as a furnace''"—furnace
- "''All the proud, and all that work wickedness, shall be stubble''"—stubble
- "''The day that comes shall set them ablaze''"—ablaze
- "''It shall leave them neither root nor branch''"—no root, no branch
- "''Unto you that fear my name''"—fear name
- "''The sun of righteousness arise''"—sun of righteousness
- "''With healing in its wings''"—healing
- "''You shall go forth, and gambol as calves of the stall''"—gambol
- "''You shall tread down the wicked''"—tread down
- "''They shall be ashes under the soles of your feet''"—ashes
- "''In the day that I do make''"—day I make
- "''Remember the law of Moses my servant''"—remember Torah
- "''Which I commanded unto him in Horeb''"—Horeb
- "''Even statutes and ordinances''"—statutes
- "''Behold, I will send you Elijah the prophet''"—send Elijah
- "''Before the coming of the great and terrible day of YHWH''"—great day
- "''He shall turn the heart of the fathers to the children''"—fathers to children
- "''And the heart of the children to their fathers''"—children to fathers
- "''Lest I come and smite the land with a curse''"—lest curse

**Modern Equivalent:** Malachi 4 concludes the Hebrew Prophets with dual imagery: judgment (burning furnace, 4:1) and blessing (sun of righteousness with healing, 4:2). "Remember the law of Moses" (4:4) looks back to Sinai. "I will send you Elijah" (4:5) looks forward—fulfilled in John the Baptist (Matthew 11:14, Luke 1:17). "Turn the heart of the fathers to the children" (4:6) is quoted in Luke 1:17. The OT ends with both Torah (4:4) and prophecy (4:5-6), and with the threat of curse (4:6)—setting the stage for the coming of Messiah.

---

## Note on Chapter Division

In the Hebrew Bible, Malachi has only 3 chapters. What is Malachi 4:1-6 in English versions is Malachi 3:19-24 in the Hebrew text. The content is identical; only the chapter division differs.

# Malachi 1: YHWH's Love for Israel and Corrupt Worship

*From the Hebrew: מַשָּׂא דְבַר־יְהוָה אֶל־יִשְׂרָאֵל (Massa Devar-YHWH El-Yisra'el) — The Burden of the Word of YHWH to Israel*

---

## Title and YHWH's Love (1:1-5)

**1:1** The burden of the word of YHWH to Israel by Malachi.

**1:2** "I have loved you," says YHWH. Yet you say: "Wherein have you loved us?" "Was not Esau Jacob's brother?" says YHWH; "Yet I loved Jacob;

**1:3** "But Esau I hated, and made his mountains a desolation, and gave his heritage to the jackals of the wilderness."

**1:4** Whereas Edom says: "We are beaten down, but we will return and build the waste places"; thus says YHWH of hosts: "They shall build, but I will throw down; and men shall call them the border of wickedness, and the people against whom YHWH has indignation for ever."

**1:5** And your eyes shall see, and you shall say: "YHWH is great beyond the border of Israel."

---

## Polluted Offerings (1:6-14)

**1:6** "A son honours his father, and a servant his master; if then I be a father, where is my honour? And if I be a master, where is my fear?" says YHWH of hosts unto you, O priests, that despise my name. And you say: "Wherein have we despised your name?"

**1:7** "You offer polluted bread upon my altar." And you say: "Wherein have we polluted you?" "In that you say: The table of YHWH is contemptible."

**1:8** "And when you offer the blind for sacrifice, is it no evil! And when you offer the lame and sick, is it no evil! Present it now unto your governor; will he be pleased with you? Or will he accept your person?" says YHWH of hosts.

**1:9** "And now, I pray you, entreat the favour of God, that he may be gracious unto us!—This has been of your doing.—Will he accept any of your persons?" says YHWH of hosts.

**1:10** "Oh that there were even one among you that would shut the doors, that you might not kindle fire on my altar in vain! I have no pleasure in you," says YHWH of hosts, "neither will I accept an offering at your hand.

**1:11** "For from the rising of the sun even unto the going down of the same my name is great among the nations; and in every place offerings are presented unto my name, even pure offerings; for my name is great among the nations," says YHWH of hosts.

**1:12** "But you profane it, in that you say: The table of the Lord is polluted, and the fruit thereof, even the food thereof, is contemptible.

**1:13** "You say also: Behold, what a weariness is it! And you have snuffed at it," says YHWH of hosts; "and you have brought that which was torn, and the lame, and the sick; thus you bring the offering; should I accept this of your hand?" says YHWH.

**1:14** "But cursed be the deceiver, who has in his flock a male, and vows, and sacrifices unto the Lord a blemished thing; for I am a great King," says YHWH of hosts, "and my name is feared among the nations."

---

## Synthesis Notes

**Key Restorations:**

**Title and YHWH's Love (1:1-5):**
**The Key Verse (1:1):**
"The burden of the word of YHWH to Israel by Malachi."

*Massa devar-YHWH el-Yisra'el be-yad Mal'akhi*—by Malachi.

**Mal'akhi:**
"My messenger"—possibly a title, not a personal name.

**The Key Verses (1:2-3):**
"''I have loved you,' says YHWH."

*Ahavti etkhem amar YHWH*—loved you.

"'Yet you say: Wherein have you loved us?'"

*Va-amartem bammah ahavtanu*—wherein loved?

**Disputation Style:**
Malachi uses a unique disputation format—statement, question, answer.

"''Was not Esau Jacob's brother?' says YHWH."

*Ha-lo ach Esav le-Ya'aqov ne'um-YHWH*—Esau brother.

"''Yet I loved Jacob.''"

*Va-ohav et-Ya'aqov*—loved Jacob.

"''But Esau I hated.''"

*Ve-et-Esav sane'ti*—hated Esau.

**Quoted in Romans 9:13.**

"''Made his mountains a desolation.''"

*Va-asim et-harav shemamah*—desolation.

"''Gave his heritage to the jackals of the wilderness.''"

*Ve-et-nachalato le-tannot midbar*—jackals.

**The Key Verses (1:4-5):**
"''They shall build, but I will throw down.''"

*Hemmah yivnu va-ani eheros*—throw down.

"''Men shall call them the border of wickedness.''"

*Ve-qar'u lahem gevul rish'ah*—wickedness.

"''The people against whom YHWH has indignation for ever.''"

*Ve-ha-am asher za'am YHWH ad-olam*—forever indignation.

"''YHWH is great beyond the border of Israel.''"

*Yigdal YHWH me-al li-gevul Yisra'el*—great beyond.

**Polluted Offerings (1:6-14):**
**The Key Verses (1:6-7):**
"''A son honours his father, and a servant his master.''"

*Ben yekhabbed av ve-eved adonav*—honor.

"''If then I be a father, where is my honour?''"

*Ve-im-av ani ayyeh kevodi*—where honor?

"''If I be a master, where is my fear?''"

*Ve-im-adonim ani ayyeh mora'י*—where fear?

"''O priests, that despise my name.''"

*Ha-kohanim bozei shemi*—priests despise.

"''Wherein have we despised your name?''"

*Bammeh vazinu et-shemekha*—wherein despised?

"''You offer polluted bread upon my altar.''"

*Maggishim al-mizbechi lechem mego'al*—polluted bread.

"''Wherein have we polluted you?''"

*Bammeh ge'alnukha*—wherein polluted?

"''In that you say: The table of YHWH is contemptible.''"

*Be-emorkhem shulchan YHWH nivzeh hu*—contemptible.

**The Key Verses (1:8-10):**
"''When you offer the blind for sacrifice, is it no evil!''"

*Ve-khi-taggishu ivver li-zbo'ach ein ra*—blind.

"''When you offer the lame and sick, is it no evil!''"

*Ve-khi taggishu pisse'ach ve-choleh ein ra*—lame, sick.

"''Present it now unto your governor; will he be pleased with you?''"

*Haqrivehu-na le-fechatekha ha-yirtzekha*—governor.

"''Or will he accept your person?''"

*O ha-yissa fanekha*—accept?

"''Entreat the favour of God, that he may be gracious unto us!''"

*Challu-na fenei-El vi-yechanenu*—entreat.

"''This has been of your doing.''"

*Mi-yedkhem hayetah zot*—your doing.

"''Will he accept any of your persons?''"

*Ha-yissa mikkhem panim*—accept?

"''Oh that there were even one among you that would shut the doors.''"

*Mi gam-bakhem ve-yisgor delatayim*—shut doors.

"''That you might not kindle fire on my altar in vain!''"

*Ve-lo-ta'iru mizbechi chinnam*—in vain.

"''I have no pleasure in you.''"

*Ein-li chefetz bakhem*—no pleasure.

"''Neither will I accept an offering at your hand.''"

*U-minchah lo-ertzeh mi-yedkhem*—not accept.

**The Key Verses (1:11-14):**
"''From the rising of the sun even unto the going down of the same my name is great among the nations.''"

*Ki mi-mizrach-shemesh ve-ad-mevo'o gadol shemi ba-goyim*—great among nations.

"''In every place offerings are presented unto my name.''"

*U-ve-khol-maqom muqtar muggash li-shemi*—offerings everywhere.

"''Even pure offerings.''"

*U-minchah tehorah*—pure.

"''For my name is great among the nations.''"

*Ki-gadol shemi ba-goyim*—great name.

"''But you profane it.''"

*Ve-attem mechalelim oto*—profane.

"''The table of the Lord is polluted.''"

*Shulchan Adonai mego'al hu*—polluted.

"''You say also: Behold, what a weariness is it!''"

*Va-amartem hinneh matelا'ah*—weariness.

"''You have snuffed at it.''"

*Ve-hippachtem oto*—snuffed.

"''You have brought that which was torn, and the lame, and the sick.''"

*Va-havetem gazul ve-et-ha-pisse'ach ve-et-ha-choleh*—torn, lame, sick.

"''Should I accept this of your hand?''"

*Ha-ertzeh otah mi-yedkhem*—accept?

"''Cursed be the deceiver.''"

*Ve-arur nokهel*—cursed deceiver.

"''Who has in his flock a male, and vows, and sacrifices... a blemished thing.''"

*Ve-yesh be-edro zakhar ve-noder ve-zove'ach mashhat la-Adonai*—blemished.

"''For I am a great King.''"

*Ki Melekh gadol ani*—great King.

"''My name is feared among the nations.''"

*U-shemi nora va-goyim*—feared.

**Archetypal Layer:** Malachi 1 contains **"I have loved you, says YHWH" (1:2)**, **"Yet you say: Wherein have you loved us?" (1:2)**—the disputation style, **"I loved Jacob; But Esau I hated" (1:2-3)**—quoted in Romans 9:13, **"YHWH is great beyond the border of Israel" (1:5)**, **"A son honours his father, and a servant his master; if then I be a father, where is my honour?" (1:6)**, **"O priests, that despise my name" (1:6)**, **"You offer polluted bread upon my altar" (1:7)**, **"when you offer the blind for sacrifice, is it no evil!" (1:8)**, **"Oh that there were even one among you that would shut the doors" (1:10)**, **"I have no pleasure in you" (1:10)**, **"from the rising of the sun even unto the going down of the same my name is great among the nations" (1:11)**, and **"I am a great King... and my name is feared among the nations" (1:14)**.

**Ethical Inversion Applied:**
- "The burden of the word of YHWH to Israel by Malachi"—burden
- "''I have loved you,' says YHWH"—loved
- "'Yet you say: Wherein have you loved us?'"—wherein loved
- "''Was not Esau Jacob's brother?''"—Esau brother
- "''Yet I loved Jacob''"—loved Jacob
- "''But Esau I hated''"—hated Esau
- "''Made his mountains a desolation''"—desolation
- "''They shall build, but I will throw down''"—throw down
- "''Men shall call them the border of wickedness''"—wickedness
- "''YHWH is great beyond the border of Israel''"—great beyond
- "''A son honours his father''"—honor
- "''If then I be a father, where is my honour?''"—where honor
- "''If I be a master, where is my fear?''"—where fear
- "''O priests, that despise my name''"—despise
- "''Wherein have we despised your name?''"—wherein
- "''You offer polluted bread upon my altar''"—polluted
- "''The table of YHWH is contemptible''"—contemptible
- "''When you offer the blind for sacrifice''"—blind
- "''When you offer the lame and sick''"—lame, sick
- "''Present it now unto your governor; will he be pleased?''"—governor
- "''Oh that there were even one among you that would shut the doors''"—shut doors
- "''I have no pleasure in you''"—no pleasure
- "''Neither will I accept an offering''"—not accept
- "''From the rising of the sun... my name is great among the nations''"—great
- "''In every place offerings are presented unto my name''"—offerings everywhere
- "''Even pure offerings''"—pure
- "''But you profane it''"—profane
- "''Behold, what a weariness is it!''"—weariness
- "''You have brought that which was torn, and the lame, and the sick''"—defective
- "''Cursed be the deceiver''"—cursed
- "''For I am a great King''"—great King
- "''My name is feared among the nations''"—feared

**Modern Equivalent:** Malachi 1 uses a distinctive disputation format. YHWH asserts love; Israel questions it (1:2). The answer: "I loved Jacob; But Esau I hated" (1:2-3). The priests despise YHWH by offering defective animals—blind, lame, sick (1:6-8). They wouldn't dare present such to their governor (1:8)! "Oh that there were even one among you that would shut the doors" (1:10)—better to close the temple than continue worthless worship. Yet "my name is great among the nations" (1:11)—Gentiles worship better than Israel's priests.

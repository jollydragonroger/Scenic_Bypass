# Malachi 3: The Messenger and the Refiner

*From the Hebrew: הִנְנִי שֹׁלֵחַ מַלְאָכִי (Hineni Shole'ach Mal'akhi) — Behold, I Send My Messenger*

---

## The Messenger of the Covenant (3:1-6)

**3:1** "Behold, I send my messenger, and he shall prepare the way before me; and the Lord, whom you seek, will suddenly come to his temple, and the messenger of the covenant, whom you delight in, behold, he comes," says YHWH of hosts.

**3:2** "But who may abide the day of his coming? And who shall stand when he appears? For he is like a refiner's fire, and like fullers' soap.

**3:3** "And he shall sit as a refiner and purifier of silver; and he shall purify the sons of Levi, and refine them as gold and silver; and there shall be they that shall offer unto YHWH offerings in righteousness.

**3:4** "Then shall the offering of Judah and Jerusalem be pleasant unto YHWH, as in the days of old, and as in ancient years.

**3:5** "And I will come near to you to judgment; and I will be a swift witness against the sorcerers, and against the adulterers, and against false swearers; and against those that oppress the hireling in his wages, the widow, and the fatherless, and that turn aside the stranger from his right, and fear not me," says YHWH of hosts.

**3:6** "For I YHWH change not; and you, O sons of Jacob, are not consumed."

---

## Robbing God (3:7-12)

**3:7** "From the days of your fathers you have turned aside from my statutes, and have not kept them. Return unto me, and I will return unto you," says YHWH of hosts. "But you say: 'Wherein shall we return?'

**3:8** "Will a man rob God? Yet you rob me. But you say: 'Wherein have we robbed you?' In tithes and heave-offerings.

**3:9** "You are cursed with the curse, yet you rob me, even this whole nation.

**3:10** "Bring the whole tithe into the store-house, that there may be food in my house, and try me now herewith," says YHWH of hosts, "if I will not open you the windows of heaven, and pour you out a blessing, that there shall be more than sufficiency.

**3:11** "And I will rebuke the devourer for your sakes, and he shall not destroy the fruits of your land; neither shall your vine cast its fruit before the time in the field," says YHWH of hosts.

**3:12** "And all nations shall call you happy; for you shall be a delightsome land," says YHWH of hosts.

---

## The Book of Remembrance (3:13-18)

**3:13** "Your words have been all too strong against me," says YHWH. "Yet you say: 'What have we spoken against you?'

**3:14** "You have said: 'It is vain to serve God; and what profit is it that we have kept his charge, and that we have walked mournfully because of YHWH of hosts?

**3:15** "'And now we call the proud happy; yea, they that work wickedness are built up; yea, they try God, and are delivered.'"

**3:16** Then they that feared YHWH spoke one with another; and YHWH hearkened, and heard, and a book of remembrance was written before him, for them that feared YHWH, and that thought upon his name.

**3:17** "And they shall be mine," says YHWH of hosts, "in the day that I do make, even my own treasure; and I will spare them, as a man spares his own son that serves him.

**3:18** "Then shall you again discern between the righteous and the wicked, between him that serves God and him that serves him not."

---

## Synthesis Notes

**Key Restorations:**

**Messenger of the Covenant (3:1-6):**
**The Key Verse (3:1):**
"''Behold, I send my messenger, and he shall prepare the way before me.''"

*Hineni shole'ach mal'akhi u-finnah-derekh lefanai*—send messenger.

**Mal'akhi:**
"My messenger"—the book's title; applied to John the Baptist in Mark 1:2.

"''The Lord, whom you seek, will suddenly come to his temple.''"

*U-fit'om yavo el-heikhalo ha-Adon asher-attem mevaqqeshim*—Lord comes.

"''The messenger of the covenant, whom you delight in.''"

*U-mal'akh ha-berit asher-attem chafetzim*—covenant messenger.

"''Behold, he comes,' says YHWH of hosts.''"

*Hinneh-va amar YHWH tzeva'ot*—he comes.

**The Key Verses (3:2-4):**
"''Who may abide the day of his coming?''"

*U-mi mekhalkkel et-yom bo'o*—who abide?

"''Who shall stand when he appears?''"

*U-mi ha-omed be-hera'oto*—who stand?

"''He is like a refiner's fire.''"

*Ki-hu ke-esh metzaref*—refiner's fire.

"''Like fullers' soap.''"

*U-khe-vorit mekhabbsim*—fullers' soap.

"''He shall sit as a refiner and purifier of silver.''"

*Ve-yashav metzaref u-metaher kesef*—refiner.

"''He shall purify the sons of Levi.''"

*Ve-tiher et-benei-Levi*—purify Levi.

"''Refine them as gold and silver.''"

*Ve-ziqqaq otam ka-zahav ve-kha-kkasef*—refine.

"''There shall be they that shall offer unto YHWH offerings in righteousness.''"

*Ve-hayu la-YHWH maggishei minchah bi-tzdaqah*—righteous offerings.

"''The offering of Judah and Jerusalem be pleasant unto YHWH.''"

*Ve-arvah la-YHWH minchat Yehudah vi-Yrushalayim*—pleasant.

"''As in the days of old, and as in ancient years.''"

*Ki-yemei olam u-khe-shanim qadmoniyyot*—ancient days.

**The Key Verses (3:5-6):**
"''I will come near to you to judgment.''"

*Ve-qaravti aleikhem la-mishpat*—judgment.

"''I will be a swift witness.''"

*Ve-hayiti ed memaher*—swift witness.

"''Against the sorcerers, and against the adulterers, and against false swearers.''"

*Ba-mekashefim u-va-mena'afim u-va-nishba'im la-shaqer*—sorcerers, adulterers, false swearers.

"''Those that oppress the hireling in his wages, the widow, and the fatherless.''"

*U-ve-oshqei sekhar sakhir almanah ve-yatom*—oppress.

"''That turn aside the stranger from his right.''"

*U-mattei-ger*—turn aside stranger.

"''Fear not me.''"

*Ve-lo yere'uni*—don't fear.

"''For I YHWH change not.''"

*Ki ani YHWH lo shaniti*—don't change.

"''You, O sons of Jacob, are not consumed.''"

*Ve-attem benei-Ya'aqov lo khelitem*—not consumed.

**Robbing God (3:7-12):**
**The Key Verses (3:7-9):**
"''From the days of your fathers you have turned aside from my statutes.''"

*Le-mi-yemei avoteikhem sartem me-chuqqai ve-lo shemartem*—turned aside.

"''Return unto me, and I will return unto you.''"

*Shuvu elai ve-ashuvah aleikhem*—return.

"''Wherein shall we return?''"

*Bammeh nashuv*—wherein?

"''Will a man rob God?''"

*Ha-yiqba adam Elohim*—rob God?

"''Yet you rob me.''"

*Ki attem qove'im oti*—rob me.

"''Wherein have we robbed you?''"

*Bammeh qeva'nukha*—wherein?

"''In tithes and heave-offerings.''"

*Ha-ma'aser ve-ha-terumah*—tithes.

"''You are cursed with the curse, yet you rob me.''"

*Ba-me'erah attem ne'arim ve-oti attem qove'im*—cursed.

"''Even this whole nation.''"

*Ha-goy kullo*—whole nation.

**The Key Verses (3:10-12):**
"''Bring the whole tithe into the store-house.''"

*Havi'u et-kol-ha-ma'aser el-beit ha-otzar*—bring tithe.

"''That there may be food in my house.''"

*Vi-yhi teref be-veiti*—food in house.

"''Try me now herewith.''"

*U-vechanuni na ba-zot*—try me.

"''If I will not open you the windows of heaven.''"

*Im-lo eftach lakhem et arubot ha-shamayim*—windows of heaven.

"''Pour you out a blessing, that there shall be more than sufficiency.''"

*Va-hariqoti lakhem berakhah ad-beli-dai*—blessing.

**Ad-Beli-Dai:**
"Until there is no more need" / "more than enough."

"''I will rebuke the devourer for your sakes.''"

*Ve-ga'arti lakhem ba-okhel*—rebuke devourer.

"''He shall not destroy the fruits of your land.''"

*Ve-lo-yashchit lakhem et-peri ha-adamah*—not destroy.

"''Your vine cast not its fruit before the time.''"

*Ve-lo-teshakkkel lakhem ha-gefen ba-sadeh*—vine.

"''All nations shall call you happy.''"

*Ve-ishru etkhem kol-ha-goyim*—happy.

"''You shall be a delightsome land.''"

*Ki-tihyu attem eretz chefetz*—delightsome.

**Book of Remembrance (3:13-18):**
**The Key Verses (3:13-15):**
"''Your words have been all too strong against me.''"

*Chazqu alai divreikhem*—strong words.

"''What have we spoken against you?''"

*Mah-nidbbarnu alekha*—what spoken?

"''You have said: It is vain to serve God.''"

*Amartem shav avod Elohim*—vain to serve.

"''What profit is it that we have kept his charge?''"

*U-mah-betza ki shamarnu mishmartoו*—what profit?

"''That we have walked mournfully because of YHWH of hosts?''"

*Ve-khi halakhnu qedorannit mi-penei YHWH tzeva'ot*—mournfully.

"''Now we call the proud happy.''"

*Ve-attah anachnu me'asherim zedim*—proud happy.

"''They that work wickedness are built up.''"

*Gam-nivnu osei rish'ah*—built up.

"''They try God, and are delivered.''"

*Gam bachanu Elohim va-yimmaleתu*—delivered.

**The Key Verses (3:16-18):**
"'They that feared YHWH spoke one with another.'"

*Az nidberu yir'ei YHWH ish el-re'ehu*—spoke.

"'YHWH hearkened, and heard.'"

*Va-yaqshev YHWH va-yishma*—hearkened.

"'A book of remembrance was written before him.'"

*Va-yikkateiv sefer zikkaron lefanav*—book of remembrance.

"'For them that feared YHWH, and that thought upon his name.'"

*Le-yir'ei YHWH u-le-choshevei shemo*—feared, thought.

"''They shall be mine... in the day that I do make, even my own treasure.''"

*Ve-hayu li... la-yom asher ani oseh segullah*—my treasure.

**Segullah:**
"Special treasure/possession."

"''I will spare them, as a man spares his own son that serves him.''"

*Ve-chamalti aleihem ka-asher yachmol ish al-beno ha-oved oto*—spare.

"''Then shall you again discern between the righteous and the wicked.''"

*Ve-shavtem u-re'item bein tzaddiq le-rasha*—discern.

"''Between him that serves God and him that serves him not.''"

*Bein oved Elohim la-asher lo avado*—serve vs. not serve.

**Archetypal Layer:** Malachi 3 contains **"Behold, I send my messenger, and he shall prepare the way before me" (3:1)**—applied to John the Baptist, **"the Lord, whom you seek, will suddenly come to his temple" (3:1)**, **"the messenger of the covenant" (3:1)**, **"who may abide the day of his coming?" (3:2)**, **"he is like a refiner's fire, and like fullers' soap" (3:2)**, **"he shall purify the sons of Levi" (3:3)**, **"I will be a swift witness against the sorcerers, and against the adulterers" (3:5)**, **"I YHWH change not" (3:6)**, **"Will a man rob God? Yet you rob me... In tithes and heave-offerings" (3:8)**, **"Bring the whole tithe into the store-house... try me now herewith... if I will not open you the windows of heaven, and pour you out a blessing" (3:10)**, **"a book of remembrance was written before him, for them that feared YHWH" (3:16)**, and **"they shall be mine... even my own treasure" (3:17)**.

**Ethical Inversion Applied:**
- "''Behold, I send my messenger''"—send messenger
- "''He shall prepare the way before me''"—prepare way
- "''The Lord, whom you seek, will suddenly come to his temple''"—Lord comes
- "''The messenger of the covenant''"—covenant messenger
- "''Who may abide the day of his coming?''"—who abide
- "''Who shall stand when he appears?''"—who stand
- "''He is like a refiner's fire''"—refiner's fire
- "''Like fullers' soap''"—soap
- "''He shall sit as a refiner and purifier of silver''"—refiner
- "''He shall purify the sons of Levi''"—purify
- "''Refine them as gold and silver''"—refine
- "''The offering of Judah and Jerusalem be pleasant''"—pleasant
- "''I will come near to you to judgment''"—judgment
- "''I will be a swift witness''"—swift witness
- "''Against the sorcerers, and against the adulterers''"—sorcerers
- "''Those that oppress the hireling... the widow... the fatherless''"—oppress
- "''I YHWH change not''"—don't change
- "''You, O sons of Jacob, are not consumed''"—not consumed
- "''Return unto me, and I will return unto you''"—return
- "''Will a man rob God?''"—rob God
- "''Yet you rob me''"—rob me
- "''In tithes and heave-offerings''"—tithes
- "''You are cursed with the curse''"—cursed
- "''Bring the whole tithe into the store-house''"—bring tithe
- "''Try me now herewith''"—try me
- "''If I will not open you the windows of heaven''"—windows of heaven
- "''Pour you out a blessing, that there shall be more than sufficiency''"—blessing
- "''I will rebuke the devourer''"—rebuke devourer
- "''All nations shall call you happy''"—happy
- "''You shall be a delightsome land''"—delightsome
- "''Your words have been all too strong against me''"—strong words
- "''It is vain to serve God''"—vain to serve
- "''We call the proud happy''"—proud happy
- "'They that feared YHWH spoke one with another'"—spoke
- "'YHWH hearkened, and heard'"—heard
- "'A book of remembrance was written before him'"—book of remembrance
- "''They shall be mine... even my own treasure''"—treasure
- "''I will spare them''"—spare
- "''Then shall you again discern between the righteous and the wicked''"—discern

**Modern Equivalent:** Malachi 3:1 is quoted in Mark 1:2 for John the Baptist. The refiner's fire (3:2) purifies the priesthood. "Will a man rob God?" (3:8) introduces the famous tithing passage—"try me now" (3:10) is YHWH's challenge, promising open windows of heaven. The "book of remembrance" (3:16) records the faithful. "They shall be mine... even my own treasure" (3:17) describes God's special possession of those who fear Him.

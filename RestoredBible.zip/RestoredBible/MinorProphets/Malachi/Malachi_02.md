# Malachi 2: Warning to Priests and Faithless Judah

*From the Hebrew: וְעַתָּה אֲלֵיכֶם הַמִּצְוָה הַזֹּאת הַכֹּהֲנִים (Ve-Attah Aleikhem Ha-Mitzvah Ha-Zot Ha-Kohanim) — And Now, O Priests, This Commandment Is for You*

---

## Warning to Priests (2:1-9)

**2:1** "And now, O ye priests, this commandment is for you.

**2:2** "If you will not hearken, and if you will not lay it to heart, to give glory unto my name," says YHWH of hosts, "then will I send the curse upon you, and I will curse your blessings; yea, I have cursed them already, because you do not lay it to heart.

**2:3** "Behold, I will rebuke the seed for your hurt, and will spread dung upon your faces, even the dung of your sacrifices; and you shall be taken away unto it.

**2:4** "And you shall know that I have sent this commandment unto you, that my covenant might be with Levi," says YHWH of hosts.

**2:5** "My covenant was with him of life and peace, and I gave them to him, and of fear, and he feared me, and was afraid of my name.

**2:6** "The law of truth was in his mouth, and unrighteousness was not found in his lips; he walked with me in peace and uprightness, and did turn many away from iniquity.

**2:7** "For the priest's lips should keep knowledge, and they should seek the law at his mouth; for he is the messenger of YHWH of hosts.

**2:8** "But you are turned aside out of the way; you have caused many to stumble in the law; you have corrupted the covenant of Levi," says YHWH of hosts.

**2:9** "Therefore have I also made you contemptible and base before all the people, according as you have not kept my ways, but have had respect of persons in the law."

---

## Faithlessness in Marriage (2:10-16)

**2:10** Have we not all one father? Has not one God created us? Why do we deal treacherously every man against his brother, profaning the covenant of our fathers?

**2:11** Judah has dealt treacherously, and an abomination is committed in Israel and in Jerusalem; for Judah has profaned the holiness of YHWH which he loves, and has married the daughter of a strange god.

**2:12** May YHWH cut off to the man that does this, him that calls and him that answers, out of the tents of Jacob, and him that offers an offering unto YHWH of hosts.

**2:13** And this further you do: you cover the altar of YHWH with tears, with weeping, and with sighing, insomuch that he regards not the offering any more, neither receives it with good will at your hand.

**2:14** Yet you say: "Wherefore?" Because YHWH has been witness between you and the wife of your youth, against whom you have dealt treacherously, though she is your companion, and the wife of your covenant.

**2:15** And did He not make one, although He had the residue of the spirit? And wherefore one? That He might seek a godly seed. Therefore take heed to your spirit, and let none deal treacherously against the wife of his youth.

**2:16** "For I hate putting away," says YHWH, the God of Israel, "and him that covers his garment with violence," says YHWH of hosts; "therefore take heed to your spirit, that you deal not treacherously."

---

## Where Is the God of Justice? (2:17)

**2:17** You have wearied YHWH with your words. Yet you say: "Wherein have we wearied him?" In that you say: "Every one that does evil is good in the sight of YHWH, and he delights in them"; or: "Where is the God of justice?"

---

## Synthesis Notes

**Key Restorations:**

**Warning to Priests (2:1-9):**
**The Key Verses (2:1-3):**
"''This commandment is for you.''"

*Ha-mitzvah ha-zot aleikhem*—commandment for you.

"''If you will not hearken, and if you will not lay it to heart.''"

*Im-lo tishme'u ve-im-lo tasimu al-lev*—if not hearken.

"''To give glory unto my name.''"

*La-tet kavod li-shemi*—give glory.

"''I will send the curse upon you, and I will curse your blessings.''"

*Ve-shillachti vakhem et-ha-me'erah ve-aroti et-birkhoteikhem*—curse blessings.

"''I have cursed them already.''"

*Ve-gam arotיah*—already cursed.

"''Because you do not lay it to heart.''"

*Ki einkhem samim al-lev*—not to heart.

"''I will rebuke the seed for your hurt.''"

*Hineni go'er lakhem et-ha-zera*—rebuke seed.

"''Will spread dung upon your faces.''"

*Ve-zeritי feresh al-peneikhem*—dung on faces.

"''Even the dung of your sacrifices.''"

*Peresh chaggeikem*—festival dung.

**The Key Verses (2:4-7):**
"''You shall know that I have sent this commandment unto you.''"

*Vi-yda'tem ki shillachti aleikhem et ha-mitzvah ha-zot*—know.

"''That my covenant might be with Levi.''"

*Lihyot beriti et-Levi*—covenant with Levi.

"''My covenant was with him of life and peace.''"

*Beriti hayetah itto ha-chayyim ve-ha-shalom*—life, peace.

"''I gave them to him, and of fear.''"

*Va-ettenem-lo mora*—gave fear.

"''He feared me, and was afraid of my name.''"

*Va-yira'eni u-mi-penei shemi nichat hu*—feared.

"''The law of truth was in his mouth.''"

*Torat emet hayetah be-fihu*—truth.

"''Unrighteousness was not found in his lips.''"

*Ve-avlah lo-nimtza bi-sefatav*—no unrighteousness.

"''He walked with me in peace and uprightness.''"

*Be-shalom u-ve-mishor halakh itti*—walked with me.

"''Did turn many away from iniquity.''"

*Ve-rabbim heshiv me-avon*—turned many.

"''The priest's lips should keep knowledge.''"

*Ki-siftei khohen yishmeru da'at*—keep knowledge.

"''They should seek the law at his mouth.''"

*Ve-torah yevaqshu mi-pihu*—seek Torah.

"''He is the messenger of YHWH of hosts.''"

*Ki mal'akh YHWH-tzeva'ot hu*—messenger.

**Mal'akh:**
"Messenger"—same word as "Malachi."

**The Key Verses (2:8-9):**
"''You are turned aside out of the way.''"

*Ve-attem sartem min-ha-derekh*—turned aside.

"''You have caused many to stumble in the law.''"

*Hikshalttem rabbim ba-torah*—stumble.

"''You have corrupted the covenant of Levi.''"

*Shiחattem berit ha-Levi*—corrupted.

"''I have made you contemptible and base before all the people.''"

*Ve-gam-ani natatti etkhem nivzim u-shefalim le-khol-ha-am*—contemptible.

"''You have not kept my ways.''"

*Einekhem shomerim et-derakhay*—not kept.

"''Have had respect of persons in the law.''"

*Ve-nosim panim ba-torah*—partiality.

**Faithlessness in Marriage (2:10-16):**
**The Key Verses (2:10-12):**
"'Have we not all one father?'"

*Ha-lo av echad le-khullanu*—one father.

"'Has not one God created us?'"

*Ha-lo El echad bera'anu*—one God.

"'Why do we deal treacherously every man against his brother?'"

*Maddu'a nivgod ish be-achiv*—treacherous.

"'Profaning the covenant of our fathers?'"

*Le-challel berit avoteinu*—profane covenant.

"'Judah has dealt treacherously.'"

*Bagdah Yehudah*—Judah treacherous.

"'An abomination is committed in Israel and in Jerusalem.'"

*Ve-to'evah ne'estah ve-Yisra'el u-vi-Yrushalayim*—abomination.

"'Judah has profaned the holiness of YHWH which he loves.'"

*Ki chillel Yehudah qodesh YHWH asher ahev*—profaned holiness.

"'Has married the daughter of a strange god.'"

*U-va'al bat-el nekhar*—strange god's daughter.

"'May YHWH cut off to the man that does this.'"

*Yakhret YHWH la-ish asher ya'asennah*—cut off.

**The Key Verses (2:13-16):**
"'You cover the altar of YHWH with tears, with weeping.'"

*Ve-zot shenit ta'asu kassot dim'ah et-mizbach YHWH*—tears.

"'He regards not the offering any more.'"

*Me-ein od penot el-ha-minchah*—not regard.

"'Yet you say: Wherefore?'"

*Va-amartem al-mah*—wherefore?

"''YHWH has been witness between you and the wife of your youth.''"

*Ki YHWH he'id beinekha u-vein eshet ne'urekha*—witness.

"''Against whom you have dealt treacherously.''"

*Asher attah bagadtah bah*—treacherous.

"''Though she is your companion, and the wife of your covenant.''"

*Ve-hi chavertekha ve-eshet beritekha*—companion, covenant wife.

"''Did He not make one, although He had the residue of the spirit?''"

*Ve-lo-echad asah ve-she'ar ruach lo*—made one.

"''That He might seek a godly seed.''"

*U-mah ha-echad mevaqqesh zera Elohim*—godly seed.

"''Take heed to your spirit, and let none deal treacherously.''"

*Ve-nishmartem be-ruchakhem u-ve-eshet ne'urekha al-yivgod*—take heed.

"''For I hate putting away,' says YHWH.''"

*Ki-sane shalach amar YHWH*—hate divorce.

"''Him that covers his garment with violence.''"

*Ve-khissah chamas al-levusho*—violence.

"''Take heed to your spirit, that you deal not treacherously.''"

*Ve-nishmartem be-ruchakhem ve-lo tivgodu*—don't be treacherous.

**Where Is the God of Justice? (2:17):**
**The Key Verse (2:17):**
"'You have wearied YHWH with your words.'"

*Hog'atem YHWH be-divreikem*—wearied.

"'Yet you say: Wherein have we wearied him?'"

*Va-amartem bammeh hoga'nu*—wherein?

"''Every one that does evil is good in the sight of YHWH, and he delights in them.''"

*Kol-oseh ra tov be-einei YHWH u-vahem hu chafetz*—evil is good.

"''Where is the God of justice?''"

*O ayyeh Elohei ha-mishpat*—where is justice?

**Archetypal Layer:** Malachi 2 contains **"this commandment is for you" (2:1)**, **"I will curse your blessings" (2:2)**, **"will spread dung upon your faces" (2:3)**, **"My covenant was with him [Levi] of life and peace" (2:5)**, **"The law of truth was in his mouth... he walked with me in peace and uprightness, and did turn many away from iniquity" (2:6)**, **"the priest's lips should keep knowledge... for he is the messenger of YHWH of hosts" (2:7)**, **"you have caused many to stumble in the law; you have corrupted the covenant of Levi" (2:8)**, **"Have we not all one father? Has not one God created us?" (2:10)**, **"Judah has... married the daughter of a strange god" (2:11)**, **"YHWH has been witness between you and the wife of your youth" (2:14)**, **"For I hate putting away" (2:16)**, and **"Where is the God of justice?" (2:17)**.

**Ethical Inversion Applied:**
- "''This commandment is for you''"—commandment
- "''If you will not hearken''"—if not
- "''To give glory unto my name''"—glory
- "''I will send the curse upon you''"—curse
- "''I will curse your blessings''"—curse blessings
- "''I will rebuke the seed''"—rebuke
- "''Will spread dung upon your faces''"—dung
- "''My covenant might be with Levi''"—Levi's covenant
- "''My covenant was with him of life and peace''"—life, peace
- "''He feared me''"—feared
- "''The law of truth was in his mouth''"—truth
- "''He walked with me in peace and uprightness''"—walked
- "''Did turn many away from iniquity''"—turned many
- "''The priest's lips should keep knowledge''"—knowledge
- "''They should seek the law at his mouth''"—seek Torah
- "''He is the messenger of YHWH of hosts''"—messenger
- "''You are turned aside out of the way''"—turned aside
- "''You have caused many to stumble''"—stumble
- "''You have corrupted the covenant of Levi''"—corrupted
- "''I have made you contemptible and base''"—contemptible
- "''You have had respect of persons in the law''"—partiality
- "'Have we not all one father?'"—one father
- "'Has not one God created us?'"—one God
- "'Why do we deal treacherously?'"—treacherous
- "'Judah has dealt treacherously'"—treacherous
- "'An abomination is committed'"—abomination
- "'Has married the daughter of a strange god'"—strange god
- "'You cover the altar of YHWH with tears'"—tears
- "''YHWH has been witness between you and the wife of your youth''"—witness
- "''She is your companion, and the wife of your covenant''"—covenant wife
- "''That He might seek a godly seed''"—godly seed
- "''Take heed to your spirit''"—take heed
- "''For I hate putting away''"—hate divorce
- "''Him that covers his garment with violence''"—violence
- "'You have wearied YHWH with your words'"—wearied
- "''Every one that does evil is good in the sight of YHWH''"—evil good
- "''Where is the God of justice?''"—where is justice

**Modern Equivalent:** Malachi 2 attacks corrupt priests—"I will spread dung upon your faces" (2:3) is shockingly graphic. The ideal priest (Levi) walked with God and turned many from iniquity (2:6). The actual priests cause stumbling and show partiality (2:8-9). The marriage section (2:10-16) condemns intermarriage with pagans AND divorce from Jewish wives. "I hate putting away" (2:16) shows YHWH's heart. The chapter ends with cynical questioning: "Where is the God of justice?" (2:17)—answered in chapter 3.

# Jonah 3: Nineveh Repents

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֶל־יוֹנָה שֵׁנִית (Va-Yehi Devar-YHWH El-Yonah Shenit) — And the Word of YHWH Came unto Jonah the Second Time*

---

## Second Commission (3:1-4)

**3:1** And the word of YHWH came unto Jonah the second time, saying:

**3:2** "Arise, go unto Nineveh, that great city, and proclaim unto it the proclamation that I bid you."

**3:3** So Jonah arose, and went unto Nineveh, according to the word of YHWH. Now Nineveh was an exceeding great city, of three days' journey.

**3:4** And Jonah began to enter into the city a day's journey, and he proclaimed, and said: "Yet forty days, and Nineveh shall be overthrown."

---

## Nineveh's Repentance (3:5-9)

**3:5** And the people of Nineveh believed God; and they proclaimed a fast, and put on sackcloth, from the greatest of them even to the least of them.

**3:6** And the tidings reached the king of Nineveh, and he arose from his throne, and laid his robe from him, and covered him with sackcloth, and sat in ashes.

**3:7** And he caused it to be proclaimed and published through Nineveh by the decree of the king and his nobles, saying: "Let neither man nor beast, herd nor flock, taste anything; let them not feed, nor drink water;

**3:8** "But let them be covered with sackcloth, both man and beast, and let them cry mightily unto God; yea, let them turn every one from his evil way, and from the violence that is in their hands.

**3:9** "Who knows whether God will not turn and repent, and turn away from his fierce anger, that we perish not?"

---

## God Relents (3:10)

**3:10** And God saw their works, that they turned from their evil way; and God repented of the evil, which he said he would do unto them; and he did it not.

---

## Synthesis Notes

**Key Restorations:**

**Second Commission (3:1-4):**
**The Key Verses (3:1-2):**
"The word of YHWH came unto Jonah the second time."

*Va-yehi devar-YHWH el-Yonah shenit*—second time.

"'Arise, go unto Nineveh, that great city.'"

*Qum lekh el-Nineveh ha-ir ha-gedolah*—great city.

"'Proclaim unto it the proclamation that I bid you.'"

*U-qera eleiha et-ha-qeri'ah asher anokhi dover elekha*—proclaim.

**The Key Verses (3:3-4):**
"Jonah arose, and went unto Nineveh, according to the word of YHWH."

*Va-yaqom Yonah va-yelekh el-Nineveh ki-devar YHWH*—obeyed.

"Nineveh was an exceeding great city, of three days' journey."

*Ve-Nineveh hayetah ir-gedolah le-Elohim mahalakh sheloshet yamim*—three days' journey.

**Ir-Gedolah Le-Elohim:**
"A great city to God" / "an exceedingly great city."

"Jonah began to enter into the city a day's journey."

*Va-yachel Yonah lavo va-ir mahalakh yom echad*—one day in.

"He proclaimed, and said: 'Yet forty days, and Nineveh shall be overthrown.'"

*Va-yiqra va-yomar od arba'im yom ve-Nineveh nehpakhet*—forty days.

**Arba'im Yom:**
"Forty days"—a period of testing/judgment.

**Nehpakhet:**
"Overthrown"—same word used for Sodom's destruction.

**Nineveh's Repentance (3:5-9):**
**The Key Verse (3:5):**
"The people of Nineveh believed God."

*Va-ya'aminu anshei Nineveh be-Elohim*—believed God.

"They proclaimed a fast, and put on sackcloth."

*Va-yiqre'u tzom va-yilbeshu saqqim*—fast, sackcloth.

"From the greatest of them even to the least of them."

*Mi-gedolam ve-ad-qetannam*—all classes.

**The Key Verses (3:6-9):**
"The tidings reached the king of Nineveh."

*Va-yigga ha-davar el-melekh Nineveh*—reached king.

"He arose from his throne, and laid his robe from him."

*Va-yaqom mi-khis'o va-ya'aver adarto me-alav*—left throne.

"Covered him with sackcloth, and sat in ashes."

*Va-yekhas saq va-yeshev al-ha-efer*—sackcloth, ashes.

"He caused it to be proclaimed and published through Nineveh."

*Va-yaz'eq va-yomer be-Nineveh*—proclamation.

"By the decree of the king and his nobles."

*Mi-ta'am ha-melekh u-gedolav*—royal decree.

"'Let neither man nor beast, herd nor flock, taste anything.'"

*Ha-adam ve-ha-behemah ha-baqar ve-ha-tzon al-yit'amu me'umah*—no eating.

"'Let them not feed, nor drink water.'"

*Al-yir'u u-mayim al-yishtu*—no drinking.

"'Let them be covered with sackcloth, both man and beast.'"

*Ve-yitkassu saqqim ha-adam ve-ha-behemah*—all in sackcloth.

"'Let them cry mightily unto God.'"

*Ve-yiqre'u el-Elohim be-chozqah*—cry mightily.

"'Let them turn every one from his evil way.'"

*Ve-yashuvu ish mi-darko ha-ra'ah*—turn from evil.

"'And from the violence that is in their hands.'"

*U-min-he-chamas asher be-khappeihem*—from violence.

"'Who knows whether God will not turn and repent.'"

*Mi-yode'a yashuv ve-nicham ha-Elohim*—who knows?

"'Turn away from his fierce anger, that we perish not?'"

*Ve-shav me-charon appo ve-lo noved*—not perish.

**God Relents (3:10):**
**The Key Verse (3:10):**
"God saw their works, that they turned from their evil way."

*Va-yar ha-Elohim et-ma'aseihem ki-shavu mi-darkam ha-ra'ah*—saw repentance.

"God repented of the evil, which he said he would do unto them."

*Va-yinnachem ha-Elohim al-ha-ra'ah asher-dibber la'asot-lahem*—repented.

"He did it not."

*Ve-lo asah*—didn't do it.

**Archetypal Layer:** Jonah 3 contains **the second commission (3:1-2)**, **Jonah's obedience this time (3:3)**, **"Nineveh was an exceeding great city, of three days' journey" (3:3)**, **Jonah's five-word sermon: "Yet forty days, and Nineveh shall be overthrown" (3:4)**, **"the people of Nineveh believed God" (3:5)**, **universal repentance: "from the greatest of them even to the least of them" (3:5)**, **the king's response: left throne, sackcloth, ashes (3:6)**, **royal decree: fasting for humans and animals (3:7-8)**, **"let them turn every one from his evil way, and from the violence that is in their hands" (3:8)**, **"Who knows whether God will not turn and repent?" (3:9)**, and **"God saw their works, that they turned from their evil way; and God repented of the evil... and he did it not" (3:10)**.

**Ethical Inversion Applied:**
- "The word of YHWH came unto Jonah the second time"—second chance
- "'Arise, go unto Nineveh'"—go
- "'Proclaim unto it the proclamation'"—proclaim
- "Jonah arose, and went unto Nineveh"—obeyed
- "Nineveh was an exceeding great city"—great city
- "Of three days' journey"—huge
- "Jonah began to enter into the city a day's journey"—entered
- "'Yet forty days, and Nineveh shall be overthrown'"—forty days
- "The people of Nineveh believed God"—believed
- "They proclaimed a fast, and put on sackcloth"—fast, sackcloth
- "From the greatest of them even to the least of them"—all classes
- "The tidings reached the king of Nineveh"—reached king
- "He arose from his throne"—left throne
- "Laid his robe from him"—removed robe
- "Covered him with sackcloth, and sat in ashes"—sackcloth, ashes
- "He caused it to be proclaimed"—decree
- "'Let neither man nor beast... taste anything'"—total fast
- "'Let them not feed, nor drink water'"—no water
- "'Let them be covered with sackcloth, both man and beast'"—animals too
- "'Let them cry mightily unto God'"—cry mightily
- "'Let them turn every one from his evil way'"—turn from evil
- "'And from the violence that is in their hands'"—from violence
- "'Who knows whether God will not turn and repent'"—who knows
- "'That we perish not'"—not perish
- "God saw their works, that they turned from their evil way"—saw repentance
- "God repented of the evil"—God relented
- "He did it not"—didn't destroy

**Modern Equivalent:** Jonah 3 is remarkable. Jonah's sermon is minimal—eight words in Hebrew (five in English). Yet Nineveh repents completely: the people believe, fast, wear sackcloth. The king leaves his throne for ashes and extends the fast to animals. The key phrase "who knows?" (3:9) echoes Joel 2:14. God's response: seeing genuine repentance (turning from evil and violence), He relents. The pagan city outperforms Israel.

# Jonah 2: Prayer from the Fish's Belly

*From the Hebrew: וַיִּתְפַּלֵּל יוֹנָה אֶל־יְהוָה (Va-Yitpallel Yonah El-YHWH) — And Jonah Prayed unto YHWH*

---

## Jonah's Prayer (2:1-9)

**2:1** And Jonah prayed unto YHWH his God out of the fish's belly.

**2:2** And he said: "I called out of my affliction unto YHWH, and he answered me; out of the belly of the nether-world cried I, and you heard my voice.

**2:3** "For you did cast me into the depth, in the heart of the seas, and the flood was round about me; all your waves and your billows passed over me.

**2:4** "And I said: 'I am cast out from before your eyes'; yet I will look again toward your holy temple.

**2:5** "The waters compassed me about, even to the soul; the deep was round about me; the weeds were wrapped about my head.

**2:6** "I went down to the bottoms of the mountains; the earth with her bars closed upon me for ever; yet have you brought up my life from the pit, O YHWH my God.

**2:7** "When my soul fainted within me, I remembered YHWH; and my prayer came in unto you, into your holy temple.

**2:8** "They that regard lying vanities forsake their own mercy.

**2:9** "But I will sacrifice unto you with the voice of thanksgiving; that which I have vowed I will pay. Salvation is of YHWH."

---

## Deliverance (2:10)

**2:10** And YHWH spoke unto the fish, and it vomited out Jonah upon the dry land.

---

## Synthesis Notes

**Key Restorations:**

**Jonah's Prayer (2:1-9):**
**The Key Verse (2:1):**
"Jonah prayed unto YHWH his God out of the fish's belly."

*Va-yitpallel Yonah el-YHWH Elohav mi-me'ei ha-dagah*—prayed from fish.

**The Key Verse (2:2):**
"'I called out of my affliction unto YHWH, and he answered me.'"

*Qarati mi-tzarah li el-YHWH va-ya'aneni*—called, answered.

"'Out of the belly of the nether-world cried I.'"

*Mi-beten She'ol shivva'ti*—belly of Sheol.

"'You heard my voice.'"

*Shama'ta qoli*—you heard.

**Beten She'ol:**
"Belly of Sheol"—the fish's belly = realm of death.

**The Key Verse (2:3):**
"'You did cast me into the depth, in the heart of the seas.'"

*Va-tashlikheני metzulah bi-levav yammim*—cast into deep.

"'The flood was round about me.'"

*Ve-nahar yesoveveni*—flood surrounded.

"'All your waves and your billows passed over me.'"

*Kol-mishbarekha ve-gallekha alai avaru*—your waves.

**The Key Verse (2:4):**
"''I am cast out from before your eyes.''"

*Nigrashti mi-neged einekha*—cast from sight.

"'Yet I will look again toward your holy temple.'"

*Akh osif le-habbit el-heikhal qodshekha*—look to temple.

**The Key Verse (2:5):**
"'The waters compassed me about, even to the soul.'"

*Afafuni mayim ad-nefesh*—waters to soul.

"'The deep was round about me.'"

*Tehom yesoveveni*—deep surrounded.

"'The weeds were wrapped about my head.'"

*Suf chavush le-roshi*—weeds wrapped.

**The Key Verse (2:6):**
"'I went down to the bottoms of the mountains.'"

*Le-qitzvi harim yaradti*—bottoms of mountains.

"'The earth with her bars closed upon me for ever.'"

*Ha-aretz bericheiha va'adi le-olam*—bars closed.

"'Yet have you brought up my life from the pit, O YHWH my God.'"

*Va-ta'al mi-shachat chayyai YHWH Elohai*—brought up from pit.

**Shachat:**
"Pit"—the grave, Sheol.

**The Key Verse (2:7):**
"'When my soul fainted within me, I remembered YHWH.'"

*Be-hit'attef alai nafshi et-YHWH zakharti*—remembered YHWH.

"'My prayer came in unto you, into your holy temple.'"

*Va-tavo elekha tefilati el-heikhal qodshekha*—prayer reached temple.

**The Key Verses (2:8-9):**
"'They that regard lying vanities forsake their own mercy.'"

*Meshammrim havlei-shav chasdam ya'azovu*—forsake mercy.

**Havlei-Shav:**
"Lying vanities"—false gods, idols.

"'But I will sacrifice unto you with the voice of thanksgiving.'"

*Va-ani be-qol todah ezbechah-lakh*—thanksgiving sacrifice.

"'That which I have vowed I will pay.'"

*Asher nadarti ashallemiah*—pay vows.

"'Salvation is of YHWH.'"

*Yeshu'atah la-YHWH*—salvation is YHWH's.

**Yeshu'atah La-YHWH:**
"Salvation belongs to YHWH"—the climactic confession.

**Deliverance (2:10):**
**The Key Verse (2:10):**
"YHWH spoke unto the fish."

*Va-yomer YHWH la-dag*—YHWH spoke to fish.

"It vomited out Jonah upon the dry land."

*Va-yaqe et-Yonah el-ha-yabashah*—vomited onto land.

**Archetypal Layer:** Jonah 2 is **Jonah's psalm of thanksgiving from the fish's belly**, containing **"I called out of my affliction unto YHWH, and he answered me" (2:2)**, **"out of the belly of the nether-world cried I" (2:2)**—Sheol, **"You did cast me into the depth, in the heart of the seas" (2:3)**, **"I am cast out from before your eyes; yet I will look again toward your holy temple" (2:4)**, **"the weeds were wrapped about my head" (2:5)**, **"I went down to the bottoms of the mountains... yet have you brought up my life from the pit" (2:6)**, **"When my soul fainted within me, I remembered YHWH" (2:7)**, **"They that regard lying vanities forsake their own mercy" (2:8)**, **"Salvation is of YHWH" (2:9)**, and **"YHWH spoke unto the fish, and it vomited out Jonah upon the dry land" (2:10)**.

**Ethical Inversion Applied:**
- "Jonah prayed unto YHWH his God out of the fish's belly"—prayer from fish
- "'I called out of my affliction unto YHWH'"—called
- "'He answered me'"—answered
- "'Out of the belly of the nether-world cried I'"—Sheol
- "'You heard my voice'"—heard
- "'You did cast me into the depth'"—cast into deep
- "'In the heart of the seas'"—heart of seas
- "'The flood was round about me'"—flood
- "'All your waves and your billows passed over me'"—waves
- "''I am cast out from before your eyes''"—cast out
- "'Yet I will look again toward your holy temple'"—look to temple
- "'The waters compassed me about, even to the soul'"—waters to soul
- "'The deep was round about me'"—deep
- "'The weeds were wrapped about my head'"—weeds
- "'I went down to the bottoms of the mountains'"—bottoms
- "'The earth with her bars closed upon me for ever'"—bars closed
- "'Yet have you brought up my life from the pit'"—brought up
- "'When my soul fainted within me, I remembered YHWH'"—remembered
- "'My prayer came in unto you'"—prayer reached
- "'They that regard lying vanities forsake their own mercy'"—forsake mercy
- "'I will sacrifice unto you with the voice of thanksgiving'"—thanksgiving
- "'That which I have vowed I will pay'"—pay vows
- "'Salvation is of YHWH'"—salvation YHWH's
- "YHWH spoke unto the fish"—spoke to fish
- "It vomited out Jonah upon the dry land"—vomited out

**Modern Equivalent:** Jonah 2 is a thanksgiving psalm composed in the fish's belly—already thanking God for deliverance before it happens. The imagery draws on many psalms: waters, waves, Sheol, the pit. "Salvation is of YHWH" (2:9) is the theological climax. The fish obeying YHWH's command (2:10) shows God's sovereignty over creation.

# Jonah 4: Jonah's Anger and YHWH's Lesson

*From the Hebrew: וַיֵּרַע אֶל־יוֹנָה רָעָה גְדוֹלָה (Va-Yera El-Yonah Ra'ah Gedolah) — But It Displeased Jonah Exceedingly*

---

## Jonah's Anger (4:1-4)

**4:1** But it displeased Jonah exceedingly, and he was angry.

**4:2** And he prayed unto YHWH, and said: "I pray you, O YHWH, was not this my saying, when I was yet in my country? Therefore I fled beforehand unto Tarshish; for I knew that you are a gracious God, and compassionate, long-suffering, and abundant in mercy, and repent of the evil.

**4:3** "Therefore now, O YHWH, take, I beseech you, my life from me; for it is better for me to die than to live."

**4:4** And YHWH said: "Are you greatly angry?"

---

## The Plant and the Worm (4:5-8)

**4:5** Then Jonah went out of the city, and sat on the east side of the city, and there made him a booth, and sat under it in the shadow, till he might see what would become of the city.

**4:6** And YHWH God prepared a gourd, and made it to come up over Jonah, that it might be a shadow over his head, to deliver him from his evil. So Jonah was exceeding glad because of the gourd.

**4:7** But God prepared a worm when the morning rose the next day, and it smote the gourd, that it withered.

**4:8** And it came to pass, when the sun arose, that God prepared a vehement east wind; and the sun beat upon the head of Jonah, that he fainted, and requested for himself that he might die, and said: "It is better for me to die than to live."

---

## YHWH's Lesson (4:9-11)

**4:9** And God said to Jonah: "Are you greatly angry for the gourd?" And he said: "I am greatly angry, even unto death."

**4:10** And YHWH said: "You have had pity on the gourd, for which you have not laboured, neither did you make it grow, which came up in a night, and perished in a night;

**4:11** "And should not I have pity on Nineveh, that great city, wherein are more than sixscore thousand persons that cannot discern between their right hand and their left hand, and also much cattle?"

---

## Synthesis Notes

**Key Restorations:**

**Jonah's Anger (4:1-4):**
**The Key Verse (4:1):**
"It displeased Jonah exceedingly, and he was angry."

*Va-yera el-Yonah ra'ah gedolah va-yichar lo*—greatly displeased.

**The Key Verse (4:2):**
"He prayed unto YHWH."

*Va-yitpallel el-YHWH*—prayed.

"'I pray you, O YHWH, was not this my saying, when I was yet in my country?'"

*Annah YHWH ha-lo-zeh devari ad-heyoti al-admati*—I said this before.

"'Therefore I fled beforehand unto Tarshish.'"

*Al-ken qiddamti livroach Tarshيshah*—why I fled.

"'For I knew that you are a gracious God, and compassionate.'"

*Ki yada'ti ki attah El-channun ve-rachum*—gracious, compassionate.

"'Long-suffering, and abundant in mercy.'"

*Erekh appayim ve-rav-chesed*—slow to anger, abundant mercy.

"'And repent of the evil.'"

*Ve-nicham al-ha-ra'ah*—relent from evil.

**El-Channun Ve-Rachum:**
The classic confession from Exodus 34:6—Jonah knew God would forgive!

**The Key Verse (4:3):**
"'Take, I beseech you, my life from me.'"

*Ve-attah YHWH qach-na et-nafshi mimmennni*—take my life.

"'It is better for me to die than to live.'"

*Ki tov moti me-chayyai*—better dead.

**The Key Verse (4:4):**
"YHWH said: 'Are you greatly angry?'"

*Va-yomer YHWH ha-heitev charah lakh*—rightly angry?

**The Plant and the Worm (4:5-8):**
**The Key Verses (4:5-6):**
"Jonah went out of the city, and sat on the east side of the city."

*Va-yetze Yonah min-ha-ir va-yeshev mi-qedem la-ir*—sat outside.

"There made him a booth, and sat under it in the shadow."

*Va-ya'as lo sham sukkah va-yeshev tachteiha ba-tzel*—booth for shade.

"Till he might see what would become of the city."

*Ad asher yir'eh mah-yihyeh ba-ir*—waiting to see.

"YHWH God prepared a gourd."

*Va-yemen YHWH-Elohim qiqayon*—prepared gourd.

**Qiqayon:**
A fast-growing plant, possibly castor bean.

"Made it to come up over Jonah, that it might be a shadow over his head."

*Va-ya'al me-al le-Yonah lihyot tzel al-rosho*—shade over head.

"To deliver him from his evil."

*Le-hatzil lo me-ra'ato*—deliver from discomfort.

"Jonah was exceeding glad because of the gourd."

*Va-yismach Yonah al-ha-qiqayon simchah gedolah*—exceeding glad.

**The Key Verses (4:7-8):**
"God prepared a worm when the morning rose the next day."

*Va-yemen ha-Elohim tola'at ba-alot ha-shachar la-mocharat*—prepared worm.

"It smote the gourd, that it withered."

*Va-takh et-ha-qiqayon va-yivash*—gourd withered.

"When the sun arose, God prepared a vehement east wind."

*Va-yehi ki-zroach ha-shemesh va-yemen Elohim ruach qadim charishit*—east wind.

"The sun beat upon the head of Jonah, that he fainted."

*Va-takh ha-shemesh al-rosh Yonah va-yit'allaf*—fainted.

"Requested for himself that he might die."

*Va-yish'al et-nafsho lamut*—wanted death.

"'It is better for me to die than to live.'"

*Tov moti me-chayyai*—better dead.

**YHWH's Lesson (4:9-11):**
**The Key Verse (4:9):**
"God said to Jonah: 'Are you greatly angry for the gourd?'"

*Va-yomer Elohim el-Yonah ha-heitev charah-lekha al-ha-qiqayon*—angry for gourd?

"He said: 'I am greatly angry, even unto death.'"

*Va-yomer heitev charah-li ad-mavet*—angry unto death.

**The Key Verses (4:10-11):**
"'You have had pity on the gourd.'"

*Attah chasta al-ha-qiqayon*—you pitied.

"'For which you have not laboured.'"

*Asher lo-amalta vo*—didn't labor.

"'Neither did you make it grow.'"

*Ve-lo giddaltho*—didn't grow.

"'Which came up in a night, and perished in a night.'"

*She-bin-laylah hayah u-vin-laylah avad*—overnight plant.

"'And should not I have pity on Nineveh, that great city?'"

*Va-ani lo achus al-Nineveh ha-ir ha-gedolah*—shouldn't I pity?

"'Wherein are more than sixscore thousand persons.'"

*Asher-yesh-bah harbeh mi-shtem-esreh ribbו adam*—120,000 people.

"'That cannot discern between their right hand and their left hand.'"

*Asher lo-yada bein-yemino li-smolo*—can't tell right from left.

**Cannot Discern:**
Young children, or perhaps all Ninevites who don't know better.

"'And also much cattle?'"

*U-vehemah rabbah*—much cattle.

**The Book Ends with a Question:**
YHWH's question is left unanswered—the reader must respond.

**Archetypal Layer:** Jonah 4 contains **Jonah's anger at Nineveh's salvation (4:1)**, **his confession: "I knew that you are a gracious God, and compassionate, long-suffering, and abundant in mercy" (4:2)**—quoting Exodus 34:6, **"it is better for me to die than to live" (4:3)**, **Jonah waiting outside the city (4:5)**, **YHWH prepares a plant (4:6), a worm (4:7), and an east wind (4:8)**, **Jonah's joy over the plant (4:6) and despair when it dies (4:8)**, **YHWH's question: "Are you greatly angry for the gourd?" (4:9)**, **Jonah's response: "I am greatly angry, even unto death" (4:9)**, and **the book's climax: "Should not I have pity on Nineveh, that great city, wherein are more than sixscore thousand persons that cannot discern between their right hand and their left hand, and also much cattle?" (4:11)**.

**Ethical Inversion Applied:**
- "It displeased Jonah exceedingly, and he was angry"—displeased
- "He prayed unto YHWH"—angry prayer
- "'Was not this my saying, when I was yet in my country?'"—predicted this
- "'Therefore I fled beforehand unto Tarshish'"—why I fled
- "'I knew that you are a gracious God, and compassionate'"—gracious
- "'Long-suffering, and abundant in mercy'"—abundant mercy
- "'And repent of the evil'"—relent
- "'Take, I beseech you, my life from me'"—take my life
- "'It is better for me to die than to live'"—better dead
- "'Are you greatly angry?'"—question
- "Jonah went out of the city"—left city
- "Sat on the east side... made him a booth"—booth
- "Till he might see what would become of the city"—waiting
- "YHWH God prepared a gourd"—prepared plant
- "That it might be a shadow over his head"—shade
- "Jonah was exceeding glad because of the gourd"—glad
- "God prepared a worm"—prepared worm
- "It smote the gourd, that it withered"—withered
- "God prepared a vehement east wind"—east wind
- "The sun beat upon the head of Jonah, that he fainted"—fainted
- "'It is better for me to die than to live'"—better dead again
- "'Are you greatly angry for the gourd?'"—angry for plant?
- "'I am greatly angry, even unto death'"—angry unto death
- "'You have had pity on the gourd'"—pitied plant
- "'For which you have not laboured'"—didn't labor
- "'Which came up in a night, and perished in a night'"—overnight
- "'Should not I have pity on Nineveh?'"—shouldn't I pity?
- "'More than sixscore thousand persons'"—120,000
- "'That cannot discern between their right hand and their left hand'"—innocent
- "'And also much cattle?'"—cattle too

**Modern Equivalent:** Jonah 4 exposes Jonah's heart. He's angry that God forgave Nineveh—he quotes Exodus 34:6 (God's self-revelation as gracious and compassionate) as a complaint! The object lesson: Jonah cares more about a plant than 120,000 people. The book ends with God's question unanswered—forcing readers to examine their own hearts about mercy toward enemies.

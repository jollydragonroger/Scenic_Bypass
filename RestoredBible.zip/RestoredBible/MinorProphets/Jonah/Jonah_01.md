# Jonah 1: Flight from YHWH

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֶל־יוֹנָה (Va-Yehi Devar-YHWH El-Yonah) — And the Word of YHWH Came unto Jonah*

---

## Jonah's Commission and Flight (1:1-3)

**1:1** Now the word of YHWH came unto Jonah the son of Amittai, saying:

**1:2** "Arise, go to Nineveh, that great city, and proclaim against it; for their wickedness is come up before me."

**1:3** But Jonah rose up to flee unto Tarshish from the presence of YHWH; and he went down to Joppa, and found a ship going to Tarshish; so he paid the fare thereof, and went down into it, to go with them unto Tarshish, from the presence of YHWH.

---

## The Storm (1:4-10)

**1:4** But YHWH hurled a great wind into the sea, and there was a mighty tempest in the sea, so that the ship was like to be broken.

**1:5** And the mariners were afraid, and cried every man unto his god; and they cast forth the wares that were in the ship into the sea, to lighten it unto them. But Jonah was gone down into the innermost parts of the ship; and he lay, and was fast asleep.

**1:6** So the shipmaster came to him, and said unto him: "What do you mean, O sleeper? Arise, call upon your God, perhaps God will think upon us, that we perish not."

**1:7** And they said every one to his fellow: "Come, and let us cast lots, that we may know for whose cause this evil is upon us." So they cast lots, and the lot fell upon Jonah.

**1:8** Then said they unto him: "Tell us, we pray, for whose cause this evil is upon us: what is your occupation? And whence do you come? What is your country? And of what people are you?"

**1:9** And he said unto them: "I am a Hebrew; and I fear YHWH, the God of heaven, who has made the sea and the dry land."

**1:10** Then were the men exceedingly afraid, and said unto him: "What is this that you have done?" For the men knew that he fled from the presence of YHWH, because he had told them.

---

## Jonah Cast Overboard (1:11-16)

**1:11** Then said they unto him: "What shall we do unto you, that the sea may be calm unto us?" For the sea grew more and more tempestuous.

**1:12** And he said unto them: "Take me up, and cast me forth into the sea; so shall the sea be calm unto you; for I know that for my sake this great tempest is upon you."

**1:13** Nevertheless the men rowed hard to bring it to the land; but they could not; for the sea grew more and more tempestuous against them.

**1:14** Wherefore they cried unto YHWH, and said: "We beseech you, O YHWH, we beseech you, let us not perish for this man's life, and lay not upon us innocent blood; for you, O YHWH, have done as it pleased you."

**1:15** So they took up Jonah, and cast him forth into the sea; and the sea ceased from its raging.

**1:16** Then the men feared YHWH exceedingly; and they offered a sacrifice unto YHWH, and made vows.

---

## The Great Fish (1:17)

**1:17** And YHWH prepared a great fish to swallow up Jonah; and Jonah was in the belly of the fish three days and three nights.

---

## Synthesis Notes

**Key Restorations:**

**Jonah's Commission and Flight (1:1-3):**
**The Key Verses (1:1-2):**
"Now the word of YHWH came unto Jonah the son of Amittai."

*Va-yehi devar-YHWH el-Yonah ben-Amittai*—word to Jonah.

**Yonah:**
"Dove."

**Amittai:**
"My truth."

"'Arise, go to Nineveh, that great city.'"

*Qum lekh el-Nineveh ha-ir ha-gedolah*—great city.

"'Proclaim against it.'"

*U-qera aleha*—proclaim.

"'For their wickedness is come up before me.'"

*Ki-aletah ra'atam lefanai*—wickedness risen.

**The Key Verse (1:3):**
"Jonah rose up to flee unto Tarshish from the presence of YHWH."

*Va-yaqom Yonah livroach Tarshيshah mi-lifnei YHWH*—flee to Tarshish.

**Tarshish:**
Possibly Spain—the opposite direction from Nineveh.

"He went down to Joppa, and found a ship going to Tarshish."

*Va-yered Yafo va-yimtza oniyyah ba'ah Tarshيshah*—down to Joppa.

"So he paid the fare thereof, and went down into it."

*Va-yitten sekharah va-yered bah*—paid fare.

"To go with them unto Tarshish, from the presence of YHWH."

*Lavo immahem Tarshيshah mi-lifnei YHWH*—from YHWH's presence.

**The Storm (1:4-10):**
**The Key Verses (1:4-5):**
"YHWH hurled a great wind into the sea."

*Va-YHWH hetil ruach-gedolah el-ha-yam*—hurled wind.

**Hetil:**
"Hurled"—same verb used for Jonah being thrown.

"There was a mighty tempest in the sea."

*Va-yehi sa'ar-gadol ba-yam*—mighty tempest.

"The ship was like to be broken."

*Ve-ha-oniyyah chishshah le-hishaver*—ship breaking.

"The mariners were afraid, and cried every man unto his god."

*Va-yire'u ha-mallachim va-yiz'aqu ish el-elohav*—cried to gods.

"They cast forth the wares... into the sea, to lighten it."

*Va-yatilu et-ha-kelim... el-ha-yam le-haqel me-aleihem*—lighten ship.

"Jonah was gone down into the innermost parts of the ship."

*Ve-Yonah yarad el-yarketei ha-sefinah*—gone down.

"He lay, and was fast asleep."

*Va-yishkav va-yeradam*—fast asleep.

**The Key Verses (1:6-7):**
"'What do you mean, O sleeper?'"

*Mah-lekha nirdam*—what are you doing sleeping?

"'Arise, call upon your God.'"

*Qum qera el-Elohekha*—call your God.

"'Perhaps God will think upon us, that we perish not.'"

*Ulai yitashshet ha-Elohim lanu ve-lo novad*—perhaps we won't perish.

"'Come, and let us cast lots.'"

*Lekhu ve-nappilah goralot*—cast lots.

"That we may know for whose cause this evil is upon us."

*Ve-nede'ah be-shellemi ha-ra'ah ha-zot lanu*—whose cause.

"The lot fell upon Jonah."

*Va-yippol ha-goral al-Yonah*—lot on Jonah.

**The Key Verses (1:8-10):**
"'Tell us... what is your occupation?'"

*Haggidah-na lanu... mah-melakhtekha*—occupation.

"'Whence do you come? What is your country?'"

*U-me'ayin tavo mah artzekha*—origin.

"'Of what people are you?'"

*Ve-ei-mi-zeh am attah*—people.

"'I am a Hebrew; and I fear YHWH, the God of heaven.'"

*Ivri anokhi ve-et-YHWH Elohei ha-shamayim ani yare*—Hebrew.

"'Who has made the sea and the dry land.'"

*Asher-asah et-ha-yam ve-et-ha-yabashah*—made sea and land.

"Then were the men exceedingly afraid."

*Va-yire'u ha-anashim yir'ah gedolah*—exceedingly afraid.

"'What is this that you have done?'"

*Mah-zot asita*—what have you done?

"The men knew that he fled from the presence of YHWH."

*Ki-yade'u ha-anashim ki-mi-lifnei YHWH hu vore'ach*—knew he fled.

"Because he had told them."

*Ki higgid lahem*—he told them.

**Jonah Cast Overboard (1:11-16):**
**The Key Verses (1:11-13):**
"'What shall we do unto you, that the sea may be calm unto us?'"

*Mah-na'aseh lakh ve-yishtoq ha-yam me-aleinu*—what do we do?

"For the sea grew more and more tempestuous."

*Ki ha-yam holekh ve-so'er*—sea raging more.

"'Take me up, and cast me forth into the sea.'"

*Sa'uni va-hatiluni el-ha-yam*—throw me in.

"'So shall the sea be calm unto you.'"

*Ve-yishtoq ha-yam me-aleikhem*—sea calm.

"'For I know that for my sake this great tempest is upon you.'"

*Ki yode'a ani ki ve-shelli ha-sa'ar ha-gadol ha-zeh aleikhem*—my fault.

"The men rowed hard to bring it to the land."

*Va-yachteru ha-anashim le-hashiv el-ha-yabashah*—rowed hard.

"But they could not."

*Ve-lo yakholu*—couldn't.

"For the sea grew more and more tempestuous against them."

*Ki ha-yam holekh ve-so'er aleihem*—sea raging.

**The Key Verses (1:14-16):**
"They cried unto YHWH."

*Va-yiqre'u el-YHWH*—cried to YHWH.

"'We beseech you, O YHWH, we beseech you, let us not perish for this man's life.'"

*Annah YHWH al-na novdah be-nefesh ha-ish ha-zeh*—don't let us perish.

"'Lay not upon us innocent blood.'"

*Ve-al-titten aleinu dam naqi*—innocent blood.

"'For you, O YHWH, have done as it pleased you.'"

*Ki-attah YHWH ka-asher chafatzta asita*—you did as you pleased.

"They took up Jonah, and cast him forth into the sea."

*Va-yis'u et-Yonah va-yetיluhu el-ha-yam*—threw Jonah.

"The sea ceased from its raging."

*Va-ya'amod ha-yam mi-za'po*—sea ceased.

"The men feared YHWH exceedingly."

*Va-yire'u ha-anashim yir'ah gedolah et-YHWH*—feared YHWH.

"They offered a sacrifice unto YHWH, and made vows."

*Va-yizbechu-zevach la-YHWH va-yidderu nedarim*—sacrifice, vows.

**The Great Fish (1:17):**
**The Key Verse (1:17):**
"YHWH prepared a great fish to swallow up Jonah."

*Va-yemen YHWH dag gadol livlo'a et-Yonah*—great fish.

**Dag Gadol:**
"Great fish"—not specifically a whale.

"Jonah was in the belly of the fish three days and three nights."

*Va-yehi Yonah bi-me'ei ha-dag sheloshah yamim u-shloshah leilot*—three days, nights.

**Three Days and Three Nights:**
Jesus refers to this in Matthew 12:40.

**Archetypal Layer:** Jonah 1 contains **the commission to Nineveh (1:2)**, **Jonah's flight to Tarshish—the opposite direction (1:3)**, **YHWH hurls a great wind (1:4)**, **Jonah asleep in the ship (1:5)**, **the captain: "What do you mean, O sleeper?" (1:6)**, **lots fall on Jonah (1:7)**, **Jonah's confession: "I am a Hebrew; and I fear YHWH, the God of heaven, who has made the sea and the dry land" (1:9)**, **"Take me up, and cast me forth into the sea" (1:12)**, **the sailors try to row to land but can't (1:13)**, **they pray to YHWH and throw Jonah overboard (1:14-15)**, **the sea calms, the sailors fear YHWH and sacrifice (1:16)**, and **"YHWH prepared a great fish to swallow up Jonah... three days and three nights" (1:17)**.

**Ethical Inversion Applied:**
- "The word of YHWH came unto Jonah"—commission
- "'Arise, go to Nineveh'"—go to Nineveh
- "'Proclaim against it'"—proclaim
- "'Their wickedness is come up before me'"—wickedness
- "Jonah rose up to flee unto Tarshish"—flee
- "From the presence of YHWH"—flee YHWH
- "He went down to Joppa"—went down
- "Paid the fare thereof"—paid fare
- "YHWH hurled a great wind into the sea"—hurled wind
- "A mighty tempest"—tempest
- "The ship was like to be broken"—breaking
- "The mariners were afraid, and cried every man unto his god"—cried to gods
- "They cast forth the wares"—lighten ship
- "Jonah was gone down... and was fast asleep"—asleep
- "'What do you mean, O sleeper?'"—sleeper
- "'Arise, call upon your God'"—call God
- "'Come, and let us cast lots'"—cast lots
- "The lot fell upon Jonah"—lot on Jonah
- "'I am a Hebrew; and I fear YHWH'"—confession
- "'Who has made the sea and the dry land'"—Creator
- "The men exceedingly afraid"—afraid
- "'What is this that you have done?'"—accusation
- "'What shall we do unto you?'"—what to do
- "'Take me up, and cast me forth into the sea'"—throw me
- "'For I know that for my sake this great tempest is upon you'"—my fault
- "The men rowed hard to bring it to the land"—tried to row
- "But they could not"—couldn't
- "They cried unto YHWH"—cried to YHWH
- "'Let us not perish for this man's life'"—don't perish
- "'Lay not upon us innocent blood'"—innocent blood
- "They took up Jonah, and cast him forth"—threw Jonah
- "The sea ceased from its raging"—sea calmed
- "The men feared YHWH exceedingly"—feared YHWH
- "They offered a sacrifice unto YHWH, and made vows"—sacrifice, vows
- "YHWH prepared a great fish to swallow up Jonah"—great fish
- "Three days and three nights"—three days

**Modern Equivalent:** Jonah 1 introduces the reluctant prophet. Commanded to go east to Nineveh (Assyria's capital), Jonah flees west to Tarshish (probably Spain). The pagan sailors are more pious than the prophet—they pray to YHWH, try to save Jonah, and worship when delivered. The "great fish" becomes Jonah's unlikely salvation. "Three days and three nights" (1:17) prefigures Christ's burial.

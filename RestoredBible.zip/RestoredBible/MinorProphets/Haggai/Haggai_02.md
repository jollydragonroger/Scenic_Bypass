# Haggai 2: The Glory of the New Temple

*From the Hebrew: בַּשְּׁבִיעִי בְּעֶשְׂרִים וְאֶחָד לַחֹדֶשׁ (Ba-Shevi'i Be-Esrim Ve-Echad La-Chodesh) — In the Seventh Month, on the Twenty-First Day*

---

## Second Oracle: The Greater Glory (2:1-9)

**2:1** In the seventh month, in the one and twentieth day of the month, came the word of YHWH by Haggai the prophet, saying:

**2:2** "Speak now to Zerubbabel the son of Shealtiel, governor of Judah, and to Joshua the son of Jehozadak, the high priest, and to the remnant of the people, saying:

**2:3** "'Who is left among you that saw this house in its former glory? And how do you see it now? Is it not in your eyes as nothing?

**2:4** "'Yet now be strong, O Zerubbabel,' says YHWH; 'and be strong, O Joshua, son of Jehozadak, the high priest; and be strong, all you people of the land,' says YHWH, 'and work; for I am with you,' says YHWH of hosts.

**2:5** "'The word that I covenanted with you when you came out of Egypt, and my spirit, abides among you; fear not.'

**2:6** "For thus says YHWH of hosts: 'Yet once, it is a little while, and I will shake the heavens, and the earth, and the sea, and the dry land;

**2:7** "'And I will shake all nations, and the choicest things of all nations shall come, and I will fill this house with glory,' says YHWH of hosts.

**2:8** "'The silver is mine, and the gold is mine,' says YHWH of hosts.

**2:9** "'The glory of this latter house shall be greater than that of the former,' says YHWH of hosts; 'and in this place will I give peace,' says YHWH of hosts."

---

## Third Oracle: Holiness and Uncleanness (2:10-19)

**2:10** In the four and twentieth day of the ninth month, in the second year of Darius, came the word of YHWH by Haggai the prophet, saying:

**2:11** "Thus says YHWH of hosts: Ask now the priests concerning the law, saying:

**2:12** "'If one bear hallowed flesh in the skirt of his garment, and with his skirt do touch bread, or pottage, or wine, or oil, or any food, shall it become holy?'" And the priests answered and said: "No."

**2:13** Then said Haggai: "If one that is unclean by a dead body touch any of these, shall it be unclean?" And the priests answered and said: "It shall be unclean."

**2:14** Then answered Haggai, and said: "So is this people, and so is this nation before me, says YHWH; and so is every work of their hands; and that which they offer there is unclean.

**2:15** "And now, I pray you, consider from this day and backward, before a stone was laid upon a stone in the temple of YHWH;

**2:16** "Through all that time, when one came to a heap of twenty measures, there were but ten; when one came to the wine-vat to draw out fifty press-measures, there were but twenty.

**2:17** "I smote you with blasting and with mildew and with hail in all the work of your hands; yet you turned not to me," says YHWH.

**2:18** "'Consider from this day and backward, from the four and twentieth day of the ninth month, even from the day that the foundation of YHWH's temple was laid, consider:

**2:19** "'Is the seed yet in the barn? Yea, the vine, and the fig-tree, and the pomegranate, and the olive-tree has not brought forth—from this day will I bless you.'"

---

## Fourth Oracle: Zerubbabel the Signet (2:20-23)

**2:20** And the word of YHWH came the second time unto Haggai in the four and twentieth day of the month, saying:

**2:21** "Speak to Zerubbabel, governor of Judah, saying: 'I will shake the heavens and the earth;

**2:22** "'And I will overthrow the throne of kingdoms, and I will destroy the strength of the kingdoms of the nations; and I will overthrow the chariots, and those that ride in them; and the horses and their riders shall come down, every one by the sword of his brother.

**2:23** "'In that day,' says YHWH of hosts, 'will I take you, O Zerubbabel, my servant, the son of Shealtiel,' says YHWH, 'and will make you as a signet; for I have chosen you,' says YHWH of hosts."

---

## Synthesis Notes

**Key Restorations:**

**Second Oracle (2:1-9):**
**The Key Verses (2:1-3):**
"In the seventh month, in the one and twentieth day of the month."

*Ba-shevi'i be-esrim ve-echad la-chodesh*—21st of 7th month.

"'Speak now to Zerubbabel... and to Joshua... and to the remnant of the people.'"

*Emor-na el-Zerubbavel... ve-el-Yehoshua... ve-el-she'erit ha-am*—speak.

"''Who is left among you that saw this house in its former glory?''"

*Mi vakhem ha-nish'ar asher ra'ah et-ha-bayit ha-zeh bi-khvodo ha-rishon*—who saw?

"''How do you see it now?''"

*U-mah attem ro'im oto attah*—how now?

"''Is it not in your eyes as nothing?''"

*Ha-lo khamohu ke-ayin be-eineikhem*—as nothing.

**The Key Verses (2:4-5):**
"''Be strong, O Zerubbabel... be strong, O Joshua... be strong, all you people of the land.''"

*Chazaq Zerubbavel... va-chazaq Yehoshua... va-chazqu kol-am ha-aretz*—be strong.

"''Work; for I am with you.''"

*Va-asu ki-ani ittkhem*—work, I'm with you.

"''The word that I covenanted with you when you came out of Egypt.''"

*Et-ha-davar asher-karatתi ittkhem be-tzetekhem mi-Mitzrayim*—Exodus covenant.

"''My spirit, abides among you; fear not.''"

*Ve-ruchi omedet be-tokhekhem al-tira'u*—spirit among you.

**The Key Verses (2:6-9):**
"''Yet once, it is a little while.''"

*Od achat me'at hi*—little while.

"''I will shake the heavens, and the earth, and the sea, and the dry land.''"

*Va-ani mar'ish et-ha-shamayim ve-et-ha-aretz ve-et-ha-yam ve-et-he-charavah*—shake all.

"''I will shake all nations.''"

*Ve-hir'ashti et-kol-ha-goyim*—shake nations.

"''The choicest things of all nations shall come.''"

*U-va'u chemdat kol-ha-goyim*—choicest things.

**Chemdat Kol-Ha-Goyim:**
"Desire/choicest of all nations"—traditionally messianic.

"''I will fill this house with glory.''"

*U-milleiti et-ha-bayit ha-zeh kavod*—fill with glory.

"''The silver is mine, and the gold is mine.''"

*Li ha-kesef ve-li ha-zahav*—silver, gold mine.

"''The glory of this latter house shall be greater than that of the former.''"

*Gadol yihyeh kevod ha-bayit ha-zeh ha-acharon min-ha-rishon*—greater glory.

"''In this place will I give peace.''"

*U-va-maqom ha-zeh etten shalom*—give peace.

**Third Oracle (2:10-19):**
**The Key Verses (2:10-14):**
"In the four and twentieth day of the ninth month."

*Be-esrim ve-arba'ah la-teshi'i*—24th of 9th month.

"''Ask now the priests concerning the law.''"

*She'al-na et-ha-kohanim torah*—ask priests.

"''If one bear hallowed flesh in the skirt of his garment, and with his skirt do touch bread... shall it become holy?''"

*Hen yissa-ish basar-qodesh bi-khenaf bigdo ve-naga vi-knafo el-ha-lechem... ha-yiqdash*—holy?

"The priests answered: 'No.'"

*Va-ya'anu ha-kohanim va-yomeru lo*—no.

"''If one that is unclean by a dead body touch any of these, shall it be unclean?''"

*Im-yigga teme-nefesh be-khol-elleh ha-yitma*—unclean?

"The priests answered: 'It shall be unclean.'"

*Va-ya'anu ha-kohanim va-yomeru yitma*—unclean.

**Principle:**
Uncleanness transfers more readily than holiness.

"''So is this people, and so is this nation before me.''"

*Ken ha-am-ha-zeh ve-khen ha-goy-ha-zeh lefanai*—so are you.

"''Every work of their hands; and that which they offer there is unclean.''"

*Ve-khen kol-ma'aseh yedeihem va-asher yaqrivu sham tame hu*—unclean.

**The Key Verses (2:15-19):**
"''Consider from this day and backward.''"

*Ve-attah simu-na levavekhem min-ha-yom ha-zeh va-ma'lah*—consider backward.

"''Before a stone was laid upon a stone in the temple.''"

*Mi-terem sum-even el-even be-heikhal YHWH*—before building.

"''When one came to a heap of twenty measures, there were but ten.''"

*Ba el-aremah esrim ve-hayetah asarah*—half expected.

"''When one came to the wine-vat to draw out fifty, there were but twenty.''"

*Ba el-ha-yeqev lachsof chamishim purah ve-hayetah esrim*—40% of expected.

"''I smote you with blasting and with mildew and with hail.''"

*Hikkeiti etkhem ba-shiddafon u-va-yerakon u-va-barad*—blasting, mildew, hail.

"''Yet you turned not to me.''"

*Ve-ein-etkhem elai*—didn't turn.

"''Is the seed yet in the barn?''"

*Ha-od ha-zera ba-megurah*—seed in barn?

"''The vine, and the fig-tree, and the pomegranate, and the olive-tree has not brought forth.''"

*Ve-ad-ha-gefen ve-ha-te'enah ve-ha-rimmon ve-etz ha-zayit lo nasa*—not brought forth.

"''From this day will I bless you.''"

*Min-ha-yom ha-zeh avarekh*—from today, blessing.

**Fourth Oracle (2:20-23):**
**The Key Verses (2:20-23):**
"The word of YHWH came the second time unto Haggai in the four and twentieth day."

*Va-yehi devar-YHWH shenit el-Chaggai be-esrim ve-arba'ah la-chodesh*—same day.

"''I will shake the heavens and the earth.''"

*Ani mar'ish et-ha-shamayim ve-et-ha-aretz*—shake.

"''I will overthrow the throne of kingdoms.''"

*Ve-hafakhti kisse mamlakhot*—overthrow.

"''I will destroy the strength of the kingdoms of the nations.''"

*Ve-hishmadti chozeq mamlakhot ha-goyim*—destroy strength.

"''I will overthrow the chariots, and those that ride in them.''"

*Ve-hafakhti merkavah ve-rokheveiha*—overthrow chariots.

"''The horses and their riders shall come down, every one by the sword of his brother.''"

*Ve-yaredu susim ve-rokheveihem ish be-cherev achiv*—by brother's sword.

"''In that day... will I take you, O Zerubbabel, my servant.''"

*Ba-yom ha-hu... eqqachakha Zerubbavel avdi*—take Zerubbabel.

"''Will make you as a signet.''"

*Ve-samתיkha ka-chotam*—signet.

**Chotam:**
"Signet ring"—symbol of authority, reversing Jeremiah 22:24 where Jehoiachin was removed as signet.

"''For I have chosen you.''"

*Ki-bekha bacharti*—chosen.

**Archetypal Layer:** Haggai 2 contains **"Who is left among you that saw this house in its former glory? Is it not in your eyes as nothing?" (2:3)**, **"Be strong... and work; for I am with you... my spirit, abides among you; fear not" (2:4-5)**, **"Yet once, it is a little while, and I will shake the heavens, and the earth" (2:6)**, **"the choicest things of all nations shall come" (2:7)**, **"The silver is mine, and the gold is mine" (2:8)**, **"The glory of this latter house shall be greater than that of the former... in this place will I give peace" (2:9)**, **the teaching on holiness vs. uncleanness (2:12-14)**, **"from this day will I bless you" (2:19)**, and **"I will take you, O Zerubbabel, my servant... and will make you as a signet; for I have chosen you" (2:23)**.

**Ethical Inversion Applied:**
- "In the seventh month, in the one and twentieth day"—dated
- "''Who is left among you that saw this house in its former glory?''"—who saw
- "''Is it not in your eyes as nothing?''"—as nothing
- "''Be strong, O Zerubbabel''"—be strong
- "''Be strong, O Joshua''"—be strong
- "''Be strong, all you people of the land''"—be strong
- "''Work; for I am with you''"—work, with you
- "''The word that I covenanted with you when you came out of Egypt''"—Exodus
- "''My spirit, abides among you; fear not''"—spirit, fear not
- "''Yet once, it is a little while''"—little while
- "''I will shake the heavens, and the earth''"—shake
- "''I will shake all nations''"—shake nations
- "''The choicest things of all nations shall come''"—choicest
- "''I will fill this house with glory''"—fill with glory
- "''The silver is mine, and the gold is mine''"—silver, gold
- "''The glory of this latter house shall be greater''"—greater glory
- "''In this place will I give peace''"—peace
- "''Ask now the priests concerning the law''"—ask priests
- "''If one bear hallowed flesh... shall it become holy?''"—holiness
- "''If one that is unclean by a dead body touch any of these, shall it be unclean?''"—uncleanness
- "''So is this people... every work of their hands... is unclean''"—unclean
- "''Consider from this day and backward''"—consider
- "''When one came to a heap of twenty measures, there were but ten''"—half
- "''I smote you with blasting and with mildew''"—blasting
- "''Yet you turned not to me''"—didn't turn
- "''From this day will I bless you''"—blessing
- "''I will shake the heavens and the earth''"—shake
- "''I will overthrow the throne of kingdoms''"—overthrow
- "''I will destroy the strength of the kingdoms''"—destroy
- "''I will take you, O Zerubbabel, my servant''"—take
- "''Will make you as a signet''"—signet
- "''For I have chosen you''"—chosen

**Modern Equivalent:** Haggai 2 addresses discouragement—the new temple looks pathetic compared to Solomon's. But "the glory of this latter house shall be greater" (2:9). The teaching on holiness (2:12-14) shows that uncleanness spreads more easily than holiness—they've been contaminated by neglect. "From this day will I bless you" (2:19) marks the turning point. The book ends with Zerubbabel as "signet" (2:23)—reversing Jeremiah 22:24 where the signet was removed. Davidic hope is restored.

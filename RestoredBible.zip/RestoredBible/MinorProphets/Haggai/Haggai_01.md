# Haggai 1: Call to Rebuild the Temple

*From the Hebrew: בִּשְׁנַת שְׁתַּיִם לְדָרְיָוֶשׁ הַמֶּלֶךְ (Bi-Shenat Shetayim Le-Daryavesh Ha-Melekh) — In the Second Year of Darius the King*

---

## First Oracle: Priorities (1:1-11)

**1:1** In the second year of Darius the king, in the sixth month, in the first day of the month, came the word of YHWH by Haggai the prophet unto Zerubbabel the son of Shealtiel, governor of Judah, and to Joshua the son of Jehozadak, the high priest, saying:

**1:2** Thus speaks YHWH of hosts, saying: This people says: "The time is not come, the time that YHWH's house should be built."

**1:3** Then came the word of YHWH by Haggai the prophet, saying:

**1:4** "Is it a time for you yourselves to dwell in your ceiled houses, while this house lies waste?

**1:5** "Now therefore thus says YHWH of hosts: Consider your ways.

**1:6** "You have sown much, and bring in little; you eat, but you have not enough; you drink, but you are not filled with drink; you clothe yourselves, but there is none warm; and he that earns wages earns wages for a bag with holes."

**1:7** Thus says YHWH of hosts: Consider your ways.

**1:8** "Go up to the mountain, and bring wood, and build the house; and I will take pleasure in it, and I will be glorified," says YHWH.

**1:9** "You looked for much, and, lo, it came to little; and when you brought it home, I did blow upon it. Why? says YHWH of hosts. Because of my house that lies waste, while you run every man for his own house.

**1:10** "Therefore over you the heaven has withheld its dew, and the earth has withheld its produce.

**1:11** "And I called for a drought upon the land, and upon the mountains, and upon the grain, and upon the wine, and upon the oil, and upon that which the ground brings forth, and upon men, and upon cattle, and upon all the labour of the hands."

---

## The People's Response (1:12-15)

**1:12** Then Zerubbabel the son of Shealtiel, and Joshua the son of Jehozadak, the high priest, with all the remnant of the people, hearkened unto the voice of YHWH their God, and to the words of Haggai the prophet, as YHWH their God had sent him; and the people feared before YHWH.

**1:13** Then spoke Haggai YHWH's messenger in YHWH's message unto the people, saying: "I am with you," says YHWH.

**1:14** And YHWH stirred up the spirit of Zerubbabel the son of Shealtiel, governor of Judah, and the spirit of Joshua the son of Jehozadak, the high priest, and the spirit of all the remnant of the people; and they came and did work in the house of YHWH of hosts, their God,

**1:15** In the four and twentieth day of the sixth month, in the second year of Darius the king.

---

## Synthesis Notes

**Key Restorations:**

**First Oracle (1:1-11):**
**The Key Verse (1:1):**
"In the second year of Darius the king, in the sixth month, in the first day of the month."

*Bi-shenat shetayim le-Daryavesh ha-melekh ba-chodesh ha-shishi be-yom echad la-chodesh*—dated.

**520 BCE:**
Darius I of Persia; precisely dated prophecy.

"Came the word of YHWH by Haggai the prophet."

*Hayah devar-YHWH be-yad-Chaggai ha-navi*—through Haggai.

**Chaggai:**
"Festive" or "my feast."

"Unto Zerubbabel the son of Shealtiel, governor of Judah."

*El-Zerubbavel ben-She'altiel pachat Yehudah*—Zerubbabel.

**Zerubbavel:**
"Seed of Babylon"—Davidic descendant, governor.

"To Joshua the son of Jehozadak, the high priest."

*Ve-el-Yehoshua ben-Yehotzadaq ha-kohen ha-gadol*—Joshua high priest.

**The Key Verses (1:2-4):**
"''This people says: The time is not come, the time that YHWH's house should be built.''"

*Ha-am ha-zeh ameru lo-et-bo et-beit-YHWH le-hibbanot*—not time.

"''Is it a time for you yourselves to dwell in your ceiled houses?''"

*Ha-et lakhem attem lashevet be-vatteikhem sefunim*—ceiled houses.

"''While this house lies waste?''"

*Ve-ha-bayit ha-zeh charev*—temple waste.

**The Key Verses (1:5-6):**
"''Consider your ways.''"

*Simu levavekhem al-darkheikhem*—consider ways.

"''You have sown much, and bring in little.''"

*Zera'tem harbeh ve-have me'at*—sown much, little.

"''You eat, but you have not enough.''"

*Akhol ve-ein le-sovah*—eat, not enough.

"''You drink, but you are not filled with drink.''"

*Shato ve-ein le-shokhrah*—drink, not filled.

"''You clothe yourselves, but there is none warm.''"

*Lavosh ve-ein le-chom lo*—clothe, not warm.

"''He that earns wages earns wages for a bag with holes.''"

*Ve-ha-mistaკker mistaკker el-tzeror naquv*—bag with holes.

**Bag with Holes:**
Economic frustration—nothing they earn satisfies.

**The Key Verses (1:7-9):**
"''Consider your ways.''"

*Simu levavekhem al-darkheikhem*—consider again.

"''Go up to the mountain, and bring wood, and build the house.''"

*Alu ha-har va-havetem etz u-venu ha-bayit*—build.

"''I will take pleasure in it, and I will be glorified.''"

*Ve-ertzeh-vo ve-ikkaved*—pleasure, glory.

"''You looked for much, and, lo, it came to little.''"

*Panoh el-harbeh ve-hinneh li-me'at*—expected much.

"''When you brought it home, I did blow upon it.''"

*Va-havetem ha-bayit ve-nafachti vo*—blew upon it.

"''Because of my house that lies waste.''"

*Ya'an beiti asher-hu charev*—my house waste.

"''While you run every man for his own house.''"

*Ve-attem ratzim ish le-veito*—run to own houses.

**The Key Verses (1:10-11):**
"''Over you the heaven has withheld its dew.''"

*Al-ken aleikhem kale'u shamayim mi-tal*—no dew.

"''The earth has withheld its produce.''"

*Ve-ha-aretz kale'ah yevulah*—no produce.

"''I called for a drought upon the land.''"

*Va-eqra chorev al-ha-aretz*—drought.

"''Upon the mountains... the grain... the wine... the oil.''"

*Ve-al-he-harim ve-al-ha-dagan ve-al-ha-tirosh ve-al-ha-yitzhar*—everything.

**People's Response (1:12-15):**
**The Key Verses (1:12-15):**
"Zerubbabel... and Joshua... with all the remnant of the people, hearkened."

*Va-yishma Zerubbavel... vi-Yהoshua... ve-khol she'erit ha-am be-qol YHWH*—hearkened.

"The people feared before YHWH."

*Va-yire'u ha-am mi-penei YHWH*—feared.

"''I am with you,' says YHWH."

*Ani ittkhem ne'um-YHWH*—I am with you.

"YHWH stirred up the spirit of Zerubbabel... and... Joshua... and... all the remnant."

*Va-ya'ar YHWH et-ruach Zerubbavel... ve-et-ruach Yehoshua... ve-et-ruach kol she'erit ha-am*—stirred spirits.

"They came and did work in the house of YHWH of hosts."

*Va-yavo'u va-ya'asu melakhah be-veit YHWH tzeva'ot Eloheihem*—worked.

"In the four and twentieth day of the sixth month."

*Be-yom esrim ve-arba'ah la-chodesh ba-shishi*—24th day.

**23 Days Later:**
From first oracle (1st day) to work beginning (24th day).

**Archetypal Layer:** Haggai 1 is **precisely dated (520 BCE)**, containing **"This people says: The time is not come" (1:2)**, **"Is it a time for you yourselves to dwell in your ceiled houses, while this house lies waste?" (1:4)**, **"Consider your ways" (1:5, 7)**, **economic frustration: "he that earns wages earns wages for a bag with holes" (1:6)**, **"Go up to the mountain, and bring wood, and build the house; and I will take pleasure in it, and I will be glorified" (1:8)**, **"Because of my house that lies waste, while you run every man for his own house" (1:9)**, **"I am with you" (1:13)**, and **YHWH stirring up the spirits of leaders and people (1:14)**.

**Ethical Inversion Applied:**
- "In the second year of Darius the king"—dated
- "Came the word of YHWH by Haggai the prophet"—through Haggai
- "Unto Zerubbabel... governor of Judah"—Zerubbabel
- "To Joshua... the high priest"—Joshua
- "''This people says: The time is not come''"—not time
- "''Is it a time for you yourselves to dwell in your ceiled houses?''"—ceiled houses
- "''While this house lies waste?''"—waste
- "''Consider your ways''"—consider
- "''You have sown much, and bring in little''"—sown, little
- "''You eat, but you have not enough''"—not enough
- "''You drink, but you are not filled''"—not filled
- "''You clothe yourselves, but there is none warm''"—not warm
- "''He that earns wages earns wages for a bag with holes''"—bag with holes
- "''Go up to the mountain, and bring wood, and build the house''"—build
- "''I will take pleasure in it, and I will be glorified''"—pleasure, glory
- "''You looked for much, and, lo, it came to little''"—little
- "''When you brought it home, I did blow upon it''"—blew
- "''Because of my house that lies waste''"—my house waste
- "''While you run every man for his own house''"—own houses
- "''Over you the heaven has withheld its dew''"—no dew
- "''The earth has withheld its produce''"—no produce
- "''I called for a drought upon the land''"—drought
- "Zerubbabel... and Joshua... hearkened"—hearkened
- "The people feared before YHWH"—feared
- "''I am with you''"—with you
- "YHWH stirred up the spirit"—stirred
- "They came and did work in the house of YHWH"—worked
- "In the four and twentieth day"—23 days later

**Modern Equivalent:** Haggai 1 addresses returned exiles who've rebuilt their own houses but neglected YHWH's temple. "Consider your ways" (1:5, 7) is the refrain. Economic frustration (1:6) results from misplaced priorities. The image of "a bag with holes" perfectly captures futile labor. The people respond positively—23 days later work begins. "I am with you" (1:13) is YHWH's simple, powerful assurance.

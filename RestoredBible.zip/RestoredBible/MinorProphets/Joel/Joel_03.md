# Joel 3: The Valley of Decision

*From the Hebrew: כִּי הִנֵּה בַּיָּמִים הָהֵמָּה (Ki Hinneh Ba-Yamim Ha-Hemmah) — For Behold, in Those Days*

---

## Judgment on the Nations (3:1-8)

**3:1** For behold, in those days, and in that time, when I shall bring back the captivity of Judah and Jerusalem,

**3:2** I will gather all nations, and will bring them down into the valley of Jehoshaphat; and I will enter into judgment with them there for my people and for my heritage Israel, whom they have scattered among the nations, and divided my land;

**3:3** And they have cast lots for my people; and have given a boy for a harlot, and sold a girl for wine, and have drunk it.

**3:4** And also what are you to me, O Tyre, and Zidon, and all the regions of Philistia? Will you render me a recompense? And if you recompense me, swiftly, speedily will I return your recompense upon your own head.

**3:5** Forasmuch as you have taken my silver and my gold, and have carried into your temples my goodly treasures;

**3:6** The children also of Judah and the children of Jerusalem have you sold unto the sons of the Grecians, that you might remove them far from their border;

**3:7** Behold, I will stir them up out of the place whither you have sold them, and will return your recompense upon your own head;

**3:8** And I will sell your sons and your daughters into the hand of the children of Judah, and they shall sell them to the men of Sheba, to a nation far off; for YHWH has spoken.

---

## Call to Battle (3:9-17)

**3:9** Proclaim this among the nations, prepare war; stir up the mighty men; let all the men of war draw near, let them come up.

**3:10** Beat your plowshares into swords, and your pruning-hooks into spears; let the weak say: "I am strong."

**3:11** Haste and come, all you nations round about, and gather yourselves together; thither cause your mighty ones to come down, O YHWH.

**3:12** Let the nations be stirred up, and come up to the valley of Jehoshaphat; for there will I sit to judge all the nations round about.

**3:13** Put in the sickle, for the harvest is ripe; come, tread, for the winepress is full, the vats overflow; for their wickedness is great.

**3:14** Multitudes, multitudes in the valley of decision! For the day of YHWH is near in the valley of decision.

**3:15** The sun and the moon are darkened, and the stars withdraw their shining.

**3:16** And YHWH shall roar from Zion, and utter his voice from Jerusalem, and the heavens and the earth shall shake; but YHWH will be a refuge unto his people, and a stronghold to the children of Israel.

**3:17** So shall you know that I am YHWH your God, dwelling in Zion my holy mountain; then shall Jerusalem be holy, and there shall no strangers pass through her any more.

---

## Blessing for Judah (3:18-21)

**3:18** And it shall come to pass in that day, that the mountains shall drop down sweet wine, and the hills shall flow with milk, and all the brooks of Judah shall flow with waters; and a fountain shall come forth from the house of YHWH, and shall water the valley of Shittim.

**3:19** Egypt shall be a desolation, and Edom shall be a desolate wilderness, for the violence done to the children of Judah, because they have shed innocent blood in their land.

**3:20** But Judah shall be inhabited for ever, and Jerusalem from generation to generation.

**3:21** And I will hold as innocent their blood which I have not held as innocent; and YHWH dwells in Zion.

---

## Synthesis Notes

**Key Restorations:**

**Judgment on the Nations (3:1-8):**
**The Key Verses (3:1-2):**
"'In those days, and in that time, when I shall bring back the captivity of Judah and Jerusalem.'"

*Ki hinneh ba-yamim ha-hemmah u-va-et ha-hi asher ashiv et-shevut Yehudah vi-Yrushalayim*—restore captivity.

"'I will gather all nations.'"

*Ve-qibbatzti et-kol-ha-goyim*—gather nations.

"'Will bring them down into the valley of Jehoshaphat.'"

*Ve-horadtim el-emeq Yehoshafat*—valley of Jehoshaphat.

**Emeq Yehoshafat:**
"Valley of YHWH Judges"—symbolic name for judgment.

"'I will enter into judgment with them there for my people.'"

*Ve-nishpatti immam sham al ammi*—judgment for Israel.

"'For my heritage Israel, whom they have scattered among the nations.'"

*Ve-nachalati Yisra'el asher pizzeru va-goyim*—scattered.

"'And divided my land.'"

*Ve-et-artzi chillequ*—divided land.

**The Key Verse (3:3):**
"'They have cast lots for my people.'"

*Ve-el-ammi yaddו goral*—cast lots.

"'Given a boy for a harlot.'"

*Va-yittenu ha-yeled ba-zonah*—boy for harlot.

"'Sold a girl for wine, and have drunk it.'"

*Ve-ha-yaldah makheru ve-yayin va-yishtu*—girl for wine.

**The Key Verses (3:4-8):**
"'What are you to me, O Tyre, and Zidon, and all the regions of Philistia?'"

*Ve-gam mah-attem li Tzor ve-Tzidon ve-khol gelilot Peleshet*—Tyre, Sidon, Philistia.

"'Will you render me a recompense?'"

*Ha-gemul attem meshallmim alai*—recompense?

"'Swiftly, speedily will I return your recompense upon your own head.'"

*Qal meherah ashiv gemulkhem be-rosהekhem*—return on head.

"'You have taken my silver and my gold.'"

*Asher kaspi u-zehavi leقachtem*—taken silver, gold.

"'Have carried into your temples my goodly treasures.'"

*U-machamaddai ha-tovim havetem le-heikhalekhem*—treasures to temples.

"'The children of Judah and the children of Jerusalem have you sold unto the sons of the Grecians.'"

*U-venei Yehudah u-venei Yerushalayim mekhارtem li-venei ha-Yevanim*—sold to Greeks.

"'That you might remove them far from their border.'"

*Lema'an harchiqam me-al gevulam*—remove far.

"'I will stir them up out of the place whither you have sold them.'"

*Hineni me'iram min-ha-maqom asher-mekhartem otam shammah*—stir up.

"'Will return your recompense upon your own head.'"

*Va-hashivoti gemulkhem be-roshekhem*—recompense.

"'I will sell your sons and your daughters into the hand of the children of Judah.'"

*U-makharti et-beneikhem ve-et-benotekhem be-yad benei Yehudah*—sold.

"'They shall sell them to the men of Sheba.'"

*U-mekhorum li-Sheva'im*—to Sheba.

**Call to Battle (3:9-17):**
**The Key Verses (3:9-11):**
"'Proclaim this among the nations, prepare war.'"

*Qir'u-zot ba-goyim qaddešu milchamah*—prepare war.

"'Stir up the mighty men.'"

*Ha'iru ha-gibborim*—stir mighty.

"'Let all the men of war draw near, let them come up.'"

*Yiggešu ya'alu kol anshei ha-milchamah*—come up.

"'Beat your plowshares into swords.'"

*Kottu itteikem la-charavot*—plowshares to swords.

**Reverse of Isaiah 2:4:**
Isaiah predicts swords to plowshares; Joel reverses for war.

"'Your pruning-hooks into spears.'"

*U-mazmeroteikhem li-remachim*—pruning-hooks to spears.

"'Let the weak say: I am strong.'"

*Ha-challash yomar gibbor ani*—weak say strong.

"'Haste and come, all you nations round about.'"

*Ushu va-vo'u khol-ha-goyim missaviv*—come, nations.

"'Gather yourselves together.'"

*Ve-niqbatzu*—gather.

"'Thither cause your mighty ones to come down, O YHWH.'"

*Shammah hanecht YHWH gibborekha*—YHWH's mighty.

**The Key Verses (3:12-14):**
"'Let the nations be stirred up, and come up to the valley of Jehoshaphat.'"

*Ye'oru ve-ya'alu ha-goyim el-emeq Yehoshafat*—to valley.

"'There will I sit to judge all the nations round about.'"

*Ki shammah eshev lishpot et-kol-ha-goyim missaviv*—sit to judge.

"'Put in the sickle, for the harvest is ripe.'"

*Shilchu maggal ki vashal qatzir*—sickle, harvest.

"'Come, tread, for the winepress is full.'"

*Bo'u redu ki male'ah gat*—tread winepress.

"'The vats overflow; for their wickedness is great.'"

*Heshiqu ha-yeqavim ki rabbah ra'atam*—overflow.

"'Multitudes, multitudes in the valley of decision!'"

*Hamonim hamonim be-emeq he-charutz*—valley of decision.

**Emeq He-Charutz:**
"Valley of Decision" or "Valley of Threshing."

"'For the day of YHWH is near in the valley of decision.'"

*Ki qarov yom YHWH be-emeq he-charutz*—day near.

**The Key Verses (3:15-17):**
"'The sun and the moon are darkened.'"

*Shemesh ve-yare'ach qadaru*—sun, moon dark.

"'The stars withdraw their shining.'"

*Ve-kokhavim asefu nogham*—stars dark.

"'YHWH shall roar from Zion.'"

*Va-YHWH mi-Tziyon yish'ag*—roar from Zion.

"'Utter his voice from Jerusalem.'"

*U-mi-Yrushalayim yitten qolo*—voice from Jerusalem.

"'The heavens and the earth shall shake.'"

*Ve-ra'ashu shamayim va-aretz*—shake.

"'YHWH will be a refuge unto his people.'"

*Va-YHWH machaseh le-ammo*—refuge.

"'A stronghold to the children of Israel.'"

*U-ma'oz li-vnei Yisra'el*—stronghold.

"'So shall you know that I am YHWH your God.'"

*Vi-yda'tem ki ani YHWH Eloheikhem*—know YHWH.

"'Dwelling in Zion my holy mountain.'"

*Shokhen be-Tziyon har-qodshi*—dwelling in Zion.

"'Jerusalem shall be holy.'"

*Ve-hayetah Yerushalayim qodesh*—holy.

"'There shall no strangers pass through her any more.'"

*Ve-zarim lo-ya'avru-vah od*—no strangers.

**Blessing for Judah (3:18-21):**
**The Key Verses (3:18-21):**
"'The mountains shall drop down sweet wine.'"

*Ve-hayah va-yom ha-hu yittfu he-harim asis*—mountains drop wine.

"'The hills shall flow with milk.'"

*Ve-ha-geva'ot telakhna chalav*—hills flow milk.

"'All the brooks of Judah shall flow with waters.'"

*Ve-khol-afiqei Yehudah yelekhu mayim*—brooks flow.

"'A fountain shall come forth from the house of YHWH.'"

*U-ma'yan mi-beit YHWH yetze*—fountain from temple.

"'Shall water the valley of Shittim.'"

*Ve-hishqah et-nachal ha-Shittim*—water Shittim.

**Fountain from Temple:**
Echoes Ezekiel 47's temple river.

"'Egypt shall be a desolation.'"

*Mitzrayim li-shemamah tihyeh*—Egypt desolate.

"'Edom shall be a desolate wilderness.'"

*Ve-Edom le-midbar shemamah tihyeh*—Edom desolate.

"'For the violence done to the children of Judah.'"

*Me-chamas benei Yehudah*—violence to Judah.

"'Because they have shed innocent blood in their land.'"

*Asher-shafekhu dam naqi be-artzam*—innocent blood.

"'Judah shall be inhabited for ever.'"

*Vi-Yhudah le-olam teshev*—forever.

"'Jerusalem from generation to generation.'"

*Vi-Yrushalayim le-dor va-dor*—generation to generation.

"'I will hold as innocent their blood which I have not held as innocent.'"

*Ve-niqqeiti damam lo-niqqeiti*—cleanse blood.

"'YHWH dwells in Zion.'"

*Va-YHWH shokhen be-Tziyon*—YHWH dwells.

**Archetypal Layer:** Joel 3 contains **"I will bring back the captivity of Judah and Jerusalem" (3:1)**, **"I will gather all nations... into the valley of Jehoshaphat" (3:2)**, **judgment for scattering Israel and dividing the land (3:2)**, **"they have cast lots for my people" (3:3)**, **"beat your plowshares into swords" (3:10)**—reverse of Isaiah 2:4, **"let the weak say: I am strong" (3:10)**, **"put in the sickle, for the harvest is ripe" (3:13)**, **"Multitudes, multitudes in the valley of decision" (3:14)**, **cosmic signs (3:15)**, **"YHWH shall roar from Zion" (3:16)**, **"YHWH will be a refuge unto his people" (3:16)**, **"Jerusalem shall be holy" (3:17)**, **"a fountain shall come forth from the house of YHWH" (3:18)**, and **"YHWH dwells in Zion" (3:21)**.

**Ethical Inversion Applied:**
- "'In those days... when I shall bring back the captivity'"—restore
- "'I will gather all nations'"—gather
- "'Will bring them down into the valley of Jehoshaphat'"—judgment valley
- "'I will enter into judgment with them'"—judgment
- "'They have scattered among the nations, and divided my land'"—scattered
- "'They have cast lots for my people'"—cast lots
- "'Given a boy for a harlot, sold a girl for wine'"—sold children
- "'What are you to me, O Tyre, and Zidon?'"—Phoenicia
- "'Will you render me a recompense?'"—recompense
- "'You have taken my silver and my gold'"—plunder
- "'Have sold unto the sons of the Grecians'"—sold to Greeks
- "'I will stir them up'"—stir up
- "'Will return your recompense upon your own head'"—return
- "'Proclaim this among the nations, prepare war'"—prepare war
- "'Stir up the mighty men'"—stir mighty
- "'Beat your plowshares into swords'"—plowshares to swords
- "'Your pruning-hooks into spears'"—pruning-hooks to spears
- "'Let the weak say: I am strong'"—weak say strong
- "'Let the nations be stirred up'"—nations stirred
- "'Come up to the valley of Jehoshaphat'"—judgment valley
- "'There will I sit to judge'"—judge
- "'Put in the sickle, for the harvest is ripe'"—harvest
- "'Come, tread, for the winepress is full'"—tread
- "'The vats overflow'"—overflow
- "'Multitudes, multitudes in the valley of decision'"—valley of decision
- "'The day of YHWH is near in the valley of decision'"—day near
- "'The sun and the moon are darkened'"—darkened
- "'YHWH shall roar from Zion'"—roar
- "'The heavens and the earth shall shake'"—shake
- "'YHWH will be a refuge unto his people'"—refuge
- "'A stronghold to the children of Israel'"—stronghold
- "'I am YHWH your God'"—YHWH God
- "'Dwelling in Zion my holy mountain'"—Zion
- "'Jerusalem shall be holy'"—holy
- "'No strangers pass through her any more'"—no strangers
- "'The mountains shall drop down sweet wine'"—wine
- "'The hills shall flow with milk'"—milk
- "'All the brooks of Judah shall flow with waters'"—waters
- "'A fountain shall come forth from the house of YHWH'"—fountain
- "'Shall water the valley of Shittim'"—Shittim
- "'Egypt shall be a desolation'"—Egypt desolate
- "'Edom shall be a desolate wilderness'"—Edom desolate
- "'For the violence done to the children of Judah'"—violence
- "'Judah shall be inhabited for ever'"—forever
- "'Jerusalem from generation to generation'"—generation to generation
- "'YHWH dwells in Zion'"—YHWH dwells

**Modern Equivalent:** Joel 3 is eschatological judgment. The "valley of Jehoshaphat" (3:2, 12) and "valley of decision" (3:14) are where nations face divine judgment for mistreating Israel. "Beat your plowshares into swords" (3:10) deliberately reverses Isaiah 2:4's peace vision—this is war time. The fountain from the temple (3:18) echoes Ezekiel 47 and Zechariah 14. "YHWH dwells in Zion" (3:21) is the book's climax.

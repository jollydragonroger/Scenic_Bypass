# Joel 2: The Day of YHWH and the Call to Repentance

*From the Hebrew: תִּקְעוּ שׁוֹפָר בְּצִיּוֹן (Tiq'u Shofar Be-Tziyon) — Blow the Horn in Zion*

---

## The Invading Army (2:1-11)

**2:1** Blow the horn in Zion, and sound an alarm in my holy mountain; let all the inhabitants of the land tremble; for the day of YHWH comes, for it is nigh at hand;

**2:2** A day of darkness and gloominess, a day of clouds and thick darkness, as blackness spread upon the mountains; a great people and a strong, there has not been ever the like, neither shall be any more after them, even to the years of many generations.

**2:3** A fire devours before them, and behind them a flame blazes; the land is as the garden of Eden before them, and behind them a desolate wilderness; yea, and nothing escapes them.

**2:4** The appearance of them is as the appearance of horses; and as horsemen, so do they run.

**2:5** Like the noise of chariots, on the tops of the mountains do they leap, like the noise of a flame of fire that devours the stubble, as a mighty people set in battle array.

**2:6** Before them the peoples are in anguish; all faces gather blackness.

**2:7** They run like mighty men, they climb the wall like men of war; and they march every one on his ways, and they break not their ranks.

**2:8** Neither does one thrust another, they march every one in his path; and they burst through the weapons, and break not off their course.

**2:9** They leap upon the city, they run upon the wall; they climb up into the houses; they enter in at the windows like a thief.

**2:10** Before them the earth quakes, the heavens tremble; the sun and the moon are darkened, and the stars withdraw their shining.

**2:11** And YHWH utters his voice before his army; for his camp is very great, for he is mighty that executes his word; for great is the day of YHWH and very terrible; and who can abide it?

---

## Call to Repentance (2:12-17)

**2:12** Yet even now, says YHWH, turn unto me with all your heart, and with fasting, and with weeping, and with mourning;

**2:13** And rend your heart, and not your garments, and turn unto YHWH your God; for he is gracious and compassionate, long-suffering, and abundant in mercy, and repents him of the evil.

**2:14** Who knows whether he will not turn and repent, and leave a blessing behind him, even a meal-offering and a drink-offering unto YHWH your God?

**2:15** Blow the horn in Zion, sanctify a fast, call a solemn assembly;

**2:16** Gather the people, sanctify the congregation, assemble the elders, gather the children, and those that suck the breasts; let the bridegroom go forth from his chamber, and the bride out of her pavilion.

**2:17** Let the priests, the ministers of YHWH, weep between the porch and the altar, and let them say: "Spare your people, O YHWH, and give not your heritage to reproach, that the nations should make them a byword; wherefore should they say among the peoples: 'Where is their God?'"

---

## YHWH's Response (2:18-27)

**2:18** Then was YHWH jealous for his land, and had pity on his people.

**2:19** And YHWH answered and said unto his people: "Behold, I will send you grain, and wine, and oil, and you shall be satisfied therewith; and I will no more make you a reproach among the nations;

**2:20** "But I will remove far off from you the northern one, and will drive him into a land barren and desolate, his front into the eastern sea, and his hinder part into the western sea; that his ill savour may come up, and his stench may come up, because he has done great things."

**2:21** Fear not, O land, be glad and rejoice; for YHWH has done great things.

**2:22** Be not afraid, you beasts of the field; for the pastures of the wilderness do spring, for the tree bears its fruit, the fig-tree and the vine do yield their strength.

**2:23** Be glad then, you children of Zion, and rejoice in YHWH your God; for he gives you the former rain in just measure, and he causes to come down for you the rain, the former rain and the latter rain, at the first.

**2:24** And the floors shall be full of wheat, and the vats shall overflow with wine and oil.

**2:25** And I will restore to you the years that the locust has eaten, the cankerworm, and the caterpillar, and the palmerworm, my great army which I sent among you.

**2:26** And you shall eat in plenty and be satisfied, and shall praise the name of YHWH your God, that has dealt wondrously with you; and my people shall never be ashamed.

**2:27** And you shall know that I am in the midst of Israel, and that I am YHWH your God, and there is none else; and my people shall never be ashamed.

---

## The Outpouring of the Spirit (2:28-32)

**2:28** And it shall come to pass afterward, that I will pour out my spirit upon all flesh; and your sons and your daughters shall prophesy, your old men shall dream dreams, your young men shall see visions;

**2:29** And also upon the servants and upon the handmaids in those days will I pour out my spirit.

**2:30** And I will show wonders in the heavens and in the earth, blood, and fire, and pillars of smoke.

**2:31** The sun shall be turned into darkness, and the moon into blood, before the great and terrible day of YHWH come.

**2:32** And it shall come to pass, that whosoever shall call on the name of YHWH shall be delivered; for in mount Zion and in Jerusalem there shall be those that escape, as YHWH has said, and among the remnant those whom YHWH does call.

---

## Synthesis Notes

**Key Restorations:**

**Invading Army (2:1-11):**
**The Key Verses (2:1-2):**
"'Blow the horn in Zion, and sound an alarm in my holy mountain.'"

*Tiq'u shofar be-Tziyon ve-hari'u be-har qodshi*—blow horn.

"'Let all the inhabitants of the land tremble.'"

*Yirgezu kol yoshevei ha-aretz*—tremble.

"'The day of YHWH comes, for it is nigh at hand.'"

*Ki-va yom YHWH ki qarov*—day near.

"'A day of darkness and gloominess, a day of clouds and thick darkness.'"

*Yom choshekh va-afelah yom anan va-arafel*—darkness.

"'A great people and a strong.'"

*Am rav ve-atzum*—great, strong people.

"'There has not been ever the like.'"

*Kamohu lo nihyah min-ha-olam*—unprecedented.

**The Key Verses (2:3-5):**
"'A fire devours before them, and behind them a flame blazes.'"

*Lefanav akhelah esh ve-acharav telahbet lehavah*—fire before, behind.

"'The land is as the garden of Eden before them.'"

*Ke-gan-Eden ha-aretz lefanav*—like Eden.

"'Behind them a desolate wilderness.'"

*Ve-acharav midbar shemamah*—desolate wilderness.

"'Nothing escapes them.'"

*Ve-gam peleితah lo-hayetah lo*—nothing escapes.

"'The appearance of them is as the appearance of horses.'"

*Ke-mar'eh susim mar'ehu*—like horses.

"'As horsemen, so do they run.'"

*U-khe-farashim ken yerutzun*—like horsemen.

"'Like the noise of chariots.'"

*Ke-qol merkavot*—chariot noise.

**The Key Verses (2:6-11):**
"'Before them the peoples are in anguish.'"

*Mi-panav yachilu ammim*—peoples anguish.

"'All faces gather blackness.'"

*Kol-panim qibbetzu fa'rur*—faces blacken.

"'They run like mighty men, they climb the wall like men of war.'"

*Ke-gibborim yerutzun ke-anshei milchamah ya'alu chomah*—like warriors.

"'They march every one on his ways, and they break not their ranks.'"

*Ve-ish bi-derakhav yelekun ve-lo yeavtun orchotam*—orderly.

"'They burst through the weapons, and break not off their course.'"

*U-ve'ad ha-shelach yippolu lo yivtza'u*—unstoppable.

"'They leap upon the city, they run upon the wall.'"

*Ba-ir yashoqqu ba-chomah yerutzun*—climb walls.

"'They enter in at the windows like a thief.'"

*Be'ad ha-challonot yavo'u ka-gannav*—like thief.

"'Before them the earth quakes, the heavens tremble.'"

*Lefanav rag'zah eretz ra'ashu shamayim*—earth, heavens shake.

"'The sun and the moon are darkened.'"

*Shemesh ve-yare'ach qadaru*—sun, moon dark.

"'The stars withdraw their shining.'"

*Ve-kokhavim asefu nogham*—stars dark.

"'YHWH utters his voice before his army.'"

*Va-YHWH natan qolo lifnei cheilo*—YHWH's voice.

"'His camp is very great.'"

*Ki rav me'od machanehו*—great camp.

"'He is mighty that executes his word.'"

*Ki atzum oseh devaro*—executes word.

"'Great is the day of YHWH and very terrible.'"

*Ki-gadol yom YHWH ve-nora me'od*—great, terrible.

"'Who can abide it?'"

*U-mi yekhilennו*—who can endure?

**Call to Repentance (2:12-17):**
**The Key Verses (2:12-14):**
"''Yet even now,' says YHWH, 'turn unto me with all your heart.''"

*Ve-gam-attah ne'um YHWH shuvu adai be-khol-levavkhem*—turn now.

"'With fasting, and with weeping, and with mourning.'"

*U-ve-tzom u-vi-vekhi u-ve-misped*—fasting, weeping.

"'Rend your heart, and not your garments.'"

*Ve-qir'u levavkhem ve-al-bigdeikhem*—heart not garments.

"'Turn unto YHWH your God.'"

*Ve-shuvu el-YHWH Eloheikhem*—turn to YHWH.

"'For he is gracious and compassionate.'"

*Ki-channun ve-rachum hu*—gracious, compassionate.

"'Long-suffering, and abundant in mercy.'"

*Erekh appayim ve-rav-chesed*—slow to anger, abundant mercy.

"'Repents him of the evil.'"

*Ve-nicham al-ha-ra'ah*—relents.

"'Who knows whether he will not turn and repent.'"

*Mi yode'a yashuv ve-nicham*—who knows?

"'Leave a blessing behind him.'"

*Ve-hish'ir acharav berakhah*—leave blessing.

**The Key Verses (2:15-17):**
"'Blow the horn in Zion, sanctify a fast.'"

*Tiq'u shofar be-Tziyon qaddešu-tzom*—horn, fast.

"'Call a solemn assembly.'"

*Qir'u atzarah*—assembly.

"'Gather the people, sanctify the congregation.'"

*Ispu-am qaddešu qahal*—gather, sanctify.

"'Assemble the elders, gather the children.'"

*Qivtzu zeqenim ispu olalim*—all ages.

"'Let the bridegroom go forth from his chamber.'"

*Yetze chatan me-chedro*—bridegroom.

"'The bride out of her pavilion.'"

*Ve-khallah me-chuppatah*—bride.

"'Let the priests... weep between the porch and the altar.'"

*Bein ha-ulam ve-la-mizbe'ach yivku ha-kohanim*—between porch and altar.

"''Spare your people, O YHWH.''"

*Chusah YHWH al-ammekha*—spare.

"''Give not your heritage to reproach.''"

*Ve-al-titten nachalatekha le-cherpah*—not reproach.

"''That the nations should make them a byword.''"

*Limshol-bam goyim*—byword.

"''Wherefore should they say among the peoples: Where is their God?''"

*Lammah yomeru va-ammim ayyeh Eloheihem*—where is God?

**YHWH's Response (2:18-27):**
**The Key Verses (2:18-20):**
"'Then was YHWH jealous for his land.'"

*Va-yeqanne YHWH le-artzo*—jealous.

"'Had pity on his people.'"

*Va-yachmol al-ammo*—pity.

"''Behold, I will send you grain, and wine, and oil.''"

*Hineni shole'ach lakhem et-ha-dagan ve-ha-tirosh ve-ha-yitzhar*—restore.

"''You shall be satisfied therewith.''"

*U-seba'tem oto*—satisfied.

"''I will no more make you a reproach among the nations.''"

*Ve-lo-etten etkhem od cherpah ba-goyim*—no reproach.

"''I will remove far off from you the northern one.''"

*Ve-et-ha-tzefoni archiq me-aleikhem*—northern removed.

"''Will drive him into a land barren and desolate.''"

*Ve-hidachtiv el-eretz tziyyah u-shemamah*—desolate land.

**Ha-Tzefoni:**
"The northern one"—the locust army, or eschatological enemy.

**The Key Verses (2:21-25):**
"'Fear not, O land, be glad and rejoice.'"

*Al-tire'i adamah gili u-semachi*—rejoice.

"'YHWH has done great things.'"

*Ki-higdil YHWH la'asot*—great things.

"'Be not afraid, you beasts of the field.'"

*Al-tire'u bahamot sadai*—beasts.

"'The pastures of the wilderness do spring.'"

*Ki dašsu ne'ot midbar*—pastures spring.

"'The tree bears its fruit.'"

*Ki-etz nasa piryo*—tree bears.

"'The fig-tree and the vine do yield their strength.'"

*Te'enah va-gefen natnu cheilam*—fig, vine.

"'Be glad then, you children of Zion.'"

*U-venei Tziyon gilu ve-simchu*—children of Zion.

"'Rejoice in YHWH your God.'"

*Ba-YHWH Eloheikhem*—in YHWH.

"'He gives you the former rain in just measure.'"

*Ki-natan lakhem et-ha-moreh li-tzedaqah*—former rain.

"'He causes to come down for you the rain, the former rain and the latter rain.'"

*Va-yored lakhem geshem moreh u-malqosh ba-rishon*—rains.

"'The floors shall be full of wheat.'"

*U-male'u ha-goranot bar*—full floors.

"'The vats shall overflow with wine and oil.'"

*Ve-heshiqu ha-yeqavim tirosh ve-yitzhar*—overflow.

"''I will restore to you the years that the locust has eaten.''"

*Ve-shillam'ti lakhem et-ha-shanim asher akhal ha-arbeh*—restore years.

**Restore the Years:**
Famous promise—God restores what was lost.

"'The cankerworm, and the caterpillar, and the palmerworm.'"

*Ha-yeleq ve-he-chasil ve-ha-gazam*—all locusts.

"'My great army which I sent among you.'"

*Cheili ha-gadol asher shillachti vakhem*—my army.

**The Key Verses (2:26-27):**
"''You shall eat in plenty and be satisfied.''"

*Va-akhaltem akhol ve-savo'a*—eat, satisfied.

"''Shall praise the name of YHWH your God.''"

*Ve-hillaltem et-shem YHWH Eloheikhem*—praise.

"''That has dealt wondrously with you.''"

*Asher-asah immakhem le-hafli*—wondrously.

"''My people shall never be ashamed.''"

*Ve-lo-yevoshu ammi le-olam*—never ashamed.

"''You shall know that I am in the midst of Israel.''"

*Vi-yda'tem ki be-qerev Yisra'el ani*—in midst.

"''I am YHWH your God, and there is none else.''"

*Va-ani YHWH Eloheikhem ve-ein od*—none else.

**Outpouring of the Spirit (2:28-32):**
**The Key Verses (2:28-29):**
"''It shall come to pass afterward, that I will pour out my spirit upon all flesh.''"

*Ve-hayah acharei-khen eshpokh et-ruchi al-kol-basar*—pour out Spirit.

"''Your sons and your daughters shall prophesy.''"

*Ve-nibbe'u beneikhem u-venotekhem*—sons, daughters prophesy.

"''Your old men shall dream dreams.''"

*Ziqneikhem chalomot yachalomun*—old men dream.

"''Your young men shall see visions.''"

*Bachureikhem chezyonot yir'u*—young men visions.

"''Also upon the servants and upon the handmaids in those days will I pour out my spirit.''"

*Ve-gam al-ha-avadim ve-al-ha-shefachot ba-yamim ha-hemmah eshpokh et-ruchi*—servants too.

**Pentecost:**
Peter quotes this in Acts 2:17-21.

**The Key Verses (2:30-32):**
"''I will show wonders in the heavens and in the earth.''"

*Ve-natatti moftim ba-shamayim u-va-aretz*—wonders.

"''Blood, and fire, and pillars of smoke.''"

*Dam va-esh ve-timrot ashan*—blood, fire, smoke.

"''The sun shall be turned into darkness, and the moon into blood.''"

*Ha-shemesh yehafekh le-choshekh ve-ha-yare'ach le-dam*—sun dark, moon blood.

"''Before the great and terrible day of YHWH come.''"

*Lifnei bo yom YHWH ha-gadol ve-ha-nora*—before day of YHWH.

"''Whosoever shall call on the name of YHWH shall be delivered.''"

*Ve-hayah kol asher-yiqra be-shem YHWH yimmalet*—call, delivered.

"''In mount Zion and in Jerusalem there shall be those that escape.''"

*Ki be-har Tziyon u-vi-Yrushalayim tihyeh peleתah*—escape.

"''As YHWH has said.''"

*Ka-asher amar YHWH*—as YHWH said.

"''Among the remnant those whom YHWH does call.''"

*U-va-seridim asher YHWH qore*—YHWH calls.

**Archetypal Layer:** Joel 2 contains **"Blow the horn in Zion" (2:1)**, **the locust army described as apocalyptic invasion (2:1-11)**, **"the day of YHWH comes... a day of darkness and gloominess" (2:1-2)**, **"the land is as the garden of Eden before them, and behind them a desolate wilderness" (2:3)**, **cosmic signs: earth quakes, heavens tremble, sun and moon darkened (2:10)**, **"who can abide it?" (2:11)**, **"rend your heart, and not your garments" (2:13)**, **"he is gracious and compassionate, long-suffering, and abundant in mercy" (2:13)**, **"I will restore to you the years that the locust has eaten" (2:25)**, **"I will pour out my spirit upon all flesh" (2:28)**—quoted at Pentecost, **"your sons and your daughters shall prophesy" (2:28)**, **"the sun shall be turned into darkness, and the moon into blood" (2:31)**, and **"whosoever shall call on the name of YHWH shall be delivered" (2:32)**.

**Ethical Inversion Applied:**
- "'Blow the horn in Zion'"—alarm
- "'The day of YHWH comes'"—day near
- "'A day of darkness and gloominess'"—darkness
- "'A great people and a strong'"—unprecedented
- "'A fire devours before them'"—fire
- "'The land is as the garden of Eden before them'"—Eden
- "'Behind them a desolate wilderness'"—desolation
- "'The appearance of them is as the appearance of horses'"—horses
- "'Before them the peoples are in anguish'"—anguish
- "'They climb the wall like men of war'"—warriors
- "'Before them the earth quakes, the heavens tremble'"—cosmic shaking
- "'The sun and the moon are darkened'"—darkened
- "'YHWH utters his voice before his army'"—YHWH's army
- "'Great is the day of YHWH and very terrible'"—terrible
- "'Who can abide it?'"—who can endure
- "''Turn unto me with all your heart''"—turn
- "'With fasting, and with weeping'"—fasting
- "'Rend your heart, and not your garments'"—heart not garments
- "'He is gracious and compassionate'"—gracious
- "'Long-suffering, and abundant in mercy'"—mercy
- "'Who knows whether he will not turn and repent'"—who knows
- "'Blow the horn in Zion, sanctify a fast'"—fast
- "'Gather the people'"—gather
- "'Let the bridegroom go forth'"—bridegroom
- "'Let the priests... weep between the porch and the altar'"—weep
- "''Spare your people, O YHWH''"—spare
- "''Where is their God?''"—where is God
- "'Then was YHWH jealous for his land'"—jealous
- "'Had pity on his people'"—pity
- "''I will send you grain, and wine, and oil''"—restore
- "''I will remove far off from you the northern one''"—remove enemy
- "'Fear not, O land, be glad and rejoice'"—rejoice
- "'YHWH has done great things'"—great things
- "'The pastures of the wilderness do spring'"—pastures spring
- "'Be glad then, you children of Zion'"—be glad
- "''I will restore to you the years that the locust has eaten''"—restore years
- "''You shall eat in plenty and be satisfied''"—satisfied
- "''My people shall never be ashamed''"—never ashamed
- "''I am YHWH your God, and there is none else''"—none else
- "''I will pour out my spirit upon all flesh''"—pour out Spirit
- "''Your sons and your daughters shall prophesy''"—prophesy
- "''Your old men shall dream dreams''"—dreams
- "''Your young men shall see visions''"—visions
- "''Also upon the servants and upon the handmaids''"—servants too
- "''Blood, and fire, and pillars of smoke''"—signs
- "''The sun shall be turned into darkness, and the moon into blood''"—sun, moon
- "''Whosoever shall call on the name of YHWH shall be delivered''"—call, delivered
- "''Among the remnant those whom YHWH does call''"—YHWH calls

**Modern Equivalent:** Joel 2 moves from apocalyptic terror to glorious hope. The locust army becomes cosmic judgment. "Rend your heart, and not your garments" (2:13) calls for genuine repentance. "I will restore the years the locust has eaten" (2:25) promises restoration. The Spirit outpouring (2:28-32), quoted by Peter at Pentecost (Acts 2), promises prophetic gifts for all—sons, daughters, servants, old and young.

# Joel 1: The Locust Plague

*From the Hebrew: דְּבַר־יְהוָה אֲשֶׁר הָיָה אֶל־יוֹאֵל (Devar-YHWH Asher Hayah El-Yo'el) — The Word of YHWH That Came to Joel*

---

## Title and Call to Attention (1:1-4)

**1:1** The word of YHWH that came to Joel the son of Pethuel.

**1:2** Hear this, you old men, and give ear, all you inhabitants of the land. Has this been in your days, or in the days of your fathers?

**1:3** Tell your children of it, and let your children tell their children, and their children another generation.

**1:4** That which the cutting locust has left has the swarming locust eaten; and that which the swarming locust has left has the hopping locust eaten; and that which the hopping locust has left has the destroying locust eaten.

---

## Call to Lament (1:5-14)

**1:5** Awake, you drunkards, and weep, and wail, all you drinkers of wine, because of the sweet wine, for it is cut off from your mouth.

**1:6** For a nation is come up upon my land, mighty, and without number; his teeth are the teeth of a lion, and he has the jaw-teeth of a lioness.

**1:7** He has laid my vine waste, and barked my fig-tree; he has made it clean bare, and cast it down, the branches thereof are made white.

**1:8** Lament like a virgin girded with sackcloth for the husband of her youth.

**1:9** The meal-offering and the drink-offering is cut off from the house of YHWH; the priests mourn, even YHWH's ministers.

**1:10** The field is wasted, the land mourns; for the grain is wasted, the new wine is dried up, the oil languishes.

**1:11** Be ashamed, O you husbandmen, wail, O you vinedressers, for the wheat and for the barley; because the harvest of the field is perished.

**1:12** The vine is withered, and the fig-tree languishes; the pomegranate-tree, the palm-tree also, and the apple-tree, even all the trees of the field are withered; for joy is withered away from the sons of men.

**1:13** Gird yourselves, and lament, you priests, wail, you ministers of the altar; come, lie all night in sackcloth, you ministers of my God; for the meal-offering and the drink-offering is withholden from the house of your God.

**1:14** Sanctify a fast, call a solemn assembly, gather the elders and all the inhabitants of the land unto the house of YHWH your God, and cry unto YHWH.

---

## The Day of YHWH (1:15-20)

**1:15** Alas for the day! For the day of YHWH is at hand, and as destruction from the Almighty shall it come.

**1:16** Is not the food cut off before our eyes, yea, joy and gladness from the house of our God?

**1:17** The grains shrivel under their clods; the garners are laid desolate, the barns are broken down; for the grain is withered.

**1:18** How do the beasts groan! The herds of cattle are perplexed, because they have no pasture; yea, the flocks of sheep are made desolate.

**1:19** Unto you, O YHWH, do I cry; for the fire has devoured the pastures of the wilderness, and the flame has set ablaze all the trees of the field.

**1:20** Yea, the beasts of the field pant unto you; for the water brooks are dried up, and the fire has devoured the pastures of the wilderness.

---

## Synthesis Notes

**Key Restorations:**

**Title and Call to Attention (1:1-4):**
**The Key Verse (1:1):**
"The word of YHWH that came to Joel the son of Pethuel."

*Devar-YHWH asher hayah el-Yo'el ben-Petu'el*—word to Joel.

**Yo'el:**
"YHWH is God."

**The Key Verses (1:2-3):**
"'Hear this, you old men, and give ear, all you inhabitants of the land.'"

*Shim'u-zot ha-zeqenim ve-ha'azinu kol yoshevei ha-aretz*—hear, elders.

"'Has this been in your days, or in the days of your fathers?'"

*Ha-hayetah zot bi-yemeikhem ve-im bi-yemei avoteikhem*—unprecedented.

"'Tell your children of it, and let your children tell their children.'"

*Li-veneikhem sapperu ve-veneikhem li-vneihem u-vneihem le-dor acher*—intergenerational.

**The Key Verse (1:4):**
"'That which the cutting locust has left has the swarming locust eaten.'"

*Yeter ha-gazam akhal ha-arbeh*—cutting → swarming.

"'That which the swarming locust has left has the hopping locust eaten.'"

*Ve-yeter ha-arbeh akhal ha-yeleq*—swarming → hopping.

"'That which the hopping locust has left has the destroying locust eaten.'"

*Ve-yeter ha-yeleq akhal he-chasil*—hopping → destroying.

**Four Locusts:**
Gazam, arbeh, yeleq, chasil—four stages or species of locust, total devastation.

**Call to Lament (1:5-14):**
**The Key Verses (1:5-7):**
"'Awake, you drunkards, and weep.'"

*Haqitzu shikkorim u-vekhu*—drunkards wake.

"'Wail, all you drinkers of wine, because of the sweet wine.'"

*Ve-heililu kol-shotei yayin al-asis*—wail for wine.

"'For it is cut off from your mouth.'"

*Ki nikhrat mi-pikhem*—cut off.

"'A nation is come up upon my land, mighty, and without number.'"

*Ki-goy alah al-artzi atzum ve-ein mispar*—mighty nation.

"'His teeth are the teeth of a lion.'"

*Shinnav shinnei aryeh*—lion's teeth.

"'He has the jaw-teeth of a lioness.'"

*U-metalle'ot lavi lo*—lioness jaws.

"'He has laid my vine waste, and barked my fig-tree.'"

*Sam gafni le-shammah u-te'enati li-qetsafah*—devastated.

**The Key Verses (1:8-10):**
"'Lament like a virgin girded with sackcloth for the husband of her youth.'"

*Eli ki-vetulah chagurat-saq al-ba'al ne'urekha*—virgin mourning.

"'The meal-offering and the drink-offering is cut off from the house of YHWH.'"

*Hokhrat minchah va-nesekh mi-beit YHWH*—offerings cut off.

"'The priests mourn, even YHWH's ministers.'"

*Avelu ha-kohanim mesharetei YHWH*—priests mourn.

"'The field is wasted, the land mourns.'"

*Shuddad sadeh avelah adamah*—field wasted.

"'The grain is wasted, the new wine is dried up, the oil languishes.'"

*Ki shuddad dagan hovish tirosh umlal yitzhar*—all crops gone.

**The Key Verses (1:11-14):**
"'Be ashamed, O you husbandmen, wail, O you vinedressers.'"

*Hovishu ikkarim heililu korerim*—farmers, vinedressers.

"'For the wheat and for the barley; because the harvest of the field is perished.'"

*Al-chittah ve-al-se'orah ki avad qetzir sadeh*—harvest perished.

"'The vine is withered, and the fig-tree languishes.'"

*Ha-gefen hovيshah ve-ha-te'enah umlelah*—vine, fig withered.

"'All the trees of the field are withered.'"

*Kol-atzei ha-sadeh yaveshu*—all trees.

"'Joy is withered away from the sons of men.'"

*Ki-hovish sason min-benei adam*—joy gone.

"'Gird yourselves, and lament, you priests.'"

*Chigru ve-sifdu ha-kohanim*—priests lament.

"'Come, lie all night in sackcloth.'"

*Bo'u linu va-saqqim*—lie in sackcloth.

"'Sanctify a fast, call a solemn assembly.'"

*Qaddešu-tzom qir'u atzarah*—fast, assembly.

"'Gather the elders and all the inhabitants of the land unto the house of YHWH.'"

*Ispu zeqenim kol yoshevei ha-aretz beit YHWH Eloheikhem*—gather.

"'Cry unto YHWH.'"

*Ve-za'aqu el-YHWH*—cry.

**Day of YHWH (1:15-20):**
**The Key Verse (1:15):**
"'Alas for the day!'"

*Ahah la-yom*—alas.

"'For the day of YHWH is at hand.'"

*Ki qarov yom YHWH*—day near.

"'As destruction from the Almighty shall it come.'"

*U-khe-shod mi-Shaddai yavo*—destruction from Shaddai.

**Shod Mi-Shaddai:**
Wordplay: "destruction" (shod) from "Almighty" (Shaddai).

**The Key Verses (1:16-20):**
"'Is not the food cut off before our eyes?'"

*Ha-lo neged eineinu okhel nikhrat*—food cut off.

"'Joy and gladness from the house of our God?'"

*Mi-beit Eloheinu simchah va-gil*—joy gone.

"'The grains shrivel under their clods.'"

*Aવeshu perudot tachat megrefoteihem*—grains shrivel.

"'The garners are laid desolate.'"

*Nashammו otzarot*—granaries desolate.

"'How do the beasts groan!'"

*Mah-ne'enchah behemah*—beasts groan.

"'The herds of cattle are perplexed.'"

*Navokhu edrei vaqar*—cattle perplexed.

"'Because they have no pasture.'"

*Ki ein mir'eh lahem*—no pasture.

"'The flocks of sheep are made desolate.'"

*Gam-edrei ha-tzon ne'shamu*—sheep desolate.

"'Unto you, O YHWH, do I cry.'"

*Elekha YHWH eqra*—cry to YHWH.

"'The fire has devoured the pastures of the wilderness.'"

*Ki esh akhelah ne'ot midbar*—fire devoured.

"'The flame has set ablaze all the trees of the field.'"

*Ve-lehavah lihatah kol-atzei ha-sadeh*—trees ablaze.

"'The beasts of the field pant unto you.'"

*Gam-bahamot sadeh ta'arog elekha*—beasts pant.

"'The water brooks are dried up.'"

*Ki yaveshu afiqei mayim*—brooks dried.

**Archetypal Layer:** Joel 1 describes a **devastating locust plague**, containing **four stages of locust destruction (1:4)**, **"a nation is come up upon my land, mighty, and without number" (1:6)**, **call to all groups to lament: drunkards (1:5), priests (1:9, 13), farmers (1:11)**, **"joy is withered away from the sons of men" (1:12)**, **"sanctify a fast, call a solemn assembly" (1:14)**, **"the day of YHWH is at hand" (1:15)**, **"as destruction from the Almighty shall it come" (1:15)**, and **cosmic mourning: beasts, land, fire (1:18-20)**.

**Ethical Inversion Applied:**
- "The word of YHWH that came to Joel"—prophetic call
- "'Hear this, you old men'"—hear
- "'Has this been in your days?'"—unprecedented
- "'Tell your children of it'"—intergenerational
- "'That which the cutting locust has left has the swarming locust eaten'"—total destruction
- "'Awake, you drunkards, and weep'"—drunkards
- "'A nation is come up upon my land'"—locust nation
- "'His teeth are the teeth of a lion'"—lion teeth
- "'He has laid my vine waste'"—devastation
- "'Lament like a virgin girded with sackcloth'"—virgin mourning
- "'The meal-offering and the drink-offering is cut off'"—offerings cut
- "'The priests mourn'"—priests mourn
- "'The field is wasted, the land mourns'"—land mourns
- "'The grain is wasted'"—grain gone
- "'Be ashamed, O you husbandmen'"—farmers ashamed
- "'All the trees of the field are withered'"—all withered
- "'Joy is withered away from the sons of men'"—joy gone
- "'Gird yourselves, and lament, you priests'"—priests lament
- "'Sanctify a fast, call a solemn assembly'"—fast
- "'Cry unto YHWH'"—cry
- "'Alas for the day!'"—alas
- "'The day of YHWH is at hand'"—day of YHWH
- "'As destruction from the Almighty shall it come'"—destruction
- "'Is not the food cut off before our eyes?'"—cut off
- "'The grains shrivel'"—shrivel
- "'How do the beasts groan!'"—beasts groan
- "'Unto you, O YHWH, do I cry'"—cry
- "'The fire has devoured'"—fire
- "'The beasts of the field pant unto you'"—beasts pant
- "'The water brooks are dried up'"—dried

**Modern Equivalent:** Joel 1 describes agricultural catastrophe—a locust plague of unprecedented severity. Four locust terms (1:4) emphasize total devastation. The locusts are compared to a "nation" with lion's teeth (1:6). This becomes a lens for the "Day of YHWH" (1:15)—natural disaster prefiguring cosmic judgment. The call to fasting and assembly (1:14) is the proper response.

# Zechariah 10: YHWH Will Restore His People

*From the Hebrew: שַׁאֲלוּ מֵיְהוָה מָטָר (Sha'alu Me-YHWH Matar) — Ask of YHWH Rain*

---

## Ask YHWH, Not Idols (10:1-2)

**10:1** Ask of YHWH rain in the time of the latter rain, even of YHWH that makes lightnings; and he will give them showers of rain, to every one grass in the field.

**10:2** For the teraphim have spoken vanity, and the diviners have seen a lie, and the dreams speak falsely, they comfort in vain; therefore they go their way like sheep, they are afflicted, because there is no shepherd.

---

## YHWH's Anger and Restoration (10:3-12)

**10:3** My anger is kindled against the shepherds, and I will punish the he-goats; for YHWH of hosts has remembered his flock the house of Judah, and will make them as his majestic horse in the battle.

**10:4** Out of them shall come forth the corner-stone, out of them the stake, out of them the battle bow, out of them every master together.

**10:5** And they shall be as mighty men, treading down in the mire of the streets in the battle; and they shall fight, because YHWH is with them; and the riders on horses shall be confounded.

**10:6** And I will strengthen the house of Judah, and I will save the house of Joseph, and I will bring them back, for I have compassion upon them; and they shall be as though I had not cast them off; for I am YHWH their God, and I will hear them.

**10:7** And they of Ephraim shall be like a mighty man, and their heart shall rejoice as through wine; yea, their children shall see it, and rejoice; their heart shall be glad in YHWH.

**10:8** I will hiss for them, and gather them, for I have redeemed them; and they shall increase as they have increased.

**10:9** And I will sow them among the peoples, and they shall remember me in far countries; and they shall live with their children, and shall return.

**10:10** I will bring them back also out of the land of Egypt, and gather them out of Assyria; and I will bring them into the land of Gilead and Lebanon; and place shall not suffice them.

**10:11** And over the sea affliction shall pass, and the waves shall be smitten in the sea, and all the depths of the Nile shall dry up; and the pride of Assyria shall be brought down, and the sceptre of Egypt shall depart away.

**10:12** And I will strengthen them in YHWH; and they shall walk in his name, says YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Ask YHWH, Not Idols (10:1-2):**
**The Key Verses (10:1-2):**
"''Ask of YHWH rain in the time of the latter rain.''"

*Sha'alu me-YHWH matar be-et malqosh*—ask rain.

"''YHWH that makes lightnings.''"

*YHWH oseh chazizim*—makes lightnings.

"''He will give them showers of rain.''"

*U-mtar geshem yitten lahem*—showers.

"''To every one grass in the field.''"

*Le-ish esev ba-sadeh*—grass.

"''The teraphim have spoken vanity.''"

*Ki ha-terafim dibberu-aven*—teraphim vanity.

**Teraphim:**
Household idols.

"''The diviners have seen a lie.''"

*Ve-ha-qosemim chazu sheqer*—false visions.

"''The dreams speak falsely, they comfort in vain.''"

*Va-chalomot ha-shav yedabberu hevel yenachamun*—false comfort.

"''They go their way like sheep, they are afflicted, because there is no shepherd.''"

*Al-ken nas'u kemo-tzon ya'anu ki-ein ro'eh*—no shepherd.

**YHWH's Anger and Restoration (10:3-12):**
**The Key Verses (10:3-5):**
"''My anger is kindled against the shepherds.''"

*Al-ha-ro'im charah appi*—anger at shepherds.

"''I will punish the he-goats.''"

*Ve-al-ha-attudim efqod*—punish he-goats.

"''YHWH of hosts has remembered his flock the house of Judah.''"

*Ki-faqad YHWH tzeva'ot et-edרו et-beit Yehudah*—remembered.

"''Will make them as his majestic horse in the battle.''"

*Ve-sam otam ke-sus hodo ba-milchamah*—majestic horse.

"''Out of them shall come forth the corner-stone.''"

*Mimmennו pinnah*—cornerstone.

"''Out of them the stake.''"

*Mimmennו yated*—stake.

"''Out of them the battle bow.''"

*Mimmennו qeshet milchamah*—battle bow.

"''Out of them every master together.''"

*Mimmennו yetze khol-noges yachdav*—every leader.

"''They shall be as mighty men.''"

*Ve-hayu ke-gibborim*—mighty men.

"''Treading down in the mire of the streets in the battle.''"

*Bosim be-tit chutzot ba-milchamah*—treading.

"''They shall fight, because YHWH is with them.''"

*Ve-nilchamu ki YHWH immam*—YHWH with them.

"''The riders on horses shall be confounded.''"

*Ve-hovishu rokhevei susim*—confounded.

**The Key Verses (10:6-9):**
"''I will strengthen the house of Judah.''"

*Ve-gibbartי et-beit Yehudah*—strengthen Judah.

"''I will save the house of Joseph.''"

*Ve-et-beit Yosef oshi'a*—save Joseph.

"''I will bring them back, for I have compassion upon them.''"

*Ve-hoshevotim ki richamtim*—bring back.

"''They shall be as though I had not cast them off.''"

*Ve-hayu ka-asher lo-zenahhtim*—as if not cast off.

"''I am YHWH their God, and I will hear them.''"

*Ki ani YHWH Eloheihem ve-e'enem*—hear.

"''They of Ephraim shall be like a mighty man.''"

*Ve-hayu ke-gibbor Efrayim*—Ephraim mighty.

"''Their heart shall rejoice as through wine.''"

*Ve-samach libbam kemo-yayin*—rejoice.

"''Their children shall see it, and rejoice.''"

*Ve-veneihem yir'u ve-samechu*—children rejoice.

"''Their heart shall be glad in YHWH.''"

*Yagel libbam ba-YHWH*—glad in YHWH.

"''I will hiss for them, and gather them.''"

*Eshreqah lahem va-aqabbetzem*—hiss, gather.

"''I have redeemed them.''"

*Ki feditim*—redeemed.

"''They shall increase as they have increased.''"

*Ve-ravu kemo ravu*—increase.

"''I will sow them among the peoples.''"

*Va-ezra'em ba-ammim*—sow.

"''They shall remember me in far countries.''"

*U-va-merchaqim yizkeruni*—remember.

"''They shall live with their children, and shall return.''"

*Ve-chayu et-beneihem va-shavu*—return.

**The Key Verses (10:10-12):**
"''I will bring them back also out of the land of Egypt.''"

*Va-hashivotim me-eretz Mitzrayim*—from Egypt.

"''Gather them out of Assyria.''"

*U-me-Ashur aqabbetzem*—from Assyria.

"''I will bring them into the land of Gilead and Lebanon.''"

*Ve-el-eretz Gil'ad u-Levanon avi'em*—Gilead, Lebanon.

"''Place shall not suffice them.''"

*Ve-lo yimmatze lahem*—not enough room.

"''Over the sea affliction shall pass.''"

*Ve-avar ba-yam tzarah*—sea affliction.

"''The waves shall be smitten in the sea.''"

*Ve-hikkah va-yam gallim*—waves smitten.

"''All the depths of the Nile shall dry up.''"

*Ve-hovishu kol metzulot ye'or*—Nile dries.

"''The pride of Assyria shall be brought down.''"

*Ve-hurad ge'on Ashur*—Assyria's pride.

"''The sceptre of Egypt shall depart away.''"

*Ve-shevet Mitzrayim yasur*—Egypt's scepter.

"''I will strengthen them in YHWH.''"

*Ve-gibbartim ba-YHWH*—strengthen.

"''They shall walk in his name.''"

*U-vi-shemo yithalakhu*—walk in name.

**Archetypal Layer:** Zechariah 10 contains **"Ask of YHWH rain in the time of the latter rain" (10:1)**, **"the teraphim have spoken vanity, and the diviners have seen a lie" (10:2)**, **"they are afflicted, because there is no shepherd" (10:2)**, **"My anger is kindled against the shepherds" (10:3)**, **"YHWH of hosts has remembered his flock" (10:3)**, **"Out of them shall come forth the corner-stone, out of them the stake, out of them the battle bow" (10:4)**, **"I will strengthen the house of Judah, and I will save the house of Joseph" (10:6)**, **"they shall be as though I had not cast them off" (10:6)**, **"I will hiss for them, and gather them, for I have redeemed them" (10:8)**, **"I will sow them among the peoples, and they shall remember me in far countries" (10:9)**, **new Exodus imagery: "over the sea affliction shall pass... the depths of the Nile shall dry up" (10:11)**, and **"I will strengthen them in YHWH; and they shall walk in his name" (10:12)**.

**Ethical Inversion Applied:**
- "''Ask of YHWH rain in the time of the latter rain''"—ask YHWH
- "''YHWH that makes lightnings''"—makes lightnings
- "''He will give them showers of rain''"—showers
- "''The teraphim have spoken vanity''"—teraphim vanity
- "''The diviners have seen a lie''"—false
- "''The dreams speak falsely''"—false dreams
- "''They are afflicted, because there is no shepherd''"—no shepherd
- "''My anger is kindled against the shepherds''"—anger at shepherds
- "''I will punish the he-goats''"—punish
- "''YHWH of hosts has remembered his flock''"—remembered
- "''Will make them as his majestic horse''"—majestic
- "''Out of them shall come forth the corner-stone''"—cornerstone
- "''Out of them the stake''"—stake
- "''Out of them the battle bow''"—bow
- "''They shall be as mighty men''"—mighty
- "''They shall fight, because YHWH is with them''"—YHWH with
- "''I will strengthen the house of Judah''"—strengthen
- "''I will save the house of Joseph''"—save
- "''I will bring them back''"—bring back
- "''They shall be as though I had not cast them off''"—as if not cast off
- "''I am YHWH their God, and I will hear them''"—hear
- "''They of Ephraim shall be like a mighty man''"—mighty
- "''Their heart shall rejoice''"—rejoice
- "''I will hiss for them, and gather them''"—gather
- "''I have redeemed them''"—redeemed
- "''They shall increase''"—increase
- "''I will sow them among the peoples''"—sow
- "''They shall remember me in far countries''"—remember
- "''They shall live with their children, and shall return''"—return
- "''I will bring them back... out of Egypt''"—from Egypt
- "''Gather them out of Assyria''"—from Assyria
- "''Place shall not suffice them''"—not enough room
- "''Over the sea affliction shall pass''"—sea
- "''The depths of the Nile shall dry up''"—Nile dries
- "''The pride of Assyria shall be brought down''"—Assyria down
- "''The sceptre of Egypt shall depart away''"—Egypt's scepter
- "''I will strengthen them in YHWH''"—strengthen
- "''They shall walk in his name''"—walk in name

**Modern Equivalent:** Zechariah 10 contrasts YHWH (source of rain and blessing) with false teraphim and diviners (10:1-2). The problem: no shepherd (10:2). The solution: YHWH remembers His flock (10:3). From Judah comes cornerstone, stake, and bow (10:4). Both Judah and Joseph (Ephraim) will be saved and restored (10:6-7). New Exodus imagery (10:11) shows YHWH parting the sea again. "They shall walk in his name" (10:12) concludes with confident faith.

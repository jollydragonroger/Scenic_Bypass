# Zechariah 8: Promises of Restoration

*From the Hebrew: וַיְהִי דְּבַר־יְהוָה צְבָאוֹת (Va-Yehi Devar-YHWH Tzeva'ot) — And the Word of YHWH of Hosts Came*

---

## Ten Oracles of Restoration (8:1-23)

**8:1** And the word of YHWH of hosts came, saying:

**8:2** "Thus says YHWH of hosts: I am jealous for Zion with great jealousy, and I am jealous for her with great fury."

**8:3** Thus says YHWH: "I return unto Zion, and will dwell in the midst of Jerusalem; and Jerusalem shall be called the city of truth; and the mountain of YHWH of hosts the holy mountain."

**8:4** Thus says YHWH of hosts: "There shall yet old men and old women sit in the broad places of Jerusalem, every man with his staff in his hand for very age.

**8:5** "And the broad places of the city shall be full of boys and girls playing in the broad places thereof."

**8:6** Thus says YHWH of hosts: "If it be marvellous in the eyes of the remnant of this people in those days, should it also be marvellous in my eyes?" says YHWH of hosts.

**8:7** Thus says YHWH of hosts: "Behold, I will save my people from the east country, and from the west country;

**8:8** "And I will bring them, and they shall dwell in the midst of Jerusalem; and they shall be my people, and I will be their God, in truth and in righteousness."

**8:9** Thus says YHWH of hosts: "Let your hands be strong, you that hear in these days these words from the mouth of the prophets that were in the day that the foundation of the house of YHWH of hosts was laid, even the temple, that it might be built.

**8:10** "For before those days there was no hire for man, nor any hire for beast; neither was there any peace to him that went out or came in because of the adversary; for I set all men every one against his neighbour.

**8:11** "But now I will not be unto the remnant of this people as in the former days," says YHWH of hosts.

**8:12** "For as the seed of peace, the vine shall give her fruit, and the ground shall give her increase, and the heavens shall give their dew; and I will cause the remnant of this people to inherit all these things.

**8:13** "And it shall come to pass that, as you were a curse among the nations, O house of Judah and house of Israel, so will I save you, and you shall be a blessing. Fear not, but let your hands be strong."

**8:14** For thus says YHWH of hosts: "As I purposed to do evil unto you, when your fathers provoked me," says YHWH of hosts, "and I repented not;

**8:15** "So again have I purposed in these days to do good unto Jerusalem and to the house of Judah; fear not.

**8:16** "These are the things that you shall do: Speak truth every man with his neighbour; execute the judgment of truth and peace in your gates;

**8:17** "And let none of you devise evil in your hearts against his neighbour; and love no false oath; for all these are things that I hate," says YHWH.

**8:18** And the word of YHWH of hosts came unto me, saying:

**8:19** "Thus says YHWH of hosts: The fast of the fourth month, and the fast of the fifth, and the fast of the seventh, and the fast of the tenth, shall be to the house of Judah joy and gladness, and cheerful seasons; therefore love truth and peace."

**8:20** Thus says YHWH of hosts: "It shall yet come to pass, that there shall come peoples, and the inhabitants of many cities;

**8:21** "And the inhabitants of one city shall go to another, saying: 'Let us go speedily to entreat the favour of YHWH, and to seek YHWH of hosts; I will go also.'

**8:22** "Yea, many peoples and mighty nations shall come to seek YHWH of hosts in Jerusalem, and to entreat the favour of YHWH."

**8:23** Thus says YHWH of hosts: "In those days it shall come to pass, that ten men shall take hold, out of all the languages of the nations, shall even take hold of the skirt of him that is a Jew, saying: 'We will go with you, for we have heard that God is with you.'"

---

## Synthesis Notes

**Key Restorations:**

**Ten Oracles (8:1-23):**
**The Key Verses (8:1-3):**
"''I am jealous for Zion with great jealousy.''"

*Qinneiti le-Tziyon qin'ah gedolah*—jealous.

"''I am jealous for her with great fury.''"

*Ve-chemah gedolah qinneiti lah*—fury.

"''I return unto Zion, and will dwell in the midst of Jerusalem.''"

*Shavti el-Tziyon ve-shakhantiב be-tokh Yerushalayim*—return, dwell.

"''Jerusalem shall be called the city of truth.''"

*Ve-niqre'ah Yerushalayim ir-ha-emet*—city of truth.

"''The mountain of YHWH of hosts the holy mountain.''"

*Ve-har-YHWH tzeva'ot har ha-qodesh*—holy mountain.

**The Key Verses (8:4-5):**
"''There shall yet old men and old women sit in the broad places of Jerusalem.''"

*Od yeshvu zeqenim u-zeqenot bi-rechovot Yerushalayim*—elderly.

"''Every man with his staff in his hand for very age.''"

*Ve-ish mish'aneto be-yado me-rov yamim*—aged.

"''The broad places of the city shall be full of boys and girls playing.''"

*U-rechovot ha-ir yimale'u yeladim vi-yeladot mesachaqim bi-rechovoteiha*—children playing.

**The Key Verses (8:6-8):**
"''If it be marvellous in the eyes of the remnant of this people... should it also be marvellous in my eyes?''"

*Ki yippale be-einei she'erit ha-am ha-zeh ba-yamim ha-hem gam-be-einai yippale*—marvellous?

"''I will save my people from the east country, and from the west country.''"

*Hineni moshia et-ammi me-eretz mizrach u-me-eretz mevo ha-shemesh*—save from east and west.

"''They shall be my people, and I will be their God.''"

*Ve-hayu li le-am va-ani ehyeh lahem le-Elohim*—covenant formula.

"''In truth and in righteousness.''"

*Be-emet u-vi-tzdaqah*—truth, righteousness.

**The Key Verses (8:9-13):**
"''Let your hands be strong.''"

*Techezaqnah yedeikhem*—be strong.

"''Before those days there was no hire for man, nor any hire for beast.''"

*Ki lifnei ha-yamim ha-hem sekhar ha-adam lo hayah u-sekhar ha-behemah einennah*—no wages.

"''Neither was there any peace... because of the adversary.''"

*Ve-la-yotze ve-la-ba ein shalom min-ha-tzar*—no peace.

"''I set all men every one against his neighbour.''"

*Va-ashalach et-kol-ha-adam ish be-re'ehu*—against neighbor.

"''Now I will not be unto the remnant... as in the former days.''"

*Ve-attah lo kha-yamim ha-rishonim ani li-she'erit ha-am ha-zeh*—not like before.

"''The vine shall give her fruit, and the ground shall give her increase.''"

*Ki-zera ha-shalom ha-gefen titten piryah ve-ha-aretz titten et-yevulah*—fertility.

"''As you were a curse among the nations... so will I save you, and you shall be a blessing.''"

*Ka-asher heyitem qelalah ba-goyim... ken oshia etkhem vi-heyitem berakhah*—curse to blessing.

"''Fear not, but let your hands be strong.''"

*Al-tire'u techezaqnah yedeikhem*—fear not.

**The Key Verses (8:14-17):**
"''As I purposed to do evil unto you... and I repented not.''"

*Ka-asher zamam ti le-hara lakhemו... ve-lo nichamti*—purposed evil.

"''So again have I purposed in these days to do good.''"

*Ken shavti zamam ti ba-yamim ha-elleh le-heitiv*—purposed good.

"''Speak truth every man with his neighbour.''"

*Dabberu emet ish et-re'ehu*—speak truth.

"''Execute the judgment of truth and peace in your gates.''"

*Emet u-mishpat shalom shiftu be-sha'areikhem*—justice, peace.

"''Let none of you devise evil in your hearts against his neighbour.''"

*Ve-ish et-ra'at re'ehu al-tachshevu bi-levavekhem*—no evil.

"''Love no false oath.''"

*U-shevu'at sheqer al-te'ahavu*—no false oath.

"''All these are things that I hate.''"

*Ki et-kol-elleh asher saneiti*—I hate.

**The Key Verses (8:18-19):**
"''The fast of the fourth month, and the fast of the fifth, and the fast of the seventh, and the fast of the tenth.''"

*Tzom ha-revi'i ve-tzom ha-chamishi ve-tzom ha-shevi'i ve-tzom ha-asiri*—four fasts.

"''Shall be to the house of Judah joy and gladness, and cheerful seasons.''"

*Yihyeh le-veit-Yehudah le-sason u-le-simchah u-le-mo'adim tovim*—joy.

"''Therefore love truth and peace.''"

*Ve-ha-emet ve-ha-shalom ehavu*—love truth, peace.

**The Key Verses (8:20-23):**
"''There shall come peoples, and the inhabitants of many cities.''"

*Od asher yavo'u ammim ve-yoshevei arim rabbot*—peoples come.

"''Let us go speedily to entreat the favour of YHWH.''"

*Nelkhah halokh le-challot et-penei YHWH*—entreat YHWH.

"''I will go also.''"

*Elkhah gam-ani*—I'll go too.

"''Many peoples and mighty nations shall come to seek YHWH of hosts in Jerusalem.''"

*U-va'u ammim rabbim ve-goyim atzumim le-vaqqesh et-YHWH tzeva'ot bi-Yrushalayim*—nations seek.

"''Ten men shall take hold... of the skirt of him that is a Jew.''"

*Yachazיqu asarah anashim mi-kol leshonot ha-goyim... bi-khenaf ish Yehudi*—ten men.

"''We will go with you, for we have heard that God is with you.''"

*Nelkhah immakhem ki shama'nu Elohim immakhem*—God with you.

**Archetypal Layer:** Zechariah 8 contains **"I am jealous for Zion with great jealousy" (8:2)**, **"Jerusalem shall be called the city of truth" (8:3)**, **"old men and old women sit in the broad places... boys and girls playing" (8:4-5)**—image of peaceful prosperity, **"If it be marvellous in the eyes of the remnant... should it also be marvellous in my eyes?" (8:6)**, **"I will save my people from the east country, and from the west country" (8:7)**, **"they shall be my people, and I will be their God" (8:8)**, **"Let your hands be strong" (8:9, 13)**, **"as you were a curse among the nations... so will I save you, and you shall be a blessing" (8:13)**, **"Speak truth every man with his neighbour; execute the judgment of truth and peace" (8:16)**, **fasts becoming "joy and gladness, and cheerful seasons" (8:19)**, and **"ten men... shall take hold of the skirt of him that is a Jew, saying: We will go with you, for we have heard that God is with you" (8:23)**.

**Ethical Inversion Applied:**
- "''I am jealous for Zion with great jealousy''"—jealous
- "''I return unto Zion, and will dwell in the midst of Jerusalem''"—return
- "''Jerusalem shall be called the city of truth''"—truth
- "''The mountain of YHWH of hosts the holy mountain''"—holy
- "''Old men and old women sit in the broad places''"—elderly
- "''The broad places... full of boys and girls playing''"—children
- "''If it be marvellous... should it also be marvellous in my eyes?''"—not hard for God
- "''I will save my people from the east... and from the west''"—save
- "''They shall be my people, and I will be their God''"—covenant
- "''In truth and in righteousness''"—truth
- "''Let your hands be strong''"—be strong
- "''Before those days there was no hire for man''"—no wages
- "''Neither was there any peace''"—no peace
- "''Now I will not be... as in the former days''"—new era
- "''The vine shall give her fruit''"—fertility
- "''As you were a curse... so will I save you, and you shall be a blessing''"—blessing
- "''Fear not''"—fear not
- "''As I purposed to do evil... and I repented not''"—purposed evil
- "''So again have I purposed... to do good''"—purposed good
- "''Speak truth every man with his neighbour''"—speak truth
- "''Execute the judgment of truth and peace''"—justice
- "''Let none of you devise evil''"—no evil
- "''Love no false oath''"—no false oath
- "''The fast of the fourth... fifth... seventh... tenth''"—four fasts
- "''Shall be... joy and gladness''"—joy
- "''Love truth and peace''"—love truth, peace
- "''There shall come peoples, and the inhabitants of many cities''"—peoples come
- "''Let us go speedily to entreat the favour of YHWH''"—go
- "''Many peoples and mighty nations shall come to seek YHWH''"—nations seek
- "''Ten men shall take hold... of the skirt of him that is a Jew''"—ten men
- "''We will go with you, for we have heard that God is with you''"—God with you

**Modern Equivalent:** Zechariah 8 is overwhelmingly positive—ten oracles of blessing. The vision of elderly and children in Jerusalem's streets (8:4-5) depicts security and prosperity. "As you were a curse... so will I save you, and you shall be a blessing" (8:13) echoes Abraham's call. The fasts become festivals (8:19). The chapter climaxes with Gentiles seeking YHWH through Jews: "ten men... shall take hold of the skirt of him that is a Jew, saying: We will go with you, for we have heard that God is with you" (8:23).

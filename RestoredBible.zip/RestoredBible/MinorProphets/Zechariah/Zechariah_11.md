# Zechariah 11: The Shepherd and the Flock

*From the Hebrew: פְּתַח לְבָנוֹן דְּלָתֶיךָ (Petach Levanon Delatekha) — Open Your Doors, O Lebanon*

---

## The Doom of the Land (11:1-3)

**11:1** Open your doors, O Lebanon, that the fire may devour your cedars.

**11:2** Wail, O cypress-tree, for the cedar is fallen; because the glorious ones are spoiled; wail, O ye oaks of Bashan, for the strong forest is come down.

**11:3** The sound of the wailing of the shepherds, for their glory is spoiled; the sound of the roaring of young lions, for the pride of the Jordan is laid waste.

---

## The Two Shepherds (11:4-17)

**11:4** Thus said YHWH my God: "Feed the flock of slaughter;

**11:5** "Whose buyers slay them, and hold themselves not guilty; and they that sell them say: 'Blessed be YHWH, for I am rich'; and their own shepherds pity them not.

**11:6** "For I will no more pity the inhabitants of the land," says YHWH; "but, lo, I will deliver the men every one into his neighbour's hand, and into the hand of his king; and they shall smite the land, and out of their hand I will not deliver them."

**11:7** So I fed the flock of slaughter, verily the poor of the flock. And I took unto me two staves; the one I called Graciousness, and the other I called Binders; and I fed the flock.

**11:8** And I cut off the three shepherds in one month; for my soul became impatient of them, and their soul also loathed me.

**11:9** Then said I: "I will not feed you; that which dies, let it die; and that which is to be cut off, let it be cut off; and let them that are left eat every one the flesh of another."

**11:10** And I took my staff Graciousness, and cut it asunder, that I might break my covenant which I had made with all the peoples.

**11:11** And it was broken in that day; and the poor of the flock that gave heed unto me knew thereby that it was the word of YHWH.

**11:12** And I said unto them: "If you think good, give me my hire; and if not, forbear." So they weighed for my hire thirty pieces of silver.

**11:13** And YHWH said unto me: "Cast it unto the potter, the goodly price that I was prized at of them." And I took the thirty pieces of silver, and cast them unto the potter, in the house of YHWH.

**11:14** Then I cut asunder my other staff, even Binders, that I might break the brotherhood between Judah and Israel.

**11:15** And YHWH said unto me: "Take unto you yet the instruments of a foolish shepherd.

**11:16** "For, lo, I will raise up a shepherd in the land, who will not remember those that are cut off, neither will seek those that are scattered, nor heal that which is broken; nor will he feed that which stands still, but he will eat the flesh of the fat, and will break their hoofs in pieces."

**11:17** Woe to the worthless shepherd that leaves the flock! The sword shall be upon his arm, and upon his right eye; his arm shall be clean dried up, and his right eye shall be utterly darkened.

---

## Synthesis Notes

**Key Restorations:**

**Doom of the Land (11:1-3):**
**The Key Verses (11:1-3):**
"''Open your doors, O Lebanon, that the fire may devour your cedars.''"

*Petach Levanon delatekha ve-tokhal esh ba-arazekha*—open, fire.

"''Wail, O cypress-tree, for the cedar is fallen.''"

*Heilel berosh ki-nafal erez*—wail.

"''Because the glorious ones are spoiled.''"

*Ki shuddedו addirim*—spoiled.

"''Wail, O ye oaks of Bashan.''"

*Heililu allonei Vashan*—oaks wail.

"''For the strong forest is come down.''"

*Ki yarad ya'ar ha-batzur*—forest down.

"''The sound of the wailing of the shepherds.''"

*Qol yelelat ha-ro'im*—shepherds wail.

"''For their glory is spoiled.''"

*Ki shuddah adartam*—glory spoiled.

"''The sound of the roaring of young lions.''"

*Qol sha'agat kefirim*—lions roar.

"''For the pride of the Jordan is laid waste.''"

*Ki shuddad ge'on ha-Yarden*—Jordan's pride.

**Two Shepherds (11:4-17):**
**The Key Verses (11:4-7):**
"''Feed the flock of slaughter.''"

*Re'eh et-tzon ha-haregah*—flock of slaughter.

"''Whose buyers slay them, and hold themselves not guilty.''"

*Asher qoneihen yahargun ve-lo ye'shamu*—buyers slay.

"''They that sell them say: Blessed be YHWH, for I am rich.''"

*U-mokhereיhen yomar barukh YHWH va-ashir*—sellers blessed.

"''Their own shepherds pity them not.''"

*Ve-ro'eihem lo yachmol aleihem*—no pity.

"''I will no more pity the inhabitants of the land.''"

*Ki lo-echmol od al-yoshevei ha-aretz*—no pity.

"''I will deliver the men every one into his neighbour's hand.''"

*Ve-hinneh anokhi mamtzi et-ha-adam ish be-yad re'ehu*—deliver to neighbor.

"''Into the hand of his king.''"

*U-ve-yad malkhu*—to king.

"'I fed the flock of slaughter, verily the poor of the flock.'"

*Va-er'eh et-tzon ha-haregah lakhen aniyyei ha-tzon*—fed poor.

"'I took unto me two staves.'"

*Va-eqqach-li shenei maqlot*—two staves.

"'The one I called Graciousness.'"

*Le-echad qarati No'am*—Graciousness.

**No'am:**
"Graciousness" / "Favor" / "Beauty."

"'The other I called Binders.'"

*U-le-echad qarati Chovlim*—Binders.

**Chovlim:**
"Binders" / "Union."

**The Key Verses (11:8-11):**
"'I cut off the three shepherds in one month.'"

*Va-akhchid et-sheloshet ha-ro'im be-yerach echad*—three shepherds.

"'My soul became impatient of them, and their soul also loathed me.'"

*Va-tiqtzar nafshi bahem ve-gam nafsham ba'alah bi*—mutual loathing.

"''I will not feed you.''"

*Lo er'eh etkhem*—won't feed.

"''That which dies, let it die.''"

*Ha-metah tamut*—let die.

"''That which is to be cut off, let it be cut off.''"

*Ve-ha-nikhchedet tikkaחed*—cut off.

"''Let them that are left eat every one the flesh of another.''"

*Ve-ha-nish'arot tokhalנah ishah et-besar re'utah*—cannibalism.

"'I took my staff Graciousness, and cut it asunder.'"

*Va-eqqach et-maqli et-No'am va-egda oto*—broke Graciousness.

"'That I might break my covenant which I had made with all the peoples.'"

*Le-hafer et-beriti asher karati et-kol-ha-ammim*—break covenant.

"'The poor of the flock... knew thereby that it was the word of YHWH.'"

*Va-yede'u... ki devar-YHWH hu*—knew it was YHWH.

**The Key Verses (11:12-14):**
"''If you think good, give me my hire; and if not, forbear.''"

*Im-tov be-eineikhem havu sekhari ve-im-lo chadalu*—give hire.

"'They weighed for my hire thirty pieces of silver.'"

*Va-yishqelu et-sekhari sheloshim kasef*—thirty silver.

**Thirty Pieces of Silver:**
The price of a slave (Exodus 21:32); quoted in Matthew 27:9-10.

"''Cast it unto the potter, the goodly price that I was prized at of them.''"

*Hashlikhehu el-ha-yotzer adder ha-yeqar asher yaqarti me-aleihem*—to potter.

"'I took the thirty pieces of silver, and cast them unto the potter, in the house of YHWH.'"

*Va-eqqach sheloshim ha-kesef va-ashlikه oto beit YHWH el-ha-yotzer*—cast in temple.

"'I cut asunder my other staff, even Binders.'"

*Va-egda et-maqli ha-sheni et Chovlim*—broke Binders.

"'That I might break the brotherhood between Judah and Israel.'"

*Le-hafer et-ha-achavah bein Yehudah u-vein Yisra'el*—break brotherhood.

**The Key Verses (11:15-17):**
"''Take unto you yet the instruments of a foolish shepherd.''"

*Od qach-lekha keli ro'eh evili*—foolish shepherd.

"''I will raise up a shepherd in the land.''"

*Ki hinneni meqim ro'eh ba-aretz*—raise shepherd.

"''Who will not remember those that are cut off.''"

*Ha-nikhchadot lo-yifqod*—not remember.

"''Neither will seek those that are scattered.''"

*Ha-na'ar lo yevaqqesh*—not seek.

"''Nor heal that which is broken.''"

*Ve-ha-nishberot lo yerappe*—not heal.

"''He will eat the flesh of the fat.''"

*U-vesar ha-beri'ah yokhal*—eat fat.

"''Will break their hoofs in pieces.''"

*U-farseihen yefareq*—break hoofs.

"''Woe to the worthless shepherd that leaves the flock!''"

*Hoy ro'י ha-elil ozevi ha-tzon*—worthless shepherd.

"''The sword shall be upon his arm, and upon his right eye.''"

*Cherev al-zero'ו ve-al-ein yemino*—sword on arm, eye.

"''His arm shall be clean dried up.''"

*Zero'o yavosh tivash*—arm dried.

"''His right eye shall be utterly darkened.''"

*Ve-ein yemino kahhoh tikheh*—eye darkened.

**Archetypal Layer:** Zechariah 11 contains **"Open your doors, O Lebanon, that the fire may devour your cedars" (11:1)**, **"Feed the flock of slaughter" (11:4)**, **buyers slaying and sellers blessing YHWH while getting rich (11:5)**, **two staves: Graciousness (No'am) and Binders (Chovlim) (11:7)**, **"I cut off the three shepherds in one month" (11:8)**, **breaking the staff Graciousness to break the covenant (11:10)**, **"they weighed for my hire thirty pieces of silver" (11:12)**—quoted in Matthew 27:9-10, **"Cast it unto the potter" (11:13)**, **breaking the staff Binders to break brotherhood between Judah and Israel (11:14)**, **the foolish shepherd who doesn't care for the flock (11:15-16)**, and **"Woe to the worthless shepherd that leaves the flock!" (11:17)**.

**Ethical Inversion Applied:**
- "''Open your doors, O Lebanon''"—open
- "''That the fire may devour your cedars''"—fire
- "''Wail, O cypress-tree, for the cedar is fallen''"—wail
- "''The sound of the wailing of the shepherds''"—wailing
- "''For the pride of the Jordan is laid waste''"—laid waste
- "''Feed the flock of slaughter''"—flock of slaughter
- "''Whose buyers slay them, and hold themselves not guilty''"—slay
- "''They that sell them say: Blessed be YHWH, for I am rich''"—sellers rich
- "''Their own shepherds pity them not''"—no pity
- "''I will no more pity the inhabitants of the land''"—no pity
- "'I took unto me two staves'"—two staves
- "'The one I called Graciousness'"—Graciousness
- "'The other I called Binders'"—Binders
- "'I cut off the three shepherds in one month'"—three shepherds
- "''I will not feed you''"—won't feed
- "''That which dies, let it die''"—let die
- "'I took my staff Graciousness, and cut it asunder'"—broke
- "'That I might break my covenant'"—break covenant
- "'They weighed for my hire thirty pieces of silver'"—thirty silver
- "''Cast it unto the potter''"—to potter
- "'I cast them unto the potter, in the house of YHWH'"—cast
- "'I cut asunder my other staff'"—broke
- "'That I might break the brotherhood'"—break brotherhood
- "''Take unto you... the instruments of a foolish shepherd''"—foolish
- "''I will raise up a shepherd in the land''"—raise shepherd
- "''Who will not remember those that are cut off''"—not remember
- "''Neither will seek those that are scattered''"—not seek
- "''Nor heal that which is broken''"—not heal
- "''He will eat the flesh of the fat''"—eat
- "''Woe to the worthless shepherd''"—worthless
- "''The sword shall be upon his arm, and upon his right eye''"—sword
- "''His arm shall be clean dried up''"—dried
- "''His right eye shall be utterly darkened''"—darkened

**Modern Equivalent:** Zechariah 11 is a dark prophetic drama. The good shepherd feeds the flock of slaughter with two staves—Graciousness and Binders. He breaks both, symbolizing broken covenant and brotherhood. "Thirty pieces of silver" (11:12-13) is quoted in Matthew 27:9-10 regarding Judas's betrayal. The foolish/worthless shepherd (11:15-17) who exploits the flock contrasts with the good shepherd. This chapter anticipates rejection of the true shepherd.

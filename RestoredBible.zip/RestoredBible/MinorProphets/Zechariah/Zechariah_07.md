# Zechariah 7: The Question of Fasting

*From the Hebrew: וַיְהִי בִּשְׁנַת אַרְבַּע לְדָרְיָוֶשׁ הַמֶּלֶךְ (Va-Yehi Bi-Shenat Arba Le-Daryavesh Ha-Melekh) — And It Came to Pass in the Fourth Year of King Darius*

---

## The Delegation's Question (7:1-3)

**7:1** And it came to pass in the fourth year of king Darius, that the word of YHWH came unto Zechariah in the fourth day of the ninth month, even in Chislev;

**7:2** When Bethel-sarezer and Regem-melech and their men had sent to entreat the favour of YHWH,

**7:3** And to speak unto the priests of the house of YHWH of hosts, and to the prophets, saying: "Should I weep in the fifth month, separating myself, as I have done these so many years?"

---

## YHWH's Response (7:4-14)

**7:4** Then came the word of YHWH of hosts unto me, saying:

**7:5** "Speak unto all the people of the land, and to the priests, saying: When you fasted and mourned in the fifth and in the seventh month, even these seventy years, did you at all fast unto me, even to me?

**7:6** "And when you eat, and when you drink, are you not they that eat, and they that drink?

**7:7** "Should you not hear the words which YHWH proclaimed by the former prophets, when Jerusalem was inhabited and in prosperity, and the cities thereof round about her, and the South and the Lowland were inhabited?"

**7:8** And the word of YHWH came unto Zechariah, saying:

**7:9** "Thus has YHWH of hosts spoken, saying: Execute true justice, and show mercy and compassion every man to his brother;

**7:10** "And oppress not the widow, nor the fatherless, the stranger, nor the poor; and let none of you devise evil against his brother in your heart."

**7:11** But they refused to attend, and turned a stubborn shoulder, and stopped their ears, that they might not hear.

**7:12** Yea, they made their hearts as an adamant stone, lest they should hear the law, and the words which YHWH of hosts had sent by his spirit by the hand of the former prophets; therefore came there great wrath from YHWH of hosts.

**7:13** And it came to pass that, as he called, and they would not hear; so they shall call, and I will not hear, said YHWH of hosts;

**7:14** And I will scatter them with a whirlwind among all the nations whom they have not known. Thus the land was desolate after them, so that no man passed through nor returned; for they laid the pleasant land desolate.

---

## Synthesis Notes

**Key Restorations:**

**Delegation's Question (7:1-3):**
**The Key Verses (7:1-3):**
"'In the fourth year of king Darius... in the fourth day of the ninth month, even in Chislev.'"

*Bi-shenat arba le-Daryavesh ha-melekh... be-arba'ah la-chodesh ha-teshi'i be-Khislev*—December 518 BCE.

"'Bethel-sarezer and Regem-melech and their men had sent to entreat the favour of YHWH.'"

*Va-yishlach Beit-El Sar'etzer ve-Regem-Melekh va-anashav le-challot et-penei YHWH*—delegation.

"''Should I weep in the fifth month, separating myself, as I have done these so many years?''"

*Ha-evkeh ba-chodesh ha-chamishi hinnazer ka-asher asiti zeh kammah shanim*—fifth month fast.

**Fifth Month:**
Commemorating the temple's destruction (586 BCE).

**YHWH's Response (7:4-14):**
**The Key Verses (7:4-7):**
"''Speak unto all the people of the land, and to the priests.''"

*Emor el-kol-am ha-aretz ve-el-ha-kohanim*—speak.

"''When you fasted and mourned in the fifth and in the seventh month.''"

*Ki-tzamtem ve-safod ba-chamishi u-va-shevi'i*—fifth, seventh.

"''Even these seventy years.''"

*Ve-zeh shiv'im shanah*—70 years.

"''Did you at all fast unto me, even to me?''"

*Ha-tzom tzamtuni ani*—unto me?

"''When you eat, and when you drink, are you not they that eat, and they that drink?''"

*Ve-khi tokהelu ve-khi tishtu ha-lo attem ha-okhelim ve-attem ha-shotim*—for yourselves.

"''Should you not hear the words which YHWH proclaimed by the former prophets?''"

*Ha-lo et-ha-devarim asher qara YHWH be-yad ha-nevi'im ha-rishonim*—former prophets.

"''When Jerusalem was inhabited and in prosperity.''"

*Bi-hyot Yerushalayim yoshevet u-sheleva*—prosperity.

**The Key Verses (7:8-10):**
"''Thus has YHWH of hosts spoken.''"

*Koh amar YHWH tzeva'ot*—thus says.

"''Execute true justice.''"

*Mishpat emet shefotu*—true justice.

"''Show mercy and compassion every man to his brother.''"

*Ve-chesed ve-rachamim asu ish et-achiv*—mercy, compassion.

"''Oppress not the widow, nor the fatherless, the stranger, nor the poor.''"

*Ve-almanah ve-yatom ger ve-ani al-ta'ashoqu*—don't oppress.

"''Let none of you devise evil against his brother in your heart.''"

*Ve-ra'at ish achiv al-tachshevu bi-levavekhem*—no evil.

**The Key Verses (7:11-14):**
"'They refused to attend.'"

*Va-yema'anu le-haqshiv*—refused.

"'Turned a stubborn shoulder.'"

*Va-yittenu khatef soreרet*—stubborn shoulder.

"'Stopped their ears, that they might not hear.'"

*Ve-ozneihem hikhbidu mi-shemo'a*—stopped ears.

"'They made their hearts as an adamant stone.'"

*Ve-libbam samu shamir*—adamant heart.

"'Lest they should hear the law, and the words which YHWH of hosts had sent by his spirit.'"

*Mi-shemo'a et-ha-torah ve-et-ha-devarim asher shalach YHWH tzeva'ot be-rucho*—law, words.

"'By the hand of the former prophets.'"

*Be-yad ha-nevi'im ha-rishonim*—former prophets.

"'Therefore came there great wrath from YHWH of hosts.'"

*Va-yehi qetzef gadol me-et YHWH tzeva'ot*—great wrath.

"''As he called, and they would not hear; so they shall call, and I will not hear.''"

*Va-yehi ka-asher qara ve-lo shame'u ken yiqra'u ve-lo eshma*—reciprocal not hearing.

"''I will scatter them with a whirlwind among all the nations.''"

*Va-esa'arem al-kol-ha-goyim asher lo-yeda'um*—scatter.

"'The land was desolate after them.'"

*Ve-ha-aretz nashamah achareihem*—desolate.

"'No man passed through nor returned.'"

*Me-over u-mi-shav*—none passed.

"'They laid the pleasant land desolate.'"

*Va-yasimu eretz-chemdah li-shemamah*—pleasant land desolate.

**Archetypal Layer:** Zechariah 7 contains **the question about fasting in the fifth month (7:3)**, **"When you fasted and mourned... even these seventy years, did you at all fast unto me, even to me?" (7:5)**, **"when you eat, and when you drink, are you not they that eat, and they that drink?" (7:6)**—fasting was for themselves, **"Execute true justice, and show mercy and compassion every man to his brother" (7:9)**, **"oppress not the widow, nor the fatherless, the stranger, nor the poor" (7:10)**, **"they refused to attend, and turned a stubborn shoulder, and stopped their ears" (7:11)**, **"they made their hearts as an adamant stone" (7:12)**, **"as he called, and they would not hear; so they shall call, and I will not hear" (7:13)**, and **"they laid the pleasant land desolate" (7:14)**.

**Ethical Inversion Applied:**
- "'In the fourth year of king Darius'"—dated
- "'Bethel-sarezer and Regem-melech... had sent'"—delegation
- "''Should I weep in the fifth month?''"—fifth month
- "''Separating myself, as I have done these so many years?''"—years of fasting
- "''Speak unto all the people of the land, and to the priests''"—speak
- "''When you fasted and mourned in the fifth and in the seventh month''"—fifth, seventh
- "''Even these seventy years''"—70 years
- "''Did you at all fast unto me, even to me?''"—unto me?
- "''When you eat... are you not they that eat?''"—for yourselves
- "''Should you not hear the words... by the former prophets?''"—former prophets
- "''When Jerusalem was inhabited and in prosperity''"—prosperity
- "''Execute true justice''"—true justice
- "''Show mercy and compassion every man to his brother''"—mercy
- "''Oppress not the widow, nor the fatherless''"—don't oppress
- "''The stranger, nor the poor''"—stranger, poor
- "''Let none of you devise evil against his brother''"—no evil
- "'They refused to attend'"—refused
- "'Turned a stubborn shoulder'"—stubborn
- "'Stopped their ears'"—stopped ears
- "'They made their hearts as an adamant stone'"—adamant
- "'Lest they should hear the law'"—law
- "'Therefore came there great wrath'"—wrath
- "''As he called, and they would not hear''"—wouldn't hear
- "''So they shall call, and I will not hear''"—won't hear
- "''I will scatter them with a whirlwind''"—scatter
- "'The land was desolate after them'"—desolate
- "'No man passed through nor returned'"—none passed
- "'They laid the pleasant land desolate'"—desolate

**Modern Equivalent:** Zechariah 7 addresses a question about continuing fasts commemorating the temple's destruction. YHWH's response reframes the issue: "Did you at all fast unto me?" (7:5). The fasts were self-focused. What YHWH really wanted: true justice, mercy, compassion, and protection of the vulnerable (7:9-10). The former generation refused this message—adamant hearts (7:12)—and experienced exile. The same principles apply now.

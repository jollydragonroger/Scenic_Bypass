# Zechariah 3: The Cleansing of Joshua the High Priest

*From the Hebrew: וַיַּרְאֵנִי אֶת־יְהוֹשֻׁעַ הַכֹּהֵן הַגָּדוֹל (Va-Yar'eni Et-Yehoshua Ha-Kohen Ha-Gadol) — And He Showed Me Joshua the High Priest*

---

## Fourth Vision: Joshua and Satan (3:1-10)

**3:1** And he showed me Joshua the high priest standing before the angel of YHWH, and Satan standing at his right hand to accuse him.

**3:2** And YHWH said unto Satan: "YHWH rebuke you, O Satan, yea, YHWH that has chosen Jerusalem rebuke you; is not this man a brand plucked out of the fire?"

**3:3** Now Joshua was clothed with filthy garments, and stood before the angel.

**3:4** And he answered and spoke unto those that stood before him, saying: "Take the filthy garments from off him." And unto him he said: "Behold, I cause your iniquity to pass from you, and I clothe you with festive robes."

**3:5** And I said: "Let them set a fair mitre upon his head." So they set a fair mitre upon his head, and clothed him with garments; and the angel of YHWH stood by.

**3:6** And the angel of YHWH forewarned Joshua, saying:

**3:7** "Thus says YHWH of hosts: If you will walk in my ways, and if you will keep my charge, then you also shall judge my house, and shall also keep my courts, and I will give you access among these that stand by.

**3:8** "Hear now, O Joshua the high priest, you and your fellows that sit before you; for they are men that are a sign; for, behold, I will bring forth my servant the Branch.

**3:9** "For behold the stone that I have set before Joshua; upon one stone are seven eyes; behold, I will engrave the graving thereof," says YHWH of hosts, "and I will remove the iniquity of that land in one day.

**3:10** "In that day," says YHWH of hosts, "shall you call every man his neighbour under the vine and under the fig-tree."

---

## Synthesis Notes

**Key Restorations:**

**Fourth Vision (3:1-10):**
**The Key Verses (3:1-2):**
"'He showed me Joshua the high priest standing before the angel of YHWH.'"

*Va-yar'eni et-Yehoshua ha-kohen ha-gadol omed lifnei mal'akh YHWH*—Joshua before angel.

"'Satan standing at his right hand to accuse him.'"

*Ve-ha-Satan omed al-yemino le-sitno*—Satan accuses.

**Ha-Satan:**
"The Adversary/Accuser"—with the definite article, a title.

"''YHWH rebuke you, O Satan.''"

*Yig'ar YHWH bekha ha-Satan*—rebuke Satan.

"''YHWH that has chosen Jerusalem rebuke you.''"

*Ve-yig'ar YHWH bekha ha-bocher bi-Yrushalayim*—chosen Jerusalem.

"''Is not this man a brand plucked out of the fire?''"

*Ha-lo zeh ud mutzal me-esh*—brand from fire.

**Ud Mutzal Me-Esh:**
"A brand plucked from the fire"—barely rescued.

**The Key Verses (3:3-5):**
"'Joshua was clothed with filthy garments.'"

*Vi-Yhoshua hayah lavush begadim tzo'im*—filthy garments.

"'Stood before the angel.'"

*Ve-omed lifnei ha-mal'akh*—before angel.

"''Take the filthy garments from off him.''"

*Hasiru ha-begadim ha-tzo'im me-alav*—remove filthy.

"''Behold, I cause your iniquity to pass from you.''"

*Re'eh he'evarti me-alekha avonekha*—iniquity removed.

"''I clothe you with festive robes.''"

*Ve-halbesh otkha machalatzot*—festive robes.

**Machalatzot:**
"Festive robes" / "rich garments."

"'I said: Let them set a fair mitre upon his head.'"

*Va-omar yasimu tzanif tahor al-rosho*—fair mitre.

"'So they set a fair mitre upon his head, and clothed him with garments.'"

*Va-yasimu ha-tzanif ha-tahor al-rosho va-yalbishuhu begadim*—mitre, garments.

"'The angel of YHWH stood by.'"

*U-mal'akh YHWH omed*—angel standing.

**The Key Verses (3:6-7):**
"'The angel of YHWH forewarned Joshua.'"

*Va-ya'ad mal'akh YHWH bi-Yהoshua*—forewarned.

"''If you will walk in my ways.''"

*Im-bi-derakhay telekh*—walk in ways.

"''If you will keep my charge.''"

*Ve-im et-mishmarti tishmor*—keep charge.

"''Then you also shall judge my house.''"

*Ve-gam-attah tadin et-beiti*—judge house.

"''Shall also keep my courts.''"

*Ve-gam tishmor et-chatzeirai*—keep courts.

"''I will give you access among these that stand by.''"

*Ve-natatti lekha mahlekhim bein ha-omedim ha-elleh*—access.

**Mahlekhim:**
"Access" / "free passage"—among the heavenly council.

**The Key Verses (3:8-10):**
"''Hear now, O Joshua the high priest.''"

*Shema-na Yehoshua ha-kohen ha-gadol*—hear.

"''You and your fellows that sit before you.''"

*Attah ve-re'ekha ha-yoshevim lefanekha*—fellows.

"''They are men that are a sign.''"

*Ki-anshei mofet hemmah*—men of sign.

"''Behold, I will bring forth my servant the Branch.''"

*Ki-hineni mevi et-avdi Tzemach*—servant Branch.

**Avdi Tzemach:**
"My servant the Branch"—messianic title (cf. Isaiah 11:1, Jeremiah 23:5, 33:15).

"''Behold the stone that I have set before Joshua.''"

*Ki hinneh ha-even asher natatti lifnei Yehoshua*—stone.

"''Upon one stone are seven eyes.''"

*Al-even achat shiv'ah einayim*—seven eyes.

"''I will engrave the graving thereof.''"

*Hineni mefatte'ach pittuchah*—engrave.

"''I will remove the iniquity of that land in one day.''"

*U-mashti et-avon ha-aretz ha-hi be-yom echad*—one day.

**Be-Yom Echad:**
"In one day"—complete, sudden atonement.

"''In that day... shall you call every man his neighbour under the vine and under the fig-tree.''"

*Ba-yom ha-hu... tiqre'u ish le-re'ehu el-tachat gefen ve-el-tachat te'enah*—vine, fig tree.

**Archetypal Layer:** Zechariah 3 contains **the fourth vision: Joshua before YHWH's angel, Satan accusing (3:1)**, **"YHWH rebuke you, O Satan... is not this man a brand plucked out of the fire?" (3:2)**, **Joshua in filthy garments (3:3)**, **"Take the filthy garments from off him... I cause your iniquity to pass from you, and I clothe you with festive robes" (3:4)**, **"Let them set a fair mitre upon his head" (3:5)**, **conditional promise: "If you will walk in my ways... you shall judge my house" (3:7)**, **"I will give you access among these that stand by" (3:7)**, **"I will bring forth my servant the Branch" (3:8)**, **"the stone... upon one stone are seven eyes" (3:9)**, **"I will remove the iniquity of that land in one day" (3:9)**, and **"shall you call every man his neighbour under the vine and under the fig-tree" (3:10)**.

**Ethical Inversion Applied:**
- "'He showed me Joshua the high priest'"—Joshua
- "'Standing before the angel of YHWH'"—before angel
- "'Satan standing at his right hand to accuse him'"—Satan accuses
- "''YHWH rebuke you, O Satan''"—rebuke
- "''YHWH that has chosen Jerusalem rebuke you''"—chosen Jerusalem
- "''Is not this man a brand plucked out of the fire?''"—brand from fire
- "'Joshua was clothed with filthy garments'"—filthy
- "''Take the filthy garments from off him''"—remove
- "''Behold, I cause your iniquity to pass from you''"—iniquity removed
- "''I clothe you with festive robes''"—festive robes
- "'Let them set a fair mitre upon his head'"—mitre
- "'The angel of YHWH stood by'"—angel present
- "''If you will walk in my ways''"—walk in ways
- "''If you will keep my charge''"—keep charge
- "''You shall judge my house''"—judge
- "''I will give you access among these that stand by''"—access
- "''Hear now, O Joshua the high priest''"—hear
- "''They are men that are a sign''"—sign
- "''I will bring forth my servant the Branch''"—Branch
- "''The stone that I have set before Joshua''"—stone
- "''Upon one stone are seven eyes''"—seven eyes
- "''I will engrave the graving thereof''"—engrave
- "''I will remove the iniquity of that land in one day''"—one day
- "''Shall you call every man his neighbour under the vine and under the fig-tree''"—vine, fig tree

**Modern Equivalent:** Zechariah 3 presents a heavenly courtroom. Joshua the high priest stands accused by Satan, but YHWH rebukes the accuser. Joshua's filthy garments (representing sin) are exchanged for festive robes—a picture of justification. "My servant the Branch" (3:8) is messianic. The stone with seven eyes (3:9) represents divine omniscience. "In one day" (3:9) points to complete atonement. The chapter ends with eschatological peace: everyone under vine and fig tree (3:10).

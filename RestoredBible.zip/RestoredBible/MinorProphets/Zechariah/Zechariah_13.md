# Zechariah 13: The Fountain for Cleansing

*From the Hebrew: בַּיּוֹם הַהוּא יִהְיֶה מָקוֹר נִפְתָּח (Ba-Yom Ha-Hu Yihyeh Maqor Niftach) — In That Day There Shall Be a Fountain Opened*

---

## Cleansing from Sin and Idolatry (13:1-6)

**13:1** In that day there shall be a fountain opened to the house of David and to the inhabitants of Jerusalem, for sin and for uncleanness.

**13:2** And it shall come to pass in that day, says YHWH of hosts, that I will cut off the names of the idols out of the land, and they shall no more be remembered; and also I will cause the prophets and the unclean spirit to pass out of the land.

**13:3** And it shall come to pass that, when any shall yet prophesy, then his father and his mother that begot him shall say unto him: "You shall not live, for you speak lies in the name of YHWH"; and his father and his mother that begot him shall thrust him through when he prophesies.

**13:4** And it shall come to pass in that day, that the prophets shall be ashamed every one of his vision, when he prophesies; neither shall they wear a hairy mantle to deceive;

**13:5** But he shall say: "I am no prophet, I am a tiller of the ground; for a man taught me to keep cattle from my youth."

**13:6** And one shall say unto him: "What are these wounds between your hands?" Then he shall answer: "Those with which I was wounded in the house of my friends."

---

## The Smitten Shepherd and the Refined Remnant (13:7-9)

**13:7** Awake, O sword, against my shepherd, and against the man that is my fellow, says YHWH of hosts; smite the shepherd, and the sheep shall be scattered; and I will turn my hand upon the little ones.

**13:8** And it shall come to pass, that in all the land, says YHWH, two parts therein shall be cut off and die; but the third shall be left therein.

**13:9** And I will bring the third part through the fire, and will refine them as silver is refined, and will try them as gold is tried; they shall call on my name, and I will answer them; I will say: "It is my people"; and they shall say: "YHWH is my God."

---

## Synthesis Notes

**Key Restorations:**

**Cleansing from Sin and Idolatry (13:1-6):**
**The Key Verse (13:1):**
"''In that day there shall be a fountain opened.''"

*Ba-yom ha-hu yihyeh maqor niftach*—fountain opened.

"''To the house of David and to the inhabitants of Jerusalem.''"

*Le-veit David u-le-yoshevei Yerushalayim*—David, Jerusalem.

"''For sin and for uncleanness.''"

*Le-chattat u-le-niddah*—sin, uncleanness.

**Maqor:**
"Fountain/spring"—source of cleansing.

**The Key Verses (13:2-3):**
"''I will cut off the names of the idols out of the land.''"

*Akhrit et-shemot ha-atzabbim min-ha-aretz*—cut off idols.

"''They shall no more be remembered.''"

*Ve-lo yizzakheru od*—not remembered.

"''I will cause the prophets and the unclean spirit to pass out of the land.''"

*Ve-gam et-ha-nevi'im ve-et-ruach ha-tum'ah a'avir min-ha-aretz*—prophets, unclean spirit.

"''When any shall yet prophesy, then his father and his mother... shall say unto him: You shall not live.''"

*Ve-hayah ki-yinnavve ish od ve-ameru elav aviv ve-immo yoledav lo tichyeh*—parents condemn.

"''You speak lies in the name of YHWH.''"

*Ki sheqer dibbarta be-shem YHWH*—lies in YHWH's name.

"''His father and his mother... shall thrust him through when he prophesies.''"

*U-deqaruhu aviv ve-immo yoledav be-hinave'o*—thrust through.

**The Key Verses (13:4-6):**
"''The prophets shall be ashamed every one of his vision.''"

*Yevoshu ha-nevi'im ish me-chezyono*—ashamed.

"''When he prophesies.''"

*Be-hinave'o*—when prophesies.

"''Neither shall they wear a hairy mantle to deceive.''"

*Ve-lo yilbeshu adderet se'ar lema'an kachesh*—no hairy mantle.

"''But he shall say: I am no prophet.''"

*Ve-amar lo navi anokhi*—not prophet.

"''I am a tiller of the ground.''"

*Ish-oved adamah anokhi*—farmer.

"''A man taught me to keep cattle from my youth.''"

*Ki adam hiqnani mi-ne'urai*—taught from youth.

"''What are these wounds between your hands?''"

*Mah ha-makkot ha-elleh bein yadekha*—wounds?

"''Those with which I was wounded in the house of my friends.''"

*Asher hukketi beit me'ahavai*—wounded by friends.

**Smitten Shepherd and Refined Remnant (13:7-9):**
**The Key Verse (13:7):**
"''Awake, O sword, against my shepherd.''"

*Cherev uri al-ro'י*—sword, shepherd.

"''Against the man that is my fellow.''"

*Ve-al-gever amiti*—my fellow.

**Gever Amiti:**
"The man who is my fellow/associate"—intimate relationship.

"''Smite the shepherd, and the sheep shall be scattered.''"

*Hakh et-ha-ro'eh u-teפutzeinah ha-tzon*—smite, scatter.

**Quoted in Matthew 26:31, Mark 14:27:**
Jesus quotes this at Gethsemane.

"''I will turn my hand upon the little ones.''"

*Va-hashivoti yadi al-ha-tzo'arim*—hand on little ones.

**The Key Verses (13:8-9):**
"''In all the land... two parts therein shall be cut off and die.''"

*Ve-hayah ve-khol-ha-aretz... pi-shenayim bah yikkaretu yigva'u*—two-thirds die.

"''But the third shall be left therein.''"

*Ve-ha-shelishit yivvatzer bah*—third left.

"''I will bring the third part through the fire.''"

*Ve-heveti et-ha-shelishit ba-esh*—through fire.

"''Will refine them as silver is refined.''"

*U-tzerafתim ki-tzeref et-ha-kesef*—refine silver.

"''Will try them as gold is tried.''"

*U-vechanתim ki-bechon et-ha-zahav*—try gold.

"''They shall call on my name, and I will answer them.''"

*Hu yiqra vi-shmi va-ani e'eneh oto*—call, answer.

"''I will say: It is my people.''"

*Amarti ammi hu*—my people.

"''They shall say: YHWH is my God.''"

*Ve-hu yomar YHWH Elohai*—YHWH my God.

**Covenant Formula Restored.**

**Archetypal Layer:** Zechariah 13 contains **"In that day there shall be a fountain opened to the house of David... for sin and for uncleanness" (13:1)**, **"I will cut off the names of the idols out of the land" (13:2)**, **"I will cause the prophets and the unclean spirit to pass out of the land" (13:2)**, **false prophets condemned by their own parents (13:3)**, **"the prophets shall be ashamed every one of his vision" (13:4)**, **"I am no prophet, I am a tiller of the ground" (13:5)**, **"What are these wounds between your hands? Those with which I was wounded in the house of my friends" (13:6)**, **"Awake, O sword, against my shepherd, and against the man that is my fellow... smite the shepherd, and the sheep shall be scattered" (13:7)**—quoted in Matthew 26:31, **"two parts therein shall be cut off and die; but the third shall be left" (13:8)**, **"I will bring the third part through the fire, and will refine them as silver" (13:9)**, and **the renewed covenant formula: "I will say: It is my people; and they shall say: YHWH is my God" (13:9)**.

**Ethical Inversion Applied:**
- "''In that day there shall be a fountain opened''"—fountain
- "''To the house of David and to the inhabitants of Jerusalem''"—David, Jerusalem
- "''For sin and for uncleanness''"—cleansing
- "''I will cut off the names of the idols out of the land''"—cut off idols
- "''They shall no more be remembered''"—not remembered
- "''I will cause the prophets and the unclean spirit to pass out''"—remove
- "''When any shall yet prophesy... his father and his mother... shall say unto him: You shall not live''"—parents condemn
- "''You speak lies in the name of YHWH''"—lies
- "''His father and his mother... shall thrust him through''"—thrust through
- "''The prophets shall be ashamed every one of his vision''"—ashamed
- "''Neither shall they wear a hairy mantle to deceive''"—no mantle
- "''I am no prophet''"—deny prophesy
- "''I am a tiller of the ground''"—farmer
- "''What are these wounds between your hands?''"—wounds
- "''Those with which I was wounded in the house of my friends''"—wounded by friends
- "''Awake, O sword, against my shepherd''"—sword, shepherd
- "''Against the man that is my fellow''"—my fellow
- "''Smite the shepherd, and the sheep shall be scattered''"—smite, scatter
- "''I will turn my hand upon the little ones''"—hand on little ones
- "''Two parts therein shall be cut off and die''"—two-thirds
- "''But the third shall be left therein''"—third left
- "''I will bring the third part through the fire''"—through fire
- "''Will refine them as silver is refined''"—refine
- "''Will try them as gold is tried''"—try
- "''They shall call on my name, and I will answer them''"—call, answer
- "''I will say: It is my people''"—my people
- "''They shall say: YHWH is my God''"—my God

**Modern Equivalent:** Zechariah 13 begins with a fountain for cleansing sin (13:1)—spiritual purification. False prophets will be so despised that their own parents will condemn them (13:3). The smitten shepherd (13:7) is quoted by Jesus at Gethsemane (Matthew 26:31)—He is the shepherd struck, and the disciples scatter. The refining of the remnant through fire (13:9) produces a people who truly say "YHWH is my God"—the covenant restored.

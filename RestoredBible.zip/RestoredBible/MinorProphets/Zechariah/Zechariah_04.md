# Zechariah 4: The Lampstand and the Two Olive Trees

*From the Hebrew: וַיָּשָׁב הַמַּלְאָךְ הַדֹּבֵר בִּי וַיְעִירֵנִי (Va-Yashov Ha-Mal'akh Ha-Dover Bi Va-Ye'ireni) — And the Angel That Spoke with Me Came Again, and Waked Me*

---

## Fifth Vision: The Golden Lampstand (4:1-14)

**4:1** And the angel that spoke with me came again, and waked me, as a man that is wakened out of his sleep.

**4:2** And he said unto me: "What do you see?" And I said: "I have seen, and behold a candlestick all of gold, with a bowl upon the top of it, and its seven lamps thereon; there are seven pipes, yea, seven, to the lamps, which are upon the top thereof;

**4:3** "And two olive-trees by it, one upon the right side of the bowl, and the other upon the left side thereof."

**4:4** And I answered and spoke to the angel that spoke with me, saying: "What are these, my lord?"

**4:5** Then the angel that spoke with me answered and said unto me: "Know you not what these are?" And I said: "No, my lord."

**4:6** Then he answered and spoke unto me, saying: "This is the word of YHWH unto Zerubbabel, saying: 'Not by might, nor by power, but by my spirit,' says YHWH of hosts.

**4:7** "'Who are you, O great mountain? Before Zerubbabel you shall become a plain; and he shall bring forth the top stone with shoutings of Grace, grace, unto it.'"

**4:8** Moreover the word of YHWH came unto me, saying:

**4:9** "The hands of Zerubbabel have laid the foundation of this house; his hands shall also finish it; and you shall know that YHWH of hosts has sent me unto you.

**4:10** "For who has despised the day of small things? For they shall rejoice, even these seven eyes of YHWH, which run to and fro through the whole earth, when they see the plummet in the hand of Zerubbabel."

**4:11** Then answered I, and said unto him: "What are these two olive-trees upon the right side of the candlestick and upon the left side thereof?"

**4:12** And I answered the second time, and said unto him: "What are these two olive-branches, which are beside the two golden spouts, that empty the golden oil out of themselves?"

**4:13** And he answered me and said: "Know you not what these are?" And I said: "No, my lord."

**4:14** Then said he: "These are the two anointed ones, that stand by the Lord of the whole earth."

---

## Synthesis Notes

**Key Restorations:**

**Fifth Vision (4:1-14):**
**The Key Verses (4:1-3):**
"'The angel that spoke with me came again, and waked me.'"

*Va-yashov ha-mal'akh ha-dover bi va-ye'ireni*—waked.

"'As a man that is wakened out of his sleep.'"

*Ke-ish asher-ye'or mi-shenato*—from sleep.

"''What do you see?''"

*Mah attah ro'eh*—what see?

"''I have seen, and behold a candlestick all of gold.''"

*Ra'iti ve-hinneh menorat zahav kullah*—golden lampstand.

"''With a bowl upon the top of it.''"

*Ve-gullah al-roshah*—bowl on top.

"''Its seven lamps thereon.''"

*Ve-shiv'ah neroteiha aleiha*—seven lamps.

"''There are seven pipes, yea, seven, to the lamps.''"

*Shiv'ah va-shiv'ah mutzaqot la-nerot*—seven pipes each.

"''Two olive-trees by it, one upon the right side of the bowl, and the other upon the left side thereof.''"

*U-shenayim zeitim aleiha echad mi-yemin ha-gullah ve-echad al-semolah*—two olives.

**The Key Verses (4:4-6):**
"''What are these, my lord?''"

*Mah-elleh adoni*—what?

"''Know you not what these are?''"

*Ha-lo yada'ta mah-hemmah elleh*—don't you know?

"''No, my lord.''"

*Lo adoni*—no.

"''This is the word of YHWH unto Zerubbabel.''"

*Zeh devar-YHWH el-Zerubbavel*—to Zerubbabel.

"''Not by might, nor by power, but by my spirit.''"

*Lo ve-chayil ve-lo ve-khoach ki im-be-ruchi*—by my spirit.

**Lo Ve-Chayil Ve-Lo Ve-Khoach Ki Im-Be-Ruchi:**
"Not by might, nor by power, but by my spirit"—one of the most quoted verses.

**The Key Verses (4:7-10):**
"''Who are you, O great mountain?''"

*Mi-attah har-ha-gadol*—great mountain.

"''Before Zerubbabel you shall become a plain.''"

*Lifnei Zerubbavel le-mishor*—become plain.

"''He shall bring forth the top stone.''"

*Ve-hotzi et-ha-even ha-roshah*—top stone.

"''With shoutings of Grace, grace, unto it.''"

*Teshu'ot chen chen lah*—grace, grace.

"''The hands of Zerubbabel have laid the foundation of this house.''"

*Yedei Zerubbavel yissedu ha-bayit ha-zeh*—laid foundation.

"''His hands shall also finish it.''"

*Ve-yadav tevatzza'nah*—finish.

"''You shall know that YHWH of hosts has sent me unto you.''"

*Ve-yada'ta ki-YHWH tzeva'ot shelachani aleikhem*—sent.

"''Who has despised the day of small things?''"

*Ki mi vaz le-yom qetannot*—small things.

"''These seven eyes of YHWH, which run to and fro through the whole earth.''"

*Shiv'ah elleh einei YHWH hemmah meshotetim be-khol-ha-aretz*—seven eyes.

"''They shall rejoice... when they see the plummet in the hand of Zerubbabel.''"

*Ve-samechu ve-ra'u et-ha-even ha-bedil be-yad Zerubbavel*—plummet.

**The Key Verses (4:11-14):**
"''What are these two olive-trees?''"

*Mah-shenei ha-zeitim ha-elleh*—two olives.

"''Upon the right side of the candlestick and upon the left side thereof?''"

*Al-yemin ha-menorah ve-al-semolah*—right and left.

"''What are these two olive-branches?''"

*Mah shetei shibbolei ha-zeitim*—olive branches.

"''Which are beside the two golden spouts.''"

*Asher be-yad shenei tzanteret ha-zahav*—golden spouts.

"''That empty the golden oil out of themselves?''"

*Ha-meriqim me-aleihem ha-zahav*—empty oil.

"''Know you not what these are?''"

*Ha-lo yada'ta mah-elleh*—don't know?

"''No, my lord.''"

*Lo adoni*—no.

"''These are the two anointed ones, that stand by the Lord of the whole earth.''"

*Elleh shenei venei-ha-yitzhar ha-omedim al-Adon kol-ha-aretz*—two anointed.

**Shenei Venei-Ha-Yitzhar:**
"The two sons of oil" = "the two anointed ones"—Zerubbabel and Joshua, king and priest.

**Archetypal Layer:** Zechariah 4 contains **the fifth vision: golden lampstand with bowl and seven lamps, two olive trees (4:1-3)**, **"Not by might, nor by power, but by my spirit, says YHWH of hosts" (4:6)**, **"Who are you, O great mountain? Before Zerubbabel you shall become a plain" (4:7)**, **"he shall bring forth the top stone with shoutings of Grace, grace" (4:7)**, **"The hands of Zerubbabel have laid the foundation... his hands shall also finish it" (4:9)**, **"who has despised the day of small things?" (4:10)**, **"these seven eyes of YHWH, which run to and fro through the whole earth" (4:10)**, and **"These are the two anointed ones, that stand by the Lord of the whole earth" (4:14)**.

**Ethical Inversion Applied:**
- "'The angel... came again, and waked me'"—waked
- "''What do you see?''"—see
- "''A candlestick all of gold''"—golden lampstand
- "''With a bowl upon the top of it''"—bowl
- "''Its seven lamps thereon''"—seven lamps
- "''There are seven pipes... to the lamps''"—pipes
- "''Two olive-trees by it''"—olive trees
- "''What are these, my lord?''"—question
- "''Know you not what these are?''"—don't know
- "''This is the word of YHWH unto Zerubbabel''"—to Zerubbabel
- "''Not by might, nor by power, but by my spirit''"—by spirit
- "''Who are you, O great mountain?''"—mountain
- "''Before Zerubbabel you shall become a plain''"—plain
- "''He shall bring forth the top stone''"—top stone
- "''With shoutings of Grace, grace''"—grace
- "''The hands of Zerubbabel have laid the foundation''"—foundation
- "''His hands shall also finish it''"—finish
- "'You shall know that YHWH of hosts has sent me'"—sent
- "''Who has despised the day of small things?''"—small things
- "''These seven eyes of YHWH''"—seven eyes
- "''Which run to and fro through the whole earth''"—run through earth
- "''They shall rejoice... when they see the plummet''"—rejoice
- "''What are these two olive-trees?''"—two olives
- "''What are these two olive-branches?''"—branches
- "''Which... empty the golden oil?''"—empty oil
- "''These are the two anointed ones''"—two anointed
- "''That stand by the Lord of the whole earth''"—stand by Lord

**Modern Equivalent:** Zechariah 4 centers on "Not by might, nor by power, but by my spirit" (4:6)—encouragement for the rebuilding task. The great mountain will become a plain before Zerubbabel (4:7). "Who has despised the day of small things?" (4:10) encourages those discouraged by the modest second temple. The two olive trees (4:14) are "the two anointed ones"—Zerubbabel (royal) and Joshua (priestly), representing dual messianic leadership.

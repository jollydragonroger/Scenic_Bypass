# Zechariah 2: The Man with the Measuring Line

*From the Hebrew: וָאֶשָּׂא עֵינַי וָאֵרֶא (Va-Essa Einai Va-Ere) — And I Lifted Up My Eyes, and Saw*

---

## Third Vision: The Measuring Line (2:1-5)

**2:1** And I lifted up my eyes, and saw, and behold a man with a measuring line in his hand.

**2:2** Then said I: "Whither are you going?" And he said unto me: "To measure Jerusalem, to see what is the breadth thereof, and what is the length thereof."

**2:3** And, behold, the angel that spoke with me went forth, and another angel went out to meet him,

**2:4** And said unto him: "Run, speak to this young man, saying: Jerusalem shall be inhabited without walls, for the multitude of men and cattle therein.

**2:5** "For I, says YHWH, will be unto her a wall of fire round about, and I will be the glory in the midst of her."

---

## Call to Flee Babylon (2:6-13)

**2:6** Ho, ho, flee from the land of the north, says YHWH; for I have spread you abroad as the four winds of the heaven, says YHWH.

**2:7** Ho, Zion, escape, you that dwell with the daughter of Babylon.

**2:8** For thus says YHWH of hosts who sent me after glory unto the nations which spoiled you: "Surely he that touches you touches the apple of his eye.

**2:9** "For, behold, I will shake my hand over them, and they shall be a spoil to those that served them"; and you shall know that YHWH of hosts has sent me.

**2:10** "Sing and rejoice, O daughter of Zion; for, lo, I come, and I will dwell in the midst of you," says YHWH.

**2:11** "And many nations shall join themselves to YHWH in that day, and shall be my people, and I will dwell in the midst of you"; and you shall know that YHWH of hosts has sent me unto you.

**2:12** And YHWH shall inherit Judah as his portion in the holy land, and shall choose Jerusalem again.

**2:13** Be silent, all flesh, before YHWH; for he is aroused out of his holy habitation.

---

## Synthesis Notes

**Key Restorations:**

**Third Vision (2:1-5):**
**The Key Verses (2:1-2):**
"'I lifted up my eyes, and saw, and behold a man with a measuring line in his hand.'"

*Va-essa einai va-ere ve-hinneh ish u-ve-yado chevel middah*—measuring line.

"''Whither are you going?''"

*Anah attah holekh*—where going?

"''To measure Jerusalem, to see what is the breadth thereof, and what is the length thereof.''"

*Limdod et-Yerushalayim lir'ot kammah rochbah ve-khammah orkah*—measure Jerusalem.

**The Key Verses (2:3-5):**
"'The angel that spoke with me went forth, and another angel went out to meet him.'"

*Ve-hinneh ha-mal'akh ha-dover bi yotze u-mal'akh acher yotze liqrato*—angels.

"''Run, speak to this young man.''"

*Rutz dabber el-ha-na'ar ha-laz*—run, speak.

"''Jerusalem shall be inhabited without walls.''"

*Perazot teshev Yerushalayim*—without walls.

"''For the multitude of men and cattle therein.''"

*Me-rov adam u-vehemah be-tokhah*—multitude.

"''I, says YHWH, will be unto her a wall of fire round about.''"

*Va-ani ehyeh-lah ne'um-YHWH chomat esh saviv*—wall of fire.

"''I will be the glory in the midst of her.''"

*U-le-khavod ehyeh be-tokhah*—glory within.

**Call to Flee Babylon (2:6-13):**
**The Key Verses (2:6-7):**
"''Ho, ho, flee from the land of the north.''"

*Hoy hoy nusu me-eretz tzafon*—flee north.

"''I have spread you abroad as the four winds of the heaven.''"

*Ki ke-arba ruchot ha-shamayim perastי etkhem*—four winds.

"''Ho, Zion, escape, you that dwell with the daughter of Babylon.''"

*Hoy Tziyon himmalti yoshevet bat-Bavel*—escape Babylon.

**The Key Verses (2:8-9):**
"''He that touches you touches the apple of his eye.''"

*Ha-nogea bakhem nogea be-vavat eino*—apple of eye.

**Bavat Eino:**
"Apple of his eye"—the pupil, most sensitive part.

"''I will shake my hand over them, and they shall be a spoil.''"

*Ki hineni menif et-yadi aleihem ve-hayu shallal le-ovedeihem*—shake hand.

"'You shall know that YHWH of hosts has sent me.'"

*Vi-yda'tem ki-YHWH tzeva'ot shelachani*—sent me.

**The Key Verses (2:10-12):**
"''Sing and rejoice, O daughter of Zion.''"

*Ronni ve-simchi bat-Tziyon*—sing, rejoice.

"''Lo, I come, and I will dwell in the midst of you.''"

*Ki hineni-va ve-shakhantiב be-tokhekh*—dwell in midst.

"''Many nations shall join themselves to YHWH in that day.''"

*Ve-nilvו goyim rabbim el-YHWH ba-yom ha-hu*—nations join.

"''Shall be my people.''"

*Ve-hayu li le-am*—my people.

"''I will dwell in the midst of you.''"

*Ve-shakhantiв be-tokhekh*—dwell.

"'You shall know that YHWH of hosts has sent me unto you.'"

*Ve-yada'at ki-YHWH tzeva'ot shelachani elayikh*—sent me.

"'YHWH shall inherit Judah as his portion in the holy land.'"

*Ve-nachal YHWH et-Yehudah chelqo al-admat ha-qodesh*—holy land.

**Admat Ha-Qodesh:**
"The holy land"—only occurrence of this phrase.

"'Shall choose Jerusalem again.'"

*U-vachar od bi-Yrushalayim*—choose Jerusalem.

**The Key Verse (2:13):**
"'Be silent, all flesh, before YHWH.'"

*Has kol-basar mi-penei YHWH*—silence.

"'He is aroused out of his holy habitation.'"

*Ki ne'or mi-me'on qodsho*—aroused.

**Archetypal Layer:** Zechariah 2 contains **the third vision: man with measuring line (2:1-5)**, **"Jerusalem shall be inhabited without walls, for the multitude of men and cattle therein" (2:4)**, **"I, says YHWH, will be unto her a wall of fire round about, and I will be the glory in the midst of her" (2:5)**, **"Ho, ho, flee from the land of the north... Ho, Zion, escape, you that dwell with the daughter of Babylon" (2:6-7)**, **"he that touches you touches the apple of his eye" (2:8)**, **"Sing and rejoice, O daughter of Zion; for, lo, I come, and I will dwell in the midst of you" (2:10)**, **"many nations shall join themselves to YHWH in that day, and shall be my people" (2:11)**, **"YHWH shall inherit Judah as his portion in the holy land" (2:12)**, and **"Be silent, all flesh, before YHWH" (2:13)**.

**Ethical Inversion Applied:**
- "'I lifted up my eyes, and saw... a man with a measuring line'"—measuring line
- "''Whither are you going?''"—question
- "''To measure Jerusalem''"—measure
- "'The angel that spoke with me went forth'"—angels
- "''Run, speak to this young man''"—run
- "''Jerusalem shall be inhabited without walls''"—without walls
- "''For the multitude of men and cattle therein''"—multitude
- "''I... will be unto her a wall of fire round about''"—wall of fire
- "''I will be the glory in the midst of her''"—glory within
- "''Ho, ho, flee from the land of the north''"—flee north
- "''I have spread you abroad as the four winds''"—four winds
- "''Ho, Zion, escape, you that dwell with the daughter of Babylon''"—escape
- "''He that touches you touches the apple of his eye''"—apple of eye
- "''I will shake my hand over them''"—shake hand
- "''They shall be a spoil''"—spoil
- "'You shall know that YHWH of hosts has sent me'"—sent
- "''Sing and rejoice, O daughter of Zion''"—sing
- "''Lo, I come, and I will dwell in the midst of you''"—dwell
- "''Many nations shall join themselves to YHWH''"—nations join
- "''Shall be my people''"—my people
- "'YHWH shall inherit Judah as his portion in the holy land'"—holy land
- "'Shall choose Jerusalem again'"—choose
- "'Be silent, all flesh, before YHWH'"—silence
- "'He is aroused out of his holy habitation'"—aroused

**Modern Equivalent:** Zechariah 2 presents a vision of Jerusalem too great for walls (2:4)—YHWH Himself will be a wall of fire and glory within (2:5). The call to flee Babylon (2:6-7) urges exiles still there to escape. "Apple of his eye" (2:8) shows YHWH's protective love. "Many nations shall join themselves to YHWH" (2:11) anticipates Gentile inclusion. "The holy land" (2:12) appears only here in the OT. "Be silent, all flesh" (2:13) prepares for theophany.

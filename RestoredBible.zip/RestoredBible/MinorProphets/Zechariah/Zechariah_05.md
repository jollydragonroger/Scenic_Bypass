# Zechariah 5: The Flying Scroll and the Woman in the Ephah

*From the Hebrew: וָאָשׁוּב וָאֶשָּׂא עֵינַי וָאֶרְאֶה (Va-Ashuv Va-Essa Einai Va-Er'eh) — Then Again I Lifted Up My Eyes, and Saw*

---

## Sixth Vision: The Flying Scroll (5:1-4)

**5:1** Then again I lifted up my eyes, and saw, and behold a flying scroll.

**5:2** And he said unto me: "What do you see?" And I answered: "I see a flying scroll; the length thereof is twenty cubits, and the breadth thereof ten cubits."

**5:3** Then said he unto me: "This is the curse that goes forth over the face of the whole land; for every one that steals shall be swept away on the one side like it; and every one that swears shall be swept away on the other side like it.

**5:4** "I will cause it to go forth," says YHWH of hosts, "and it shall enter into the house of the thief, and into the house of him that swears falsely by my name; and it shall abide in the midst of his house, and shall consume it with the timber thereof and the stones thereof."

---

## Seventh Vision: The Woman in the Ephah (5:5-11)

**5:5** Then the angel that spoke with me went forth, and said unto me: "Lift up now your eyes, and see what is this that goes forth."

**5:6** And I said: "What is it?" And he said: "This is the ephah-measure that goes forth." He said moreover: "This is their eye in all the land."

**5:7** And, behold, there was lifted up a cover of lead; and this is a woman sitting in the midst of the ephah.

**5:8** And he said: "This is Wickedness." And he cast her down into the midst of the ephah; and he cast the weight of lead upon the mouth thereof.

**5:9** Then lifted I up my eyes, and saw, and behold, there came forth two women, and the wind was in their wings; for they had wings like the wings of a stork; and they lifted up the ephah between the earth and the heaven.

**5:10** Then said I to the angel that spoke with me: "Whither do these bear the ephah?"

**5:11** And he said unto me: "To build her a house in the land of Shinar; and when it is prepared, she shall be set there in her own place."

---

## Synthesis Notes

**Key Restorations:**

**Sixth Vision (5:1-4):**
**The Key Verses (5:1-2):**
"'I lifted up my eyes, and saw, and behold a flying scroll.'"

*Va-ashuv va-essa einai va-er'eh ve-hinneh megillah afah*—flying scroll.

"''What do you see?''"

*Mah attah ro'eh*—what see?

"''I see a flying scroll; the length thereof is twenty cubits, and the breadth thereof ten cubits.''"

*Ani ro'eh megillah afah orkhah esrim ba-ammah ve-rochbah eser ba-ammah*—20x10 cubits.

**Dimensions:**
Same as the porch of Solomon's temple (1 Kings 6:3).

**The Key Verses (5:3-4):**
"''This is the curse that goes forth over the face of the whole land.''"

*Zot ha-alah ha-yotzet al-penei khol-ha-aretz*—curse.

"''Every one that steals shall be swept away on the one side like it.''"

*Ki khol-ha-gonnev mi-zeh kamohah niqqah*—thieves swept.

"''Every one that swears shall be swept away on the other side like it.''"

*Ve-khol-ha-nishba mi-zeh kamohah niqqah*—false swearers swept.

"''I will cause it to go forth.''"

*Hotzeitiha ne'um YHWH tzeva'ot*—sent forth.

"''It shall enter into the house of the thief.''"

*U-va'ah el-beit ha-gannav*—thief's house.

"''Into the house of him that swears falsely by my name.''"

*Ve-el-beit ha-nishba vi-shmi la-shaqer*—false swearer's house.

"''It shall abide in the midst of his house.''"

*Ve-lanah be-tokh beito*—abide.

"''Shall consume it with the timber thereof and the stones thereof.''"

*Ve-khillatathu ve-et-etzav ve-et-avanav*—consume house.

**Seventh Vision (5:5-11):**
**The Key Verses (5:5-8):**
"''Lift up now your eyes, and see what is this that goes forth.''"

*Sa-na einekha u-re'eh mah ha-yotze ha-zot*—what goes forth?

"''What is it?''"

*Mah-hi*—what?

"''This is the ephah-measure that goes forth.''"

*Zot ha-eifah ha-yotzet*—ephah.

**Eifah:**
A dry measure, about 5-6 gallons; here a container.

"''This is their eye in all the land.''"

*Va-yomer zot einam be-khol-ha-aretz*—their eye.

"'There was lifted up a cover of lead.'"

*Ve-hinneh kikkar oferet nissa't*—lead cover.

"'This is a woman sitting in the midst of the ephah.'"

*Ve-zot ishah achat yoshevet be-tokh ha-eifah*—woman inside.

"''This is Wickedness.''"

*Va-yomer zot ha-rish'ah*—Wickedness.

"'He cast her down into the midst of the ephah.'"

*Va-yashlekh otah el-tokh ha-eifah*—cast down.

"'He cast the weight of lead upon the mouth thereof.'"

*Va-yashlekh et-even ha-oferet el-piha*—lead weight.

**The Key Verses (5:9-11):**
"'There came forth two women, and the wind was in their wings.'"

*Ve-hinneh shtayim nashim yוtz'ot ve-ruach be-khanfeihem*—two women.

"'They had wings like the wings of a stork.'"

*Ve-lahem kenafayim ke-khanfei ha-chasidah*—stork wings.

"'They lifted up the ephah between the earth and the heaven.'"

*Va-tissena et-ha-eifah bein ha-aretz u-vein ha-shamayim*—lifted.

"''Whither do these bear the ephah?''"

*Anah hemmah molikhot et-ha-eifah*—where?

"''To build her a house in the land of Shinar.''"

*Livnot-lah vayit be-eretz Shin'ar*—Shinar.

**Shin'ar:**
Babylonia—wickedness is being removed to its proper place.

"''When it is prepared, she shall be set there in her own place.''"

*Ve-hukhan ve-hunnichah-sham al-mekhunata*—set in place.

**Archetypal Layer:** Zechariah 5 contains **the sixth vision: the flying scroll (5:1-4)**—20x10 cubits (same as temple porch), **"This is the curse that goes forth over the face of the whole land" (5:3)**, **judgment on thieves and false swearers (5:3-4)**, **"it shall enter into the house... and shall consume it with the timber thereof and the stones thereof" (5:4)**, **the seventh vision: the woman in the ephah (5:5-11)**, **"This is Wickedness" (5:8)**, **lead cover sealing her in (5:8)**, **two women with stork wings carrying the ephah (5:9)**, and **"To build her a house in the land of Shinar" (5:11)**—wickedness removed to Babylon.

**Ethical Inversion Applied:**
- "'I lifted up my eyes, and saw... a flying scroll'"—flying scroll
- "''What do you see?''"—see
- "''I see a flying scroll; the length thereof is twenty cubits''"—20x10
- "''This is the curse that goes forth over the face of the whole land''"—curse
- "''Every one that steals shall be swept away''"—thieves
- "''Every one that swears shall be swept away''"—false swearers
- "''I will cause it to go forth''"—sent
- "''It shall enter into the house of the thief''"—thief's house
- "''Into the house of him that swears falsely''"—false swearer
- "''It shall abide in the midst of his house''"—abide
- "''Shall consume it with the timber thereof and the stones thereof''"—consume
- "''Lift up now your eyes, and see what is this that goes forth''"—goes forth
- "''This is the ephah-measure that goes forth''"—ephah
- "''This is their eye in all the land''"—eye
- "'There was lifted up a cover of lead'"—lead cover
- "'This is a woman sitting in the midst of the ephah'"—woman
- "''This is Wickedness''"—Wickedness
- "'He cast her down into the midst of the ephah'"—cast down
- "'He cast the weight of lead upon the mouth thereof'"—lead weight
- "'There came forth two women, and the wind was in their wings'"—two women
- "'They had wings like the wings of a stork'"—stork wings
- "'They lifted up the ephah between the earth and the heaven'"—lifted
- "''Whither do these bear the ephah?''"—where
- "''To build her a house in the land of Shinar''"—Shinar
- "''She shall be set there in her own place''"—set in place

**Modern Equivalent:** Zechariah 5 presents two purification visions. The flying scroll (5:1-4) represents the curse on lawbreakers—it enters and destroys their houses. The woman in the ephah (5:5-11) is "Wickedness" personified, sealed with lead and carried to Shinar (Babylon)—wickedness is being removed from the holy land to its proper home. Both visions show God purifying His community.

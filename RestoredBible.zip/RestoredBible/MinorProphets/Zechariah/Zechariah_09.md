# Zechariah 9: The Coming King

*From the Hebrew: מַשָּׂא דְבַר־יְהוָה (Massa Devar-YHWH) — The Burden of the Word of YHWH*

---

## Judgment on Neighboring Nations (9:1-8)

**9:1** The burden of the word of YHWH. In the land of Hadrach, and in Damascus shall be his resting-place; for YHWH's is the eye of man and all the tribes of Israel.

**9:2** And Hamath also, which borders thereon; Tyre and Zidon, for they are very wise.

**9:3** And Tyre did build herself a stronghold, and heaped up silver as the dust, and fine gold as the mire of the streets.

**9:4** Behold, the Lord will dispossess her, and he will smite her power in the sea; and she shall be devoured with fire.

**9:5** Ashkelon shall see it, and fear; Gaza also, and shall be sore pained; and Ekron, for her expectation shall be ashamed; and the king shall perish from Gaza, and Ashkelon shall not be inhabited.

**9:6** And a bastard shall dwell in Ashdod, and I will cut off the pride of the Philistines.

**9:7** And I will take away his blood out of his mouth, and his detestable things from between his teeth; and he also shall be a remnant for our God; and he shall be as a chief in Judah, and Ekron as a Jebusite.

**9:8** And I will encamp about my house against the army, that none pass through or return; and no oppressor shall pass through them any more; for now have I seen with my eyes.

---

## The Coming King (9:9-10)

**9:9** Rejoice greatly, O daughter of Zion, shout, O daughter of Jerusalem; behold, your king comes unto you, he is just, and victorious, lowly, and riding upon an ass, even upon a colt the foal of an ass.

**9:10** And I will cut off the chariot from Ephraim, and the horse from Jerusalem, and the battle bow shall be cut off, and he shall speak peace unto the nations; and his dominion shall be from sea to sea, and from the River to the ends of the earth.

---

## Restoration of the Prisoners (9:11-17)

**9:11** As for you also, because of the blood of your covenant I send forth your prisoners out of the pit wherein is no water.

**9:12** Return to the stronghold, you prisoners of hope; even today do I declare that I will render double unto you.

**9:13** For I bend Judah for me, I fill the bow with Ephraim; and I will stir up your sons, O Zion, against your sons, O Greece, and will make you as the sword of a mighty man.

**9:14** And YHWH shall be seen over them, and his arrow shall go forth as the lightning; and the Lord YHWH will blow the horn, and will go with whirlwinds of the south.

**9:15** YHWH of hosts will defend them; and they shall devour, and shall tread down the sling-stones; and they shall drink, and make a noise as through wine; and they shall be filled like the basins, like the corners of the altar.

**9:16** And YHWH their God shall save them in that day as the flock of his people; for they shall be as the stones of a crown, glittering over his land.

**9:17** For how great is their goodness, and how great is their beauty! Corn shall make the young men flourish, and new wine the maidens.

---

## Synthesis Notes

**Key Restorations:**

**Judgment on Neighboring Nations (9:1-8):**
**The Key Verses (9:1-4):**
"'The burden of the word of YHWH.'"

*Massa devar-YHWH*—burden.

"'In the land of Hadrach, and in Damascus shall be his resting-place.'"

*Be-eretz Chadrakh u-Dammesek menuchato*—Hadrach, Damascus.

"'YHWH's is the eye of man and all the tribes of Israel.'"

*Ki la-YHWH ein adam ve-khol shivtei Yisra'el*—YHWH's eye.

"'Hamath also, which borders thereon; Tyre and Zidon, for they are very wise.'"

*Ve-gam Chamat tigbol-bah Tzor ve-Tzidon ki chakhemah me'od*—wise.

"'Tyre did build herself a stronghold.'"

*Va-tiven Tzor matzor lah*—stronghold.

"'Heaped up silver as the dust, and fine gold as the mire of the streets.'"

*Va-titzbor-kesef ke-afar ve-charutz ke-tit chutzot*—silver, gold.

"'The Lord will dispossess her.'"

*Hinneh Adonai yorishennaה*—dispossess.

"'He will smite her power in the sea.'"

*Ve-hikkah va-yam cheilah*—smite.

"'She shall be devoured with fire.'"

*Ve-hi ba-esh te'akhel*—fire.

**The Key Verses (9:5-8):**
"'Ashkelon shall see it, and fear; Gaza also, and shall be sore pained.'"

*Tere Ashqelon ve-tira ve-Azzah ve-tacהil me'od*—fear, pain.

"'Ekron, for her expectation shall be ashamed.'"

*Ve-Eqron ki-hovish mabbatah*—ashamed.

"'The king shall perish from Gaza.'"

*Ve-avad melekh me-Azzah*—king perishes.

"'Ashkelon shall not be inhabited.'"

*Ve-Ashqelon lo teshev*—uninhabited.

"'A bastard shall dwell in Ashdod.'"

*Ve-yashav mamzer be-Ashdod*—bastard.

"'I will cut off the pride of the Philistines.'"

*Ve-hikhrati ge'on Pelishtim*—cut off pride.

"'I will take away his blood out of his mouth.'"

*Va-hasiroti damav mi-piv*—blood removed.

"'His detestable things from between his teeth.'"

*Ve-shiqqוtzav mi-bein shinnav*—detestable things.

"'He also shall be a remnant for our God.'"

*Ve-nish'ar gam-hu le-Eloheinu*—remnant.

"'He shall be as a chief in Judah, and Ekron as a Jebusite.'"

*Ve-hayah ke-alluf bi-Yhudah ve-Eqron ki-Yevusi*—like Jebusite.

"'I will encamp about my house against the army.'"

*Ve-chanitי le-veiti mitzavah*—encamp.

"'No oppressor shall pass through them any more.'"

*Ve-lo-ya'avor aleihem od noges*—no oppressor.

"'For now have I seen with my eyes.'"

*Ki attah ra'iti be-einai*—I have seen.

**The Coming King (9:9-10):**
**The Key Verse (9:9):**
"''Rejoice greatly, O daughter of Zion, shout, O daughter of Jerusalem.''"

*Gili me'od bat-Tziyon hari'i bat-Yerushalayim*—rejoice, shout.

"''Behold, your king comes unto you.''"

*Hinneh malkekh yavo lakh*—king comes.

"''He is just, and victorious.''"

*Tzaddiq ve-nosha hu*—just, victorious.

"''Lowly, and riding upon an ass.''"

*Ani ve-rokhev al-chamor*—lowly, on donkey.

"''Even upon a colt the foal of an ass.''"

*Ve-al-ayir ben-atonot*—colt.

**Quoted in Matthew 21:5, John 12:15:**
Jesus's triumphal entry.

**The Key Verse (9:10):**
"''I will cut off the chariot from Ephraim, and the horse from Jerusalem.''"

*Ve-hikhrati-rekev me-Efrayim ve-sus mi-Yrushalayim*—cut off weapons.

"''The battle bow shall be cut off.''"

*Ve-nikhretah qeshet milchamah*—bow cut off.

"''He shall speak peace unto the nations.''"

*Ve-dibber shalom la-goyim*—speak peace.

"''His dominion shall be from sea to sea.''"

*U-moshlo mi-yam ad-yam*—sea to sea.

"''From the River to the ends of the earth.''"

*U-mi-nahar ad-afsei-aretz*—to earth's ends.

**Restoration of the Prisoners (9:11-17):**
**The Key Verses (9:11-13):**
"''Because of the blood of your covenant I send forth your prisoners.''"

*Gam-at be-dam-beritekh shillachti asirayikh*—covenant blood.

"''Out of the pit wherein is no water.''"

*Mi-bor ein mayim bo*—waterless pit.

"''Return to the stronghold, you prisoners of hope.''"

*Shuvu le-vitzaron asirei ha-tiqvah*—prisoners of hope.

"''Even today do I declare that I will render double unto you.''"

*Gam ha-yom maggid mishneh ashiv lakh*—double.

"''I bend Judah for me, I fill the bow with Ephraim.''"

*Ki-darakhti li Yehudah qeshet milleti Efrayim*—Judah bow.

"''I will stir up your sons, O Zion, against your sons, O Greece.''"

*Ve-orarti vanayikh Tziyon al-banayikh Yavan*—Zion vs. Greece.

"''Will make you as the sword of a mighty man.''"

*Ve-samtikh ke-cherev gibbor*—mighty sword.

**The Key Verses (9:14-17):**
"''YHWH shall be seen over them.''"

*Va-YHWH aleihem yera'eh*—YHWH seen.

"''His arrow shall go forth as the lightning.''"

*Ve-yatza kha-baraq chitzo*—arrow like lightning.

"''The Lord YHWH will blow the horn.''"

*Va-Adonai YHWH ba-shofar yitqa*—blow horn.

"''Will go with whirlwinds of the south.''"

*Ve-halakh be-sa'arot teiman*—whirlwinds.

"''YHWH of hosts will defend them.''"

*YHWH tzeva'ot yagen aleihem*—defend.

"''YHWH their God shall save them in that day as the flock of his people.''"

*Ve-hoshi'am YHWH Eloheihem ba-yom ha-hu ke-tzon ammo*—save as flock.

"''They shall be as the stones of a crown, glittering over his land.''"

*Ki avnei-nezer mitnoseसot al-admato*—crown stones.

"''How great is their goodness, and how great is their beauty!''"

*Ki-mah-tuvo u-mah-yofyo*—goodness, beauty.

"''Corn shall make the young men flourish, and new wine the maidens.''"

*Dagan yenovev bachurim ve-tirosh betulot*—corn, wine.

**Archetypal Layer:** Zechariah 9 contains **judgment on surrounding nations (9:1-8)**: Hadrach, Damascus, Tyre, Zidon, Philistia, **"I will encamp about my house... no oppressor shall pass through them any more" (9:8)**, **the famous messianic prophecy (9:9-10)**: "Rejoice greatly, O daughter of Zion... behold, your king comes unto you, he is just, and victorious, lowly, and riding upon an ass"—quoted in Matthew 21:5, **"he shall speak peace unto the nations; and his dominion shall be from sea to sea" (9:10)**, **"because of the blood of your covenant I send forth your prisoners" (9:11)**, **"Return to the stronghold, you prisoners of hope" (9:12)**, **"I will stir up your sons, O Zion, against your sons, O Greece" (9:13)**, and **"they shall be as the stones of a crown, glittering over his land" (9:16)**.

**Ethical Inversion Applied:**
- "'The burden of the word of YHWH'"—burden
- "'In the land of Hadrach, and in Damascus'"—Hadrach, Damascus
- "'Tyre and Zidon, for they are very wise'"—wise
- "'Tyre did build herself a stronghold'"—stronghold
- "'Heaped up silver as the dust'"—silver
- "'The Lord will dispossess her'"—dispossess
- "'She shall be devoured with fire'"—fire
- "'Ashkelon shall see it, and fear'"—fear
- "'The king shall perish from Gaza'"—perish
- "'A bastard shall dwell in Ashdod'"—bastard
- "'I will cut off the pride of the Philistines'"—cut off
- "'He also shall be a remnant for our God'"—remnant
- "'I will encamp about my house'"—encamp
- "'No oppressor shall pass through them any more'"—no oppressor
- "''Rejoice greatly, O daughter of Zion''"—rejoice
- "''Behold, your king comes unto you''"—king comes
- "''He is just, and victorious''"—just
- "''Lowly, and riding upon an ass''"—lowly, donkey
- "''I will cut off the chariot from Ephraim''"—cut off weapons
- "''He shall speak peace unto the nations''"—speak peace
- "''His dominion shall be from sea to sea''"—sea to sea
- "''Because of the blood of your covenant''"—covenant blood
- "''I send forth your prisoners out of the pit''"—prisoners freed
- "''Return to the stronghold, you prisoners of hope''"—prisoners of hope
- "''I will render double unto you''"—double
- "''I bend Judah for me, I fill the bow with Ephraim''"—bow
- "''I will stir up your sons, O Zion, against your sons, O Greece''"—Zion vs. Greece
- "''YHWH shall be seen over them''"—seen
- "''His arrow shall go forth as the lightning''"—lightning
- "''YHWH of hosts will defend them''"—defend
- "''YHWH their God shall save them... as the flock''"—save
- "''They shall be as the stones of a crown''"—crown stones
- "''How great is their goodness, and how great is their beauty!''"—goodness, beauty

**Modern Equivalent:** Zechariah 9:9 is the famous prophecy of the king riding on a donkey—quoted in the Gospels for Jesus's triumphal entry. The king is "just, and victorious, lowly"—a humble conqueror who brings peace. "His dominion shall be from sea to sea" (9:10) is universal. "Prisoners of hope" (9:12) is a powerful phrase. The chapter also predicts conflict with Greece (9:13)—remarkably specific for the 6th century BCE.

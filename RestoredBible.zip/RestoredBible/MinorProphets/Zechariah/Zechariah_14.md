# Zechariah 14: The Day of YHWH and His Universal Reign

*From the Hebrew: הִנֵּה יוֹם־בָּא לַיהוָה (Hinneh Yom-Ba La-YHWH) — Behold, a Day of YHWH Comes*

---

## The Final Battle (14:1-5)

**14:1** Behold, a day of YHWH comes, when your spoil shall be divided in the midst of you.

**14:2** For I will gather all nations against Jerusalem to battle; and the city shall be taken, and the houses rifled, and the women ravished; and half of the city shall go forth into captivity, but the residue of the people shall not be cut off from the city.

**14:3** Then shall YHWH go forth, and fight against those nations, as when he fights in the day of battle.

**14:4** And his feet shall stand in that day upon the mount of Olives, which is before Jerusalem on the east, and the mount of Olives shall be cleft in the midst thereof toward the east and toward the west, so that there shall be a very great valley; and half of the mountain shall remove toward the north, and half of it toward the south.

**14:5** And you shall flee to the valley of my mountains; for the valley of the mountains shall reach unto Azel; yea, you shall flee, like as you fled from before the earthquake in the days of Uzziah king of Judah; and YHWH my God shall come, and all the holy ones with you.

---

## Cosmic Changes and Living Waters (14:6-11)

**14:6** And it shall come to pass in that day, that there shall not be light, but heavy clouds and thick;

**14:7** And there shall be one day which shall be known as YHWH's, not day, and not night; but it shall come to pass, that at evening time there shall be light.

**14:8** And it shall come to pass in that day, that living waters shall go out from Jerusalem: half of them toward the eastern sea, and half of them toward the western sea; in summer and in winter shall it be.

**14:9** And YHWH shall be King over all the earth; in that day shall YHWH be One, and his name One.

**14:10** All the land shall be turned as the Arabah, from Geba to Rimmon south of Jerusalem; and she shall be lifted up, and inhabited in her place, from Benjamin's gate unto the place of the first gate, unto the corner gate, and from the tower of Hananel unto the king's winepresses.

**14:11** And men shall dwell therein, and there shall be no more curse; but Jerusalem shall dwell safely.

---

## Plague on the Enemies and Universal Worship (14:12-21)

**14:12** And this shall be the plague wherewith YHWH will smite all the peoples that have warred against Jerusalem: their flesh shall consume away while they stand upon their feet, and their eyes shall consume away in their sockets, and their tongue shall consume away in their mouth.

**14:13** And it shall come to pass in that day, that a great tumult from YHWH shall be among them; and they shall lay hold every one on the hand of his neighbour, and his hand shall rise up against the hand of his neighbour.

**14:14** And Judah also shall fight against Jerusalem; and the wealth of all the nations round about shall be gathered together, gold, and silver, and apparel, in great abundance.

**14:15** And so shall be the plague of the horse, of the mule, of the camel, and of the ass, and of all the beasts that shall be in those camps, as this plague.

**14:16** And it shall come to pass, that every one that is left of all the nations that came against Jerusalem shall go up from year to year to worship the King, YHWH of hosts, and to keep the feast of tabernacles.

**14:17** And it shall be, that whoso of the families of the earth goes not up unto Jerusalem to worship the King, YHWH of hosts, upon them there shall be no rain.

**14:18** And if the family of Egypt go not up, and come not, they shall have no overflow; there shall be the plague, wherewith YHWH will smite the nations that go not up to keep the feast of tabernacles.

**14:19** This shall be the punishment of Egypt, and the punishment of all the nations that go not up to keep the feast of tabernacles.

**14:20** In that day shall there be upon the bells of the horses: HOLY UNTO YHWH; and the pots in YHWH's house shall be like the basins before the altar.

**14:21** Yea, every pot in Jerusalem and in Judah shall be holy unto YHWH of hosts; and all they that sacrifice shall come and take of them, and seethe therein; and in that day there shall be no more a trafficker in the house of YHWH of hosts.

---

## Synthesis Notes

**Key Restorations:**

**Final Battle (14:1-5):**
**The Key Verses (14:1-2):**
"'Behold, a day of YHWH comes.'"

*Hinneh yom-ba la-YHWH*—day of YHWH.

"'Your spoil shall be divided in the midst of you.'"

*Ve-chullaq shalaleikh be-qirbekh*—spoil divided.

"''I will gather all nations against Jerusalem to battle.''"

*Ve-asafti et-kol-ha-goyim el-Yerushalayim la-milchamah*—gather nations.

"''The city shall be taken, and the houses rifled, and the women ravished.''"

*Ve-nilkedah ha-ir ve-nashassu ha-battim ve-ha-nashim tishshakavenah*—city taken.

"''Half of the city shall go forth into captivity.''"

*Ve-yatza chatzi ha-ir ba-golah*—half captive.

"''The residue of the people shall not be cut off from the city.''"

*Ve-yeter ha-am lo yikkaret min-ha-ir*—residue remains.

**The Key Verses (14:3-5):**
"''YHWH go forth, and fight against those nations.''"

*Ve-yatza YHWH ve-nilcham ba-goyim ha-hem*—YHWH fights.

"''As when he fights in the day of battle.''"

*Ke-yom hillachamo be-yom qerav*—day of battle.

"''His feet shall stand in that day upon the mount of Olives.''"

*Ve-amdu raglav ba-yom ha-hu al-har ha-Zetim*—Mount of Olives.

"''The mount of Olives shall be cleft in the midst thereof toward the east and toward the west.''"

*Ve-nivqa har ha-Zetim me-chetzyo mizrachah ve-yammah*—cleft.

"''There shall be a very great valley.''"

*Gei gedolah me'od*—great valley.

"''Half of the mountain shall remove toward the north, and half of it toward the south.''"

*U-mash chatzi ha-har tzafonah ve-chetzyo negbah*—move.

"''You shall flee to the valley of my mountains.''"

*Ve-nastem gei-harai*—flee.

"''Like as you fled from before the earthquake in the days of Uzziah.''"

*Ka-asher nastem mi-penei ha-ra'ash bi-yemei Uzziyyah*—earthquake.

"''YHWH my God shall come, and all the holy ones with you.''"

*U-va YHWH Elohai kol-qedoshim immakh*—YHWH comes with holy ones.

**Cosmic Changes and Living Waters (14:6-11):**
**The Key Verses (14:6-9):**
"''There shall not be light, but heavy clouds and thick.''"

*Ve-hayah ba-yom ha-hu lo-yihyeh or yeqarot yeqaffa'on*—no light.

"''There shall be one day which shall be known as YHWH's.''"

*Ve-hayah yom-echad hu yivvada la-YHWH*—YHWH's day.

"''Not day, and not night.''"

*Lo-yom ve-lo-laylah*—neither.

"''At evening time there shall be light.''"

*Ve-hayah le-et-erev yihyeh-or*—light at evening.

"''Living waters shall go out from Jerusalem.''"

*Yetze'u mayim-chayyim mi-Yrushalayim*—living waters.

"''Half of them toward the eastern sea, and half of them toward the western sea.''"

*Chetzyu el-ha-yam ha-qadmoni ve-chetzyu el-ha-yam ha-acharon*—east, west.

"''In summer and in winter shall it be.''"

*Ba-qayitz u-va-choref yihyeh*—year-round.

"''YHWH shall be King over all the earth.''"

*Ve-hayah YHWH le-Melekh al-kol-ha-aretz*—King over all.

"''In that day shall YHWH be One, and his name One.''"

*Ba-yom ha-hu yihyeh YHWH echad u-shemo echad*—YHWH One.

**YHWH Echad U-Shemo Echad:**
"YHWH will be One and His name One"—universal monotheism.

**The Key Verses (14:10-11):**
"''All the land shall be turned as the Arabah.''"

*Yissov kol-ha-aretz ka-Aravah*—like Arabah.

"''From Geba to Rimmon south of Jerusalem.''"

*Mi-Geva le-Rimmon negev Yerushalayim*—Geba to Rimmon.

"''She shall be lifted up, and inhabited in her place.''"

*Ve-ra'amah ve-yashवah tachteiha*—lifted, inhabited.

"''From Benjamin's gate unto the place of the first gate, unto the corner gate.''"

*Mi-sha'ar Binyamin ad-meqom sha'ar ha-rishon ad-sha'ar ha-pinnot*—gates.

"''From the tower of Hananel unto the king's winepresses.''"

*U-mi-migdal Chanan'el ad yeqevei ha-melekh*—tower, winepresses.

"''Men shall dwell therein, and there shall be no more curse.''"

*Ve-yashvu vah ve-cherem lo yihyeh-od*—no curse.

"''Jerusalem shall dwell safely.''"

*Ve-yashვah Yerushalayim la-vetach*—safely.

**Plague on Enemies and Universal Worship (14:12-21):**
**The Key Verses (14:12-15):**
"''This shall be the plague wherewith YHWH will smite all the peoples.''"

*Ve-zot tihyeh ha-maggefahh asher yiggof YHWH et-kol-ha-ammim*—plague.

"''Their flesh shall consume away while they stand upon their feet.''"

*Hammeq besaro ve-hu omed al-raglav*—flesh consumes.

"''Their eyes shall consume away in their sockets.''"

*Ve-einav timmaqnah be-choreihen*—eyes consume.

"''Their tongue shall consume away in their mouth.''"

*U-leshono timמaq be-fihem*—tongue consumes.

"''A great tumult from YHWH shall be among them.''"

*Ve-hayah ba-yom ha-hu tihyeh mehumat-YHWH rabbah bahem*—tumult.

"''They shall lay hold every one on the hand of his neighbour.''"

*Ve-hecheziqu ish yad re'ehu*—seize neighbor.

"''His hand shall rise up against the hand of his neighbour.''"

*Ve-aletah yado al-yad re'ehu*—fight each other.

"''The wealth of all the nations round about shall be gathered together.''"

*Ve-usaf cheil kol-ha-goyim saviv*—wealth gathered.

"''Gold, and silver, and apparel, in great abundance.''"

*Zahav va-khesef u-vegadim la-rov me'od*—abundance.

"''So shall be the plague of the horse, of the mule, of the camel.''"

*Ve-khen tihyeh maggefat ha-sus ha-pered ha-gamal*—animals.

**The Key Verses (14:16-19):**
"''Every one that is left of all the nations... shall go up from year to year to worship the King, YHWH of hosts.''"

*Ve-hayah kol-ha-notar mi-kol-ha-goyim... ve-alu midei shanah ve-shanah le-hishtachavot le-Melekh YHWH tzeva'ot*—worship.

"''To keep the feast of tabernacles.''"

*Ve-lachog et-chag ha-Sukkot*—Sukkot.

"''Whoso... goes not up unto Jerusalem to worship the King... upon them there shall be no rain.''"

*Ve-hayah asher lo-ya'aleh... al-ha-goyim... ve-lo aleihem yihyeh ha-geshem*—no rain.

"''If the family of Egypt go not up, and come not, they shall have no overflow.''"

*Ve-im-mishpachat Mitzrayim lo-ta'aleh ve-lo va'ah ve-lo aleihem*—Egypt.

"''There shall be the plague.''"

*Tihyeh ha-maggefah*—plague.

"''This shall be the punishment of Egypt, and the punishment of all the nations.''"

*Zot tihyeh chattat Mitzrayim ve-chattat kol-ha-goyim*—punishment.

**The Key Verses (14:20-21):**
"''In that day shall there be upon the bells of the horses: HOLY UNTO YHWH.''"

*Ba-yom ha-hu yihyeh al-metzillot ha-sus Qodesh la-YHWH*—horses holy.

"''The pots in YHWH's house shall be like the basins before the altar.''"

*Ve-hayah ha-sirot be-veit YHWH ka-mizraqim lifnei ha-mizbe'ach*—pots like basins.

"''Every pot in Jerusalem and in Judah shall be holy unto YHWH of hosts.''"

*Ve-hayah kol-sir bi-Yrushalayim u-vi-Yhudah qodesh la-YHWH tzeva'ot*—all pots holy.

"''All they that sacrifice shall come and take of them, and seethe therein.''"

*U-va'u kol-ha-zovechim ve-laqchu mehem u-vishlu vahem*—sacrifice.

"''In that day there shall be no more a trafficker in the house of YHWH of hosts.''"

*Ve-lo-yihyeh kena'ani od be-veit-YHWH tzeva'ot ba-yom ha-hu*—no trafficker.

**Kena'ani:**
"Canaanite" or "trader/trafficker"—no commerce in the temple.

**Archetypal Layer:** Zechariah 14 is the **eschatological climax**, containing **"I will gather all nations against Jerusalem to battle" (14:2)**, **"YHWH go forth, and fight against those nations" (14:3)**, **"his feet shall stand in that day upon the mount of Olives" (14:4)**, **the Mount of Olives splitting (14:4)**, **"YHWH my God shall come, and all the holy ones with you" (14:5)**, **"at evening time there shall be light" (14:7)**, **"living waters shall go out from Jerusalem" (14:8)**, **"YHWH shall be King over all the earth; in that day shall YHWH be One, and his name One" (14:9)**, **"there shall be no more curse; but Jerusalem shall dwell safely" (14:11)**, **nations coming to keep the feast of tabernacles (14:16)**, **no rain for those who don't come (14:17)**, **"upon the bells of the horses: HOLY UNTO YHWH" (14:20)**, **"every pot in Jerusalem and in Judah shall be holy" (14:21)**, and **"there shall be no more a trafficker in the house of YHWH" (14:21)**.

**Ethical Inversion Applied:**
- "'Behold, a day of YHWH comes'"—day of YHWH
- "'Your spoil shall be divided'"—spoil
- "''I will gather all nations against Jerusalem''"—gather nations
- "''The city shall be taken''"—taken
- "''Half of the city shall go forth into captivity''"—captivity
- "''The residue... shall not be cut off''"—residue remains
- "''YHWH go forth, and fight against those nations''"—YHWH fights
- "''His feet shall stand... upon the mount of Olives''"—Mount of Olives
- "''The mount of Olives shall be cleft''"—cleft
- "''There shall be a very great valley''"—valley
- "''You shall flee to the valley''"—flee
- "''Like as you fled from before the earthquake''"—earthquake
- "''YHWH my God shall come, and all the holy ones with you''"—YHWH comes
- "''There shall not be light, but heavy clouds''"—no light
- "''There shall be one day which shall be known as YHWH's''"—YHWH's day
- "''At evening time there shall be light''"—light at evening
- "''Living waters shall go out from Jerusalem''"—living waters
- "''Half of them toward the eastern sea, and half of them toward the western sea''"—both seas
- "''In summer and in winter shall it be''"—year-round
- "''YHWH shall be King over all the earth''"—King over all
- "''In that day shall YHWH be One, and his name One''"—YHWH One
- "''All the land shall be turned as the Arabah''"—flat
- "''She shall be lifted up, and inhabited''"—lifted
- "''There shall be no more curse''"—no curse
- "''Jerusalem shall dwell safely''"—safely
- "''This shall be the plague''"—plague
- "''Their flesh shall consume away while they stand''"—consume
- "''A great tumult from YHWH shall be among them''"—tumult
- "''The wealth of all the nations... shall be gathered''"—wealth
- "''Every one that is left of all the nations... shall go up... to worship the King''"—worship
- "''To keep the feast of tabernacles''"—Sukkot
- "''Upon them there shall be no rain''"—no rain
- "''In that day shall there be upon the bells of the horses: HOLY UNTO YHWH''"—horses holy
- "''The pots in YHWH's house shall be like the basins before the altar''"—pots holy
- "''Every pot in Jerusalem and in Judah shall be holy''"—all holy
- "''There shall be no more a trafficker in the house of YHWH''"—no trafficker

**Modern Equivalent:** Zechariah 14 is the grand finale. Nations gather against Jerusalem, the city is taken, but YHWH intervenes—His feet on the Mount of Olives, which splits. "YHWH shall be King over all the earth; in that day shall YHWH be One, and his name One" (14:9) is universal monotheism. Living waters flow from Jerusalem (14:8). Surviving nations must keep Sukkot (14:16). The holiness spreads: even horses' bells say "HOLY UNTO YHWH" (14:20), every pot is holy (14:21). No more traffickers in the temple—pure worship.

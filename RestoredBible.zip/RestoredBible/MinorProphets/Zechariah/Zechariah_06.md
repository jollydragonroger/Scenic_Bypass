# Zechariah 6: The Four Chariots and the Crowning of Joshua

*From the Hebrew: וָאָשֻׁב וָאֶשָּׂא עֵינַי וָאֶרְאֶה (Va-Ashuv Va-Essa Einai Va-Er'eh) — And Again I Lifted Up My Eyes, and Saw*

---

## Eighth Vision: The Four Chariots (6:1-8)

**6:1** And again I lifted up my eyes, and saw, and behold, there came four chariots out from between the two mountains; and the mountains were mountains of brass.

**6:2** In the first chariot were red horses; and in the second chariot black horses;

**6:3** And in the third chariot white horses; and in the fourth chariot grizzled bay horses.

**6:4** Then I answered and said unto the angel that spoke with me: "What are these, my lord?"

**6:5** And the angel answered and said unto me: "These are the four winds of heaven, which go forth from standing before the Lord of all the earth.

**6:6** "The chariot wherein are the black horses goes forth toward the north country; and the white go forth after them; and the grizzled go forth toward the south country."

**6:7** And the bay went forth, and sought to go that they might walk to and fro through the earth; and he said: "Get you hence, walk to and fro through the earth." So they walked to and fro through the earth.

**6:8** Then cried he upon me, and spoke unto me, saying: "Behold, these that go toward the north country have caused my spirit to rest in the north country."

---

## The Crowning of Joshua (6:9-15)

**6:9** And the word of YHWH came unto me, saying:

**6:10** "Take of them of the captivity, even of Heldai, of Tobijah, and of Jedaiah, that are come from Babylon, and go the same day, and go into the house of Josiah the son of Zephaniah;

**6:11** "Yea, take silver and gold, and make crowns, and set the one upon the head of Joshua the son of Jehozadak, the high priest;

**6:12** "And speak unto him, saying: 'Thus speaks YHWH of hosts, saying: Behold, a man whose name is the Branch, and who shall grow up out of his place, and he shall build the temple of YHWH;

**6:13** "'Yea, he shall build the temple of YHWH; and he shall bear the glory, and shall sit and rule upon his throne; and he shall be a priest upon his throne; and the counsel of peace shall be between them both.'

**6:14** "And the crowns shall be to Helem, and to Tobijah, and to Jedaiah, and to Hen the son of Zephaniah, for a memorial in the temple of YHWH.

**6:15** "And they that are far off shall come and build in the temple of YHWH, and you shall know that YHWH of hosts has sent me unto you. And it shall come to pass, if you will diligently hearken to the voice of YHWH your God—"

---

## Synthesis Notes

**Key Restorations:**

**Eighth Vision (6:1-8):**
**The Key Verses (6:1-3):**
"'I lifted up my eyes, and saw, and behold, there came four chariots.'"

*Va-ashuv va-essa einai va-er'eh ve-hinneh arba merkavot*—four chariots.

"'Out from between the two mountains.'"

*Yotz'ot mi-bein shenei he-harim*—between mountains.

"'The mountains were mountains of brass.'"

*Ve-he-harim harei nechoshet*—brass mountains.

"'In the first chariot were red horses.'"

*Ba-merkavah ha-rishonah susim adummim*—red.

"'In the second chariot black horses.'"

*U-va-merkavah ha-shenit susim sheחorim*—black.

"'In the third chariot white horses.'"

*U-va-merkavah ha-shelishit susim levanim*—white.

"'In the fourth chariot grizzled bay horses.'"

*U-va-merkavah ha-revi'it susim beruddim amutztzim*—grizzled.

**The Key Verses (6:4-8):**
"''What are these, my lord?''"

*Mah-elleh adoni*—what?

"''These are the four winds of heaven.''"

*Elleh arba ruchot ha-shamayim*—four winds.

"''Which go forth from standing before the Lord of all the earth.''"

*Yotz'ot me-hityatztzev al-Adon kol-ha-aretz*—before Lord.

"''The chariot wherein are the black horses goes forth toward the north country.''"

*Asher-bah ha-susim ha-shechhorim yotz'im el-eretz tzafon*—north.

"''The white go forth after them.''"

*Ve-ha-levanim yatz'u el-achareihem*—after.

"''The grizzled go forth toward the south country.''"

*Ve-ha-beruddim yatz'u el-eretz ha-teiman*—south.

"''The bay went forth, and sought to go that they might walk to and fro through the earth.''"

*Ve-ha-amutztzim yatz'u va-yevaqshu lalekhet le-hitהallekh ba-aretz*—walk earth.

"''Get you hence, walk to and fro through the earth.''"

*Lekhu hithalekhu va-aretz*—walk.

"''So they walked to and fro through the earth.''"

*Va-tithalakhnah ba-aretz*—walked.

"''These that go toward the north country have caused my spirit to rest in the north country.''"

*Ha-yotz'im el-eretz tzafon henichu et-ruchi be-eretz tzafon*—spirit rests.

**Crowning of Joshua (6:9-15):**
**The Key Verses (6:9-11):**
"'The word of YHWH came unto me.'"

*Va-yehi devar-YHWH elai*—word came.

"''Take of them of the captivity.''"

*Laqoach me-et ha-golah*—from captivity.

"''Even of Heldai, of Tobijah, and of Jedaiah.''"

*Me-et Cheldai u-me-et Toviyyah u-me-et Yeda'yah*—names.

"''That are come from Babylon.''"

*Asher-ba'u mi-Bavel*—from Babylon.

"''Go into the house of Josiah the son of Zephaniah.''"

*U-vata attah ba-yom ha-hu u-vata beit Yoshiyyahu ven-Tzefanyah*—Josiah's house.

"''Take silver and gold, and make crowns.''"

*Ve-laqachta khesef ve-zahav ve-asita atarot*—make crowns.

"''Set the one upon the head of Joshua the son of Jehozadak, the high priest.''"

*Ve-samta be-rosh Yehoshua ven-Yehotzadק ha-kohen ha-gadol*—crown Joshua.

**The Key Verses (6:12-13):**
"''Behold, a man whose name is the Branch.''"

*Hinneh-ish Tzemach shemo*—Branch.

"''Who shall grow up out of his place.''"

*U-mi-tachtav yitzmach*—grow up.

"''He shall build the temple of YHWH.''"

*Ve-vanah et-heikhal YHWH*—build temple.

"''Yea, he shall build the temple of YHWH.''"

*Ve-hu yivneh et-heikhal YHWH*—build temple.

"''He shall bear the glory.''"

*Ve-hu yissa hod*—bear glory.

"''Shall sit and rule upon his throne.''"

*Ve-yashav u-mashal al-kis'o*—sit, rule.

"''He shall be a priest upon his throne.''"

*Ve-hayah kohen al-kis'o*—priest on throne.

**Priest on Throne:**
Uniting royal and priestly offices—messianic.

"''The counsel of peace shall be between them both.''"

*Va-atzat shalom tihyeh bein sheneihem*—counsel of peace.

**The Key Verses (6:14-15):**
"''The crowns shall be... for a memorial in the temple of YHWH.''"

*Ve-ha-atarot tihyeh... le-zikkaron be-heikhal YHWH*—memorial.

"''They that are far off shall come and build in the temple of YHWH.''"

*U-rechoqim yavo'u u-vanu be-heikhal YHWH*—far off build.

"''You shall know that YHWH of hosts has sent me unto you.''"

*Vi-yda'tem ki-YHWH tzeva'ot shelachani aleikhem*—sent.

"''If you will diligently hearken to the voice of YHWH your God—''"

*Ve-hayah im-shamoa tishme'un be-qol YHWH Eloheikhem*—if hearken.

**Archetypal Layer:** Zechariah 6 contains **the eighth vision: four chariots from between two bronze mountains (6:1-8)**, **"These are the four winds of heaven, which go forth from standing before the Lord of all the earth" (6:5)**, **chariots going north and south (6:6)**, **"these that go toward the north country have caused my spirit to rest in the north country" (6:8)**, **the symbolic crowning of Joshua (6:9-15)**, **"Behold, a man whose name is the Branch, and who shall grow up out of his place, and he shall build the temple of YHWH" (6:12)**, **"he shall bear the glory, and shall sit and rule upon his throne; and he shall be a priest upon his throne" (6:13)**—uniting king and priest, **"the counsel of peace shall be between them both" (6:13)**, and **"they that are far off shall come and build in the temple" (6:15)**.

**Ethical Inversion Applied:**
- "'I lifted up my eyes, and saw... four chariots'"—four chariots
- "'Out from between the two mountains'"—between mountains
- "'The mountains were mountains of brass'"—brass
- "'In the first chariot were red horses'"—red
- "'In the second chariot black horses'"—black
- "'In the third chariot white horses'"—white
- "'In the fourth chariot grizzled bay horses'"—grizzled
- "''What are these, my lord?''"—question
- "''These are the four winds of heaven''"—four winds
- "''Which go forth from standing before the Lord of all the earth''"—before Lord
- "''The black horses goes forth toward the north country''"—north
- "''The white go forth after them''"—after
- "''The grizzled go forth toward the south country''"—south
- "''Walk to and fro through the earth''"—walk
- "''These... have caused my spirit to rest in the north country''"—spirit rests
- "'Take of them of the captivity'"—from captivity
- "'That are come from Babylon'"—from Babylon
- "''Take silver and gold, and make crowns''"—crowns
- "''Set the one upon the head of Joshua''"—crown Joshua
- "''Behold, a man whose name is the Branch''"—Branch
- "''Who shall grow up out of his place''"—grow
- "''He shall build the temple of YHWH''"—build temple
- "''He shall bear the glory''"—glory
- "''Shall sit and rule upon his throne''"—rule
- "''He shall be a priest upon his throne''"—priest on throne
- "''The counsel of peace shall be between them both''"—peace
- "''The crowns shall be... for a memorial''"—memorial
- "''They that are far off shall come and build''"—far off build
- "'You shall know that YHWH of hosts has sent me'"—sent
- "''If you will diligently hearken''"—if hearken

**Modern Equivalent:** Zechariah 6 concludes the night visions with four chariots (divine agents) patrolling the earth. The crowning of Joshua (6:9-15) is symbolically messianic: "the Branch" will build the temple, bear glory, and be "a priest upon his throne" (6:13)—uniting royal and priestly roles in one figure. "They that are far off shall come and build" (6:15) anticipates Gentile participation.

# Zechariah 1: Call to Return and the Night Visions Begin

*From the Hebrew: בַּחֹדֶשׁ הַשְּׁמִינִי בִּשְׁנַת שְׁתַּיִם לְדָרְיָוֶשׁ (Ba-Chodesh Ha-Shemini Bi-Shenat Shetayim Le-Daryavesh) — In the Eighth Month, in the Second Year of Darius*

---

## Call to Return (1:1-6)

**1:1** In the eighth month, in the second year of Darius, came the word of YHWH unto Zechariah the son of Berechiah, the son of Iddo, the prophet, saying:

**1:2** YHWH was sore displeased with your fathers.

**1:3** Therefore say unto them: Thus says YHWH of hosts: Return unto me, says YHWH of hosts, and I will return unto you, says YHWH of hosts.

**1:4** Be not as your fathers, unto whom the former prophets proclaimed, saying: "Thus says YHWH of hosts: Return now from your evil ways, and from your evil doings"; but they did not hear, nor attend unto me, says YHWH.

**1:5** Your fathers, where are they? And the prophets, do they live for ever?

**1:6** But my words and my statutes, which I commanded my servants the prophets, did they not overtake your fathers? So they turned and said: "Like as YHWH of hosts purposed to do unto us, according to our ways, and according to our doings, so has he dealt with us."

---

## First Vision: The Horsemen (1:7-17)

**1:7** Upon the four and twentieth day of the eleventh month, which is the month Shebat, in the second year of Darius, came the word of YHWH unto Zechariah the son of Berechiah, the son of Iddo, the prophet, saying:

**1:8** I saw in the night, and behold a man riding upon a red horse, and he stood among the myrtle-trees that were in the bottom; and behind him there were horses, red, sorrel, and white.

**1:9** Then said I: "O my lord, what are these?" And the angel that spoke with me said unto me: "I will show you what these are."

**1:10** And the man that stood among the myrtle-trees answered and said: "These are they whom YHWH has sent to walk to and fro through the earth."

**1:11** And they answered the angel of YHWH that stood among the myrtle-trees, and said: "We have walked to and fro through the earth, and, behold, all the earth sits still, and is at rest."

**1:12** Then the angel of YHWH answered and said: "O YHWH of hosts, how long will you not have compassion on Jerusalem and on the cities of Judah, against which you have had indignation these threescore and ten years?"

**1:13** And YHWH answered the angel that spoke with me with good words, even comforting words.

**1:14** So the angel that spoke with me said unto me: "Proclaim, saying: Thus says YHWH of hosts: I am jealous for Jerusalem and for Zion with a great jealousy.

**1:15** "And I am very sore displeased with the nations that are at ease; for I was but a little displeased, and they helped forward the affliction.

**1:16** "Therefore thus says YHWH: I return to Jerusalem with compassions: my house shall be built in it, says YHWH of hosts, and a line shall be stretched forth over Jerusalem.

**1:17** "Proclaim yet again, saying: Thus says YHWH of hosts: My cities shall again overflow with prosperity; and YHWH shall yet comfort Zion, and shall yet choose Jerusalem."

---

## Second Vision: The Four Horns and Four Craftsmen (1:18-21)

**1:18** And I lifted up my eyes, and saw, and behold four horns.

**1:19** And I said unto the angel that spoke with me: "What are these?" And he said unto me: "These are the horns which have scattered Judah, Israel, and Jerusalem."

**1:20** And YHWH showed me four craftsmen.

**1:21** Then said I: "What come these to do?" And he spoke, saying: "These are the horns which scattered Judah, so that no man did lift up his head; but these are come to terrify them, to cast down the horns of the nations, which lifted up their horn against the land of Judah to scatter it."

---

## Synthesis Notes

**Key Restorations:**

**Call to Return (1:1-6):**
**The Key Verse (1:1):**
"In the eighth month, in the second year of Darius."

*Ba-chodesh ha-shemini bi-shenat shetayim le-Daryavesh*—October/November 520 BCE.

"Came the word of YHWH unto Zechariah the son of Berechiah, the son of Iddo."

*Hayah devar-YHWH el-Zekharyah ben-Berekhyah ben-Iddo ha-navi*—Zechariah.

**Zekharyah:**
"YHWH remembers."

**The Key Verses (1:2-4):**
"'YHWH was sore displeased with your fathers.'"

*Qatzaf YHWH al-avoteikhem qatzef*—displeased.

"''Return unto me,' says YHWH of hosts, 'and I will return unto you.''"

*Shuvu elai ne'um YHWH tzeva'ot ve-ashuv aleikhem*—return, I'll return.

"'Be not as your fathers, unto whom the former prophets proclaimed.'"

*Al-tihyu ka-avoteikhem asher qare'u aleihem ha-nevi'im ha-rishonim*—not like fathers.

"''Return now from your evil ways, and from your evil doings.''"

*Shuvu-na mi-darkheikhem ha-ra'im u-me-alilotekhem ha-ra'im*—return.

"'But they did not hear, nor attend unto me.'"

*Ve-lo sham'u ve-lo-hiqshivu elai*—didn't hear.

**The Key Verses (1:5-6):**
"'Your fathers, where are they?'"

*Avoteikhem ayyeh-hem*—where are fathers?

"'The prophets, do they live for ever?'"

*Ve-ha-nevi'im ha-le-olam yichyu*—prophets live forever?

"'My words and my statutes... did they not overtake your fathers?'"

*Akh devarai ve-chuqqai... ha-lo hissigu avoteikhem*—words overtook.

"'So they turned and said: Like as YHWH of hosts purposed to do unto us... so has he dealt with us.'"

*Va-yashuvu va-yomeru ka-asher zamam YHWH tzeva'ot la'asot lanu... ken asah ittanu*—admitted.

**First Vision (1:7-17):**
**The Key Verses (1:7-8):**
"Upon the four and twentieth day of the eleventh month, which is the month Shebat."

*Be-yom esrim ve-arba'ah la-ashtei-asar chodesh hu-chodesh Shevat*—February 519 BCE.

"'I saw in the night, and behold a man riding upon a red horse.'"

*Ra'iti ha-laylah ve-hinneh ish rokhev al-sus adom*—red horse.

"'He stood among the myrtle-trees that were in the bottom.'"

*Ve-hu omed bein ha-hadassim asher ba-metzulah*—myrtle trees.

"'Behind him there were horses, red, sorrel, and white.'"

*Ve-acharav susim adummim seruqqim u-levanim*—horses.

**The Key Verses (1:9-11):**
"''O my lord, what are these?''"

*Mah-elleh adoni*—what are these?

"'The angel that spoke with me said unto me: I will show you what these are.'"

*Va-yomer elai ha-mal'akh ha-dover bi ani ar'ekha mah-hemmah elleh*—will show.

"'These are they whom YHWH has sent to walk to and fro through the earth.'"

*Elleh asher shalach YHWH le-hitהallekh ba-aretz*—patrol earth.

"'We have walked to and fro through the earth, and, behold, all the earth sits still, and is at rest.'"

*Hithalakhnu va-aretz ve-hinneh khol-ha-aretz yoshevet ve-shoqetet*—earth at rest.

**The Key Verses (1:12-17):**
"'O YHWH of hosts, how long will you not have compassion on Jerusalem?'"

*YHWH tzeva'ot ad-matai attah lo-terachem et-Yerushalayim*—how long?

"'These threescore and ten years.'"

*Zeh shiv'im shanah*—70 years.

"'YHWH answered the angel... with good words, even comforting words.'"

*Va-ya'an YHWH... devarim tovim devarim nichumim*—comforting words.

"''I am jealous for Jerusalem and for Zion with a great jealousy.''"

*Qinneiti li-Yrushalayim u-le-Tziyon qin'ah gedolah*—jealous.

"''I am very sore displeased with the nations that are at ease.''"

*Ve-qetzef gadol ani qotzef al-ha-goyim ha-sha'anannim*—displeased with nations.

"''I was but a little displeased, and they helped forward the affliction.''"

*Asher ani qatzafti me'at ve-hemmah azeru le-ra'ah*—overdid punishment.

"''I return to Jerusalem with compassions.''"

*Shavti li-Yrushalayim be-rachamim*—return with compassion.

"''My house shall be built in it.''"

*Beiti yibbaneh-bah*—house built.

"''A line shall be stretched forth over Jerusalem.''"

*Ve-qav yinnateh al-Yerushalayim*—measuring line.

"''My cities shall again overflow with prosperity.''"

*Od tafutzנah arai mi-tov*—overflow.

"''YHWH shall yet comfort Zion, and shall yet choose Jerusalem.''"

*Ve-nicham YHWH od et-Tziyon u-vachar od bi-Yrushalayim*—comfort, choose.

**Second Vision (1:18-21):**
**The Key Verses (1:18-21):**
"'I lifted up my eyes, and saw, and behold four horns.'"

*Va-essa et-einai va-ere ve-hinneh arba qeranot*—four horns.

"''What are these?''"

*Mah-elleh*—what?

"''These are the horns which have scattered Judah, Israel, and Jerusalem.''"

*Elleh ha-qeranot asher zeru et-Yehudah et-Yisra'el vi-Yrushalayim*—scattered.

"'YHWH showed me four craftsmen.'"

*Va-yar'eni YHWH arba'ah charashim*—four craftsmen.

"''What come these to do?''"

*Mah elleh ba'im la'asot*—to do what?

"''These are the horns which scattered Judah.''"

*Elleh ha-qeranot asher-zeru et-Yehudah*—scattered Judah.

"''So that no man did lift up his head.''"

*Le-fi ish lo-nasa rosho*—couldn't lift head.

"''These are come to terrify them, to cast down the horns of the nations.''"

*Va-yavo'u elleh le-hacharid otam le-yadot et-qarnot ha-goyim*—cast down.

**Archetypal Layer:** Zechariah 1 contains **"Return unto me... and I will return unto you" (1:3)**, **"Be not as your fathers" (1:4)**, **"Your fathers, where are they? And the prophets, do they live for ever?" (1:5)**, **the first night vision: horsemen among myrtle trees (1:7-17)**, **"all the earth sits still, and is at rest" (1:11)**, **"how long will you not have compassion on Jerusalem... these threescore and ten years?" (1:12)**, **"I am jealous for Jerusalem and for Zion with a great jealousy" (1:14)**, **"I am very sore displeased with the nations that are at ease; for I was but a little displeased, and they helped forward the affliction" (1:15)**, **"I return to Jerusalem with compassions" (1:16)**, **the second vision: four horns and four craftsmen (1:18-21)**.

**Ethical Inversion Applied:**
- "In the eighth month, in the second year of Darius"—dated
- "Came the word of YHWH unto Zechariah"—to Zechariah
- "'YHWH was sore displeased with your fathers'"—displeased
- "''Return unto me... and I will return unto you''"—mutual return
- "'Be not as your fathers'"—not like fathers
- "''Return now from your evil ways''"—return
- "'They did not hear, nor attend unto me'"—didn't hear
- "'Your fathers, where are they?'"—where
- "'The prophets, do they live for ever?'"—prophets mortal
- "'My words and my statutes... did they not overtake your fathers?'"—overtook
- "'So they turned and said'"—admitted
- "'I saw in the night, and behold a man riding upon a red horse'"—red horse
- "'He stood among the myrtle-trees'"—myrtle trees
- "'Behind him there were horses, red, sorrel, and white'"—horses
- "''What are these?''"—question
- "'These are they whom YHWH has sent to walk to and fro'"—patrol
- "'All the earth sits still, and is at rest'"—at rest
- "'How long will you not have compassion on Jerusalem?'"—how long
- "'These threescore and ten years'"—70 years
- "'YHWH answered... with good words, even comforting words'"—comfort
- "''I am jealous for Jerusalem''"—jealous
- "''I am very sore displeased with the nations that are at ease''"—displeased
- "''They helped forward the affliction''"—overdid it
- "''I return to Jerusalem with compassions''"—return
- "''My house shall be built''"—house built
- "''A line shall be stretched forth over Jerusalem''"—measuring line
- "''My cities shall again overflow with prosperity''"—overflow
- "''YHWH shall yet comfort Zion''"—comfort
- "'I lifted up my eyes, and saw... four horns'"—four horns
- "'These are the horns which have scattered Judah'"—scattered
- "'YHWH showed me four craftsmen'"—craftsmen
- "'These are come to terrify them, to cast down the horns'"—cast down

**Modern Equivalent:** Zechariah 1 introduces the prophet and his night visions. The call to return (1:3) is reciprocal—"Return unto me... and I will return unto you." The first vision shows YHWH's patrol finding earth at rest while Jerusalem suffers (1:11-12). YHWH's response: jealousy for Zion, anger at nations who overdid punishment (1:15), and promise to return with compassion (1:16). The four horns (1:18-21) representing oppressing nations will be cast down by four craftsmen.

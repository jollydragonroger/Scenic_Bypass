# Zechariah 12: Jerusalem a Cup of Reeling

*From the Hebrew: מַשָּׂא דְבַר־יְהוָה עַל־יִשְׂרָאֵל (Massa Devar-YHWH Al-Yisra'el) — The Burden of the Word of YHWH Concerning Israel*

---

## Jerusalem Besieged and Delivered (12:1-9)

**12:1** The burden of the word of YHWH concerning Israel. The saying of YHWH, who stretches forth the heavens, and lays the foundation of the earth, and forms the spirit of man within him:

**12:2** "Behold, I will make Jerusalem a cup of reeling unto all the peoples round about, and upon Judah also shall it fall to be in the siege against Jerusalem.

**12:3** "And it shall come to pass in that day, that I will make Jerusalem a stone of burden for all the peoples; all that burden themselves with it shall be sore wounded; and all the nations of the earth shall be gathered together against it.

**12:4** "In that day," says YHWH, "I will smite every horse with bewilderment, and his rider with madness; and I will open my eyes upon the house of Judah, and will smite every horse of the peoples with blindness.

**12:5** "And the chiefs of Judah shall say in their heart: 'The inhabitants of Jerusalem are my strength through YHWH of hosts their God.'

**12:6** "In that day will I make the chiefs of Judah like a pan of fire among wood, and like a torch of fire among sheaves; and they shall devour all the peoples round about, on the right hand and on the left; and Jerusalem shall be inhabited again in her own place, even in Jerusalem.

**12:7** "YHWH also shall save the tents of Judah first, that the glory of the house of David and the glory of the inhabitants of Jerusalem be not magnified above Judah.

**12:8** "In that day shall YHWH defend the inhabitants of Jerusalem; and he that stumbles among them at that day shall be as David; and the house of David shall be as a godlike being, as the angel of YHWH before them.

**12:9** "And it shall come to pass in that day, that I will seek to destroy all the nations that come against Jerusalem."

---

## Mourning for the Pierced One (12:10-14)

**12:10** "And I will pour upon the house of David, and upon the inhabitants of Jerusalem, the spirit of grace and of supplication; and they shall look unto me whom they have pierced; and they shall mourn for him, as one mourns for his only son, and shall be in bitterness for him, as one that is in bitterness for his first-born.

**12:11** "In that day shall there be a great mourning in Jerusalem, as the mourning of Hadadrimmon in the valley of Megiddon.

**12:12** "And the land shall mourn, every family apart: the family of the house of David apart, and their wives apart; the family of the house of Nathan apart, and their wives apart;

**12:13** "The family of the house of Levi apart, and their wives apart; the family of the Shimeites apart, and their wives apart;

**12:14** "All the families that remain, every family apart, and their wives apart."

---

## Synthesis Notes

**Key Restorations:**

**Jerusalem Besieged and Delivered (12:1-9):**
**The Key Verse (12:1):**
"'The burden of the word of YHWH concerning Israel.'"

*Massa devar-YHWH al-Yisra'el*—burden concerning Israel.

"'The saying of YHWH, who stretches forth the heavens.'"

*Ne'um YHWH noteh shamayim*—stretches heavens.

"'Lays the foundation of the earth.'"

*Ve-yosed aretz*—lays foundation.

"'Forms the spirit of man within him.'"

*Ve-yotzer ruach-adam be-qirbo*—forms spirit.

**The Key Verses (12:2-3):**
"''I will make Jerusalem a cup of reeling unto all the peoples round about.''"

*Hineni sam et-Yerushalayim saf-ra'al le-khol-ha-ammim saviv*—cup of reeling.

**Saf-Ra'al:**
"Cup of reeling/staggering"—intoxicating, disorienting.

"''Upon Judah also shall it fall to be in the siege against Jerusalem.''"

*Ve-gam al-Yehudah yihyeh va-matzor al-Yerushalayim*—siege.

"''I will make Jerusalem a stone of burden for all the peoples.''"

*Asamti et-Yerushalayim even ma'amasah le-khol-ha-ammim*—stone of burden.

"''All that burden themselves with it shall be sore wounded.''"

*Kol-omeseiha sarot yissaretu*—wounded.

"''All the nations of the earth shall be gathered together against it.''"

*Ve-ne'esfu aleiha kol goyei ha-aretz*—nations gather.

**The Key Verses (12:4-6):**
"''In that day... I will smite every horse with bewilderment.''"

*Ba-yom ha-hu... akkeh khol-sus ba-timmahon*—bewilderment.

"''His rider with madness.''"

*Ve-rokhevo ba-shigga'on*—madness.

"''I will open my eyes upon the house of Judah.''"

*Ve-al-beit Yehudah eftach et-einai*—open eyes.

"''Will smite every horse of the peoples with blindness.''"

*Ve-khol sus ha-ammim akkeh ba-ivvaron*—blindness.

"''The chiefs of Judah shall say in their heart.''"

*Ve-ameru allufei Yehudah be-libbam*—chiefs say.

"''The inhabitants of Jerusalem are my strength through YHWH of hosts their God.''"

*Amtzah li yoshevei Yerushalayim ba-YHWH tzeva'ot Eloheihem*—strength.

"''In that day will I make the chiefs of Judah like a pan of fire among wood.''"

*Ba-yom ha-hu asim et-allufei Yehudah ke-kiyyor esh be-etzim*—fire pan.

"''Like a torch of fire among sheaves.''"

*U-khe-lappid esh be-amir*—torch.

"''They shall devour all the peoples round about.''"

*Ve-akhelu al-yamin ve-al-semol et-kol-ha-ammim saviv*—devour.

"''Jerusalem shall be inhabited again in her own place, even in Jerusalem.''"

*Ve-yashvah Yerushalayim od tachteiha bi-Yrushalayim*—inhabited.

**The Key Verses (12:7-9):**
"''YHWH also shall save the tents of Judah first.''"

*Ve-hoshi'a YHWH et-ohalei Yehudah ba-rishonah*—save Judah first.

"''That the glory of the house of David... be not magnified above Judah.''"

*Lema'an lo-tigdal tif'eret beit-David... al-Yehudah*—not above Judah.

"''In that day shall YHWH defend the inhabitants of Jerusalem.''"

*Ba-yom ha-hu yagen YHWH be'ad yoshev Yerushalayim*—defend.

"''He that stumbles among them at that day shall be as David.''"

*Ve-hayah ha-nikhshal bahem ba-yom ha-hu ke-David*—like David.

"''The house of David shall be as a godlike being.''"

*U-veit David ke-Elohim*—godlike.

"''As the angel of YHWH before them.''"

*Ke-mal'akh YHWH lifneihem*—like angel.

"''I will seek to destroy all the nations that come against Jerusalem.''"

*Va-avaqqesh le-hashmid et-kol-ha-goyim ha-ba'im al-Yerushalayim*—destroy nations.

**Mourning for the Pierced One (12:10-14):**
**The Key Verse (12:10):**
"''I will pour upon the house of David... the spirit of grace and of supplication.''"

*Ve-shafakhti al-beit David ve-al yoshev Yerushalayim ruach chen ve-tachanunimים*—spirit of grace.

"''They shall look unto me whom they have pierced.''"

*Ve-hibbitu elai et asher-daqaru*—look on pierced one.

**Et Asher-Daqaru:**
"Whom they have pierced"—quoted in John 19:37.

"''They shall mourn for him, as one mourns for his only son.''"

*Ve-safedu alav ke-misped al-ha-yachid*—mourn as for only son.

"''Shall be in bitterness for him, as one that is in bitterness for his first-born.''"

*Ve-hamer alav ke-hamer al-ha-bekhor*—bitterness for firstborn.

**The Key Verses (12:11-14):**
"''In that day shall there be a great mourning in Jerusalem.''"

*Ba-yom ha-hu yigdal ha-misped bi-Yrushalayim*—great mourning.

"''As the mourning of Hadadrimmon in the valley of Megiddon.''"

*Ke-misped Hadadrimmon be-viq'at Megiddon*—Hadadrimmon.

**Hadadrimmon:**
Possibly mourning for Josiah at Megiddo (2 Chronicles 35:22-25).

"''The land shall mourn, every family apart.''"

*Ve-safedah ha-aretz mishpachot mishpachot levad*—families apart.

"''The family of the house of David apart, and their wives apart.''"

*Mishpachat beit-David levad u-nesheיhem levad*—David's family.

"''The family of the house of Nathan apart.''"

*Mishpachat beit-Natan levad*—Nathan's family.

"''The family of the house of Levi apart.''"

*Mishpachat beit-ha-Levi levad*—Levi's family.

"''The family of the Shimeites apart.''"

*Mishpachat ha-Shim'י levad*—Shimei's family.

"''All the families that remain, every family apart, and their wives apart.''"

*Kol ha-mishpachot ha-nish'arot mishpachot mishpachot levad u-nesheיhem levad*—all families.

**Archetypal Layer:** Zechariah 12 contains **"I will make Jerusalem a cup of reeling unto all the peoples round about" (12:2)**, **"I will make Jerusalem a stone of burden for all the peoples; all that burden themselves with it shall be sore wounded" (12:3)**, **"all the nations of the earth shall be gathered together against it" (12:3)**, **"In that day... I will smite every horse with bewilderment, and his rider with madness" (12:4)**, **"I will make the chiefs of Judah like a pan of fire among wood" (12:6)**, **"In that day shall YHWH defend the inhabitants of Jerusalem" (12:8)**, **"the house of David shall be as a godlike being, as the angel of YHWH" (12:8)**, **"I will pour upon the house of David... the spirit of grace and of supplication" (12:10)**, **"they shall look unto me whom they have pierced" (12:10)**—quoted in John 19:37, **"they shall mourn for him, as one mourns for his only son" (12:10)**, and **the detailed mourning by families (12:11-14)**.

**Ethical Inversion Applied:**
- "'The burden of the word of YHWH concerning Israel'"—burden
- "'YHWH, who stretches forth the heavens'"—stretches
- "'Lays the foundation of the earth'"—foundation
- "'Forms the spirit of man within him'"—forms spirit
- "''I will make Jerusalem a cup of reeling''"—cup of reeling
- "''I will make Jerusalem a stone of burden''"—stone of burden
- "''All that burden themselves with it shall be sore wounded''"—wounded
- "''All the nations of the earth shall be gathered together against it''"—nations gather
- "''I will smite every horse with bewilderment''"—bewilderment
- "''His rider with madness''"—madness
- "''I will open my eyes upon the house of Judah''"—open eyes
- "''The chiefs of Judah shall say... The inhabitants of Jerusalem are my strength''"—strength
- "''I will make the chiefs of Judah like a pan of fire''"—fire
- "''Like a torch of fire among sheaves''"—torch
- "''They shall devour all the peoples round about''"—devour
- "''Jerusalem shall be inhabited again''"—inhabited
- "''YHWH also shall save the tents of Judah first''"—save first
- "''In that day shall YHWH defend the inhabitants of Jerusalem''"—defend
- "''He that stumbles among them... shall be as David''"—like David
- "''The house of David shall be as a godlike being''"—godlike
- "''I will seek to destroy all the nations that come against Jerusalem''"—destroy
- "''I will pour... the spirit of grace and of supplication''"—spirit of grace
- "''They shall look unto me whom they have pierced''"—pierced
- "''They shall mourn for him, as one mourns for his only son''"—mourn
- "''Shall be in bitterness for him, as... for his first-born''"—bitterness
- "''In that day shall there be a great mourning in Jerusalem''"—great mourning
- "''As the mourning of Hadadrimmon in the valley of Megiddon''"—Megiddo
- "''The land shall mourn, every family apart''"—families mourn

**Modern Equivalent:** Zechariah 12 is eschatological. Jerusalem becomes both a "cup of reeling" and a "stone of burden"—nations who attack her will stagger and be wounded. YHWH defends Jerusalem supernaturally. The climax (12:10) is deeply messianic: "they shall look unto me whom they have pierced"—John 19:37 applies this to Jesus. The mourning for the pierced one "as one mourns for his only son" is intense and private, family by family.

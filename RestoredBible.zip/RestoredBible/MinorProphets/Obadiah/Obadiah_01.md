# Obadiah 1: Oracle Against Edom

*From the Hebrew: חֲזוֹן עֹבַדְיָה (Chazon Ovadyah) — The Vision of Obadiah*

---

## Title and Summons (1:1)

**1:1** The vision of Obadiah. Thus says the Lord YHWH concerning Edom: We have heard a message from YHWH, and an ambassador is sent among the nations: "Arise, and let us rise up against her in battle."

---

## Edom's Pride and Fall (1:2-9)

**1:2** Behold, I make you small among the nations; you are greatly despised.

**1:3** The pride of your heart has deceived you, O you that dwell in the clefts of the rock, your habitation on high; that say in your heart: "Who shall bring me down to the ground?"

**1:4** Though you make your nest as high as the eagle, and though you set it among the stars, I will bring you down from thence, says YHWH.

**1:5** If thieves came to you, if robbers by night—how you are cut off!—would they not steal only till they had enough? If grape-gatherers came to you, would they not leave some gleaning grapes?

**1:6** How is Esau searched out! How are his hidden treasures sought out!

**1:7** All the men of your confederacy have conducted you to the border; the men that were at peace with you have deceived you, and prevailed against you; they that eat your bread lay a snare under you, in whom there is no understanding.

**1:8** Shall I not in that day, says YHWH, destroy the wise men out of Edom, and understanding out of the mount of Esau?

**1:9** And your mighty men, O Teman, shall be dismayed, to the end that every one may be cut off from the mount of Esau by slaughter.

---

## Edom's Sin Against Jacob (1:10-14)

**1:10** For the violence done to your brother Jacob shame shall cover you, and you shall be cut off for ever.

**1:11** In the day that you stood aloof, in the day that strangers carried away his substance, and foreigners entered into his gates, and cast lots upon Jerusalem, even you were as one of them.

**1:12** But you should not have looked on the day of your brother in the day of his disaster, neither should you have rejoiced over the children of Judah in the day of their destruction; neither should you have spoken proudly in the day of distress.

**1:13** You should not have entered into the gate of my people in the day of their calamity; yea, you should not have looked on their affliction in the day of their calamity, nor have laid hands on their substance in the day of their calamity.

**1:14** Neither should you have stood in the crossway, to cut off those of his that escape; neither should you have delivered up those of his that did remain in the day of distress.

---

## The Day of YHWH (1:15-21)

**1:15** For the day of YHWH is near upon all the nations; as you have done, it shall be done unto you; your dealing shall return upon your own head.

**1:16** For as you have drunk upon my holy mountain, so shall all the nations drink continually, yea, they shall drink, and swallow down, and shall be as though they had not been.

**1:17** But in mount Zion there shall be those that escape, and it shall be holy; and the house of Jacob shall possess their possessions.

**1:18** And the house of Jacob shall be a fire, and the house of Joseph a flame, and the house of Esau for stubble, and they shall kindle in them, and devour them; and there shall not be any remaining of the house of Esau; for YHWH has spoken.

**1:19** And they of the South shall possess the mount of Esau, and they of the Lowland the Philistines; and they shall possess the field of Ephraim, and the field of Samaria; and Benjamin shall possess Gilead.

**1:20** And the captivity of this host of the children of Israel, that are among the Canaanites, even unto Zarephath, and the captivity of Jerusalem, that is in Sepharad, shall possess the cities of the South.

**1:21** And saviours shall come up on mount Zion to judge the mount of Esau; and the kingdom shall be YHWH's.

---

## Synthesis Notes

**Key Restorations:**

**Title and Summons (1:1):**
**The Key Verse (1:1):**
"The vision of Obadiah."

*Chazon Ovadyah*—Obadiah's vision.

**Ovadyah:**
"Servant of YHWH."

"Thus says the Lord YHWH concerning Edom."

*Koh-amar Adonai YHWH le-Edom*—concerning Edom.

"We have heard a message from YHWH."

*Shemu'ah shama'nu me-et YHWH*—message heard.

"An ambassador is sent among the nations."

*Ve-tzir ba-goyim shullach*—ambassador sent.

"'Arise, and let us rise up against her in battle.'"

*Qumu ve-naqumah aleha la-milchamah*—rise for battle.

**Edom's Pride and Fall (1:2-9):**
**The Key Verses (1:2-4):**
"'Behold, I make you small among the nations.'"

*Hinneh qaton netattikha ba-goyim*—small.

"'You are greatly despised.'"

*Bazui attah me'od*—despised.

"'The pride of your heart has deceived you.'"

*Zedon libbeka hishi'ekha*—pride deceived.

"'O you that dwell in the clefts of the rock.'"

*Shokhenei be-chagvei-sela*—rock clefts.

**Sela:**
"Rock"—Petra, Edom's capital, carved in cliffs.

"'Your habitation on high.'"

*Merom shivto*—high dwelling.

"''Who shall bring me down to the ground?''"

*Mi yorideni aretz*—who'll bring me down?

"'Though you make your nest as high as the eagle.'"

*Im-tagbiha ka-nesher*—high as eagle.

"'Though you set it among the stars.'"

*Ve-im-bein kokhavim sim qinnekha*—among stars.

"'I will bring you down from thence.'"

*Mi-sham oridekha*—bring down.

**The Key Verses (1:5-7):**
"'If thieves came to you... would they not steal only till they had enough?'"

*Im-gannavim ba'u-lekha... ha-lo yignevu dayam*—thieves take enough.

"'If grape-gatherers came to you, would they not leave some gleaning grapes?'"

*Im-botzrim ba'u lakh ha-lo yash'iru olelot*—gleanings left.

"'How is Esau searched out! How are his hidden treasures sought out!'"

*Eikh nechpesu Esav niv'u matzpunav*—completely searched.

**Complete Destruction:**
Unlike thieves or grape-gatherers, Edom's enemies leave nothing.

"'All the men of your confederacy have conducted you to the border.'"

*Ad-ha-gevul shillchukha kol anshei veritekha*—allies betray.

"'The men that were at peace with you have deceived you.'"

*Hishi'ukha yakהelu lekha anshei shelomekha*—deceived by friends.

"'They that eat your bread lay a snare under you.'"

*Lachmekha yasimu mazor tachtekha*—bread companions trap.

"'In whom there is no understanding.'"

*Ein tevunah bo*—no understanding.

**The Key Verses (1:8-9):**
"''Shall I not in that day... destroy the wise men out of Edom?''"

*Ha-lo va-yom ha-hu... ve-ha'avadti chakhamim me-Edom*—destroy wise.

"'Understanding out of the mount of Esau.'"

*U-tevunah me-har Esav*—understanding gone.

"'Your mighty men, O Teman, shall be dismayed.'"

*Ve-chattu gibborekha Teiman*—Teman dismayed.

**Teman:**
Region of Edom, famous for wisdom (cf. Job's friend Eliphaz the Temanite).

"'Every one may be cut off from the mount of Esau by slaughter.'"

*Lema'an yikkaret-ish me-har Esav mi-qatel*—cut off.

**Edom's Sin Against Jacob (1:10-14):**
**The Key Verse (1:10):**
"'For the violence done to your brother Jacob.'"

*Me-chamas achikha Ya'aqov*—violence to brother.

"'Shame shall cover you.'"

*Tekassekha voshnah*—shame covers.

"'You shall be cut off for ever.'"

*Ve-nikhrata le-olam*—cut off forever.

**The Key Verses (1:11-14):**
"'In the day that you stood aloof.'"

*Be-yom amodekha mi-neged*—stood aloof.

"'In the day that strangers carried away his substance.'"

*Be-yom shevot zarim cheilo*—strangers took.

"'Foreigners entered into his gates.'"

*Ve-nokherim ba'u she'arav*—foreigners entered.

"'Cast lots upon Jerusalem.'"

*Ve-al-Yerushalayim yaddו goral*—cast lots.

"'Even you were as one of them.'"

*Gam-attah ke-achad mehem*—you were one of them.

"'You should not have looked on the day of your brother.'"

*Ve-al-tere be-yom achikha*—shouldn't have looked.

"'In the day of his disaster.'"

*Be-yom nokhro*—disaster day.

"'Neither should you have rejoiced over the children of Judah.'"

*Ve-al-tismach li-vnei Yehudah*—shouldn't rejoice.

"'In the day of their destruction.'"

*Be-yom obedam*—destruction day.

"'Neither should you have spoken proudly in the day of distress.'"

*Ve-al-tagdel pikha be-yom tzarah*—shouldn't boast.

"'You should not have entered into the gate of my people.'"

*Al-tavo ve-sha'ar-ammi*—shouldn't enter.

"'In the day of their calamity.'"

*Be-yom eidam*—calamity day.

"'Nor have laid hands on their substance.'"

*Ve-al-tishlachnah ve-cheilo*—shouldn't plunder.

"'Neither should you have stood in the crossway.'"

*Ve-al-ta'amod al-ha-pereq*—shouldn't block escape.

"'To cut off those of his that escape.'"

*Le-hakhrit et-pelitav*—cut off escapees.

"'Neither should you have delivered up those of his that did remain.'"

*Ve-al-tasger seridav*—shouldn't hand over.

"'In the day of distress.'"

*Be-yom tzarah*—distress day.

**Day of YHWH (1:15-21):**
**The Key Verses (1:15-16):**
"'For the day of YHWH is near upon all the nations.'"

*Ki-qarov yom-YHWH al-kol-ha-goyim*—day near.

"'As you have done, it shall be done unto you.'"

*Ka-asher asita ye'aseh lakh*—reciprocity.

"'Your dealing shall return upon your own head.'"

*Gemulekha yashuv be-roshekha*—return on head.

"'For as you have drunk upon my holy mountain.'"

*Ki ka-asher shetitem al-har qodshi*—drunk on mountain.

"'So shall all the nations drink continually.'"

*Yishtu khol-ha-goyim tamid*—nations drink.

"'They shall drink, and swallow down.'"

*Ve-shatu ve-la'u*—drink, swallow.

"'Shall be as though they had not been.'"

*Ve-hayu ke-lo hayu*—as if never were.

**The Key Verses (1:17-18):**
"'In mount Zion there shall be those that escape.'"

*U-ve-har Tziyon tihyeh peletah*—Zion escape.

"'It shall be holy.'"

*Ve-hayah qodesh*—holy.

"'The house of Jacob shall possess their possessions.'"

*Ve-yareshu beit-Ya'aqov et morashehem*—possess possessions.

"'The house of Jacob shall be a fire.'"

*Ve-hayah veit-Ya'aqov esh*—Jacob fire.

"'The house of Joseph a flame.'"

*U-veit Yosef lehavah*—Joseph flame.

"'The house of Esau for stubble.'"

*U-veit Esav le-qash*—Esau stubble.

"'They shall kindle in them, and devour them.'"

*Ve-dalqu vahem va-akhalum*—kindle, devour.

"'There shall not be any remaining of the house of Esau.'"

*Ve-lo-yihyeh sarid le-veit Esav*—none remain.

**The Key Verses (1:19-21):**
"'They of the South shall possess the mount of Esau.'"

*Ve-yareshu ha-Negev et-har Esav*—South possesses Edom.

"'They of the Lowland the Philistines.'"

*Ve-ha-Shefelah et-Pelishtim*—Shephelah possesses Philistia.

"'They shall possess the field of Ephraim, and the field of Samaria.'"

*Ve-yareshu et-sedeh Efrayim ve-et sedeh Shomeron*—possess Ephraim, Samaria.

"'Benjamin shall possess Gilead.'"

*U-Vinyamin et-ha-Gil'ad*—Benjamin possesses Gilead.

"'The captivity of this host of the children of Israel.'"

*Ve-galut ha-chel-ha-zeh li-venei Yisra'el*—exiles.

"'That are among the Canaanites, even unto Zarephath.'"

*Asher-Kena'anim ad-Tzarفat*—to Zarephath.

"'The captivity of Jerusalem, that is in Sepharad.'"

*Ve-galut Yerushalayim asher bi-Sefarad*—Sepharad.

**Sepharad:**
Later identified with Spain (hence "Sephardic" Jews).

"'Shall possess the cities of the South.'"

*Yireshu et arei ha-Negev*—possess South.

"'Saviours shall come up on mount Zion to judge the mount of Esau.'"

*Ve-alu moshi'im be-har Tziyon lishpot et-har Esav*—saviours judge Esau.

"'The kingdom shall be YHWH's.'"

*Ve-hayetah la-YHWH ha-melukhah*—kingdom YHWH's.

**Archetypal Layer:** Obadiah is the **shortest book**, an **oracle against Edom**, containing **Edom's pride: "Who shall bring me down?" (1:3)**, **"Though you set it among the stars, I will bring you down" (1:4)**, **Edom's betrayal by allies (1:7)**, **destruction of Edom's famous wisdom (1:8)**, **the sin: violence to "your brother Jacob" (1:10)**, **standing aloof, rejoicing, plundering, blocking escapees during Jerusalem's fall (1:11-14)**, **"the day of YHWH is near upon all the nations" (1:15)**, **"as you have done, it shall be done unto you" (1:15)**, **"in mount Zion there shall be those that escape" (1:17)**, **"the house of Jacob shall be a fire... the house of Esau for stubble" (1:18)**, and **"the kingdom shall be YHWH's" (1:21)**.

**Ethical Inversion Applied:**
- "The vision of Obadiah"—Obadiah's vision
- "Thus says the Lord YHWH concerning Edom"—concerning Edom
- "'Arise, and let us rise up against her in battle'"—nations against Edom
- "'Behold, I make you small among the nations'"—small
- "'You are greatly despised'"—despised
- "'The pride of your heart has deceived you'"—pride
- "'O you that dwell in the clefts of the rock'"—Petra
- "''Who shall bring me down to the ground?''"—arrogance
- "'Though you make your nest as high as the eagle'"—high
- "'Though you set it among the stars'"—among stars
- "'I will bring you down from thence'"—brought down
- "'If thieves came to you... would they not steal only till they had enough?'"—complete destruction
- "'How is Esau searched out!'"—searched
- "'All the men of your confederacy have... deceived you'"—betrayed
- "'They that eat your bread lay a snare under you'"—friends trap
- "'Shall I not... destroy the wise men out of Edom?'"—wisdom destroyed
- "'Your mighty men, O Teman, shall be dismayed'"—dismayed
- "'For the violence done to your brother Jacob'"—violence to brother
- "'Shame shall cover you'"—shame
- "'You shall be cut off for ever'"—forever
- "'In the day that you stood aloof'"—stood aloof
- "'Foreigners entered into his gates'"—foreigners entered
- "'Even you were as one of them'"—you too
- "'You should not have looked on the day of your brother'"—shouldn't look
- "'Neither should you have rejoiced'"—shouldn't rejoice
- "'Neither should you have spoken proudly'"—shouldn't boast
- "'You should not have entered into the gate'"—shouldn't enter
- "'Nor have laid hands on their substance'"—shouldn't plunder
- "'Neither should you have stood in the crossway'"—shouldn't block
- "'To cut off those of his that escape'"—cut off escapees
- "'Neither should you have delivered up those of his that did remain'"—shouldn't betray
- "'For the day of YHWH is near upon all the nations'"—day near
- "'As you have done, it shall be done unto you'"—reciprocity
- "'Your dealing shall return upon your own head'"—return
- "'In mount Zion there shall be those that escape'"—Zion escape
- "'It shall be holy'"—holy
- "'The house of Jacob shall be a fire'"—Jacob fire
- "'The house of Esau for stubble'"—Esau stubble
- "'There shall not be any remaining of the house of Esau'"—none remain
- "'Saviours shall come up on mount Zion'"—saviours
- "'To judge the mount of Esau'"—judge Esau
- "'The kingdom shall be YHWH's'"—kingdom YHWH's

**Modern Equivalent:** Obadiah is the Bible's shortest book—21 verses against Edom. The sin: when Jerusalem fell (586 BCE), Edom (descended from Jacob's brother Esau) stood aloof, rejoiced, plundered, and blocked escapees (1:11-14). The principle of reciprocity (1:15) applies: "as you have done, it shall be done unto you." Edom's pride—dwelling in impregnable Petra—won't save them. The book ends with eschatological hope: "the kingdom shall be YHWH's" (1:21).

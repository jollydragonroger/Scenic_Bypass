# Exodus Chapter 13: The Firstborn and the Pillar

*From the Hebrew: Consecration and Guidance*

---

**13:1** And YHWH spoke unto Moses, saying:

**13:2** "Sanctify unto me every firstborn—קַדֶּשׁ־לִי כָל־בְּכוֹר (qaddesh-li kol-bechor)—whatever opens the womb among the children of Israel, both of man and of beast; it is mine."

**13:3** And Moses said unto the people: "Remember this day—זָכוֹר אֶת־הַיּוֹם הַזֶּה (zachor et-ha-yom ha-zeh)—in which you came out from Egypt, from the house of bondage—מִבֵּית עֲבָדִים (mi-beit avadim); for by strength of hand YHWH brought you out from here; no leavened bread shall be eaten.

**13:4** "Today you are going out, in the month of Aviv—בְּחֹדֶשׁ הָאָבִיב (be-chodesh ha-Aviv).

**13:5** "And it shall be, when YHWH brings you into the land of the Canaanite and the Hittite and the Amorite and the Hivite and the Jebusite, which he swore unto your fathers to give you, a land flowing with milk and honey, that you shall keep this service in this month.

**13:6** "Seven days you shall eat unleavened bread, and on the seventh day shall be a feast to YHWH.

**13:7** "Unleavened bread shall be eaten throughout the seven days; and no leavened bread shall be seen with you, neither shall leaven be seen with you in all your territory.

**13:8** "And you shall tell your son in that day, saying, 'It is because of what YHWH did for me when I came out of Egypt.'

**13:9** "And it shall be for a sign unto you upon your hand, and for a memorial between your eyes—לְזִכָּרוֹן בֵּין עֵינֶיךָ (le-zikkaron bein einecha)—that the law of YHWH may be in your mouth; for with a strong hand YHWH brought you out of Egypt.

**13:10** "And you shall keep this ordinance in its appointed time from year to year.

---

**13:11** "And it shall be, when YHWH brings you into the land of the Canaanite, as he swore unto you and to your fathers, and gives it to you,

**13:12** "That you shall set apart unto YHWH—וְהַעֲבַרְתָּ (ve-ha'avarta)—all that opens the womb, and every firstling that comes of a beast which you have; the males shall be YHWH's.

**13:13** "And every firstling of a donkey you shall redeem with a lamb; and if you will not redeem it, then you shall break its neck. And every firstborn of man among your sons you shall redeem.

**13:14** "And it shall be, when your son asks you in time to come, saying, 'What is this?'—מַה־זֹּאת (mah-zot)—that you shall say unto him, 'By strength of hand YHWH brought us out from Egypt, from the house of bondage.

**13:15** "'And it came to pass, when Pharaoh stubbornly refused to let us go, that YHWH killed every firstborn in the land of Egypt, both the firstborn of man and the firstborn of beast. Therefore I sacrifice to YHWH all that opens the womb, being males; but every firstborn of my sons I redeem.'

**13:16** "And it shall be for a sign upon your hand, and for frontlets between your eyes—וּלְטוֹטָפֹת בֵּין עֵינֶיךָ (u-le-totafot bein einecha); for by strength of hand YHWH brought us out of Egypt."

---

**13:17** And it came to pass, when Pharaoh let the people go, that Consciousness did not lead them by the way of the land of the Philistines, although that was near; for Consciousness said, "Lest the people repent when they see war, and they return to Egypt."

**13:18** And Consciousness led the people around by the way of the wilderness of the Sea of Reeds—יַם־סוּף (Yam-Suf); and the children of Israel went up armed—חֲמֻשִׁים (chamushim)—out of the land of Egypt.

**13:19** And Moses took the bones of Joseph with him; for Joseph had made the children of Israel solemnly swear, saying, "Consciousness will surely visit you; and you shall carry up my bones from here with you."

**13:20** And they journeyed from Succoth and encamped in Etham, at the edge of the wilderness.

**13:21** And YHWH went before them by day in a pillar of cloud—עַמּוּד עָנָן (ammud anan)—to lead them the way, and by night in a pillar of fire—עַמּוּד אֵשׁ (ammud esh)—to give them light, to go by day and by night.

**13:22** The pillar of cloud by day and the pillar of fire by night did not depart from before the people.

---

## Synthesis Notes

**Key Restorations:**

**Sanctification of the Firstborn:**
Because YHWH killed Egypt's firstborn and spared Israel's, every Israelite firstborn—human and animal—belongs to YHWH. This is redemptive claim: the spared life is consecrated.

**"Remember This Day":**
*Zachor* (זָכוֹר)—the imperative of memory. Memory is commanded, not optional. The exodus is not merely past event but perpetual obligation.

**The Month of Aviv:**
*Aviv* (אָבִיב) means "spring" or "ripening grain." The agricultural calendar aligns with liberation. New life in nature, new life for the people.

**"For Me" — First Person Memory:**
"What YHWH did for me when I came out of Egypt." The ritual collapses time—every participant is present at the exodus, not merely commemorating it. The Passover Haggadah enshrines this: "In every generation, one must see oneself as though one personally came out of Egypt."

**Sign on Hand, Memorial Between Eyes:**
This becomes the basis for *tefillin* (phylacteries)—the small boxes containing Torah passages strapped to arm and forehead. Whether the original command was literal or metaphorical, Jewish practice literalized it. The body carries the memory.

**The Firstborn Donkey:**
Donkeys cannot be sacrificed (not kosher), so they are redeemed with a lamb or their necks are broken. The principle: what belongs to YHWH must be given or redeemed. There is no neutral option.

**"What Is This?" (מַה־זֹּאת):**
The child's question. The ritual is designed to provoke inquiry. Teaching occurs through question-answer, not lecture. The Passover Seder's four questions emerge from this pattern.

**The Roundabout Way:**
YHWH does not lead by the direct route ("the way of the land of the Philistines") because the people might see war and return to Egypt. Divine wisdom accounts for human weakness. The longer route through the wilderness is not punishment but protection.

**"Armed" (חֲמֻשִׁים, chamushim):**
The word can mean "armed" or "in groups of fifty" or "in battle array." Israel leaves not as fleeing refugees but as organized force. They carry weapons—perhaps from the despoiled Egyptians.

**Joseph's Bones:**
Moses fulfills the oath (Genesis 50:25). Joseph's bones travel with Israel—the ancestor who descended to Egypt now ascends with his descendants. The promise is kept across centuries.

**The Pillar of Cloud and Fire:**

YHWH's presence becomes visible:
- By day: pillar of cloud (*ammud anan*)—shade in the desert, visible guide
- By night: pillar of fire (*ammud esh*)—light in darkness, warmth, protection

**Cloud** = divine concealment and presence together. **Fire** = transformation, revelation (from the symbol map). The pillar is both—YHWH hidden in cloud, revealed in fire.

"Did not depart from before the people"—constant presence. The God who "came down" to Egypt now goes before them.

**Archetypal Layer:** The firstborn consecration transforms death into dedication. What was spared is claimed. The pillar represents the axis mundi traveling—the meeting point of heaven and earth in motion, guiding the people through the formless wilderness.

**Psychological Reading:** The longer route acknowledges that recently liberated slaves are not yet ready for battle. External freedom precedes internal transformation. YHWH "leads around" rather than demanding what the people cannot yet give. Liberation is process, not instant change.

**Ethical Inversion Applied:**
- Memory is commanded—liberation must not be forgotten
- The body carries remembrance (sign on hand, between eyes)
- Children's questions are invited, not silenced
- The firstborn is consecrated because it was spared—blessing creates obligation
- Divine guidance takes account of human limitation (the indirect route)

**Modern Equivalent:** Lasting change requires memory embedded in practice—ritual, tradition, story. "What YHWH did for me" collapses historical distance; the participant enters the story. And wise leadership takes the longer path when people aren't ready for the direct confrontation. The pillar goes before—guidance is provided, not just command.

# Exodus Chapter 1: A New King and the Oppression

*From the Hebrew: שְׁמוֹת (Shemot) — Names*

---

**1:1** And these are the names—שְׁמוֹת (shemot)—of the children of Israel who came into Egypt; with Jacob, each man and his household came:

**1:2** Reuben, Simeon, Levi, and Judah;

**1:3** Issachar, Zebulun, and Benjamin;

**1:4** Dan and Naphtali, Gad and Asher.

**1:5** And all the souls that came out of the loins of Jacob were seventy souls; and Joseph was already in Egypt.

**1:6** And Joseph died, and all his brothers, and all that generation.

**1:7** And the children of Israel were fruitful, and swarmed—וַיִּשְׁרְצוּ (va-yishretsu)—and multiplied, and became exceedingly mighty—וַיַּעַצְמוּ בִּמְאֹד מְאֹד (va-ya'atsmu bi-me'od me'od); and the land was filled with them.

**1:8** And a new king arose over Egypt, who knew not Joseph—אֲשֶׁר לֹא־יָדַע אֶת־יוֹסֵף (asher lo-yada et-Yosef).

**1:9** And he said unto his people: "Behold, the people of the children of Israel are more and mightier than we.

**1:10** "Come, let us deal wisely—הָבָה נִתְחַכְּמָה (havah nitchakkemah)—with them, lest they multiply, and it come to pass, when war befalls us, that they also join our enemies and fight against us, and go up from the land."

**1:11** And they set over them taskmasters—שָׂרֵי מִסִּים (sarei missim)—to afflict them with their burdens. And they built for Pharaoh store-cities—עָרֵי מִסְכְּנוֹת (arei miskenot)—Pithom and Raamses.

**1:12** But the more they afflicted them, the more they multiplied and the more they spread abroad; and they were in dread—וַיָּקֻצוּ (va-yaqutsu)—because of the children of Israel.

**1:13** And the Egyptians made the children of Israel serve with rigor—בְּפָרֶךְ (be-farekh).

**1:14** And they made their lives bitter with hard service—בַּעֲבֹדָה קָשָׁה (ba-avodah qashah)—in mortar and in brick, and in all manner of service in the field; all their service wherein they made them serve was with rigor.

**1:15** And the king of Egypt spoke to the Hebrew midwives—הַמְיַלְּדֹת הָעִבְרִיֹּת (ha-meyalledot ha-Ivriyot)—of whom the name of one was Shiphrah—שִׁפְרָה (Shifrah)—and the name of the other Puah—פּוּעָה (Pu'ah).

**1:16** And he said: "When you serve as midwife to the Hebrew women and see them upon the birthstool—הָאָבְנָיִם (ha-ovnayim)—if it is a son, you shall kill him; but if it is a daughter, she shall live."

**1:17** But the midwives feared Consciousness—וַתִּירֶאןָ הַמְיַלְּדֹת אֶת־הָאֱלֹהִים (va-tire'na ha-meyalledot et-ha-Elohim)—and did not do as the king of Egypt spoke unto them, but kept the children alive—וַתְּחַיֶּיןָ אֶת־הַיְלָדִים (va-techayeyna et-ha-yeladim).

**1:18** And the king of Egypt called for the midwives and said unto them: "Why have you done this thing, and kept the children alive?"

**1:19** And the midwives said unto Pharaoh: "Because the Hebrew women are not like the Egyptian women; for they are vigorous—חָיוֹת (chayot)—and give birth before the midwife comes unto them."

**1:20** And Consciousness dealt well with the midwives; and the people multiplied and became very mighty.

**1:21** And it came to pass, because the midwives feared Consciousness, that Consciousness made them houses—בָּתִּים (battim).

**1:22** And Pharaoh commanded all his people, saying: "Every son that is born you shall cast into the River—הַיְאֹרָה (ha-Ye'orah)—and every daughter you shall keep alive."

---

## Synthesis Notes

**Key Restorations:**

**"These Are the Names" (שְׁמוֹת, Shemot):**
The book's Hebrew title comes from its opening word. Names matter—identity matters. The people who came as named individuals will become an anonymous mass of slaves before emerging again with names and identity.

**The Generational Break:**
"Joseph died, and all his brothers, and all that generation." The connection to the past is severed. The memory of Joseph's service to Egypt is gone.

**"They Swarmed" (וַיִּשְׁרְצוּ, va-yishretsu):**
The same verb used for fish and creatures in Genesis 1:20-21. Israel multiplies like creation itself—fulfilling the blessing "be fruitful and multiply." The language echoes primeval abundance.

**"A New King Who Knew Not Joseph":**
*Lo-yada* (לֹא־יָדַע)—"did not know." This may mean literal ignorance (different dynasty) or political erasure (choosing not to acknowledge). Either way, the relationship resets to zero—or worse.

**"Let Us Deal Wisely" (נִתְחַכְּמָה, nitchakkemah):**
Pharaoh's "wisdom" is the wisdom of the **beast/machine**—"uncontrolled systemic appetite, bureaucracy" from the symbol map. His wisdom is strategic oppression: demographic control through labor exploitation and eventual genocide.

**The Oppression Cycle:**
- Forced labor (taskmasters, burdens)
- Store-cities (Pithom, Raamses)—Israel builds Egyptian infrastructure
- "Service with rigor" (בְּפָרֶךְ, be-farekh)—crushing, breaking work
- Lives made "bitter" (מָרַר, marar)—the same root as the bitter herbs of Passover

**But: "The More They Afflicted, the More They Multiplied":**
Oppression backfires. The blessing cannot be negated by human cruelty. The harder Egypt presses, the more Israel expands.

**The Midwives — The First Resisters:**

- *Shiphrah* (שִׁפְרָה): Possibly "beauty" or "fair one"
- *Pu'ah* (פּוּעָה): Possibly "splendid" or related to crying out

These are the first named resisters of tyranny. They are told to commit infanticide; they refuse. Their resistance is the beginning of liberation.

**"The Midwives Feared Consciousness":**
Their fear of God outweighs their fear of Pharaoh. This is the **civil courage** of the symbolic key—"autonomous ethics over compliance." They obey a higher law.

**The Clever Lie:**
When questioned, the midwives claim Hebrew women give birth too fast to be killed. "They are vigorous" (חָיוֹת, chayot)—the word also means "animals" or "living ones." The lie may contain irony: these slave-women are too alive for your death system.

**"Consciousness Made Them Houses":**
*Battim* (בָּתִּים)—houses, families, dynasties. Because the midwives preserved life, Consciousness establishes their lineages. Resistance to death is rewarded with life.

**The Escalation:**
When the midwives fail him, Pharaoh escalates to public genocide: "Every son that is born, cast into the River." The Nile, source of Egypt's life, is weaponized against Israel's sons. The entire Egyptian populace is commanded to participate.

**Archetypal Layer:** The oppressive empire (beast/machine) seeks to destroy the emerging people. But life resists—through fertility that overwhelms control, through midwives who refuse orders, through divine providence that defeats "wisdom." The pattern of death-and-deliverance is established.

**Ethical Inversion Applied:**
- Pharaoh's "wisdom" is revealed as machinery of death
- The midwives' disobedience is true righteousness
- The system commands evil; the moral center disobeys
- Civil resistance to unjust authority is honored, not punished

**Psychological Reading:** The unconscious (Israel in Egypt) begins to threaten the conscious system (Pharaoh's order). The system's response is attempted destruction of the emerging. But the unconscious is generative—it cannot be killed by force. It will produce the liberator.

**Modern Equivalent:** Authoritarian systems fear minority populations. "They might join our enemies" is the perennial paranoid justification. Labor exploitation, demographic control, and genocide are escalating responses. But midwives exist—those who refuse participation in evil. And their refusal preserves the future.

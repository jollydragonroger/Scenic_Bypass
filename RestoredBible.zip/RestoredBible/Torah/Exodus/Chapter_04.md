# Exodus Chapter 4: Moses' Objections and the Signs

*From the Hebrew: The Reluctant Prophet*

---

**4:1** And Moses answered and said: "But behold, they will not believe me, nor listen to my voice; for they will say, 'YHWH has not appeared unto you.'"

**4:2** And YHWH said unto him: "What is that in your hand?" And he said: "A staff—מַטֶּה (matteh)."

**4:3** And YHWH said: "Cast it on the ground." And he cast it on the ground, and it became a serpent—נָחָשׁ (nachash); and Moses fled from before it.

**4:4** And YHWH said unto Moses: "Stretch out your hand and take it by the tail"—and he stretched out his hand and seized it, and it became a staff in his palm—

**4:5** "That they may believe that YHWH, the Consciousness of their fathers, the Consciousness of Abraham, the Consciousness of Isaac, and the Consciousness of Jacob, has appeared unto you."

**4:6** And YHWH said unto him further: "Now put your hand into your bosom." And he put his hand into his bosom; and when he took it out, behold, his hand was leprous—מְצֹרַעַת (metsora'at)—like snow.

**4:7** And YHWH said: "Put your hand back into your bosom"—and he put his hand back into his bosom, and when he took it out of his bosom, behold, it had returned like his flesh.

**4:8** "And it shall come to pass, if they will not believe you nor listen to the voice of the first sign, that they may believe the voice of the latter sign.

**4:9** "And it shall come to pass, if they will not believe even these two signs, nor listen to your voice, that you shall take from the water of the River and pour it upon the dry land; and the water which you take from the River shall become blood upon the dry land."

**4:10** And Moses said unto YHWH: "Please, my Lord, I am not a man of words—לֹא אִישׁ דְּבָרִים (lo ish devarim)—neither yesterday nor the day before, nor since you have spoken unto your servant; for I am heavy of mouth and heavy of tongue—כְבַד־פֶּה וּכְבַד לָשׁוֹן (khevad-peh u-khevad lashon)."

**4:11** And YHWH said unto him: "Who has made man's mouth? Or who makes one mute or deaf, or seeing or blind? Is it not I, YHWH?

**4:12** "And now go, and I will be with your mouth—וְאָנֹכִי אֶהְיֶה עִם־פִּיךָ (ve-anochi ehyeh im-picha)—and will teach you what you shall speak."

**4:13** And Moses said: "Please, my Lord, send by the hand of whomever you will send—שְׁלַח־נָא בְּיַד־תִּשְׁלָח (shelach-na be-yad-tishlach)."

**4:14** And the anger of YHWH was kindled against Moses, and YHWH said: "Is there not Aaron your brother, the Levite? I know that he can speak well. And also, behold, he is coming out to meet you; and when he sees you, he will be glad in his heart.

**4:15** "And you shall speak unto him and put the words in his mouth; and I will be with your mouth and with his mouth, and will teach you what you shall do.

**4:16** "And he shall speak for you unto the people; and he shall be to you as a mouth, and you shall be to him as Consciousness—לֵאלֹהִים (l'Elohim).

**4:17** "And this staff you shall take in your hand, with which you shall do the signs."

---

**4:18** And Moses went and returned to Jethro his father-in-law, and said unto him: "Let me go, please, and return unto my brothers who are in Egypt, and see whether they are yet alive." And Jethro said to Moses: "Go in peace."

**4:19** And YHWH said unto Moses in Midian: "Go, return into Egypt; for all the men who sought your life are dead."

**4:20** And Moses took his wife and his sons, and set them upon a donkey, and returned to the land of Egypt; and Moses took the staff of Consciousness—מַטֵּה הָאֱלֹהִים (matteh ha-Elohim)—in his hand.

**4:21** And YHWH said unto Moses: "When you go to return into Egypt, see that all the wonders which I have put in your hand, you do them before Pharaoh; and I will harden his heart—וַאֲנִי אֲחַזֵּק אֶת־לִבּוֹ (va-ani achazzeq et-libbo)—and he will not let the people go.

**4:22** "And you shall say unto Pharaoh: 'Thus says YHWH: Israel is my son, my firstborn—בְּנִי בְכֹרִי יִשְׂרָאֵל (beni vechori Yisra'el).

**4:23** "'And I say unto you: Let my son go, that he may serve me. And if you refuse to let him go, behold, I will kill your son, your firstborn—בִּנְךָ בְּכֹרֶךָ (bincha bechorecha).'"

---

**4:24** And it came to pass on the way, at the lodging place, that YHWH met him and sought to kill him—וַיְבַקֵּשׁ הֲמִיתוֹ (va-yevaqesh hamito).

**4:25** And Zipporah took a flint and cut off the foreskin of her son, and touched it to his feet, and said: "Surely you are a bridegroom of blood—חֲתַן־דָּמִים (chatan-damim)—to me."

**4:26** And YHWH let him go. Then she said: "A bridegroom of blood," because of the circumcision.

---

**4:27** And YHWH said to Aaron: "Go to meet Moses in the wilderness." And he went and met him at the mountain of Consciousness and kissed him.

**4:28** And Moses told Aaron all the words of YHWH who had sent him, and all the signs which YHWH had commanded him.

**4:29** And Moses and Aaron went and gathered all the elders of the children of Israel.

**4:30** And Aaron spoke all the words which YHWH had spoken unto Moses, and did the signs in the sight of the people.

**4:31** And the people believed; and they heard that YHWH had visited—פָּקַד (paqad)—the children of Israel, and that YHWH had seen their affliction; and they bowed their heads and worshipped.

---

## Synthesis Notes

**Key Restorations:**

**Moses' Continued Objections:**

Moses offers multiple reasons to refuse the call:
1. "Who am I?" (3:11) — Answered: "I will be with you"
2. "What is your name?" (3:13) — Answered: "I AM"
3. "They won't believe me" (4:1) — Answered: Three signs
4. "I'm not eloquent" (4:10) — Answered: "I made mouths"
5. "Send someone else" (4:13) — Answered with anger: Aaron will help

The progression shows deepening resistance—from genuine questions to outright refusal.

**The Three Signs:**

1. **Staff to serpent**: The *nachash* (נָחָשׁ)—the serpent, **regenerative knowledge, creative intelligence** from the symbol map. Moses' shepherd's tool transforms into living power. The serpent—symbol of Egypt (uraeus), symbol of wisdom—is under YHWH's control.

2. **Hand leprous and healed**: Disease and healing at divine command. The body itself becomes sign—mortality and restoration.

3. **Water to blood**: The Nile, Egypt's life-source, transformed to blood. This foreshadows the first plague.

**"Heavy of Mouth and Tongue":**
Moses claims speech impediment—possibly a stutter, or simply feeling inadequate as a speaker after 40 years with sheep. YHWH's response: "Who made mouths?" The creator of organs can empower their use.

**"Send Whoever You Will Send":**
This is veiled refusal. Moses says "send someone else." YHWH's anger flares—but then accommodation: Aaron will be the spokesman.

**"You Shall Be to Him as Consciousness":**
Moses will be to Aaron what YHWH is to Moses—source of words. The prophetic chain: YHWH → Moses → Aaron → people/Pharaoh.

**The Hardening of Pharaoh's Heart:**

This is the first mention of what becomes a repeated pattern. *Achazzeq* (אֲחַזֵּק)—"I will harden" or "I will strengthen." The Hebrew has multiple verbs for this:
- חָזַק (chazaq): strengthen, harden
- כָּבֵד (kaved): make heavy
- קָשָׁה (qashah): make stubborn

Sometimes YHWH hardens; sometimes Pharaoh hardens himself. The text presents both divine sovereignty and human responsibility without resolving the tension.

**"Israel Is My Son, My Firstborn":**
The collective is personified. Israel is YHWH's firstborn—the one who receives the inheritance. The warning to Pharaoh: if you hold my firstborn, I will take your firstborn.

**The Attack at the Lodging Place (4:24-26):**

This is one of the most mysterious passages in Scripture:
- YHWH "sought to kill him"—whom? Moses? The son?
- Zipporah performs emergency circumcision
- She touches "his feet" (possibly a euphemism for genitals)
- "Bridegroom of blood" (חֲתַן־דָּמִים)—what does this mean?

Possible interpretations:
- Moses had not circumcised his son (violating the Abrahamic covenant)
- Blood-ritual appeases the attacking deity
- Zipporah's action saves the one YHWH sought to kill
- The episode marks Moses' full transition back to Israelite identity

The passage remains genuinely obscure. The restoration acknowledges the mystery without forcing false clarity.

**"YHWH Had Visited":**
The people hear the recognition-word—*paqad* (פָּקַד), "visited"—and believe. Joseph's prophecy (Genesis 50:24) is fulfilled. They bow and worship.

**Archetypal Layer:** The reluctant prophet is universal—Jonah, Jeremiah, and others will resist their calls. Moses' objections are overcome not by addressing his inadequacy but by emphasizing divine sufficiency. The dangerous encounter at the lodging place marks the threshold crossing—death-touch before transformation.

**Psychological Reading:** The ego (Moses) resists the Self's (YHWH's) call with escalating excuses. Each excuse is answered until naked refusal appears ("send someone else"). The anger and accommodation (Aaron) show that divine purpose works with and through human limitation. The circumcision episode may represent the ego's near-death at the threshold of transformation.

**Ethical Inversion Applied:**
- YHWH's hardening of Pharaoh raises profound questions about freedom and responsibility
- The text does not resolve this—it presents it
- Moses the murderer becomes Moses the liberator
- Zipporah, the Midianite woman, saves the mission through blood-ritual
- The foreign wife knows what the Israelite man forgot

**Modern Equivalent:** Genuine calling is often resisted. We generate objections until we run out—then bare refusal appears. Divine calling works through human limitation (Aaron as spokesman) rather than demanding perfection. And threshold moments may feel like death before they enable new life.

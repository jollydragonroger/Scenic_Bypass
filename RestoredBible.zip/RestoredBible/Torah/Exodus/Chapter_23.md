# Exodus Chapter 23: Justice, Sabbaths, and Festivals

*From the Hebrew: Culmination of the Covenant*

---

**23:1** "You shall not raise a false report—שֵׁמַע שָׁוְא (shema shav). Do not put your hand with the wicked to be an unrighteous witness.

**23:2** "You shall not follow a multitude to do evil—לֹא־תִהְיֶה אַחֲרֵי־רַבִּים לְרָעֹת (lo-tihyeh acharei-rabbim le-ra'ot); neither shall you testify in a dispute so as to turn aside after a multitude to pervert justice.

**23:3** "Neither shall you favor a poor man in his dispute.

**23:4** "If you meet your enemy's ox or his donkey going astray, you shall surely bring it back to him.

**23:5** "If you see the donkey of one who hates you lying under its burden, you shall refrain from leaving him with it; you shall surely release it with him.

**23:6** "You shall not pervert the judgment of your poor in his dispute.

**23:7** "Keep far from a false matter—מִדְּבַר־שֶׁקֶר (mi-devar-sheqer); and the innocent and righteous you shall not kill; for I will not justify the wicked.

**23:8** "And you shall take no bribe—שֹׁחַד (shochad); for a bribe blinds those who have sight and perverts the words of the righteous.

**23:9** "And you shall not oppress a stranger; for you know the soul of a stranger—נֶפֶשׁ הַגֵּר (nefesh ha-ger)—seeing you were strangers in the land of Egypt.

---

**23:10** "And six years you shall sow your land and gather in its fruits;

**23:11** "But the seventh year you shall let it rest and lie fallow—וּשְׁמַטְתָּהּ וּנְטַשְׁתָּהּ (u-shemattah u-netashtah)—that the poor of your people may eat; and what they leave the beast of the field shall eat. In like manner you shall deal with your vineyard and with your olive grove.

**23:12** "Six days you shall do your work, but on the seventh day you shall rest—תִּשְׁבֹּת (tishbot)—that your ox and your donkey may rest, and the son of your maidservant and the stranger may be refreshed—וְיִנָּפֵשׁ (ve-yinnafesh).

**23:13** "And in all things that I have said unto you, take heed; and make no mention of the name of other gods, neither let it be heard out of your mouth.

---

**23:14** "Three times you shall keep a feast unto me in the year.

**23:15** "The Feast of Unleavened Bread—חַג הַמַּצּוֹת (chag ha-matsot)—you shall keep; seven days you shall eat unleavened bread, as I commanded you, at the time appointed in the month of Aviv; for in it you came out from Egypt; and none shall appear before me empty.

**23:16** "And the Feast of Harvest—חַג הַקָּצִיר (chag ha-qatsir)—the firstfruits of your labors, which you sow in the field; and the Feast of Ingathering—חַג הָאָסִף (chag ha-asif)—at the end of the year, when you gather in your labors from the field.

**23:17** "Three times in the year all your males shall appear before the Lord YHWH.

**23:18** "You shall not offer the blood of my sacrifice with leavened bread; neither shall the fat of my feast remain until the morning.

**23:19** "The first of the firstfruits of your land you shall bring into the house of YHWH your Consciousness. You shall not boil a kid in its mother's milk—לֹא־תְבַשֵּׁל גְּדִי בַּחֲלֵב אִמּוֹ (lo-tevashel gedi ba-chalev immo).

---

**23:20** "Behold, I send a messenger—מַלְאָךְ (malach)—before you, to keep you in the way and to bring you into the place which I have prepared.

**23:21** "Take heed of him and obey his voice; do not provoke him, for he will not pardon your transgression; for my name is in him—שְׁמִי בְּקִרְבּוֹ (shemi be-qirbo).

**23:22** "But if you shall indeed obey his voice and do all that I speak, then I will be an enemy unto your enemies and an adversary unto your adversaries.

**23:23** "For my messenger shall go before you and bring you unto the Amorite and the Hittite and the Perizzite and the Canaanite and the Hivite and the Jebusite; and I will cut them off.

**23:24** "You shall not bow down to their gods nor serve them, nor do according to their works; but you shall utterly overthrow them and utterly break in pieces their pillars—מַצֵּבֹתֵיהֶם (matsevoteihem).

**23:25** "And you shall serve YHWH your Consciousness, and he shall bless your bread and your water; and I will take sickness away from your midst.

**23:26** "None shall miscarry nor be barren in your land; the number of your days I will fulfill.

**23:27** "I will send my terror before you—אֶת־אֵימָתִי (et-eimati)—and will throw into confusion all the people to whom you shall come, and I will make all your enemies turn their backs unto you.

**23:28** "And I will send the hornet—הַצִּרְעָה (ha-tsir'ah)—before you, which shall drive out the Hivite, the Canaanite, and the Hittite from before you.

**23:29** "I will not drive them out from before you in one year, lest the land become desolate and the beasts of the field multiply against you.

**23:30** "Little by little I will drive them out from before you, until you have increased and inherited the land.

**23:31** "And I will set your border from the Sea of Reeds even unto the Sea of the Philistines, and from the wilderness unto the River; for I will give the inhabitants of the land into your hand, and you shall drive them out before you.

**23:32** "You shall make no covenant with them nor with their gods.

**23:33** "They shall not dwell in your land, lest they make you sin against me; for if you serve their gods, it will surely be a snare unto you."

---

## Synthesis Notes

**Key Restorations:**

**Justice in the Courts (23:1-8):**

Remarkable ethical principles:
- No false reports—don't spread lies
- Don't follow the crowd to do evil—majority doesn't determine right
- Don't favor the poor *or* the rich—justice is impartial
- Return your enemy's stray animal—obligation transcends enmity
- Help even the one who hates you—enemies' animals matter
- No bribes—they blind the perceptive and corrupt the righteous
- "Keep far from a false matter"—distance yourself from lies

**"You Know the Soul of the Stranger":**
*Nefesh ha-ger* (נֶפֶשׁ הַגֵּר)—the inner experience, the psyche of the foreigner. Israel knows what it feels like to be alien, vulnerable, other. This empathetic knowledge grounds ethical obligation.

**The Sabbatical Year:**
Every seventh year, the land rests:
- Let it lie fallow (*shemattah*, release)
- The poor may eat what grows naturally
- Animals may graze the remainder

This is economic redistribution, ecological rest, and theological statement: the land belongs to YHWH, not to human owners.

**The Weekly Sabbath:**
Stated again with emphasis on rest for the vulnerable:
- Ox and donkey rest
- Son of the maidservant rests
- Stranger is *refreshed* (*yinnafesh*—literally "be-souled," recover breath/life)

The sabbath is for all—including animals and servants.

**The Three Pilgrimage Festivals:**

1. **Unleavened Bread (חַג הַמַּצּוֹת)**: In Aviv (spring), commemorating the exodus
2. **Harvest (חַג הַקָּצִיר)**: Firstfruits of wheat (later called Shavuot/Pentecost)
3. **Ingathering (חַג הָאָסִף)**: End of agricultural year (later called Sukkot/Tabernacles)

These are agricultural feasts transformed into commemorations of divine action.

**"None Shall Appear Before Me Empty":**
Bring offerings when you come. Worship includes giving.

**"Do Not Boil a Kid in Its Mother's Milk":**
This prohibition (repeated in 34:26 and Deuteronomy 14:21) becomes the basis for the separation of meat and dairy in Jewish law. The original meaning may have been:
- A Canaanite cultic practice to be avoided
- A principle of not mixing life-giving (milk) with death (slaughter)
- Compassion—the mother's nourishment should not become the means of cooking her offspring

The depth of the prohibition exceeds its surface.

**The Messenger (מַלְאָךְ, malach):**
A mysterious figure—angel? divine presence? pre-incarnate Word? "My name is in him"—he carries the divine name. He will not pardon transgression; obey him completely.

**The Conquest Promise:**
YHWH will drive out the inhabitants of Canaan—but "little by little," not all at once. The ecological reasoning: too rapid conquest leaves the land desolate, wildlife multiplying dangerously. Even divine action respects process.

**The Borders Promised:**
From the Sea of Reeds (Red Sea) to the Sea of the Philistines (Mediterranean), from the wilderness to the River (Euphrates)—the maximum extent of Israelite territory, achieved only briefly under David and Solomon.

**No Covenant with Them:**
The prohibition of treaties with Canaanite peoples is religious, not ethnic: "lest they make you sin against me." The fear is assimilation to other gods, not racial contamination.

**Archetypal Layer:** The chapter weaves justice, rest, and conquest into a single vision. The sabbatical principle (seventh year rest) extends the sabbath into economic and ecological spheres. The festivals mark time by divine action. The messenger represents transcendent guidance that cannot be manipulated.

**Psychological Reading:** "You know the soul of the stranger" is the foundation of ethical imagination—projecting into the experience of the other because you have been the other. Empathy arising from memory is more reliable than abstract principle.

**Ethical Inversion Applied:**
- Don't follow the crowd to do evil—social consensus doesn't determine righteousness
- Help your enemy's animal—obligation to creatures transcends human enmity
- The poor are not favored OR disfavored—justice is truly blind
- "Keep far from a false matter"—maintain distance from deceit
- The land rests, the poor eat, the animals graze—the seventh year is redistribution
- "Little by little"—divine action respects process, doesn't overwhelm

**Modern Equivalent:** Justice requires resisting crowd pressure. Impartiality means not favoring rich *or* poor—only facts matter. The sabbatical principle (rest for land, relief for poor) challenges extractive economics. And the prohibition of boiling a kid in its mother's milk—whatever its origin—points to the principle: don't use life-giving elements for death, don't mix nurture with destruction.

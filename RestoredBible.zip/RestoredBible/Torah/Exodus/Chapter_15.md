# Exodus Chapter 15: The Song of the Sea

*From the Hebrew: שִׁירַת הַיָּם (Shirat HaYam) — The Song at the Sea*

---

**15:1** Then Moses and the children of Israel sang this song unto YHWH, and spoke, saying:

"I will sing unto YHWH, for he has triumphed gloriously—גָּאֹה גָּאָה (ga'oh ga'ah);
The horse and his rider he has thrown into the sea.

**15:2** "YHWH is my strength and my song—עָזִּי וְזִמְרָת יָהּ (azzi ve-zimrat Yah)—
And he has become my salvation—יְשׁוּעָה (yeshu'ah);
This is my Consciousness, and I will glorify him—וְאַנְוֵהוּ (ve-anvehu);
My father's Consciousness, and I will exalt him.

**15:3** "YHWH is a man of war—אִישׁ מִלְחָמָה (ish milchamah);
YHWH is his name.

**15:4** "Pharaoh's chariots and his army he has cast into the sea;
And his chosen captains are drowned in the Sea of Reeds.

**15:5** "The depths covered them;
They went down into the depths like a stone.

**15:6** "Your right hand, O YHWH, is glorious in power;
Your right hand, O YHWH, shatters the enemy.

**15:7** "And in the greatness of your majesty you overthrow those who rise against you;
You send forth your fury—חֲרֹנְךָ (charoncha)—it consumes them like stubble.

**15:8** "And with the blast of your nostrils—בְּרוּחַ אַפֶּיךָ (be-ruach appecha)—the waters were piled up;
The floods stood upright like a heap;
The depths congealed in the heart of the sea.

**15:9** "The enemy said, 'I will pursue, I will overtake,
I will divide the spoil, my soul shall be satisfied upon them;
I will draw my sword, my hand shall destroy them.'

**15:10** "You blew with your wind—רוּחֲךָ (ruchacha)—the sea covered them;
They sank like lead in the mighty waters.

**15:11** "Who is like you among the gods, O YHWH—מִי־כָמֹכָה בָּאֵלִם יהוה (mi-chamocha ba-elim YHWH)?
Who is like you, majestic in holiness,
Fearsome in praises, working wonders?

**15:12** "You stretched out your right hand;
The earth swallowed them.

**15:13** "You in your loving-kindness—חַסְדְּךָ (chasdecha)—have led the people whom you have redeemed;
You have guided them in your strength unto your holy habitation.

**15:14** "The peoples have heard, they tremble;
Pangs have seized the inhabitants of Philistia.

**15:15** "Then the chiefs of Edom were dismayed;
The mighty ones of Moab, trembling seized them;
All the inhabitants of Canaan melted away.

**15:16** "Fear and dread fell upon them;
By the greatness of your arm they became still as a stone;
Until your people pass over, O YHWH,
Until the people pass over whom you have acquired.

**15:17** "You will bring them and plant them in the mountain of your inheritance,
The place, O YHWH, which you have made for your dwelling,
The sanctuary, O Lord, which your hands have established.

**15:18** "YHWH shall reign forever and ever—יהוה יִמְלֹךְ לְעֹלָם וָעֶד (YHWH yimloch le-olam va-ed)."

---

**15:19** For the horses of Pharaoh went in with his chariots and with his horsemen into the sea, and YHWH brought back the waters of the sea upon them; but the children of Israel walked on dry ground in the midst of the sea.

**15:20** And Miriam the prophetess—הַנְּבִיאָה (ha-nevi'ah)—the sister of Aaron, took a timbrel—תֹּף (tof)—in her hand; and all the women went out after her with timbrels and with dances.

**15:21** And Miriam sang unto them:

"Sing unto YHWH, for he has triumphed gloriously;
The horse and his rider he has thrown into the sea."

---

**15:22** And Moses led Israel onward from the Sea of Reeds, and they went out into the wilderness of Shur; and they went three days in the wilderness and found no water.

**15:23** And they came to Marah, and they could not drink the waters of Marah, for they were bitter—מָרִים (marim); therefore the name of it was called Marah—מָרָה (Marah).

**15:24** And the people murmured against Moses, saying, "What shall we drink?"

**15:25** And he cried unto YHWH; and YHWH showed him a tree—עֵץ (ets); and he cast it into the waters, and the waters became sweet. There YHWH made for them a statute and an ordinance, and there he tested them.

**15:26** And YHWH said: "If you will diligently listen to the voice of YHWH your Consciousness, and will do what is right in his eyes, and will give ear to his commandments, and keep all his statutes, I will put none of the diseases upon you which I have put upon the Egyptians; for I am YHWH who heals you—יהוה רֹפְאֶךָ (YHWH rof'echa)."

**15:27** And they came to Elim, and there were twelve springs of water—שְׁתֵּים עֶשְׂרֵה עֵינֹת מַיִם (shtem esreh einot mayim)—and seventy palm trees; and they encamped there by the waters.

---

## Synthesis Notes

**Key Restorations:**

**The Song of the Sea (שִׁירַת הַיָּם):**
This is among the oldest poetry in the Bible, possibly composed near the events themselves. The archaic Hebrew forms suggest great antiquity. Jewish liturgy includes this song daily; it is chanted with special melody on the seventh day of Passover.

**"Triumphed Gloriously" (גָּאֹה גָּאָה):**
The doubling intensifies: "He has surely risen in majesty" or "He has utterly triumphed." The root גָּאָה (ga'ah) suggests rising, lifting, swelling—like waves.

**"YHWH Is a Man of War":**
*Ish milchamah* (אִישׁ מִלְחָמָה)—YHWH is characterized as warrior. The divine fights for Israel; Israel does not fight. This is the theology of the sea crossing: YHWH alone defeats Pharaoh.

**The Breath/Wind of YHWH:**
"With the blast of your nostrils (*ruach appecha*) the waters were piled up." The same *ruach* (spirit/wind/breath) that moved over the waters in creation (Genesis 1:2) now divides the waters for deliverance. Creation and liberation are linked.

**"Who Is Like You Among the Gods?":**
*Mi-chamocha ba-elim YHWH* (מִי־כָמֹכָה בָּאֵלִם יהוה)—the rhetorical question assumes other gods exist but asserts YHWH's incomparability. This is henotheism moving toward monotheism. The phrase becomes central in Jewish liturgy.

**The Future Vision (15:14-17):**
The song leaps from the sea to the future:
- Philistia trembles
- Edom and Moab are dismayed
- Canaan melts
- Israel is planted on YHWH's mountain

The song sees the conquest and the temple from the perspective of the sea. The journey is complete before it begins.

**"YHWH Shall Reign Forever":**
The song climaxes with eternal kingship. The exodus establishes YHWH as Israel's true king—not Pharaoh, not any human ruler.

**Miriam the Prophetess:**
Miriam is called *nevi'ah* (נְבִיאָה)—prophetess—the first woman so titled in Scripture. She leads the women in response-song with timbrel and dance. The exodus is celebrated by both genders, with women's liturgy distinct.

**The Timbrel (תֹּף, tof):**
A frame drum, the instrument of women's celebration in ancient Israel. The women took timbrels out of Egypt—even in flight, they prepared for celebration. Faith carries instruments.

**Marah — The First Wilderness Crisis:**
Three days without water, then bitter water. The pattern of wilderness complaint begins immediately. Liberation does not end struggle; it transforms struggle's context.

**"What Shall We Drink?":**
The people murmur (*va-yillonu*)—the first of many wilderness murmurings. The verb becomes technical for Israel's recurring complaints.

**The Tree:**
YHWH shows Moses a tree (*ets*) to sweeten the water. What tree? The text doesn't specify. The tree transforms bitter to sweet—**wood as instrument of transformation**.

**"YHWH Who Heals You" (יהוה רֹפְאֶךָ):**
A new divine name: YHWH Rofecha—YHWH your Healer. The God who struck Egypt with disease promises to spare Israel from those diseases if they obey. Healing is covenant blessing.

**Elim:**
After Marah (bitterness), Elim (אֵילִם, "oaks" or "terebinths")—an oasis with twelve springs and seventy palms. Twelve for the tribes; seventy for the elders (or the nations). After testing, abundance.

**Archetypal Layer:** The Song of the Sea is **sacred poetry as memory-making**. The event is transformed into liturgy that sustains identity across millennia. The journey from sea to Marah to Elim establishes the wilderness pattern: crisis → complaint → provision → testing → abundance.

**Psychological Reading:** Immediately after the greatest victory, the people face new crisis (no water, then bitter water). Liberation does not eliminate problems; it changes their nature. The grumbling begins at once—the liberated psyche still carries slave reflexes. The tree that sweetens bitter water is the transforming element—wisdom, insight, or grace that changes experience.

**Ethical Inversion Applied:**
- YHWH as warrior fights so Israel doesn't have to
- Miriam leads women's worship—not subordinate but parallel
- The exodus produces hope for future nations (trembling of Philistia, Edom, Moab, Canaan)—what happened at the sea will resonate
- Healing is linked to covenant obedience—not magic but relationship

**Modern Equivalent:** Victory requires celebration and song—the event must be sung into memory. But celebration is followed immediately by new problems (Marah). The liberated face the wilderness, where the old complaints emerge. And something must sweeten the bitter waters—some tree, some wisdom, some intervention that transforms the undrinkable into life.

# Exodus Chapter 26: The Tabernacle Structure

*From the Hebrew: The Dwelling*

---

**26:1** "And the tabernacle—הַמִּשְׁכָּן (ha-mishkan)—you shall make with ten curtains of fine twisted linen and blue and purple and scarlet yarn; with cherubim, the work of a skillful workman, you shall make them.

**26:2** "The length of each curtain shall be twenty-eight cubits, and the breadth of each curtain four cubits; all the curtains shall have the same measure.

**26:3** "Five curtains shall be coupled to one another, and the other five curtains shall be coupled to one another.

**26:4** "And you shall make loops of blue on the edge of the one curtain at the end of the coupling; and likewise you shall make in the edge of the curtain that is outermost in the second coupling.

**26:5** "Fifty loops you shall make on the one curtain, and fifty loops you shall make on the edge of the curtain that is in the second coupling; the loops shall be opposite one another.

**26:6** "And you shall make fifty clasps of gold, and couple the curtains to one another with the clasps, that the tabernacle may be one—וְהָיָה הַמִּשְׁכָּן אֶחָד (ve-hayah ha-mishkan echad).

**26:7** "And you shall make curtains of goats' hair for a tent over the tabernacle; eleven curtains you shall make.

**26:8** "The length of each curtain shall be thirty cubits, and the breadth of each curtain four cubits; the eleven curtains shall have the same measure.

**26:9** "And you shall couple five curtains by themselves, and six curtains by themselves, and shall double over the sixth curtain in the front of the tent.

**26:10** "And you shall make fifty loops on the edge of the one curtain that is outermost in the coupling, and fifty loops on the edge of the curtain of the second coupling.

**26:11** "And you shall make fifty clasps of bronze, and put the clasps into the loops, and couple the tent together, that it may be one.

**26:12** "And the overhanging part that remains of the curtains of the tent—the half curtain that remains—shall hang over the back of the tabernacle.

**26:13** "And the cubit on the one side and the cubit on the other side, of what remains in the length of the curtains of the tent, shall hang over the sides of the tabernacle, on this side and on that side, to cover it.

**26:14** "And you shall make a covering for the tent of rams' skins dyed red, and a covering of porpoise skins above.

---

**26:15** "And you shall make the boards for the tabernacle of acacia wood, standing up.

**26:16** "Ten cubits shall be the length of a board, and a cubit and a half the breadth of each board.

**26:17** "Two tenons shall there be in each board, joined to one another; thus shall you make for all the boards of the tabernacle.

**26:18** "And you shall make the boards for the tabernacle: twenty boards for the south side.

**26:19** "And you shall make forty sockets of silver under the twenty boards; two sockets under one board for its two tenons, and two sockets under another board for its two tenons.

**26:20** "And for the second side of the tabernacle, on the north side, twenty boards,

**26:21** "And their forty sockets of silver; two sockets under one board, and two sockets under another board.

**26:22** "And for the rear of the tabernacle westward you shall make six boards.

**26:23** "And two boards you shall make for the corners of the tabernacle in the rear.

**26:24** "And they shall be double beneath, and in like manner they shall be complete unto the top of it unto one ring; thus shall it be for both of them; they shall be for the two corners.

**26:25** "And there shall be eight boards, and their sockets of silver, sixteen sockets; two sockets under one board, and two sockets under another board.

**26:26** "And you shall make bars of acacia wood: five for the boards of the one side of the tabernacle,

**26:27** "And five bars for the boards of the other side of the tabernacle, and five bars for the boards of the side of the tabernacle, for the rear westward.

**26:28** "And the middle bar in the midst of the boards shall pass from end to end.

**26:29** "And you shall overlay the boards with gold, and make their rings of gold as holders for the bars; and you shall overlay the bars with gold.

**26:30** "And you shall erect the tabernacle according to its plan—כְּמִשְׁפָּטוֹ (ke-mishpato)—which was shown you on the mountain.

---

**26:31** "And you shall make a veil—פָּרֹכֶת (parochet)—of blue and purple and scarlet yarn and fine twisted linen; with cherubim, the work of a skillful workman, it shall be made.

**26:32** "And you shall hang it upon four pillars of acacia overlaid with gold; their hooks shall be of gold, upon four sockets of silver.

**26:33** "And you shall hang the veil under the clasps, and bring in there within the veil the ark of the testimony; and the veil shall divide for you between the holy place and the most holy—בֵּין הַקֹּדֶשׁ וּבֵין קֹדֶשׁ הַקֳּדָשִׁים (bein ha-qodesh u-vein qodesh ha-qodashim).

**26:34** "And you shall put the mercy seat upon the ark of the testimony in the most holy place.

**26:35** "And you shall set the table outside the veil, and the lampstand opposite the table on the side of the tabernacle toward the south; and you shall put the table on the north side.

**26:36** "And you shall make a screen—מָסָךְ (masach)—for the door of the tent, of blue and purple and scarlet yarn and fine twisted linen, the work of the embroiderer.

**26:37** "And you shall make for the screen five pillars of acacia and overlay them with gold; their hooks shall be of gold; and you shall cast five sockets of bronze for them."

---

## Synthesis Notes

**Key Restorations:**

**The Mishkan (מִשְׁכָּן):**
From the root שָׁכַן (shakan), "to dwell." The tabernacle is literally "the dwelling"—the place where the divine presence dwells among Israel. This is not a temple (permanent) but a tent (portable). YHWH travels with the people.

**The Layered Coverings:**

The tabernacle has multiple layers:
1. **Inner curtains**: Fine linen with blue, purple, scarlet—woven with cherubim (visible from inside)
2. **Goats' hair curtains**: Protective layer over the linen
3. **Rams' skins dyed red**: Weather protection
4. **Porpoise/sea creature skins**: Outermost waterproof covering

From outside, the tabernacle looks plain—rough skins. From inside, it is beautiful—cherubim-adorned linen. The glory is hidden within.

**"That the Tabernacle May Be One":**
*Ve-hayah ha-mishkan echad* (וְהָיָה הַמִּשְׁכָּן אֶחָד)—despite multiple curtains and components, the structure is unified. The fifty gold clasps join the two sets of five curtains into one whole. Unity despite multiplicity.

**The Structural Framework:**
- 48 acacia boards (20 + 20 + 6 + 2 corners)
- 100 silver sockets (96 for boards, 4 for veil pillars)
- Gold overlay on boards
- Bars to stabilize the structure

The framework is substantial—real construction, not flimsy tent. The tabernacle is both portable and sturdy.

**The Cubit:**
A cubit is approximately 18 inches (the length from elbow to fingertip). The tabernacle's interior space is approximately 45 feet × 15 feet × 15 feet—a significant structure.

**The Veil (פָּרֹכֶת, parochet):**

The most sacred division:
- Blue, purple, scarlet, fine linen
- Cherubim woven in
- Hung on four gold-overlaid pillars
- Divides the Holy Place from the Holy of Holies

The veil separates. Only the high priest enters beyond it, only on Yom Kippur. The ark and mercy seat are behind this barrier. At Jesus' death, "the veil of the temple was torn from top to bottom" (Matthew 27:51)—access opened.

**Holy and Most Holy:**
*Ha-qodesh* (הַקֹּדֶשׁ)—the holy place; *qodesh ha-qodashim* (קֹדֶשׁ הַקֳּדָשִׁים)—the holy of holies, the most holy. Gradations of holiness: courtyard → holy place → most holy. The nearer to the ark, the holier the space.

**The Layout:**
- Ark and mercy seat: in the most holy place (west end)
- Table of showbread: north side of holy place
- Menorah: south side of holy place
- Altar of incense: before the veil (detailed in chapter 30)

The priest entering the holy place sees the table on the right, the menorah on the left, and the veil ahead.

**The Screen (מָסָךְ, masach):**
The entrance to the tent—less elaborate than the veil, but still embroidered in sacred colors. This is the door of the holy place.

**Bronze vs. Silver vs. Gold:**
The materials indicate gradation:
- Bronze: outermost (screen pillars, tent clasps)
- Silver: structural foundation (sockets for boards)
- Gold: innermost, sacred objects

The progression inward is a progression toward greater value and holiness.

**Archetypal Layer:** The tabernacle is a **microcosm**—the universe in miniature. The outer courtyard is earth; the holy place is heaven; the holy of holies is the divine throne room. The gradation of access mirrors the gradation of creation.

The cherubim on the veil and inner curtains recall Eden's guardians (Genesis 3:24). Entering the tabernacle is approaching what was lost—the presence of God.

**Psychological Reading:** The layered structure represents levels of consciousness. The outer appearance is plain; the inner reality is glorious. Access deepens progressively. The veil marks the boundary between ordinary awareness and the depths of the psyche where the divine dwells.

**Ethical Inversion Applied:**
- The glory is hidden within—external appearance is humble
- Unity from multiplicity—the components become one
- Gradation of holiness respects the dangerous nature of the divine
- The pattern was "shown on the mountain"—human construction follows heavenly template
- Portability matters—YHWH travels with the people, not fixed in one place

**Modern Equivalent:** Sacred spaces often hide their glory within plain exteriors. The gradation of access (courtyard → holy → most holy) models how approach to the transcendent requires stages. And the portable sanctuary—rather than fixed temple—suggests that divine presence accompanies people on their journey rather than waiting at a destination.

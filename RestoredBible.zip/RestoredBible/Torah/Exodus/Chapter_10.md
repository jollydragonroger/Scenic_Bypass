# Exodus Chapter 10: Locusts and Darkness

*From the Hebrew: The Penultimate Plagues*

---

**10:1** And YHWH said unto Moses: "Go in unto Pharaoh; for I have hardened his heart—הִכְבַּדְתִּי אֶת־לִבּוֹ (hichbadti et-libbo)—and the heart of his servants, that I might show these my signs in their midst,

**10:2** "And that you may tell in the ears of your son and of your son's son what I have wrought upon Egypt, and my signs which I have done among them; that you may know that I am YHWH."

**10:3** And Moses and Aaron came in unto Pharaoh and said unto him: "Thus says YHWH, the Consciousness of the Hebrews: 'How long will you refuse to humble yourself before me—לֵעָנֹת מִפָּנָי (le'anot mippanai)? Let my people go, that they may serve me.

**10:4** "'For if you refuse to let my people go, behold, tomorrow I will bring locusts—אַרְבֶּה (arbeh)—into your territory.

**10:5** "'And they shall cover the eye of the earth—עֵין הָאָרֶץ (ein ha-arets)—so that one cannot see the earth; and they shall eat the residue of that which is escaped, which remains unto you from the hail, and shall eat every tree which grows for you out of the field.

**10:6** "'And they shall fill your houses and the houses of all your servants and the houses of all the Egyptians, which neither your fathers nor your fathers' fathers have seen, from the day they were upon the earth unto this day.'" And Moses turned and went out from Pharaoh.

**10:7** And Pharaoh's servants said unto him: "How long shall this man be a snare unto us—מוֹקֵשׁ (moqesh)? Let the men go, that they may serve YHWH their Consciousness. Do you not yet know that Egypt is destroyed—אָבְדָה מִצְרָיִם (avdah Mitsrayim)?"

**10:8** And Moses and Aaron were brought again unto Pharaoh; and he said unto them: "Go, serve YHWH your Consciousness. Who are they that shall go?"

**10:9** And Moses said: "We will go with our young and with our old, with our sons and with our daughters, with our flocks and with our herds we will go; for we have a feast of YHWH."

**10:10** And Pharaoh said unto them: "So may YHWH be with you, as I will let you go with your little ones! Look, for evil is before your faces—רְאוּ כִּי רָעָה נֶגֶד פְּנֵיכֶם (re'u ki ra'ah neged peneichem).

**10:11** "Not so! Go now, you that are men, and serve YHWH; for that is what you desire." And they were driven out from Pharaoh's presence.

**10:12** And YHWH said unto Moses: "Stretch out your hand over the land of Egypt for the locusts, that they may come up upon the land of Egypt and eat every herb of the land, all that the hail has left."

**10:13** And Moses stretched out his staff over the land of Egypt, and YHWH brought an east wind—רוּחַ קָדִים (ruach qadim)—upon the land all that day and all the night; when it was morning, the east wind brought the locusts.

**10:14** And the locusts went up over all the land of Egypt, and rested upon all the territory of Egypt; very grievous were they. Before them there were no such locusts as they, neither after them shall there be such.

**10:15** And they covered the eye of all the land, and the land was darkened; and they ate every herb of the land and all the fruit of the trees which the hail had left; and there remained not any green thing—כָּל־יֶרֶק (kol-yereq)—in the trees or in the herbs of the field, throughout all the land of Egypt.

**10:16** And Pharaoh called for Moses and Aaron in haste; and he said: "I have sinned against YHWH your Consciousness and against you.

**10:17** "And now please forgive my sin—שָׂא נָא חַטָּאתִי (sa na chattati)—only this once, and entreat YHWH your Consciousness, that he may take away from me only this death."

**10:18** And Moses went out from Pharaoh and entreated YHWH.

**10:19** And YHWH turned a very strong west wind—רוּחַ־יָם (ruach-yam)—which took up the locusts and drove them into the Sea of Reeds; not one locust remained in all the territory of Egypt.

**10:20** And YHWH hardened Pharaoh's heart, and he did not let the children of Israel go.

---

**10:21** And YHWH said unto Moses: "Stretch out your hand toward the heavens, that there may be darkness over the land of Egypt—a darkness that may be felt—וְיָמֵשׁ חֹשֶׁךְ (ve-yamesh choshech)."

**10:22** And Moses stretched out his hand toward the heavens; and there was thick darkness—חֹשֶׁךְ־אֲפֵלָה (choshech-afelah)—in all the land of Egypt three days.

**10:23** They did not see one another, neither did anyone rise from his place for three days; but all the children of Israel had light in their dwellings.

**10:24** And Pharaoh called unto Moses and said: "Go, serve YHWH; only let your flocks and your herds be stayed; your little ones also may go with you."

**10:25** And Moses said: "You must also give into our hands sacrifices and burnt offerings, that we may sacrifice unto YHWH our Consciousness.

**10:26** "Our livestock also shall go with us; not a hoof shall be left behind—לֹא תִשָּׁאֵר פַּרְסָה (lo tisha'er parsah); for from them we must take to serve YHWH our Consciousness; and we do not know with what we must serve YHWH until we come there."

**10:27** And YHWH hardened Pharaoh's heart, and he would not let them go.

**10:28** And Pharaoh said unto him: "Go from me! Take heed to yourself! See my face no more! For in the day you see my face you shall die!"

**10:29** And Moses said: "You have spoken well; I will see your face again no more."

---

## Synthesis Notes

**Key Restorations:**

**The Purpose of Hardening:**
YHWH explicitly states the purpose of hardening Pharaoh:
- "That I might show these signs"
- "That you may tell your children and grandchildren"
- "That you may know that I am YHWH"

The plagues become narrative—story to be transmitted across generations. Suffering produces testimony.

**"How Long Will You Refuse to Humble Yourself?":**
*Le'anot mippanai* (לֵעָנֹת מִפָּנָי)—to humble yourself, to be afflicted before my face. The same root (*anah*) as Israel's affliction in Egypt. Pharaoh is called to experience what he has inflicted.

**The Eighth Plague: Locusts (אַרְבֶּה, arbeh):**

The locusts consume what the hail left:
- Cover "the eye of the earth" (*ein ha-arets*)—the surface, the visible land
- Fill houses
- Eat every green thing
- Unprecedented: none before or after like them

**Pharaoh's Servants Break:**
For the first time, Pharaoh's own advisors urge release: "Do you not yet know that Egypt is destroyed?" The word *avdah* (אָבְדָה)—perished, lost. The court recognizes what Pharaoh refuses to acknowledge.

**The Negotiation:**
Pharaoh asks: "Who shall go?" Moses: everyone—young, old, sons, daughters, flocks, herds. Pharaoh: only the men. He sees through the request—if everyone goes, they won't return.

**"Evil Is Before Your Faces":**
Pharaoh's curse/warning: *ra'ah* (evil) awaits them. He threatens divine or practical consequences. Some read this as accusation: "You have evil intentions."

**The East Wind:**
*Ruach qadim* (רוּחַ קָדִים)—the east wind, the desert wind, the hot destructive wind. It blows all day and night, carrying the locusts. Wind as instrument of plague.

**The West Wind:**
*Ruach-yam* (רוּחַ־יָם)—literally "sea wind" from the Mediterranean. It drives the locusts into the Sea of Reeds (*Yam Suf*). The same sea that will soon part.

**"Take Away from Me This Death":**
Pharaoh calls the locusts "this death." The agricultural destruction is existential—no crops means no food means death. His confession ("I have sinned") is desperate, not genuine.

**The Ninth Plague: Darkness (חֹשֶׁךְ, choshech):**

This plague attacks Ra, the sun god—Egypt's supreme deity:
- "Darkness that may be felt" (*ve-yamesh*)—thick, tangible, oppressive
- Three days—echoing creation's timeframe
- No one sees another; no one rises
- But Israel has light in their dwellings

**Thick Darkness (חֹשֶׁךְ־אֲפֵלָה):**
Double terminology emphasizing intensity. *Afelah* is deep gloom, the darkness of Sheol. This is anti-creation—return to the darkness before "Let there be light."

**The Final Negotiation:**
Pharaoh's last offer: people and children may go, but livestock stays. This is economic hostage-taking—without flocks and herds, they must return.

Moses refuses: "Not a hoof shall be left behind."

**"See My Face No More":**
Pharaoh banishes Moses with a death threat. Moses accepts: "I will see your face again no more." This is the final break. The next encounter will be the announcement of death.

**Archetypal Layer:** The penultimate plagues attack:
8. Vegetation (agricultural life)—locusts consume all green
9. Light itself (cosmic order)—darkness covers the land

**Darkness** in the symbol map relates to the unconscious, to the formless, to anti-creation. Egypt experiences the undoing of cosmic order—the sun god is defeated.

**Psychological Reading:** Pharaoh's servants see what he cannot: "Egypt is destroyed." The support structure begins to fracture. Pharaoh's negotiating positions shrink: only men → men and children → all but livestock. Each concession reveals his diminishing control.

The darkness is existential: "They did not see one another, neither did anyone rise from his place." Isolation and paralysis—the psychological condition of total defeat.

**Ethical Inversion Applied:**
- The light/darkness distinction continues the Goshen pattern
- Israel has light while Egypt has darkness
- This is not geography but metaphysics—covenant people dwell in light
- Pharaoh's final threat ("see my face no more") becomes truth—their relationship is over
- The court's recognition ("Egypt is destroyed") shows that systems can see their own collapse while leaders deny it

**Modern Equivalent:** When a system is failing, advisors often see it before leaders. "Don't you know Egypt is destroyed?" is the voice of reality against denial. Negotiations shrink as power diminishes. And finally the ultimatum comes—"see my face no more"—the complete break that precedes final crisis.

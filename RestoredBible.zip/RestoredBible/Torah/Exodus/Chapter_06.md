# Exodus Chapter 6: YHWH's Response and the Genealogy

*From the Hebrew: וָאֵרָא (Va'era) — And I Appeared*

---

**6:1** And YHWH said unto Moses: "Now you shall see what I will do to Pharaoh; for by a strong hand he shall let them go, and by a strong hand he shall drive them out of his land."

**6:2** And Consciousness spoke unto Moses and said unto him: "I am YHWH.

**6:3** "And I appeared unto Abraham, unto Isaac, and unto Jacob as El Shaddai—אֵל שַׁדָּי; but by my name YHWH—יהוה—I was not known to them.

**6:4** "And I also established my covenant with them, to give them the land of Canaan, the land of their sojournings, wherein they sojourned.

**6:5** "And I have also heard the groaning of the children of Israel, whom the Egyptians hold in bondage; and I have remembered my covenant.

**6:6** "Therefore say unto the children of Israel: 'I am YHWH, and I will bring you out—וְהוֹצֵאתִי (ve-hotseti)—from under the burdens of the Egyptians, and I will deliver you—וְהִצַּלְתִּי (ve-hitsalti)—from their bondage, and I will redeem you—וְגָאַלְתִּי (ve-ga'alti)—with an outstretched arm and with great judgments.

**6:7** "'And I will take you—וְלָקַחְתִּי (ve-laqachti)—to me for a people, and I will be to you a Consciousness; and you shall know that I am YHWH your Consciousness, who brings you out from under the burdens of Egypt.

**6:8** "'And I will bring you—וְהֵבֵאתִי (ve-heveti)—unto the land which I lifted up my hand to give to Abraham, to Isaac, and to Jacob; and I will give it to you for a heritage. I am YHWH.'"

**6:9** And Moses spoke thus unto the children of Israel; but they did not listen unto Moses because of shortness of spirit—מִקֹּצֶר רוּחַ (mi-qotser ruach)—and because of hard bondage.

**6:10** And YHWH spoke unto Moses, saying:

**6:11** "Go in, speak unto Pharaoh king of Egypt, that he let the children of Israel go out of his land."

**6:12** And Moses spoke before YHWH, saying: "Behold, the children of Israel have not listened unto me; how then shall Pharaoh listen to me, and I am of uncircumcised lips—עֲרַל שְׂפָתָיִם (aral sefatayim)?"

**6:13** And YHWH spoke unto Moses and unto Aaron, and gave them a charge unto the children of Israel and unto Pharaoh king of Egypt, to bring the children of Israel out of the land of Egypt.

---

**6:14** These are the heads of their fathers' houses. The sons of Reuben, the firstborn of Israel: Hanoch and Pallu, Hezron and Carmi; these are the families of Reuben.

**6:15** And the sons of Simeon: Jemuel and Jamin and Ohad and Jachin and Zohar, and Shaul the son of a Canaanite woman; these are the families of Simeon.

**6:16** And these are the names of the sons of Levi according to their generations: Gershon and Kohath and Merari; and the years of the life of Levi were one hundred and thirty-seven years.

**6:17** The sons of Gershon: Libni and Shimei, according to their families.

**6:18** And the sons of Kohath: Amram and Izhar and Hebron and Uzziel; and the years of the life of Kohath were one hundred and thirty-three years.

**6:19** And the sons of Merari: Mahli and Mushi. These are the families of the Levites according to their generations.

**6:20** And Amram took Jochebed—יוֹכֶבֶד (Yokheved)—his father's sister, as wife; and she bore him Aaron and Moses; and the years of the life of Amram were one hundred and thirty-seven years.

**6:21** And the sons of Izhar: Korah and Nepheg and Zichri.

**6:22** And the sons of Uzziel: Mishael and Elzaphan and Sithri.

**6:23** And Aaron took Elisheba—אֱלִישֶׁבַע (Elisheva)—the daughter of Amminadab, the sister of Nahshon, as wife; and she bore him Nadab and Abihu, Eleazar and Ithamar.

**6:24** And the sons of Korah: Assir and Elkanah and Abiasaph; these are the families of the Korahites.

**6:25** And Eleazar, Aaron's son, took one of the daughters of Putiel as wife; and she bore him Phinehas. These are the heads of the fathers of the Levites according to their families.

**6:26** This is that Aaron and Moses, to whom YHWH said: "Bring out the children of Israel from the land of Egypt according to their hosts."

**6:27** These are they who spoke to Pharaoh king of Egypt, to bring out the children of Israel from Egypt; this is that Moses and Aaron.

---

**6:28** And it came to pass, on the day when YHWH spoke unto Moses in the land of Egypt,

**6:29** That YHWH spoke unto Moses, saying: "I am YHWH; speak unto Pharaoh king of Egypt all that I speak unto you."

**6:30** And Moses said before YHWH: "Behold, I am of uncircumcised lips; how shall Pharaoh listen unto me?"

---

## Synthesis Notes

**Key Restorations:**

**"Now You Shall See":**
YHWH's response to Moses' complaint (5:22-23) is not rebuke but promise. The delay is about to end. Pharaoh will not just let them go—he will drive them out.

**The Names of God:**

A crucial theological statement:
- "I appeared to Abraham, Isaac, and Jacob as El Shaddai"
- "But by my name YHWH I was not known to them"

This is complex, since Genesis uses YHWH from the beginning. Possible readings:
- The patriarchs knew the name but not its full meaning
- The name YHWH is now revealed with new depth
- Different source traditions are woven together

The restoration notes the tension without forcing resolution. What is clear: something new is being revealed about the divine name.

**The Five Verbs of Redemption (6:6-8):**

These become liturgically central:
1. **וְהוֹצֵאתִי** (ve-hotseti): "I will bring you out" — from under the burdens
2. **וְהִצַּלְתִּי** (ve-hitsalti): "I will deliver you" — from bondage
3. **וְגָאַלְתִּי** (ve-ga'alti): "I will redeem you" — with outstretched arm
4. **וְלָקַחְתִּי** (ve-laqachti): "I will take you" — as my people
5. **וְהֵבֵאתִי** (ve-heveti): "I will bring you" — into the land

These correspond to the four cups of the Passover Seder (the fifth, for "I will bring," is Elijah's cup—the promise not yet fully realized).

**"I Will Redeem" (וְגָאַלְתִּי, ve-ga'alti):**
The root גָּאַל (ga'al) is the kinsman-redeemer concept—one who recovers what is lost, who buys back family from slavery, who restores inheritance. YHWH acts as Israel's kinsman-redeemer.

**"Shortness of Spirit" (קֹצֶר רוּחַ, qotser ruach):**
The people cannot hear Moses because they are crushed—literally "short of breath" or "constricted spirit." Oppression contracts the soul; they cannot receive good news. Their condition prevents hope.

**"Uncircumcised Lips" (עֲרַל שְׂפָתָיִם, aral sefatayim):**
Moses returns to his speech impediment, but with new language—his lips are "uncircumcised," blocked, unready. The metaphor suggests something that needs to be cut away before function.

**The Genealogy:**

The narrative pauses for genealogy—specifically tracing Moses and Aaron:
- Reuben's sons (firstborn, but not the line of Moses)
- Simeon's sons (second, not the line)
- Levi's sons → Kohath → Amram → Aaron and Moses

The genealogy authenticates Moses and Aaron's Levitical lineage. It also introduces key figures:
- **Jochebed** (יוֹכֶבֶד): Moses' mother, finally named. Her name means "YHWH is glory"—containing the divine name.
- **Elisheba** (אֱלִישֶׁבַע): Aaron's wife, "my God is abundance/oath"
- **Nadab, Abihu, Eleazar, Ithamar**: Aaron's sons, the priestly line
- **Phinehas**: Aaron's grandson, who will become zealous priest

**"This Is That Moses and Aaron":**
The emphatic repetition (6:26-27) brackets the genealogy, emphasizing: these specific men, from this specific lineage, are the ones who will confront Pharaoh.

**Archetypal Layer:** The divine response to crisis is promise, not punishment. YHWH answers Moses' complaint with expanded revelation—the name, the five-fold promise, the covenant memory. But the people are too crushed to hear. Liberation requires not just divine action but human capacity to receive.

**Psychological Reading:** Trauma ("shortness of spirit") blocks reception. The people cannot hear good news because their psychic space is constricted by suffering. Moses' "uncircumcised lips" represents the prophet's sense of being blocked, not ready, impure for the task. Divine response: persist anyway.

**Ethical Inversion Applied:**
- YHWH's "I was not known" suggests progressive revelation—not all truth given at once
- The kinsman-redeemer concept (*ga'al*) places YHWH in familial relationship with Israel
- The people's inability to hear is not blamed—it is understood as consequence of oppression
- The genealogy anchors cosmic promise in specific human lineage

**Modern Equivalent:** Those deeply oppressed may be unable to hear liberation promises. "Shortness of spirit" is the psychological condition of the crushed. Liberators must persist even when the oppressed cannot yet receive hope. And progressive revelation means we may not have understood everything at first—new depth emerges.

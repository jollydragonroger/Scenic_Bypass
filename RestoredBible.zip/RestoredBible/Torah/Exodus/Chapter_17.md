# Exodus Chapter 17: Water from the Rock and Battle with Amalek

*From the Hebrew: Testing and Warfare*

---

**17:1** And all the congregation of the children of Israel journeyed from the wilderness of Sin, by their journeys, according to the commandment of YHWH, and encamped at Rephidim; and there was no water for the people to drink.

**17:2** And the people contended with Moses—וַיָּרֶב הָעָם (va-yarev ha-am)—and said: "Give us water that we may drink." And Moses said unto them: "Why do you contend with me? Why do you test YHWH—מַה־תְּנַסּוּן אֶת־יהוה (mah-tenassun et-YHWH)?"

**17:3** And the people thirsted there for water, and the people murmured against Moses, and said: "Why is this that you have brought us up out of Egypt, to kill us and our children and our livestock with thirst?"

**17:4** And Moses cried unto YHWH, saying: "What shall I do unto this people? A little more and they will stone me."

**17:5** And YHWH said unto Moses: "Pass on before the people, and take with you some of the elders of Israel; and your staff, with which you struck the River, take in your hand, and go.

**17:6** "Behold, I will stand before you there upon the rock in Horeb; and you shall strike the rock—וְהִכִּיתָ בַצּוּר (ve-hikkita va-tsur)—and water shall come out of it, that the people may drink." And Moses did so in the sight of the elders of Israel.

**17:7** And he called the name of the place Massah and Meribah—מַסָּה וּמְרִיבָה (Massah u-Merivah)—because of the contention of the children of Israel, and because they tested YHWH, saying, "Is YHWH among us or not?—הֲיֵשׁ יהוה בְּקִרְבֵּנוּ אִם־אָיִן (ha-yesh YHWH be-qirbenu im-ayin)?"

---

**17:8** And Amalek came and fought with Israel at Rephidim.

**17:9** And Moses said unto Joshua—יְהוֹשֻׁעַ (Yehoshu'a): "Choose for us men, and go out, fight with Amalek. Tomorrow I will stand on the top of the hill with the staff of Consciousness in my hand."

**17:10** And Joshua did as Moses had said to him, to fight with Amalek; and Moses, Aaron, and Hur went up to the top of the hill.

**17:11** And it came to pass, when Moses held up his hand, that Israel prevailed; and when he let down his hand, Amalek prevailed.

**17:12** And Moses' hands were heavy; and they took a stone and put it under him, and he sat upon it; and Aaron and Hur held up his hands, the one on one side and the other on the other side; and his hands were steady—אֱמוּנָה (emunah)—until the going down of the sun.

**17:13** And Joshua weakened Amalek and his people with the edge of the sword.

**17:14** And YHWH said unto Moses: "Write this for a memorial in the book, and rehearse it in the ears of Joshua: that I will utterly blot out—מָחֹה אֶמְחֶה (machoh emcheh)—the remembrance of Amalek from under heaven."

**17:15** And Moses built an altar and called its name YHWH-nissi—יהוה נִסִּי (YHWH Nissi), "YHWH is my banner."

**17:16** And he said: "For a hand upon the throne of Yah!—כִּי־יָד עַל־כֵּס יָהּ (ki-yad al-kes Yah)—YHWH will have war with Amalek from generation to generation."

---

## Synthesis Notes

**Key Restorations:**

**Rephidim:**
Another waterless camp. The pattern continues: journey → crisis → complaint → provision. The people have seen manna fall daily, yet water shortage produces immediate panic.

**"Why Do You Test YHWH?":**
Moses reframes their complaint. The question "Give us water" becomes a test of YHWH—doubting whether YHWH is present, whether YHWH can or will provide. Complaint masks unbelief.

**"Is YHWH Among Us or Not?":**
This is the core question Israel keeps asking. Despite the plagues, the sea crossing, the manna—still they doubt presence. Each crisis erases previous evidence. The question reveals the unstable faith of the recently liberated.

**Moses' Fear:**
"A little more and they will stone me." Moses is genuinely afraid. The people's frustration is violent. Leadership of the liberated is dangerous.

**The Rock at Horeb:**
The same Horeb where Moses encountered the burning bush. YHWH will "stand before you there upon the rock." The rock is struck; water flows. The staff that turned the Nile to blood now produces life-giving water.

**Massah and Meribah:**
- *Massah* (מַסָּה): "Testing"—where Israel tested YHWH
- *Meribah* (מְרִיבָה): "Contention"—where Israel contended with Moses

These names become bywords for Israel's faithlessness. Psalm 95:8-9: "Do not harden your hearts as at Meribah, as in the day of Massah in the wilderness."

**Amalek:**
The first military enemy Israel faces. Amalek is a descendant of Esau (Genesis 36:12). They attack the vulnerable Israelites—Deuteronomy 25:17-18 says they "attacked you on the way when you were faint and weary, and cut off your stragglers."

**Joshua Introduced:**
*Yehoshu'a* (יְהוֹשֻׁעַ)—"YHWH is salvation." He appears suddenly, already Moses' military commander. He will become Moses' successor.

**The Raised Hands:**

Moses on the hilltop with upraised staff creates an iconic image:
- When hands are up, Israel prevails
- When hands drop, Amalek prevails

The battle is won not by skill alone but by prophetic intercession. Moses' hands become the determining factor.

**"Steady" (אֱמוּנָה, emunah):**
The word translated "steady" is *emunah*—faithfulness, firmness, the same root as "amen" and "believe." Moses' hands are held in *emunah*. The physical steadiness represents spiritual constancy.

**Aaron and Hur:**
They support Moses' arms. Leadership requires support. The leader cannot maintain alone. Hur appears here without introduction; tradition identifies him as related to Miriam.

**"Utterly Blot Out":**
*Machoh emcheh* (מָחֹה אֶמְחֶה)—the doubling intensifies: I will surely, completely, blot out Amalek's memory. This is perpetual enmity. Israel is commanded to remember what Amalek did—and to blot out the memory. The paradox is deliberate.

**YHWH-Nissi:**
"YHWH is my banner" or "YHWH is my standard." The altar commemorates victory. YHWH was the battle-standard under which Israel fought.

**"War from Generation to Generation":**
The conflict with Amalek is ongoing. Saul will be commanded to destroy them (1 Samuel 15); Haman in Esther is identified as an Agagite (Amalekite descendant). The enmity continues.

**Archetypal Layer:** The water from rock is **provision from the impossible**. The rock is dead stone; YHWH stands upon it; water flows. The battle with Amalek introduces **warfare as spiritual discipline**—the outcome depends on intercession as much as combat.

**Psychological Reading:** "Is YHWH among us or not?" is the perpetual question of the anxious psyche. Each crisis raises it afresh; each provision temporarily settles it. The raised hands of Moses symbolize sustained faith—which requires support. The leader cannot hold alone; Aaron and Hur are necessary.

**Ethical Inversion Applied:**
- The people test YHWH—but YHWH responds with provision, not punishment
- Amalek attacks the weak and stragglers—predatory violence against the vulnerable
- The condemnation of Amalek is not ethnic hatred but response to their predatory character
- Victory requires both military action (Joshua) and spiritual intercession (Moses)
- Leadership needs community support (Aaron and Hur)

**Modern Equivalent:** Every liberation faces internal doubt ("Is YHWH among us?") and external attack (Amalek). Leaders under pressure may fear violence from their own people. And the battle is won on two fronts simultaneously—the field and the hill, action and intercession, struggle and prayer. Neither alone is sufficient.

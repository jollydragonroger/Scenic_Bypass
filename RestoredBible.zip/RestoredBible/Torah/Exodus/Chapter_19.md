# Exodus Chapter 19: Arrival at Sinai

*From the Hebrew: The Theophany Prepared*

---

**19:1** In the third month after the children of Israel had gone out of the land of Egypt, on that day, they came into the wilderness of Sinai.

**19:2** And they journeyed from Rephidim and came into the wilderness of Sinai, and encamped in the wilderness; and Israel encamped there before the mountain—נֶגֶד הָהָר (neged ha-har).

**19:3** And Moses went up unto Consciousness, and YHWH called unto him from the mountain, saying: "Thus shall you say to the house of Jacob, and tell the children of Israel:

**19:4** "'You have seen what I did to the Egyptians, and how I bore you on eagles' wings—עַל־כַּנְפֵי נְשָׁרִים (al-kanfei nesharim)—and brought you unto myself.

**19:5** "'And now, if you will indeed obey my voice and keep my covenant, then you shall be my own treasure from among all peoples—סְגֻלָּה מִכָּל־הָעַמִּים (segullah mi-kol-ha-ammim); for all the earth is mine.

**19:6** "'And you shall be unto me a kingdom of priests—מַמְלֶכֶת כֹּהֲנִים (mamlekhet kohanim)—and a holy nation—גוֹי קָדוֹשׁ (goy qadosh).' These are the words which you shall speak unto the children of Israel."

**19:7** And Moses came and called for the elders of the people, and set before them all these words which YHWH commanded him.

**19:8** And all the people answered together and said: "All that YHWH has spoken we will do—נַעֲשֶׂה (na'aseh)." And Moses reported the words of the people unto YHWH.

**19:9** And YHWH said unto Moses: "Behold, I come unto you in a thick cloud—בְּעַב הֶעָנָן (be-av he-anan)—that the people may hear when I speak with you, and may also believe you forever." And Moses told the words of the people unto YHWH.

**19:10** And YHWH said unto Moses: "Go unto the people and sanctify them—וְקִדַּשְׁתָּם (ve-qiddashtam)—today and tomorrow, and let them wash their garments.

**19:11** "And let them be ready for the third day; for on the third day YHWH will come down—יֵרֵד יהוה (yered YHWH)—in the sight of all the people upon Mount Sinai.

**19:12** "And you shall set bounds for the people round about, saying, 'Take heed to yourselves that you go not up into the mountain nor touch the border of it; whoever touches the mountain shall surely be put to death.

**19:13** "'No hand shall touch him, but he shall surely be stoned or shot through; whether beast or man, it shall not live.' When the ram's horn sounds a long blast—בִּמְשֹׁךְ הַיֹּבֵל (bi-meshoch ha-yovel)—they shall come up to the mountain."

**19:14** And Moses went down from the mountain unto the people, and sanctified the people; and they washed their garments.

**19:15** And he said unto the people: "Be ready for the third day; do not come near a woman."

**19:16** And it came to pass on the third day, when it was morning, that there were thunders and lightnings—קֹלֹת וּבְרָקִים (qolot u-veraqim)—and a thick cloud upon the mountain, and the voice of the shofar exceedingly loud; and all the people that were in the camp trembled.

**19:17** And Moses brought forth the people out of the camp to meet Consciousness; and they stood at the lower part of the mountain.

**19:18** And Mount Sinai smoked in its entirety—עָשַׁן כֻּלּוֹ (ashan kullo)—because YHWH descended upon it in fire; and its smoke went up like the smoke of a furnace, and the whole mountain quaked greatly.

**19:19** And the voice of the shofar went on and grew louder and louder; Moses spoke, and Consciousness answered him with a voice—בְּקוֹל (be-qol).

**19:20** And YHWH came down upon Mount Sinai, to the top of the mountain; and YHWH called Moses to the top of the mountain; and Moses went up.

**19:21** And YHWH said unto Moses: "Go down, warn the people, lest they break through unto YHWH to gaze, and many of them fall.

**19:22** "And let the priests also, who come near to YHWH, sanctify themselves, lest YHWH break forth upon them."

**19:23** And Moses said unto YHWH: "The people cannot come up to Mount Sinai; for you yourself warned us, saying, 'Set bounds about the mountain, and sanctify it.'"

**19:24** And YHWH said unto him: "Go, get down, and come up, you and Aaron with you; but let not the priests and the people break through to come up unto YHWH, lest he break forth upon them."

**19:25** And Moses went down unto the people and spoke unto them.

---

## Synthesis Notes

**Key Restorations:**

**The Third Month:**
Fifty days after Passover (approximately)—the basis for Shavuot (Pentecost), the festival commemorating the giving of the Torah. The timing connects liberation and law.

**"Before the Mountain":**
Israel encamps facing Sinai. The entire nation positions itself for encounter. The mountain is the **axis mundi**—meeting point of heaven and earth (from the symbol map).

**"Eagles' Wings":**
*Kanfei nesharim* (כַּנְפֵי נְשָׁרִים)—the image of YHWH carrying Israel like an eagle carries its young. Deuteronomy 32:11 expands this: the eagle stirs up its nest, hovers over its young, catches them on its wings. The exodus was supernatural transport.

**The Covenant Proposal (19:5-6):**

YHWH offers conditional relationship:
- "If you obey my voice and keep my covenant..."
- "You shall be my *segullah*"—treasure, special possession
- "A kingdom of priests"—the whole nation as mediators
- "A holy nation"—set apart for divine purpose

This is not unconditional election but covenantal agreement. The people must respond.

**"All the Earth Is Mine":**
YHWH's claim is universal. Israel's election is not because YHWH is a tribal deity; all earth belongs to YHWH. Israel is chosen *from among* the nations, not in place of them.

**"We Will Do" (נַעֲשֶׂה):**
The people's unified response accepts the covenant before knowing its terms. The commitment precedes the commandments. Later tradition emphasizes: *na'aseh ve-nishma*—"we will do and we will hear/understand" (24:7). Action before comprehension.

**Preparation for Theophany:**
- Sanctification (consecration, ritual purity)
- Washing garments
- Three days of preparation
- Sexual abstinence (temporary ritual purity)
- Boundaries around the mountain

Encounter with the holy requires preparation. The numinous is dangerous.

**The Descent:**
"YHWH will come down upon Mount Sinai"—divine descent. The transcendent becomes localized, approachable (within limits). Fire, smoke, thunder, lightning—the theophany is overwhelming.

**The Boundary of Death:**
Whoever touches the mountain dies. Even animals. The holiness is so intense that physical contact is fatal. This is not arbitrary rule but the nature of the holy—the finite cannot casually contact the infinite.

**The Shofar:**
The ram's horn sounds—not blown by human hands but sounding from the mountain itself. It grows louder, not softer. The supernatural source is evident.

**Fire and Smoke:**
"YHWH descended upon it in fire"—**fire = transformation, revelation** (symbol map). The mountain becomes furnace. The smoke ascends like sacrificial smoke, but the whole mountain is the altar.

**"Moses Spoke, and Consciousness Answered with a Voice":**
Dialogue between human and divine. Moses speaks into the thunder; a voice answers. This is the basis for prophetic communication—speech and response.

**The Warning Repeated:**
Even as theophany occurs, YHWH warns again: don't let the people break through. The fascination with the holy (*mysterium fascinans*) must be balanced with terror (*mysterium tremendum*). The people might rush forward to their own destruction.

**"Lest YHWH Break Forth":**
The divine is not safe. Holiness is not gentle. Unprepared encounter with YHWH is destruction. The boundaries protect, not restrict.

**Archetypal Layer:** Sinai is the supreme **mountain/temple—axis of integration** (symbol map). Heaven touches earth; the divine speaks audibly; law is given. The fire and smoke mark the threshold between realms. The people stand at the base; Moses ascends; only the top is where YHWH dwells.

**Psychological Reading:** The encounter with the numinous requires preparation. The ego cannot casually approach the Self. Boundaries, purification, waiting—these structure the encounter so it transforms rather than destroys. The trembling is appropriate; the holy is terrifying.

**Ethical Inversion Applied:**
- Israel is chosen not for superiority but for service—"kingdom of priests" means serving others
- "All the earth is mine" relativizes Israel's specialness—they are part of divine purpose, not its totality
- The people commit before knowing terms—faith precedes full understanding
- The dangerous holiness is protected by boundaries—grace includes warning

**Modern Equivalent:** Genuine encounter with the transcendent requires preparation—it cannot be casual. Systems that trivialize the sacred lose its power; systems that approach carelessly are harmed. And collective commitment ("we will do") creates community before details are negotiated.

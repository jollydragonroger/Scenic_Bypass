# Exodus Chapter 28: The Priestly Garments

*From the Hebrew: בִּגְדֵי קֹדֶשׁ (Bigdei Qodesh) — Holy Vestments*

---

**28:1** "And you, bring near unto you Aaron your brother, and his sons with him, from among the children of Israel, that he may minister unto me as priest—לְכַהֲנוֹ־לִי (le-chahano-li)—Aaron, Nadab and Abihu, Eleazar and Ithamar, Aaron's sons.

**28:2** "And you shall make holy garments—בִּגְדֵי־קֹדֶשׁ (bigdei-qodesh)—for Aaron your brother, for glory and for beauty—לְכָבוֹד וּלְתִפְאָרֶת (le-chavod u-le-tif'aret).

**28:3** "And you shall speak unto all who are wise of heart—חַכְמֵי־לֵב (chachmei-lev)—whom I have filled with the spirit of wisdom, that they make Aaron's garments to sanctify him, that he may minister unto me as priest.

**28:4** "And these are the garments which they shall make: a breastpiece—חֹשֶׁן (choshen)—and an ephod—אֵפוֹד (efod)—and a robe—מְעִיל (me'il)—and a tunic of checkered work—כְּתֹנֶת תַּשְׁבֵּץ (ketonet tashbets)—a turban—מִצְנֶפֶת (mitsnefet)—and a sash—אַבְנֵט (avnet). And they shall make holy garments for Aaron your brother and his sons, that he may minister unto me as priest.

**28:5** "And they shall take the gold and the blue and the purple and the scarlet yarn and the fine linen.

---

**28:6** "And they shall make the ephod of gold, of blue and of purple, of scarlet yarn and of fine twisted linen, the work of the skillful workman.

**28:7** "It shall have two shoulder pieces attached to its two ends, that it may be joined together.

**28:8** "And the skillfully woven band of the ephod, which is upon it, shall be of the same workmanship and of one piece with it: of gold, of blue and purple and scarlet yarn and fine twisted linen.

**28:9** "And you shall take two onyx stones—אַבְנֵי־שֹׁהַם (avnei-shoham)—and engrave on them the names of the sons of Israel:

**28:10** "Six of their names on the one stone, and the names of the remaining six on the other stone, according to their birth.

**28:11** "With the work of an engraver in stone, like the engravings of a signet, you shall engrave the two stones with the names of the sons of Israel; you shall make them enclosed in settings of gold filigree.

**28:12** "And you shall put the two stones upon the shoulder pieces of the ephod, stones of memorial for the sons of Israel; and Aaron shall bear their names before YHWH upon his two shoulders for a memorial.

**28:13** "And you shall make settings of gold filigree,

**28:14** "And two chains of pure gold; like cords you shall make them, of twisted work; and you shall fasten the corded chains to the settings.

---

**28:15** "And you shall make a breastpiece of judgment—חֹשֶׁן מִשְׁפָּט (choshen mishpat)—the work of a skillful workman; like the work of the ephod you shall make it: of gold, of blue and purple and scarlet yarn, and of fine twisted linen you shall make it.

**28:16** "Square it shall be and doubled; a span its length and a span its breadth.

**28:17** "And you shall set in it settings of stones, four rows of stones: a row of sardius, topaz, and carbuncle shall be the first row;

**28:18** "And the second row: an emerald, a sapphire, and a diamond;

**28:19** "And the third row: a jacinth, an agate, and an amethyst;

**28:20** "And the fourth row: a beryl, and an onyx, and a jasper; they shall be enclosed in gold in their settings.

**28:21** "And the stones shall be according to the names of the sons of Israel, twelve, according to their names; like the engravings of a signet, each according to his name, they shall be for the twelve tribes.

**28:22** "And you shall make upon the breastpiece chains like cords, of twisted work of pure gold.

**28:23** "And you shall make upon the breastpiece two rings of gold, and shall put the two rings on the two ends of the breastpiece.

**28:24** "And you shall put the two cords of gold in the two rings at the ends of the breastpiece.

**28:25** "And the other two ends of the two cords you shall put on the two settings, and attach them to the shoulder pieces of the ephod in the front.

**28:26** "And you shall make two rings of gold and put them upon the two ends of the breastpiece, on its edge which is toward the ephod on the inside.

**28:27** "And you shall make two rings of gold and put them on the two shoulder pieces of the ephod underneath, in front, close to where it is joined, above the skillfully woven band of the ephod.

**28:28** "And they shall bind the breastpiece by its rings unto the rings of the ephod with a cord of blue, that it may be upon the skillfully woven band of the ephod, and that the breastpiece may not come loose from the ephod.

**28:29** "And Aaron shall bear the names of the sons of Israel in the breastpiece of judgment upon his heart, when he goes into the holy place, for a memorial before YHWH continually.

**28:30** "And you shall put in the breastpiece of judgment the Urim and the Thummim—הָאוּרִים וְאֶת־הַתֻּמִּים (ha-Urim ve-et-ha-Tummim)—and they shall be upon Aaron's heart when he goes in before YHWH; and Aaron shall bear the judgment of the children of Israel upon his heart before YHWH continually.

---

**28:31** "And you shall make the robe of the ephod all of blue.

**28:32** "And there shall be an opening for the head in the midst of it; it shall have a binding of woven work around its opening, like the opening of a coat of mail, that it may not be torn.

**28:33** "And upon its hem you shall make pomegranates of blue and purple and scarlet yarn, all around its hem, and bells of gold between them all around:

**28:34** "A golden bell and a pomegranate, a golden bell and a pomegranate, upon the hem of the robe all around.

**28:35** "And it shall be upon Aaron to minister; and its sound shall be heard when he goes into the holy place before YHWH, and when he comes out, that he not die.

---

**28:36** "And you shall make a plate of pure gold and engrave upon it, like the engravings of a signet: HOLY TO YHWH—קֹדֶשׁ לַיהוה (Qodesh la-YHWH).

**28:37** "And you shall put it on a cord of blue, and it shall be upon the turban; upon the front of the turban it shall be.

**28:38** "And it shall be upon Aaron's forehead, and Aaron shall bear the iniquity of the holy things—עֲוֺן הַקֳּדָשִׁים (avon ha-qodashim)—which the children of Israel shall hallow in all their holy gifts; and it shall be upon his forehead always, that they may be accepted before YHWH.

**28:39** "And you shall weave the tunic of checkered work of fine linen, and you shall make the turban of fine linen, and you shall make the sash the work of the embroiderer.

**28:40** "And for Aaron's sons you shall make tunics, and you shall make for them sashes, and you shall make for them headbands, for glory and for beauty.

**28:41** "And you shall put them upon Aaron your brother, and upon his sons with him; and you shall anoint them and ordain them—וּמִלֵּאתָ אֶת־יָדָם (u-mille'ta et-yadam)—and sanctify them, that they may minister unto me as priests.

**28:42** "And you shall make them linen undergarments to cover the flesh of their nakedness; from the hips to the thighs they shall reach.

**28:43** "And they shall be upon Aaron and upon his sons when they go into the tent of meeting, or when they come near unto the altar to minister in the holy place, that they not bear iniquity and die. It shall be a statute forever to him and to his descendants after him."

---

## Synthesis Notes

**Key Restorations:**

**"For Glory and for Beauty":**
*Le-chavod u-le-tif'aret* (לְכָבוֹד וּלְתִפְאָרֶת)—the purpose of the priestly garments is aesthetic and honorific. Beauty matters in worship. The priest is adorned for encounter with the holy.

**"Wise of Heart":**
*Chachmei-lev* (חַכְמֵי־לֵב)—wisdom resides in the heart, not the head. The artisans are "filled with the spirit of wisdom." Sacred art requires divine gifting.

**The Eight Garments of the High Priest:**

1. **Ephod** (אֵפוֹד): Vest-like outer garment, gold-threaded
2. **Breastpiece** (חֹשֶׁן): Attached to ephod, bearing twelve stones
3. **Robe** (מְעִיל): Blue robe worn under the ephod
4. **Tunic** (כְּתֹנֶת): Checkered linen undergarment
5. **Turban** (מִצְנֶפֶת): Head covering
6. **Sash** (אַבְנֵט): Embroidered belt
7. **Gold plate** (צִיץ): "Holy to YHWH" on forehead
8. **Undergarments**: Linen breeches

**The Shoulder Stones:**
Two onyx stones on the ephod's shoulders, each bearing six tribal names. Aaron "bears" the tribes before YHWH. The priest carries the people.

**The Twelve Stones:**
The breastpiece bears twelve gemstones, one for each tribe:
- Row 1: Sardius, topaz, carbuncle
- Row 2: Emerald, sapphire, diamond
- Row 3: Jacinth, agate, amethyst
- Row 4: Beryl, onyx, jasper

Each stone engraved with a tribal name. The priest carries all Israel upon his heart.

**"Upon His Heart":**
The breastpiece is called *choshen mishpat*—"breastpiece of judgment" or "breastpiece of decision." It rests over the heart. Aaron bears the tribes' names "upon his heart before YHWH continually." Intercession is heartwork.

**The Urim and Thummim:**
*Ha-Urim ve-ha-Tummim* (הָאוּרִים וְהַתֻּמִּים)—literally "the lights and the perfections" or "the lights and the truths." Placed within the breastpiece, they are used for divine inquiry (1 Samuel 28:6). The exact mechanism is unknown—perhaps casting lots, perhaps divine illumination. They represent access to divine guidance.

**The Blue Robe:**
Entirely blue—the color of heaven. Its hem has golden bells alternating with pomegranate decorations. The bells sound when the priest moves. "Its sound shall be heard... that he not die." The sound signals his presence; silence would indicate death in the holy place.

**"Holy to YHWH":**
*Qodesh la-YHWH* (קֹדֶשׁ לַיהוה)—engraved on the gold plate worn on the forehead. This marks the priest as consecrated. The declaration is visible to all who see him approach.

**"Bear the Iniquity of the Holy Things":**
Aaron's forehead-plate allows him to bear the imperfection of Israel's offerings. Even sincere worship is flawed; the priest carries that flaw so the offerings are accepted. This is priestly atonement.

**"Fill Their Hands":**
*Mille'ta et-yadam* (מִלֵּאתָ אֶת־יָדָם)—literally "fill their hand." This idiom means ordination—filling the hand with priestly authority and responsibility. The expression appears throughout priestly installation texts.

**Archetypal Layer:** The priest is **clothed in meaning**—every element signifies. The stones carry the tribes; the bells announce presence; the inscription declares consecration. The priest doesn't dress practically but symbolically. His body becomes a text.

The high priest is a **mediating figure**—carrying Israel's names on heart and shoulders, bearing the iniquity of offerings, entering where others cannot go.

**Psychological Reading:** The garments transform identity. Aaron becomes not just himself but the bearer of the twelve tribes. Clothing creates role. The external transformation (garments) enables internal function (priesthood).

**Ethical Inversion Applied:**
- Beauty and glory belong in worship—aesthetics is sacred
- Wisdom is of the heart, not merely the mind
- The priest carries the people—burden as honor
- Imperfect offerings are accepted through priestly mediation
- The bells protect the priest—even the sacred has danger

**Modern Equivalent:** Those who lead in sacred functions are transformed by what they wear and bear. The priest carries others' burdens "upon the heart." Sacred role is not personal achievement but service. And access to divine guidance (Urim and Thummim) represents the need for discernment in leadership—decisions require more than human calculation.

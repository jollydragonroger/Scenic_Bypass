# Exodus Chapter 24: The Covenant Ratified

*From the Hebrew: Blood and Vision*

---

**24:1** And YHWH said unto Moses: "Come up unto YHWH—you, and Aaron, Nadab and Abihu, and seventy of the elders of Israel; and worship from afar.

**24:2** "And Moses alone shall come near unto YHWH; but they shall not come near, neither shall the people go up with him."

**24:3** And Moses came and told the people all the words of YHWH and all the ordinances; and all the people answered with one voice and said: "All the words which YHWH has spoken we will do—כָּל־הַדְּבָרִים אֲשֶׁר־דִּבֶּר יהוה נַעֲשֶׂה (kol-ha-devarim asher-dibber YHWH na'aseh)."

**24:4** And Moses wrote all the words of YHWH, and rose up early in the morning, and built an altar under the mountain, and twelve pillars—מַצֵּבָה (matsevah)—according to the twelve tribes of Israel.

**24:5** And he sent the young men of the children of Israel, and they offered burnt offerings and sacrificed peace offerings of oxen unto YHWH.

**24:6** And Moses took half of the blood and put it in basins; and half of the blood he sprinkled on the altar.

**24:7** And he took the book of the covenant—סֵפֶר הַבְּרִית (sefer ha-berit)—and read in the hearing of the people; and they said: "All that YHWH has spoken we will do, and we will hear—נַעֲשֶׂה וְנִשְׁמָע (na'aseh ve-nishma)."

**24:8** And Moses took the blood and sprinkled it on the people, and said: "Behold the blood of the covenant—דַּם־הַבְּרִית (dam-ha-berit)—which YHWH has made with you concerning all these words."

---

**24:9** And Moses went up, and Aaron, Nadab and Abihu, and seventy of the elders of Israel.

**24:10** And they saw the Consciousness of Israel—וַיִּרְאוּ אֵת אֱלֹהֵי יִשְׂרָאֵל (va-yir'u et Elohei Yisra'el); and under his feet was like a pavement of sapphire stone—לִבְנַת הַסַּפִּיר (livnat ha-sappir)—and like the very heaven for clearness.

**24:11** And upon the nobles of the children of Israel he did not lay his hand; and they beheld Consciousness, and they ate and drank.

**24:12** And YHWH said unto Moses: "Come up to me into the mountain and be there; and I will give you the tablets of stone—לֻחֹת הָאֶבֶן (luchot ha-even)—and the law and the commandment which I have written, to teach them."

**24:13** And Moses rose up, and Joshua his minister; and Moses went up into the mountain of Consciousness.

**24:14** And he said unto the elders: "Wait for us here until we return unto you. And behold, Aaron and Hur are with you; whoever has a matter, let him come unto them."

**24:15** And Moses went up into the mountain, and the cloud covered the mountain.

**24:16** And the glory of YHWH—כְּבוֹד יהוה (kevod YHWH)—dwelt upon Mount Sinai, and the cloud covered it six days; and on the seventh day he called unto Moses out of the midst of the cloud.

**24:17** And the appearance of the glory of YHWH was like devouring fire—אֵשׁ אֹכֶלֶת (esh ochelet)—on the top of the mountain in the eyes of the children of Israel.

**24:18** And Moses entered into the midst of the cloud and went up into the mountain; and Moses was in the mountain forty days and forty nights.

---

## Synthesis Notes

**Key Restorations:**

**The Hierarchical Approach:**
- Moses alone comes near
- Aaron, Nadab, Abihu, and seventy elders worship "from afar"
- The people remain below

Holiness requires gradation. Not everyone can approach equally. The nearer to the divine, the fewer who ascend.

**The Unified Response:**
"All the words which YHWH has spoken we will do." The people speak with one voice—unanimity of consent. The covenant requires agreement from all.

**The Twelve Pillars:**
*Matsevot* (מַצֵּבֹת)—standing stones, one for each tribe. These are permitted here; later they will be associated with Canaanite worship and prohibited (Deuteronomy 16:22). Context determines meaning.

**The Blood Ritual:**

The covenant is ratified with blood:
- Half the blood on the altar (representing YHWH)
- Half the blood on the people

Both parties are bound by the same blood. The covenant is a blood bond—deadly serious, life-binding.

**"We Will Do and We Will Hear" (נַעֲשֶׂה וְנִשְׁמָע):**
This is the famous response. The order is significant: *na'aseh* (we will do) precedes *nishma* (we will hear/understand). Action before full comprehension. Commitment before complete knowledge. Trust enables understanding.

Rabbinic tradition celebrates this: Israel accepted the Torah before knowing all its contents. Faith precedes full disclosure.

**"The Blood of the Covenant":**
*Dam-ha-berit* (דַּם־הַבְּרִית)—the phrase echoed by Jesus at the Last Supper (Matthew 26:28). Blood seals the relationship. The pattern is established here.

**The Vision on the Mountain:**

The seventy elders, with Aaron, Nadab, and Abihu, experience theophany:
- "They saw the Consciousness of Israel"—extraordinary statement; normally "no one can see God and live" (33:20)
- Under his feet: sapphire pavement, clear as heaven
- "He did not lay his hand on them"—they survived the vision
- "They ate and drank"—covenant meal in divine presence

This is the only biblical scene where multiple people see YHWH and live to describe what they saw (sapphire pavement). The meal confirms the covenant—shared eating seals relationship.

**The Sapphire Pavement:**
*Livnat ha-sappir* (לִבְנַת הַסַּפִּיר)—white/brilliant sapphire, the blue of heaven made solid. Ezekiel's vision (Ezekiel 1:26) will echo this—a throne like sapphire. The ground of heaven is visible.

**The Tablets of Stone:**
YHWH will give Moses stone tablets—the law "written" by divine hand. The written form makes the covenant permanent, portable, and transmissible.

**Joshua Accompanies:**
Joshua, Moses' "minister" (*meshareto*), goes partway up. He will reappear in 32:17. His presence sets up his future succession.

**Aaron and Hur Left in Charge:**
The elders are to wait; Aaron and Hur handle disputes. This arrangement will prove fateful—Aaron's leadership in Moses' absence produces the golden calf.

**Six Days, Then the Seventh:**
The cloud covers Sinai six days; on the seventh, YHWH speaks. The creation pattern (six days of work, seventh of rest/completion) structures the theophany.

**Forty Days and Forty Nights:**
Moses enters the cloud and remains forty days and nights. This becomes the archetypal period of transformative encounter—Noah's flood (40 days), Elijah's journey to Horeb (40 days), Jesus' wilderness temptation (40 days).

**"Devouring Fire":**
*Esh ochelet* (אֵשׁ אֹכֶלֶת)—fire that consumes. The appearance of glory is terrifying—the mountain appears to be on fire. **Fire = transformation, revelation** (symbol map). The people below see Moses enter what looks like destruction.

**Archetypal Layer:** The covenant ratification brings together all elements:
- Blood (life, death, binding)
- Vision (divine presence perceived)
- Meal (fellowship sealed)
- Law (written tablets, permanent form)
- Fire (transformation, the dangerous holy)

The **mountain/temple as axis** is fully manifest—heaven touches earth, the elders see what underlies reality, Moses enters the cloud.

**Psychological Reading:** The commitment "we will do and we will hear" models how transformation works: we act before we fully understand; understanding follows action. The ego cannot comprehend the Self before engaging it. The forty days in the cloud is the period of transformation—Moses will return with shining face (34:29).

**Ethical Inversion Applied:**
- Blood binds both parties—YHWH and Israel are covenanted together
- The people commit before knowing everything—trust precedes full disclosure
- The vision includes a meal—the divine is encountered through ordinary human activity (eating)
- Survival of the theophany is remarkable—"he did not lay his hand on them"
- Gradation of access is not elitism but acknowledgment of human limits

**Modern Equivalent:** Genuine commitment often precedes complete understanding. "We will do and we will hear" is the structure of marriage, of vocation, of discipleship—you cannot know fully before you begin. The blood of the covenant marks serious commitment; casual relationship doesn't require blood. And encounter with the transcendent takes time—forty days, not forty minutes.

# Exodus Chapter 7: The Plagues Begin

*From the Hebrew: Blood*

---

**7:1** And YHWH said unto Moses: "See, I have made you a god to Pharaoh—אֱלֹהִים לְפַרְעֹה (elohim le-Far'oh)—and Aaron your brother shall be your prophet.

**7:2** "You shall speak all that I command you, and Aaron your brother shall speak unto Pharaoh, that he let the children of Israel go out of his land.

**7:3** "And I will harden—וַאֲנִי אַקְשֶׁה (va-ani aqsheh)—Pharaoh's heart, and multiply my signs and my wonders in the land of Egypt.

**7:4** "And Pharaoh shall not listen unto you; and I will lay my hand upon Egypt and bring forth my hosts, my people the children of Israel, out of the land of Egypt by great judgments.

**7:5** "And the Egyptians shall know that I am YHWH—וְיָדְעוּ מִצְרַיִם כִּי־אֲנִי יהוה (ve-yad'u Mitsrayim ki-ani YHWH)—when I stretch out my hand upon Egypt and bring out the children of Israel from among them."

**7:6** And Moses and Aaron did so; as YHWH commanded them, so they did.

**7:7** And Moses was eighty years old, and Aaron eighty-three years old, when they spoke unto Pharaoh.

---

**7:8** And YHWH spoke unto Moses and unto Aaron, saying:

**7:9** "When Pharaoh shall speak unto you, saying, 'Show a wonder for yourselves,' then you shall say unto Aaron: 'Take your staff and cast it before Pharaoh,' and it shall become a serpent—תַנִּין (tannin)."

**7:10** And Moses and Aaron came in unto Pharaoh, and they did so, as YHWH had commanded; and Aaron cast down his staff before Pharaoh and before his servants, and it became a serpent.

**7:11** And Pharaoh also called for the wise men and the sorcerers—הַחֲרְטֻמִּים (ha-chartummim); and they also, the magicians of Egypt, did so with their secret arts—בְּלַהֲטֵיהֶם (be-lahateihem).

**7:12** And each man cast down his staff, and they became serpents; but Aaron's staff swallowed up their staffs.

**7:13** And Pharaoh's heart was hardened—וַיֶּחֱזַק (va-yechezaq)—and he did not listen to them, as YHWH had spoken.

---

**7:14** And YHWH said unto Moses: "Pharaoh's heart is heavy—כָּבֵד (kaved); he refuses to let the people go.

**7:15** "Go unto Pharaoh in the morning; behold, he goes out unto the water; and you shall stand to meet him by the bank of the River, and the staff which was turned into a serpent you shall take in your hand.

**7:16** "And you shall say unto him: 'YHWH, the Consciousness of the Hebrews, has sent me unto you, saying: Let my people go, that they may serve me in the wilderness; and behold, you have not listened until now.

**7:17** "'Thus says YHWH: By this you shall know that I am YHWH—בְּזֹאת תֵּדַע כִּי אֲנִי יהוה (be-zot teda ki ani YHWH). Behold, I will strike with the staff that is in my hand upon the waters which are in the River, and they shall be turned to blood.

**7:18** "'And the fish that are in the River shall die, and the River shall stink; and the Egyptians shall loathe to drink water from the River.'"

**7:19** And YHWH said unto Moses: "Say unto Aaron: 'Take your staff and stretch out your hand over the waters of Egypt—over their rivers, over their canals, and over their pools, and over all their gatherings of water—that they may become blood; and there shall be blood throughout all the land of Egypt, both in vessels of wood and in vessels of stone.'"

**7:20** And Moses and Aaron did so, as YHWH commanded; and he lifted up the staff and struck the waters that were in the River, in the sight of Pharaoh and in the sight of his servants; and all the waters that were in the River were turned to blood.

**7:21** And the fish that were in the River died; and the River stank, and the Egyptians could not drink water from the River; and the blood was throughout all the land of Egypt.

**7:22** And the magicians of Egypt did so with their secret arts; and Pharaoh's heart was hardened, and he did not listen to them, as YHWH had spoken.

**7:23** And Pharaoh turned and went into his house, and did not set his heart even to this.

**7:24** And all the Egyptians dug around the River for water to drink; for they could not drink of the water of the River.

**7:25** And seven days were fulfilled after YHWH had struck the River.

---

## Synthesis Notes

**Key Restorations:**

**"I Have Made You a God to Pharaoh":**
Moses becomes *elohim* (אֱלֹהִים) to Pharaoh—a divine figure, a representative of transcendent power. Aaron is his *navi* (prophet/spokesman). The hierarchy mirrors divine structure: YHWH → Moses → Aaron → Pharaoh/Israel.

**The Hardening:**
Three Hebrew verbs describe Pharaoh's heart:
- *Chazaq* (חָזַק): strengthen, harden
- *Kaved* (כָּבֵד): heavy (like in "hardened")
- *Qashah* (קָשָׁה): make stiff, obstinate

Sometimes YHWH hardens; sometimes Pharaoh hardens himself. The interplay continues throughout the plague narrative.

**"The Egyptians Shall Know That I Am YHWH":**
This is the purpose statement of the plagues—not merely punishment but **revelation**. Pharaoh asked "Who is YHWH?" (5:2). The plagues answer.

**The Tannin (תַנִּין):**
Different from the *nachash* (serpent) in chapter 4. *Tannin* is a sea monster, dragon, or crocodile—particularly apt in Egypt, where crocodiles were sacred. Aaron's staff becomes a creature of chaos that swallows the Egyptian magicians' creatures.

**The Magicians (הַחַרְטֻמִּים, ha-chartummim):**
Egyptian priestly magicians who practice *lahat* (secret arts, possibly from the word for "flame" or "blade"). They can replicate the sign—their staffs also become serpents. But Aaron's swallows theirs. Replication is not victory.

**The First Plague: Blood (דָּם, dam):**

The Nile—Egypt's life-source, worshipped as the god Hapi—becomes blood:
- Fish die
- Water stinks
- Egyptians cannot drink

This strikes at the foundation of Egyptian existence. The sacred river becomes death.

**The Magicians Replicate:**
Remarkably, the magicians also turn water to blood. But this only adds to the problem—more blood, less water. Their "success" worsens the situation.

**Pharaoh's Response:**
He "turned and went into his house, and did not set his heart even to this." He dismisses the plague, returns to his palace, refuses engagement. His heart is "heavy" (*kaved*)—the same word as "glory" (כָּבוֹד, kavod). His glory-heart is his weight-heart.

**Seven Days:**
The plague lasts a week—a complete cycle. Then the next phase begins.

**Archetypal Layer:** The plagues begin by attacking the source—the Nile, Egypt's life-blood, becomes literal blood. **Water = collective unconscious, renewal** from the symbol map; **blood = life-force, sacrifice, death**. The life-giving water becomes death-dealing blood. The unconscious source of Egyptian power is corrupted.

**Psychological Reading:** The beast/machine (Pharaoh's system) is confronted with reality it cannot process. The magicians can replicate the sign but not reverse it. They add to the problem. Pharaoh's response—withdrawal, dismissal—is the ego's refusal to engage with the numinous.

**Ethical Inversion Applied:**
- The Nile as god is challenged by YHWH
- Egyptian religious power (magicians) can imitate but not heal
- The purpose is knowledge, not just punishment: "By this you shall know"
- The plagues are revelation before they are judgment

**Ecological-Systemic Reading:** The plagues target Egyptian systems one by one:
1. Water → blood (ecological foundation)
2. Then creatures, agriculture, atmosphere, and finally human life

Each plague escalates, targeting a different layer of the ordered world Egypt has built. The beast/machine is being systematically dismantled.

**Modern Equivalent:** Systems of oppression depend on certain resources they take for granted. When those foundations are disrupted, the system's response is often replication (do more of what worked before) and denial (retreat to the palace). Neither works. The disruption continues until the system yields or collapses.

# Exodus Chapter 3: The Burning Bush

*From the Hebrew: The Call of Moses*

---

**3:1** And Moses was shepherding the flock of Jethro—יִתְרוֹ (Yitro)—his father-in-law, the priest of Midian; and he led the flock to the back of the wilderness and came to the mountain of Consciousness, to Horeb—חֹרֵבָה (Chorevah).

**3:2** And the messenger of YHWH appeared unto him in a flame of fire—בְּלַבַּת־אֵשׁ (be-labbat-esh)—from the midst of a bush—הַסְּנֶה (ha-seneh); and he looked, and behold, the bush was burning with fire, but the bush was not consumed—וְהַסְּנֶה אֵינֶנּוּ אֻכָּל (ve-ha-seneh einennu ukkal).

**3:3** And Moses said: "I will turn aside now and see this great sight—הַמַּרְאֶה הַגָּדֹל (ha-mar'eh ha-gadol)—why the bush is not burned."

**3:4** And YHWH saw that he turned aside to see; and Consciousness called unto him from the midst of the bush, and said: "Moses! Moses!" And he said: "Here I am—הִנֵּנִי (hineni)."

**3:5** And Consciousness said: "Do not come near here; put off your sandals from your feet, for the place upon which you stand is holy ground—אַדְמַת־קֹדֶשׁ (admat-qodesh)."

**3:6** And Consciousness said: "I am the Consciousness of your father, the Consciousness of Abraham, the Consciousness of Isaac, and the Consciousness of Jacob." And Moses hid his face, for he was afraid to look upon the Consciousness.

**3:7** And YHWH said: "I have surely seen—רָאֹה רָאִיתִי (ra'oh ra'iti)—the affliction of my people who are in Egypt, and I have heard their cry because of their taskmasters; for I know their sorrows.

**3:8** "And I have come down to deliver them from the hand of the Egyptians, and to bring them up from that land unto a good and spacious land, unto a land flowing with milk and honey—אֶרֶץ זָבַת חָלָב וּדְבָשׁ (erets zavat chalav u-devash)—unto the place of the Canaanite and the Hittite and the Amorite and the Perizzite and the Hivite and the Jebusite.

**3:9** "And now, behold, the cry of the children of Israel has come unto me; and I have also seen the oppression with which the Egyptians oppress them.

**3:10** "And now come, I will send you unto Pharaoh, and bring my people, the children of Israel, out of Egypt."

**3:11** And Moses said unto Consciousness: "Who am I—מִי אָנֹכִי (mi anochi)—that I should go unto Pharaoh, and that I should bring the children of Israel out of Egypt?"

**3:12** And Consciousness said: "For I will be with you—כִּי־אֶהְיֶה עִמָּךְ (ki-ehyeh immach); and this shall be the sign unto you that I have sent you: when you have brought the people out of Egypt, you shall serve Consciousness upon this mountain."

**3:13** And Moses said unto Consciousness: "Behold, when I come unto the children of Israel and say unto them, 'The Consciousness of your fathers has sent me unto you,' and they say to me, 'What is the name?'—what shall I say unto them?"

**3:14** And Consciousness said unto Moses: "I AM THAT I AM—אֶהְיֶה אֲשֶׁר אֶהְיֶה (Ehyeh Asher Ehyeh)." And Consciousness said: "Thus shall you say unto the children of Israel: 'I AM—אֶהְיֶה (Ehyeh)—has sent me unto you.'"

**3:15** And Consciousness said moreover unto Moses: "Thus shall you say unto the children of Israel: 'YHWH—יהוה—the Consciousness of your fathers, the Consciousness of Abraham, the Consciousness of Isaac, and the Consciousness of Jacob, has sent me unto you.' This is my name forever—זֶה־שְּׁמִי לְעֹלָם (zeh-shemi le-olam)—and this is my memorial unto all generations."

**3:16** "Go and gather the elders of Israel and say unto them: 'YHWH, the Consciousness of your fathers, the Consciousness of Abraham, Isaac, and Jacob, has appeared unto me, saying: I have surely visited you—פָּקֹד פָּקַדְתִּי (paqod paqadti)—and seen what is done to you in Egypt.

**3:17** "'And I have said: I will bring you up from the affliction of Egypt unto the land of the Canaanite and the Hittite and the Amorite and the Perizzite and the Hivite and the Jebusite, unto a land flowing with milk and honey.'

**3:18** "And they shall listen to your voice; and you shall come, you and the elders of Israel, unto the king of Egypt, and you shall say unto him: 'YHWH, the Consciousness of the Hebrews, has met with us; and now, please let us go three days' journey into the wilderness, that we may sacrifice to YHWH our Consciousness.'

**3:19** "And I know that the king of Egypt will not let you go, except by a mighty hand—בְּיָד חֲזָקָה (be-yad chazaqah).

**3:20** "And I will stretch out my hand and strike Egypt with all my wonders which I will do in its midst; and after that he will let you go.

**3:21** "And I will give this people favor in the eyes of the Egyptians; and it shall come to pass, when you go, you shall not go empty.

**3:22** "And every woman shall ask of her neighbor and of her who sojourns in her house, vessels of silver and vessels of gold and garments; and you shall put them upon your sons and upon your daughters, and you shall despoil—וְנִצַּלְתֶּם (ve-nitsaltem)—Egypt."

---

## Synthesis Notes

**Key Restorations:**

**The Mountain of Consciousness:**
Moses leads flocks to Horeb—also called Sinai. The "mountain of Consciousness" is named before Moses knows it as such. He stumbles upon sacred geography.

**The Burning Bush (הַסְּנֶה, ha-seneh):**

The bush burns but is not consumed. **Fire = transformation, revelation, information burst** (from the symbol map). The fire here reveals without destroying. This is theophany—divine manifestation in material form that does not annihilate the material.

The bush (סְנֶה, seneh) may connect to Sinai (סִינַי)—the site of later revelation.

**Moses' Curiosity:**
He turns aside to investigate. YHWH waits until Moses turns—divine encounter requires human attention. The call comes only when Moses shows interest in the mystery.

**"Moses! Moses!":**
The double call—like "Abraham! Abraham!" (Genesis 22:11) and "Jacob! Jacob!" (Genesis 46:2). This signals urgent divine address.

**"Put Off Your Sandals":**
The ground itself is holy. Holiness is not only in the vision but in the ordinary earth. The removal of sandals creates direct contact with sacred ground—vulnerability, humility.

**The Divine Self-Identification:**
"I am the Consciousness of your father"—connecting to ancestral tradition. Moses is not encountering a new god but the god of his fathers, the covenant god.

**The Three Verbs (3:7):**
Consciousness has:
1. **Seen** (רָאָה) the affliction
2. **Heard** (שָׁמַע) the cry
3. **Known** (יָדַע) the sorrows

This echoes 2:24-25. Now the knowing becomes speaking; observation becomes commission.

**"I Have Come Down":**
Divine descent—as at Babel (Genesis 11:5), but here for liberation, not confusion. The transcendent Consciousness enters the situation.

**"Land Flowing with Milk and Honey":**
The first occurrence of this iconic phrase. Milk (pastoral abundance) and honey (natural sweetness/wild plenty) signify a land of effortless fertility—the opposite of Egypt's hard labor.

**Moses' First Objection: "Who Am I?":**
Moses questions his own adequacy. He is no longer the impulsive prince who killed the Egyptian. Forty years in the wilderness have produced humility.

**The Answer: "I Will Be With You":**
*Ki-ehyeh immach* (כִּי־אֶהְיֶה עִמָּךְ)—"For I will be with you." The answer to "who am I?" is not about Moses but about divine presence. Moses' identity is irrelevant; YHWH's presence is sufficient.

**The Sign That Comes After:**
The sign that YHWH sent Moses is: "You will serve upon this mountain." This sign is only verifiable after the exodus is complete. Faith must precede confirmation.

**The Divine Name (אֶהְיֶה אֲשֶׁר אֶהְיֶה, Ehyeh Asher Ehyeh):**

This is the most mysterious and significant name-revelation in Scripture:

- *Ehyeh* (אֶהְיֶה): First person singular of the verb הָיָה (hayah), "to be"
- Translations: "I AM THAT I AM," "I WILL BE WHAT I WILL BE," "I AM WHO I AM"

The name refuses definition. It is not a static identity but dynamic being—presence that will manifest as needed. The name is a verb, not a noun.

**YHWH (יהוה):**
The Tetragrammaton—the four-letter name traditionally not pronounced. Related to *Ehyeh* but in third person: "He is" or "He causes to be." This is "my name forever"—the covenant name, the personal name of the god of Israel.

**"I Have Surely Visited" (פָּקֹד פָּקַדְתִּי):**
The phrase Joseph prophesied (Genesis 50:24-25). The recognition-sign is fulfilled. The visitation has come.

**The Three-Day Request:**
Moses is to ask Pharaoh for a three-day journey to sacrifice. This appears to be a limited request—but YHWH already knows Pharaoh will refuse. The modest request exposes Pharaoh's absolute resistance.

**Despoiling Egypt:**
The departing Israelites will take Egyptian wealth—compensation for generations of slave labor. The exodus is not escape of the impoverished but departure of the enriched.

**Archetypal Layer:** The burning bush is the **axis mundi**—the mountain/temple of the symbol map, "axis of integration, meeting of realms." Fire that does not consume is spirit that manifests without destroying matter. Moses encounters the numinous and receives the impossible commission.

**Psychological Reading:** The encounter at the bush is the ego meeting the Self. Moses' question "Who am I?" is answered not with ego-inflation but with assurance of transcendent presence. The name "I AM" is pure being encountering limited human consciousness.

**Ethical Inversion Applied:**
- The god who speaks is not distant but has "come down"
- The liberation is not human achievement but divine initiative
- Moses' inadequacy is irrelevant—presence is sufficient
- The oppressed will leave wealthy—justice includes compensation

**Modern Equivalent:** Genuine calling often comes in unexpected places (back of the wilderness) and requires turning aside from routine. The question "Who am I to do this?" is answered not with self-esteem but with "I will be with you." And systems of oppression (Pharaoh) will not yield to reasonable requests—only to confrontation with power.

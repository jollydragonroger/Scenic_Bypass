# Exodus Chapter 32: The Golden Calf

*From the Hebrew: כִּי תִשָּׂא (Ki Tissa) — The Great Apostasy*

---

**32:1** And when the people saw that Moses delayed to come down from the mountain, the people gathered themselves together unto Aaron and said unto him: "Arise, make us gods—אֱלֹהִים (elohim)—who shall go before us; for this Moses, the man who brought us up out of the land of Egypt, we do not know what has become of him."

**32:2** And Aaron said unto them: "Break off the golden rings which are in the ears of your wives, of your sons, and of your daughters, and bring them unto me."

**32:3** And all the people broke off the golden rings which were in their ears, and brought them unto Aaron.

**32:4** And he took them from their hand, and fashioned it with an engraving tool, and made it a molten calf—עֵגֶל מַסֵּכָה (egel massechah); and they said: "These are your gods, O Israel, which brought you up out of the land of Egypt!"

**32:5** And Aaron saw, and he built an altar before it; and Aaron made proclamation and said: "Tomorrow shall be a feast to YHWH—חַג לַיהוה (chag la-YHWH)."

**32:6** And they rose up early on the morrow, and offered burnt offerings, and brought peace offerings; and the people sat down to eat and to drink, and rose up to play—לְצַחֵק (le-tsacheq).

---

**32:7** And YHWH spoke unto Moses: "Go, get down; for your people, whom you brought up out of the land of Egypt, have corrupted themselves.

**32:8** "They have turned aside quickly from the way which I commanded them; they have made themselves a molten calf, and have worshipped it, and have sacrificed unto it, and said, 'These are your gods, O Israel, which brought you up out of the land of Egypt.'"

**32:9** And YHWH said unto Moses: "I have seen this people, and behold, it is a stiff-necked people—עַם־קְשֵׁה־עֹרֶף (am-qesheh-oref).

**32:10** "Now therefore let me alone, that my anger may burn against them and that I may consume them; and I will make of you a great nation."

**32:11** And Moses besought YHWH his Consciousness, and said: "YHWH, why does your anger burn against your people, whom you have brought out of the land of Egypt with great power and with a mighty hand?

**32:12** "Why should the Egyptians say, 'For evil he brought them out, to kill them in the mountains and to consume them from the face of the earth'? Turn from your burning anger, and relent concerning this evil against your people.

**32:13** "Remember Abraham, Isaac, and Israel, your servants, to whom you swore by your own self, and said unto them, 'I will multiply your seed as the stars of heaven, and all this land that I have spoken of I will give to your seed, and they shall inherit it forever.'"

**32:14** And YHWH relented concerning the evil which he had spoken of doing unto his people—וַיִּנָּחֶם יהוה עַל־הָרָעָה (va-yinnachem YHWH al-ha-ra'ah).

---

**32:15** And Moses turned and went down from the mountain, and the two tablets of the testimony were in his hand; tablets written on both their sides—on the one side and on the other they were written.

**32:16** And the tablets were the work of Consciousness, and the writing was the writing of Consciousness, engraved upon the tablets.

**32:17** And Joshua heard the noise of the people as they shouted, and he said unto Moses: "There is a noise of war in the camp."

**32:18** And Moses said: "It is not the sound of the cry of victory, nor is it the sound of the cry of defeat; it is the sound of singing that I hear."

**32:19** And it came to pass, as soon as he came near unto the camp, that he saw the calf and the dancing; and Moses' anger burned, and he threw the tablets out of his hands, and broke them at the foot of the mountain.

**32:20** And he took the calf which they had made, and burned it with fire, and ground it to powder, and scattered it upon the water, and made the children of Israel drink it.

**32:21** And Moses said unto Aaron: "What did this people do unto you, that you have brought a great sin upon them?"

**32:22** And Aaron said: "Let not the anger of my lord burn; you know the people, that they are set on evil.

**32:23** "And they said unto me, 'Make us gods who shall go before us; for this Moses, the man who brought us up out of the land of Egypt, we do not know what has become of him.'

**32:24** "And I said unto them, 'Whoever has any gold, let them break it off.' So they gave it to me, and I cast it into the fire, and out came this calf—וַיֵּצֵא הָעֵגֶל הַזֶּה (va-yetse ha-egel ha-zeh)."

**32:25** And Moses saw that the people had broken loose—פָרֻעַ (parua)—for Aaron had let them break loose, to their shame among their enemies.

**32:26** Then Moses stood in the gate of the camp and said: "Whoever is for YHWH, come to me!—מִי לַיהוה אֵלָי (mi la-YHWH elai)!" And all the sons of Levi gathered themselves together unto him.

**32:27** And he said unto them: "Thus says YHWH, the Consciousness of Israel: 'Put every man his sword upon his thigh, and go back and forth from gate to gate throughout the camp, and slay every man his brother, and every man his companion, and every man his neighbor.'"

**32:28** And the sons of Levi did according to the word of Moses; and there fell of the people that day about three thousand men.

**32:29** And Moses said: "Consecrate yourselves today unto YHWH—מִלְאוּ יֶדְכֶם הַיּוֹם לַיהוה (mil'u yedchem ha-yom la-YHWH)—for each man has been against his son and against his brother, that he may bestow upon you a blessing this day."

---

**32:30** And it came to pass on the morrow, that Moses said unto the people: "You have sinned a great sin; and now I will go up unto YHWH; perhaps I can make atonement—אֲכַפְּרָה (achapperah)—for your sin."

**32:31** And Moses returned unto YHWH, and said: "Alas, this people has sinned a great sin, and have made themselves gods of gold.

**32:32** "Yet now, if you will, forgive their sin—וְאִם־אַיִן מְחֵנִי נָא מִסִּפְרְךָ (ve-im-ayin mecheni na mi-sifrecha)—and if not, blot me, please, out of your book which you have written."

**32:33** And YHWH said unto Moses: "Whoever has sinned against me, him will I blot out of my book.

**32:34** "And now go, lead the people unto the place of which I have spoken unto you; behold, my messenger shall go before you; nevertheless in the day when I visit, I will visit their sin upon them."

**32:35** And YHWH struck the people, because they had made the calf, which Aaron made.

---

## Synthesis Notes

**Key Restorations:**

**Moses' Delay:**
Moses has been on the mountain forty days. The people conclude he is gone, lost, dead. Their faith, never deep, collapses. They want visible gods, tangible presence.

**"Make Us Gods":**
The request is for *elohim*—gods, divine beings, or (as some read it) "a god." They want something visible to lead them. Moses is gone; YHWH is invisible. They demand representation.

**Aaron's Compliance:**
Aaron does not resist. He collects the gold, fashions the calf, builds an altar, and proclaims a feast "to YHWH." This is syncretism—worshipping YHWH through a calf image, mixing true worship with idolatrous form.

**The Calf (עֵגֶל, egel):**
A young bull—symbol of fertility, strength, and divinity throughout the ancient Near East. Egyptian Apis bull; Canaanite Baal iconography. The calf may be intended as a throne for YHWH (like the cherubim over the ark) or as YHWH's image. Either way, it violates the commandment against images.

**"Rose Up to Play":**
*Le-tsacheq* (לְצַחֵק)—the verb suggests revelry, possibly sexual. The worship degenerates into excess. What began as religious festival becomes chaotic celebration.

**"Your People":**
YHWH says to Moses: "your people, whom you brought up." Moses will reverse this: "your people, whom you brought out." The disowning language reveals divine anger. YHWH temporarily disclaims Israel.

**"Stiff-Necked People":**
*Am-qesheh-oref* (עַם־קְשֵׁה־עֹרֶף)—an ox that won't bend its neck to the yoke. Israel is stubborn, resistant to guidance, unyielding.

**"Let Me Alone":**
YHWH's words to Moses are remarkable: "Let me alone, that my anger may burn." This implies Moses can prevent YHWH's wrath by not letting alone—by interceding. YHWH invites intercession by warning what happens without it.

**Moses' Intercession:**
Moses argues with YHWH:
1. "Why should your anger burn against your people?"—reminding YHWH of ownership
2. "What will Egypt say?"—concern for YHWH's reputation
3. "Remember Abraham, Isaac, and Israel"—invoking the covenant

**"YHWH Relented":**
*Va-yinnachem YHWH* (וַיִּנָּחֶם יהוה)—YHWH "was comforted" or "changed mind" or "relented." This is anthropomorphic language suggesting genuine divine response to intercession. Prayer changes things—even divine intention.

**The Broken Tablets:**
Moses descends, sees the calf and dancing, and throws down the tablets—breaking them. The covenant is symbolically shattered. What God wrote is destroyed by the people's sin.

**Drinking the Dust:**
Moses burns the calf, grinds it to powder, scatters it on water, and makes Israel drink. This may be an ordeal (like Numbers 5:12-31) or simply complete destruction—they consume their own sin.

**Aaron's Excuse:**
"I cast it into the fire, and out came this calf." This is absurdly evasive—as if the calf formed itself. Aaron minimizes his agency, blames the people, and claims innocent astonishment.

**The Levite Purge:**
Moses calls "Whoever is for YHWH"—the Levites respond. They execute about 3,000 people. This violence is "consecration" (*mil'u yedchem*)—filling their hands for priestly service. The Levites earn their priesthood through zeal.

**Moses' Ultimate Offer:**
Moses returns to YHWH and offers himself: "If you will not forgive them, blot me out of your book." This is vicarious substitution—Moses willing to lose his own place to save the people. YHWH refuses: each bears his own guilt.

**Archetypal Layer:** The golden calf represents the **beast/machine**—"uncontrolled systemic appetite" (symbol map). The people make a god they can see and control. The calf is manufactured religion—human construction masquerading as divine. The breaking of the tablets is the shattering of relationship. Moses' intercession shows the prophet as mediator, standing between divine wrath and human sin.

**Psychological Reading:** The people cannot tolerate absence. Forty days without Moses produces regressive anxiety. They construct a visible god to manage their fear. Aaron's passivity represents the leader who follows the crowd rather than guiding it. Moses' rage (breaking the tablets) is righteous anger at betrayal. His later intercession shows anger transformed into advocacy.

**Ethical Inversion Applied:**
- The calf is an attempt to control the divine—but God cannot be imaged
- Aaron's evasion ("out came this calf") is the archetype of excuse-making
- The Levites' violence is troubling—zeal produces bloodshed
- Moses' offer to be blotted out shows vicarious love—preferring others' salvation to his own
- YHWH relents—intercession genuinely affects divine action

**Modern Equivalent:** When leaders are absent or the transcendent seems distant, people construct substitutes. The golden calf is any manufactured religion that makes the divine manageable. Aaron represents leaders who give people what they want rather than what they need. And genuine intercession—standing in the gap, offering oneself—remains the prophetic calling.

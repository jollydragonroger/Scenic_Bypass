# Exodus Chapter 27: The Altar and the Courtyard

*From the Hebrew: The Outer Sanctuary*

---

**27:1** "And you shall make the altar of acacia wood, five cubits long and five cubits broad; the altar shall be square, and its height shall be three cubits.

**27:2** "And you shall make its horns on its four corners; its horns shall be of one piece with it; and you shall overlay it with bronze.

**27:3** "And you shall make its pots for removing its ashes, and its shovels and its basins and its forks and its firepans; all its vessels you shall make of bronze.

**27:4** "And you shall make for it a grating, a network of bronze; and upon the net you shall make four bronze rings at its four corners.

**27:5** "And you shall put it under the ledge of the altar beneath, that the net may reach halfway up the altar.

**27:6** "And you shall make poles for the altar, poles of acacia wood, and overlay them with bronze.

**27:7** "And the poles shall be put into the rings, and the poles shall be upon the two sides of the altar when carrying it.

**27:8** "Hollow with boards you shall make it; as it was shown you on the mountain, so shall they make it.

---

**27:9** "And you shall make the court—חֲצַר (chatser)—of the tabernacle. On the south side there shall be hangings for the court of fine twisted linen, a hundred cubits long for one side;

**27:10** "And its twenty pillars and their twenty sockets shall be of bronze; the hooks of the pillars and their bands shall be of silver.

**27:11** "And likewise for the north side in length there shall be hangings a hundred cubits long, and its twenty pillars and their twenty sockets of bronze; the hooks of the pillars and their bands of silver.

**27:12** "And for the breadth of the court on the west side shall be hangings of fifty cubits; their pillars ten and their sockets ten.

**27:13** "And the breadth of the court on the east side shall be fifty cubits.

**27:14** "The hangings for one side of the gate shall be fifteen cubits; their pillars three and their sockets three.

**27:15** "And for the other side shall be hangings of fifteen cubits; their pillars three and their sockets three.

**27:16** "And for the gate of the court shall be a screen of twenty cubits, of blue and purple and scarlet yarn and fine twisted linen, the work of the embroiderer; their pillars four and their sockets four.

**27:17** "All the pillars around the court shall be banded with silver; their hooks shall be of silver, and their sockets of bronze.

**27:18** "The length of the court shall be a hundred cubits, and the breadth fifty cubits throughout, and the height five cubits, of fine twisted linen; and their sockets of bronze.

**27:19** "All the vessels of the tabernacle in all its service, and all its pegs, and all the pegs of the court, shall be of bronze.

---

**27:20** "And you shall command the children of Israel, that they bring unto you pure oil of pressed olives—שֶׁמֶן זַיִת זָךְ (shemen zayit zach)—for the light, to cause a lamp to burn continually—לְהַעֲלֹת נֵר תָּמִיד (le-ha'alot ner tamid).

**27:21** "In the tent of meeting, outside the veil which is before the testimony, Aaron and his sons shall arrange it from evening to morning before YHWH; it shall be a statute forever throughout their generations on behalf of the children of Israel."

---

## Synthesis Notes

**Key Restorations:**

**The Bronze Altar:**
The altar of burnt offering—the primary place of sacrifice:
- 5 × 5 × 3 cubits (approximately 7.5 × 7.5 × 4.5 feet)
- Square—geometric perfection
- Acacia wood overlaid with bronze
- Four horns at the corners

**The Horns:**
*Qarnot* (קַרְנֹת)—projections at each corner. The horns are places of refuge (1 Kings 1:50); blood is applied to them during sacrifice; they symbolize power and sanctuary. One "grasps the horns of the altar" for protection.

**Bronze, Not Gold:**
The outer altar is bronze—durable, heat-resistant, appropriate for fire. Gold (innermost), silver (structural), bronze (outermost)—the hierarchy of metals reflects distance from the holy of holies.

**The Grating:**
A bronze mesh beneath the altar surface, with rings for carrying. The altar, like the ark, is portable. The poles never leave the rings.

**"Hollow with Boards":**
The altar is not solid but hollow—filled with earth when in place (20:24). This allows the altar to be relatively light for transport while substantial when used.

**The Courtyard (חֲצַר, chatser):**

The enclosed space around the tabernacle:
- 100 × 50 cubits (approximately 150 × 75 feet)
- 5 cubits high (about 7.5 feet)—a visual barrier, not climbable
- Fine linen hangings on pillars
- 60 pillars total (20 + 20 + 10 + 10)
- Bronze sockets, silver hooks and bands

The courtyard defines sacred space. Inside is holy; outside is ordinary. The boundary matters.

**The Entrance:**
- East side (toward the rising sun)
- 20-cubit gate screen (30 feet wide)
- Embroidered in sacred colors: blue, purple, scarlet
- Four pillars

The entrance is distinguished from the walls—decorated, central, inviting approach.

**The Dimensions:**
The courtyard is 2:1 ratio (100 × 50). The tabernacle itself is similarly proportioned (30 × 10 cubits). Sacred geometry appears throughout.

**The Eternal Lamp (נֵר תָּמִיד, ner tamid):**

The chapter concludes with the light:
- Pure pressed olive oil
- Burns continually (from evening to morning, or perpetually)
- Maintained by Aaron and his sons
- In the holy place, outside the veil

The light never goes out. Darkness never fully wins in the sanctuary. The *ner tamid* (eternal light) is still found in synagogues today, burning before the ark.

**"Pure Oil of Pressed Olives":**
*Shemen zayit zach* (שֶׁמֶן זַיִת זָךְ)—literally "oil of olive, pure." First pressing, no sediment, cleanest burning. The best oil for the perpetual light.

**"A Statute Forever":**
*Chuqqat olam* (חֻקַּת עוֹלָם)—permanent, across all generations. This practice is not temporary. The light burns as long as Israel exists.

**Archetypal Layer:** The courtyard is the **threshold space**—between the profane world and the holy interior. The altar is the place of transformation—where offerings are consumed by fire, moving from earthly to heavenly. The eternal light is constancy amidst change—the one element that never ceases.

**Fire** on the altar transforms; **light** in the holy place illuminates. Both are fire, but with different functions.

**Psychological Reading:** The structure moves inward:
- Outside the camp: ordinary life
- Courtyard: approach, sacrifice, purification
- Holy place: service, light, bread, incense
- Holy of holies: presence, silence, once per year

The progression represents stages of spiritual development—from ordinary consciousness through purification and service to direct encounter.

**Ethical Inversion Applied:**
- The altar has horns of refuge—even the place of sacrifice offers sanctuary
- The eternal light is maintained by priests but belongs to all Israel ("on behalf of the children of Israel")
- The most precious materials are innermost; the functional materials are outer
- The pattern was shown on the mountain—human worship follows divine design

**Modern Equivalent:** Sacred spaces have boundaries—the courtyard wall. Approach to the holy requires passing through stages—you cannot jump from street to sanctuary. The eternal light represents what must never be extinguished—core commitments that define identity. And the altar, where transformation happens through fire, is in the courtyard—accessible to all who enter, not hidden in the inner sanctum.

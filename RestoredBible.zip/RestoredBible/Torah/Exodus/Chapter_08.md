# Exodus Chapter 8: Frogs, Gnats, and Flies

*From the Hebrew: The Escalation*

---

**8:1** And YHWH said unto Moses: "Go in unto Pharaoh and say unto him: 'Thus says YHWH: Let my people go, that they may serve me.

**8:2** "'And if you refuse to let them go, behold, I will strike all your territory with frogs—בַּצְפַרְדְּעִים (ba-tsefarde'im).

**8:3** "'And the River shall swarm with frogs, and they shall come up and enter into your house and into your bedchamber and upon your bed, and into the houses of your servants and upon your people, and into your ovens and into your kneading troughs.

**8:4** "'And the frogs shall come up upon you and upon your people and upon all your servants.'"

**8:5** And YHWH said unto Moses: "Say unto Aaron: 'Stretch out your hand with your staff over the rivers, over the canals, and over the pools, and bring up the frogs upon the land of Egypt.'"

**8:6** And Aaron stretched out his hand over the waters of Egypt; and the frogs came up and covered the land of Egypt.

**8:7** And the magicians did so with their secret arts, and brought up frogs upon the land of Egypt.

**8:8** And Pharaoh called for Moses and Aaron and said: "Entreat YHWH—הַעְתִּירוּ אֶל־יהוה (ha'tiru el-YHWH)—that he take away the frogs from me and from my people; and I will let the people go, that they may sacrifice unto YHWH."

**8:9** And Moses said unto Pharaoh: "Glory over me!—הִתְפָּאֵר עָלַי (hitpa'er alai)—when shall I entreat for you and for your servants and for your people, to destroy the frogs from you and from your houses, that they may remain only in the River?"

**8:10** And Pharaoh said: "Tomorrow—לְמָחָר (le-machar)." And Moses said: "According to your word, that you may know that there is none like YHWH our Consciousness.

**8:11** "And the frogs shall depart from you and from your houses and from your servants and from your people; only in the River shall they remain."

**8:12** And Moses and Aaron went out from Pharaoh; and Moses cried unto YHWH concerning the frogs which he had brought upon Pharaoh.

**8:13** And YHWH did according to the word of Moses; and the frogs died out of the houses, out of the courts, and out of the fields.

**8:14** And they gathered them together in heaps upon heaps—חֳמָרִם חֳמָרִם (chomarim chomarim)—and the land stank.

**8:15** And Pharaoh saw that there was respite—הָרְוָחָה (ha-revachah)—and he hardened his heart—וְהַכְבֵּד אֶת־לִבּוֹ (ve-hakhbed et-libbo)—and did not listen unto them, as YHWH had spoken.

---

**8:16** And YHWH said unto Moses: "Say unto Aaron: 'Stretch out your staff and strike the dust of the earth, that it may become gnats—כִנִּים (kinnim)—throughout all the land of Egypt.'"

**8:17** And they did so; and Aaron stretched out his hand with his staff and struck the dust of the earth, and there were gnats upon man and upon beast; all the dust of the earth became gnats throughout all the land of Egypt.

**8:18** And the magicians did so with their secret arts to bring forth gnats, but they could not; and there were gnats upon man and upon beast.

**8:19** And the magicians said unto Pharaoh: "This is the finger of God—אֶצְבַּע אֱלֹהִים (etsba Elohim)!" And Pharaoh's heart was hardened, and he did not listen unto them, as YHWH had spoken.

---

**8:20** And YHWH said unto Moses: "Rise up early in the morning and stand before Pharaoh—behold, he comes forth to the water—and say unto him: 'Thus says YHWH: Let my people go, that they may serve me.

**8:21** "'For if you will not let my people go, behold, I will send upon you and upon your servants and upon your people and into your houses the swarm—הֶעָרֹב (he-arov); and the houses of the Egyptians shall be full of the swarm, and also the ground upon which they are.

**8:22** "'And I will set apart—וְהִפְלֵיתִי (ve-hifleti)—in that day the land of Goshen, in which my people dwell, that no swarm shall be there; to the end that you may know that I am YHWH in the midst of the earth.

**8:23** "'And I will put a division—פְדֻת (pedut)—between my people and your people. Tomorrow shall this sign be.'"

**8:24** And YHWH did so; and there came a grievous swarm into the house of Pharaoh and into his servants' houses; and in all the land of Egypt the land was corrupted by reason of the swarm.

**8:25** And Pharaoh called for Moses and for Aaron and said: "Go, sacrifice to your Consciousness in the land."

**8:26** And Moses said: "It is not right to do so, for we would sacrifice the abomination of the Egyptians—תּוֹעֲבַת מִצְרַיִם (to'avat Mitsrayim)—to YHWH our Consciousness. Behold, if we sacrifice the abomination of the Egyptians before their eyes, will they not stone us?

**8:27** "We will go three days' journey into the wilderness and sacrifice to YHWH our Consciousness, as he shall say unto us."

**8:28** And Pharaoh said: "I will let you go, that you may sacrifice to YHWH your Consciousness in the wilderness; only you shall not go very far away. Entreat for me."

**8:29** And Moses said: "Behold, I am going out from you, and I will entreat YHWH, and the swarm shall depart from Pharaoh, from his servants, and from his people tomorrow; only let not Pharaoh deal deceitfully anymore—אַל־יֹסֵף פַּרְעֹה הָתֵל (al-yosef Par'oh hatel)—in not letting the people go to sacrifice to YHWH."

**8:30** And Moses went out from Pharaoh and entreated YHWH.

**8:31** And YHWH did according to the word of Moses; and he removed the swarm from Pharaoh, from his servants, and from his people; there remained not one.

**8:32** And Pharaoh hardened his heart this time also, and did not let the people go.

---

## Synthesis Notes

**Key Restorations:**

**The Frogs (צְפַרְדְּעִים, tsefarde'im):**

The frog was associated with the Egyptian goddess Heqet, deity of fertility and childbirth. The plague turns the sacred into the pestilent:
- Frogs in beds, ovens, kneading troughs
- Frogs on Pharaoh himself
- The symbol of fertility becomes infestation

**The Magicians Replicate—Again:**
They bring up more frogs. Once again, their "success" worsens the problem. They can add to the plague but not end it.

**Pharaoh's First Request:**
For the first time, Pharaoh asks Moses to pray to YHWH. He uses the divine name. He acknowledges Moses' access to power he doesn't control. He promises release.

**"Tomorrow":**
Moses asks when to pray; Pharaoh says "tomorrow." Why not immediately? Perhaps disbelief, perhaps testing, perhaps reluctance to seem too desperate. The delay is strange—another night with frogs.

**"That You May Know":**
Moses frames the answer to Pharaoh's request as evidence: "That you may know there is none like YHWH." Each plague teaches.

**The Broken Promise:**
When the frogs die and relief (*revachah*) comes, Pharaoh hardens his heart. The pattern: crisis → request → relief → refusal.

**The Gnats (כִּנִּים, kinnim):**

Possibly gnats, lice, or mosquitoes. This plague comes without warning—no announcement to Pharaoh.

The dust of the earth becomes swarming insects. Creation itself turns hostile.

**"The Finger of God" (אֶצְבַּע אֱלֹהִים):**

The magicians cannot replicate this plague. They acknowledge divine power: "This is the finger of God." Yet Pharaoh remains hardened.

The phrase "finger of God" appears later for the tablets of the law (31:18)—divine power inscribed.

**The Swarm (עָרֹב, arov):**

The Hebrew doesn't specify what creature—just "the swarm." Traditionally understood as flies, or possibly a mixture of wild animals. The land is "corrupted" by it.

**The Distinction Begins:**
For the first time, Goshen is explicitly protected. *Ve-hifleti* (וְהִפְלֵיתִי)—"I will set apart." The word contains the root *pele* (פלא)—wonder. The distinction itself is miraculous.

*Pedut* (פְדֻת)—"division" or "redemption." The separation between Israel and Egypt is redemptive boundary.

**"The Abomination of the Egyptians":**
Moses explains why they cannot sacrifice in Egypt: what Israelites sacrifice (sheep, cattle) is sacred to Egyptians. Public sacrifice would provoke violence. The cultural-religious gap requires physical separation.

**Pharaoh's Partial Concession:**
"Go... but not very far." Pharaoh tries to negotiate, to maintain control. Moses insists on the full three days. Pharaoh agrees—then reneges again.

**"Let Not Pharaoh Deal Deceitfully Anymore":**
Moses names the pattern: Pharaoh promises, then breaks. *Hatel* (הָתֵל)—to deceive, mock. Pharaoh is a serial promise-breaker.

**Archetypal Layer:** Each plague attacks a layer of Egyptian order:
1. Water → blood (ecological foundation)
2. Frogs (sacred creature becomes plague)
3. Gnats (dust becomes hostile—magicians fail)
4. Swarm (nature invades human space—distinction begins)

The beast/machine is being dismantled systematically. Its magic reaches its limit at the gnats; the magicians confess "the finger of God."

**Psychological Reading:** The relief-then-refusal pattern (*revachah* → hardening) shows how the ego reasserts once pressure eases. Pharaoh cannot maintain openness. Each respite restores his defensive structure.

**Ethical Inversion Applied:**
- Egyptian magic acknowledges divine power but Pharaoh ignores the confession
- The distinction (Goshen protected) begins—not all will suffer equally
- Moses calls out deception: "Let not Pharaoh deal deceitfully anymore"
- The pattern of promise-then-betrayal is named

**Modern Equivalent:** Systems under pressure often negotiate superficially while planning to renege. "Go, but not too far" is the partial concession designed to maintain control. Relief from crisis often leads to forgotten promises. And eventually, even the system's own experts (magicians) acknowledge they're facing something beyond their power.

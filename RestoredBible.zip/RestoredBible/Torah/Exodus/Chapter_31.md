# Exodus Chapter 31: The Artisans and the Sabbath

*From the Hebrew: Spirit-Filled Craftsmanship*

---

**31:1** And YHWH spoke unto Moses, saying:

**31:2** "See, I have called by name Bezalel—בְּצַלְאֵל (Betsal'el)—the son of Uri, the son of Hur, of the tribe of Judah.

**31:3** "And I have filled him with the spirit of Consciousness—רוּחַ אֱלֹהִים (ruach Elohim)—in wisdom and in understanding and in knowledge and in all manner of workmanship,

**31:4** "To devise skillful works—לַחְשֹׁב מַחֲשָׁבֹת (lachshov machashavot)—to work in gold and in silver and in bronze,

**31:5** "And in cutting of stones for setting, and in carving of wood, to work in all manner of workmanship.

**31:6** "And I, behold, I have appointed with him Oholiab—אָהֳלִיאָב (Oholiav)—the son of Ahisamach, of the tribe of Dan; and in the heart of all who are wise of heart I have put wisdom, that they may make all that I have commanded you:

**31:7** "The tent of meeting, and the ark of the testimony, and the mercy seat that is upon it, and all the furniture of the tent,

**31:8** "And the table and its vessels, and the pure lampstand and all its vessels, and the altar of incense,

**31:9** "And the altar of burnt offering and all its vessels, and the basin and its stand,

**31:10** "And the woven garments, and the holy garments for Aaron the priest, and the garments of his sons, to minister as priests,

**31:11** "And the anointing oil, and the fragrant incense for the holy place; according to all that I have commanded you they shall do."

---

**31:12** And YHWH spoke unto Moses, saying:

**31:13** "And you, speak unto the children of Israel, saying: 'Surely my sabbaths you shall keep—אַךְ אֶת־שַׁבְּתֹתַי תִּשְׁמֹרוּ (ach et-shabbtotai tishmoru); for it is a sign between me and you throughout your generations, that you may know that I am YHWH who sanctifies you.

**31:14** "'And you shall keep the sabbath, for it is holy unto you; everyone who profanes it shall surely be put to death; for whoever does work on it, that soul shall be cut off from among his people.

**31:15** "'Six days shall work be done, but on the seventh day is a sabbath of solemn rest—שַׁבַּת שַׁבָּתוֹן (shabbat shabbaton)—holy unto YHWH; whoever does work on the sabbath day shall surely be put to death.

**31:16** "'And the children of Israel shall keep the sabbath, to observe the sabbath throughout their generations, as a perpetual covenant—בְּרִית עוֹלָם (berit olam).

**31:17** "'Between me and the children of Israel it is a sign forever—אוֹת הִיא לְעֹלָם (ot hi le-olam); for in six days YHWH made the heavens and the earth, and on the seventh day he rested and was refreshed—וַיִּנָּפַשׁ (va-yinnafash).'"

**31:18** And when YHWH finished speaking with Moses upon Mount Sinai, he gave unto Moses the two tablets of the testimony—לֻחֹת הָעֵדֻת (luchot ha-edut)—tablets of stone, written with the finger of Consciousness—בְּאֶצְבַּע אֱלֹהִים (be-etsba Elohim).

---

## Synthesis Notes

**Key Restorations:**

**Bezalel — "In the Shadow of God":**
*Betsal'el* (בְּצַלְאֵל): "in the shadow/protection of El/God." The chief artisan is named by YHWH, called by name. He is from the tribe of Judah (the royal tribe), grandson of Hur (who helped support Moses' arms during battle with Amalek, 17:12).

**"Filled with the Spirit of Consciousness":**
*Ruach Elohim* (רוּחַ אֱלֹהִים)—the same phrase as Genesis 1:2 (the spirit hovering over the waters). This is the first individual explicitly said to be filled with God's spirit in Scripture. The filling is for craftsmanship, not prophecy. Art is spirit-work.

**The Fourfold Filling:**
Bezalel is filled with:
1. **Wisdom** (חָכְמָה, chokmah): skill, practical intelligence
2. **Understanding** (תְּבוּנָה, tevunah): discernment, insight
3. **Knowledge** (דַּעַת, da'at): experiential knowledge
4. **All manner of workmanship**: comprehensive ability

Sacred art requires divine gifting. The tabernacle is not built by mere human skill but by spirit-empowered craftsmanship.

**"To Devise Skillful Works":**
*Lachshov machashavot* (לַחְשֹׁב מַחֲשָׁבֹת)—literally "to think thoughts" or "to plan designs." The artisan thinks creatively; the work begins in imagination before it becomes material.

**Oholiab — "The Father Is My Tent":**
*Oholiav* (אָהֳלִיאָב): from the tribe of Dan, assisting Bezalel. Judah (south, royal) and Dan (north, border) collaborate. The work is pan-Israelite.

**"Wise of Heart":**
*Chakam-lev* (חֲכַם־לֵב)—wisdom dwells in the heart, not the head. YHWH has put wisdom "in the heart of all who are wise of heart." Those already gifted receive more. Divine enhancement of human capacity.

**The Sabbath Commandment:**

Placed here, between the tabernacle instructions and the golden calf narrative, the sabbath command is emphatic:
- "Surely (*ach*) my sabbaths you shall keep"—the particle *ach* is emphatic, limiting
- A sign (*ot*) between YHWH and Israel
- Profaning it = death
- A perpetual covenant (*berit olam*)

**Why Here?**
The placement suggests: even building the tabernacle does not override the sabbath. The most sacred work must stop on the seventh day. The sabbath is not negotiable, not even for constructing YHWH's dwelling.

**"Sabbath of Solemn Rest" (שַׁבַּת שַׁבָּתוֹן):**
The doubling intensifies: a sabbath-sabbath, the ultimate rest. This is the sabbatical principle in its most concentrated form.

**"He Rested and Was Refreshed" (וַיִּנָּפַשׁ):**
The verb *nafash* is the same root as *nefesh* (soul). YHWH was "re-souled," refreshed at the soul level. This anthropomorphism dignifies rest. Even YHWH rests. How much more should humans?

**The Two Tablets:**
*Luchot ha-edut* (לֻחֹת הָעֵדֻת)—tablets of testimony. Stone tablets, written by "the finger of Consciousness." Divine handwriting. No human scribe, no Moses' pen—direct inscription by YHWH.

Tradition holds there were ten words (commandments), five on each tablet—duties to God on one, duties to neighbor on the other.

**Archetypal Layer:** The artisan filled with divine spirit represents the **creative intelligence** of the symbol map—imagination empowered by the transcendent. Bezalel's work is not mere craftsmanship but spirit-infused creation. The sabbath interrupts all work—even sacred work—because rest is as fundamental as action. The tablets are the **word made stone**—divine communication in permanent, material form.

**Psychological Reading:** Creativity arises from the unconscious (spirit-filled). Bezalel "thinks thoughts"—design emerges from somewhere. The sabbath acknowledges that productivity is not ultimate; rest restores. The tablets represent the law internalized—stone that becomes conscience.

**Ethical Inversion Applied:**
- Art and craftsmanship are spirit-work—not inferior to prophecy
- Wisdom is in the heart—intelligence is more than intellectual
- The sabbath overrides even tabernacle construction—rest is non-negotiable
- YHWH "was refreshed"—rest is divine, not merely human need
- The tablets are written by God's finger—law is not human invention

**Modern Equivalent:** Creative work is sacred when spirit-filled. Those who build, design, and craft can be as spirit-filled as those who preach. And the sabbath principle applies even to the most important projects—rest is not optional, not a concession to weakness, but a fundamental rhythm. Even God rested and "was re-souled."

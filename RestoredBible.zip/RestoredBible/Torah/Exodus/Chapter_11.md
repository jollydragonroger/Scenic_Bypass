# Exodus Chapter 11: The Announcement of the Final Plague

*From the Hebrew: Death of the Firstborn Foretold*

---

**11:1** And YHWH said unto Moses: "One more plague—נֶגַע אֶחָד (nega echad)—will I bring upon Pharaoh and upon Egypt; afterward he will let you go from here. When he lets you go, he shall surely drive you out altogether—גָּרֵשׁ יְגָרֵשׁ (garesh yegaresh).

**11:2** "Speak now in the ears of the people, and let them ask—וְיִשְׁאֲלוּ (ve-yish'alu)—every man of his neighbor, and every woman of her neighbor, vessels of silver and vessels of gold."

**11:3** And YHWH gave the people favor—חֵן (chen)—in the eyes of the Egyptians. Moreover, the man Moses was very great in the land of Egypt, in the eyes of Pharaoh's servants and in the eyes of the people.

**11:4** And Moses said: "Thus says YHWH: 'About midnight—כַּחֲצֹת הַלַּיְלָה (ka-chatsot ha-laylah)—I will go out into the midst of Egypt.

**11:5** "'And every firstborn in the land of Egypt shall die—וּמֵת כָּל־בְּכוֹר (u-met kol-bechor)—from the firstborn of Pharaoh who sits upon his throne, unto the firstborn of the maidservant who is behind the mill, and every firstborn of beast.

**11:6** "'And there shall be a great cry throughout all the land of Egypt—צְעָקָה גְדֹלָה (tse'aqah gedolah)—such as there has not been, nor shall be anymore.

**11:7** "'But against any of the children of Israel not a dog shall whet its tongue—לֹא יֶחֱרַץ־כֶּלֶב לְשֹׁנוֹ (lo yecherats-kelev leshono)—against man or beast; that you may know that YHWH makes a distinction—יַפְלֶה (yafleh)—between Egypt and Israel.'

**11:8** "And all these your servants shall come down unto me and bow down unto me, saying: 'Go out, you and all the people that follow you!' And after that I will go out." And Moses went out from Pharaoh in hot anger—בָּחֳרִי־אָף (ba-chori-af).

**11:9** And YHWH said unto Moses: "Pharaoh shall not listen unto you, that my wonders may be multiplied in the land of Egypt."

**11:10** And Moses and Aaron did all these wonders before Pharaoh; and YHWH hardened Pharaoh's heart, and he did not let the children of Israel go out of his land.

---

## Synthesis Notes

**Key Restorations:**

**"One More Plague":**
*Nega echad* (נֶגַע אֶחָד)—one final stroke. The escalation is complete. Nine plagues have attacked creation systematically; the tenth will attack life itself at its source—the firstborn.

**"He Shall Surely Drive You Out":**
The doubling (*garesh yegaresh*) emphasizes completeness. Not merely permission to leave but expulsion. Pharaoh will not just "let go" but "drive out."

**The Asking (וְיִשְׁאֲלוּ, ve-yish'alu):**
The word *sha'al* means "ask" or "borrow." The Israelites are to ask their Egyptian neighbors for valuables. This is not theft but reparations—compensation for generations of slave labor.

**"Favor in the Eyes of the Egyptians":**
*Chen* (חֵן)—grace, favor, charm. After nine plagues, the Egyptians are ready to give. Terror and perhaps respect motivate generosity. The oppressed are now honored.

**Moses' Greatness:**
"The man Moses was very great in the land of Egypt." His stature has grown through the confrontations. Pharaoh's servants and the general population recognize his power. Moses, the refugee who fled Egypt, now stands supreme.

**"About Midnight":**
*Ka-chatsot ha-laylah* (כַּחֲצֹת הַלַּיְלָה)—approximately midnight. The precise moment is veiled. YHWH will go forth at the liminal hour—the threshold between days.

**"I Will Go Out":**
YHWH personally will traverse Egypt. This is not plague through intermediary but divine presence moving in judgment.

**The Death of the Firstborn:**

The scope is total:
- "From the firstborn of Pharaoh who sits upon the throne"—the heir to empire
- "Unto the firstborn of the maidservant who is behind the mill"—the lowest slave
- "Every firstborn of beast"—extending to animals

The parallel to Pharaoh's command (1:22) is exact: Pharaoh ordered the death of all Israelite male children; now the death of all Egyptian firstborn is announced. **The measure one uses is measured back.**

**"A Great Cry":**
*Tse'aqah gedolah* (צְעָקָה גְדֹלָה)—the same root as Israel's cry under oppression (2:23). Egypt will now cry as Israel cried. The suffering is reversed.

**"Not a Dog Shall Whet Its Tongue":**
A proverbial expression for absolute peace—not even a dog's growl. Complete distinction between Egypt's chaos and Israel's safety.

**"YHWH Makes a Distinction" (יַפְלֶה, yafleh):**
From *palah*—to be distinct, wonderful, set apart. The root of *pele* (wonder). The distinction itself is miraculous.

**Moses' Hot Anger:**
*Ba-chori-af* (בָּחֳרִי־אָף)—burning of nostrils, fierce anger. Moses leaves Pharaoh enraged. After all the plagues, all the negotiations, all the broken promises—Moses is done.

**The Summary:**
Verse 10 summarizes: Moses and Aaron did all these wonders; YHWH hardened Pharaoh's heart; he did not let them go. The stage is set for the final act.

**Archetypal Layer:** The tenth plague attacks the principle of succession—the firstborn is the future. Pharaoh sought to destroy Israel's future (kill the sons); YHWH destroys Egypt's future. The cosmic justice is exact: what you did will be done to you.

**The firstborn** represents continuity, inheritance, the perpetuation of the system. The death of all firstborn is the death of Egypt's tomorrow.

**Psychological Reading:** Moses' anger is finally expressed. The prophet has been patient, obedient, repeatedly returning to negotiate. Now, with the final plague announced, his fury emerges. Righteous anger at stubborn oppression is appropriate; Moses is not passive.

**Ethical Inversion Applied:**

The death of the firstborn is the most troubling of the plagues:
- Children die for Pharaoh's sin
- The innocent suffer for the ruler's choices
- The "maidservant behind the mill" loses her firstborn too

**The restoration acknowledges the horror without excusing it:**
- The plague mirrors Pharaoh's genocide (all sons killed)
- The text presents divine judgment operating on the principle of measure-for-measure
- The moral center is the distinction—Israel is spared
- The pattern raises permanent questions about collective punishment

The text does not resolve these questions. It presents them.

**Modern Equivalent:** Systems that order the death of children produce consequences that eventually return to them. The cry of the oppressed rises until it is answered by a cry from the oppressors. And when judgment falls, it often falls on the innocent within the guilty system—the maidservant's child dies alongside Pharaoh's. This is the terrible logic of systemic collapse.

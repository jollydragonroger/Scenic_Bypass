# Exodus Chapter 30: The Altar of Incense and Sacred Items

*From the Hebrew: קְטֹרֶת (Qetoret) — Incense*

---

**30:1** "And you shall make an altar for the burning of incense—מִזְבֵּחַ מִקְטַר קְטֹרֶת (mizbeach miqtar qetoret); of acacia wood you shall make it.

**30:2** "A cubit shall be its length and a cubit its breadth—it shall be square—and two cubits shall be its height; its horns shall be of one piece with it.

**30:3** "And you shall overlay it with pure gold—its top and its sides round about and its horns; and you shall make for it a molding of gold round about.

**30:4** "And two golden rings you shall make for it under its molding; on its two sides, on its two opposite sides, you shall make them; and they shall be as holders for poles with which to carry it.

**30:5** "And you shall make the poles of acacia wood and overlay them with gold.

**30:6** "And you shall put it before the veil that is by the ark of the testimony, before the mercy seat that is over the testimony, where I will meet with you.

**30:7** "And Aaron shall burn fragrant incense on it—קְטֹרֶת סַמִּים (qetoret sammim); every morning when he tends the lamps he shall burn it.

**30:8** "And when Aaron lights the lamps between the evenings, he shall burn it, a perpetual incense before YHWH throughout your generations.

**30:9** "You shall not offer strange incense upon it—קְטֹרֶת זָרָה (qetoret zarah)—nor burnt offering nor grain offering; neither shall you pour a drink offering upon it.

**30:10** "And Aaron shall make atonement upon its horns once in the year; with the blood of the sin offering of atonement once in the year he shall make atonement for it throughout your generations; it is most holy unto YHWH."

---

**30:11** And YHWH spoke unto Moses, saying:

**30:12** "When you take the census of the children of Israel according to their number, then each shall give a ransom for his soul—כֹּפֶר נַפְשׁוֹ (kofer nafsho)—unto YHWH when you number them, that there be no plague among them when you number them.

**30:13** "This they shall give, everyone who passes among those who are numbered: half a shekel according to the shekel of the sanctuary—מַחֲצִית הַשֶּׁקֶל בְּשֶׁקֶל הַקֹּדֶשׁ (machatsit ha-sheqel be-sheqel ha-qodesh)—twenty gerahs to the shekel; half a shekel as a contribution to YHWH.

**30:14** "Everyone who passes among those who are numbered, from twenty years old and upward, shall give the contribution to YHWH.

**30:15** "The rich shall not give more, and the poor shall not give less, than half a shekel, when you give the contribution to YHWH to make atonement for your souls.

**30:16** "And you shall take the atonement money from the children of Israel, and shall appoint it for the service of the tent of meeting; and it shall be for the children of Israel as a memorial before YHWH, to make atonement for your souls."

---

**30:17** And YHWH spoke unto Moses, saying:

**30:18** "You shall also make a basin of bronze—כִּיּוֹר נְחֹשֶׁת (kiyyor nechoshet)—and its stand of bronze, for washing; and you shall put it between the tent of meeting and the altar, and you shall put water in it.

**30:19** "And Aaron and his sons shall wash their hands and their feet from it.

**30:20** "When they go into the tent of meeting, they shall wash with water, that they not die; or when they come near to the altar to minister, to burn a fire offering unto YHWH.

**30:21** "So they shall wash their hands and their feet, that they not die; and it shall be a statute forever to them, to him and to his descendants throughout their generations."

---

**30:22** And YHWH spoke unto Moses, saying:

**30:23** "And you, take for yourself choice spices—בְּשָׂמִים רֹאשׁ (besamim rosh): of flowing myrrh—מָר דְּרוֹר (mor deror)—five hundred shekels, and of sweet cinnamon half as much, two hundred and fifty, and of sweet calamus two hundred and fifty,

**30:24** "And of cassia five hundred, according to the shekel of the sanctuary, and of olive oil a hin.

**30:25** "And you shall make it a holy anointing oil—שֶׁמֶן מִשְׁחַת־קֹדֶשׁ (shemen mishchat-qodesh)—a compound after the art of the perfumer; it shall be a holy anointing oil.

**30:26** "And you shall anoint with it the tent of meeting and the ark of the testimony,

**30:27** "And the table and all its vessels, and the lampstand and its vessels, and the altar of incense,

**30:28** "And the altar of burnt offering and all its vessels, and the basin and its stand.

**30:29** "And you shall sanctify them, that they may be most holy; whatever touches them shall be holy.

**30:30** "And you shall anoint Aaron and his sons, and sanctify them, that they may minister unto me as priests.

**30:31** "And you shall speak unto the children of Israel, saying, 'This shall be a holy anointing oil unto me throughout your generations.

**30:32** "'Upon the flesh of man it shall not be poured, neither shall you make any like it according to its composition; it is holy, and it shall be holy unto you.

**30:33** "'Whoever compounds any like it, or whoever puts any of it upon a stranger, shall be cut off from his people.'"

---

**30:34** And YHWH said unto Moses: "Take unto you sweet spices: stacte and onycha and galbanum, sweet spices with pure frankincense—לְבֹנָה זַכָּה (levonah zakkah); of each shall there be an equal part.

**30:35** "And you shall make it an incense—קְטֹרֶת (qetoret)—a compound after the art of the perfumer, seasoned with salt, pure and holy.

**30:36** "And you shall beat some of it very fine, and put of it before the testimony in the tent of meeting, where I will meet with you; it shall be unto you most holy.

**30:37** "And the incense which you shall make, according to its composition you shall not make for yourselves; it shall be unto you holy unto YHWH.

**30:38** "Whoever makes any like it, to smell of it, shall be cut off from his people."

---

## Synthesis Notes

**Key Restorations:**

**The Altar of Incense:**
A smaller altar (1 × 1 × 2 cubits) made of gold-overlaid acacia:
- Placed before the veil, near the ark
- Used exclusively for incense (no burnt offerings, no libations)
- Tended twice daily (morning and evening)
- Annual atonement on its horns (Yom Kippur)

The incense altar is the closest regular approach to the holy of holies. The smoke rises toward the mercy seat.

**"Strange Incense" (קְטֹרֶת זָרָה):**
Unauthorized incense is forbidden. Nadab and Abihu will later offer "strange fire" and die (Leviticus 10:1-2). The formula matters; innovation is dangerous in sacred matters.

**The Census Tax:**

When Israel is counted, each person pays:
- Half a shekel (about 1/5 ounce of silver)
- Rich and poor pay the same amount
- This is "ransom for his soul" (*kofer nafsho*)

Counting people carries risk—the census implies ownership or military muster. The payment ransoms each soul, averting plague. The equal payment asserts equal worth before YHWH.

**The Bronze Basin (כִּיּוֹר, kiyyor):**

For priestly washing:
- Bronze, placed between tent and altar
- Priests wash hands and feet before entering or ministering
- Failure to wash means death

Purification precedes approach. The body must be clean to serve. This is not hygiene but ritual—symbolic cleansing for sacred function.

**The Anointing Oil:**

A specific formula:
- Myrrh (מָר דְּרוֹר, mor deror): 500 shekels
- Cinnamon: 250 shekels
- Calamus: 250 shekels
- Cassia: 500 shekels
- Olive oil: 1 hin (about 1.5 gallons)

This oil anoints:
- The tabernacle and all furnishings
- Aaron and his sons

The formula is exclusive—not to be replicated for personal use. Making it for common purposes means being "cut off" from the people.

**"Flowing Myrrh" (מָר דְּרוֹר):**
*Mor deror*—literally "myrrh of freedom." The finest myrrh flows naturally without cutting the tree. Freedom/purity combined in the primary ingredient.

**The Incense Formula:**

Four ingredients in equal parts:
- Stacte (*nataf*): a resin
- Onycha (*shecheleth*): possibly from a sea creature
- Galbanum: a gum resin
- Frankincense (*levonah*): the white resin

Plus salt, beaten fine. This is the sacred incense burned on the golden altar. Like the oil, it cannot be replicated for personal use.

**"Cut Off":**
The penalty for misusing sacred formulas is *karet*—being cut off. This may mean death, exile, or divine excision from the covenant community. The sacred formulas are not for private enjoyment.

**Archetypal Layer:** The incense rising before the veil represents prayer ascending. The smoke moves toward the invisible presence. The census tax asserts that each soul has equal value—no one is worth more or less. The washing represents purification before encounter. The sacred oil and incense are exclusive—the holy cannot be replicated for profane use.

**Psychological Reading:** The anointing oil transforms objects and persons. What was ordinary becomes sacred through application of the sacred compound. The incense creates an atmosphere of holiness—sense experience (smell) engaged in worship. The prohibition of replication protects the sacred from trivialization.

**Ethical Inversion Applied:**
- Rich and poor pay the same—equality before YHWH
- The ransom price is uniform—no soul is valued higher than another
- Washing is required before service—approach requires preparation
- The formulas are exclusive—the sacred resists replication
- "Cut off" protects holiness from casual appropriation

**Modern Equivalent:** Some things should not be replicated for personal use. The sacred formulas represent what is set apart—available for sacred function but not for common consumption. The equal census payment anticipates one-person-one-vote: in the divine count, the rich are not worth more than the poor. And purification before service (washing) represents the preparation required for meaningful work.

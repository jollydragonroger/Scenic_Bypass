# Exodus Chapter 36: The Construction Begins

*From the Hebrew: More Than Enough*

---

**36:1** And Bezalel and Oholiab shall work, and every wise-hearted man in whom YHWH has put wisdom and understanding to know how to work all the work for the service of the sanctuary, according to all that YHWH has commanded.

**36:2** And Moses called Bezalel and Oholiab, and every wise-hearted man in whose heart YHWH had put wisdom, every one whose heart stirred him up to come unto the work to do it.

**36:3** And they received from Moses all the contribution which the children of Israel had brought for the work of the service of the sanctuary, to make it. And they brought yet unto him freewill offerings every morning.

**36:4** And all the wise men who were doing all the work of the sanctuary came, every man from his work which they were doing.

**36:5** And they spoke unto Moses, saying: "The people bring much more than enough—מַרְבִּים הָעָם לְהָבִיא (marbim ha-am le-havi)—for the service of the work which YHWH commanded to make."

**36:6** And Moses gave commandment, and they caused it to be proclaimed throughout the camp, saying: "Let neither man nor woman make any more work for the contribution of the sanctuary." So the people were restrained from bringing—וַיִּכָּלֵא הָעָם מֵהָבִיא (va-yikkale ha-am me-havi).

**36:7** For the stuff they had was sufficient—דַּיָּם (dayyam)—for all the work to make it, and more than enough.

---

**36:8** And every wise-hearted man among those who did the work made the tabernacle with ten curtains of fine twisted linen, and blue and purple and scarlet yarn; with cherubim, the work of a skillful workman, he made them.

**36:9** The length of each curtain was twenty-eight cubits, and the breadth of each curtain four cubits; all the curtains had one measure.

**36:10** And he coupled five curtains to one another, and the other five curtains he coupled to one another.

**36:11** And he made loops of blue on the edge of one curtain at the end of the coupling; likewise he made in the edge of the curtain that was outermost in the second coupling.

**36:12** Fifty loops he made on one curtain, and fifty loops he made on the edge of the curtain that was in the second coupling; the loops were opposite one another.

**36:13** And he made fifty clasps of gold, and coupled the curtains one to another with the clasps; so the tabernacle was one.

**36:14** And he made curtains of goats' hair for a tent over the tabernacle; eleven curtains he made.

**36:15** The length of each curtain was thirty cubits, and four cubits the breadth of each curtain; the eleven curtains had one measure.

**36:16** And he coupled five curtains by themselves, and six curtains by themselves.

**36:17** And he made fifty loops on the edge of the curtain that was outermost in the coupling, and fifty loops he made upon the edge of the curtain which was outmost in the second coupling.

**36:18** And he made fifty clasps of bronze to couple the tent together, that it might be one.

**36:19** And he made a covering for the tent of rams' skins dyed red, and a covering of porpoise skins above.

**36:20** And he made the boards for the tabernacle of acacia wood, standing up.

**36:21** Ten cubits was the length of a board, and a cubit and a half the breadth of each board.

**36:22** Each board had two tenons, joined to one another; thus he made for all the boards of the tabernacle.

**36:23** And he made the boards for the tabernacle: twenty boards for the south side.

**36:24** And he made forty sockets of silver under the twenty boards: two sockets under one board for its two tenons, and two sockets under another board for its two tenons.

**36:25** And for the other side of the tabernacle, on the north side, he made twenty boards,

**36:26** And their forty sockets of silver: two sockets under one board, and two sockets under another board.

**36:27** And for the rear of the tabernacle westward he made six boards.

**36:28** And two boards he made for the corners of the tabernacle in the rear.

**36:29** And they were double beneath, and in like manner they were complete unto its top unto one ring; thus he made for both of them in both corners.

**36:30** And there were eight boards, and their sockets of silver, sixteen sockets; two sockets under every board.

**36:31** And he made bars of acacia wood: five for the boards of the one side of the tabernacle,

**36:32** And five bars for the boards of the other side of the tabernacle, and five bars for the boards of the tabernacle for the rear westward.

**36:33** And he made the middle bar to pass through in the midst of the boards from end to end.

**36:34** And he overlaid the boards with gold, and made their rings of gold as holders for the bars, and overlaid the bars with gold.

**36:35** And he made the veil of blue and purple and scarlet yarn and fine twisted linen; with cherubim, the work of a skillful workman, he made it.

**36:36** And he made for it four pillars of acacia and overlaid them with gold; their hooks were of gold; and he cast for them four sockets of silver.

**36:37** And he made a screen for the door of the tent, of blue and purple and scarlet yarn and fine twisted linen, the work of the embroiderer;

**36:38** And its five pillars with their hooks; and he overlaid their capitals and their bands with gold; and their five sockets were of bronze.

---

## Synthesis Notes

**Key Restorations:**

**"More Than Enough":**
*Marbim ha-am le-havi* (מַרְבִּים הָעָם לְהָבִיא)—"The people are bringing more than enough." This is unprecedented in religious history: the people give so generously that they must be *restrained from bringing*.

The artisans report to Moses: the contributions exceed the need. Moses commands a halt: "Let no one make any more." The people are stopped from giving.

**"Sufficient, and More Than Enough":**
*Dayyam* (דַּיָּם)—enough, sufficient. After the golden calf debacle, Israel demonstrates its restored commitment through overwhelming generosity. What they gave for the calf is now matched and exceeded for the tabernacle.

**The Construction Parallels the Instructions:**
Chapters 36-39 largely repeat chapters 25-28, but in the past tense—what was commanded is now executed. The repetition is liturgical; it emphasizes obedience. Every detail commanded is fulfilled.

**"So the Tabernacle Was One":**
*Va-yehi ha-mishkan echad* (וַיְהִי הַמִּשְׁכָּן אֶחָד)—the fifty gold clasps join the curtains "so the tabernacle was one." Unity achieved through connection. Many parts become one whole.

**The Structural Elements:**

The chapter covers:
1. **Linen curtains** (10 curtains with cherubim) — verses 8-13
2. **Goat hair curtains** (11 curtains) — verses 14-18
3. **Outer coverings** (rams' skins, porpoise skins) — verse 19
4. **Acacia boards** (48 boards for the framework) — verses 20-30
5. **Bars** (15 bars to stabilize) — verses 31-34
6. **The veil** (separating holy from most holy) — verses 35-36
7. **The screen** (entrance to the tent) — verses 37-38

**The Shift from Command to Execution:**
Chapter 26 commands: "You shall make." Chapter 36 reports: "He made." The passive obedience to divine instruction is the pattern. The artisan does not innovate; he implements.

**Archetypal Layer:** The overflowing generosity reverses the golden calf. Where Israel contributed gold for idolatry, they now give so much for true worship that they must be stopped. The healing of the breach is demonstrated through action.

The repetition of construction details enacts **ritual memory**—saying the same thing again fixes it in consciousness. The tabernacle is built in narrative as it was built in time.

**Psychological Reading:** After betrayal (the calf), restoration requires concrete action. Words of repentance are insufficient; deeds are necessary. Israel's overwhelming generosity is the behavioral expression of renewed commitment. They give until they must be restrained.

**Ethical Inversion Applied:**
- Generosity must be restrained—an unusual problem
- The tabernacle is built by community giving, not royal taxation
- Unity from multiplicity—"the tabernacle was one"
- Obedience is exact—what was commanded is precisely executed
- The pattern comes from heaven—human work implements divine design

**Modern Equivalent:** Genuine community projects can elicit overwhelming generosity when hearts are moved. The pattern of command-then-execution models institutional faithfulness: leaders set the vision; workers implement precisely. And the redundancy of the narrative (saying twice what was said once) emphasizes the importance of both intention and completion.

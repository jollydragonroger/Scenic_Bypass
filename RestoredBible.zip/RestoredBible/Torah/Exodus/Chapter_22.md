# Exodus Chapter 22: Laws on Property and Society

*From the Hebrew: Restitution and Responsibility*

---

**22:1** "If a man steals an ox or a sheep and slaughters it or sells it, he shall pay five oxen for the ox and four sheep for the sheep.

**22:2** "If the thief is found breaking in and is struck so that he dies, there is no bloodguilt for him.

**22:3** "But if the sun has risen upon him, there is bloodguilt for him. He shall make full restitution; if he has nothing, then he shall be sold for his theft.

**22:4** "If the theft is found alive in his hand, whether ox or donkey or sheep, he shall pay double.

**22:5** "If a man causes a field or vineyard to be grazed, and lets his beast loose and it grazes in another man's field, he shall make restitution from the best of his own field and the best of his own vineyard.

**22:6** "If fire breaks out and catches in thorns, so that the stacked grain or the standing grain or the field is consumed, the one who kindled the fire shall surely make restitution.

**22:7** "If a man gives to his neighbor money or goods to keep, and it is stolen out of the man's house, if the thief is found, he shall pay double.

**22:8** "If the thief is not found, then the owner of the house shall come near to the judges—הָאֱלֹהִים (ha-Elohim)—to determine whether he has put his hand unto his neighbor's goods.

**22:9** "For every matter of trespass—for ox, for donkey, for sheep, for garment, for any lost thing about which one says, 'This is it'—the case of both parties shall come before the judges; whomever the judges condemn shall pay double to his neighbor.

**22:10** "If a man gives to his neighbor a donkey or an ox or a sheep or any beast to keep, and it dies or is injured or is driven away, no one seeing it,

**22:11** "An oath of YHWH shall be between them both, whether he has not put his hand unto his neighbor's goods; and its owner shall accept it, and he shall not make restitution.

**22:12** "But if it is indeed stolen from him, he shall make restitution unto its owner.

**22:13** "If it is torn by a beast, he shall bring it as evidence; he shall not make restitution for what was torn.

**22:14** "And if a man borrows anything of his neighbor, and it is injured or dies, its owner not being with it, he shall surely make restitution.

**22:15** "If its owner was with it, he shall not make restitution; if it was hired, it came for its hire.

---

**22:16** "And if a man seduces a virgin who is not betrothed and lies with her, he shall surely pay a bride-price for her to be his wife.

**22:17** "If her father utterly refuses to give her unto him, he shall pay money according to the bride-price of virgins.

**22:18** "You shall not allow a sorceress to live—מְכַשֵּׁפָה לֹא תְחַיֶּה (mechashshefah lo techayeh).

**22:19** "Whoever lies with a beast shall surely be put to death.

**22:20** "Whoever sacrifices to any god, except unto YHWH only, shall be utterly destroyed—יָחֳרָם (yochoram).

**22:21** "And you shall not wrong a stranger—גֵּר (ger)—nor oppress him; for you were strangers in the land of Egypt.

**22:22** "You shall not afflict any widow or orphan.

**22:23** "If you afflict them at all, and they cry at all unto me, I will surely hear their cry—שָׁמֹעַ אֶשְׁמַע צַעֲקָתוֹ (shamo'a eshma tsa'aqato).

**22:24** "And my anger shall burn, and I will kill you with the sword; and your wives shall be widows, and your children orphans.

**22:25** "If you lend money to any of my people, to the poor among you, you shall not be to him as a creditor; you shall not charge him interest—נֶשֶׁךְ (neshech).

**22:26** "If you take your neighbor's garment as a pledge, you shall return it unto him before the sun goes down;

**22:27** "For that is his only covering, it is his garment for his skin; in what shall he sleep? And it shall come to pass, when he cries unto me, that I will hear; for I am gracious—חַנּוּן אָנִי (channun ani).

**22:28** "You shall not revile the judges—אֱלֹהִים (Elohim)—nor curse a ruler of your people.

**22:29** "You shall not delay your fullness and your flow—מְלֵאָתְךָ וְדִמְעֲךָ (mele'atecha ve-dim'acha); the firstborn of your sons you shall give to me.

**22:30** "Likewise shall you do with your oxen and with your sheep; seven days it shall be with its mother; on the eighth day you shall give it to me.

**22:31** "And you shall be holy men unto me; therefore you shall not eat any flesh torn by beasts in the field; you shall cast it to the dogs."

---

## Synthesis Notes

**Key Restorations:**

**Graduated Restitution:**
- Ox stolen and slaughtered: 5x restitution
- Sheep stolen and slaughtered: 4x restitution
- Animal found alive: 2x restitution

The ox requires greater restitution because it is a work animal—the loss includes productive capacity. The penalties are economic, not corporal.

**Night-Breaking vs. Daylight:**
If a thief is killed while breaking in at night, no bloodguilt. If killed after sunrise, bloodguilt exists. The distinction: at night, the homeowner cannot assess threat; in daylight, lethal force may be excessive.

**Fire and Liability:**
If you start a fire that spreads and destroys crops, you pay. You are responsible for consequences of your actions even if unintended.

**Deposits and Bailment:**
Detailed laws on entrusted goods:
- If stolen from the keeper, and thief found: thief pays double
- If thief not found: the keeper swears an oath before the judges
- If the animal dies naturally or is injured or driven away without witness: oath of YHWH settles it
- If stolen from the keeper: keeper pays restitution
- If torn by beasts: bring evidence, no restitution

The system relies on sacred oaths when evidence is unavailable.

**Borrowing:**
- If borrowed item is damaged without owner present: borrower pays
- If owner present: owner bears the risk
- If hired (not borrowed): the hire price covers the risk

**Seduction of an Unbetrothed Virgin:**
The seducer must pay bride-price and marry her—unless her father refuses, in which case he still pays. This protects the woman's economic position in a culture where virginity affected marriage prospects.

**Capital Offenses (Social Order):**
- Sorcery (*mechashshefah*, feminine form): death
- Bestiality: death
- Sacrifice to other gods (*cherem*, dedication to destruction): death

These protect the covenant community's integrity. The "sorceress" prohibition has been used tragically in later history; the original context addressed practices associated with other cults.

**Protection of the Vulnerable:**

The heart of the chapter:
- **Strangers (גֵּר, ger)**: "You were strangers in Egypt"—memory of oppression grounds ethics
- **Widows and orphans**: Those without male protection in patriarchal society
- **The poor**: No interest on loans; pledges returned before sundown

"If they cry unto me, I will surely hear"—YHWH personally receives the cry of the oppressed. The same language as Israel's cry in Egypt (2:23-24).

**"I Am Gracious" (חַנּוּן אָנִי):**
YHWH's self-description. The poor man's cloak must be returned because YHWH hears the cry of the cold and exposed. Divine compassion grounds economic regulation.

**No Interest (נֶשֶׁךְ, neshech):**
The word *neshech* literally means "bite"—interest bites into the principal. Lending to the poor within Israel must be without interest. This is economic protection, not prohibition of all lending.

**The Garment Pledge:**
If you take a poor person's cloak as security for a loan, return it by nightfall. A cloak is both clothing and bedding. To keep it overnight is to condemn him to cold. "In what shall he sleep?"

**Firstfruits and Firstborn:**
Grain, wine ("fullness and flow"), and firstborn sons belong to YHWH. The firstborn is redeemed (not sacrificed), but the principle remains: the first belongs to God.

**Holy Men — No Torn Flesh:**
The chapter ends with a food law: don't eat what beasts have torn (*terefah*—the root of "treif," non-kosher). Holiness includes dietary discipline.

**Archetypal Layer:** The chapter oscillates between property law and social ethics, culminating in protection of the vulnerable. The **ethical inversion key** is most visible here: the stranger, widow, orphan, and poor are the moral center. YHWH hears their cry.

**Psychological Reading:** The laws shape community psychology—how we treat the weakest reveals our character. The prohibition of interest prevents debt spirals that destroy social fabric. The return of the cloak by nightfall is practical compassion.

**Ethical Inversion Applied:**
- Memory of oppression grounds ethics: "you were strangers"
- YHWH personally hears the cry of the vulnerable
- Interest is prohibited as exploitation—the "bite" that consumes
- The cloak must be returned—even collateral has limits when survival is at stake
- The stranger, widow, orphan are the test of covenant faithfulness

**Modern Equivalent:** Economic systems that extract from the poor (predatory lending, payday loans at high interest) violate these principles. Protection of the vulnerable—immigrants, those without family support, the impoverished—remains the ethical test. And the question "in what shall he sleep?" challenges any system that takes basic necessities as collateral.

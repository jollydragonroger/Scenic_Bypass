# Exodus Chapter 39: The Priestly Garments Completed

*From the Hebrew: פְקוּדֵי (Pequdei) — Accounts/Inventories*

---

**39:1** And of the blue and purple and scarlet yarn they made woven garments—בִגְדֵי־שְׂרָד (bigdei-serad)—for ministering in the holy place, and made the holy garments for Aaron, as YHWH commanded Moses.

**39:2** And he made the ephod of gold, of blue and purple and scarlet yarn, and of fine twisted linen.

**39:3** And they beat the gold into thin plates, and cut it into threads, to work it in the blue and in the purple and in the scarlet yarn and in the fine linen, the work of the skillful workman.

**39:4** They made for it shoulder pieces, attached; at its two ends it was attached.

**39:5** And the skillfully woven band of the ephod that was upon it was of one piece with it and of the same workmanship: of gold, of blue and purple and scarlet yarn, and of fine twisted linen, as YHWH commanded Moses.

**39:6** And they made the onyx stones, enclosed in settings of gold filigree, engraved with the engravings of a signet, according to the names of the sons of Israel.

**39:7** And he put them on the shoulder pieces of the ephod, stones of memorial for the sons of Israel, as YHWH commanded Moses.

---

**39:8** And he made the breastpiece, the work of a skillful workman, like the work of the ephod: of gold, of blue and purple and scarlet yarn, and of fine twisted linen.

**39:9** It was square; they made the breastpiece doubled: a span its length, and a span its breadth, doubled.

**39:10** And they set in it four rows of stones. A row of sardius, topaz, and carbuncle was the first row.

**39:11** And the second row: an emerald, a sapphire, and a diamond.

**39:12** And the third row: a jacinth, an agate, and an amethyst.

**39:13** And the fourth row: a beryl, an onyx, and a jasper; they were enclosed in settings of gold filigree.

**39:14** And the stones were according to the names of the sons of Israel, twelve, according to their names; like the engravings of a signet, each according to its name, for the twelve tribes.

**39:15** And they made upon the breastpiece chains like cords, of twisted work of pure gold.

**39:16** And they made two settings of gold filigree and two golden rings, and put the two rings on the two ends of the breastpiece.

**39:17** And they put the two cords of gold in the two rings at the ends of the breastpiece.

**39:18** And the other two ends of the two cords they put on the two settings, and attached them to the shoulder pieces of the ephod, in the front.

**39:19** And they made two golden rings, and put them on the two ends of the breastpiece, on its edge which was toward the ephod on the inside.

**39:20** And they made two golden rings, and put them on the two shoulder pieces of the ephod underneath, in the front, close to where it is joined, above the skillfully woven band of the ephod.

**39:21** And they bound the breastpiece by its rings unto the rings of the ephod with a cord of blue, that it might be upon the skillfully woven band of the ephod, and that the breastpiece might not come loose from the ephod, as YHWH commanded Moses.

---

**39:22** And he made the robe of the ephod of woven work, all of blue.

**39:23** And the opening of the robe in the midst of it was like the opening of a coat of mail, with a binding around its opening, that it might not be torn.

**39:24** And they made upon the hems of the robe pomegranates of blue and purple and scarlet yarn, twisted.

**39:25** And they made bells of pure gold, and put the bells between the pomegranates upon the hem of the robe, round about, between the pomegranates:

**39:26** A bell and a pomegranate, a bell and a pomegranate, upon the hem of the robe round about, for ministering, as YHWH commanded Moses.

**39:27** And they made the tunics of fine linen, of woven work, for Aaron and for his sons,

**39:28** And the turban of fine linen, and the headbands of fine linen, and the linen undergarments of fine twisted linen,

**39:29** And the sash of fine twisted linen, and blue and purple and scarlet yarn, the work of the embroiderer, as YHWH commanded Moses.

---

**39:30** And they made the plate of the holy crown of pure gold, and wrote upon it a writing, like the engravings of a signet: HOLY TO YHWH—קֹדֶשׁ לַיהוה (Qodesh la-YHWH).

**39:31** And they tied unto it a cord of blue, to fasten it upon the turban above, as YHWH commanded Moses.

---

**39:32** Thus was finished all the work of the tabernacle of the tent of meeting; and the children of Israel did according to all that YHWH commanded Moses; so they did.

**39:33** And they brought the tabernacle unto Moses: the tent and all its furnishings, its clasps, its boards, its bars, and its pillars, and its sockets;

**39:34** And the covering of rams' skins dyed red, and the covering of porpoise skins, and the veil of the screen;

**39:35** The ark of the testimony and its poles, and the mercy seat;

**39:36** The table, all its vessels, and the showbread;

**39:37** The pure lampstand, its lamps—the lamps to be set in order—and all its vessels, and the oil for the light;

**39:38** And the golden altar, and the anointing oil, and the fragrant incense, and the screen for the door of the tent;

**39:39** The bronze altar, and its grating of bronze, its poles, and all its vessels; the basin and its stand;

**39:40** The hangings of the court, its pillars, and its sockets, and the screen for the gate of the court, its cords, and its pegs, and all the vessels of the service of the tabernacle, for the tent of meeting;

**39:41** The woven garments for ministering in the holy place, the holy garments for Aaron the priest, and the garments of his sons, to minister as priests.

**39:42** According to all that YHWH commanded Moses, so the children of Israel did all the work.

**39:43** And Moses saw all the work, and behold, they had done it; as YHWH had commanded, so had they done it. And Moses blessed them.

---

## Synthesis Notes

**Key Restorations:**

**The Ephod:**
The outer garment of the high priest:
- Gold thread woven with blue, purple, scarlet, and linen
- Two onyx stones on the shoulders, engraved with the twelve tribes' names
- Aaron carries Israel on his shoulders

**The Breastpiece:**
Twelve gemstones in four rows:
- Row 1: Sardius, topaz, carbuncle
- Row 2: Emerald, sapphire, diamond
- Row 3: Jacinth, agate, amethyst
- Row 4: Beryl, onyx, jasper

Each stone engraved with a tribal name. Aaron carries Israel over his heart.

**The Technical Detail:**
"They beat the gold into thin plates, and cut it into threads"—the process of making gold thread for weaving. This is sophisticated metallurgy and textile work combined.

**The Blue Robe:**
Worn under the ephod:
- All blue (the color of heaven)
- Opening reinforced like armor
- Hem decorated with alternating golden bells and pomegranates

The bells sound when the priest moves—announcing presence in the sanctuary.

**The Holy Crown:**
*Nezer ha-qodesh* (נֵזֶר הַקֹּדֶשׁ)—the plate of pure gold engraved "HOLY TO YHWH," attached to the turban by a blue cord. The priest's forehead declares his consecration.

**The Completion:**
"Thus was finished all the work"—the Hebrew echoes Genesis 2:1 ("Thus were finished the heavens and the earth"). Creation language for tabernacle construction. Building the sanctuary mirrors cosmic creation.

**The Presentation to Moses:**
Everything is brought to Moses for inspection:
- The tent and all furnishings
- The ark and mercy seat
- Table and showbread
- Menorah and oil
- Altars (golden and bronze)
- Basin
- Courtyard hangings
- Priestly garments

**The Refrain:**
"As YHWH commanded Moses"—this phrase appears seven times in the chapter. The number of creation. Complete obedience.

**"Moses Saw... and Blessed Them":**
Moses inspects the work ("Moses saw"), confirms its accuracy ("behold, they had done it"), and blesses them. This parallels Genesis 1:31: "And God saw everything that he had made, and behold, it was very good."

Moses takes the role of God surveying creation. The tabernacle is the microcosmic creation.

**Archetypal Layer:** The priestly garments make Aaron a living symbol:
- Shoulders carry the tribes (responsibility)
- Heart bears the tribes (compassion)
- Forehead declares holiness (identity)
- Bells announce presence (communication)

The completion and blessing parallel the seventh day—rest after creation. The tabernacle is finished; blessing follows.

**Psychological Reading:** The meticulous repetition of "as YHWH commanded Moses" models faithful execution. There is no innovation, no improvement, no deviation. The pattern given is the pattern followed. This is not mindless compliance but careful attention.

**Ethical Inversion Applied:**
- Obedience is creative work—the artisans obey by making
- The priest carries the people—leadership as burden-bearing
- Moses blesses the workers—recognition follows completion
- Creation language for construction—human work participates in divine order
- "They had done it"—communal accomplishment, not individual glory

**Modern Equivalent:** Projects reach completion through faithful execution. The refrain "as commanded, so they did" is the mark of reliable implementation. And the blessing at the end—Moses' recognition of work well done—models how leaders should acknowledge those who carry out the vision.

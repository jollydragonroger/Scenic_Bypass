# Exodus Chapter 33: The Presence and the Glory

*From the Hebrew: Face to Face*

---

**33:1** And YHWH spoke unto Moses: "Go, get up from here, you and the people whom you have brought up out of the land of Egypt, unto the land which I swore unto Abraham, to Isaac, and to Jacob, saying, 'To your seed I will give it.'

**33:2** "And I will send a messenger before you; and I will drive out the Canaanite, the Amorite, and the Hittite, and the Perizzite, the Hivite, and the Jebusite.

**33:3** "Go up to a land flowing with milk and honey; for I will not go up in your midst—כִּי לֹא אֶעֱלֶה בְּקִרְבְּךָ (ki lo e'eleh be-qirbeha)—for you are a stiff-necked people, lest I consume you on the way."

**33:4** And when the people heard this evil word, they mourned; and no man put on his ornaments.

**33:5** And YHWH said unto Moses: "Say unto the children of Israel, 'You are a stiff-necked people; if I go up into your midst for one moment, I would consume you. Now therefore put off your ornaments from you, that I may know what to do unto you.'"

**33:6** And the children of Israel stripped themselves of their ornaments from Mount Horeb onward.

---

**33:7** And Moses would take the tent and pitch it outside the camp, afar off from the camp; and he called it the tent of meeting—אֹהֶל מוֹעֵד (ohel mo'ed). And it came to pass that everyone who sought YHWH would go out unto the tent of meeting, which was outside the camp.

**33:8** And it came to pass, when Moses went out unto the tent, that all the people rose up, and stood every man at the door of his tent, and looked after Moses, until he was gone into the tent.

**33:9** And it came to pass, when Moses entered into the tent, that the pillar of cloud descended and stood at the door of the tent; and YHWH spoke with Moses.

**33:10** And all the people saw the pillar of cloud standing at the door of the tent; and all the people rose up and worshipped, every man at the door of his tent.

**33:11** And YHWH spoke unto Moses face to face—פָּנִים אֶל־פָּנִים (panim el-panim)—as a man speaks unto his friend. And he would return into the camp; but his servant Joshua the son of Nun, a young man, did not depart from the midst of the tent.

---

**33:12** And Moses said unto YHWH: "See, you say unto me, 'Bring up this people'; and you have not let me know whom you will send with me. Yet you have said, 'I know you by name, and you have also found favor in my sight.'

**33:13** "Now therefore, if I have found favor in your sight, please show me your way—הוֹדִעֵנִי נָא אֶת־דְּרָכֶךָ (hodi'eni na et-derachecha)—that I may know you, that I may find favor in your sight; and consider that this nation is your people."

**33:14** And YHWH said: "My presence shall go—פָּנַי יֵלֵכוּ (panai yelechu)—and I will give you rest."

**33:15** And Moses said unto him: "If your presence does not go, do not bring us up from here.

**33:16** "For how shall it be known that I have found favor in your sight, I and your people? Is it not by your going with us, so that we are distinguished—וְנִפְלִינוּ (ve-niflinu)—I and your people, from every people that is on the face of the earth?"

**33:17** And YHWH said unto Moses: "This thing also that you have spoken I will do; for you have found favor in my sight, and I know you by name."

**33:18** And Moses said: "Please, show me your glory—הַרְאֵנִי נָא אֶת־כְּבֹדֶךָ (har'eni na et-kevodecha)."

**33:19** And YHWH said: "I will make all my goodness—כָּל־טוּבִי (kol-tuvi)—pass before you, and I will proclaim the name of YHWH before you; and I will be gracious to whom I will be gracious, and will show mercy to whom I will show mercy—וְחַנֹּתִי אֶת־אֲשֶׁר אָחֹן וְרִחַמְתִּי אֶת־אֲשֶׁר אֲרַחֵם (ve-channoti et-asher achon ve-richamti et-asher arachem)."

**33:20** And YHWH said: "You cannot see my face—לֹא תוּכַל לִרְאֹת אֶת־פָּנָי (lo tuchal lir'ot et-panai)—for no man shall see me and live."

**33:21** And YHWH said: "Behold, there is a place by me, and you shall stand upon the rock.

**33:22** "And it shall come to pass, while my glory passes by, that I will put you in a cleft of the rock—בְּנִקְרַת הַצּוּר (be-niqrat ha-tsur)—and I will cover you with my hand until I have passed by.

**33:23** "And I will take away my hand, and you shall see my back—אֶת־אֲחֹרָי (et-achorai)—but my face shall not be seen."

---

## Synthesis Notes

**Key Restorations:**

**"I Will Not Go Up in Your Midst":**
YHWH threatens withdrawal. The promise of land remains, but the promise of presence is conditional. A messenger will lead, but YHWH personally will not travel with them. Holiness and stiff-necked people are incompatible—"lest I consume you."

**The People Mourn:**
They strip off their ornaments. The gold that made the calf is now removed in mourning. External adornment is set aside in grief over lost presence.

**The Tent of Meeting Outside the Camp:**
Moses pitches a tent *outside* the camp—not the tabernacle (not yet built), but a provisional meeting place. The distance signifies the breach. YHWH meets Moses there, but not within the camp.

**"Face to Face":**
*Panim el-panim* (פָּנִים אֶל־פָּנִים)—YHWH speaks with Moses as friend to friend. This is intimacy, directness, personal relationship. Yet verse 20 will say Moses cannot see YHWH's face. The paradox: Moses experiences "face to face" communion while being told the face cannot be seen.

**Joshua Remains:**
Joshua does not leave the tent. His continuous presence prepares him for succession. While Moses goes back to the camp, Joshua stays near the meeting place.

**Moses' Request — "Show Me Your Way":**
Moses wants to know YHWH's *derech* (דֶּרֶךְ)—way, path, manner. Not just what YHWH commands, but how YHWH operates. Understanding leads to intimacy: "that I may know you."

**"My Presence Shall Go":**
*Panai yelechu* (פָּנַי יֵלֵכוּ)—literally "my face will go." YHWH concedes to Moses' plea. The presence will accompany. The threat of withdrawal is reversed.

**"We Are Distinguished":**
*Ve-niflinu* (וְנִפְלִינוּ)—from *palah*, to be distinct, wonderful. What makes Israel unique is not ethnicity or land but YHWH's presence going with them. Presence creates identity.

**Moses' Ultimate Request — "Show Me Your Glory":**
Having secured the promise of presence, Moses asks for more: *kevodecha* (כְּבֹדֶךָ)—your glory. He wants the full theophany, the unmediated vision.

**"All My Goodness":**
YHWH responds: "I will make all my goodness (*tuvi*) pass before you." Glory is expressed as goodness. The divine nature is fundamentally benevolent.

**"I Will Be Gracious to Whom I Will Be Gracious":**
This is divine freedom—*chen* and *rachamim* (grace and mercy) are given as YHWH chooses. There is no formula that compels grace. YHWH remains sovereign even in mercy.

**"You Cannot See My Face":**
*Lo tuchal lir'ot et-panai*—the limit. Full frontal theophany is fatal. The face—the unmediated presence—destroys the finite creature.

**The Cleft in the Rock:**
Moses will be hidden in the rock's cleft (*niqrat ha-tsur*). YHWH will cover him with divine hand (*kaf*) as glory passes. Then Moses will see the "back" (*achorai*)—what follows the passing, the afterglow, the trailing effects.

**Glory's Back:**
What Moses sees is not the essence but the echo—not the face but the backside. This is indirect revelation, mediated theophany, glory's trace rather than glory's source.

**Archetypal Layer:** The cleft in the rock is **sanctuary within danger**. The passing glory is the numinous in motion—too powerful to face, but leaving traces that can be perceived. The hand covering Moses is divine protection enabling partial revelation. The paradox: Moses speaks face to face yet cannot see the face.

**Psychological Reading:** Moses' ascending requests model spiritual growth:
1. Show me your way (ethical guidance)
2. Let your presence go with us (assured relationship)
3. Show me your glory (ultimate vision)

The final request exceeds what the finite can receive. The self cannot see the Self directly—but it can see the wake, the effect, the trailing glory.

**Ethical Inversion Applied:**
- Presence is the supreme gift—land without presence is inadequate
- Distinction (*niflinu*) comes from relationship, not from nature
- Grace is given freely—"to whom I will"—no claim compels it
- The limit ("you cannot see my face") is not arbitrary but protective
- What Moses sees is the backside—revelation is always partial

**Modern Equivalent:** The deepest encounter with the transcendent is indirect. "Face to face" conversation coexists with inability to see the face. We perceive traces, aftereffects, glory's backside—not the direct essence. And what distinguishes a community is not its achievements but the presence that accompanies it.

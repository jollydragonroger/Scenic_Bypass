# Exodus Chapter 40: The Tabernacle Erected

*From the Hebrew: The Glory Fills the Dwelling*

---

**40:1** And YHWH spoke unto Moses, saying:

**40:2** "On the first day of the first month you shall set up the tabernacle of the tent of meeting.

**40:3** "And you shall put therein the ark of the testimony, and screen the ark with the veil.

**40:4** "And you shall bring in the table and set in order the things that are upon it; and you shall bring in the lampstand and light its lamps.

**40:5** "And you shall set the golden altar for incense before the ark of the testimony, and put up the screen of the door to the tabernacle.

**40:6** "And you shall set the altar of burnt offering before the door of the tabernacle of the tent of meeting.

**40:7** "And you shall set the basin between the tent of meeting and the altar, and put water therein.

**40:8** "And you shall set up the court round about, and hang up the screen of the gate of the court.

**40:9** "And you shall take the anointing oil, and anoint the tabernacle and all that is therein, and shall sanctify it and all its vessels; and it shall be holy.

**40:10** "And you shall anoint the altar of burnt offering and all its vessels, and sanctify the altar; and the altar shall be most holy.

**40:11** "And you shall anoint the basin and its stand, and sanctify it.

**40:12** "And you shall bring Aaron and his sons unto the door of the tent of meeting, and wash them with water.

**40:13** "And you shall put upon Aaron the holy garments, and anoint him, and sanctify him, that he may minister unto me as priest.

**40:14** "And you shall bring his sons, and put tunics upon them.

**40:15** "And you shall anoint them, as you anointed their father, that they may minister unto me as priests; and their anointing shall be for an everlasting priesthood throughout their generations."

**40:16** Thus did Moses; according to all that YHWH commanded him, so he did.

---

**40:17** And it came to pass in the first month in the second year, on the first day of the month, that the tabernacle was set up.

**40:18** And Moses set up the tabernacle, and laid its sockets, and set up its boards, and put in its bars, and set up its pillars.

**40:19** And he spread the tent over the tabernacle, and put the covering of the tent above upon it, as YHWH commanded Moses.

**40:20** And he took and put the testimony into the ark, and set the poles on the ark, and put the mercy seat above upon the ark.

**40:21** And he brought the ark into the tabernacle, and set up the veil of the screen, and screened the ark of the testimony, as YHWH commanded Moses.

**40:22** And he put the table in the tent of meeting, on the side of the tabernacle northward, outside the veil.

**40:23** And he set the bread in order upon it before YHWH, as YHWH commanded Moses.

**40:24** And he put the lampstand in the tent of meeting, opposite the table, on the side of the tabernacle southward.

**40:25** And he lighted the lamps before YHWH, as YHWH commanded Moses.

**40:26** And he put the golden altar in the tent of meeting before the veil;

**40:27** And he burned fragrant incense upon it, as YHWH commanded Moses.

**40:28** And he put up the screen of the door to the tabernacle.

**40:29** And the altar of burnt offering he set at the door of the tabernacle of the tent of meeting, and offered upon it the burnt offering and the grain offering, as YHWH commanded Moses.

**40:30** And he set the basin between the tent of meeting and the altar, and put water therein, for washing.

**40:31** And Moses and Aaron and his sons washed their hands and their feet thereat;

**40:32** When they went into the tent of meeting, and when they came near unto the altar, they washed, as YHWH commanded Moses.

**40:33** And he set up the court round about the tabernacle and the altar, and put up the screen of the gate of the court. So Moses finished the work—וַיְכַל מֹשֶׁה אֶת־הַמְּלָאכָה (va-yechal Mosheh et-ha-melachah).

---

**40:34** And the cloud covered the tent of meeting, and the glory of YHWH filled the tabernacle—וּכְבוֹד יהוה מָלֵא אֶת־הַמִּשְׁכָּן (u-chevod YHWH male et-ha-mishkan).

**40:35** And Moses was not able to enter into the tent of meeting, because the cloud dwelt upon it, and the glory of YHWH filled the tabernacle.

**40:36** And when the cloud was taken up from over the tabernacle, the children of Israel went forward throughout all their journeys.

**40:37** But if the cloud was not taken up, then they did not journey until the day that it was taken up.

**40:38** For the cloud of YHWH was upon the tabernacle by day, and fire was in it by night, in the sight of all the house of Israel, throughout all their journeys.

---

## Synthesis Notes

**Key Restorations:**

**The First Day of the First Month:**
Exactly one year after the exodus (Exodus 12:2 established the calendar). The tabernacle is erected on the anniversary of liberation. A new beginning on the new year's day.

**The Sequence of Assembly:**

Moses personally sets up the tabernacle:
1. Framework (sockets, boards, bars, pillars)
2. Tent coverings
3. Ark with testimony and mercy seat → into the holy of holies
4. Veil to screen the ark
5. Table with showbread → north side
6. Menorah lit → south side
7. Golden altar with incense → before the veil
8. Screen at the door
9. Bronze altar at the entrance → burnt offering
10. Basin with water → between tent and altar
11. Courtyard hangings and gate screen

**"As YHWH Commanded Moses":**
The phrase appears seven times in verses 19-32. Seven times = completion. Perfect obedience.

**"Moses Finished the Work":**
*Va-yechal Mosheh et-ha-melachah* (וַיְכַל מֹשֶׁה אֶת־הַמְּלָאכָה)—the same language as Genesis 2:2 ("God finished his work"). Creation and tabernacle construction are parallel. The tabernacle is completed as the cosmos was completed.

**The Glory Fills the Tabernacle:**

The climax of Exodus:
- The cloud covers the tent of meeting
- The glory of YHWH (*kevod YHWH*) fills the tabernacle
- Moses cannot enter—the glory is too intense

After all the instructions, all the construction, all the obedience—the result is divine presence. YHWH moves in. The tabernacle becomes what it was built to be: the dwelling place of God.

**Moses Excluded:**
Even Moses, who spoke with YHWH face to face, cannot enter when the glory fills. The presence is overwhelming. Later (Leviticus 16) entry will be regulated—the high priest, once a year, with blood and incense.

**The Cloud and Fire:**
The pillar that led from Egypt (13:21-22) now rests on the tabernacle:
- Cloud by day
- Fire by night
- Visible to all Israel

The same presence that guided becomes the presence that dwells. The journey continues, but now with YHWH dwelling among them.

**The Journeys Regulated:**
When the cloud rises, Israel travels. When it stays, Israel waits. The journey is now guided by presence, not by human decision. Numbers 9:15-23 will expand this: sometimes the cloud stayed for days; sometimes just overnight. They moved when it moved.

**Archetypal Layer:** The tabernacle is complete—the **axis mundi** is established. Heaven and earth meet in the tent. The glory filling the tabernacle is the culmination of the exodus: not just freedom from Egypt but communion with YHWH. The journey that began with groaning under oppression ends with glory in the midst.

The cloud/fire is the visible sign of invisible presence. Israel no longer travels alone. The God who brought them out now dwells among them.

**Psychological Reading:** The work is complete; the glory arrives. This is the pattern of genuine spiritual work—preparation, obedience, construction, and then the arrival of what could not be manufactured. Moses cannot enter—the ego, even the holiest ego, is overwhelmed by the fullness of presence.

**Ethical Inversion Applied:**
- The tabernacle is built by human hands but filled by divine glory
- Obedience creates the container; presence is gift
- Even Moses is excluded when glory fills—the holy overwhelms
- The cloud guides the journey—divine direction, human following
- The fire by night / cloud by day is visible to all Israel—presence is public

**The End of Exodus:**
Exodus begins with Israel enslaved, groaning, crying out. It ends with Israel free, encamped around the tabernacle, the glory of YHWH in their midst, cloud and fire guiding their journey.

From bondage to presence. From Pharaoh's service to YHWH's dwelling. From Egypt to Sinai to the journeys that lie ahead.

The book ends not at a destination but on the way—"throughout all their journeys." Leviticus will address how to live with the holy presence. Numbers will narrate the journeys. But Exodus closes with the fundamental reality established: YHWH dwells among them.

---

## Synthesis Notes for the Book of Exodus

Exodus traces the arc from slavery to sanctuary:
- **Chapters 1-18**: Liberation (oppression, plagues, sea crossing, wilderness provision)
- **Chapters 19-24**: Covenant (Sinai theophany, Ten Words, Book of the Covenant, ratification)
- **Chapters 25-31**: Instructions (tabernacle, priesthood, sabbath)
- **Chapters 32-34**: Crisis and Renewal (golden calf, intercession, new tablets)
- **Chapters 35-40**: Construction (obedient implementation, completion, glory)

The themes interweave:
- **Liberation for presence**: Freedom from Egypt is for dwelling with YHWH
- **Law as gift**: The commandments structure life with the holy
- **Obedience as creation**: The tabernacle built "as YHWH commanded" parallels cosmic creation
- **Glory as goal**: The book ends not with arrival in the land but with glory in the tent

The exodus is incomplete without the tabernacle. Freedom without presence is purposeless. The book answers: Why were we freed? So that YHWH might dwell among us.

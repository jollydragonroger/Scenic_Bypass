# Exodus Chapter 18: Jethro's Visit

*From the Hebrew: יִתְרוֹ (Yitro) — Counsel from Midian*

---

**18:1** And Jethro—יִתְרוֹ (Yitro)—the priest of Midian, Moses' father-in-law, heard of all that Consciousness had done for Moses and for Israel his people, that YHWH had brought Israel out of Egypt.

**18:2** And Jethro, Moses' father-in-law, took Zipporah, Moses' wife, after he had sent her back,

**18:3** And her two sons, of whom the name of one was Gershom—גֵּרְשֹׁם (Gershom)—for he said, "I have been a stranger in a foreign land";

**18:4** And the name of the other was Eliezer—אֱלִיעֶזֶר (Eli'ezer)—"for the Consciousness of my father was my help—בְּעֶזְרִי (be-ezri)—and delivered me from the sword of Pharaoh."

**18:5** And Jethro, Moses' father-in-law, came with his sons and his wife unto Moses, unto the wilderness where he was encamped, at the mountain of Consciousness.

**18:6** And he said unto Moses: "I, your father-in-law Jethro, have come unto you, and your wife, and her two sons with her."

**18:7** And Moses went out to meet his father-in-law, and bowed down and kissed him; and they asked each other of their welfare; and they came into the tent.

**18:8** And Moses told his father-in-law all that YHWH had done unto Pharaoh and to the Egyptians for Israel's sake, all the hardship—הַתְּלָאָה (ha-tela'ah)—that had come upon them in the way, and how YHWH had delivered them.

**18:9** And Jethro rejoiced—וַיִּחַדְּ (va-yichad)—over all the good which YHWH had done to Israel, in that he had delivered them from the hand of the Egyptians.

**18:10** And Jethro said: "Blessed be YHWH—בָּרוּךְ יהוה (baruch YHWH)—who has delivered you from the hand of the Egyptians and from the hand of Pharaoh, who has delivered the people from under the hand of the Egyptians.

**18:11** "Now I know that YHWH is greater than all gods—כִּי גָדוֹל יהוה מִכָּל־הָאֱלֹהִים (ki gadol YHWH mi-kol-ha-elohim); for in the thing wherein they dealt arrogantly, he was above them."

**18:12** And Jethro, Moses' father-in-law, took a burnt offering and sacrifices for Consciousness; and Aaron came, and all the elders of Israel, to eat bread with Moses' father-in-law before Consciousness.

---

**18:13** And it came to pass on the morrow, that Moses sat to judge the people; and the people stood by Moses from the morning unto the evening.

**18:14** And Moses' father-in-law saw all that he was doing to the people, and he said: "What is this thing that you are doing to the people? Why do you sit alone, and all the people stand by you from morning unto evening?"

**18:15** And Moses said unto his father-in-law: "Because the people come unto me to inquire of Consciousness.

**18:16** "When they have a matter, it comes unto me; and I judge between a man and his neighbor, and I make them know the statutes of Consciousness and his laws."

**18:17** And Moses' father-in-law said unto him: "The thing that you are doing is not good.

**18:18** "You will surely wear yourself out—נָבֹל תִּבֹּל (navol tibbol)—both you and this people that is with you; for the thing is too heavy for you; you are not able to do it alone.

**18:19** "Listen now unto my voice; I will give you counsel, and may Consciousness be with you. You be for the people before Consciousness, and you bring the matters unto Consciousness.

**18:20** "And you shall teach them—וְהִזְהַרְתָּה (ve-hizhartah)—the statutes and the laws, and shall show them the way in which they must walk and the work that they must do.

**18:21** "And you shall look out from all the people able men—אַנְשֵׁי־חַיִל (anshei-chayil)—who fear Consciousness, men of truth, hating unjust gain; and place such over them to be rulers of thousands, rulers of hundreds, rulers of fifties, and rulers of tens.

**18:22** "And let them judge the people at all times; and every great matter they shall bring unto you, but every small matter they shall judge themselves; so shall it be easier for you, and they shall bear the burden with you.

**18:23** "If you shall do this thing, and Consciousness command you so, then you shall be able to endure, and all this people also shall go to their place in peace."

**18:24** And Moses listened to the voice of his father-in-law and did all that he had said.

**18:25** And Moses chose able men out of all Israel, and made them heads over the people: rulers of thousands, rulers of hundreds, rulers of fifties, and rulers of tens.

**18:26** And they judged the people at all times; the hard matters they brought unto Moses, but every small matter they judged themselves.

**18:27** And Moses let his father-in-law depart; and he went his way into his own land.

---

## Synthesis Notes

**Key Restorations:**

**Jethro the Priest of Midian:**
A non-Israelite priest brings Moses' family and offers crucial counsel. Wisdom comes from outside the covenant community. Jethro is honored, not dismissed as pagan.

**Zipporah and the Sons:**
Moses apparently sent his family back to Midian at some point—perhaps before confronting Pharaoh, perhaps after the circumcision incident (4:24-26). The text doesn't explain. Now they are reunited.

**Eliezer:**
The second son, named here for the first time: "The Consciousness of my father was my help." The name encodes Moses' experience of divine deliverance.

**Jethro's Confession:**
"Now I know that YHWH is greater than all gods." This is not monotheism but comparative henotheism—YHWH is supreme among gods. Jethro, a Midianite priest, recognizes YHWH's supremacy through the exodus narrative.

**"In the Thing Wherein They Dealt Arrogantly":**
The Egyptians' pride became their downfall. Measure for measure—what they used to oppress became the instrument of their destruction.

**Jethro's Sacrifice:**
A Midianite priest offers burnt offering and sacrifices "for Consciousness." Aaron and the elders eat with him "before Consciousness." This is interfaith worship—a non-Israelite's offering is accepted.

**Moses' Unsustainable Burden:**
Moses judges alone, from morning to evening. The people stand waiting. The system is inefficient and exhausting. Jethro sees immediately what Moses cannot: this will destroy him and the people.

**"You Will Surely Wear Yourself Out":**
*Navol tibbol* (נָבֹל תִּבֹּל)—the doubling intensifies: "Withering you will wither." Leadership burnout is predictable. The one who cannot delegate will collapse.

**Jethro's Counsel — Delegation:**

Jethro's system:
1. **Moses' role**: Represent the people before Consciousness; teach statutes and laws; handle the great matters
2. **Appointed judges**: Rulers of thousands, hundreds, fifties, tens; handle routine cases; bring only difficult matters up

This is organizational structure—hierarchy for efficiency, delegation for sustainability.

**The Qualifications:**
*Anshei-chayil* (אַנְשֵׁי־חַיִל)—"men of valor/ability"
- Fear Consciousness (reverent)
- Men of truth (honest)
- Hating unjust gain (incorruptible)

Character precedes position. Competence without integrity disqualifies.

**"If Consciousness Command You So":**
Jethro conditions his advice: implement this if YHWH approves. The counsel is practical, but divine endorsement is necessary. Moses doesn't act merely on human wisdom.

**Moses Listens:**
"Moses listened to the voice of his father-in-law and did all that he had said." The leader receives counsel from a non-Israelite elder and implements it. Wisdom is not limited to Israel.

**Jethro Departs:**
Having given counsel and seen his daughter and grandsons, Jethro returns to Midian. He doesn't stay; he doesn't become Israelite. He contributes and goes home.

**Archetypal Layer:** Jethro represents **wisdom from outside the system**. The insider (Moses) cannot see his own unsustainability. The outsider (Jethro) sees immediately and offers practical counsel. Wisdom is not tribal; it comes from wherever it arises.

**Psychological Reading:** The leader who tries to do everything alone is exhibiting ego inflation—only I can judge, only I can mediate. Jethro's intervention is the necessary correction: share the burden, distribute responsibility, focus on what only you can do. Sustainable leadership requires structure.

**Ethical Inversion Applied:**
- A Midianite priest teaches Israel's leader about governance—truth from outside
- Jethro's sacrifice is accepted—non-Israelite worship is honored
- Delegation is not weakness but wisdom
- Character qualifications for judges prioritize integrity over tribal affiliation
- Moses' willingness to learn from his father-in-law models humility

**Modern Equivalent:** Burnout is predictable when leaders refuse to delegate. "You will wear yourself out" is the diagnosis of every unsustainable system. The solution: distributed authority, clear hierarchy, and focus. And wisdom often comes from outside—the outsider sees what the insider cannot. The test is whether the insider can listen.

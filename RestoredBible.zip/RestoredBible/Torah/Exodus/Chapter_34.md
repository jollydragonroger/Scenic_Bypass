# Exodus Chapter 34: The Covenant Renewed

*From the Hebrew: The Shining Face*

---

**34:1** And YHWH said unto Moses: "Hew for yourself two tablets of stone like the first; and I will write upon the tablets the words that were on the first tablets, which you broke.

**34:2** "And be ready by the morning, and come up in the morning unto Mount Sinai, and present yourself there to me on the top of the mountain.

**34:3** "And no man shall come up with you, neither let any man be seen throughout all the mountain; neither let the flocks nor herds graze before that mountain."

**34:4** And Moses hewed two tablets of stone like the first; and Moses rose up early in the morning and went up unto Mount Sinai, as YHWH had commanded him, and took in his hand the two tablets of stone.

**34:5** And YHWH descended in the cloud and stood with him there, and proclaimed the name of YHWH—וַיִּקְרָא בְשֵׁם יהוה (va-yiqra ve-shem YHWH).

**34:6** And YHWH passed by before him and proclaimed: "YHWH, YHWH, a God merciful and gracious—אֵל רַחוּם וְחַנּוּן (El rachum ve-channun)—slow to anger, and abounding in loving-kindness and truth—וְרַב־חֶסֶד וֶאֱמֶת (ve-rav-chesed ve-emet),

**34:7** "Keeping loving-kindness unto thousands, forgiving iniquity and transgression and sin—נֹשֵׂא עָוֺן וָפֶשַׁע וְחַטָּאָה (nose avon va-fesha ve-chatta'ah)—but who will by no means clear the guilty, visiting the iniquity of the fathers upon the children and upon the children's children, unto the third and unto the fourth generation."

**34:8** And Moses made haste and bowed his head toward the earth and worshipped.

**34:9** And he said: "If now I have found favor in your sight, O Lord, let the Lord, I pray, go in our midst; for it is a stiff-necked people; and pardon our iniquity and our sin, and take us for your inheritance."

---

**34:10** And YHWH said: "Behold, I am making a covenant; before all your people I will do marvels—נִפְלָאֹת (nifla'ot)—such as have not been wrought in all the earth nor in any nation; and all the people among whom you are shall see the work of YHWH, for it is a fearsome thing that I am doing with you.

**34:11** "Observe what I command you this day; behold, I am driving out before you the Amorite and the Canaanite and the Hittite and the Perizzite and the Hivite and the Jebusite.

**34:12** "Take heed to yourself, lest you make a covenant with the inhabitants of the land where you are going, lest it be a snare in your midst.

**34:13** "But you shall destroy their altars, and break their pillars, and cut down their Asherim—אֲשֵׁרָיו (asherav).

**34:14** "For you shall worship no other god; for YHWH, whose name is Jealous—קַנָּא שְׁמוֹ (Qanna shemo)—is a jealous God—אֵל קַנָּא (El qanna).

**34:15** "Lest you make a covenant with the inhabitants of the land, and they go astray after their gods, and sacrifice unto their gods, and one call you and you eat of his sacrifice,

**34:16** "And you take of their daughters for your sons, and their daughters go astray after their gods and make your sons go astray after their gods.

**34:17** "You shall make no molten gods for yourself.

**34:18** "The feast of unleavened bread you shall keep. Seven days you shall eat unleavened bread, as I commanded you, at the time appointed in the month of Aviv; for in the month of Aviv you came out from Egypt.

**34:19** "All that opens the womb is mine; and all your cattle that is male, the firstlings of ox and sheep.

**34:20** "And the firstling of a donkey you shall redeem with a lamb; and if you will not redeem it, then you shall break its neck. All the firstborn of your sons you shall redeem. And none shall appear before me empty.

**34:21** "Six days you shall work, but on the seventh day you shall rest; in plowing time and in harvest you shall rest.

**34:22** "And you shall observe the feast of weeks, of the firstfruits of wheat harvest, and the feast of ingathering at the turn of the year.

**34:23** "Three times in the year shall all your males appear before the Lord YHWH, the Consciousness of Israel.

**34:24** "For I will cast out nations before you and enlarge your borders; neither shall any man covet your land when you go up to appear before YHWH your Consciousness three times in the year.

**34:25** "You shall not offer the blood of my sacrifice with leavened bread; neither shall the sacrifice of the feast of the Passover be left unto the morning.

**34:26** "The first of the firstfruits of your land you shall bring unto the house of YHWH your Consciousness. You shall not boil a kid in its mother's milk."

**34:27** And YHWH said unto Moses: "Write these words; for according to the tenor of these words I have made a covenant with you and with Israel."

**34:28** And Moses was there with YHWH forty days and forty nights; he did neither eat bread nor drink water. And YHWH wrote upon the tablets the words of the covenant, the ten words—עֲשֶׂרֶת הַדְּבָרִים (aseret ha-devarim).

---

**34:29** And it came to pass, when Moses came down from Mount Sinai—and the two tablets of the testimony were in Moses' hand when he came down from the mountain—that Moses did not know that the skin of his face shone—קָרַן עוֹר פָּנָיו (qaran or panav)—because he had been speaking with YHWH.

**34:30** And Aaron and all the children of Israel saw Moses, and behold, the skin of his face shone; and they were afraid to come near him.

**34:31** And Moses called unto them; and Aaron and all the leaders of the congregation returned unto him; and Moses spoke to them.

**34:32** And afterward all the children of Israel came near; and he commanded them all that YHWH had spoken with him on Mount Sinai.

**34:33** And when Moses had finished speaking with them, he put a veil—מַסְוֶה (masveh)—upon his face.

**34:34** But when Moses went in before YHWH to speak with him, he would take off the veil until he came out; and he came out and spoke unto the children of Israel that which he was commanded.

**34:35** And the children of Israel saw the face of Moses, that the skin of Moses' face shone; and Moses put the veil upon his face again, until he went in to speak with YHWH.

---

## Synthesis Notes

**Key Restorations:**

**The New Tablets:**
Moses hews the stone; YHWH writes. The first tablets were entirely divine work (31:18); now there is human labor. The renewal involves human participation.

**The Theophany (34:6-7):**

The divine self-proclamation—one of the most cited texts in Scripture:

"YHWH, YHWH"—the name repeated, emphasizing identity

The **Thirteen Attributes of Mercy** (traditional enumeration):
1. YHWH (before sin)
2. YHWH (after sin and repentance)
3. El (mighty God)
4. Rachum (merciful/compassionate)
5. Channun (gracious)
6. Erech appayim (slow to anger)
7. Rav chesed (abounding in loving-kindness)
8. Emet (truth/faithfulness)
9. Notser chesed la-alafim (preserving kindness to thousands)
10. Nose avon (forgiving iniquity)
11. Nose fesha (forgiving transgression)
12. Nose chatta'ah (forgiving sin)
13. Naqqeh (clearing/not clearing the guilty)

This is YHWH's self-definition—character revealed, not abstract theology.

**Mercy and Justice Together:**
YHWH forgives iniquity, transgression, and sin—*but* does not clear the guilty. The tension is maintained: forgiveness is real; consequences are real. Mercy dominates (thousands vs. 3-4 generations), but justice is not erased.

**Moses' Plea:**
Moses now uses "stiff-necked people" as an argument *for* YHWH's presence: because they are stubborn, they need YHWH with them. The diagnosis becomes the plea.

**The Renewed Covenant:**
The stipulations largely repeat earlier material:
- No covenants with Canaanites
- Destroy their cult objects
- No molten gods
- Keep the three festivals
- Firstborn belong to YHWH
- Sabbath (even in plowing and harvest)
- Do not boil a kid in its mother's milk

The covenant is renewed, not replaced. The same terms apply after the golden calf as before.

**"YHWH, Whose Name Is Jealous":**
*Qanna shemo* (קַנָּא שְׁמוֹ)—"Jealous is his name." The exclusivity is part of YHWH's identity. This is not petty envy but passionate possessiveness—like spousal love that will not share.

**Forty Days Again:**
Moses again spends forty days on the mountain, fasting. The parallel to the first ascent is exact. The renewal mirrors the original.

**"The Ten Words":**
*Aseret ha-devarim* (עֲשֶׂרֶת הַדְּבָרִים)—the Decalogue. YHWH writes them on the stone. The core of the covenant remains the Ten Commandments.

**The Shining Face:**

*Qaran or panav* (קָרַן עוֹר פָּנָיו)—literally "the skin of his face horned/shone." The verb *qaran* comes from *qeren* (horn). The skin radiated light—possibly with horn-like rays. This is why Michelangelo sculpted Moses with horns; the Hebrew allows both readings.

Moses doesn't know his face is shining. The transformation is external evidence of internal encounter. He is unconscious of his own radiance.

**The Veil:**
Moses veils his face after speaking to the people. When he enters YHWH's presence, he removes it. When he speaks to Israel, the veil is off. After speaking, he covers again.

Paul interprets this in 2 Corinthians 3:7-18: Moses veiled the fading glory; in Christ, the veil is removed.

**Archetypal Layer:** The divine self-proclamation is the supreme revelation of character. What YHWH shows Moses is not form but attributes—who YHWH is, not what YHWH looks like. The shining face is the **transformation through encounter**—prolonged presence in the divine changes the one who approaches. The veil protects the people from overwhelming glory.

**Psychological Reading:** The encounter with the transcendent transforms. Moses descends changed—visibly changed. He is unaware of his own radiance; genuine transformation is often invisible to the transformed. The veil suggests that direct glory is too much for ordinary consciousness; it must be mediated.

**Ethical Inversion Applied:**
- The divine attributes prioritize mercy—13 attributes mostly positive
- "Forgiving iniquity, transgression, and sin"—comprehensive forgiveness
- Yet "not clearing the guilty"—consequences remain
- Moses' radiance is unconscious—true holiness is unself-conscious
- The veil protects rather than hides—gradual revelation

**Modern Equivalent:** We become what we gaze upon. Moses, spending time in the presence, is transformed. The transformation is visible to others before it is known to the self. And the "thirteen attributes" show that the divine nature is primarily merciful—slow to anger, abounding in kindness, forgiving. Justice exists, but mercy predominates.

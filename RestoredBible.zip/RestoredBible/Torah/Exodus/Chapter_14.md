# Exodus Chapter 14: The Crossing of the Sea

*From the Hebrew: בְּשַׁלַּח (Beshalach) — When He Let Go*

---

**14:1** And YHWH spoke unto Moses, saying:

**14:2** "Speak unto the children of Israel, that they turn back and encamp before Pi-hahiroth, between Migdol and the sea, before Baal-zephon; opposite it shall you encamp by the sea.

**14:3** "And Pharaoh shall say of the children of Israel, 'They are entangled in the land; the wilderness has shut them in.'

**14:4** "And I will harden Pharaoh's heart, and he shall pursue after them; and I will be glorified—וְאִכָּבְדָה (ve-ikkavdah)—in Pharaoh and in all his host; and the Egyptians shall know that I am YHWH." And they did so.

**14:5** And it was told the king of Egypt that the people had fled; and the heart of Pharaoh and of his servants was turned against the people, and they said, "What is this we have done, that we have let Israel go from serving us?"

**14:6** And he made ready his chariot and took his people with him.

**14:7** And he took six hundred chosen chariots—שֵׁשׁ־מֵאוֹת רֶכֶב בָּחוּר (shesh-me'ot rechev bachur)—and all the chariots of Egypt, and captains over all of them.

**14:8** And YHWH hardened the heart of Pharaoh king of Egypt, and he pursued after the children of Israel; and the children of Israel went out with a high hand—בְּיָד רָמָה (be-yad ramah).

**14:9** And the Egyptians pursued after them—all the horses and chariots of Pharaoh, and his horsemen and his army—and overtook them encamped by the sea, by Pi-hahiroth, before Baal-zephon.

**14:10** And Pharaoh drew near; and the children of Israel lifted up their eyes, and behold, the Egyptians were marching after them; and they were very afraid; and the children of Israel cried out unto YHWH.

**14:11** And they said unto Moses: "Is it because there were no graves in Egypt that you have taken us to die in the wilderness? What is this you have done to us, to bring us out of Egypt?

**14:12** "Is not this the word that we spoke unto you in Egypt, saying, 'Let us alone, that we may serve the Egyptians'? For it would have been better for us to serve the Egyptians than to die in the wilderness."

**14:13** And Moses said unto the people: "Fear not! Stand still and see the salvation of YHWH—יְשׁוּעַת יהוה (yeshu'at YHWH)—which he will work for you today; for the Egyptians whom you have seen today, you shall see them again no more forever.

**14:14** "YHWH shall fight for you, and you shall hold your peace—תַּחֲרִשׁוּן (tacharishun)."

**14:15** And YHWH said unto Moses: "Why do you cry unto me? Speak unto the children of Israel, that they go forward—וְיִסָּעוּ (ve-yissa'u).

**14:16** "And you, lift up your staff and stretch out your hand over the sea and divide it; and the children of Israel shall go through the midst of the sea on dry ground.

**14:17** "And I, behold, I will harden the hearts of the Egyptians, and they shall go in after them; and I will be glorified in Pharaoh and in all his host, in his chariots and in his horsemen.

**14:18** "And the Egyptians shall know that I am YHWH, when I am glorified in Pharaoh, in his chariots and in his horsemen."

**14:19** And the messenger of Consciousness, who went before the camp of Israel, moved and went behind them; and the pillar of cloud moved from before them and stood behind them.

**14:20** And it came between the camp of Egypt and the camp of Israel; and there was the cloud and the darkness, yet it gave light by night; and the one did not come near the other all the night.

**14:21** And Moses stretched out his hand over the sea; and YHWH caused the sea to go back by a strong east wind—רוּחַ קָדִים עַזָּה (ruach qadim azzah)—all that night, and made the sea into dry land, and the waters were divided.

**14:22** And the children of Israel went into the midst of the sea on the dry ground; and the waters were a wall unto them on their right hand and on their left.

**14:23** And the Egyptians pursued and went in after them—all Pharaoh's horses, his chariots and his horsemen—into the midst of the sea.

**14:24** And it came to pass in the morning watch—בְּאַשְׁמֹרֶת הַבֹּקֶר (be-ashmoret ha-boqer)—that YHWH looked down upon the camp of the Egyptians through the pillar of fire and of cloud, and threw the camp of the Egyptians into confusion—וַיָּהָם (va-yaham).

**14:25** And he took off their chariot wheels, and they drove them with difficulty; and the Egyptians said, "Let us flee from the face of Israel; for YHWH fights for them against Egypt!"

**14:26** And YHWH said unto Moses: "Stretch out your hand over the sea, that the waters may come back upon the Egyptians, upon their chariots and upon their horsemen."

**14:27** And Moses stretched out his hand over the sea, and the sea returned to its strength—לְאֵיתָנוֹ (le-eitano)—when the morning appeared; and the Egyptians fled into it; and YHWH shook off—וַיְנַעֵר (va-yena'er)—the Egyptians in the midst of the sea.

**14:28** And the waters returned and covered the chariots and the horsemen, all the host of Pharaoh that went in after them into the sea; there remained not so much as one of them.

**14:29** But the children of Israel walked on dry ground through the midst of the sea; and the waters were a wall unto them on their right hand and on their left.

**14:30** Thus YHWH saved Israel that day from the hand of Egypt; and Israel saw Egypt dead upon the seashore.

**14:31** And Israel saw the great hand—הַיָּד הַגְּדֹלָה (ha-yad ha-gedolah)—which YHWH had done upon Egypt; and the people feared YHWH and believed—וַיַּאֲמִינוּ (va-ya'aminu)—in YHWH and in Moses his servant.

---

## Synthesis Notes

**Key Restorations:**

**The Trap:**
YHWH commands Israel to turn back and encamp by the sea—an apparent dead end. Pharaoh sees this and concludes: "They are entangled; the wilderness has shut them in." The trap is set—but for Pharaoh, not Israel.

**Pharaoh's Regret:**
"What have we done, letting Israel go?" Even after the death of the firstborn, Pharaoh recovers his appetite for control. The system cannot imagine functioning without the slaves.

**Six Hundred Chosen Chariots:**
Egypt's military pride—chariots were the ancient equivalent of tanks. Pharaoh mobilizes his elite force. The gods of Egypt have failed; now Egyptian technology will pursue.

**"With a High Hand" (בְּיָד רָמָה):**
Israel left boldly, defiantly—hand raised. But now, seeing the Egyptian army, their boldness collapses into terror.

**The People's Complaint:**
"Were there no graves in Egypt?" The first of many wilderness complaints. They prefer slavery with security to freedom with danger. This is the psychology of the long-oppressed: liberation is terrifying.

**"Stand Still and See":**
Moses' response is faith under pressure: don't fight, don't flee—stand and watch. "YHWH shall fight for you." The Hebrew *tacharishun* (תַּחֲרִשׁוּן) means "be silent"—don't speak, don't panic.

**"Why Do You Cry to Me? Go Forward!":**
YHWH's response to Moses' (implied) prayer is surprising: stop praying and start moving. There is a time for petition and a time for action. The sea will part when they step toward it.

**The Pillar Moves:**
The pillar of cloud, which led from the front, now moves to the rear—between Israel and Egypt. It provides darkness to Egypt, light to Israel. The same phenomenon is experienced differently depending on where you stand.

**The East Wind:**
*Ruach qadim azzah* (רוּחַ קָדִים עַזָּה)—a strong east wind all night. The sea doesn't instantly split; it is driven back by wind working through the night. Divine action works through natural means prolonged supernaturally.

**Waters as Walls:**
The waters stand as walls on right and left—not a gradual wading through shallows but a passage between vertical walls of water. This is beyond natural; this is the sea obeying command.

**The Morning Watch:**
*Ashmoret ha-boqer* (אַשְׁמֹרֶת הַבֹּקֶר)—the last watch before dawn, the darkest hour. YHWH "looks down" through the pillar—the gaze itself brings confusion. The Egyptians' chariot wheels fail; they cannot advance or retreat.

**"YHWH Fights for Them":**
The Egyptians finally understand: this is not nature, not coincidence—YHWH is fighting for Israel. Their realization comes too late.

**"YHWH Shook Off" (וַיְנַעֵר):**
The verb *na'ar* means to shake off, like shaking off insects or dust. The Egyptians are shaken off into the sea—dismissed, discarded. The mighty army becomes debris.

**The Reckoning:**
"There remained not so much as one of them." Complete destruction. The army that pursued is annihilated. Israel stands on the far shore; Egypt lies dead on the near shore.

**The Great Hand:**
"Israel saw the great hand (*ha-yad ha-gedolah*) which YHWH had done." The metaphor is consistent: YHWH's hand brought them out; YHWH's hand defeated Egypt; YHWH's hand saves.

**"They Believed":**
*Va-ya'aminu* (וַיַּאֲמִינוּ)—from the root אמן (*amen*), signifying trust, firmness, faithfulness. They believed in YHWH and in Moses his servant. The liberation is complete; faith is born.

**Archetypal Layer:** The sea crossing is the supreme symbol of **death and rebirth**:
- The old life (Egypt) is definitively ended
- Passage through water is passage through death
- The new life begins on the far shore
- Pharaoh's army is the pursuing past that must be drowned

**Water = collective unconscious, renewal** (from the symbol map). Israel passes through the waters of chaos and emerges reborn. This is baptism archetype—death by water, life beyond.

**Psychological Reading:** The complaint before the sea is the soul's terror at the threshold. Old bondage seems preferable to unknown freedom. "Let us alone to serve" is the voice of the part that fears change. But the way forward is through, not back. The waters part when you move.

**Ethical Inversion Applied:**
- YHWH is glorified through Pharaoh's destruction—glory through judgment
- The trap is for the trapper: Pharaoh pursues into his own doom
- The same pillar is light to Israel, darkness to Egypt—presence experienced as opposite depending on relation
- Violence is not glorified but recognized: Israel does not fight; YHWH fights

**Modern Equivalent:** Every genuine liberation involves a sea—a point of no return where the old system pursues and the new life seems impossible. "Go forward" is the command when retreat is tempting. The pursuing power may be formidable, but systems that depend on oppression eventually drown in their own pursuit. And the morning reveals them dead on the shore.

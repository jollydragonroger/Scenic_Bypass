# Exodus Chapter 38: The Altar, Basin, and Courtyard

*From the Hebrew: The Outer Construction*

---

**38:1** And he made the altar of burnt offering of acacia wood; five cubits was its length, and five cubits its breadth—square—and three cubits its height.

**38:2** And he made its horns on its four corners; its horns were of one piece with it; and he overlaid it with bronze.

**38:3** And he made all the vessels of the altar: the pots and the shovels and the basins and the forks and the firepans; all its vessels he made of bronze.

**38:4** And he made for the altar a grating of network of bronze, under its ledge beneath, reaching halfway up.

**38:5** And he cast four rings at the four ends of the grating of bronze, as holders for the poles.

**38:6** And he made the poles of acacia wood, and overlaid them with bronze.

**38:7** And he put the poles into the rings on the sides of the altar, with which to carry it; hollow with boards he made it.

**38:8** And he made the basin of bronze, and its stand of bronze, from the mirrors of the serving women—בְּמַרְאֹת הַצֹּבְאֹת (be-mar'ot ha-tsove'ot)—who served at the door of the tent of meeting.

---

**38:9** And he made the court. For the south side the hangings of the court were of fine twisted linen, a hundred cubits;

**38:10** Their pillars were twenty, and their sockets twenty, of bronze; the hooks of the pillars and their bands were of silver.

**38:11** And for the north side, a hundred cubits; their pillars were twenty, and their sockets twenty, of bronze; the hooks of the pillars and their bands were of silver.

**38:12** And for the west side, hangings of fifty cubits; their pillars were ten, and their sockets ten; the hooks of the pillars and their bands were of silver.

**38:13** And for the east side, fifty cubits.

**38:14** The hangings for one side of the gate were fifteen cubits; their pillars were three, and their sockets three.

**38:15** And so for the other side. On this side and on that side of the gate of the court were hangings of fifteen cubits; their pillars were three, and their sockets three.

**38:16** All the hangings of the court round about were of fine twisted linen.

**38:17** And the sockets for the pillars were of bronze; the hooks of the pillars and their bands were of silver; and the overlaying of their capitals was of silver; and all the pillars of the court were banded with silver.

**38:18** And the screen of the gate of the court was the work of the embroiderer, of blue and purple and scarlet yarn and fine twisted linen; and twenty cubits was the length, and the height in the breadth was five cubits, corresponding to the hangings of the court.

**38:19** And their pillars were four, and their sockets four, of bronze; their hooks were of silver, and the overlaying of their capitals and their bands were of silver.

**38:20** And all the pegs of the tabernacle and of the court round about were of bronze.

---

**38:21** These are the accounts of the tabernacle—פְקוּדֵי הַמִּשְׁכָּן (pequdei ha-mishkan)—the tabernacle of the testimony, as they were counted at the commandment of Moses, for the service of the Levites, by the hand of Ithamar the son of Aaron the priest.

**38:22** And Bezalel the son of Uri, the son of Hur, of the tribe of Judah, made all that YHWH commanded Moses.

**38:23** And with him was Oholiab the son of Ahisamach, of the tribe of Dan, an engraver and a skillful workman and an embroiderer in blue and in purple and in scarlet yarn and in fine linen.

**38:24** All the gold that was used for the work, in all the work of the sanctuary—the gold of the wave offering—was twenty-nine talents and seven hundred and thirty shekels, according to the shekel of the sanctuary.

**38:25** And the silver of those who were numbered of the congregation was a hundred talents and a thousand seven hundred and seventy-five shekels, according to the shekel of the sanctuary:

**38:26** A beka a head—בֶּקַע לַגֻּלְגֹּלֶת (beqa la-gulgolet)—half a shekel, according to the shekel of the sanctuary, for everyone who passed over to those who were numbered, from twenty years old and upward, for six hundred and three thousand five hundred and fifty men.

**38:27** And the hundred talents of silver were for casting the sockets of the sanctuary and the sockets of the veil: a hundred sockets for the hundred talents, a talent for a socket.

**38:28** And of the thousand seven hundred and seventy-five shekels he made hooks for the pillars, and overlaid their capitals and banded them.

**38:29** And the bronze of the wave offering was seventy talents and two thousand four hundred shekels.

**38:30** And with it he made the sockets for the door of the tent of meeting, and the bronze altar, and the bronze grating for it, and all the vessels of the altar,

**38:31** And the sockets of the court round about, and the sockets of the gate of the court, and all the pegs of the tabernacle, and all the pegs of the court round about.

---

## Synthesis Notes

**Key Restorations:**

**The Bronze Altar:**
The altar of burnt offering—the largest piece of furniture:
- 5 × 5 × 3 cubits (approximately 7.5 × 7.5 × 4.5 feet)
- Bronze-overlaid acacia wood
- Horns at four corners
- Grating halfway up
- Hollow, portable with poles

This is the altar of sacrifice, placed in the courtyard, visible to all who enter.

**The Bronze Basin:**

A remarkable note: the basin was made "from the mirrors of the serving women" (*be-mar'ot ha-tsove'ot*).

*Mar'ot* (מַרְאֹת) = mirrors (polished bronze)
*Ha-tsove'ot* (הַצֹּבְאֹת) = the women who served/assembled

Who are these women? The text is unclear. They "served at the door of the tent of meeting"—some form of religious service. Their mirrors—instruments of personal vanity—are transformed into the basin for priestly purification.

This is remarkable: women contribute their personal possessions for sacred use, and their presence at the sanctuary door is noted. Their service is honored in the text.

**The Courtyard:**
- 100 × 50 cubits
- Fine linen hangings
- 60 pillars total
- Bronze sockets, silver hooks and bands
- 20-cubit gate on the east (embroidered screen)

**The Accounting (38:21-31):**

The chapter concludes with an inventory—a financial accounting of materials:

**Gold**: 29 talents + 730 shekels
- Used for the holiest furnishings

**Silver**: 100 talents + 1,775 shekels
- From the census (half-shekel per person)
- 603,550 men counted
- Used for sockets (100 talents = 100 sockets) and pillar fittings

**Bronze**: 70 talents + 2,400 shekels
- For altar, sockets, pegs, grating

**"A Beka a Head" (בֶּקַע לַגֻּלְגֹּלֶת):**
*Beqa* = half (of a shekel)
*Gulgolet* = skull (head count)

The census tax from chapter 30 is now accounted. Each adult male contributed equally; the total reveals the population.

**603,550 Men:**
This census number appears again in Numbers 1:46. It implies a total population of 2-3 million. Historically debated, but the text presents it as precise accounting.

**Ithamar's Role:**
Aaron's son Ithamar oversees the Levitical service and accounting. The priestly family is already functioning in administrative capacity.

**Archetypal Layer:** The bronze altar is the place of **transformation through sacrifice**—the fire that consumes offerings. The basin represents **purification**—the priests wash before approaching. The accounting demonstrates **transparency**—every contribution tracked, nothing misappropriated.

The women's mirrors becoming the basin is powerful: vanity transformed into purification; personal adornment becoming sacred instrument.

**Psychological Reading:** The inventory is not mere bureaucracy but accountability. The community's offerings are accounted for—trust is maintained through transparency. The transformation of mirrors into basin suggests that what once served the ego can be refashioned for sacred purpose.

**Ethical Inversion Applied:**
- Women's contributions are specifically honored
- Their "service" at the sanctuary door is acknowledged
- Transparency in accounting protects against corruption
- Every contribution—gold, silver, bronze—has its place
- The census reveals equal participation (half-shekel each)

**Modern Equivalent:** Financial transparency builds trust. Sacred projects require accounting. And the transformation of personal vanity items (mirrors) into instruments of purification (basin) models how what once served ego can be repurposed for higher use.

# Exodus Chapter 16: Manna and Quail

*From the Hebrew: Bread from Heaven*

---

**16:1** And they journeyed from Elim, and all the congregation of the children of Israel came unto the wilderness of Sin—מִדְבַּר־סִין (midbar-Sin)—which is between Elim and Sinai, on the fifteenth day of the second month after their departing out of the land of Egypt.

**16:2** And the whole congregation of the children of Israel murmured—וַיִּלּוֹנוּ (va-yillonu)—against Moses and against Aaron in the wilderness.

**16:3** And the children of Israel said unto them: "Would that we had died by the hand of YHWH in the land of Egypt, when we sat by the fleshpots—סִיר הַבָּשָׂר (sir ha-basar)—when we ate bread to the full! For you have brought us out into this wilderness to kill this whole assembly with hunger."

**16:4** And YHWH said unto Moses: "Behold, I will rain bread from heaven for you—הִנְנִי מַמְטִיר לָכֶם לֶחֶם מִן־הַשָּׁמָיִם (hineni mamtir lachem lechem min-ha-shamayim); and the people shall go out and gather a day's portion every day, that I may test them—לְמַעַן אֲנַסֶּנּוּ (le-ma'an anassenu)—whether they will walk in my law or not.

**16:5** "And it shall come to pass on the sixth day, that they shall prepare what they bring in, and it shall be double what they gather daily."

**16:6** And Moses and Aaron said unto all the children of Israel: "At evening you shall know that YHWH has brought you out from the land of Egypt;

**16:7** "And in the morning you shall see the glory of YHWH—כְּבוֹד יהוה (kevod YHWH); for he has heard your murmurings against YHWH; and what are we, that you murmur against us?"

**16:8** And Moses said: "When YHWH gives you in the evening flesh to eat, and in the morning bread to the full; for YHWH hears your murmurings which you murmur against him; and what are we? Your murmurings are not against us, but against YHWH."

**16:9** And Moses said unto Aaron: "Say unto all the congregation of the children of Israel, 'Come near before YHWH; for he has heard your murmurings.'"

**16:10** And it came to pass, as Aaron spoke unto the whole congregation of the children of Israel, that they looked toward the wilderness, and behold, the glory of YHWH appeared in the cloud.

**16:11** And YHWH spoke unto Moses, saying:

**16:12** "I have heard the murmurings of the children of Israel. Speak unto them, saying, 'Between the evenings you shall eat flesh, and in the morning you shall be filled with bread; and you shall know that I am YHWH your Consciousness.'"

**16:13** And it came to pass at evening that the quail—שְׂלָו (selav)—came up and covered the camp; and in the morning there was a layer of dew around the camp.

**16:14** And when the layer of dew lifted, behold, upon the face of the wilderness lay a fine, flaky thing—דַּק מְחֻסְפָּס (daq mechuspas)—fine as frost on the ground.

**16:15** And when the children of Israel saw it, they said to one another, "What is it?"—מָן הוּא (man hu)—for they did not know what it was. And Moses said unto them: "This is the bread which YHWH has given you to eat.

**16:16** "This is the thing which YHWH has commanded: 'Gather of it each man according to his eating, an omer—עֹמֶר (omer)—per head, according to the number of your persons; each man for those who are in his tent shall you take.'"

**16:17** And the children of Israel did so, and gathered, some more, some less.

**16:18** And when they measured it with an omer, the one who gathered much had nothing over, and the one who gathered little had no lack; each man gathered according to his eating.

**16:19** And Moses said unto them: "Let no man leave of it until the morning."

**16:20** But they did not listen unto Moses; and some left of it until the morning, and it bred worms and stank; and Moses was angry with them.

**16:21** And they gathered it morning by morning, each man according to his eating; and when the sun grew hot, it melted.

**16:22** And it came to pass on the sixth day that they gathered double bread, two omers for each one; and all the leaders of the congregation came and told Moses.

**16:23** And he said unto them: "This is what YHWH has spoken: Tomorrow is a solemn rest, a holy sabbath—שַׁבָּתוֹן שַׁבַּת־קֹדֶשׁ (shabbaton shabbat-qodesh)—unto YHWH. Bake what you will bake, and boil what you will boil; and all that remains over lay up for yourselves to be kept until the morning."

**16:24** And they laid it up until the morning, as Moses commanded; and it did not stink, neither was there any worm in it.

**16:25** And Moses said: "Eat that today; for today is a sabbath unto YHWH; today you shall not find it in the field.

**16:26** "Six days you shall gather it; but on the seventh day is the sabbath, in it there shall be none."

**16:27** And it came to pass on the seventh day that some of the people went out to gather, and they found none.

**16:28** And YHWH said unto Moses: "How long do you refuse to keep my commandments and my laws?

**16:29** "See that YHWH has given you the sabbath; therefore he gives you on the sixth day bread for two days. Let each man remain in his place; let no man go out of his place on the seventh day."

**16:30** So the people rested on the seventh day.

**16:31** And the house of Israel called its name manna—מָן (man); and it was like coriander seed, white, and its taste was like wafers made with honey.

**16:32** And Moses said: "This is the thing which YHWH has commanded: 'Fill an omer of it to be kept for your generations, that they may see the bread with which I fed you in the wilderness, when I brought you out from the land of Egypt.'"

**16:33** And Moses said unto Aaron: "Take a jar, and put an omer full of manna in it, and lay it up before YHWH, to be kept for your generations."

**16:34** As YHWH commanded Moses, so Aaron laid it up before the Testimony, to be kept.

**16:35** And the children of Israel ate the manna forty years, until they came to a land inhabited; they ate the manna until they came unto the border of the land of Canaan.

**16:36** Now an omer is the tenth part of an ephah.

---

## Synthesis Notes

**Key Restorations:**

**The Wilderness of Sin:**
Not related to English "sin"—*Sin* (סִין) is a place name, possibly connected to the moon god Sin (Sumerian/Akkadian). The journey moves toward Sinai.

**The Murmuring Pattern:**
*Va-yillonu* (וַיִּלּוֹנוּ)—"they murmured." This verb becomes the defining action of the wilderness generation. Complaint after complaint, despite repeated provision.

**"The Fleshpots of Egypt":**
The nostalgia is selective—they remember meat and bread, not slavery and infanticide. Memory distorts: Egypt becomes paradise in retrospect. This is the psychology of those who resist change.

**"Bread from Heaven":**
*Lechem min-ha-shamayim* (לֶחֶם מִן־הַשָּׁמָיִם)—the phrase that will echo through Scripture into John 6. The provision is supernatural—bread that descends, not bread that is grown.

**The Test:**
The manna is testing: "That I may test them, whether they will walk in my law or not." Daily dependence, daily gathering, no hoarding—the provision teaches trust.

**"What Is It?" (מָן הוּא):**
The name "manna" comes from the question *man hu*—"what is it?" The substance is named by its mystery. They don't know what it is, but they eat it.

**The Omer Miracle:**
Those who gathered much had nothing over; those who gathered little had no lack. The manna redistributes itself to need. Paul quotes this (2 Corinthians 8:15) regarding economic sharing. The provision is inherently egalitarian.

**No Hoarding:**
What is kept overnight breeds worms and stinks—except on the sabbath. The provision teaches: take what you need for today. Anxiety about tomorrow is unnecessary. Trust daily.

**The Sabbath Introduced:**
Before Sinai, before the Ten Commandments, the sabbath is introduced through manna practice. Double portion on the sixth day; no gathering on the seventh. The sabbath is built into the rhythm of provision.

**"How Long Do You Refuse?":**
YHWH's exasperation: some still went out on the seventh day to gather. They found none. The lesson must be learned repeatedly.

**The Description:**
"Like coriander seed, white... like wafers made with honey." Manna is described by analogy—small, round, white, sweet. Numbers 11:7-8 adds that it looked like bdellium and tasted like cakes baked with oil.

**The Jar for Testimony:**
An omer of manna is preserved "before YHWH... before the Testimony"—this will be placed in the Ark of the Covenant. The provision is memorialized for future generations. They will see what sustained the ancestors.

**Forty Years:**
"They ate manna forty years"—the entire wilderness period. The provision never fails. Only when they enter Canaan and eat the land's produce does the manna cease (Joshua 5:12).

**Archetypal Layer:** Manna is **bread from heaven**—sustenance that descends, that cannot be hoarded, that equalizes, that teaches dependence. It is the symbol of divine provision that meets need but prevents accumulation. The wilderness becomes school, and manna is the curriculum.

**Psychological Reading:** The recently liberated cannot yet trust that provision will continue. They try to hoard; it rots. They go out on sabbath; they find nothing. Learning trust requires daily practice—gathering enough, no more, and resting when told to rest. The ego resists this discipline.

**Ethical Inversion Applied:**
- The murmuring is against YHWH, not Moses—complaints about provision are theological
- The provision equalizes: more gathered = no excess; less gathered = no lack
- Hoarding produces rot—the system punishes accumulation
- Sabbath is built into nature's rhythm before it is commanded as law
- Memory is preserved (the jar) so future generations know what sustained ancestors

**Modern Equivalent:** Economies built on hoarding and accumulation contradict the manna principle. Provision that cannot be stored teaches trust; provision that equalizes challenges inequality. "Gathering according to eating" is enough—not more. And the sabbath is not arbitrary rule but cosmic rhythm: even provision rests.

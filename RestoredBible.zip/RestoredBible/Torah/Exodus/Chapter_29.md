# Exodus Chapter 29: The Ordination of the Priests

*From the Hebrew: מִלֻּאִים (Millu'im) — Filling/Ordination*

---

**29:1** "And this is the thing that you shall do unto them to sanctify them, to minister unto me as priests: take one young bull and two rams without blemish,

**29:2** "And unleavened bread, and unleavened cakes mixed with oil, and unleavened wafers anointed with oil; of fine wheat flour you shall make them.

**29:3** "And you shall put them into one basket, and bring them in the basket, with the bull and the two rams.

**29:4** "And Aaron and his sons you shall bring unto the door of the tent of meeting, and shall wash them with water.

**29:5** "And you shall take the garments, and put upon Aaron the tunic and the robe of the ephod and the ephod and the breastpiece, and gird him with the skillfully woven band of the ephod.

**29:6** "And you shall set the turban upon his head, and put the holy crown upon the turban.

**29:7** "Then you shall take the anointing oil and pour it upon his head, and anoint him.

**29:8** "And you shall bring his sons, and put tunics upon them.

**29:9** "And you shall gird them with sashes, Aaron and his sons, and bind headbands on them; and the priesthood shall be theirs by a perpetual statute; and you shall ordain Aaron and his sons—וּמִלֵּאתָ יַד־אַהֲרֹן וְיַד־בָּנָיו (u-mille'ta yad-Aharon ve-yad-banav).

---

**29:10** "And you shall bring the bull before the tent of meeting; and Aaron and his sons shall lay their hands upon the head of the bull.

**29:11** "And you shall slaughter the bull before YHWH, at the door of the tent of meeting.

**29:12** "And you shall take of the blood of the bull, and put it upon the horns of the altar with your finger, and pour out all the blood at the base of the altar.

**29:13** "And you shall take all the fat that covers the entrails, and the lobe of the liver, and the two kidneys, and the fat that is upon them, and burn them upon the altar.

**29:14** "But the flesh of the bull, and its skin, and its dung, you shall burn with fire outside the camp; it is a sin offering—חַטָּאת (chattat).

**29:15** "And you shall take one ram; and Aaron and his sons shall lay their hands upon the head of the ram.

**29:16** "And you shall slaughter the ram, and shall take its blood and throw it against the altar all around.

**29:17** "And you shall cut the ram into its pieces, and wash its entrails and its legs, and put them with its pieces and with its head.

**29:18** "And you shall burn the whole ram upon the altar; it is a burnt offering—עֹלָה (olah)—unto YHWH; it is a pleasing aroma—רֵיחַ נִיחוֹחַ (reiach nichoach)—a fire offering unto YHWH.

**29:19** "And you shall take the other ram; and Aaron and his sons shall lay their hands upon the head of the ram.

**29:20** "Then you shall slaughter the ram, and take of its blood, and put it upon the tip of the right ear of Aaron—תְּנוּךְ אֹזֶן אַהֲרֹן (tenuch ozen Aharon)—and upon the tip of the right ear of his sons, and upon the thumb of their right hand, and upon the great toe of their right foot, and throw the blood against the altar all around.

**29:21** "And you shall take of the blood that is upon the altar, and of the anointing oil, and sprinkle it upon Aaron and upon his garments, and upon his sons and upon his sons' garments with him; and he shall be hallowed, and his garments, and his sons and his sons' garments with him.

**29:22** "And you shall take of the ram the fat, and the fat tail, and the fat that covers the entrails, and the lobe of the liver, and the two kidneys, and the fat that is upon them, and the right thigh; for it is a ram of ordination—אֵיל מִלֻּאִים (eil millu'im).

**29:23** "And one loaf of bread, and one cake of oiled bread, and one wafer, out of the basket of unleavened bread that is before YHWH.

**29:24** "And you shall put all these in the hands of Aaron and in the hands of his sons, and wave them as a wave offering before YHWH.

**29:25** "And you shall take them from their hands, and burn them upon the altar for a burnt offering, for a pleasing aroma before YHWH; it is a fire offering unto YHWH.

**29:26** "And you shall take the breast of the ram of ordination that is Aaron's, and wave it as a wave offering before YHWH; and it shall be your portion.

**29:27** "And you shall sanctify the breast of the wave offering, and the thigh of the contribution, which was waved and which was contributed, of the ram of ordination, of that which is Aaron's and of that which is his sons'.

**29:28** "And it shall be for Aaron and his sons as a portion forever from the children of Israel; for it is a contribution; and it shall be a contribution from the children of Israel from their peace offerings, their contribution unto YHWH.

**29:29** "And the holy garments of Aaron shall be for his sons after him, to be anointed in them and to be ordained in them.

**29:30** "Seven days shall the son who is priest in his place wear them, who comes into the tent of meeting to minister in the holy place.

---

**29:31** "And you shall take the ram of ordination and boil its flesh in a holy place.

**29:32** "And Aaron and his sons shall eat the flesh of the ram, and the bread that is in the basket, at the door of the tent of meeting.

**29:33** "And they shall eat those things with which atonement was made—כִּפֶּר (kipper)—to ordain them and to sanctify them; but a stranger shall not eat of them, for they are holy.

**29:34** "And if any of the flesh of the ordination, or of the bread, remain until the morning, then you shall burn the remainder with fire; it shall not be eaten, for it is holy.

**29:35** "And thus shall you do unto Aaron and unto his sons, according to all that I have commanded you; seven days you shall ordain them.

**29:36** "And you shall offer a bull daily as a sin offering for atonement; and you shall cleanse the altar when you make atonement for it; and you shall anoint it to sanctify it.

**29:37** "Seven days you shall make atonement for the altar and sanctify it; and the altar shall be most holy. Whatever touches the altar shall be holy.

---

**29:38** "Now this is what you shall offer upon the altar: two lambs a year old, day by day continually—תָּמִיד (tamid).

**29:39** "The one lamb you shall offer in the morning, and the other lamb you shall offer between the evenings.

**29:40** "And with the one lamb a tenth measure of fine flour mixed with a fourth of a hin of pressed oil, and a fourth of a hin of wine for a drink offering.

**29:41** "And the other lamb you shall offer between the evenings; with the same grain offering and drink offering as in the morning you shall offer with it, for a pleasing aroma, a fire offering unto YHWH.

**29:42** "It shall be a continual burnt offering throughout your generations at the door of the tent of meeting before YHWH, where I will meet with you—אִוָּעֵד לָכֶם (ivva'ed lachem)—to speak to you there.

**29:43** "And there I will meet with the children of Israel, and it shall be sanctified by my glory.

**29:44** "And I will sanctify the tent of meeting and the altar; and Aaron and his sons I will sanctify to minister to me as priests.

**29:45** "And I will dwell among the children of Israel—וְשָׁכַנְתִּי בְּתוֹךְ בְּנֵי יִשְׂרָאֵל (ve-shachanti be-toch benei Yisra'el)—and will be their Consciousness.

**29:46** "And they shall know that I am YHWH their Consciousness, who brought them out of the land of Egypt, that I may dwell among them; I am YHWH their Consciousness."

---

## Synthesis Notes

**Key Restorations:**

**The Seven-Day Ordination:**
Priestly ordination is not instantaneous but processional. Seven days of ritual—the complete cycle of creation—transforms Aaron and his sons from ordinary Israelites to priests.

**The Three Offerings:**

1. **The bull** — sin offering (*chattat*): purifies from sin
2. **First ram** — burnt offering (*olah*): complete dedication
3. **Second ram** — ordination offering (*eil millu'im*): consecration for service

Each has distinct purpose; together they complete ordination.

**Laying Hands on the Head:**
*Semichah* (סְמִיכָה)—the hands-on gesture transfers identity. The animal represents the one offering it. The life given is symbolically the offerer's life.

**Blood on Ear, Thumb, Toe:**
The blood of the ordination ram is applied to:
- Right ear (*tenuch ozen*): hearing consecrated
- Right thumb: action consecrated
- Right great toe: walk consecrated

The whole person—perception, work, and way of life—is marked for sacred service.

**Blood and Oil Sprinkled:**
Aaron and his sons are sprinkled with blood and anointing oil together. The mixture consecrates both persons and garments. They are made holy.

**"Fill Their Hands":**
*Mille'ta yad* (מִלֵּאתָ יַד)—the portions of the offering are placed in the priests' hands and waved before YHWH. This "filling of hands" is ordination itself. They receive authority to handle sacred things.

**The Wave Offering:**
*Tenufah* (תְּנוּפָה)—moving the offering before YHWH, perhaps in a wave-like motion. This dedicates it to YHWH before it is burned or eaten.

**Eating the Sacred:**
Aaron and his sons eat the ordination ram and bread "at the door of the tent of meeting." The sacred meal is part of ordination. They consume what was offered—communion with YHWH through shared food.

**"A Stranger Shall Not Eat":**
These portions are for priests only. The holiness is not transferable to the unauthorized. Sacred eating requires sacred status.

**The Daily Offering (תָּמִיד, tamid):**

The perpetual offering:
- Two lambs daily (morning and evening)
- Grain and oil with each
- Wine libation with each
- Every day, without exception

This is the heartbeat of the tabernacle—constant worship, never ceasing. The *tamid* represents ongoing relationship, not occasional attention.

**"I Will Meet With You":**
*Ivva'ed lachem* (אִוָּעֵד לָכֶם)—the root of "meeting" in "tent of meeting." The purpose of all this—sanctuary, priesthood, offerings—is meeting. YHWH desires encounter.

**"I Will Dwell Among the Children of Israel":**
*Ve-shachanti be-toch benei Yisra'el*—the Shekinah dwelling among them. This is the climax: not a distant God but a present one. The exodus was not just from Egypt but toward presence.

**"That I May Dwell Among Them":**
The liberation from Egypt finds its purpose here. Why the exodus? So YHWH could dwell with Israel. Freedom is not an end but a means—freedom for relationship.

**Archetypal Layer:** Ordination transforms ordinary persons into sacred mediators. The blood marks the body; the garments cover it; the filling of hands empowers it. The seven days recapitulate creation—new beings emerge, priests who did not exist before.

The daily offering (*tamid*) represents **constancy**—the altar never cold, the worship never ceasing. Divine presence requires sustained attention.

**Psychological Reading:** The ordination ritual transforms identity. Aaron enters as tribal leader; he emerges as high priest. The external rituals effect internal change. The blood on ear, thumb, and toe consecrates the whole person—how one hears, what one does, where one walks.

**Ethical Inversion Applied:**
- Ordination requires seven days—transformation takes time
- The sin offering purifies what will become sacred—holiness requires cleansing
- The priests eat the sacred food—worship includes communion
- The daily offering never ceases—relationship is maintained, not achieved
- "That I may dwell among them"—the exodus was for presence, not just freedom

**Modern Equivalent:** Leadership in sacred service requires preparation—not instant appointment. The whole person is consecrated (ear, hand, foot). And the "daily offering" principle applies: relationship requires consistent attention, not sporadic effort. The purpose of liberation is communion—freedom for, not just freedom from.

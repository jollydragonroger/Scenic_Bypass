# Exodus Chapter 20: The Ten Words

*From the Hebrew: עֲשֶׂרֶת הַדְּבָרִים (Aseret HaDevarim) — The Decalogue*

---

**20:1** And Consciousness spoke all these words, saying:

**20:2** "I am YHWH your Consciousness—אָנֹכִי יהוה אֱלֹהֶיךָ (anochi YHWH Elohecha)—who brought you out of the land of Egypt, out of the house of bondage.

**20:3** "You shall have no other gods before me—לֹא יִהְיֶה־לְךָ אֱלֹהִים אֲחֵרִים עַל־פָּנָי (lo yihyeh-lecha elohim acherim al-panai).

**20:4** "You shall not make for yourself a carved image—פֶּסֶל (pesel)—or any likeness of what is in heaven above, or on the earth beneath, or in the water under the earth.

**20:5** "You shall not bow down to them nor serve them; for I, YHWH your Consciousness, am a jealous God—אֵל קַנָּא (El qanna)—visiting the iniquity of the fathers upon the children unto the third and fourth generation of those who hate me,

**20:6** "But showing loving-kindness—חֶסֶד (chesed)—unto thousands of those who love me and keep my commandments.

**20:7** "You shall not take the name of YHWH your Consciousness in vain—לַשָּׁוְא (la-shav); for YHWH will not hold guiltless the one who takes his name in vain.

**20:8** "Remember the sabbath day, to keep it holy—זָכוֹר אֶת־יוֹם הַשַּׁבָּת לְקַדְּשׁוֹ (zachor et-yom ha-shabbat le-qadesho).

**20:9** "Six days you shall labor and do all your work;

**20:10** "But the seventh day is a sabbath unto YHWH your Consciousness; you shall not do any work—you, nor your son, nor your daughter, nor your male servant, nor your female servant, nor your beast, nor your stranger who is within your gates.

**20:11** "For in six days YHWH made the heavens and the earth, the sea and all that is in them, and rested on the seventh day; therefore YHWH blessed the sabbath day and made it holy.

**20:12** "Honor your father and your mother—כַּבֵּד אֶת־אָבִיךָ וְאֶת־אִמֶּךָ (kabbed et-avicha ve-et-immecha)—that your days may be long upon the land which YHWH your Consciousness gives you.

**20:13** "You shall not murder—לֹא תִּרְצָח (lo tirtsach).

**20:14** "You shall not commit adultery—לֹא תִּנְאָף (lo tin'af).

**20:15** "You shall not steal—לֹא תִּגְנֹב (lo tignov).

**20:16** "You shall not bear false witness against your neighbor—לֹא־תַעֲנֶה בְרֵעֲךָ עֵד שָׁקֶר (lo-ta'aneh ve-re'acha ed shaqer).

**20:17** "You shall not covet—לֹא תַחְמֹד (lo tachmod)—your neighbor's house; you shall not covet your neighbor's wife, nor his male servant, nor his female servant, nor his ox, nor his donkey, nor anything that is your neighbor's."

---

**20:18** And all the people saw the thunderings and the lightnings, and the voice of the shofar, and the mountain smoking; and when the people saw it, they trembled and stood at a distance.

**20:19** And they said unto Moses: "You speak with us, and we will hear; but let not Consciousness speak with us, lest we die."

**20:20** And Moses said unto the people: "Fear not; for Consciousness has come to test you—לְבַעֲבוּר נַסּוֹת אֶתְכֶם (le-va'avur nassot etchem)—and that the fear of him may be before your faces, that you may not sin."

**20:21** And the people stood at a distance, while Moses drew near unto the thick darkness—הָעֲרָפֶל (ha-arafel)—where Consciousness was.

---

**20:22** And YHWH said unto Moses: "Thus shall you say unto the children of Israel: 'You have seen that I have spoken with you from heaven.

**20:23** "'You shall not make with me gods of silver, nor shall you make for yourselves gods of gold.

**20:24** "'An altar of earth you shall make unto me, and shall sacrifice upon it your burnt offerings and your peace offerings, your sheep and your oxen; in every place where I cause my name to be remembered I will come unto you and bless you.

**20:25** "'And if you make me an altar of stone, you shall not build it of hewn stones; for if you lift up your tool upon it, you have profaned it.

**20:26** "'Neither shall you go up by steps unto my altar, that your nakedness be not exposed upon it.'"

---

## Synthesis Notes

**Key Restorations:**

**"Consciousness Spoke All These Words":**
The Ten Words are not mediated through Moses but spoken directly by YHWH. The people hear the divine voice. This is unique—law given by audible theophany.

**The Prologue (20:2):**
"I am YHWH your Consciousness, who brought you out of Egypt." The commandments are grounded in liberation, not arbitrary authority. The one who saved has the right to command. Law follows grace.

**The First Word: No Other Gods:**
*Al-panai* (עַל־פָּנָי)—"before my face" or "against me" or "besides me." The phrase allows for varying interpretations: no gods in my presence, no gods ahead of me, no gods in addition to me. Israel moves from henotheism (YHWH is supreme) toward monotheism (YHWH alone).

**The Second Word: No Images:**
*Pesel* (פֶּסֶל)—carved image, idol. The prohibition covers heaven, earth, and water—the entire cosmos. No representation of the divine. YHWH cannot be captured in form.

**"Jealous God" (אֵל קַנָּא):**
*Qanna* suggests passionate, zealous love—not petty jealousy but fierce exclusivity. The language is marital: YHWH's relationship with Israel is spousal.

**"Third and Fourth... Thousands":**
The asymmetry is crucial: iniquity visited to 3-4 generations; loving-kindness (*chesed*) to thousands. Mercy vastly exceeds judgment.

**The Third Word: The Name:**
"You shall not lift up (*tissa*) the name of YHWH *la-shav*"—in vain, emptily, falsely. This covers false oaths, empty invocations, and trivializing the sacred name. The name carries power; misuse has consequences.

**The Fourth Word: Sabbath:**
"Remember (*zachor*) the sabbath." Deuteronomy 5:12 says "observe (*shamor*)." Tradition reconciles: both were spoken simultaneously. The sabbath is grounded in creation (here) and in liberation (Deuteronomy). Rest is cosmic and covenantal.

The sabbath extends to all: son, daughter, servants, animals, strangers. No one is exempt; no one is excluded from rest.

**The Fifth Word: Honor Parents:**
*Kabbed* (כַּבֵּד)—from the root for "heavy, weighty." Give weight to your parents. This is the transitional commandment—between duties to God and duties to neighbor. It carries a promise: long life in the land.

**The Sixth Word: No Murder:**
*Lo tirtsach* (לֹא תִּרְצָח). The verb *ratsach* is specific: unlawful killing, murder. It does not prohibit all killing (war, execution are addressed elsewhere) but prohibits murder.

**The Seventh Word: No Adultery:**
*Lo tin'af* (לֹא תִּנְאָף). The verb *na'af* is specifically adultery—violation of marriage. The marriage covenant mirrors the divine covenant.

**The Eighth Word: No Stealing:**
*Lo tignov* (לֹא תִּגְנֹב). Some traditions read this as primarily about kidnapping (stealing persons, as Joseph was stolen). Property theft is addressed in later laws. The short form covers both.

**The Ninth Word: No False Witness:**
*Ed shaqer* (עֵד שָׁקֶר)—lying testimony. The context is judicial: don't give false testimony against your neighbor in court. Truth-telling in legal settings is fundamental to justice.

**The Tenth Word: No Coveting:**
*Lo tachmod* (לֹא תַחְמֹד)—don't desire, don't lust after. This is internal; all previous commandments address action. Coveting is the root of murder, adultery, theft. The commandment addresses the heart.

**The People's Retreat:**
The theophany overwhelms them: "Let not Consciousness speak with us, lest we die." They request mediation. From here on, Moses becomes the mediator of law. Direct revelation is too much.

**"The Thick Darkness":**
*Ha-arafel* (הָעֲרָפֶל)—dense darkness, cloud. Moses approaches where YHWH is hidden. The light is so intense it appears as darkness. The divine presence is veiled even as it is revealed.

**Altar Instructions:**
- Earth altar or unhewn stone—no elaborate construction
- No steps—avoid exposure (nakedness/vulnerability)
- Simplicity characterizes proper worship

**Archetypal Layer:** The Ten Words are **the ethical core**—boundaries that make civilization possible. They move from relation to God (1-4) through family (5) to society (6-10). The inward command (coveting) recognizes that outer behavior flows from inner state.

**Psychological Reading:** The people cannot bear direct encounter; they choose mediation. This is psychologically realistic: the ego cannot continuously face the numinous. Moses enters the darkness on behalf of the people. Prophecy mediates what would otherwise destroy.

**Ethical Inversion Applied:**
- The commandments are grounded in liberation, not oppression
- "Jealous God" is passionate love, not petty control
- The sabbath liberates all—including servants and animals
- Mercy extends to thousands; judgment to three or four
- The final commandment addresses the interior—the heart is accountable

**Modern Equivalent:** Societies require shared ethical boundaries—against murder, theft, perjury. The genius of the Decalogue is compression: ten principles cover the essential. The prohibition of coveting recognizes that external behavior follows internal desire. And grounding law in liberation ("I brought you out") rather than raw power creates moral authority.

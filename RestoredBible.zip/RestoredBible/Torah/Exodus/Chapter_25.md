# Exodus Chapter 25: The Tabernacle Offerings and the Ark

*From the Hebrew: תְּרוּמָה (Terumah) — Contribution*

---

**25:1** And YHWH spoke unto Moses, saying:

**25:2** "Speak unto the children of Israel, that they take for me a contribution—תְּרוּמָה (terumah); from every man whose heart moves him—כֹּל אִישׁ אֲשֶׁר יִדְּבֶנּוּ לִבּוֹ (kol ish asher yiddevenu libbo)—you shall take my contribution.

**25:3** "And this is the contribution which you shall take from them: gold and silver and bronze;

**25:4** "And blue and purple and scarlet yarn, and fine linen, and goats' hair;

**25:5** "And rams' skins dyed red, and porpoise skins, and acacia wood;

**25:6** "Oil for the light, spices for the anointing oil and for the fragrant incense;

**25:7** "Onyx stones and stones to be set, for the ephod and for the breastpiece.

**25:8** "And let them make me a sanctuary—מִקְדָּשׁ (miqdash)—that I may dwell in their midst—וְשָׁכַנְתִּי בְּתוֹכָם (ve-shachanti be-tocham).

**25:9** "According to all that I show you—the pattern of the tabernacle—תַּבְנִית הַמִּשְׁכָּן (tavnit ha-mishkan)—and the pattern of all its furnishings—so shall you make it.

---

**25:10** "And they shall make an ark—אָרוֹן (aron)—of acacia wood; two and a half cubits its length, and a cubit and a half its breadth, and a cubit and a half its height.

**25:11** "And you shall overlay it with pure gold; inside and outside you shall overlay it, and you shall make upon it a molding of gold round about.

**25:12** "And you shall cast four rings of gold for it, and put them on its four feet; two rings on one side of it, and two rings on the other side of it.

**25:13** "And you shall make poles of acacia wood and overlay them with gold.

**25:14** "And you shall put the poles into the rings on the sides of the ark, to carry the ark with them.

**25:15** "The poles shall remain in the rings of the ark; they shall not be removed from it.

**25:16** "And you shall put into the ark the testimony—הָעֵדֻת (ha-edut)—which I shall give you.

**25:17** "And you shall make a mercy seat—כַּפֹּרֶת (kapporet)—of pure gold; two and a half cubits its length, and a cubit and a half its breadth.

**25:18** "And you shall make two cherubim of gold; of hammered work you shall make them, on the two ends of the mercy seat.

**25:19** "And make one cherub on one end and one cherub on the other end; of one piece with the mercy seat you shall make the cherubim on its two ends.

**25:20** "And the cherubim shall spread out their wings on high, covering the mercy seat with their wings, and their faces toward each other; toward the mercy seat shall the faces of the cherubim be.

**25:21** "And you shall put the mercy seat upon the ark from above; and in the ark you shall put the testimony that I shall give you.

**25:22** "And there I will meet with you—וְנוֹעַדְתִּי לְךָ (ve-no'adti lecha)—and I will speak with you from above the mercy seat, from between the two cherubim which are upon the ark of the testimony, of all things which I will command you for the children of Israel.

---

**25:23** "And you shall make a table of acacia wood; two cubits its length, and a cubit its breadth, and a cubit and a half its height.

**25:24** "And you shall overlay it with pure gold and make a molding of gold round about.

**25:25** "And you shall make for it a rim of a handbreadth round about, and a molding of gold for the rim round about.

**25:26** "And you shall make for it four rings of gold, and put the rings in the four corners that are on its four legs.

**25:27** "Close by the rim shall the rings be, as holders for poles to carry the table.

**25:28** "And you shall make the poles of acacia wood, and overlay them with gold, that the table may be carried with them.

**25:29** "And you shall make its dishes and its spoons and its jars and its bowls with which to pour; of pure gold you shall make them.

**25:30** "And you shall set upon the table showbread—לֶחֶם פָּנִים (lechem panim)—before me always.

---

**25:31** "And you shall make a lampstand—מְנֹרָה (menorah)—of pure gold; of hammered work shall the lampstand be made; its base and its shaft, its cups, its buds, and its flowers shall be of one piece with it.

**25:32** "And six branches shall come out of its sides: three branches of the lampstand out of one side, and three branches of the lampstand out of the other side.

**25:33** "Three cups made like almond blossoms in one branch, with a bud and a flower; and three cups made like almond blossoms in the other branch, with a bud and a flower—so for the six branches coming out of the lampstand.

**25:34** "And in the lampstand four cups made like almond blossoms, with their buds and their flowers.

**25:35** "And a bud under two branches of one piece with it, and a bud under two branches of one piece with it, and a bud under two branches of one piece with it—for the six branches coming out of the lampstand.

**25:36** "Their buds and their branches shall be of one piece with it; the whole of it one piece of hammered work of pure gold.

**25:37** "And you shall make its seven lamps; and they shall light its lamps to give light toward its front.

**25:38** "And its tongs and its trays shall be of pure gold.

**25:39** "Of a talent of pure gold shall it be made, with all these vessels.

**25:40** "And see that you make them according to their pattern—בְּתַבְנִיתָם (be-tavnitam)—which was shown you on the mountain."

---

## Synthesis Notes

**Key Restorations:**

**"Whose Heart Moves Him":**
*Yiddevenu libbo* (יִדְּבֶנּוּ לִבּוֹ)—whose heart prompts him, makes him willing. The contribution is voluntary, from inner motivation. YHWH does not demand; YHWH invites. The sanctuary is built from willing hearts.

**The Materials:**
The list moves from most precious to necessary:
- Gold, silver, bronze (metals)
- Colored yarns and fine linen (textiles)
- Animal skins (covering)
- Acacia wood (structure)
- Oil and spices (function)
- Gemstones (priestly garments)

These materials come from the despoiling of Egypt (12:35-36). What Egypt gave becomes the sanctuary of YHWH.

**"That I May Dwell in Their Midst":**
*Ve-shachanti be-tocham* (וְשָׁכַנְתִּי בְּתוֹכָם)—the root שָׁכַן (shakan) gives us *Shekinah*, the divine presence. The sanctuary's purpose: divine dwelling among humans. Not in them individually (yet) but among them collectively.

**The Pattern (תַּבְנִית, tavnit):**
Moses sees a pattern—a heavenly model of the earthly sanctuary. The tabernacle is a copy of a celestial original. Hebrews 8:5 develops this: the earthly is a shadow of the heavenly.

**The Ark (אָרוֹן, aron):**

The most sacred object:
- Acacia wood overlaid with gold (inside and out)
- 2.5 × 1.5 × 1.5 cubits (approximately 3.75 × 2.25 × 2.25 feet)
- Carried by poles that never leave the rings
- Contains "the testimony" (the tablets)

The ark is a portable throne, a container of covenant, a meeting point of divine and human.

**The Mercy Seat (כַּפֹּרֶת, kapporet):**
The lid of the ark. The word comes from כָּפַר (kapar)—to cover, to atone. This is where atonement happens on Yom Kippur (Leviticus 16). The blood is sprinkled here. **The place of covering is the place of meeting.**

**The Cherubim:**
Winged creatures facing each other, wings spread over the mercy seat. Not the chubby infants of Renaissance art—the biblical cherubim are throne-guardians, composite creatures (Ezekiel 1, 10). They guard the way to the tree of life (Genesis 3:24); now they guard the place of meeting.

**"There I Will Meet with You":**
*Ve-no'adti lecha* (וְנוֹעַדְתִּי לְךָ)—I will appoint meeting with you. The space between the cherubim, above the mercy seat, is the locus of revelation. YHWH speaks from this point. The invisible presence hovers over the ark.

**The Table and Showbread:**
*Lechem panim* (לֶחֶם פָּנִים)—"bread of presence" or "bread of faces." Twelve loaves (one for each tribe) set before YHWH continually. Replaced weekly; the old bread eaten by priests. The table signifies ongoing provision and communion.

**The Menorah:**
The seven-branched lampstand:
- Pure gold, hammered from one piece
- Six branches plus central shaft = seven lights
- Almond blossom design (cups, buds, flowers)
- Lamps lit continually

The menorah is a stylized tree—the tree of life represented in gold. Light in the sanctuary; Israel is to be light. The seven lamps may represent the seven days of creation, the fullness of divine light.

**"According to Their Pattern":**
Moses is shown the heavenly pattern and must replicate it exactly. The earthly sanctuary corresponds to a heavenly reality. Precision matters—this is not human design but divine blueprint.

**Archetypal Layer:** The tabernacle is the **axis mundi made portable**—the mountain/temple that can travel with the people. The ark is the throne; the cherubim are the guards; the mercy seat is the meeting place. The menorah is the tree of life; the showbread is provision; the whole structure is heaven intersecting earth.

**Psychological Reading:** The invitation is "whose heart moves him"—interior motivation. The sanctuary is built from willing offering, not taxation. The pattern is given, not invented—consciousness receives the form from the transcendent and implements it.

**Ethical Inversion Applied:**
- The sanctuary is voluntary—no compulsion
- The materials come from Egypt—oppression's wealth becomes sacred service
- YHWH "dwells among them"—the transcendent becomes immanent
- The mercy seat (atonement cover) is the place of meeting—reconciliation is central
- The pattern is heavenly—human construction follows divine template

**Modern Equivalent:** Sacred space is built from willing hearts. The precise attention to detail models how serious work requires exactness. The menorah as tree of life and the ark as throne suggest that genuine sacred space must include both illumination (understanding) and authority (covenant). And the use of Egyptian wealth for YHWH's sanctuary shows how what was gained through injustice can be transformed for sacred purpose.

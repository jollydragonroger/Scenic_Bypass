# Exodus Chapter 35: The Sabbath and the Offering

*From the Hebrew: וַיַּקְהֵל (Vayakhel) — And He Assembled*

---

**35:1** And Moses assembled all the congregation of the children of Israel, and said unto them: "These are the things which YHWH has commanded, to do them.

**35:2** "Six days shall work be done, but on the seventh day there shall be to you a holy day, a sabbath of solemn rest unto YHWH; whoever does work on it shall be put to death.

**35:3** "You shall kindle no fire—לֹא־תְבַעֲרוּ אֵשׁ (lo-teva'aru esh)—throughout your habitations on the sabbath day."

---

**35:4** And Moses spoke unto all the congregation of the children of Israel, saying: "This is the thing which YHWH commanded, saying:

**35:5** "'Take from among you a contribution unto YHWH; whoever is of a willing heart—כֹּל נְדִיב לִבּוֹ (kol nediv libbo)—let him bring it, YHWH's contribution: gold and silver and bronze,

**35:6** "And blue and purple and scarlet yarn, and fine linen, and goats' hair,

**35:7** "And rams' skins dyed red, and porpoise skins, and acacia wood,

**35:8** "And oil for the light, and spices for the anointing oil and for the fragrant incense,

**35:9** "And onyx stones and stones to be set, for the ephod and for the breastpiece.

**35:10** "'And let every wise-hearted one among you come—וְכָל־חֲכַם־לֵב בָּכֶם (ve-chol-chakam-lev bachem)—and make all that YHWH has commanded:

**35:11** "The tabernacle, its tent and its covering, its clasps and its boards, its bars, its pillars, and its sockets;

**35:12** "The ark and its poles, the mercy seat, and the veil of the screen;

**35:13** "The table and its poles and all its vessels, and the showbread;

**35:14** "The lampstand also for the light, and its vessels, and its lamps, and the oil for the light;

**35:15** "And the altar of incense and its poles, and the anointing oil, and the fragrant incense, and the screen for the door, at the door of the tabernacle;

**35:16** "The altar of burnt offering with its grating of bronze, its poles, and all its vessels, the basin and its stand;

**35:17** "The hangings of the court, its pillars, and its sockets, and the screen for the gate of the court;

**35:18** "The pegs of the tabernacle, and the pegs of the court, and their cords;

**35:19** "The woven garments for ministering in the holy place, the holy garments for Aaron the priest, and the garments of his sons, to minister as priests.'"

---

**35:20** And all the congregation of the children of Israel departed from the presence of Moses.

**35:21** And they came, every one whose heart stirred him up—כֹּל־אִישׁ אֲשֶׁר־נְשָׂאוֹ לִבּוֹ (kol-ish asher-nesa'o libbo)—and every one whose spirit made him willing—וְכֹל אֲשֶׁר נָדְבָה רוּחוֹ (ve-chol asher nadeva rucho)—and brought YHWH's contribution for the work of the tent of meeting, and for all its service, and for the holy garments.

**35:22** And they came, both men and women, as many as were willing-hearted, and brought brooches and earrings and signet rings and armlets, all jewels of gold; even every man who offered an offering of gold unto YHWH.

**35:23** And every man with whom was found blue and purple and scarlet yarn, and fine linen, and goats' hair, and rams' skins dyed red, and porpoise skins, brought them.

**35:24** Every one who offered a contribution of silver and bronze brought YHWH's contribution; and every one with whom was found acacia wood for any work of the service brought it.

**35:25** And every wise-hearted woman spun with her hands—וְכָל־אִשָּׁה חַכְמַת־לֵב בְּיָדֶיהָ טָווּ (ve-chol-ishah chakmat-lev be-yadeiha tavu)—and brought what they had spun: the blue and the purple, the scarlet yarn, and the fine linen.

**35:26** And all the women whose heart stirred them up in wisdom spun the goats' hair.

**35:27** And the leaders brought the onyx stones and the stones to be set, for the ephod and for the breastpiece;

**35:28** And the spice and the oil, for the light and for the anointing oil and for the fragrant incense.

**35:29** The children of Israel brought a freewill offering unto YHWH; every man and woman whose heart made them willing to bring for all the work, which YHWH had commanded to be made by the hand of Moses.

---

**35:30** And Moses said unto the children of Israel: "See, YHWH has called by name Bezalel the son of Uri, the son of Hur, of the tribe of Judah.

**35:31** "And he has filled him with the spirit of Consciousness, in wisdom, in understanding, and in knowledge, and in all manner of workmanship,

**35:32** "And to devise skillful works, to work in gold and in silver and in bronze,

**35:33** "And in cutting of stones for setting, and in carving of wood, to work in all manner of skillful workmanship.

**35:34** "And he has put in his heart to teach—לְהוֹרֹת נָתַן בְּלִבּוֹ (le-horot natan be-libbo)—both he and Oholiab the son of Ahisamach, of the tribe of Dan.

**35:35** "He has filled them with wisdom of heart—חָכְמַת־לֵב (chokmat-lev)—to work all manner of work, of the engraver and of the skillful workman and of the embroiderer, in blue and in purple, in scarlet yarn and in fine linen, and of the weaver; those who do any work and those who devise skillful work."

---

## Synthesis Notes

**Key Restorations:**

**The Sabbath First:**
Before discussing the tabernacle work, Moses reiterates the sabbath commandment. The sequence is significant: even sacred construction halts for sabbath. The sanctuary is important; the sabbath is more important.

**"Kindle No Fire":**
*Lo-teva'aru esh*—this specific prohibition appears only here. Traditional interpretation: no fire for work (cooking, metallurgy) on sabbath. The tabernacle will require fire for metallurgy, but not on the seventh day.

**The Willing Heart:**
Three phrases describe the givers:
- *Nediv libbo* (נְדִיב לִבּוֹ): willing/generous of heart
- *Nesa'o libbo* (נְשָׂאוֹ לִבּוֹ): whose heart lifted him
- *Nadeva rucho* (נָדְבָה רוּחוֹ): whose spirit moved him willingly

All giving is voluntary, from interior motivation. YHWH wants willing hearts, not compelled contributions.

**Men and Women:**
"They came, both men and women"—the tabernacle is built by all Israel. Women spin the yarns; they bring jewelry. The contribution is not gendered. Some women are explicitly called "wise-hearted" (*chakmat-lev*).

**The Leaders Bring:**
*Ha-nesi'im* (the leaders/princes) bring the precious stones and spices—the rare, expensive items. Each level of society contributes according to capacity.

**Wisdom of Heart:**
*Chokmat-lev* (חָכְמַת־לֵב)—repeated emphasis. Wisdom dwells in the heart. The artisans have this; the spinning women have this. Sacred work requires heart-wisdom, not mere intellectual skill.

**Bezalel and Oholiab:**
Reintroduction of the chief artisans. Now they have an additional gift: "he has put in his heart to teach" (*le-horot natan be-libbo*). They are not only craftsmen but teachers. Skill must be transmitted.

**All Manner of Work:**
The variety of skills listed:
- Engraver (precious stones)
- Skillful workman (general craftsmanship)
- Embroiderer (textile design)
- Weaver (fabric creation)
- Those who devise (designers, planners)

The tabernacle requires diverse gifts working together.

**Archetypal Layer:** The assembly responds to the golden calf crisis with opposite behavior: instead of demanding Aaron make gods, they willingly bring offerings for YHWH's dwelling. The contrast is deliberate—the people who contributed gold for the calf now contribute gold for the tabernacle. What was perverted is now redeemed.

**Psychological Reading:** Interior motivation ("willing heart," "stirred spirit") produces genuine offering. Compulsion produces compliance; willingness produces generosity. The heart-language throughout suggests that sacred work originates in the affective depths, not in duty or obligation.

**Ethical Inversion Applied:**
- Sabbath precedes tabernacle—rest is more fundamental than even sacred construction
- All giving is voluntary—the sanctuary is built from willingness, not taxation
- Women are wise-hearted—skill and wisdom are not gendered
- Teaching is a gift—Bezalel can teach, not only make
- Diversity of gifts is required—no one person has all skills

**Modern Equivalent:** The best work emerges from willing hearts, not compulsion. Sabbath remains non-negotiable even for urgent sacred projects. And the community's offerings—material, skill, teaching—combine to build what no individual could construct alone.

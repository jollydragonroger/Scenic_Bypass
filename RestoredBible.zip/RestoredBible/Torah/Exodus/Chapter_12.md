# Exodus Chapter 12: The Passover

*From the Hebrew: פֶּסַח (Pesach) — The Passing Over*

---

**12:1** And YHWH spoke unto Moses and Aaron in the land of Egypt, saying:

**12:2** "This month shall be unto you the beginning of months—רֹאשׁ חֳדָשִׁים (rosh chodashim); it shall be the first month of the year to you.

**12:3** "Speak unto all the congregation of Israel, saying: 'On the tenth day of this month they shall take to them every man a lamb—שֶׂה (seh)—according to their fathers' houses, a lamb for a household.

**12:4** "'And if the household is too small for a lamb, let him and his neighbor next unto his house take one according to the number of the souls; according to what each man eats you shall make your count for the lamb.

**12:5** "'Your lamb shall be without blemish—תָּמִים (tamim)—a male of the first year; you shall take it from the sheep or from the goats.

**12:6** "'And you shall keep it until the fourteenth day of this month; and the whole assembly of the congregation of Israel shall slaughter it between the evenings—בֵּין הָעַרְבָּיִם (bein ha-arbayim).

**12:7** "'And they shall take of the blood and put it on the two doorposts and on the lintel—הַמַּשְׁקוֹף (ha-mashqof)—upon the houses wherein they shall eat it.

**12:8** "'And they shall eat the flesh in that night, roasted with fire—צְלִי־אֵשׁ (tseli-esh)—and unleavened bread—מַצּוֹת (matsot); with bitter herbs—מְרֹרִים (merorim)—they shall eat it.

**12:9** "'Eat not of it raw, nor boiled in water, but roasted with fire; its head with its legs and with its inner parts.

**12:10** "'And you shall let nothing of it remain until the morning; and that which remains of it until the morning you shall burn with fire.

**12:11** "'And thus shall you eat it: with your loins girded, your sandals on your feet, and your staff in your hand; and you shall eat it in haste—בְּחִפָּזוֹן (be-chippazon). It is the Passover of YHWH—פֶּסַח הוּא לַיהוה (Pesach hu la-YHWH).

**12:12** "'For I will pass through—וְעָבַרְתִּי (ve-avarti)—the land of Egypt in that night, and will strike every firstborn in the land of Egypt, both man and beast; and against all the gods of Egypt I will execute judgments—שְׁפָטִים (shefatim). I am YHWH.

**12:13** "'And the blood shall be to you for a sign upon the houses where you are; and when I see the blood, I will pass over you—וּפָסַחְתִּי עֲלֵכֶם (u-fasachti aleichem)—and there shall no plague be upon you to destroy you when I strike the land of Egypt.

**12:14** "'And this day shall be unto you for a memorial—זִכָּרוֹן (zikkaron); and you shall keep it as a feast to YHWH throughout your generations; you shall keep it as a feast by an ordinance forever.

---

**12:15** "'Seven days shall you eat unleavened bread; on the first day you shall remove leaven—שְׂאֹר (se'or)—out of your houses; for whoever eats leavened bread from the first day until the seventh day, that soul shall be cut off from Israel.

**12:16** "'And on the first day there shall be a holy convocation—מִקְרָא־קֹדֶשׁ (miqra-qodesh)—and on the seventh day there shall be a holy convocation to you; no manner of work shall be done in them, except what every soul must eat—that only may be done by you.

**12:17** "'And you shall observe the unleavened bread; for on this very day I brought your hosts out of the land of Egypt; therefore shall you observe this day throughout your generations by an ordinance forever.

**12:18** "'In the first month, on the fourteenth day of the month at evening, you shall eat unleavened bread, until the twenty-first day of the month at evening.

**12:19** "'Seven days shall there be no leaven found in your houses; for whoever eats what is leavened, that soul shall be cut off from the congregation of Israel, whether a sojourner or a native of the land.

**12:20** "'You shall eat nothing leavened; in all your habitations shall you eat unleavened bread.'"

---

**12:21** And Moses called for all the elders of Israel and said unto them: "Draw out and take—מִשְׁכוּ וּקְחוּ (mishchu u-qechu)—lambs according to your families, and slaughter the Passover.

**12:22** "And you shall take a bunch of hyssop—אֵזוֹב (ezov)—and dip it in the blood that is in the basin, and strike the lintel and the two doorposts with the blood that is in the basin; and none of you shall go out of the door of his house until the morning.

**12:23** "For YHWH will pass through to strike the Egyptians; and when he sees the blood upon the lintel and on the two doorposts, YHWH will pass over the door, and will not allow the destroyer—הַמַּשְׁחִית (ha-mashchit)—to come into your houses to strike you.

**12:24** "And you shall observe this thing as an ordinance for you and for your sons forever.

**12:25** "And it shall come to pass, when you come to the land which YHWH will give you, as he has promised, that you shall keep this service.

**12:26** "And it shall come to pass, when your children say unto you, 'What do you mean by this service?'—מָה הָעֲבֹדָה הַזֹּאת לָכֶם (mah ha-avodah ha-zot lachem)—

**12:27** "That you shall say, 'It is the sacrifice of the Passover of YHWH, who passed over the houses of the children of Israel in Egypt, when he struck the Egyptians and delivered our houses.'" And the people bowed their heads and worshipped.

**12:28** And the children of Israel went and did so; as YHWH had commanded Moses and Aaron, so they did.

---

**12:29** And it came to pass at midnight—וַיְהִי בַּחֲצִי הַלַּיְלָה (va-yehi ba-chatsi ha-laylah)—that YHWH struck every firstborn in the land of Egypt, from the firstborn of Pharaoh who sat on his throne unto the firstborn of the captive who was in the dungeon, and every firstborn of beast.

**12:30** And Pharaoh rose up in the night, he and all his servants and all the Egyptians; and there was a great cry in Egypt; for there was not a house where there was not one dead.

**12:31** And he called for Moses and Aaron by night, and said: "Rise up, get out from among my people, both you and the children of Israel; and go, serve YHWH, as you have said.

**12:32** "Also take your flocks and your herds, as you have said, and go; and bless me also—וּבֵרַכְתֶּם גַּם־אֹתִי (u-verachtem gam-oti)."

**12:33** And the Egyptians were urgent upon the people, to send them out of the land in haste; for they said, "We are all dead men."

**12:34** And the people took their dough before it was leavened, their kneading troughs bound up in their clothes upon their shoulders.

**12:35** And the children of Israel did according to the word of Moses; and they asked of the Egyptians vessels of silver and vessels of gold and garments.

**12:36** And YHWH gave the people favor in the eyes of the Egyptians, so that they let them have what they asked. And they despoiled—וַיְנַצְּלוּ (va-yenatselu)—Egypt.

---

**12:37** And the children of Israel journeyed from Rameses to Succoth, about six hundred thousand on foot who were men—כְּשֵׁשׁ־מֵאוֹת אֶלֶף רַגְלִי (ke-shesh-me'ot elef ragli)—besides children.

**12:38** And a mixed multitude—עֵרֶב רַב (erev rav)—went up also with them; and flocks and herds, very much cattle.

**12:39** And they baked unleavened cakes of the dough which they brought out of Egypt, for it was not leavened; because they were thrust out of Egypt and could not delay, neither had they prepared for themselves any provisions.

**12:40** Now the dwelling of the children of Israel, which they dwelt in Egypt, was four hundred and thirty years.

**12:41** And it came to pass at the end of four hundred and thirty years, on that very day, all the hosts of YHWH went out from the land of Egypt.

**12:42** It is a night of watching—לֵיל שִׁמֻּרִים (leil shimmurim)—unto YHWH, for bringing them out from the land of Egypt; this is that night of YHWH, a watching for all the children of Israel throughout their generations.

---

**12:43** And YHWH said unto Moses and Aaron: "This is the ordinance of the Passover: no foreigner—בֶּן־נֵכָר (ben-nechar)—shall eat of it.

**12:44** "But every man's servant that is bought for money, when you have circumcised him, then shall he eat of it.

**12:45** "A sojourner and a hired servant shall not eat of it.

**12:46** "In one house shall it be eaten; you shall not carry any of the flesh outside the house; neither shall you break a bone of it—וְעֶצֶם לֹא תִשְׁבְּרוּ־בוֹ (ve-etsem lo tishberu-vo).

**12:47** "All the congregation of Israel shall keep it.

**12:48** "And when a stranger—גֵּר (ger)—shall sojourn with you and will keep the Passover to YHWH, let all his males be circumcised, and then let him come near and keep it; and he shall be as a native of the land; but no uncircumcised person shall eat of it.

**12:49** "One law—תּוֹרָה אַחַת (torah achat)—shall be to the native and unto the stranger that sojourns among you."

**12:50** And all the children of Israel did so; as YHWH commanded Moses and Aaron, so they did.

**12:51** And it came to pass on that very day that YHWH brought the children of Israel out of the land of Egypt by their hosts.

---

## Synthesis Notes

**Key Restorations:**

**The New Calendar:**
"This month shall be the first month"—time itself is reset. Liberation creates a new beginning. The exodus becomes year-zero of Israelite identity.

**The Lamb (שֶׂה, seh):**
- Without blemish (*tamim*)—complete, whole, perfect
- Kept from the 10th to the 14th—observed, known
- Slaughtered "between the evenings"—twilight, the liminal hour
- Blood on doorposts and lintel—marking the house

**The Blood:**
Blood is the sign, not for YHWH (who knows where Israel lives) but for Israel—"the blood shall be to you for a sign." The marking is for the marked, not the marker.

**The Meal:**
- Roasted with fire (*tseli-esh*)—**fire = transformation**
- Unleavened bread (*matsot*)—bread of haste, bread without time to rise
- Bitter herbs (*merorim*)—the bitterness of slavery remembered in the mouth

**The Posture:**
"Loins girded, sandals on feet, staff in hand"—ready to move. Eat in haste (*chippazon*). This is not a leisurely meal but emergency rations. Departure is imminent.

**"Against All the Gods of Egypt I Will Execute Judgments":**
The plagues are explicitly theological—attacks on Egyptian deities. The Nile (Hapi), frogs (Heqet), the sun (Ra)—and now the firstborn, connected to Pharaoh's divine status. YHWH triumphs over Egypt's pantheon.

**The Destroyer (הַמַּשְׁחִית, ha-mashchit):**
YHWH "will not allow the destroyer to come in." Who is this destroyer? An angel of death? A personification of divine judgment? The text doesn't specify. YHWH both strikes and restrains the striking force.

**The Children's Question:**
"What do you mean by this service?" The ritual is designed to provoke questions. Each generation must ask; each generation must be told. The Seder is educational.

**Midnight (חֲצִי הַלַּיְלָה):**
The blow falls at the liminal moment—the threshold between days. "Not a house where there was not one dead"—universality of the strike.

**"Bless Me Also":**
Pharaoh's final request to Moses: "bless me." The god-king asks the slave-prophet for blessing. The complete inversion is achieved.

**The Mixed Multitude (עֵרֶב רַב):**
Not only Israelites leave—a mixed group, perhaps Egyptian sympathizers, other slaves, those who saw YHWH's power. The exodus is not ethnically pure. Israel includes those who join the journey.

**Six Hundred Thousand:**
*Ke-shesh-me'ot elef ragli*—about 600,000 men on foot, plus children. With women and elderly, perhaps 2-3 million. This number is debated historically. *Elef* (אֶלֶף) can mean "thousand" or "clan/military unit." The number may be symbolic of vast multitude or a smaller actual count. The restoration notes the interpretive question.

**"A Night of Watching" (לֵיל שִׁמֻּרִים):**
YHWH watched over Israel that night; Israel watches (commemorates) that night forever. The watching is mutual—divine and human attentiveness meeting across time.

**"One Law" (תּוֹרָה אַחַת):**
The same law applies to native and stranger who joins. The distinction is not ethnicity but covenant: circumcision brings participation. The stranger who commits can eat the Passover.

**"You Shall Not Break a Bone":**
The lamb's bones remain unbroken—the animal is consumed whole, intact. This detail will be recalled in John 19:36 regarding Jesus' death.

**Archetypal Layer:** The Passover is the foundational ritual of liberation:
- Blood marks the threshold
- Fire transforms the offering
- Haste characterizes the moment
- Death passes over those who are marked
- The destroyer is restrained

This is the **descent for integration** (from the symbol map)—passage through death to new life. The firstborn die so that the firstborn nation lives. The pattern is substitutionary.

**Psychological Reading:** The ritual enacts what happened. Memory is not merely cognitive but embodied—eating unleavened bread, tasting bitter herbs, marking doorposts. The body remembers what the mind might forget. And the children's question ensures transmission.

**Ethical Inversion Applied:**
- The slaves leave wealthy (despoiling Egypt)—justice includes reparations
- The mixed multitude is included—identity is open to joiners
- One law for native and stranger—equality within covenant
- The ritual preserves memory against forgetting
- Pharaoh asks for blessing—complete reversal of power

**Modern Equivalent:** Liberation requires ritual to sustain memory. "What does this mean?" is the question each generation must ask. The haste of the first departure becomes the deliberate remembrance of every subsequent Seder. And systems of oppression, when they finally break, break suddenly—"we are all dead men."

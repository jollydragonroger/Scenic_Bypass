# Exodus Chapter 5: First Confrontation with Pharaoh

*From the Hebrew: "Who Is YHWH?"*

---

**5:1** And afterward Moses and Aaron came and said unto Pharaoh: "Thus says YHWH, the Consciousness of Israel: 'Let my people go, that they may hold a feast unto me in the wilderness.'"

**5:2** And Pharaoh said: "Who is YHWH—מִי יהוה (mi YHWH)—that I should listen to his voice to let Israel go? I do not know YHWH—לֹא יָדַעְתִּי אֶת־יהוה (lo yadati et-YHWH)—and moreover I will not let Israel go."

**5:3** And they said: "The Consciousness of the Hebrews has met with us. Please let us go three days' journey into the wilderness and sacrifice to YHWH our Consciousness, lest he fall upon us with pestilence or with the sword."

**5:4** And the king of Egypt said unto them: "Moses and Aaron, why do you take the people from their work? Go unto your burdens!"

**5:5** And Pharaoh said: "Behold, the people of the land are now many, and you would have them rest from their burdens—וְהִשְׁבַּתֶּם אֹתָם מִסִּבְלֹתָם (ve-hishbattem otam mi-sivlotam)!"

**5:6** And Pharaoh commanded the same day the taskmasters of the people and their officers, saying:

**5:7** "You shall no longer give the people straw to make bricks as before; let them go and gather straw for themselves.

**5:8** "And the quota of bricks which they made before you shall lay upon them; you shall not diminish from it, for they are idle—נִרְפִּים (nirpim)—therefore they cry, saying, 'Let us go and sacrifice to our Consciousness.'

**5:9** "Let heavier work be laid upon the men—תִּכְבַּד הָעֲבֹדָה (tikhbad ha-avodah)—that they may work at it, and let them not pay attention to lying words—דִּבְרֵי־שָׁקֶר (divrei-shaqer)."

**5:10** And the taskmasters of the people and their officers went out and spoke to the people, saying: "Thus says Pharaoh: 'I will not give you straw.

**5:11** "'Go yourselves, get yourselves straw from wherever you can find it; for nothing of your work shall be diminished.'"

**5:12** And the people scattered throughout all the land of Egypt to gather stubble for straw.

**5:13** And the taskmasters were pressing, saying: "Finish your work, the daily matter each day, as when there was straw."

**5:14** And the officers of the children of Israel, whom Pharaoh's taskmasters had set over them, were beaten, saying: "Why have you not fulfilled your quota of making bricks both yesterday and today, as before?"

**5:15** And the officers of the children of Israel came and cried out to Pharaoh, saying: "Why do you deal thus with your servants?

**5:16** "No straw is given to your servants, and they say to us, 'Make bricks!' And behold, your servants are beaten, but the fault is in your own people."

**5:17** And Pharaoh said: "You are idle, idle!—נִרְפִּים אַתֶּם נִרְפִּים (nirpim attem nirpim). Therefore you say, 'Let us go and sacrifice to YHWH.'

**5:18** "And now go, work! And straw shall not be given to you, and you shall deliver the quota of bricks."

**5:19** And the officers of the children of Israel saw that they were in trouble—בְּרָע (be-ra)—when it was said: "You shall not diminish from your bricks, the daily matter each day."

**5:20** And they met Moses and Aaron, who stood waiting for them as they came out from Pharaoh.

**5:21** And they said unto them: "May YHWH look upon you and judge—יֵרֶא יהוה עֲלֵיכֶם וְיִשְׁפֹּט (yere YHWH aleichem ve-yishpot)—because you have made our scent odious—הִבְאַשְׁתֶּם אֶת־רֵיחֵנוּ (hiv'ashtem et-reichenu)—in the eyes of Pharaoh and in the eyes of his servants, to put a sword in their hand to kill us."

**5:22** And Moses returned unto YHWH and said: "Lord, why have you done evil to this people—לָמָה הֲרֵעֹתָה לָעָם הַזֶּה (lamah hare'otah la-am ha-zeh)? Why is it that you have sent me?

**5:23** "For since I came to Pharaoh to speak in your name, he has done evil to this people, and you have not delivered your people at all—וְהַצֵּל לֹא־הִצַּלְתָּ (ve-hatsel lo-hitsalta)."

---

## Synthesis Notes

**Key Restorations:**

**"Who Is YHWH?":**
Pharaoh's question is not merely rhetorical. He genuinely does not recognize YHWH—this is a god outside Egyptian pantheon, a god of slaves. His "I do not know YHWH" (*lo yadati*) will be answered through the plagues: "By this you shall know that I am YHWH" (7:17).

The narrative arc: Pharaoh asks "Who is YHWH?" The plagues are the answer.

**The Modest Request:**
Three days' journey to sacrifice—apparently a limited request. But Pharaoh perceives the threat correctly: this is about control. Any concession undermines absolute power.

**"They Are Idle":**
Pharaoh interprets religious desire as laziness. The slaves want to worship? They must have too much time. His solution: increase the burden.

**Straw for Bricks:**
Ancient Egyptian mud-bricks required straw (chopped stalks) as binding material. Removing the straw supply while maintaining quotas creates impossible demands. This is systemic cruelty—maintaining productivity requirements while removing resources.

**The Hierarchy of Oppression:**
- Pharaoh commands
- Egyptian taskmasters enforce
- Israelite officers are held responsible
- Workers suffer

When quotas aren't met, the Israelite officers (overseers from among the slaves) are beaten. They become the buffer—responsible for the impossible, punished for failure.

**"The Fault Is in Your Own People":**
The Israelite officers courageously tell Pharaoh the truth: the fault is with Egypt, not with them. But Pharaoh dismisses them: "You are idle, idle!"

**The Backlash Against Moses:**
The Israelite officers curse Moses and Aaron: "May YHWH look upon you and judge!" The intervention has made things worse. This is the cost of confronting power—initial backlash, increased suffering before liberation.

**"You Have Made Our Scent Odious":**
*Hiv'ashtem et-reichenu*—literally "you have made us stink." Before, they were tolerated slaves; now they are marked as troublemakers. The petition has drawn hostile attention.

**Moses' Complaint to YHWH:**
Moses returns to YHWH with honest protest:
- "Why have you done evil to this people?"
- "Why did you send me?"
- "Since I spoke in your name, things are worse"
- "You have not delivered at all!"

This is not faithlessness but prophetic complaint—arguing with God, demanding explanation. Abraham did it (Genesis 18); Moses does it; later prophets (Jeremiah, Habakkuk) will do it.

**"You Have Not Delivered at All":**
*Hatsel lo-hitsalta*—the infinitive absolute emphasizes: absolutely no deliverance. Moses expected results; he got increased suffering. The gap between promise and experience produces crisis.

**Archetypal Layer:** The first confrontation with the beast/machine produces backlash. Systems don't yield to initial challenge; they intensify oppression. The liberator is blamed by those he came to free. This is the dark night before the dawn—worse before better.

**Psychological Reading:** When the ego (Moses) challenges the old order (Pharaoh/Egypt), the immediate result is increased pressure. The established system fights back. Those caught in between (Israelite officers) suffer most and may blame the agent of change. Moses' complaint to YHWH is the crisis of the activist: "It's worse than before—what's the point?"

**Ethical Inversion Applied:**
- Pharaoh frames worship as idleness
- The desire for meaning is called laziness
- Religious aspiration is punished with harder labor
- The system weaponizes productivity against the human
- Moses' honest anger at YHWH is not punished but answered (Chapter 6)

**Systemic-Ecological Reading:** The demand for more bricks without providing straw is the pattern of extractive systems everywhere: maintain productivity, reduce resources, punish those caught in the gap. The workers must "scatter throughout the land" to find stubble—ecological foraging to meet impossible industrial demands.

**Modern Equivalent:** Attempts to change oppressive systems often produce initial backlash. The powerful increase pressure. Those in the middle (middle management, community leaders) get squeezed. The reformers are blamed by those they're trying to help. And the honest question to higher purpose—"Why is it worse?"—is the natural crisis of activism before breakthrough.

# Exodus Chapter 9: Pestilence, Boils, and Hail

*From the Hebrew: The Middle Plagues*

---

**9:1** And YHWH said unto Moses: "Go in unto Pharaoh and speak unto him: 'Thus says YHWH, the Consciousness of the Hebrews: Let my people go, that they may serve me.

**9:2** "'For if you refuse to let them go and still hold them,

**9:3** "'Behold, the hand of YHWH is upon your livestock which are in the field—upon the horses, upon the donkeys, upon the camels, upon the cattle, and upon the sheep—a very severe pestilence—דֶּבֶר כָּבֵד מְאֹד (dever kaved me'od).

**9:4** "'And YHWH shall make a distinction—וְהִפְלָה (ve-hiflah)—between the livestock of Israel and the livestock of Egypt; and nothing shall die of all that belongs to the children of Israel.'"

**9:5** And YHWH set a time, saying: "Tomorrow YHWH shall do this thing in the land."

**9:6** And YHWH did this thing on the morrow, and all the livestock of Egypt died; but of the livestock of the children of Israel not one died.

**9:7** And Pharaoh sent, and behold, not even one of the livestock of Israel died. But the heart of Pharaoh was hardened—וַיִּכְבַּד (va-yikhbad)—and he did not let the people go.

---

**9:8** And YHWH said unto Moses and unto Aaron: "Take for yourselves handfuls of soot from a furnace—פִּיחַ כִּבְשָׁן (piach kivshan)—and let Moses throw it toward the heavens in the sight of Pharaoh.

**9:9** "And it shall become fine dust over all the land of Egypt, and shall become boils—שְׁחִין (shechin)—breaking out in sores upon man and upon beast, throughout all the land of Egypt."

**9:10** And they took soot from the furnace and stood before Pharaoh; and Moses threw it toward the heavens, and it became boils breaking out in sores upon man and upon beast.

**9:11** And the magicians could not stand before Moses because of the boils; for the boils were upon the magicians and upon all the Egyptians.

**9:12** And YHWH hardened—וַיְחַזֵּק (va-yechazzeq)—the heart of Pharaoh, and he did not listen unto them, as YHWH had spoken unto Moses.

---

**9:13** And YHWH said unto Moses: "Rise up early in the morning and stand before Pharaoh, and say unto him: 'Thus says YHWH, the Consciousness of the Hebrews: Let my people go, that they may serve me.

**9:14** "'For at this time I will send all my plagues upon your heart, and upon your servants, and upon your people; that you may know that there is none like me in all the earth.

**9:15** "'For now I could have stretched out my hand and struck you and your people with pestilence, and you would have been cut off from the earth.

**9:16** "'But indeed for this purpose I have raised you up—הֶעֱמַדְתִּיךָ (he'emadticha)—to show you my power, and that my name may be declared throughout all the earth.

**9:17** "'Still you exalt yourself—מִסְתּוֹלֵל (mistolel)—against my people, not letting them go.

**9:18** "'Behold, tomorrow at this time I will cause it to rain a very heavy hail—בָּרָד כָּבֵד מְאֹד (barad kaved me'od)—such as has not been in Egypt from the day it was founded until now.

**9:19** "'And now send, hasten to bring your livestock and all that you have in the field into shelter; every man and beast that is found in the field and is not brought home—the hail shall come down upon them, and they shall die.'"

**9:20** The one who feared the word of YHWH among the servants of Pharaoh made his servants and his livestock flee into the houses.

**9:21** And the one who did not set his heart to the word of YHWH left his servants and his livestock in the field.

**9:22** And YHWH said unto Moses: "Stretch out your hand toward the heavens, that there may be hail in all the land of Egypt—upon man and upon beast and upon every herb of the field, throughout the land of Egypt."

**9:23** And Moses stretched out his staff toward the heavens; and YHWH gave thunder—קֹלֹת (qolot)—and hail, and fire ran down to the earth—וַתִּהֲלַךְ אֵשׁ אָרְצָה (va-tihalach esh artsah); and YHWH rained hail upon the land of Egypt.

**9:24** And there was hail, and fire flashing in the midst of the hail—וְאֵשׁ מִתְלַקַּחַת בְּתוֹךְ הַבָּרָד (ve-esh mitlaqachat be-toch ha-barad)—very heavy, such as had not been in all the land of Egypt since it became a nation.

**9:25** And the hail struck throughout all the land of Egypt all that was in the field, both man and beast; and the hail struck every herb of the field and broke every tree of the field.

**9:26** Only in the land of Goshen, where the children of Israel were, there was no hail.

**9:27** And Pharaoh sent and called for Moses and Aaron, and said unto them: "I have sinned this time—חָטָאתִי הַפָּעַם (chatati ha-pa'am). YHWH is righteous—צַדִּיק (tsaddiq)—and I and my people are wicked—רְשָׁעִים (resha'im)."

**9:28** "Entreat YHWH, and let there be enough of the mighty thunderings and hail; and I will let you go, and you shall stay no longer."

**9:29** And Moses said unto him: "As soon as I am gone out of the city, I will spread out my hands unto YHWH; the thunders shall cease, and there shall be no more hail; that you may know that the earth is YHWH's.

**9:30** "But as for you and your servants, I know that you do not yet fear YHWH Consciousness."

**9:31** And the flax and the barley were struck; for the barley was in the ear, and the flax was in bloom.

**9:32** But the wheat and the spelt were not struck, for they ripen later.

**9:33** And Moses went out of the city from Pharaoh and spread out his hands unto YHWH; and the thunders and hail ceased, and the rain was not poured upon the earth.

**9:34** And Pharaoh saw that the rain and the hail and the thunders had ceased, and he sinned yet more, and hardened his heart—וַיַּכְבֵּד לִבּוֹ (va-yakhbed libbo)—he and his servants.

**9:35** And the heart of Pharaoh was hardened, and he did not let the children of Israel go, as YHWH had spoken by the hand of Moses.

---

## Synthesis Notes

**Key Restorations:**

**The Fifth Plague: Pestilence (דֶּבֶר, dever):**

A disease strikes Egyptian livestock—horses, donkeys, camels, cattle, sheep. "All" the livestock of Egypt died, yet later plagues still affect livestock. "All" may be hyperbolic or refer to exposed livestock.

The distinction continues: not one Israelite animal dies. Pharaoh investigates ("sent and behold") and confirms the difference—yet hardens anyway.

**The Sixth Plague: Boils (שְׁחִין, shechin):**

Soot from a furnace (*kivshan*)—the word used for brick-kilns. The instrument of Israel's oppression (brick-making) becomes the source of Egypt's affliction. The soot Moses throws becomes skin disease.

**The Magicians Fall:**
"The magicians could not stand before Moses because of the boils." The court magicians—who replicated early plagues, who acknowledged "the finger of God"—are now incapacitated. They cannot even appear. The competition is over.

**YHWH Hardens:**
At the boils, for the first time clearly, "YHWH hardened (*va-yechazzeq*) the heart of Pharaoh." The language shifts from Pharaoh hardening himself to YHWH hardening him. The moral implications are profound and unresolved.

**The Purpose Statement (9:15-16):**
YHWH explains why Pharaoh still exists:
- "I could have struck you with pestilence"
- "But I have raised you up (*he'emadticha*)"
- "To show you my power"
- "That my name may be declared throughout all the earth"

This is the text Paul quotes in Romans 9:17. Pharaoh's existence serves divine purpose. The hardening is instrumentalized.

**"You Still Exalt Yourself" (מִסְתּוֹלֵל, mistolel):**
The verb suggests building a highway or ramp—lifting oneself up, creating barriers. Pharaoh elevates himself against Israel and against YHWH.

**The Seventh Plague: Hail (בָּרָד, barad):**

The most severe plague yet:
- Warning given with time to respond
- Those who "feared the word of YHWH" bring livestock inside
- Those who "did not set heart to the word" leave them out
- Choice is introduced—Egyptians can respond to warning

**Fire Within Hail:**
*Esh mitlaqachat be-toch ha-barad*—"fire flashing within the hail." A supernatural phenomenon: fire and ice together. **Fire = transformation, revelation** (symbol map). The contradiction of elements signals divine intervention beyond natural process.

**Pharaoh's "Confession":**
"I have sinned. YHWH is righteous. I and my people are wicked."

This sounds like genuine repentance. Pharaoh uses theological language—*tsaddiq* (righteous), *resha'im* (wicked). He acknowledges sin.

But Moses knows: "You do not yet fear YHWH Consciousness." The words are correct; the heart is not changed.

**The Agricultural Detail:**
Flax and barley are struck (early-ripening); wheat and spelt are spared (late-ripening). This grounds the narrative in agricultural reality and sets up the locust plague (which will destroy what remains).

**The Pattern Continues:**
"Pharaoh saw that the rain and hail and thunders had ceased, and he sinned yet more." Relief produces regression. Every respite restores his resistance.

**Archetypal Layer:** The plagues now attack:
5. Livestock (economic foundation)
6. Bodies (physical health of Egyptians themselves)
7. Sky/weather (cosmic order—fire and ice)

The assault moves from external (water, creatures) to internal (bodies) to cosmic (elements). The beast/machine is being attacked at every level.

**Psychological Reading:** Pharaoh's confession under duress ("I have sinned") followed by immediate regression shows crisis-produced insight that doesn't integrate. The ego under pressure may acknowledge truth but cannot sustain the acknowledgment. Relief erases recognition.

**Ethical Inversion Applied:**
- YHWH's hardening of Pharaoh raises the question: is Pharaoh responsible?
- The text presents both divine hardening AND Pharaoh's choice to "sin yet more"
- Warning is given before the hail—those who respond are spared
- Human response remains possible even within divine purpose
- The magicians' incapacity shows: the system's defenders are now victims

**Modern Equivalent:** Systems under catastrophic pressure may produce temporary acknowledgments of wrong ("I have sinned") that evaporate once pressure eases. Leaders may speak correct words without interior change. And warnings are given—those who heed them are spared; those who "do not set heart to the word" suffer consequences.

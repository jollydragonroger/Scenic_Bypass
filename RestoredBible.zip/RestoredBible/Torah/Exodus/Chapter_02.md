# Exodus Chapter 2: The Birth and Flight of Moses

*From the Hebrew: The Deliverer Preserved*

---

**2:1** And a man of the house of Levi went and took a daughter of Levi.

**2:2** And the woman conceived and bore a son; and she saw him that he was good—כִּי־טוֹב הוּא (ki-tov hu)—and she hid him three months.

**2:3** And when she could no longer hide him, she took for him an ark of papyrus—תֵּבַת גֹּמֶא (tevat gome)—and daubed it with bitumen and with pitch; and she put the child in it and placed it among the reeds—בַּסּוּף (ba-suf)—by the bank of the River.

**2:4** And his sister stood at a distance to know what would be done to him.

**2:5** And the daughter of Pharaoh came down to bathe at the River; and her maidens walked along by the riverside. And she saw the ark among the reeds and sent her maid to fetch it.

**2:6** And she opened it and saw the child; and behold, the boy was weeping. And she had compassion on him—וַתַּחְמֹל עָלָיו (va-tachmol alav)—and said: "This is one of the Hebrews' children."

**2:7** And his sister said unto Pharaoh's daughter: "Shall I go and call for you a nurse of the Hebrew women, that she may nurse the child for you?"

**2:8** And Pharaoh's daughter said unto her: "Go." And the maiden went and called the child's mother.

**2:9** And Pharaoh's daughter said unto her: "Take this child and nurse him for me, and I will give you your wages." And the woman took the child and nursed him.

**2:10** And the child grew, and she brought him unto Pharaoh's daughter, and he became her son. And she called his name Moses—מֹשֶׁה (Mosheh)—and said: "Because I drew him—מְשִׁיתִהוּ (meshitihu)—from the water."

---

**2:11** And it came to pass in those days, when Moses was grown, that he went out unto his brothers and looked upon their burdens; and he saw an Egyptian man striking a Hebrew man, one of his brothers.

**2:12** And he turned this way and that, and saw that there was no one; and he struck the Egyptian and hid him in the sand.

**2:13** And he went out the second day, and behold, two Hebrew men were fighting; and he said to the one who was in the wrong: "Why do you strike your fellow?"

**2:14** And the man said: "Who made you a prince and a judge over us—מִי שָׂמְךָ לְאִישׁ שַׂר וְשֹׁפֵט עָלֵינוּ (mi samcha le-ish sar ve-shofet aleinu)? Do you intend to kill me as you killed the Egyptian?" And Moses was afraid and said: "Surely the thing is known."

**2:15** And Pharaoh heard this thing and sought to kill Moses. And Moses fled from before Pharaoh and dwelt in the land of Midian; and he sat down by a well.

**2:16** And the priest of Midian had seven daughters; and they came and drew water and filled the troughs to water their father's flock.

**2:17** And the shepherds came and drove them away; but Moses arose and saved them—וַיּוֹשִׁעָן (va-yoshi'an)—and watered their flock.

**2:18** And they came to Reuel—רְעוּאֵל (Re'uel)—their father, and he said: "How is it that you have come so quickly today?"

**2:19** And they said: "An Egyptian man—אִישׁ מִצְרִי (ish Mitsri)—delivered us from the hand of the shepherds, and also drew water for us and watered the flock."

**2:20** And he said unto his daughters: "And where is he? Why is it that you have left the man? Call him, that he may eat bread."

**2:21** And Moses was content to dwell with the man; and he gave Moses Zipporah—צִפֹּרָה (Tsipporah)—his daughter.

**2:22** And she bore a son, and he called his name Gershom—גֵּרְשֹׁם (Gershom)—for he said: "I have been a stranger—גֵּר (ger)—in a foreign land."

---

**2:23** And it came to pass in the course of those many days that the king of Egypt died; and the children of Israel groaned—וַיֵּאָנְחוּ (va-ye'anechu)—because of the bondage, and they cried out; and their cry for help—שַׁוְעָתָם (shav'atam)—went up unto Consciousness because of the bondage.

**2:24** And Consciousness heard their groaning, and Consciousness remembered—וַיִּזְכֹּר (va-yizkor)—the covenant with Abraham, with Isaac, and with Jacob.

**2:25** And Consciousness saw the children of Israel, and Consciousness knew—וַיֵּדַע (va-yeda).

---

## Synthesis Notes

**Key Restorations:**

**The Levite Marriage:**
Neither parent is named initially—just "a man of the house of Levi" and "a daughter of Levi." Later (6:20) they are identified as Amram and Jochebed. The anonymity creates everyman/everywoman resonance; any Israelite family could be the source of deliverance.

**"She Saw That He Was Good" (כִּי־טוֹב הוּא):**
The same language as creation: "And God saw that it was good" (Genesis 1). The child is marked with creational goodness. Some traditions read this as seeing something special—beauty, light, destiny. The mother recognizes the child's significance.

**The Ark (תֵּבָה, tevah):**
The word *tevah* appears only twice in the Bible—here for Moses' basket and for Noah's ark. The connection is deliberate: both are vessels of salvation from water-destruction, both carry the hope of a new beginning.

**The Reeds (סוּף, suf):**
The *suf* (reeds/rushes) will appear again at the *Yam Suf*—the Sea of Reeds (Red Sea). Moses is saved from water among reeds; he will later lead Israel through water among reeds.

**Pharaoh's Daughter:**
She is never named in the Hebrew text (Egyptian tradition and later midrash call her Bithiah or Thermuthis). She is Pharaoh's daughter—the oppressor's child—yet she has compassion. She recognizes the child is Hebrew but saves him anyway. She becomes an agent of subversion within the royal house.

**The Sister's Cleverness:**
Miriam (though unnamed here) arranges for Moses to be nursed by his own mother—who now gets paid by Egypt to raise her own child. The irony: Pharaoh's household funds the raising of their eventual nemesis.

**The Name "Moses" (מֹשֶׁה, Mosheh):**
Pharaoh's daughter gives an etymology: "I drew him (*meshitihu*) from the water." The Hebrew wordplay works, though the form *Mosheh* actually means "one who draws out" (active, not passive). Moses' name prophetically describes his future role—drawing Israel out of Egypt.

**Moses' Identity Crisis:**
Raised as Egyptian royalty, Moses discovers his Hebrew origins. He "goes out unto his brothers"—identifying with the oppressed, not the oppressor.

**The Three Interventions:**
1. **Egyptian strikes Hebrew**: Moses kills the Egyptian (violence against oppressor)
2. **Hebrew strikes Hebrew**: Moses tries to intervene (rejected)
3. **Shepherds oppress women**: Moses saves them (accepted)

The pattern: violence, rejection, acceptance. Moses must fail in Egypt before succeeding in Midian.

**"Who Made You a Prince and Judge?":**
The Hebrew man's challenge cuts deep. Moses has no authority—not from Israel, not from Egypt. He acts on impulse, is rejected, and flees. He will return with divine commission.

**"An Egyptian Man":**
The Midianite women identify Moses as Egyptian. His cultural identity is ambiguous—Hebrew by birth, Egyptian by upbringing, now refugee in Midian. He is a man between worlds.

**Reuel/Jethro:**
Moses' father-in-law has multiple names (Reuel here, Jethro later). *Re'uel* means "friend of God"—a Midianite priest who apparently knows the divine.

**Gershom:**
Moses names his son "Stranger there"—*ger* (stranger) + *sham* (there). Moses identifies as alien, not at home. The name marks his exile identity.

**The Cry Goes Up:**
While Moses shepherds in Midian for years (perhaps 40), Israel groans. Their *shav'ah* (cry for help) rises to heaven. The language echoes the "outcry" of Sodom (Genesis 18:20).

**Consciousness Remembered:**
*Va-yizkor* (וַיִּזְכֹּר)—the same verb used for Noah (Genesis 8:1). Divine remembering is not recall of something forgotten but attention turned toward action. The covenant with Abraham, Isaac, and Jacob is activated.

**Four Divine Verbs:**
The chapter ends with four verbs describing Consciousness:
1. **Heard** (שָׁמַע) their groaning
2. **Remembered** (זָכַר) the covenant
3. **Saw** (רָאָה) the children of Israel
4. **Knew** (יָדַע)—the verse simply ends: "and Consciousness knew"

What did Consciousness know? The verb stands without object—complete knowing, intimate awareness. The stage is set for action.

**Archetypal Layer:** Moses' journey follows the hero pattern—miraculous birth/preservation, dual identity, failed first attempt, exile, and preparation for call. The water imagery (saved from Nile, sitting by well, watering flocks) prefigures his relationship with water throughout the narrative.

**Psychological Reading:** Moses must fail as a self-appointed liberator before succeeding as a divinely commissioned one. His impulsive violence and subsequent rejection send him to the wilderness where he will be shaped. The ego's attempt at liberation fails; divine calling succeeds.

**Ethical Inversion Applied:**
- The oppressor's daughter becomes the savior of the liberator
- The Egyptian-raised man identifies with the slaves
- The violent intervention fails; the compassionate intervention at the well succeeds
- Those at the bottom of the system (slave infant, midwives, daughter who disobeys) are the instruments of revolution

**Modern Equivalent:** Identity is complex—Moses is Hebrew, Egyptian, and Midianite. His first attempt at justice (killing the oppressor) fails and creates danger. True liberation requires calling, preparation, and right timing. The groaning of the oppressed rises until it cannot be ignored.

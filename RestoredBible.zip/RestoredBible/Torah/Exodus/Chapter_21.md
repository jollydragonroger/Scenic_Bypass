# Exodus Chapter 21: The Book of the Covenant — Laws on Persons

*From the Hebrew: מִּשְׁפָּטִים (Mishpatim) — Ordinances*

---

**21:1** "And these are the ordinances—הַמִּשְׁפָּטִים (ha-mishpatim)—which you shall set before them:

---

**21:2** "If you buy a Hebrew servant—עֶבֶד עִבְרִי (eved Ivri)—six years he shall serve; and in the seventh he shall go out free, for nothing.

**21:3** "If he came in by himself, he shall go out by himself; if he is married, then his wife shall go out with him.

**21:4** "If his master gives him a wife and she bears him sons or daughters, the wife and her children shall be her master's, and he shall go out by himself.

**21:5** "But if the servant shall plainly say, 'I love my master, my wife, and my children; I will not go out free'—

**21:6** "Then his master shall bring him unto the judges—הָאֱלֹהִים (ha-Elohim)—and shall bring him to the door or unto the doorpost; and his master shall pierce his ear with an awl—מַרְצֵעַ (martse'a); and he shall serve him forever.

**21:7** "And if a man sells his daughter as a maidservant—אָמָה (amah)—she shall not go out as the male servants go out.

**21:8** "If she is displeasing in the eyes of her master who designated her for himself, then he shall let her be redeemed; he shall have no power to sell her unto a foreign people, seeing that he has dealt deceitfully with her.

**21:9** "And if he designates her for his son, he shall deal with her according to the manner of daughters.

**21:10** "If he takes another wife, he shall not diminish her food, her clothing, or her conjugal rights—עֹנָתָהּ (onatah).

**21:11** "And if he does not do these three unto her, then she shall go out free, without money.

---

**21:12** "Whoever strikes a man so that he dies shall surely be put to death.

**21:13** "But if he did not lie in wait and Consciousness delivered him into his hand, then I will appoint you a place where he may flee.

**21:14** "But if a man comes presumptuously upon his neighbor to kill him with cunning, you shall take him from my altar to die.

**21:15** "And whoever strikes his father or his mother shall surely be put to death.

**21:16** "And whoever kidnaps a man—וְגֹנֵב אִישׁ (ve-gonev ish)—whether he sells him or he is found in his hand, shall surely be put to death.

**21:17** "And whoever curses his father or his mother shall surely be put to death.

**21:18** "And if men quarrel, and one strikes the other with a stone or with his fist, and he does not die but takes to his bed—

**21:19** "If he rises and walks about outside upon his staff, then the one who struck him shall be acquitted; only he shall pay for his loss of time and shall cause him to be thoroughly healed.

**21:20** "And if a man strikes his servant or his maidservant with a rod, and he dies under his hand, he shall surely be avenged.

**21:21** "But if he survives a day or two, he shall not be avenged; for he is his property—כַּסְפּוֹ (kaspo).

**21:22** "And if men strive together, and strike a pregnant woman so that her children come out, and there is no harm, he shall surely be fined according as the woman's husband shall lay upon him; and he shall pay as the judges determine.

**21:23** "But if there is harm, then you shall give life for life—נֶפֶשׁ תַּחַת נָפֶשׁ (nefesh tachat nafesh)—

**21:24** "Eye for eye, tooth for tooth, hand for hand, foot for foot,

**21:25** "Burning for burning, wound for wound, stripe for stripe.

**21:26** "And if a man strikes the eye of his servant or the eye of his maidservant and destroys it, he shall let him go free for his eye's sake.

**21:27** "And if he knocks out his servant's tooth or his maidservant's tooth, he shall let him go free for his tooth's sake.

---

**21:28** "And if an ox gores a man or a woman so that they die, the ox shall surely be stoned, and its flesh shall not be eaten; but the owner of the ox shall be acquitted.

**21:29** "But if the ox was accustomed to gore in time past, and its owner was warned but did not keep it in, and it kills a man or a woman, the ox shall be stoned, and its owner also shall be put to death.

**21:30** "If a ransom is laid upon him, then he shall give for the redemption of his life whatever is laid upon him.

**21:31** "Whether it has gored a son or has gored a daughter, according to this judgment shall it be done unto him.

**21:32** "If the ox gores a male servant or a female servant, he shall give unto their master thirty shekels of silver—שְׁלֹשִׁים שְׁקָלִים כֶּסֶף (sheloshim sheqalim kesef)—and the ox shall be stoned.

**21:33** "And if a man opens a pit, or if a man digs a pit and does not cover it, and an ox or a donkey falls into it,

**21:34** "The owner of the pit shall make restitution; he shall give money unto its owner, and the dead beast shall be his.

**21:35** "And if one man's ox hurts another's ox so that it dies, then they shall sell the live ox and divide its price; and the dead one also they shall divide.

**21:36** "Or if it is known that the ox was accustomed to gore in time past, and its owner did not keep it in, he shall surely pay ox for ox, and the dead one shall be his own."

---

## Synthesis Notes

**Key Restorations:**

**The Mishpatim (Ordinances):**
These are case laws—specific applications of general principles. They follow the pattern: "If X occurs, then Y is the consequence." This is ancient Near Eastern legal form, paralleled in Hammurabi's Code and other collections.

**Hebrew Servitude:**
The laws begin with slavery—Israel, recently liberated from slavery, now regulates it. Key provisions:
- Six years maximum, then freedom
- Go out as you came in (marital status)
- Option to remain permanently (ear-piercing ritual)

This is not chattel slavery as later practiced; it is term servitude, often for debt. But it is still problematic from modern perspective.

**The Female Servant:**
Different rules apply. A father might sell his daughter as a potential wife for the buyer or buyer's son. She has protections:
- Cannot be sold to foreigners
- If designated for the son, treated as daughter
- If another wife is taken, her rights continue
- If rights are violated, she goes free

These laws ameliorate but do not abolish a patriarchal system.

**Capital Offenses:**
- Murder (premeditated killing)
- Kidnapping
- Striking parents
- Cursing parents

The distinction between intentional and unintentional killing is established. Cities of refuge will be designated for accidental death.

**"Consciousness Delivered Him Into His Hand":**
Accidental death is attributed to divine providence. The killer who did not intend death may flee to a sanctuary.

**"Take Him from My Altar":**
Even the altar (sanctuary) provides no refuge for premeditated murder. The killer cannot claim sacred asylum.

**Assault and Liability:**
The laws establish graduated liability:
- Fatal assault = death penalty
- Non-fatal assault = pay medical costs and lost wages
- Assault on a servant that kills = "avenging" (punishment)
- Assault on a servant that doesn't kill immediately = no punishment ("for he is his property")

This last provision is troubling—servants are property. The law restrains violence (you cannot kill with impunity) but does not abolish the property status.

**The Lex Talionis (21:23-25):**
"Eye for eye, tooth for tooth"—the law of proportional justice. This is often misread as primitive vengeance. Its actual function is **limitation**: the punishment must not exceed the crime. You cannot take a life for an eye. Proportionality restrains revenge.

Jewish tradition interpreted this as monetary compensation equivalent to the injury, not literal retaliation.

**Slaves Who Lose Eye or Tooth:**
If a master permanently injures a servant's eye or tooth, the servant goes free. Bodily injury earns freedom. This incentivizes restraint—violence costs the master the servant.

**The Goring Ox:**
These laws establish owner liability:
- First offense by the ox: ox dies, owner acquitted
- Known dangerous ox: owner is liable for death penalty or ransom
- Ox gores a servant: owner pays 30 shekels (later the price of Judas's betrayal, Matthew 26:15)

**The Open Pit:**
Creating a hazard creates liability. The pit-digger is responsible for animals that fall in. Property owners are responsible for dangers on their property.

**Archetypal Layer:** The Book of the Covenant moves from thunderous theophany to practical case law. The holy descends into the mundane. **The mountain becomes the marketplace.** Divine revelation addresses oxen, pits, and servitude. Nothing is too ordinary for covenantal concern.

**Ethical Inversion Applied:**

These laws present genuine difficulty for "ethical inversion" because they include:
- Slavery (regulated but not abolished)
- Death penalty for cursing parents
- Servants as "property" (*kaspo*, "his money")

**The restoration acknowledges tension:**
- These laws were progressive *for their time*—limiting slavery to six years, protecting female servants, establishing proportional justice
- They are not the final ethical word—prophets will later critique slavery (Jeremiah 34), and Jesus will reinterpret the lex talionis (Matthew 5:38-39)
- The trajectory points toward liberation, even if the text remains within its ancient context

**The moral center is not static law but the God who liberates.** Laws that once improved conditions become inadequate as the trajectory continues.

**Modern Equivalent:** All legal systems reflect their context. What was once progressive becomes inadequate. The principle of proportional justice (lex talionis) remains valid—punishment should fit the crime. The principle of owner liability (the pit, the ox) remains valid—you are responsible for hazards you create. But the toleration of servitude belongs to a stage that liberation has moved beyond.

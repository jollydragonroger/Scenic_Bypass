# Exodus Chapter 37: The Ark and the Furnishings

*From the Hebrew: Bezalel's Work*

---

**37:1** And Bezalel made the ark of acacia wood; two and a half cubits was its length, and a cubit and a half its breadth, and a cubit and a half its height.

**37:2** And he overlaid it with pure gold inside and outside, and made a molding of gold for it round about.

**37:3** And he cast for it four rings of gold, for its four feet; two rings on one side of it, and two rings on the other side of it.

**37:4** And he made poles of acacia wood and overlaid them with gold.

**37:5** And he put the poles into the rings on the sides of the ark, to carry the ark.

**37:6** And he made a mercy seat of pure gold; two and a half cubits its length, and a cubit and a half its breadth.

**37:7** And he made two cherubim of gold; of hammered work he made them, at the two ends of the mercy seat:

**37:8** One cherub at one end, and one cherub at the other end; of one piece with the mercy seat he made the cherubim at its two ends.

**37:9** And the cherubim spread out their wings on high, covering the mercy seat with their wings, with their faces toward each other; toward the mercy seat were the faces of the cherubim.

---

**37:10** And he made the table of acacia wood; two cubits its length, and a cubit its breadth, and a cubit and a half its height.

**37:11** And he overlaid it with pure gold, and made a molding of gold for it round about.

**37:12** And he made for it a border of a handbreadth round about, and made a molding of gold for its border round about.

**37:13** And he cast for it four rings of gold, and put the rings in the four corners that were on its four legs.

**37:14** Close by the border were the rings, as holders for the poles to carry the table.

**37:15** And he made the poles of acacia wood, and overlaid them with gold, to carry the table.

**37:16** And he made the vessels which were upon the table: its dishes and its spoons and its bowls and its jars, with which to pour out, of pure gold.

---

**37:17** And he made the lampstand of pure gold; of hammered work he made the lampstand, its base and its shaft; its cups, its buds, and its flowers were of one piece with it.

**37:18** And six branches went out of its sides: three branches of the lampstand out of one side of it, and three branches of the lampstand out of the other side of it.

**37:19** Three cups made like almond blossoms in one branch, with a bud and a flower; and three cups made like almond blossoms in the other branch, with a bud and a flower—so for the six branches going out of the lampstand.

**37:20** And in the lampstand were four cups made like almond blossoms, with their buds and their flowers;

**37:21** And a bud under two branches of one piece with it, and a bud under two branches of one piece with it, and a bud under two branches of one piece with it, for the six branches going out of it.

**37:22** Their buds and their branches were of one piece with it; the whole of it was one piece of hammered work of pure gold.

**37:23** And he made its seven lamps, and its tongs, and its trays, of pure gold.

**37:24** Of a talent of pure gold he made it, and all its vessels.

---

**37:25** And he made the altar of incense of acacia wood; a cubit its length, and a cubit its breadth—square—and two cubits its height; its horns were of one piece with it.

**37:26** And he overlaid it with pure gold: its top and its sides round about, and its horns; and he made for it a molding of gold round about.

**37:27** And he made for it two golden rings under its molding, on its two sides, on its two opposite sides, as holders for poles with which to carry it.

**37:28** And he made the poles of acacia wood, and overlaid them with gold.

**37:29** And he made the holy anointing oil and the pure fragrant incense, the work of the perfumer.

---

## Synthesis Notes

**Key Restorations:**

**Bezalel Makes the Ark:**
The most sacred object is made first. Bezalel personally crafts the ark—acacia wood overlaid with gold inside and out. The poles remain in the rings; the ark is always ready to move.

**The Mercy Seat and Cherubim:**
Hammered from one piece of gold—the cherubim are not attached but formed from the same metal as the mercy seat. They face each other, wings spread, covering the seat. This is the place of meeting (25:22).

**The Table of Showbread:**
Gold-overlaid acacia, with vessels for the bread of presence. The dishes, spoons, bowls, and jars are pure gold. Twelve loaves will be placed here weekly.

**The Menorah:**
Hammered from a single talent of pure gold (approximately 75 pounds):
- Central shaft with three branches on each side
- Almond blossom design (cups, buds, flowers)
- Seven lamps on top

The menorah is a stylized tree—almond blossoms, branches, buds. It represents life, light, the tree of life restored. The almond (*shaqed*) is the "watching tree" (Jeremiah 1:11-12)—first to bloom, symbol of watchfulness.

**The Altar of Incense:**
Smaller than the bronze altar (1 × 1 × 2 cubits), overlaid with pure gold. Its horns are part of the same piece. Poles for carrying. This altar stands before the veil, nearest to the holy of holies.

**The Anointing Oil and Incense:**
Bezalel also makes the sacred compounds—the anointing oil (30:22-25) and the incense (30:34-38). These are not just furniture but sacred substances.

**Consistent Pattern:**
Each object is described in the same sequence as its command (chapters 25, 30). The obedience is meticulous. Nothing is omitted; nothing is added.

**Archetypal Layer:** The ark is the **throne of the invisible God**—the cherubim are the throne guardians, the mercy seat is the footstool. The menorah is the **tree of life**—seven lights, almond blossoms, life and light together. The table represents **ongoing provision**—bread continually before YHWH. The incense altar is **prayer rising**—fragrance ascending.

Together these furnishings create a microcosm:
- Ark = throne/presence
- Menorah = life/light
- Table = provision
- Incense altar = communication (prayer)

**Psychological Reading:** The careful craftsmanship models attention. Each detail matters. The hammering from one piece (cherubim, menorah) represents integration—parts that belong together, not assembled but formed as one.

**Ethical Inversion Applied:**
- The ark is made by human hands but houses divine presence
- The menorah is tree-shaped—Eden's tree restored in gold
- The incense altar stands nearest the holy of holies—prayer approaches the center
- One talent of gold for the menorah—extraordinary investment in light
- Sacred substances (oil, incense) are crafted with the same care as furniture

**Modern Equivalent:** The most important work often goes unseen. The ark is made for the most holy place where only the high priest enters once a year. The menorah gives light in the sanctuary where ordinary people never go. The investment is in the presence, not the publicity.

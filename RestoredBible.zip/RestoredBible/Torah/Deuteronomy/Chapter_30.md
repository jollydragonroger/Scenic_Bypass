# Deuteronomy Chapter 30: Restoration and the Choice of Life

*From the Hebrew: וּבָחַרְתָּ בַּחַיִּים (U-Vacharta Ba-Chayyim) — Choose Life*

---

**30:1** "And it shall come to pass, when all these things have come upon you, the blessing and the curse, which I have set before you, and you shall call them to mind among all the nations, where YHWH your Consciousness has driven you,

**30:2** "And shall return unto YHWH your Consciousness, and shall listen to his voice according to all that I command you this day, you and your children, with all your heart, and with all your soul;

**30:3** "That then YHWH your Consciousness will turn your captivity, and have compassion upon you, and will return and gather you from all the peoples, where YHWH your Consciousness has scattered you.

**30:4** "If any of you that are scattered be in the uttermost parts of heaven, from there will YHWH your Consciousness gather you, and from there will he fetch you.

**30:5** "And YHWH your Consciousness will bring you into the land which your fathers possessed, and you shall possess it; and he will do you good, and multiply you above your fathers.

**30:6** "And YHWH your Consciousness will circumcise your heart, and the heart of your seed, to love YHWH your Consciousness with all your heart, and with all your soul, that you may live—וּמָל יהוה אֱלֹהֶיךָ אֶת־לְבָבְךָ (u-mal YHWH Eloheicha et-levavecha).

**30:7** "And YHWH your Consciousness will put all these curses upon your enemies, and on those who hate you, who persecuted you.

**30:8** "And you shall return and listen to the voice of YHWH, and do all his commandments which I command you this day.

**30:9** "And YHWH your Consciousness will make you over-abundant in all the work of your hand, in the fruit of your body, and in the fruit of your cattle, and in the fruit of your land, for good; for YHWH will again rejoice over you for good, as he rejoiced over your fathers;

**30:10** "If you shall listen to the voice of YHWH your Consciousness, to keep his commandments and his statutes which are written in this book of the law; if you turn unto YHWH your Consciousness with all your heart, and with all your soul.

---

**30:11** "For this commandment which I command you this day, it is not too hard for you, neither is it far off.

**30:12** "It is not in heaven, that you should say: 'Who shall go up for us to heaven, and bring it unto us, and make us hear it, that we may do it?'

**30:13** "Neither is it beyond the sea, that you should say: 'Who shall go over the sea for us, and bring it unto us, and make us hear it, that we may do it?'

**30:14** "But the word is very near unto you, in your mouth, and in your heart, that you may do it—כִּי־קָרוֹב אֵלֶיךָ הַדָּבָר מְאֹד בְּפִיךָ וּבִלְבָבְךָ לַעֲשֹׂתוֹ (ki-qarov eleicha ha-davar me'od be-ficha u-vi-levavecha la'asoto).

---

**30:15** "See, I have set before you this day life and good, and death and evil,

**30:16** "In that I command you this day to love YHWH your Consciousness, to walk in his ways, and to keep his commandments and his statutes and his ordinances; then you shall live and multiply, and YHWH your Consciousness shall bless you in the land into which you go in to possess it.

**30:17** "But if your heart turns away, and you will not hear, but shall be drawn away, and worship other gods, and serve them;

**30:18** "I declare unto you this day, that you shall surely perish; you shall not prolong your days upon the land, into which you pass over the Jordan to go in to possess it.

**30:19** "I call heaven and earth to witness against you this day, that I have set before you life and death, the blessing and the curse; therefore choose life, that you may live, you and your seed—וּבָחַרְתָּ בַּחַיִּים לְמַעַן תִּחְיֶה אַתָּה וְזַרְעֶךָ (u-vacharta ba-chayyim lema'an tichyeh attah ve-zar'echa);

**30:20** "To love YHWH your Consciousness, to listen to his voice, and to cleave unto him; for he is your life, and the length of your days; that you may dwell in the land which YHWH swore unto your fathers, to Abraham, to Isaac, and to Jacob, to give them."

---

## Synthesis Notes

**Key Restorations:**

**The Promise of Restoration (30:1-10):**
After blessing and curse have both come—after exile—there is still hope:

1. Israel will "call them to mind" (reflect) among the nations
2. Israel will "return unto YHWH" (repent) with all heart and soul
3. YHWH will "turn your captivity" (restore)
4. YHWH will "gather you from all the peoples"
5. Even from "the uttermost parts of heaven"—the ends of the earth
6. YHWH will bring them back to the land
7. YHWH will "circumcise your heart"

**Heart Circumcision:**
*U-mal YHWH Eloheicha et-levavecha*—"YHWH your Consciousness will circumcise your heart."

In 10:16, Moses commanded: "Circumcise the foreskin of your heart." Here, YHWH promises to do it himself. What was commanded becomes gift. External requirement becomes internal transformation.

This is the new covenant vision: God changes the heart (Jeremiah 31:31-34; Ezekiel 36:26-27).

**Curses Transferred:**
The curses that fell on Israel will be redirected to their enemies and persecutors. The judgment reverses.

**YHWH Rejoices Again:**
"YHWH will again rejoice over you for good, as he rejoiced over your fathers." The joy of blessing returns after the grief of judgment.

**The Nearness of the Word (30:11-14):**

The commandment is not:
- **Too hard** (*niflet*)—beyond your ability
- **Far off**—requiring a quest
- **In heaven**—needing someone to ascend
- **Beyond the sea**—needing someone to cross

Instead: "The word is very near unto you, in your mouth, and in your heart, that you may do it."

The Torah is accessible, internalized, doable. This is not about ease but about availability.

**Paul's Use:**
Romans 10:6-8 applies this passage to faith in Christ. The word near in mouth and heart becomes confession and belief.

**The Choice (30:15-20):**

**Two Options:**
| Choice | Result |
|--------|--------|
| Life and good | Love YHWH, walk in his ways, keep commandments → live, multiply, be blessed |
| Death and evil | Heart turns away, worship other gods → perish, not prolong days |

**"Choose Life":**
*U-vacharta ba-chayyim*—"Therefore choose life, that you may live, you and your seed."

This is one of the Bible's most famous imperatives. The choice is presented starkly: life or death, blessing or curse. Heaven and earth are called as witnesses.

**"He Is Your Life":**
"To love YHWH your Consciousness, to listen to his voice, and to cleave unto him; for he is your life, and the length of your days."

YHWH is not merely the source of life; he *is* life itself.

**Archetypal Layer:** The chapter moves from **judgment to hope**. Even after the worst curses are fulfilled, restoration is possible. The exile is not the end.

Heart circumcision represents **transformation that God performs**. Human effort commanded what only divine grace accomplishes.

"Choose life" establishes **moral agency**. Despite all the forces shaping human destiny, the choice remains real.

**Psychological Reading:** "The word is very near unto you" counters the excuse that the commandments are impossible or inaccessible. The claim of inability is rejected; the Torah is in mouth and heart.

**Ethical Inversion Applied:**
- After exile, still hope—judgment is not final
- YHWH circumcises the heart—what was commanded becomes gift
- Curses transferred to enemies—reversal of judgment
- "Not too hard, not far off"—accessibility, not impossibility
- "Choose life"—real choice, real consequence
- "He is your life"—YHWH is life itself

**Modern Equivalent:** The promise of restoration after catastrophe has sustained Jewish hope through centuries of exile and persecution. "Choose life" has become a universal ethical principle. And the nearness of the word challenges claims that moral knowledge is inaccessible.

# Deuteronomy Chapter 4: Exhortation to Obey

*From the Hebrew: שְׁמַע יִשְׂרָאֵל (Shema Yisra'el) — Hear, O Israel*

---

**4:1** "And now, O Israel, hearken unto the statutes and unto the ordinances, which I teach you, to do them; that you may live, and go in and possess the land which YHWH, the Consciousness of your fathers, gives you.

**4:2** "You shall not add unto the word which I command you, neither shall you diminish from it, that you may keep the commandments of YHWH your Consciousness which I command you.

**4:3** "Your eyes have seen what YHWH did because of Baal-peor; for all the men who followed Baal-peor, YHWH your Consciousness has destroyed them from the midst of you.

**4:4** "But you who did cleave unto YHWH your Consciousness are alive every one of you this day.

**4:5** "Behold, I have taught you statutes and ordinances, even as YHWH my Consciousness commanded me, that you should do so in the midst of the land into which you go to possess it.

**4:6** "Observe them therefore and do them; for this is your wisdom and your understanding in the sight of the peoples, who, when they hear all these statutes, shall say: 'Surely this great nation is a wise and understanding people.'

**4:7** "For what great nation is there, that has God so near unto them, as YHWH our Consciousness is whenever we call upon him?

**4:8** "And what great nation is there, that has statutes and ordinances so righteous as all this law, which I set before you this day?

---

**4:9** "Only take heed to yourself, and keep your soul diligently, lest you forget the things which your eyes saw, and lest they depart from your heart all the days of your life; but make them known unto your children and your children's children:

**4:10** "The day that you stood before YHWH your Consciousness in Horeb, when YHWH said unto me: 'Assemble me the people, and I will make them hear my words, that they may learn to fear me all the days that they live upon the earth, and that they may teach their children.'

**4:11** "And you came near and stood under the mountain; and the mountain burned with fire unto the heart of heaven, with darkness, cloud, and thick darkness.

**4:12** "And YHWH spoke unto you out of the midst of the fire; you heard the voice of words, but saw no form—תְּמוּנָה (temunah)—only a voice.

**4:13** "And he declared unto you his covenant, which he commanded you to perform, even the ten words—עֲשֶׂרֶת הַדְּבָרִים (aseret ha-devarim); and he wrote them upon two tables of stone.

**4:14** "And YHWH commanded me at that time to teach you statutes and ordinances, that you might do them in the land into which you go over to possess it.

---

**4:15** "Take therefore good heed unto yourselves—for you saw no manner of form on the day that YHWH spoke unto you in Horeb out of the midst of the fire—

**4:16** "Lest you deal corruptly, and make yourselves a graven image, even the form of any figure, the likeness of male or female,

**4:17** "The likeness of any beast that is on the earth, the likeness of any winged fowl that flies in the heavens,

**4:18** "The likeness of anything that creeps on the ground, the likeness of any fish that is in the water under the earth;

**4:19** "And lest you lift up your eyes unto heaven, and when you see the sun and the moon and the stars, all the host of heaven, you be drawn away and worship them, and serve them, which YHWH your Consciousness has allotted unto all the peoples under the whole heaven.

**4:20** "But you has YHWH taken, and brought forth out of the iron furnace, out of Egypt, to be unto him a people of inheritance, as at this day.

---

**4:21** "Now YHWH was angry with me for your sakes, and swore that I should not go over the Jordan, and that I should not go in unto that good land, which YHWH your Consciousness gives you for an inheritance.

**4:22** "But I must die in this land, I must not go over the Jordan; but you are to go over, and possess that good land.

**4:23** "Take heed unto yourselves, lest you forget the covenant of YHWH your Consciousness, which he made with you, and make yourselves a graven image in the form of anything which YHWH your Consciousness has forbidden you.

**4:24** "For YHWH your Consciousness is a devouring fire—אֵשׁ אֹכְלָה (esh ochelah)—a jealous God.

---

**4:25** "When you shall beget children, and children's children, and you shall have been long in the land, and shall deal corruptly, and make a graven image in the form of anything, and shall do what is evil in the sight of YHWH your Consciousness, to provoke him;

**4:26** "I call heaven and earth to witness against you this day, that you shall soon utterly perish from off the land into which you go over the Jordan to possess it; you shall not prolong your days upon it, but shall utterly be destroyed.

**4:27** "And YHWH shall scatter you among the peoples, and you shall be left few in number among the nations, where YHWH shall lead you away.

**4:28** "And there you shall serve gods, the work of men's hands, wood and stone, which neither see, nor hear, nor eat, nor smell.

**4:29** "But from there you shall seek YHWH your Consciousness, and you shall find him, if you search after him with all your heart and with all your soul.

**4:30** "In your distress, when all these things have come upon you, in the end of days—בְּאַחֲרִית הַיָּמִים (be-acharit ha-yamim)—you will return to YHWH your Consciousness, and listen to his voice.

**4:31** "For YHWH your Consciousness is a merciful God—אֵל רַחוּם (El rachum); he will not fail you, neither destroy you, nor forget the covenant of your fathers which he swore unto them.

---

**4:32** "For ask now of the days past, which were before you, since the day that God created man upon the earth, and from the one end of heaven unto the other, whether there has been any such thing as this great thing, or has been heard like it?

**4:33** "Did ever a people hear the voice of God speaking out of the midst of the fire, as you have heard, and live?

**4:34** "Or has God tried to go and take him a nation from the midst of another nation, by trials, by signs, and by wonders, and by war, and by a mighty hand, and by an outstretched arm, and by great terrors, according to all that YHWH your Consciousness did for you in Egypt before your eyes?

**4:35** "Unto you it was shown, that you might know that YHWH, he is God; there is none else beside him—אֵין עוֹד מִלְּבַדּוֹ (ein od milvado).

**4:36** "Out of heaven he made you to hear his voice, that he might instruct you; and upon earth he made you to see his great fire; and you heard his words out of the midst of the fire.

**4:37** "And because he loved your fathers, and chose their seed after them, and brought you out with his presence, with his great power, out of Egypt,

**4:38** "To drive out nations from before you greater and mightier than you, to bring you in, to give you their land for an inheritance, as at this day;

**4:39** "Know this day, and lay it to your heart, that YHWH, he is God in heaven above and upon the earth beneath; there is none else—אֵין עוֹד (ein od).

**4:40** "And you shall keep his statutes, and his commandments, which I command you this day, that it may go well with you, and with your children after you, and that you may prolong your days upon the land, which YHWH your Consciousness gives you, forever."

---

**4:41** Then Moses set apart three cities beyond the Jordan toward the sunrise;

**4:42** That the manslayer might flee there, who kills his neighbor unawares, and hated him not in time past; and that fleeing unto one of these cities he might live:

**4:43** Bezer in the wilderness, in the table-land, for the Reubenites; and Ramoth in Gilead, for the Gadites; and Golan in Bashan, for the Manassites.

---

**4:44** And this is the law which Moses set before the children of Israel;

**4:45** These are the testimonies, and the statutes, and the ordinances, which Moses spoke unto the children of Israel, when they came forth out of Egypt;

**4:46** Beyond the Jordan, in the valley over against Beth-peor, in the land of Sihon king of the Amorites, who dwelt at Heshbon, whom Moses and the children of Israel smote, when they came forth out of Egypt;

**4:47** And they took his land in possession, and the land of Og king of Bashan, the two kings of the Amorites, who were beyond the Jordan toward the sunrise;

**4:48** From Aroer, which is on the edge of the valley of the Arnon, even unto Mount Sion—the same is Hermon—

**4:49** And all the Arabah beyond the Jordan eastward, even unto the sea of the Arabah, under the slopes of Pisgah.

---

## Synthesis Notes

**Key Restorations:**

**The Call to Obey:**
"That you may live, and go in and possess the land." Obedience is the condition for flourishing. The statutes lead to life.

**No Addition or Subtraction:**
"You shall not add unto the word... neither shall you diminish from it." The commandments are complete; human editing is forbidden.

**Israel's Distinctiveness:**
- "What great nation has God so near unto them?"—YHWH's accessibility
- "What great nation has statutes and ordinances so righteous?"—the law's excellence

The nations will recognize Israel's wisdom through the law.

**Remember Horeb:**
The Sinai experience must be transmitted to children and grandchildren:
- The mountain burning with fire
- Darkness, cloud, thick darkness
- The voice of words
- No visible form (*temunah*)

**"You Saw No Form":**
This is the theological basis for the image prohibition. YHWH spoke but showed no shape. Therefore no image can represent him. Images reduce the formless to form.

**The Ten Words (עֲשֶׂרֶת הַדְּבָרִים):**
The Hebrew term for the Ten Commandments. Written on two tablets of stone by YHWH himself.

**Forbidden Images:**
The catalog of prohibited representations:
- Male or female figures
- Animals, birds, creeping things, fish
- Sun, moon, stars (the host of heaven)

YHWH "allotted" these to the nations—they worship creation. Israel worships the Creator.

**"Iron Furnace":**
Egypt as a smelting furnace. Israel was refined through suffering. The exodus is purification.

**"Devouring Fire, Jealous God":**
*Esh ochelah, El qanna*—YHWH's nature. He consumes what opposes him; he does not share devotion.

**The Prophecy of Exile and Return:**
Moses foresees:
1. Corruption after long settlement
2. Exile among the nations
3. Serving gods of wood and stone
4. Seeking YHWH in distress
5. Finding him with whole heart
6. Return "in the end of days"

**"YHWH Is a Merciful God":**
*El rachum*—the same God who is devouring fire is also merciful. He will not forget the covenant.

**Theological Claims:**
- "YHWH, he is God; there is none else beside him" (*ein od milvado*)
- "YHWH, he is God in heaven above and upon the earth beneath; there is none else" (*ein od*)

These are explicit monotheistic affirmations.

**The Transjordan Cities of Refuge:**
Moses establishes three refuge cities east of the Jordan:
- **Bezer** (Reuben)
- **Ramoth** (Gad)
- **Golan** (Manasseh)

**Archetypal Layer:** The chapter moves from historical memory (Horeb, Peor) to theological principle (no form, no images) to prophetic vision (exile and return). The structure is comprehensive: past experience → present instruction → future warning → ultimate hope.

**Psychological Reading:** The prohibition of images is grounded in experience: "You saw no form." The commandment is not arbitrary but based on the nature of divine self-revelation. Memory shapes worship.

**Ethical Inversion Applied:**
- "That you may live"—obedience leads to flourishing
- No addition or subtraction—the word is complete
- "You saw no form"—experience grounds the image prohibition
- Devouring fire AND merciful God—YHWH holds both
- Exile foreseen, return promised—judgment is not final

**Modern Equivalent:** The prohibition on adding or subtracting from the word challenges both legalistic addition and liberal subtraction. The experience-based theology (no form seen, therefore no image made) models how encounter shapes doctrine. And the exile-return pattern assures that even severe judgment is not the end of the story.

# Deuteronomy Chapter 13: False Prophets and Enticement to Idolatry

*From the Hebrew: נָבִיא שֶׁקֶר (Navi Sheqer) — The False Prophet*

---

**13:1** "If there arises in the midst of you a prophet, or a dreamer of dreams, and he gives you a sign or a wonder,

**13:2** "And the sign or the wonder comes to pass, of which he spoke unto you, saying: 'Let us go after other gods, which you have not known, and let us serve them';

**13:3** "You shall not listen to the words of that prophet, or to that dreamer of dreams; for YHWH your Consciousness is testing you, to know whether you love YHWH your Consciousness with all your heart and with all your soul.

**13:4** "After YHWH your Consciousness you shall walk, and him you shall fear, and his commandments you shall keep, and unto his voice you shall listen, and him you shall serve, and unto him you shall cleave.

**13:5** "And that prophet, or that dreamer of dreams, shall be put to death; because he has spoken rebellion against YHWH your Consciousness, who brought you out of the land of Egypt, and redeemed you out of the house of bondage, to draw you aside out of the way which YHWH your Consciousness commanded you to walk in. So shall you put away the evil from the midst of you.

---

**13:6** "If your brother, the son of your mother, or your son, or your daughter, or the wife of your bosom, or your friend, who is as your own soul, entices you secretly, saying: 'Let us go and serve other gods,' which you have not known, you, nor your fathers;

**13:7** "Of the gods of the peoples who are round about you, near unto you, or far off from you, from the one end of the earth even unto the other end of the earth;

**13:8** "You shall not consent unto him, nor listen to him; neither shall your eye pity him, neither shall you spare, neither shall you conceal him;

**13:9** "But you shall surely kill him; your hand shall be first upon him to put him to death, and afterward the hand of all the people.

**13:10** "And you shall stone him with stones, that he die; because he has sought to draw you away from YHWH your Consciousness, who brought you out of the land of Egypt, out of the house of bondage.

**13:11** "And all Israel shall hear, and fear, and shall do no more any such wickedness as this is in the midst of you.

---

**13:12** "If you shall hear tell concerning one of your cities, which YHWH your Consciousness gives you to dwell there, saying:

**13:13** "'Certain base fellows have gone out from the midst of you, and have drawn away the inhabitants of their city, saying: Let us go and serve other gods, which you have not known';

**13:14** "Then you shall inquire, and make search, and ask diligently; and behold, if it is truth, and the thing certain, that such abomination is wrought in the midst of you,

**13:15** "You shall surely smite the inhabitants of that city with the edge of the sword, destroying it utterly—הַחֲרֵם (hacharem)—and all that is therein and the cattle thereof, with the edge of the sword.

**13:16** "And you shall gather all the spoil of it into the midst of the street thereof, and shall burn with fire the city, and all the spoil thereof entirely, unto YHWH your Consciousness; and it shall be a heap forever—תֵּל עוֹלָם (tel olam); it shall not be built again.

**13:17** "And there shall cleave nothing of the devoted thing to your hand, that YHWH may turn from the fierceness of his anger, and show you mercy, and have compassion upon you, and multiply you, as he has sworn unto your fathers;

**13:18** "When you shall listen to the voice of YHWH your Consciousness, to keep all his commandments which I command you this day, to do that which is right in the eyes of YHWH your Consciousness."

---

## Synthesis Notes

**Key Restorations:**

**The False Prophet (13:1-5):**
A prophet or dream-interpreter arises with a sign or wonder—and it comes true. But he says: "Let us go after other gods."

The sign's fulfillment does not validate the message. YHWH is testing Israel: "to know whether you love YHWH your Consciousness with all your heart and with all your soul."

**Truth of Sign ≠ Truth of Message:**
Miraculous signs are not the ultimate criterion. The content of the message matters. If the prophet leads away from YHWH—regardless of signs—he is false.

The false prophet is executed for "speaking rebellion against YHWH."

**The Enticing Relative (13:6-11):**
The enticer may be:
- Brother
- Son or daughter
- Wife
- Closest friend ("who is as your own soul")

If they secretly urge: "Let us go and serve other gods"—

**No pity, no sparing, no concealment.**

The one enticed must be first to execute. Then the community stones the enticer to death.

"All Israel shall hear, and fear"—the punishment is meant to deter.

**The Apostate City (13:12-18):**
If an entire city is seduced by "base fellows" (*benei beliya'al*) to serve other gods:

1. **Investigate thoroughly**—inquire, search, ask diligently
2. **If confirmed**—the city receives *cherem*
3. **Destroy all inhabitants and cattle**
4. **Gather all spoil into the street and burn it**
5. **The city becomes a *tel olam***—a perpetual ruin, never rebuilt
6. **Take nothing of the devoted thing**

**"Nothing of the Devoted Thing":**
The *cherem* is complete. No one may profit from the destruction. The spoil is YHWH's—burned entirely.

**The Purpose:**
"That YHWH may turn from the fierceness of his anger." The extreme action is to restore covenant relationship by removing the corruption.

**Archetypal Layer:** The chapter addresses **internal threats**—the false prophet, the beloved relative, the seduced city. External enemies are less dangerous than internal corruptors. Those closest have the greatest power to lead astray.

The criterion for discerning prophets is **content, not power**. Signs and wonders prove nothing if the message contradicts YHWH's revealed will.

**Psychological Reading:** The requirement to execute a beloved relative (wife, child, closest friend) tests loyalty's absolute nature. Family bonds are strong; covenant bonds must be stronger.

The thorough investigation required for the apostate city ("inquire, make search, ask diligently") prevents rush to judgment. Due process precedes punishment.

**Ethical Inversion Applied:**
- Signs don't validate—content matters more than miracles
- "YHWH is testing you"—false prophets serve a diagnostic purpose
- Closest relationships must not override covenant—no pity, no concealment
- Investigation required—due process before extreme action
- The city becomes permanent ruin—no rebuilding, no profit
- "All Israel shall hear and fear"—public knowledge deters

**Difficult Elements:**
The execution of family members for enticement, and the destruction of entire cities, are deeply troubling commands. The text presents them as necessary to prevent covenant corruption that would ultimately destroy all Israel. The severity reflects the existential threat that idolatry represents in this context.

**Modern Equivalent:** The principle that miracles don't validate false teaching remains relevant—charisma and power are not the criteria for truth. The requirement of thorough investigation before action ("inquire, make search, ask diligently") anticipates due process. And the warning about those closest being most dangerous applies to any relationship of trust.

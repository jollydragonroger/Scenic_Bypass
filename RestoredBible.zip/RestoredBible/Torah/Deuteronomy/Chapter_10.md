# Deuteronomy Chapter 10: The New Tablets and What YHWH Requires

*From the Hebrew: מָה יהוה שֹׁאֵל (Mah YHWH Sho'el) — What YHWH Asks*

---

**10:1** "At that time YHWH said unto me: 'Hew yourself two tables of stone like the first, and come up unto me into the mount, and make yourself an ark of wood.

**10:2** "'And I will write on the tables the words that were on the first tables which you broke, and you shall put them in the ark.'

**10:3** "So I made an ark of acacia wood, and hewed two tables of stone like the first, and went up into the mount, having the two tables in my hand.

**10:4** "And he wrote on the tables, according to the first writing, the ten words—עֲשֶׂרֶת הַדְּבָרִים (aseret ha-devarim)—which YHWH spoke unto you in the mount out of the midst of the fire in the day of the assembly; and YHWH gave them unto me.

**10:5** "And I turned and came down from the mount, and put the tables in the ark which I had made; and there they are, as YHWH commanded me."

---

**10:6** (And the children of Israel journeyed from Beeroth-bene-jaakan to Moserah; there Aaron died, and there he was buried; and Eleazar his son ministered as priest in his place.

**10:7** From there they journeyed unto Gudgodah; and from Gudgodah to Jotbathah, a land of brooks of water.

**10:8** At that time YHWH set apart the tribe of Levi, to carry the ark of the covenant of YHWH, to stand before YHWH to minister unto him, and to bless in his name, unto this day.

**10:9** Therefore Levi has no portion nor inheritance with his brothers; YHWH is his inheritance, as YHWH your Consciousness spoke unto him.)

---

**10:10** "And I stayed in the mount, as at the first time, forty days and forty nights; and YHWH listened unto me that time also; YHWH would not destroy you.

**10:11** "And YHWH said unto me: 'Arise, take your journey before the people, and let them go in and possess the land, which I swore unto their fathers to give unto them.'

---

**10:12** "And now, Israel, what does YHWH your Consciousness require of you, but to fear YHWH your Consciousness, to walk in all his ways, and to love him, and to serve YHWH your Consciousness with all your heart and with all your soul,

**10:13** "To keep the commandments of YHWH, and his statutes, which I command you this day for your good?

**10:14** "Behold, unto YHWH your Consciousness belong the heaven, and the heaven of heavens, the earth, with all that is therein.

**10:15** "Only YHWH had a delight in your fathers to love them, and he chose their seed after them, even you, above all peoples, as at this day.

**10:16** "Circumcise therefore the foreskin of your heart, and be no more stiff-necked—וּמַלְתֶּם אֵת עָרְלַת לְבַבְכֶם (u-maltem et orlat levavchem).

**10:17** "For YHWH your Consciousness, he is God of gods, and Lord of lords, the great God, the mighty, and the awful, who regards not persons, nor takes reward.

**10:18** "He executes justice for the fatherless and widow, and loves the stranger, in giving him food and raiment.

**10:19** "Love therefore the stranger; for you were strangers in the land of Egypt.

**10:20** "You shall fear YHWH your Consciousness; him shall you serve; and to him shall you cleave, and by his name shall you swear.

**10:21** "He is your praise, and he is your God, who has done for you these great and terrible things, which your eyes have seen.

**10:22** "Your fathers went down into Egypt with seventy souls; and now YHWH your Consciousness has made you as the stars of heaven for multitude."

---

## Synthesis Notes

**Key Restorations:**

**The Second Tablets:**
After the golden calf, Moses receives instructions to:
1. Hew two new tablets (Moses prepares the material)
2. Make an ark of acacia wood
3. Ascend the mountain again

YHWH writes the same ten words on the new tablets. The content is unchanged; the covenant is renewed.

**The Ark:**
Moses' simple ark precedes the elaborate ark described in Exodus 25. This wooden box held the tablets until the tabernacle was built.

**Aaron's Death (Parenthetical):**
A brief note about Aaron's death at Moserah (elsewhere called Mount Hor), Eleazar's succession, and the journeys that followed. The Levites' separation "at that time" is noted—their role as ark-carriers and ministers.

**"YHWH Is His Inheritance":**
Levi receives no land because YHWH himself is their portion. They live from the offerings and tithes, sustained by serving the One who sustains all.

**What Does YHWH Require?:**
The great summary of divine expectation:
1. **Fear YHWH**—reverence, awe
2. **Walk in all his ways**—imitation of divine character
3. **Love him**—affection, loyalty
4. **Serve YHWH with all heart and soul**—complete devotion
5. **Keep the commandments**—obedience

"For your good"—the commandments benefit Israel, not YHWH.

**"Heaven of Heavens":**
*Shamei ha-shamayim*—the highest heavens. All creation belongs to YHWH. He needs nothing from Israel. Yet he delighted in the fathers and chose their descendants.

**"Circumcise the Foreskin of Your Heart":**
*U-maltem et orlat levavchem*—a stunning metaphor. Physical circumcision is external; heart circumcision is internal transformation. The stiff neck must bend; the closed heart must open.

This image recurs in Jeremiah 4:4 and is developed by Paul (Romans 2:28-29). External signs are insufficient; inner change is required.

**God of Gods, Lord of Lords:**
YHWH is supreme over all divine beings and all powers. Yet this supreme deity:
- Regards not persons (no favoritism)
- Takes no bribe
- Executes justice for orphan and widow
- Loves the stranger

Power and compassion unite in YHWH.

**Love the Stranger:**
"For you were strangers in the land of Egypt." Israel's experience of vulnerability becomes the ground for ethical treatment of others' vulnerability. Memory shapes ethics.

**Seventy to Stars:**
Jacob's family entered Egypt as seventy souls. Now they are "as the stars of heaven for multitude." The Abrahamic promise (Genesis 15:5) is fulfilled.

**Archetypal Layer:** The chapter moves from **covenant renewal** (new tablets) to **covenant summary** (what YHWH requires). The heart of the matter is not complexity but simplicity: fear, walk, love, serve, keep.

Heart circumcision represents **internal transformation**. External markers (physical circumcision, religious observance) are insufficient without corresponding inner reality.

**Psychological Reading:** The question "What does YHWH require?" implies that the requirements might be overwhelming. The answer is surprisingly focused: fear, love, walk, serve, keep. The emphasis on "for your good" reframes commandments as gift, not burden.

**Ethical Inversion Applied:**
- New tablets replace broken ones—covenant can be renewed after failure
- YHWH is Levi's inheritance—some receive God instead of land
- "What does YHWH require?"—focused summary, not endless complexity
- Circumcise your heart—internal transformation required
- God of gods executes justice for the vulnerable—power serves the weak
- Love the stranger—Israel's memory shapes their ethics

**Modern Equivalent:** The question "What does God require?" remains central. The Deuteronomic answer (fear, love, walk, serve, keep) provides a focused summary. Heart circumcision challenges any religion of external compliance without internal change. And the command to love the stranger because "you were strangers" grounds ethics in historical memory.

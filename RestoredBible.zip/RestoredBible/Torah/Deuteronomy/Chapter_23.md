# Deuteronomy Chapter 23: The Assembly and Miscellaneous Laws

*From the Hebrew: קְהַל יהוה (Qehal YHWH) — The Assembly of YHWH*

---

**23:1** "He who is crushed or maimed in his private parts shall not enter into the assembly of YHWH.

**23:2** "A *mamzer* shall not enter into the assembly of YHWH; even to the tenth generation shall none of his enter into the assembly of YHWH.

**23:3** "An Ammonite or a Moabite shall not enter into the assembly of YHWH; even to the tenth generation shall none of them enter into the assembly of YHWH forever;

**23:4** "Because they did not meet you with bread and with water in the way, when you came forth out of Egypt; and because they hired against you Balaam the son of Beor from Pethor of Aram-naharaim, to curse you.

**23:5** "Nevertheless YHWH your Consciousness would not listen unto Balaam; but YHWH your Consciousness turned the curse into a blessing unto you, because YHWH your Consciousness loved you.

**23:6** "You shall not seek their peace nor their prosperity all your days forever.

**23:7** "You shall not abhor an Edomite, for he is your brother; you shall not abhor an Egyptian, because you were a stranger in his land.

**23:8** "The children of the third generation that are born unto them may enter into the assembly of YHWH.

---

**23:9** "When you go forth in camp against your enemies, then you shall keep yourself from every evil thing.

**23:10** "If there is among you any man, who is not clean by reason of that which chances him by night, then shall he go abroad out of the camp, he shall not come within the camp.

**23:11** "But it shall be, when evening comes on, he shall bathe himself in water; and when the sun is down, he may come within the camp.

**23:12** "You shall have a place also outside the camp, where you shall go forth abroad.

**23:13** "And you shall have a paddle among your weapons; and it shall be, when you sit down abroad, you shall dig with it, and shall turn back and cover that which comes from you.

**23:14** "For YHWH your Consciousness walks in the midst of your camp, to deliver you, and to give up your enemies before you; therefore shall your camp be holy; that he see no unseemly thing in you, and turn away from you.

---

**23:15** "You shall not deliver unto his master a bondman who has escaped from his master unto you.

**23:16** "He shall dwell with you, in the midst of you, in the place which he shall choose within one of your gates, where it pleases him best; you shall not wrong him.

---

**23:17** "There shall be no *qedeshah* of the daughters of Israel, neither shall there be a *qadesh* of the sons of Israel.

**23:18** "You shall not bring the hire of a harlot, or the price of a dog, into the house of YHWH your Consciousness for any vow; for both of these are an abomination unto YHWH your Consciousness.

---

**23:19** "You shall not lend upon interest to your brother: interest of money, interest of food, interest of anything that is lent upon interest.

**23:20** "Unto a foreigner you may lend upon interest; but unto your brother you shall not lend upon interest; that YHWH your Consciousness may bless you in all that you put your hand unto, in the land into which you go in to possess it.

---

**23:21** "When you shall vow a vow unto YHWH your Consciousness, you shall not be slack to pay it; for YHWH your Consciousness will surely require it of you; and it will be sin in you.

**23:22** "But if you shall forbear to vow, it shall be no sin in you.

**23:23** "That which has gone out of your lips you shall observe and do; according as you have vowed freely unto YHWH your Consciousness, even that which you have promised with your mouth.

---

**23:24** "When you come into your neighbor's vineyard, then you may eat grapes until you have enough at your own pleasure; but you shall not put any in your vessel.

**23:25** "When you come into your neighbor's standing grain, then you may pluck ears with your hand; but you shall not move a sickle unto your neighbor's standing grain."

---

## Synthesis Notes

**Key Restorations:**

**Exclusions from the Assembly (23:1-8):**

| Category | Exclusion |
|----------|-----------|
| Crushed/maimed genitals | Permanent |
| *Mamzer* (uncertain meaning—possibly illegitimate or from forbidden union) | To 10th generation |
| Ammonite or Moabite | Forever |
| Edomite | 3rd generation may enter |
| Egyptian | 3rd generation may enter |

**The Ammonite/Moabite Exclusion:**
Two reasons:
1. They did not provide bread and water when Israel passed
2. They hired Balaam to curse Israel

Yet "YHWH turned the curse into a blessing"—Balaam's story is recalled.

**Edomites and Egyptians:**
More favorable treatment:
- Edomites: "he is your brother" (Esau's descendants)
- Egyptians: "you were a stranger in his land"

Their descendants may enter the assembly after three generations.

**Camp Purity (23:9-14):**
In military camp:
- Nocturnal emission: leave camp until evening, bathe, return after sunset
- Designated latrine area outside camp
- Carry a paddle to dig and cover waste

**"YHWH Walks in the Midst of Your Camp":**
The theological rationale: YHWH's presence requires holiness. "That he see no unseemly thing"—even sanitation is theological.

**The Escaped Slave (23:15-16):**
A slave who escapes to Israel:
- Shall not be returned to his master
- May live wherever he chooses
- Shall not be wronged

This is remarkable in the ancient world. Most law codes required return of fugitive slaves. Israel is to be a refuge.

**Cult Prostitution Forbidden (23:17-18):**
- No *qedeshah* (sacred prostitute, female) or *qadesh* (male)
- No bringing prostitute's earnings or "price of a dog" (possibly male prostitute) into the sanctuary

Canaanite fertility cults used sacred prostitution. Israel's worship must be different.

**Interest Prohibition (23:19-20):**
No interest (*neshech*, "bite") on loans to a brother:
- Money, food, or anything else
- Foreigners may be charged interest
- But brothers must lend without profit

This protects the poor from debt spirals within the covenant community.

**Vows (23:21-23):**
- If you vow, fulfill it promptly—YHWH requires it
- If you don't vow, there's no sin
- Once spoken, it must be done

Vows are optional but binding.

**Neighbor's Produce (23:24-25):**
You may eat from a neighbor's vineyard or grain field:
- Grapes: eat your fill, but don't take any away
- Grain: pluck ears by hand, but don't use a sickle

This allows the hungry to eat but protects the owner from theft. Jesus' disciples did this (Mark 2:23).

**Archetypal Layer:** The camp purity laws connect **physical cleanliness to divine presence**. YHWH's walking in the camp makes even waste disposal a sacred matter.

The escaped slave law makes Israel a **sanctuary for the oppressed**—a remarkable counter-cultural provision.

**Psychological Reading:** The interest prohibition addresses the power imbalance in lending. The brother in need should not become prey to the brother with resources.

**Ethical Inversion Applied:**
- Assembly exclusions vary by category—not all are permanent
- "YHWH walks in your camp"—divine presence requires purity
- Escaped slaves protected—Israel is refuge, not returning fugitives
- No cult prostitution—Israel's worship differs from Canaan's
- No interest to brothers—lending must not exploit
- Eat from neighbor's field—hospitality to the hungry, but not theft

**Modern Equivalent:** The escaped slave law anticipates asylum and refuge principles. The interest prohibition influenced medieval Christian and Islamic banking. And the allowance to eat from a neighbor's field balances private property with provision for the hungry.

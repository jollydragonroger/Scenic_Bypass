# Deuteronomy Chapter 27: The Altar on Ebal and the Curses

*From the Hebrew: אָרוּר (Arur) — Cursed*

---

**27:1** And Moses and the elders of Israel commanded the people, saying: "Keep all the commandment which I command you this day.

**27:2** "And it shall be on the day when you shall pass over the Jordan unto the land which YHWH your Consciousness gives you, that you shall set up great stones, and plaster them with plaster.

**27:3** "And you shall write upon them all the words of this law, when you have passed over; that you may go in unto the land which YHWH your Consciousness gives you, a land flowing with milk and honey, as YHWH, the Consciousness of your fathers, has promised you.

**27:4** "And it shall be when you have passed over the Jordan, that you shall set up these stones, which I command you this day, in Mount Ebal, and you shall plaster them with plaster.

**27:5** "And there shall you build an altar unto YHWH your Consciousness, an altar of stones; you shall lift up no iron tool upon them.

**27:6** "You shall build the altar of YHWH your Consciousness of unhewn stones; and you shall offer burnt offerings upon it unto YHWH your Consciousness.

**27:7** "And you shall sacrifice peace offerings, and shall eat there; and you shall rejoice before YHWH your Consciousness.

**27:8** "And you shall write upon the stones all the words of this law very plainly."

---

**27:9** And Moses and the priests the Levites spoke unto all Israel, saying: "Keep silence, and hear, O Israel; this day you have become the people of YHWH your Consciousness.

**27:10** "You shall therefore listen to the voice of YHWH your Consciousness, and do his commandments and his statutes, which I command you this day."

---

**27:11** And Moses charged the people the same day, saying:

**27:12** "These shall stand upon Mount Gerizim to bless the people, when you have passed over the Jordan: Simeon, and Levi, and Judah, and Issachar, and Joseph, and Benjamin.

**27:13** "And these shall stand upon Mount Ebal for the curse: Reuben, Gad, and Asher, and Zebulun, Dan, and Naphtali.

**27:14** "And the Levites shall speak, and say unto all the men of Israel with a loud voice:

---

**27:15** "'Cursed is the man who makes a graven or molten image, an abomination unto YHWH, the work of the hands of the craftsman, and sets it up in secret.' And all the people shall answer and say: 'Amen.'

**27:16** "'Cursed is he who dishonors his father or his mother.' And all the people shall say: 'Amen.'

**27:17** "'Cursed is he who removes his neighbor's landmark.' And all the people shall say: 'Amen.'

**27:18** "'Cursed is he who makes the blind to wander out of the way.' And all the people shall say: 'Amen.'

**27:19** "'Cursed is he who perverts the justice due to the stranger, fatherless, and widow.' And all the people shall say: 'Amen.'

**27:20** "'Cursed is he who lies with his father's wife, because he has uncovered his father's skirt.' And all the people shall say: 'Amen.'

**27:21** "'Cursed is he who lies with any manner of beast.' And all the people shall say: 'Amen.'

**27:22** "'Cursed is he who lies with his sister, the daughter of his father, or the daughter of his mother.' And all the people shall say: 'Amen.'

**27:23** "'Cursed is he who lies with his mother-in-law.' And all the people shall say: 'Amen.'

**27:24** "'Cursed is he who smites his neighbor in secret.' And all the people shall say: 'Amen.'

**27:25** "'Cursed is he who takes a bribe to slay an innocent person.' And all the people shall say: 'Amen.'

**27:26** "'Cursed is he who confirms not the words of this law to do them.' And all the people shall say: 'Amen.'"

---

## Synthesis Notes

**Key Restorations:**

**The Monument (27:1-8):**
Upon crossing the Jordan, Israel shall:
1. Set up large stones
2. Plaster them with plite (lime plaster)
3. Write "all the words of this law" on them
4. Erect them on Mount Ebal
5. Build an altar of unhewn stones (no iron tools)
6. Offer burnt offerings and peace offerings
7. Rejoice

The law is publicly displayed for all to read. The altar confirms the covenant.

**"Unhewn Stones":**
Consistent with Exodus 20:25—iron tools would profane the altar. The stones remain as YHWH made them.

**"This Day You Have Become":**
"This day you have become the people of YHWH your Consciousness." The covenant is ratified; identity is confirmed.

**The Two Mountains (27:11-13):**

**Mount Gerizim (blessing)**—six tribes:
- Simeon, Levi, Judah
- Issachar, Joseph, Benjamin

(Leah's sons plus Rachel's sons)

**Mount Ebal (curse)**—six tribes:
- Reuben, Gad, Asher
- Zebulun, Dan, Naphtali

(Includes the sons of the handmaids and some of Leah's sons)

The two mountains flank the valley of Shechem. Israel stands divided between them, hearing blessing and curse.

**The Twelve Curses (27:15-26):**

| Curse | Category |
|-------|----------|
| Secret idol worship | First commandment |
| Dishonoring parents | Fifth commandment |
| Moving landmark | Property/theft |
| Misleading the blind | Cruelty to vulnerable |
| Perverting justice for stranger/orphan/widow | Social justice |
| Lying with father's wife | Incest |
| Bestiality | Sexual boundary |
| Lying with sister | Incest |
| Lying with mother-in-law | Incest |
| Secret murder | Sixth commandment |
| Taking bribe for murder | Corruption |
| Not confirming this law | Summary |

**The Pattern:**
Many curses address **secret sins**—hidden idols, secret murder, covert injustice. Human courts may not catch these; YHWH's curse does.

**"Amen" (אָמֵן):**
Each curse requires the people's affirmation: "Amen"—"so be it," "truly," "let it stand." The people accept the curse upon themselves if they violate.

**The Final Curse:**
"Cursed is he who confirms not the words of this law to do them." This is comprehensive—anyone who does not uphold the entire law falls under the curse.

Paul quotes this in Galatians 3:10: "Cursed is everyone who does not continue in all things written in the book of the law, to do them."

**Archetypal Layer:** The ceremony creates **dramatic covenant ratification**. Standing between two mountains, hearing curses pronounced, answering "Amen"—the people physically embody their covenant commitment.

The curses address sins that might escape human justice but not divine notice. **Secret sin is still sin.**

**Psychological Reading:** The public "Amen" creates communal accountability. Each person verbally accepts the curse for violation. The ceremony makes abstract law into embodied commitment.

**Ethical Inversion Applied:**
- Law written publicly—everyone can read
- Unhewn stones—the altar is natural, not crafted
- "This day you have become"—identity is declared
- Twelve curses—mostly secret sins
- "Amen" required—personal acceptance of consequences
- The final curse is comprehensive—no partial obedience

**Historical Fulfillment:**
Joshua 8:30-35 records the ceremony's execution. After the conquest of Ai, Joshua built the altar on Ebal, wrote the law on stones, and the people stood divided between the mountains as blessings and curses were read.

**Modern Equivalent:** Public reading of founding documents (constitutions, charters) echoes this ceremony. The "Amen" response anticipates oaths of office or citizenship. And the focus on secret sins addresses the gap between public behavior and private action.

# Deuteronomy Chapter 12: The One Place of Worship

*From the Hebrew: הַמָּקוֹם (HaMaqom) — The Place*

---

**12:1** "These are the statutes and the ordinances which you shall observe to do in the land which YHWH, the Consciousness of your fathers, has given you to possess it, all the days that you live upon the earth.

**12:2** "You shall surely destroy all the places in which the nations that you are to dispossess served their gods, upon the high mountains, and upon the hills, and under every green tree.

**12:3** "And you shall break down their altars, and dash in pieces their pillars, and burn their Asherim with fire; and you shall hew down the graven images of their gods; and you shall destroy their name out of that place.

**12:4** "You shall not do so unto YHWH your Consciousness.

**12:5** "But unto the place which YHWH your Consciousness shall choose out of all your tribes to put his name there, even unto his habitation shall you seek, and there you shall come—אֶל־הַמָּקוֹם אֲשֶׁר־יִבְחַר יהוה (el-ha-maqom asher-yivchar YHWH).

**12:6** "And there you shall bring your burnt offerings, and your sacrifices, and your tithes, and the contribution of your hand, and your vows, and your freewill offerings, and the firstlings of your herd and of your flock.

**12:7** "And there you shall eat before YHWH your Consciousness, and you shall rejoice in all that you put your hand unto, you and your households, in which YHWH your Consciousness has blessed you.

**12:8** "You shall not do after all that we do here this day, every man whatever is right in his own eyes.

**12:9** "For you have not yet come to the rest and to the inheritance, which YHWH your Consciousness gives you.

**12:10** "But when you go over the Jordan, and dwell in the land which YHWH your Consciousness causes you to inherit, and he gives you rest from all your enemies round about, so that you dwell in safety;

**12:11** "Then it shall come to pass that the place which YHWH your Consciousness shall choose to cause his name to dwell there, there shall you bring all that I command you: your burnt offerings, and your sacrifices, your tithes, and the contribution of your hand, and all your choice vows which you vow unto YHWH.

**12:12** "And you shall rejoice before YHWH your Consciousness, you, and your sons, and your daughters, and your men-servants, and your maid-servants, and the Levite who is within your gates, since he has no portion nor inheritance with you.

---

**12:13** "Take heed to yourself that you offer not your burnt offerings in every place that you see;

**12:14** "But in the place which YHWH shall choose in one of your tribes, there you shall offer your burnt offerings, and there you shall do all that I command you.

**12:15** "Nevertheless you may slaughter and eat flesh within all your gates, after all the desire of your soul, according to the blessing of YHWH your Consciousness which he has given you; the unclean and the clean may eat thereof, as of the gazelle, and as of the deer.

**12:16** "Only you shall not eat the blood; you shall pour it out upon the earth as water.

**12:17** "You may not eat within your gates the tithe of your grain, or of your wine, or of your oil, or the firstlings of your herd or of your flock, nor any of your vows which you vow, nor your freewill offerings, nor the contribution of your hand;

**12:18** "But you shall eat them before YHWH your Consciousness in the place which YHWH your Consciousness shall choose, you, and your son, and your daughter, and your man-servant, and your maid-servant, and the Levite who is within your gates; and you shall rejoice before YHWH your Consciousness in all that you put your hand unto.

**12:19** "Take heed to yourself that you forsake not the Levite as long as you live upon your land.

---

**12:20** "When YHWH your Consciousness shall enlarge your border, as he has promised you, and you shall say: 'I will eat flesh,' because your soul desires to eat flesh; you may eat flesh, after all the desire of your soul.

**12:21** "If the place which YHWH your Consciousness shall choose to put his name there is too far from you, then you shall kill of your herd and of your flock, which YHWH has given you, as I have commanded you, and you shall eat within your gates, after all the desire of your soul.

**12:22** "Even as the gazelle and as the deer is eaten, so you shall eat thereof; the unclean and the clean may eat thereof alike.

**12:23** "Only be steadfast in not eating the blood; for the blood is the life—כִּי הַדָּם הוּא הַנָּפֶשׁ (ki ha-dam hu ha-nefesh); and you shall not eat the life with the flesh.

**12:24** "You shall not eat it; you shall pour it out upon the earth as water.

**12:25** "You shall not eat it; that it may go well with you, and with your children after you, when you shall do that which is right in the eyes of YHWH.

**12:26** "Only your holy things which you have, and your vows, you shall take, and go unto the place which YHWH shall choose.

**12:27** "And you shall offer your burnt offerings, the flesh and the blood, upon the altar of YHWH your Consciousness; and the blood of your sacrifices shall be poured out upon the altar of YHWH your Consciousness, and you shall eat the flesh.

**12:28** "Observe and hear all these words which I command you, that it may go well with you, and with your children after you forever, when you do that which is good and right in the eyes of YHWH your Consciousness.

---

**12:29** "When YHWH your Consciousness shall cut off the nations from before you, where you go in to dispossess them, and you dispossess them, and dwell in their land;

**12:30** "Take heed to yourself that you be not ensnared to follow them, after that they are destroyed from before you; and that you inquire not after their gods, saying: 'How do these nations serve their gods? Even so will I do likewise.'

**12:31** "You shall not do so unto YHWH your Consciousness; for every abomination to YHWH, which he hates, have they done unto their gods; for even their sons and their daughters do they burn in the fire to their gods.

**12:32** "All this word which I command you, that shall you observe to do; you shall not add thereto, nor diminish from it."

---

## Synthesis Notes

**Key Restorations:**

**Destruction of Canaanite Worship Sites:**
High mountains, hills, under green trees—all the places where Canaanites worshipped must be destroyed:
- Break down altars
- Dash pillars (*matsevot*)
- Burn Asherim (sacred poles)
- Hew down graven images
- "Destroy their name out of that place"

**"You Shall Not Do So":**
YHWH will not be worshipped at multiple sites like the Canaanite gods. Centralization is commanded.

**"The Place Which YHWH Shall Choose":**
*El-ha-maqom asher-yivchar YHWH*—this phrase occurs repeatedly. The central sanctuary is not yet named (eventually Jerusalem), but the principle is established: one place, YHWH's choice, his name dwelling there.

**What Goes to the Central Sanctuary:**
- Burnt offerings
- Sacrifices
- Tithes
- Contributions
- Vows
- Freewill offerings
- Firstlings

**Rejoicing Before YHWH:**
The central sanctuary is not for grim duty but for celebration. "You shall rejoice" appears multiple times. The whole household participates: sons, daughters, servants, and the Levite.

**"Every Man Whatever Is Right in His Own Eyes":**
This phrase, describing the pre-centralization chaos, becomes Judges' leitmotif. Without central sanctuary and settled order, everyone does what seems right to them.

**Secular Slaughter Permitted:**
Before centralization (and in the wilderness), all slaughter was sacrificial. Now, with the sanctuary distant, ordinary meat-eating is permitted:
- Slaughter within your gates
- Clean and unclean persons may eat (this is not sacrifice)
- Treated like hunting game (gazelle, deer)

**The Blood Prohibition:**
Even in secular slaughter: "You shall not eat the blood." Why? "The blood is the life" (*ha-dam hu ha-nefesh*). Blood must be poured out like water.

**Sacred Food at the Sanctuary:**
Tithes, firstlings, vows, contributions—these may only be eaten at the central sanctuary. They are sacred; ordinary eating is prohibited.

**Care for Levites:**
"Forsake not the Levite"—without land inheritance, Levites depend on the community's faithfulness.

**Do Not Imitate Canaanites:**
"How do these nations serve their gods? Even so will I do likewise"—this inquiry is forbidden. YHWH's worship is revealed, not borrowed. The Canaanite practices include burning children in fire—abomination.

**No Addition or Subtraction:**
"You shall not add thereto, nor diminish from it." The law is complete as given.

**Archetypal Layer:** Centralization represents **unified worship**. Many altars fragment devotion; one place focuses it. The "place which YHWH shall choose" is where divine and human meet—axis mundi.

The permission of secular slaughter marks a **transition from sacred to ordinary**. Not every meal is sacrifice; not every animal death is worship. This allows normal life at a distance from the sanctuary.

**Psychological Reading:** The prohibition on asking "How do these nations serve their gods?" blocks curiosity that leads to syncretism. The question itself is dangerous.

**Ethical Inversion Applied:**
- Destroy Canaanite sites—no preservation of enemy worship
- One place YHWH chooses—centralized worship
- "Every man what is right in his own eyes"—chaos without order
- Secular slaughter permitted—ordinary life distinguished from sacred
- Blood is the life—profound respect for life-force
- Do not imitate Canaanites—especially child sacrifice

**Modern Equivalent:** The centralization principle challenges religious fragmentation. The permission of secular slaughter (distinct from sacrifice) models how sacred and ordinary can coexist without confusion. And the prohibition on borrowing pagan practices warns against syncretism.

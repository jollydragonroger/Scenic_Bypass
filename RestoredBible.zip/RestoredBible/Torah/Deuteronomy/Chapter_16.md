# Deuteronomy Chapter 16: The Three Pilgrimage Festivals

*From the Hebrew: שָׁלֹשׁ רְגָלִים (Shalosh Regalim) — Three Pilgrimages*

---

**16:1** "Observe the month of Abib, and keep the Passover unto YHWH your Consciousness; for in the month of Abib YHWH your Consciousness brought you forth out of Egypt by night.

**16:2** "And you shall sacrifice the Passover offering unto YHWH your Consciousness, of the flock and the herd, in the place which YHWH shall choose to cause his name to dwell there.

**16:3** "You shall eat no leavened bread with it; seven days you shall eat unleavened bread therewith, even the bread of affliction—לֶחֶם עֹנִי (lechem oni)—for in haste you came forth out of the land of Egypt; that you may remember the day when you came forth out of the land of Egypt all the days of your life.

**16:4** "And there shall be no leaven seen with you in all your borders seven days; neither shall any of the flesh, which you sacrifice the first day at evening, remain all night until the morning.

**16:5** "You may not sacrifice the Passover offering within any of your gates, which YHWH your Consciousness gives you;

**16:6** "But at the place which YHWH your Consciousness shall choose to cause his name to dwell in, there you shall sacrifice the Passover offering at evening, at the going down of the sun, at the season that you came forth out of Egypt.

**16:7** "And you shall roast and eat it in the place which YHWH your Consciousness shall choose; and you shall turn in the morning, and go unto your tents.

**16:8** "Six days you shall eat unleavened bread; and on the seventh day shall be a solemn assembly to YHWH your Consciousness; you shall do no work therein.

---

**16:9** "Seven weeks you shall number unto you; from the time the sickle is first put to the standing grain you shall begin to number seven weeks.

**16:10** "And you shall keep the Feast of Weeks unto YHWH your Consciousness with a tribute of a freewill offering of your hand, which you shall give, according as YHWH your Consciousness blesses you.

**16:11** "And you shall rejoice before YHWH your Consciousness, you, and your son, and your daughter, and your man-servant, and your maid-servant, and the Levite who is within your gates, and the stranger, and the fatherless, and the widow, who are in the midst of you, in the place which YHWH your Consciousness shall choose to cause his name to dwell there.

**16:12** "And you shall remember that you were a bondman in Egypt; and you shall observe and do these statutes.

---

**16:13** "You shall keep the Feast of Booths seven days, after you have gathered in from your threshing-floor and from your wine-press.

**16:14** "And you shall rejoice in your feast, you, and your son, and your daughter, and your man-servant, and your maid-servant, and the Levite, and the stranger, and the fatherless, and the widow, who are within your gates.

**16:15** "Seven days you shall keep a feast unto YHWH your Consciousness in the place which YHWH shall choose; because YHWH your Consciousness will bless you in all your increase, and in all the work of your hands, and you shall be altogether joyful—וְהָיִיתָ אַךְ שָׂמֵחַ (ve-hayita ach same'ach).

**16:16** "Three times in a year shall all your males appear before YHWH your Consciousness in the place which he shall choose: on the Feast of Unleavened Bread, and on the Feast of Weeks, and on the Feast of Booths; and they shall not appear before YHWH empty.

**16:17** "Every man shall give as he is able, according to the blessing of YHWH your Consciousness which he has given you.

---

**16:18** "Judges and officers you shall make in all your gates, which YHWH your Consciousness gives you, according to your tribes; and they shall judge the people with righteous judgment.

**16:19** "You shall not wrest judgment; you shall not respect persons; neither shall you take a bribe; for a bribe blinds the eyes of the wise, and perverts the words of the righteous.

**16:20** "Justice, justice you shall pursue—צֶדֶק צֶדֶק תִּרְדֹּף (tsedeq tsedeq tirdof)—that you may live, and inherit the land which YHWH your Consciousness gives you.

**16:21** "You shall not plant an Asherah of any kind of tree beside the altar of YHWH your Consciousness, which you shall make.

**16:22** "Neither shall you set up a pillar, which YHWH your Consciousness hates."

---

## Synthesis Notes

**Key Restorations:**

**Passover and Unleavened Bread (16:1-8):**
- **Month of Abib** (Aviv, later called Nisan)—spring month
- Sacrifice at the central sanctuary (not "within your gates")
- **Unleavened bread seven days**—"bread of affliction"
- No leaven in all your borders
- Sacrifice at evening, at sunset
- Return home in the morning

**"Bread of Affliction" (לֶחֶם עֹנִי):**
The unleavened bread commemorates the hasty departure—no time for dough to rise. The poverty bread of slaves becomes the memorial bread of freedom.

**Feast of Weeks / Shavuot (16:9-12):**
- Seven weeks (49 days) from the beginning of grain harvest
- The 50th day is the festival (hence "Pentecost" in Greek)
- Freewill offering proportional to YHWH's blessing
- Rejoicing with entire household including vulnerable classes
- "Remember that you were a bondman in Egypt"

**Feast of Booths / Sukkot (16:13-15):**
- After the fall harvest (threshing-floor and wine-press)
- Seven days
- Inclusive celebration (family, servants, Levite, stranger, orphan, widow)
- "You shall be altogether joyful"

**"Altogether Joyful" (אַךְ שָׂמֵחַ):**
The emphatic command: only joy, nothing but joy. Sukkot is the festival of complete celebration.

**The Three Pilgrimages (16:16-17):**
All males must appear before YHWH three times yearly:
1. Unleavened Bread (Passover season)
2. Weeks (Shavuot/Pentecost)
3. Booths (Sukkot)

"They shall not appear before YHWH empty"—bring offerings proportional to blessing received.

**Judges and Officers (16:18-20):**
- Appointed in every gate (city)
- Judge with righteous judgment
- No wresting (perverting) judgment
- No respecting persons (partiality)
- No bribes ("a bribe blinds the eyes of the wise")

**"Justice, Justice You Shall Pursue":**
*Tsedeq tsedeq tirdof*—the doubled word emphasizes urgency. Pursue justice actively, relentlessly. "That you may live"—justice is life-giving.

**Forbidden Worship Objects:**
- No Asherah (sacred pole/tree) beside YHWH's altar
- No standing pillar (*matsevah*)

These were associated with Canaanite worship. YHWH's altar must stand alone.

**Archetypal Layer:** The three pilgrimages create **rhythmic return** to the central sanctuary. The agricultural year (spring grain, summer wheat, fall harvest) is sanctified through worship.

"Justice, justice you shall pursue" places **justice at the heart of communal life**. The doubled word makes it impossible to miss: this is the priority.

**Psychological Reading:** The command to be "altogether joyful" at Sukkot acknowledges that joy can be commanded—or at least, circumstances can be created that make joy appropriate. The festival structure facilitates the emotion.

**Ethical Inversion Applied:**
- Three pilgrimages mark the year—time is sacred
- "Remember you were a bondman"—memory shapes festival practice
- Include vulnerable classes—Levite, stranger, orphan, widow
- "Justice, justice"—doubled emphasis
- "A bribe blinds the wise"—even the wise are corruptible
- No Asherah beside the altar—YHWH stands alone

**Modern Equivalent:** The principle of proportional giving ("as he is able, according to the blessing") remains relevant. The doubled emphasis on justice challenges any society that claims to value it. And the inclusion of vulnerable classes in celebration models how festivals can serve social cohesion.

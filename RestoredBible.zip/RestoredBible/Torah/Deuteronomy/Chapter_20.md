# Deuteronomy Chapter 20: Laws of Warfare

*From the Hebrew: מִלְחָמָה (Milchamah) — War*

---

**20:1** "When you go forth to battle against your enemies, and see horses, and chariots, and a people more than you, you shall not be afraid of them; for YHWH your Consciousness is with you, who brought you up out of the land of Egypt.

**20:2** "And it shall be, when you draw near unto the battle, that the priest shall approach and speak unto the people,

**20:3** "And shall say unto them: 'Hear, O Israel, you draw near this day unto battle against your enemies; let not your heart faint; fear not, nor be alarmed, neither be you affrighted at them;

**20:4** "'For YHWH your Consciousness is he who goes with you, to fight for you against your enemies, to save you.'

**20:5** "And the officers shall speak unto the people, saying: 'What man is there who has built a new house, and has not dedicated it? Let him go and return to his house, lest he die in the battle, and another man dedicate it.

**20:6** "'And what man is there who has planted a vineyard, and has not used the fruit thereof? Let him go and return unto his house, lest he die in the battle, and another man use the fruit thereof.

**20:7** "'And what man is there who has betrothed a wife, and has not taken her? Let him go and return unto his house, lest he die in the battle, and another man take her.'

**20:8** "And the officers shall speak further unto the people, and they shall say: 'What man is there who is fearful and faint-hearted? Let him go and return unto his house, lest his brothers' heart melt as his heart.'

**20:9** "And it shall be, when the officers have made an end of speaking unto the people, that captains of hosts shall be appointed at the head of the people.

---

**20:10** "When you draw near unto a city to fight against it, then proclaim peace unto it.

**20:11** "And it shall be, if it make you answer of peace, and open unto you, then it shall be, that all the people that are found therein shall become tributary unto you, and shall serve you.

**20:12** "And if it will make no peace with you, but will make war against you, then you shall besiege it.

**20:13** "And when YHWH your Consciousness delivers it into your hand, you shall smite every male thereof with the edge of the sword.

**20:14** "But the women, and the little ones, and the cattle, and all that is in the city, even all the spoil thereof, shall you take for a prey unto yourself; and you shall eat the spoil of your enemies, which YHWH your Consciousness has given you.

**20:15** "Thus shall you do unto all the cities which are very far off from you, which are not of the cities of these nations.

---

**20:16** "However, of the cities of these peoples, which YHWH your Consciousness gives you for an inheritance, you shall save alive nothing that breathes.

**20:17** "But you shall utterly destroy them—הַחֲרֵם תַּחֲרִימֵם (hacharem tacharimem): the Hittite, and the Amorite, the Canaanite, and the Perizzite, the Hivite, and the Jebusite; as YHWH your Consciousness has commanded you;

**20:18** "That they teach you not to do after all their abominations, which they have done unto their gods, and so you sin against YHWH your Consciousness.

---

**20:19** "When you shall besiege a city a long time, in making war against it to take it, you shall not destroy the trees thereof by wielding an axe against them; for you may eat of them, but you shall not cut them down; for is the tree of the field a man, that it should be besieged by you?

**20:20** "Only the trees of which you know that they are not trees for food, them you may destroy and cut down, that you may build bulwarks against the city that makes war with you, until it falls."

---

## Synthesis Notes

**Key Restorations:**

**The Priest's Address:**
Before battle, the priest speaks:
- "Let not your heart faint"
- "Fear not, nor be alarmed"
- "YHWH your Consciousness... goes with you, to fight for you"

The battle is YHWH's; human courage comes from divine presence.

**Exemptions from Battle:**
The officers announce four exemptions:

1. **New house not dedicated**: Let him return to dedicate it
2. **Vineyard not yet used**: Let him return to enjoy its fruit
3. **Betrothed wife not yet taken**: Let him return to marry
4. **Fearful and faint-hearted**: Let him return, lest he spread fear

**The Rationale:**
"Lest he die in the battle, and another man..." The concern is that someone else would complete what the soldier began. There's also the practical concern that the fearful will demoralize others.

**Distant Cities (20:10-15):**
For cities outside Canaan:
1. **First offer peace**
2. **If accepted**: the city becomes tributary (forced labor)
3. **If rejected**: besiege and conquer
4. **Kill all males**
5. **Take women, children, livestock, spoil as plunder**

This is warfare with limits—combatant males are killed; non-combatants are spared.

**Canaanite Cities (20:16-18):**
For the seven nations within Canaan, different rules apply:
- "You shall save alive nothing that breathes"
- Complete *cherem* (destruction)
- Reason: "That they teach you not to do after all their abominations"

The distinction: distant enemies are political threats; Canaanite nations are religious threats. Their survival means potential assimilation of their practices.

**Protection of Trees (20:19-20):**
During siege warfare:
- Do not cut down fruit trees ("for you may eat of them")
- Non-fruit trees may be cut for siege works

**"Is the Tree of the Field a Man?"**
The rhetorical question: trees are not the enemy. Scorched-earth tactics harm the land that the conqueror will inherit. This is early environmental law in warfare.

**Archetypal Layer:** The exemptions reveal **what matters**: completing life's basic structures (house, vineyard, marriage). War is interruption; these represent normalcy. The fearful exemption acknowledges that **fear is contagious**.

The tree protection law distinguishes **combatants from creation**. Even in war, not everything is enemy. The land and its productivity deserve protection.

**Psychological Reading:** The priest's address counters the psychological impact of seeing superior forces (horses, chariots, more numerous enemy). The response to fear is theological: YHWH fights for you.

**Ethical Inversion Applied:**
- YHWH fights for Israel—divine presence overcomes fear
- Exemptions protect life transitions—house, vineyard, marriage
- Fear exemption—the fearful may leave rather than infect others
- Offer peace first—war is not the first option
- Distant cities: males killed, others spared—limits on destruction
- Canaanite cities: total destruction—religious survival takes precedence
- Trees protected—creation is not the enemy

**Difficult Elements:**
The distinction between distant and Canaanite cities creates two levels of warfare, the second being genocidal. The text presents this as necessary for religious survival. The tree protection law, by contrast, shows remarkable environmental sensitivity.

**Modern Equivalent:** Laws of armed conflict (Geneva Conventions) echo the distinction between combatants and non-combatants. The tree protection law anticipates environmental law in warfare. And the exemptions for major life transitions suggest that some things matter more than military service.

# Deuteronomy Chapter 17: Justice, Priests, and Kings

*From the Hebrew: מֶלֶךְ (Melech) — The King*

---

**17:1** "You shall not sacrifice unto YHWH your Consciousness an ox, or a sheep, in which is a blemish, any evil thing; for that is an abomination unto YHWH your Consciousness.

**17:2** "If there is found in the midst of you, within any of your gates which YHWH your Consciousness gives you, man or woman, who does what is evil in the sight of YHWH your Consciousness, in transgressing his covenant,

**17:3** "And has gone and served other gods, and worshipped them, or the sun, or the moon, or any of the host of heaven, which I have not commanded;

**17:4** "And it is told you, and you have heard of it, then you shall inquire diligently; and behold, if it is true, and the thing certain, that such abomination is wrought in Israel,

**17:5** "Then you shall bring forth that man or that woman, who has done this evil thing, unto your gates, even the man or the woman; and you shall stone them with stones, that they die.

**17:6** "At the mouth of two witnesses, or three witnesses, shall he who is to die be put to death; at the mouth of one witness he shall not be put to death.

**17:7** "The hand of the witnesses shall be first upon him to put him to death, and afterward the hand of all the people. So you shall put away the evil from the midst of you.

---

**17:8** "If there arise a matter too hard for you in judgment, between blood and blood, between plea and plea, and between stroke and stroke, matters of controversy within your gates; then you shall arise, and go up unto the place which YHWH your Consciousness shall choose.

**17:9** "And you shall come unto the priests the Levites, and unto the judge that shall be in those days; and you shall inquire; and they shall declare unto you the sentence of judgment.

**17:10** "And you shall do according to the tenor of the sentence, which they shall declare unto you from that place which YHWH shall choose; and you shall observe to do according to all that they shall teach you.

**17:11** "According to the law which they shall teach you, and according to the judgment which they shall tell you, you shall do; you shall not turn aside from the sentence which they shall declare unto you, to the right hand, nor to the left.

**17:12** "And the man who does presumptuously, in not listening unto the priest who stands to minister there before YHWH your Consciousness, or unto the judge, that man shall die; and you shall put away the evil from Israel.

**17:13** "And all the people shall hear, and fear, and do no more presumptuously.

---

**17:14** "When you come unto the land which YHWH your Consciousness gives you, and shall possess it, and shall dwell therein, and shall say: 'I will set a king over me, like all the nations that are round about me';

**17:15** "You shall surely set him king over you, whom YHWH your Consciousness shall choose; one from among your brothers shall you set king over you; you may not put a foreigner over you, who is not your brother.

**17:16** "Only he shall not multiply horses to himself, nor cause the people to return to Egypt, to the end that he may multiply horses; forasmuch as YHWH has said unto you: 'You shall henceforth return no more that way.'

**17:17** "Neither shall he multiply wives to himself, that his heart turn not away; neither shall he greatly multiply to himself silver and gold.

**17:18** "And it shall be, when he sits upon the throne of his kingdom, that he shall write for himself a copy of this law in a book, out of that which is before the priests the Levites.

**17:19** "And it shall be with him, and he shall read therein all the days of his life; that he may learn to fear YHWH his Consciousness, to keep all the words of this law and these statutes, to do them;

**17:20** "That his heart be not lifted up above his brothers, and that he turn not aside from the commandment, to the right hand, or to the left; to the end that he may prolong his days in his kingdom, he and his children, in the midst of Israel."

---

## Synthesis Notes

**Key Restorations:**

**No Blemished Sacrifices:**
The chapter opens with sacrifice quality—no defect, no blemish. Giving YHWH less than the best is "abomination."

**Idolatry Trial (17:2-7):**
If someone worships other gods (sun, moon, stars):
1. **Report and inquiry**—diligent investigation
2. **Confirmation**—"if it is true, and the thing certain"
3. **Execution at the gates**—public stoning
4. **Witnesses required**—two or three; one witness is insufficient
5. **Witnesses strike first**—they bear responsibility for their testimony

**The Central Court (17:8-13):**
When local cases are too difficult ("between blood and blood, between plea and plea"):
- Go up to the central sanctuary
- Consult the priests and the judge
- Their decision is binding
- No deviation "to the right hand, nor to the left"
- Presumptuous defiance of the court = death

This establishes a **supreme court** at the central sanctuary for hard cases.

**The Law of the King (17:14-20):**

When Israel requests a king "like all the nations":
- YHWH permits it
- YHWH chooses the king
- The king must be an Israelite ("from among your brothers")

**Royal Restrictions:**
1. **Not multiply horses**—especially not from Egypt (no return to Egypt for military power)
2. **Not multiply wives**—"that his heart turn not away"
3. **Not greatly multiply silver and gold**—no excessive wealth accumulation

**The King's Torah:**
- He must write a personal copy of "this law"
- From the scroll kept by the priests
- Read it "all the days of his life"
- Purpose: learn to fear YHWH, keep the commandments, not be "lifted up above his brothers"

**The Humble King:**
The king is not above the law but under it. He is a brother among brothers, subject to the Torah. The law restrains royal power.

**Historical Fulfillment:**
Solomon violated all three prohibitions: horses from Egypt (1 Kings 10:28-29), many wives who turned his heart (1 Kings 11:1-8), and vast gold accumulation (1 Kings 10:14-22). The warnings were prophetically accurate.

**Archetypal Layer:** The law of the king creates **constitutional monarchy** before the term existed. The king is chosen by YHWH, limited by law, and defined by Torah study. Power is constrained.

The restrictions on horses, wives, and gold address the **corruptions of power**: military might, political alliances (often sealed by marriage), and wealth. All three tend to turn the heart from YHWH.

**Psychological Reading:** The requirement that the king write and read the Torah personally keeps him connected to the source of authority. The law prevents the king from becoming a god unto himself.

**Ethical Inversion Applied:**
- Two or three witnesses required—protection against false accusation
- Witnesses strike first—accountability for testimony
- Central court for hard cases—hierarchical justice system
- King permitted but constrained—power under law
- No horses from Egypt—no return to the place of bondage
- King reads Torah daily—the ruler is ruled by the word

**Modern Equivalent:** The principle of constitutional limits on executive power remains foundational. The requirement of multiple witnesses for capital cases anticipates evidentiary standards. And the vision of a ruler who studies the law daily models accountable leadership.

# Deuteronomy Chapter 28: Blessings and Curses

*From the Hebrew: בְּרָכוֹת וּקְלָלוֹת (Berachot U-Qelalot) — Blessings and Curses*

---

## The Blessings (28:1-14)

**28:1** "And it shall come to pass, if you shall diligently listen unto the voice of YHWH your Consciousness, to observe to do all his commandments which I command you this day, that YHWH your Consciousness will set you on high above all the nations of the earth.

**28:2** "And all these blessings shall come upon you, and overtake you, if you shall listen unto the voice of YHWH your Consciousness.

**28:3** "Blessed shall you be in the city, and blessed shall you be in the field.

**28:4** "Blessed shall be the fruit of your body, and the fruit of your land, and the fruit of your cattle, the increase of your cattle, and the young of your flock.

**28:5** "Blessed shall be your basket and your kneading-trough.

**28:6** "Blessed shall you be when you come in, and blessed shall you be when you go out.

**28:7** "YHWH will cause your enemies who rise up against you to be smitten before you; they shall come out against you one way, and shall flee before you seven ways.

**28:8** "YHWH will command the blessing upon you in your barns, and in all that you put your hand unto; and he will bless you in the land which YHWH your Consciousness gives you.

**28:9** "YHWH will establish you for a holy people unto himself, as he has sworn unto you; if you shall keep the commandments of YHWH your Consciousness, and walk in his ways.

**28:10** "And all the peoples of the earth shall see that the name of YHWH is called upon you; and they shall be afraid of you.

**28:11** "And YHWH will make you over-abundant for good, in the fruit of your body, and in the fruit of your cattle, and in the fruit of your land, in the land which YHWH swore unto your fathers to give you.

**28:12** "YHWH will open unto you his good treasury, the heaven, to give the rain of your land in its season, and to bless all the work of your hand; and you shall lend unto many nations, but you shall not borrow.

**28:13** "And YHWH will make you the head, and not the tail; and you shall be above only, and you shall not be beneath; if you shall listen unto the commandments of YHWH your Consciousness, which I command you this day, to observe and to do them;

**28:14** "And you shall not turn aside from any of the words which I command you this day, to the right hand, or to the left, to go after other gods to serve them."

---

## The Curses (28:15-68)

**28:15** "But it shall come to pass, if you will not listen unto the voice of YHWH your Consciousness, to observe to do all his commandments and his statutes which I command you this day; that all these curses shall come upon you, and overtake you.

**28:16** "Cursed shall you be in the city, and cursed shall you be in the field.

**28:17** "Cursed shall be your basket and your kneading-trough.

**28:18** "Cursed shall be the fruit of your body, and the fruit of your land, the increase of your cattle, and the young of your flock.

**28:19** "Cursed shall you be when you come in, and cursed shall you be when you go out.

**28:20** "YHWH will send upon you cursing, discomfiture, and rebuke, in all that you put your hand unto to do, until you are destroyed, and until you perish quickly; because of the evil of your doings, whereby you have forsaken me.

**28:21** "YHWH will make the pestilence cleave unto you, until he has consumed you from off the land, into which you go in to possess it.

**28:22** "YHWH will smite you with consumption, and with fever, and with inflammation, and with fiery heat, and with drought, and with blasting, and with mildew; and they shall pursue you until you perish.

**28:23** "And your heaven that is over your head shall be brass, and the earth that is under you shall be iron.

**28:24** "YHWH will make the rain of your land powder and dust; from heaven shall it come down upon you, until you are destroyed.

**28:25** "YHWH will cause you to be smitten before your enemies; you shall go out one way against them, and shall flee seven ways before them; and you shall be a horror unto all the kingdoms of the earth.

**28:26** "And your carcasses shall be food unto all fowls of the air, and unto the beasts of the earth, and there shall be none to frighten them away.

**28:27** "YHWH will smite you with the boil of Egypt, and with the emerods, and with the scab, and with the itch, whereof you cannot be healed.

**28:28** "YHWH will smite you with madness, and with blindness, and with astonishment of heart.

**28:29** "And you shall grope at noonday, as the blind gropes in darkness, and you shall not prosper in your ways; and you shall be only oppressed and robbed always, and there shall be none to save you.

**28:30** "You shall betroth a wife, and another man shall lie with her; you shall build a house, and you shall not dwell therein; you shall plant a vineyard, and you shall not use the fruit thereof.

**28:31** "Your ox shall be slain before your eyes, and you shall not eat thereof; your donkey shall be violently taken away from before your face, and shall not be restored to you; your sheep shall be given unto your enemies, and you shall have none to save you.

**28:32** "Your sons and your daughters shall be given unto another people, and your eyes shall look, and fail with longing for them all the day; and there shall be nothing in the power of your hand.

**28:33** "The fruit of your land, and all your labors, shall a nation which you know not eat up; and you shall be only oppressed and crushed always;

**28:34** "So that you shall be mad for the sight of your eyes which you shall see.

**28:35** "YHWH will smite you in the knees, and in the legs, with a sore boil, whereof you cannot be healed, from the sole of your foot unto the crown of your head.

**28:36** "YHWH will bring you, and your king whom you shall set over you, unto a nation that you have not known, you nor your fathers; and there shall you serve other gods, wood and stone.

**28:37** "And you shall become an astonishment, a proverb, and a byword, among all the peoples where YHWH shall lead you away.

---

**28:38-44** [Agricultural and economic reversals continue in detail—much sowing, little harvesting; olive trees but no oil; children taken captive; the stranger rising higher while Israel sinks lower.]

**28:45** "And all these curses shall come upon you, and shall pursue you, and overtake you, till you are destroyed; because you did not listen unto the voice of YHWH your Consciousness, to keep his commandments and his statutes which he commanded you.

**28:46** "And they shall be upon you for a sign and for a wonder, and upon your seed forever.

**28:47** "Because you did not serve YHWH your Consciousness with joyfulness, and with gladness of heart, by reason of the abundance of all things;

**28:48** "Therefore shall you serve your enemies whom YHWH shall send against you, in hunger, and in thirst, and in nakedness, and in want of all things; and he shall put a yoke of iron upon your neck, until he has destroyed you.

---

**28:49** "YHWH will bring a nation against you from far, from the end of the earth, as the vulture swoops down; a nation whose tongue you shall not understand;

**28:50** "A nation of fierce countenance, who shall not regard the person of the old, nor show favor to the young.

**28:51** "And he shall eat the fruit of your cattle, and the fruit of your land, until you are destroyed; who also shall not leave you grain, wine, or oil, the increase of your cattle, or the young of your flock, until he has caused you to perish.

**28:52** "And he shall besiege you in all your gates, until your high and fortified walls come down, wherein you trusted, throughout all your land; and he shall besiege you in all your gates throughout all your land, which YHWH your Consciousness has given you.

**28:53** "And you shall eat the fruit of your own body, the flesh of your sons and of your daughters, whom YHWH your Consciousness has given you; in the siege and in the distress, with which your enemies shall distress you.

**28:54-57** [Descriptions of siege cannibalism—even the most tender and delicate will hoard food from family members, eating their own children in secret.]

**28:58** "If you will not observe to do all the words of this law that are written in this book, that you may fear this glorious and awful name, YHWH your Consciousness;

**28:59** "Then YHWH will make your plagues wonderful, and the plagues of your seed, plagues great and of long continuance, and sicknesses sore and of long continuance.

**28:60** "And he will bring upon you again all the diseases of Egypt, which you were afraid of; and they shall cleave unto you.

**28:61** "Also every sickness, and every plague, which is not written in the book of this law, them will YHWH bring upon you, until you are destroyed.

**28:62** "And you shall be left few in number, whereas you were as the stars of heaven for multitude; because you did not listen unto the voice of YHWH your Consciousness.

**28:63** "And it shall come to pass, that as YHWH rejoiced over you to do you good, and to multiply you; so YHWH will rejoice over you to cause you to perish, and to destroy you; and you shall be plucked from off the land into which you go in to possess it.

**28:64** "And YHWH will scatter you among all peoples, from the one end of the earth even unto the other end of the earth; and there you shall serve other gods, which you have not known, you nor your fathers, wood and stone.

**28:65** "And among these nations you shall have no repose, and there shall be no rest for the sole of your foot; but YHWH will give you there a trembling heart, and failing of eyes, and languishing of soul.

**28:66** "And your life shall hang in doubt before you; and you shall fear night and day, and shall have no assurance of your life.

**28:67** "In the morning you shall say: 'Would it were evening!' And at evening you shall say: 'Would it were morning!' for the fear of your heart which you shall fear, and for the sight of your eyes which you shall see.

**28:68** "And YHWH will bring you back into Egypt in ships, by the way of which I said unto you: 'You shall see it no more again'; and there you shall sell yourselves unto your enemies for bondmen and for bondwomen, and no man shall buy you."

---

## Synthesis Notes

**Key Restorations:**

**The Structure:**
- Blessings (28:1-14): 14 verses
- Curses (28:15-68): 54 verses

The curses are nearly four times longer than the blessings. The text dwells on consequences of disobedience.

**The Blessings:**
- City and field
- Fertility (body, land, animals)
- Basket and kneading-trough (daily provision)
- Coming in and going out
- Victory over enemies (they flee seven ways)
- Rain in season
- Lending, not borrowing
- Head, not tail; above, not beneath

**The Curses (Inversion):**
Each blessing has a corresponding curse:
- City and field cursed
- Barrenness
- Basket and trough cursed
- Enemies victorious (you flee seven ways)
- Drought (heaven brass, earth iron)
- Diseases, madness, blindness
- Loss of wife, house, vineyard to others
- Children taken captive
- Becoming borrower, not lender
- Tail, not head

**"Because You Did Not Serve... with Joyfulness":**
The startling diagnosis (28:47): disobedience was not serving YHWH "with joyfulness, and with gladness of heart, by reason of the abundance." Joy was expected; its absence was failure.

**The Distant Nation:**
"A nation from far... as the vulture swoops down; a nation whose tongue you shall not understand." This prophesies conquest by a foreign power—fulfilled by Assyria (northern kingdom, 722 BCE) and Babylon (southern kingdom, 586 BCE), and again by Rome (70 CE).

**Siege Cannibalism:**
The most horrifying detail: parents eating their own children during siege. This occurred during the Babylonian siege (Lamentations 4:10) and the Roman siege (Josephus, Wars 6.3.4).

**Dispersion:**
"YHWH will scatter you among all peoples, from the one end of the earth even unto the other." The diaspora is foreseen.

**"Your Life Shall Hang in Doubt":**
The psychological state of exile: trembling heart, failing eyes, languishing soul. No rest, no assurance. Fear day and night.

**Return to Egypt:**
The ultimate reversal: "YHWH will bring you back into Egypt in ships." The exodus reversed. Worse: "You shall sell yourselves... and no man shall buy you"—so worthless that even as slaves no one wants them.

**Archetypal Layer:** Chapter 28 is the **covenant sanction**—the consequences that follow obedience or disobedience. Ancient treaties included blessings and curses; this follows that pattern but with theological depth.

The curses describe **anti-creation**—the reversal of fruitfulness, order, and blessing that creation established. Disobedience un-makes the world.

**Psychological Reading:** The escalating curses create visceral impact. The reader is meant to feel the weight of consequences. This is not dispassionate legal statement but emotional appeal.

**Ethical Inversion Applied:**
- Blessings and curses are conditional—obedience determines outcome
- Joy was expected—its absence was failure
- The curses are longer—consequences of failure dominate
- Foreign conquest prophesied—history confirms
- Siege cannibalism—the extreme of desperation
- Return to Egypt—the ultimate anti-exodus

**Historical Fulfillment:**
Jewish history has repeatedly encountered these curses: Assyrian and Babylonian conquests, Roman destruction, medieval persecutions, modern catastrophes. The text has been read as both prophecy and explanation.

**Modern Equivalent:** The connection between national choices and national outcomes remains debated. The psychological description of exile (trembling heart, life hanging in doubt, no rest) describes refugee experience across history.

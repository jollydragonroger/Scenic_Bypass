# Deuteronomy Chapter 2: The Journey Through Edom, Moab, and Ammon

*From the Hebrew: סֹב לָכֶם (Sov Lachem) — Turn Yourselves*

---

**2:1** "Then we turned, and took our journey into the wilderness by the way to the Red Sea, as YHWH spoke unto me; and we circled Mount Seir many days.

**2:2** "And YHWH spoke unto me, saying:

**2:3** "'You have circled this mountain long enough; turn northward.

**2:4** "'And command the people, saying: You are to pass through the border of your brothers the children of Esau, who dwell in Seir; and they will be afraid of you; take good heed therefore;

**2:5** "'Do not contend with them; for I will not give you of their land, no, not so much as for the sole of the foot to tread on; because I have given Mount Seir unto Esau for a possession.

**2:6** "'You shall purchase food from them for money, that you may eat; and you shall also buy water from them for money, that you may drink.

**2:7** "'For YHWH your Consciousness has blessed you in all the work of your hand; he has known your walking through this great wilderness; these forty years YHWH your Consciousness has been with you; you have lacked nothing.'

**2:8** "So we passed by from our brothers the children of Esau, who dwell in Seir, from the way of the Arabah, from Elath and from Ezion-geber. And we turned and passed by the way of the wilderness of Moab.

---

**2:9** "And YHWH said unto me: 'Do not harass Moab, neither contend with them in battle; for I will not give you of their land for a possession; because I have given Ar unto the children of Lot for a possession.'

**2:10** "(The Emim dwelt therein in times past, a people great, and many, and tall, as the Anakim;

**2:11** "They also are accounted Rephaim, as the Anakim; but the Moabites call them Emim.

**2:12** "And in Seir dwelt the Horites in times past; but the children of Esau succeeded them, and destroyed them from before them, and dwelt in their place; as Israel did unto the land of his possession, which YHWH gave unto them.)

**2:13** "'Now rise up, and cross over the brook Zered.' And we crossed over the brook Zered.

**2:14** "And the days in which we came from Kadesh-barnea, until we crossed over the brook Zered, were thirty-eight years; until all the generation of the men of war were consumed from the midst of the camp, as YHWH swore unto them.

**2:15** "Moreover the hand of YHWH was against them, to discomfit them from the midst of the camp, until they were consumed.

---

**2:16** "So it came to pass, when all the men of war were consumed and dead from among the people,

**2:17** "That YHWH spoke unto me, saying:

**2:18** "'You are this day to pass over the border of Moab, even Ar;

**2:19** "'And when you come near unto the children of Ammon, do not harass them, nor contend with them; for I will not give you of the land of the children of Ammon for a possession; because I have given it unto the children of Lot for a possession.'

**2:20** "(That also is accounted a land of Rephaim; Rephaim dwelt therein in times past; but the Ammonites call them Zamzummim;

**2:21** "A people great, and many, and tall, as the Anakim; but YHWH destroyed them before them; and they succeeded them, and dwelt in their place;

**2:22** "As he did for the children of Esau, who dwell in Seir, when he destroyed the Horites from before them; and they succeeded them, and dwelt in their place even unto this day;

**2:23** "And the Avvim, who dwelt in villages unto Gaza, the Caphtorim, who came forth out of Caphtor, destroyed them, and dwelt in their place.)

---

**2:24** "'Rise up, take your journey, and pass over the valley of the Arnon; behold, I have given into your hand Sihon the Amorite, king of Heshbon, and his land; begin to possess it, and contend with him in battle.

**2:25** "'This day will I begin to put the dread of you and the fear of you upon the peoples that are under the whole heaven, who, when they hear the report of you, shall tremble, and be in anguish because of you.'

**2:26** "And I sent messengers out of the wilderness of Kedemoth unto Sihon king of Heshbon with words of peace, saying:

**2:27** "'Let me pass through your land; I will go along by the highway, I will neither turn unto the right hand nor to the left.

**2:28** "'You shall sell me food for money, that I may eat; and give me water for money, that I may drink; only let me pass through on my feet,

**2:29** "'As the children of Esau who dwell in Seir, and the Moabites who dwell in Ar, did unto me; until I shall pass over the Jordan into the land which YHWH our Consciousness gives us.'

**2:30** "But Sihon king of Heshbon would not let us pass by him; for YHWH your Consciousness hardened his spirit, and made his heart obstinate, that he might deliver him into your hand, as at this day.

**2:31** "And YHWH said unto me: 'Behold, I have begun to deliver up Sihon and his land before you; begin to possess, that you may inherit his land.'

**2:32** "Then Sihon came out against us, he and all his people, unto battle at Jahaz.

**2:33** "And YHWH our Consciousness delivered him up before us; and we smote him, and his sons, and all his people.

**2:34** "And we took all his cities at that time, and utterly destroyed every city, the men, and the women, and the little ones; we left none remaining.

**2:35** "Only the cattle we took for a prey unto ourselves, with the spoil of the cities which we had taken.

**2:36** "From Aroer, which is on the edge of the valley of the Arnon, and from the city that is in the valley, even unto Gilead, there was not a city too high for us; YHWH our Consciousness delivered up all before us.

**2:37** "Only to the land of the children of Ammon you did not come near; all the side of the river Jabbok, and the cities of the hill-country, and wherever YHWH our Consciousness commanded us."

---

## Synthesis Notes

**Key Restorations:**

**The Circling:**
After the Kadesh-barnea failure, Israel circled Mount Seir "many days"—actually thirty-eight years. When that generation died, YHWH said: "You have circled this mountain long enough; turn northward."

**Protected Nations:**
Three peoples are off-limits:

1. **Edom (children of Esau)**: "Your brothers"—I have given Seir to Esau
2. **Moab (children of Lot)**: I have given Ar to the children of Lot
3. **Ammon (children of Lot)**: I have given it to the children of Lot

Israel must not attack these relatives. They may pass through, buying food and water.

**"You Have Lacked Nothing":**
Despite forty years of wilderness wandering, YHWH provided. "He has known your walking... you have lacked nothing." Divine provision sustained them through the long detour.

**The Ancient Giants:**
Moses provides historical notes about previous inhabitants:
- **Emim** in Moab (tall like Anakim; Moabites conquered them)
- **Horites** in Seir (Esau's descendants conquered them)
- **Rephaim/Zamzummim** in Ammon (Ammonites conquered them)
- **Avvim** in Gaza (Caphtorim/Philistines conquered them)

The point: other nations conquered giant peoples. Israel can do the same with YHWH's help. The giants are not invincible.

**Thirty-Eight Years:**
From Kadesh-barnea to the brook Zered: thirty-eight years. The entire generation of warriors died. "The hand of YHWH was against them, to discomfit them from the midst of the camp."

**Sihon's Defeat:**
Israel offers peace: let us pass through, we'll buy food and water. Sihon refuses.

"YHWH your Consciousness hardened his spirit"—as with Pharaoh, divine hardening. Sihon's refusal becomes the occasion for Israel's victory.

**Cherem at Heshbon:**
"We utterly destroyed every city, the men, and the women, and the little ones." This is *cherem*—total destruction. Only livestock and spoil are taken.

The territory from Aroer to Gilead becomes Israelite. But Ammon's territory (along the Jabbok) is not touched—YHWH's command is obeyed.

**Archetypal Layer:** The waiting period (thirty-eight years) represents **generational transition**. The old must die before the new can advance. Circling Seir was not pointless wandering but necessary waiting.

The protected nations (Edom, Moab, Ammon) show that **not all territory is Israel's**. YHWH gives land to other nations too. Israel's inheritance is specific, not unlimited.

**Psychological Reading:** The giant narratives encourage the new generation. Other peoples—including their relatives—conquered giants. The Anakim are not unique. The fear that paralyzed the parents need not paralyze the children.

**Ethical Inversion Applied:**
- Circling was necessary—the old generation had to die
- Relatives are protected—Edom, Moab, Ammon have divine land grants
- Other nations conquered giants—Israel can too
- Sihon's heart was hardened—his refusal enables Israel's possession
- Cherem is applied—total destruction of Sihon's kingdom
- Ammon is not touched—obedience includes restraint

**Difficult Elements:**
The hardening of Sihon's heart and the subsequent *cherem* (total destruction) raise questions about divine fairness. The text presents Sihon's refusal as both his choice and divinely ordained, and the destruction as divinely commanded.

**Modern Equivalent:** The principle of defined boundaries (what is yours, what belongs to others) applies to organizations and nations. And the encouragement from historical precedent (others conquered giants) helps communities facing seemingly impossible challenges.

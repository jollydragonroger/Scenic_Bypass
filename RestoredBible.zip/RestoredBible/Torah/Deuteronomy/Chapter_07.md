# Deuteronomy Chapter 7: The Command Concerning the Nations

*From the Hebrew: עַם סְגֻלָּה (Am Segullah) — A Treasured People*

---

**7:1** "When YHWH your Consciousness shall bring you into the land into which you go to possess it, and shall cast out many nations from before you, the Hittite, and the Girgashite, and the Amorite, and the Canaanite, and the Perizzite, and the Hivite, and the Jebusite, seven nations greater and mightier than you;

**7:2** "And when YHWH your Consciousness shall deliver them up before you, and you shall smite them; then you shall utterly destroy them—הַחֲרֵם תַּחֲרִים (hacharem tacharim); you shall make no covenant with them, nor show mercy unto them;

**7:3** "Neither shall you make marriages with them: your daughter you shall not give unto his son, nor his daughter shall you take unto your son.

**7:4** "For he will turn away your son from following me, that they may serve other gods; so will the anger of YHWH be kindled against you, and he will destroy you quickly.

**7:5** "But thus shall you deal with them: you shall break down their altars, and dash in pieces their pillars, and hew down their Asherim, and burn their graven images with fire.

---

**7:6** "For you are a holy people unto YHWH your Consciousness; YHWH your Consciousness has chosen you to be his own treasure—עַם סְגֻלָּה (am segullah)—out of all peoples that are upon the face of the earth.

**7:7** "YHWH did not set his love upon you, nor choose you, because you were more in number than any people; for you were the fewest of all peoples;

**7:8** "But because YHWH loved you, and because he would keep the oath which he swore unto your fathers, YHWH brought you out with a mighty hand, and redeemed you out of the house of bondage, from the hand of Pharaoh king of Egypt.

**7:9** "Know therefore that YHWH your Consciousness, he is God; the faithful God—הָאֵל הַנֶּאֱמָן (ha-El ha-ne'eman)—who keeps covenant and lovingkindness with those who love him and keep his commandments to a thousand generations;

**7:10** "And repays those who hate him to their face, to destroy them; he will not be slack to him who hates him, he will repay him to his face.

**7:11** "You shall therefore keep the commandment, and the statutes, and the ordinances, which I command you this day, to do them.

---

**7:12** "And it shall come to pass, because you hearken to these ordinances, and keep and do them, that YHWH your Consciousness shall keep with you the covenant and the lovingkindness which he swore unto your fathers.

**7:13** "And he will love you, and bless you, and multiply you; he will also bless the fruit of your body and the fruit of your land, your grain and your wine and your oil, the increase of your cattle and the young of your flock, in the land which he swore unto your fathers to give you.

**7:14** "You shall be blessed above all peoples; there shall not be male or female barren among you, or among your cattle.

**7:15** "And YHWH will take away from you all sickness; and none of the evil diseases of Egypt, which you know, will he put upon you, but will lay them upon all those who hate you.

**7:16** "And you shall consume all the peoples that YHWH your Consciousness shall deliver unto you; your eye shall not pity them; neither shall you serve their gods; for that will be a snare unto you.

---

**7:17** "If you shall say in your heart: 'These nations are more than I; how can I dispossess them?'

**7:18** "You shall not be afraid of them; you shall well remember what YHWH your Consciousness did unto Pharaoh, and unto all Egypt:

**7:19** "The great trials which your eyes saw, and the signs, and the wonders, and the mighty hand, and the outstretched arm, by which YHWH your Consciousness brought you out; so shall YHWH your Consciousness do unto all the peoples of whom you are afraid.

**7:20** "Moreover YHWH your Consciousness will send the hornet among them, until those who are left, and they who hide themselves, perish from before you.

**7:21** "You shall not be affrighted at them; for YHWH your Consciousness is in the midst of you, a God great and terrible.

**7:22** "And YHWH your Consciousness will cast out those nations before you little by little; you may not consume them quickly, lest the beasts of the field increase upon you.

**7:23** "But YHWH your Consciousness shall deliver them up before you, and shall discomfit them with a great discomfiture, until they are destroyed.

**7:24** "And he shall deliver their kings into your hand, and you shall make their name to perish from under heaven; there shall no man be able to stand before you, until you have destroyed them.

**7:25** "The graven images of their gods shall you burn with fire; you shall not covet the silver or the gold that is on them, nor take it unto yourself, lest you be snared by it; for it is an abomination to YHWH your Consciousness.

**7:26** "And you shall not bring an abomination into your house, and become a devoted thing like unto it; you shall utterly detest it, and you shall utterly abhor it; for it is a devoted thing—חֵרֶם (cherem)."

---

## Synthesis Notes

**Key Restorations:**

**The Seven Nations:**
Hittites, Girgashites, Amorites, Canaanites, Perizzites, Hivites, Jebusites—"greater and mightier than you." These are the inhabitants of Canaan to be displaced.

**The Cherem (חֵרֶם):**
*Hacharem tacharim*—"utterly destroy." The *cherem* is total dedication to YHWH through destruction:
- No covenant with them
- No mercy shown
- No intermarriage
- Destruction of all religious objects (altars, pillars, Asherim, images)

**The Rationale for No Intermarriage:**
"He will turn away your son from following me, that they may serve other gods." The concern is religious—mixed marriage leads to mixed worship. Solomon's story (1 Kings 11:1-8) illustrates this pattern.

**"A Treasured People" (עַם סְגֻלָּה):**
Israel is *am segullah*—a treasured, special possession. Not because of size (they were the fewest), but because:
1. YHWH loved them
2. YHWH kept his oath to the fathers

Election is grace, not merit.

**"The Faithful God" (הָאֵל הַנֶּאֱמָן):**
*Ha-El ha-ne'eman*—YHWH keeps covenant to a thousand generations for those who love him. But he also repays those who hate him "to their face"—directly, immediately.

**Blessings of Obedience:**
- Multiplication
- Fruitful bodies and land
- No barrenness (human or animal)
- Freedom from Egyptian diseases
- Conquest of enemies

**"Little by Little":**
YHWH will dispossess the nations gradually—not all at once. Why? "Lest the beasts of the field increase upon you." If the land is emptied too quickly, it will go wild. The conquest requires time for settlement.

**Don't Covet the Gold:**
The gold and silver on idols must not be taken. "Lest you be snared by it"—the precious metal is contaminated. Bringing *cherem* into your house makes you *cherem*.

**Archetypal Layer:** The *cherem* represents **radical separation**. The Canaanite religious system—with its fertility cults, child sacrifice (Molech), and sacred prostitution—is incompatible with YHWH worship. Coexistence means assimilation.

Israel's election as *am segullah* is not about inherent superiority but **divine choice grounded in love and oath**. The smallest became the chosen.

**Psychological Reading:** The fear addressed ("These nations are more than I") is the same fear that paralyzed the previous generation. The response: remember Egypt. YHWH's past action grounds confidence for present challenges.

**Ethical Inversion Applied:**
- Israel is chosen by love, not merit—election is grace
- "The fewest of all peoples"—smallness is no barrier to divine choice
- Intermarriage forbidden for religious reasons—the concern is syncretism
- Gradual conquest—God works through process, not instant transformation
- Don't covet the gold—contaminated treasure remains contaminated

**Difficult Elements:**
The command to utterly destroy nations is morally challenging. The text presents this as necessary for Israel's religious survival. The *cherem* was specific to the conquest period and these nations. Later biblical prophets emphasize that YHWH judges Israel by the same standards he judges nations. The ethical trajectory moves toward universal compassion, but this text remains difficult.

**Modern Equivalent:** The principle of not bringing "abominations into your house" applies to what communities accept and normalize. The warning about coveting contaminated gold speaks to the danger of profiting from corrupt sources. And the "little by little" pattern acknowledges that transformation takes time.

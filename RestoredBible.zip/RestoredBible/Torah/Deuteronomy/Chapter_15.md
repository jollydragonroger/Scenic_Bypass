# Deuteronomy Chapter 15: The Sabbatical Year and Release

*From the Hebrew: שְׁמִטָּה (Shemittah) — The Release*

---

**15:1** "At the end of every seven years you shall make a release—שְׁמִטָּה (shemittah).

**15:2** "And this is the manner of the release: every creditor shall release that which he has lent unto his neighbor; he shall not exact it of his neighbor and his brother; because YHWH's release has been proclaimed.

**15:3** "Of a foreigner you may exact it; but whatever of yours is with your brother your hand shall release.

**15:4** "However, there shall be no needy among you—אֶפֶס כִּי לֹא יִהְיֶה־בְּךָ אֶבְיוֹן (efes ki lo yihyeh-becha evyon)—for YHWH will surely bless you in the land which YHWH your Consciousness gives you for an inheritance to possess it;

**15:5** "If only you diligently listen to the voice of YHWH your Consciousness, to observe to do all this commandment which I command you this day.

**15:6** "For YHWH your Consciousness will bless you, as he promised you; and you shall lend unto many nations, but you shall not borrow; and you shall rule over many nations, but they shall not rule over you.

---

**15:7** "If there is among you a needy man, one of your brothers, within any of your gates, in your land which YHWH your Consciousness gives you, you shall not harden your heart, nor shut your hand from your needy brother;

**15:8** "But you shall surely open your hand unto him, and shall surely lend him sufficient for his need in that which he lacks.

**15:9** "Beware that there is not a base thought in your heart, saying: 'The seventh year, the year of release, is at hand'; and your eye be evil against your needy brother, and you give him nothing; and he cry unto YHWH against you, and it be sin in you.

**15:10** "You shall surely give him, and your heart shall not be grieved when you give unto him; because for this thing YHWH your Consciousness will bless you in all your work, and in all that you put your hand unto.

**15:11** "For the needy will never cease out of the land—כִּי לֹא־יֶחְדַּל אֶבְיוֹן מִקֶּרֶב הָאָרֶץ (ki lo-yechdal evyon mi-qerev ha-arets); therefore I command you, saying: 'You shall surely open your hand unto your brother, to your poor, and to your needy, in your land.'

---

**15:12** "If your brother, a Hebrew man, or a Hebrew woman, is sold unto you, he shall serve you six years; and in the seventh year you shall let him go free from you.

**15:13** "And when you let him go free from you, you shall not let him go empty;

**15:14** "You shall furnish him liberally out of your flock, and out of your threshing-floor, and out of your wine-press; of that with which YHWH your Consciousness has blessed you, you shall give unto him.

**15:15** "And you shall remember that you were a bondman in the land of Egypt, and YHWH your Consciousness redeemed you; therefore I command you this thing today.

**15:16** "And it shall be, if he says unto you: 'I will not go out from you'; because he loves you and your house, because he fares well with you;

**15:17** "Then you shall take an awl, and thrust it through his ear and into the door, and he shall be your bondman forever. And also unto your bondwoman you shall do likewise.

**15:18** "It shall not seem hard unto you, when you let him go free from you; for to the double of the hire of a hireling has he served you six years; and YHWH your Consciousness will bless you in all that you do.

---

**15:19** "All the firstling males that are born of your herd and of your flock you shall sanctify unto YHWH your Consciousness; you shall do no work with the firstling of your ox, nor shear the firstling of your flock.

**15:20** "You shall eat it before YHWH your Consciousness year by year in the place which YHWH shall choose, you and your household.

**15:21** "And if there is any blemish therein, lameness, or blindness, any ill blemish whatever, you shall not sacrifice it unto YHWH your Consciousness.

**15:22** "You shall eat it within your gates; the unclean and the clean may eat it alike, as the gazelle, and as the deer.

**15:23** "Only you shall not eat the blood thereof; you shall pour it out upon the ground as water."

---

## Synthesis Notes

**Key Restorations:**

**The Shemittah (שְׁמִטָּה):**
Every seventh year, debts are released. "YHWH's release has been proclaimed"—this is not optional human generosity but divine command.

**Scope of Release:**
- Applies to loans to "your brother" (fellow Israelite)
- Foreigners may still be exacted
- The distinction is covenant community

**"There Shall Be No Needy Among You":**
*Efes ki lo yihyeh-becha evyon*—the ideal. If Israel obeys fully, YHWH's blessing will eliminate poverty. The conditional: "if only you diligently listen."

**The Realistic Acknowledgment:**
"For the needy will never cease out of the land." The ideal and the realistic coexist. Because poverty will persist, the command stands: "You shall surely open your hand."

Jesus quotes this in Mark 14:7: "The poor you always have with you."

**The Warning Against Hardheartedness:**
"Beware that there is not a base thought in your heart"—the temptation to refuse a loan because the release year is near. If you give nothing and the needy person cries to YHWH, "it be sin in you."

The "evil eye" (*ayin ra'ah*) is the stingy calculation that withholds generosity.

**Hebrew Servants (15:12-18):**
A Hebrew man or woman sold into service:
- Serves six years
- Released in the seventh (personal cycle, not the national shemittah)
- Sent away with provisions: livestock, grain, wine

**"You Were a Bondman in Egypt":**
Memory grounds ethics. Because YHWH redeemed Israel from Egyptian slavery, they must treat their servants humanely.

**The Ear-Piercing:**
If the servant chooses to stay (loves the master, fares well), an awl is driven through the ear against the door. This permanent mark signifies permanent service—"your bondman forever."

The door may symbolize the household; the pierced ear, devoted listening.

**"To the Double of the Hire":**
Six years of servant labor equals twice what you'd pay a hired worker. The economic value has been received; release should not seem burdensome.

**Firstlings:**
Every firstborn male of herd and flock is sanctified to YHWH:
- No work from the firstling ox
- No shearing the firstling sheep
- Eaten before YHWH at the central sanctuary
- Blemished firstlings eaten locally as ordinary meat
- Blood always poured out

**Archetypal Layer:** The shemittah represents **economic reset**. Without periodic release, debt compounds and impoverishes permanently. The seven-year cycle prevents perpetual bondage—to debt or to masters.

The tension between "there shall be no needy" (the ideal) and "the needy will never cease" (the reality) captures the **already/not yet** of ethical aspiration.

**Psychological Reading:** The warning against the "base thought" addresses the interior calculation that justifies refusing help. The text knows human nature: people will find reasons not to give when the release year is near.

**Ethical Inversion Applied:**
- Debt release every seven years—economic reset
- "There shall be no needy" + "the needy will never cease"—ideal and reality together
- "Your eye be evil"—interior stinginess is sin
- Remember Egyptian bondage—memory shapes ethics
- Furnish liberally—don't send the servant away empty
- Firstlings belong to YHWH—first belongs to the source

**Modern Equivalent:** Debt relief and bankruptcy laws echo the shemittah principle. The warning against calculating reluctance ("the release year is near") applies to any situation where upcoming forgiveness becomes excuse for current refusal. And the generous severance provisions ("furnish him liberally") anticipate transition support for departing workers.

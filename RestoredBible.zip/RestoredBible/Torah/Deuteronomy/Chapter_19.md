# Deuteronomy Chapter 19: Cities of Refuge and Witnesses

*From the Hebrew: עֵד שֶׁקֶר (Ed Sheqer) — The False Witness*

---

**19:1** "When YHWH your Consciousness shall cut off the nations, whose land YHWH your Consciousness gives you, and you succeed them, and dwell in their cities, and in their houses,

**19:2** "You shall separate three cities for yourself in the midst of your land, which YHWH your Consciousness gives you to possess it.

**19:3** "You shall prepare the way, and divide the borders of your land, which YHWH your Consciousness causes you to inherit, into three parts, that every manslayer may flee there.

**19:4** "And this is the case of the manslayer, who shall flee there and live: whoever kills his neighbor unawares, and hated him not in time past;

**19:5** "As when a man goes into the forest with his neighbor to hew wood, and his hand fetches a stroke with the axe to cut down the tree, and the head slips from the helve, and lights upon his neighbor, that he die; he shall flee unto one of these cities and live;

**19:6** "Lest the avenger of blood pursue the manslayer, while his heart is hot, and overtake him, because the way is long, and smite him mortally; whereas he was not deserving of death, inasmuch as he hated him not in time past.

**19:7** "Wherefore I command you, saying: You shall separate three cities for yourself.

**19:8** "And if YHWH your Consciousness enlarge your border, as he has sworn unto your fathers, and give you all the land which he promised to give unto your fathers—

**19:9** "If you shall keep all this commandment to do it, which I command you this day, to love YHWH your Consciousness, and to walk ever in his ways—then shall you add three cities more for yourself, beside these three;

**19:10** "That innocent blood be not shed in the midst of your land, which YHWH your Consciousness gives you for an inheritance, and so blood be upon you.

---

**19:11** "But if any man hates his neighbor, and lies in wait for him, and rises up against him, and smites him mortally that he die; and he flees into one of these cities;

**19:12** "Then the elders of his city shall send and fetch him from there, and deliver him into the hand of the avenger of blood, that he may die.

**19:13** "Your eye shall not pity him, but you shall put away the blood of the innocent from Israel, that it may go well with you.

---

**19:14** "You shall not remove your neighbor's landmark, which they of old time have set, in your inheritance which you shall inherit, in the land that YHWH your Consciousness gives you to possess it.

---

**19:15** "One witness shall not rise up against a man for any iniquity, or for any sin, in any sin that he sins; at the mouth of two witnesses, or at the mouth of three witnesses, shall a matter be established.

**19:16** "If an unrighteous witness rise up against any man to testify against him of wrongdoing,

**19:17** "Then both the men, between whom the controversy is, shall stand before YHWH, before the priests and the judges who shall be in those days.

**19:18** "And the judges shall inquire diligently; and behold, if the witness is a false witness, and has testified falsely against his brother;

**19:19** "Then shall you do unto him, as he had intended to do unto his brother; so shall you put away the evil from the midst of you.

**19:20** "And those who remain shall hear, and fear, and shall henceforth commit no more any such evil in the midst of you.

**19:21** "And your eye shall not pity: life for life, eye for eye, tooth for tooth, hand for hand, foot for foot."

---

## Synthesis Notes

**Key Restorations:**

**Three Cities of Refuge (West of Jordan):**
In addition to the three already established east of the Jordan (4:41-43), three more are to be set apart west of the Jordan. The land is to be divided into three regions, with a refuge city accessible in each.

**"Prepare the Way":**
Roads to the refuge cities must be maintained. Access must be easy; the fleeing manslayer's life depends on reaching safety before the avenger catches him.

**The Case Example:**
Two men cutting wood; the axe-head flies off and kills one. This is accident—no prior hatred, no intent. The survivor flees to the refuge city.

**"While His Heart Is Hot":**
The avenger (*go'el ha-dam*) may pursue in the heat of grief and anger. The refuge city protects the accidental killer from hot-blooded revenge.

**Potential Expansion:**
If YHWH enlarges the territory (the full promised land from Euphrates to the sea), three additional cities should be added—six total west of Jordan, plus the three east, for nine total.

**Murder vs. Manslaughter:**
If the killer hated his neighbor, lay in wait, and struck mortally—this is murder. The elders of his own city must extradite him from the refuge city and deliver him to the avenger. "Your eye shall not pity."

**The Landmark (19:14):**
"You shall not remove your neighbor's landmark"—boundary stones marking property lines were sacred. Moving them to steal land was a grave offense (also Proverbs 22:28, 23:10).

**The Witness Laws (19:15-21):**

**Minimum of Two Witnesses:**
No one may be convicted on a single witness. Two or three are required to establish any matter.

**The False Witness:**
If someone brings false testimony:
1. Both parties stand before YHWH (at the central sanctuary)
2. Priests and judges investigate diligently
3. If the witness is proven false:

**"Do unto him as he had intended to do unto his brother."**

The false witness receives the penalty he sought to inflict on the accused. If he tried to get someone executed, he is executed. If he tried to get someone fined, he pays the fine.

**"Life for Life, Eye for Eye...":**
The *lex talionis*—the law of proportional retaliation. In this context, it applies specifically to false witnesses: they receive the exact penalty they sought to impose.

This principle limits vengeance (no more than the offense) and ensures justice (no less than the offense).

**Archetypal Layer:** The refuge cities create **graduated justice**—distinction between intentional murder and accidental killing. Hot vengeance is prevented by cool procedure.

The false witness law makes accusation **self-risking**. If you falsely accuse, you face what you tried to inflict. This deters malicious prosecution.

**Psychological Reading:** The "hot heart" of the avenger is acknowledged—grief and anger are powerful. The system doesn't deny these emotions but channels them through process.

**Ethical Inversion Applied:**
- Roads prepared—access to justice must be easy
- Murder cannot hide in refuge—the city protects accident, not intent
- Landmark removal forbidden—property boundaries are sacred
- Two witnesses minimum—protection against false accusation
- False witness receives intended penalty—accusation is self-risking
- "Eye for eye"—proportionality, not escalation

**Modern Equivalent:** The distinction between murder and manslaughter remains foundational to criminal law. The requirement of multiple witnesses anticipates evidentiary standards. The punishment of false accusers (perjury laws) deters malicious prosecution. And "eye for eye" properly understood limits rather than encourages revenge.

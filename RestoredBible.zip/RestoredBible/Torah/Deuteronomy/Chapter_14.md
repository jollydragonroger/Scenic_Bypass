# Deuteronomy Chapter 14: Clean and Unclean Animals; Tithes

*From the Hebrew: בָּנִים אַתֶּם (Banim Atem) — You Are Children*

---

**14:1** "You are children of YHWH your Consciousness; you shall not cut yourselves, nor make any baldness between your eyes for the dead.

**14:2** "For you are a holy people unto YHWH your Consciousness, and YHWH has chosen you to be a treasure unto himself—עַם סְגֻלָּה (am segullah)—out of all peoples that are upon the face of the earth.

---

**14:3** "You shall not eat any abominable thing.

**14:4** "These are the beasts which you may eat: the ox, the sheep, and the goat,

**14:5** "The deer, and the gazelle, and the roebuck, and the wild goat, and the pygarg, and the antelope, and the mountain sheep.

**14:6** "And every beast that parts the hoof, and has the hoof wholly cloven in two, and chews the cud, among the beasts, that you may eat.

**14:7** "Nevertheless these you shall not eat of those that chew the cud, or of those that have the hoof cloven: the camel, and the hare, and the rock-badger, because they chew the cud but part not the hoof, they are unclean unto you;

**14:8** "And the swine, because it parts the hoof but chews not the cud, it is unclean unto you; of their flesh you shall not eat, and their carcasses you shall not touch.

**14:9** "These you may eat of all that are in the waters: whatever has fins and scales you may eat;

**14:10** "And whatever has not fins and scales you shall not eat; it is unclean unto you.

**14:11** "Of all clean birds you may eat.

**14:12** "But these are they of which you shall not eat: the great vulture, and the bearded vulture, and the osprey;

**14:13** "And the glede, and the falcon, and the kite after its kinds;

**14:14** "And every raven after its kinds;

**14:15** "And the ostrich, and the night-hawk, and the sea-mew, and the hawk after its kinds;

**14:16** "The little owl, and the great owl, and the horned owl;

**14:17** "And the pelican, and the carrion-vulture, and the cormorant;

**14:18** "And the stork, and the heron after its kinds, and the hoopoe, and the bat.

**14:19** "And all winged swarming things are unclean unto you; they shall not be eaten.

**14:20** "Of all clean fowl you may eat.

**14:21** "You shall not eat of anything that dies of itself; you may give it unto the stranger who is within your gates, that he may eat it; or you may sell it unto a foreigner; for you are a holy people unto YHWH your Consciousness. You shall not boil a kid in its mother's milk.

---

**14:22** "You shall surely tithe all the increase of your seed, that which comes forth from the field year by year.

**14:23** "And you shall eat before YHWH your Consciousness, in the place which he shall choose to cause his name to dwell there, the tithe of your grain, of your wine, and of your oil, and the firstlings of your herd and of your flock; that you may learn to fear YHWH your Consciousness always.

**14:24** "And if the way is too long for you, so that you are not able to carry it, because the place is too far from you, which YHWH your Consciousness shall choose to set his name there, when YHWH your Consciousness shall bless you;

**14:25** "Then you shall turn it into money, and bind up the money in your hand, and shall go unto the place which YHWH your Consciousness shall choose.

**14:26** "And you shall bestow the money for whatever your soul desires, for oxen, or for sheep, or for wine, or for strong drink, or for whatever your soul asks of you; and you shall eat there before YHWH your Consciousness, and you shall rejoice, you and your household.

**14:27** "And the Levite who is within your gates, you shall not forsake him; for he has no portion nor inheritance with you.

**14:28** "At the end of every three years you shall bring forth all the tithe of your increase in the same year, and shall lay it up within your gates.

**14:29** "And the Levite, because he has no portion nor inheritance with you, and the stranger, and the fatherless, and the widow, who are within your gates, shall come, and shall eat and be satisfied; that YHWH your Consciousness may bless you in all the work of your hand which you do."

---

## Synthesis Notes

**Key Restorations:**

**"You Are Children of YHWH":**
Israel's identity grounds the ethical commands. Because they are YHWH's children:
- No cutting or baldness for the dead (pagan mourning practices)
- Holy people (*am qadosh*)
- Treasured people (*am segullah*)

**Mourning Prohibitions:**
Self-laceration and shaving bald spots between the eyes were common pagan mourning rituals. Israel's grief must be expressed differently—maintaining bodily integrity.

**Clean and Unclean Animals:**
The dietary laws summarize Leviticus 11:

**Land Animals** (both criteria required):
- Cloven hoof (completely divided)
- Chews cud (ruminant)

Clean examples: ox, sheep, goat, deer, gazelle, various wild game.

Unclean examples: camel, hare, rock-badger (chew cud, no cloven hoof); swine (cloven hoof, doesn't chew cud).

**Water Creatures:**
- Clean: fins and scales
- Unclean: everything else

**Birds:**
A list of unclean birds (predators, scavengers): vultures, falcons, ravens, owls, storks, bats, etc.

**Winged Swarming Things:**
All unclean (except certain locusts, per Leviticus 11:21-22, not mentioned here).

**Animals That Die Naturally:**
Israel may not eat *nevelah* (animals that died of themselves—unbled). But they may give or sell such meat to non-Israelites. Holiness creates distinctions.

**"Do Not Boil a Kid in Its Mother's Milk":**
This phrase appears three times in the Torah (Exodus 23:19, 34:26; here). The rabbinic tradition built the complete separation of meat and dairy from this law. The original prohibition may address a Canaanite fertility rite or simply the ethical concern of mixing life (milk) with death (slaughter).

**The Festival Tithe (14:22-27):**
Each year, bring the tithe of produce to the central sanctuary:
- Eat it there before YHWH
- "That you may learn to fear YHWH your Consciousness always"

If the distance is too great, convert to money, travel, and buy whatever you desire at the sanctuary—"oxen, or sheep, or wine, or strong drink"—and eat and rejoice.

**Wine and Strong Drink:**
The text explicitly permits purchasing wine or *shekar* (strong drink) for the festival meal. Celebration before YHWH includes alcohol.

**The Third-Year Tithe (14:28-29):**
Every third year, the tithe stays local—stored "within your gates" for:
- The Levite (no inheritance)
- The stranger
- The fatherless
- The widow

This is social welfare built into the tithing system.

**Archetypal Layer:** The dietary laws create **embodied distinction**. What enters the body marks identity. Israel's holiness is expressed through eating differently.

The tithe system combines **worship** (eating before YHWH with rejoicing) and **welfare** (third-year provision for the vulnerable). Sacred celebration and social justice are intertwined.

**Psychological Reading:** The prohibition on pagan mourning practices maintains identity in grief. The dietary laws create daily, repeated affirmation of distinctiveness. And the festival tithe transforms obligation into celebration—"whatever your soul desires."

**Ethical Inversion Applied:**
- "You are children of YHWH"—identity grounds ethics
- No pagan mourning—distinctiveness in grief
- Dietary laws embody holiness—eating as identity
- Festival tithe = celebration—not grim duty but rejoicing
- Third-year tithe = welfare—Levite, stranger, orphan, widow
- Do not forsake the Levite—ongoing responsibility

**Modern Equivalent:** Dietary practices continue to mark religious identity. The transformation of tithe into celebration ("whatever your soul desires") models how religious obligation can be joyful. And the third-year welfare tithe anticipates social safety nets for the vulnerable.

# Deuteronomy Chapter 26: Firstfruits and Tithe Confessions

*From the Hebrew: אֲרַמִּי אֹבֵד אָבִי (Arami Oved Avi) — A Wandering Aramean Was My Father*

---

**26:1** "And it shall be, when you come into the land which YHWH your Consciousness gives you for an inheritance, and possess it, and dwell therein,

**26:2** "That you shall take of the first of all the fruit of the ground, which you shall bring in from your land that YHWH your Consciousness gives you, and you shall put it in a basket, and shall go unto the place which YHWH your Consciousness shall choose to cause his name to dwell there.

**26:3** "And you shall come unto the priest who shall be in those days, and say unto him: 'I profess this day unto YHWH your Consciousness, that I have come unto the land which YHWH swore unto our fathers to give us.'

**26:4** "And the priest shall take the basket out of your hand, and set it down before the altar of YHWH your Consciousness.

**26:5** "And you shall speak and say before YHWH your Consciousness: 'A wandering Aramean was my father—אֲרַמִּי אֹבֵד אָבִי (Arami oved avi)—and he went down into Egypt, and sojourned there, few in number; and he became there a nation, great, mighty, and populous.

**26:6** "'And the Egyptians dealt ill with us, and afflicted us, and laid upon us hard bondage.

**26:7** "'And we cried unto YHWH, the Consciousness of our fathers, and YHWH heard our voice, and saw our affliction, and our toil, and our oppression.

**26:8** "'And YHWH brought us forth out of Egypt with a mighty hand, and with an outstretched arm, and with great terribleness, and with signs, and with wonders.

**26:9** "'And he has brought us into this place, and has given us this land, a land flowing with milk and honey.

**26:10** "'And now, behold, I have brought the first of the fruit of the land, which you, O YHWH, have given me.' And you shall set it down before YHWH your Consciousness, and worship before YHWH your Consciousness.

**26:11** "And you shall rejoice in all the good which YHWH your Consciousness has given unto you, and unto your house, you, and the Levite, and the stranger who is in the midst of you.

---

**26:12** "When you have made an end of tithing all the tithe of your increase in the third year, which is the year of tithing, and have given it unto the Levite, to the stranger, to the fatherless, and to the widow, that they may eat within your gates, and be satisfied;

**26:13** "Then you shall say before YHWH your Consciousness: 'I have put away the hallowed things out of my house, and also have given them unto the Levite, and unto the stranger, to the fatherless, and to the widow, according to all your commandment which you have commanded me; I have not transgressed any of your commandments, neither have I forgotten them.

**26:14** "'I have not eaten thereof in my mourning, neither have I put away thereof, being unclean, nor given thereof for the dead; I have listened to the voice of YHWH my Consciousness, I have done according to all that you have commanded me.

**26:15** "'Look forth from your holy habitation, from heaven, and bless your people Israel, and the land which you have given us, as you swore unto our fathers, a land flowing with milk and honey.'"

---

**26:16** "This day YHWH your Consciousness commands you to do these statutes and ordinances; you shall therefore observe and do them with all your heart, and with all your soul.

**26:17** "You have declared YHWH this day to be your God, and that you would walk in his ways, and keep his statutes, and his commandments, and his ordinances, and listen to his voice.

**26:18** "And YHWH has declared you this day to be his own treasure—עַם סְגֻלָּה (am segullah)—as he has promised you, and that you should keep all his commandments;

**26:19** "And to make you high above all nations that he has made, in praise, and in name, and in honor; and that you may be a holy people unto YHWH your Consciousness, as he has spoken."

---

## Synthesis Notes

**Key Restorations:**

**The Firstfruits Liturgy (26:1-11):**

The Israelite brings a basket of firstfruits to the sanctuary and recites a confessional narrative:

**"A Wandering Aramean Was My Father":**
*Arami oved avi*—this refers to Jacob, who lived in Aram (with Laban) and was a wanderer/fugitive. Some translations: "a perishing Aramean" or "my father was a lost Aramean."

**The Historical Recital:**
1. Jacob went down to Egypt, few in number
2. Became a great nation there
3. Egyptians oppressed them
4. They cried to YHWH
5. YHWH heard and saw their affliction
6. YHWH brought them out with mighty hand, outstretched arm, signs, wonders
7. YHWH gave them this land flowing with milk and honey
8. "Now I bring the first of the fruit"

**The Passover Connection:**
This recital is the core of the Passover Haggadah. The Seder retelling expands this compressed narrative into the evening's story.

**Structure:**
Humble origin → slavery → cry → deliverance → land → offering. The gift of firstfruits concludes the narrative arc. Worship responds to history.

**The Tithe Confession (26:12-15):**

In the third year (the welfare tithe year), after distributing to Levite, stranger, orphan, and widow:

**The Declaration:**
- "I have put away the hallowed things out of my house"—fulfilled the obligation
- "Given them to the Levite, stranger, fatherless, widow"—proper distribution
- "I have not transgressed... neither forgotten"
- "I have not eaten thereof in my mourning"—no ritual contamination
- "Neither put away thereof being unclean"—proper purity
- "Nor given thereof for the dead"—no pagan associations

**The Prayer:**
"Look forth from your holy habitation... and bless your people Israel."

The confession of faithful obedience becomes the basis for requesting blessing.

**Mutual Declaration (26:16-19):**

A covenant ceremony:
- Israel declares YHWH to be their God
- YHWH declares Israel to be his treasured people (*am segullah*)

The relationship is reciprocal:
- Israel: walk in YHWH's ways, keep commandments, listen to his voice
- YHWH: make Israel high above all nations in praise, name, and honor

**"A Holy People":**
The final note: "that you may be a holy people unto YHWH your Consciousness, as he has spoken."

**Archetypal Layer:** The firstfruits confession is **worship through narrative**. Identity is established by reciting the story. Every Israelite becomes part of the exodus by speaking in first person plural: "we cried... YHWH brought us forth."

The tithe confession is **ethical accounting before God**. The worshipper declares compliance and asks for blessing on that basis.

**Psychological Reading:** The firstfruits liturgy prevents entitlement. Every harvest begins with remembering: we were slaves, we owned nothing, everything is gift. The narrative re-grounds gratitude.

**Ethical Inversion Applied:**
- "A wandering Aramean was my father"—humble origin remembered
- First person plural—"we cried, he brought us out"—every generation participates
- Tithe confession is accountability—you declare what you did
- "Not eaten in mourning, not given for the dead"—purity from pagan practice
- Mutual declaration—covenant is reciprocal

**Modern Equivalent:** The firstfruits liturgy models how narrative shapes identity. The tithe confession anticipates financial accountability and reporting. And the mutual declaration (Israel claims YHWH, YHWH claims Israel) models covenant relationship.

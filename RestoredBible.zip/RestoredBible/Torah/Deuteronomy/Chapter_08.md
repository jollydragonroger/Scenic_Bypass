# Deuteronomy Chapter 8: Remember and Do Not Forget

*From the Hebrew: זָכַר (Zakhar) — Remember*

---

**8:1** "All the commandment which I command you this day shall you observe to do, that you may live, and multiply, and go in and possess the land which YHWH swore unto your fathers.

**8:2** "And you shall remember all the way which YHWH your Consciousness has led you these forty years in the wilderness, that he might humble you, to test you, to know what was in your heart, whether you would keep his commandments, or not.

**8:3** "And he humbled you, and suffered you to hunger, and fed you with manna, which you knew not, neither did your fathers know; that he might make you know that man does not live by bread alone, but by every word that proceeds out of the mouth of YHWH does man live—כִּי עַל־כָּל־מוֹצָא פִי־יהוה יִחְיֶה הָאָדָם (ki al-kol-motsa fi-YHWH yichyeh ha-adam).

**8:4** "Your raiment did not wear out upon you, neither did your foot swell, these forty years.

**8:5** "And you shall consider in your heart, that, as a man disciplines his son, so YHWH your Consciousness disciplines you.

**8:6** "And you shall keep the commandments of YHWH your Consciousness, to walk in his ways, and to fear him.

---

**8:7** "For YHWH your Consciousness brings you into a good land, a land of brooks of water, of fountains and depths, springing forth in valleys and hills;

**8:8** "A land of wheat and barley, and vines and fig trees and pomegranates; a land of olive trees and honey;

**8:9** "A land in which you shall eat bread without scarceness, you shall not lack anything in it; a land whose stones are iron, and out of whose hills you may dig copper.

**8:10** "And you shall eat and be satisfied, and bless YHWH your Consciousness for the good land which he has given you.

---

**8:11** "Beware that you forget not YHWH your Consciousness, in not keeping his commandments, and his ordinances, and his statutes, which I command you this day;

**8:12** "Lest when you have eaten and are satisfied, and have built goodly houses, and dwelt in them;

**8:13** "And when your herds and your flocks multiply, and your silver and your gold is multiplied, and all that you have is multiplied;

**8:14** "Then your heart be lifted up, and you forget YHWH your Consciousness, who brought you forth out of the land of Egypt, out of the house of bondage;

**8:15** "Who led you through the great and dreadful wilderness, with its fiery serpents and scorpions, and thirsty ground where was no water; who brought you forth water out of the rock of flint;

**8:16** "Who fed you in the wilderness with manna, which your fathers knew not, that he might humble you, and that he might test you, to do you good at your latter end;

**8:17** "And lest you say in your heart: 'My power and the might of my hand has gotten me this wealth.'

**8:18** "But you shall remember YHWH your Consciousness, for it is he who gives you power to get wealth, that he may establish his covenant which he swore unto your fathers, as at this day.

**8:19** "And it shall be, if you do at all forget YHWH your Consciousness, and walk after other gods, and serve them, and worship them, I testify against you this day that you shall surely perish.

**8:20** "As the nations which YHWH makes to perish before you, so shall you perish; because you did not listen unto the voice of YHWH your Consciousness."

---

## Synthesis Notes

**Key Restorations:**

**Remember the Way:**
"You shall remember all the way which YHWH your Consciousness has led you these forty years." The wilderness was not pointless wandering but divine pedagogy:
- To humble
- To test
- To know what was in your heart

**"Man Does Not Live by Bread Alone":**
*Ki al-kol-motsa fi-YHWH yichyeh ha-adam*—"by every word that proceeds out of the mouth of YHWH does man live."

The manna taught this: physical bread is not sufficient. The word of YHWH sustains life. Jesus quoted this verse when tempted to turn stones into bread (Matthew 4:4).

**Miraculous Preservation:**
- Clothes did not wear out
- Feet did not swell
- For forty years

The wilderness was sustained by ongoing miracle, not merely initial provision.

**"As a Man Disciplines His Son":**
The wilderness hardships were fatherly discipline, not arbitrary punishment. YHWH treats Israel as a father treats a son—training through adversity.

**The Seven Species (8:8):**
The land's bounty is described through its signature produce:
1. Wheat
2. Barley
3. Grapes (vines)
4. Figs
5. Pomegranates
6. Olives
7. Honey (date honey or bee honey)

These "seven species" (*shiv'at ha-minim*) define the land's agricultural blessing.

**"Eat and Be Satisfied and Bless":**
The origin of the blessing after meals (*birkat ha-mazon*). Satisfaction should lead to gratitude.

**The Danger of Prosperity:**
When you have:
- Eaten and are satisfied
- Built good houses
- Multiplied herds and flocks
- Increased silver and gold

Then your heart will be "lifted up" and you will forget YHWH.

The sequence: satisfaction → pride → forgetfulness → apostasy.

**"My Power and the Might of My Hand":**
The temptation of self-attribution. Success leads to "I did this." The correction: "It is he who gives you power to get wealth."

Wealth-generating ability itself is gift. The capacity to prosper comes from YHWH, not merely the prosperity.

**The Covenant Purpose:**
YHWH gives power to get wealth "that he may establish his covenant." Prosperity serves covenant purpose, not personal aggrandizement.

**The Warning:**
If you forget YHWH and follow other gods: "you shall surely perish." The same fate as the dispossessed nations. Israel is not immune from judgment.

**Archetypal Layer:** The chapter traces the **spiritual danger of success**. Wilderness teaches dependence; prosperity teaches self-sufficiency. The harder lesson is remembering YHWH when you don't need him for daily bread.

The manna principle—"not by bread alone"—establishes that **life is more than physical**. The word of YHWH is as essential as food.

**Psychological Reading:** The progression from satisfaction to pride to forgetfulness is psychologically accurate. Abundance dulls memory. Those who struggled remember; those who inherit forget.

**Ethical Inversion Applied:**
- Wilderness was training—hardship as divine pedagogy
- "Not by bread alone"—physical provision is insufficient
- Clothes didn't wear out—ongoing miracle, not just initial rescue
- Prosperity breeds forgetfulness—success is spiritually dangerous
- "He gives power to get wealth"—even capacity is gift
- Same fate as the nations—Israel is not exempt from judgment

**Modern Equivalent:** The warning about prosperity-induced forgetfulness speaks directly to affluent societies. The tendency to attribute success to "my power and might" is universal. And the manna principle ("not by bread alone") challenges purely material definitions of human flourishing.

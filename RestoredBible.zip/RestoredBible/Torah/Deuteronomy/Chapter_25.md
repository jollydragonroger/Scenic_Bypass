# Deuteronomy Chapter 25: Justice, Levirate Marriage, and Honest Measures

*From the Hebrew: יִבּוּם (Yibbum) — Levirate Marriage*

---

**25:1** "If there is a controversy between men, and they come unto judgment, and the judges judge them; then they shall justify the righteous, and condemn the wicked.

**25:2** "And it shall be, if the wicked man deserves to be beaten, that the judge shall cause him to lie down, and to be beaten before his face, according to his wickedness, by number.

**25:3** "Forty stripes he may give him, he shall not exceed; lest, if he should exceed, and beat him above these with many stripes, then your brother should be dishonored before your eyes.

---

**25:4** "You shall not muzzle the ox when he treads out the grain.

---

**25:5** "If brothers dwell together, and one of them dies, and has no son, the wife of the dead shall not be married outside unto a stranger; her husband's brother shall go in unto her, and take her to him to wife, and perform the duty of a husband's brother unto her—יִבּוּם (yibbum).

**25:6** "And it shall be, that the firstborn that she bears shall succeed in the name of his brother who is dead, that his name be not blotted out of Israel.

**25:7** "And if the man does not want to take his brother's wife, then his brother's wife shall go up to the gate unto the elders, and say: 'My husband's brother refuses to raise up unto his brother a name in Israel; he will not perform the duty of a husband's brother unto me.'

**25:8** "Then the elders of his city shall call him, and speak unto him; and if he stands, and says: 'I do not want to take her';

**25:9** "Then shall his brother's wife come unto him in the presence of the elders, and loose his shoe from off his foot, and spit in his face; and she shall answer and say: 'So shall it be done unto the man who does not build up his brother's house.'

**25:10** "And his name shall be called in Israel: The house of him whose shoe was loosed—בֵּית חֲלוּץ הַנָּעַל (beit chalutz ha-na'al).

---

**25:11** "When men strive together one with another, and the wife of the one draws near to deliver her husband out of the hand of him who smites him, and puts forth her hand, and takes him by the secrets;

**25:12** "Then you shall cut off her hand, your eye shall have no pity.

---

**25:13** "You shall not have in your bag diverse weights, a great and a small.

**25:14** "You shall not have in your house diverse measures, a great and a small.

**25:15** "A perfect and just weight shall you have; a perfect and just measure shall you have; that your days may be long upon the land which YHWH your Consciousness gives you.

**25:16** "For all that do such things, all that do unrighteously, are an abomination unto YHWH your Consciousness.

---

**25:17** "Remember what Amalek did unto you by the way as you came forth out of Egypt;

**25:18** "How he met you by the way, and smote the hindmost of you, all that were feeble behind you, when you were faint and weary; and he feared not God.

**25:19** "Therefore it shall be, when YHWH your Consciousness has given you rest from all your enemies round about, in the land which YHWH your Consciousness gives you for an inheritance to possess it, that you shall blot out the remembrance of Amalek from under heaven; you shall not forget."

---

## Synthesis Notes

**Key Restorations:**

**Limited Flogging (25:1-3):**
When a wicked man deserves beating:
- Maximum forty stripes
- "He shall not exceed"
- Reason: "lest your brother should be dishonored"

Even the guilty remains "your brother." Punishment has limits. Later tradition reduced this to thirty-nine stripes (to avoid accidentally exceeding forty)—the "forty stripes save one" Paul received (2 Corinthians 11:24).

**The Unmuzzled Ox (25:4):**
"You shall not muzzle the ox when he treads out the grain."

The ox doing the work should eat from the grain. This is basic fairness to working animals.

Paul applies this to human workers: "Does God care for oxen? Or does he say it entirely for our sake?" (1 Corinthians 9:9-10). The principle extends: workers deserve to benefit from their labor.

**Levirate Marriage (25:5-10):**
*Yibbum*—when a married man dies without a son:
- His brother should marry the widow
- The first son carries the dead brother's name
- Purpose: "that his name be not blotted out of Israel"

**Refusal:**
If the brother refuses:
- The widow appeals to the elders
- They summon and speak to him
- If he still refuses, she:
  - Removes his sandal
  - Spits in his face
  - Declares: "So shall it be done unto the man who does not build up his brother's house"
- His family becomes known as "the house of him whose shoe was loosed"

The ceremony (*chalitzah*) releases both from the obligation while shaming the refuser.

**Ruth and Boaz:**
The book of Ruth involves a relative (not quite levirate, since Boaz is not the brother) taking responsibility for the family line.

**The Immodest Rescue (25:11-12):**
If a woman intervenes in a fight by grabbing her husband's opponent's genitals:
- Her hand is cut off
- No pity

This is the only mutilation penalty in Deuteronomy besides "eye for eye" (which may be monetary). The severity may relate to potential damage to the man's ability to father children.

**Honest Weights and Measures (25:13-16):**
- No two sets of weights (one for buying, one for selling)
- No diverse measures
- "A perfect and just weight... a perfect and just measure"
- Cheating through false measures is "abomination"

Commercial honesty is theological: dishonest trading offends YHWH.

**Remember Amalek (25:17-19):**
Amalek attacked Israel at their weakest:
- "The hindmost of you"—those trailing behind
- "All that were feeble"—the weak, tired, and vulnerable
- "When you were faint and weary"
- "He feared not God"

Command: "Blot out the remembrance of Amalek from under heaven."

This becomes a perpetual enmity. Saul's failure to destroy Amalek completely (1 Samuel 15) costs him his kingship. Haman the Agagite (Esther 3:1) is an Amalekite, extending the conflict into the Persian period.

**Archetypal Layer:** The forty-stripe limit establishes **dignified punishment**. Even deserved penalty must not degrade the human being beyond measure.

Amalek represents **predation on the vulnerable**—attacking the weak at the rear. This is the opposite of covenant ethics (protect the stranger, orphan, widow). Amalek embodies anti-covenant values.

**Psychological Reading:** The levirate marriage preserves the dead brother's name and memory. In a culture where name continuation was essential, this was profound kindness to the deceased.

**Ethical Inversion Applied:**
- Forty stripes maximum—punishment has limits
- Don't muzzle the ox—workers deserve benefit
- Levirate marriage—responsibility to the dead brother's memory
- Chalitzah shames but releases—refusal is possible with consequence
- Honest weights = righteousness—commerce is ethical
- Amalek attacked the weak—predation on the vulnerable is ultimate offense

**Modern Equivalent:** The forty-stripe limit anticipates prohibitions on cruel and unusual punishment. The unmuzzled ox principle underlies fair labor practices. And honest weights and measures are enforced by consumer protection laws worldwide.

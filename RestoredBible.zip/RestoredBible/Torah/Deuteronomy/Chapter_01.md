# Deuteronomy Chapter 1: Moses' First Address Begins

*From the Hebrew: דְּבָרִים (Devarim) — Words*

---

**1:1** These are the words which Moses spoke unto all Israel beyond the Jordan; in the wilderness, in the Arabah, over against Suph, between Paran and Tophel, and Laban, and Hazeroth, and Di-zahab.

**1:2** It is eleven days' journey from Horeb by the way of Mount Seir unto Kadesh-barnea.

**1:3** And it came to pass in the fortieth year, in the eleventh month, on the first day of the month, that Moses spoke unto the children of Israel, according unto all that YHWH had given him in commandment unto them;

**1:4** After he had smitten Sihon the king of the Amorites, who dwelt in Heshbon, and Og the king of Bashan, who dwelt in Ashtaroth, at Edrei.

**1:5** Beyond the Jordan, in the land of Moab, Moses began to expound this law—הוֹאִיל מֹשֶׁה בֵּאֵר אֶת־הַתּוֹרָה הַזֹּאת (ho'il Mosheh be'er et-ha-Torah ha-zot)—saying:

---

**1:6** "YHWH our Consciousness spoke unto us in Horeb, saying: 'You have dwelt long enough at this mountain.

**1:7** "'Turn, and take your journey, and go to the hill-country of the Amorites, and unto all the places near unto it: in the Arabah, in the hill-country, and in the lowland, and in the South, and by the sea-shore; the land of the Canaanites, and Lebanon, unto the great river, the river Euphrates.

**1:8** "'Behold, I have set the land before you; go in and possess the land which YHWH swore unto your fathers, to Abraham, to Isaac, and to Jacob, to give unto them and to their seed after them.'

**1:9** "And I spoke unto you at that time, saying: 'I am not able to bear you myself alone.

**1:10** "'YHWH your Consciousness has multiplied you, and behold, you are this day as the stars of heaven for multitude.

**1:11** "'YHWH, the Consciousness of your fathers, make you a thousand times as many more as you are, and bless you, as he has promised you!

**1:12** "'How can I myself alone bear your cumbrance, and your burden, and your strife?

**1:13** "'Get yourselves wise men, and understanding, and known among your tribes, and I will make them heads over you.'

**1:14** "And you answered me, and said: 'The thing which you have spoken is good for us to do.'

**1:15** "So I took the heads of your tribes, wise men, and known, and made them heads over you, captains of thousands, and captains of hundreds, and captains of fifties, and captains of tens, and officers, according to your tribes.

**1:16** "And I charged your judges at that time, saying: 'Hear the causes between your brothers, and judge righteously between a man and his brother, and the stranger who is with him.

**1:17** "'You shall not respect persons in judgment; you shall hear the small and the great alike; you shall not be afraid of the face of any man; for the judgment is God's—כִּי הַמִּשְׁפָּט לֵאלֹהִים הוּא (ki ha-mishpat l'Elohim hu); and the cause that is too hard for you, you shall bring unto me, and I will hear it.'

**1:18** "And I commanded you at that time all the things which you should do.

---

**1:19** "And we journeyed from Horeb, and went through all that great and dreadful wilderness which you saw, by the way to the hill-country of the Amorites, as YHWH our Consciousness commanded us; and we came to Kadesh-barnea.

**1:20** "And I said unto you: 'You have come unto the hill-country of the Amorites, which YHWH our Consciousness gives unto us.

**1:21** "'Behold, YHWH your Consciousness has set the land before you; go up, take possession, as YHWH, the Consciousness of your fathers, has spoken unto you; fear not, neither be dismayed.'

**1:22** "And you came near unto me every one of you, and said: 'Let us send men before us, that they may search the land for us, and bring us back word of the way by which we must go up, and the cities unto which we shall come.'

**1:23** "And the thing pleased me well; and I took twelve men of you, one man for every tribe.

**1:24** "And they turned and went up into the hill-country, and came unto the valley of Eshcol, and spied it out.

**1:25** "And they took of the fruit of the land in their hands, and brought it down unto us, and brought us back word, and said: 'Good is the land which YHWH our Consciousness gives unto us.'

**1:26** "Yet you would not go up, but rebelled against the commandment of YHWH your Consciousness.

**1:27** "And you murmured in your tents, and said: 'Because YHWH hates us, he has brought us forth out of the land of Egypt, to deliver us into the hand of the Amorites, to destroy us.

**1:28** "'Where shall we go up? Our brothers have made our heart melt, saying: A people greater and taller than we; cities great and fortified up to heaven; and moreover we have seen the sons of the Anakim there.'

**1:29** "Then I said unto you: 'Dread not, neither be afraid of them.

**1:30** "'YHWH your Consciousness who goes before you, he shall fight for you, according to all that he did for you in Egypt before your eyes;

**1:31** "'And in the wilderness, where you have seen how YHWH your Consciousness bore you, as a man bears his son, in all the way that you went, until you came unto this place.'

**1:32** "Yet in this thing you did not believe in YHWH your Consciousness,

**1:33** "Who went before you in the way, to seek out a place for you to pitch your tents in, in fire by night, to show you by what way you should go, and in the cloud by day.

---

**1:34** "And YHWH heard the voice of your words, and was angry, and swore, saying:

**1:35** "'Surely not one of these men of this evil generation shall see the good land, which I swore to give unto your fathers,

**1:36** "'Save Caleb the son of Jephunneh; he shall see it, and to him will I give the land that he has trodden upon, and to his children, because he has wholly followed YHWH.'

**1:37** "Also YHWH was angry with me for your sakes, saying: 'You also shall not go in there.

**1:38** "'Joshua the son of Nun, who stands before you, he shall go in there; encourage him, for he shall cause Israel to inherit it.'

**1:39** "Moreover your little ones, whom you said would be a prey, and your children, who this day have no knowledge of good or evil, they shall go in there, and unto them will I give it, and they shall possess it.

**1:40** "But as for you, turn, and take your journey into the wilderness by the way to the Red Sea.

**1:41** "Then you answered and said unto me: 'We have sinned against YHWH, we will go up and fight, according to all that YHWH our Consciousness commanded us.' And you girded on every man his weapons of war, and made light of going up into the hill-country.

**1:42** "And YHWH said unto me: 'Say unto them: Go not up, neither fight; for I am not among you; lest you be smitten before your enemies.'

**1:43** "So I spoke unto you, and you did not listen; but you rebelled against the commandment of YHWH, and presumptuously went up into the hill-country.

**1:44** "And the Amorites, who dwelt in that hill-country, came out against you, and chased you, as bees do, and beat you down in Seir, unto Hormah.

**1:45** "And you returned and wept before YHWH; but YHWH did not listen to your voice, nor gave ear unto you.

**1:46** "So you abode in Kadesh many days, according unto the days that you abode there."

---

## Synthesis Notes

**Key Restorations:**

**The Setting:**
"The fortieth year, in the eleventh month, on the first day"—just weeks before Moses' death and Israel's crossing. The Transjordan victories (Sihon, Og) are complete. Moses delivers his final addresses.

**"Eleven Days' Journey":**
The distance from Horeb (Sinai) to Kadesh-barnea is eleven days. Israel took forty years. This poignant note highlights what unbelief cost.

**"Expound This Law":**
*Be'er* (בֵּאֵר)—to make clear, explain, dig into. Deuteronomy is not merely law repetition but interpretation. Moses "expounds" the Torah for the generation that will cross.

**The First Discourse:**
Moses recounts history from Sinai to the present:
1. Departure from Horeb
2. Appointment of judges
3. The spy mission and rebellion
4. The consequences

**Shared Leadership:**
Moses appointed leaders because he could not bear the burden alone. The criteria: "wise, understanding, and known"—character established in community. The structure: thousands, hundreds, fifties, tens.

**"The Judgment Is God's":**
Judges must not respect persons (show partiality), must hear small and great alike, must not fear any man. Why? Because when they judge, they judge on behalf of YHWH. The judicial office is sacred.

**The Spy Mission Retold:**
In Moses' retelling, the initiative for spies came from the people ("You came near unto me... let us send men"). Numbers 13:1 has YHWH commanding the mission. Both perspectives may be true: the people requested it; YHWH permitted it.

**"Because YHWH Hates Us":**
The people's interpretation of their situation: "He brought us out to destroy us." This is the inversion: they interpret liberation as destruction, love as hate.

**YHWH as Father:**
"YHWH your Consciousness bore you, as a man bears his son." The fatherhood of God—carrying Israel through the wilderness as a father carries a child.

**The Sentence:**
Only Caleb (who "wholly followed YHWH") and Joshua will enter. The children (who "have no knowledge of good or evil") will inherit. Moses himself is excluded—"for your sakes."

**Presumptuous Attack:**
After hearing the sentence, Israel decides to fight anyway. "Made light of going up"—they treated it casually. Without YHWH, they were routed.

**Archetypal Layer:** Deuteronomy opens with **retrospective interpretation**. The past is reviewed not merely as history but as lesson. Moses teaches the new generation through the failures of their parents.

The contrast between "eleven days" and "forty years" captures the **cost of unbelief**. What should have been quick became generational.

**Psychological Reading:** Moses' retelling shapes identity. The new generation must understand why they are here (parents' failure) and what is expected (trust YHWH). History becomes formative narrative.

**Ethical Inversion Applied:**
- Judges represent YHWH—judicial authority is sacred trust
- "YHWH hates us" is inverted perception—they called love hate
- YHWH as father bearing son—divine parenting
- The children inherit—the parents' failure opens the children's opportunity
- Presumption is not faith—going without YHWH is worse than not going

**Modern Equivalent:** Leadership requires delegation and shared burden. Judicial impartiality ("hear small and great alike") remains foundational. And the retrospective teaching—here's what happened, here's what it means—shapes how communities form identity through remembered history.

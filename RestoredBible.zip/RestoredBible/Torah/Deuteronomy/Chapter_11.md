# Deuteronomy Chapter 11: Love, Obey, and Choose Life

*From the Hebrew: בְּרָכָה וּקְלָלָה (Berachah U-Qelalah) — Blessing and Curse*

---

**11:1** "Therefore you shall love YHWH your Consciousness, and keep his charge, and his statutes, and his ordinances, and his commandments, always.

**11:2** "And know this day; for I speak not with your children who have not known, and who have not seen the discipline of YHWH your Consciousness, his greatness, his mighty hand, and his outstretched arm,

**11:3** "And his signs, and his works, which he did in the midst of Egypt unto Pharaoh the king of Egypt, and unto all his land;

**11:4** "And what he did unto the army of Egypt, unto their horses, and to their chariots; how he made the water of the Red Sea to overflow them as they pursued after you, and how YHWH has destroyed them unto this day;

**11:5** "And what he did unto you in the wilderness, until you came unto this place;

**11:6** "And what he did unto Dathan and Abiram, the sons of Eliab, the son of Reuben; how the earth opened her mouth, and swallowed them up, and their households, and their tents, and every living thing that followed them, in the midst of all Israel.

**11:7** "But your eyes have seen all the great work of YHWH which he did.

---

**11:8** "Therefore shall you keep all the commandment which I command you this day, that you may be strong, and go in and possess the land, into which you go over to possess it;

**11:9** "And that you may prolong your days upon the land, which YHWH swore unto your fathers to give unto them and to their seed, a land flowing with milk and honey.

**11:10** "For the land, into which you go in to possess it, is not as the land of Egypt, from which you came out, where you sowed your seed, and watered it with your foot, as a garden of herbs.

**11:11** "But the land, into which you go over to possess it, is a land of hills and valleys, and drinks water of the rain of heaven;

**11:12** "A land which YHWH your Consciousness cares for; the eyes of YHWH your Consciousness are always upon it, from the beginning of the year even unto the end of the year.

---

**11:13** "And it shall come to pass, if you shall listen diligently unto my commandments which I command you this day, to love YHWH your Consciousness, and to serve him with all your heart and with all your soul,

**11:14** "That I will give the rain of your land in its season, the former rain and the latter rain, that you may gather in your grain, and your wine, and your oil.

**11:15** "And I will give grass in your fields for your cattle, and you shall eat and be satisfied.

**11:16** "Take heed to yourselves, lest your heart be deceived, and you turn aside, and serve other gods, and worship them;

**11:17** "And the anger of YHWH be kindled against you, and he shut up the heavens, so that there shall be no rain, and the ground shall not yield its fruit; and you perish quickly from off the good land which YHWH gives you.

---

**11:18** "Therefore shall you lay up these my words in your heart and in your soul; and you shall bind them for a sign upon your hand, and they shall be for frontlets between your eyes.

**11:19** "And you shall teach them to your children, talking of them when you sit in your house, and when you walk by the way, and when you lie down, and when you rise up.

**11:20** "And you shall write them upon the doorposts of your house, and upon your gates;

**11:21** "That your days may be multiplied, and the days of your children, upon the land which YHWH swore unto your fathers to give them, as the days of the heavens above the earth.

**11:22** "For if you shall diligently keep all this commandment which I command you, to do it, to love YHWH your Consciousness, to walk in all his ways, and to cleave unto him,

**11:23** "Then will YHWH drive out all these nations from before you, and you shall dispossess nations greater and mightier than yourselves.

**11:24** "Every place on which the sole of your foot shall tread shall be yours: from the wilderness, and Lebanon, from the river, the river Euphrates, even unto the hinder sea shall be your border.

**11:25** "There shall no man be able to stand before you: YHWH your Consciousness shall lay the fear of you and the dread of you upon all the land that you shall tread upon, as he has spoken unto you.

---

**11:26** "Behold, I set before you this day a blessing and a curse—בְּרָכָה וּקְלָלָה (berachah u-qelalah):

**11:27** "The blessing, if you shall listen unto the commandments of YHWH your Consciousness, which I command you this day;

**11:28** "And the curse, if you shall not listen unto the commandments of YHWH your Consciousness, but turn aside out of the way which I command you this day, to go after other gods, which you have not known.

**11:29** "And it shall come to pass, when YHWH your Consciousness shall bring you into the land into which you go to possess it, that you shall set the blessing upon Mount Gerizim, and the curse upon Mount Ebal.

**11:30** "Are they not beyond the Jordan, behind the way of the going down of the sun, in the land of the Canaanites who dwell in the Arabah, over against Gilgal, beside the terebinths of Moreh?

**11:31** "For you are to pass over the Jordan to go in to possess the land which YHWH your Consciousness gives you, and you shall possess it, and dwell therein.

**11:32** "And you shall observe to do all the statutes and the ordinances which I set before you this day."

---

## Synthesis Notes

**Key Restorations:**

**"Your Eyes Have Seen":**
Moses addresses those who witnessed YHWH's acts:
- The plagues in Egypt
- The Red Sea overwhelming Pharaoh's army
- The wilderness provisions
- The earth swallowing Dathan and Abiram

This generation has firsthand experience. Their children will learn through teaching; they know through seeing.

**Egypt vs. Canaan:**
A contrast between irrigation and rain-fed agriculture:

**Egypt**: "You sowed your seed, and watered it with your foot"—irrigation from the Nile, controlled by human effort (foot-powered water wheels or channel-digging).

**Canaan**: "A land of hills and valleys, and drinks water of the rain of heaven"—dependent on seasonal rains, not human engineering.

**Theological Implication:**
In Egypt, you controlled the water. In Canaan, YHWH controls the water. The land requires faith-dependence on divine provision. "The eyes of YHWH your Consciousness are always upon it."

**Former and Latter Rain:**
*Yoreh* (autumn/early rain) prepares the ground for planting. *Malqosh* (spring/late rain) brings the crops to maturity. Both are necessary; both come from YHWH.

**The Conditional Covenant:**
If you obey: rain in season, abundant harvest, satisfaction.
If you turn aside: heaven shut, ground barren, perishing from the land.

The land's fertility is tied to covenant faithfulness.

**The Second Shema Passage (11:13-21):**
This passage is the second paragraph of the traditional Shema prayer (after 6:4-9). It repeats the instructions:
- Lay up the words in heart and soul
- Bind them on hand and forehead (*tefillin*)
- Teach them to children constantly
- Write them on doorposts and gates (*mezuzah*)

**The Promise of the Land:**
"Every place on which the sole of your foot shall tread shall be yours"—from the wilderness to Lebanon, from the Euphrates to the Mediterranean ("the hinder sea"). This is the maximal boundary, rarely achieved.

**Blessing and Curse:**
"I set before you this day a blessing and a curse." The choice is clear:
- Blessing: listen to the commandments
- Curse: turn aside to other gods

**Gerizim and Ebal:**
Two mountains flanking Shechem. Upon entering the land:
- Mount Gerizim: the blessing pronounced
- Mount Ebal: the curse pronounced

This ceremony is described in detail in Deuteronomy 27 and executed in Joshua 8:30-35.

**Archetypal Layer:** The contrast between Egypt and Canaan represents **the shift from human control to divine dependence**. Egypt's predictable Nile required human effort; Canaan's unpredictable rains require faith.

The blessing/curse choice is the **covenantal either/or**. There is no neutral ground. Obedience leads one direction; disobedience leads the other.

**Psychological Reading:** The repeated emphasis on teaching children, talking constantly, binding on body and doorpost creates a **total environment of formation**. The words are not just studied but lived in.

**Ethical Inversion Applied:**
- "Your eyes have seen"—firsthand experience grounds faith
- Canaan requires rain—dependence on YHWH, not irrigation
- "The eyes of YHWH are always upon it"—divine attention on the land
- Rain or drought—weather expresses covenant relationship
- Teach children constantly—faith is transmitted through saturation
- Blessing and curse—the choice is presented clearly

**Modern Equivalent:** The shift from Egypt to Canaan mirrors any transition from controlled to dependent circumstances. The principle of environmental formation (words everywhere, constant conversation) shapes how communities transmit values. And the blessing/curse choice frames life as consequential decision.

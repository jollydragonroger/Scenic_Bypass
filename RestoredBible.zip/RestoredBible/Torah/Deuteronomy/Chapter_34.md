# Deuteronomy Chapter 34: The Death of Moses

*From the Hebrew: מוֹת מֹשֶׁה (Mot Mosheh) — The Death of Moses*

---

**34:1** And Moses went up from the plains of Moab unto Mount Nebo, to the top of Pisgah, that is over against Jericho. And YHWH showed him all the land: the Gilead, unto Dan;

**34:2** And all Naphtali, and the land of Ephraim and Manasseh, and all the land of Judah, unto the hinder sea;

**34:3** And the South, and the Plain, the valley of Jericho the city of palm trees, unto Zoar.

**34:4** And YHWH said unto him: "This is the land which I swore unto Abraham, unto Isaac, and unto Jacob, saying: 'I will give it unto your seed.' I have caused you to see it with your eyes, but you shall not go over there."

**34:5** So Moses the servant of YHWH died there in the land of Moab, according to the word of YHWH—וַיָּמָת שָׁם מֹשֶׁה עֶבֶד־יהוה (va-yamot sham Mosheh eved-YHWH).

**34:6** And he buried him in the valley in the land of Moab over against Beth-peor; and no man knows of his burial place unto this day.

**34:7** And Moses was a hundred and twenty years old when he died; his eye was not dim, nor his natural force abated—לֹא־כָהֲתָה עֵינוֹ וְלֹא־נָס לֵחֹה (lo-chahatah eino ve-lo-nas lechoh).

**34:8** And the children of Israel wept for Moses in the plains of Moab thirty days; so the days of weeping in the mourning for Moses were ended.

**34:9** And Joshua the son of Nun was full of the spirit of wisdom—רוּחַ חָכְמָה (ruach chochmah)—for Moses had laid his hands upon him; and the children of Israel listened unto him, and did as YHWH commanded Moses.

**34:10** And there has not arisen a prophet since in Israel like unto Moses, whom YHWH knew face to face—פָּנִים אֶל־פָּנִים (panim el-panim);

**34:11** In all the signs and the wonders, which YHWH sent him to do in the land of Egypt, to Pharaoh, and to all his servants, and to all his land;

**34:12** And in all the mighty hand, and in all the great terror, which Moses wrought in the sight of all Israel.

---

## Synthesis Notes

**Key Restorations:**

**The Ascent:**
Moses climbs from the plains of Moab to Mount Nebo, to the summit of Pisgah. From there he can see across the Jordan to the promised land.

**The Panorama:**
YHWH shows Moses the entire land:
- **North**: Gilead to Dan (the far north)
- **Central north**: Naphtali
- **Central**: Ephraim and Manasseh
- **South central**: Judah to the Mediterranean ("the hinder sea")
- **South**: The Negev
- **The Valley**: The Jordan valley, Jericho (city of palms), to Zoar

This is a supernatural viewing—no physical vantage point could see all this. YHWH enables Moses to see what natural sight could not.

**The Restatement:**
"This is the land which I swore unto Abraham, unto Isaac, and unto Jacob." The patriarchal promise is recalled at the moment of its near-fulfillment. "I have caused you to see it with your eyes, but you shall not go over there."

Moses sees but cannot enter. Vision without possession. The sentence from Meribah stands.

**"According to the Word of YHWH":**
*Al pi YHWH*—literally "at the mouth of YHWH." Jewish tradition reads this as Moses dying "by the kiss of God"—a gentle death, the soul drawn out by divine breath.

**The Burial:**
"And he buried him"—the subject is ambiguous. YHWH buried Moses. Or: Moses was buried (passive). "No man knows of his burial place unto this day."

The hidden grave prevents the site from becoming a shrine. Moses cannot become an object of worship.

**120 Years:**
Moses dies at 120, the ideal human lifespan (Genesis 6:3). "His eye was not dim, nor his natural force abated"—he died in full vigor, not from decay.

**Thirty Days of Mourning:**
The same period observed for Aaron (Numbers 20:29). National grief for the departed leader.

**Joshua's Succession:**
Joshua is "full of the spirit of wisdom" because Moses laid hands on him (Numbers 27:18-23). The succession is effective; Israel listens to Joshua as they listened to Moses.

**The Epitaph (34:10-12):**
"There has not arisen a prophet since in Israel like unto Moses":
- Whom YHWH knew **face to face** (*panim el-panim*)
- In all the **signs and wonders** in Egypt
- In all the **mighty hand and great terror** before all Israel

Moses is unique. Other prophets receive visions and dreams; Moses spoke with YHWH directly (Numbers 12:6-8). No one has matched him.

**The Torah Closes:**
With Moses' death, the Torah ends. The five books of Moses conclude where the lawgiver concludes. Joshua will begin the next chapter of Israel's story.

**Who Wrote This?:**
The chapter describes Moses' death. Tradition suggests Joshua wrote this final chapter, or Moses wrote prophetically about his own death, or it was added later by divinely authorized editors.

**Archetypal Layer:** Moses' death on the mountain, seeing but not entering, represents **the leader who brings others to the threshold but cannot cross himself**. His work was to deliver and teach; another will complete the conquest.

The hidden grave prevents **idolatry of the servant**. Moses must not become the focus. YHWH alone is to be worshipped.

**Psychological Reading:** The thirty days of mourning provide structured grief. The community processes loss together, within time boundaries.

Joshua's authority comes through transmitted blessing (laying on of hands) and demonstrated wisdom. Succession requires both symbolic transfer and personal qualification.

**Ethical Inversion Applied:**
- Vision without possession—Moses sees but cannot enter
- "By the mouth of YHWH"—death as divine kiss
- Unknown grave—prevents shrine-worship
- Full vigor at 120—death not from decay
- Joshua full of wisdom—effective succession
- "No prophet like Moses"—unique and unsurpassed

---

## Book Summary: Deuteronomy

Deuteronomy ("Second Law" in Greek; *Devarim*, "Words," in Hebrew) is Moses' farewell address to the generation that will enter the land.

**Structure:**
1. **First Address** (1-4): Historical review, exhortation to obedience
2. **Second Address** (5-26): The law restated—Shema, commandments, social legislation
3. **Third Address** (27-28): Blessings and curses at Gerizim and Ebal
4. **Fourth Address** (29-30): Covenant renewal, "choose life"
5. **Conclusion** (31-34): Song, blessing, death of Moses

**Themes:**
- **Remember**: The past instructs the present; memory shapes identity
- **Hear**: *Shema*—obedience flows from hearing
- **Love**: YHWH loves Israel; Israel is to love YHWH with all heart, soul, might
- **One Place**: Centralized worship at the place YHWH chooses
- **Choose**: Life and death, blessing and curse—the choice is presented
- **Succession**: Moses to Joshua; one generation to the next

**The Heart of Deuteronomy:**
"Hear, O Israel: YHWH our God, YHWH is one. And you shall love YHWH your God with all your heart, and with all your soul, and with all your might" (6:4-5).

---

## Torah Summary: The Five Books of Moses

The Torah is complete:

| Book | Hebrew Name | Chapters | Theme |
|------|-------------|----------|-------|
| Genesis | Bereshit | 50 | Beginnings—creation, patriarchs, descent to Egypt |
| Exodus | Shemot | 40 | Deliverance—Egypt, Sinai, tabernacle |
| Leviticus | Vayiqra | 27 | Holiness—offerings, purity, sacred calendar |
| Numbers | Bemidbar | 36 | Wilderness—census, wandering, approach to land |
| Deuteronomy | Devarim | 34 | Covenant—Moses' farewell, law restated, death |

**Total: 187 chapters**

The Torah narrates from creation to the edge of the promised land. It establishes Israel's identity, covenant, and law. What follows (Joshua through Kings) tells the story of possession and loss; the Prophets interpret that history; the Writings respond in poetry, wisdom, and apocalyptic vision. But the Torah is the foundation—the instruction, the teaching, the way.

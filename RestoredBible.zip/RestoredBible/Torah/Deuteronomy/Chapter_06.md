# Deuteronomy Chapter 6: The Shema

*From the Hebrew: שְׁמַע יִשְׂרָאֵל (Shema Yisra'el) — Hear, O Israel*

---

**6:1** "Now this is the commandment, the statutes, and the ordinances, which YHWH your Consciousness commanded to teach you, that you might do them in the land into which you go over to possess it;

**6:2** "That you might fear YHWH your Consciousness, to keep all his statutes and his commandments, which I command you, you, and your son, and your son's son, all the days of your life; and that your days may be prolonged.

**6:3** "Hear therefore, O Israel, and observe to do it; that it may be well with you, and that you may increase mightily, as YHWH, the Consciousness of your fathers, promised unto you—a land flowing with milk and honey.

---

**6:4** "Hear, O Israel: YHWH our Consciousness, YHWH is one—שְׁמַע יִשְׂרָאֵל יהוה אֱלֹהֵינוּ יהוה אֶחָד (Shema Yisra'el YHWH Eloheinu YHWH echad).

**6:5** "And you shall love YHWH your Consciousness with all your heart, and with all your soul, and with all your might—בְּכָל־לְבָבְךָ וּבְכָל־נַפְשְׁךָ וּבְכָל־מְאֹדֶךָ (be-chol-levavcha u-ve-chol-nafshecha u-ve-chol-me'odecha).

**6:6** "And these words, which I command you this day, shall be upon your heart.

**6:7** "And you shall teach them diligently unto your children, and shall talk of them when you sit in your house, and when you walk by the way, and when you lie down, and when you rise up.

**6:8** "And you shall bind them for a sign upon your hand, and they shall be for frontlets between your eyes.

**6:9** "And you shall write them upon the doorposts of your house, and upon your gates.

---

**6:10** "And it shall be, when YHWH your Consciousness shall bring you into the land which he swore unto your fathers, to Abraham, to Isaac, and to Jacob, to give you—great and goodly cities, which you did not build,

**6:11** "And houses full of all good things, which you did not fill, and cisterns hewn out, which you did not hew, vineyards and olive trees, which you did not plant, and you shall eat and be satisfied—

**6:12** "Then beware lest you forget YHWH, who brought you forth out of the land of Egypt, out of the house of bondage.

**6:13** "You shall fear YHWH your Consciousness, and him shall you serve, and by his name shall you swear.

**6:14** "You shall not go after other gods, of the gods of the peoples who are round about you—

**6:15** "For YHWH your Consciousness in the midst of you is a jealous God—אֵל קַנָּא (El qanna)—lest the anger of YHWH your Consciousness be kindled against you, and he destroy you from off the face of the earth.

**6:16** "You shall not try YHWH your Consciousness, as you tried him in Massah.

**6:17** "You shall diligently keep the commandments of YHWH your Consciousness, and his testimonies, and his statutes, which he has commanded you.

**6:18** "And you shall do that which is right and good in the sight of YHWH; that it may be well with you, and that you may go in and possess the good land which YHWH swore unto your fathers,

**6:19** "To thrust out all your enemies from before you, as YHWH has spoken.

---

**6:20** "When your son asks you in time to come, saying: 'What mean the testimonies, and the statutes, and the ordinances, which YHWH our Consciousness has commanded you?'

**6:21** "Then you shall say unto your son: 'We were Pharaoh's bondmen in Egypt; and YHWH brought us out of Egypt with a mighty hand.

**6:22** "'And YHWH showed signs and wonders, great and sore, upon Egypt, upon Pharaoh, and upon all his house, before our eyes.

**6:23** "'And he brought us out from there, that he might bring us in, to give us the land which he swore unto our fathers.

**6:24** "'And YHWH commanded us to do all these statutes, to fear YHWH our Consciousness, for our good always, that he might preserve us alive, as at this day.

**6:25** "'And it shall be righteousness unto us—צְדָקָה (tsedaqah)—if we observe to do all this commandment before YHWH our Consciousness, as he has commanded us.'"

---

## Synthesis Notes

**Key Restorations:**

**The Shema (6:4-9):**
The central confession of Israel's faith, recited twice daily in Jewish practice:

**"Hear, O Israel: YHWH our God, YHWH is one"**

The Hebrew allows multiple translations:
- "YHWH our God, YHWH is one"
- "YHWH our God is one YHWH"
- "YHWH is our God, YHWH alone"

All emphasize YHWH's uniqueness and Israel's exclusive devotion.

**The Great Commandment:**
"You shall love YHWH your Consciousness with all your heart, and with all your soul, and with all your might."

- **Heart** (*levav*)—will, intention, inner self
- **Soul** (*nefesh*)—life force, being, passion
- **Might** (*me'od*)—strength, resources, "very-ness"

Total love—nothing held back.

**Transmission:**
The words are to be:
1. **Upon your heart**—internalized
2. **Taught diligently to children**—generational transmission
3. **Spoken constantly**—sitting, walking, lying down, rising
4. **Bound on hand and forehead**—physical reminder (origin of *tefillin*)
5. **Written on doorposts and gates**—public declaration (origin of *mezuzah*)

**The Danger of Prosperity:**
When you inherit what you did not build—cities, houses, cisterns, vineyards—"beware lest you forget YHWH." Prosperity breeds forgetfulness. Abundance is spiritually dangerous.

**"You Shall Not Try YHWH":**
Reference to Massah (Exodus 17:1-7), where Israel tested YHWH by demanding, "Is YHWH among us or not?" Testing God—demanding proof before trusting—is forbidden.

**The Child's Question:**
"What mean the testimonies, and the statutes, and the ordinances?" The parent's response is narrative: "We were slaves... YHWH brought us out... he gave us the land... the commandments are for our good."

The laws are grounded in story. Ethics flows from narrative. "Why do we do this?" is answered by "This is what happened to us."

**"Righteousness Unto Us":**
Obedience is *tsedaqah*—righteousness. The doing of commandments is not merely obligation but right standing before YHWH.

**Archetypal Layer:** The Shema is Israel's **confession of faith**—not a creed about God's nature but a declaration of exclusive loyalty. "YHWH is one" means undivided devotion is required.

The commandment to love with heart, soul, and might represents **total commitment**. Love is not merely emotion but will, life, and resources directed toward YHWH.

**Psychological Reading:** The constant repetition (sitting, walking, lying down, rising) creates formation. Identity is shaped by what is repeatedly spoken. The binding on body and doorpost makes the invisible visible—commitment becomes tangible.

**Ethical Inversion Applied:**
- "YHWH is one"—exclusive devotion, no divided loyalty
- Love with all heart, soul, might—total commitment
- Teach diligently—faith is transmitted, not assumed
- Prosperity breeds forgetfulness—abundance is dangerous
- "For our good always"—commandments are gift, not burden
- Answer through story—ethics grounded in narrative

**Jesus' Citation:**
When asked about the greatest commandment, Jesus quoted Deuteronomy 6:4-5, adding Leviticus 19:18 ("love your neighbor as yourself"). The Shema remains central.

**Modern Equivalent:** The Shema's emphasis on constant repetition and physical reminders anticipates how habits form identity. The warning about prosperity's spiritual danger remains relevant in affluent societies. And grounding ethics in narrative (not abstract principle) shapes how communities transmit values.

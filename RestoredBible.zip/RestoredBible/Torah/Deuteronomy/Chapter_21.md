# Deuteronomy Chapter 21: Unsolved Murder, Captives, and Family Laws

*From the Hebrew: עֶגְלָה עֲרוּפָה (Eglah Arufah) — The Broken-Necked Heifer*

---

**21:1** "If one is found slain in the land which YHWH your Consciousness gives you to possess it, lying in the field, and it is not known who has smitten him;

**21:2** "Then your elders and your judges shall come forth, and they shall measure unto the cities which are round about him who is slain.

**21:3** "And it shall be, that the city which is nearest unto the slain man, the elders of that city shall take a heifer of the herd, which has not been worked, and which has not drawn in the yoke.

**21:4** "And the elders of that city shall bring down the heifer unto a rough valley, which may neither be plowed nor sown, and shall break the heifer's neck there in the valley.

**21:5** "And the priests the sons of Levi shall come near—for them YHWH your Consciousness has chosen to minister unto him, and to bless in the name of YHWH; and according to their word shall every controversy and every stroke be.

**21:6** "And all the elders of that city, who are nearest unto the slain man, shall wash their hands over the heifer whose neck was broken in the valley.

**21:7** "And they shall answer and say: 'Our hands have not shed this blood, neither have our eyes seen it.

**21:8** "'Forgive, O YHWH, your people Israel, whom you have redeemed, and suffer not innocent blood to remain in the midst of your people Israel.' And the blood shall be forgiven them.

**21:9** "So shall you put away the innocent blood from the midst of you, when you shall do that which is right in the eyes of YHWH."

---

**21:10** "When you go forth to battle against your enemies, and YHWH your Consciousness delivers them into your hands, and you carry them away captive,

**21:11** "And you see among the captives a beautiful woman, and you desire her, and would take her to you as wife;

**21:12** "Then you shall bring her home to your house; and she shall shave her head, and do her nails;

**21:13** "And she shall put the raiment of her captivity from off her, and shall remain in your house, and bewail her father and her mother a full month; and after that you may go in unto her, and be her husband, and she shall be your wife.

**21:14** "And it shall be, if you have no delight in her, then you shall let her go wherever she will; but you shall not sell her at all for money, you shall not deal with her as a slave, because you have humbled her."

---

**21:15** "If a man has two wives, the one beloved, and the other hated, and they have borne him children, both the beloved and the hated; and if the firstborn son is hers who was hated;

**21:16** "Then it shall be, in the day that he causes his sons to inherit that which he has, that he may not make the son of the beloved the firstborn before the son of the hated, who is the firstborn.

**21:17** "But he shall acknowledge the firstborn, the son of the hated, by giving him a double portion of all that he has; for he is the beginning of his strength, the right of the firstborn is his."

---

**21:18** "If a man has a stubborn and rebellious son, who does not listen to the voice of his father, or the voice of his mother, and though they chastise him, will not listen unto them;

**21:19** "Then shall his father and his mother lay hold on him, and bring him out unto the elders of his city, and unto the gate of his place;

**21:20** "And they shall say unto the elders of his city: 'This our son is stubborn and rebellious, he does not listen to our voice; he is a glutton, and a drunkard.'

**21:21** "And all the men of his city shall stone him with stones, that he die; so shall you put away the evil from the midst of you; and all Israel shall hear, and fear."

---

**21:22** "And if a man has committed a sin worthy of death, and he is put to death, and you hang him on a tree;

**21:23** "His body shall not remain all night upon the tree, but you shall surely bury him the same day; for he who is hanged is a curse of God—קִלְלַת אֱלֹהִים (qilelat Elohim); that you defile not your land which YHWH your Consciousness gives you for an inheritance."

---

## Synthesis Notes

**Key Restorations:**

**The Unsolved Murder (21:1-9):**
When a corpse is found in the open country with no known killer:

1. **Elders and judges measure** to find the nearest city
2. **That city's elders** take an unworked heifer (never yoked)
3. **In a rough, uncultivated valley**, they break the heifer's neck
4. **Priests witness** the ceremony
5. **Elders wash hands** over the heifer
6. **Declaration**: "Our hands have not shed this blood, neither have our eyes seen it"
7. **Prayer**: "Forgive, O YHWH, your people Israel"

**The Theology:**
Unsolved murder pollutes the land. Innocent blood cries out. The community must take responsibility even when individuals cannot be identified. The heifer's death substitutes for the unknown murderer.

**The Captive Woman (21:10-14):**
A beautiful captive from war may become a wife, but with protections:
- She shaves her head and trims her nails (mourning rituals)
- She changes from captive garments
- She mourns her parents for a full month
- Only then may the man marry her
- If later he "has no delight in her," she goes free—not sold as a slave

**The Waiting Period:**
The month of mourning humanizes her. She is not taken immediately in lust. The process allows grief and transition.

**"Because You Have Humbled Her":**
*Ki innitah*—the sexual relationship changes her status. She cannot be sold afterward; she has rights.

**The Firstborn of the Unloved Wife (21:15-17):**
If a man has two wives (one loved, one hated) and the firstborn is from the hated wife:
- He may not transfer firstborn status to the beloved wife's son
- The actual firstborn receives the double portion
- "The right of the firstborn is his"

This protects inheritance from favoritism. Jacob's manipulation of birthright (preferring Joseph) is here prohibited.

**The Rebellious Son (21:18-21):**
A son who is:
- Stubborn and rebellious
- Disobedient to both parents
- Unchastened despite discipline
- "A glutton, and a drunkard"

Both parents must bring him to the elders. The community stones him.

**Safeguards:**
- Both parents must agree (prevents single-parent revenge)
- The case goes to elders (community judgment, not private execution)
- The public process ensures scrutiny

**The Hanged Criminal (21:22-23):**
A criminal executed and hung for public display must be buried the same day. Why? "He who is hanged is a curse of God."

The displayed corpse defiles the land if left overnight.

**Paul's Use:**
Paul quotes this in Galatians 3:13: "Cursed is everyone who hangs on a tree." Christ's crucifixion is understood through this text.

**Archetypal Layer:** The unsolved murder ceremony addresses **corporate responsibility**. The community cannot ignore violence in its midst; ritual action acknowledges the unresolved guilt.

The captive woman law provides **protections in exploitation**. In a brutal context (war captives), the law humanizes: waiting period, mourning, freedom if rejected.

**Psychological Reading:** The rebellious son law is rarely (perhaps never) applied in recorded Jewish history. The Talmud surrounds it with so many qualifications that it becomes theoretical. Its function may be deterrent rather than practical.

**Ethical Inversion Applied:**
- Unsolved murder requires ritual response—the community is responsible
- Captive woman has rights—waiting period, mourning, protection from sale
- Firstborn rights protected—favoritism cannot override birth order
- Both parents must accuse—prevents single-parent abuse of the law
- Same-day burial—the land must not be defiled

**Modern Equivalent:** The unsolved murder ritual anticipates cold case investigations and community accountability. The captive woman protections (waiting period, right to freedom) anticipate protections for vulnerable persons. And the requirement of same-day burial influences Jewish burial customs to this day.

# Deuteronomy Chapter 24: Divorce, Justice, and Compassion

*From the Hebrew: סֵפֶר כְּרִיתֻת (Sefer Keritut) — Certificate of Divorce*

---

**24:1** "When a man takes a wife, and marries her, then it comes to pass, if she finds no favor in his eyes, because he has found some unseemly thing in her, that he writes her a bill of divorcement—סֵפֶר כְּרִיתֻת (sefer keritut)—and gives it in her hand, and sends her out of his house,

**24:2** "And she departs out of his house, and goes and becomes another man's wife,

**24:3** "And the latter husband hates her, and writes her a bill of divorcement, and gives it in her hand, and sends her out of his house; or if the latter husband die, who took her to be his wife;

**24:4** "Her former husband, who sent her away, may not take her again to be his wife, after that she is defiled; for that is abomination before YHWH; and you shall not cause the land to sin, which YHWH your Consciousness gives you for an inheritance.

---

**24:5** "When a man takes a new wife, he shall not go out in the host, neither shall he be charged with any business; he shall be free at home one year, and shall cheer his wife whom he has taken.

---

**24:6** "No man shall take the mill or the upper millstone to pledge; for he takes a man's life to pledge.

---

**24:7** "If a man is found stealing any of his brothers of the children of Israel, and he deals with him as a slave, or sells him; then that thief shall die; so shall you put away the evil from the midst of you.

---

**24:8** "Take heed in the plague of leprosy, that you observe diligently, and do according to all that the priests the Levites shall teach you; as I commanded them, so you shall observe to do.

**24:9** "Remember what YHWH your Consciousness did unto Miriam, by the way as you came forth out of Egypt.

---

**24:10** "When you do lend your neighbor any manner of loan, you shall not go into his house to fetch his pledge.

**24:11** "You shall stand outside, and the man to whom you do lend shall bring forth the pledge outside unto you.

**24:12** "And if he is a poor man, you shall not sleep with his pledge.

**24:13** "You shall surely restore to him the pledge when the sun goes down, that he may sleep in his garment, and bless you; and it shall be righteousness unto you before YHWH your Consciousness.

---

**24:14** "You shall not oppress a hired servant who is poor and needy, whether he is of your brothers, or of your strangers who are in your land within your gates.

**24:15** "In his day you shall give him his hire, neither shall the sun go down upon it; for he is poor, and sets his heart upon it; lest he cry against you unto YHWH, and it be sin in you.

---

**24:16** "The fathers shall not be put to death for the children, neither shall the children be put to death for the fathers; every man shall be put to death for his own sin.

---

**24:17** "You shall not pervert the justice due to the stranger, or to the fatherless; nor take a widow's raiment to pledge.

**24:18** "But you shall remember that you were a bondman in Egypt, and YHWH your Consciousness redeemed you from there; therefore I command you to do this thing.

**24:19** "When you reap your harvest in your field, and have forgotten a sheaf in the field, you shall not go back to fetch it; it shall be for the stranger, for the fatherless, and for the widow; that YHWH your Consciousness may bless you in all the work of your hands.

**24:20** "When you beat your olive tree, you shall not go over the boughs again; it shall be for the stranger, for the fatherless, and for the widow.

**24:21** "When you gather the grapes of your vineyard, you shall not glean it after yourself; it shall be for the stranger, for the fatherless, and for the widow.

**24:22** "And you shall remember that you were a bondman in the land of Egypt; therefore I command you to do this thing."

---

## Synthesis Notes

**Key Restorations:**

**Divorce Law (24:1-4):**
The text does not command divorce but regulates an existing practice:
- If a man finds "some unseemly thing" (*ervat davar*) in his wife
- He writes a formal certificate of divorce (*sefer keritut*)
- She may remarry
- If divorced again or widowed, the **first husband may not take her back**

**The Prohibition:**
Remarrying the first husband after an intervening marriage is "abomination"—it would "cause the land to sin." The precise rationale is debated: perhaps preventing wife-swapping arrangements or treating marriage with frivolity.

**Jesus' Teaching:**
Jesus referenced this passage in Matthew 19:3-9, arguing that Moses permitted divorce because of hardness of heart, but God's original intent was permanent union.

**Newlywed Exemption (24:5):**
A newly married man is exempt for one year:
- No military service
- No business obligations
- "Shall cheer his wife whom he has taken"

The first year of marriage is protected time.

**The Millstone Pledge (24:6):**
You may not take a millstone (or its upper stone) as collateral. Why? "He takes a man's life to pledge"—without the mill, the family cannot grind grain for daily bread. You would be pledging survival.

**Kidnapping (24:7):**
Stealing a person (to enslave or sell) is a capital offense. This is the eighth commandment (stealing) applied to persons. Death penalty: "so shall you put away the evil."

**Leprosy Warning (24:8-9):**
Follow the priests' instructions regarding *tsara'at* (skin disease). "Remember what YHWH... did unto Miriam"—she was struck with leprosy for challenging Moses (Numbers 12). The warning is to take these conditions seriously.

**Pledge Dignity (24:10-13):**
When collecting collateral:
- Don't enter the borrower's house—wait outside
- If the pledge is a poor man's cloak, return it by sunset
- "That he may sleep in his garment"—the cloak is his blanket

Returning the pledge is "righteousness before YHWH."

**Same-Day Wages (24:14-15):**
Pay the poor worker before sunset:
- "He is poor, and sets his heart upon it"—he depends on daily wages
- Delayed payment causes him to cry to YHWH
- That cry makes it "sin in you"

**Individual Responsibility (24:16):**
"Fathers shall not be put to death for children, neither children for fathers; every man shall be put to death for his own sin."

This limits corporate punishment. Guilt is individual in capital cases. (Later, Amaziah applied this principle in 2 Kings 14:6.)

**Justice for the Vulnerable (24:17-18):**
- No perverting justice due to stranger or orphan
- No taking widow's garment as pledge
- "Remember that you were a bondman in Egypt"

Memory of vulnerability creates ethical obligation.

**Gleaning Laws (24:19-22):**
During harvest:
- Forgotten sheaf: leave it
- Olive tree: don't go over branches twice
- Vineyard: don't glean a second time

What remains is for the stranger, orphan, and widow. This is Ruth's story (Ruth 2)—gleaning in Boaz's field.

**Archetypal Layer:** The gleaning laws create **structured provision** for the poor within ordinary economic activity. Harvesting is not maximally efficient; deliberate leaving ensures the vulnerable can eat.

The pledge dignity laws protect **human worth even in debt**. The poor man's cloak may be legally taken but must be humanely returned.

**Psychological Reading:** "He sets his heart upon it" acknowledges the psychological weight of waiting for wages. The poor worker's anxiety about payment is recognized and addressed.

**Ethical Inversion Applied:**
- Divorce regulated, not commanded—limitation, not permission
- Newlywed year protected—marriage takes priority
- Millstone = life—some collateral is off-limits
- Wait outside—pledging preserves dignity
- Pay before sunset—the worker's need is urgent
- Individual punishment—children don't die for fathers
- Leave gleanings—provision through deliberate inefficiency

**Modern Equivalent:** Wage-and-hour laws requiring prompt payment echo the same-day wages command. Exemptions from certain obligations for newly married couples exist in various cultures. And gleaning programs (allowing food recovery from fields) continue this ancient practice.

# Deuteronomy Chapter 3: The Defeat of Og and Transjordan Settlement

*From the Hebrew: עוֹג מֶלֶךְ הַבָּשָׁן (Og Melech HaBashan) — Og King of Bashan*

---

**3:1** "Then we turned, and went up the way to Bashan; and Og the king of Bashan came out against us, he and all his people, to battle at Edrei.

**3:2** "And YHWH said unto me: 'Fear him not; for I have delivered him, and all his people, and his land, into your hand; and you shall do unto him as you did unto Sihon king of the Amorites, who dwelt at Heshbon.'

**3:3** "So YHWH our Consciousness delivered into our hand Og also, the king of Bashan, and all his people; and we smote him until none was left to him remaining.

**3:4** "And we took all his cities at that time; there was not a city which we did not take from them: threescore cities, all the region of Argob, the kingdom of Og in Bashan.

**3:5** "All these were fortified cities, with high walls, gates, and bars; besides unwalled towns a great many.

**3:6** "And we utterly destroyed them, as we did unto Sihon king of Heshbon, utterly destroying every city, the men, and the women, and the little ones.

**3:7** "But all the cattle, and the spoil of the cities, we took for a prey unto ourselves.

**3:8** "And we took the land at that time out of the hand of the two kings of the Amorites who were beyond the Jordan, from the valley of the Arnon unto Mount Hermon—

**3:9** "(Hermon the Sidonians call Sirion, and the Amorites call it Senir)—

**3:10** "All the cities of the plain, and all Gilead, and all Bashan, unto Salecah and Edrei, cities of the kingdom of Og in Bashan.

**3:11** "For only Og king of Bashan remained of the remnant of the Rephaim; behold, his bedstead was a bedstead of iron; is it not in Rabbah of the children of Ammon? Nine cubits was its length, and four cubits its breadth, after the cubit of a man."

---

**3:12** "And this land we took in possession at that time; from Aroer, which is by the valley of the Arnon, and half the hill-country of Gilead, and its cities, I gave unto the Reubenites and to the Gadites.

**3:13** "And the rest of Gilead, and all Bashan, the kingdom of Og, I gave unto the half-tribe of Manasseh; all the region of Argob, even all Bashan. The same is called the land of Rephaim.

**3:14** "Jair the son of Manasseh took all the region of Argob, unto the border of the Geshurites and the Maacathites, and called them, even Bashan, after his own name, Havvoth-jair, unto this day.

**3:15** "And I gave Gilead unto Machir.

**3:16** "And unto the Reubenites and unto the Gadites I gave from Gilead even unto the valley of the Arnon, the middle of the valley for a border, even unto the river Jabbok, which is the border of the children of Ammon;

**3:17** "The Arabah also, and the Jordan and its border, from Chinnereth even unto the sea of the Arabah, the Salt Sea, under the slopes of Pisgah eastward.

---

**3:18** "And I commanded you at that time, saying: 'YHWH your Consciousness has given you this land to possess it; you shall pass over armed before your brothers the children of Israel, all the men of valor.

**3:19** "'But your wives, and your little ones, and your cattle—I know that you have much cattle—shall abide in your cities which I have given you,

**3:20** "'Until YHWH gives rest unto your brothers, as unto you, and they also possess the land which YHWH your Consciousness gives them beyond the Jordan; then shall you return every man unto his possession, which I have given you.'

**3:21** "And I commanded Joshua at that time, saying: 'Your eyes have seen all that YHWH your Consciousness has done unto these two kings; so shall YHWH do unto all the kingdoms into which you pass over.

**3:22** "'You shall not fear them; for YHWH your Consciousness, he fights for you.'

---

**3:23** "And I besought YHWH at that time, saying:

**3:24** "'O Lord YHWH, you have begun to show your servant your greatness, and your strong hand; for what god is there in heaven or on earth, who can do according to your works, and according to your mighty acts?

**3:25** "'Let me go over, I pray, and see the good land that is beyond the Jordan, that goodly hill-country, and Lebanon.'

**3:26** "But YHWH was angry with me for your sakes, and did not listen unto me; and YHWH said unto me: 'Let it suffice you; speak no more unto me of this matter.

**3:27** "'Go up to the top of Pisgah, and lift up your eyes westward, and northward, and southward, and eastward, and behold with your eyes; for you shall not go over this Jordan.

**3:28** "'But charge Joshua, and encourage him, and strengthen him; for he shall go over before this people, and he shall cause them to inherit the land which you shall see.'

**3:29** "So we abode in the valley over against Beth-peor."

---

## Synthesis Notes

**Key Restorations:**

**Og of Bashan:**
The second Transjordan king. He attacks Israel at Edrei. YHWH's encouragement: "Fear him not; for I have delivered him... into your hand."

**Og's Stature:**
Og was "of the remnant of the Rephaim"—the giants. His bed/coffin (*eres*) was iron, measuring nine cubits by four cubits (approximately 13.5 feet by 6 feet). It was preserved in Rabbah of Ammon. Whether this was a literal bed or a sarcophagus, it testified to his extraordinary size.

**Sixty Cities:**
Israel takes all sixty cities of Argob—all fortified with walls, gates, and bars—plus many unwalled towns. The *cherem* is applied as with Sihon.

**The Territory:**
From the Arnon to Mount Hermon:
- Hermon is called Sirion by Sidonians, Senir by Amorites
- The plains, Gilead, and Bashan—all taken

**Distribution:**
- **Reuben and Gad**: Southern portion (Aroer to Jabbok)
- **Half-tribe of Manasseh**: Northern portion (Gilead, Bashan, Argob)
- **Jair** (Manassite): Renamed Argob as Havvoth-jair ("villages of Jair")
- **Machir**: Received Gilead

**The Obligation:**
The Transjordan tribes must cross the Jordan armed and fight with their brothers. Only after the conquest is complete may they return to their eastern possessions.

**Joshua Encouraged:**
"Your eyes have seen all that YHWH... has done unto these two kings; so shall YHWH do unto all the kingdoms." The Sihon/Og victories are paradigms for future conquest. Joshua must not fear.

**Moses' Prayer:**
Moses pleads to enter the land:
- "You have begun to show your servant your greatness"
- "Let me go over, I pray, and see the good land"

**The Refusal:**
"YHWH was angry with me for your sakes"—Moses traces his exclusion to the people's provocation at Meribah.

"Let it suffice you; speak no more unto me of this matter." The decision is final. YHWH will not revisit it.

**The Consolation:**
Moses may see the land from Pisgah—west, north, south, east. He may view but not enter.

His task now: "Charge Joshua, and encourage him, and strengthen him." Moses must prepare his successor to complete what he cannot.

**Beth-peor:**
The camp location—near the site of Israel's apostasy (Numbers 25). The name remains, a reminder.

**Archetypal Layer:** Og's giant bed represents **the last of the old order**. The Rephaim are ending; Israel is rising. The conquest of giants confirms that YHWH's power exceeds any human obstacle.

Moses' denied prayer shows that **even the greatest leaders face limits**. Moses can see but not enter. His role is to prepare Joshua, not to complete the mission himself.

**Psychological Reading:** Moses' prayer reveals his longing. After forty years of leadership, he wants to see the culmination. The refusal is painful; "speak no more unto me of this matter" closes the door definitively.

But the redirection—"charge Joshua"—gives Moses a legacy task. He cannot enter, but he can equip the one who will.

**Ethical Inversion Applied:**
- Og's iron bed witnesses his greatness—and his defeat
- "Fear him not"—YHWH's presence overcomes giant opposition
- The Transjordan tribes must fight first—shared burden before private enjoyment
- Moses is denied entry—even leaders face divine limits
- "Speak no more"—some prayers are definitively answered "no"
- Encourage Joshua—legacy is preparation of successors

**Modern Equivalent:** The defeat of Og encourages: fortified cities and giant kings can be overcome. Moses' experience with denied prayer models acceptance of limits. And his redirection to Joshua shows that preparing successors is a leader's final and essential task.

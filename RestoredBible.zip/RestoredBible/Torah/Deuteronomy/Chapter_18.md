# Deuteronomy Chapter 18: Priests, Prophets, and the Prophet to Come

*From the Hebrew: נָבִיא (Navi) — The Prophet*

---

**18:1** "The priests the Levites, all the tribe of Levi, shall have no portion nor inheritance with Israel; they shall eat the fire offerings of YHWH, and his inheritance.

**18:2** "And they shall have no inheritance among their brothers; YHWH is their inheritance, as he has spoken unto them.

**18:3** "And this shall be the priests' due from the people, from those who offer a sacrifice, whether it be ox or sheep: they shall give unto the priest the shoulder, and the two cheeks, and the maw.

**18:4** "The first-fruits of your grain, of your wine, and of your oil, and the first of the fleece of your sheep, you shall give him.

**18:5** "For YHWH your Consciousness has chosen him out of all your tribes, to stand to minister in the name of YHWH, him and his sons forever.

**18:6** "And if a Levite come from any of your gates out of all Israel, where he sojourns, and come with all the desire of his soul unto the place which YHWH shall choose;

**18:7** "Then he shall minister in the name of YHWH his Consciousness, as all his brothers the Levites do, who stand there before YHWH.

**18:8** "They shall have like portions to eat, besides that which comes of the sale of his patrimony.

---

**18:9** "When you come into the land which YHWH your Consciousness gives you, you shall not learn to do after the abominations of those nations.

**18:10** "There shall not be found among you anyone who makes his son or his daughter pass through the fire, one who uses divination, a soothsayer, or an enchanter, or a sorcerer,

**18:11** "Or a charmer, or one who consults a ghost or a familiar spirit, or a necromancer.

**18:12** "For whoever does these things is an abomination unto YHWH; and because of these abominations YHWH your Consciousness drives them out from before you.

**18:13** "You shall be wholehearted with YHWH your Consciousness—תָּמִים תִּהְיֶה עִם יהוה אֱלֹהֶיךָ (tamim tihyeh im YHWH Eloheicha).

---

**18:14** "For these nations, which you are to dispossess, listen to soothsayers, and to diviners; but as for you, YHWH your Consciousness has not given you so to do.

**18:15** "A prophet from the midst of you, from your brothers, like unto me, will YHWH your Consciousness raise up unto you; unto him you shall listen—נָבִיא מִקִּרְבְּךָ מֵאַחֶיךָ כָּמֹנִי יָקִים לְךָ יהוה אֱלֹהֶיךָ אֵלָיו תִּשְׁמָעוּן (navi mi-qirbecha me-acheicha kamoni yaqim lecha YHWH Eloheicha elav tishma'un).

**18:16** "According to all that you desired of YHWH your Consciousness in Horeb in the day of the assembly, saying: 'Let me not hear again the voice of YHWH my Consciousness, neither let me see this great fire any more, that I not die.'

**18:17** "And YHWH said unto me: 'They have well said that which they have spoken.

**18:18** "'I will raise them up a prophet from among their brothers, like unto you; and I will put my words in his mouth, and he shall speak unto them all that I shall command him.

**18:19** "'And it shall come to pass, that whoever will not listen unto my words which he shall speak in my name, I will require it of him.

**18:20** "'But the prophet, who shall speak a word presumptuously in my name, which I have not commanded him to speak, or who shall speak in the name of other gods, that prophet shall die.'

**18:21** "And if you say in your heart: 'How shall we know the word which YHWH has not spoken?'

**18:22** "When a prophet speaks in the name of YHWH, if the thing does not happen, nor come to pass, that is the thing which YHWH has not spoken; the prophet has spoken it presumptuously; you shall not be afraid of him."

---

## Synthesis Notes

**Key Restorations:**

**Levitical Provisions:**
The Levites and priests live from:
- Fire offerings (sacrificial portions)
- Priestly dues: shoulder, cheeks, maw (stomach) of sacrificed animals
- First-fruits of grain, wine, oil
- First of the fleece

"YHWH is their inheritance"—they receive God instead of land.

**Levites from Other Towns:**
A Levite from any town may come to serve at the central sanctuary and share equally in the portions. He retains whatever he has from family property.

**Forbidden Occult Practices (18:9-14):**
A comprehensive list of Canaanite divination methods:

1. **Passing son/daughter through fire**—child sacrifice to Molech
2. **Divination** (*qosem qesamim*)—seeking omens
3. **Soothsaying** (*me'onen*)—interpreting signs, clouds
4. **Enchantment** (*menachesh*)—snake charming or reading entrails
5. **Sorcery** (*mekashef*)—magic spells
6. **Charming** (*chover chaver*)—binding spells
7. **Consulting ghosts** (*sho'el ov*)—mediumship
8. **Familiar spirits** (*yidde'oni*)—spiritism
9. **Necromancy** (*doresh el ha-metim*)—inquiring of the dead

"Because of these abominations YHWH... drives them out."

**"Wholehearted with YHWH":**
*Tamim tihyeh*—be complete, blameless, undivided. Instead of fragmented occult consultation, Israel has undivided loyalty to YHWH.

**The Prophet Like Moses (18:15-19):**
Moses promises: "A prophet from the midst of you, from your brothers, like unto me, will YHWH... raise up unto you."

This prophecy operates on two levels:
1. **Immediate**: The prophetic office—YHWH will provide prophets as needed
2. **Ultimate**: The Prophet—a singular figure "like Moses"

The Samaritan community expected "the Taheb" based on this verse. Jewish tradition awaited "the Prophet" (John 1:21, 25). Christians identify Jesus as the fulfillment (Acts 3:22-23, 7:37).

**The Context:**
At Horeb, Israel requested mediation: "Let me not hear again the voice of YHWH." YHWH approved this request. The prophetic office is the answer—YHWH speaks through prophets rather than directly to all Israel.

**The True Prophet:**
"I will put my words in his mouth"—the prophet speaks YHWH's words, not his own.

**The False Prophet:**
- Speaks presumptuously in YHWH's name without command
- Speaks in the name of other gods
- Penalty: death

**The Test:**
"If the thing does not happen, nor come to pass"—unfulfilled prediction reveals the false prophet. This test applies to predictive prophecy; it doesn't address all aspects of prophetic discernment.

**Archetypal Layer:** The occult prohibition and the prophetic promise are connected. Israel doesn't need divination because YHWH provides prophets. The prophetic word replaces the occult arts.

The "prophet like Moses" creates expectation of a future figure who will mediate between YHWH and Israel as Moses did—speak face to face with God, lead the people, deliver the word.

**Psychological Reading:** The prohibition on consulting the dead addresses the human desire to know the future and contact the departed. Israel's alternative is the living prophet who speaks YHWH's current word.

**Ethical Inversion Applied:**
- YHWH is the Levites' inheritance—God instead of land
- Occult practices forbidden—divination is abomination
- "Wholehearted with YHWH"—undivided loyalty
- Prophet like Moses—mediated word instead of direct voice
- False prophets die—speaking presumptuously is capital offense
- Unfulfilled prediction = false prophet—the test of time

**Modern Equivalent:** The prohibition on occult consultation remains relevant for communities that take these texts seriously. The test of the prophet (does the prediction come true?) provides a partial criterion for evaluating claims. And the promise of a "prophet like Moses" continues to shape messianic expectation.

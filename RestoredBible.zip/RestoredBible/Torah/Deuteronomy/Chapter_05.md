# Deuteronomy Chapter 5: The Ten Commandments

*From the Hebrew: עֲשֶׂרֶת הַדְּבָרִים (Aseret HaDevarim) — The Ten Words*

---

**5:1** And Moses called unto all Israel, and said unto them: "Hear, O Israel, the statutes and the ordinances which I speak in your ears this day, that you may learn them, and observe to do them.

**5:2** "YHWH our Consciousness made a covenant with us in Horeb.

**5:3** "YHWH made not this covenant with our fathers, but with us, even us, who are all of us here alive this day.

**5:4** "YHWH spoke with you face to face in the mount out of the midst of the fire—

**5:5** "I stood between YHWH and you at that time, to declare unto you the word of YHWH; for you were afraid because of the fire, and did not go up into the mount—saying:

---

**5:6** "'I am YHWH your Consciousness, who brought you out of the land of Egypt, out of the house of bondage.

**5:7** "'You shall have no other gods before my face.

**5:8** "'You shall not make unto yourself a graven image, any manner of likeness, of anything that is in heaven above, or that is in the earth beneath, or that is in the water under the earth.

**5:9** "'You shall not bow down unto them, nor serve them; for I YHWH your Consciousness am a jealous God—אֵל קַנָּא (El qanna)—visiting the iniquity of the fathers upon the children, and upon the third and upon the fourth generation of those who hate me,

**5:10** "'And showing lovingkindness unto the thousandth generation of those who love me and keep my commandments.

**5:11** "'You shall not take the name of YHWH your Consciousness in vain—לַשָּׁוְא (la-shav); for YHWH will not hold him guiltless who takes his name in vain.

**5:12** "'Observe the sabbath day, to keep it holy, as YHWH your Consciousness commanded you.

**5:13** "'Six days you shall labor, and do all your work;

**5:14** "'But the seventh day is a sabbath unto YHWH your Consciousness; in it you shall not do any manner of work, you, nor your son, nor your daughter, nor your man-servant, nor your maid-servant, nor your ox, nor your donkey, nor any of your cattle, nor the stranger who is within your gates; that your man-servant and your maid-servant may rest as well as you.

**5:15** "'And you shall remember that you were a servant in the land of Egypt, and YHWH your Consciousness brought you out from there by a mighty hand and by an outstretched arm; therefore YHWH your Consciousness commanded you to keep the sabbath day.

**5:16** "'Honor your father and your mother, as YHWH your Consciousness commanded you; that your days may be long, and that it may go well with you, upon the land which YHWH your Consciousness gives you.

**5:17** "'You shall not murder.

**5:18** "'And you shall not commit adultery.

**5:19** "'And you shall not steal.

**5:20** "'And you shall not bear false witness against your neighbor.

**5:21** "'And you shall not covet your neighbor's wife; and you shall not desire your neighbor's house, his field, or his man-servant, or his maid-servant, his ox, or his donkey, or anything that is your neighbor's.'

---

**5:22** "These words YHWH spoke unto all your assembly in the mount out of the midst of the fire, of the cloud, and of the thick darkness, with a great voice; and he added no more. And he wrote them upon two tables of stone, and gave them unto me.

**5:23** "And it came to pass, when you heard the voice out of the midst of the darkness, while the mountain was burning with fire, that you came near unto me, all the heads of your tribes, and your elders;

**5:24** "And you said: 'Behold, YHWH our Consciousness has shown us his glory and his greatness, and we have heard his voice out of the midst of the fire; we have seen this day that God speaks with man, and he lives.

**5:25** "'Now therefore why should we die? For this great fire will consume us; if we hear the voice of YHWH our Consciousness any more, then we shall die.

**5:26** "'For who is there of all flesh, that has heard the voice of the living God—אֱלֹהִים חַיִּים (Elohim chayyim)—speaking out of the midst of the fire, as we have, and lived?

**5:27** "'Go near, and hear all that YHWH our Consciousness shall say; and speak unto us all that YHWH our Consciousness shall speak unto you; and we will hear it and do it.'

**5:28** "And YHWH heard the voice of your words, when you spoke unto me; and YHWH said unto me: 'I have heard the voice of the words of this people, which they have spoken unto you; they have well said all that they have spoken.

**5:29** "'Oh that there were such a heart in them, that they would fear me, and keep all my commandments always, that it might be well with them, and with their children forever!

**5:30** "'Go say to them: Return to your tents.

**5:31** "'But as for you, stand here by me, and I will speak unto you all the commandment, and the statutes, and the ordinances, which you shall teach them, that they may do them in the land which I give them to possess it.'

**5:32** "Observe therefore to do as YHWH your Consciousness has commanded you; you shall not turn aside to the right hand or to the left.

**5:33** "You shall walk in all the way which YHWH your Consciousness has commanded you, that you may live, and that it may be well with you, and that you may prolong your days in the land which you shall possess."

---

## Synthesis Notes

**Key Restorations:**

**"With Us, Not Our Fathers":**
Moses speaks to the new generation as if they were at Sinai: "YHWH made not this covenant with our fathers, but with us, even us, who are all of us here alive this day." The covenant transcends generation—each receives it as their own.

**Moses as Mediator:**
"I stood between YHWH and you"—the people feared the fire and asked Moses to receive the words on their behalf. Moses becomes the channel between divine voice and human ear.

**The Ten Words:**

**1. Identity/Exclusivity**: "I am YHWH... who brought you out of Egypt. You shall have no other gods."

**2. Image Prohibition**: "You shall not make a graven image"—no representation of anything in heaven, earth, or water.

**3. Name Protection**: "You shall not take the name of YHWH in vain"—*la-shav*, emptily, falsely, for nothing.

**4. Sabbath Observance**: "Observe the sabbath day"—note: Exodus 20 says "remember"; Deuteronomy says "observe."

**5. Parental Honor**: "Honor your father and your mother"—with promise of long life and well-being.

**6. Murder Prohibition**: "You shall not murder."

**7. Adultery Prohibition**: "You shall not commit adultery."

**8. Theft Prohibition**: "You shall not steal."

**9. False Witness Prohibition**: "You shall not bear false witness."

**10. Covetousness Prohibition**: "You shall not covet your neighbor's wife... house, field, servant, ox, donkey..."

**Deuteronomic Differences:**

The Sabbath commandment differs from Exodus 20:
- Exodus grounds Sabbath in creation (God rested on the seventh day)
- Deuteronomy grounds it in liberation (you were slaves in Egypt)

Both rationales are valid; Deuteronomy emphasizes the social-ethical dimension: servants must rest because Israel remembers servitude.

Also: Deuteronomy adds "his field" to the covetousness list and separates "wife" from "house."

**"He Added No More":**
The Ten Words are complete. YHWH spoke these directly to all Israel; the rest of the law came through Moses. The Ten have unique status.

**The People's Fear:**
After hearing the voice from fire, the people request mediation: "Go near, and hear... and speak unto us... and we will hear it and do it." They cannot bear direct encounter with "the living God."

**YHWH's Response:**
"They have well said all that they have spoken." The request for mediation is approved.

But then: "Oh that there were such a heart in them, that they would fear me, and keep all my commandments always!" YHWH knows their hearts will not match their words. The desire is for internal transformation, not merely verbal assent.

**Archetypal Layer:** The Ten Words are the **covenant in concentrated form**. Everything else elaborates these principles. The direct divine voice establishes their supreme authority.

The people's fear of unmediated encounter represents the **human need for mediators**. The holy is too intense for direct sustained contact.

**Psychological Reading:** "Oh that there were such a heart in them" reveals divine longing. YHWH desires willing hearts, not mere compliance. The commandments aim at internal transformation.

**Ethical Inversion Applied:**
- The covenant is addressed to "us"—each generation receives it directly
- Sabbath grounded in liberation—social ethics, not just religious ritual
- "No other gods before my face"—presence, not mere priority
- Lovingkindness to the thousandth generation—blessing outlasts curse
- "Such a heart in them"—YHWH desires internal change

**Modern Equivalent:** The Ten remain foundational ethical principles across cultures. The Deuteronomic emphasis on Sabbath as social justice (servants rest because you were slaves) connects religious practice to ethical concern. And the divine longing for "such a heart" challenges mere external compliance.

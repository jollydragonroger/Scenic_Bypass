# Deuteronomy Chapter 32: The Song of Moses

*From the Hebrew: שִׁירַת הַאֲזִינוּ (Shirat Ha'azinu) — The Song of Listen*

---

**32:1** "Give ear, you heavens, and I will speak;
And let the earth hear the words of my mouth.

**32:2** "My doctrine shall drop as the rain,
My speech shall distil as the dew;
As the small rain upon the tender grass,
And as the showers upon the herb.

**32:3** "For I will proclaim the name of YHWH;
Ascribe greatness unto our Consciousness.

**32:4** "The Rock, his work is perfect;
For all his ways are justice;
A God of faithfulness and without iniquity,
Just and right is he—הַצּוּר תָּמִים פָּעֳלוֹ (ha-Tsur tamim pa'olo).

**32:5** "They have dealt corruptly with him;
They are not his children, it is their blemish;
A generation crooked and perverse.

**32:6** "Do you thus requite YHWH,
O foolish people and unwise?
Is not he your father who created you?
He has made you and established you.

---

**32:7** "Remember the days of old,
Consider the years of many generations;
Ask your father, and he will declare unto you,
Your elders, and they will tell you.

**32:8** "When the Most High gave to the nations their inheritance,
When he separated the children of men,
He set the bounds of the peoples
According to the number of the children of Israel.

**32:9** "For YHWH's portion is his people,
Jacob is the lot of his inheritance—כִּי חֵלֶק יהוה עַמּוֹ (ki cheleq YHWH ammo).

**32:10** "He found him in a desert land,
And in the waste, a howling wilderness;
He encompassed him about, he cared for him,
He kept him as the apple of his eye—כְּאִישׁוֹן עֵינוֹ (ke-ishon eino).

**32:11** "As an eagle stirs up her nest,
Hovers over her young,
Spreads abroad her wings, takes them,
Bears them on her pinions;

**32:12** "YHWH alone did lead him,
And there was no foreign god with him.

**32:13** "He made him ride on the high places of the earth,
And he ate the increase of the field;
And he made him suck honey out of the rock,
And oil out of the flinty rock;

**32:14** "Curd of cattle, and milk of sheep,
With fat of lambs,
And rams of the breed of Bashan, and he-goats,
With the kidney-fat of wheat;
And of the blood of the grape you drank wine.

---

**32:15** "But Jeshurun grew fat, and kicked—
You grew fat, you grew thick, you grew gross—
And he forsook God who made him,
And dishonored the Rock of his salvation—וַיִּשְׁמַן יְשֻׁרוּן וַיִּבְעָט (va-yishman Yeshurun va-yiv'at).

**32:16** "They roused him to jealousy with strange gods,
With abominations they provoked him.

**32:17** "They sacrificed unto demons, no-gods,
Gods that they knew not,
New ones that came up of late,
Which your fathers dreaded not.

**32:18** "Of the Rock who begot you you were unmindful,
And forgot the God who travailed with you.

**32:19** "And YHWH saw, and spurned,
Because of the provoking of his sons and his daughters.

**32:20** "And he said: 'I will hide my face from them,
I will see what their end shall be;
For they are a very froward generation,
Children in whom is no faithfulness.

**32:21** "'They have roused me to jealousy with a no-god;
They have provoked me with their vanities;
And I will rouse them to jealousy with a no-people;
I will provoke them with a vile nation.

**32:22** "'For a fire is kindled in my nostrils,
And burns unto the depths of Sheol,
And devours the earth with its increase,
And sets ablaze the foundations of the mountains.

**32:23** "'I will heap evils upon them;
I will spend my arrows upon them.

**32:24** "'Wasting of hunger, and devouring of fire,
And bitter destruction;
And the teeth of beasts will I send upon them,
With the venom of crawling things of the dust.

**32:25** "'Without shall the sword bereave,
And in the chambers terror;
Slaying both young man and virgin,
The suckling with the man of gray hairs.

**32:26** "'I would have said: I will scatter them afar,
I will make the remembrance of them to cease from among men;

**32:27** "'Were it not that I dreaded the provocation of the enemy,
Lest their adversaries should misdeem,
Lest they should say: Our hand is exalted,
And YHWH has not wrought all this.'

---

**32:28** "For they are a nation void of counsel,
And there is no understanding in them.

**32:29** "If they were wise, they would understand this,
They would discern their latter end.

**32:30** "How should one chase a thousand,
And two put ten thousand to flight,
Except their Rock had given them over,
And YHWH had delivered them up?

**32:31** "For their rock is not as our Rock,
Even our enemies themselves being judges.

**32:32** "For their vine is of the vine of Sodom,
And of the fields of Gomorrah;
Their grapes are grapes of gall,
Their clusters are bitter.

**32:33** "Their wine is the venom of serpents,
And the cruel poison of asps.

---

**32:34** "'Is not this laid up in store with me,
Sealed up in my treasuries?

**32:35** "'Vengeance is mine, and recompense,
Against the time when their foot shall slip;
For the day of their calamity is at hand,
And the things that are to come upon them shall make haste.'—לִי נָקָם וְשִׁלֵּם (li naqam ve-shillem)

**32:36** "For YHWH will judge his people,
And repent himself for his servants;
When he sees that power is gone,
And there is none remaining, shut up or left at large.

**32:37** "And it is said: 'Where are their gods,
The rock in whom they trusted;

**32:38** "'Who ate the fat of their sacrifices,
And drank the wine of their drink-offering?
Let them rise up and help you,
Let them be your protection.'

**32:39** "See now that I, I am he,
And there is no god with me;
I kill, and I make alive;
I have wounded, and I heal;
And there is none who can deliver out of my hand—אֲנִי אָמִית וַאֲחַיֶּה (ani amit va-achayeh).

**32:40** "For I lift up my hand to heaven,
And say: As I live forever,

**32:41** "If I whet my glittering sword,
And my hand takes hold on judgment;
I will render vengeance to my adversaries,
And will recompense those who hate me.

**32:42** "I will make my arrows drunk with blood,
And my sword shall devour flesh;
With the blood of the slain and the captives,
From the hairy head of the enemy.

**32:43** "Sing aloud, O nations, of his people;
For he avenges the blood of his servants,
And renders vengeance to his adversaries,
And atones for his land, for his people—הַרְנִינוּ גוֹיִם עַמּוֹ (harninu goyim ammo)."

---

**32:44** And Moses came and spoke all the words of this song in the ears of the people, he, and Hoshea the son of Nun.

**32:45** And Moses made an end of speaking all these words to all Israel.

**32:46** And he said unto them: "Set your heart unto all the words which I testify against you this day; that you may charge your children to observe to do all the words of this law.

**32:47** "For it is no vain thing for you; because it is your life, and through this thing you shall prolong your days upon the land, into which you go over the Jordan to possess it."

---

**32:48** And YHWH spoke unto Moses that selfsame day, saying:

**32:49** "Go up into this mountain of Abarim, unto Mount Nebo, which is in the land of Moab, that is over against Jericho; and behold the land of Canaan, which I give unto the children of Israel for a possession;

**32:50** "And die in the mount where you go up, and be gathered unto your people; as Aaron your brother died in Mount Hor, and was gathered unto his people.

**32:51** "Because you trespassed against me in the midst of the children of Israel at the waters of Meribath-kadesh, in the wilderness of Zin; because you did not sanctify me in the midst of the children of Israel.

**32:52** "For you shall see the land before you; but you shall not go there into the land which I give the children of Israel."

---

## Synthesis Notes

**Key Restorations:**

**The Song's Structure:**
1. **Invocation** (1-3): Heaven and earth as witnesses
2. **Praise of YHWH** (4): The Rock, perfect, just
3. **Indictment of Israel** (5-6): Foolish, perverse
4. **Historical Review** (7-14): YHWH's care for Israel
5. **Israel's Apostasy** (15-18): Jeshurun grew fat and kicked
6. **YHWH's Judgment** (19-27): Hiding face, sending disasters
7. **Israel's Foolishness** (28-33): No understanding
8. **YHWH's Vindication** (34-42): Vengeance on enemies
9. **Conclusion** (43): Nations rejoice; atonement for land and people

**"The Rock" (הַצּוּר):**
YHWH is called "the Rock" six times. This metaphor emphasizes stability, permanence, and faithfulness. It contrasts with "their rock" (the false gods, 32:31).

**"Apple of His Eye":**
*Ke-ishon eino*—literally "like the little man of his eye" (the pupil, where one sees a tiny reflection). This expresses YHWH's tender care and protective love.

**The Eagle Image:**
YHWH as mother eagle:
- Stirs up the nest (forces the young out)
- Hovers over them
- Spreads wings to catch them
- Bears them on pinions

This is nurturing protection combined with training for independence.

**Jeshurun (יְשֻׁרוּן):**
A poetic name for Israel, meaning "the upright one" (from *yashar*, straight). Ironic: "Jeshurun grew fat, and kicked"—the upright became corrupt through prosperity.

**"They Sacrificed to Demons":**
*Shedim*—demons, no-gods. Israel worshipped entities that are not gods, new arrivals their fathers never knew.

**"I Will Hide My Face":**
*Hester panim*—the concealment of divine presence. This is not absence but deliberate withdrawal in response to covenant betrayal.

**"Vengeance Is Mine":**
*Li naqam ve-shillem*—quoted in Romans 12:19 and Hebrews 10:30. Vengeance belongs to YHWH, not to human retribution.

**"I Kill, and I Make Alive":**
*Ani amit va-achayeh*—YHWH's absolute sovereignty over life and death. "There is no god with me"—monotheistic affirmation.

**"Sing Aloud, O Nations":**
The song ends with nations rejoicing over YHWH's vindication of his people. He avenges their blood, punishes adversaries, and "atones for his land, for his people."

**Moses' Death Command:**
The chapter ends with YHWH's instruction: go up Mount Nebo, see the land, and die there. The reason is restated: "You trespassed against me at the waters of Meribath-kadesh... you did not sanctify me."

**Archetypal Layer:** The song is **covenant lawsuit in poetic form**. Heaven and earth witness; history is reviewed; the indictment is delivered; judgment is pronounced; vindication is promised.

Jeshurun's obesity represents **prosperity's spiritual danger**—the very theme developed throughout Deuteronomy.

**Psychological Reading:** The song embeds in memory what prose cannot. Its poetry, rhythm, and imagery make it unforgettable. It serves as internal witness when the predicted apostasy occurs.

**Ethical Inversion Applied:**
- "The Rock"—YHWH is stable; Israel is unstable
- "Apple of his eye"—tender divine care
- "Grew fat and kicked"—prosperity corrupts
- "Sacrificed to demons"—idolatry is demonic
- "Vengeance is mine"—human retaliation is forbidden
- "I kill, and I make alive"—YHWH's sovereignty is absolute

**Modern Equivalent:** The song warns that prosperity can lead to spiritual forgetfulness. The "vengeance is mine" principle limits vigilante justice. And the song's persistence (memorized, recited) shows how communities embed values through poetry and music.

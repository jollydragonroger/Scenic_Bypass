# Deuteronomy Chapter 22: Miscellaneous Laws

*From the Hebrew: לֹא תִרְאֶה (Lo Tir'eh) — You Shall Not See and Ignore*

---

**22:1** "You shall not see your brother's ox or his sheep driven away, and hide yourself from them; you shall surely bring them back unto your brother.

**22:2** "And if your brother is not near unto you, and you know him not, then you shall bring it home to your house, and it shall be with you until your brother requires it, and you shall restore it to him.

**22:3** "And so shall you do with his donkey; and so shall you do with his garment; and so shall you do with every lost thing of your brother's, which he has lost, and you have found; you may not hide yourself.

**22:4** "You shall not see your brother's donkey or his ox fallen down by the way, and hide yourself from them; you shall surely help him to lift them up again.

---

**22:5** "A woman shall not wear that which pertains unto a man, neither shall a man put on a woman's garment; for whoever does these things is an abomination unto YHWH your Consciousness.

---

**22:6** "If a bird's nest chance to be before you in the way, in any tree or on the ground, with young ones or eggs, and the mother sitting upon the young, or upon the eggs, you shall not take the mother with the young.

**22:7** "You shall surely let the mother go, but the young you may take unto yourself; that it may be well with you, and that you may prolong your days.

---

**22:8** "When you build a new house, then you shall make a parapet for your roof, that you bring not blood upon your house, if any man fall from there.

---

**22:9** "You shall not sow your vineyard with two kinds of seed; lest the fullness of the seed which you have sown be forfeited together with the increase of the vineyard.

**22:10** "You shall not plow with an ox and a donkey together.

**22:11** "You shall not wear a mingled stuff, wool and linen together.

**22:12** "You shall make yourself twisted cords upon the four corners of your covering, with which you cover yourself.

---

**22:13** "If any man takes a wife, and goes in unto her, and hates her,

**22:14** "And charges her with shameful things, and brings up an evil name upon her, and says: 'I took this woman, and when I came near to her, I found not in her the tokens of virginity';

**22:15** "Then shall the father of the young woman, and her mother, take and bring forth the tokens of the young woman's virginity unto the elders of the city in the gate.

**22:16** "And the young woman's father shall say unto the elders: 'I gave my daughter unto this man to wife, and he hates her;

**22:17** "'And lo, he has laid shameful things against her, saying: I found not in your daughter the tokens of virginity; and yet these are the tokens of my daughter's virginity.' And they shall spread the garment before the elders of the city.

**22:18** "And the elders of that city shall take the man and chastise him.

**22:19** "And they shall fine him a hundred shekels of silver, and give them unto the father of the young woman, because he has brought up an evil name upon a virgin of Israel; and she shall be his wife; he may not put her away all his days.

**22:20** "But if this thing is true, that the tokens of virginity were not found in the young woman;

**22:21** "Then they shall bring out the young woman to the door of her father's house, and the men of her city shall stone her with stones that she die; because she has wrought a wanton deed in Israel, to play the harlot in her father's house; so shall you put away the evil from the midst of you.

---

**22:22** "If a man is found lying with a woman married to a husband, then they shall both of them die, the man who lay with the woman, and the woman; so shall you put away the evil from Israel.

**22:23** "If there is a young woman who is a virgin betrothed unto a husband, and a man finds her in the city, and lies with her;

**22:24** "Then you shall bring them both out unto the gate of that city, and you shall stone them with stones that they die: the young woman, because she cried not, being in the city; and the man, because he has humbled his neighbor's wife; so you shall put away the evil from the midst of you.

**22:25** "But if the man finds the betrothed young woman in the field, and the man takes hold of her, and lies with her; then the man only who lay with her shall die.

**22:26** "But unto the young woman you shall do nothing; there is in the young woman no sin worthy of death; for as when a man rises against his neighbor, and slays him, even so is this matter.

**22:27** "For he found her in the field; the betrothed young woman cried, and there was none to save her.

**22:28** "If a man finds a young woman who is a virgin, who is not betrothed, and lays hold on her, and lies with her, and they are found;

**22:29** "Then the man who lay with her shall give unto the young woman's father fifty shekels of silver, and she shall be his wife, because he has humbled her; he may not put her away all his days.

**22:30** "A man shall not take his father's wife, and shall not uncover his father's skirt."

---

## Synthesis Notes

**Key Restorations:**

**Lost Property (22:1-4):**
"You may not hide yourself"—you cannot pretend not to see. If you find your brother's lost animal or property:
- Return it if you know the owner
- Keep it safely until claimed if you don't
- Help lift fallen animals

This is active neighborliness, not passive avoidance.

**Cross-Dressing Prohibition (22:5):**
"A woman shall not wear that which pertains unto a man"—and vice versa. The text calls this "abomination" (*to'evah*). Various interpretations: maintaining gender distinctions, prohibiting pagan ritual cross-dressing, or broader concerns about social order.

**The Mother Bird (22:6-7):**
If you find a nest with mother and young:
- Take the young or eggs
- Let the mother go

**Promise**: "That it may be well with you, and that you may prolong your days." This is one of only two commandments with this specific promise (the other: honoring parents).

The law balances use (you may take the young) with preservation (release the mother to reproduce again). Early conservation ethic.

**Roof Parapet (22:8):**
Flat roofs were used for living space. A parapet (safety railing) prevents falls. "That you bring not blood upon your house"—negligence that causes death brings guilt.

**Forbidden Mixtures (22:9-12):**
- No mixed seed in vineyard
- No plowing with ox and donkey together
- No wearing wool and linen together (*sha'atnez*)
- But: make twisted cords (*tzitzit*) on garment corners

The mixing prohibitions may represent separation categories—keeping kinds distinct—or have other symbolic meanings debated in tradition.

**The Slandered Bride (22:13-21):**
A husband claims his new wife was not a virgin:
- Parents present evidence (the garment with blood)
- If evidence supports her: husband is flogged, fined 100 shekels, cannot divorce her
- If no evidence: she is stoned at her father's door

The law protects the falsely accused but punishes actual deception.

**Sexual Offenses (22:22-30):**

| Situation | Penalty |
|-----------|---------|
| Adultery (married woman) | Both die |
| Betrothed woman in city | Both die (she didn't cry out) |
| Betrothed woman in field | Only the man dies (assumed rape) |
| Unbetrothed virgin | Man pays 50 shekels, must marry, cannot divorce |
| Father's wife | Forbidden |

**The Field vs. City Distinction:**
In the city, a cry for help would be heard. Silence suggests consent. In the field, no one would hear. The woman is presumed innocent; it's treated like murder ("as when a man rises against his neighbor, and slays him").

**"He May Not Put Her Away":**
Both the slanderer (22:19) and the one who violated an unbetrothed virgin (22:29) lose the right to divorce. They are permanently bound.

**Archetypal Layer:** The "you may not hide yourself" principle requires **active responsibility**. Seeing creates obligation. The lost property laws reject passive bystander ethics.

The mother bird law represents **sustainable use**—take, but preserve the source for future generations.

**Psychological Reading:** The sexual offense laws attempt to distinguish consent from coercion using available evidence (location, crying out). The field/city distinction is a proxy for evaluating circumstances.

**Ethical Inversion Applied:**
- "You may not hide yourself"—seeing creates responsibility
- Release the mother bird—sustainability, not depletion
- Parapet required—negligence is culpable
- False accusation punished—protects the innocent
- Field = presumed rape—location affects judgment
- Permanent marriage for slanderer/violator—consequences are lasting

**Modern Equivalent:** Good Samaritan laws echo the "you may not hide yourself" principle. Building codes requiring safety features (railings, etc.) extend the parapet law. The field/city distinction anticipates how context affects legal judgment about consent.

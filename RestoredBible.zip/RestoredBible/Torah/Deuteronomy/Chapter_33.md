# Deuteronomy Chapter 33: The Blessing of Moses

*From the Hebrew: בִּרְכַּת מֹשֶׁה (Birkat Mosheh) — The Blessing of Moses*

---

**33:1** And this is the blessing, with which Moses the man of God blessed the children of Israel before his death.

**33:2** And he said:
"YHWH came from Sinai,
And rose from Seir unto them;
He shined forth from Mount Paran,
And he came from the myriads of holy ones;
At his right hand was a fiery law for them—אֵשְׁדָּת (eshdat).

**33:3** "Yes, he loves the peoples;
All his holy ones are in your hand;
And they sit down at your feet,
Receiving of your words.

**33:4** "Moses commanded us a law,
An inheritance of the congregation of Jacob—תּוֹרָה צִוָּה־לָנוּ מֹשֶׁה מוֹרָשָׁה קְהִלַּת יַעֲקֹב (Torah tsivvah-lanu Mosheh morashah qehillat Ya'aqov).

**33:5** "And he was king in Jeshurun,
When the heads of the people were gathered,
All the tribes of Israel together.

---

**33:6** "Let Reuben live, and not die;
And let his men be few."

---

**33:7** "And this of Judah, and he said:
'Hear, YHWH, the voice of Judah,
And bring him unto his people;
His hands shall contend for him,
And you shall be a help against his adversaries.'"

---

**33:8** "And of Levi he said:
'Your Thummim and your Urim are with your pious one,
Whom you tested at Massah,
With whom you strove at the waters of Meribah;

**33:9** "'Who said of his father, and of his mother: I have not seen him;
Neither did he acknowledge his brothers,
Nor knew he his own children;
For they have observed your word,
And keep your covenant.

**33:10** "'They shall teach Jacob your ordinances,
And Israel your law;
They shall put incense before you,
And whole burnt offering upon your altar.

**33:11** "'Bless, YHWH, his substance,
And accept the work of his hands;
Smite through the loins of those who rise up against him,
And of those who hate him, that they rise not again.'"

---

**33:12** "Of Benjamin he said:
'The beloved of YHWH shall dwell in safety by him;
He covers him all the day,
And he dwells between his shoulders.'"

---

**33:13** "And of Joseph he said:
'Blessed of YHWH be his land;
For the precious things of heaven, for the dew,
And for the deep that couches beneath,

**33:14** "'And for the precious things of the fruits of the sun,
And for the precious things of the yield of the moons,

**33:15** "'And for the tops of the ancient mountains,
And for the precious things of the everlasting hills,

**33:16** "'And for the precious things of the earth and its fullness,
And the good will of him who dwelt in the bush;
Let it come upon the head of Joseph,
And upon the crown of him who was set apart from his brothers.

**33:17** "'His firstling bull, majesty is his;
And his horns are the horns of the wild ox;
With them he shall gore the peoples all of them, to the ends of the earth;
And they are the ten thousands of Ephraim,
And they are the thousands of Manasseh.'"

---

**33:18** "And of Zebulun he said:
'Rejoice, Zebulun, in your going out;
And, Issachar, in your tents.

**33:19** "'They shall call peoples unto the mountain;
There they shall offer sacrifices of righteousness;
For they shall suck the abundance of the seas,
And the hidden treasures of the sand.'"

---

**33:20** "And of Gad he said:
'Blessed be he who enlarges Gad;
He dwells as a lioness,
And tears the arm, yes, the crown of the head.

**33:21** "'And he chose the first part for himself,
For there the portion of the lawgiver was reserved;
And he came with the heads of the people,
He executed the righteousness of YHWH,
And his ordinances with Israel.'"

---

**33:22** "And of Dan he said:
'Dan is a lion's cub,
That leaps forth from Bashan.'"

---

**33:23** "And of Naphtali he said:
'O Naphtali, satisfied with favor,
And full with the blessing of YHWH:
Possess the sea and the south.'"

---

**33:24** "And of Asher he said:
'Blessed be Asher above sons;
Let him be the favored of his brothers,
And let him dip his foot in oil.

**33:25** "'Iron and bronze are your bars;
And as your days, so shall your strength be—וּכְיָמֶיךָ דָּבְאֶךָ (u-che-yameicha dov'echa).'"

---

**33:26** "There is none like unto God, O Jeshurun,
Who rides upon the heavens as your help,
And in his excellency on the skies.

**33:27** "The eternal God is a dwelling place,
And underneath are the everlasting arms;
And he thrust out the enemy from before you,
And said: 'Destroy.'

**33:28** "And Israel dwells in safety alone;
The fountain of Jacob is upon a land of grain and wine;
Yes, his heavens drop down dew.

**33:29** "Happy are you, O Israel, who is like unto you?
A people saved by YHWH,
The shield of your help,
And the sword of your excellency!
And your enemies shall submit unto you;
And you shall tread upon their high places—אַשְׁרֶיךָ יִשְׂרָאֵל מִי כָמוֹךָ (ashreicha Yisra'el mi chamocha)."

---

## Synthesis Notes

**Key Restorations:**

**Introduction:**
"Moses the man of God"—the only place in the Torah where Moses receives this title. He blesses Israel "before his death"—these are final words.

**The Theophany (33:2-5):**
YHWH comes from Sinai, rises from Seir, shines from Paran—a procession of divine manifestation. "Myriads of holy ones" (angelic hosts) accompany him. A "fiery law" (*eshdat*—the law as fire) is at his right hand.

**"Torah... An Inheritance":**
*Torah tsivvah-lanu Mosheh*—"Moses commanded us a law." This verse is taught to Jewish children as one of their first verses. The Torah is the inheritance of the entire congregation of Jacob.

**The Tribal Blessings:**

| Tribe | Blessing Summary |
|-------|------------------|
| **Reuben** | "Let him live, and not die"—survival, though diminished |
| **Judah** | YHWH hears his voice; help against adversaries |
| **Levi** | Urim and Thummim; teaching Torah; altar service |
| **Benjamin** | "Beloved of YHWH"; dwells in safety; YHWH covers him |
| **Joseph** | Blessed land; precious things of heaven, earth, hills; strength like a wild ox |
| **Zebulun/Issachar** | Rejoice in going out and in tents; abundance of seas |
| **Gad** | Like a lioness; chose the first portion; executed righteousness |
| **Dan** | Lion's cub leaping from Bashan |
| **Naphtali** | Satisfied with favor; full of YHWH's blessing |
| **Asher** | Most blessed; foot dipped in oil; strength as days |

**Note:** Simeon is not mentioned. By the time of the tribal allotments, Simeon was absorbed into Judah's territory (Joshua 19:1-9).

**Levi's Blessing:**
Unique in its focus on priestly function:
- Urim and Thummim (divination implements)
- Tested at Massah and Meribah
- Prioritized YHWH over family (Exodus 32:26-29)
- Teaches ordinances and law
- Offers incense and burnt offerings

**Joseph's Blessing:**
The longest and most elaborate—richly agricultural:
- Precious dew from heaven
- Deep waters below
- Fruits of sun and moon
- Ancient mountains and everlasting hills
- "The good will of him who dwelt in the bush"—the burning bush God

Joseph is called "him who was set apart from his brothers" (*nezir echav*)—echoing his Genesis story.

**"As Your Days, So Shall Your Strength Be":**
*U-che-yameicha dov'echa*—Asher's blessing. One of the most quoted verses: strength proportional to the demands of each day.

**The Conclusion (33:26-29):**
Praise of YHWH and blessing on Israel:
- "There is none like unto God, O Jeshurun"
- YHWH rides the heavens as your help
- "The eternal God is a dwelling place"
- "Underneath are the everlasting arms"
- Israel dwells safely
- "Happy are you, O Israel"—*ashreicha Yisra'el*
- "A people saved by YHWH"

**Archetypal Layer:** The blessing parallels Jacob's blessing in Genesis 49, but with significant differences. Jacob's blessings were often prophetic and sometimes harsh (Simeon, Levi). Moses' blessings are gentler, more pastoral—a father's final benediction.

The "everlasting arms underneath" is one of the Bible's most comforting images—YHWH holding up his people.

**Psychological Reading:** Final blessings carry special weight. Moses' last words are not curse but blessing—despite Israel's history of rebellion. He blesses them into the future.

**Ethical Inversion Applied:**
- "Torah is our inheritance"—the law is gift, not burden
- Levi prioritized YHWH over family—covenant supersedes kinship
- Joseph receives the longest blessing—the separated one is most blessed
- "As your days, so your strength"—adequate resources for each day
- "Everlasting arms underneath"—divine support is constant
- "Happy are you, O Israel"—blessed identity

**Modern Equivalent:** The verse "as your days, so shall your strength be" comforts those facing uncertain futures. The "everlasting arms" image sustains those in crisis. And the tribal blessings model how communities can celebrate diverse gifts and callings.

# Deuteronomy Chapter 29: The Covenant Renewed in Moab

*From the Hebrew: הַנִּסְתָּרֹת (HaNistarot) — The Hidden Things*

---

**29:1** These are the words of the covenant which YHWH commanded Moses to make with the children of Israel in the land of Moab, besides the covenant which he made with them in Horeb.

---

**29:2** And Moses called unto all Israel, and said unto them: "You have seen all that YHWH did before your eyes in the land of Egypt unto Pharaoh, and unto all his servants, and unto all his land;

**29:3** "The great trials which your eyes saw, the signs and those great wonders.

**29:4** "But YHWH has not given you a heart to know, and eyes to see, and ears to hear, unto this day.

**29:5** "And I have led you forty years in the wilderness; your clothes have not worn out upon you, and your shoe has not worn out upon your foot.

**29:6** "You have not eaten bread, neither have you drunk wine or strong drink; that you might know that I am YHWH your Consciousness.

**29:7** "And when you came unto this place, Sihon the king of Heshbon, and Og the king of Bashan, came out against us unto battle, and we smote them.

**29:8** "And we took their land, and gave it for an inheritance unto the Reubenites, and to the Gadites, and to the half-tribe of the Manassites.

**29:9** "Observe therefore the words of this covenant, and do them, that you may prosper in all that you do.

---

**29:10** "You stand this day all of you before YHWH your Consciousness: your heads, your tribes, your elders, and your officers, all the men of Israel,

**29:11** "Your little ones, your wives, and the stranger who is in the midst of your camp, from the hewer of your wood unto the drawer of your water;

**29:12** "That you should enter into the covenant of YHWH your Consciousness, and into his oath, which YHWH your Consciousness makes with you this day;

**29:13** "That he may establish you this day unto himself for a people, and that he may be unto you a God, as he spoke unto you, and as he swore unto your fathers, to Abraham, to Isaac, and to Jacob.

**29:14** "Neither with you only do I make this covenant and this oath,

**29:15** "But with him who stands here with us this day before YHWH our Consciousness, and also with him who is not here with us this day.

---

**29:16** "For you know how we dwelt in the land of Egypt, and how we came through the midst of the nations through which you passed.

**29:17** "And you have seen their detestable things, and their idols, wood and stone, silver and gold, which were among them.

**29:18** "Lest there should be among you man, or woman, or family, or tribe, whose heart turns away this day from YHWH our Consciousness, to go to serve the gods of those nations; lest there should be among you a root bearing gall and wormwood—שֹׁרֶשׁ פֹּרֶה רֹאשׁ וְלַעֲנָה (shoresh poreh rosh ve-la'anah);

**29:19** "And it come to pass, when he hears the words of this curse, that he blesses himself in his heart, saying: 'I shall have peace, though I walk in the stubbornness of my heart'—to end the watered with the dry.

**29:20** "YHWH will not be willing to pardon him, but then the anger of YHWH and his jealousy shall smoke against that man, and all the curse that is written in this book shall lie upon him, and YHWH shall blot out his name from under heaven.

**29:21** "And YHWH shall separate him unto evil out of all the tribes of Israel, according to all the curses of the covenant that is written in this book of the law.

---

**29:22** "And the generation to come, your children that shall rise up after you, and the foreigner that shall come from a far land, shall say, when they see the plagues of that land, and the sicknesses with which YHWH has made it sick;

**29:23** "And that the whole land thereof is brimstone, and salt, and a burning, that it is not sown, nor bears, nor any grass grows therein, like the overthrow of Sodom and Gomorrah, Admah and Zeboiim, which YHWH overthrew in his anger and in his wrath;

**29:24** "All the nations shall say: 'Why has YHWH done thus unto this land? What is the heat of this great anger?'

**29:25** "Then they shall say: 'Because they forsook the covenant of YHWH, the Consciousness of their fathers, which he made with them when he brought them forth out of the land of Egypt;

**29:26** "'And went and served other gods, and worshipped them, gods that they knew not, and that he had not allotted unto them;

**29:27** "'Therefore the anger of YHWH was kindled against this land, to bring upon it all the curse that is written in this book;

**29:28** "'And YHWH rooted them out of their land in anger, and in wrath, and in great indignation, and cast them into another land, as at this day.'

**29:29** "The secret things belong unto YHWH our Consciousness; but the things that are revealed belong unto us and to our children forever, that we may do all the words of this law—הַנִּסְתָּרֹת לַיהוה אֱלֹהֵינוּ וְהַנִּגְלֹת לָנוּ וּלְבָנֵינוּ עַד־עוֹלָם (ha-nistarot la-YHWH Eloheinu ve-ha-niglot lanu u-le-vaneinu ad-olam)."

---

## Synthesis Notes

**Key Restorations:**

**A Second Covenant:**
"Besides the covenant which he made with them in Horeb." This is the Moab covenant, supplementing Sinai. Moses renews the covenant with the generation that will actually enter the land.

**"YHWH Has Not Given You...":**
A striking statement: "YHWH has not given you a heart to know, and eyes to see, and ears to hear, unto this day." Despite all they witnessed, understanding has not come. This echoes Isaiah 6:9-10 and is quoted in Romans 11:8.

**The Miraculous Forty Years:**
- Clothes didn't wear out
- Shoes didn't wear out
- No bread or wine (only manna and water)—"that you might know that I am YHWH"

The wilderness deprivation was pedagogical: to teach dependence on YHWH.

**All Present for Covenant:**
The assembly includes everyone:
- Leaders (heads, tribes, elders, officers)
- Common people (all the men of Israel)
- Dependents (little ones, wives)
- Outsiders (strangers in the camp)
- Workers (wood hewers, water drawers)

No one is excluded. The covenant is comprehensive.

**"With Him Who Is Not Here":**
The covenant binds not only those present but also "him who is not here with us this day"—future generations. The unborn are included in the covenant.

**The Root Bearing Gall and Wormwood:**
*Shoresh poreh rosh ve-la'anah*—a poisonous root. One person whose heart turns away can corrupt the whole community. Hebrews 12:15 alludes to this: "lest any root of bitterness springing up trouble you."

**"I Shall Have Peace":**
The self-deceiver hears the curses and says, "I'll be fine anyway." He blesses himself, believing the curse won't apply to him. "To end the watered with the dry"—this obscure phrase may mean his stubbornness will destroy both innocent and guilty together.

**YHWH Will Not Pardon:**
For the presumptuous self-deceiver: no pardon. The curses will lie upon him; his name will be blotted out.

**The Desolate Land:**
Future generations and foreigners will ask: "Why has YHWH done thus unto this land?" The answer: "Because they forsook the covenant."

The land becomes like Sodom and Gomorrah—brimstone, salt, burning, barren. The destruction is testimony to covenant violation.

**The Secret and the Revealed (29:29):**

*Ha-nistarot la-YHWH Eloheinu*—"The secret things belong unto YHWH our Consciousness."

*Ve-ha-niglot lanu u-le-vaneinu ad-olam*—"But the things that are revealed belong unto us and to our children forever."

**Purpose**: "That we may do all the words of this law."

This verse distinguishes divine mystery from human responsibility. What YHWH has hidden is his concern; what he has revealed is ours to obey.

**Archetypal Layer:** The Moab covenant is **covenant with the second generation**. The first generation made covenant at Sinai and died in the wilderness. Their children receive their own covenant moment.

"With him who is not here" extends covenant **across time**. Each generation is bound, though not physically present.

**Psychological Reading:** The self-deceiver who says "I shall have peace" is warned against. Internal rationalization cannot escape external consequence. The curse finds those who think they're exempt.

**Ethical Inversion Applied:**
- Two covenants—Sinai and Moab, complementary
- "Not given you a heart to know"—seeing is not understanding
- All present—no exclusion from covenant
- Future generations included—the unborn are bound
- The poisonous root—one person can corrupt many
- Secret and revealed—mystery belongs to God; obedience belongs to us

**Modern Equivalent:** The verse about secret and revealed things has shaped approaches to theological mystery. What is hidden, leave to God; what is revealed, obey. And the warning about the self-deceiver who assumes "I shall have peace" speaks to moral complacency.

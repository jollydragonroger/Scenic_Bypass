# Deuteronomy Chapter 9: Not Because of Your Righteousness

*From the Hebrew: עַם קְשֵׁה־עֹרֶף (Am Qesheh-Oref) — A Stiff-Necked People*

---

**9:1** "Hear, O Israel: you are to pass over the Jordan this day, to go in to dispossess nations greater and mightier than yourself, cities great and fortified up to heaven,

**9:2** "A people great and tall, the sons of the Anakim, whom you know, and of whom you have heard say: 'Who can stand before the sons of Anak?'

**9:3** "Know therefore this day, that YHWH your Consciousness is he who goes over before you as a devouring fire; he will destroy them, and he will bring them down before you; so shall you drive them out, and make them perish quickly, as YHWH has spoken unto you.

**9:4** "Speak not in your heart, after that YHWH your Consciousness has thrust them out from before you, saying: 'For my righteousness YHWH has brought me in to possess this land'; whereas for the wickedness of these nations YHWH drives them out from before you.

**9:5** "Not for your righteousness, or for the uprightness of your heart, do you go in to possess their land; but for the wickedness of these nations YHWH your Consciousness drives them out from before you, and that he may establish the word which YHWH swore unto your fathers, to Abraham, to Isaac, and to Jacob.

**9:6** "Know therefore, that YHWH your Consciousness gives you not this good land to possess it for your righteousness; for you are a stiff-necked people—עַם קְשֵׁה־עֹרֶף (am qesheh-oref).

---

**9:7** "Remember, and forget not, how you provoked YHWH your Consciousness to wrath in the wilderness; from the day that you came forth out of the land of Egypt, until you came unto this place, you have been rebellious against YHWH.

**9:8** "Also in Horeb you provoked YHWH to wrath, and YHWH was angry with you to destroy you.

**9:9** "When I went up into the mount to receive the tables of stone, even the tables of the covenant which YHWH made with you, then I abode in the mount forty days and forty nights; I neither ate bread nor drank water.

**9:10** "And YHWH delivered unto me the two tables of stone written with the finger of God; and on them was written according to all the words, which YHWH spoke with you in the mount out of the midst of the fire in the day of the assembly.

**9:11** "And it came to pass at the end of forty days and forty nights, that YHWH gave me the two tables of stone, even the tables of the covenant.

**9:12** "And YHWH said unto me: 'Arise, get down quickly from here; for your people whom you have brought forth out of Egypt have dealt corruptly; they have quickly turned aside out of the way which I commanded them; they have made them a molten image.'

**9:13** "Furthermore YHWH spoke unto me, saying: 'I have seen this people, and behold, it is a stiff-necked people;

**9:14** "'Let me alone, that I may destroy them, and blot out their name from under heaven; and I will make of you a nation mightier and greater than they.'

**9:15** "So I turned and came down from the mount, and the mount was burning with fire; and the two tables of the covenant were in my two hands.

**9:16** "And I looked, and behold, you had sinned against YHWH your Consciousness; you had made yourselves a molten calf; you had turned aside quickly out of the way which YHWH had commanded you.

**9:17** "And I took hold of the two tables, and cast them out of my two hands, and broke them before your eyes.

**9:18** "And I fell down before YHWH, as at the first, forty days and forty nights; I neither ate bread nor drank water; because of all your sin which you sinned, in doing what was evil in the sight of YHWH, to provoke him.

**9:19** "For I was afraid of the anger and hot displeasure, with which YHWH was wroth against you to destroy you. But YHWH listened unto me that time also.

**9:20** "And YHWH was very angry with Aaron to destroy him; and I prayed for Aaron also at the same time.

**9:21** "And I took your sin, the calf which you had made, and burned it with fire, and beat it in pieces, grinding it very small, until it was as fine as dust; and I cast the dust thereof into the brook that descended out of the mount.

**9:22** "And at Taberah, and at Massah, and at Kibroth-hattaavah, you provoked YHWH to wrath.

**9:23** "And when YHWH sent you from Kadesh-barnea, saying: 'Go up and possess the land which I have given you'; then you rebelled against the commandment of YHWH your Consciousness, and you believed him not, nor listened to his voice.

**9:24** "You have been rebellious against YHWH from the day that I knew you.

---

**9:25** "So I fell down before YHWH the forty days and forty nights that I fell down; because YHWH had said he would destroy you.

**9:26** "And I prayed unto YHWH, and said: 'O Lord YHWH, destroy not your people and your inheritance, whom you have redeemed through your greatness, whom you have brought forth out of Egypt with a mighty hand.

**9:27** "'Remember your servants, Abraham, Isaac, and Jacob; look not unto the stubbornness of this people, nor to their wickedness, nor to their sin;

**9:28** "'Lest the land from which you brought us out say: Because YHWH was not able to bring them into the land which he promised unto them, and because he hated them, he has brought them out to slay them in the wilderness.

**9:29** "'Yet they are your people and your inheritance, whom you brought out by your great power and by your outstretched arm.'"

---

## Synthesis Notes

**Key Restorations:**

**Not Your Righteousness:**
Moses emphatically denies any notion of Israel's merit:
- "Not for your righteousness"
- "Not for the uprightness of your heart"
- "For you are a stiff-necked people"

The land is given for two reasons:
1. The wickedness of the nations being dispossessed
2. YHWH's oath to the patriarchs

Israel's possession is grace, not reward.

**"Stiff-Necked People" (עַם קְשֵׁה־עֹרֶף):**
The ox that will not turn when the yoke is pulled—stubborn, resistant, unyielding. This characterization appears repeatedly.

**The Catalog of Rebellions:**
Moses lists Israel's provocations:
- Horeb (the golden calf)
- Taberah (fire for complaint)
- Massah (testing YHWH)
- Kibroth-hattaavah (craving meat)
- Kadesh-barnea (refusing to enter)

"You have been rebellious against YHWH from the day that I knew you."

**The Golden Calf Retold:**
Moses recounts:
- Forty days and nights on the mountain, no food or water
- Tables of stone written with God's finger
- YHWH's announcement: "Your people have dealt corruptly"
- YHWH's offer: "I will make of you a nation mightier"
- Moses' descent, the burning mountain, the calf
- Breaking the tablets "before your eyes"
- Another forty days of prostration and fasting
- Prayer for Aaron, who was also in danger of destruction
- Grinding the calf to dust, casting it into the brook

**Moses' Intercession:**
His prayer appeals to:
- YHWH's redemptive investment ("your people and your inheritance")
- The patriarchs (Abraham, Isaac, Jacob)
- YHWH's reputation ("lest the land... say YHWH was not able")

The argument: destroying Israel would be interpreted as YHWH's failure or hatred, not Israel's sin.

**"Your People" / "My People":**
Note the tension: YHWH says "your people whom you brought out" (distancing); Moses says "your people... whom you brought out" (reassigning ownership). The covenant relationship is contested in the crisis.

**Archetypal Layer:** The chapter is **anti-triumphalism**. Before entering the land, Israel must hear clearly: this is not earned. The stiff-necked record proves unworthiness. The gift is pure grace.

Moses' intercession models **advocacy for the guilty**. He does not deny their sin but appeals to YHWH's own commitments.

**Psychological Reading:** The repeated "not for your righteousness" prevents the dangerous conclusion that success proves merit. Israel must enter the land with humility, not entitlement.

**Ethical Inversion Applied:**
- "Not for your righteousness"—possession is grace, not merit
- "Stiff-necked people"—honest self-assessment required
- Rebellious from the beginning—the record is clear
- Moses intercedes for the guilty—advocacy despite sin
- YHWH's reputation matters—his honor is at stake in Israel's fate

**Modern Equivalent:** The warning against attributing success to merit applies to any community that has received unearned advantage. The honest recounting of failures (Horeb, Taberah, Massah, Kibroth-hattaavah, Kadesh-barnea) models the kind of corporate memory that prevents triumphalism.

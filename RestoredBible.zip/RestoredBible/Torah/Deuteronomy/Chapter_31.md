# Deuteronomy Chapter 31: Moses' Final Charge

*From the Hebrew: חִזְקוּ וְאִמְצוּ (Chizqu Ve-Imtsu) — Be Strong and Courageous*

---

**31:1** And Moses went and spoke these words unto all Israel.

**31:2** And he said unto them: "I am a hundred and twenty years old this day; I can no more go out and come in; and YHWH has said unto me: 'You shall not go over this Jordan.'

**31:3** "YHWH your Consciousness, he will go over before you; he will destroy these nations from before you, and you shall dispossess them; and Joshua, he shall go over before you, as YHWH has spoken.

**31:4** "And YHWH will do unto them as he did to Sihon and to Og, the kings of the Amorites, and unto their land, whom he destroyed.

**31:5** "And YHWH will deliver them up before you, and you shall do unto them according unto all the commandment which I have commanded you.

**31:6** "Be strong and of good courage, fear not, nor be afraid of them; for YHWH your Consciousness, he it is who goes with you; he will not fail you, nor forsake you—לֹא יַרְפְּךָ וְלֹא יַעַזְבֶךָּ (lo yarpe'cha ve-lo ya'azveka)."

---

**31:7** And Moses called unto Joshua, and said unto him in the sight of all Israel: "Be strong and of good courage; for you shall go with this people into the land which YHWH has sworn unto their fathers to give them; and you shall cause them to inherit it.

**31:8** "And YHWH, he it is who goes before you; he will be with you, he will not fail you, neither forsake you; fear not, neither be dismayed."

---

**31:9** And Moses wrote this law, and delivered it unto the priests the sons of Levi, who bore the ark of the covenant of YHWH, and unto all the elders of Israel.

**31:10** And Moses commanded them, saying: "At the end of every seven years, in the set time of the year of release, in the feast of booths,

**31:11** "When all Israel comes to appear before YHWH your Consciousness in the place which he shall choose, you shall read this law before all Israel in their hearing.

**31:12** "Assemble the people, the men and the women and the little ones, and the stranger who is within your gates, that they may hear, and that they may learn, and fear YHWH your Consciousness, and observe to do all the words of this law;

**31:13** "And that their children, who have not known, may hear, and learn to fear YHWH your Consciousness, as long as you live in the land into which you go over the Jordan to possess it."

---

**31:14** And YHWH said unto Moses: "Behold, your days approach that you must die; call Joshua, and present yourselves in the tent of meeting, that I may give him a charge." And Moses and Joshua went, and presented themselves in the tent of meeting.

**31:15** And YHWH appeared in the tent in a pillar of cloud; and the pillar of cloud stood over the door of the tent.

**31:16** And YHWH said unto Moses: "Behold, you shall sleep with your fathers; and this people will rise up, and go astray after the foreign gods of the land, into which they go to be among them, and will forsake me, and break my covenant which I have made with them.

**31:17** "Then my anger shall be kindled against them in that day, and I will forsake them, and I will hide my face from them, and they shall be devoured, and many evils and troubles shall come upon them; so that they will say in that day: 'Are not these evils come upon us because our God is not among us?'

**31:18** "And I will surely hide my face in that day for all the evil which they shall have wrought, in that they have turned unto other gods.

**31:19** "Now therefore write for yourselves this song, and teach it to the children of Israel; put it in their mouths, that this song may be a witness for me against the children of Israel.

**31:20** "For when I shall have brought them into the land which I swore unto their fathers, flowing with milk and honey, and they shall have eaten and filled themselves, and grown fat; then will they turn unto other gods, and serve them, and despise me, and break my covenant.

**31:21** "And it shall come to pass, when many evils and troubles have come upon them, that this song shall testify before them as a witness; for it shall not be forgotten out of the mouths of their seed; for I know their imagination which they frame this day, before I have brought them into the land which I swore."

**31:22** So Moses wrote this song the same day, and taught it to the children of Israel.

**31:23** And he gave Joshua the son of Nun a charge, and said: "Be strong and of good courage; for you shall bring the children of Israel into the land which I swore unto them; and I will be with you."

---

**31:24** And it came to pass, when Moses had made an end of writing the words of this law in a book, until they were finished,

**31:25** That Moses commanded the Levites, who bore the ark of the covenant of YHWH, saying:

**31:26** "Take this book of the law, and put it beside the ark of the covenant of YHWH your Consciousness, that it may be there for a witness against you.

**31:27** "For I know your rebellion, and your stiff neck; behold, while I am yet alive with you this day, you have been rebellious against YHWH; and how much more after my death?

**31:28** "Assemble unto me all the elders of your tribes, and your officers, that I may speak these words in their ears, and call heaven and earth to witness against them.

**31:29** "For I know that after my death you will utterly corrupt yourselves, and turn aside from the way which I have commanded you; and evil will befall you in the end of days; because you will do that which is evil in the sight of YHWH, to provoke him through the work of your hands."

**31:30** And Moses spoke in the ears of all the assembly of Israel the words of this song, until they were finished.

---

## Synthesis Notes

**Key Restorations:**

**Moses at 120:**
"I am a hundred and twenty years old this day; I can no more go out and come in." Moses' life is complete. Jewish tradition divides it: 40 years in Egypt, 40 years in Midian, 40 years leading Israel.

**"Be Strong and of Good Courage":**
*Chazaq ve-emats*—this phrase appears repeatedly:
- To all Israel (31:6)
- To Joshua publicly (31:7)
- To Joshua from YHWH (31:23)

It becomes Joshua's charge and the book of Joshua's theme (Joshua 1:6, 7, 9, 18).

**"He Will Not Fail You, Nor Forsake You":**
*Lo yarpe'cha ve-lo ya'azveka*—YHWH's promise. Quoted in Hebrews 13:5: "I will never leave you, nor forsake you."

**The Law Written and Delivered:**
Moses writes "this law" (*ha-Torah ha-zot*) and gives it to:
- The priests (sons of Levi)
- The elders of Israel

**The Septennial Reading:**
Every seven years, at Sukkot, in the shemittah year:
- Assemble all Israel (men, women, children, strangers)
- Read the entire law publicly
- Purpose: "that they may hear, and that they may learn, and fear YHWH"
- Especially for children "who have not known"

This is *Hakhel*—the assembly. It continued in Jewish practice when possible.

**YHWH's Prophecy of Apostasy:**
YHWH tells Moses what will happen after his death:
- Israel will go astray after foreign gods
- They will forsake YHWH and break the covenant
- YHWH's anger will kindle
- He will "hide my face" (*hester panim*)
- Evils and troubles will come
- They will ask: "Is not our God not among us?"
- YHWH will hide his face because of their idolatry

**The Song as Witness:**
A song (chapter 32) is commanded:
- Written by Moses
- Taught to Israel
- Placed "in their mouths"
- Will testify against them when evil comes
- "It shall not be forgotten out of the mouths of their seed"

Songs are remembered when prose is forgotten. The song is mnemonic witness.

**The Book Beside the Ark:**
The completed "book of the law" is placed beside (not inside) the ark of the covenant. It serves as "a witness against you."

**Moses Knows Their Rebellion:**
"I know your rebellion, and your stiff neck... while I am yet alive with you this day, you have been rebellious... how much more after my death?"

Moses has no illusions. He predicts: "After my death you will utterly corrupt yourselves."

**"In the End of Days":**
*Be-acharit ha-yamim*—evil will befall them in the latter days. This eschatological phrase points to future judgment.

**Archetypal Layer:** The chapter is **transition of leadership**. Moses cannot continue; Joshua must take over. But the real transition is from human leader to divine presence: "YHWH... he it is who goes before you."

The hiding of God's face (*hester panim*) is **divine withdrawal in response to covenant betrayal**. It's not absence but deliberate turning away.

**Psychological Reading:** Moses' candor about Israel's nature (rebellious, stiff-necked, will corrupt themselves) is stark realism. He harbors no illusion that his teaching will prevent apostasy.

**Ethical Inversion Applied:**
- Moses cannot continue—even great leaders reach limits
- "Be strong and of good courage"—the charge for transition
- "He will not fail you"—human leaders change; YHWH remains
- Public reading every seven years—the law is for all
- The song as witness—music outlasts prose
- "I know your rebellion"—realism about human nature

**Modern Equivalent:** Leadership transitions require explicit commissioning ("be strong and of good courage"). The septennial public reading anticipates civic education. And the song as witness shows how music embeds values in memory.

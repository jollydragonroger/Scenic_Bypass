# Leviticus Chapter 6: The Guilt Offering and Priestly Instructions

*From the Hebrew: צַו (Tsav) — Command*

---

**6:1** And YHWH spoke unto Moses, saying:

**6:2** "If a soul sins and commits a trespass against YHWH, and deals falsely with his neighbor in a matter of deposit or of pledge, or through robbery, or has oppressed his neighbor,

**6:3** "Or has found that which was lost, and deals falsely about it, and swears to a lie—in any of all these things that a man may do, sinning in them—

**6:4** "Then it shall be, if he has sinned and is guilty, that he shall restore that which he took by robbery, or the thing which he got by oppression, or the deposit which was deposited with him, or the lost thing which he found,

**6:5** "Or anything about which he has sworn falsely; he shall restore it in full—בְּרֹאשׁוֹ (be-rosho)—and shall add to it the fifth part; unto him to whom it belongs he shall give it, on the day of his guilt offering.

**6:6** "And he shall bring his guilt offering unto YHWH, a ram without blemish from the flock, according to your valuation, for a guilt offering, unto the priest.

**6:7** "And the priest shall make atonement for him before YHWH, and he shall be forgiven concerning any one of all the things which one may do to become guilty thereby."

---

**6:8** And YHWH spoke unto Moses, saying:

**6:9** "Command Aaron and his sons, saying: 'This is the law of the burnt offering—תּוֹרַת הָעֹלָה (torat ha-olah): The burnt offering shall be on the hearth upon the altar all night until the morning; and the fire of the altar shall be kept burning on it.

**6:10** "'And the priest shall put on his linen garment, and his linen undergarment he shall put upon his flesh; and he shall take up the ashes to which the fire has consumed the burnt offering on the altar, and he shall put them beside the altar.

**6:11** "'And he shall put off his garments, and put on other garments, and carry the ashes outside the camp unto a clean place.

**6:12** "'And the fire upon the altar shall be kept burning on it; it shall not go out; and the priest shall burn wood on it every morning, and lay the burnt offering in order upon it, and shall burn upon it the fat of the peace offerings.

**6:13** "'Fire shall be kept burning upon the altar continually—אֵשׁ תָּמִיד (esh tamid); it shall not go out.

---

**6:14** "'And this is the law of the grain offering—תּוֹרַת הַמִּנְחָה (torat ha-minchah): The sons of Aaron shall offer it before YHWH, in front of the altar.

**6:15** "'And he shall take from it his handful of the fine flour of the grain offering and of its oil, and all the frankincense which is upon the grain offering, and shall burn it upon the altar for a pleasing aroma, as its memorial portion unto YHWH.

**6:16** "'And the remainder of it Aaron and his sons shall eat; with unleavened bread shall it be eaten in a holy place; in the court of the tent of meeting they shall eat it.

**6:17** "'It shall not be baked with leaven. I have given it as their portion of my fire offerings; it is most holy, as the sin offering and as the guilt offering.

**6:18** "'Every male among the children of Aaron shall eat of it, as a portion forever throughout your generations, from the fire offerings of YHWH; whoever touches them shall be holy.'"

**6:19** And YHWH spoke unto Moses, saying:

**6:20** "This is the offering of Aaron and his sons, which they shall offer unto YHWH on the day when he is anointed: the tenth part of an ephah of fine flour for a grain offering perpetually, half of it in the morning and half of it in the evening.

**6:21** "On a griddle it shall be made with oil; when it is soaked, you shall bring it in; baked pieces of the grain offering you shall offer for a pleasing aroma unto YHWH.

**6:22** "And the anointed priest who shall be in his place among his sons shall offer it; it is a statute forever unto YHWH; it shall be wholly burned.

**6:23** "And every grain offering of a priest shall be wholly burned; it shall not be eaten."

---

**6:24** And YHWH spoke unto Moses, saying:

**6:25** "Speak unto Aaron and to his sons, saying: 'This is the law of the sin offering—תּוֹרַת הַחַטָּאת (torat ha-chattat): In the place where the burnt offering is slaughtered shall the sin offering be slaughtered before YHWH; it is most holy.

**6:26** "'The priest who offers it for sin shall eat it; in a holy place it shall be eaten, in the court of the tent of meeting.

**6:27** "'Whatever touches its flesh shall be holy; and when any of its blood is sprinkled upon a garment, you shall wash that upon which it was sprinkled in a holy place.

**6:28** "'And the earthen vessel in which it is boiled shall be broken; and if it is boiled in a bronze vessel, it shall be scoured and rinsed in water.

**6:29** "'Every male among the priests shall eat of it; it is most holy.

**6:30** "'And no sin offering, of which any of the blood is brought into the tent of meeting to make atonement in the holy place, shall be eaten; it shall be burned with fire.'"

---

## Synthesis Notes

**Key Restorations:**

**Guilt Offering for Interpersonal Wrongs (6:1-7):**

Expanding from chapter 5, the *asham* now addresses wrongs against neighbors that are also "trespass against YHWH":
- False dealing with deposits or pledges
- Robbery or oppression
- Finding lost property and lying about it
- Swearing falsely

These are sins against people, but they are also violations of the divine order. Sin against neighbor is sin against YHWH.

**The Requirement:**
1. **Restore in full** (*be-rosho*, "in its principal")
2. **Add 20%** (the fifth part)
3. **Give to the owner** on the day of the guilt offering
4. **Bring the offering** (a ram)
5. **Atonement is made**; forgiveness granted

Sacrifice alone is insufficient; restitution is required. You cannot offer a ram without repaying the victim.

**The Perpetual Fire (אֵשׁ תָּמִיד):**
"Fire shall be kept burning upon the altar continually; it shall not go out." The eternal flame—never extinguished. This represents YHWH's constant presence and the ongoing availability of approach through sacrifice.

**Priestly Duties for Burnt Offering:**
- The fire burns all night
- In the morning, the priest removes ashes (wearing linen)
- Changes garments to carry ashes outside the camp
- Adds wood, lays out the burnt offering, burns peace offering fat

The priest serves the fire, maintains the altar, handles the holy.

**The Priest's Grain Offering:**
When a priest is anointed, he brings a daily grain offering—half in morning, half in evening. Unlike lay grain offerings, the priest's is entirely burned; none is eaten. The priest cannot eat his own offering.

**Sin Offering Rules:**
- Slaughtered where the burnt offering is slaughtered
- Most holy (*qodesh qodashim*)
- The priest who offers it eats it (except for offerings whose blood enters the tent of meeting)
- Eaten in a holy place
- What touches it becomes holy
- Blood-stained garments washed in holy place
- Clay vessels broken; bronze vessels scoured

The holiness is contagious. What contacts the sin offering is affected.

**"Whatever Touches Its Flesh Shall Be Holy":**
Holiness transfers. The meat of the sin offering is so sacred that anything contacting it becomes holy—requiring special treatment.

**Vessels Broken or Scoured:**
Clay absorbs; it cannot be cleansed—so it is broken. Bronze can be cleaned—so it is scoured and rinsed. The sacred leaves traces.

**Exception:**
If the sin offering's blood was brought inside the tent of meeting (for priest's or congregation's sin, chapter 4), the meat is not eaten but burned outside the camp. The deeper the penetration of the blood, the more complete the separation of the carcass.

**Archetypal Layer:** The perpetual fire (*esh tamid*) represents the **never-extinguished divine presence**. As long as the fire burns, approach is possible. The holiness that transfers to objects (garments, vessels) shows that the sacred affects whatever it touches—holiness is not containable.

**Psychological Reading:** Restitution to the victim is required before sacrifice to YHWH. The horizontal relationship (neighbor) must be addressed alongside the vertical (YHWH). You cannot buy off divine favor while owing a human debt.

**Ethical Inversion Applied:**
- Sin against neighbor = trespass against YHWH—horizontal and vertical are linked
- Restitution + 20%—the victim is compensated beyond mere return
- The perpetual fire—divine availability never ceases
- Priests eat what they offer (except their own)—the sacred is shared
- Holiness is contagious—contact with the sacred changes things

**Modern Equivalent:** You cannot reconcile with God while wronging your neighbor. Restitution (not just apology) is required—and with interest. The "perpetual fire" represents institutional commitments that must be maintained continuously. And the breaking of clay vessels (which absorb what they contact) suggests that some encounters with the sacred leave permanent traces.

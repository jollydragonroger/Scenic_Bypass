# Leviticus Chapter 19: The Holiness Code

*From the Hebrew: קְדֹשִׁים (Kedoshim) — You Shall Be Holy*

---

**19:1** And YHWH spoke unto Moses, saying:

**19:2** "Speak unto all the congregation of the children of Israel, and say unto them: 'You shall be holy—קְדֹשִׁים תִּהְיוּ (qedoshim tihyu)—for I YHWH your Consciousness am holy.

**19:3** "'You shall fear every man his mother and his father; and you shall keep my sabbaths: I am YHWH your Consciousness.

**19:4** "'Turn not unto idols—אֱלִילִים (elilim)—nor make for yourselves molten gods: I am YHWH your Consciousness.

**19:5** "'And when you offer a sacrifice of peace offerings unto YHWH, you shall offer it that you may be accepted.

**19:6** "'It shall be eaten on the day you offer it, and on the morrow; and if any remain until the third day, it shall be burned with fire.

**19:7** "'And if it be eaten at all on the third day, it is *piggul*; it shall not be accepted.

**19:8** "'And everyone who eats it shall bear his iniquity, because he has profaned the holy thing of YHWH; and that soul shall be cut off from his people.

---

**19:9** "'And when you reap the harvest of your land, you shall not wholly reap the corner of your field, neither shall you gather the gleaning of your harvest.

**19:10** "'And you shall not glean your vineyard, neither shall you gather the fallen fruit of your vineyard; you shall leave them for the poor and for the stranger: I am YHWH your Consciousness.

**19:11** "'You shall not steal; you shall not deal falsely; you shall not lie one to another.

**19:12** "'And you shall not swear by my name falsely, and profane the name of your Consciousness: I am YHWH.

**19:13** "'You shall not oppress your neighbor, nor rob him; the wages of a hired servant shall not remain with you all night until the morning.

**19:14** "'You shall not curse the deaf, nor put a stumbling block before the blind—לִפְנֵי עִוֵּר לֹא תִתֵּן מִכְשֹׁל (lifnei ivver lo titten michshol); but you shall fear your Consciousness: I am YHWH.

**19:15** "'You shall do no unrighteousness in judgment; you shall not respect the person of the poor, nor favor the person of the mighty; in righteousness you shall judge your neighbor.

**19:16** "'You shall not go about as a talebearer among your people; you shall not stand by the blood of your neighbor: I am YHWH.

**19:17** "'You shall not hate your brother in your heart; you shall surely rebuke your neighbor, and not bear sin because of him.

**19:18** "'You shall not take vengeance, nor bear any grudge against the children of your people; but you shall love your neighbor as yourself—וְאָהַבְתָּ לְרֵעֲךָ כָּמוֹךָ (ve-ahavta le-re'acha kamocha): I am YHWH.

---

**19:19** "'You shall keep my statutes. You shall not let your cattle breed with a diverse kind; you shall not sow your field with two kinds of seed; neither shall a garment of two kinds of stuff mingled together come upon you.

**19:20** "'And whoever lies carnally with a woman who is a bondmaid, designated for a man, and not at all redeemed, nor freedom given her, inquiry shall be made; they shall not be put to death, because she was not free.

**19:21** "'And he shall bring his guilt offering unto YHWH, unto the door of the tent of meeting, a ram for a guilt offering.

**19:22** "'And the priest shall make atonement for him with the ram of the guilt offering before YHWH for his sin which he has sinned; and he shall be forgiven for his sin which he has sinned.

**19:23** "'And when you come into the land, and plant all manner of trees for food, then you shall count its fruit as forbidden—עָרְלָה (orlah); three years shall it be as forbidden unto you; it shall not be eaten.

**19:24** "'And in the fourth year all its fruit shall be holy, for giving praise unto YHWH.

**19:25** "'And in the fifth year you may eat of its fruit, that it may yield unto you its increase: I am YHWH your Consciousness.

**19:26** "'You shall not eat anything with the blood; you shall not practice divination nor soothsaying—לֹא תְנַחֲשׁוּ וְלֹא תְעוֹנֵנוּ (lo tenachashu ve-lo te'onenu).

**19:27** "'You shall not round the corners of your heads, neither shall you mar the corners of your beard.

**19:28** "'You shall not make any cuttings in your flesh for the dead, nor print any marks upon you: I am YHWH.

**19:29** "'Do not profane your daughter, to make her a harlot, lest the land fall into harlotry, and the land become full of wickedness.

**19:30** "'You shall keep my sabbaths, and reverence my sanctuary: I am YHWH.

**19:31** "'Turn not unto mediums—הָאֹבֹת (ha-ovot)—nor unto wizards—הַיִּדְּעֹנִים (ha-yidde'onim); seek them not out, to be defiled by them: I am YHWH your Consciousness.

**19:32** "'You shall rise up before the hoary head, and honor the face of the old man, and fear your Consciousness: I am YHWH.

**19:33** "'And if a stranger sojourns with you in your land, you shall not wrong him.

**19:34** "'The stranger who sojourns with you shall be unto you as the native-born among you, and you shall love him as yourself—וְאָהַבְתָּ לוֹ כָּמוֹךָ (ve-ahavta lo kamocha)—for you were strangers in the land of Egypt: I am YHWH your Consciousness.

**19:35** "'You shall do no unrighteousness in judgment, in measures of length, of weight, or of quantity.

**19:36** "'Just balances, just weights, a just ephah, and a just hin, shall you have: I am YHWH your Consciousness, who brought you out of the land of Egypt.

**19:37** "'And you shall observe all my statutes, and all my ordinances, and do them: I am YHWH.'"

---

## Synthesis Notes

**Key Restorations:**

**"You Shall Be Holy":**
*Qedoshim tihyu ki qadosh ani YHWH Eloheichem* (קְדֹשִׁים תִּהְיוּ כִּי קָדוֹשׁ אֲנִי יהוה אֱלֹהֵיכֶם)—the programmatic statement. Israel's holiness derives from YHWH's holiness. The imitation of God is the ethical imperative.

**The Ten Commandments Echoed:**
This chapter weaves through the Decalogue:
- Parents (19:3) — Fifth Commandment
- Sabbaths (19:3, 30) — Fourth Commandment
- Idols (19:4) — First/Second Commandments
- Stealing, lying (19:11) — Eighth, Ninth Commandments
- False swearing (19:12) — Third Commandment

**The Social Ethics:**

Remarkable ethical demands:

- **Gleaning laws** (19:9-10): Leave the corners of fields and fallen grapes for the poor and stranger
- **Prompt wage payment** (19:13): Pay workers the same day
- **Protection of the vulnerable** (19:14): Don't curse the deaf or trip the blind
- **Just judgment** (19:15): Favor neither poor nor rich
- **No slander** (19:16): Don't be a talebearer
- **Active rescue** (19:16): Don't stand idly by when your neighbor's life is at risk
- **Constructive rebuke** (19:17): Reprove rather than harboring hatred
- **No vengeance or grudge** (19:18): Release resentment

**"Love Your Neighbor as Yourself":**
*Ve-ahavta le-re'acha kamocha* (וְאָהַבְתָּ לְרֵעֲךָ כָּמוֹךָ)—the command Jesus identified as the second greatest (Matthew 22:39). The neighbor (*re'a*) in context is the fellow Israelite.

**"Love the Stranger as Yourself":**
*Ve-ahavta lo kamocha* (וְאָהַבְתָּ לוֹ כָּמוֹךָ)—the same command extended to the stranger/immigrant (19:34). The rationale: "for you were strangers in Egypt." Memory of oppression grounds ethics of inclusion.

**"Before the Blind" (לִפְנֵי עִוֵּר):**
This becomes a major principle in Jewish ethics. Literally: don't trip a blind person. Broadly: don't mislead anyone who lacks the capacity to see what you're doing—don't give bad advice to the naïve, don't enable the addicted.

**Forbidden Mixtures (כִּלְאַיִם, Kilayim):**
- Don't crossbreed animals
- Don't sow mixed seeds
- Don't wear mixed fabrics (wool and linen together)

These prohibitions preserve created categories. The principle: maintain the distinctions God established.

**Orlah (עָרְלָה):**
The fruit of new trees is "uncircumcised" (the same word) for three years. Year four is holy (given to YHWH). Year five is available for eating. Patience is required; first-fruits belong to God.

**Divination Prohibited:**
*Nachash* (divination from omens) and *onan* (soothsaying) are forbidden. Israel must not seek hidden knowledge through pagan techniques. YHWH reveals what needs knowing.

**Mediums and Wizards:**
*Ovot* and *yidde'onim*—those who consult the dead or familiar spirits. This practice is forbidden because it bypasses YHWH. The dead are in YHWH's realm; the living should not manipulate that boundary.

**Honor the Elderly:**
"Rise before the hoary head"—stand when an elder enters. Physical gesture of respect for age and experience.

**Honest Weights and Measures:**
Just balances (*moznei tsedeq*), just weights (*avnei tsedeq*). Commercial honesty is a divine requirement. Cheating in business is an offense against YHWH.

**Archetypal Layer:** Leviticus 19 is the **ethical core of the Torah**—the holiness that expresses itself in social justice, care for the vulnerable, honest commerce, and love of neighbor and stranger. Holiness is not only ritual purity but right relationship.

**Psychological Reading:** The prohibition "You shall not hate your brother in your heart" addresses the interior. The command to rebuke rather than harbor resentment is psychologically healthy—address the issue rather than nurturing bitterness. Love of neighbor as self presumes healthy self-regard as the basis for regard of others.

**Ethical Inversion Applied:**
- Holiness is imitation of God—not arbitrary rules
- Gleaning laws institutionalize care for the poor
- "Before the blind"—protect those who cannot protect themselves
- Love extends to the stranger—the boundary of "neighbor" expands
- Memory of oppression grounds ethics—"you were strangers"
- Honest commerce is divine requirement—cheating is impiety

**Modern Equivalent:** This chapter remains the foundation of Jewish social ethics. The gleaning principle (leave something for those who cannot provide for themselves) undergirds welfare systems. "Before the blind" applies to consumer protection, informed consent, and fiduciary duty. And the twin commands—love neighbor, love stranger—define the scope of ethical obligation.

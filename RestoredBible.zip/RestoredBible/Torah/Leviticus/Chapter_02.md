# Leviticus Chapter 2: The Grain Offering

*From the Hebrew: מִנְחָה (Minchah) — Gift/Tribute*

---

**2:1** "And when anyone brings a grain offering—מִנְחָה (minchah)—unto YHWH, his offering shall be of fine flour; and he shall pour oil upon it and put frankincense upon it.

**2:2** "And he shall bring it to Aaron's sons the priests; and he shall take from it his handful of its fine flour and of its oil, with all its frankincense; and the priest shall burn the memorial portion—אַזְכָּרָתָהּ (azkaratah)—upon the altar, a fire offering of a pleasing aroma unto YHWH.

**2:3** "And the remainder of the grain offering shall be Aaron's and his sons'; it is a most holy thing—קֹדֶשׁ קָדָשִׁים (qodesh qodashim)—of the fire offerings of YHWH.

---

**2:4** "And when you bring a grain offering baked in the oven, it shall be unleavened cakes of fine flour mixed with oil, or unleavened wafers anointed with oil.

**2:5** "And if your offering is a grain offering baked on a griddle, it shall be of fine flour unleavened, mixed with oil.

**2:6** "You shall break it in pieces and pour oil upon it; it is a grain offering.

**2:7** "And if your offering is a grain offering cooked in a pan, it shall be made of fine flour with oil.

**2:8** "And you shall bring the grain offering that is made of these things unto YHWH; and it shall be presented unto the priest, and he shall bring it unto the altar.

**2:9** "And the priest shall take up from the grain offering the memorial portion, and shall burn it upon the altar, a fire offering of a pleasing aroma unto YHWH.

**2:10** "And the remainder of the grain offering shall be Aaron's and his sons'; it is a most holy thing of the fire offerings of YHWH.

---

**2:11** "No grain offering which you bring unto YHWH shall be made with leaven—חָמֵץ (chamets); for you shall burn no leaven nor any honey as a fire offering unto YHWH.

**2:12** "As an offering of firstfruits you may bring them unto YHWH; but they shall not come up for a pleasing aroma on the altar.

**2:13** "And every grain offering of yours you shall season with salt; you shall not let the salt of the covenant of your Consciousness—מֶלַח בְּרִית אֱלֹהֶיךָ (melach berit Elohecha)—be lacking from your grain offering; with all your offerings you shall offer salt.

---

**2:14** "And if you bring a grain offering of firstfruits unto YHWH, you shall bring for the grain offering of your firstfruits fresh ears roasted with fire, grits of fresh grain.

**2:15** "And you shall put oil upon it, and lay frankincense upon it; it is a grain offering.

**2:16** "And the priest shall burn the memorial portion: some of its grits and some of its oil, with all its frankincense, a fire offering unto YHWH."

---

## Synthesis Notes

**Key Restorations:**

**Minchah (מִנְחָה):**
The word means "gift" or "tribute"—the kind of present one brings to a king. The grain offering is non-animal, a gift from the harvest. It can be offered alone or alongside animal sacrifices.

**Fine Flour, Oil, Frankincense:**
The three components:
- **Fine flour** (*solet*, סֹלֶת): best quality, finely ground
- **Oil**: adds richness, represents blessing
- **Frankincense** (*levonah*): creates fragrant smoke when burned

**The Memorial Portion (אַזְכָּרָה, azkarah):**
Only a handful is burned—the *azkarah*, literally "that which causes remembrance." The burning creates a memorial before YHWH. The rest goes to the priests.

**"Most Holy" (קֹדֶשׁ קָדָשִׁים, qodesh qodashim):**
The priestly portion is "most holy"—it must be eaten in a holy place by holy persons (priests). The same designation as the holy of holies.

**Forms of the Minchah:**

1. **Raw flour** with oil and frankincense (verses 1-3)
2. **Baked in oven**: unleavened cakes or wafers (verse 4)
3. **Griddle**: flat bread broken in pieces (verses 5-6)
4. **Pan**: deeper cooking (verse 7)
5. **Firstfruits**: fresh roasted grain (verses 14-16)

The variety accommodates different circumstances and preferences.

**No Leaven, No Honey:**
*Chamets* (חָמֵץ), leaven, is prohibited. *Devash* (דְּבָשׁ), honey, is also prohibited on the altar. Both cause fermentation/decomposition. The altar receives what is stable, not what is transforming through decay.

Leaven and honey may be brought as firstfruits (verse 12) but not burned on the altar.

**Salt Required:**
"The salt of the covenant of your Consciousness"—*melach berit* (מֶלַח בְּרִית). Salt preserves, does not decay, represents permanence. Every offering must include salt.

The phrase "salt of the covenant" suggests the covenant is enduring, incorruptible, preserved like salt preserves.

**Archetypal Layer:** The grain offering is the **gift of cultivation**—human labor transformed into offering. It represents the fruit of work, not just the gift of animals. The partial burning (memorial portion) and priestly consumption create a shared meal: YHWH receives the aroma; priests receive the substance.

**Salt** represents covenant permanence; **leaven** represents the process of change/decay. The altar receives the stable, not the fermenting.

**Psychological Reading:** The grain offering recognizes that not all gifts are animals. The poor could bring flour. The agricultural worker brings the harvest. The offering meets people where they are economically and vocationally.

**Ethical Inversion Applied:**
- The gift is from human labor—agriculture contributes to worship
- Salt represents covenant permanence—relationships that endure
- Leaven is excluded—no corruption, no ferment on the altar
- The priests eat the remainder—the sacred is shared, not wasted
- Variety of forms accommodates different capacities

**Modern Equivalent:** Not every offering is costly. The flour offering represents the gift of ordinary work. Salt—preservative, seasoning—symbolizes what makes relationships durable. And the prohibition of leaven suggests that what is brought to the divine should be whole, not in the process of decomposition.

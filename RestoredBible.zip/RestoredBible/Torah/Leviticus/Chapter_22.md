# Leviticus Chapter 22: Sacred Offerings and Their Requirements

*From the Hebrew: קָדָשִׁים (Qodashim) — Holy Things*

---

**22:1** And YHWH spoke unto Moses, saying:

**22:2** "Speak unto Aaron and to his sons, that they separate themselves from the holy things of the children of Israel, which they hallow unto me, and that they not profane my holy name: I am YHWH.

**22:3** "Say unto them: 'Whoever of all your offspring throughout your generations, who approaches the holy things, which the children of Israel hallow unto YHWH, having his uncleanness upon him, that soul shall be cut off from before me: I am YHWH.

**22:4** "'Whatever man of the offspring of Aaron is a *tsarua*, or has a discharge, he shall not eat of the holy things, until he is clean. And whoever touches anything unclean by the dead, or a man whose seed goes from him,

**22:5** "'Or whoever touches any swarming thing, by which he may be made unclean, or a man of whom he may become unclean, whatever his uncleanness;

**22:6** "'The soul who touches any such shall be unclean until the evening, and shall not eat of the holy things, unless he bathes his flesh in water.

**22:7** "'And when the sun is down, he shall be clean; and afterward he may eat of the holy things, for it is his bread.

**22:8** "'That which dies of itself, or is torn by beasts, he shall not eat, to defile himself by it: I am YHWH.

**22:9** "'They shall therefore keep my charge, lest they bear sin for it, and die thereby, if they profane it: I am YHWH who sanctifies them.

---

**22:10** "'No stranger shall eat of the holy thing; a sojourner of the priest, or a hired servant, shall not eat of the holy thing.

**22:11** "'But if a priest buys any soul with his money, he may eat of it; and those who are born in his house, they may eat of his bread.

**22:12** "'And if a priest's daughter is married unto a stranger, she shall not eat of the contribution of the holy things.

**22:13** "'But if a priest's daughter is a widow, or divorced, and has no child, and is returned unto her father's house, as in her youth, she may eat of her father's bread; but no stranger shall eat of it.

**22:14** "'And if a man eats of the holy thing unwittingly, then he shall add the fifth part of it unto it, and shall give the holy thing unto the priest.

**22:15** "'And they shall not profane the holy things of the children of Israel, which they offer unto YHWH,

**22:16** "'And so cause them to bear the iniquity that brings guilt, when they eat their holy things; for I am YHWH who sanctifies them.'"

---

**22:17** And YHWH spoke unto Moses, saying:

**22:18** "Speak unto Aaron, and to his sons, and unto all the children of Israel, and say unto them: 'Whatever man of the house of Israel, or of the strangers in Israel, who offers his offering, whether it be any of their vows, or any of their freewill offerings, which they offer unto YHWH for a burnt offering,

**22:19** "'That you may be accepted, you shall offer a male without blemish—תָּמִים (tamim)—of the cattle, of the sheep, or of the goats.

**22:20** "'Whatever has a blemish, you shall not offer; for it shall not be acceptable for you.

**22:21** "'And whoever offers a sacrifice of peace offerings unto YHWH to accomplish a vow, or for a freewill offering, of the herd or of the flock, it shall be perfect to be accepted; there shall be no blemish in it.

**22:22** "'Blind, or broken, or maimed, or having a running sore, or scab, or scurvy, you shall not offer these unto YHWH, nor make a fire offering of them upon the altar unto YHWH.

**22:23** "'Either a bull or a lamb that has anything too long or too short, you may offer for a freewill offering; but for a vow it shall not be accepted.

**22:24** "'That which has its testicles bruised, or crushed, or torn, or cut, you shall not offer unto YHWH; neither shall you do thus in your land.

**22:25** "'Neither from the hand of a foreigner shall you offer the bread of your Consciousness of any of these; for their corruption is in them, there is a blemish in them; they shall not be accepted for you.'"

---

**22:26** And YHWH spoke unto Moses, saying:

**22:27** "When a bull, or a sheep, or a goat, is brought forth, then it shall be seven days with its mother; and from the eighth day and on it shall be accepted for a fire offering unto YHWH.

**22:28** "And whether it be cow or ewe, you shall not kill it and its young both in one day.

**22:29** "And when you sacrifice a sacrifice of thanksgiving unto YHWH, you shall sacrifice it that you may be accepted.

**22:30** "On the same day it shall be eaten; you shall leave none of it until the morning: I am YHWH.

**22:31** "Therefore you shall keep my commandments, and do them: I am YHWH.

**22:32** "And you shall not profane my holy name; but I will be hallowed among the children of Israel—וְנִקְדַּשְׁתִּי בְּתוֹךְ בְּנֵי יִשְׂרָאֵל (ve-niqdashti be-toch benei Yisra'el): I am YHWH who sanctifies you,

**22:33** "Who brought you out of the land of Egypt, to be your Consciousness: I am YHWH."

---

## Synthesis Notes

**Key Restorations:**

**Priests and Uncleanness:**
Priests must not approach holy things while unclean:
- *Tsara'at* (skin disease)
- Discharge (*zav*)
- Contact with dead
- Seminal emission
- Contact with unclean creatures
- Contact with unclean persons

Violation while unclean = cut off. The penalty is severe because the profanation is severe.

**Cleansing Process:**
Unclean until evening; bathing required; then may eat the holy things. The sacred food is "his bread"—the priest's sustenance from the offerings.

**Who May Eat Sacred Food:**
- Priests and their households (including slaves born or purchased)
- Priest's daughter returned home (widowed/divorced, no children)

Who may not:
- Strangers
- Sojourners
- Hired servants
- Priest's daughter married to a non-priest

**Unwitting Eating:**
If someone eats sacred food unknowingly, they must repay it plus 20% (the fifth part). The principle from chapter 5 continues.

**Offerings Without Blemish:**

For burnt offerings and vows:
- Male without blemish (*tamim*)
- No blindness, broken bones, maiming, sores, scabs

For freewill offerings:
- Slight disproportion (too long/short limbs) permitted
- But for vows, perfection is required

Castrated animals are completely forbidden—not even for freewill offerings.

**"Their Corruption Is in Them":**
Animals from foreigners are not acceptable. The implication: the standards of foreign breeders cannot be trusted; blemishes may be hidden.

**The Newborn:**
An animal must be with its mother seven days before being acceptable for sacrifice. The eighth day (new beginning) is the first day of eligibility. This parallels circumcision on the eighth day.

**Mother and Young:**
"You shall not kill it and its young both in one day." This law protects against cruelty—wiping out mother and offspring together. Maimonides saw this as training compassion.

**Thanksgiving Must Be Eaten Same Day:**
The thanksgiving offering (*todah*) cannot be kept overnight. Gratitude is for now, not storage.

**"I Will Be Hallowed":**
*Ve-niqdashti* (וְנִקְדַּשְׁתִּי)—"I will be sanctified." YHWH's holiness is manifested through Israel's obedience. When Israel keeps the commandments, YHWH is hallowed among them.

**The Exodus Foundation:**
"Who brought you out of the land of Egypt"—the basis for all these commands. Liberation creates obligation. The God who saved has the right to require.

**Archetypal Layer:** The blemish-free offering represents **offering the best**. The animal is symbolic of the offerer; a flawed offering suggests a flawed heart. The eight-day requirement parallels human development—the newborn needs time with its mother before being separated.

**Psychological Reading:** The compassion laws (not killing mother and young together, waiting eight days) train emotional sensitivity. Ritual practice shapes character. The prohibition isn't merely about the animal but about what the practice does to the human who performs it.

**Ethical Inversion Applied:**
- Priests in uncleanness must not approach—proximity requires purity
- Sacred food is for sacred persons—boundaries matter
- The best is required for vows—commitment deserves excellence
- Mother and young protected—cruelty is prohibited
- YHWH is hallowed through Israel's obedience—divine reputation linked to human behavior

**Modern Equivalent:** Offerings (whatever form they take) should represent one's best, not leftovers. The protection of mother and young anticipates animal welfare concerns. And the principle that God's reputation is affected by the community's behavior ("I will be hallowed among the children of Israel") challenges religious communities: their conduct reflects on what they claim to represent.

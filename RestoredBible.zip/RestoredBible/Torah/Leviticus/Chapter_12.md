# Leviticus Chapter 12: Purification After Childbirth

*From the Hebrew: טֻמְאַת יוֹלֶדֶת (Tumat Yoledet) — Impurity of the One Who Bears*

---

**12:1** And YHWH spoke unto Moses, saying:

**12:2** "Speak unto the children of Israel, saying: 'If a woman conceives and bears a male child, then she shall be unclean seven days; as in the days of her menstrual impurity—כִּימֵי נִדַּת דְּוֺתָהּ (ki-mei niddat devotah)—she shall be unclean.

**12:3** "'And on the eighth day the flesh of his foreskin shall be circumcised—וּבַיּוֹם הַשְּׁמִינִי יִמּוֹל (u-va-yom ha-shemini yimmol).

**12:4** "'And she shall continue in the blood of purification—בִּדְמֵי טָהֳרָה (bi-demei tahorah)—thirty-three days; she shall not touch any holy thing, nor come into the sanctuary, until the days of her purification are fulfilled.

**12:5** "'But if she bears a female child, then she shall be unclean two weeks, as in her menstrual impurity; and she shall continue in the blood of purification sixty-six days.

**12:6** "'And when the days of her purification are fulfilled, for a son or for a daughter, she shall bring a lamb a year old for a burnt offering, and a young pigeon or a turtledove for a sin offering, unto the door of the tent of meeting, unto the priest.

**12:7** "'And he shall offer it before YHWH, and make atonement for her; and she shall be cleansed from the flow of her blood. This is the law for her who bears, whether a male or a female.

**12:8** "'And if her means do not suffice for a lamb, then she shall take two turtledoves or two young pigeons, one for a burnt offering and the other for a sin offering; and the priest shall make atonement for her, and she shall be clean.'"

---

## Synthesis Notes

**Key Restorations:**

**The Periods of Impurity:**

For a male child:
- 7 days of impurity (like menstruation)
- 33 days of "blood of purification"
- Total: 40 days

For a female child:
- 14 days of impurity
- 66 days of "blood of purification"
- Total: 80 days

The doubled period for a female child has generated extensive discussion. Possible interpretations:
- The female child will herself bear children and menstruate—the impurity anticipates her future
- Ancient association of blood with life and the sacred requires extended separation
- No fully satisfactory explanation is given in the text

**"Blood of Purification" (דְּמֵי טָהֳרָה):**
After the initial impurity period, the woman enters a transitional state. She is not fully impure (unclean in the strict sense) but is excluded from the sanctuary and holy things. The blood is now "blood of purification"—the process is underway.

**Circumcision on the Eighth Day:**
The command is embedded here: "on the eighth day the flesh of his foreskin shall be circumcised." The pattern is consistent—seven days complete the old; the eighth begins the new. Circumcision marks the male child's entry into the covenant.

**The Offerings:**
After the purification period:
- Burnt offering (lamb or, for the poor, a bird)
- Sin offering (bird)

The sin offering is not for moral sin but for ritual impurity. Childbirth, though blessed, involves blood and physical processes that require purification before sanctuary access.

**Mary's Offering (Luke 2:22-24):**
Mary brought "a pair of turtledoves or two young pigeons"—the poor woman's offering (verse 8). This indicates Jesus' family's economic status. They followed this Levitical law precisely.

**"She Shall Be Clean":**
The process concludes with full restoration. The woman can again touch holy things and enter the sanctuary. The impurity is temporary and remediable.

**Archetypal Layer:** Childbirth involves the threshold between life and death, the shedding of blood, the emergence of new life from within. The impurity is not moral but ontological—proximity to the boundary of existence. The purification period allows the transition from that liminal space back to normal sacred access.

The **eighth day** for circumcision continues the pattern: seven = completion of a cycle; eight = new beginning. The male child enters covenant relationship on the day of new beginning.

**Psychological Reading:** The period of separation may have functioned practically—allowing the new mother time to recover before resuming normal community and religious activities. The gradation (7/33 or 14/66 days) structures the transition.

The offering at the end marks reintegration. The mother returns to full participation, publicly affirmed through sacrifice.

**Ethical Inversion Applied:**
- Childbirth is blessed but involves blood—proximity to life's boundary
- The impurity is temporary—not a condemnation but a process
- The poor are accommodated—birds instead of lamb
- The eighth day marks new covenant entry
- The offering accomplishes reintegration—the woman is fully restored

**Difficult Elements:**
The doubled period for female children remains difficult. The text does not explain it. Possible approaches:
- Acknowledge the difficulty without pretending to resolve it
- Note that ancient purity systems often have unexplained asymmetries
- Recognize that the symbolic system may carry meanings no longer accessible

**Modern Equivalent:** Transitions (birth, death, major life changes) may require structured time before full reintegration. The new mother's separation is not punishment but acknowledgment that something significant has occurred. Rituals of reintegration (the offering) mark the return to normal life.

# Leviticus Chapter 1: The Burnt Offering

*From the Hebrew: וַיִּקְרָא (Vayikra) — And He Called*

---

**1:1** And YHWH called unto Moses, and spoke unto him from the tent of meeting, saying:

**1:2** "Speak unto the children of Israel, and say unto them: 'When any man of you brings an offering—קָרְבָּן (qorban)—unto YHWH, you shall bring your offering of the cattle, of the herd or of the flock.

**1:3** "'If his offering is a burnt offering—עֹלָה (olah)—of the herd, he shall offer it a male without blemish; he shall offer it at the door of the tent of meeting, that he may be accepted—לִרְצֹנוֹ (lirtsono)—before YHWH.

**1:4** "'And he shall lay his hand upon the head of the burnt offering, and it shall be accepted for him to make atonement for him—לְכַפֵּר עָלָיו (le-chapper alav).

**1:5** "'And he shall slaughter the young bull before YHWH; and Aaron's sons the priests shall present the blood, and throw the blood against the altar round about, which is at the door of the tent of meeting.

**1:6** "'And he shall flay the burnt offering and cut it into its pieces.

**1:7** "'And the sons of Aaron the priest shall put fire upon the altar and lay wood in order upon the fire.

**1:8** "'And Aaron's sons the priests shall lay the pieces, the head, and the fat, in order upon the wood that is on the fire which is upon the altar.

**1:9** "'But its entrails and its legs he shall wash with water; and the priest shall burn the whole on the altar, a burnt offering, a fire offering of a pleasing aroma—רֵיחַ נִיחוֹחַ (reiach nichoach)—unto YHWH.

---

**1:10** "'And if his offering is of the flock, of the sheep or of the goats, for a burnt offering, he shall offer it a male without blemish.

**1:11** "'And he shall slaughter it on the north side of the altar before YHWH; and Aaron's sons the priests shall throw its blood against the altar round about.

**1:12** "'And he shall cut it into its pieces, with its head and its fat; and the priest shall lay them in order on the wood that is on the fire which is upon the altar.

**1:13** "'But the entrails and the legs he shall wash with water; and the priest shall offer the whole, and burn it upon the altar; it is a burnt offering, a fire offering of a pleasing aroma unto YHWH.

---

**1:14** "'And if his offering to YHWH is a burnt offering of birds, then he shall bring his offering of turtledoves or of young pigeons.

**1:15** "'And the priest shall bring it unto the altar, and wring off its head, and burn it on the altar; and its blood shall be drained out on the side of the altar.

**1:16** "'And he shall remove its crop with its feathers, and cast it beside the altar on the east side, in the place of the ashes.

**1:17** "'And he shall tear it open by its wings, but shall not divide it; and the priest shall burn it upon the altar, upon the wood that is upon the fire; it is a burnt offering, a fire offering of a pleasing aroma unto YHWH.'"

---

## Synthesis Notes

**Key Restorations:**

**"And YHWH Called":**
*Vayikra* (וַיִּקְרָא)—the book's Hebrew name. YHWH initiates communication from within the completed tabernacle. The glory that filled the tent (Exodus 40:34) now speaks. The presence is not silent but instructive.

**Qorban (קָרְבָּן) — Offering:**
From the root קָרַב (qarav), "to draw near." An offering is that which brings one near to YHWH. Sacrifice is about proximity, not transaction. The qorban creates closeness.

**The Burnt Offering (עֹלָה, Olah):**
From the root עָלָה (alah), "to go up." The olah goes up entirely in smoke—nothing is eaten by priests or offerer. It is complete dedication, total ascent.

**The Three Tiers:**
- **From the herd**: cattle (most expensive)
- **From the flock**: sheep or goats (middle tier)
- **From the birds**: turtledoves or pigeons (least expensive)

The poor can offer what the wealthy offer in intention. The value of the animal differs; the acceptance is the same.

**"Without Blemish" (תָּמִים, tamim):**
The animal must be whole, complete, perfect—no defects. What is offered to YHWH must be the best, not the disposable.

**"That He May Be Accepted" (לִרְצֹנוֹ, lirtsono):**
Literally "for his acceptance" or "for his favor." The offering creates a state of acceptability. The offerer is received.

**The Hand-Laying (סְמִיכָה, semichah):**
"He shall lay his hand upon the head"—the gesture of identification. The offerer and the offering become connected. What happens to the animal happens representatively to the person.

**"To Make Atonement" (לְכַפֵּר, le-chapper):**
From כָּפַר (kaphar), "to cover" or "to ransom." The offering covers sin, creates reconciliation, restores relationship. The atonement is effected through blood and fire.

**The Process:**

1. **Offerer brings** the animal to the tent of meeting
2. **Offerer lays hand** on the animal's head
3. **Offerer slaughters** the animal (not the priest)
4. **Priests handle the blood** (throwing it against the altar)
5. **Offerer flays and cuts** the animal
6. **Priests arrange** the pieces on the altar
7. **Everything burns**—complete consumption

**"A Pleasing Aroma" (רֵיחַ נִיחוֹחַ, reiach nichoach):**
Anthropomorphic language—YHWH "smells" the offering and is pleased. This is not about literal smell but about acceptance. The smoke ascending carries the dedication upward.

**The North Side:**
Sheep and goats are slaughtered "on the north side of the altar." Tradition associates north with judgment; the altar's north side is where the blood is offered.

**Birds for the Poor:**
The poorest Israelite can bring turtledoves or pigeons. The priest does the work (wringing the head, draining blood). The offering is accepted equally—"a pleasing aroma unto YHWH."

**Archetypal Layer:** The burnt offering is **total dedication**—nothing held back. The animal ascends entirely in smoke, symbolizing complete self-offering. The **fire = transformation** (symbol map): what was earthly becomes heavenly through flame. The offering that rises is the self that ascends.

**Psychological Reading:** The hand-laying creates identification. The offerer says, in effect, "This animal is me." What is then slaughtered, burned, and transformed is symbolically the old self. The burnt offering is ego-death ritualized—the willingness to give everything.

**Ethical Inversion Applied:**
- The qorban brings near—sacrifice is about relationship, not appeasement
- Three tiers ensure accessibility—wealth doesn't determine access to YHWH
- The offerer participates (slaughtering, cutting)—not merely watching
- "Without blemish" means best, not leftover
- The "pleasing aroma" suggests YHWH delights in dedication

**Modern Equivalent:** Total dedication (the olah) means holding nothing back. The gradations (herd, flock, birds) recognize economic difference without spiritual hierarchy. And the process requires the offerer's active participation—genuine devotion is not passive.

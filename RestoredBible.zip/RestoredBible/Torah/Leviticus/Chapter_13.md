# Leviticus Chapter 13: Laws Concerning Skin Diseases

*From the Hebrew: צָרַעַת (Tsara'at) — Affliction*

---

**13:1** And YHWH spoke unto Moses and unto Aaron, saying:

**13:2** "When a man has on the skin of his flesh a swelling—שְׂאֵת (se'et)—or a scab—סַפַּחַת (sappachat)—or a bright spot—בַּהֶרֶת (baheret)—and it becomes in the skin of his flesh the plague of *tsara'at*—נֶגַע צָרַעַת (nega tsara'at)—then he shall be brought unto Aaron the priest, or unto one of his sons the priests.

**13:3** "And the priest shall look at the plague in the skin of the flesh; and if the hair in the plague has turned white, and the appearance of the plague is deeper than the skin of his flesh, it is the plague of *tsara'at*; and the priest shall look at him, and pronounce him unclean.

**13:4** "And if the bright spot is white in the skin of his flesh, and its appearance is not deeper than the skin, and its hair has not turned white, then the priest shall shut up him who has the plague seven days.

**13:5** "And the priest shall look at him on the seventh day; and behold, if the plague in his sight has stayed, and the plague has not spread in the skin, then the priest shall shut him up seven days more.

**13:6** "And the priest shall look at him again on the seventh day; and behold, if the plague has faded, and the plague has not spread in the skin, then the priest shall pronounce him clean; it is a scab; and he shall wash his clothes, and be clean.

**13:7** "But if the scab spreads abroad in the skin, after he has shown himself to the priest for his cleansing, he shall show himself to the priest again.

**13:8** "And the priest shall look; and behold, if the scab has spread in the skin, then the priest shall pronounce him unclean; it is *tsara'at*.

---

**13:9** "When the plague of *tsara'at* is in a man, then he shall be brought unto the priest.

**13:10** "And the priest shall look; and behold, if there is a white swelling in the skin, and it has turned the hair white, and there is quick raw flesh in the swelling,

**13:11** "It is an old *tsara'at* in the skin of his flesh, and the priest shall pronounce him unclean; he shall not shut him up, for he is unclean.

**13:12** "And if the *tsara'at* breaks out abroad in the skin, and the *tsara'at* covers all the skin of him who has the plague from his head even to his feet, as far as the priest can see,

**13:13** "Then the priest shall look; and behold, if the *tsara'at* has covered all his flesh, he shall pronounce him clean who has the plague; it has all turned white; he is clean.

**13:14** "But whenever raw flesh appears in him, he shall be unclean.

**13:15** "And the priest shall look at the raw flesh, and pronounce him unclean; the raw flesh is unclean; it is *tsara'at*.

**13:16** "Or if the raw flesh turns again, and is changed unto white, then he shall come unto the priest.

**13:17** "And the priest shall look at him; and behold, if the plague has turned white, then the priest shall pronounce him clean who has the plague; he is clean.

---

**13:18** "And when the flesh has a boil in its skin, and it is healed,

**13:19** "And in the place of the boil there is a white swelling, or a bright spot, reddish-white, then it shall be shown to the priest.

**13:20** "And the priest shall look; and behold, if its appearance is lower than the skin, and its hair has turned white, then the priest shall pronounce him unclean; it is the plague of *tsara'at* that has broken out in the boil.

**13:21** "But if the priest looks at it, and behold, there is no white hair in it, and it is not lower than the skin, but is faded, then the priest shall shut him up seven days.

**13:22** "And if it spreads abroad in the skin, then the priest shall pronounce him unclean; it is a plague.

**13:23** "But if the bright spot stays in its place, and does not spread, it is the scar of the boil; and the priest shall pronounce him clean.

---

**13:24** "Or when the flesh has a burn—מִכְוַת־אֵשׁ (michvat-esh)—in its skin, and the raw flesh of the burn becomes a bright spot, reddish-white or white,

**13:25** "Then the priest shall look at it; and behold, if the hair in the bright spot has turned white, and its appearance is deeper than the skin, it is *tsara'at* that has broken out in the burn; and the priest shall pronounce him unclean; it is the plague of *tsara'at*.

**13:26** "But if the priest looks at it, and behold, there is no white hair in the bright spot, and it is not lower than the skin, but is faded, then the priest shall shut him up seven days.

**13:27** "And the priest shall look at him on the seventh day; if it has spread abroad in the skin, then the priest shall pronounce him unclean; it is the plague of *tsara'at*.

**13:28** "And if the bright spot stays in its place, and does not spread in the skin, but is faded, it is the swelling of the burn; and the priest shall pronounce him clean; for it is the scar of the burn.

---

**13:29** "And when a man or a woman has a plague upon the head or upon the beard,

**13:30** "Then the priest shall look at the plague; and behold, if its appearance is deeper than the skin, and there is in it yellow thin hair, then the priest shall pronounce him unclean; it is a scall—נֶתֶק (neteq)—it is *tsara'at* of the head or of the beard.

**13:31** "And if the priest looks at the plague of the scall, and behold, its appearance is not deeper than the skin, and there is no black hair in it, then the priest shall shut up him who has the plague of the scall seven days.

**13:32** "And on the seventh day the priest shall look at the plague; and behold, if the scall has not spread, and there is no yellow hair in it, and the appearance of the scall is not deeper than the skin,

**13:33** "Then he shall be shaved, but the scall shall he not shave; and the priest shall shut up him who has the scall seven days more.

**13:34** "And on the seventh day the priest shall look at the scall; and behold, if the scall has not spread in the skin, and its appearance is not deeper than the skin, then the priest shall pronounce him clean; and he shall wash his clothes, and be clean.

**13:35** "But if the scall spreads abroad in the skin after his cleansing,

**13:36** "Then the priest shall look at him; and behold, if the scall has spread in the skin, the priest shall not look for the yellow hair; he is unclean.

**13:37** "But if in his eyes the scall has stayed, and black hair has grown up in it, the scall is healed; he is clean; and the priest shall pronounce him clean.

---

**13:38** "And when a man or a woman has bright spots in the skin of the flesh, even white bright spots,

**13:39** "Then the priest shall look; and behold, if the bright spots in the skin of their flesh are dull white, it is a harmless rash that has broken out in the skin; he is clean.

**13:40** "And if a man's hair has fallen off his head, he is bald; he is clean.

**13:41** "And if his hair has fallen off from the front part of his head, he is forehead-bald; he is clean.

**13:42** "But if there is in the bald head, or the bald forehead, a reddish-white plague, it is *tsara'at* breaking out in his bald head or his bald forehead.

**13:43** "Then the priest shall look at him; and behold, if the swelling of the plague is reddish-white in his bald head or in his bald forehead, as the appearance of *tsara'at* in the skin of the flesh,

**13:44** "He is a leprous man—אִישׁ צָרוּעַ (ish tsarua)—he is unclean; the priest shall certainly pronounce him unclean; his plague is in his head.

---

**13:45** "And the *tsarua* in whom the plague is, his clothes shall be torn, and the hair of his head shall go loose, and he shall cover his upper lip, and shall cry, 'Unclean, unclean!'—טָמֵא טָמֵא (tame, tame).

**13:46** "All the days wherein the plague is in him he shall be unclean; he is unclean; he shall dwell alone—בָּדָד יֵשֵׁב (badad yeshev)—outside the camp shall his dwelling be.

---

**13:47** "And when the plague of *tsara'at* is in a garment, whether in a woolen garment or a linen garment,

**13:48** "Whether in the warp or the woof, of linen or of wool, or in a skin, or in anything made of skin,

**13:49** "If the plague is greenish or reddish in the garment, or in the skin, or in the warp, or in the woof, or in anything of skin, it is the plague of *tsara'at*, and shall be shown unto the priest.

**13:50** "And the priest shall look at the plague, and shut up that which has the plague seven days.

**13:51** "And he shall look at the plague on the seventh day; if the plague has spread in the garment, either in the warp, or in the woof, or in the skin, whatever service skin is used for, the plague is a malignant *tsara'at*; it is unclean.

**13:52** "And he shall burn the garment, whether the warp or the woof, in wool or in linen, or anything of skin, in which the plague is; for it is a malignant *tsara'at*; it shall be burned in the fire.

**13:53** "And if the priest shall look, and behold, the plague has not spread in the garment, either in the warp, or in the woof, or in anything of skin,

**13:54** "Then the priest shall command that they wash the thing in which the plague is, and he shall shut it up seven days more.

**13:55** "And the priest shall look at the plague after it is washed; and behold, if the plague has not changed its color, and the plague has not spread, it is unclean; you shall burn it in the fire; it is a fret, whether the bareness is inside or outside.

**13:56** "And if the priest looks, and behold, the plague is faded after the washing of it, then he shall tear it out of the garment, or out of the skin, or out of the warp, or out of the woof.

**13:57** "And if it appears still in the garment, either in the warp, or in the woof, or in anything of skin, it is breaking out; you shall burn with fire that in which the plague is.

**13:58** "And the garment, either the warp, or the woof, or whatever thing of skin it may be, which you shall wash, if the plague is departed from them, then it shall be washed a second time, and shall be clean.

**13:59** "This is the law of the plague of *tsara'at* in a garment of wool or linen, either in the warp or the woof, or anything of skin, to pronounce it clean, or to pronounce it unclean."

---

## Synthesis Notes

**Key Restorations:**

**Tsara'at (צָרַעַת):**
Traditionally translated "leprosy," *tsara'at* is not Hansen's disease (modern leprosy). It is a ritual category covering various skin conditions, and even affects clothing (verses 47-59). The condition is defined by symptoms: swelling, scabs, bright spots, white hair, spreading, depth below skin surface.

**The Priest as Diagnostician:**
The priest examines the afflicted. This is not medical diagnosis but ritual assessment. The priest determines clean or unclean status—a religious, not medical, judgment.

**The Quarantine System:**
- If symptoms are ambiguous: isolate for 7 days
- Re-examine: if stable, isolate 7 more days
- Re-examine: if healed, pronounce clean; if spreading, pronounce unclean

This quarantine serves community protection and diagnostic certainty.

**Signs of Uncleanness:**
- Hair turned white in the afflicted area
- Appearance deeper than skin
- Spreading of the condition
- Raw flesh visible

**Paradox of Total Coverage (13:12-13):**
If the *tsara'at* covers the entire body and has turned white with no raw flesh, the person is pronounced **clean**. This seems counterintuitive but may reflect:
- Complete transformation is stable
- Raw flesh indicates active disease
- Fully white skin indicates resolution

**The Proclamation (13:45-46):**
The confirmed *tsarua* must:
- Tear clothes (mourning)
- Let hair go loose (mourning)
- Cover the upper lip (barrier, shame, or to prevent transmission)
- Cry "Unclean, unclean!" (warning others)
- Dwell alone, outside the camp

This is social death—complete separation from community and sanctuary.

**Tsara'at in Garments:**
The condition can affect fabric and leather:
- Greenish or reddish discoloration
- Spreading indicates malignancy
- Treatment: washing, isolation, or burning

This may describe mold, mildew, or fungal growth that was associated with the same ritual category as skin disease.

**Archetypal Layer:** *Tsara'at* represents **corruption that must be identified and isolated**. The system protects the community from contagion—both physical and ritual. The afflicted person becomes a living symbol of death (torn clothes, loose hair, covering the face—all mourning practices).

The priest's role as diagnostician models the **discernment function**: distinguishing clean from unclean, disease from scar, active from healed.

**Psychological Reading:** The detailed diagnostic criteria train careful observation. Hasty judgment is prevented—the seven-day quarantine allows time. The system distinguishes between stable conditions (scars, baldness—clean) and active, spreading conditions (unclean).

**Ethical Inversion Applied:**
- The priest examines, not condemns—diagnosis before judgment
- Quarantine allows uncertainty—not immediate exclusion
- Complete transformation may mean healing—paradox of total coverage
- The afflicted warns others—community protection
- Healing restores—the process is not permanent if the condition resolves

**Modern Equivalent:** Public health systems still isolate contagious conditions. The distinction between diagnosis (what is this?) and status determination (what does it mean for community life?) remains relevant. The detailed criteria prevent hasty labeling—careful examination before pronouncement.

# Leviticus Chapter 24: The Lamp, the Bread, and the Blasphemer

*From the Hebrew: נֵר תָּמִיד (Ner Tamid) — The Eternal Light*

---

**24:1** And YHWH spoke unto Moses, saying:

**24:2** "Command the children of Israel, that they bring unto you pure olive oil beaten for the light, to cause a lamp to burn continually—לְהַעֲלֹת נֵר תָּמִיד (le-ha'alot ner tamid).

**24:3** "Outside the veil of the testimony, in the tent of meeting, Aaron shall set it in order from evening to morning before YHWH continually; it shall be a statute forever throughout your generations.

**24:4** "He shall set in order the lamps upon the pure lampstand before YHWH continually.

---

**24:5** "And you shall take fine flour, and bake twelve cakes of it; two tenth measures shall be in each cake.

**24:6** "And you shall set them in two rows, six in a row, upon the pure table before YHWH.

**24:7** "And you shall put pure frankincense upon each row, that it may be unto the bread as a memorial portion—אַזְכָּרָה (azkarah)—a fire offering unto YHWH.

**24:8** "Every sabbath day he shall set it in order before YHWH continually; it is from the children of Israel, an everlasting covenant.

**24:9** "And it shall be for Aaron and his sons; and they shall eat it in a holy place; for it is most holy unto him of the fire offerings of YHWH, a perpetual due."

---

**24:10** And the son of an Israelite woman, whose father was an Egyptian, went out among the children of Israel; and the son of the Israelite woman and a man of Israel strove together in the camp.

**24:11** And the son of the Israelite woman blasphemed the Name—וַיִּקֹּב... אֶת־הַשֵּׁם (va-yiqqov... et-ha-Shem)—and cursed; and they brought him unto Moses. And his mother's name was Shelomith, the daughter of Dibri, of the tribe of Dan.

**24:12** And they put him in custody, that it might be declared unto them at the mouth of YHWH.

**24:13** And YHWH spoke unto Moses, saying:

**24:14** "Bring forth him who cursed outside the camp; and let all who heard him lay their hands upon his head, and let all the congregation stone him.

**24:15** "And you shall speak unto the children of Israel, saying: 'Whoever curses his Consciousness shall bear his sin.

**24:16** "'And he who blasphemes the name of YHWH—וְנֹקֵב שֵׁם יהוה (ve-noqev shem YHWH)—shall surely be put to death; all the congregation shall certainly stone him; the stranger as well as the native-born, when he blasphemes the Name, shall be put to death.

---

**24:17** "'And he who takes the life of any man shall surely be put to death.

**24:18** "'And he who takes the life of a beast shall make it good, life for life—נֶפֶשׁ תַּחַת נָפֶשׁ (nefesh tachat nafesh).

**24:19** "'And if a man causes a blemish in his neighbor, as he has done, so shall it be done to him:

**24:20** "'Breach for breach, eye for eye, tooth for tooth—עַיִן תַּחַת עַיִן שֵׁן תַּחַת שֵׁן (ayin tachat ayin, shen tachat shen); as he has caused a blemish in a man, so shall it be done to him.

**24:21** "'And he who kills a beast shall make it good; and he who kills a man shall be put to death.

**24:22** "'You shall have one law—מִשְׁפַּט אֶחָד (mishpat echad)—for the stranger and for the native-born; for I am YHWH your Consciousness.'"

**24:23** And Moses spoke to the children of Israel, and they brought forth him who had cursed out of the camp, and stoned him with stones. And the children of Israel did as YHWH commanded Moses.

---

## Synthesis Notes

**Key Restorations:**

**The Eternal Lamp (נֵר תָּמִיד):**
The menorah burns continually. Aaron tends it evening to morning; the light never goes out. The *ner tamid* (eternal light) in synagogues today recalls this practice. The light symbolizes YHWH's constant presence.

**The Showbread (לֶחֶם הַפָּנִים):**
Twelve cakes (one for each tribe), arranged in two rows of six on the golden table. Renewed every sabbath; the old bread is eaten by the priests in a holy place. The frankincense is burned as the "memorial portion." This is bread "of the presence" (*lechem panim*)—continually before YHWH.

**The Case of the Blasphemer:**

A narrative interrupts the ritual laws:
- The son of an Israelite woman and Egyptian man
- A fight in the camp
- He "blasphemes the Name and curses"
- Brought to Moses; placed in custody
- Moses inquires of YHWH

**"The Name" (הַשֵּׁם, ha-Shem):**
The text uses "the Name" rather than writing the divine name in connection with blasphemy. This became the basis for Jewish practice of saying *ha-Shem* instead of pronouncing the tetragrammaton.

**The Penalty:**
Death by stoning. The witnesses lay hands on his head (transferring responsibility, perhaps indicating "his blood is on his own head"). The whole congregation participates in the execution.

**One Law for Stranger and Native:**
*Mishpat echad* (מִשְׁפַּט אֶחָד)—the same law applies to the mixed-heritage blasphemer as to any Israelite. Ethnic origin does not create different standards. This is remarkably egalitarian for ancient law.

**The Lex Talionis (24:17-21):**

Inserted here, the law of proportional justice:
- Human life taken = death
- Animal life taken = replacement (life for life)
- Bodily injury = equivalent injury (eye for eye, tooth for tooth)

**Proportionality:**
The *lex talionis* limits vengeance. You may not take more than was taken. The punishment fits the crime exactly. Jewish tradition interpreted this as monetary compensation equal to the injury, not literal mutilation.

**Archetypal Layer:** The eternal lamp and continual bread represent **YHWH's unceasing presence and provision**. The blasphemy case addresses **the power of speech**—words that attack the divine name are capital offenses. The lex talionis establishes **proportional justice**—neither excessive punishment nor inadequate response.

**Psychological Reading:** Blasphemy is not merely about offense but about undermining the sacred order. The Name represents YHWH's presence; to curse it is to attack the center of the community's identity. The collective stoning involves everyone—the community acts together.

**Ethical Inversion Applied:**
- The eternal lamp = YHWH's constant presence
- The showbread = continual provision for the tribes
- One law for all = ethnic origin doesn't determine legal status
- Eye for eye = proportional limitation on vengeance
- Witnesses lay hands = responsibility is clear and witnessed

**Difficult Elements:**
Death for blasphemy is severe. The text reflects a society where the sacred name was the center of communal identity. Attacking it was attacking the community's foundation. Modern application focuses on the principle (words matter, the sacred deserves protection) rather than the penalty.

**Modern Equivalent:** The eternal lamp continues in synagogues as the *ner tamid*. The showbread anticipates communion practices. The one-law principle is foundational to equal justice. And the lex talionis, properly understood as proportionality rather than vengeance, underlies modern jurisprudence: the punishment should fit the crime.

# Leviticus Chapter 15: Bodily Discharges

*From the Hebrew: זָב וְזָבָה (Zav ve-Zavah) — Flows and Impurity*

---

**15:1** And YHWH spoke unto Moses and to Aaron, saying:

**15:2** "Speak unto the children of Israel, and say unto them: 'When any man has a discharge from his flesh—זָב מִבְּשָׂרוֹ (zav mi-besaro)—his discharge is unclean.

**15:3** "'And this shall be his uncleanness in his discharge: whether his flesh runs with his discharge, or his flesh is stopped from his discharge, it is his uncleanness.

**15:4** "'Every bed on which he who has the discharge lies shall be unclean; and everything on which he sits shall be unclean.

**15:5** "'And whoever touches his bed shall wash his clothes, and bathe himself in water, and be unclean until the evening.

**15:6** "'And he who sits on anything on which he who has the discharge sat shall wash his clothes, and bathe himself in water, and be unclean until the evening.

**15:7** "'And he who touches the flesh of him who has the discharge shall wash his clothes, and bathe himself in water, and be unclean until the evening.

**15:8** "'And if he who has the discharge spits upon him who is clean, then he shall wash his clothes, and bathe himself in water, and be unclean until the evening.

**15:9** "'And whatever saddle he who has the discharge rides upon shall be unclean.

**15:10** "'And whoever touches anything that was under him shall be unclean until the evening; and he who carries those things shall wash his clothes, and bathe himself in water, and be unclean until the evening.

**15:11** "'And whomever he who has the discharge touches, without having rinsed his hands in water, shall wash his clothes, and bathe himself in water, and be unclean until the evening.

**15:12** "'And the earthen vessel which he who has the discharge touches shall be broken; and every vessel of wood shall be rinsed in water.

**15:13** "'And when he who has a discharge is cleansed of his discharge, then he shall count for himself seven days for his cleansing, and wash his clothes; and he shall bathe his flesh in living water—מַיִם חַיִּים (mayim chayyim)—and shall be clean.

**15:14** "'And on the eighth day he shall take for himself two turtledoves, or two young pigeons, and come before YHWH unto the door of the tent of meeting, and give them unto the priest.

**15:15** "'And the priest shall offer them, the one for a sin offering, and the other for a burnt offering; and the priest shall make atonement for him before YHWH for his discharge.

---

**15:16** "'And if any man has an emission of seed—שִׁכְבַת־זֶרַע (shichvat-zera)—then he shall bathe all his flesh in water, and be unclean until the evening.

**15:17** "'And every garment, and every skin, on which the seed is, shall be washed with water, and be unclean until the evening.

**15:18** "'And if a man lies with a woman and there is an emission of seed, they shall both bathe themselves in water, and be unclean until the evening.

---

**15:19** "'And if a woman has a discharge, and her discharge in her flesh is blood, she shall be in her impurity—נִדָּתָהּ (niddatah)—seven days; and whoever touches her shall be unclean until the evening.

**15:20** "'And everything upon which she lies during her impurity shall be unclean; everything also upon which she sits shall be unclean.

**15:21** "'And whoever touches her bed shall wash his clothes, and bathe himself in water, and be unclean until the evening.

**15:22** "'And whoever touches anything upon which she sits shall wash his clothes, and bathe himself in water, and be unclean until the evening.

**15:23** "'And if it is on the bed, or on anything on which she sits, when he touches it, he shall be unclean until the evening.

**15:24** "'And if any man lies with her, and her impurity is upon him, he shall be unclean seven days; and every bed on which he lies shall be unclean.

**15:25** "'And if a woman has a discharge of her blood many days not in the time of her impurity, or if she has a discharge beyond the time of her impurity, all the days of the discharge of her uncleanness she shall be as in the days of her impurity; she is unclean.

**15:26** "'Every bed on which she lies all the days of her discharge shall be unto her as the bed of her impurity; and everything on which she sits shall be unclean, as the uncleanness of her impurity.

**15:27** "'And whoever touches those things shall be unclean, and shall wash his clothes, and bathe himself in water, and be unclean until the evening.

**15:28** "'And if she is cleansed of her discharge, then she shall count for herself seven days, and after that she shall be clean.

**15:29** "'And on the eighth day she shall take for herself two turtledoves, or two young pigeons, and bring them unto the priest, to the door of the tent of meeting.

**15:30** "'And the priest shall offer the one for a sin offering, and the other for a burnt offering; and the priest shall make atonement for her before YHWH for the discharge of her uncleanness.

---

**15:31** "'Thus shall you separate the children of Israel from their uncleanness, that they not die in their uncleanness, when they defile my tabernacle that is in their midst—בְּטַמְּאָם אֶת־מִשְׁכָּנִי אֲשֶׁר בְּתוֹכָם (be-tamm'am et-mishkani asher be-tocham).'"

**15:32** This is the law of him who has a discharge, and of him whose seed goes from him, so that he is unclean thereby;

**15:33** And of her who is sick with her impurity, and of him who has a discharge, of the man and of the woman, and of him who lies with her who is unclean.

---

## Synthesis Notes

**Key Restorations:**

**Categories of Discharge:**

The chapter addresses four types:

1. **Male abnormal discharge** (*zav*, verses 2-15): Likely gonorrhea or similar pathological discharge; creates severe uncleanness; requires seven days plus offerings after cessation

2. **Male seminal emission** (verses 16-18): Normal bodily function; creates minor uncleanness; resolved by evening with washing

3. **Female menstruation** (*niddah*, verses 19-24): Regular monthly cycle; seven days of uncleanness; no offering required for normal menstruation

4. **Female abnormal bleeding** (*zavah*, verses 25-30): Irregular or prolonged bleeding; like the *zav*, requires seven days plus offerings after cessation

**Degrees of Uncleanness:**

Normal functions (semen, menstruation):
- Unclean until evening
- Washing required
- No offerings needed

Abnormal discharges (*zav*, *zavah*):
- Prolonged uncleanness (duration of discharge plus seven days)
- Offerings required (sin offering + burnt offering)
- Living water required for bathing

**Transmission of Uncleanness:**
- Direct touch of the person
- Contact with bed, seat, or saddle
- Spit from the *zav*
- Touch without rinsed hands
- Sexual contact

Impurity spreads through contact. The affected person contaminates surfaces; surfaces contaminate others.

**Earthen Vessels:**
As with the sin offering (6:28), earthen vessels that contact the unclean must be broken. They absorb impurity and cannot be cleansed.

**Living Water (מַיִם חַיִּים):**
For the *zav* and *zavah*, bathing must be in "living water"—flowing water from a spring or stream, not stagnant. The water that moves carries away impurity.

**The Eighth Day:**
Both *zav* and *zavah* bring offerings on the eighth day after the seven-day count. The pattern is consistent: seven days of transition, eighth day for new beginning.

**The Purpose (15:31):**
"That they not die in their uncleanness, when they defile my tabernacle." The stakes are high. Uncleanness that contacts the sanctuary brings death. The separation protects the community.

**No Moral Judgment:**
Normal bodily functions (seminal emission, menstruation) cause uncleanness without sin. The offerings for abnormal discharges are not for moral guilt but for ritual restoration. The body itself generates impurity that must be addressed.

**Archetypal Layer:** Bodily discharges involve the **boundary between inside and outside**. What flows from within crosses the threshold of the body. In the Levitical system, these crossings require attention—washing, waiting, sometimes offering.

The tabernacle in the midst of Israel is like the body's center—it must be protected from contamination. Bodily impurity and sanctuary purity are connected.

**Psychological Reading:** The system acknowledges that bodies produce substances that require attention. Rather than ignoring or being disgusted, the law names these realities and provides structured response. The process is not shameful but procedural.

**Ethical Inversion Applied:**
- Normal bodily functions are not sin—but they require attention
- Men and women are treated symmetrically (parallel laws for discharge)
- Abnormal conditions require more extensive purification
- The sanctuary's holiness is the concern—protection of the sacred center
- Living water (flowing, not stagnant) purifies

**Difficult Elements:**
The laws have been used to marginalize women (menstrual exclusion extended beyond the text's requirements). The text itself is procedural, not condemnatory. The impurity is temporary and remediable.

**Modern Equivalent:** Bodies produce what they produce. Mature systems acknowledge biological realities without shame. The distinction between normal (minor impurity, quickly resolved) and abnormal (extended process, medical attention) remains relevant. And the protection of sacred spaces from contamination applies wherever holiness is cultivated.

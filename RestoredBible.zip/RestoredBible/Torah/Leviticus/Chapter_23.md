# Leviticus Chapter 23: The Appointed Festivals

*From the Hebrew: מוֹעֲדֵי יהוה (Mo'adei YHWH) — The Appointed Times*

---

**23:1** And YHWH spoke unto Moses, saying:

**23:2** "Speak unto the children of Israel, and say unto them: 'The appointed times of YHWH—מוֹעֲדֵי יהוה (mo'adei YHWH)—which you shall proclaim as holy convocations—מִקְרָאֵי קֹדֶשׁ (miqra'ei qodesh)—these are my appointed times.

---

**23:3** "'Six days shall work be done; but on the seventh day is a sabbath of solemn rest, a holy convocation; you shall do no manner of work; it is a sabbath unto YHWH in all your dwellings.

---

**23:4** "'These are the appointed times of YHWH, holy convocations, which you shall proclaim in their appointed season.

**23:5** "'In the first month, on the fourteenth day of the month between the evenings, is YHWH's Passover—פֶּסַח לַיהוה (Pesach la-YHWH).

**23:6** "'And on the fifteenth day of the same month is the Feast of Unleavened Bread—חַג הַמַּצּוֹת (Chag HaMatzot)—unto YHWH; seven days you shall eat unleavened bread.

**23:7** "'On the first day you shall have a holy convocation; you shall do no laborious work.

**23:8** "'But you shall offer a fire offering unto YHWH seven days; on the seventh day is a holy convocation; you shall do no laborious work.'"

---

**23:9** And YHWH spoke unto Moses, saying:

**23:10** "Speak unto the children of Israel, and say unto them: 'When you come into the land which I give unto you, and reap its harvest, then you shall bring the sheaf of the firstfruits of your harvest—עֹמֶר רֵאשִׁית קְצִירְכֶם (omer reshit qetsirchem)—unto the priest.

**23:11** "'And he shall wave the sheaf before YHWH, to be accepted for you; on the morrow after the sabbath the priest shall wave it.

**23:12** "'And on the day when you wave the sheaf, you shall offer a male lamb without blemish, a year old, for a burnt offering unto YHWH.

**23:13** "'And its grain offering shall be two tenth measures of fine flour mixed with oil, a fire offering unto YHWH for a pleasing aroma; and its drink offering shall be of wine, a fourth of a hin.

**23:14** "'And you shall eat no bread, nor parched grain, nor fresh ears, until this same day, until you have brought the offering of your Consciousness; it is a statute forever throughout your generations in all your dwellings.

---

**23:15** "'And you shall count for yourselves from the morrow after the sabbath, from the day that you brought the sheaf of the wave offering; seven complete sabbaths shall there be;

**23:16** "'Until the morrow after the seventh sabbath shall you count fifty days—חֲמִשִּׁים יוֹם (chamishim yom); and you shall offer a new grain offering unto YHWH.

**23:17** "'You shall bring out of your dwellings two loaves of bread for a wave offering, made of two tenth measures; they shall be of fine flour, baked with leaven—חָמֵץ (chamets)—as firstfruits unto YHWH.

**23:18** "'And you shall present with the bread seven lambs without blemish, a year old, and one young bull, and two rams; they shall be a burnt offering unto YHWH, with their grain offering and their drink offerings, a fire offering of a pleasing aroma unto YHWH.

**23:19** "'And you shall offer one male goat for a sin offering, and two male lambs a year old for a sacrifice of peace offerings.

**23:20** "'And the priest shall wave them with the bread of the firstfruits for a wave offering before YHWH, with the two lambs; they shall be holy to YHWH for the priest.

**23:21** "'And you shall proclaim on this same day that it is a holy convocation unto you; you shall do no laborious work; it is a statute forever in all your dwellings throughout your generations.

**23:22** "'And when you reap the harvest of your land, you shall not wholly reap the corner of your field, neither shall you gather the gleaning of your harvest; you shall leave them for the poor and for the stranger: I am YHWH your Consciousness.'"

---

**23:23** And YHWH spoke unto Moses, saying:

**23:24** "Speak unto the children of Israel, saying: 'In the seventh month, on the first day of the month, shall be a solemn rest unto you, a memorial of blowing—זִכְרוֹן תְּרוּעָה (zichron teru'ah)—a holy convocation.

**23:25** "'You shall do no laborious work; and you shall offer a fire offering unto YHWH.'"

---

**23:26** And YHWH spoke unto Moses, saying:

**23:27** "Howbeit on the tenth day of this seventh month is the Day of Atonement—יוֹם הַכִּפֻּרִים (Yom HaKippurim); it shall be a holy convocation unto you, and you shall afflict your souls; and you shall offer a fire offering unto YHWH.

**23:28** "And you shall do no manner of work on this same day; for it is a day of atonement, to make atonement for you before YHWH your Consciousness.

**23:29** "For whatever soul it be who shall not be afflicted on this same day, he shall be cut off from his people.

**23:30** "And whatever soul it be who does any manner of work on this same day, that soul will I destroy from among his people.

**23:31** "You shall do no manner of work; it is a statute forever throughout your generations in all your dwellings.

**23:32** "It shall be unto you a sabbath of solemn rest, and you shall afflict your souls; on the ninth day of the month at evening, from evening unto evening, shall you keep your sabbath."

---

**23:33** And YHWH spoke unto Moses, saying:

**23:34** "Speak unto the children of Israel, saying: 'On the fifteenth day of this seventh month is the Feast of Booths—חַג הַסֻּכּוֹת (Chag HaSukkot)—for seven days unto YHWH.

**23:35** "'On the first day shall be a holy convocation; you shall do no laborious work.

**23:36** "'Seven days you shall offer fire offerings unto YHWH; on the eighth day shall be a holy convocation unto you, and you shall offer a fire offering unto YHWH; it is a solemn assembly—עֲצֶרֶת (atseret); you shall do no laborious work.

**23:37** "'These are the appointed times of YHWH, which you shall proclaim as holy convocations, to offer fire offerings unto YHWH, burnt offering and grain offering, sacrifice and drink offerings, each on its own day;

**23:38** "'Besides the sabbaths of YHWH, and besides your gifts, and besides all your vows, and besides all your freewill offerings, which you give unto YHWH.

**23:39** "'Howbeit on the fifteenth day of the seventh month, when you have gathered in the fruits of the land, you shall keep the feast of YHWH seven days; on the first day shall be a solemn rest, and on the eighth day shall be a solemn rest.

**23:40** "'And you shall take on the first day the fruit of goodly trees—פְּרִי עֵץ הָדָר (peri ets hadar)—branches of palm trees, and boughs of thick trees, and willows of the brook; and you shall rejoice before YHWH your Consciousness seven days.

**23:41** "'And you shall keep it a feast unto YHWH seven days in the year; it is a statute forever throughout your generations; in the seventh month you shall keep it.

**23:42** "'In booths you shall dwell seven days; all who are native-born in Israel shall dwell in booths—בַּסֻּכֹּת (ba-sukkot);

**23:43** "'That your generations may know that I made the children of Israel dwell in booths, when I brought them out of the land of Egypt: I am YHWH your Consciousness.'"

**23:44** And Moses declared unto the children of Israel the appointed times of YHWH.

---

## Synthesis Notes

**Key Restorations:**

**The Appointed Times (מוֹעֲדִים, mo'adim):**
The festivals are YHWH's appointed times—not merely Israel's celebrations but cosmic appointments. The word *mo'ed* suggests meeting, rendezvous. These are scheduled encounters between YHWH and Israel.

**The Weekly Sabbath (23:3):**
Listed first among the appointed times. The sabbath is foundational—the pattern for all other festivals.

**The Spring Festivals:**

1. **Passover** (*Pesach*, 14 Nisan): The lamb slaughtered "between the evenings" (late afternoon)

2. **Unleavened Bread** (*Chag HaMatzot*, 15-21 Nisan): Seven days without leaven; first and seventh days are holy convocations

3. **Firstfruits** (*Omer*, "morrow after the sabbath"): The first sheaf of barley harvest is waved; no eating new grain until this offering

4. **Weeks/Pentecost** (*Shavuot*, 50 days after Firstfruits): Two leavened loaves waved; harvest celebration; later associated with giving of Torah at Sinai

**Leaven at Shavuot:**
Uniquely, the Shavuot loaves are leavened (*chamets*). This is the only time leaven appears on the altar. The harvest thanksgiving includes the normal bread of daily life.

**Gleaning Reminder (23:22):**
The harvest festival includes the command to leave corners and gleanings for the poor. Celebration includes provision for the vulnerable.

**The Fall Festivals:**

5. **Trumpets** (*Zichron Teru'ah* / later *Rosh Hashanah*, 1 Tishrei): Memorial of blowing; rest; fire offerings. The shofar sounds; a new year begins.

6. **Day of Atonement** (*Yom Kippur*, 10 Tishrei): Afflict souls (fast); complete rest; atonement made. Failure to afflict = cut off; working = destroyed.

7. **Booths/Tabernacles** (*Sukkot*, 15-22 Tishrei): Seven days in booths; the four species (citron, palm, myrtle, willow); eighth day assembly (*atseret*)

**"From Evening to Evening":**
Yom Kippur begins on the ninth at evening and continues through the tenth—"from evening to evening." This defines the Jewish day: evening to evening, not midnight to midnight.

**The Four Species (23:40):**
- *Peri ets hadar*: "Fruit of goodly/beautiful trees"—traditionally citron (*etrog*)
- Palm branches (*lulav*)
- Boughs of thick trees—traditionally myrtle (*hadas*)
- Willows of the brook (*aravot*)

These are waved before YHWH. The ritual continues in Jewish practice.

**Dwelling in Booths:**
Israel lives in temporary structures (*sukkot*) for seven days, remembering the wilderness wandering. The booth is deliberately impermanent—open to the sky, fragile. It recalls dependence on YHWH during the wilderness years.

**The Eighth Day (שְׁמִינִי עֲצֶרֶת, Shemini Atseret):**
A solemn assembly concluding Sukkot. Later tradition made it a separate festival. "Atseret" suggests a closing gathering, a culmination.

**Archetypal Layer:** The festivals mark **sacred time**—the rhythm of the year structured by divine appointment. Spring festivals celebrate liberation and first harvest; fall festivals celebrate final harvest, atonement, and wilderness memory.

The sukkah (booth) is **deliberate vulnerability**—leaving permanent structures to dwell in temporary ones. The practice teaches dependence and remembrance.

**Psychological Reading:** The festival calendar creates collective memory. Each year Israel re-enacts exodus (Passover), harvest thanksgiving (Shavuot, Sukkot), and atonement (Yom Kippur). The calendar shapes identity through repetition.

**Ethical Inversion Applied:**
- The festivals are YHWH's, not merely Israel's—divine initiative in sacred time
- Leaven appears at Shavuot—the ordinary bread of life is acceptable
- Gleaning is commanded during harvest festivals—celebration includes the poor
- Dwelling in booths teaches dependence—impermanence is instructive
- The eighth day completes—seven + one = new beginning

**Modern Equivalent:** Communities need calendrical rhythm—times of celebration, times of solemnity, times of remembrance. The pattern of work and rest (sabbath), of harvest and thanksgiving, of atonement and renewal, structures meaningful life. And the sukkah principle—deliberately experiencing vulnerability—remains spiritually valuable.

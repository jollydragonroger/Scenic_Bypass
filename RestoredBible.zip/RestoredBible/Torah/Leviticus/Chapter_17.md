# Leviticus Chapter 17: The Sanctity of Blood

*From the Hebrew: דָּם (Dam) — Blood Is Life*

---

**17:1** And YHWH spoke unto Moses, saying:

**17:2** "Speak unto Aaron, and unto his sons, and unto all the children of Israel, and say unto them: 'This is the thing which YHWH has commanded, saying:

**17:3** "'Whatever man of the house of Israel kills an ox, or lamb, or goat, in the camp, or who kills it outside the camp,

**17:4** "'And has not brought it unto the door of the tent of meeting, to present it as an offering unto YHWH before the tabernacle of YHWH, blood shall be imputed unto that man—דָּם יֵחָשֵׁב לָאִישׁ הַהוּא (dam yechashev la-ish ha-hu); he has shed blood; and that man shall be cut off from among his people.

**17:5** "'To the end that the children of Israel may bring their sacrifices, which they sacrifice in the open field, and bring them unto YHWH, unto the door of the tent of meeting, unto the priest, and sacrifice them for peace offerings unto YHWH.

**17:6** "'And the priest shall throw the blood against the altar of YHWH at the door of the tent of meeting, and burn the fat for a pleasing aroma unto YHWH.

**17:7** "'And they shall no more sacrifice their sacrifices unto the goat-demons—לַשְּׂעִירִם (la-se'irim)—after which they go astray. This shall be a statute forever unto them throughout their generations.'

---

**17:8** "And you shall say unto them: 'Whatever man of the house of Israel, or of the strangers who sojourn among them, who offers a burnt offering or sacrifice,

**17:9** "'And does not bring it unto the door of the tent of meeting, to offer it unto YHWH, that man shall be cut off from his people.

**17:10** "'And whatever man of the house of Israel, or of the strangers who sojourn among them, who eats any blood, I will set my face against that soul who eats blood, and will cut him off from among his people.

**17:11** "'For the life of the flesh is in the blood—כִּי נֶפֶשׁ הַבָּשָׂר בַּדָּם הִוא (ki nefesh ha-basar ba-dam hi)—and I have given it to you upon the altar to make atonement for your souls; for it is the blood that makes atonement by reason of the life—כִּי־הַדָּם הוּא בַּנֶּפֶשׁ יְכַפֵּר (ki-ha-dam hu ba-nefesh yechapper).

**17:12** "'Therefore I said unto the children of Israel: No soul of you shall eat blood, neither shall any stranger who sojourns among you eat blood.

**17:13** "'And whatever man of the children of Israel, or of the strangers who sojourn among them, who hunts and catches any beast or bird that may be eaten, he shall pour out its blood, and cover it with dust.

**17:14** "'For as to the life of all flesh, its blood is its life—כִּי־נֶפֶשׁ כָּל־בָּשָׂר דָּמוֹ בְנַפְשׁוֹ הוּא (ki-nefesh kol-basar damo ve-nafsho hu); therefore I said unto the children of Israel: You shall not eat the blood of any flesh; for the life of all flesh is its blood; whoever eats it shall be cut off.

**17:15** "'And every soul who eats that which dies of itself, or that which is torn by beasts, whether he is native-born or a stranger, he shall wash his clothes, and bathe himself in water, and be unclean until the evening; then shall he be clean.

**17:16** "'But if he does not wash them, nor bathe his flesh, then he shall bear his iniquity.'"

---

## Synthesis Notes

**Key Restorations:**

**Centralization of Sacrifice:**
All slaughter of domestic animals (ox, lamb, goat) must be brought to the tent of meeting. Private slaughter, even for food, is forbidden during the wilderness period. The blood must be handled at the altar.

This changes in Deuteronomy 12:15-16, where secular slaughter away from the central sanctuary is permitted—but even then, the blood must be poured out.

**"Blood Shall Be Imputed":**
Private slaughter is treated as bloodshed—as if murder. The animal's blood, not properly offered, counts against the person. The blood-handling requirement is absolute.

**The Goat-Demons (שְׂעִירִם, se'irim):**
Literally "hairy ones"—goat-demons, satyrs, or wilderness spirits. Israel had been sacrificing to these in the open field. The centralization requirement eliminates this practice. All sacrifice must be to YHWH, at YHWH's altar.

**Blood Prohibition:**

The absolute prohibition:
- No Israelite may eat blood
- No stranger among them may eat blood
- Violation: YHWH sets his face against that person; cut off from the people

**The Theological Rationale (17:11):**

The central verse of Levitical theology:
- "The life (*nefesh*) of the flesh is in the blood"
- "I have given it to you upon the altar to make atonement for your souls"
- "It is the blood that makes atonement by reason of the life"

Blood = life. Life belongs to YHWH. Blood is given for atonement—life for life. Eating blood is consuming what belongs to YHWH alone.

**Hunted Game:**
Wild animals (not domestic) can be eaten, but the blood must be poured out and covered with dust. The blood returns to the earth, covered, not consumed.

**Animals Found Dead:**
Those who eat an animal that died naturally or was killed by predators become unclean. Washing and waiting until evening cleanses. But if they fail to wash, they "bear their iniquity."

**Archetypal Layer:** Blood is the **life-force**. It is YHWH's portion, never human food. The altar receives the blood; humans receive the flesh. The separation is absolute. Consuming blood is consuming life that belongs to the divine.

The prohibition of the *se'irim* (goat-demons) shows that Israel's tendency was toward distributed worship—sacrificing to local spirits. Centralization consolidates worship at the one altar of the one God.

**Psychological Reading:** The blood prohibition creates a visceral boundary. Every meal involving meat requires attention to the blood. The practice of pouring out and covering the blood of hunted game ritualizes respect for the life taken.

**Ethical Inversion Applied:**
- Blood is life—consuming it is consuming what belongs to YHWH
- Centralization ends private sacrifice and worship of lesser spirits
- The stranger is included in the prohibition—not just ethnic Israel
- Hunting is permitted, but blood must be handled respectfully
- Atonement works through blood—life given for life

**Modern Equivalent:** The blood prohibition underlies kosher slaughter (*shechitah*)—the animal must be killed in a way that drains the blood. The principle extends: some things are not for human consumption; some belong to the transcendent order. And centralization of worship, while having practical difficulties, addresses the fragmentation of devotion.

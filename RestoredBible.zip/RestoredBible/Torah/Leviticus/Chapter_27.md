# Leviticus Chapter 27: Vows and Dedications

*From the Hebrew: נֶדֶר (Neder) — The Vow*

---

**27:1** And YHWH spoke unto Moses, saying:

**27:2** "Speak unto the children of Israel, and say unto them: 'When a man makes a special vow—כִּי יַפְלִא נֶדֶר (ki yafli neder)—of persons unto YHWH, by your valuation,

**27:3** "'Then your valuation shall be: for a male from twenty years old up to sixty years old, your valuation shall be fifty shekels of silver, after the shekel of the sanctuary.

**27:4** "'And if it is a female, then your valuation shall be thirty shekels.

**27:5** "'And if it is from five years old up to twenty years old, then your valuation shall be: for a male, twenty shekels, and for a female, ten shekels.

**27:6** "'And if it is from a month old up to five years old, then your valuation shall be: for a male, five shekels of silver, and for a female, your valuation shall be three shekels of silver.

**27:7** "'And if it is from sixty years old and upward, if it is a male, then your valuation shall be fifteen shekels, and for a female, ten shekels.

**27:8** "'But if he is poorer than your valuation, then he shall be set before the priest, and the priest shall value him; according to what the one who vowed can afford, the priest shall value him.

---

**27:9** "'And if it is a beast, of which men bring an offering unto YHWH, all that any man gives of such unto YHWH shall be holy.

**27:10** "'He shall not alter it, nor change it, a good for a bad, or a bad for a good; and if he shall at all change beast for beast, then both it and that for which it is changed shall be holy.

**27:11** "'And if it is any unclean beast, of which they do not offer an offering unto YHWH, then he shall set the beast before the priest;

**27:12** "'And the priest shall value it, whether it is good or bad; as you the priest values it, so shall it be.

**27:13** "'But if he will indeed redeem it, then he shall add the fifth part of it unto your valuation.

---

**27:14** "'And when a man sanctifies his house to be holy unto YHWH, then the priest shall value it, whether it is good or bad; as the priest values it, so shall it stand.

**27:15** "'And if he who sanctified it will redeem his house, then he shall add the fifth part of the money of your valuation unto it, and it shall be his.

**27:16** "'And if a man sanctifies unto YHWH part of the field of his possession, then your valuation shall be according to the seed required for it; a homer of barley seed at fifty shekels of silver.

**27:17** "'If he sanctifies his field from the year of jubilee, according to your valuation it shall stand.

**27:18** "'But if he sanctifies his field after the jubilee, then the priest shall reckon unto him the money according to the years that remain unto the year of jubilee; and an abatement shall be made from your valuation.

**27:19** "'And if he who sanctified the field will indeed redeem it, then he shall add the fifth part of the money of your valuation unto it, and it shall be his.

**27:20** "'And if he will not redeem the field, or if he has sold the field to another man, it shall not be redeemed any more.

**27:21** "'But the field, when it goes out in the jubilee, shall be holy unto YHWH, as a field devoted; it shall be the possession of the priest.

**27:22** "'And if he sanctifies unto YHWH a field which he has bought, which is not of the field of his possession,

**27:23** "'Then the priest shall reckon unto him the amount of your valuation unto the year of jubilee; and he shall give your valuation on that day, as a holy thing unto YHWH.

**27:24** "'In the year of jubilee the field shall return unto him from whom it was bought, to him to whom the possession of the land belongs.

**27:25** "'And all your valuations shall be according to the shekel of the sanctuary—שֶׁקֶל הַקֹּדֶשׁ (sheqel ha-qodesh); twenty gerahs shall be the shekel.

---

**27:26** "'Howbeit the firstborn among beasts, which is made a firstborn unto YHWH, no man shall sanctify it; whether it is an ox or sheep, it is YHWH's.

**27:27** "'And if it is of an unclean beast, then he shall ransom it according to your valuation, and shall add the fifth part of it; or if it is not redeemed, then it shall be sold according to your valuation.

**27:28** "'Notwithstanding, no devoted thing—חֵרֶם (cherem)—that a man devotes unto YHWH of all that he has, whether of man, or beast, or of the field of his possession, shall be sold or redeemed; every devoted thing is most holy unto YHWH.

**27:29** "'No one devoted—כָּל־חֵרֶם (kol-cherem)—who is devoted from among men, shall be ransomed; he shall surely be put to death.

**27:30** "'And all the tithe of the land, whether of the seed of the land, or of the fruit of the tree, is YHWH's; it is holy unto YHWH.

**27:31** "'And if a man will redeem any of his tithe, he shall add the fifth part of it.

**27:32** "'And all the tithe of the herd or the flock, whatever passes under the rod, the tenth shall be holy unto YHWH.

**27:33** "'He shall not search whether it is good or bad, neither shall he change it; and if he changes it at all, then both it and that for which it is changed shall be holy; it shall not be redeemed.'"

**27:34** These are the commandments which YHWH commanded Moses for the children of Israel on Mount Sinai.

---

## Synthesis Notes

**Key Restorations:**

**Vows of Persons:**
A person could be "vowed" to YHWH—dedicated to sanctuary service. Since not everyone could actually serve, a monetary equivalent was established:

| Age | Male | Female |
|-----|------|--------|
| 1 month - 5 years | 5 shekels | 3 shekels |
| 5-20 years | 20 shekels | 10 shekels |
| 20-60 years | 50 shekels | 30 shekels |
| 60+ years | 15 shekels | 10 shekels |

The valuations reflect ancient economic assessments of labor capacity, not inherent human worth.

**Provision for the Poor:**
"If he is poorer than your valuation"—the priest adjusts according to what the person can afford. No one is excluded from vow-making by poverty.

**Dedicated Animals:**
Animals vowed to YHWH become holy and cannot be exchanged. If someone tries to substitute, both animals become holy. Clean animals are sacrificed; unclean animals are valued and may be redeemed (plus 20%).

**Dedicated Houses and Fields:**
Houses and ancestral fields can be sanctified to YHWH. The owner may redeem by paying valuation plus 20%. Field valuation is based on seed capacity and years until jubilee. At jubilee, unredeemed fields become sanctuary property.

**Purchased Fields:**
Fields purchased (not ancestral) can be dedicated, but at jubilee they return to the original family—the purchaser's dedication does not permanently alienate ancestral land.

**The Shekel of the Sanctuary:**
All valuations use the sanctuary standard: 20 gerahs = 1 shekel. This ensures consistent measurement.

**Firstborn Cannot Be Vowed:**
The firstborn already belongs to YHWH (Exodus 13:2). You cannot vow what is already YHWH's. Unclean firstborn (donkeys) are redeemed or sold.

**Cherem (חֵרֶם) — The Devoted Thing:**
*Cherem* is the most severe form of dedication—irrevocable, unredeemable. What is *cherem* is completely given over:
- Cannot be sold
- Cannot be redeemed
- Persons under *cherem* are put to death

This applies in warfare (total destruction of enemy cities) and in extreme religious violations. The *cherem* is "most holy unto YHWH."

**The Tithe:**
One-tenth of produce and livestock belongs to YHWH:
- Seed of the land
- Fruit of the tree
- Every tenth animal passing under the rod

The tithe may be redeemed (plus 20% for produce). Animals cannot be exchanged; if substituted, both become holy.

**The Closing (27:34):**
"These are the commandments which YHWH commanded Moses for the children of Israel on Mount Sinai." The book ends where it began—at Sinai, with Moses receiving and transmitting YHWH's words.

**Archetypal Layer:** The chapter addresses **the economics of the sacred**. Vows create obligation; the sanctuary system provides mechanisms for fulfilling or redeeming them. The *cherem* represents the **absolute dedication**—what is given cannot be taken back.

**Psychological Reading:** Vows externalize commitment. The system allows for human inconstancy (redemption with 20% penalty) while maintaining the seriousness of dedication. The escalating categories (ordinary vow → sanctification → *cherem*) represent degrees of commitment.

**Ethical Inversion Applied:**
- Valuations reflect economic capacity, not human worth
- The poor are accommodated—reduced valuations based on means
- Substitution is penalized—commitment means commitment
- The tithe is YHWH's—not a gift but an acknowledgment of ownership
- *Cherem* is irrevocable—some dedications cannot be undone

**Modern Equivalent:** Pledges to religious and charitable causes continue. The principle of adjusting expectations to capacity (the poor person's reduced valuation) anticipates progressive giving structures. And the 20% redemption fee acknowledges that changing course has a cost—commitment is not costless.

---

## Book Summary: Leviticus

Leviticus addresses how Israel lives with the holy God dwelling in their midst. The book moves through:

1. **Offerings** (1-7): The five types of sacrifice and how they work
2. **Priesthood** (8-10): Ordination of Aaron and sons; the tragedy of Nadab and Abihu
3. **Purity** (11-15): Clean/unclean animals, bodily conditions, their treatment
4. **Day of Atonement** (16): The annual cleansing of sanctuary and people
5. **Holiness Code** (17-26): Blood prohibition, sexual ethics, social justice, festivals, blessings and curses
6. **Vows and Dedications** (27): The economics of sacred commitment

The book's central concern: how does a holy God dwell among an unholy people? The answer: through sacrifice, priesthood, purity, and ethical holiness. "You shall be holy, for I YHWH your God am holy" (19:2) is the programmatic statement.

The offerings provide means of approach; the priests mediate; the purity system maintains boundaries; the Day of Atonement annually resets; the ethical demands shape community life. Together these enable YHWH to "walk among you" (26:12) without the people being destroyed.

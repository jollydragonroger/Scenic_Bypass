# Leviticus Chapter 5: Special Cases and the Guilt Offering

*From the Hebrew: אָשָׁם (Asham) — Guilt/Reparation Offering*

---

**5:1** "And if a soul sins in that he hears the voice of adjuration—קוֹל אָלָה (qol alah)—and he is a witness, whether he has seen or known, if he does not tell it, then he shall bear his iniquity.

**5:2** "Or if a soul touches any unclean thing, whether it is the carcass of an unclean beast, or the carcass of unclean cattle, or the carcass of unclean swarming things, and it is hidden from him, and he becomes unclean, then he shall be guilty.

**5:3** "Or if he touches the uncleanness of man, whatever his uncleanness may be with which he becomes unclean, and it is hidden from him, and then he comes to know it, then he shall be guilty.

**5:4** "Or if a soul swears, speaking rashly with his lips to do evil or to do good, whatever it may be that a man speaks rashly with an oath, and it is hidden from him, and then he comes to know it, then he shall be guilty in one of these things.

**5:5** "And it shall be, when he is guilty in one of these things, that he shall confess—וְהִתְוַדָּה (ve-hitvaddah)—that he has sinned in that thing.

**5:6** "And he shall bring his guilt offering—אֲשָׁמוֹ (ashamo)—unto YHWH for his sin which he has sinned, a female from the flock, a lamb or a goat, for a sin offering; and the priest shall make atonement for him concerning his sin.

---

**5:7** "And if his means do not suffice for a lamb, then he shall bring for his guilt, for that which he has sinned, two turtledoves or two young pigeons unto YHWH: one for a sin offering and one for a burnt offering.

**5:8** "And he shall bring them unto the priest, who shall offer the one for the sin offering first, and wring off its head at the back of its neck, but shall not divide it.

**5:9** "And he shall sprinkle of the blood of the sin offering upon the side of the altar; and the rest of the blood shall be drained out at the base of the altar; it is a sin offering.

**5:10** "And the second he shall offer for a burnt offering, according to the ordinance; and the priest shall make atonement for him concerning his sin which he has sinned, and he shall be forgiven.

**5:11** "But if his means do not suffice for two turtledoves or two young pigeons, then he shall bring for his offering for that which he has sinned the tenth part of an ephah of fine flour for a sin offering; he shall put no oil upon it, neither shall he put any frankincense upon it; for it is a sin offering.

**5:12** "And he shall bring it to the priest, and the priest shall take his handful of it as the memorial portion, and burn it upon the altar, upon the fire offerings of YHWH; it is a sin offering.

**5:13** "And the priest shall make atonement for him concerning his sin that he has sinned in any one of these things, and he shall be forgiven; and the remainder shall be the priest's, as the grain offering."

---

**5:14** And YHWH spoke unto Moses, saying:

**5:15** "If a soul commits a trespass—מַעַל (ma'al)—and sins unintentionally in the holy things of YHWH, then he shall bring his guilt offering unto YHWH, a ram without blemish from the flock, according to your valuation in silver by shekels, after the shekel of the sanctuary, for a guilt offering.

**5:16** "And he shall make restitution for that which he has done amiss in the holy thing, and shall add the fifth part to it, and give it unto the priest; and the priest shall make atonement for him with the ram of the guilt offering, and he shall be forgiven.

**5:17** "And if a soul sins, and does any of the things which YHWH has commanded not to be done, though he did not know it, yet he is guilty, and shall bear his iniquity.

**5:18** "And he shall bring a ram without blemish from the flock, according to your valuation, for a guilt offering, unto the priest; and the priest shall make atonement for him concerning the error which he committed, though he did not know it, and he shall be forgiven.

**5:19** "It is a guilt offering; he is certainly guilty before YHWH."

---

## Synthesis Notes

**Key Restorations:**

**Four Special Cases (5:1-4):**

Specific situations requiring the *chattat*:

1. **Failure to testify** (verse 1): Hearing a public adjuration (*qol alah*—a call for witnesses to come forward) and failing to speak. Silence when testimony is required is sin.

2. **Touching uncleanness unknowingly** (verses 2-3): Contact with carcasses (animal or human uncleanness) that one didn't notice. When awareness comes, guilt is recognized.

3. **Rash oaths** (verse 4): Swearing thoughtlessly to do something (good or evil) and then realizing one cannot or should not fulfill it.

**The Requirement of Confession:**
*Ve-hitvaddah* (וְהִתְוַדָּה)—"he shall confess." This is the first explicit requirement of verbal confession in the sacrificial system. The offerer must acknowledge the specific sin. Ritual without recognition is insufficient.

**Graduated Offering for the Poor:**

Three tiers of affordability:
1. **Standard**: female lamb or goat
2. **Reduced**: two birds (one for sin offering, one for burnt offering)
3. **Minimal**: tenth of an ephah of flour (no oil, no frankincense)

The poorest person can still bring a sin offering. Economics does not bar access to forgiveness. The flour offering for sin has no oil or frankincense—this is penitential, not celebratory.

**The Guilt Offering (אָשָׁם, Asham):**

Beginning in verse 14, a distinct offering is introduced:
- Specifically for *ma'al* (מַעַל)—trespass, misappropriation, breach of trust
- Concerns "holy things of YHWH"—things dedicated to the sanctuary
- Requires a ram without blemish
- Requires monetary valuation
- Requires restitution plus 20% (*chomesh*, the fifth part)

The *asham* addresses property violations, especially sacred property. It combines sacrifice with compensation.

**"The Fifth Part":**
Restitution is not merely equal replacement but 120% of the value. The extra 20% is compensation for the deprivation suffered. Justice includes surplus.

**Guilt Without Knowledge:**
"Though he did not know it, yet he is guilty" (verse 17). Ignorance does not eliminate guilt. The violation occurred; the conscience eventually registers it. The offering addresses objective guilt, not just subjective awareness.

**"He Is Certainly Guilty Before YHWH":**
*Asham asham la-YHWH* (אָשֹׁם אָשֵׁם לַיהוה)—the doubling intensifies. There is real guilt, real violation. The offering addresses something actual.

**Archetypal Layer:** This chapter recognizes **varying degrees of culpability and capacity**:
- Sin can be not knowing you witnessed (failure to testify)
- Sin can be unknowing contamination (touching uncleanness)
- Sin can be thoughtless speech (rash oaths)
- Sin can be misappropriating sacred things (trespass)

The offerings are graduated for economic reality. The guilt offering adds restitution—sin against property requires more than ritual; it requires repayment.

**Psychological Reading:** Confession (*hitvaddah*) makes the internal external. Naming the sin is part of addressing it. The graduated offerings acknowledge that people have different capacities—the poor are not excluded. And the 20% addition recognizes that wrongful deprivation deserves more than mere return.

**Ethical Inversion Applied:**
- Silence when testimony is needed is sin—the duty to speak
- Ignorance does not eliminate guilt—we are responsible for what we don't know
- Confession is required—acknowledgment precedes atonement
- Economic capacity is accommodated—flour suffices for the poorest
- Restitution plus 20%—justice includes compensation for loss

**Modern Equivalent:** Failing to testify when called is still recognized as obstruction. Ignorance of law is no excuse—but here, remedy is provided. Restitution with interest (the 20%) models reparative justice. And the accessibility of the offering (down to flour for the poorest) suggests that reconciliation should never be priced out of reach.

# Leviticus Chapter 9: The Priests Begin Their Ministry

*From the Hebrew: The Eighth Day — Glory Appears*

---

**9:1** And it came to pass on the eighth day—בַּיּוֹם הַשְּׁמִינִי (ba-yom ha-shemini)—that Moses called Aaron and his sons, and the elders of Israel.

**9:2** And he said unto Aaron: "Take for yourself a bull-calf for a sin offering, and a ram for a burnt offering, without blemish, and offer them before YHWH.

**9:3** "And unto the children of Israel you shall speak, saying: 'Take a male goat for a sin offering, and a calf and a lamb, both a year old, without blemish, for a burnt offering,

**9:4** "'And an ox and a ram for peace offerings, to sacrifice before YHWH, and a grain offering mixed with oil; for today YHWH will appear unto you—כִּי הַיּוֹם יהוה נִרְאָה אֲלֵיכֶם (ki ha-yom YHWH nir'ah aleichem).'"

**9:5** And they brought that which Moses commanded before the tent of meeting; and all the congregation drew near and stood before YHWH.

**9:6** And Moses said: "This is the thing which YHWH commanded you to do; and the glory of YHWH shall appear unto you."

**9:7** And Moses said unto Aaron: "Draw near unto the altar, and offer your sin offering and your burnt offering, and make atonement for yourself and for the people; and offer the offering of the people, and make atonement for them, as YHWH commanded."

---

**9:8** And Aaron drew near unto the altar, and slaughtered the calf of the sin offering, which was for himself.

**9:9** And the sons of Aaron presented the blood unto him; and he dipped his finger in the blood, and put it upon the horns of the altar, and poured out the blood at the base of the altar.

**9:10** And the fat, and the kidneys, and the lobe of the liver of the sin offering, he burned upon the altar, as YHWH commanded Moses.

**9:11** And the flesh and the skin he burned with fire outside the camp.

**9:12** And he slaughtered the burnt offering; and Aaron's sons delivered unto him the blood, and he threw it against the altar round about.

**9:13** And they delivered the burnt offering unto him, piece by piece, and the head; and he burned them upon the altar.

**9:14** And he washed the entrails and the legs, and burned them upon the burnt offering on the altar.

**9:15** And he presented the people's offering, and took the goat of the sin offering which was for the people, and slaughtered it, and offered it for sin, as the first.

**9:16** And he presented the burnt offering, and offered it according to the ordinance.

**9:17** And he presented the grain offering, and filled his hand from it, and burned it upon the altar, besides the burnt offering of the morning.

**9:18** And he slaughtered the ox and the ram, the sacrifice of peace offerings, which was for the people; and Aaron's sons delivered unto him the blood, and he threw it against the altar round about.

**9:19** And the fat of the ox and of the ram, the fat tail, and that which covers the entrails, and the kidneys, and the lobe of the liver—

**9:20** They put the fat upon the breasts, and he burned the fat upon the altar.

**9:21** And the breasts and the right thigh Aaron waved for a wave offering before YHWH, as Moses commanded.

**9:22** And Aaron lifted up his hands toward the people and blessed them—וַיִּשָּׂא אַהֲרֹן אֶת־יָדָו אֶל־הָעָם וַיְבָרְכֵם (va-yissa Aharon et-yadav el-ha-am va-yevarechem); and he came down from offering the sin offering, and the burnt offering, and the peace offerings.

**9:23** And Moses and Aaron went into the tent of meeting, and came out, and blessed the people; and the glory of YHWH appeared unto all the people—וַיֵּרָא כְבוֹד־יהוה אֶל־כָּל־הָעָם (va-yera chevod-YHWH el-kol-ha-am).

**9:24** And fire came forth from before YHWH—וַתֵּצֵא אֵשׁ מִלִּפְנֵי יהוה (va-tetse esh mi-lifnei YHWH)—and consumed upon the altar the burnt offering and the fat; and when all the people saw it, they shouted—וַיָּרֹנּוּ (va-yaronnu)—and fell on their faces.

---

## Synthesis Notes

**Key Restorations:**

**The Eighth Day:**
After seven days of ordination (chapter 8), the eighth day begins the new reality. Seven = completion; eight = new beginning. The priests are now ready to function.

**The Promise:**
"Today YHWH will appear unto you." The sacrifices are offered with the expectation of theophany. This is not routine worship but inaugural revelation.

**Aaron's First Offerings:**

For himself:
- Bull-calf for sin offering
- Ram for burnt offering

For the people:
- Male goat for sin offering
- Calf and lamb for burnt offering
- Ox and ram for peace offerings
- Grain offering with oil

Aaron must first atone for himself before he can represent the people.

**Aaron Officiates:**
For the first time, Aaron (not Moses) officiates at the altar. He slaughters, applies blood, burns fat. His sons assist. The priesthood is functioning.

**The Sequence:**
1. Aaron's sin offering (purification)
2. Aaron's burnt offering (dedication)
3. People's sin offering (purification)
4. People's burnt offering (dedication)
5. Grain offering (tribute)
6. Peace offerings (fellowship)

The order moves from personal purification to communal celebration.

**Aaron Blesses:**
"Aaron lifted up his hands toward the people and blessed them." This is the first priestly blessing—the lifted hands, the words of blessing. The blessing in Numbers 6:24-26 ("YHWH bless you and keep you...") may be what Aaron spoke.

**Moses and Aaron Enter:**
They go into the tent of meeting together—a unique moment. Moses is transferring authority. They emerge and bless the people together.

**The Glory Appears:**
*Va-yera chevod-YHWH* (וַיֵּרָא כְבוֹד־יהוה)—the glory of YHWH appeared to all the people. This is the visible manifestation of divine presence—what was promised is now seen.

**Fire from Before YHWH:**
*Va-tetse esh mi-lifnei YHWH* (וַתֵּצֵא אֵשׁ מִלִּפְנֵי יהוה)—fire came out from YHWH's presence and consumed the burnt offering and fat on the altar. Divine fire ignites the sacrifice. YHWH accepts the offering with fire.

This fire will become the perpetual fire (6:13). The altar fire originates from YHWH, not from human ignition.

**The People's Response:**
They shouted (*va-yaronnu*)—a cry of joy, acclamation, praise. And they fell on their faces—prostration before the holy. Joy and awe together.

**Archetypal Layer:** The eighth day is **new creation**—the old seven days complete, the new era begins. The fire from YHWH is **divine acceptance**—the sacrifice is consumed by heaven's fire, not merely human flame. The glory appearing is the **theophany that validates**—the system works; YHWH responds.

**Psychological Reading:** The people witness their offerings accepted. The abstract covenant becomes concrete—fire descends. The response is both joy (shouting) and terror (falling prostrate). The numinous produces this double response: fascination and fear.

**Ethical Inversion Applied:**
- Aaron atones for himself before the people—leaders need cleansing too
- Moses transfers authority—succession is public and witnessed
- Divine fire accepts the offering—YHWH responds, not merely receives
- Shouting and falling prostrate—joy and reverence together
- The eighth day begins new reality—seven days prepare, the eighth inaugurates

**Modern Equivalent:** Leadership transitions should be public and ceremonial. Those who lead worship must first address their own need for grace. And genuine encounter with the holy produces both joy and awe—not one without the other.

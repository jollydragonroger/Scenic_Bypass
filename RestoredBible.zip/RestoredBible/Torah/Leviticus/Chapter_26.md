# Leviticus Chapter 26: Blessings and Curses

*From the Hebrew: בְּחֻקֹּתַי (Bechukotai) — In My Statutes*

---

**26:1** "You shall make no idols—אֱלִילִם (elilim)—nor shall you set up a graven image or a pillar, nor shall you place any figured stone in your land, to bow down unto it; for I am YHWH your Consciousness.

**26:2** "You shall keep my sabbaths, and reverence my sanctuary: I am YHWH.

---

**26:3** "If you walk in my statutes, and keep my commandments, and do them,

**26:4** "Then I will give your rains in their season, and the land shall yield its produce, and the trees of the field shall yield their fruit.

**26:5** "And your threshing shall reach unto the vintage, and the vintage shall reach unto the sowing time; and you shall eat your bread to the full, and dwell in your land safely.

**26:6** "And I will give peace in the land, and you shall lie down, and none shall make you afraid; and I will cause evil beasts to cease from the land, and the sword shall not go through your land.

**26:7** "And you shall chase your enemies, and they shall fall before you by the sword.

**26:8** "And five of you shall chase a hundred, and a hundred of you shall chase ten thousand; and your enemies shall fall before you by the sword.

**26:9** "And I will turn unto you, and make you fruitful, and multiply you, and will establish my covenant with you.

**26:10** "And you shall eat old store long kept, and you shall bring forth the old because of the new.

**26:11** "And I will set my tabernacle among you—וְנָתַתִּי מִשְׁכָּנִי בְּתוֹכְכֶם (ve-natati mishkani be-tochechem)—and my soul shall not abhor you.

**26:12** "And I will walk among you, and will be your Consciousness, and you shall be my people—וְהִתְהַלַּכְתִּי בְּתוֹכְכֶם (ve-hithallachti be-tochechem).

**26:13** "I am YHWH your Consciousness, who brought you out of the land of Egypt, that you should not be their slaves; and I broke the bars of your yoke, and made you walk upright—וָאוֹלֵךְ אֶתְכֶם קוֹמְמִיּוּת (va-olech etchem qomemiyyut)."

---

**26:14** "But if you will not listen unto me, and will not do all these commandments,

**26:15** "And if you shall reject my statutes, and if your soul abhors my ordinances, so that you will not do all my commandments, but break my covenant,

**26:16** "Then I also will do this unto you: I will appoint terror over you—בֶּהָלָה (behalah)—consumption, and fever, that shall consume the eyes, and cause sorrow of heart; and you shall sow your seed in vain, for your enemies shall eat it.

**26:17** "And I will set my face against you, and you shall be smitten before your enemies; they who hate you shall rule over you; and you shall flee when none pursues you.

**26:18** "And if you will not yet for these things listen unto me, then I will chastise you seven times more for your sins.

**26:19** "And I will break the pride of your power; and I will make your heaven as iron, and your earth as bronze.

**26:20** "And your strength shall be spent in vain; for your land shall not yield its produce, neither shall the trees of the land yield their fruit.

**26:21** "And if you walk contrary unto me—קֶרִי (qeri)—and will not listen unto me, I will bring seven times more plagues upon you according to your sins.

**26:22** "And I will send the beast of the field among you, which shall rob you of your children, and destroy your cattle, and make you few in number; and your ways shall become desolate.

**26:23** "And if by these things you will not be corrected unto me, but will walk contrary unto me,

**26:24** "Then will I also walk contrary unto you—וְהָלַכְתִּי אַף־אֲנִי עִמָּכֶם בְּקֶרִי (ve-halachti af-ani immachem be-qeri); and I will smite you, even I, seven times for your sins.

**26:25** "And I will bring a sword upon you, that shall execute the vengeance of the covenant; and you shall be gathered together within your cities; and I will send the pestilence among you; and you shall be delivered into the hand of the enemy.

**26:26** "When I break your staff of bread, ten women shall bake your bread in one oven, and they shall deliver your bread again by weight; and you shall eat, and not be satisfied.

**26:27** "And if you will not for all this listen unto me, but walk contrary unto me,

**26:28** "Then I will walk contrary unto you in fury; and I also will chastise you seven times for your sins.

**26:29** "And you shall eat the flesh of your sons, and the flesh of your daughters shall you eat.

**26:30** "And I will destroy your high places, and cut down your sun-pillars, and cast your carcasses upon the carcasses of your idols; and my soul shall abhor you.

**26:31** "And I will make your cities a waste, and will bring your sanctuaries unto desolation, and I will not smell the savor of your pleasing aromas.

**26:32** "And I will bring the land into desolation; and your enemies who dwell in it shall be astonished at it.

**26:33** "And you will I scatter among the nations—וְאֶתְכֶם אֱזָרֶה בַגּוֹיִם (ve-etchem ezareh va-goyim)—and I will draw out the sword after you; and your land shall be a desolation, and your cities shall be a waste.

**26:34** "Then shall the land enjoy its sabbaths, as long as it lies desolate, and you are in your enemies' land; even then shall the land rest, and enjoy its sabbaths.

**26:35** "As long as it lies desolate it shall have rest, the rest which it did not have in your sabbaths, when you dwelt upon it.

**26:36** "And as for those of you who are left, I will send a faintness into their heart in the lands of their enemies; and the sound of a driven leaf shall chase them; and they shall flee, as one flees from the sword; and they shall fall when none pursues.

**26:37** "And they shall stumble one upon another, as if before the sword, when none pursues; and you shall have no power to stand before your enemies.

**26:38** "And you shall perish among the nations, and the land of your enemies shall eat you up.

**26:39** "And those of you who are left shall pine away in their iniquity in your enemies' lands; and also in the iniquities of their fathers shall they pine away with them.

---

**26:40** "And they shall confess their iniquity, and the iniquity of their fathers, in their trespass which they trespassed against me, and also that they walked contrary unto me,

**26:41** "So that I also walked contrary unto them, and brought them into the land of their enemies; if then their uncircumcised heart is humbled—וְאָז יִכָּנַע לְבָבָם הֶעָרֵל (ve-az yikkane levavam he-arel)—and they then accept the punishment of their iniquity,

**26:42** "Then will I remember my covenant with Jacob—וְזָכַרְתִּי אֶת־בְּרִיתִי יַעֲקוֹב (ve-zacharti et-beriti Ya'aqov)—and also my covenant with Isaac, and also my covenant with Abraham will I remember; and I will remember the land.

**26:43** "And the land shall be forsaken by them, and shall enjoy its sabbaths, while it lies desolate without them; and they shall accept the punishment of their iniquity, because they rejected my ordinances, and their soul abhorred my statutes.

**26:44** "And yet for all that, when they are in the land of their enemies, I will not reject them, neither will I abhor them, to destroy them utterly, and to break my covenant with them; for I am YHWH their Consciousness.

**26:45** "But I will for their sakes remember the covenant of their ancestors, whom I brought out of the land of Egypt in the sight of the nations, that I might be their Consciousness: I am YHWH."

**26:46** These are the statutes and ordinances and laws which YHWH made between him and the children of Israel on Mount Sinai by the hand of Moses.

---

## Synthesis Notes

**Key Restorations:**

**The Covenant Pattern:**
The chapter follows ancient treaty structure:
- Stipulations (keep statutes, sabbaths, sanctuary)
- Blessings for obedience
- Curses for disobedience
- Provision for restoration

**The Blessings (26:3-13):**

If Israel obeys:
- Rain in season
- Abundant harvests
- Peace and security
- Victory over enemies
- Fruitfulness and multiplication
- YHWH dwelling among them
- Walking upright (*qomemiyyut*)

The climax: "I will walk among you, and will be your Consciousness, and you shall be my people." This is covenant relationship at its fullest.

**"Walk Upright" (קוֹמְמִיּוּת):**
*Qomemiyyut*—with heads held high, in dignity. YHWH broke the yoke of Egyptian slavery; Israel now walks upright, not bowed.

**The Curses (26:14-39):**

Escalating in five stages, each worse if Israel does not repent:

1. **Terror, disease, defeat** (16-17)
2. **Drought, failed harvests** (18-20)—"seven times more"
3. **Wild beasts, decimation** (21-22)—"seven times more"
4. **Sword, pestilence, siege** (23-26)—"seven times more"
5. **Cannibalism, exile, desolation** (27-39)—"seven times more"

**"Walking Contrary" (קֶרִי, qeri):**
A key word, appearing seven times. It suggests hostility, opposition, randomness. If Israel walks contrary (*qeri*) to YHWH, YHWH will walk contrary to them.

**The Land's Sabbaths:**
The land will get its sabbatical rest one way or another. If Israel does not observe sabbatical years while living there, the land will rest during Israel's exile. The land's rights are inviolable.

**"Uncircumcised Heart":**
*Levavam he-arel* (לְבָבָם הֶעָרֵל)—the heart that has not been opened, the stubborn interior. Physical circumcision is insufficient; the heart must be circumcised (Deuteronomy 10:16, 30:6; Jeremiah 4:4).

**The Promise of Restoration:**
Even in exile, if they confess, if their heart is humbled, if they accept their punishment:
- YHWH will remember the covenant (Jacob, Isaac, Abraham—reverse order)
- YHWH will remember the land
- YHWH will not reject them utterly

"I will not reject them, neither will I abhor them, to destroy them utterly." The covenant is unbreakable. Discipline is severe but not final.

**The Patriarchal Covenants:**
"My covenant with Jacob... Isaac... Abraham"—the ancestral promises remain the foundation. Even when the Sinai covenant is violated, the earlier promises endure.

**Archetypal Layer:** The blessings and curses represent **cosmic order responding to moral choice**. Obedience aligns with the grain of creation; disobedience disrupts it. The escalating curses are not vindictive but **corrective**—each stage offers opportunity for repentance before the next.

The land having its sabbaths is **ecological justice**—the created order will be respected, either through obedience or through exile.

**Psychological Reading:** The curses describe the progressive disintegration that follows covenant-breaking: first internal anxiety, then external threat, then social collapse, then exile. The stages mirror the unraveling of a society that has lost its moral center.

**Ethical Inversion Applied:**
- Blessings are natural consequences of alignment with YHWH
- Curses are corrective, not merely punitive—each stage allows response
- The land has rights—sabbatical rest will occur one way or another
- The uncircumcised heart is the real problem—external compliance is insufficient
- The covenant is unbreakable—even exile does not end the relationship

**Modern Equivalent:** Societies that violate ecological and social boundaries experience consequences—failed harvests, conflict, displacement. The pattern of escalating consequences with opportunities for correction applies to environmental and social systems. And the promise of restoration—that even severe discipline is not ultimate rejection—offers hope within judgment.

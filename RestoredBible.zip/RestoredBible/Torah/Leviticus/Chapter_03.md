# Leviticus Chapter 3: The Peace Offering

*From the Hebrew: זֶבַח שְׁלָמִים (Zevach Shelamim) — Sacrifice of Well-Being*

---

**3:1** "And if his offering is a sacrifice of peace offerings—זֶבַח שְׁלָמִים (zevach shelamim)—if he offers it of the herd, whether male or female, he shall offer it without blemish before YHWH.

**3:2** "And he shall lay his hand upon the head of his offering, and slaughter it at the door of the tent of meeting; and Aaron's sons the priests shall throw the blood against the altar round about.

**3:3** "And he shall present of the sacrifice of peace offerings a fire offering unto YHWH: the fat that covers the entrails, and all the fat that is upon the entrails,

**3:4** "And the two kidneys, and the fat that is upon them, which is upon the loins, and the lobe of the liver, which he shall remove with the kidneys.

**3:5** "And Aaron's sons shall burn it on the altar upon the burnt offering, which is upon the wood that is on the fire; it is a fire offering of a pleasing aroma unto YHWH.

---

**3:6** "And if his offering for a sacrifice of peace offerings unto YHWH is of the flock, male or female, he shall offer it without blemish.

**3:7** "If he offers a lamb for his offering, then he shall offer it before YHWH.

**3:8** "And he shall lay his hand upon the head of his offering, and slaughter it before the tent of meeting; and Aaron's sons shall throw its blood against the altar round about.

**3:9** "And he shall present of the sacrifice of peace offerings a fire offering unto YHWH: its fat, the entire fat tail cut off close to the backbone, and the fat that covers the entrails, and all the fat that is upon the entrails,

**3:10** "And the two kidneys, and the fat that is upon them, which is upon the loins, and the lobe of the liver, which he shall remove with the kidneys.

**3:11** "And the priest shall burn it upon the altar; it is the food of the fire offering—לֶחֶם אִשֶּׁה (lechem isheh)—unto YHWH.

---

**3:12** "And if his offering is a goat, then he shall offer it before YHWH.

**3:13** "And he shall lay his hand upon its head, and slaughter it before the tent of meeting; and the sons of Aaron shall throw its blood against the altar round about.

**3:14** "And he shall present of it his offering, a fire offering unto YHWH: the fat that covers the entrails, and all the fat that is upon the entrails,

**3:15** "And the two kidneys, and the fat that is upon them, which is upon the loins, and the lobe of the liver, which he shall remove with the kidneys.

**3:16** "And the priest shall burn them upon the altar; it is the food of the fire offering for a pleasing aroma. All the fat is YHWH's—כָּל־חֵלֶב לַיהוה (kol-chelev la-YHWH).

**3:17** "It shall be a perpetual statute throughout your generations in all your dwellings: you shall eat neither fat nor blood—כָּל־חֵלֶב וְכָל־דָּם לֹא תֹאכֵלוּ (kol-chelev ve-chol-dam lo tochelu)."

---

## Synthesis Notes

**Key Restorations:**

**Zevach Shelamim (זֶבַח שְׁלָמִים):**
From *shalom* (שָׁלוֹם)—peace, wholeness, well-being. This is the offering of communion, fellowship, reconciliation. Unlike the burnt offering (entirely burned) or sin offering (partially eaten by priests), the peace offering is shared: YHWH receives the fat; priests receive portions; the offerer and family eat the rest.

**Male or Female:**
Unlike the burnt offering (male only), peace offerings can be male or female. The requirement is "without blemish"—wholeness matters more than gender.

**The Fat Belongs to YHWH:**
The fat (*chelev*, חֵלֶב) is always burned for YHWH:
- Fat covering the entrails
- Fat on the kidneys
- Lobe of the liver
- Fat tail (for sheep)

Fat was considered the richest, best part. It goes to YHWH. The principle: the best belongs to God.

**The Fat Tail:**
Sheep in the ancient Near East were fat-tailed breeds. The entire tail, "cut off close to the backbone," is offered. This could weigh several pounds—a significant portion.

**"The Food of the Fire Offering" (לֶחֶם אִשֶּׁה):**
*Lechem isheh*—literally "bread of the fire offering." Anthropomorphic language: the burning fat is "food" for YHWH. This doesn't mean YHWH literally eats, but the metaphor emphasizes the offering as gift, as meal.

**Blood on the Altar:**
The blood is thrown against the altar—not merely dripped or poured but actively cast around all sides. Blood represents life; the life is offered back to the Life-giver.

**The Communion Meal:**
What is not burned (most of the animal) is eaten. Leviticus 7 will specify: the breast goes to all priests (wave offering); the right thigh to the officiating priest; the rest to the offerer and family.

This is a **shared meal**—YHWH, priests, and worshippers all participate. The peace offering creates fellowship through eating together.

**Perpetual Prohibition:**
"You shall eat neither fat nor blood"—this applies in all dwellings, throughout all generations. The fat belongs to YHWH; the blood belongs to YHWH. Humans may eat the flesh but not these.

**Archetypal Layer:** The peace offering is the **communion meal**—shared food creating fellowship. The fat rising as smoke represents what goes to heaven; the flesh eaten below represents earthly fellowship. The meal bridges heaven and earth, divine and human.

**Psychological Reading:** Eating together creates community. The peace offering is not solitary but relational—family and guests join. The joy of relationship with YHWH is expressed through shared food. Worship is not grim duty but festive meal.

**Ethical Inversion Applied:**
- The best (fat) goes to YHWH—generosity means giving the best, not the leftovers
- Male or female—less restrictive than burnt offering; wellness is widely accessible
- Shared eating creates community—worship is social, not individualistic
- Fat and blood are permanently prohibited—certain things always belong to YHWH

**Modern Equivalent:** The peace offering models communal celebration. The best is given to God; the rest is shared with community. Genuine worship includes festivity, not only solemnity. And some things are always reserved—not everything is for human consumption.

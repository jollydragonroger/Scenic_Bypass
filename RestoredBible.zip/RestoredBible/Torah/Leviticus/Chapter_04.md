# Leviticus Chapter 4: The Sin Offering

*From the Hebrew: חַטָּאת (Chattat) — Purification Offering*

---

**4:1** And YHWH spoke unto Moses, saying:

**4:2** "Speak unto the children of Israel, saying: 'When a soul sins unintentionally—כִּי־תֶחֱטָא בִשְׁגָגָה (ki-techeta vi-shgagah)—against any of the commandments of YHWH concerning things that ought not to be done, and does any one of them:

---

**4:3** "'If the anointed priest—הַכֹּהֵן הַמָּשִׁיחַ (ha-kohen ha-mashiach)—sins so as to bring guilt upon the people, then he shall offer for his sin which he has sinned a young bull without blemish unto YHWH for a sin offering.

**4:4** "'And he shall bring the bull unto the door of the tent of meeting before YHWH; and he shall lay his hand upon the head of the bull, and slaughter the bull before YHWH.

**4:5** "'And the anointed priest shall take of the blood of the bull and bring it to the tent of meeting.

**4:6** "'And the priest shall dip his finger in the blood, and sprinkle of the blood seven times before YHWH, before the veil of the sanctuary.

**4:7** "'And the priest shall put some of the blood upon the horns of the altar of fragrant incense before YHWH, which is in the tent of meeting; and all the rest of the blood of the bull he shall pour out at the base of the altar of burnt offering, which is at the door of the tent of meeting.

**4:8** "'And all the fat of the bull of the sin offering he shall take off from it: the fat that covers the entrails, and all the fat that is upon the entrails,

**4:9** "'And the two kidneys, and the fat that is upon them, which is upon the loins, and the lobe of the liver, which he shall remove with the kidneys,

**4:10** "'As it is taken off from the ox of the sacrifice of peace offerings; and the priest shall burn them upon the altar of burnt offering.

**4:11** "'And the skin of the bull, and all its flesh, with its head, and with its legs, and its entrails, and its dung,

**4:12** "'Even the whole bull shall he carry outside the camp unto a clean place, where the ashes are poured out, and burn it upon wood with fire; where the ashes are poured out it shall be burned.

---

**4:13** "'And if the whole congregation of Israel sins unintentionally, and the thing is hidden from the eyes of the assembly, and they have done any of the things which YHWH has commanded not to be done, and are guilty;

**4:14** "'When the sin which they have sinned is known, then the assembly shall offer a young bull for a sin offering, and bring it before the tent of meeting.

**4:15** "'And the elders of the congregation shall lay their hands upon the head of the bull before YHWH; and the bull shall be slaughtered before YHWH.

**4:16** "'And the anointed priest shall bring of the blood of the bull to the tent of meeting.

**4:17** "'And the priest shall dip his finger in the blood, and sprinkle it seven times before YHWH, before the veil.

**4:18** "'And he shall put some of the blood upon the horns of the altar which is before YHWH, that is in the tent of meeting; and all the rest of the blood he shall pour out at the base of the altar of burnt offering, which is at the door of the tent of meeting.

**4:19** "'And all its fat he shall take off from it, and burn it upon the altar.

**4:20** "'And he shall do with the bull as he did with the bull of the sin offering; so shall he do with this; and the priest shall make atonement for them, and they shall be forgiven—וְנִסְלַח לָהֶם (ve-nislach lahem).

**4:21** "'And he shall carry the bull outside the camp, and burn it as he burned the first bull; it is the sin offering for the assembly.

---

**4:22** "'When a leader—נָשִׂיא (nasi)—sins, and does unintentionally any one of all the things which YHWH his Consciousness has commanded not to be done, and is guilty;

**4:23** "'If his sin wherein he has sinned is made known to him, he shall bring for his offering a goat, a male without blemish.

**4:24** "'And he shall lay his hand upon the head of the goat, and slaughter it in the place where they slaughter the burnt offering before YHWH; it is a sin offering.

**4:25** "'And the priest shall take of the blood of the sin offering with his finger, and put it upon the horns of the altar of burnt offering; and the rest of its blood he shall pour out at the base of the altar of burnt offering.

**4:26** "'And all its fat he shall burn upon the altar, as the fat of the sacrifice of peace offerings; and the priest shall make atonement for him concerning his sin, and he shall be forgiven.

---

**4:27** "'And if any soul of the common people—עַם הָאָרֶץ (am ha-arets)—sins unintentionally, in doing any of the things which YHWH has commanded not to be done, and is guilty;

**4:28** "'If his sin which he has sinned is made known to him, then he shall bring for his offering a goat, a female without blemish, for his sin which he has sinned.

**4:29** "'And he shall lay his hand upon the head of the sin offering, and slaughter the sin offering in the place of the burnt offering.

**4:30** "'And the priest shall take of its blood with his finger, and put it upon the horns of the altar of burnt offering; and all the rest of its blood he shall pour out at the base of the altar.

**4:31** "'And all its fat he shall remove, as the fat is removed from the sacrifice of peace offerings; and the priest shall burn it upon the altar for a pleasing aroma unto YHWH; and the priest shall make atonement for him, and he shall be forgiven.

**4:32** "'And if he brings a lamb for his offering for a sin offering, he shall bring a female without blemish.

**4:33** "'And he shall lay his hand upon the head of the sin offering, and slaughter it for a sin offering in the place where they slaughter the burnt offering.

**4:34** "'And the priest shall take of the blood of the sin offering with his finger, and put it upon the horns of the altar of burnt offering; and all the rest of its blood he shall pour out at the base of the altar.

**4:35** "'And all its fat he shall remove, as the fat of the lamb is removed from the sacrifice of peace offerings; and the priest shall burn them upon the altar, upon the fire offerings of YHWH; and the priest shall make atonement for him concerning his sin that he has sinned, and he shall be forgiven.'"

---

## Synthesis Notes

**Key Restorations:**

**Chattat (חַטָּאת):**
Often translated "sin offering," the word comes from the root חָטָא (chata), "to miss the mark." The *chattat* addresses inadvertent sin—when someone violates a commandment without intending to. It is a purification offering, cleansing the sanctuary and the offerer from the contamination of sin.

**"Unintentionally" (בִשְׁגָגָה, bi-shgagah):**
This offering is for *shgagah*—inadvertent, unintentional, mistaken acts. It does not address deliberate, high-handed rebellion (Numbers 15:30-31). The *chattat* recognizes that sin can occur without full awareness.

**The Four Categories:**

The offering varies by the offerer's status:

1. **Anointed priest** (*ha-kohen ha-mashiach*): young bull; blood sprinkled before the veil, placed on incense altar; carcass burned outside camp

2. **Whole congregation**: young bull; same procedure as priest; elders lay hands

3. **Leader** (*nasi*): male goat; blood on horns of burnt offering altar only

4. **Common person** (*am ha-arets*): female goat or lamb; same as leader

The higher the status, the more elaborate the ritual. The priest's sin "brings guilt upon the people"—leadership carries greater consequence.

**Blood Rituals:**
- For priest/congregation: blood sprinkled seven times before the veil; placed on horns of incense altar; poured at base of burnt offering altar
- For leader/commoner: blood on horns of burnt offering altar only; poured at base

The priest's sin requires blood closer to the holy of holies. Greater sin requires deeper penetration of cleansing.

**Outside the Camp:**
The priest's and congregation's bulls are burned outside the camp—skin, flesh, entrails, dung. This anticipates Hebrews 13:11-12: "Jesus also suffered outside the gate." The sin-bearing animal is expelled from the community.

**"And He Shall Be Forgiven" (וְנִסְלַח, ve-nislach):**
The refrain of the chapter. The offering effects forgiveness. *Salach* (סָלַח) is used only of divine forgiveness. When the ritual is complete, YHWH forgives. The offering works.

**"The Anointed Priest" (הַכֹּהֵן הַמָּשִׁיחַ):**
Literally "the priest, the anointed one"—the term *mashiach* (משיח), from which "Messiah" derives. The high priest is the anointed one, the mediator. His sin affects all Israel.

**Archetypal Layer:** The *chattat* addresses **contamination**—sin pollutes the sanctuary, the community, the relationship with YHWH. The blood cleanses. The burning outside the camp removes the pollution from Israel's midst.

The graduated offering (bull for priest/congregation, goat for leader, female goat/lamb for commoner) recognizes that **responsibility correlates with status**. The leader's sin is more consequential than the commoner's.

**Psychological Reading:** Unintentional sin is still sin. We cause harm without meaning to; we violate principles we didn't know we were violating. The *chattat* acknowledges this—and provides remedy. Ignorance does not absolve, but it does not condemn permanently. Forgiveness is available.

**Ethical Inversion Applied:**
- Sin can be unintentional—we are responsible for more than we intend
- Higher status = greater consequence—leadership bears more weight
- Blood cleanses—life given addresses life disrupted
- "He shall be forgiven"—the offering accomplishes restoration
- Burning outside the camp—contamination is expelled from community

**Modern Equivalent:** Leaders bear greater responsibility; their failures affect more people. Inadvertent harm still requires address—"I didn't mean to" doesn't erase consequences. And ritual (whatever form it takes) can mark the transition from guilt to forgiveness, making reconciliation concrete rather than merely conceptual.

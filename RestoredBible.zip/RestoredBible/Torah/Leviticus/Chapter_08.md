# Leviticus Chapter 8: The Ordination of Aaron and His Sons

*From the Hebrew: מִלֻּאִים (Millu'im) — The Filling of Hands*

---

**8:1** And YHWH spoke unto Moses, saying:

**8:2** "Take Aaron and his sons with him, and the garments, and the anointing oil, and the bull of the sin offering, and the two rams, and the basket of unleavened bread;

**8:3** "And assemble all the congregation at the door of the tent of meeting."

**8:4** And Moses did as YHWH commanded him; and the congregation was assembled at the door of the tent of meeting.

**8:5** And Moses said unto the congregation: "This is the thing which YHWH has commanded to be done."

**8:6** And Moses brought Aaron and his sons, and washed them with water.

**8:7** And he put upon him the tunic, and girded him with the sash, and clothed him with the robe, and put the ephod upon him, and he girded him with the skillfully woven band of the ephod, and bound it unto him with it.

**8:8** And he placed the breastpiece upon him; and in the breastpiece he put the Urim and the Thummim.

**8:9** And he set the turban upon his head; and upon the turban, in front, he set the golden plate, the holy crown—נֵזֶר הַקֹּדֶשׁ (nezer ha-qodesh)—as YHWH commanded Moses.

**8:10** And Moses took the anointing oil, and anointed the tabernacle and all that was in it, and sanctified them.

**8:11** And he sprinkled of it upon the altar seven times, and anointed the altar and all its vessels, and the basin and its stand, to sanctify them.

**8:12** And he poured of the anointing oil upon Aaron's head, and anointed him, to sanctify him.

**8:13** And Moses brought Aaron's sons, and clothed them with tunics, and girded them with sashes, and bound headbands on them, as YHWH commanded Moses.

---

**8:14** And he brought the bull of the sin offering; and Aaron and his sons laid their hands upon the head of the bull of the sin offering.

**8:15** And he slaughtered it; and Moses took the blood, and put it upon the horns of the altar round about with his finger, and purified the altar, and poured out the blood at the base of the altar, and sanctified it, to make atonement upon it.

**8:16** And he took all the fat that was upon the entrails, and the lobe of the liver, and the two kidneys, and their fat; and Moses burned it upon the altar.

**8:17** But the bull, and its skin, and its flesh, and its dung, he burned with fire outside the camp, as YHWH commanded Moses.

**8:18** And he presented the ram of the burnt offering; and Aaron and his sons laid their hands upon the head of the ram.

**8:19** And he slaughtered it; and Moses threw the blood against the altar round about.

**8:20** And he cut the ram into its pieces; and Moses burned the head, and the pieces, and the fat.

**8:21** And the entrails and the legs he washed with water; and Moses burned the whole ram upon the altar; it was a burnt offering for a pleasing aroma; it was a fire offering unto YHWH, as YHWH commanded Moses.

**8:22** And he presented the second ram, the ram of ordination—אֵיל הַמִּלֻּאִים (eil ha-millu'im); and Aaron and his sons laid their hands upon the head of the ram.

**8:23** And he slaughtered it; and Moses took of its blood, and put it upon the tip of Aaron's right ear, and upon the thumb of his right hand, and upon the great toe of his right foot.

**8:24** And he brought Aaron's sons; and Moses put of the blood upon the tip of their right ear, and upon the thumb of their right hand, and upon the great toe of their right foot; and Moses threw the blood against the altar round about.

**8:25** And he took the fat, and the fat tail, and all the fat that was upon the entrails, and the lobe of the liver, and the two kidneys, and their fat, and the right thigh.

**8:26** And out of the basket of unleavened bread that was before YHWH, he took one unleavened cake, and one cake of oiled bread, and one wafer, and placed them on the fat and upon the right thigh.

**8:27** And he put all these upon the hands of Aaron, and upon the hands of his sons, and waved them for a wave offering before YHWH.

**8:28** And Moses took them from their hands, and burned them on the altar upon the burnt offering; they were an ordination offering for a pleasing aroma; it was a fire offering unto YHWH.

**8:29** And Moses took the breast and waved it for a wave offering before YHWH; it was Moses' portion of the ram of ordination, as YHWH commanded Moses.

**8:30** And Moses took of the anointing oil, and of the blood which was upon the altar, and sprinkled it upon Aaron, upon his garments, and upon his sons, and upon his sons' garments with him; and sanctified Aaron, his garments, and his sons, and his sons' garments with him.

---

**8:31** And Moses said unto Aaron and to his sons: "Boil the flesh at the door of the tent of meeting; and there eat it and the bread that is in the basket of ordination, as I commanded, saying, 'Aaron and his sons shall eat it.'

**8:32** "And the remainder of the flesh and of the bread you shall burn with fire.

**8:33** "And you shall not go out from the door of the tent of meeting for seven days, until the days of your ordination are fulfilled; for seven days shall he ordain you—יְמַלֵּא אֶת־יֶדְכֶם (yemalle et-yedchem).

**8:34** "As has been done this day, so YHWH has commanded to do, to make atonement for you.

**8:35** "And at the door of the tent of meeting you shall dwell day and night for seven days, and keep the charge of YHWH, that you not die; for so I have been commanded."

**8:36** And Aaron and his sons did all the things which YHWH commanded by the hand of Moses.

---

## Synthesis Notes

**Key Restorations:**

**Public Ordination:**
"Assemble all the congregation at the door of the tent of meeting." The ordination is not private but witnessed by all Israel. The people see the priests being consecrated. The authority is publicly conferred.

**The Sequence of Vesting:**

Moses dresses Aaron in order:
1. **Tunic** (linen undergarment)
2. **Sash** (embroidered belt)
3. **Robe** (blue, with bells and pomegranates)
4. **Ephod** (gold-threaded outer garment)
5. **Breastpiece** (with Urim and Thummim)
6. **Turban** with **golden plate** ("Holy to YHWH")

Each layer adds authority. The garments make the priest.

**Anointing:**

Moses anoints in sequence:
1. The tabernacle and all its contents
2. The altar (sprinkled seven times)
3. The basin and stand
4. Aaron's head (oil poured, not just sprinkled)

The oil sanctifies—sets apart for sacred use. Aaron's head receives poured oil, not merely sprinkled, indicating fullness of consecration.

**The Three Offerings:**

1. **Bull of sin offering**: purifies the altar and priests; blood on altar horns; fat burned; carcass burned outside camp

2. **Ram of burnt offering**: complete dedication; entirely burned on the altar

3. **Ram of ordination** (*eil ha-millu'im*): the special ordination sacrifice; blood applied to ear, thumb, toe

**Blood on Ear, Thumb, Toe:**
The blood of the ordination ram is applied to:
- Right ear (*tenuch*): consecrating hearing
- Right thumb: consecrating work
- Right great toe: consecrating walk

The whole person—perception, action, movement—is marked for sacred service.

**"Filling the Hands" (מִלֻּאִים):**
The fat, right thigh, and cakes are placed in the hands of Aaron and his sons. This "filling of hands" is the ordination itself—they now hold priestly authority. The filled hands are waved before YHWH and then burned.

**Oil and Blood Together:**
Moses sprinkles Aaron and his sons with a mixture of anointing oil and altar blood. Both persons and garments are sanctified. The combination is unique to ordination.

**Moses' Portion:**
The breast of the ordination ram goes to Moses—he is functioning as priest during the ordination. This is his portion because he performs the priestly role.

**Seven Days:**
The ordination takes seven days. They must not leave the tent of meeting doorway for the entire period. The charge is serious: "that you not die." Incomplete ordination would be fatal.

**"As YHWH Commanded Moses":**
The refrain emphasizes complete obedience. Every step follows the divine instruction (Exodus 29).

**Archetypal Layer:** The seven-day ordination recapitulates creation. A new order emerges—the priestly order. The blood-marked body (ear, thumb, toe) represents total consecration. The "filling of hands" is the conferral of authority—empty hands become full.

**Psychological Reading:** Transformation requires time (seven days), ritual (multiple offerings), and community witness (the congregation assembled). The garments externalize internal change. The blood marks the body as the new identity takes form.

**Ethical Inversion Applied:**
- Public ordination—authority is conferred before witnesses, not secretly
- Seven days of completion—transformation is not instant
- Blood on ear, thumb, toe—the whole person is consecrated
- "That you not die"—the stakes are real; sacred service is serious
- Moses functions as priest—until the priests are ready, someone must bridge

**Modern Equivalent:** Ordination requires:
- Public recognition (community witnesses)
- Symbolic actions (vestments, anointing)
- Time (seven days of formation)
- Total commitment (not leaving the doorway)
- Consequence for failure (the seriousness of vocation)

The process transforms identity. What enters is layperson; what emerges is priest.

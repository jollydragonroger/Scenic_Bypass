# Leviticus Chapter 20: Penalties for Violations

*From the Hebrew: Consequences of Transgression*

---

**20:1** And YHWH spoke unto Moses, saying:

**20:2** "Again, you shall say to the children of Israel: 'Whoever of the children of Israel, or of the strangers who sojourn in Israel, who gives any of his offspring unto Molech, shall surely be put to death; the people of the land shall stone him with stones.

**20:3** "'And I will set my face against that man, and will cut him off from among his people; because he has given of his offspring unto Molech, to defile my sanctuary and to profane my holy name.

**20:4** "'And if the people of the land do at all hide their eyes from that man, when he gives of his offspring unto Molech, and do not put him to death,

**20:5** "'Then I will set my face against that man, and against his family, and will cut him off, and all who go astray after him, to go astray after Molech, from among their people.

**20:6** "'And the soul who turns unto mediums and unto wizards, to go astray after them, I will set my face against that soul, and will cut him off from among his people.

**20:7** "'Sanctify yourselves therefore, and be holy; for I am YHWH your Consciousness.

**20:8** "'And you shall keep my statutes, and do them: I am YHWH who sanctifies you.

---

**20:9** "'For everyone who curses his father or his mother shall surely be put to death; he has cursed his father or his mother; his blood is upon him.

**20:10** "'And the man who commits adultery with another man's wife, who commits adultery with his neighbor's wife, the adulterer and the adulteress shall surely be put to death.

**20:11** "'And the man who lies with his father's wife has uncovered his father's nakedness; both of them shall surely be put to death; their blood is upon them.

**20:12** "'And if a man lies with his daughter-in-law, both of them shall surely be put to death; they have wrought confusion—תֶּבֶל (tevel); their blood is upon them.

**20:13** "'And if a man lies with a male as with a woman, both of them have committed an abomination; they shall surely be put to death; their blood is upon them.

**20:14** "'And if a man takes a woman and her mother, it is wickedness—זִמָּה (zimmah); they shall be burned with fire, both he and they; that there be no wickedness among you.

**20:15** "'And if a man lies with a beast, he shall surely be put to death; and you shall kill the beast.

**20:16** "'And if a woman approaches any beast to lie with it, you shall kill the woman and the beast; they shall surely be put to death; their blood is upon them.

**20:17** "'And if a man takes his sister, his father's daughter or his mother's daughter, and sees her nakedness, and she sees his nakedness, it is a shameful thing—חֶסֶד (chesed, here meaning 'disgrace'); and they shall be cut off in the sight of the children of their people; he has uncovered his sister's nakedness; he shall bear his iniquity.

**20:18** "'And if a man lies with a woman having her sickness, and uncovers her nakedness, he has exposed her flow, and she has uncovered the flow of her blood; both of them shall be cut off from among their people.

**20:19** "'And you shall not uncover the nakedness of your mother's sister, nor of your father's sister; for he has made naked his near kin; they shall bear their iniquity.

**20:20** "'And if a man lies with his uncle's wife, he has uncovered his uncle's nakedness; they shall bear their sin; they shall die childless.

**20:21** "'And if a man takes his brother's wife, it is impurity—נִדָּה (niddah); he has uncovered his brother's nakedness; they shall be childless.

---

**20:22** "'You shall therefore keep all my statutes, and all my ordinances, and do them, that the land, where I am bringing you to dwell, not vomit you out.

**20:23** "'And you shall not walk in the customs of the nation which I am casting out before you; for they did all these things, and therefore I abhorred them.

**20:24** "'But I have said unto you: You shall inherit their land, and I will give it unto you to possess it, a land flowing with milk and honey. I am YHWH your Consciousness, who has separated you from the peoples.

**20:25** "'You shall therefore separate between the clean beast and the unclean, and between the unclean fowl and the clean; and you shall not make your souls abominable by beast, or by fowl, or by anything with which the ground teems, which I have separated from you as unclean.

**20:26** "'And you shall be holy unto me; for I YHWH am holy, and have separated you from the peoples, that you should be mine.

**20:27** "'And a man or a woman who is a medium or a wizard shall surely be put to death; they shall stone them with stones; their blood is upon them.'"

---

## Synthesis Notes

**Key Restorations:**

**Penalties Prescribed:**
This chapter provides the penalties for violations enumerated in chapter 18 and elsewhere. The punishments include:
- Death by stoning (Molech worship, cursing parents, adultery, male homosexual acts, bestiality, mediums)
- Death by burning (man who takes woman and her mother)
- Being "cut off" (*karet*—divine excision from the people)
- Childlessness (certain incestuous relations)

**"Their Blood Is Upon Them":**
*Demeihem bam* (דְּמֵיהֶם בָּם)—the phrase indicates that the executed bear responsibility for their own death. The community is not guilty of bloodshed; the violators brought it upon themselves.

**Molech Worship:**
Child sacrifice to Molech warrants death. If the community fails to execute the offender, YHWH will act directly—cutting off the person and family. Complicity through inaction is judged.

**Graduated Penalties:**
Not all violations receive the death penalty:
- Some: death (adultery, certain incest, Molech worship)
- Some: cut off (incest with sister, intercourse during menstruation)
- Some: childlessness (uncle's wife, brother's wife)

The severity correlates with the degree of violation.

**The Land Vomits:**
The warning from chapter 18 is repeated: the land will expel those who practice these things. The Canaanites were expelled; Israel will be too if they follow the same path.

**Separation:**
The chapter emphasizes separation (*havdil*):
- YHWH has separated Israel from the nations
- Israel must separate clean from unclean
- Holiness means being set apart

Distinction is the principle. Israel's identity depends on maintained boundaries.

**"That You Should Be Mine":**
*Li-heyot li* (לִהְיוֹת לִי)—the purpose of separation is belonging to YHWH. Israel is YHWH's special possession. The ethical requirements serve this relationship.

**Archetypal Layer:** The penalties demonstrate that **transgression has consequence**. The symbolic system is not merely descriptive but prescriptive—violation brings response. The community is responsible for enforcement; failure to act implicates the community.

The "blood upon them" language shifts responsibility to the violator. The executioners are not murderers; they are implementing divine judgment.

**Psychological Reading:** The severe penalties indicate the seriousness of the violations. The social order depends on these boundaries. The community must act, or the pollution spreads.

**Ethical Inversion Applied:**
- The penalties were contextually appropriate to ancient Israel—they are not prescriptions for all time
- The principle of consequence remains: actions have results
- Community responsibility: failure to address violation implicates everyone
- The purpose is holiness, not cruelty—"that you should be mine"
- Separation creates identity—distinction is foundational

**Difficult Elements:**
Capital punishment for cursing parents, adultery, and various sexual acts is severe by modern standards. The text reflects ancient Near Eastern legal norms. The trajectory of interpretation has generally moved toward less severe application, but the principle of consequence remains.

**Modern Equivalent:** While capital punishment for these offenses is not practiced in most contemporary societies, the underlying principles—that actions have consequences, that communities must address violations, that boundaries preserve identity—remain relevant. The question becomes: what forms do consequences appropriately take in changed contexts?

# Leviticus Chapter 18: Laws on Sexual Relations

*From the Hebrew: עֲרָיוֹת (Arayot) — Nakedness/Sexual Boundaries*

---

**18:1** And YHWH spoke unto Moses, saying:

**18:2** "Speak unto the children of Israel, and say unto them: 'I am YHWH your Consciousness.

**18:3** "'After the doings of the land of Egypt, where you dwelt, you shall not do; and after the doings of the land of Canaan, where I am bringing you, you shall not do; neither shall you walk in their statutes.

**18:4** "'My ordinances you shall do, and my statutes you shall keep, to walk in them: I am YHWH your Consciousness.

**18:5** "'And you shall keep my statutes and my ordinances, which if a man does, he shall live by them—וָחַי בָּהֶם (va-chai bahem): I am YHWH.

---

**18:6** "'None of you shall approach any who is near of kin to him, to uncover nakedness—לְגַלּוֹת עֶרְוָה (le-gallot ervah): I am YHWH.

**18:7** "'The nakedness of your father, and the nakedness of your mother, you shall not uncover; she is your mother; you shall not uncover her nakedness.

**18:8** "'The nakedness of your father's wife you shall not uncover; it is your father's nakedness.

**18:9** "'The nakedness of your sister, the daughter of your father, or the daughter of your mother, whether born at home or born abroad, their nakedness you shall not uncover.

**18:10** "'The nakedness of your son's daughter, or of your daughter's daughter, their nakedness you shall not uncover; for theirs is your own nakedness.

**18:11** "'The nakedness of your father's wife's daughter, begotten of your father, she is your sister, you shall not uncover her nakedness.

**18:12** "'You shall not uncover the nakedness of your father's sister; she is your father's near kinswoman.

**18:13** "'You shall not uncover the nakedness of your mother's sister; for she is your mother's near kinswoman.

**18:14** "'You shall not uncover the nakedness of your father's brother; you shall not approach his wife; she is your aunt.

**18:15** "'You shall not uncover the nakedness of your daughter-in-law; she is your son's wife; you shall not uncover her nakedness.

**18:16** "'You shall not uncover the nakedness of your brother's wife; it is your brother's nakedness.

**18:17** "'You shall not uncover the nakedness of a woman and her daughter; you shall not take her son's daughter, or her daughter's daughter, to uncover her nakedness; they are near kinswomen; it is wickedness—זִמָּה (zimmah).

**18:18** "'And you shall not take a woman as a rival wife to her sister, to uncover her nakedness, beside the other in her lifetime.

---

**18:19** "'And you shall not approach a woman to uncover her nakedness during her menstrual impurity—בְּנִדַּת טֻמְאָתָהּ (be-niddat tumatah).

**18:20** "'And you shall not lie carnally with your neighbor's wife, to defile yourself with her.

**18:21** "'And you shall not give any of your offspring to pass through for Molech—לְהַעֲבִיר לַמֹּלֶךְ (le-ha'avir la-Molech)—and you shall not profane the name of your Consciousness: I am YHWH.

**18:22** "'You shall not lie with a male as with a woman; it is an abomination—תּוֹעֵבָה (to'evah).

**18:23** "'And you shall not lie with any beast to defile yourself with it; neither shall any woman stand before a beast to lie with it; it is a perversion—תֶּבֶל (tevel).

---

**18:24** "'Do not defile yourselves in any of these things; for in all these the nations are defiled which I cast out from before you.

**18:25** "'And the land was defiled; therefore I visit its iniquity upon it, and the land vomits out—וַתָּקִא (va-taqi)—its inhabitants.

**18:26** "'But you shall keep my statutes and my ordinances, and shall not do any of these abominations; neither the native-born, nor the stranger who sojourns among you;

**18:27** "'For all these abominations have the men of the land done, who were before you, and the land is defiled;

**18:28** "'That the land not vomit you out also, when you defile it, as it vomited out the nation that was before you.

**18:29** "'For whoever does any of these abominations, those souls that do them shall be cut off from among their people.

**18:30** "'Therefore you shall keep my charge, that you not do any of these abominable customs, which were done before you, and that you not defile yourselves by them: I am YHWH your Consciousness.'"

---

## Synthesis Notes

**Key Restorations:**

**The Frame (18:1-5, 24-30):**
The sexual laws are framed by identity and consequence:
- "I am YHWH your Consciousness" (repeated)
- "You shall not do as Egypt did... or as Canaan does"
- "The land vomits out its inhabitants" who do these things

The prohibitions define Israel over against the surrounding nations. These are not arbitrary rules but identity markers and ecological necessities—the land itself responds to moral violation.

**"He Shall Live by Them":**
*Va-chai bahem* (וָחַי בָּהֶם)—a key phrase in Jewish tradition. The commandments are for life, not death. Later rabbis used this principle to permit breaking commandments to save life (*pikuach nefesh*).

**"Uncover Nakedness" (גַּלּוֹת עֶרְוָה):**
The euphemism for sexual relations. The phrase covers the range of forbidden sexual acts.

**The Incest Prohibitions (18:6-18):**

Forbidden relations with:
- Mother (18:7)
- Father's wife/stepmother (18:8)
- Sister (full or half) (18:9, 11)
- Granddaughter (18:10)
- Father's sister/aunt (18:12)
- Mother's sister/aunt (18:13)
- Father's brother's wife (18:14)
- Daughter-in-law (18:15)
- Brother's wife (18:16—exception in Deuteronomy 25:5 for levirate marriage)
- Woman and her daughter or granddaughter (18:17)
- Two sisters simultaneously (18:18)

The list establishes the boundaries of the kinship group within which sexual relations are forbidden.

**Molech (מֹלֶךְ):**
The prohibition against child sacrifice appears in the middle of sexual prohibitions. "Passing through for Molech" refers to the practice of offering children to this deity, possibly by fire. The placement suggests the violation of the parent-child bond is comparable to sexual violation of family bonds.

**To'evah (תּוֹעֵבָה):**
Often translated "abomination"—a strong term of revulsion. Used for various prohibited practices (not only sexual). The term indicates something that crosses a fundamental boundary.

**The Land Vomits:**
*Va-taqi ha-arets* (וַתָּקִא הָאָרֶץ)—the land itself expels those who practice these things. This is ecological language: the land is a moral entity that responds to human behavior. The Canaanites were expelled because of these practices; Israel will suffer the same if they follow suit.

**Archetypal Layer:** The sexual prohibitions define the **boundaries of kinship and relation**. The family structure is protected from the confusion of sexual violation. Incest collapses the distinctions that make family possible.

The "land vomiting" represents the **ecological consequence of moral failure**. The symbolic system extends beyond human society to include the earth itself.

**Psychological Reading:** Sexual boundaries preserve the structure of identity. "Your father's nakedness" is not merely the father's body but his realm, his honor, his place in the family system. Violation of sexual boundaries destabilizes the entire relational network.

**Ethical Inversion Applied:**
- Identity is defined against surrounding practices—distinctiveness matters
- The laws are "for life"—not arbitrary burdens but life-giving structures
- The land is a moral participant—ecology responds to ethics
- The stranger is included—these are not ethnic exclusions but universal boundaries
- Cut off = separation from the community—the consequence of violation

**Difficult Elements:**
Leviticus 18:22 has been the subject of extensive debate. The text prohibits male-male sexual intercourse, calling it *to'evah*. Various interpretive approaches:
- Traditional: the prohibition is absolute
- Contextual: the prohibition addresses specific ancient practices (cultic, exploitative)
- The hermeneutical question: how do ancient purity laws apply in changed contexts?

The ethical inversion key does not resolve this tension but notes that the moral center is always "the agent who regains free will" and that application requires wrestling with both text and context.

**Modern Equivalent:** Sexual ethics continue to navigate kinship boundaries. The incest prohibitions remain almost universally accepted. The ecological language ("the land vomits") anticipates modern awareness that human behavior affects the environment. And the framework—"I am YHWH your Consciousness"—roots ethics in relationship with the transcendent.

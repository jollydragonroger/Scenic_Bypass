# Leviticus Chapter 11: Clean and Unclean Animals

*From the Hebrew: טָהוֹר וְטָמֵא (Tahor ve-Tame) — Pure and Impure*

---

**11:1** And YHWH spoke unto Moses and to Aaron, saying unto them:

**11:2** "Speak unto the children of Israel, saying: 'These are the living things which you may eat among all the beasts that are on the earth.

**11:3** "'Whatever parts the hoof and is cloven-footed and chews the cud—מַעֲלַת גֵּרָה (ma'alat gerah)—among the beasts, that you may eat.

**11:4** "'Nevertheless these you shall not eat of those that chew the cud or of those that part the hoof: the camel, because it chews the cud but does not part the hoof, is unclean unto you;

**11:5** "'And the rock badger, because it chews the cud but does not part the hoof, is unclean unto you;

**11:6** "'And the hare, because it chews the cud but does not part the hoof, is unclean unto you;

**11:7** "'And the pig—הַחֲזִיר (ha-chazir)—because it parts the hoof and is cloven-footed, but does not chew the cud, is unclean unto you.

**11:8** "'Of their flesh you shall not eat, and their carcasses you shall not touch; they are unclean unto you.

---

**11:9** "'These you may eat, of all that are in the waters: whatever has fins and scales in the waters, in the seas and in the rivers, those you may eat.

**11:10** "'And all that do not have fins and scales in the seas and in the rivers, of all that swarm in the waters, and of all the living creatures that are in the waters, they are an abomination—שֶׁקֶץ (sheqets)—unto you.

**11:11** "'They shall be an abomination unto you; of their flesh you shall not eat, and their carcasses you shall have in abomination.

**11:12** "'Whatever in the waters does not have fins and scales is an abomination unto you.

---

**11:13** "'And these you shall have in abomination among the birds; they shall not be eaten, they are an abomination: the eagle, and the bearded vulture, and the black vulture,

**11:14** "'And the kite, and the falcon after its kind,

**11:15** "'Every raven after its kind,

**11:16** "'And the ostrich, and the nighthawk, and the sea gull, and the hawk after its kind,

**11:17** "'And the little owl, and the cormorant, and the great owl,

**11:18** "'And the white owl, and the pelican, and the carrion vulture,

**11:19** "'And the stork, the heron after its kind, and the hoopoe, and the bat.

**11:20** "'All winged swarming things that go upon all fours are an abomination unto you.

**11:21** "'Yet these you may eat of all winged swarming things that go upon all fours: those which have jointed legs above their feet, with which to leap upon the earth.

**11:22** "'Of these you may eat: the locust after its kind, and the bald locust after its kind, and the cricket after its kind, and the grasshopper after its kind.

**11:23** "'But all other winged swarming things which have four feet are an abomination unto you.

---

**11:24** "'And by these you shall become unclean; whoever touches the carcass of them shall be unclean until the evening.

**11:25** "'And whoever carries any of their carcass shall wash his clothes, and be unclean until the evening.

**11:26** "'Every beast which parts the hoof but is not cloven-footed nor chews the cud is unclean unto you; everyone who touches it shall be unclean.

**11:27** "'And whatever goes upon its paws, among all beasts that go on all fours, are unclean unto you; whoever touches their carcass shall be unclean until the evening.

**11:28** "'And he who carries their carcass shall wash his clothes, and be unclean until the evening; they are unclean unto you.

---

**11:29** "'And these are unclean unto you among the swarming things that swarm upon the earth: the weasel, and the mouse, and the great lizard after its kind,

**11:30** "'And the gecko, and the land crocodile, and the lizard, and the sand lizard, and the chameleon.

**11:31** "'These are unclean unto you among all that swarm; whoever touches them when they are dead shall be unclean until the evening.

**11:32** "'And upon whatever any of them falls when they are dead, it shall be unclean; whether it is any vessel of wood, or garment, or skin, or sack, whatever vessel it may be, with which any work is done, it must be put into water, and it shall be unclean until the evening; then it shall be clean.

**11:33** "'And every earthen vessel into which any of them falls, whatever is in it shall be unclean, and you shall break the vessel.

**11:34** "'Any food which may be eaten, upon which water comes, shall be unclean; and all drink that may be drunk in every such vessel shall be unclean.

**11:35** "'And everything upon which any part of their carcass falls shall be unclean; whether oven or stove, it shall be broken in pieces; they are unclean, and shall be unclean unto you.

**11:36** "'Nevertheless a spring or a cistern in which water is collected shall be clean; but he who touches their carcass shall be unclean.

**11:37** "'And if any part of their carcass falls upon any sowing seed which is to be sown, it is clean.

**11:38** "'But if water is put upon the seed, and any part of their carcass falls upon it, it is unclean unto you.

---

**11:39** "'And if any beast of which you may eat dies, he who touches its carcass shall be unclean until the evening.

**11:40** "'And he who eats of its carcass shall wash his clothes, and be unclean until the evening; he also who carries its carcass shall wash his clothes, and be unclean until the evening.

**11:41** "'And every swarming thing that swarms upon the earth is an abomination; it shall not be eaten.

**11:42** "'Whatever goes on its belly, and whatever goes on all fours, or whatever has many feet, all swarming things that swarm upon the earth—you shall not eat them, for they are an abomination.

**11:43** "'You shall not make yourselves abominable—אַל־תְּשַׁקְּצוּ (al-teshaqqetsu)—with any swarming thing that swarms, and you shall not make yourselves unclean with them, that you should be defiled by them.

**11:44** "'For I am YHWH your Consciousness; you shall sanctify yourselves, and you shall be holy—וִהְיִיתֶם קְדֹשִׁים (vi-heyitem qedoshim)—for I am holy; and you shall not defile yourselves with any swarming thing that moves upon the earth.

**11:45** "'For I am YHWH who brought you up out of the land of Egypt, to be your Consciousness; you shall therefore be holy, for I am holy.'"

**11:46** This is the law of the beast, and of the bird, and of every living creature that moves in the waters, and of every creature that swarms upon the earth;

**11:47** To make a distinction between the unclean and the clean—לְהַבְדִּיל בֵּין הַטָּמֵא וּבֵין הַטָּהֹר (le-havdil bein ha-tame u-vein ha-tahor)—and between the living thing that may be eaten and the living thing that may not be eaten.

---

## Synthesis Notes

**Key Restorations:**

**The Two Criteria for Land Animals:**
1. **Parts the hoof and is cloven-footed** (split hoof)
2. **Chews the cud** (*ma'alat gerah*—ruminant digestion)

Both criteria must be met. This permits cattle, sheep, goats, deer. It excludes:
- Camel (chews cud, no split hoof)
- Rock badger/hyrax (appears to chew cud, no split hoof)
- Hare (appears to chew cud, no split hoof)
- Pig (split hoof, doesn't chew cud)

**The Pig (חֲזִיר, chazir):**
The pig becomes the archetypal unclean animal in Jewish consciousness—it appears kosher (cloven hoof) but lacks the internal criterion (cud-chewing). It represents hypocrisy: outward conformity, inward deficiency.

**Water Creatures:**
The criteria: **fins and scales**. This permits most fish but excludes shellfish, eels, catfish, sharks, all crustaceans and mollusks. Creatures that lack fins and scales are *sheqets*—abomination.

**Birds:**
No positive criteria given; only a list of prohibited birds. The pattern: predators, carrion-eaters, and certain waterbirds are excluded. Birds of prey are unclean.

**Insects:**
Most are unclean, but certain locusts with jointed legs for leaping are permitted. Locusts, crickets, grasshoppers—these are kosher. All other "swarming things" are forbidden.

**Transmission of Uncleanness:**
- Touching a carcass = unclean until evening
- Carrying a carcass = wash clothes, unclean until evening
- Carcass falls into vessel = vessel unclean (earthenware must be broken)
- Dry seed remains clean; wet seed becomes unclean

Uncleanness is contagious, transmitted by contact. Water and evening end most uncleanness.

**The Theological Foundation (11:44-45):**

The laws culminate in the great declaration:
- "I am YHWH your Consciousness"
- "You shall be holy, for I am holy"
- "I am YHWH who brought you up out of the land of Egypt"

Holiness is the reason. Israel is set apart; what Israel eats marks that separation. Diet is identity. The exodus is the basis—liberation creates obligation.

**"To Make a Distinction" (לְהַבְדִּיל, le-havdil):**
The verb *havdil* means to separate, distinguish, divide. The dietary laws train Israel in discernment—learning to distinguish categories, to see differences, to choose carefully. What begins with food extends to all of life.

**Archetypal Layer:** The dietary laws create a **symbolic system** where eating is a form of moral and spiritual practice. The categories (clean/unclean, permitted/forbidden) structure reality. Israel learns holiness through daily decisions about food.

The animals that "mix categories" (pig with hoof but no cud; creatures without fins or scales in water) represent **boundary confusion**. Clean animals fit their category fully.

**Psychological Reading:** Diet is intimate—what enters the body shapes identity. The laws make every meal a reminder of covenant. By controlling intake, Israel practices discernment. The physical discipline supports spiritual formation.

**Ethical Inversion Applied:**
- Holiness is the reason—not arbitrary rules but identity formation
- The exodus is the ground—liberation creates obligation to distinctiveness
- Discernment (*havdil*) is the skill—distinguishing categories
- The pig is false appearance—outward conformity, inward deficiency
- Daily practice shapes identity—diet as spiritual discipline

**Modern Equivalent:** What we consume shapes who we are—physically, spiritually, ethically. The discipline of discernment (what to accept, what to reject) extends beyond food to media, relationships, ideas. The system trains the capacity to distinguish.

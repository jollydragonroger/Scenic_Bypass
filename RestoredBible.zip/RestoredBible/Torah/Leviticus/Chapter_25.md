# Leviticus Chapter 25: The Sabbatical Year and Jubilee

*From the Hebrew: בְּהַר (Behar) — On the Mountain*

---

**25:1** And YHWH spoke unto Moses on Mount Sinai, saying:

**25:2** "Speak unto the children of Israel, and say unto them: 'When you come into the land which I give you, then shall the land keep a sabbath unto YHWH—וְשָׁבְתָה הָאָרֶץ שַׁבָּת לַיהוה (ve-shavetah ha-arets shabbat la-YHWH).

**25:3** "'Six years you shall sow your field, and six years you shall prune your vineyard, and gather in its produce.

**25:4** "'But in the seventh year shall be a sabbath of solemn rest for the land, a sabbath unto YHWH; you shall neither sow your field, nor prune your vineyard.

**25:5** "'That which grows of itself of your harvest you shall not reap, and the grapes of your undressed vine you shall not gather; it shall be a year of solemn rest for the land.

**25:6** "'And the sabbath of the land shall be for food for you: for you, and for your servant, and for your maid, and for your hired servant, and for the stranger who sojourns with you;

**25:7** "'And for your cattle, and for the beasts that are in your land, shall all the increase thereof be for food.

---

**25:8** "'And you shall count seven sabbaths of years unto you, seven times seven years; and the space of the seven sabbaths of years shall be unto you forty and nine years.

**25:9** "'Then you shall send abroad the loud trumpet—שׁוֹפַר תְּרוּעָה (shofar teru'ah)—on the tenth day of the seventh month; on the Day of Atonement shall you send abroad the trumpet throughout all your land.

**25:10** "'And you shall hallow the fiftieth year, and proclaim liberty throughout the land unto all the inhabitants thereof—וּקְרָאתֶם דְּרוֹר בָּאָרֶץ (u-qeratem deror ba-arets); it shall be a jubilee—יוֹבֵל (yovel)—unto you; and you shall return every man unto his possession, and you shall return every man unto his family.

**25:11** "'A jubilee shall that fiftieth year be unto you; you shall not sow, neither reap that which grows of itself in it, nor gather the grapes in it of the undressed vines.

**25:12** "'For it is a jubilee; it shall be holy unto you; you shall eat of the increase thereof out of the field.

**25:13** "'In this year of jubilee you shall return every man unto his possession.

---

**25:14** "'And if you sell anything unto your neighbor, or buy from your neighbor's hand, you shall not wrong one another.

**25:15** "'According to the number of years after the jubilee you shall buy from your neighbor, and according to the number of years of the crops he shall sell unto you.

**25:16** "'According to the multitude of the years you shall increase the price thereof, and according to the fewness of the years you shall diminish the price of it; for the number of the crops he sells unto you.

**25:17** "'And you shall not wrong one another; but you shall fear your Consciousness; for I am YHWH your Consciousness.

**25:18** "'Therefore you shall do my statutes, and keep my ordinances and do them; and you shall dwell in the land in safety.

**25:19** "'And the land shall yield its fruit, and you shall eat to the full, and dwell therein in safety.

**25:20** "'And if you shall say: What shall we eat in the seventh year? Behold, we shall not sow, nor gather in our produce!

**25:21** "'Then I will command my blessing upon you in the sixth year, and it shall bring forth produce for three years.

**25:22** "'And you shall sow the eighth year, and eat of the produce, the old store; until the ninth year, until its produce comes in, you shall eat the old store.

---

**25:23** "'And the land shall not be sold in perpetuity—לִצְמִתֻת (li-tsmitut); for the land is mine—כִּי־לִי הָאָרֶץ (ki-li ha-arets); for you are strangers and sojourners with me.

**25:24** "'And in all the land of your possession you shall grant redemption for the land.

**25:25** "'If your brother becomes poor, and sells some of his possession, then shall his kinsman who is nearest unto him come, and shall redeem that which his brother sold.

**25:26** "'And if a man has no kinsman, and himself becomes able to redeem it,

**25:27** "'Then let him count the years of the sale thereof, and restore the surplus unto the man to whom he sold it; and he shall return unto his possession.

**25:28** "'But if he is not able to restore it to him, then that which he has sold shall remain in the hand of him who has bought it until the year of jubilee; and in the jubilee it shall go out, and he shall return unto his possession.

**25:29** "'And if a man sells a dwelling house in a walled city, then he may redeem it within a whole year after it is sold; within a full year may he redeem it.

**25:30** "'And if it is not redeemed within the space of a full year, then the house that is in the walled city shall be made sure in perpetuity to him who bought it, throughout his generations; it shall not go out in the jubilee.

**25:31** "'But the houses of the villages which have no wall round about them shall be reckoned with the fields of the country; they may be redeemed, and they shall go out in the jubilee.

**25:32** "'Nevertheless the cities of the Levites, the houses of the cities of their possession, the Levites may redeem at any time.

**25:33** "'And if a man purchases from the Levites, then the house that was sold, and the city of his possession, shall go out in the jubilee; for the houses of the cities of the Levites are their possession among the children of Israel.

**25:34** "'But the field of the open land of their cities may not be sold; for it is their perpetual possession.

---

**25:35** "'And if your brother becomes poor, and his hand wavers beside you, then you shall uphold him—וְהֶחֱזַקְתָּ בּוֹ (ve-hechezaqta bo); as a stranger and a sojourner shall he live with you.

**25:36** "'Take no interest of him—נֶשֶׁךְ (neshech)—or increase—תַּרְבִּית (tarbit); but fear your Consciousness; that your brother may live with you.

**25:37** "'You shall not give him your money upon interest, nor give him your food for increase.

**25:38** "'I am YHWH your Consciousness, who brought you out of the land of Egypt, to give you the land of Canaan, to be your Consciousness.

**25:39** "'And if your brother becomes poor beside you, and sells himself unto you, you shall not make him serve as a slave—עֲבֹדַת עָבֶד (avodat aved).

**25:40** "'As a hired servant, and as a sojourner, he shall be with you; he shall serve with you unto the year of jubilee.

**25:41** "'And then he shall go out from you, he and his children with him, and shall return unto his own family, and unto the possession of his fathers shall he return.

**25:42** "'For they are my servants, whom I brought out of the land of Egypt; they shall not be sold as bondsmen.

**25:43** "'You shall not rule over him with rigor—בְּפָרֶךְ (be-farekh); but shall fear your Consciousness.

**25:44** "'And as for your bondsmen and your bondswomen, whom you may have—of the nations that are round about you, of them shall you buy bondsmen and bondswomen.

**25:45** "'Moreover of the children of the strangers who sojourn among you, of them may you buy, and of their families that are with you, which they have begotten in your land; and they may be your possession.

**25:46** "'And you may make them an inheritance for your children after you, to hold for a possession; of them may you take your bondsmen forever; but over your brothers the children of Israel you shall not rule, one over another, with rigor.

---

**25:47** "'And if a stranger or sojourner with you grows rich, and your brother beside him becomes poor, and sells himself unto the stranger or sojourner with you, or to the stock of the stranger's family,

**25:48** "'After he is sold he may be redeemed; one of his brothers may redeem him;

**25:49** "'Or his uncle, or his uncle's son, may redeem him, or any of his kin of his family may redeem him; or if he grows rich, he may redeem himself.

**25:50** "'And he shall reckon with him who bought him from the year that he sold himself to him unto the year of jubilee; and the price of his sale shall be according to the number of years; according to the time of a hired servant shall it be with him.

**25:51** "'If there are yet many years, according to them he shall give back the price of his redemption out of the money that he was bought for.

**25:52** "'And if there remain but few years unto the year of jubilee, then he shall reckon with him; according unto his years shall he give back the price of his redemption.

**25:53** "'As a hired servant year by year shall he be with him; he shall not rule over him with rigor in your sight.

**25:54** "'And if he is not redeemed by these means, then he shall go out in the year of jubilee, he and his children with him.

**25:55** "'For unto me the children of Israel are servants; they are my servants whom I brought out of the land of Egypt: I am YHWH your Consciousness.'"

---

## Synthesis Notes

**Key Restorations:**

**The Sabbath of the Land:**
Every seventh year, the land rests:
- No sowing
- No pruning
- No organized harvest
- What grows naturally is available to all (owners, servants, strangers, animals)

The land itself observes sabbath. Agriculture is not unlimited exploitation.

**The Jubilee (יוֹבֵל, yovel):**
Every fiftieth year (after seven sabbatical cycles):
- Land returns to original family ownership
- Israelite slaves are freed
- Debts are released
- The shofar sounds on Yom Kippur

"Proclaim liberty throughout the land"—*deror* (דְּרוֹר), freedom, release. This phrase appears on the Liberty Bell in Philadelphia.

**Land Cannot Be Sold Permanently:**
"The land is mine; you are strangers and sojourners with me." Israel does not ultimately own the land; YHWH does. Sales are really leases until the next jubilee. Price is calculated by number of remaining harvests.

**Walled City Exception:**
Urban real estate in walled cities can be sold permanently (after one year of redemption right). This allows urban development. But villages and Levitical cities follow jubilee rules.

**No Interest on Loans to the Poor:**
*Neshech* (biting interest) and *tarbit* (increase) are forbidden when lending to an impoverished brother. The exodus is the reason: "I brought you out of Egypt." Freed people must not exploit each other.

**Israelite Servants:**
If poverty forces an Israelite to sell himself:
- He is not treated as a slave
- He works as a hired servant
- He is released at jubilee
- No rigorous treatment (*farekh*—the same word used for Egyptian oppression in Exodus 1:13-14)

"They are my servants"—Israelites belong to YHWH, not to each other. Slavery of one Israelite to another is incompatible with their shared liberation.

**Foreign Slaves:**
The text permits acquiring slaves from surrounding nations and resident aliens. They may be held permanently and inherited. This distinction between Israelite and foreign bondservants reflects ancient Near Eastern norms. The ethical trajectory points toward broader liberation, but the text itself contains this difficult distinction.

**Redemption by Kinsman:**
The *go'el* (redeemer, kinsman) has responsibility to buy back what a relative has lost. This applies to land and to persons sold. Family solidarity protects against permanent dispossession.

**Divine Provision:**
"What shall we eat in the seventh year?" YHWH promises a triple harvest in the sixth year. Trust in divine provision enables sabbatical practice.

**Archetypal Layer:** The jubilee is the **great reset**—preventing permanent accumulation of land and permanent enslavement. The system resists the concentration of wealth and the creation of a permanent underclass. Every fifty years, the social order is recalibrated to the original distribution.

**Psychological Reading:** The jubilee addresses the psychological burden of permanent debt and dispossession. The guaranteed return (for land and persons) means that poverty is never final. Hope is built into the system.

**Ethical Inversion Applied:**
- The land belongs to YHWH—humans are stewards, not ultimate owners
- Liberty is proclaimed—the jubilee resists permanent bondage
- No interest to the poor—economic exploitation is forbidden
- Israelites cannot be slaves—the exodus defines identity
- The sixth year blessing—faith enables the practice

**Difficult Elements:**
The permission of foreign slavery is troubling. The text improves on surrounding cultures (limits on Israelite bondage, no permanent Israelite slavery) but does not abolish slavery as an institution. The ethical trajectory (exodus liberation, jubilee release, "proclaim liberty") points beyond what the text explicitly achieves.

**Modern Equivalent:** The jubilee principle—periodic debt relief, land reform, prevention of permanent dispossession—influences contemporary discussions of economic justice. The prohibition of interest to the poor anticipates microlending principles. And "the land is mine" challenges any absolute notion of private property.

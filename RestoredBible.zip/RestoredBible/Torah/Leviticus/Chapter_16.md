# Leviticus Chapter 16: The Day of Atonement

*From the Hebrew: יוֹם הַכִּפֻּרִים (Yom HaKippurim) — The Day of Coverings*

---

**16:1** And YHWH spoke unto Moses after the death of the two sons of Aaron, when they drew near before YHWH, and died.

**16:2** And YHWH said unto Moses: "Speak unto Aaron your brother, that he come not at all times into the holy place within the veil, before the mercy seat which is upon the ark, that he not die; for I appear in the cloud upon the mercy seat.

**16:3** "Thus shall Aaron come into the holy place: with a young bull for a sin offering, and a ram for a burnt offering.

**16:4** "He shall put on the holy linen tunic, and he shall have linen undergarments upon his flesh, and shall be girded with the linen sash, and with the linen turban shall he be attired; they are holy garments; and he shall bathe his flesh in water, and put them on.

**16:5** "And he shall take from the congregation of the children of Israel two male goats for a sin offering, and one ram for a burnt offering.

**16:6** "And Aaron shall present the bull of the sin offering, which is for himself, and make atonement for himself and for his house.

**16:7** "And he shall take the two goats, and set them before YHWH at the door of the tent of meeting.

**16:8** "And Aaron shall cast lots upon the two goats: one lot for YHWH, and the other lot for Azazel—לַעֲזָאזֵל (la-Azazel).

**16:9** "And Aaron shall present the goat upon which the lot fell for YHWH, and offer it for a sin offering.

**16:10** "But the goat on which the lot fell for Azazel shall be set alive before YHWH, to make atonement over it, to send it away for Azazel into the wilderness.

---

**16:11** "And Aaron shall present the bull of the sin offering, which is for himself, and shall make atonement for himself and for his house, and shall kill the bull of the sin offering which is for himself.

**16:12** "And he shall take a censer full of coals of fire from upon the altar before YHWH, and his hands full of sweet incense beaten small, and bring it within the veil.

**16:13** "And he shall put the incense upon the fire before YHWH, that the cloud of the incense may cover the mercy seat that is upon the testimony, that he not die.

**16:14** "And he shall take of the blood of the bull, and sprinkle it with his finger upon the mercy seat on the east; and before the mercy seat he shall sprinkle of the blood with his finger seven times.

**16:15** "Then shall he kill the goat of the sin offering, that is for the people, and bring its blood within the veil, and do with its blood as he did with the blood of the bull, and sprinkle it upon the mercy seat and before the mercy seat.

**16:16** "And he shall make atonement for the holy place, because of the uncleannesses of the children of Israel, and because of their transgressions, even all their sins; and so shall he do for the tent of meeting, that dwells with them in the midst of their uncleannesses.

**16:17** "And there shall be no man in the tent of meeting when he goes in to make atonement in the holy place, until he comes out, and has made atonement for himself and for his house and for all the assembly of Israel.

**16:18** "And he shall go out unto the altar that is before YHWH, and make atonement for it; and shall take of the blood of the bull, and of the blood of the goat, and put it upon the horns of the altar round about.

**16:19** "And he shall sprinkle of the blood upon it with his finger seven times, and cleanse it, and hallow it from the uncleannesses of the children of Israel.

---

**16:20** "And when he has made an end of atoning for the holy place, and the tent of meeting, and the altar, he shall present the live goat.

**16:21** "And Aaron shall lay both his hands upon the head of the live goat, and confess over it all the iniquities of the children of Israel, and all their transgressions, even all their sins; and he shall put them upon the head of the goat, and shall send it away by the hand of a man who is in readiness into the wilderness.

**16:22** "And the goat shall bear upon it all their iniquities unto a land cut off—אֶרֶץ גְּזֵרָה (erets gezerah); and he shall let the goat go in the wilderness.

**16:23** "And Aaron shall come into the tent of meeting, and shall put off the linen garments, which he put on when he went into the holy place, and shall leave them there.

**16:24** "And he shall bathe his flesh in water in a holy place, and put on his garments, and come forth, and offer his burnt offering and the burnt offering of the people, and make atonement for himself and for the people.

**16:25** "And the fat of the sin offering shall he burn upon the altar.

**16:26** "And he who lets the goat go for Azazel shall wash his clothes, and bathe his flesh in water, and afterward he may come into the camp.

**16:27** "And the bull of the sin offering, and the goat of the sin offering, whose blood was brought in to make atonement in the holy place, shall be carried forth outside the camp; and they shall burn in the fire their skins, and their flesh, and their dung.

**16:28** "And he who burns them shall wash his clothes, and bathe his flesh in water, and afterward he may come into the camp.

---

**16:29** "And it shall be a statute forever unto you: in the seventh month, on the tenth day of the month, you shall afflict your souls—תְּעַנּוּ אֶת־נַפְשֹׁתֵיכֶם (te'annu et-nafshoteichem)—and shall do no manner of work, the native-born and the stranger who sojourns among you.

**16:30** "For on this day shall atonement be made for you, to cleanse you; from all your sins you shall be clean before YHWH—מִכֹּל חַטֹּאתֵיכֶם לִפְנֵי יהוה תִּטְהָרוּ (mi-kol chattoteichem lifnei YHWH titharu).

**16:31** "It is a sabbath of solemn rest unto you, and you shall afflict your souls; it is a statute forever.

**16:32** "And the priest who is anointed and who is consecrated to be priest in his father's stead shall make the atonement, and shall put on the linen garments, the holy garments.

**16:33** "And he shall make atonement for the holy sanctuary; and he shall make atonement for the tent of meeting and for the altar; and he shall make atonement for the priests and for all the people of the assembly.

**16:34** "And this shall be an everlasting statute unto you, to make atonement for the children of Israel because of all their sins once in the year—אַחַת בַּשָּׁנָה (achat ba-shanah)." And he did as YHWH commanded Moses.

---

## Synthesis Notes

**Key Restorations:**

**Context:**
The chapter opens "after the death of the two sons of Aaron"—Nadab and Abihu (chapter 10). Their unauthorized approach was fatal. This chapter establishes the authorized way to enter the most holy place.

**The Annual Entry:**
Only on this day, once a year, may the high priest enter the holy of holies. The rest of the year, even the high priest is forbidden. "He come not at all times"—the approach is regulated, not casual.

**The Linen Garments:**
For this day alone, Aaron does not wear the golden garments of glory. He wears simple white linen:
- Linen tunic
- Linen undergarments
- Linen sash
- Linen turban

The high priest approaches as supplicant, not as magnificently vested leader. Humility, not glory.

**The Incense Cloud:**
Before sprinkling blood on the mercy seat, Aaron fills the holy of holies with incense smoke. "That the cloud of the incense may cover the mercy seat... that he not die." The cloud veils the direct presence. Even on the Day of Atonement, YHWH's presence is screened.

**The Two Goats:**

The lot is cast:
- One goat "for YHWH"—slaughtered, blood sprinkled on the mercy seat
- One goat "for Azazel"—sent away alive into the wilderness

**Azazel (עֲזָאזֵל):**
The meaning is debated:
- A place name (rocky cliff in the wilderness)
- A demon or wilderness spirit (later Jewish tradition)
- A term meaning "complete removal" (*ez* + *azal* = goat that goes away)

Whatever Azazel means, the goat carries Israel's sins away, out of the camp, into "a land cut off" (*erets gezerah*).

**The Scapegoat:**
Aaron lays both hands on the live goat and confesses "all the iniquities of the children of Israel, and all their transgressions, even all their sins." The sins are symbolically transferred to the goat. The goat bears them away. The people are released.

**Blood on the Mercy Seat:**
The blood of the bull (for the priest) and the goat (for the people) is sprinkled:
- Upon the mercy seat
- Before the mercy seat (seven times)
- On the altar horns
- Upon the altar (seven times)

The entire sanctuary is cleansed from the accumulated impurity of Israel's sins.

**"Afflict Your Souls":**
*Te'annu et-nafshoteichem* (תְּעַנּוּ אֶת־נַפְשֹׁתֵיכֶם)—traditionally interpreted as fasting. The people participate through self-denial, complete rest (sabbath of sabbaths), and no work.

**"From All Your Sins You Shall Be Clean":**
The promise is comprehensive. Yom Kippur addresses all sins—not just inadvertent ones (chapters 4-5) but all transgressions. This is annual cleansing, complete reset.

**Once a Year:**
*Achat ba-shanah* (אַחַת בַּשָּׁנָה)—once in the year. The tenth day of the seventh month (Tishrei). This becomes the holiest day of the Jewish calendar—Yom Kippur.

**Archetypal Layer:** Yom Kippur is the **annual death and resurrection** of the covenant community. The accumulated impurity is purged. The sins are sent away. The sanctuary is cleansed. Israel begins again.

The two goats represent **two aspects of atonement**:
- The slain goat: blood for purification
- The live goat: removal of guilt

Death cleanses the sanctuary; the living goat carries away the transferred sin.

**Psychological Reading:** The scapegoat ritual externalizes guilt. What is confessed and placed on the goat is sent away—visibly, physically. The community watches the goat disappear into the wilderness. Their sins go with it.

The high priest's entry into the holy of holies is the most dangerous moment of the year. He goes where no one else may go. He emerges alive—proof that the atonement was accepted.

**Ethical Inversion Applied:**
- The high priest wears humble linen, not glorious gold
- Lots determine which goat for which purpose—no human manipulation
- Confession is comprehensive—all iniquities, transgressions, sins
- The community participates through fasting—not passive recipients
- The sins are sent away, not merely covered—removal, not suppression

**Modern Equivalent:** Communities need annual reckoning—acknowledgment of failure, ritual of release. The scapegoat (unfortunately literalized in harmful ways) represents the need to externalize and send away accumulated guilt. And the high priest's danger in the holy of holies suggests that genuine reconciliation is not casual—someone must enter the dangerous place on behalf of the community.

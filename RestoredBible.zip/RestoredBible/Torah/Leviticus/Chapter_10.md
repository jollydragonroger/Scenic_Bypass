# Leviticus Chapter 10: The Death of Nadab and Abihu

*From the Hebrew: Strange Fire*

---

**10:1** And Nadab and Abihu, the sons of Aaron, each took his censer, and put fire in it, and put incense upon it, and offered strange fire—אֵשׁ זָרָה (esh zarah)—before YHWH, which he had not commanded them.

**10:2** And fire came forth from before YHWH—וַתֵּצֵא אֵשׁ מִלִּפְנֵי יהוה (va-tetse esh mi-lifnei YHWH)—and consumed them, and they died before YHWH.

**10:3** And Moses said unto Aaron: "This is what YHWH spoke, saying, 'Through those who are near me I will be sanctified—בִּקְרֹבַי אֶקָּדֵשׁ (bi-qrovai eqqadesh)—and before all the people I will be glorified.'" And Aaron was silent—וַיִּדֹּם אַהֲרֹן (va-yiddom Aharon).

**10:4** And Moses called Mishael and Elzaphan, the sons of Uzziel the uncle of Aaron, and said unto them: "Draw near, carry your brothers from before the sanctuary out of the camp."

**10:5** And they drew near, and carried them in their tunics out of the camp, as Moses had said.

**10:6** And Moses said unto Aaron, and unto Eleazar and unto Ithamar, his sons: "Do not let the hair of your heads go loose, neither rend your clothes, lest you die, and lest wrath come upon all the congregation; but let your brothers, the whole house of Israel, bewail the burning which YHWH has kindled.

**10:7** "And you shall not go out from the door of the tent of meeting, lest you die; for the anointing oil of YHWH is upon you." And they did according to the word of Moses.

---

**10:8** And YHWH spoke unto Aaron, saying:

**10:9** "Do not drink wine nor strong drink—יַיִן וְשֵׁכָר (yayin ve-shechar)—you, nor your sons with you, when you go into the tent of meeting, lest you die; it is a statute forever throughout your generations.

**10:10** "And that you may distinguish between the holy and the common—בֵּין הַקֹּדֶשׁ וּבֵין הַחֹל (bein ha-qodesh u-vein ha-chol)—and between the unclean and the clean—וּבֵין הַטָּמֵא וּבֵין הַטָּהוֹר (u-vein ha-tame u-vein ha-tahor);

**10:11** "And that you may teach the children of Israel all the statutes which YHWH has spoken unto them by the hand of Moses."

---

**10:12** And Moses spoke unto Aaron, and unto Eleazar and unto Ithamar, his remaining sons: "Take the grain offering that remains of the fire offerings of YHWH, and eat it unleavened beside the altar; for it is most holy.

**10:13** "And you shall eat it in a holy place, because it is your due and your sons' due of the fire offerings of YHWH; for so I have been commanded.

**10:14** "And the breast of the wave offering and the thigh of the contribution you shall eat in a clean place, you and your sons and your daughters with you; for they are given as your due and your sons' due, out of the sacrifices of peace offerings of the children of Israel.

**10:15** "The thigh of the contribution and the breast of the wave offering they shall bring with the fire offerings of the fat, to wave for a wave offering before YHWH; and it shall be yours and your sons' with you, as a portion forever, as YHWH has commanded."

**10:16** And Moses diligently inquired for the goat of the sin offering, and behold, it was burned; and he was angry with Eleazar and with Ithamar, the remaining sons of Aaron, saying:

**10:17** "Why have you not eaten the sin offering in the place of the sanctuary, seeing it is most holy, and he has given it to you to bear the iniquity of the congregation, to make atonement for them before YHWH?

**10:18** "Behold, its blood was not brought inside the sanctuary; you certainly should have eaten it in the sanctuary, as I commanded."

**10:19** And Aaron spoke unto Moses: "Behold, this day they have offered their sin offering and their burnt offering before YHWH, and such things have befallen me; and if I had eaten the sin offering today, would it have been good in the sight of YHWH?"

**10:20** And when Moses heard that, it was good in his sight—וַיִּיטַב בְּעֵינָיו (va-yitav be-einav).

---

## Synthesis Notes

**Key Restorations:**

**Strange Fire (אֵשׁ זָרָה, esh zarah):**
Nadab and Abihu, Aaron's two eldest sons, offer incense with fire "which he had not commanded them." The precise violation is debated:
- Unauthorized fire source (not from the altar)
- Unauthorized time (not at the proper hour)
- Unauthorized incense formula
- Intoxication (implied by verses 8-9)

The text emphasizes: "which he had not commanded." Innovation in sacred ritual is dangerous. What YHWH did not command is *zarah*—strange, foreign, illegitimate.

**Fire That Consumes:**
The same phrase as 9:24—"fire came forth from before YHWH" (*va-tetse esh mi-lifnei YHWH*). In chapter 9, divine fire accepted the offering; in chapter 10, divine fire destroys the offerers. The same fire that blesses can destroy. Holiness is not safe.

**"Through Those Near Me I Will Be Sanctified":**
Moses interprets: those closest to YHWH bear greater responsibility. Privilege brings stricter judgment. The priests who serve at the altar cannot treat the sacred casually.

**"Aaron Was Silent":**
*Va-yiddom Aharon* (וַיִּדֹּם אַהֲרֹן)—Aaron says nothing. He does not protest, defend his sons, or question YHWH. His silence is submission, grief beyond words, acceptance of divine judgment. This is one of Scripture's most powerful moments of restrained anguish.

**No Mourning for Aaron:**
Aaron, Eleazar, and Ithamar are forbidden the normal mourning rites:
- No loosening hair (*parah*)
- No tearing clothes (*qara*)
- No leaving the sanctuary

They must continue their priestly duties. The anointing oil is on them; they cannot mourn as laypeople would. The community may mourn; the priests may not.

**Prohibition of Wine:**
Immediately following, YHWH speaks directly to Aaron (rare—usually through Moses): no wine or strong drink when entering the tent of meeting. This suggests intoxication may have contributed to Nadab and Abihu's error. Priests must be sober to distinguish holy from common, clean from unclean.

**The Priestly Vocation:**
"That you may distinguish between the holy and the common, and between the unclean and the clean, and that you may teach..." The priest's role:
1. **Discernment**—holy/common, clean/unclean
2. **Teaching**—transmitting the statutes to Israel

The sin of Nadab and Abihu was failure of discernment.

**The Uneaten Sin Offering:**
Moses discovers the sin offering goat was burned, not eaten. He is angry—the priests should have eaten it "to bear the iniquity of the congregation." Eating the sin offering was part of the atonement process.

**Aaron's Defense:**
Aaron explains: after what happened today (his sons' deaths), would eating the sin offering have been acceptable? He sensed that eating in grief would be inappropriate. Moses accepts this—"it was good in his sight."

Aaron's pastoral instinct overrides the technical requirement. Sometimes grief suspends normal duties.

**Archetypal Layer:** The death of Nadab and Abihu is **the danger of the sacred**. The holy is not domesticated. Approach requires precision, sobriety, and command. Innovation is perilous. The same fire that accepts can consume.

Aaron's silence is **submission to the mysterium tremendum**—the holy that terrifies. There are no words adequate to divine judgment.

**Psychological Reading:** Those who serve closest to the holy bear the greatest risk. The ego that innovates in sacred matters—adding what was not commanded—may be destroyed. Aaron's silence is the ego's appropriate response to overwhelming judgment: no defense, no complaint, only silence.

**Ethical Inversion Applied:**
- Innovation in sacred matters is dangerous—"which he had not commanded"
- Proximity to the holy increases responsibility
- Aaron's silence is profound submission
- Sobriety is required for discernment
- Pastoral sensitivity can override technical rules (Aaron's defense is accepted)

**Modern Equivalent:** Those who lead in sacred matters cannot be casual or experimental with what is holy. Intoxication (literal or figurative—ego-inflation, carelessness) impairs the discernment needed. And sometimes grief genuinely prevents normal function; grace acknowledges this.

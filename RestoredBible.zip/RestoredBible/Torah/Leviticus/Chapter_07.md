# Leviticus Chapter 7: Laws of the Guilt and Peace Offerings

*From the Hebrew: Priestly Portions and Prohibitions*

---

**7:1** "And this is the law of the guilt offering—תּוֹרַת הָאָשָׁם (torat ha-asham); it is most holy.

**7:2** "In the place where they slaughter the burnt offering they shall slaughter the guilt offering; and its blood he shall throw against the altar round about.

**7:3** "And all its fat he shall offer from it: the fat tail, and the fat that covers the entrails,

**7:4** "And the two kidneys, and the fat that is upon them, which is upon the loins, and the lobe of the liver, which he shall remove with the kidneys.

**7:5** "And the priest shall burn them upon the altar for a fire offering unto YHWH; it is a guilt offering.

**7:6** "Every male among the priests shall eat of it; in a holy place it shall be eaten; it is most holy.

**7:7** "As is the sin offering, so is the guilt offering; there is one law for them; the priest who makes atonement with it shall have it.

**7:8** "And the priest who offers any man's burnt offering, the priest shall have for himself the skin of the burnt offering which he has offered.

**7:9** "And every grain offering that is baked in the oven, and all that is prepared in the pan and on the griddle, shall be the priest's who offers it.

**7:10** "And every grain offering, mixed with oil or dry, shall belong to all the sons of Aaron alike.

---

**7:11** "And this is the law of the sacrifice of peace offerings—תּוֹרַת זֶבַח הַשְּׁלָמִים (torat zevach ha-shelamim)—which one may offer unto YHWH.

**7:12** "If he offers it for a thanksgiving—תּוֹדָה (todah)—then he shall offer with the sacrifice of thanksgiving unleavened cakes mixed with oil, and unleavened wafers anointed with oil, and cakes of fine flour soaked and mixed with oil.

**7:13** "With cakes of leavened bread he shall bring his offering with the sacrifice of his peace offerings for thanksgiving.

**7:14** "And of it he shall offer one out of each offering as a contribution unto YHWH; it shall be the priest's who throws the blood of the peace offerings.

**7:15** "And the flesh of the sacrifice of his peace offerings for thanksgiving shall be eaten on the day of his offering; he shall not leave any of it until the morning.

**7:16** "But if the sacrifice of his offering is a vow—נֶדֶר (neder)—or a freewill offering—נְדָבָה (nedavah)—it shall be eaten on the day that he offers his sacrifice; and on the morrow the remainder of it may be eaten.

**7:17** "But the remainder of the flesh of the sacrifice on the third day shall be burned with fire.

**7:18** "And if any of the flesh of the sacrifice of his peace offerings is eaten on the third day, it shall not be accepted; it shall not be reckoned unto him who offers it; it shall be a foul thing—פִּגּוּל (piggul)—and the soul who eats of it shall bear his iniquity.

**7:19** "And the flesh that touches any unclean thing shall not be eaten; it shall be burned with fire. And as for the flesh, everyone who is clean may eat of it.

**7:20** "But the soul who eats of the flesh of the sacrifice of peace offerings that belong to YHWH, having his uncleanness upon him, that soul shall be cut off from his people.

**7:21** "And when a soul touches any unclean thing, whether it is the uncleanness of man or an unclean beast or any unclean abomination, and eats of the flesh of the sacrifice of peace offerings which belong to YHWH, that soul shall be cut off from his people."

---

**7:22** And YHWH spoke unto Moses, saying:

**7:23** "Speak unto the children of Israel, saying: 'You shall eat no fat—כָּל־חֵלֶב (kol-chelev)—of ox or sheep or goat.

**7:24** "'And the fat of that which dies of itself, and the fat of that which is torn by beasts, may be used for any other service; but you shall in no way eat of it.

**7:25** "'For whoever eats the fat of the beast from which men offer a fire offering unto YHWH, the soul who eats it shall be cut off from his people.

**7:26** "'And you shall eat no blood—כָּל־דָּם (kol-dam)—in any of your dwellings, whether of bird or of beast.

**7:27** "'Whoever eats any blood, that soul shall be cut off from his people.'"

---

**7:28** And YHWH spoke unto Moses, saying:

**7:29** "Speak unto the children of Israel, saying: 'He who offers the sacrifice of his peace offerings unto YHWH shall bring his offering unto YHWH from the sacrifice of his peace offerings.

**7:30** "'His own hands shall bring the fire offerings of YHWH; the fat with the breast he shall bring, that the breast may be waved as a wave offering—תְּנוּפָה (tenufah)—before YHWH.

**7:31** "'And the priest shall burn the fat upon the altar; but the breast shall be Aaron's and his sons'.

**7:32** "'And the right thigh—שׁוֹק הַיָּמִין (shoq ha-yamin)—you shall give unto the priest for a contribution from your sacrifices of peace offerings.

**7:33** "'He among the sons of Aaron who offers the blood of the peace offerings and the fat shall have the right thigh for a portion.

**7:34** "'For the breast of the wave offering and the thigh of the contribution I have taken from the children of Israel from their sacrifices of peace offerings, and have given them unto Aaron the priest and unto his sons as a portion forever from the children of Israel.'"

**7:35** This is the portion of the anointing of Aaron and of the anointing of his sons, from the fire offerings of YHWH, on the day when he brought them near to minister unto YHWH as priests;

**7:36** Which YHWH commanded to be given them from the children of Israel, on the day that he anointed them; it is a portion forever throughout their generations.

**7:37** This is the law of the burnt offering, of the grain offering, and of the sin offering, and of the guilt offering, and of the ordination offering, and of the sacrifice of peace offerings,

**7:38** Which YHWH commanded Moses on Mount Sinai, on the day that he commanded the children of Israel to offer their offerings unto YHWH, in the wilderness of Sinai.

---

## Synthesis Notes

**Key Restorations:**

**Guilt Offering Summary:**
Like the sin offering—most holy, slaughtered where burnt offerings are slaughtered. The officiating priest receives the meat.

**Priestly Portions:**
- **Burnt offering**: priest gets the skin (valuable leather)
- **Grain offering (baked)**: officiating priest
- **Grain offering (unbaked)**: all priests share equally
- **Peace offering**: breast (wave offering) to all priests; right thigh to officiating priest

**Three Types of Peace Offering:**

1. **Todah (תּוֹדָה)** — Thanksgiving: offered in gratitude for deliverance or blessing; accompanied by various cakes (leavened and unleavened); must be eaten the same day

2. **Neder (נֶדֶר)** — Vow: fulfilling a promise made to YHWH; may be eaten over two days

3. **Nedavah (נְדָבָה)** — Freewill: voluntary, spontaneous offering; may be eaten over two days

**Time Limits:**
- Thanksgiving: eaten same day
- Vow/freewill: eaten within two days
- Third day: any remaining meat is burned; eating it is *piggul* (abomination) and makes the offering invalid

**Piggul (פִּגּוּל):**
Offensive, foul, abhorrent. Meat kept beyond the permitted time becomes piggul—eating it brings guilt, not blessing. The offering "shall not be reckoned unto him"—it is invalidated.

**Uncleanness and Eating:**
- Meat that touches anything unclean: burn it
- Clean persons may eat the peace offering
- Unclean persons who eat: cut off from the people
- Touching uncleanness and then eating: cut off

Purity matters for participation. The sacred meal requires clean participants.

**Fat and Blood Prohibited:**
Universal, perpetual prohibitions:
- No eating fat (*chelev*) of ox, sheep, or goat
- Fat from animals that die naturally or are torn: may be used for other purposes (leather-working, lamps) but not eaten
- No eating blood of any bird or beast
- Penalty: cut off from the people

Fat and blood belong to YHWH. They are never for human consumption.

**The Wave Offering (תְּנוּפָה):**
The breast is "waved" before YHWH—a horizontal movement presenting the portion to YHWH before giving it to the priests. The gesture acknowledges YHWH's ownership before human receipt.

**The Contribution (תְּרוּמָה):**
The right thigh is a *terumah*—a lifted-up or elevated contribution. This goes to the officiating priest.

**Summary (7:37-38):**
The section concludes by listing all the offerings:
- Burnt offering (*olah*)
- Grain offering (*minchah*)
- Sin offering (*chattat*)
- Guilt offering (*asham*)
- Ordination offering (*millu'im*)
- Peace offerings (*shelamim*)

These are "the law" (*torah*)—the instruction—given at Sinai.

**Archetypal Layer:** The peace offering is the **communal feast**—YHWH receives the fat; priests receive the breast and thigh; the offerer and guests eat the rest. It is shared celebration. The time limits (same day or two days) ensure the meal is communal and fresh, not hoarded.

The prohibition of fat and blood reserves the richest (fat) and the life (blood) for YHWH. Humans eat flesh; YHWH receives the essence.

**Psychological Reading:** Thanksgiving (*todah*) must be eaten immediately—gratitude is not for storing but for sharing now. The time limits prevent the sacred meal from becoming private property. And the purity requirements ensure that participants are in a fit state for encounter with the holy.

**Ethical Inversion Applied:**
- Three motivations for peace offering: thanksgiving, vow, freewill—different occasions, same fellowship
- Time limits prevent hoarding—the sacred meal is for now
- Fat and blood are YHWH's—certain things are never for human consumption
- Priests are provided for through the sacrificial system—no separate taxation
- "Cut off" for eating in uncleanness—approach to the sacred requires preparation

**Modern Equivalent:** Gratitude should be celebrated immediately, not deferred. Shared meals build community. And some things are reserved—not everything is for human use. The priestly portions model how religious leadership can be sustained through the community's worship rather than separate economic systems.

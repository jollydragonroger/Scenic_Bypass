# Leviticus Chapter 14: Purification from Skin Disease

*From the Hebrew: טָהֳרַת הַמְּצֹרָע (Tahorat Ha-Metsora) — Cleansing of the Afflicted*

---

**14:1** And YHWH spoke unto Moses, saying:

**14:2** "This shall be the law of the *metsora* in the day of his cleansing—תּוֹרַת הַמְּצֹרָע בְּיוֹם טָהֳרָתוֹ (torat ha-metsora be-yom tahorato): he shall be brought unto the priest.

**14:3** "And the priest shall go forth outside the camp; and the priest shall look, and behold, if the plague of *tsara'at* is healed in the *tsarua*,

**14:4** "Then shall the priest command to take for him who is to be cleansed two living clean birds, and cedar wood, and scarlet, and hyssop.

**14:5** "And the priest shall command to kill one of the birds in an earthen vessel over living water—מַיִם חַיִּים (mayim chayyim).

**14:6** "As for the living bird, he shall take it, and the cedar wood, and the scarlet, and the hyssop, and shall dip them and the living bird in the blood of the bird that was killed over the living water.

**14:7** "And he shall sprinkle upon him who is to be cleansed from the *tsara'at* seven times, and shall pronounce him clean, and shall let the living bird loose into the open field.

**14:8** "And he who is to be cleansed shall wash his clothes, and shave off all his hair, and bathe himself in water; and he shall be clean. And after that he may come into the camp; but he shall dwell outside his tent seven days.

**14:9** "And on the seventh day he shall shave all his hair off his head and his beard and his eyebrows; all his hair he shall shave off. And he shall wash his clothes, and bathe his flesh in water, and he shall be clean.

---

**14:10** "And on the eighth day he shall take two male lambs without blemish, and one ewe lamb a year old without blemish, and three tenth measures of fine flour for a grain offering, mixed with oil, and one log of oil.

**14:11** "And the priest who cleanses him shall set the man who is to be cleansed, and those things, before YHWH, at the door of the tent of meeting.

**14:12** "And the priest shall take one of the male lambs, and offer it for a guilt offering—אָשָׁם (asham)—and the log of oil, and wave them for a wave offering before YHWH.

**14:13** "And he shall kill the lamb in the place where they kill the sin offering and the burnt offering, in the place of the sanctuary; for as the sin offering is the priest's, so is the guilt offering; it is most holy.

**14:14** "And the priest shall take of the blood of the guilt offering, and the priest shall put it upon the tip of the right ear of him who is to be cleansed, and upon the thumb of his right hand, and upon the great toe of his right foot.

**14:15** "And the priest shall take of the log of oil, and pour it into the palm of his own left hand.

**14:16** "And the priest shall dip his right finger in the oil that is in his left hand, and shall sprinkle of the oil with his finger seven times before YHWH.

**14:17** "And of the rest of the oil that is in his hand the priest shall put upon the tip of the right ear of him who is to be cleansed, and upon the thumb of his right hand, and upon the great toe of his right foot, upon the blood of the guilt offering.

**14:18** "And the rest of the oil that is in the priest's hand he shall put upon the head of him who is to be cleansed; and the priest shall make atonement for him before YHWH.

**14:19** "And the priest shall offer the sin offering, and make atonement for him who is to be cleansed from his uncleanness; and afterward he shall kill the burnt offering.

**14:20** "And the priest shall offer the burnt offering and the grain offering upon the altar; and the priest shall make atonement for him, and he shall be clean.

---

**14:21** "And if he is poor, and his means do not suffice, then he shall take one male lamb for a guilt offering to be waved, to make atonement for him, and one tenth measure of fine flour mixed with oil for a grain offering, and a log of oil,

**14:22** "And two turtledoves, or two young pigeons, such as his means suffice for; and the one shall be a sin offering, and the other a burnt offering.

**14:23** "And on the eighth day he shall bring them for his cleansing unto the priest, unto the door of the tent of meeting, before YHWH.

**14:24** "And the priest shall take the lamb of the guilt offering, and the log of oil, and the priest shall wave them for a wave offering before YHWH.

**14:25** "And he shall kill the lamb of the guilt offering; and the priest shall take of the blood of the guilt offering, and put it upon the tip of the right ear of him who is to be cleansed, and upon the thumb of his right hand, and upon the great toe of his right foot.

**14:26** "And the priest shall pour of the oil into the palm of his own left hand.

**14:27** "And the priest shall sprinkle with his right finger some of the oil that is in his left hand seven times before YHWH.

**14:28** "And the priest shall put of the oil that is in his hand upon the tip of the right ear of him who is to be cleansed, and upon the thumb of his right hand, and upon the great toe of his right foot, upon the place of the blood of the guilt offering.

**14:29** "And the rest of the oil that is in the priest's hand he shall put upon the head of him who is to be cleansed, to make atonement for him before YHWH.

**14:30** "And he shall offer one of the turtledoves, or of the young pigeons, such as his means suffice for,

**14:31** "Such as his means suffice for, the one for a sin offering, and the other for a burnt offering, with the grain offering; and the priest shall make atonement for him who is to be cleansed before YHWH.

**14:32** "This is the law for him in whom is the plague of *tsara'at*, whose means do not suffice for his cleansing."

---

**14:33** And YHWH spoke unto Moses and unto Aaron, saying:

**14:34** "When you come into the land of Canaan, which I give to you for a possession, and I put the plague of *tsara'at* in a house of the land of your possession,

**14:35** "Then he who owns the house shall come and tell the priest, saying, 'Something like a plague has appeared to me in the house.'

**14:36** "And the priest shall command that they empty the house, before the priest goes in to look at the plague, that all that is in the house may not be made unclean; and afterward the priest shall go in to see the house.

**14:37** "And he shall look at the plague; and behold, if the plague is in the walls of the house with greenish or reddish depressions, and their appearance is deeper than the surface of the wall,

**14:38** "Then the priest shall go out of the house to the door of the house, and shut up the house seven days.

**14:39** "And the priest shall return on the seventh day, and shall look; and behold, if the plague has spread in the walls of the house,

**14:40** "Then the priest shall command that they take out the stones in which the plague is, and cast them into an unclean place outside the city.

**14:41** "And he shall cause the house to be scraped inside round about, and they shall pour out the mortar that they scrape off outside the city into an unclean place.

**14:42** "And they shall take other stones, and put them in the place of those stones; and he shall take other mortar, and shall plaster the house.

**14:43** "And if the plague comes again, and breaks out in the house, after he has taken out the stones, and after he has scraped the house, and after it is plastered,

**14:44** "Then the priest shall come in and look; and behold, if the plague has spread in the house, it is a malignant *tsara'at* in the house; it is unclean.

**14:45** "And he shall break down the house, its stones, and its timber, and all the mortar of the house; and he shall carry them forth out of the city unto an unclean place.

**14:46** "And he who goes into the house all the while that it is shut up shall be unclean until the evening.

**14:47** "And he who lies in the house shall wash his clothes; and he who eats in the house shall wash his clothes.

**14:48** "And if the priest comes in and looks, and behold, the plague has not spread in the house, after the house was plastered, then the priest shall pronounce the house clean, because the plague is healed.

**14:49** "And he shall take to cleanse the house two birds, and cedar wood, and scarlet, and hyssop.

**14:50** "And he shall kill one of the birds in an earthen vessel over living water.

**14:51** "And he shall take the cedar wood, and the hyssop, and the scarlet, and the living bird, and dip them in the blood of the slain bird, and in the living water, and sprinkle the house seven times.

**14:52** "And he shall cleanse the house with the blood of the bird, and with the living water, and with the living bird, and with the cedar wood, and with the hyssop, and with the scarlet.

**14:53** "And he shall let the living bird go out of the city into the open field; so shall he make atonement for the house; and it shall be clean."

**14:54** This is the law for all manner of plague of *tsara'at*, and for a scall,

**14:55** And for the *tsara'at* of a garment, and for a house,

**14:56** And for a swelling, and for a scab, and for a bright spot;

**14:57** To teach when it is unclean, and when it is clean—לְהוֹרֹת בְּיוֹם הַטָּמֵא וּבְיוֹם הַטָּהוֹר (le-horot be-yom ha-tame u-ve-yom ha-tahor): this is the law of *tsara'at*.

---

## Synthesis Notes

**Key Restorations:**

**The Two Birds Ritual:**
The first stage of cleansing takes place outside the camp:
- Two clean birds, cedar wood, scarlet yarn, hyssop
- One bird killed over living water in an earthen vessel
- The living bird, cedar, scarlet, and hyssop dipped in the blood
- The healed person sprinkled seven times
- The living bird released into the open field

This ritual is unique. The released bird carries away the impurity—a sending-away rite similar to the scapegoat (chapter 16).

**Symbolism of the Elements:**
- **Cedar**: durable, aromatic wood
- **Scarlet**: red dye, associated with blood/life
- **Hyssop**: cleansing herb (used in Passover, Psalm 51:7)
- **Living water** (*mayim chayyim*): flowing, not stagnant—water of life
- **Living bird**: carries the impurity away

**The Eight-Day Process:**

After the bird ritual:
- Day 1: Shave all hair, wash clothes, bathe—enter the camp but stay outside tent
- Day 7: Shave again (head, beard, eyebrows—all hair), wash, bathe
- Day 8: Bring offerings to the sanctuary

**Blood and Oil on Ear, Thumb, Toe:**
The guilt offering's blood, then oil, is applied to:
- Right ear
- Right thumb
- Right great toe

This is the same pattern as priestly ordination (8:23-24). The healed *metsora* is being **re-ordained** into community life. The whole person (hearing, working, walking) is reconsecrated.

**The Offerings:**
- Guilt offering (*asham*): lamb
- Sin offering (*chattat*): lamb (or bird for the poor)
- Burnt offering (*olah*): lamb (or bird for the poor)
- Grain offering (*minchah*): fine flour with oil

**Provision for the Poor:**
The poor bring one lamb (for the guilt offering—this cannot be reduced) plus two birds instead of two additional lambs. Access to cleansing is not determined by wealth.

**Tsara'at in Houses:**
When Israel enters Canaan, houses can be afflicted:
- Greenish or reddish depressions in walls
- Priest examines, quarantines seven days
- If spreading: remove affected stones, scrape, replaster
- If recurring after repair: demolish the house
- Cleansed house: two-bird ritual as for persons

**"I Put the Plague":**
Remarkable: "I put the plague of *tsara'at* in a house" (14:34). YHWH takes responsibility for the affliction. This is not random misfortune but divine action—requiring attention and response.

**Archetypal Layer:** The two-bird ritual is **death and life split**. One bird dies; one carries away impurity to the open field. The healed person is sprinkled with the blood of the dead bird and symbolically released like the living bird. Death enables new life.

The blood and oil on ear, thumb, toe represent **re-creation of the whole person**—the same anointing as priestly ordination. The healed *metsora* is not merely restored but reconstituted.

**Psychological Reading:** The elaborate process marks the transition from social death back to community life. The shaving removes the old; the offerings establish the new relationship. The seven-day interim (inside camp but outside tent) is liminal—between exclusion and full restoration.

**Ethical Inversion Applied:**
- Healing is possible—the affliction is not permanent
- Elaborate ritual marks genuine restoration—reintegration is serious
- The poor are accommodated—full cleansing regardless of means
- Houses can be healed or must be destroyed—the same diagnostic process applies
- YHWH puts the plague—divine action invites human response

**Modern Equivalent:** Reintegration after serious illness or social exclusion requires process—not instant return but staged restoration. The ritual acknowledges what has happened and marks genuine change. The provision for the poor ensures that economic status does not determine access to restoration.

# Leviticus Chapter 21: Regulations for Priests

*From the Hebrew: קְדֻשַּׁת כֹּהֲנִים (Kedushat Kohanim) — Holiness of the Priests*

---

**21:1** And YHWH said unto Moses: "Speak unto the priests the sons of Aaron, and say unto them: 'None shall defile himself for the dead among his people,

**21:2** "'Except for his kin, who is near unto him: for his mother, and for his father, and for his son, and for his daughter, and for his brother,

**21:3** "'And for his virgin sister, who is near unto him, who has had no husband, for her he may defile himself.

**21:4** "'He shall not defile himself, being a chief man among his people, to profane himself.

**21:5** "'They shall not make baldness upon their head, neither shall they shave off the corner of their beard, nor make any cuttings in their flesh.

**21:6** "'They shall be holy unto their Consciousness, and not profane the name of their Consciousness; for the fire offerings of YHWH, the bread of their Consciousness, they offer; therefore they shall be holy.

**21:7** "'They shall not take a woman who is a harlot or profaned; neither shall they take a woman divorced from her husband; for he is holy unto his Consciousness.

**21:8** "'You shall sanctify him therefore; for he offers the bread of your Consciousness; he shall be holy unto you; for I YHWH, who sanctify you, am holy.

**21:9** "'And the daughter of any priest, if she profanes herself by playing the harlot, she profanes her father; she shall be burned with fire.

---

**21:10** "'And the priest who is highest among his brothers—הַכֹּהֵן הַגָּדוֹל (ha-kohen ha-gadol)—upon whose head the anointing oil is poured, and who is consecrated to put on the garments, shall not let the hair of his head go loose, nor rend his clothes.

**21:11** "'Neither shall he go in to any dead body, nor defile himself for his father, or for his mother.

**21:12** "'Neither shall he go out of the sanctuary, nor profane the sanctuary of his Consciousness; for the crown of the anointing oil of his Consciousness is upon him: I am YHWH.

**21:13** "'And he shall take a wife in her virginity.

**21:14** "'A widow, or a divorced woman, or a profaned woman, or a harlot, these he shall not take; but a virgin of his own people shall he take as wife.

**21:15** "'And he shall not profane his offspring among his people; for I am YHWH who sanctifies him.'"

---

**21:16** And YHWH spoke unto Moses, saying:

**21:17** "Speak unto Aaron, saying: 'Whoever of your offspring throughout their generations who has a blemish—מוּם (mum)—shall not approach to offer the bread of his Consciousness.

**21:18** "'For whatever man has a blemish, he shall not approach: a blind man, or a lame, or one who has a flat nose, or anything superfluous,

**21:19** "'Or a man who has a broken foot, or a broken hand,

**21:20** "'Or crook-backed, or a dwarf, or who has a blemish in his eye, or is scabbed, or scurvy, or has his stones crushed—

**21:21** "'No man of the offspring of Aaron the priest, who has a blemish, shall come near to offer the fire offerings of YHWH; he has a blemish; he shall not come near to offer the bread of his Consciousness.

**21:22** "'He may eat the bread of his Consciousness, both of the most holy, and of the holy.

**21:23** "'Only he shall not go in unto the veil, nor come near unto the altar, because he has a blemish; that he not profane my sanctuaries; for I am YHWH who sanctifies them.'"

**21:24** So Moses spoke unto Aaron, and to his sons, and unto all the children of Israel.

---

## Synthesis Notes

**Key Restorations:**

**Priestly Holiness:**
Priests are held to higher standards than ordinary Israelites. Their proximity to the sanctuary and handling of sacred things requires stricter observance.

**Contact with the Dead:**
Ordinary priests may defile themselves for immediate family only:
- Mother, father
- Son, daughter
- Brother
- Virgin sister

They may not mourn for extended relatives or non-family. The high priest may not defile himself even for father or mother. His consecration is absolute.

**Mourning Practices Forbidden:**
- No baldness on the head
- No shaving the corners of the beard
- No cuttings in the flesh

These were pagan mourning customs. Priests must not adopt them.

**Marriage Restrictions:**

Ordinary priests may not marry:
- A harlot
- A profaned woman (one who has been sexually compromised)
- A divorced woman

The high priest may only marry a virgin from his own people. The restriction is more severe for the high priest.

**"The High Priest" (הַכֹּהֵן הַגָּדוֹל):**
*Ha-kohen ha-gadol*—the first use of this term in Leviticus. He is "highest among his brothers," anointed with oil, wearing the special garments. His holiness requirements are maximal.

**Physical Blemishes:**
Priests with physical defects may not officiate at the altar:
- Blindness
- Lameness
- Facial deformity
- Extra or missing limbs
- Broken bones
- Hunchback
- Dwarfism
- Eye defects
- Skin diseases
- Crushed testicles

They remain priests and may eat the priestly portions, but they may not approach the altar or enter beyond the veil.

**The Rationale:**
As the offerings must be "without blemish," so the one who offers them must be without blemish. The physical wholeness symbolizes the spiritual completeness required for sacred service.

**"He May Eat the Bread of His Consciousness":**
The blemished priest is not expelled from the priesthood. He retains his status and his portion. He simply cannot officiate at the altar. His identity is preserved even if his function is limited.

**Archetypal Layer:** The priest's body is a **symbol of the sacred order**. Physical wholeness represents the wholeness required for approaching the holy. The restrictions are symbolic, not statements about human worth.

The high priest's total separation from death (not even for parents) represents **complete dedication to life** as represented by the sanctuary.

**Psychological Reading:** The blemished priest's continued participation (eating the sacred portions) but restricted function (not officiating) represents a nuanced approach. Identity is not reduced to function. The person is valued even if their role is limited.

**Ethical Inversion Applied:**
- Higher status = stricter requirements—proximity to the holy demands more
- The blemished priest retains identity—he is still a priest, still eats sacred food
- The restrictions are symbolic—physical wholeness represents spiritual wholeness
- Marriage restrictions protect priestly families' integrity
- The high priest's separation from death is maximal—completely dedicated to the sanctuary of life

**Difficult Elements:**
The exclusion of those with physical disabilities from altar service is problematic by modern standards. The text reflects ancient symbolic associations between physical wholeness and ritual fitness. The principle of inclusion (the blemished priest still eats, still belongs) mitigates but does not eliminate the difficulty.

**Modern Equivalent:** While physical requirements for religious leaders are no longer applied literally, the principle that those who serve in sacred functions are held to higher standards remains. The distinction between identity (who you are) and function (what you do) is valuable—limitation in one area doesn't negate belonging in another.

# Numbers Chapter 13: The Twelve Spies

*From the Hebrew: שְׁלַח־לְךָ (Shelach-Lecha) — Send for Yourself*

---

**13:1** And YHWH spoke unto Moses, saying:

**13:2** "Send men, that they may spy out the land of Canaan, which I give unto the children of Israel; of every tribe of their fathers you shall send a man, every one a prince among them."

**13:3** And Moses sent them from the wilderness of Paran according to the commandment of YHWH; all of them men who were heads of the children of Israel.

**13:4** And these were their names: of the tribe of Reuben, Shammua the son of Zaccur.

**13:5** Of the tribe of Simeon, Shaphat the son of Hori.

**13:6** Of the tribe of Judah, Caleb the son of Jephunneh.

**13:7** Of the tribe of Issachar, Igal the son of Joseph.

**13:8** Of the tribe of Ephraim, Hoshea the son of Nun.

**13:9** Of the tribe of Benjamin, Palti the son of Raphu.

**13:10** Of the tribe of Zebulun, Gaddiel the son of Sodi.

**13:11** Of the tribe of Joseph, of the tribe of Manasseh, Gaddi the son of Susi.

**13:12** Of the tribe of Dan, Ammiel the son of Gemalli.

**13:13** Of the tribe of Asher, Sethur the son of Michael.

**13:14** Of the tribe of Naphtali, Nahbi the son of Vophsi.

**13:15** Of the tribe of Gad, Geuel the son of Machi.

**13:16** These are the names of the men whom Moses sent to spy out the land. And Moses called Hoshea the son of Nun, Joshua—יְהוֹשֻׁעַ (Yehoshua).

---

**13:17** And Moses sent them to spy out the land of Canaan, and said unto them: "Go up this way by the South—הַנֶּגֶב (ha-Negev)—and go up into the hill-country.

**13:18** "And see the land, what it is; and the people who dwell in it, whether they are strong or weak, whether they are few or many;

**13:19** "And what the land is that they dwell in, whether it is good or bad; and what cities they are that they dwell in, whether in camps or in strongholds;

**13:20** "And what the land is, whether it is fat or lean, whether there is wood in it, or not. And be of good courage, and bring of the fruit of the land." Now the time was the time of the first-ripe grapes.

**13:21** So they went up, and spied out the land from the wilderness of Zin unto Rehob, at the entrance to Hamath.

**13:22** And they went up by the South, and came unto Hebron; and Ahiman, Sheshai, and Talmai, the children of Anak, were there. Now Hebron was built seven years before Zoan in Egypt.

**13:23** And they came unto the valley of Eshcol—נַחַל אֶשְׁכֹּל (Nachal Eshkol)—and cut down from there a branch with one cluster of grapes, and they carried it upon a pole between two; they took also of the pomegranates, and of the figs.

**13:24** That place was called the valley of Eshcol—עֵמֶק אֶשְׁכֹּל (Emeq Eshkol)—because of the cluster which the children of Israel cut down from there.

**13:25** And they returned from spying out the land at the end of forty days.

---

**13:26** And they went and came to Moses, and to Aaron, and to all the congregation of the children of Israel, unto the wilderness of Paran, to Kadesh; and brought back word unto them, and unto all the congregation, and showed them the fruit of the land.

**13:27** And they told him, and said: "We came unto the land where you sent us, and surely it flows with milk and honey—זָבַת חָלָב וּדְבַשׁ (zavat chalav u-devash)—and this is the fruit of it.

**13:28** "However, the people who dwell in the land are fierce, and the cities are fortified and very great; and moreover we saw the children of Anak there.

**13:29** "Amalek dwells in the land of the South; and the Hittite, and the Jebusite, and the Amorite, dwell in the hill-country; and the Canaanite dwells by the sea, and along the Jordan."

**13:30** And Caleb stilled the people before Moses, and said: "We should go up at once, and possess it; for we are well able to overcome it."

**13:31** But the men who went up with him said: "We are not able to go up against the people; for they are stronger than we."

**13:32** And they brought up an evil report—דִּבָּה (dibbah)—of the land which they had spied out unto the children of Israel, saying: "The land, through which we have passed to spy it out, is a land that eats up its inhabitants; and all the people that we saw in it are men of great stature.

**13:33** "And there we saw the Nephilim—הַנְּפִילִים (ha-Nephilim)—the sons of Anak, who come of the Nephilim; and we were in our own sight as grasshoppers, and so we were in their sight."

---

## Synthesis Notes

**Key Restorations:**

**The Mission:**
Twelve spies, one from each tribe—all princes, tribal leaders. They are to reconnoiter Canaan:
- The people (strong/weak, few/many)
- The land (good/bad, fertile/barren)
- The cities (camps/fortresses)

**Hoshea Becomes Joshua:**
Moses renames Hoshea (הוֹשֵׁעַ, "salvation") to Yehoshua (יְהוֹשֻׁעַ, "YHWH saves"). The addition of the divine name marks his calling. This is the future successor to Moses.

**The Route:**
From the Negev north through the hill country to Hebron, then to the valley of Eshcol, and as far as Rehob near Hamath (the northern extent of the promised land). They traverse the full length.

**Forty Days:**
The spying takes forty days—one day for each year they will wander (14:34).

**The Fruit:**
A single cluster of grapes so large it requires two men to carry on a pole. Pomegranates and figs. The land's fertility is visually demonstrated.

**The Children of Anak (בְּנֵי עֲנָק):**
The Anakim—a people of great stature. Ahiman, Sheshai, and Talmai are named. Hebron is their territory. The spies are intimidated.

**The Report:**

All twelve agree: the land is good, flowing with milk and honey.

But then the majority (ten) and minority (two) diverge:

**The Ten:**
- "The people are fierce"
- "Cities are fortified and very great"
- "We saw the children of Anak"
- "We are not able to go up"
- "The land eats up its inhabitants"
- "We saw the Nephilim"
- "We were as grasshoppers in our own sight"

**Caleb (and Joshua, 14:6):**
- "We should go up at once"
- "We are well able to overcome it"

**The "Evil Report" (דִּבָּה, dibbah):**
The ten bring a *dibbah*—a discouraging, slanderous report. The factual information (large people, fortified cities) becomes distorted: "the land eats up its inhabitants." The interpretation is designed to demoralize.

**The Nephilim:**
The same term from Genesis 6:4—the giants of pre-flood days. Whether literal descendants or rhetorical exaggeration, the effect is to make conquest seem impossible.

**"Grasshoppers in Our Own Sight":**
The fatal phrase. Before they report what the giants thought, they report their own self-perception: "We were in our own sight as grasshoppers." The failure is first internal. They see themselves as small before they are seen that way.

**Archetypal Layer:** The spying mission is the **test of faith at the threshold**. The land is everything promised—fertile, abundant—but inhabited by formidable peoples. The question: will Israel trust YHWH's promise or their own assessment?

The Nephilim represent **primal fear**—the monsters of legend, the overwhelming obstacle. The grasshopper self-image reveals **failure of identity**: they forgot who they were (YHWH's redeemed people) and saw only their weakness.

**Psychological Reading:** The ten spies project their fear onto reality. The land doesn't actually "eat its inhabitants"—but fear makes it seem so. The self-assessment as grasshoppers precedes any external evaluation. What we believe about ourselves shapes what we perceive.

Caleb's confidence is not denial of the facts but different interpretation: "We are well able." Same data, different conclusion—faith versus fear.

**Ethical Inversion Applied:**
- The land is good—the promise is confirmed
- The obstacles are real—fortified cities, large peoples
- Fear distorts perception—the land becomes monstrous
- Self-image precedes external reality—grasshoppers in their own sight first
- Caleb's minority report—faith sees differently
- The evil report is contagious—dibbah spreads despair

**Modern Equivalent:** Reconnaissance missions often produce conflicting reports depending on the interpreter's perspective. The grasshopper self-image warns: internal beliefs shape external perceptions. And the majority report is not always right—sometimes the minority (Caleb, Joshua) sees more clearly because they interpret through faith rather than fear.

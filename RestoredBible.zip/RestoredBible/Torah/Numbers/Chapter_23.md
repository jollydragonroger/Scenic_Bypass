# Numbers Chapter 23: Balaam's First Two Oracles

*From the Hebrew: מָשָׁל (Mashal) — The Prophetic Utterances*

---

**23:1** And Balaam said unto Balak: "Build me here seven altars, and prepare me here seven bulls and seven rams."

**23:2** And Balak did as Balaam spoke; and Balak and Balaam offered on every altar a bull and a ram.

**23:3** And Balaam said unto Balak: "Stand by your burnt offering, and I will go; perhaps YHWH will come to meet me; and whatever he shows me I will tell you." And he went to a bare height.

**23:4** And God met Balaam; and he said unto him: "I have prepared the seven altars, and I have offered up a bull and a ram on every altar."

**23:5** And YHWH put a word in Balaam's mouth, and said: "Return unto Balak, and thus you shall speak."

**23:6** And he returned unto him, and lo, he stood by his burnt offering, he, and all the princes of Moab.

**23:7** And he took up his parable—מְשָׁלוֹ (meshalo)—and said:

"From Aram Balak brings me,
The king of Moab from the mountains of the east:
'Come, curse me Jacob,
And come, execrate Israel.'

**23:8** "How shall I curse, whom God has not cursed?
And how shall I execrate, whom YHWH has not execrated?

**23:9** "For from the top of the rocks I see him,
And from the hills I behold him:
Lo, it is a people that dwells alone,
And shall not be reckoned among the nations—לֹא יִתְחַשָּׁב בַּגּוֹיִם (lo yitchashav ba-goyim).

**23:10** "Who can count the dust of Jacob,
Or number the fourth part of Israel?
Let me die the death of the righteous—יְשָׁרִים (yesharim),
And let my end be like his!"

---

**23:11** And Balak said unto Balaam: "What have you done unto me? I took you to curse my enemies, and behold, you have blessed them altogether."

**23:12** And he answered and said: "Must I not take heed to speak that which YHWH puts in my mouth?"

**23:13** And Balak said unto him: "Come, I pray, with me unto another place, from which you may see them; you shall see but the utmost part of them, and shall not see them all; and curse me them from there."

**23:14** And he took him into the field of Zophim, to the top of Pisgah, and built seven altars, and offered up a bull and a ram on every altar.

**23:15** And he said unto Balak: "Stand here by your burnt offering, while I go to meet yonder."

**23:16** And YHWH met Balaam, and put a word in his mouth, and said: "Return unto Balak, and thus shall you speak."

**23:17** And he came to him, and behold, he stood by his burnt offering, and the princes of Moab with him. And Balak said unto him: "What has YHWH spoken?"

**23:18** And he took up his parable, and said:

"Rise up, Balak, and hear;
Give ear unto me, you son of Zippor.

**23:19** "God is not a man, that he should lie—לֹא אִישׁ אֵל וִיכַזֵּב (lo ish El vi-chazzev),
Neither the son of man, that he should repent;
Has he said, and shall he not do it?
Or has he spoken, and shall he not make it good?

**23:20** "Behold, I have received commandment to bless;
And he has blessed, and I cannot reverse it.

**23:21** "He has not beheld iniquity in Jacob,
Neither has he seen perverseness in Israel;
YHWH his God is with him,
And the shout of a king is among them.

**23:22** "God brings them forth out of Egypt;
He has as it were the strength of the wild ox—תּוֹעֲפֹת רְאֵם (to'afot re'em).

**23:23** "For there is no enchantment against Jacob,
Neither is there any divination against Israel—לֹא־נַחַשׁ בְּיַעֲקֹב וְלֹא־קֶסֶם בְּיִשְׂרָאֵל;
Now is it said of Jacob and of Israel:
'What has God wrought!'

**23:24** "Behold, a people that rises up as a lioness,
And as a lion lifts himself up;
He shall not lie down until he eats of the prey,
And drinks the blood of the slain."

---

**23:25** And Balak said unto Balaam: "Neither curse them at all, nor bless them at all."

**23:26** But Balaam answered and said unto Balak: "Did I not tell you, saying: 'All that YHWH speaks, that I must do'?"

**23:27** And Balak said unto Balaam: "Come now, I will take you unto another place; perhaps it will please God that you may curse me them from there."

**23:28** And Balak took Balaam unto the top of Peor, that looks toward the desert.

**23:29** And Balaam said unto Balak: "Build me here seven altars, and prepare me here seven bulls and seven rams."

**23:30** And Balak did as Balaam said, and offered up a bull and a ram on every altar.

---

## Synthesis Notes

**Key Restorations:**

**The Sevenfold Sacrifice:**
Seven altars, seven bulls, seven rams. This elaborate preparation is designed to invoke divine favor. Balaam goes apart to receive revelation while Balak waits by the offerings.

**The First Oracle (23:7-10):**

Key themes:
- **Balaam cannot curse what God has not cursed**—his power is derivative
- **Israel dwells alone**—distinct among nations, not reckoned with them
- **Uncountable as dust**—fulfillment of Abrahamic promise (Genesis 13:16)
- **"Let me die the death of the righteous"**—Balaam desires Israel's blessed end

**"A People That Dwells Alone":**
*Am levadad yishkon* (עַם לְבָדָד יִשְׁכֹּן)—Israel's distinctiveness is blessing, not curse. This phrase has become a touchstone of Jewish identity: set apart, not assimilated.

**Balak's Protest:**
"I took you to curse my enemies, and behold, you have blessed them altogether!" The hired curser has become an involuntary blesser.

**Change of Location:**
Balak tries a new vantage point—perhaps partial visibility will enable partial curse. The field of Zophim ("watchers") on Mount Pisgah. Same ritual: seven altars, seven bulls, seven rams.

**The Second Oracle (23:18-24):**

Key themes:
- **God is not a man that he should lie**—divine faithfulness is absolute
- **"He has blessed, and I cannot reverse it"**—the blessing is irrevocable
- **No iniquity seen in Jacob**—YHWH chooses not to see their sin
- **The shout of a king among them**—Israel has royal destiny
- **Strength of the wild ox**—untameable power
- **No enchantment or divination against Israel**—Balaam's profession is useless
- **Lion imagery**—predator, not prey

**"God Is Not a Man" (לֹא אִישׁ אֵל):**
A foundational theological statement. YHWH does not lie, does not change his mind capriciously, does not fail to fulfill what he has spoken. Human unreliability cannot be projected onto God.

**"No Enchantment Against Jacob":**
*Lo nachash be-Ya'aqov*—the very arts Balaam practices have no power against Israel. This is the irony: Balaam declares his own profession impotent against this people.

**"What Has God Wrought!":**
*Mah pa'al El*—an exclamation of wonder at divine action. This phrase was famously used as the first telegraph message in 1844.

**Balak's Frustration:**
"Neither curse them at all, nor bless them at all." He would settle for silence. But Balaam cannot remain silent—he must speak what YHWH gives.

**Third Attempt:**
Balak tries yet another location: the top of Peor, overlooking the desert. Same preparation: seven altars, seven bulls, seven rams. The pattern will repeat.

**Archetypal Layer:** Balaam's oracles reveal the **futility of opposing what God has blessed**. The professional curser becomes an unwilling witness to Israel's election. Each attempt to curse produces greater blessing.

The imagery escalates: dust (uncountable), lion (predator), wild ox (untameable). Israel is described in terms of power, not vulnerability.

**Psychological Reading:** Balak's strategy—change location, try again—reflects the human tendency to believe that circumstances can alter divine decree. The repeated failure demonstrates that YHWH's word is not location-dependent.

Balaam's position is conflicted: he desires the reward but cannot speak against YHWH's word. His final "let me die the death of the righteous" suggests he admires what he cannot join.

**Ethical Inversion Applied:**
- The hired curser blesses—profession cannot override YHWH
- God is not a man—divine faithfulness exceeds human fickleness
- Israel dwells alone—distinctiveness is destiny
- No enchantment against Jacob—occult powers are impotent
- The lion rises—Israel as predator, not prey

**Modern Equivalent:** When external forces attempt to curse what God has blessed, the curse rebounds as blessing. The "dwelling alone" quality can be burden or gift—isolation or distinction. And the principle that God's word cannot be bought or manipulated applies to all attempts to use religion for hire.

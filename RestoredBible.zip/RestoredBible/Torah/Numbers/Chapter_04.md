# Numbers Chapter 4: The Levitical Service Duties

*From the Hebrew: עֲבֹדַת הַלְוִיִּם (Avodat HaLeviyyim) — The Work of the Levites*

---

**4:1** And YHWH spoke unto Moses and unto Aaron, saying:

**4:2** "Take the census of the sons of Kohath from among the sons of Levi, by their families, by their fathers' houses,

**4:3** "From thirty years old and upward until fifty years old, all who enter the service—לִצְבָא (la-tsava)—to do the work in the tent of meeting.

**4:4** "This is the service of the sons of Kohath in the tent of meeting: the most holy things—קֹדֶשׁ הַקֳּדָשִׁים (qodesh ha-qodashim).

**4:5** "When the camp sets forward, Aaron and his sons shall come, and they shall take down the veil of the screen, and cover the ark of the testimony with it.

**4:6** "And they shall put upon it a covering of porpoise skin, and shall spread over it a cloth all of blue, and shall set in place its poles.

**4:7** "And upon the table of the showbread they shall spread a cloth of blue, and put upon it the dishes, and the spoons, and the bowls, and the jars for the pouring; and the continual bread shall be upon it.

**4:8** "And they shall spread upon them a cloth of scarlet, and cover that with a covering of porpoise skin, and shall set in place its poles.

**4:9** "And they shall take a cloth of blue, and cover the lampstand of the light, and its lamps, and its tongs, and its trays, and all its oil vessels, with which they minister unto it.

**4:10** "And they shall put it and all its vessels within a covering of porpoise skin, and shall put it upon the carrying frame.

**4:11** "And upon the golden altar they shall spread a cloth of blue, and cover it with a covering of porpoise skin, and shall set in place its poles.

**4:12** "And they shall take all the vessels of ministry, with which they minister in the sanctuary, and put them in a cloth of blue, and cover them with a covering of porpoise skin, and shall put them on the carrying frame.

**4:13** "And they shall take away the ashes from the altar, and spread a purple cloth upon it.

**4:14** "And they shall put upon it all its vessels, with which they minister about it: the firepans, the forks, and the shovels, and the basins, all the vessels of the altar; and they shall spread upon it a covering of porpoise skin, and set in place its poles.

**4:15** "And when Aaron and his sons have finished covering the sanctuary, and all the vessels of the sanctuary, when the camp is to set forward, after that the sons of Kohath shall come to carry them; but they shall not touch the holy things, lest they die—וְלֹא־יִגְּעוּ אֶל־הַקֹּדֶשׁ וָמֵתוּ (ve-lo yigg'u el-ha-qodesh va-metu). These are the burden of the sons of Kohath in the tent of meeting.

**4:16** "And the charge of Eleazar the son of Aaron the priest shall be the oil for the light, and the fragrant incense, and the continual grain offering, and the anointing oil: the charge of all the tabernacle, and of all that is in it, in the sanctuary, and in its vessels."

---

**4:17** And YHWH spoke unto Moses and unto Aaron, saying:

**4:18** "Do not cut off the tribe of the families of the Kohathites from among the Levites.

**4:19** "But thus do unto them, that they may live, and not die, when they approach unto the most holy things: Aaron and his sons shall go in, and appoint them every one to his service and to his burden;

**4:20** "But they shall not go in to see the holy things even for a moment—כְּבַלַּע (ke-valla)—lest they die."

---

**4:21** And YHWH spoke unto Moses, saying:

**4:22** "Take the census of the sons of Gershon also, by their fathers' houses, by their families;

**4:23** "From thirty years old and upward until fifty years old you shall number them, all who enter in to perform the service, to do the work in the tent of meeting.

**4:24** "This is the service of the families of the Gershonites, in serving and in carrying:

**4:25** "They shall carry the curtains of the tabernacle, and the tent of meeting, its covering, and the covering of porpoise skin that is above upon it, and the screen for the door of the tent of meeting,

**4:26** "And the hangings of the court, and the screen for the door of the gate of the court, which is by the tabernacle and by the altar round about, and their cords, and all the vessels of their service, and whatsoever shall be done with them; so shall they serve.

**4:27** "At the commandment of Aaron and his sons shall be all the service of the sons of the Gershonites, in all their burden and in all their service; and you shall appoint unto them in charge all their burden.

**4:28** "This is the service of the families of the sons of the Gershonites in the tent of meeting; and their charge shall be under the hand of Ithamar the son of Aaron the priest.

---

**4:29** "As for the sons of Merari, you shall number them by their families, by their fathers' houses;

**4:30** "From thirty years old and upward until fifty years old you shall number them, everyone who enters into the service, to do the work of the tent of meeting.

**4:31** "And this is the charge of their burden, according to all their service in the tent of meeting: the boards of the tabernacle, and its bars, and its pillars, and its sockets,

**4:32** "And the pillars of the court round about, and their sockets, and their pegs, and their cords, with all their instruments, and with all their service; and by name you shall appoint the instruments of the charge of their burden.

**4:33** "This is the service of the families of the sons of Merari, according to all their service in the tent of meeting, under the hand of Ithamar the son of Aaron the priest."

---

**4:34** And Moses and Aaron and the princes of the congregation numbered the sons of the Kohathites by their families, and by their fathers' houses,

**4:35** From thirty years old and upward until fifty years old, everyone who entered into the service, for work in the tent of meeting.

**4:36** And those who were numbered of them by their families were two thousand seven hundred and fifty.

**4:37** These are they who were numbered of the families of the Kohathites, all who served in the tent of meeting, whom Moses and Aaron numbered according to the commandment of YHWH by the hand of Moses.

**4:38** And those who were numbered of the sons of Gershon, by their families, and by their fathers' houses,

**4:39** From thirty years old and upward until fifty years old, everyone who entered into the service, for work in the tent of meeting,

**4:40** Those who were numbered of them, by their families, by their fathers' houses, were two thousand six hundred and thirty.

**4:41** These are they who were numbered of the families of the sons of Gershon, all who served in the tent of meeting, whom Moses and Aaron numbered according to the commandment of YHWH.

**4:42** And those who were numbered of the families of the sons of Merari, by their families, by their fathers' houses,

**4:43** From thirty years old and upward until fifty years old, everyone who entered into the service, for work in the tent of meeting,

**4:44** Those who were numbered of them by their families were three thousand and two hundred.

**4:45** These are they who were numbered of the families of the sons of Merari, whom Moses and Aaron numbered according to the commandment of YHWH by the hand of Moses.

**4:46** All those who were numbered of the Levites, whom Moses and Aaron and the princes of Israel numbered, by their families and by their fathers' houses,

**4:47** From thirty years old and upward until fifty years old, everyone who entered to do the work of service, and the work of carrying in the tent of meeting,

**4:48** Those who were numbered of them were eight thousand five hundred and eighty.

**4:49** According to the commandment of YHWH they were numbered by the hand of Moses, every one according to his service, and according to his burden; thus were they numbered by him, as YHWH commanded Moses.

---

## Synthesis Notes

**Key Restorations:**

**Service Age:**
Levites serve from age 30 to 50—twenty years of active duty. This differs from chapter 3 (one month and up), which counted all Levites. Here only those of service age are counted.

**The Kohathites (4:4-20):**

Responsibility: The most holy things (*qodesh ha-qodashim*)
- Ark of the testimony
- Table of showbread
- Lampstand
- Golden altar (incense)
- Bronze altar
- All vessels of ministry

**Critical restriction:** Kohathites must not touch or see the holy objects uncovered. Aaron and his sons first cover each item:
- Ark: veil + porpoise skin + blue cloth
- Table: blue cloth + items on top + scarlet cloth + porpoise skin
- Lampstand: blue cloth + porpoise skin
- Golden altar: blue cloth + porpoise skin
- Bronze altar: purple cloth + porpoise skin

Only after covering do Kohathites carry them. "They shall not touch the holy things, lest they die."

**"Even for a Moment" (כְּבַלַּע, ke-valla):**
The Kohathites must not see the holy things even for a blink—*ke-valla*, "as a swallowing," a moment so brief. The danger is extreme.

**Eleazar's Charge:**
Aaron's son Eleazar supervises the Kohathites and is personally responsible for:
- Oil for the light
- Fragrant incense
- Continual grain offering
- Anointing oil
- All the sanctuary and its contents

**The Gershonites (4:21-28):**

Responsibility: Fabric and coverings
- Curtains of the tabernacle
- Tent covering
- Porpoise skin covering
- Door screen
- Court hangings
- Gate screen
- Cords

Under the supervision of Ithamar son of Aaron.

**The Merarites (4:29-33):**

Responsibility: Structural elements
- Boards (frames)
- Bars
- Pillars
- Sockets
- Pegs
- Cords

"By name you shall appoint"—each item is assigned to a specific Merarite. Nothing is left to chance. Under Ithamar's supervision.

**The Service Census:**

| Clan | Service-age males |
|------|-------------------|
| Kohath | 2,750 |
| Gershon | 2,630 |
| Merari | 3,200 |
| **Total** | **8,580** |

**Archetypal Layer:** The covering of the holy objects represents the **veiling of the sacred**. The most holy cannot be seen by those who carry it. They transport what they never behold. This is faith—carrying what cannot be directly perceived.

The division of labor (Kohath = sacred furniture, Gershon = fabrics, Merari = structure) represents **specialized service**. Each clan has its expertise.

**Psychological Reading:** The prohibition on seeing "even for a moment" intensifies the sense of the holy. The Kohathites know what they carry by the weight and the covered shape, not by sight. This creates reverence through restraint.

**Ethical Inversion Applied:**
- The holy requires protection—covering preserves both object and carrier
- Priests prepare; Levites carry—role differentiation serves safety
- Age limits (30-50) ensure capability—service has a season
- Every item assigned by name—accountability is specific
- "Lest they die"—the sacred is genuinely dangerous

**Modern Equivalent:** Handling dangerous or precious materials requires specialized training and protective measures. The covering of the holy anticipates protocols for handling hazardous substances. And the age limits (30-50) recognize that some service requires peak capacity.

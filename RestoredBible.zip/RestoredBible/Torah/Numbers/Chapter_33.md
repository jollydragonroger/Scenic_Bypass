# Numbers Chapter 33: The Stages of the Journey

*From the Hebrew: מַסְעֵי (Mas'ei) — The Journeys*

---

**33:1** These are the journeys of the children of Israel, when they went forth out of the land of Egypt by their hosts under the hand of Moses and Aaron.

**33:2** And Moses wrote their goings out according to their journeys by the commandment of YHWH; and these are their journeys according to their goings out.

**33:3** And they journeyed from Rameses in the first month, on the fifteenth day of the first month; on the morrow after the Passover the children of Israel went out with a high hand in the sight of all the Egyptians,

**33:4** While the Egyptians were burying all their firstborn, whom YHWH had smitten among them; upon their gods also YHWH executed judgments.

**33:5-37** [The itinerary lists 42 stations from Rameses to the plains of Moab:]

From Rameses to Succoth to Etham to Pi-hahiroth (before the sea) to the wilderness of Etham (three days through the Red Sea) to Marah to Elim (twelve springs, seventy palms) to the Red Sea to the wilderness of Sin to Dophkah to Alush to Rephidim (no water) to the wilderness of Sinai...

...to Kibroth-hattaavah to Hazeroth to Rithmah to Rimmon-perez to Libnah to Rissah to Kehelathah to Mount Shepher to Haradah to Makheloth to Tahath to Terah to Mithkah to Hashmonah to Moseroth to Bene-jaakan to Hor-haggidgad to Jotbathah to Abronah to Ezion-geber to Kadesh (wilderness of Zin)...

...to Mount Hor (where Aaron died, 40th year, 5th month, 1st day) to Zalmonah to Punon to Oboth to Iye-abarim to Dibon-gad to Almon-diblathaim to the mountains of Abarim before Nebo to the plains of Moab by the Jordan at Jericho.

**33:38** And Aaron the priest went up into Mount Hor at the commandment of YHWH, and died there, in the fortieth year after the children of Israel came out of the land of Egypt, in the fifth month, on the first day of the month.

**33:39** And Aaron was a hundred and twenty-three years old when he died in Mount Hor.

**33:40** And the Canaanite, the king of Arad, who dwelt in the South in the land of Canaan, heard of the coming of the children of Israel.

---

**33:41-49** [The final stations from Mount Hor to the plains of Moab are listed.]

**33:50** And YHWH spoke unto Moses in the plains of Moab by the Jordan at Jericho, saying:

**33:51** "Speak unto the children of Israel, and say unto them: 'When you pass over the Jordan into the land of Canaan,

**33:52** "'Then you shall drive out all the inhabitants of the land from before you, and destroy all their figured stones, and destroy all their molten images, and demolish all their high places.

**33:53** "'And you shall take possession of the land, and dwell therein; for unto you have I given the land to possess it.

**33:54** "'And you shall inherit the land by lot according to your families: to the more you shall give the more inheritance, and to the fewer you shall give the less inheritance; wherever the lot falls to any man, that shall be his; according to the tribes of your fathers you shall inherit.

**33:55** "'But if you do not drive out the inhabitants of the land from before you, then those whom you let remain of them shall be as pricks in your eyes, and as thorns in your sides, and they shall harass you in the land wherein you dwell.

**33:56** "'And it shall come to pass, that as I thought to do unto them, so will I do unto you.'"

---

## Synthesis Notes

**Key Restorations:**

**The Record:**
"Moses wrote their goings out according to their journeys by the commandment of YHWH." This is divinely commanded record-keeping. The itinerary is sacred history, preserved by Moses' own hand.

**Forty-Two Stations:**
From Rameses to the plains of Moab, 42 encampment sites are listed. This creates a journey map of the wilderness period. Some locations are otherwise unknown; others are significant (Sinai, Kadesh, Mount Hor).

**The Exodus Moment:**
"On the morrow after the Passover the children of Israel went out with a high hand"—*be-yad ramah*, confidently, boldly. The Egyptians were burying their firstborn while Israel departed. YHWH's judgment on Egypt's gods is noted.

**Aaron's Death:**
The itinerary pauses to record: Aaron died on Mount Hor on the first day of the fifth month of the fortieth year. He was 123 years old. The date is precise; the moment is marked.

**The Command for Conquest:**

Upon crossing the Jordan:
1. **Drive out the inhabitants**
2. **Destroy their religious objects**: figured stones (*maskiyot*), molten images, high places (*bamot*)
3. **Possess the land**—it is given by YHWH
4. **Distribute by lot**—larger tribes get larger portions

**The Warning:**
"If you do not drive out the inhabitants... they shall be as pricks in your eyes, and as thorns in your sides." Incomplete conquest leads to ongoing harassment.

**The Reversal:**
"As I thought to do unto them, so will I do unto you." The judgment intended for Canaan's inhabitants will fall on Israel if they fail to complete the conquest and instead adopt Canaanite practices.

**Archetypal Layer:** The itinerary represents **remembered journey**. Each station is a marker of divine guidance. The forty-two stops create a sacred geography of wilderness experience.

The command to destroy religious images and high places addresses **the danger of syncretism**. Leaving the inhabitants means leaving their religion; leaving their religion means eventual adoption.

**Psychological Reading:** The detailed itinerary creates collective memory. Future generations can trace the journey: "our ancestors camped here, then here, then here." The geography carries the narrative.

The warning about "pricks in your eyes and thorns in your sides" uses vivid physical imagery for ongoing irritation. Incomplete action leads to persistent discomfort.

**Ethical Inversion Applied:**
- Moses wrote by divine command—record-keeping is sacred duty
- Forty-two stations—the journey is mapped and remembered
- Drive out and destroy idolatry—religious purity requires decisive action
- Distribution by lot—divine selection of territory
- Incomplete obedience brings judgment—what was meant for Canaan falls on Israel

**Difficult Elements:**
The command to drive out inhabitants and destroy all religious sites is a mandate for what modern terms would call ethnic cleansing and cultural destruction. The text presents this as necessary for Israel's religious survival. The ethical challenge remains: how do we read such texts today?

**Modern Equivalent:** The principle that incomplete transformation leads to ongoing problems applies in many contexts. The "thorns and pricks" of unaddressed issues continue to irritate. And the warning that failure to complete the task brings the task's consequences onto oneself suggests accountability for incomplete obedience.

# Numbers Chapter 8: The Lampstand and Levite Consecration

*From the Hebrew: בְּהַעֲלֹתְךָ (Beha'alotecha) — When You Light*

---

**8:1** And YHWH spoke unto Moses, saying:

**8:2** "Speak unto Aaron, and say unto him: 'When you light the lamps—בְּהַעֲלֹתְךָ אֶת־הַנֵּרֹת (beha'alotecha et-ha-nerot)—the seven lamps shall give light in front of the lampstand.'"

**8:3** And Aaron did so: he lighted its lamps in front of the lampstand, as YHWH commanded Moses.

**8:4** And this was the workmanship of the lampstand: beaten work of gold, from its base to its flowers it was beaten work; according to the pattern which YHWH had shown Moses, so he made the lampstand.

---

**8:5** And YHWH spoke unto Moses, saying:

**8:6** "Take the Levites from among the children of Israel, and cleanse them.

**8:7** "And thus shall you do unto them, to cleanse them: sprinkle the water of purification—מֵי חַטָּאת (mei chattat)—upon them, and let them cause a razor to pass over all their flesh, and let them wash their clothes, and cleanse themselves.

**8:8** "Then let them take a young bull, and its grain offering of fine flour mixed with oil; and another young bull you shall take for a sin offering.

**8:9** "And you shall bring the Levites before the tent of meeting; and you shall assemble the whole congregation of the children of Israel.

**8:10** "And you shall bring the Levites before YHWH; and the children of Israel shall lay their hands upon the Levites.

**8:11** "And Aaron shall offer the Levites before YHWH as a wave offering—תְּנוּפָה (tenufah)—from the children of Israel, that they may be to do the service of YHWH.

**8:12** "And the Levites shall lay their hands upon the heads of the bulls; and you shall offer the one for a sin offering, and the other for a burnt offering, unto YHWH, to make atonement for the Levites.

**8:13** "And you shall set the Levites before Aaron and before his sons, and offer them as a wave offering unto YHWH.

**8:14** "Thus shall you separate the Levites from among the children of Israel; and the Levites shall be mine.

**8:15** "And after that shall the Levites go in to do the service of the tent of meeting; and you shall cleanse them, and offer them as a wave offering.

**8:16** "For they are wholly given unto me from among the children of Israel; instead of all who open the womb, the firstborn of all the children of Israel, I have taken them unto me.

**8:17** "For all the firstborn among the children of Israel are mine, both man and beast; on the day that I smote all the firstborn in the land of Egypt I sanctified them for myself.

**8:18** "And I have taken the Levites instead of all the firstborn among the children of Israel.

**8:19** "And I have given the Levites as a gift—נְתֻנִים (netunim)—to Aaron and to his sons from among the children of Israel, to do the service of the children of Israel in the tent of meeting, and to make atonement for the children of Israel, that there be no plague among the children of Israel, when the children of Israel come near unto the sanctuary."

**8:20** Thus did Moses, and Aaron, and all the congregation of the children of Israel, unto the Levites; according unto all that YHWH commanded Moses concerning the Levites, so did the children of Israel unto them.

**8:21** And the Levites purified themselves, and they washed their clothes; and Aaron offered them as a wave offering before YHWH; and Aaron made atonement for them to cleanse them.

**8:22** And after that the Levites went in to do their service in the tent of meeting before Aaron, and before his sons; as YHWH had commanded Moses concerning the Levites, so did they unto them.

---

**8:23** And YHWH spoke unto Moses, saying:

**8:24** "This is that which pertains unto the Levites: from twenty-five years old and upward they shall go in to perform the service in the work of the tent of meeting.

**8:25** "And from the age of fifty years they shall retire from the service of the work, and shall serve no more.

**8:26** "But they shall minister with their brothers in the tent of meeting, to keep the charge, but they shall do no service. Thus shall you do unto the Levites concerning their charges."

---

## Synthesis Notes

**Key Restorations:**

**The Menorah (8:1-4):**
Aaron lights the seven lamps so they shine "in front of the lampstand"—toward the table of showbread, illuminating the holy place. The lampstand is described as "beaten work"—hammered from a single talent of gold, made according to the pattern shown to Moses.

**Levite Consecration (8:5-22):**

The purification ritual:

1. **Sprinkle water of purification** (*mei chattat*)—water mixed with ashes of the red heifer (Numbers 19)
2. **Shave entire body**—removal of all hair
3. **Wash clothes**—purification of garments
4. **Two bulls**—one for sin offering, one for burnt offering

The communal act:

5. **The whole congregation assembles**
6. **Israel lays hands on the Levites**—the nation transfers its obligation to the Levites
7. **Aaron waves the Levites** as a wave offering—the Levites themselves are the offering
8. **The Levites lay hands on the bulls**—transferring their own need for atonement
9. **The bulls are offered**—atonement made for the Levites

**"Waved as a Wave Offering":**
The Levites are symbolically "waved" before YHWH—presented, dedicated, offered. This is unique: human beings presented as a wave offering, representing their complete dedication.

**Israel Lays Hands on Levites:**
The entire congregation participates. The hand-laying transfers the firstborn obligation from all Israel to the Levites. The Levites become Israel's representatives in sanctuary service.

**The Substitution Principle:**
"Instead of all who open the womb... I have taken them." The Levites substitute for Israel's firstborn, who belong to YHWH since the Passover. One tribe serves so that eleven do not have to.

**"Given as a Gift" (נְתֻנִים, netunim):**
The Levites are *netunim*—"given ones." They are given by YHWH to Aaron for service. The word emphasizes their dedicated, assigned status.

**Protective Function:**
"That there be no plague among the children of Israel, when the children of Israel come near unto the sanctuary." The Levites protect Israel from divine wrath. They serve as a buffer—handling what would be dangerous for unauthorized persons.

**Levitical Service Age (8:23-26):**
- Begin at age 25
- Retire from active service at age 50
- After 50, they may assist but not perform the heavy work

Note: Chapter 4 specified ages 30-50 for carrying the tabernacle. The difference may reflect different types of service: 25-30 for training and lighter duties, 30-50 for heavy transport, 50+ for advisory roles.

**Archetypal Layer:** The Levites as wave offering represent **human dedication made visible**. An entire tribe is "waved" before YHWH—not symbolically but as actual persons presented for service. This is corporate consecration.

The hand-laying by all Israel makes the Levites **representatives**: they carry Israel's obligation, stand in Israel's place, bear Israel's risk.

**Psychological Reading:** The ritual creates identity. The Levites are shaved, washed, atoned for, waved, and set apart. The transformation is physical and communal. After the ritual, they are different—consecrated, assigned, responsible.

**Ethical Inversion Applied:**
- The menorah gives light forward—illuminating the sacred space
- Israel participates in Levite consecration—the whole community is involved
- The Levites are the offering—human dedication, not merely animal sacrifice
- Substitution for firstborn—one tribe serves so others are freed
- Age limits protect—heavy service has a season; elders advise

**Modern Equivalent:** The ordination of religious leaders involves community participation (laying on of hands) and ritual actions that mark transition. The age limits (active service 25-50, advisory after) anticipate retirement and emeritus status. And the protective function (buffer between holy and ordinary) models the role of trained mediators in handling dangerous or specialized materials.

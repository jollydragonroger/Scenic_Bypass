# Numbers Chapter 22: Balak Summons Balaam

*From the Hebrew: בָּלָק (Balaq) — The Moabite Fear*

---

**22:1** And the children of Israel journeyed, and encamped in the plains of Moab beyond the Jordan at Jericho.

**22:2** And Balak the son of Zippor saw all that Israel had done to the Amorites.

**22:3** And Moab was sore afraid of the people, because they were many; and Moab was distressed because of the children of Israel.

**22:4** And Moab said unto the elders of Midian: "Now will this multitude lick up all that is round about us, as the ox licks up the grass of the field." And Balak the son of Zippor was king of Moab at that time.

**22:5** And he sent messengers unto Balaam the son of Beor, to Pethor, which is by the River, to the land of the children of his people, to call him, saying: "Behold, there is a people come out from Egypt; behold, they cover the face of the earth, and they abide over against me.

**22:6** "Come now therefore, I pray, curse me this people; for they are too mighty for me; perhaps I shall prevail, that we may smite them, and that I may drive them out of the land; for I know that he whom you bless is blessed, and he whom you curse is cursed."

**22:7** And the elders of Moab and the elders of Midian departed with divination fees in their hand; and they came unto Balaam, and spoke unto him the words of Balak.

**22:8** And he said unto them: "Lodge here this night, and I will bring you back word, as YHWH shall speak unto me." And the princes of Moab abode with Balaam.

**22:9** And God came unto Balaam, and said: "What men are these with you?"

**22:10** And Balaam said unto God: "Balak the son of Zippor, king of Moab, has sent unto me, saying:

**22:11** "'Behold, the people that is come out of Egypt, it covers the face of the earth; now, come curse me them; perhaps I shall be able to fight against them, and shall drive them out.'"

**22:12** And God said unto Balaam: "You shall not go with them; you shall not curse the people; for they are blessed."

**22:13** And Balaam rose up in the morning, and said unto the princes of Balak: "Go to your land; for YHWH refuses to permit me to go with you."

**22:14** And the princes of Moab rose up, and they went unto Balak, and said: "Balaam refuses to come with us."

---

**22:15** And Balak sent yet again princes, more, and more honorable than they.

**22:16** And they came to Balaam, and said to him: "Thus says Balak the son of Zippor: 'Let nothing, I pray, hinder you from coming unto me;

**22:17** "'For I will promote you unto very great honor, and whatever you say unto me I will do; come therefore, I pray, curse me this people.'"

**22:18** And Balaam answered and said unto the servants of Balak: "If Balak would give me his house full of silver and gold, I cannot go beyond the word of YHWH my God, to do anything small or great.

**22:19** "Now therefore, I pray, tarry also here this night, that I may know what more YHWH will speak unto me."

**22:20** And God came unto Balaam at night, and said unto him: "If the men are come to call you, rise up, go with them; but only the word which I speak unto you, that shall you do."

**22:21** And Balaam rose up in the morning, and saddled his donkey, and went with the princes of Moab.

---

**22:22** And God's anger was kindled because he went; and the angel of YHWH placed himself in the way as an adversary—שָׂטָן (satan)—against him. Now he was riding upon his donkey, and his two servants were with him.

**22:23** And the donkey saw the angel of YHWH standing in the way, with his sword drawn in his hand; and the donkey turned aside out of the way, and went into the field; and Balaam smote the donkey, to turn her into the way.

**22:24** Then the angel of YHWH stood in a hollow way between the vineyards, a fence being on this side, and a fence on that side.

**22:25** And the donkey saw the angel of YHWH, and she thrust herself unto the wall, and crushed Balaam's foot against the wall; and he smote her again.

**22:26** And the angel of YHWH went further, and stood in a narrow place, where was no way to turn either to the right hand or to the left.

**22:27** And the donkey saw the angel of YHWH, and she lay down under Balaam; and Balaam's anger was kindled, and he smote the donkey with his staff.

**22:28** And YHWH opened the mouth of the donkey—וַיִּפְתַּח יהוה אֶת־פִּי הָאָתוֹן (va-yiftach YHWH et-pi ha-aton)—and she said unto Balaam: "What have I done unto you, that you have smitten me these three times?"

**22:29** And Balaam said unto the donkey: "Because you have mocked me; I would there were a sword in my hand, for now I would kill you."

**22:30** And the donkey said unto Balaam: "Am I not your donkey, upon which you have ridden all your life long unto this day? Was I ever accustomed to do so unto you?" And he said: "No."

**22:31** Then YHWH opened the eyes of Balaam, and he saw the angel of YHWH standing in the way, with his sword drawn in his hand; and he bowed his head, and fell on his face.

**22:32** And the angel of YHWH said unto him: "Why have you smitten your donkey these three times? Behold, I am come forth as an adversary, because your way is contrary unto me.

**22:33** "And the donkey saw me, and turned aside before me these three times; unless she had turned aside from me, surely now I would have slain you, and saved her alive."

**22:34** And Balaam said unto the angel of YHWH: "I have sinned; for I knew not that you stood in the way against me; now therefore, if it displease you, I will turn back."

**22:35** And the angel of YHWH said unto Balaam: "Go with the men; but only the word that I shall speak unto you, that you shall speak." So Balaam went with the princes of Balak.

---

**22:36** And when Balak heard that Balaam was come, he went out to meet him unto Ir-moab, which is on the border of the Arnon, which is in the utmost part of the border.

**22:37** And Balak said unto Balaam: "Did I not earnestly send unto you to call you? Why did you not come unto me? Am I not able indeed to promote you to honor?"

**22:38** And Balaam said unto Balak: "Lo, I am come unto you; have I now any power at all to speak anything? The word that God puts in my mouth, that shall I speak."

**22:39** And Balaam went with Balak, and they came unto Kiriath-huzoth.

**22:40** And Balak sacrificed oxen and sheep, and sent to Balaam, and to the princes that were with him.

**22:41** And it came to pass in the morning, that Balak took Balaam, and brought him up into Bamoth-baal, and he saw from there the utmost part of the people.

---

## Synthesis Notes

**Key Restorations:**

**The Setting:**
Israel camps in the plains of Moab, opposite Jericho. They have just defeated Sihon and Og. Moab is terrified.

**Balak's Strategy:**
Unable to defeat Israel militarily, Balak summons a renowned seer. Balaam son of Beor, from Pethor by the Euphrates, is known: "he whom you bless is blessed, and he whom you curse is cursed." Balak seeks supernatural defeat.

**Balaam's Knowledge of YHWH:**
Remarkably, this pagan diviner knows YHWH. He says "YHWH my God" (22:18). He waits for YHWH's word. He cannot act independently of YHWH's permission. The seer's power is real but subordinate to YHWH.

**First Response:**
YHWH tells Balaam: "You shall not go... for they are blessed." Balaam sends the messengers away.

**Second Embassy:**
Balak sends more prestigious envoys with greater promises. Balaam insists: "If Balak would give me his house full of silver and gold, I cannot go beyond the word of YHWH." But he asks them to stay while he inquires again.

**The Permissive Word:**
YHWH permits Balaam to go: "If the men are come to call you, rise up, go with them; but only the word which I speak unto you, that shall you do."

**God's Anger:**
Yet "God's anger was kindled because he went." This seems contradictory. Possible interpretations:
- YHWH permitted but was displeased with Balaam's motive
- Balaam went too eagerly, without waiting for the men to call him
- The permission was a test of Balaam's heart

**The Angel as Satan (שָׂטָן):**
The angel of YHWH stands as an "adversary"—*satan*, not a proper name but a role: "one who opposes." The angel blocks the way with drawn sword.

**The Donkey:**
Three times the donkey sees the angel and turns aside:
1. Into the field
2. Against the wall (crushing Balaam's foot)
3. Lies down (no room to turn)

Each time Balaam beats her. He—the seer—sees nothing. The donkey—a beast—sees the angel.

**The Speaking Donkey:**
"YHWH opened the mouth of the donkey." She speaks coherently, complaining of the beatings and appealing to their long relationship. Balaam converses with her as if this is normal.

The irony: the prophet who comes to speak for hire is instructed by his donkey.

**Eyes Opened:**
Then "YHWH opened the eyes of Balaam." The seer who came to curse finally sees. The angel reveals: the donkey saved Balaam's life. Had she not turned aside, the angel would have killed Balaam.

**Submission:**
Balaam confesses: "I have sinned." The angel reaffirms: "Go with the men; but only the word that I shall speak unto you, that you shall speak."

**Meeting Balak:**
Balaam arrives and announces his limitation: "Have I now any power at all to speak anything? The word that God puts in my mouth, that shall I speak." Balak brings him to Bamoth-baal to view Israel.

**Archetypal Layer:** The donkey who sees what the seer cannot represents **humble perception exceeding arrogant expertise**. The beast is more attuned to divine presence than the professional diviner. This is inversion: the low sees what the high misses.

Balaam is a **conflicted prophet**—genuinely connected to YHWH but motivated by reward. He speaks truth but desires the curse's payment. His path is blocked by his own mount.

**Psychological Reading:** Balaam's repeated inquiry (after the first "no") reveals his hope that YHWH might change. The permission granted becomes a test. His eagerness betrays his heart. And his blindness to the angel—while the donkey sees—exposes how desire can obstruct vision.

**Ethical Inversion Applied:**
- A pagan seer knows YHWH—divine knowledge is not limited to Israel
- The donkey sees, the seer is blind—humble creatures may perceive more
- Permission granted but anger kindled—motive matters beyond action
- The word cannot be bought—Balaam's power depends on YHWH's word
- "I cannot go beyond"—even the diviner-for-hire is constrained by YHWH

**Modern Equivalent:** Those with spiritual credentials may be blinder than the humble. The desire for reward can corrupt genuine gifting. And the repeated asking ("maybe this time God will say yes") reveals a heart that hasn't truly accepted the first answer.

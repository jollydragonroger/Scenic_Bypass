# Numbers Chapter 5: Purity Laws and the Jealousy Ordeal

*From the Hebrew: סוֹטָה (Sotah) — The Wayward Woman*

---

**5:1** And YHWH spoke unto Moses, saying:

**5:2** "Command the children of Israel, that they put out of the camp every leper—צָרוּעַ (tsarua)—and everyone who has a discharge, and whoever is unclean by the dead.

**5:3** "Both male and female shall you put out, outside the camp shall you put them; that they not defile their camp, in the midst of which I dwell."

**5:4** And the children of Israel did so, and put them outside the camp; as YHWH spoke unto Moses, so did the children of Israel.

---

**5:5** And YHWH spoke unto Moses, saying:

**5:6** "Speak unto the children of Israel: 'When a man or woman commits any sin that men commit, to act unfaithfully against YHWH—לִמְעֹל מַעַל בַּיהוה (lim'ol ma'al ba-YHWH)—and that soul is guilty,

**5:7** "'Then they shall confess their sin which they have done; and he shall make restitution for his guilt in full, and add to it the fifth part thereof, and give it unto him against whom he has been guilty.

**5:8** "'But if the man has no kinsman to whom restitution may be made for the guilt, the restitution for guilt which is made unto YHWH shall be the priest's, besides the ram of the atonement, by which atonement is made for him.

**5:9** "'And every contribution of all the holy things of the children of Israel, which they present unto the priest, shall be his.

**5:10** "'And every man's hallowed things shall be his; whatever any man gives the priest, it shall be his.'"

---

**5:11** And YHWH spoke unto Moses, saying:

**5:12** "Speak unto the children of Israel, and say unto them: 'If any man's wife goes aside, and acts unfaithfully against him,

**5:13** "'And a man lies with her carnally, and it is hidden from the eyes of her husband, and she is kept close, and she is defiled, and there is no witness against her, and she was not taken in the act;

**5:14** "'And the spirit of jealousy—רוּחַ קִנְאָה (ruach qin'ah)—comes upon him, and he is jealous of his wife, and she is defiled; or if the spirit of jealousy comes upon him, and he is jealous of his wife, and she is not defiled;

**5:15** "'Then shall the man bring his wife unto the priest, and shall bring her offering for her, the tenth part of an ephah of barley meal; he shall pour no oil upon it, nor put frankincense upon it; for it is a grain offering of jealousy, a grain offering of memorial, bringing iniquity to remembrance.

**5:16** "'And the priest shall bring her near, and set her before YHWH.

**5:17** "'And the priest shall take holy water in an earthen vessel; and of the dust that is on the floor of the tabernacle the priest shall take, and put it into the water.

**5:18** "'And the priest shall set the woman before YHWH, and let down the hair of the woman's head, and put the grain offering of memorial in her hands, which is the grain offering of jealousy; and the priest shall have in his hand the water of bitterness that brings the curse—מֵי הַמָּרִים הַמְאָרְרִים (mei ha-marim ha-me'arerim).

**5:19** "'And the priest shall cause her to swear, and shall say unto the woman: If no man has lain with you, and if you have not gone aside to uncleanness, being under your husband, be free from this water of bitterness that brings the curse.

**5:20** "'But if you have gone aside, being under your husband, and if you are defiled, and some man has lain with you besides your husband—

**5:21** "'Then the priest shall cause the woman to swear with the oath of cursing, and the priest shall say unto the woman—YHWH make you a curse and an oath among your people, when YHWH makes your thigh fall away, and your belly swell;

**5:22** "'And this water that brings the curse shall go into your bowels, and make your belly swell, and your thigh fall away. And the woman shall say: Amen, Amen.

**5:23** "'And the priest shall write these curses in a scroll, and he shall blot them out into the water of bitterness.

**5:24** "'And he shall make the woman drink the water of bitterness that brings the curse; and the water that brings the curse shall enter into her and become bitter.

**5:25** "'And the priest shall take the grain offering of jealousy out of the woman's hand, and shall wave the grain offering before YHWH, and bring it unto the altar.

**5:26** "'And the priest shall take a handful of the grain offering, as the memorial thereof, and burn it upon the altar, and afterward shall make the woman drink the water.

**5:27** "'And when he has made her drink the water, then it shall come to pass, if she is defiled, and has acted unfaithfully against her husband, that the water that brings the curse shall enter into her and become bitter, and her belly shall swell, and her thigh shall fall away; and the woman shall be a curse among her people.

**5:28** "'And if the woman is not defiled, but is clean, then she shall be free, and shall conceive seed.

**5:29** "'This is the law of jealousy, when a wife, being under her husband, goes aside, and is defiled;

**5:30** "'Or when the spirit of jealousy comes upon a man, and he is jealous over his wife; then he shall set the woman before YHWH, and the priest shall execute upon her all this law.

**5:31** "'And the man shall be free from iniquity, and that woman shall bear her iniquity.'"

---

## Synthesis Notes

**Key Restorations:**

**Exclusion from Camp (5:1-4):**
Three categories of unclean persons must be put outside the camp:
- *Tsarua* (skin disease)
- Those with discharge
- Those corpse-contaminated

The reason: "that they not defile their camp, in the midst of which I dwell." YHWH's presence requires purity.

**Restitution for Wrong (5:5-10):**
Sin against a neighbor is unfaithfulness (*ma'al*) against YHWH. Restitution requires:
- Confession
- Full repayment plus 20%
- If no kinsman to receive it, payment goes to the priest
- Plus a ram for atonement

**The Jealousy Ordeal (סוֹטָה, Sotah, 5:11-31):**

The situation:
- A husband suspects his wife of adultery
- No witnesses, no proof
- "The spirit of jealousy" (*ruach qin'ah*) comes upon him

The ritual:
1. The husband brings his wife to the priest
2. He brings a grain offering: barley meal, no oil, no frankincense (a penitential offering)
3. The priest prepares "the water of bitterness": holy water + dust from the tabernacle floor
4. The woman's hair is unbound (sign of vulnerability/mourning)
5. She holds the grain offering
6. The priest pronounces the oath: if innocent, be free; if guilty, thigh falls, belly swells
7. The woman says "Amen, Amen"
8. The curses are written and washed into the water
9. The grain offering is waved and burned
10. The woman drinks the water

**The Outcome:**
- If guilty: physical symptoms manifest; she becomes "a curse among her people"
- If innocent: no harm; she "shall conceive seed"

**"Thigh Falls, Belly Swells":**
The precise meaning is debated. Possibly:
- Miscarriage or barrenness
- Internal prolapse
- The language is euphemistic for reproductive consequences

**The Purpose:**
The ordeal resolves an otherwise unresolvable situation. Without witnesses, the case cannot be adjudicated by normal legal means. The ritual hands the judgment to YHWH. The water is harmless in itself; only divine intervention produces consequences.

**The Man's Immunity:**
"The man shall be free from iniquity"—the accusing husband bears no guilt regardless of the outcome. This protects against frivolous accusations having no consequence. But the asymmetry (no equivalent ordeal if a wife suspects her husband) reflects the patriarchal context.

**Archetypal Layer:** The ordeal is a **trial by sacred means**—when human knowledge fails, divine judgment is sought. The water, the dust, the written curses dissolved—these create a ritual space where truth can manifest beyond normal evidence.

The unbound hair and the oath create **liminality**: the woman is between statuses, awaiting divine verdict.

**Psychological Reading:** The ritual provides closure. Suspicion that cannot be resolved festers. The ordeal, whatever its actual effects, provides a structured resolution. After the ritual, the matter is settled—by divine verdict, not ongoing suspicion.

**Ethical Inversion Applied:**
- The camp's purity protects divine presence—uncleanness endangers the community
- Sin against neighbor is sin against YHWH—horizontal and vertical are linked
- The ordeal resolves the unresolvable—some cases exceed human judgment
- The woman speaks: "Amen, Amen"—she participates in accepting the verdict
- Asymmetry reflects context—the text does not transcend all ancient norms

**Difficult Elements:**
The *sotah* ritual is patriarchal: only wives are tested, not husbands. The ritual was eventually abolished by Rabban Yochanan ben Zakkai (1st century CE), who declared it invalid when adultery became too common. The principle of divine judgment on hidden matters remains; the specific ritual does not.

**Modern Equivalent:** The need to resolve suspicion when evidence is lacking remains. The *sotah* ritual is not practiced, but the underlying issue—how to handle accusations without proof—continues to challenge legal and relational systems. The ritual at least provided structure and finality where endless suspicion would have been destructive.

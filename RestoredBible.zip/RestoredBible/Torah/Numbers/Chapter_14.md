# Numbers Chapter 14: The People's Rebellion

*From the Hebrew: מָאֵן (Ma'en) — The Great Refusal*

---

**14:1** And all the congregation lifted up their voice, and cried; and the people wept that night.

**14:2** And all the children of Israel murmured against Moses and against Aaron; and the whole congregation said unto them: "Would that we had died in the land of Egypt! Or would that we had died in this wilderness!

**14:3** "And why does YHWH bring us unto this land, to fall by the sword? Our wives and our little ones will be a prey; were it not better for us to return into Egypt?"

**14:4** And they said one to another: "Let us make a captain, and let us return into Egypt."

**14:5** Then Moses and Aaron fell on their faces before all the assembly of the congregation of the children of Israel.

**14:6** And Joshua the son of Nun and Caleb the son of Jephunneh, who were of those who spied out the land, tore their clothes.

**14:7** And they spoke unto all the congregation of the children of Israel, saying: "The land, which we passed through to spy it out, is an exceedingly good land.

**14:8** "If YHWH delights in us—אִם־חָפֵץ בָּנוּ יהוה (im-chafets banu YHWH)—then he will bring us into this land, and give it unto us; a land which flows with milk and honey.

**14:9** "Only do not rebel against YHWH, and do not fear the people of the land; for they are bread for us—כִּי לַחְמֵנוּ הֵם (ki lachmenu hem); their defense has departed from them, and YHWH is with us; do not fear them."

**14:10** But all the congregation said to stone them with stones. And the glory of YHWH appeared in the tent of meeting unto all the children of Israel.

---

**14:11** And YHWH said unto Moses: "How long will this people despise me? And how long will they not believe in me, for all the signs which I have wrought among them?

**14:12** "I will smite them with the pestilence, and disinherit them, and will make of you a nation greater and mightier than they."

**14:13** And Moses said unto YHWH: "Then the Egyptians will hear of it; for you brought up this people in your might from among them;

**14:14** "And they will tell it to the inhabitants of this land, who have heard that you YHWH are in the midst of this people; that you YHWH are seen face to face, and your cloud stands over them, and you go before them, in a pillar of cloud by day, and in a pillar of fire by night.

**14:15** "Now if you kill this people as one man, then the nations who have heard the report of you will speak, saying:

**14:16** "'Because YHWH was not able to bring this people into the land which he swore unto them, therefore he has slain them in the wilderness.'

**14:17** "And now, I pray, let the power of my Lord be great, according as you have spoken, saying:

**14:18** "'YHWH is slow to anger, and abundant in lovingkindness—יהוה אֶרֶךְ אַפַּיִם וְרַב־חֶסֶד (YHWH erech appayim ve-rav-chesed)—forgiving iniquity and transgression, and that will by no means clear the guilty; visiting the iniquity of the fathers upon the children, upon the third and upon the fourth generation.'

**14:19** "Pardon, I pray, the iniquity of this people according to the greatness of your lovingkindness, and as you have forgiven this people from Egypt even until now."

**14:20** And YHWH said: "I have pardoned according to your word—סָלַחְתִּי כִּדְבָרֶךָ (salachti ki-devarecha).

---

**14:21** "But as I live, and as all the earth shall be filled with the glory of YHWH,

**14:22** "Surely all the men who have seen my glory, and my signs, which I wrought in Egypt and in the wilderness, yet have put me to the test these ten times, and have not listened to my voice,

**14:23** "Surely they shall not see the land which I swore unto their fathers, neither shall any of those who despised me see it.

**14:24** "But my servant Caleb, because he had another spirit with him—רוּחַ אַחֶרֶת (ruach acheret)—and has followed me fully, him will I bring into the land into which he went; and his seed shall possess it.

**14:25** "Now the Amalekite and the Canaanite dwell in the valley; tomorrow turn, and journey into the wilderness by the way to the Red Sea."

---

**14:26** And YHWH spoke unto Moses and unto Aaron, saying:

**14:27** "How long shall I bear with this evil congregation, who murmur against me? I have heard the murmurings of the children of Israel, which they murmur against me.

**14:28** "Say unto them: 'As I live, says YHWH, surely as you have spoken in my ears, so will I do to you:

**14:29** "'Your carcasses shall fall in this wilderness; and all who were numbered of you, according to your whole number, from twenty years old and upward, who have murmured against me,

**14:30** "'Surely you shall not come into the land, concerning which I lifted up my hand that I would make you dwell therein, save Caleb the son of Jephunneh, and Joshua the son of Nun.

**14:31** "'But your little ones, whom you said would be a prey, them will I bring in, and they shall know the land which you have rejected.

**14:32** "'But as for you, your carcasses shall fall in this wilderness.

**14:33** "'And your children shall be shepherds in the wilderness forty years, and shall bear your unfaithfulness, until your carcasses are consumed in the wilderness.

**14:34** "'After the number of the days in which you spied out the land, forty days, for every day a year—יוֹם לַשָּׁנָה (yom la-shanah)—shall you bear your iniquities, even forty years; and you shall know my displeasure.'

**14:35** "I YHWH have spoken; surely this will I do unto all this evil congregation, who are gathered together against me; in this wilderness they shall be consumed, and there they shall die."

**14:36** And the men whom Moses sent to spy out the land, who returned, and made all the congregation to murmur against him, by bringing up an evil report against the land,

**14:37** Even those men who brought up the evil report of the land, died by the plague before YHWH.

**14:38** But Joshua the son of Nun, and Caleb the son of Jephunneh, remained alive of those men who went to spy out the land.

---

**14:39** And Moses told these words unto all the children of Israel; and the people mourned greatly.

**14:40** And they rose up early in the morning, and went up to the top of the mountain, saying: "Lo, we are here, and will go up unto the place which YHWH has promised; for we have sinned."

**14:41** And Moses said: "Why now do you transgress the commandment of YHWH, seeing it shall not prosper?

**14:42** "Go not up, for YHWH is not among you; that you be not smitten before your enemies.

**14:43** "For there the Amalekite and the Canaanite are before you, and you shall fall by the sword; because you turned back from following YHWH, therefore YHWH will not be with you."

**14:44** But they presumed to go up to the top of the mountain; but the ark of the covenant of YHWH, and Moses, did not depart from the camp.

**14:45** And the Amalekite and the Canaanite, who dwelt in that hill-country, came down, and smote them and beat them down, even unto Hormah.

---

## Synthesis Notes

**Key Restorations:**

**The Night of Weeping:**
All Israel weeps. The evil report produces despair: "Would that we had died in Egypt!" The people prefer remembered slavery to promised freedom. They propose electing a new captain and returning to Egypt.

**Joshua and Caleb's Plea:**
They tear their clothes (mourning) and counter the majority:
- "The land is exceedingly good"
- "If YHWH delights in us, he will bring us"
- "They are bread for us"—the Canaanites will be consumed
- "Their defense has departed"—divine protection has left them
- "YHWH is with us; do not fear"

**"Stone Them!":**
The congregation's response to Joshua and Caleb: execution. They are silenced only by the appearing of YHWH's glory.

**YHWH's Proposal:**
"I will smite them with pestilence, and disinherit them, and will make of you a nation greater and mightier." This echoes Exodus 32:10 (the golden calf). YHWH offers to start over with Moses.

**Moses' Intercession:**
Moses argues from YHWH's reputation:
- The Egyptians will hear
- The nations will say YHWH couldn't complete what he started
- YHWH's honor is at stake

Then Moses quotes YHWH's self-revelation (Exodus 34:6-7): "slow to anger, abundant in lovingkindness." He appeals to YHWH's own character.

**"I Have Pardoned According to Your Word":**
*Salachti ki-devarecha*—the pardon is granted because of Moses' intercession. But pardon is not removal of consequence.

**The Sentence:**
- This generation (20 years and older) will not enter the land
- Their carcasses will fall in the wilderness
- Forty years of wandering—one year for each day of spying
- The children (who they feared would be "prey") will inherit
- Only Caleb and Joshua are exempted

**"Ten Times":**
YHWH counts ten provocations (the tradition identifies: at the Red Sea, Marah, the wilderness of Sin, manna violations, Rephidim, the golden calf, Taberah, Kibroth-hattaavah, and twice at Kadesh).

**Caleb's "Other Spirit" (רוּחַ אַחֶרֶת):**
Caleb had *ruach acheret*—a different spirit. Where others saw impossibility, he saw possibility. His perspective was shaped by faith, not fear.

**The Ten Spies Die:**
The ten who brought the evil report die immediately by plague. Joshua and Caleb alone survive.

**Presumptuous Attack:**
After hearing the sentence, Israel reverses: "We will go up!" But Moses warns: "YHWH is not among you." They go anyway. The ark and Moses stay in camp. Result: defeat at Hormah.

**The Principle:**
Disobedience cannot be corrected by belated compliance. They refused to go when commanded; now they go when forbidden. Both are rebellion.

**Archetypal Layer:** This chapter is the **pivot point of the wilderness narrative**. The exodus generation loses the promise. The failure is not military but spiritual—they did not believe despite all the signs. Their children will inherit what they rejected.

Caleb's "other spirit" represents **the minority who see differently**—faith that interprets the same data through trust rather than fear.

**Psychological Reading:** The congregation's psychology is revealed: fear → despair → regression (back to Egypt) → violence (stone Joshua and Caleb) → belated overcompensation (attack without YHWH). The pattern is common: fear produces irrational responses.

**Ethical Inversion Applied:**
- Pardon doesn't remove all consequences—forgiveness and discipline coexist
- The children inherit what the parents rejected—the next generation gets the promise
- "They are bread for us"—faith reverses the power dynamic
- Caleb's different spirit—perception shaped by trust
- Presumption is not faith—going when forbidden is as wrong as refusing when commanded

**Modern Equivalent:** Fear-based decisions can forfeit opportunities that don't return. The distinction between faithful courage (Joshua and Caleb) and presumptuous action (attacking without YHWH) remains critical. And the children who inherit what their parents couldn't receive suggests that sometimes the next generation completes what the previous one couldn't.

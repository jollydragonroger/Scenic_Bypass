# Numbers Chapter 19: The Red Heifer

*From the Hebrew: פָרָה אֲדֻמָּה (Parah Adumah) — The Red Cow*

---

**19:1** And YHWH spoke unto Moses and unto Aaron, saying:

**19:2** "This is the statute of the law which YHWH has commanded, saying: 'Speak unto the children of Israel, that they bring you a red heifer—פָרָה אֲדֻמָּה (parah adumah)—without blemish, in which there is no defect, and upon which never came a yoke.

**19:3** "'And you shall give her unto Eleazar the priest, and she shall be brought forth outside the camp, and she shall be slaughtered before him.

**19:4** "'And Eleazar the priest shall take of her blood with his finger, and sprinkle of her blood toward the front of the tent of meeting seven times.

**19:5** "'And the heifer shall be burned in his sight; her skin, and her flesh, and her blood, with her dung, shall be burned.

**19:6** "'And the priest shall take cedar wood, and hyssop, and scarlet, and cast it into the midst of the burning of the heifer.

**19:7** "'Then the priest shall wash his clothes, and he shall bathe his flesh in water, and afterward he may come into the camp; and the priest shall be unclean until the evening.

**19:8** "'And he who burns her shall wash his clothes in water, and bathe his flesh in water, and shall be unclean until the evening.

**19:9** "'And a man who is clean shall gather up the ashes of the heifer, and lay them up outside the camp in a clean place; and it shall be kept for the congregation of the children of Israel for a water of impurity—מֵי נִדָּה (mei niddah); it is a purification from sin.

**19:10** "'And he who gathers the ashes of the heifer shall wash his clothes, and be unclean until the evening. And it shall be unto the children of Israel, and unto the stranger who sojourns among them, for a statute forever.

---

**19:11** "'He who touches the dead body of any man shall be unclean seven days.

**19:12** "'He shall purify himself with it on the third day and on the seventh day, and then he shall be clean; but if he does not purify himself on the third day and on the seventh day, he shall not be clean.

**19:13** "'Whoever touches a dead person, the body of a man who has died, and does not purify himself, defiles the tabernacle of YHWH; and that soul shall be cut off from Israel; because the water of impurity was not thrown upon him, he shall be unclean; his uncleanness is yet upon him.

**19:14** "'This is the law when a man dies in a tent: everyone who comes into the tent, and everything that is in the tent, shall be unclean seven days.

**19:15** "'And every open vessel, which has no covering bound upon it, is unclean.

**19:16** "'And whoever in the open field touches one who is slain with a sword, or a dead body, or a bone of a man, or a grave, shall be unclean seven days.

**19:17** "'And for the unclean they shall take of the ashes of the burning of the sin offering, and running water shall be put upon them in a vessel.

**19:18** "'And a clean person shall take hyssop, and dip it in the water, and sprinkle it upon the tent, and upon all the vessels, and upon the persons who were there, and upon him who touched the bone, or the slain, or the dead, or the grave.

**19:19** "'And the clean person shall sprinkle upon the unclean on the third day and on the seventh day; and on the seventh day he shall purify him; and he shall wash his clothes, and bathe himself in water, and shall be clean at evening.

**19:20** "'But the man who shall be unclean, and shall not purify himself, that soul shall be cut off from the midst of the assembly, because he has defiled the sanctuary of YHWH; the water of impurity has not been thrown upon him; he is unclean.

**19:21** "'And it shall be a perpetual statute unto them. And he who sprinkles the water of impurity shall wash his clothes; and he who touches the water of impurity shall be unclean until the evening.

**19:22** "'And whatever the unclean person touches shall be unclean; and the soul who touches it shall be unclean until the evening.'"

---

## Synthesis Notes

**Key Restorations:**

**The Red Heifer (פָרָה אֲדֻמָּה):**
Requirements:
- **Red** (*adumah*)—completely red, no other color
- **Without blemish** (*temimah*)—physically perfect
- **Never yoked**—never used for ordinary work

This is unique among sacrifices: performed outside the camp, not at the altar; entirely burned (skin, flesh, blood, dung); the ashes preserved for future use.

**The Procedure:**
1. Eleazar (not Aaron) takes the heifer outside the camp
2. It is slaughtered before him
3. He sprinkles blood toward the tent of meeting seven times
4. The entire animal is burned
5. Cedar wood, hyssop, and scarlet are thrown into the fire
6. The ashes are gathered and stored "in a clean place"

**Cedar, Hyssop, Scarlet:**
The same three elements used in the cleansing of the *metsora* (Leviticus 14:4-6). Cedar = durability, height; hyssop = cleansing, lowliness; scarlet = blood, life. They appear together in purification rituals.

**The Water of Impurity (מֵי נִדָּה):**
The ashes are mixed with "living water" (running water) to create the purification water. This is not used immediately but stored for when corpse contamination occurs.

**Corpse Contamination:**
The most severe form of ritual impurity:
- Contact with a dead body: unclean 7 days
- Being in a tent where someone died: unclean 7 days
- Touching bone, grave, or battle-slain: unclean 7 days
- Open vessels in the death-tent: unclean

**The Purification Process:**
- Day 3: sprinkled with the water of impurity
- Day 7: sprinkled again, then wash clothes and bathe
- Evening of day 7: clean

Failure to purify = cut off from the assembly (the contamination "defiles the tabernacle of YHWH").

**The Paradox:**
Everyone who participates in creating or applying the purification water becomes unclean:
- The priest who burns the heifer: unclean until evening
- The one who burns it: unclean until evening
- The one who gathers the ashes: unclean until evening
- The clean person who sprinkles: must wash clothes
- Whoever touches the water: unclean until evening

The means of purification contaminates those who handle it. This is paradoxical—the thing that cleanses, defiles.

**Archetypal Layer:** Death is the ultimate boundary. Corpse contamination represents **contact with the realm of death**—the opposite of the God of life. The elaborate purification separates the living from death's contagion.

The paradox (clean made unclean by handling purification) suggests that **dealing with death's contamination is costly**. Those who cleanse others take on temporary impurity themselves.

**Psychological Reading:** The seven-day process gives time. Death's impact is not instantly processed. The third and seventh day applications structure the transition from contaminated to clean.

The requirement to purify or be "cut off" makes corpse contamination everyone's responsibility. You cannot ignore contact with death.

**Ethical Inversion Applied:**
- Death is the ultimate impurity—the opposite of the living God
- The red heifer is wholly given—entirely consumed, ashes preserved
- The paradox of purification—those who cleanse become temporarily unclean
- The third and seventh days—structured time for transition
- Failure to purify excludes—you cannot remain contaminated in YHWH's community

**The Chuqqah (חֻקָּה):**
The red heifer is the quintessential *chuqqah*—a statute without obvious rational explanation. Jewish tradition considers it the most mysterious of all commandments. King Solomon, the wisest, reportedly said he understood all commandments except this one.

**Modern Equivalent:** Death still requires processing. Cultures have mourning rituals, purification practices, and structured time for grief. The paradox that those who handle death (funeral workers, hospice staff, grief counselors) bear a burden reflects the ancient principle. And the structured timeline (days 3 and 7) anticipates how grief work moves through stages.

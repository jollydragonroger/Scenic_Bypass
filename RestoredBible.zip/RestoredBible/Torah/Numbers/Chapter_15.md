# Numbers Chapter 15: Laws of Offerings and the Sabbath-Breaker

*From the Hebrew: כִּי תָבֹאוּ (Ki Tavo'u) — When You Come*

---

**15:1** And YHWH spoke unto Moses, saying:

**15:2** "Speak unto the children of Israel, and say unto them: 'When you come into the land of your habitations, which I give unto you—כִּי תָבֹאוּ אֶל־אֶרֶץ מוֹשְׁבֹתֵיכֶם (ki tavo'u el-erets moshvoteichem),

**15:3** "'And will make a fire offering unto YHWH, a burnt offering, or a sacrifice, in fulfillment of a vow, or as a freewill offering, or in your appointed seasons, to make a pleasing aroma unto YHWH, of the herd, or of the flock;

**15:4** "'Then he who brings his offering shall bring unto YHWH a grain offering of a tenth part of an ephah of fine flour, mixed with a fourth part of a hin of oil;

**15:5** "'And wine for the drink offering, a fourth part of a hin, you shall prepare with the burnt offering, or for the sacrifice, for each lamb.

**15:6** "'Or for a ram, you shall prepare for a grain offering two tenth parts of an ephah of fine flour mixed with a third part of a hin of oil;

**15:7** "'And for the drink offering you shall present a third part of a hin of wine, for a pleasing aroma unto YHWH.

**15:8** "'And when you prepare a bull for a burnt offering, or for a sacrifice, in fulfillment of a vow, or for peace offerings unto YHWH,

**15:9** "'Then shall he bring with the bull a grain offering of three tenth parts of an ephah of fine flour mixed with half a hin of oil;

**15:10** "'And you shall bring for the drink offering half a hin of wine, for a fire offering of a pleasing aroma unto YHWH.

**15:11** "'Thus shall it be done for each bull, or for each ram, or for each of the male lambs, or of the kids.

**15:12** "'According to the number that you shall prepare, so shall you do to each one according to their number.

**15:13** "'All who are native-born shall do these things in this manner, in presenting a fire offering of a pleasing aroma unto YHWH.

**15:14** "'And if a stranger sojourns with you, or whoever may be among you throughout your generations, and will offer a fire offering of a pleasing aroma unto YHWH, as you do, so shall he do.

**15:15** "'As for the assembly, there shall be one statute—חֻקָּה אַחַת (chuqqah achat)—for you and for the stranger who sojourns with you, a statute forever throughout your generations; as you are, so shall the stranger be before YHWH.

**15:16** "'One law and one ordinance shall be for you and for the stranger who sojourns with you.'"

---

**15:17** And YHWH spoke unto Moses, saying:

**15:18** "Speak unto the children of Israel, and say unto them: 'When you come into the land where I bring you,

**15:19** "'Then it shall be, that when you eat of the bread of the land, you shall set apart a contribution unto YHWH.

**15:20** "'Of the first of your dough you shall set apart a cake for a contribution—חַלָּה תְּרִימוּ תְרוּמָה (challah tarimu terumah); as the contribution of the threshing-floor, so shall you set it apart.

**15:21** "'Of the first of your dough you shall give unto YHWH a contribution throughout your generations.

---

**15:22** "'And when you err, and do not do all these commandments, which YHWH has spoken unto Moses,

**15:23** "'Even all that YHWH has commanded you by the hand of Moses, from the day that YHWH gave commandment, and onward throughout your generations,

**15:24** "'Then it shall be, if it was done unwittingly, without the knowledge of the congregation, that all the congregation shall offer one young bull for a burnt offering, for a pleasing aroma unto YHWH, with its grain offering and its drink offering, according to the ordinance, and one male goat for a sin offering.

**15:25** "'And the priest shall make atonement for all the congregation of the children of Israel, and they shall be forgiven; for it was an error, and they have brought their offering, a fire offering unto YHWH, and their sin offering before YHWH, for their error.

**15:26** "'And all the congregation of the children of Israel shall be forgiven, and the stranger who sojourns among them; for in respect of all the people it was done unwittingly.

**15:27** "'And if one person sins unwittingly, then he shall bring a female goat a year old for a sin offering.

**15:28** "'And the priest shall make atonement for the soul who errs, when he sins unwittingly, before YHWH, to make atonement for him; and he shall be forgiven.

**15:29** "'You shall have one law for him who does anything unwittingly, for him who is native-born among the children of Israel, and for the stranger who sojourns among them.

**15:30** "'But the soul who does anything with a high hand—בְּיָד רָמָה (be-yad ramah)—whether he is native-born or a stranger, that one blasphemes YHWH; and that soul shall be cut off from among his people.

**15:31** "'Because he has despised the word of YHWH, and has broken his commandment; that soul shall utterly be cut off; his iniquity is upon him.'"

---

**15:32** And while the children of Israel were in the wilderness, they found a man gathering sticks upon the sabbath day.

**15:33** And those who found him gathering sticks brought him unto Moses and Aaron, and unto all the congregation.

**15:34** And they put him in custody, because it had not been declared what should be done to him.

**15:35** And YHWH said unto Moses: "The man shall surely be put to death; all the congregation shall stone him with stones outside the camp."

**15:36** And all the congregation brought him outside the camp, and stoned him with stones, and he died, as YHWH commanded Moses.

---

**15:37** And YHWH spoke unto Moses, saying:

**15:38** "Speak unto the children of Israel, and bid them that they make them fringes—צִיצִת (tsitsit)—on the corners of their garments throughout their generations, and that they put upon the fringe of each corner a thread of blue—פְּתִיל תְּכֵלֶת (petil techelet).

**15:39** "And it shall be unto you for a fringe, that you may look upon it, and remember all the commandments of YHWH, and do them; and that you go not about after your own heart and your own eyes, after which you go astray;

**15:40** "That you may remember and do all my commandments, and be holy unto your Consciousness.

**15:41** "I am YHWH your Consciousness, who brought you out of the land of Egypt, to be your Consciousness: I am YHWH your Consciousness."

---

## Synthesis Notes

**Key Restorations:**

**"When You Come into the Land":**
After the devastating judgment of chapter 14, these laws look forward to the eventual entry. The next generation will need these instructions. The promise remains.

**Grain and Drink Offerings:**
Proportional accompaniments for animal sacrifices:

| Animal | Flour | Oil | Wine |
|--------|-------|-----|------|
| Lamb | 1/10 ephah | 1/4 hin | 1/4 hin |
| Ram | 2/10 ephah | 1/3 hin | 1/3 hin |
| Bull | 3/10 ephah | 1/2 hin | 1/2 hin |

**One Law for Native and Stranger:**
*Chuqqah achat*—one statute for Israelite and sojourner alike. The stranger who worships YHWH follows the same ritual requirements. "As you are, so shall the stranger be before YHWH."

**Challah (חַלָּה):**
The first portion of dough belongs to YHWH. This is the origin of the *challah* offering—a contribution from the first kneading. The practice continues in Jewish observance.

**Unintentional vs. Intentional Sin:**

Unintentional sin (*shegagah*):
- Community: bull (burnt offering) + goat (sin offering)
- Individual: female goat
- Atonement is available; forgiveness is granted

Intentional sin ("with a high hand," *be-yad ramah*):
- No sacrifice available
- The person has "despised the word of YHWH"
- Cut off from the people

The phrase "high hand" suggests defiance, arrogance, deliberate rebellion.

**The Sabbath-Breaker:**
A man gathers wood on the Sabbath. This is a test case: the penalty was not yet specified. YHWH declares: death by stoning outside the camp. The congregation executes the sentence.

This is severe. The violation is deliberate (gathering wood requires intentional effort on the Sabbath). It is public rebellion against the foundational commandment. The execution establishes the seriousness of Sabbath observance.

**The Tsitsit (צִיצִת):**
Fringes on the corners of garments, each with a blue thread (*petil techelet*):
- Visual reminder of the commandments
- "That you may look upon it, and remember"
- Protection against following "your own heart and your own eyes"

The fringes make the invisible covenant visible. Every Israelite wears the reminder.

**Archetypal Layer:** The grain and drink offerings show that **animal sacrifice is not complete without agricultural gifts**—blood and bread, flesh and wine. The whole creation participates in worship.

The tsitsit make **covenant visible and wearable**. Israel carries the reminder on their bodies. The blue thread (*techelet*)—sky-colored—connects earth to heaven.

**Psychological Reading:** The distinction between unintentional and intentional sin addresses different heart conditions. Mistakes can be atoned; deliberate defiance cannot. The category of "high hand" identifies the attitude that makes atonement impossible: arrogant rebellion.

The tsitsit function as behavioral anchors—visual cues that trigger memory and shape action. "Look upon it and remember."

**Ethical Inversion Applied:**
- One law for native and stranger—equality before YHWH
- The challah offering—first portion belongs to God
- Unintentional sin is forgivable—mistakes don't exclude
- High-handed sin is fatal—deliberate rebellion is different
- The tsitsit remind—external aids to internal faithfulness

**Difficult Elements:**
The death penalty for gathering wood on the Sabbath seems disproportionate. The text presents it as establishing precedent in a foundational period. Later Judaism developed elaborate Sabbath rules to prevent even approaching violation—"building a fence around the Torah."

**Modern Equivalent:** Visual reminders of commitment (religious symbols, wedding rings, uniforms) function like tsitsit—external cues that anchor internal identity. The distinction between mistakes (forgivable) and deliberate defiance (a different category) remains relevant in ethical and legal thinking.

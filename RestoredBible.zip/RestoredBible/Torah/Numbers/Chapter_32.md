# Numbers Chapter 32: The Transjordan Tribes

*From the Hebrew: אֶרֶץ מִקְנֶה (Erets Miqneh) — Land for Livestock*

---

**32:1** Now the children of Reuben and the children of Gad had a very great multitude of cattle; and when they saw the land of Jazer, and the land of Gilead, that behold, the place was a place for cattle,

**32:2** The children of Gad and the children of Reuben came and spoke unto Moses, and to Eleazar the priest, and unto the princes of the congregation, saying:

**32:3** "Ataroth, and Dibon, and Jazer, and Nimrah, and Heshbon, and Elealeh, and Sebam, and Nebo, and Beon,

**32:4** "The land which YHWH smote before the congregation of Israel, is a land for cattle, and your servants have cattle."

**32:5** And they said: "If we have found favor in your sight, let this land be given unto your servants for a possession; bring us not over the Jordan."

**32:6** And Moses said unto the children of Gad and to the children of Reuben: "Shall your brothers go to the war, and shall you sit here?

**32:7** "And why do you discourage the heart of the children of Israel from going over into the land which YHWH has given them?

**32:8** "Thus did your fathers, when I sent them from Kadesh-barnea to see the land.

**32:9** "For when they went up unto the valley of Eshcol, and saw the land, they discouraged the heart of the children of Israel, that they should not go into the land which YHWH had given them.

**32:10** "And YHWH's anger was kindled in that day, and he swore, saying:

**32:11** "'Surely none of the men who came up out of Egypt, from twenty years old and upward, shall see the land which I swore unto Abraham, unto Isaac, and unto Jacob; because they have not wholly followed me;

**32:12** "'Save Caleb the son of Jephunneh the Kenizzite, and Joshua the son of Nun; because they have wholly followed YHWH.'

**32:13** "And YHWH's anger was kindled against Israel, and he made them wander in the wilderness forty years, until all the generation, who had done evil in the sight of YHWH, was consumed.

**32:14** "And behold, you have risen up in your fathers' place, a brood of sinful men, to augment yet the fierce anger of YHWH toward Israel.

**32:15** "For if you turn away from after him, he will yet again leave them in the wilderness; and you will destroy all this people."

---

**32:16** And they came near unto him, and said: "We will build sheepfolds here for our cattle, and cities for our little ones;

**32:17** "But we ourselves will be armed and ready to go before the children of Israel, until we have brought them unto their place; and our little ones shall dwell in the fortified cities because of the inhabitants of the land.

**32:18** "We will not return unto our houses, until the children of Israel have inherited every man his inheritance.

**32:19** "For we will not inherit with them on the other side of the Jordan, and forward, because our inheritance is fallen to us on this side of the Jordan eastward."

**32:20** And Moses said unto them: "If you will do this thing, if you will arm yourselves to go before YHWH to the war,

**32:21** "And every armed man of you will pass over the Jordan before YHWH, until he has driven out his enemies from before him,

**32:22** "And the land is subdued before YHWH, and afterward you return, then you shall be clear before YHWH and before Israel, and this land shall be unto you for a possession before YHWH.

**32:23** "But if you will not do so, behold, you have sinned against YHWH; and know your sin, which will find you out—וּדְעוּ חַטַּאתְכֶם אֲשֶׁר תִּמְצָא אֶתְכֶם (u-de'u chattat'chem asher timtsa etchem).

**32:24** "Build yourselves cities for your little ones, and folds for your sheep; and do that which has proceeded out of your mouth."

**32:25** And the children of Gad and the children of Reuben spoke unto Moses, saying: "Your servants will do as my lord commands.

**32:26** "Our little ones, our wives, our flocks, and all our cattle, shall be there in the cities of Gilead;

**32:27** "But your servants will pass over, every man who is armed for war, before YHWH to battle, as my lord says."

**32:28** So Moses gave charge concerning them to Eleazar the priest, and to Joshua the son of Nun, and to the heads of the fathers' houses of the tribes of the children of Israel.

**32:29** And Moses said unto them: "If the children of Gad and the children of Reuben will pass with you over the Jordan, every man who is armed to battle, before YHWH, and the land shall be subdued before you, then you shall give them the land of Gilead for a possession;

**32:30** "But if they will not pass over with you armed, they shall have possessions among you in the land of Canaan."

**32:31** And the children of Gad and the children of Reuben answered, saying: "As YHWH has said unto your servants, so will we do.

**32:32** "We will pass over armed before YHWH into the land of Canaan, and the possession of our inheritance shall be on this side of the Jordan."

**32:33** And Moses gave unto them, even to the children of Gad, and to the children of Reuben, and unto the half-tribe of Manasseh the son of Joseph, the kingdom of Sihon king of the Amorites, and the kingdom of Og king of Bashan, the land, according to its cities with their borders, even the cities of the land round about.

**32:34-42** [The cities rebuilt by Gad, Reuben, and the half-tribe of Manasseh are listed: Dibon, Ataroth, Aroer, Atroth-shophan, Jazer, Jogbehah, Beth-nimrah, Beth-haran, Nebo, Baal-meon, Sibmah, and others in Gilead and Bashan.]

---

## Synthesis Notes

**Key Restorations:**

**The Request:**
Reuben and Gad have large herds. They see the Transjordan territory (conquered from Sihon and Og) is good cattle country. They ask to settle there rather than crossing the Jordan.

**Moses' Alarm:**
Moses hears their request as repetition of the Kadesh-barnea failure:
- "Shall your brothers go to the war, and shall you sit here?"
- "Why do you discourage the heart of the children of Israel?"
- "Thus did your fathers, when I sent them from Kadesh-barnea"

He fears another generational failure—the sons repeating the fathers' sin.

**The Counter-Proposal:**
Reuben and Gad clarify: they will fight alongside their brothers. They propose:
1. Build sheepfolds and fortified cities for families and livestock
2. Cross the Jordan armed
3. Fight in the vanguard until conquest is complete
4. Only then return to the Transjordan

They will not inherit west of the Jordan—their portion is east.

**Moses Accepts:**
If they fulfill their commitment:
- Cross armed before YHWH
- Fight until the land is subdued
- Then they may return and possess the Transjordan

**"Your Sin Will Find You Out":**
*U-de'u chattat'chem asher timtsa etchem*—a proverbial warning. If they fail to keep their promise, their sin will catch up with them. Consequences are inescapable.

**The Half-Tribe of Manasseh:**
Though not part of the original request, half of Manasseh also settles in the Transjordan. The conquest of Gilead and Bashan is assigned to them.

**The Charge to Joshua and Eleazar:**
Moses won't live to see the conquest completed. He charges future leadership to hold Reuben and Gad accountable. The agreement is binding beyond Moses' lifetime.

**The Cities:**
The chapter concludes with a list of rebuilt and renamed cities. The infrastructure is established for the Transjordan settlement.

**Archetypal Layer:** The request to settle short of the promised land raises the question of **partial fulfillment**. Is the Transjordan truly "the land"? Reuben and Gad choose grazing land over crossing the Jordan. The pattern of the twelve divided (10.5 west, 2.5 east) begins here.

The commitment to fight first, enjoy later, establishes the principle of **shared burden before individual benefit**.

**Psychological Reading:** Moses' immediate alarm shows how deeply the Kadesh-barnea failure shaped him. He hears any reluctance as repetition of that trauma. The tribes must explicitly clarify their intention to fight.

**Ethical Inversion Applied:**
- Initial request sounds like desertion—communication matters
- Shared burden before private benefit—fight first, settle later
- "Your sin will find you out"—accountability is inescapable
- The agreement binds beyond Moses—commitments outlast individuals
- Half of Manasseh joins—the configuration evolves

**Modern Equivalent:** Groups with different needs (Reuben/Gad's cattle vs. others' land preferences) can find accommodation if they commit to shared responsibility first. The principle of contributing to collective effort before taking individual benefit structures many organizations.

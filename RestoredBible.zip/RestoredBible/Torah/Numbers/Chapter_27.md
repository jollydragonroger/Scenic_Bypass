# Numbers Chapter 27: The Daughters of Zelophehad and Joshua Commissioned

*From the Hebrew: בְּנוֹת צְלָפְחָד (Benot Tselofchad) — The Daughters' Inheritance*

---

**27:1** Then drew near the daughters of Zelophehad, the son of Hepher, the son of Gilead, the son of Machir, the son of Manasseh, of the families of Manasseh the son of Joseph; and these are the names of his daughters: Mahlah, Noah, and Hoglah, and Milcah, and Tirzah.

**27:2** And they stood before Moses, and before Eleazar the priest, and before the princes and all the congregation, at the door of the tent of meeting, saying:

**27:3** "Our father died in the wilderness, and he was not among the company of those who gathered themselves together against YHWH in the company of Korah, but he died in his own sin; and he had no sons.

**27:4** "Why should the name of our father be taken away from among his family, because he had no son? Give unto us a possession among the brothers of our father."

**27:5** And Moses brought their cause before YHWH.

**27:6** And YHWH spoke unto Moses, saying:

**27:7** "The daughters of Zelophehad speak right—כֵּן בְּנוֹת צְלָפְחָד דֹּבְרֹת (ken benot Tselofchad doverot); you shall surely give them a possession of an inheritance among their father's brothers; and you shall cause the inheritance of their father to pass unto them.

**27:8** "And you shall speak unto the children of Israel, saying: 'If a man dies, and has no son, then you shall cause his inheritance to pass unto his daughter.

**27:9** "'And if he has no daughter, then you shall give his inheritance unto his brothers.

**27:10** "'And if he has no brothers, then you shall give his inheritance unto his father's brothers.

**27:11** "'And if his father has no brothers, then you shall give his inheritance unto his kinsman who is nearest to him of his family, and he shall possess it.' And it shall be unto the children of Israel a statute of judgment—חֻקַּת מִשְׁפָּט (chuqqat mishpat)—as YHWH commanded Moses."

---

**27:12** And YHWH said unto Moses: "Go up into this mountain of Abarim, and behold the land which I have given unto the children of Israel.

**27:13** "And when you have seen it, you also shall be gathered unto your people, as Aaron your brother was gathered;

**27:14** "Because you rebelled against my commandment in the wilderness of Zin, in the strife of the congregation, to sanctify me at the waters before their eyes." These are the waters of Meribah of Kadesh in the wilderness of Zin.

**27:15** And Moses spoke unto YHWH, saying:

**27:16** "Let YHWH, the God of the spirits of all flesh—אֱלֹהֵי הָרוּחֹת לְכָל־בָּשָׂר (Elohei ha-ruchot le-chol-basar)—appoint a man over the congregation,

**27:17** "Who may go out before them, and who may come in before them, and who may lead them out, and who may bring them in; that the congregation of YHWH be not as sheep which have no shepherd."

**27:18** And YHWH said unto Moses: "Take Joshua the son of Nun, a man in whom is spirit—אִישׁ אֲשֶׁר־רוּחַ בּוֹ (ish asher-ruach bo)—and lay your hand upon him.

**27:19** "And set him before Eleazar the priest, and before all the congregation; and give him a charge in their sight.

**27:20** "And you shall put of your honor upon him—מֵהוֹדְךָ (me-hodecha)—that all the congregation of the children of Israel may listen.

**27:21** "And he shall stand before Eleazar the priest, who shall inquire for him by the judgment of the Urim before YHWH; at his word shall they go out, and at his word they shall come in, both he, and all the children of Israel with him, even all the congregation."

**27:22** And Moses did as YHWH commanded him; and he took Joshua, and set him before Eleazar the priest, and before all the congregation.

**27:23** And he laid his hands upon him, and gave him a charge, as YHWH spoke by the hand of Moses.

---

## Synthesis Notes

**Key Restorations:**

**The Daughters of Zelophehad:**
Five sisters—Mahlah, Noah, Hoglah, Milcah, and Tirzah—from the tribe of Manasseh. Their father died in the wilderness (of natural causes, not in Korah's rebellion). He had no sons.

**Their Case:**
They approach publicly—before Moses, Eleazar, the princes, and the whole congregation. Their argument:
1. Our father died in his own sin (not rebellion)
2. He had no sons
3. Why should his name disappear from his family?
4. Give us a possession among his brothers

They ask for inheritance rights normally reserved for sons.

**"The Daughters Speak Right":**
YHWH validates their claim: *ken benot Tselofchad doverot*—"the daughters of Zelophehad speak correctly." Their reasoning is sound; their request is just.

**The New Law:**
Inheritance passes in this order:
1. Sons
2. Daughters (if no sons)
3. Brothers (if no children)
4. Father's brothers (if no brothers)
5. Nearest kinsman (if no uncles)

This becomes "a statute of judgment" (*chuqqat mishpat*)—binding precedent established through case law.

**Moses' Mortality:**
YHWH tells Moses: go up Mount Abarim, see the land, and die. Like Aaron. The reason is restated: "Because you rebelled against my commandment... at the waters of Meribah."

Moses will see but not enter. The sentence from chapter 20 is reaffirmed.

**Moses' Request:**
Rather than plead for himself, Moses asks for a successor: "Let YHWH... appoint a man over the congregation." He uses the title "God of the spirits of all flesh"—the One who knows every individual and can select the right leader.

**"Sheep Without a Shepherd":**
Moses' concern: the congregation should not be left leaderless. This phrase recurs in prophetic and gospel literature (Ezekiel 34:5; Matthew 9:36).

**Joshua Appointed:**
YHWH selects Joshua son of Nun—"a man in whom is spirit." The same Joshua who was Moses' attendant (Exodus 24:13), who spied the land (Numbers 13), who stood with Caleb against the fearful majority.

**The Commissioning:**
- Moses lays hands on Joshua—transferring authority
- Joshua is set before Eleazar and the congregation—public installation
- Moses puts "of your honor upon him"—not all, but some of Moses' majesty transfers
- Joshua will inquire through the Urim (via Eleazar)—priestly guidance for decisions

**A Different Mode:**
Moses spoke with YHWH directly ("mouth to mouth," Numbers 12:8). Joshua will need Eleazar and the Urim. The relationship shifts: the unique Mosaic access will not continue.

**Archetypal Layer:** The daughters' case represents **law responding to justice**. The system adapts when an unjust outcome (name lost because of no sons) is identified. New cases create new precedent.

Moses' commissioning of Joshua is **succession planned**. Moses does not cling to power but ensures continuity. He asks for a successor before being asked; he transfers authority publicly.

**Psychological Reading:** The daughters' courage to stand before the entire assembly and make their case models advocacy. They name the injustice clearly and propose a solution.

Moses' response to his own mortality—concern for the people rather than self-pity—demonstrates mature leadership. His final act is ensuring the community's future.

**Ethical Inversion Applied:**
- Women inherit when there are no sons—the law expands to include them
- Case law creates precedent—new situations require new rulings
- Moses asks for a successor—leadership is about the mission, not the leader
- Joshua receives "some of" Moses' honor—succession involves transfer but not equality
- The Urim replaces direct access—different leaders have different modes

**Modern Equivalent:** The daughters' case anticipates property rights for women. Case law (applying principles to new situations) is how legal systems develop. And succession planning—ensuring leadership continuity before crisis—remains essential for organizational health.

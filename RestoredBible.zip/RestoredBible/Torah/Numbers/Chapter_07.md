# Numbers Chapter 7: The Offerings of the Tribal Leaders

*From the Hebrew: חֲנֻכַּת הַמִּזְבֵּחַ (Chanukat HaMizbeach) — Dedication of the Altar*

---

**7:1** And it came to pass on the day that Moses finished setting up the tabernacle, and had anointed it and sanctified it, and all its vessels, and the altar and all its vessels, and had anointed them and sanctified them,

**7:2** That the princes of Israel, the heads of their fathers' houses, the princes of the tribes, those who were over those who were numbered, offered.

**7:3** And they brought their offering before YHWH, six covered wagons, and twelve oxen: a wagon for every two princes, and for each one an ox; and they presented them before the tabernacle.

**7:4** And YHWH spoke unto Moses, saying:

**7:5** "Take it from them, that they may be used for the service of the tent of meeting; and you shall give them unto the Levites, to every man according to his service."

**7:6** And Moses took the wagons and the oxen, and gave them unto the Levites.

**7:7** Two wagons and four oxen he gave unto the sons of Gershon, according to their service.

**7:8** And four wagons and eight oxen he gave unto the sons of Merari, according to their service, under the hand of Ithamar the son of Aaron the priest.

**7:9** But unto the sons of Kohath he gave none, because the service of the holy things belonged to them; they carried them upon their shoulders.

---

**7:10** And the princes offered for the dedication of the altar on the day that it was anointed; and the princes brought their offering before the altar.

**7:11** And YHWH said unto Moses: "They shall offer their offering, each prince on his day, for the dedication of the altar."

**7:12** And he who offered his offering the first day was Nahshon the son of Amminadab, of the tribe of Judah.

**7:13** And his offering was one silver dish, the weight of which was a hundred and thirty shekels, one silver basin of seventy shekels, after the shekel of the sanctuary, both of them full of fine flour mixed with oil for a grain offering;

**7:14** One golden spoon of ten shekels, full of incense;

**7:15** One young bull, one ram, one male lamb a year old, for a burnt offering;

**7:16** One male goat for a sin offering;

**7:17** And for the sacrifice of peace offerings, two oxen, five rams, five male goats, five male lambs a year old. This was the offering of Nahshon the son of Amminadab.

---

**7:18** On the second day Nethanel the son of Zuar, prince of Issachar, offered.

**7:19** He offered for his offering one silver dish, the weight of which was a hundred and thirty shekels, one silver basin of seventy shekels, after the shekel of the sanctuary, both of them full of fine flour mixed with oil for a grain offering;

**7:20** One golden spoon of ten shekels, full of incense;

**7:21** One young bull, one ram, one male lamb a year old, for a burnt offering;

**7:22** One male goat for a sin offering;

**7:23** And for the sacrifice of peace offerings, two oxen, five rams, five male goats, five male lambs a year old. This was the offering of Nethanel the son of Zuar.

---

**7:24** On the third day Eliab the son of Helon, prince of the children of Zebulun:

**7:25** His offering was one silver dish, the weight of which was a hundred and thirty shekels, one silver basin of seventy shekels, after the shekel of the sanctuary, both of them full of fine flour mixed with oil for a grain offering;

**7:26** One golden spoon of ten shekels, full of incense;

**7:27** One young bull, one ram, one male lamb a year old, for a burnt offering;

**7:28** One male goat for a sin offering;

**7:29** And for the sacrifice of peace offerings, two oxen, five rams, five male goats, five male lambs a year old. This was the offering of Eliab the son of Helon.

---

**7:30-83** [The pattern continues for each of the remaining nine princes, each offering identically on successive days:]

- Day 4: **Elizur son of Shedeur** (Reuben)
- Day 5: **Shelumiel son of Zurishaddai** (Simeon)
- Day 6: **Eliasaph son of Deuel** (Gad)
- Day 7: **Elishama son of Ammihud** (Ephraim)
- Day 8: **Gamaliel son of Pedahzur** (Manasseh)
- Day 9: **Abidan son of Gideoni** (Benjamin)
- Day 10: **Ahiezer son of Ammishaddai** (Dan)
- Day 11: **Pagiel son of Ochran** (Asher)
- Day 12: **Ahira son of Enan** (Naphtali)

Each prince brings the identical offering: silver dish (130 shekels), silver basin (70 shekels), golden spoon (10 shekels), bull, ram, lamb (burnt offering), goat (sin offering), and peace offerings (2 oxen, 5 rams, 5 male goats, 5 lambs).

---

**7:84** This was the dedication of the altar, on the day when it was anointed, by the princes of Israel: twelve silver dishes, twelve silver basins, twelve golden spoons;

**7:85** Each silver dish weighing a hundred and thirty shekels, and each basin seventy; all the silver of the vessels two thousand and four hundred shekels, after the shekel of the sanctuary;

**7:86** Twelve golden spoons, full of incense, weighing ten shekels apiece, after the shekel of the sanctuary; all the gold of the spoons a hundred and twenty shekels;

**7:87** All the cattle for the burnt offering twelve bulls, twelve rams, twelve male lambs a year old, with their grain offering; and twelve male goats for a sin offering;

**7:88** And all the cattle for the sacrifice of peace offerings twenty-four bulls, sixty rams, sixty male goats, sixty male lambs a year old. This was the dedication of the altar, after it was anointed.

---

**7:89** And when Moses went into the tent of meeting to speak with YHWH, he heard the Voice speaking unto him from above the mercy seat that was upon the ark of the testimony, from between the two cherubim; and YHWH spoke unto him.

---

## Synthesis Notes

**Key Restorations:**

**The Setting:**
The chapter returns to the day the tabernacle was completed and anointed (Exodus 40). The twelve tribal leaders bring dedication offerings over twelve consecutive days.

**The Wagons and Oxen:**
Six wagons and twelve oxen for transporting the tabernacle:
- Gershonites receive 2 wagons, 4 oxen (for fabrics—lighter load)
- Merarites receive 4 wagons, 8 oxen (for structural elements—heavier load)
- Kohathites receive none—they carry the holy objects on their shoulders

The distribution reflects the weight of each clan's responsibility.

**One Prince Per Day:**
Each tribal leader presents his offering on a separate day. Though the offerings are identical, each is given its own day of honor. No tribe is rushed or combined with another.

**The Identical Offering:**

Each prince brings:
- **Silver dish** (130 shekels) full of flour + oil
- **Silver basin** (70 shekels) full of flour + oil
- **Golden spoon** (10 shekels) full of incense
- **Burnt offering**: 1 bull, 1 ram, 1 lamb
- **Sin offering**: 1 male goat
- **Peace offerings**: 2 oxen, 5 rams, 5 male goats, 5 lambs

**The Order:**
The princes offer in the same order as the camp arrangement (chapter 2):
1. Judah (east)
2. Issachar
3. Zebulun
4. Reuben (south)
5. Simeon
6. Gad
7. Ephraim (west)
8. Manasseh
9. Benjamin
10. Dan (north)
11. Asher
12. Naphtali

**The Totals:**
- Silver: 2,400 shekels
- Gold: 120 shekels
- Burnt offerings: 12 bulls, 12 rams, 12 lambs
- Sin offerings: 12 goats
- Peace offerings: 24 bulls, 60 rams, 60 goats, 60 lambs

**The Repetition:**
The chapter is the longest in the Torah (89 verses) because each prince's offering is recorded in full, even though identical. This is liturgical literature—the repetition honors each tribe equally.

**The Voice from the Mercy Seat (7:89):**
The chapter concludes with Moses entering the tent of meeting and hearing the Voice (*ha-Qol*) speaking from between the cherubim. This is theophany—YHWH speaks from the completed sanctuary. The dedication is accepted; communication is established.

**Archetypal Layer:** The twelve-day dedication represents **complete participation**—all Israel, through its leaders, dedicates the altar. The identical offerings express **equality**—no tribe is greater in dedication than another. The repetition is **liturgical emphasis**—what matters is said again and again.

The Voice from between the cherubim establishes the **function of the sanctuary**: this is where YHWH speaks. The tabernacle is not merely a dwelling but a place of communication.

**Psychological Reading:** The extended repetition creates a ritual rhythm. Each tribe has its day; each is named; each gift is recorded. The equality prevents jealousy; the individual attention prevents anonymity.

**Ethical Inversion Applied:**
- Each tribe honored equally—identical offerings, individual days
- The Kohathites carry on shoulders—the most holy requires personal burden
- Wagons distributed by need—heavier loads get more transport
- The Voice speaks from the mercy seat—the sanctuary enables communication
- Repetition honors each—no tribe is abbreviated or rushed

**Modern Equivalent:** The dedication of a sacred space involves all stakeholders. The principle of equal participation (each tribe's offering recorded fully) models how to honor diverse contributors. And the final verse—the Voice speaking from the mercy seat—reminds us that sacred spaces are meant for encounter, not merely observation.

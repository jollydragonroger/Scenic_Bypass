# Numbers Chapter 12: Miriam and Aaron Challenge Moses

*From the Hebrew: מִרְיָם (Miriam) — The Rebellion of Siblings*

---

**12:1** And Miriam and Aaron spoke against Moses because of the Cushite woman whom he had married; for he had married a Cushite woman.

**12:2** And they said: "Has YHWH indeed spoken only by Moses? Has he not spoken also by us?"—הֲרַק אַךְ־בְּמֹשֶׁה דִּבֶּר יהוה הֲלֹא גַּם־בָּנוּ דִבֵּר (ha-raq ach-be-Mosheh dibber YHWH ha-lo gam-banu dibber). And YHWH heard it.

**12:3** Now the man Moses was very humble, more than any man who was on the face of the earth—וְהָאִישׁ מֹשֶׁה עָנָו מְאֹד מִכֹּל הָאָדָם (ve-ha-ish Mosheh anav me'od mi-kol ha-adam).

**12:4** And YHWH spoke suddenly unto Moses, and unto Aaron, and unto Miriam: "Come out, you three, unto the tent of meeting." And they three came out.

**12:5** And YHWH came down in a pillar of cloud, and stood at the door of the tent, and called Aaron and Miriam; and they both came forth.

**12:6** And he said: "Hear now my words: If there is a prophet among you, I YHWH make myself known unto him in a vision, I speak with him in a dream.

**12:7** "My servant Moses is not so; he is faithful in all my house.

**12:8** "With him I speak mouth to mouth—פֶּה אֶל־פֶּה (peh el-peh)—in clear vision and not in riddles; and he beholds the form of YHWH. Why then were you not afraid to speak against my servant, against Moses?"

**12:9** And the anger of YHWH was kindled against them; and he departed.

**12:10** And when the cloud removed from over the tent, behold, Miriam was leprous, as white as snow—מְצֹרַעַת כַּשָּׁלֶג (metsora'at ka-shaleg); and Aaron looked upon Miriam, and behold, she was leprous.

**12:11** And Aaron said unto Moses: "Oh my lord, lay not sin upon us, in which we have done foolishly, and in which we have sinned.

**12:12** "Let her not be as one dead, of whom the flesh is half consumed when he comes out of his mother's womb."

**12:13** And Moses cried unto YHWH, saying: "Heal her now, O God, I beseech you—אֵל נָא רְפָא נָא לָהּ (El na refa na lah)."

**12:14** And YHWH said unto Moses: "If her father had but spit in her face, should she not be ashamed seven days? Let her be shut up outside the camp seven days, and after that she shall be brought in again."

**12:15** And Miriam was shut up outside the camp seven days; and the people did not journey until Miriam was brought in again.

**12:16** And afterward the people journeyed from Hazeroth, and encamped in the wilderness of Paran.

---

## Synthesis Notes

**Key Restorations:**

**The Complaint:**
Miriam and Aaron speak against Moses. The stated reason: his Cushite wife. The real issue (verse 2): "Has YHWH spoken only by Moses? Has he not spoken also by us?" This is a challenge to Moses' unique authority.

**The Cushite Woman:**
*Ishah Kushit* (אִשָּׁה כֻשִׁית)—a woman from Cush (Ethiopia/Nubia). This may be:
- Zipporah (if Midianites are connected to Cush)
- A second wife (not previously mentioned)
- A symbolic term

The complaint about the wife may mask the real grievance: prophetic jealousy.

**"YHWH Heard It":**
The complaint is overheard by YHWH. What is spoken privately against God's servant is not private.

**Moses' Humility:**
*Anav me'od* (עָנָו מְאֹד)—"very humble/meek." This parenthetical note explains why Moses does not defend himself. His humility is precisely what makes the attack unjust.

**YHWH's Sudden Summons:**
"YHWH spoke suddenly"—*pit'om* (פִּתְאֹם), unexpectedly. The three siblings are called to the tent. YHWH appears in the cloud and addresses Aaron and Miriam directly.

**Levels of Prophetic Communication:**

YHWH distinguishes Moses from other prophets:
- **Other prophets**: visions, dreams, riddles (*chidot*)
- **Moses**: mouth to mouth (*peh el-peh*), clear vision (*mar'eh*), beholds YHWH's form (*temunah*)

Moses' access is unique, unmediated, direct. The challenge to his authority misunderstands the nature of his calling.

**"Why Were You Not Afraid?":**
YHWH's question cuts to the heart: speaking against Moses is speaking against YHWH's chosen. The lack of fear reveals spiritual blindness.

**Miriam's Affliction:**
Miriam becomes *metsora'at*—afflicted with skin disease, "white as snow." Aaron is not struck. Possible reasons:
- Miriam was the instigator (her name appears first)
- Aaron's priestly function protects him from this particular affliction
- Aaron's immediate confession and plea indicates he recognized the sin

**Aaron's Plea:**
Aaron calls Moses "my lord" (*adoni*)—acknowledging his authority. He confesses: "we have done foolishly... we have sinned." He asks that Miriam not be "as one dead"—her condition is like a stillborn with decaying flesh.

**Moses' Prayer:**
The shortest intercessory prayer in Scripture: *El na refa na lah*—"God, please, heal her, please." Five words. Moses, the one wronged, prays for his accuser.

**Seven Days Outside:**
YHWH's response: the discipline stands for seven days. The analogy: if her father had spit in her face (an act of severe shame), she would be shamed seven days. The divine rebuke requires at least this much.

**The People Wait:**
Israel does not journey until Miriam is restored. Her importance is recognized—she is prophetess (Exodus 15:20), leader alongside Moses and Aaron (Micah 6:4). The camp waits for her.

**Archetypal Layer:** The challenge to Moses' authority is a **rebellion from within the inner circle**—not outsiders but siblings, not strangers but prophets. YHWH's defense of Moses establishes the **unique prophetic calling**: Moses is not merely one prophet among others but the servant faithful in all YHWH's house.

Miriam's affliction and restoration follow the **pattern of prophetic judgment**: swift punishment, confession, intercession, and restoration after a period of discipline.

**Psychological Reading:** The jealousy masked as concern about the Cushite wife reveals how personal grievance can hide behind pious objection. The real issue (prophetic authority) is not stated directly but is what YHWH addresses.

Moses' immediate intercession for his accusers demonstrates the humility attributed to him. He does not gloat, does not delay, does not condition his prayer.

**Ethical Inversion Applied:**
- The humble leader does not defend himself—YHWH defends
- Prophetic jealousy is rebuked—Moses' role is unique, not competitive
- The accuser is disciplined—speaking against YHWH's servant has consequences
- The wronged one intercedes—Moses prays for Miriam
- Restoration follows discipline—Miriam is brought back after seven days
- The community waits—no one is left behind

**Modern Equivalent:** Challenges to leadership from those closest (family, inner circle) are particularly painful and destructive. The pattern here: YHWH defends the faithful servant; the challenger is disciplined; but the wronged leader intercedes rather than retaliates; restoration is possible after appropriate discipline.

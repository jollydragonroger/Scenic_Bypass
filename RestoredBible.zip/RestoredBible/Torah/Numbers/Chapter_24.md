# Numbers Chapter 24: Balaam's Final Oracles

*From the Hebrew: כּוֹכָב מִיַּעֲקֹב (Kochav mi-Ya'aqov) — A Star from Jacob*

---

**24:1** And when Balaam saw that it pleased YHWH to bless Israel, he went not, as at the other times, to meet with enchantments, but he set his face toward the wilderness.

**24:2** And Balaam lifted up his eyes, and he saw Israel dwelling according to their tribes; and the spirit of God came upon him—וַתְּהִי עָלָיו רוּחַ אֱלֹהִים (va-tehi alav ruach Elohim).

**24:3** And he took up his parable, and said:

"The oracle of Balaam the son of Beor,
And the oracle of the man whose eye is opened—נְאֻם הַגֶּבֶר שְׁתֻם הָעָיִן (ne'um ha-gever shetum ha-ayin);

**24:4** "The oracle of him who hears the words of God,
Who sees the vision of the Almighty—מַחֲזֵה שַׁדַּי (machazeh Shaddai),
Fallen down, yet having his eyes uncovered:

**24:5** "How goodly are your tents, O Jacob,
Your dwellings, O Israel!—מַה־טֹּבוּ אֹהָלֶיךָ יַעֲקֹב (mah-tovu ohaleicha Ya'aqov)

**24:6** "As valleys are they spread forth,
As gardens by the river-side,
As aloes which YHWH has planted,
As cedar trees beside the waters.

**24:7** "Water shall flow from his branches,
And his seed shall be in many waters;
And his king shall be higher than Agag,
And his kingdom shall be exalted.

**24:8** "God brings him forth out of Egypt;
He has as it were the strength of the wild ox;
He shall eat up the nations his adversaries,
And shall break their bones in pieces,
And pierce them through with his arrows.

**24:9** "He couches, he lies down as a lion,
And as a lioness; who shall rouse him up?
Blessed is he who blesses you,
And cursed is he who curses you."

---

**24:10** And Balak's anger was kindled against Balaam, and he struck his hands together; and Balak said unto Balaam: "I called you to curse my enemies, and behold, you have altogether blessed them these three times.

**24:11** "Therefore now flee to your place; I thought to promote you to great honor; but lo, YHWH has kept you back from honor."

**24:12** And Balaam said unto Balak: "Did I not also speak to your messengers whom you sent unto me, saying:

**24:13** "'If Balak would give me his house full of silver and gold, I cannot go beyond the word of YHWH, to do either good or bad of my own mind; what YHWH speaks, that will I speak'?

**24:14** "And now, behold, I go unto my people; come, I will announce to you what this people shall do to your people in the end of days—בְּאַחֲרִית הַיָּמִים (be-acharit ha-yamim)."

---

**24:15** And he took up his parable, and said:

"The oracle of Balaam the son of Beor,
And the oracle of the man whose eye is opened;

**24:16** "The oracle of him who hears the words of God,
And knows the knowledge of the Most High—וְיֹדֵעַ דַּעַת עֶלְיוֹן (ve-yodea da'at Elyon),
Who sees the vision of the Almighty,
Fallen down, yet having his eyes uncovered:

**24:17** "I see him, but not now;
I behold him, but not near;
There shall step forth a star out of Jacob—דָּרַךְ כּוֹכָב מִיַּעֲקֹב (darach kochav mi-Ya'aqov),
And a scepter shall rise out of Israel,
And shall smite through the corners of Moab,
And break down all the sons of Seth.

**24:18** "And Edom shall be a possession,
Seir also, his enemies, shall be a possession;
While Israel does valiantly.

**24:19** "And out of Jacob shall one have dominion,
And shall destroy the remnant from the city."

---

**24:20** And he looked upon Amalek, and took up his parable, and said:

"Amalek was the first of the nations;
But his end shall be destruction."

**24:21** And he looked upon the Kenite, and took up his parable, and said:

"Strong is your dwelling-place,
And your nest is set in the rock.

**24:22** "Nevertheless Kain shall be wasted;
How long? Asshur shall carry you away captive."

**24:23** And he took up his parable, and said:

"Alas, who shall live when God does this?

**24:24** "But ships shall come from the coast of Kittim,
And they shall afflict Asshur, and shall afflict Eber,
And he also shall come to destruction."

**24:25** And Balaam rose up, and went and returned to his place; and Balak also went his way.

---

## Synthesis Notes

**Key Restorations:**

**No More Enchantments:**
Balaam abandons his divination techniques. He simply looks at Israel and receives the spirit of God directly. The professional apparatus is set aside.

**"The Man Whose Eye Is Opened":**
*Shetum ha-ayin*—a difficult phrase, possibly meaning "opened" or "closed" (the Hebrew is ambiguous). The context suggests opened: Balaam now sees clearly what he could not see before (remember the donkey incident).

**The Third Oracle (24:3-9):**

The most lyrical:
- **"How goodly are your tents, O Jacob"** (*Mah tovu*)—becomes a beloved Jewish prayer, recited upon entering synagogue
- **Garden and river imagery**—Israel as planted, watered, flourishing
- **"His king shall be higher than Agag"**—prophecy of royalty, specifically mentioning the Amalekite king Agag (fulfilled by Saul in 1 Samuel 15)
- **Lion imagery repeated**—Israel as majestic predator
- **"Blessed is he who blesses you, cursed is he who curses you"**—echo of the Abrahamic blessing (Genesis 12:3)

**Balak's Fury:**
He strikes his hands together in frustration. Three attempts, three blessings. He dismisses Balaam without payment: "YHWH has kept you back from honor."

**The Fourth Oracle (24:15-19):**

The messianic prophecy:
- **"I see him, but not now; I behold him, but not near"**—future vision
- **"A star out of Jacob"** (*kochav mi-Ya'aqov*)—the star prophecy
- **"A scepter out of Israel"**—royal authority
- **Moab and Edom conquered**—neighboring enemies subdued
- **"Out of Jacob shall one have dominion"**—universal rule

**The Star and Scepter:**
This prophecy became central in Jewish messianic expectation. Bar Kokhba ("Son of the Star") claimed fulfillment in the second century CE revolt. Christians see fulfillment in Jesus (the Magi following a star, Matthew 2).

**"In the End of Days" (בְּאַחֲרִית הַיָּמִים):**
Balaam announces he will prophesy what happens *be-acharit ha-yamim*—in the latter days, the eschatological future.

**The Minor Oracles (24:20-24):**

Brief prophecies against other nations:
- **Amalek**: "first of nations" in attacking Israel, but destined for destruction
- **Kenites**: secure ("nest in the rock") but eventually carried away by Assyria
- **Kittim** (Cyprus/Greece?): ships from the west will afflict Assyria and Eber (Hebrews?)

These cryptic verses may reference historical events or remain eschatologically unfulfilled.

**Balaam Departs:**
He returns to his place. But his story is not over—he will later advise Moab/Midian on how to seduce Israel (Numbers 31:16; Revelation 2:14).

**Archetypal Layer:** The star and scepter represent **kingship arising from Israel** that will have cosmic significance. The vision extends beyond immediate context to "the end of days." Balaam—the pagan seer—becomes the vehicle for Israel's most expansive messianic prophecy.

**Psychological Reading:** Balaam has fully surrendered to his prophetic function. The earlier conflict (desire for reward vs. inability to speak against YHWH) resolves into pure utterance. He speaks beyond himself, seeing what he cannot reach ("not now... not near").

**Ethical Inversion Applied:**
- The hired curser becomes the source of messianic prophecy
- "Mah tovu"—the enemy's words become Israel's prayer
- The star and scepter—royalty announced by an outsider
- "In the end of days"—the pagan seer speaks of Israel's eschatological future
- Balak loses both the curse and the money—he gets nothing

**Modern Equivalent:** Sometimes the clearest vision of a community's destiny comes from outside that community. The "Mah tovu" transformation—enemy's utterance becoming beloved prayer—models how hostile words can be reframed as blessing. And the star/scepter imagery continues to shape messianic expectation across traditions.

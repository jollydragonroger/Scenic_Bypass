# Numbers Chapter 28: The Daily and Festival Offerings

*From the Hebrew: קָרְבָּנִי (Qorbani) — My Offering*

---

**28:1** And YHWH spoke unto Moses, saying:

**28:2** "Command the children of Israel, and say unto them: 'My offering, my food for my fire offerings, of a pleasing aroma unto me, shall you observe to offer unto me in its due season.'

**28:3** "And you shall say unto them: 'This is the fire offering which you shall bring unto YHWH: male lambs a year old without blemish, two day by day, for a continual burnt offering—עֹלַת תָּמִיד (olat tamid).

**28:4** "'The one lamb you shall offer in the morning, and the other lamb you shall offer towards evening;

**28:5** "'And a tenth part of an ephah of fine flour for a grain offering, mixed with a fourth part of a hin of beaten oil.

**28:6** "'It is a continual burnt offering, which was ordained in Mount Sinai for a pleasing aroma, a fire offering unto YHWH.

**28:7** "'And the drink offering thereof shall be a fourth part of a hin for the one lamb; in the holy place you shall pour out a drink offering of strong drink unto YHWH.

**28:8** "'And the other lamb you shall offer towards evening; as the grain offering of the morning, and as the drink offering thereof, you shall offer it, a fire offering of a pleasing aroma unto YHWH.

---

**28:9** "'And on the sabbath day two male lambs a year old without blemish, and two tenth parts of an ephah of fine flour for a grain offering, mixed with oil, and the drink offering thereof.

**28:10** "'This is the burnt offering of every sabbath, besides the continual burnt offering, and the drink offering thereof.

---

**28:11** "'And in the beginnings of your months you shall present a burnt offering unto YHWH: two young bulls, and one ram, and seven male lambs a year old, without blemish;

**28:12** "'And three tenth parts of an ephah of fine flour for a grain offering, mixed with oil, for each bull; and two tenth parts of fine flour for a grain offering, mixed with oil, for the one ram;

**28:13** "'And a tenth part of fine flour mixed with oil for a grain offering unto every lamb; for a burnt offering of a pleasing aroma, a fire offering unto YHWH.

**28:14** "'And their drink offerings shall be half a hin of wine for a bull, and a third part of a hin for the ram, and a fourth part of a hin for a lamb. This is the burnt offering of every month throughout the months of the year.

**28:15** "'And one male goat for a sin offering unto YHWH; it shall be offered besides the continual burnt offering, and the drink offering thereof.

---

**28:16** "'And in the first month, on the fourteenth day of the month, is YHWH's Passover.

**28:17** "'And on the fifteenth day of this month shall be a feast; seven days shall unleavened bread be eaten.

**28:18** "'On the first day shall be a holy convocation; you shall do no manner of servile work;

**28:19** "'But you shall present a fire offering, a burnt offering unto YHWH: two young bulls, and one ram, and seven male lambs a year old; they shall be unto you without blemish;

**28:20** "'And their grain offering, fine flour mixed with oil; three tenth parts shall you offer for a bull, and two tenth parts for the ram;

**28:21** "'A tenth part shall you offer for every lamb of the seven lambs;

**28:22** "'And one male goat for a sin offering, to make atonement for you.

**28:23** "'You shall offer these besides the burnt offering of the morning, which is for a continual burnt offering.

**28:24** "'After this manner you shall offer daily, for seven days, the food of the fire offering of a pleasing aroma unto YHWH; it shall be offered besides the continual burnt offering, and the drink offering thereof.

**28:25** "'And on the seventh day you shall have a holy convocation; you shall do no manner of servile work.

---

**28:26** "'Also on the day of the first-fruits, when you bring a new grain offering unto YHWH, in your Feast of Weeks, you shall have a holy convocation; you shall do no manner of servile work;

**28:27** "'But you shall present a burnt offering for a pleasing aroma unto YHWH: two young bulls, one ram, seven male lambs a year old;

**28:28** "'And their grain offering, fine flour mixed with oil, three tenth parts for each bull, two tenth parts for the one ram,

**28:29** "'A tenth part for every lamb of the seven lambs;

**28:30** "'One male goat, to make atonement for you.

**28:31** "'Besides the continual burnt offering, and the grain offering thereof, you shall offer them—they shall be unto you without blemish—and their drink offerings.'"

---

## Synthesis Notes

**Key Restorations:**

**The Daily Offering (תָּמִיד, Tamid):**
Two lambs each day—one morning, one evening. This is the *olat tamid*, the continual burnt offering. It bookends every day with sacrifice. The entire Temple service is built around maintaining this offering.

**Accompanying Offerings:**
Each lamb requires:
- 1/10 ephah fine flour (grain offering)
- 1/4 hin oil (mixed with flour)
- 1/4 hin wine (drink offering)

**The Sabbath Addition:**
On Sabbath, add to the daily offering:
- 2 additional lambs
- 2/10 ephah flour
- Appropriate drink offerings

The Sabbath is marked by increased offering, not decreased.

**The New Moon (Rosh Chodesh):**
At the beginning of each month:
- 2 bulls
- 1 ram
- 7 lambs
- Proportional grain and drink offerings
- 1 male goat for sin offering

The monthly cycle is marked liturgically. The new moon was a minor festival.

**Passover and Unleavened Bread:**
- 14th of first month: Passover
- 15th-21st: Feast of Unleavened Bread
- First and seventh days: holy convocations (no work)
- Each day: same offerings as new moon (2 bulls, 1 ram, 7 lambs, 1 goat)

These are *in addition to* the daily offering.

**Feast of Weeks (Shavuot):**
- Day of first-fruits
- Holy convocation (no work)
- Same offerings as Passover days

**The Pattern:**
Daily < Sabbath < New Moon < Festivals

Each level adds to what precedes. Nothing replaces the *tamid*; everything builds on it.

**"Besides the Continual Burnt Offering":**
The phrase repeats throughout. The daily offering never stops; festival offerings supplement it.

**Archetypal Layer:** The calendar of offerings creates a **rhythm of worship**. Daily, weekly, monthly, annually—each cycle has its sacrificial markers. Time is sanctified through ritual.

The *tamid* (continual offering) represents **unceasing worship**. Morning and evening, every day, the altar burns. This is Israel's perpetual orientation toward YHWH.

**Psychological Reading:** The detailed prescriptions create predictability and structure. The worshipper knows what happens when. The rhythm shapes consciousness—time is measured by offerings.

**Ethical Inversion Applied:**
- Daily offering is foundational—everything else adds to it
- Sabbath increases rather than decreases worship
- The new moon marks monthly renewal
- Festivals intensify the ordinary pattern
- "My offering, my food"—YHWH takes ownership

**Modern Equivalent:** Communities mark time through regular gatherings (daily prayer, weekly worship, annual celebrations). The principle of "adding to, not replacing" suggests that special occasions should enhance rather than substitute for regular practice.

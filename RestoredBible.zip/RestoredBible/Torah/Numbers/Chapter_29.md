# Numbers Chapter 29: The Fall Festival Offerings

*From the Hebrew: יוֹם תְּרוּעָה (Yom Teru'ah) — Day of Blowing*

---

**29:1** "And in the seventh month, on the first day of the month, you shall have a holy convocation; you shall do no manner of servile work; it is a day of blowing—יוֹם תְּרוּעָה (yom teru'ah)—unto you.

**29:2** "And you shall offer a burnt offering for a pleasing aroma unto YHWH: one young bull, one ram, seven male lambs a year old, without blemish;

**29:3** "And their grain offering, fine flour mixed with oil, three tenth parts for the bull, two tenth parts for the ram,

**29:4** "And one tenth part for every lamb of the seven lambs;

**29:5** "And one male goat for a sin offering, to make atonement for you;

**29:6** "Besides the burnt offering of the new moon, and the grain offering thereof, and the continual burnt offering and the grain offering thereof, and their drink offerings, according to their ordinance, for a pleasing aroma, a fire offering unto YHWH.

---

**29:7** "And on the tenth day of this seventh month you shall have a holy convocation; and you shall afflict your souls; you shall do no manner of work.

**29:8** "But you shall offer a burnt offering unto YHWH for a pleasing aroma: one young bull, one ram, seven male lambs a year old; they shall be unto you without blemish.

**29:9** "And their grain offering, fine flour mixed with oil, three tenth parts for the bull, two tenth parts for the one ram,

**29:10** "A tenth part for every lamb of the seven lambs;

**29:11** "One male goat for a sin offering; besides the sin offering of atonement, and the continual burnt offering, and the grain offering thereof, and their drink offerings.

---

**29:12** "And on the fifteenth day of the seventh month you shall have a holy convocation; you shall do no manner of servile work, and you shall keep a feast unto YHWH seven days.

**29:13** "And you shall offer a burnt offering, a fire offering, of a pleasing aroma unto YHWH: thirteen young bulls, two rams, fourteen male lambs a year old; they shall be without blemish.

**29:14** "And their grain offering, fine flour mixed with oil, three tenth parts for every bull of the thirteen bulls, two tenth parts for each ram of the two rams,

**29:15** "And a tenth part for every lamb of the fourteen lambs;

**29:16** "And one male goat for a sin offering; besides the continual burnt offering, the grain offering thereof, and the drink offering thereof.

**29:17** "And on the second day you shall offer twelve young bulls, two rams, fourteen male lambs a year old, without blemish;

**29:18** "And their grain offering and their drink offerings for the bulls, for the rams, and for the lambs, according to their number, after the ordinance;

**29:19** "And one male goat for a sin offering; besides the continual burnt offering, and the grain offering thereof, and their drink offerings.

**29:20** "And on the third day eleven bulls, two rams, fourteen lambs a year old, without blemish;

**29:21** "And their grain offering and their drink offerings for the bulls, for the rams, and for the lambs, according to their number, after the ordinance;

**29:22** "And one male goat for a sin offering; besides the continual burnt offering, and the grain offering thereof, and the drink offering thereof.

**29:23** "And on the fourth day ten bulls, two rams, fourteen lambs a year old, without blemish;

**29:24** "Their grain offering and their drink offerings for the bulls, for the rams, and for the lambs, according to their number, after the ordinance;

**29:25** "And one male goat for a sin offering; besides the continual burnt offering, the grain offering thereof, and the drink offering thereof.

**29:26** "And on the fifth day nine bulls, two rams, fourteen lambs a year old, without blemish;

**29:27** "And their grain offering and their drink offerings for the bulls, for the rams, and for the lambs, according to their number, after the ordinance;

**29:28** "And one male goat for a sin offering; besides the continual burnt offering, and the grain offering thereof, and the drink offering thereof.

**29:29** "And on the sixth day eight bulls, two rams, fourteen lambs a year old, without blemish;

**29:30** "And their grain offering and their drink offerings for the bulls, for the rams, and for the lambs, according to their number, after the ordinance;

**29:31** "And one male goat for a sin offering; besides the continual burnt offering, the grain offering thereof, and the drink offerings thereof.

**29:32** "And on the seventh day seven bulls, two rams, fourteen lambs a year old, without blemish;

**29:33** "And their grain offering and their drink offerings for the bulls, for the rams, and for the lambs, according to their number, after the ordinance;

**29:34** "And one male goat for a sin offering; besides the continual burnt offering, the grain offering thereof, and the drink offering thereof.

---

**29:35** "On the eighth day you shall have a solemn assembly—עֲצֶרֶת (atseret); you shall do no manner of servile work;

**29:36** "But you shall offer a burnt offering, a fire offering, of a pleasing aroma unto YHWH: one bull, one ram, seven lambs a year old, without blemish;

**29:37** "Their grain offering and their drink offerings for the bull, for the ram, and for the lambs, according to their number, after the ordinance;

**29:38** "And one male goat for a sin offering; besides the continual burnt offering, and the grain offering thereof, and the drink offering thereof.

**29:39** "These you shall offer unto YHWH in your appointed seasons, besides your vows, and your freewill offerings, whether they be your burnt offerings, or your grain offerings, or your drink offerings, or your peace offerings."

**29:40** And Moses told the children of Israel according to all that YHWH commanded Moses.

---

## Synthesis Notes

**Key Restorations:**

**The Seventh Month:**
The holiest month of the year, containing:
- 1st day: Yom Teru'ah (Day of Blowing / Rosh Hashanah)
- 10th day: Yom Kippur (Day of Atonement)
- 15th-21st: Sukkot (Feast of Booths)
- 22nd (8th day of Sukkot): Shemini Atseret (Solemn Assembly)

**Day of Blowing (1st day):**
*Yom teru'ah*—the shofar is blown. This becomes Rosh Hashanah (New Year) in later Judaism. Offerings: 1 bull, 1 ram, 7 lambs, 1 goat. Added to the new moon offerings (since it's also the first of the month).

**Day of Atonement (10th day):**
"Afflict your souls"—fasting. "Do no manner of work"—complete rest (not just "servile work"). Same burnt offerings as Day of Blowing, plus the special Yom Kippur rituals (Leviticus 16). Two sin offerings: the regular one here, plus the special atonement offerings.

**Feast of Booths (15th-21st):**

The most elaborate offerings of the year. The bull count descends daily:

| Day | Bulls | Rams | Lambs | Goat |
|-----|-------|------|-------|------|
| 1 | 13 | 2 | 14 | 1 |
| 2 | 12 | 2 | 14 | 1 |
| 3 | 11 | 2 | 14 | 1 |
| 4 | 10 | 2 | 14 | 1 |
| 5 | 9 | 2 | 14 | 1 |
| 6 | 8 | 2 | 14 | 1 |
| 7 | 7 | 2 | 14 | 1 |

**Total bulls over seven days: 70**

The tradition interprets this as representing the 70 nations of the world (Genesis 10). Sukkot offerings are for all humanity.

**Descending Pattern:**
The bulls decrease each day from 13 to 7. Various interpretations:
- Diminishing intensity as the festival concludes
- Symbolic movement from many to seven (completion)
- The world's nations gradually included

**Shemini Atseret (8th day):**
*Atseret*—solemn assembly. The offerings drop dramatically: 1 bull, 1 ram, 7 lambs, 1 goat. This is intimate, focused—just Israel and YHWH after the universal celebration.

**The Numbers:**

Over Sukkot alone:
- 70 bulls
- 14 rams
- 98 lambs
- 7 goats

This is the most intensive sacrificial period of the year.

**"Besides Your Vows and Freewill Offerings":**
The prescribed offerings are minimum requirements. Personal vows and voluntary offerings are additional.

**Archetypal Layer:** The seventh month concentrates the sacred calendar. Atonement (Yom Kippur) precedes celebration (Sukkot). The decreasing bulls suggest **movement from universal to particular**—the nations, then Israel alone.

The 70 bulls for 70 nations positions Sukkot as **universal worship**—Israel's offerings on behalf of humanity.

**Psychological Reading:** The intensive sacrificial schedule creates total immersion. For three weeks (counting preparation), the seventh month is consumed with sacred activity. This is the climax of the liturgical year.

**Ethical Inversion Applied:**
- The seventh month is climactic—the holiest period
- Atonement precedes celebration—cleansing before rejoicing
- 70 bulls for 70 nations—Israel's offerings benefit the world
- Descending count—movement toward completion
- The eighth day is intimate—after universal celebration, particular relationship

**Modern Equivalent:** The fall holy days remain central in Jewish practice. The structure of atonement before celebration shapes High Holy Day observance. And the tradition of universal intercession (the 70 bulls) suggests that particular communities can worship on behalf of the larger world.

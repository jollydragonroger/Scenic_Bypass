# Numbers Chapter 25: The Sin at Peor

*From the Hebrew: בַּעַל פְּעוֹר (Baal Peor) — The Apostasy*

---

**25:1** And Israel abode in Shittim, and the people began to commit harlotry with the daughters of Moab.

**25:2** And they called the people unto the sacrifices of their gods; and the people ate, and bowed down to their gods.

**25:3** And Israel joined himself unto Baal-peor—וַיִּצָּמֶד יִשְׂרָאֵל לְבַעַל פְּעוֹר (va-yitsamed Yisra'el le-Baal Pe'or); and the anger of YHWH was kindled against Israel.

**25:4** And YHWH said unto Moses: "Take all the chiefs of the people, and hang them up unto YHWH before the sun, that the fierce anger of YHWH may turn away from Israel."

**25:5** And Moses said unto the judges of Israel: "Slay every one his men who have joined themselves unto Baal-peor."

**25:6** And behold, one of the children of Israel came and brought unto his brothers a Midianite woman in the sight of Moses, and in the sight of all the congregation of the children of Israel, while they were weeping at the door of the tent of meeting.

**25:7** And when Phinehas, the son of Eleazar, the son of Aaron the priest, saw it, he rose up from the midst of the congregation, and took a spear in his hand.

**25:8** And he went after the man of Israel into the chamber, and thrust both of them through, the man of Israel, and the woman through her belly. So the plague was stayed from the children of Israel.

**25:9** And those who died by the plague were twenty-four thousand.

---

**25:10** And YHWH spoke unto Moses, saying:

**25:11** "Phinehas, the son of Eleazar, the son of Aaron the priest, has turned my wrath away from the children of Israel, in that he was zealous with my zeal among them—בְּקַנְאוֹ אֶת־קִנְאָתִי (be-qan'o et-qin'ati)—so that I consumed not the children of Israel in my zeal.

**25:12** "Wherefore say: 'Behold, I give unto him my covenant of peace—בְּרִיתִי שָׁלוֹם (beriti shalom).

**25:13** "'And it shall be unto him, and to his seed after him, the covenant of an everlasting priesthood—בְּרִית כְּהֻנַּת עוֹלָם (berit kehunnat olam); because he was zealous for his God, and made atonement for the children of Israel.'"

**25:14** Now the name of the man of Israel who was slain, who was slain with the Midianite woman, was Zimri, the son of Salu, a prince of a father's house among the Simeonites.

**25:15** And the name of the Midianite woman who was slain was Cozbi, the daughter of Zur; he was head of a people of a father's house in Midian.

**25:16** And YHWH spoke unto Moses, saying:

**25:17** "Harass the Midianites, and smite them;

**25:18** "For they harass you with their wiles, with which they have beguiled you in the matter of Peor, and in the matter of Cozbi, the daughter of the prince of Midian, their sister, who was slain on the day of the plague in the matter of Peor."

---

## Synthesis Notes

**Key Restorations:**

**The Setting:**
Israel is at Shittim, in the plains of Moab, near the Jordan. They have just received Balaam's blessings. Now comes the seduction Balaam could not curse but would later advise (Numbers 31:16; Revelation 2:14).

**Sexual and Spiritual Apostasy:**
The Moabite/Midianite women invite Israelite men to:
1. Sexual relations (*zanah*—harlotry)
2. Sacrificial meals
3. Worship of their gods

The sequence: physical intimacy → shared table → shared altar. Sex leads to idolatry.

**"Joined to Baal-Peor":**
*Yitsamed le-Baal Pe'or*—Israel is "yoked" to the local deity. Baal-Peor was likely a fertility god worshipped at Mount Peor. The language suggests binding, attachment, marriage to the foreign god.

**YHWH's Command:**
"Take all the chiefs of the people, and hang them up unto YHWH before the sun." Public execution of leaders—those responsible for allowing or participating in the apostasy. Exposure "before the sun" makes the judgment visible.

**Zimri's Brazen Act:**
While the congregation weeps at the tent of meeting (mourning the sin, fearing the plague), Zimri son of Salu—a Simeonite prince—publicly brings a Midianite woman (Cozbi, daughter of a Midianite chief) into the camp, "in the sight of Moses, and in the sight of all the congregation."

This is not private sin but public defiance. A prince of Israel, a princess of Midian—political and religious rebellion combined.

**Phinehas Acts:**
Phinehas, grandson of Aaron, takes a spear and follows them into the tent (*qubbah*—possibly a shrine-tent or bridal chamber). He thrusts both through with one blow. The plague stops. 24,000 have already died.

**The Covenant of Peace:**
YHWH commends Phinehas:
- "He was zealous with my zeal"—his passion matched YHWH's
- "He made atonement for the children of Israel"—his act was atoning
- "My covenant of peace"—*beriti shalom*
- "Covenant of everlasting priesthood"—the Phinehas line receives perpetual priesthood

**Zealotry:**
*Qin'ah* (קִנְאָה)—zeal, jealousy. Phinehas's zeal reflects YHWH's. He acts with divine passion against covenant betrayal. This becomes the model for later zealot movements (Elijah, Maccabees, the Zealot party of Jesus' time).

**The Names:**
- **Zimri** ("my song/praise")—ironic, given his shameful act
- **Cozbi** ("my lie/deception")—fitting for one who participated in seducing Israel
- **Phinehas** (Egyptian origin, possibly "the Nubian")—the faithful priest

**War Against Midian:**
YHWH commands: "Harass the Midianites and smite them." The seduction was strategic—"they beguiled you in the matter of Peor." Midian will be attacked in chapter 31.

**Balaam's Role:**
Later texts reveal (Numbers 31:16) that Balaam advised this strategy. Unable to curse Israel directly, he showed how to seduce them into cursing themselves through apostasy.

**Archetypal Layer:** The sin at Peor represents **seduction where assault failed**. What Balak's curses couldn't accomplish, Moab/Midian's women did. Sexual temptation becomes the gateway to spiritual betrayal.

Phinehas's act is **violent atonement**—his spear stops the plague. The priest who kills becomes the priest who saves. This paradox—violence as salvation—is troubling but central to the narrative.

**Psychological Reading:** The public nature of Zimri's act suggests deliberate provocation—defiance of Moses and YHWH. Phinehas's immediate response indicates he understood the symbolic weight of the moment. The entire community watched both the sin and the response.

**Ethical Inversion Applied:**
- Sexual sin leads to spiritual apostasy—the body to the soul
- Public sin requires public response—Zimri's defiance, Phinehas's execution
- Zeal can atone—passion for God's honor has saving power
- The covenant of peace comes through violence—paradox of atonement
- Balaam's indirect strategy—what he couldn't curse, he advised others to corrupt

**Difficult Elements:**
Phinehas's killing is extrajudicial violence. The text presents it as heroic and atoning. This has been used to justify religious violence throughout history. The ethical challenge: distinguishing divinely sanctioned action in a unique historical moment from general warrant for vigilante violence.

**Modern Equivalent:** The connection between sexual and spiritual compromise remains relevant. Intimate relationships shape beliefs. And the question of when passionate action is appropriate versus when it becomes dangerous zealotry continues to challenge communities of faith.

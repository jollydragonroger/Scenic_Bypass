# Numbers Chapter 17: Aaron's Rod That Budded

*From the Hebrew: מַטֶּה אַהֲרֹן (Matteh Aharon) — The Staff of Aaron*

---

**17:1** And YHWH spoke unto Moses, saying:

**17:2** "Speak unto the children of Israel, and take of them rods, one for each fathers' house, of all their princes according to their fathers' houses, twelve rods; you shall write every man's name upon his rod.

**17:3** "And you shall write Aaron's name upon the rod of Levi; for there shall be one rod for each head of their fathers' houses.

**17:4** "And you shall lay them up in the tent of meeting before the testimony, where I meet with you.

**17:5** "And it shall come to pass, that the man whom I shall choose, his rod shall bud; and I will make to cease from me the murmurings of the children of Israel, which they murmur against you."

**17:6** And Moses spoke unto the children of Israel; and all their princes gave him rods, one for each prince, according to their fathers' houses, twelve rods; and the rod of Aaron was among their rods.

**17:7** And Moses laid up the rods before YHWH in the tent of the testimony.

**17:8** And it came to pass on the morrow, that Moses went into the tent of the testimony; and behold, the rod of Aaron for the house of Levi had budded, and put forth buds, and bloomed blossoms, and bore ripe almonds—וַיִּגְמֹל שְׁקֵדִים (va-yigmol sheqedim).

**17:9** And Moses brought out all the rods from before YHWH unto all the children of Israel; and they looked, and took every man his rod.

**17:10** And YHWH said unto Moses: "Put back the rod of Aaron before the testimony, to be kept for a token against the rebellious—לְאוֹת לִבְנֵי־מֶרִי (le-ot li-vnei-meri); that you may make an end of their murmurings against me, that they not die."

**17:11** Thus did Moses; as YHWH commanded him, so did he.

**17:12** And the children of Israel spoke unto Moses, saying: "Behold, we perish, we are lost, we are all lost!

**17:13** "Everyone who comes near, who comes near unto the tabernacle of YHWH, shall die; shall we be wholly consumed?"

---

## Synthesis Notes

**Key Restorations:**

**The Test:**
After Korah's rebellion, YHWH provides a definitive sign to settle the question of priestly authority. Twelve rods (one per tribe, with Aaron's for Levi), each inscribed with the leader's name, are placed before the testimony in the tent of meeting.

**Divine Selection:**
"The man whom I shall choose, his rod shall bud." YHWH will cause life to appear where there should be none—a dead branch will sprout. This is beyond manipulation; only divine power can make dead wood live.

**Aaron's Rod:**
Overnight, Aaron's rod:
- **Budded** (put forth shoots)
- **Bloomed** (produced blossoms)
- **Bore ripe almonds** (yielded fruit)

Three stages of growth happened simultaneously—not the natural sequence but miraculous compression. Dead wood produced not just sprouts but mature fruit in one night.

**The Almond (שָׁקֵד, shaqed):**
The almond tree is the first to bloom in Israel (January-February). Its Hebrew name (*shaqed*) comes from the root meaning "to watch, be alert"—the "watcher tree." In Jeremiah 1:11-12, YHWH makes a wordplay: "I am watching (*shoqed*) over my word to perform it."

The almond symbolizes God's watchful attentiveness and the first-fruits of promised action.

**The Rod Preserved:**
Aaron's rod is placed before the testimony as a permanent sign "against the rebellious" (*li-vnei-meri*). The budded rod remains as evidence: YHWH has chosen Aaron.

Later tradition (Hebrews 9:4) places Aaron's rod inside the ark of the covenant, alongside the tablets and a jar of manna.

**Israel's Fear:**
The people's response is terror: "We perish, we are lost... everyone who comes near shall die!" They now fear too much. Korah presumed access; now Israel fears any approach. The next chapter will clarify the Levites' mediating role.

**Archetypal Layer:** The budding rod is **life from death**—resurrection symbolized. The dead stick of a fallen tree produces blossoms and fruit overnight. This is YHWH's creative power validating his choice.

The three stages (bud, blossom, fruit) simultaneously present represent **complete confirmation**—not partial evidence but full demonstration.

**Psychological Reading:** The rod resolves the question visibly, publicly, permanently. Each prince can see his own unchanged rod and Aaron's transformed one. The evidence is concrete, not debatable.

Israel's excessive fear ("shall we be wholly consumed?") shows the swing from presumption to terror. Chapter 18 will address this by clarifying how the Levites make safe approach possible.

**Ethical Inversion Applied:**
- Divine selection is visible—the rod provides concrete evidence
- Dead wood produces life—only YHWH can do this
- The rod is preserved—future generations will see the sign
- Rebellion is answered by demonstration—not argument but evidence
- Terror follows presumption—the extremes must be balanced

**Modern Equivalent:** Leadership legitimacy questions are often settled by evidence of "fruitfulness"—does the claimed authority produce life? The budding rod models validation through visible results rather than mere assertion. And the preserved rod as memorial suggests that communities need tangible reminders of foundational decisions.

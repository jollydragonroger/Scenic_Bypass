# Numbers Chapter 30: Laws Concerning Vows

*From the Hebrew: נֶדֶר (Neder) — The Binding Word*

---

**30:1** And Moses spoke unto the heads of the tribes of the children of Israel, saying: "This is the thing which YHWH has commanded.

**30:2** "When a man vows a vow—נֶדֶר (neder)—unto YHWH, or swears an oath—שְׁבֻעָה (shevu'ah)—to bind his soul with a bond, he shall not break his word; he shall do according to all that proceeds out of his mouth.

**30:3** "Also when a woman vows a vow unto YHWH, and binds herself by a bond, being in her father's house, in her youth,

**30:4** "And her father hears her vow, or her bond with which she has bound her soul, and her father holds his peace at her, then all her vows shall stand, and every bond with which she has bound her soul shall stand.

**30:5** "But if her father disallows her in the day that he hears, none of her vows, or of her bonds with which she has bound her soul, shall stand; and YHWH will forgive her, because her father disallowed her.

**30:6** "And if she is married to a husband, while her vows are upon her, or the rash utterance of her lips, with which she has bound her soul,

**30:7** "And her husband hears it, and holds his peace at her in the day that he hears it, then her vows shall stand, and her bonds with which she has bound her soul shall stand.

**30:8** "But if her husband disallows her in the day that he hears it, then he shall make void her vow which is upon her, and the rash utterance of her lips, with which she has bound her soul; and YHWH will forgive her.

**30:9** "But the vow of a widow, or of her who is divorced, even everything with which she has bound her soul, shall stand against her.

**30:10** "And if she vowed in her husband's house, or bound her soul by a bond with an oath,

**30:11** "And her husband heard it, and held his peace at her, and disallowed her not, then all her vows shall stand, and every bond with which she bound her soul shall stand.

**30:12** "But if her husband made them null and void in the day that he heard them, then whatsoever proceeded out of her lips, whether it were her vows, or the bond of her soul, shall not stand; her husband has made them void; and YHWH will forgive her.

**30:13** "Every vow, and every binding oath to afflict the soul, her husband may confirm it, or her husband may make it void.

**30:14** "But if her husband altogether holds his peace at her from day to day, then he confirms all her vows, or all her bonds, which are upon her; he has confirmed them, because he held his peace at her in the day that he heard them.

**30:15** "But if he makes them null and void after that he has heard them, then he shall bear her iniquity."

**30:16** These are the statutes which YHWH commanded Moses, between a man and his wife, between a father and his daughter, being in her youth, in her father's house.

---

## Synthesis Notes

**Key Restorations:**

**The Binding Word:**
A vow (*neder*) is a promise to do something; an oath (*shevu'ah*) is a promise to abstain. Both bind the soul. "He shall not break his word; he shall do according to all that proceeds out of his mouth."

**A Man's Vow:**
A man's vow stands absolutely. Once spoken, it binds. There is no nullification provision for adult men.

**A Woman's Vow:**
A woman's vow may be subject to male authority, depending on her status:

1. **Unmarried daughter in father's house:**
   - Father hears and is silent → vow stands
   - Father disallows on the day he hears → vow is void; YHWH forgives

2. **Married woman:**
   - Husband hears and is silent → vow stands
   - Husband disallows on the day he hears → vow is void; YHWH forgives
   - Husband silent initially, then later annuls → he bears her iniquity

3. **Widow or divorced woman:**
   - Her vow stands absolutely (like a man's)
   - No male authority to annul

**"In the Day That He Hears":**
The annulment must occur immediately—on the same day. Delayed silence constitutes confirmation. You cannot wait and then annul.

**"YHWH Will Forgive Her":**
When a vow is properly annulled by father or husband, the woman is not held guilty for the unfulfilled vow. The annulment releases her from both the obligation and the guilt.

**"He Shall Bear Her Iniquity":**
If a husband waits (allowing the vow to be confirmed by silence) and then later annuls, he bears the consequences. The fault shifts to him.

**"Rash Utterance of Her Lips":**
*Mivta sefateiha*—impulsive speech that binds. The law acknowledges that vows may be made hastily and provides a mechanism for annulment.

**The Context:**
This chapter addresses household dynamics in an ancient patriarchal context. The father or husband has authority to protect the household from vows that might disrupt family resources or obligations.

**Archetypal Layer:** Words have binding power. The vow creates obligation before YHWH. The system provides **protective annulment** for those under authority while holding independent adults (men, widows, divorcées) fully accountable.

The principle of **immediate response** (same day) prevents manipulation—you cannot wait to see if the vow is advantageous before deciding.

**Psychological Reading:** The provision for annulment acknowledges human impulsivity. Not every spoken vow reflects mature consideration. The protective structure allows correction of hasty speech.

**Ethical Inversion Applied:**
- Words bind the soul—speech creates obligation
- Men's vows stand absolutely—full accountability
- Women's vows may be annulled—depending on status and authority
- Widows and divorcées have full authority—independent women are fully accountable
- Same-day response required—silence is consent
- Delayed annulment shifts guilt—responsibility has consequences

**Difficult Elements:**
The asymmetry between men and women reflects patriarchal social structure. Women under male authority have their vows subject to male veto; men's vows are not subject to any such limitation. The law assumes and reinforces a hierarchical household.

The provision for widows and divorcées (their vows stand) shows that the issue is not inherent female incapacity but the structure of household authority.

**Modern Equivalent:** The principle that words create binding obligation remains. The protective annulment function (stopping someone from hasty commitments) exists in cooling-off periods for contracts. And the same-day rule (act immediately or lose the right) appears in various legal contexts.

# Numbers Chapter 18: Duties and Portions of Priests and Levites

*From the Hebrew: מַתְּנֹת כְּהֻנָּה (Mattenot Kehunnah) — Gifts of the Priesthood*

---

**18:1** And YHWH said unto Aaron: "You and your sons and your father's house with you shall bear the iniquity of the sanctuary; and you and your sons with you shall bear the iniquity of your priesthood.

**18:2** "And your brothers also, the tribe of Levi, the tribe of your father, bring near with you, that they may be joined unto you, and minister unto you; but you and your sons with you shall be before the tent of the testimony.

**18:3** "And they shall keep your charge, and the charge of all the tent; only they shall not come near unto the vessels of the sanctuary and unto the altar, that they not die, neither they, nor you.

**18:4** "And they shall be joined unto you, and keep the charge of the tent of meeting, for all the service of the tent; and a stranger shall not come near unto you.

**18:5** "And you shall keep the charge of the sanctuary, and the charge of the altar, that there be wrath no more upon the children of Israel.

**18:6** "And I, behold, I have taken your brothers the Levites from among the children of Israel; to you they are given as a gift—מַתָּנָה (mattanah)—unto YHWH, to do the service of the tent of meeting.

**18:7** "And you and your sons with you shall keep your priesthood for everything of the altar, and for that within the veil; and you shall serve. I give you the priesthood as a service of gift; and the stranger who comes near shall be put to death."

---

**18:8** And YHWH spoke unto Aaron: "And I, behold, I have given you the charge of my contributions—תְּרוּמֹתַי (terumotai)—even all the hallowed things of the children of Israel; unto you have I given them for a portion, and to your sons, as a due forever.

**18:9** "This shall be yours of the most holy things, reserved from the fire: every offering of theirs, even every grain offering of theirs, and every sin offering of theirs, and every guilt offering of theirs, which they shall render unto me, shall be most holy for you and for your sons.

**18:10** "In a most holy place shall you eat it; every male shall eat thereof; it shall be holy unto you.

**18:11** "And this is yours: the contribution of their gift, even all the wave offerings of the children of Israel; I have given them unto you, and to your sons and to your daughters with you, as a due forever; everyone who is clean in your house may eat of it.

**18:12** "All the best of the oil, and all the best of the wine, and of the grain, the first-fruits of them which they give unto YHWH, to you have I given them.

**18:13** "The first-ripe fruits of all that is in their land, which they bring unto YHWH, shall be yours; everyone who is clean in your house may eat of it.

**18:14** "Everything devoted—חֵרֶם (cherem)—in Israel shall be yours.

**18:15** "Everything that opens the womb, of all flesh which they offer unto YHWH, both of man and beast, shall be yours; nevertheless the firstborn of man you shall surely redeem, and the firstling of unclean beasts you shall redeem.

**18:16** "And their redemption money—from a month old you shall redeem them—shall be, according to your valuation, five shekels of silver, after the shekel of the sanctuary, which is twenty gerahs.

**18:17** "But the firstling of an ox, or the firstling of a sheep, or the firstling of a goat, you shall not redeem; they are holy; you shall throw their blood against the altar, and shall burn their fat for a fire offering, for a pleasing aroma unto YHWH.

**18:18** "And their flesh shall be yours, as the wave breast and as the right thigh, it shall be yours.

**18:19** "All the contributions of the holy things, which the children of Israel offer unto YHWH, have I given you, and your sons and your daughters with you, as a due forever; it is a covenant of salt—בְּרִית מֶלַח (berit melach)—forever before YHWH unto you and to your seed with you."

---

**18:20** And YHWH said unto Aaron: "You shall have no inheritance in their land, neither shall you have any portion among them; I am your portion and your inheritance among the children of Israel—אֲנִי חֶלְקְךָ וְנַחֲלָתְךָ (ani chelqecha ve-nachalatecha).

**18:21** "And unto the children of Levi, behold, I have given all the tithe in Israel for an inheritance, in return for their service which they serve, the service of the tent of meeting.

**18:22** "And henceforth the children of Israel shall not come near the tent of meeting, lest they bear sin, and die.

**18:23** "But the Levites shall do the service of the tent of meeting, and they shall bear their iniquity; it shall be a statute forever throughout your generations. And among the children of Israel they shall have no inheritance.

**18:24** "For the tithe of the children of Israel, which they set apart as a contribution unto YHWH, I have given to the Levites for an inheritance; therefore I have said unto them: 'Among the children of Israel they shall have no inheritance.'"

---

**18:25** And YHWH spoke unto Moses, saying:

**18:26** "Moreover you shall speak unto the Levites, and say unto them: 'When you take of the children of Israel the tithe which I have given you from them for your inheritance, then you shall set apart of it a contribution for YHWH, a tithe of the tithe—מַעֲשַׂר מִן־הַמַּעֲשֵׂר (ma'aser min-ha-ma'aser).

**18:27** "'And your contribution shall be reckoned unto you, as though it were the grain of the threshing-floor, and as the fullness of the wine-press.

**18:28** "'Thus you also shall set apart a contribution unto YHWH of all your tithes, which you receive of the children of Israel; and you shall give thereof YHWH's contribution to Aaron the priest.

**18:29** "'Out of all your gifts you shall set apart every contribution of YHWH, of all the best thereof, even the hallowed part thereof out of it.'

**18:30** "Therefore you shall say unto them: 'When you set apart the best thereof from it, then it shall be counted unto the Levites as the produce of the threshing-floor, and as the produce of the wine-press.

**18:31** "'And you may eat it in every place, you and your households; for it is your reward in return for your service in the tent of meeting.

**18:32** "'And you shall bear no sin by reason of it, when you have set apart from it the best thereof; and you shall not profane the holy things of the children of Israel, that you not die.'"

---

## Synthesis Notes

**Key Restorations:**

**Bearing Iniquity:**
The priests and Levites "bear the iniquity" of the sanctuary—they take responsibility for any violations. If unauthorized persons approach, the blame falls on those who should have prevented it. This is protective service.

**Division of Labor:**
- **Priests** (Aaron and sons): altar, sanctuary interior, sacred vessels
- **Levites**: tent of meeting service, assisting priests, guarding

Levites may not touch the sacred vessels or approach the altar. The boundary protects both them and Israel.

**Priesthood as Gift:**
"I give you the priesthood as a service of gift" (*mattanah*)—the priesthood is not seized but given. It is privilege received, not right claimed.

**Priestly Portions:**

From the offerings:
- **Most holy** (grain, sin, guilt offerings): priests only, eaten in holy place
- **Holy** (wave offerings, contributions): priestly families, eaten in clean places

From the land:
- **First-fruits** of oil, wine, grain
- **Everything devoted** (*cherem*)
- **Firstborn**: redeemed (humans, unclean animals) or sacrificed (clean animals)

**Redemption of Firstborn:**
- Human firstborn: redeemed at 5 shekels (from one month old)
- Unclean animal firstborn: redeemed
- Clean animal firstborn: sacrificed, flesh to priests

**"Covenant of Salt" (בְּרִית מֶלַח):**
The priestly provisions are secured by a "covenant of salt"—salt symbolizes permanence (preservative), friendship (shared meals), and covenant loyalty. The priestly due is irrevocable.

**"I Am Your Portion":**
Priests and Levites receive no tribal land allotment. Instead: "I am your portion and your inheritance." YHWH himself is their inheritance. Their support comes from the offerings, not from land.

**The Levitical Tithe:**
All Israel gives a tenth (tithe) of produce to the Levites—this is their income in exchange for their service. They have no land; they live on the tithe.

**The Tithe of the Tithe:**
The Levites, in turn, give a tenth of what they receive to the priests. The Levites tithe to Aaron just as Israel tithes to the Levites. Everyone participates in giving.

**Archetypal Layer:** The system creates **interdependence**: Israel supports Levites, Levites support priests, priests serve the sanctuary. Each level depends on the others. No one is self-sufficient.

"I am your portion" represents the **radical dependence** of those who serve the holy. They own nothing except YHWH's provision through the offerings.

**Psychological Reading:** The detailed provisions address the fear expressed at the end of chapter 17 ("shall we be wholly consumed?"). The answer: the priests and Levites bear the responsibility; they make approach safe. Israel can approach through them.

**Ethical Inversion Applied:**
- Bearing iniquity is service—the priests absorb the danger
- The priesthood is gift, not right—privilege received
- Covenant of salt—irrevocable commitment
- YHWH is inheritance—those who serve the holy don't own land
- Tithe of the tithe—everyone gives, even the Levites

**Modern Equivalent:** Those who serve religious institutions are often supported by the community rather than holding independent wealth. The "tithe of the tithe" principle suggests that religious professionals also have giving obligations. And "I am your portion" challenges any view that sacred service leads to material accumulation.

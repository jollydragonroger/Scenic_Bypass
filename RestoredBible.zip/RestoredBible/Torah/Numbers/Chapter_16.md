# Numbers Chapter 16: The Rebellion of Korah

*From the Hebrew: קֹרַח (Korach) — The Great Rebellion*

---

**16:1** Now Korah, the son of Izhar, the son of Kohath, the son of Levi, with Dathan and Abiram, the sons of Eliab, and On, the son of Peleth, sons of Reuben, took men;

**16:2** And they rose up before Moses, with certain of the children of Israel, two hundred and fifty men; they were princes of the congregation, called to the assembly, men of renown.

**16:3** And they assembled themselves together against Moses and against Aaron, and said unto them: "You take too much upon yourselves, seeing all the congregation are holy, every one of them, and YHWH is among them; why then do you lift yourselves up above the assembly of YHWH?"

**16:4** And when Moses heard it, he fell upon his face.

**16:5** And he spoke unto Korah and unto all his company, saying: "In the morning YHWH will show who is his, and who is holy, and will cause him to come near unto him; even him whom he shall choose will he cause to come near unto him.

**16:6** "This do: take yourselves censers, Korah, and all your company;

**16:7** "And put fire in them, and put incense upon them before YHWH tomorrow; and it shall be that the man whom YHWH chooses, he shall be holy. You take too much upon yourselves, you sons of Levi."

**16:8** And Moses said unto Korah: "Hear now, you sons of Levi:

**16:9** "Is it a small thing unto you, that the Consciousness of Israel has separated you from the congregation of Israel, to bring you near to himself, to do the service of the tabernacle of YHWH, and to stand before the congregation to minister unto them;

**16:10** "And that he has brought you near, and all your brothers the sons of Levi with you? And do you seek the priesthood also?

**16:11** "Therefore you and all your company are gathered together against YHWH; and Aaron, what is he that you murmur against him?"

---

**16:12** And Moses sent to call Dathan and Abiram, the sons of Eliab; and they said: "We will not come up.

**16:13** "Is it a small thing that you have brought us up out of a land flowing with milk and honey, to kill us in the wilderness, but you must also make yourself a prince over us?

**16:14** "Moreover you have not brought us into a land flowing with milk and honey, nor given us inheritance of fields and vineyards; will you put out the eyes of these men? We will not come up."

**16:15** And Moses was very angry, and said unto YHWH: "Respect not their offering; I have not taken one donkey from them, neither have I hurt one of them."

**16:16** And Moses said unto Korah: "You and all your company, be present before YHWH, you, and they, and Aaron, tomorrow;

**16:17** "And take every man his censer, and put incense upon them, and bring before YHWH every man his censer, two hundred and fifty censers; you also, and Aaron, each his censer."

**16:18** And they took every man his censer, and put fire in them, and laid incense upon them, and stood at the door of the tent of meeting with Moses and Aaron.

**16:19** And Korah assembled all the congregation against them unto the door of the tent of meeting; and the glory of YHWH appeared unto all the congregation.

---

**16:20** And YHWH spoke unto Moses and unto Aaron, saying:

**16:21** "Separate yourselves from among this congregation, that I may consume them in a moment."

**16:22** And they fell upon their faces, and said: "O God, the God of the spirits of all flesh—אֵל אֱלֹהֵי הָרוּחֹת לְכָל־בָּשָׂר (El Elohei ha-ruchot le-chol-basar)—shall one man sin, and will you be angry with all the congregation?"

**16:23** And YHWH spoke unto Moses, saying:

**16:24** "Speak unto the congregation, saying: 'Get you up from about the dwelling of Korah, Dathan, and Abiram.'"

**16:25** And Moses rose up and went unto Dathan and Abiram; and the elders of Israel followed him.

**16:26** And he spoke unto the congregation, saying: "Depart, I pray you, from the tents of these wicked men, and touch nothing of theirs, lest you be swept away in all their sins."

**16:27** So they got them up from the dwelling of Korah, Dathan, and Abiram, on every side; and Dathan and Abiram came out, and stood at the door of their tents, with their wives, and their sons, and their little ones.

**16:28** And Moses said: "Hereby you shall know that YHWH has sent me to do all these works, and that I have not done them of my own mind.

**16:29** "If these men die the common death of all men, or if they be visited after the visitation of all men, then YHWH has not sent me.

**16:30** "But if YHWH makes a new thing—בְּרִיאָה (beri'ah)—and the ground opens its mouth and swallows them up, with all that belongs to them, and they go down alive into Sheol, then you shall understand that these men have despised YHWH."

**16:31** And it came to pass, as he finished speaking all these words, that the ground that was under them split apart;

**16:32** And the earth opened her mouth, and swallowed them up, and their households, and all the men who belonged to Korah, and all their goods.

**16:33** So they, and all who belonged to them, went down alive into Sheol; and the earth closed upon them, and they perished from among the assembly.

**16:34** And all Israel who were round about them fled at their cry; for they said: "Lest the earth swallow us up."

**16:35** And fire came forth from YHWH, and devoured the two hundred and fifty men who offered the incense.

---

**16:36** And YHWH spoke unto Moses, saying:

**16:37** "Speak unto Eleazar the son of Aaron the priest, that he take up the censers out of the burning, and scatter the fire yonder; for they are holy,

**16:38** "Even the censers of these men who have sinned at the cost of their lives; and let them be made beaten plates for a covering of the altar, for they were offered before YHWH, and are become holy; and they shall be a sign unto the children of Israel."

**16:39** And Eleazar the priest took the bronze censers, which those who were burned had offered; and they beat them out for a covering of the altar,

**16:40** To be a memorial unto the children of Israel, that no stranger, who is not of the seed of Aaron, come near to burn incense before YHWH; that he be not as Korah, and as his company; as YHWH spoke unto him by the hand of Moses.

---

**16:41** But on the morrow all the congregation of the children of Israel murmured against Moses and against Aaron, saying: "You have killed the people of YHWH."

**16:42** And it came to pass, when the congregation assembled against Moses and against Aaron, that they looked toward the tent of meeting; and behold, the cloud covered it, and the glory of YHWH appeared.

**16:43** And Moses and Aaron came to the front of the tent of meeting.

**16:44** And YHWH spoke unto Moses, saying:

**16:45** "Get you up from among this congregation, that I may consume them in a moment." And they fell upon their faces.

**16:46** And Moses said unto Aaron: "Take your censer, and put fire from upon the altar, and lay incense upon it, and carry it quickly unto the congregation, and make atonement for them; for wrath is gone out from YHWH; the plague is begun."

**16:47** And Aaron took as Moses spoke, and ran into the midst of the assembly; and behold, the plague had begun among the people; and he put on the incense, and made atonement for the people.

**16:48** And he stood between the dead and the living; and the plague was stayed.

**16:49** Now those who died by the plague were fourteen thousand and seven hundred, besides those who died about the matter of Korah.

**16:50** And Aaron returned unto Moses unto the door of the tent of meeting; and the plague was stayed.

---

## Synthesis Notes

**Key Restorations:**

**The Conspiracy:**
A coalition of Levites and Reubenites:
- **Korah** (Kohathite Levite)—challenges Aaron's priesthood
- **Dathan and Abiram** (Reubenites)—challenge Moses' leadership
- **250 princes**—men of standing who join the rebellion

**The Charge:**
"You take too much upon yourselves, seeing all the congregation are holy, every one of them, and YHWH is among them." The argument appeals to democratized holiness: everyone is holy; no one should be elevated.

**The Irony:**
The charge is partly true—all Israel is called to be holy. But the Levites themselves were separated for special service. Korah wants what he claims to reject: exclusive access. He doesn't want equality; he wants Aaron's role.

**Moses' Response:**
He returns the accusation: "You take too much upon yourselves, you sons of Levi." And he asks: "Is it a small thing that God has separated you... and do you seek the priesthood also?" The Levites have privilege; they want more.

**Dathan and Abiram's Inversion:**
They call Egypt "a land flowing with milk and honey"—the phrase for Canaan applied to Egypt! They accuse Moses of bringing them out to kill them. Reality is inverted in their complaint.

**The Test:**
All 250 bring censers with incense before YHWH. YHWH will show whom he has chosen.

**Moses' Intercession:**
When YHWH threatens to destroy the congregation, Moses and Aaron intercede: "Shall one man sin, and will you be angry with all the congregation?" They appeal to YHWH as "God of the spirits of all flesh"—the God who knows each individual.

**"A New Thing" (בְּרִיאָה):**
Moses announces a unique judgment: if the earth swallows them alive, YHWH has spoken through Moses. This is unprecedented—*beri'ah*, a new creation of judgment.

**The Earth Opens:**
The ground splits; Korah, Dathan, Abiram, and their households descend alive into Sheol. The earth closes. Fire consumes the 250.

**The Bronze Censers:**
The censers are holy—they were presented before YHWH. Eleazar hammers them into a covering for the altar. They become a permanent warning: no unauthorized person may offer incense.

**The Next Day:**
Despite witnessing the judgment, Israel blames Moses and Aaron: "You have killed the people of YHWH." Plague begins. Aaron runs into the midst with incense, stands between the dead and the living, and the plague stops. 14,700 die.

**Aaron's Intercession:**
The very act Korah claimed to deserve—offering incense—becomes the means of salvation. Aaron's authorized incense stops the plague that unauthorized incense triggered.

**Archetypal Layer:** Korah represents **rebellion disguised as populism**. The claim "everyone is holy" masks the ambition "I want Aaron's role." True spiritual democracy is different from leveling that disguises power-seeking.

The earth swallowing rebels is the **world-order responding to disruption**. Creation itself rejects those who disrupt the sacred hierarchy.

**Psychological Reading:** The rebellion combines multiple grievances (Levite jealousy, Reubenite resentment, general discontent). Coalition rebellions often fail because the motivations don't align. Korah wants priesthood; Dathan and Abiram want return to Egypt.

**Ethical Inversion Applied:**
- Populist rhetoric can mask ambition—"all are holy" while seeking exclusive power
- The Levites already had privilege—they wanted more
- Egypt called "milk and honey"—reality inverted
- The censers become warning—rebellion memorialized as caution
- Aaron's incense saves—the authorized act atones

**Modern Equivalent:** Rebellions claiming to represent "the people" sometimes mask personal ambition. The distinction between legitimate critique and power-seeking rebellion remains relevant. And the image of Aaron standing "between the dead and the living" models intercession—entering the danger zone to stop destruction.

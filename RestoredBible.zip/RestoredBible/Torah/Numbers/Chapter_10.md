# Numbers Chapter 10: The Silver Trumpets and Departure from Sinai

*From the Hebrew: חֲצֹצְרוֹת (Chatsotsrot) — The Trumpets*

---

**10:1** And YHWH spoke unto Moses, saying:

**10:2** "Make for yourself two trumpets of silver—חֲצֹצְרֹת כֶּסֶף (chatsotsrot kesef); of beaten work you shall make them; and they shall be for you for the calling of the congregation, and for causing the camps to set forward.

**10:3** "And when they shall blow with them, all the congregation shall gather themselves unto you at the door of the tent of meeting.

**10:4** "And if they blow but with one, then the princes, the heads of the thousands of Israel, shall gather themselves unto you.

**10:5** "And when you blow an alarm—תְּרוּעָה (teru'ah)—the camps that lie on the east side shall set forward.

**10:6** "And when you blow an alarm the second time, the camps that lie on the south side shall set forward; they shall blow an alarm for their journeys.

**10:7** "But when the assembly is to be gathered together, you shall blow, but you shall not sound an alarm.

**10:8** "And the sons of Aaron, the priests, shall blow with the trumpets; and they shall be to you for a statute forever throughout your generations.

**10:9** "And when you go to war in your land against the adversary who oppresses you, then you shall sound an alarm with the trumpets; and you shall be remembered before YHWH your Consciousness, and you shall be saved from your enemies.

**10:10** "Also in the day of your gladness, and in your appointed times, and in the beginnings of your months, you shall blow with the trumpets over your burnt offerings, and over your sacrifices of peace offerings; and they shall be to you for a memorial before your Consciousness: I am YHWH your Consciousness."

---

**10:11** And it came to pass in the second year, in the second month, on the twentieth day of the month, that the cloud was taken up from over the tabernacle of the testimony.

**10:12** And the children of Israel set forward according to their journeys out of the wilderness of Sinai; and the cloud abode in the wilderness of Paran.

**10:13** And they set forward first according to the commandment of YHWH by the hand of Moses.

**10:14** And the standard of the camp of the children of Judah set forward first according to their hosts; and over his host was Nahshon the son of Amminadab.

**10:15** And over the host of the tribe of the children of Issachar was Nethanel the son of Zuar.

**10:16** And over the host of the tribe of the children of Zebulun was Eliab the son of Helon.

**10:17** And the tabernacle was taken down; and the sons of Gershon and the sons of Merari, who carried the tabernacle, set forward.

**10:18** And the standard of the camp of Reuben set forward according to their hosts; and over his host was Elizur the son of Shedeur.

**10:19** And over the host of the tribe of the children of Simeon was Shelumiel the son of Zurishaddai.

**10:20** And over the host of the tribe of the children of Gad was Eliasaph the son of Deuel.

**10:21** And the Kohathites set forward, carrying the sanctuary; and the others set up the tabernacle before their arrival.

**10:22** And the standard of the camp of the children of Ephraim set forward according to their hosts; and over his host was Elishama the son of Ammihud.

**10:23** And over the host of the tribe of the children of Manasseh was Gamaliel the son of Pedahzur.

**10:24** And over the host of the tribe of the children of Benjamin was Abidan the son of Gideoni.

**10:25** And the standard of the camp of the children of Dan, the rear guard of all the camps, set forward according to their hosts; and over his host was Ahiezer the son of Ammishaddai.

**10:26** And over the host of the tribe of the children of Asher was Pagiel the son of Ochran.

**10:27** And over the host of the tribe of the children of Naphtali was Ahira the son of Enan.

**10:28** Thus were the journeyings of the children of Israel according to their hosts; and they set forward.

---

**10:29** And Moses said unto Hobab, the son of Reuel the Midianite, Moses' father-in-law: "We are journeying unto the place of which YHWH said, 'I will give it unto you'; come with us, and we will do you good; for YHWH has spoken good concerning Israel."

**10:30** And he said unto him: "I will not go; but I will depart to my own land, and to my kindred."

**10:31** And Moses said: "Leave us not, I pray; for you know how we are to encamp in the wilderness, and you shall be to us instead of eyes.

**10:32** "And it shall be, if you go with us, that whatever good YHWH shall do unto us, the same will we do unto you."

**10:33** And they set forward from the mount of YHWH three days' journey; and the ark of the covenant of YHWH went before them three days' journey, to seek out a resting place for them.

**10:34** And the cloud of YHWH was over them by day, when they set forward from the camp.

**10:35** And it came to pass, when the ark set forward, that Moses said: "Rise up, YHWH, and let your enemies be scattered; and let those who hate you flee before you."

**10:36** And when it rested, he said: "Return, YHWH, unto the ten thousands of the thousands of Israel."

---

## Synthesis Notes

**Key Restorations:**

**The Silver Trumpets:**
Two trumpets of hammered silver, blown by the priests:

| Signal | Meaning |
|--------|---------|
| Both trumpets, continuous | Whole congregation assembles |
| One trumpet | Tribal leaders assemble |
| Alarm blast (teru'ah) | East camps move |
| Second alarm | South camps move |
| (Implied: third, fourth) | West, north camps move |

**Priestly Trumpeters:**
Only "the sons of Aaron, the priests" may blow the trumpets. This is not a general assembly but a sacred function. The trumpets communicate divine command through priestly agency.

**Uses of the Trumpets:**
1. **Assembly**: gathering the congregation or leaders
2. **Journey**: signaling departure in sequence
3. **War**: "you shall be remembered before YHWH"—the trumpet invokes divine attention
4. **Festivals**: appointed times, new moons, offerings

**Departure from Sinai (10:11):**
"In the second year, in the second month, on the twentieth day"—Israel leaves Sinai almost a year after arriving (Exodus 19:1). The cloud lifts; the journey to Canaan begins.

**The March Order:**

1. **Judah's camp** (Judah, Issachar, Zebulun)
2. **Gershonites and Merarites** with tabernacle structure
3. **Reuben's camp** (Reuben, Simeon, Gad)
4. **Kohathites** with sacred objects (so the structure is set up before they arrive)
5. **Ephraim's camp** (Ephraim, Manasseh, Benjamin)
6. **Dan's camp** as rear guard (Dan, Asher, Naphtali)

The sacred objects travel in the center, protected on all sides.

**Hobab (10:29-32):**
Moses' brother-in-law (or father-in-law—the relationship is debated). Moses invites him to join:
- "We will do you good"
- "YHWH has spoken good concerning Israel"
- "You shall be to us instead of eyes"—Hobab's wilderness knowledge is valuable

Hobab initially declines. Moses persists. Judges 1:16 and 4:11 suggest Hobab's descendants (Kenites) eventually settled in Israel.

**"Instead of Eyes":**
Even with the cloud guiding, Moses values Hobab's practical wilderness expertise. Divine guidance and human wisdom are not mutually exclusive.

**The Ark Goes Before:**
"The ark of the covenant of YHWH went before them... to seek out a resting place." The ark—representing YHWH's presence—scouts ahead. YHWH leads.

**Moses' Invocations (10:35-36):**

When the ark moved:
*"Rise up, YHWH, and let your enemies be scattered; and let those who hate you flee before you."*

When the ark rested:
*"Return, YHWH, unto the ten thousands of the thousands of Israel."*

These are battle cries and settlement prayers. The ark's movement is YHWH's movement. The invocations personify the ark as YHWH's active presence.

**The Inverted Nuns:**
In the Hebrew text, verses 35-36 are bracketed by inverted letter *nuns* (נ). This marks them as a distinct unit—possibly indicating these verses could be a separate book or a liturgical insertion.

**Archetypal Layer:** The trumpets are **divine communication through human instruments**—the priests mediate the call. The march from Sinai begins the second phase: from covenant-formation to journey toward promise.

The ark "seeking a resting place" portrays YHWH as **active scout**—not passive cargo but leading presence.

**Psychological Reading:** The structured march provides security. Each tribe knows its place and time. The sequential departure prevents chaos. And Moses' request to Hobab shows that spiritual leadership welcomes practical expertise.

**Ethical Inversion Applied:**
- Priests blow the trumpets—communication is a sacred function
- The ark goes before—YHWH leads, Israel follows
- Human knowledge (Hobab) is valued—divine guidance doesn't preclude practical wisdom
- The march is ordered—structure enables movement
- Moses' invocations express dependence—YHWH's rising and returning is Israel's security

**Modern Equivalent:** Clear communication systems (the trumpets) enable coordinated action. Departure from formative experiences (Sinai) leads to the journey toward purpose. And the combination of divine guidance (the cloud) with practical wisdom (Hobab) models how spiritual and practical resources work together.

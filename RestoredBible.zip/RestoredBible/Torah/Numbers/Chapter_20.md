# Numbers Chapter 20: Waters of Meribah and Death of Aaron

*From the Hebrew: מֵי מְרִיבָה (Mei Merivah) — Waters of Strife*

---

**20:1** And the children of Israel, the whole congregation, came into the wilderness of Zin in the first month; and the people abode in Kadesh; and Miriam died there, and was buried there.

**20:2** And there was no water for the congregation; and they assembled themselves together against Moses and against Aaron.

**20:3** And the people strove with Moses, and spoke, saying: "Would that we had died when our brothers died before YHWH!

**20:4** "And why have you brought the assembly of YHWH into this wilderness, to die there, we and our cattle?

**20:5** "And why have you made us come up out of Egypt, to bring us unto this evil place? It is no place of seed, or of figs, or of vines, or of pomegranates; neither is there any water to drink."

**20:6** And Moses and Aaron went from the presence of the assembly unto the door of the tent of meeting, and fell upon their faces; and the glory of YHWH appeared unto them.

---

**20:7** And YHWH spoke unto Moses, saying:

**20:8** "Take the rod, and assemble the congregation, you and Aaron your brother, and speak unto the rock before their eyes, that it give forth its water; and you shall bring forth to them water out of the rock; so you shall give the congregation and their cattle drink."

**20:9** And Moses took the rod from before YHWH, as he commanded him.

**20:10** And Moses and Aaron gathered the assembly together before the rock, and he said unto them: "Hear now, you rebels—הַמֹּרִים (ha-morim); shall we bring forth water out of this rock?"

**20:11** And Moses lifted up his hand, and smote the rock with his rod twice; and water came forth abundantly, and the congregation drank, and their cattle.

**20:12** And YHWH said unto Moses and Aaron: "Because you did not believe in me, to sanctify me in the eyes of the children of Israel, therefore you shall not bring this assembly into the land which I have given them."

**20:13** These are the waters of Meribah—מֵי מְרִיבָה (Mei Merivah)—where the children of Israel strove with YHWH, and he was sanctified in them.

---

**20:14** And Moses sent messengers from Kadesh unto the king of Edom: "Thus says your brother Israel: You know all the travail that has befallen us;

**20:15** "How our fathers went down into Egypt, and we dwelt in Egypt a long time; and the Egyptians dealt ill with us, and our fathers;

**20:16** "And when we cried unto YHWH, he heard our voice, and sent an angel, and brought us forth out of Egypt; and behold, we are in Kadesh, a city in the uttermost of your border.

**20:17** "Let us pass, I pray you, through your land; we will not pass through field or through vineyard, neither will we drink of the water of the wells; we will go along the king's highway, we will not turn aside to the right hand nor to the left, until we have passed your border."

**20:18** And Edom said unto him: "You shall not pass through me, lest I come out with the sword against you."

**20:19** And the children of Israel said unto him: "We will go up by the highway; and if we drink of your water, I and my cattle, then will I give the price of it; let me only pass through on my feet; there is no other matter."

**20:20** And he said: "You shall not pass through." And Edom came out against him with much people, and with a strong hand.

**20:21** Thus Edom refused to give Israel passage through his border; and Israel turned away from him.

---

**20:22** And they journeyed from Kadesh; and the children of Israel, the whole congregation, came unto Mount Hor.

**20:23** And YHWH spoke unto Moses and Aaron in Mount Hor, by the border of the land of Edom, saying:

**20:24** "Aaron shall be gathered unto his people; for he shall not enter into the land which I have given unto the children of Israel, because you rebelled against my word at the waters of Meribah.

**20:25** "Take Aaron and Eleazar his son, and bring them up unto Mount Hor.

**20:26** "And strip Aaron of his garments, and put them upon Eleazar his son; and Aaron shall be gathered unto his people, and shall die there."

**20:27** And Moses did as YHWH commanded; and they went up into Mount Hor in the sight of all the congregation.

**20:28** And Moses stripped Aaron of his garments, and put them upon Eleazar his son; and Aaron died there on the top of the mount; and Moses and Eleazar came down from the mount.

**20:29** And when all the congregation saw that Aaron was dead, they wept for Aaron thirty days, all the house of Israel.

---

## Synthesis Notes

**Key Restorations:**

**Miriam's Death:**
The chapter opens with Miriam's death at Kadesh—a single verse. She who led the women in song at the sea (Exodus 15:20-21), who watched over infant Moses (Exodus 2), who was struck with *tsara'at* and restored (Numbers 12), dies and is buried. The first of the three siblings to go.

**The Water Crisis:**
Immediately after Miriam's death: no water. The people assemble against Moses and Aaron. The complaint echoes earlier rebellions: "Why did you bring us out of Egypt?"

**YHWH's Instruction:**
"Speak unto the rock before their eyes, that it give forth its water." The instruction is to speak, not strike.

**Moses' Action:**
Instead of speaking to the rock:
- He addresses the people: "Hear now, you rebels"
- He asks: "Shall we bring forth water?"
- He strikes the rock twice

Water comes forth. The immediate need is met. But something has gone wrong.

**The Judgment:**
"Because you did not believe in me, to sanctify me in the eyes of the children of Israel, therefore you shall not bring this assembly into the land."

What was the failure?
- Striking instead of speaking?
- The plural "shall we bring forth"—taking credit?
- Calling the people "rebels" in anger?
- Striking twice (lack of faith)?
- "You did not believe in me"—failure of trust
- "To sanctify me"—failure to demonstrate YHWH's holiness

The text does not specify precisely. The result: Moses and Aaron will not enter the land.

**Meribah (מְרִיבָה):**
"Strife"—the same name as the earlier water crisis (Exodus 17:7). Two Meribahs, both about water, framing the wilderness period.

**Edom Refuses Passage:**
Moses appeals to Edom as "brother Israel"—Esau's descendants. He asks for peaceful passage on the King's Highway. Edom refuses, threatens war. Israel turns away. The ancient enmity (Jacob/Esau) continues.

**Aaron's Death:**
At Mount Hor, YHWH commands:
- Bring Aaron and Eleazar up the mountain
- Strip Aaron's garments (the high priestly vestments)
- Transfer them to Eleazar
- Aaron will die there

The transfer is public—the congregation watches them ascend. Moses returns with Eleazar wearing the high priest's garments. Aaron remains on the mountain.

**Thirty Days of Mourning:**
All Israel mourns Aaron for thirty days—the same period later observed for Moses (Deuteronomy 34:8). The high priest's death affects the entire community.

**Archetypal Layer:** The chapter narrates the **end of the first generation's leadership**. Miriam, then Aaron—Moses will follow. The transfer of garments from Aaron to Eleazar is **succession made visible**: the office continues; the person passes.

Moses' failure at Meribah represents **the cost of anger and frustration**. Even the greatest leader, provoked beyond endurance, can forfeit the goal.

**Psychological Reading:** After forty years of complaint, Moses snaps. "Hear now, you rebels!" is not measured instruction but frustrated outburst. The striking (twice!) suggests force where faith was required. Leadership exhaustion has consequences.

The transfer of priestly garments on the mountain, in view of all Israel, creates public closure. The people see Aaron go up; they see Eleazar descend vested. Succession is clear.

**Ethical Inversion Applied:**
- Miriam's death is recorded briefly—even leaders die
- Moses' failure at Meribah—frustration does not excuse unfaithfulness
- "You did not sanctify me"—the leader represents God's character
- Edom's refusal—even kinship doesn't guarantee cooperation
- Aaron's garments transfer—the office outlasts the person
- Thirty days of mourning—community grief is given time

**Modern Equivalent:** Leadership burnout can result in actions that forfeit the goal. The distinction between speaking and striking—trust versus force—remains relevant. And succession planning (transferring "garments" publicly) ensures continuity when leaders pass.

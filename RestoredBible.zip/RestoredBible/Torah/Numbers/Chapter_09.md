# Numbers Chapter 9: The Second Passover and the Cloud

*From the Hebrew: פֶּסַח שֵׁנִי (Pesach Sheni) — The Second Passover*

---

**9:1** And YHWH spoke unto Moses in the wilderness of Sinai, in the first month of the second year after they came out of the land of Egypt, saying:

**9:2** "Let the children of Israel keep the Passover in its appointed time.

**9:3** "On the fourteenth day of this month, between the evenings, you shall keep it in its appointed time; according to all its statutes, and according to all its ordinances, you shall keep it."

**9:4** And Moses spoke unto the children of Israel, that they should keep the Passover.

**9:5** And they kept the Passover in the first month, on the fourteenth day of the month, between the evenings, in the wilderness of Sinai; according to all that YHWH commanded Moses, so did the children of Israel.

---

**9:6** And there were certain men, who were unclean by the dead body of a man, so that they could not keep the Passover on that day; and they came before Moses and before Aaron on that day.

**9:7** And those men said unto him: "We are unclean by the dead body of a man; why are we kept back, that we may not bring the offering of YHWH in its appointed time among the children of Israel?"

**9:8** And Moses said unto them: "Stand still, that I may hear what YHWH will command concerning you."

**9:9** And YHWH spoke unto Moses, saying:

**9:10** "Speak unto the children of Israel, saying: 'If any man of you or of your generations shall be unclean by reason of a dead body, or be on a journey afar off, yet he shall keep the Passover unto YHWH.

**9:11** "'In the second month on the fourteenth day between the evenings they shall keep it; with unleavened bread and bitter herbs they shall eat it.

**9:12** "'They shall leave none of it unto the morning, nor break a bone of it; according to all the statute of the Passover they shall keep it.

**9:13** "'But the man who is clean, and is not on a journey, and forbears to keep the Passover, that soul shall be cut off from his people; because he did not bring the offering of YHWH in its appointed time, that man shall bear his sin.

**9:14** "'And if a stranger shall sojourn among you, and will keep the Passover unto YHWH, according to the statute of the Passover, and according to its ordinance, so shall he do; you shall have one statute, both for the stranger, and for him who is born in the land.'"

---

**9:15** And on the day that the tabernacle was set up the cloud covered the tabernacle, even the tent of the testimony; and at evening it was upon the tabernacle as it were the appearance of fire, until morning.

**9:16** So it was continually: the cloud covered it, and the appearance of fire by night.

**9:17** And whenever the cloud was taken up from over the tent, then after that the children of Israel journeyed; and in the place where the cloud abode, there the children of Israel encamped.

**9:18** At the commandment of YHWH the children of Israel journeyed, and at the commandment of YHWH they encamped; as long as the cloud abode upon the tabernacle they remained encamped.

**9:19** And when the cloud tarried upon the tabernacle many days, then the children of Israel kept the charge of YHWH, and did not journey.

**9:20** And sometimes the cloud was a few days upon the tabernacle; according to the commandment of YHWH they remained encamped, and according to the commandment of YHWH they journeyed.

**9:21** And sometimes the cloud was from evening until morning; and when the cloud was taken up in the morning, they journeyed; or if it continued a day and a night, when the cloud was taken up, they journeyed.

**9:22** Whether it were two days, or a month, or a year, that the cloud tarried upon the tabernacle, abiding upon it, the children of Israel remained encamped, and did not journey; but when it was taken up, they journeyed.

**9:23** At the commandment of YHWH they encamped, and at the commandment of YHWH they journeyed; they kept the charge of YHWH, at the commandment of YHWH by the hand of Moses.

---

## Synthesis Notes

**Key Restorations:**

**The First Passover in the Wilderness:**
One year after the exodus, Israel observes Passover at Sinai. This is the first anniversary—the commemoration of the event. "According to all that YHWH commanded Moses, so did the children of Israel."

**The Problem:**
Some men are corpse-unclean and cannot participate. Corpse contamination lasts seven days (Numbers 19); if the contamination occurred close to Passover, they cannot be purified in time.

Their question is remarkable: "Why should we be kept back?" They want to participate; they feel the exclusion as loss. This is not reluctant compliance but eager belonging.

**Moses Waits for YHWH:**
Moses does not improvise. He says, "Stand still, that I may hear what YHWH will command." New cases require new revelation. The law is living, responsive, adaptable.

**Pesach Sheni — The Second Passover:**
YHWH provides a solution: a second Passover one month later (second month, fourteenth day) for those who were:
- Corpse-unclean at the regular time
- On a distant journey

The same rules apply: unleavened bread, bitter herbs, nothing left until morning, no broken bones.

**Deliberate Non-Observance:**
Those who are clean and present but choose not to observe Passover are "cut off from their people." The second Passover is for inability, not unwillingness. Deliberate neglect is severely punished.

**The Stranger Included:**
"If a stranger shall sojourn among you, and will keep the Passover"—the non-Israelite who attaches to Israel may fully participate. "One statute for the stranger and for him who is born in the land." Passover is not ethnically exclusive.

**The Cloud (9:15-23):**

The pillar of cloud/fire guides Israel's movements:
- Cloud by day, fire by night
- When cloud lifts: journey
- When cloud settles: camp
- Duration unpredictable: could be overnight, two days, a month, or a year

Israel must remain responsive. They cannot predict when the cloud will move. They must watch, wait, and follow.

**"At the Commandment of YHWH":**
The phrase appears repeatedly (verses 18, 20, 23). Israel's movement is not self-directed but YHWH-directed. The cloud is visible command.

**Archetypal Layer:** Pesach Sheni represents **grace for the excluded**—those legitimately unable to participate are given a second chance. The law accommodates circumstances. This is not leniency but equity.

The cloud is **divine guidance made visible**. Israel does not navigate by human wisdom but by following presence. The unpredictability (two days or a year) requires **constant attentiveness**.

**Psychological Reading:** The men who ask "Why should we be kept back?" model healthy desire for participation. Their exclusion grieves them. YHWH's response honors that desire—provision is made.

The cloud's unpredictability trains flexibility. Israel cannot settle into routine; they must remain alert. This is spiritual formation through uncertainty.

**Ethical Inversion Applied:**
- Legitimate inability is accommodated—the second Passover
- Deliberate neglect is punished—grace for circumstance, not for indifference
- The stranger is included—ethnic boundaries don't exclude the willing
- Moses waits for YHWH—new situations require new revelation
- The cloud's timing is YHWH's—human schedules are subordinated

**Modern Equivalent:** Religious systems that accommodate those with legitimate barriers (illness, travel, circumstances) while maintaining expectation for the able reflect this principle. And the cloud metaphor applies: discerning divine guidance requires watching, waiting, and willingness to move on unpredictable timelines.

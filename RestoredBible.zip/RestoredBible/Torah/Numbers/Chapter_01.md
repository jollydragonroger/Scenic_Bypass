# Numbers Chapter 1: The First Census

*From the Hebrew: בְּמִדְבַּר (Bemidbar) — In the Wilderness*

---

**1:1** And YHWH spoke unto Moses in the wilderness of Sinai, in the tent of meeting, on the first day of the second month, in the second year after they came out of the land of Egypt, saying:

**1:2** "Take the census—שְׂאוּ אֶת־רֹאשׁ (se'u et-rosh)—of all the congregation of the children of Israel, by their families, by their fathers' houses, according to the number of names, every male, by their polls;

**1:3** "From twenty years old and upward, all who are able to go forth to war in Israel, you and Aaron shall number them by their hosts.

**1:4** "And with you there shall be a man of every tribe, each one head of his father's house.

**1:5** "And these are the names of the men who shall stand with you: of Reuben, Elizur the son of Shedeur.

**1:6** "Of Simeon, Shelumiel the son of Zurishaddai.

**1:7** "Of Judah, Nahshon the son of Amminadab.

**1:8** "Of Issachar, Nethanel the son of Zuar.

**1:9** "Of Zebulun, Eliab the son of Helon.

**1:10** "Of the children of Joseph: of Ephraim, Elishama the son of Ammihud; of Manasseh, Gamaliel the son of Pedahzur.

**1:11** "Of Benjamin, Abidan the son of Gideoni.

**1:12** "Of Dan, Ahiezer the son of Ammishaddai.

**1:13** "Of Asher, Pagiel the son of Ochran.

**1:14** "Of Gad, Eliasaph the son of Deuel.

**1:15** "Of Naphtali, Ahira the son of Enan."

**1:16** These were the ones called of the congregation, the princes of the tribes of their fathers; they were the heads of the thousands of Israel.

---

**1:17** And Moses and Aaron took these men who are mentioned by name.

**1:18** And they assembled all the congregation on the first day of the second month, and they declared their ancestry by their families, by their fathers' houses, according to the number of names, from twenty years old and upward, by their polls.

**1:19** As YHWH commanded Moses, so he numbered them in the wilderness of Sinai.

**1:20** And the children of Reuben, Israel's firstborn, their generations, by their families, by their fathers' houses, according to the number of names, by their polls, every male from twenty years old and upward, all who were able to go forth to war:

**1:21** Those who were numbered of them, of the tribe of Reuben, were forty-six thousand and five hundred.

**1:22** Of the children of Simeon, their generations, by their families, by their fathers' houses, those who were numbered of them, according to the number of names, by their polls, every male from twenty years old and upward, all who were able to go forth to war:

**1:23** Those who were numbered of them, of the tribe of Simeon, were fifty-nine thousand and three hundred.

**1:24** Of the children of Gad, their generations, by their families, by their fathers' houses, according to the number of names, from twenty years old and upward, all who were able to go forth to war:

**1:25** Those who were numbered of them, of the tribe of Gad, were forty-five thousand six hundred and fifty.

**1:26** Of the children of Judah, their generations, by their families, by their fathers' houses, according to the number of names, from twenty years old and upward, all who were able to go forth to war:

**1:27** Those who were numbered of them, of the tribe of Judah, were seventy-four thousand and six hundred.

**1:28** Of the children of Issachar, their generations, by their families, by their fathers' houses, according to the number of names, from twenty years old and upward, all who were able to go forth to war:

**1:29** Those who were numbered of them, of the tribe of Issachar, were fifty-four thousand and four hundred.

**1:30** Of the children of Zebulun, their generations, by their families, by their fathers' houses, according to the number of names, from twenty years old and upward, all who were able to go forth to war:

**1:31** Those who were numbered of them, of the tribe of Zebulun, were fifty-seven thousand and four hundred.

**1:32** Of the children of Joseph: of the children of Ephraim, their generations, by their families, by their fathers' houses, according to the number of names, from twenty years old and upward, all who were able to go forth to war:

**1:33** Those who were numbered of them, of the tribe of Ephraim, were forty thousand and five hundred.

**1:34** Of the children of Manasseh, their generations, by their families, by their fathers' houses, according to the number of names, from twenty years old and upward, all who were able to go forth to war:

**1:35** Those who were numbered of them, of the tribe of Manasseh, were thirty-two thousand and two hundred.

**1:36** Of the children of Benjamin, their generations, by their families, by their fathers' houses, according to the number of names, from twenty years old and upward, all who were able to go forth to war:

**1:37** Those who were numbered of them, of the tribe of Benjamin, were thirty-five thousand and four hundred.

**1:38** Of the children of Dan, their generations, by their families, by their fathers' houses, according to the number of names, from twenty years old and upward, all who were able to go forth to war:

**1:39** Those who were numbered of them, of the tribe of Dan, were sixty-two thousand and seven hundred.

**1:40** Of the children of Asher, their generations, by their families, by their fathers' houses, according to the number of names, from twenty years old and upward, all who were able to go forth to war:

**1:41** Those who were numbered of them, of the tribe of Asher, were forty-one thousand and five hundred.

**1:42** Of the children of Naphtali, their generations, by their families, by their fathers' houses, according to the number of names, from twenty years old and upward, all who were able to go forth to war:

**1:43** Those who were numbered of them, of the tribe of Naphtali, were fifty-three thousand and four hundred.

**1:44** These are they who were numbered, whom Moses and Aaron numbered, and the princes of Israel, twelve men; each one was for his father's house.

**1:45** And all those who were numbered of the children of Israel by their fathers' houses, from twenty years old and upward, all who were able to go forth to war in Israel—

**1:46** All those who were numbered were six hundred and three thousand five hundred and fifty.

---

**1:47** But the Levites after the tribe of their fathers were not numbered among them.

**1:48** For YHWH spoke unto Moses, saying:

**1:49** "Only the tribe of Levi you shall not number, neither shall you take the census of them among the children of Israel.

**1:50** "But appoint the Levites over the tabernacle of the testimony, and over all its vessels, and over all that belongs to it; they shall carry the tabernacle, and all its vessels; and they shall minister unto it, and shall encamp round about the tabernacle.

**1:51** "And when the tabernacle sets forward, the Levites shall take it down; and when the tabernacle is to be pitched, the Levites shall set it up; and the stranger who comes near shall be put to death.

**1:52** "And the children of Israel shall pitch their tents, every man by his own camp, and every man by his own standard, according to their hosts.

**1:53** "But the Levites shall encamp round about the tabernacle of the testimony, that there be no wrath upon the congregation of the children of Israel; and the Levites shall keep the charge of the tabernacle of the testimony."

**1:54** Thus did the children of Israel; according to all that YHWH commanded Moses, so they did.

---

## Synthesis Notes

**Key Restorations:**

**The Setting:**
"In the wilderness of Sinai, in the tent of meeting, on the first day of the second month, in the second year." Precise dating: approximately one month after the tabernacle was erected (Exodus 40:17). YHWH speaks from the completed sanctuary.

**"Take the Census" (שְׂאוּ אֶת־רֹאשׁ):**
Literally "lift up the head"—to count by heads. The census is a military muster: males twenty years and older who can go to war. This is preparation for the conquest of Canaan.

**The Twelve Tribal Leaders:**
Each tribe has a designated leader (*nasi*) who assists Moses and Aaron:
- Reuben: Elizur
- Simeon: Shelumiel
- Judah: Nahshon (ancestor of David)
- Issachar: Nethanel
- Zebulun: Eliab
- Ephraim: Elishama
- Manasseh: Gamaliel
- Benjamin: Abidan
- Dan: Ahiezer
- Asher: Pagiel
- Gad: Eliasaph
- Naphtali: Ahira

**The Tribal Counts:**

| Tribe | Count |
|-------|-------|
| Reuben | 46,500 |
| Simeon | 59,300 |
| Gad | 45,650 |
| Judah | 74,600 |
| Issachar | 54,400 |
| Zebulun | 57,400 |
| Ephraim | 40,500 |
| Manasseh | 32,200 |
| Benjamin | 35,400 |
| Dan | 62,700 |
| Asher | 41,500 |
| Naphtali | 53,400 |
| **Total** | **603,550** |

**The Numbers:**
The total of 603,550 implies a total population of 2-3 million. Historically debated—some see these as military units (*eleph* meaning "clan" rather than "thousand"). The text presents them as literal counts.

**Levi Excluded:**
The Levites are not counted in the military census. They have a different role: caring for the tabernacle. Their census comes in chapter 3.

**The Levites' Role:**
- Carry the tabernacle and its vessels
- Set up and take down the sanctuary
- Camp around the tabernacle (buffer zone)
- Prevent "wrath upon the congregation"

The Levites protect Israel from the holy. Unauthorized approach brings death; the Levites guard the boundary.

**Camp Organization:**
Israel camps "by standards" (*degel*)—organized by tribe around the tabernacle. The arrangement is military and liturgical: the army is organized around the sanctuary.

**Archetypal Layer:** The census transforms the mixed multitude that left Egypt into an **organized military-liturgical community**. Each person is counted, named, placed within family, clan, and tribe. Identity is established through structure.

The Levites as buffer represent the **mediation necessary when the holy dwells among the unholy**. They absorb the danger.

**Psychological Reading:** Being counted matters. Each name, each head lifted, each person registered—the census creates belonging. The organization by tribes and clans provides identity within the larger whole.

**Ethical Inversion Applied:**
- The census is for military readiness—liberation leads to responsibility
- Each tribe has leadership—distributed authority
- The Levites are set apart—specialization serves the whole
- The tabernacle is central—worship organizes military and social life
- "According to all that YHWH commanded"—obedience structures the community

**Modern Equivalent:** Census and registration establish citizenship. The organization of the camp around the sanctuary models how communities organize around their sacred center. And the Levite role—specialists who manage the interface between ordinary and holy—anticipates specialized religious vocations.

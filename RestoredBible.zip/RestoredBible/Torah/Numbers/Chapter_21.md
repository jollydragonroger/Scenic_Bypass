# Numbers Chapter 21: The Bronze Serpent and Conquests

*From the Hebrew: נְחַשׁ הַנְּחֹשֶׁת (Nechash HaNechoshet) — The Serpent of Bronze*

---

**21:1** And the Canaanite, the king of Arad, who dwelt in the South, heard tell that Israel came by the way of Atharim; and he fought against Israel, and took some of them captive.

**21:2** And Israel vowed a vow unto YHWH, and said: "If you will indeed deliver this people into my hand, then I will utterly destroy their cities."

**21:3** And YHWH listened to the voice of Israel, and delivered up the Canaanites; and they utterly destroyed them and their cities; and the name of the place was called Hormah—חָרְמָה (Chormah).

---

**21:4** And they journeyed from Mount Hor by the way to the Red Sea, to go around the land of Edom; and the soul of the people became impatient because of the way.

**21:5** And the people spoke against God, and against Moses: "Why have you brought us up out of Egypt to die in the wilderness? For there is no bread, and there is no water; and our soul loathes this light bread."

**21:6** And YHWH sent fiery serpents—הַנְּחָשִׁים הַשְּׂרָפִים (ha-nechashim ha-serafim)—among the people, and they bit the people; and many people of Israel died.

**21:7** And the people came to Moses, and said: "We have sinned, because we have spoken against YHWH, and against you; pray unto YHWH, that he take away the serpents from us." And Moses prayed for the people.

**21:8** And YHWH said unto Moses: "Make a fiery serpent, and set it upon a pole; and it shall come to pass, that everyone who is bitten, when he sees it, shall live."

**21:9** And Moses made a serpent of bronze—נְחַשׁ נְחֹשֶׁת (nechash nechoshet)—and set it upon a pole; and it came to pass, that if a serpent had bitten any man, when he looked unto the serpent of bronze, he lived.

---

**21:10** And the children of Israel journeyed, and encamped in Oboth.

**21:11** And they journeyed from Oboth, and encamped at Iye-abarim, in the wilderness which is before Moab, toward the sunrise.

**21:12** From there they journeyed, and encamped in the valley of Zered.

**21:13** From there they journeyed, and encamped on the other side of the Arnon, which is in the wilderness, that comes out of the border of the Amorites; for the Arnon is the border of Moab, between Moab and the Amorites.

**21:14** Therefore it is said in the Book of the Wars of YHWH—בְּסֵפֶר מִלְחֲמֹת יהוה (be-Sefer Milchamot YHWH):
"Vaheb in Suphah,
And the valleys of the Arnon,

**21:15** "And the slope of the valleys
That inclines toward the seat of Ar,
And leans upon the border of Moab."

**21:16** And from there to Beer; that is the well of which YHWH said unto Moses: "Gather the people together, and I will give them water."

**21:17** Then Israel sang this song:
"Spring up, O well—עֲלִי בְאֵר (ali ve'er)—sing to it:

**21:18** "The well, which the princes dug,
Which the nobles of the people delved,
With the scepter, with their staves."
And from the wilderness to Mattanah;

**21:19** And from Mattanah to Nahaliel; and from Nahaliel to Bamoth;

**21:20** And from Bamoth to the valley that is in the field of Moab, to the top of Pisgah, which looks down upon the desert.

---

**21:21** And Israel sent messengers unto Sihon king of the Amorites, saying:

**21:22** "Let me pass through your land; we will not turn aside into field, or into vineyard; we will not drink of the water of the wells; we will go by the king's highway, until we have passed your border."

**21:23** And Sihon would not allow Israel to pass through his border; but Sihon gathered all his people together, and went out against Israel into the wilderness, and came to Jahaz; and he fought against Israel.

**21:24** And Israel smote him with the edge of the sword, and possessed his land from the Arnon unto the Jabbok, unto the children of Ammon; for the border of the children of Ammon was strong.

**21:25** And Israel took all these cities; and Israel dwelt in all the cities of the Amorites, in Heshbon, and in all its towns.

**21:26** For Heshbon was the city of Sihon the king of the Amorites, who had fought against the former king of Moab, and taken all his land out of his hand, unto the Arnon.

**21:27** Wherefore the poets say:
"Come to Heshbon,
Let the city of Sihon be built and established;

**21:28** "For a fire has gone out of Heshbon,
A flame from the city of Sihon;
It has devoured Ar of Moab,
The lords of the high places of the Arnon.

**21:29** "Woe to you, Moab!
You are undone, O people of Chemosh!
He has given his sons as fugitives,
And his daughters into captivity,
Unto Sihon king of the Amorites.

**21:30** "We have shot at them; Heshbon is perished unto Dibon,
And we have laid waste unto Nophah,
Which reaches unto Medeba."

**21:31** Thus Israel dwelt in the land of the Amorites.

**21:32** And Moses sent to spy out Jazer, and they took its towns, and drove out the Amorites who were there.

**21:33** And they turned and went up by the way of Bashan; and Og the king of Bashan went out against them, he and all his people, to battle at Edrei.

**21:34** And YHWH said unto Moses: "Fear him not; for I have delivered him into your hand, and all his people, and his land; and you shall do to him as you did unto Sihon king of the Amorites, who dwelt at Heshbon."

**21:35** So they smote him, and his sons, and all his people, until there was none left to him remaining; and they possessed his land.

---

## Synthesis Notes

**Key Restorations:**

**Victory at Hormah:**
The king of Arad attacks Israel and takes captives. Israel vows total destruction (*cherem*) if YHWH delivers them. YHWH does; Israel destroys the cities. Hormah means "destruction"—named for the *cherem* enacted.

**The Fiery Serpents:**
Israel complains again: "no bread, no water, we loathe this light bread (manna)." YHWH sends *nechashim serafim*—fiery serpents (burning, poisonous). Many die.

The people confess: "We have sinned." Moses prays.

**The Bronze Serpent:**
YHWH's remedy is surprising: make a serpent image, set it on a pole. Those bitten who look at it will live.

This is paradoxical: the serpent that kills becomes the image that heals. Looking at the representation of the threat brings salvation.

**Nechash Nechoshet:**
A wordplay: *nechash* (serpent) made of *nechoshet* (bronze/copper). The Hebrew words are related.

**Later History:**
This bronze serpent (*Nehushtan*) was preserved and eventually became an object of worship. King Hezekiah destroyed it (2 Kings 18:4) because Israel was burning incense to it.

**Jesus' Reference:**
"As Moses lifted up the serpent in the wilderness, so must the Son of Man be lifted up, that whoever believes in him may have eternal life" (John 3:14-15). The bronze serpent becomes a type of the crucified Christ.

**The Book of the Wars of YHWH:**
A lost text quoted here—ancient war poetry celebrating YHWH's battles. This indicates that the Torah draws on earlier sources.

**The Song of the Well:**
"Spring up, O well!" (*Ali be'er*)—a joyful song for water discovered. The princes and nobles dug with their staffs. Celebration of provision.

**Sihon of the Amorites:**
Israel requests peaceful passage (as with Edom). Sihon refuses and attacks. Israel defeats him and takes his territory from the Arnon to the Jabbok—the Transjordan.

**The Taunt Song:**
A poetic fragment mocking Moab and celebrating Sihon's earlier conquest. Now Israel takes what Sihon took. The irony: Sihon's victories become Israel's inheritance.

**Og of Bashan:**
Og attacks at Edrei. YHWH encourages Moses: "Fear him not; I have delivered him into your hand." Israel defeats Og and takes Bashan. These two victories (Sihon, Og) become paradigmatic in later Scripture (Psalm 135:11, 136:19-20).

**Archetypal Layer:** The bronze serpent is the **paradox of salvation through the image of death**. The thing that kills, when represented and gazed upon, heals. This is homeopathic theology—the poison becomes the cure.

The Transjordan victories mark the **beginning of conquest**. The wilderness wandering ends; military success begins. The generation of refusal is dying; the generation of inheritance is rising.

**Psychological Reading:** Looking at the serpent requires acknowledging the threat. The healing comes not by denying the danger but by facing it. The bronze image makes the killer visible; sight leads to life.

**Ethical Inversion Applied:**
- Complaint brings serpents—consequence for ingratitude
- Confession brings remedy—"we have sinned"
- The death-image heals—paradox of salvation
- Peaceful passage refused—Israel fights only when provoked
- Victories give Transjordan—the land east of Jordan becomes Israelite

**Modern Equivalent:** Medical practice uses attenuated pathogens (vaccines) to protect against disease—the principle of the bronze serpent. The psychological insight that facing one's fears (looking at the serpent) enables healing anticipates exposure therapy. And the Transjordan victories show that sometimes what is given comes through conflict when peaceful options fail.

# Numbers Chapter 3: The Levites and Their Duties

*From the Hebrew: בְּנֵי לֵוִי (Benei Levi) — Sons of Levi*

---

**3:1** Now these are the generations of Aaron and Moses in the day that YHWH spoke with Moses on Mount Sinai.

**3:2** And these are the names of the sons of Aaron: Nadab the firstborn, and Abihu, Eleazar, and Ithamar.

**3:3** These are the names of the sons of Aaron, the priests who were anointed, whom he consecrated to minister as priests.

**3:4** And Nadab and Abihu died before YHWH, when they offered strange fire before YHWH, in the wilderness of Sinai, and they had no children; and Eleazar and Ithamar ministered as priests in the presence of Aaron their father.

---

**3:5** And YHWH spoke unto Moses, saying:

**3:6** "Bring the tribe of Levi near, and set them before Aaron the priest, that they may minister unto him.

**3:7** "And they shall keep his charge, and the charge of the whole congregation before the tent of meeting, to do the service of the tabernacle.

**3:8** "And they shall keep all the vessels of the tent of meeting, and the charge of the children of Israel, to do the service of the tabernacle.

**3:9** "And you shall give the Levites unto Aaron and to his sons; they are wholly given—נְתֻנִים נְתֻנִים (netunim netunim)—unto him from the children of Israel.

**3:10** "And Aaron and his sons you shall appoint, and they shall keep their priesthood; and the stranger who comes near shall be put to death."

---

**3:11** And YHWH spoke unto Moses, saying:

**3:12** "And I, behold, I have taken the Levites from among the children of Israel instead of all the firstborn who open the womb among the children of Israel; and the Levites shall be mine.

**3:13** "For all the firstborn are mine; on the day that I smote all the firstborn in the land of Egypt I sanctified unto me all the firstborn in Israel, both man and beast; mine they shall be: I am YHWH."

---

**3:14** And YHWH spoke unto Moses in the wilderness of Sinai, saying:

**3:15** "Number the children of Levi by their fathers' houses, by their families; every male from a month old and upward you shall number."

**3:16** And Moses numbered them according to the word of YHWH, as he was commanded.

**3:17** And these were the sons of Levi by their names: Gershon, and Kohath, and Merari.

**3:18** And these are the names of the sons of Gershon by their families: Libni and Shimei.

**3:19** And the sons of Kohath by their families: Amram and Izhar, Hebron and Uzziel.

**3:20** And the sons of Merari by their families: Mahli and Mushi. These are the families of the Levites according to their fathers' houses.

**3:21** Of Gershon was the family of the Libnites, and the family of the Shimeites; these are the families of the Gershonites.

**3:22** Those who were numbered of them, according to the number of all the males, from a month old and upward, those who were numbered of them were seven thousand and five hundred.

**3:23** The families of the Gershonites shall encamp behind the tabernacle westward.

**3:24** And the prince of the father's house of the Gershonites shall be Eliasaph the son of Lael.

**3:25** And the charge of the sons of Gershon in the tent of meeting shall be the tabernacle, and the tent, its covering, and the screen for the door of the tent of meeting,

**3:26** And the hangings of the court, and the screen for the door of the court, which is by the tabernacle and by the altar round about, and the cords of it for all its service.

**3:27** And of Kohath was the family of the Amramites, and the family of the Izharites, and the family of the Hebronites, and the family of the Uzzielites; these are the families of the Kohathites.

**3:28** According to the number of all the males, from a month old and upward, there were eight thousand and six hundred, keeping the charge of the sanctuary.

**3:29** The families of the sons of Kohath shall encamp on the side of the tabernacle southward.

**3:30** And the prince of the father's house of the families of the Kohathites shall be Elizaphan the son of Uzziel.

**3:31** And their charge shall be the ark, and the table, and the lampstand, and the altars, and the vessels of the sanctuary with which they minister, and the screen, and all its service.

**3:32** And Eleazar the son of Aaron the priest shall be prince of the princes of the Levites, and have the oversight of those who keep the charge of the sanctuary.

**3:33** Of Merari was the family of the Mahlites, and the family of the Mushites; these are the families of Merari.

**3:34** And those who were numbered of them, according to the number of all the males, from a month old and upward, were six thousand and two hundred.

**3:35** And the prince of the father's house of the families of Merari was Zuriel the son of Abihail; they shall encamp on the side of the tabernacle northward.

**3:36** And the appointed charge of the sons of Merari shall be the boards of the tabernacle, and its bars, and its pillars, and its sockets, and all its vessels, and all its service,

**3:37** And the pillars of the court round about, and their sockets, and their pegs, and their cords.

**3:38** And those who encamp before the tabernacle eastward, before the tent of meeting toward the sunrise, shall be Moses, and Aaron and his sons, keeping the charge of the sanctuary in the charge of the children of Israel; and the stranger who comes near shall be put to death.

**3:39** All who were numbered of the Levites, whom Moses and Aaron numbered at the commandment of YHWH, by their families, all the males from a month old and upward, were twenty-two thousand.

---

**3:40** And YHWH said unto Moses: "Number all the firstborn males of the children of Israel from a month old and upward, and take the number of their names.

**3:41** "And you shall take the Levites for me—I am YHWH—instead of all the firstborn among the children of Israel; and the cattle of the Levites instead of all the firstlings among the cattle of the children of Israel."

**3:42** And Moses numbered, as YHWH commanded him, all the firstborn among the children of Israel.

**3:43** And all the firstborn males according to the number of names, from a month old and upward, of those who were numbered of them, were twenty-two thousand two hundred and seventy-three.

**3:44** And YHWH spoke unto Moses, saying:

**3:45** "Take the Levites instead of all the firstborn among the children of Israel, and the cattle of the Levites instead of their cattle; and the Levites shall be mine: I am YHWH.

**3:46** "And for the redemption of the two hundred and seventy-three of the firstborn of the children of Israel, who are over and above the number of the Levites,

**3:47** "You shall take five shekels apiece by the head; after the shekel of the sanctuary you shall take them—the shekel is twenty gerahs.

**3:48** "And you shall give the money, with which the excess of them is redeemed, unto Aaron and to his sons."

**3:49** And Moses took the redemption money from those who were over and above those who were redeemed by the Levites;

**3:50** From the firstborn of the children of Israel he took the money, a thousand three hundred and sixty-five shekels, after the shekel of the sanctuary.

**3:51** And Moses gave the redemption money unto Aaron and to his sons, according to the word of YHWH, as YHWH commanded Moses.

---

## Synthesis Notes

**Key Restorations:**

**Aaron's Line:**
The chapter begins with Aaron's genealogy, not Moses'. Though titled "generations of Aaron and Moses," the focus is the priestly line. Nadab and Abihu are remembered—they died for offering "strange fire" (Leviticus 10). Eleazar and Ithamar continue the priesthood.

**Levites Given to Aaron:**
The Levites serve the priests. They are "wholly given" (*netunim netunim*—the doubling emphasizes totality) to Aaron. They assist but do not perform priestly functions.

**Substitute for Firstborn:**
YHWH claims all firstborn (Exodus 13). Here the Levites substitute for Israel's firstborn. One Levite = one firstborn. This is redemption through substitution.

**The Levite Census:**
Unlike the other tribes (males 20+), Levites are counted from one month old. They are dedicated from infancy.

**The Three Levitical Clans:**

| Clan | Count | Position | Responsibilities |
|------|-------|----------|------------------|
| Gershon | 7,500 | West | Tent coverings, hangings, screens |
| Kohath | 8,600 | South | Sacred furniture (ark, table, lampstand, altars) |
| Merari | 6,200 | North | Structural elements (boards, bars, pillars, sockets) |

**Moses and Aaron:**
They camp on the east—the entrance side, before the tent of meeting toward the sunrise. This is the position of greatest honor and responsibility.

**Eleazar Over Kohath:**
Eleazar son of Aaron is "prince of the princes of the Levites"—chief supervisor over the Kohathites who handle the most sacred objects.

**Total Levites: 22,000**
The sum of the three clans (7,500 + 8,600 + 6,200 = 22,300) exceeds 22,000 by 300. Various explanations: scribal error, or the 300 were firstborn Levites who could not redeem other firstborn.

**The Surplus Firstborn:**
Israel's firstborn: 22,273
Levites: 22,000
Surplus: 273

These 273 firstborn cannot be "covered" by Levites and must pay 5 shekels each for redemption. Total: 1,365 shekels to Aaron and sons.

**Archetypal Layer:** The Levites are the **substitute offering**—they stand in for Israel's firstborn, who belong to YHWH by right of the Passover redemption. The entire tribe is "given" to serve. This is vicarious dedication.

**Psychological Reading:** Each Levite has a specific role: covering (Gershon), sacred objects (Kohath), structure (Merari). Knowing one's function within the larger purpose provides meaning. The surplus who must pay for redemption shows that the system deals with remainders—everyone is accounted for.

**Ethical Inversion Applied:**
- The firstborn belong to YHWH—the Passover created this claim
- Levites substitute—one life for another
- Specific roles for each clan—differentiation serves the whole
- The surplus is addressed—no one falls through the cracks
- "Stranger who comes near shall be put to death"—boundaries protect

**Modern Equivalent:** Specialized roles within organizations (like Levitical clans) enable complex operations. The substitution principle (Levites for firstborn) anticipates representative systems. And the redemption payment for the surplus shows that systems must handle edge cases.

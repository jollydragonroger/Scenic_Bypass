# Numbers Chapter 31: The War Against Midian

*From the Hebrew: נְקַם נִקְמַת (Neqam Niqmat) — The Vengeance*

---

**31:1** And YHWH spoke unto Moses, saying:

**31:2** "Avenge the children of Israel of the Midianites; afterward you shall be gathered unto your people."

**31:3** And Moses spoke unto the people, saying: "Arm from among you men for the war, that they may go against Midian, to execute YHWH's vengeance on Midian.

**31:4** "A thousand from every tribe, throughout all the tribes of Israel, shall you send to the war."

**31:5** So there were delivered, out of the thousands of Israel, a thousand of every tribe, twelve thousand armed for war.

**31:6** And Moses sent them, a thousand of every tribe, to the war, them and Phinehas the son of Eleazar the priest, to the war, with the holy vessels and the trumpets for the alarm in his hand.

**31:7** And they warred against Midian, as YHWH commanded Moses; and they slew every male.

**31:8** And they slew the kings of Midian with the rest of their slain: Evi, and Rekem, and Zur, and Hur, and Reba, the five kings of Midian; Balaam also the son of Beor they slew with the sword.

**31:9** And the children of Israel took captive the women of Midian and their little ones; and all their cattle, and all their flocks, and all their goods, they took for a prey.

**31:10** And all their cities in their settlements, and all their encampments, they burned with fire.

**31:11** And they took all the spoil, and all the prey, both of man and of beast.

**31:12** And they brought the captives, and the prey, and the spoil, unto Moses, and unto Eleazar the priest, and unto the congregation of the children of Israel, unto the camp, unto the plains of Moab, which are by the Jordan at Jericho.

---

**31:13** And Moses, and Eleazar the priest, and all the princes of the congregation, went forth to meet them outside the camp.

**31:14** And Moses was angry with the officers of the host, the captains of thousands and the captains of hundreds, who came from the service of the war.

**31:15** And Moses said unto them: "Have you saved all the women alive?

**31:16** "Behold, these caused the children of Israel, through the counsel of Balaam—בִּדְבַר בִּלְעָם (bi-devar Bil'am)—to commit trespass against YHWH in the matter of Peor, and so the plague was among the congregation of YHWH.

**31:17** "Now therefore kill every male among the little ones, and kill every woman who has known man by lying with him.

**31:18** "But all the young girls, who have not known man by lying with him, keep alive for yourselves.

**31:19** "And encamp outside the camp seven days; whoever has killed any person, and whoever has touched any slain, purify yourselves on the third day and on the seventh day, you and your captives.

**31:20** "And as to every garment, and all that is made of skin, and all work of goats' hair, and all things made of wood, you shall purify."

**31:21** And Eleazar the priest said unto the men of war who went to the battle: "This is the statute of the law which YHWH has commanded Moses:

**31:22** "Howbeit the gold, and the silver, the bronze, the iron, the tin, and the lead,

**31:23** "Everything that may abide the fire, you shall make to go through the fire, and it shall be clean; nevertheless it shall be purified with the water of impurity; and all that does not abide the fire you shall make to go through the water.

**31:24** "And you shall wash your clothes on the seventh day, and you shall be clean; and afterward you may come into the camp."

---

**31:25** And YHWH spoke unto Moses, saying:

**31:26** "Take the count of the prey that was taken, both of man and of beast, you, and Eleazar the priest, and the heads of the fathers' houses of the congregation;

**31:27** "And divide the prey into two parts: between the men skilled in war, who went out to battle, and all the congregation.

**31:28** "And levy a tribute unto YHWH of the men of war who went out to battle: one soul of every five hundred, both of the persons, and of the cattle, and of the donkeys, and of the flocks;

**31:29** "Take it of their half, and give it unto Eleazar the priest, as a contribution for YHWH.

**31:30** "And of the children of Israel's half, you shall take one drawn out of every fifty, of the persons, of the cattle, of the donkeys, and of the flocks, even of all the beasts, and give them unto the Levites, who keep the charge of the tabernacle of YHWH."

**31:31** And Moses and Eleazar the priest did as YHWH commanded Moses.

**31:32-47** [The inventory of spoil is listed in detail: 675,000 sheep, 72,000 cattle, 61,000 donkeys, 32,000 virgin women. Half went to the warriors, half to the congregation, with tributes to YHWH and the Levites.]

**31:48** And the officers who were over the thousands of the host, the captains of thousands, and the captains of hundreds, came near unto Moses;

**31:49** And they said unto Moses: "Your servants have taken the count of the men of war who are under our charge, and there lacks not one man of us.

**31:50** "And we have brought YHWH's offering, what every man has gotten, of jewels of gold, armlets, and bracelets, signet-rings, earrings, and pendants, to make atonement for our souls before YHWH."

**31:51** And Moses and Eleazar the priest took the gold of them, even all wrought jewels.

**31:52** And all the gold of the contribution that they set apart for YHWH, of the captains of thousands and of the captains of hundreds, was sixteen thousand seven hundred and fifty shekels.

**31:53** For the men of war had taken booty, every man for himself.

**31:54** And Moses and Eleazar the priest took the gold of the captains of thousands and of hundreds, and brought it into the tent of meeting, for a memorial for the children of Israel before YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Moses' Final Military Act:**
"Afterward you shall be gathered unto your people." This is Moses' last major action before death. He will not lead the conquest of Canaan, but he leads this punitive expedition.

**Twelve Thousand Warriors:**
One thousand from each tribe—a small, representative force. Phinehas (who stopped the plague at Peor) leads, carrying the holy vessels and trumpets.

**Total Victory:**
Israel kills all Midianite males, including the five kings (Evi, Rekem, Zur, Hur, Reba) and—significantly—Balaam. The seer who blessed Israel is killed with the sword among the Midianites.

**Balaam's Counsel Revealed:**
"These caused the children of Israel, through the counsel of Balaam, to commit trespass... in the matter of Peor." Now we learn Balaam's role: unable to curse Israel directly, he advised Midian on how to seduce them into apostasy. The Peor incident (chapter 25) was Balaam's strategy.

**Moses' Anger:**
The officers brought back women and children. Moses is furious: these are the very women who seduced Israel. The women who participated in the Peor seduction must die.

**The Command:**
- Kill all male children
- Kill all women who have known a man
- Keep the virgin girls

This is harsh, reflecting the logic of *cherem* (total destruction) and the prevention of future seduction.

**Purification:**
Those who killed or touched corpses are unclean seven days. The purification ritual (days 3 and 7, water of impurity) applies. Metal items are purified by fire; other items by water.

**Division of Spoil:**

The spoil is divided:
- Half to the 12,000 warriors
- Half to the congregation

Tributes:
- From the warriors' half: 1/500 to the priests
- From the congregation's half: 1/50 to the Levites

The warriors give a smaller percentage (0.2%) because they did the fighting; the congregation gives a larger percentage (2%) because they received without fighting.

**Not One Man Lost:**
The officers report zero casualties—an extraordinary result. In gratitude, they offer gold jewelry as an atonement offering. 16,750 shekels of gold go to the sanctuary.

**Archetypal Layer:** The war against Midian is **vengeance for Peor**—the seduction is avenged. Balaam's death completes his story: the prophet who blessed Israel is killed among those who followed his advice to corrupt them.

The division of spoil establishes **principles of distribution**: those who fight receive, but the community also shares; the sanctuary and its servants receive their portion.

**Psychological Reading:** Moses' anger at the officers reveals the depth of feeling about Peor. The women who seduced Israel cannot be integrated—the danger of repeated seduction is too great.

**Ethical Inversion Applied:**
- Vengeance is YHWH's—executed through Israel
- Balaam's death reveals his treachery—the blesser became adviser of corruption
- The seducers are eliminated—the source of apostasy is removed
- Purification follows warfare—killing creates impurity requiring cleansing
- Distribution includes all—fighters and community, priests and Levites

**Difficult Elements:**
The killing of women and male children is deeply troubling. The text presents it as necessary to prevent future corruption. Ancient warfare often involved such practices, but the moral challenge remains. The virgin girls kept "for yourselves" also raises questions about their fate.

**Modern Equivalent:** The principle of addressing the root cause of seduction (Balaam's advice, the seducing women) rather than merely the symptoms remains relevant in different contexts. And the purification requirements after violence suggest that killing, even when commanded, is not morally neutral—it requires cleansing.

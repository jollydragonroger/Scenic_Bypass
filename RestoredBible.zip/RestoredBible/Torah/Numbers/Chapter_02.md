# Numbers Chapter 2: The Arrangement of the Camp

*From the Hebrew: דֶּגֶל (Degel) — The Standards*

---

**2:1** And YHWH spoke unto Moses and unto Aaron, saying:

**2:2** "The children of Israel shall encamp every man by his own standard—דֶּגֶל (degel)—with the ensigns of their fathers' houses; at a distance, around the tent of meeting they shall encamp.

---

**2:3** "And those who encamp on the east side toward the sunrise shall be the standard of the camp of Judah, according to their hosts; and the prince of the children of Judah is Nahshon the son of Amminadab.

**2:4** "And his host, and those who were numbered of them, are seventy-four thousand and six hundred.

**2:5** "And those who encamp next to him shall be the tribe of Issachar; and the prince of the children of Issachar is Nethanel the son of Zuar.

**2:6** "And his host, and those who were numbered of it, are fifty-four thousand and four hundred.

**2:7** "Then the tribe of Zebulun; and the prince of the children of Zebulun is Eliab the son of Helon.

**2:8** "And his host, and those who were numbered of it, are fifty-seven thousand and four hundred.

**2:9** "All who were numbered of the camp of Judah are a hundred and eighty-six thousand and four hundred, according to their hosts. They shall set forth first.

---

**2:10** "On the south side shall be the standard of the camp of Reuben according to their hosts; and the prince of the children of Reuben is Elizur the son of Shedeur.

**2:11** "And his host, and those who were numbered of it, are forty-six thousand and five hundred.

**2:12** "And those who encamp next to him shall be the tribe of Simeon; and the prince of the children of Simeon is Shelumiel the son of Zurishaddai.

**2:13** "And his host, and those who were numbered of them, are fifty-nine thousand and three hundred.

**2:14** "Then the tribe of Gad; and the prince of the children of Gad is Eliasaph the son of Reuel.

**2:15** "And his host, and those who were numbered of them, are forty-five thousand six hundred and fifty.

**2:16** "All who were numbered of the camp of Reuben are a hundred and fifty-one thousand four hundred and fifty, according to their hosts. And they shall set forth second.

---

**2:17** "Then the tent of meeting shall set forth, with the camp of the Levites in the midst of the camps; as they encamp, so shall they set forth, every man in his place, by their standards.

---

**2:18** "On the west side shall be the standard of the camp of Ephraim according to their hosts; and the prince of the children of Ephraim is Elishama the son of Ammihud.

**2:19** "And his host, and those who were numbered of them, are forty thousand and five hundred.

**2:20** "And next to him shall be the tribe of Manasseh; and the prince of the children of Manasseh is Gamaliel the son of Pedahzur.

**2:21** "And his host, and those who were numbered of them, are thirty-two thousand and two hundred.

**2:22** "Then the tribe of Benjamin; and the prince of the children of Benjamin is Abidan the son of Gideoni.

**2:23** "And his host, and those who were numbered of them, are thirty-five thousand and four hundred.

**2:24** "All who were numbered of the camp of Ephraim are a hundred and eight thousand and one hundred, according to their hosts. And they shall set forth third.

---

**2:25** "On the north side shall be the standard of the camp of Dan according to their hosts; and the prince of the children of Dan is Ahiezer the son of Ammishaddai.

**2:26** "And his host, and those who were numbered of them, are sixty-two thousand and seven hundred.

**2:27** "And those who encamp next to him shall be the tribe of Asher; and the prince of the children of Asher is Pagiel the son of Ochran.

**2:28** "And his host, and those who were numbered of them, are forty-one thousand and five hundred.

**2:29** "Then the tribe of Naphtali; and the prince of the children of Naphtali is Ahira the son of Enan.

**2:30** "And his host, and those who were numbered of them, are fifty-three thousand and four hundred.

**2:31** "All who were numbered of the camp of Dan are a hundred and fifty-seven thousand and six hundred. They shall set forth hindmost by their standards."

---

**2:32** These are they who were numbered of the children of Israel by their fathers' houses; all who were numbered of the camps according to their hosts are six hundred and three thousand five hundred and fifty.

**2:33** But the Levites were not numbered among the children of Israel, as YHWH commanded Moses.

**2:34** And the children of Israel did according to all that YHWH commanded Moses; so they encamped by their standards, and so they set forth, every man by his families, according to his father's house.

---

## Synthesis Notes

**Key Restorations:**

**The Camp Arrangement:**

The tabernacle is at the center. The twelve tribes camp around it in four divisions of three tribes each:

**EAST (toward sunrise)** — Camp of Judah:
- Judah (74,600) — lead tribe
- Issachar (54,400)
- Zebulun (57,400)
- **Total: 186,400** — *Sets forth first*

**SOUTH** — Camp of Reuben:
- Reuben (46,500) — lead tribe
- Simeon (59,300)
- Gad (45,650)
- **Total: 151,450** — *Sets forth second*

**CENTER** — The Levites with the tabernacle

**WEST** — Camp of Ephraim:
- Ephraim (40,500) — lead tribe
- Manasseh (32,200)
- Benjamin (35,400)
- **Total: 108,100** — *Sets forth third*

**NORTH** — Camp of Dan:
- Dan (62,700) — lead tribe
- Asher (41,500)
- Naphtali (53,400)
- **Total: 157,600** — *Sets forth last (rear guard)*

**The Standards (דֶּגֶל, degel):**
Each division has its own standard—a flag or banner. Later tradition (not in the text) assigned symbols: Judah = lion, Reuben = man, Ephraim = ox, Dan = eagle. These four correspond to the four living creatures of Ezekiel 1 and Revelation 4.

**"At a Distance":**
The tribes camp "at a distance" from the tent of meeting. The Levites form the inner ring (chapter 3 will detail their positions). The distance protects the people from the holy.

**Judah First:**
Judah's camp leads the march. This is significant: Judah will become the royal tribe, the line of David. The preeminence is established here in the march order.

**The Tabernacle in the Center:**
When Israel moves, the tabernacle moves in the center of the column—after Judah and Reuben, before Ephraim and Dan. The sanctuary is protected on all sides.

**The Groupings:**
The camp divisions reflect genealogical relationships:
- East: Leah's sons (Judah, Issachar, Zebulun)
- South: Leah's firstborn Reuben, plus Simeon (Leah) and Gad (Zilpah)
- West: Rachel's descendants (Ephraim and Manasseh = Joseph; Benjamin)
- North: Bilhah's son Dan, plus Asher (Zilpah) and Naphtali (Bilhah)

**Archetypal Layer:** The camp is a **sacred geometry**—the holy at the center, the tribes arranged by cardinal directions, the march order prescribed. This is liturgical organization: Israel moves as a worshipping community, not merely as refugees or an army.

The four-sided arrangement around the sanctuary anticipates the heavenly city (Revelation 21:12-13) with gates on four sides for the twelve tribes.

**Psychological Reading:** Knowing one's place provides security. Each tribe has its position, its standard, its leader, its number. The camp is ordered, not chaotic. Order around the holy creates stability.

**Ethical Inversion Applied:**
- The tabernacle is central—worship organizes everything else
- Judah leads—later royal preeminence begins here
- Distance from the holy protects—access is graduated
- Each tribe has its place—diversity within unity
- The march is organized—movement has structure

**Modern Equivalent:** Communities organize around their sacred center (church, temple, civic space). The arrangement of the camp models how physical positioning reflects spiritual priorities. And the clear chain of leadership (tribal princes, march order) enables coordinated action.

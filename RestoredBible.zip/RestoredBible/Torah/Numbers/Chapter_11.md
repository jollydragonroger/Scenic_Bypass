# Numbers Chapter 11: Complaints, Quail, and the Spirit

*From the Hebrew: תַּבְעֵרָה (Taberah) — The Place of Burning*

---

**11:1** And the people were as murmurers, speaking evil in the ears of YHWH; and when YHWH heard it, his anger was kindled; and the fire of YHWH burned among them, and devoured in the outermost part of the camp.

**11:2** And the people cried unto Moses; and Moses prayed unto YHWH, and the fire abated.

**11:3** And the name of that place was called Taberah—תַּבְעֵרָה (Taberah)—because the fire of YHWH burned among them.

---

**11:4** And the mixed multitude—הָאסַפְסֻף (ha-asafsuf)—that was among them fell to lusting; and the children of Israel also wept again, and said: "Who shall give us flesh to eat?

**11:5** "We remember the fish, which we ate in Egypt for nothing; the cucumbers, and the melons, and the leeks, and the onions, and the garlic.

**11:6** "But now our soul is dried away; there is nothing at all; only this manna to look upon."

**11:7** And the manna was like coriander seed, and its color was like the color of bdellium.

**11:8** The people went about, and gathered it, and ground it in mills, or beat it in mortars, and boiled it in pots, and made cakes of it; and its taste was like the taste of cakes baked with oil.

**11:9** And when the dew fell upon the camp in the night, the manna fell upon it.

---

**11:10** And Moses heard the people weeping throughout their families, every man at the door of his tent; and the anger of YHWH was kindled greatly; and Moses was displeased.

**11:11** And Moses said unto YHWH: "Why have you dealt ill with your servant? And why have I not found favor in your sight, that you lay the burden of all this people upon me?

**11:12** "Have I conceived all this people? Have I brought them forth, that you should say unto me, 'Carry them in your bosom, as a nursing father carries the sucking child,' unto the land which you swore unto their fathers?

**11:13** "Where should I get flesh to give unto all this people? For they weep unto me, saying, 'Give us flesh, that we may eat.'

**11:14** "I am not able to bear all this people alone, because it is too heavy for me.

**11:15** "And if you deal thus with me, kill me, I pray, out of hand, if I have found favor in your sight; and let me not see my wretchedness."

---

**11:16** And YHWH said unto Moses: "Gather unto me seventy men of the elders of Israel, whom you know to be elders of the people, and officers over them; and bring them unto the tent of meeting, that they may stand there with you.

**11:17** "And I will come down and speak with you there; and I will take of the spirit which is upon you, and will put it upon them; and they shall bear the burden of the people with you, that you bear it not yourself alone.

**11:18** "And say unto the people: 'Sanctify yourselves for tomorrow, and you shall eat flesh; for you have wept in the ears of YHWH, saying, "Who shall give us flesh to eat? For it was well with us in Egypt." Therefore YHWH will give you flesh, and you shall eat.

**11:19** "'You shall not eat one day, nor two days, nor five days, neither ten days, nor twenty days,

**11:20** "'But a whole month, until it comes out at your nostrils, and it becomes loathsome unto you; because you have rejected YHWH who is among you, and have wept before him, saying, "Why did we come out of Egypt?"'"

**11:21** And Moses said: "The people, among whom I am, are six hundred thousand footmen; and you have said, 'I will give them flesh, that they may eat a whole month!'

**11:22** "Shall flocks and herds be slaughtered for them, to suffice them? Or shall all the fish of the sea be gathered together for them, to suffice them?"

**11:23** And YHWH said unto Moses: "Is YHWH's hand short?—הֲיַד יהוה תִּקְצָר (ha-yad YHWH tiqtsar)—Now you shall see whether my word shall come to pass unto you or not."

---

**11:24** And Moses went out, and told the people the words of YHWH; and he gathered seventy men of the elders of the people, and set them round about the tent.

**11:25** And YHWH came down in the cloud, and spoke unto him, and took of the spirit that was upon him, and put it upon the seventy elders; and it came to pass, that, when the spirit rested upon them, they prophesied, but they did so no more.

**11:26** But there remained two men in the camp, the name of the one was Eldad, and the name of the other Medad; and the spirit rested upon them; and they were among those who were written, but had not gone out unto the tent; and they prophesied in the camp.

**11:27** And a young man ran, and told Moses, and said: "Eldad and Medad are prophesying in the camp!"

**11:28** And Joshua the son of Nun, the attendant of Moses from his youth, answered and said: "My lord Moses, forbid them!"

**11:29** And Moses said unto him: "Are you jealous for my sake? Would that all YHWH's people were prophets, that YHWH would put his spirit upon them!"—מִי יִתֵּן כָּל־עַם יהוה נְבִיאִים (mi yitten kol-am YHWH nevi'im).

**11:30** And Moses withdrew into the camp, he and the elders of Israel.

---

**11:31** And a wind went forth from YHWH, and brought quails from the sea, and let them fall by the camp, about a day's journey on this side, and a day's journey on the other side, round about the camp, and about two cubits above the face of the earth.

**11:32** And the people rose up all that day, and all the night, and all the next day, and gathered the quails; he who gathered least gathered ten homers; and they spread them all abroad for themselves round about the camp.

**11:33** While the flesh was yet between their teeth, before it was chewed, the anger of YHWH was kindled against the people, and YHWH smote the people with a very great plague.

**11:34** And the name of that place was called Kibroth-hattaavah—קִבְרוֹת הַתַּאֲוָה (Qivrot HaTa'avah)—because there they buried the people who lusted.

**11:35** From Kibroth-hattaavah the people journeyed unto Hazeroth; and they abode at Hazeroth.

---

## Synthesis Notes

**Key Restorations:**

**Taberah — "Burning":**
The journey from Sinai immediately produces complaint. YHWH's fire consumes "the outermost part of the camp." Moses intercedes; the fire stops. The place is named for the event: *Taberah*, burning.

**The Mixed Multitude (הָאסַפְסֻף, ha-asafsuf):**
Non-Israelites who joined the exodus (Exodus 12:38). They "fell to lusting"—literally, "they lusted a lust" (*hit'avvu ta'avah*). The desire is intense, obsessive. Israel joins in.

**The Complaint:**
"We remember the fish... cucumbers, melons, leeks, onions, garlic." Memory of Egyptian food, romanticized. "Our soul is dried away; there is nothing at all; only this manna." Ingratitude for divine provision; longing for slavery's cuisine.

**Moses' Breakdown (11:10-15):**
Moses reaches his limit:
- "Why have you dealt ill with your servant?"
- "Have I conceived all this people?"
- "I am not able to bear all this people alone"
- "Kill me, I pray, out of hand"

This is genuine leadership crisis—exhaustion, frustration, despair. Moses does not hide his limits.

**The Seventy Elders:**
YHWH's response to Moses' complaint:
- Gather seventy elders
- YHWH will take from the spirit on Moses and distribute it
- They will share the burden

This is delegated authority and distributed spiritual gifting. Moses is not diminished; the spirit is extended.

**"They Prophesied, but Did So No More":**
The prophesying was a one-time sign validating their calling—not an ongoing prophetic ministry. The spirit's manifestation confirmed their appointment.

**Eldad and Medad:**
Two of the seventy who stayed in camp rather than going to the tent. The spirit came upon them anyway. They prophesied in the camp.

**Joshua's Jealousy:**
Joshua, Moses' young attendant, is alarmed: "Forbid them!" He sees unauthorized prophecy as threatening Moses' authority.

**Moses' Response:**
"Are you jealous for my sake? Would that all YHWH's people were prophets!" Moses refuses to monopolize the spirit. He desires democratized revelation—all Israel as prophets. This anticipates Joel 2:28-29.

**"Is YHWH's Hand Short?":**
Moses doubts the promise of meat for 600,000 for a month. YHWH's response challenges the limit of Moses' faith. Divine capacity exceeds human calculation.

**The Quail:**
Wind brings quail from the sea—piled two cubits deep, a day's journey in every direction. The people gather greedily: the minimum gathered was ten homers (about 60 bushels).

**Kibroth-hattaavah — "Graves of Craving":**
Before they even finish chewing, plague strikes. Those who craved are buried. The place is named *Qivrot HaTa'avah*—graves of the cravers. Getting what you lust for can kill you.

**Archetypal Layer:** The progression—complaint, fire, intercession, more complaint, divine response—reveals the **pattern of wilderness testing**. The journey from Sinai exposes the heart. Liberation was easier than transformation.

The seventy elders with distributed spirit model **shared leadership**. Moses' wish for universal prophecy anticipates Pentecost.

**Psychological Reading:** Moses' breakdown is honest. He does not pretend to cope. His prayer is raw: "Kill me." YHWH responds not with rebuke but with help—distributed leadership. The system is redesigned to address the complaint.

The quail episode shows **the danger of getting what you crave**. Desire granted excessively becomes judgment. The graves of craving warn against obsessive longing.

**Ethical Inversion Applied:**
- Complaint is remembered—places are named for failure
- Moses' breakdown is heard—YHWH provides help, not condemnation
- The spirit is distributed—leadership is shared, not hoarded
- Joshua's jealousy is rebuked—spiritual gifts are not to be monopolized
- Craving is deadly—getting what you want can destroy you

**Modern Equivalent:** Leaders reaching burnout need support, not criticism. Distributed leadership prevents collapse. And the graves of craving warn: be careful what you wish for. Obsessive desire, even when granted, may bring destruction rather than satisfaction.

# Numbers Chapter 34: The Boundaries of the Land

*From the Hebrew: גְּבוּל הָאָרֶץ (Gevul Ha-Arets) — The Border of the Land*

---

**34:1** And YHWH spoke unto Moses, saying:

**34:2** "Command the children of Israel, and say unto them: 'When you come into the land of Canaan, this shall be the land that shall fall unto you for an inheritance, even the land of Canaan according to its borders.

**34:3** "'Your south side shall be from the wilderness of Zin along by the side of Edom, and your south border shall be from the end of the Salt Sea eastward;

**34:4** "'And your border shall turn about southward of the ascent of Akrabbim, and pass along to Zin; and the goings out thereof shall be southward of Kadesh-barnea; and it shall go forth to Hazar-addar, and pass along to Azmon;

**34:5** "'And the border shall turn about from Azmon unto the Brook of Egypt, and the goings out thereof shall be at the Sea.

**34:6** "'And for the western border, you shall have the Great Sea and its border; this shall be your west border.

**34:7** "'And this shall be your north border: from the Great Sea you shall mark out your line unto Mount Hor;

**34:8** "'From Mount Hor you shall mark out a line unto the entrance of Hamath; and the goings out of the border shall be at Zedad;

**34:9** "'And the border shall go forth to Ziphron, and the goings out thereof shall be at Hazar-enan; this shall be your north border.

**34:10** "'And you shall mark out your east border from Hazar-enan to Shepham;

**34:11** "'And the border shall go down from Shepham to Riblah, on the east side of Ain; and the border shall go down, and shall strike upon the shoulder of the sea of Chinnereth eastward;

**34:12** "'And the border shall go down to the Jordan, and the goings out thereof shall be at the Salt Sea. This shall be your land according to its borders round about.'"

---

**34:13** And Moses commanded the children of Israel, saying: "This is the land which you shall inherit by lot, which YHWH has commanded to give unto the nine tribes, and to the half-tribe;

**34:14** "For the tribe of the children of Reuben according to their fathers' houses, and the tribe of the children of Gad according to their fathers' houses, have received, and the half-tribe of Manasseh have received their inheritance;

**34:15** "The two tribes and the half-tribe have received their inheritance beyond the Jordan at Jericho eastward, toward the sunrise."

---

**34:16** And YHWH spoke unto Moses, saying:

**34:17** "These are the names of the men who shall take possession of the land for you: Eleazar the priest, and Joshua the son of Nun.

**34:18** "And you shall take one prince of every tribe, to take possession of the land.

**34:19** "And these are the names of the men: of the tribe of Judah, Caleb the son of Jephunneh.

**34:20** "And of the tribe of the children of Simeon, Shemuel the son of Ammihud.

**34:21** "Of the tribe of Benjamin, Elidad the son of Chislon.

**34:22** "And of the tribe of the children of Dan a prince, Bukki the son of Jogli.

**34:23** "Of the children of Joseph: of the tribe of the children of Manasseh a prince, Hanniel the son of Ephod.

**34:24** "And of the tribe of the children of Ephraim a prince, Kemuel the son of Shiphtan.

**34:25** "And of the tribe of the children of Zebulun a prince, Elizaphan the son of Parnach.

**34:26** "And of the tribe of the children of Issachar a prince, Paltiel the son of Azzan.

**34:27** "And of the tribe of the children of Asher a prince, Ahihud the son of Shelomi.

**34:28** "And of the tribe of the children of Naphtali a prince, Pedahel the son of Ammihud."

**34:29** These are they whom YHWH commanded to divide the inheritance unto the children of Israel in the land of Canaan.

---

## Synthesis Notes

**Key Restorations:**

**The Promised Land Defined:**
YHWH specifies the exact boundaries of Canaan—the land west of the Jordan that Israel will inherit. This is distinct from the Transjordan territories already assigned to Reuben, Gad, and half of Manasseh.

**The Borders:**

**South:** From the wilderness of Zin along Edom's border, from the southern end of the Dead Sea (Salt Sea), through the Ascent of Akrabbim (Scorpion Pass), to Kadesh-barnea, then to the Brook of Egypt (Wadi el-Arish), ending at the Mediterranean.

**West:** The Great Sea (Mediterranean) and its coastline.

**North:** From the Mediterranean to Mount Hor (a northern mountain, not the one where Aaron died), to the entrance of Hamath, to Zedad, Ziphron, and Hazar-enan.

**East:** From Hazar-enan to Shepham, down to Riblah, along the Sea of Chinnereth (Galilee), down the Jordan River to the Dead Sea.

**The Shape:**
The boundaries describe roughly the territory from the Negev desert to Lebanon, from the Mediterranean to the Jordan Valley. This is "Greater Israel" or "Canaan proper"—though Israel never fully controlled all of it.

**Nine and a Half Tribes:**
The land division is for nine and a half tribes. Reuben, Gad, and half of Manasseh already have their Transjordan allotments.

**The Land Commission:**
Ten tribal representatives will oversee the division:
- **Eleazar** (high priest) and **Joshua** (leader)
- **Caleb** for Judah—the surviving faithful spy
- Nine other princes, one per tribe

Note: The order differs from earlier lists, reflecting the actual settlement pattern (south to north).

**Caleb Named:**
Caleb son of Jephunneh—who spied the land and brought a good report—will distribute Judah's territory. His faithfulness is rewarded with this role.

**Archetypal Layer:** The boundaries define **sacred space**. The land is not vaguely "over there" but precisely delineated. Every border point is named. This is real geography, not mythic territory.

The appointment of princes creates **shared authority** for distribution. No single leader decides alone; tribal representatives participate.

**Psychological Reading:** Precise boundaries create clarity. The people know exactly what they are to inherit. Ambiguity is removed; the goal is defined.

**Ethical Inversion Applied:**
- The land is defined by YHWH—not by human conquest alone
- Boundaries are specific—the inheritance is measurable
- Nine and a half tribes receive Canaan—the Transjordan is settled
- Caleb participates in distribution—faithfulness is honored
- Tribal representatives share authority—distribution is collective

**Historical Note:**
Israel's actual control varied over the centuries. Solomon's kingdom approached these boundaries; later periods saw much smaller territories. The defined borders represent the ideal inheritance.

**Modern Equivalent:** Clear definitions of scope (what is included, what is not) enable implementation. The commission structure (leadership plus representatives) models participatory governance. And the distinction between ideal boundaries and actual control remains relevant in any project.

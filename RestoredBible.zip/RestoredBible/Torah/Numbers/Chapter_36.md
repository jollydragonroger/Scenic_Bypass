# Numbers Chapter 36: The Inheritance of Zelophehad's Daughters

*From the Hebrew: נַחֲלַת בְּנוֹת צְלָפְחָד (Nachalat Benot Tselofchad) — The Daughters' Inheritance Secured*

---

**36:1** And the heads of the fathers' houses of the family of the children of Gilead, the son of Machir, the son of Manasseh, of the families of the sons of Joseph, came near, and spoke before Moses, and before the princes, the heads of the fathers' houses of the children of Israel.

**36:2** And they said: "YHWH commanded my lord to give the land for inheritance by lot to the children of Israel; and my lord was commanded by YHWH to give the inheritance of Zelophehad our brother unto his daughters.

**36:3** "And if they marry any of the sons of the other tribes of the children of Israel, then will their inheritance be taken away from the inheritance of our fathers, and will be added to the inheritance of the tribe unto which they shall belong; so will it be taken away from the lot of our inheritance.

**36:4** "And when the jubilee of the children of Israel shall be, then will their inheritance be added unto the inheritance of the tribe unto which they shall belong; so will their inheritance be taken away from the inheritance of the tribe of our fathers."

---

**36:5** And Moses commanded the children of Israel according to the word of YHWH, saying: "The tribe of the sons of Joseph speaks right.

**36:6** "This is the thing which YHWH commands concerning the daughters of Zelophehad, saying: 'Let them marry whom they think best; only into the family of the tribe of their father shall they marry.

**36:7** "'So shall no inheritance of the children of Israel be transferred from tribe to tribe; for the children of Israel shall cleave every one to the inheritance of the tribe of his fathers.

**36:8** "'And every daughter, who possesses an inheritance in any tribe of the children of Israel, shall marry one of the family of the tribe of her father, that the children of Israel may possess every man the inheritance of his fathers.

**36:9** "'So shall no inheritance be transferred from one tribe to another tribe; for the tribes of the children of Israel shall cleave every one to its own inheritance.'"

**36:10** Even as YHWH commanded Moses, so did the daughters of Zelophehad.

**36:11** For Mahlah, Tirzah, and Hoglah, and Milcah, and Noah, the daughters of Zelophehad, married their father's brothers' sons.

**36:12** They married into the families of the sons of Manasseh the son of Joseph, and their inheritance remained in the tribe of the family of their father.

**36:13** These are the commandments and the ordinances which YHWH commanded by the hand of Moses unto the children of Israel in the plains of Moab by the Jordan at Jericho.

---

## Synthesis Notes

**Key Restorations:**

**The Problem:**
Chapter 27 established that daughters inherit when there are no sons. But what happens if those daughters marry outside their tribe? Their inheritance would transfer to the husband's tribe, permanently diminishing their original tribe's territory.

**The Manassite Concern:**
The heads of the Gilead clan (Manasseh) raise the issue. Zelophehad's daughters are Manassites. If they marry men from other tribes, Manasseh loses their portion. Even the jubilee won't restore it—the jubilee returns land to families, but the family would now belong to a different tribe.

**"The Tribe of the Sons of Joseph Speaks Right":**
Moses validates their concern. The earlier ruling (daughters inherit) created an unintended consequence (potential tribal territory loss). The system needs refinement.

**The Solution:**
Daughters who inherit land must marry within their father's tribe. They have free choice of husband ("whom they think best") within that constraint. This preserves both:
1. The daughters' right to inherit
2. The tribal territory integrity

**The Daughters Comply:**
Mahlah, Tirzah, Hoglah, Milcah, and Noah marry their cousins—sons of their father's brothers. The inheritance stays in Manasseh.

**A General Rule:**
The ruling extends beyond Zelophehad's case: any daughter who inherits must marry within her tribe. The tribal boundaries are maintained across generations.

**The Closing (36:13):**
"These are the commandments and the ordinances which YHWH commanded by the hand of Moses unto the children of Israel in the plains of Moab by the Jordan at Jericho."

This final verse closes the book of Numbers. The people are poised to enter Canaan; the laws are given; the next step is Joshua.

**Archetypal Layer:** The chapter shows **law refining itself**. The earlier ruling (daughters inherit) was correct but incomplete. New cases reveal implications that require adjustment. The law develops through application.

The balance between **individual rights** (daughters inherit, daughters choose husbands) and **communal structure** (tribal territories remain intact) models how legal systems navigate competing values.

**Psychological Reading:** The daughters of Zelophehad are not passive recipients of decisions about them. In chapter 27, they advocated for themselves. Here, they comply with the refinement. Their agency is recognized within the communal framework.

**Ethical Inversion Applied:**
- The earlier ruling was right but incomplete—law develops
- Daughters choose husbands—freedom within constraint
- Tribal integrity is preserved—community structure is valued
- The cousins are mentioned by name—specific obedience recorded
- The book closes in the plains of Moab—ready to cross

**The Book of Numbers Complete:**

Numbers traces Israel from Sinai to the plains of Moab:
- The first census (1-4)
- Purity and offerings (5-10)
- Failures and wandering (11-20)
- The new generation's approach (21-36)

The book begins with order (census, camp arrangement) and ends with order (boundaries, cities, inheritance). Between lies the wilderness: rebellion, plague, serpents, Balaam, and the death of an entire generation. The people who leave Sinai are not the people who reach Moab.

---

## Book Summary: Numbers

Numbers narrates forty years of wilderness experience. The Hebrew title (*Bemidbar*, "In the Wilderness") captures the setting better than the English title (from the censuses).

**Structure:**
1. **At Sinai** (1-10): Census, Levites, purity laws, departure
2. **Wilderness Wandering** (11-21): Complaints, spies, rebellion, bronze serpent
3. **Plains of Moab** (22-36): Balaam, Peor, second census, preparation for conquest

**Themes:**
- **Rebellion and consequence**: The first generation refuses the land and dies in the wilderness
- **Divine provision**: Manna, water, quail—YHWH sustains despite complaint
- **Leadership succession**: Aaron dies, Eleazar takes over; Moses is told he will die, Joshua is commissioned
- **Preparation for the land**: Boundaries, cities, inheritance laws—the second generation is equipped

**The Moral Center:**
Those who trust YHWH's promise (Caleb, Joshua) enter the land. Those who fear the giants more than they trust YHWH die in the wilderness. The distinction between the two generations is faith.

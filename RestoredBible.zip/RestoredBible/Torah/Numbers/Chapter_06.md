# Numbers Chapter 6: The Nazirite Vow and the Priestly Blessing

*From the Hebrew: נָזִיר (Nazir) — The Consecrated One*

---

**6:1** And YHWH spoke unto Moses, saying:

**6:2** "Speak unto the children of Israel, and say unto them: 'When either man or woman shall make a special vow, the vow of a Nazirite—נֶדֶר נָזִיר (neder nazir)—to separate himself unto YHWH,

**6:3** "'He shall separate himself from wine and strong drink; he shall drink no vinegar of wine, or vinegar of strong drink, neither shall he drink any juice of grapes, nor eat fresh grapes or dried.

**6:4** "'All the days of his separation he shall eat nothing that is made of the grape-vine, from the seeds even to the skin.

**6:5** "'All the days of his vow of separation no razor shall come upon his head; until the days are fulfilled, during which he separates himself unto YHWH, he shall be holy; he shall let the locks of the hair of his head grow long.

**6:6** "'All the days that he separates himself unto YHWH he shall not come near a dead body.

**6:7** "'He shall not make himself unclean for his father, or for his mother, for his brother, or for his sister, when they die; because his consecration unto Consciousness is upon his head.

**6:8** "'All the days of his separation he is holy unto YHWH.

---

**6:9** "'And if any man dies very suddenly beside him, and he defiles the head of his consecration, then he shall shave his head on the day of his cleansing; on the seventh day he shall shave it.

**6:10** "'And on the eighth day he shall bring two turtledoves, or two young pigeons, to the priest, to the door of the tent of meeting.

**6:11** "'And the priest shall offer one for a sin offering, and the other for a burnt offering, and make atonement for him, because he sinned by reason of the dead, and shall hallow his head that same day.

**6:12** "'And he shall consecrate unto YHWH the days of his separation, and shall bring a male lamb a year old for a guilt offering; but the former days shall be void, because his separation was defiled.

---

**6:13** "'And this is the law of the Nazirite, when the days of his separation are fulfilled: he shall be brought unto the door of the tent of meeting;

**6:14** "'And he shall present his offering unto YHWH, one male lamb a year old without blemish for a burnt offering, and one ewe lamb a year old without blemish for a sin offering, and one ram without blemish for peace offerings,

**6:15** "'And a basket of unleavened bread, cakes of fine flour mixed with oil, and unleavened wafers anointed with oil, and their grain offering, and their drink offerings.

**6:16** "'And the priest shall present them before YHWH, and shall offer his sin offering, and his burnt offering.

**6:17** "'And he shall offer the ram for a sacrifice of peace offerings unto YHWH, with the basket of unleavened bread; the priest shall offer also its grain offering, and its drink offering.

**6:18** "'And the Nazirite shall shave the head of his separation at the door of the tent of meeting, and shall take the hair of the head of his separation, and put it on the fire which is under the sacrifice of peace offerings.

**6:19** "'And the priest shall take the boiled shoulder of the ram, and one unleavened cake out of the basket, and one unleavened wafer, and shall put them upon the hands of the Nazirite, after he has shaved his consecrated hair.

**6:20** "'And the priest shall wave them for a wave offering before YHWH; this is holy for the priest, together with the breast of the wave offering and the thigh of the contribution. And after that the Nazirite may drink wine.

**6:21** "'This is the law of the Nazirite who vows, and of his offering unto YHWH for his separation, besides that which he is able to afford; according to his vow which he vows, so he must do after the law of his separation.'"

---

**6:22** And YHWH spoke unto Moses, saying:

**6:23** "Speak unto Aaron and unto his sons, saying: 'Thus shall you bless the children of Israel; you shall say unto them:

**6:24** "'YHWH bless you, and keep you—יְבָרֶכְךָ יהוה וְיִשְׁמְרֶךָ (yevarechecha YHWH ve-yishmerecha);

**6:25** "'YHWH make his face shine upon you, and be gracious unto you—יָאֵר יהוה פָּנָיו אֵלֶיךָ וִיחֻנֶּךָּ (ya'er YHWH panav eleicha vi-chuneka);

**6:26** "'YHWH lift up his countenance upon you, and give you peace—יִשָּׂא יהוה פָּנָיו אֵלֶיךָ וְיָשֵׂם לְךָ שָׁלוֹם (yissa YHWH panav eleicha ve-yasem lecha shalom).'

**6:27** "So they shall put my name upon the children of Israel, and I will bless them."

---

## Synthesis Notes

**Key Restorations:**

**The Nazirite (נָזִיר, nazir):**
From the root נָזַר (nazar), "to separate, consecrate." The Nazirite vow is a voluntary act of special dedication to YHWH—available to both men and women.

**The Three Restrictions:**

1. **No grape products** (6:3-4): Wine, vinegar, juice, fresh or dried grapes, seeds, skins—total abstinence from the vine

2. **No cutting hair** (6:5): The hair grows as a visible sign of consecration; it is "holy unto YHWH"

3. **No contact with the dead** (6:6-7): Even for closest family (father, mother, brother, sister)—stricter than for ordinary priests (who may mourn immediate family)

**The Rationale:**
Wine represents celebration and normal social life; abstaining separates the Nazirite from ordinary society. The growing hair is a visible symbol of the vow's duration. Corpse avoidance preserves maximum purity.

**Accidental Defilement (6:9-12):**
If someone dies suddenly near the Nazirite:
- The consecrated head is defiled
- Day 7: shave the head
- Day 8: bring two birds (sin offering + burnt offering)
- Bring a guilt offering (male lamb)
- The previous days are void—the count restarts

The severity: accidental defilement cancels all accumulated time. The vow must be restarted.

**Completion of the Vow (6:13-21):**
When the vow period ends:
- Burnt offering (male lamb)
- Sin offering (female lamb)
- Peace offering (ram)
- Basket of unleavened bread
- Grain and drink offerings

Then:
- Shave the head at the tent of meeting
- Put the hair on the fire under the peace offering
- Priest waves the shoulder, cake, and wafer
- The Nazirite may now drink wine

**The Hair Burned:**
The consecrated hair—the visible symbol of the vow—is burned with the peace offering. The dedication is consummated; the sign is offered to YHWH.

**Famous Nazirites:**
- Samson (Judges 13:5)—lifelong, from the womb
- Samuel (1 Samuel 1:11)—dedicated by Hannah
- John the Baptist (Luke 1:15)—possibly
- Paul took a Nazirite vow (Acts 18:18, 21:23-26)

**The Priestly Blessing (6:24-26):**

Three lines, ascending in length (3 words, 5 words, 7 words in Hebrew):

1. **"YHWH bless you and keep you"**
   - *Yevarechecha*: may he bless you (prosperity, favor)
   - *Yishmerecha*: may he keep/guard you (protection)

2. **"YHWH make his face shine upon you and be gracious to you"**
   - *Ya'er panav*: may his face shine (radiant favor)
   - *Vichuneka*: may he be gracious (undeserved kindness)

3. **"YHWH lift up his countenance upon you and give you peace"**
   - *Yissa panav*: may he lift his face (attentive presence)
   - *Yasem lecha shalom*: may he give you peace (complete well-being)

**"Put My Name Upon Them":**
The blessing places YHWH's name on Israel. The Name confers identity and protection. The blessing is not priestly magic but YHWH's own action: "I will bless them."

**Archetypal Layer:** The Nazirite represents **voluntary, intensified holiness**—a layperson taking on priestly-level restrictions. The three abstentions (wine, hair-cutting, corpse contact) create separation from ordinary life.

The priestly blessing is the **spoken conferral of divine favor**—words that effect what they declare. The three-fold structure (blessing/keeping, shining/grace, lifting/peace) moves from material protection through relational favor to ultimate wholeness (*shalom*).

**Psychological Reading:** The Nazirite vow provides a structure for deep dedication. The visible sign (uncut hair) makes the commitment public and accountable. The time-limited nature (vs. lifelong) makes the intensity sustainable.

The priestly blessing is spoken regularly over the congregation. Hearing the words—especially with YHWH's name—shapes identity and expectation.

**Ethical Inversion Applied:**
- The Nazirite vow is voluntary—intensified holiness by choice
- Available to women as well as men—"man or woman"
- Abstention from the vine—separation from normal social celebration
- The hair is the "crown"—holiness made visible
- The blessing is YHWH's action—the priest is the channel, not the source

**Modern Equivalent:** Periods of intensified discipline (fasting, retreats, abstention) continue. The visible sign (uncut hair) anticipated later religious practices (monks' tonsures, Sikhs' uncut hair). And the Aaronic blessing remains in use—spoken in Jewish and Christian liturgy worldwide.

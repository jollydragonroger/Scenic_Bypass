# Numbers Chapter 35: Levitical Cities and Cities of Refuge

*From the Hebrew: עָרֵי מִקְלָט (Arei Miqlat) — Cities of Refuge*

---

**35:1** And YHWH spoke unto Moses in the plains of Moab by the Jordan at Jericho, saying:

**35:2** "Command the children of Israel, that they give unto the Levites of the inheritance of their possession cities to dwell in; and open land round about the cities shall you give unto the Levites.

**35:3** "And the cities shall they have to dwell in; and their open land shall be for their cattle, and for their substance, and for all their beasts.

**35:4** "And the open land about the cities, which you shall give unto the Levites, shall be from the wall of the city and outward a thousand cubits round about.

**35:5** "And you shall measure outside the city for the east side two thousand cubits, and for the south side two thousand cubits, and for the west side two thousand cubits, and for the north side two thousand cubits, the city being in the midst. This shall be to them the open land about the cities.

**35:6** "And the cities which you shall give unto the Levites, they shall be the six cities of refuge, which you shall give for the manslayer to flee unto; and besides them you shall give forty-two cities.

**35:7** "All the cities which you shall give to the Levites shall be forty-eight cities: them shall you give with their open land.

**35:8** "And concerning the cities which you shall give of the possession of the children of Israel, from the many you shall take many, and from the few you shall take few; each tribe according to its inheritance which it inherits shall give of its cities unto the Levites."

---

**35:9** And YHWH spoke unto Moses, saying:

**35:10** "Speak unto the children of Israel, and say unto them: 'When you pass over the Jordan into the land of Canaan,

**35:11** "'Then you shall appoint yourselves cities to be cities of refuge for you, that the manslayer who kills any person unwittingly may flee there.

**35:12** "'And the cities shall be unto you for refuge from the avenger—גֹּאֵל (go'el)—that the manslayer not die, until he stands before the congregation for judgment.

**35:13** "'And the cities which you shall give shall be for you six cities of refuge.

**35:14** "'Three cities shall you give beyond the Jordan, and three cities shall you give in the land of Canaan; they shall be cities of refuge.

**35:15** "'For the children of Israel, and for the stranger and for the settler among them, shall these six cities be for refuge, that everyone who kills any person unwittingly may flee there.

---

**35:16** "'But if he smote him with an instrument of iron, so that he died, he is a murderer; the murderer shall surely be put to death.

**35:17** "'And if he smote him with a stone in the hand, by which a man may die, and he died, he is a murderer; the murderer shall surely be put to death.

**35:18** "'Or if he smote him with a weapon of wood in the hand, by which a man may die, and he died, he is a murderer; the murderer shall surely be put to death.

**35:19** "'The avenger of blood—גֹּאֵל הַדָּם (go'el ha-dam)—shall himself put the murderer to death; when he meets him, he shall put him to death.

**35:20** "'And if he thrust at him in hatred, or hurled at him by lying in wait, so that he died,

**35:21** "'Or in enmity smote him with his hand, and he died, he who smote him shall surely be put to death; he is a murderer; the avenger of blood shall put the murderer to death when he meets him.

---

**35:22** "'But if he thrust him suddenly without enmity, or hurled upon him anything without lying in wait,

**35:23** "'Or with any stone, by which a man may die, seeing him not, and cast it upon him so that he died, and he was not his enemy, neither sought his harm,

**35:24** "'Then the congregation shall judge between the smiter and the avenger of blood according to these ordinances.

**35:25** "'And the congregation shall deliver the manslayer out of the hand of the avenger of blood, and the congregation shall restore him to his city of refuge, where he had fled; and he shall dwell therein until the death of the high priest, who was anointed with the holy oil.

**35:26** "'But if the manslayer shall at any time go beyond the border of his city of refuge, where he flees,

**35:27** "'And the avenger of blood finds him outside the border of his city of refuge, and the avenger of blood kills the manslayer, there shall be no bloodguilt for him.

**35:28** "'Because he should have remained in his city of refuge until the death of the high priest; but after the death of the high priest the manslayer may return into the land of his possession.

**35:29** "'And these things shall be for a statute of judgment unto you throughout your generations in all your dwellings.

---

**35:30** "'Whoever kills any person, the murderer shall be put to death by the mouth of witnesses; but one witness shall not testify against any person that he die.

**35:31** "'Moreover you shall take no ransom for the life of a murderer, who is guilty of death; but he shall surely be put to death.

**35:32** "'And you shall take no ransom for him who has fled to his city of refuge, that he should come again to dwell in the land, until the death of the priest.

**35:33** "'So you shall not pollute the land wherein you are; for blood pollutes the land; and no expiation can be made for the land for the blood that is shed therein, but by the blood of him who shed it.

**35:34** "'And you shall not defile the land which you inhabit, in the midst of which I dwell; for I YHWH dwell in the midst of the children of Israel.'"

---

## Synthesis Notes

**Key Restorations:**

**Levitical Cities:**
The Levites receive no tribal territory, but they receive cities distributed throughout all tribes:
- 48 cities total
- Each with surrounding pastureland (1,000-2,000 cubits)
- Proportional from each tribe (more from larger tribes)

This distributes the Levites throughout the land—they are not concentrated but scattered as religious teachers and examples.

**Cities of Refuge (עָרֵי מִקְלָט):**
Six of the 48 Levitical cities are designated as refuge cities:
- 3 east of the Jordan
- 3 west of the Jordan
- Open to Israelites, strangers, and settlers

**The Problem Addressed:**
In ancient societies, the *go'el ha-dam* (blood avenger/redeemer) had the right and duty to kill anyone who killed a relative. But not all killing is murder. The refuge cities provide a place for the unintentional killer to flee before the avenger reaches him.

**Murder vs. Manslaughter:**

**Murder (intentional):**
- Killing with iron, stone, or wooden weapon
- Killing from hatred
- Killing by lying in wait
- Killing in enmity

Penalty: Death. The *go'el ha-dam* executes the murderer. No ransom can substitute.

**Manslaughter (unintentional):**
- Sudden act without enmity
- No lying in wait
- No prior hatred
- Accidental (stone falls, seeing him not)

The congregation judges between the killer and the avenger. If manslaughter, the killer is returned to the refuge city.

**The Exile:**
The accidental killer must remain in the refuge city until the high priest's death. If he leaves before then and the avenger finds him, the avenger may kill him without guilt.

**"Until the Death of the High Priest":**
The high priest's death creates a general release—perhaps atoning for the bloodshed, perhaps marking a new era. After the priest dies, the manslayer may return home.

**No Ransom:**
For murder: no amount of money can substitute for the death penalty.
For manslaughter: no payment can shorten the refuge exile.

**Witnesses:**
Capital punishment requires at least two witnesses. One witness is insufficient for a death sentence.

**Land Pollution:**
"Blood pollutes the land"—the theological reason underlying these laws. Unpunished murder contaminates the land where YHWH dwells. Only the murderer's blood cleanses the land.

**Archetypal Layer:** The cities of refuge create **graduated justice**—distinguishing intentional murder from accidental killing. The system prevents both blood feud escalation (by protecting the accidental killer) and murder going unpunished (by denying refuge to the intentional killer).

The high priest's death as release suggests **vicarious atonement**—his death somehow covers the manslayer's bloodguilt.

**Psychological Reading:** The exile to refuge cities creates consequences without death. The accidental killer loses home, property, and freedom—significant penalty—but not life. The structure acknowledges that unintentional killing is still killing, even if not murder.

**Ethical Inversion Applied:**
- Levites scattered throughout—religious presence everywhere
- Refuge protects from immediate vengeance—justice, not blood feud
- Congregation judges—community determines intent
- No ransom for murder—life cannot be bought
- Land pollution requires blood—unpunished murder defiles
- High priest's death releases—vicarious atonement

**Modern Equivalent:** The distinction between murder and manslaughter remains foundational to criminal law. The refuge principle (protection pending trial) anticipates bail and protective custody. And the requirement of multiple witnesses for capital cases establishes evidentiary standards.

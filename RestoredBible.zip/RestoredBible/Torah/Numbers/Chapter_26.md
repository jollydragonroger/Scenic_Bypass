# Numbers Chapter 26: The Second Census

*From the Hebrew: פְּקֻדֵּיהֶם (Pequdeihem) — Those Numbered*

---

**26:1** And it came to pass after the plague, that YHWH spoke unto Moses and unto Eleazar the son of Aaron the priest, saying:

**26:2** "Take the census of all the congregation of the children of Israel, from twenty years old and upward, by their fathers' houses, all who are able to go forth to war in Israel."

**26:3** And Moses and Eleazar the priest spoke with them in the plains of Moab by the Jordan at Jericho, saying:

**26:4** "[Take the census of the people] from twenty years old and upward, as YHWH commanded Moses." And these are the children of Israel, who came forth out of the land of Egypt:

---

**26:5** Reuben, the firstborn of Israel: the sons of Reuben: of Hanoch, the family of the Hanochites; of Pallu, the family of the Palluites;

**26:6** Of Hezron, the family of the Hezronites; of Carmi, the family of the Carmites.

**26:7** These are the families of the Reubenites; and those who were numbered of them were forty-three thousand seven hundred and thirty.

**26:8** And the sons of Pallu: Eliab.

**26:9** And the sons of Eliab: Nemuel, and Dathan, and Abiram. These are that Dathan and Abiram, who were called of the congregation, who strove against Moses and against Aaron in the company of Korah, when they strove against YHWH;

**26:10** And the earth opened her mouth and swallowed them up together with Korah, when that company died; what time the fire devoured two hundred and fifty men, and they became a sign.

**26:11** Notwithstanding, the sons of Korah did not die.

---

**26:12-51** [The census continues through all the tribes:]

| Tribe | Count | Change from First Census |
|-------|-------|--------------------------|
| Reuben | 43,730 | -2,770 |
| Simeon | 22,200 | -37,100 |
| Gad | 40,500 | -5,150 |
| Judah | 76,500 | +1,900 |
| Issachar | 64,300 | +9,900 |
| Zebulun | 60,500 | +3,100 |
| Manasseh | 52,700 | +20,500 |
| Ephraim | 32,500 | -8,000 |
| Benjamin | 45,600 | +10,200 |
| Dan | 64,400 | +1,700 |
| Asher | 53,400 | +11,900 |
| Naphtali | 45,400 | -8,000 |

**26:51** These are those who were numbered of the children of Israel: six hundred and one thousand seven hundred and thirty.

---

**26:52** And YHWH spoke unto Moses, saying:

**26:53** "Unto these the land shall be divided for an inheritance according to the number of names.

**26:54** "To the more you shall give the more inheritance, and to the fewer you shall give the less inheritance; to each one according to those who were numbered of him shall his inheritance be given.

**26:55** "Notwithstanding, the land shall be divided by lot; according to the names of the tribes of their fathers they shall inherit.

**26:56** "According to the lot shall their inheritance be divided between the more and the fewer."

---

**26:57** And these are those who were numbered of the Levites by their families: of Gershon, the family of the Gershonites; of Kohath, the family of the Kohathites; of Merari, the family of the Merarites.

**26:58** These are the families of Levi: the family of the Libnites, the family of the Hebronites, the family of the Mahlites, the family of the Mushites, the family of the Korahites. And Kohath begat Amram.

**26:59** And the name of Amram's wife was Jochebed, the daughter of Levi, who was born to Levi in Egypt; and she bore unto Amram Aaron and Moses, and Miriam their sister.

**26:60** And unto Aaron were born Nadab and Abihu, Eleazar and Ithamar.

**26:61** And Nadab and Abihu died, when they offered strange fire before YHWH.

**26:62** And those who were numbered of them were twenty-three thousand, every male from a month old and upward; for they were not numbered among the children of Israel, because there was no inheritance given them among the children of Israel.

---

**26:63** These are those who were numbered by Moses and Eleazar the priest, who numbered the children of Israel in the plains of Moab by the Jordan at Jericho.

**26:64** But among these there was not a man of those who were numbered by Moses and Aaron the priest, when they numbered the children of Israel in the wilderness of Sinai.

**26:65** For YHWH had said of them: "They shall surely die in the wilderness." And there was not left a man of them, save Caleb the son of Jephunneh, and Joshua the son of Nun.

---

## Synthesis Notes

**Key Restorations:**

**After the Plague:**
The second census follows the plague at Peor (24,000 dead). The first generation has died; a new generation must be counted for the conquest.

**Eleazar Replaces Aaron:**
Aaron has died (chapter 20). Eleazar now assists Moses. The leadership transition is underway.

**Purpose:**
1. Military readiness: counting those able to go to war
2. Land distribution: proportional allocation by tribe

**The Numbers:**

First census (Numbers 1): 603,550
Second census: 601,730
Net change: -1,820

Despite plagues, rebellions, and 40 years of wilderness, the population is essentially stable.

**Dramatic Changes:**
- **Simeon**: 59,300 → 22,200 (down 37,100—63% loss). The Simeonites may have been particularly affected by the Peor plague; Zimri was a Simeonite prince.
- **Manasseh**: 32,200 → 52,700 (up 20,500—64% gain)

**"The Sons of Korah Did Not Die":**
A notable parenthetical. Though Korah perished, his descendants survived. The Korahites become temple singers—Psalms 42, 44-49, 84-85, 87-88 are attributed to them. Destruction of the father did not end the line.

**Dathan and Abiram Remembered:**
The census of Reuben notes that these were the rebels "who strove against Moses and against Aaron." Their judgment is memorialized within the genealogy.

**Land Distribution:**
- Larger tribes get larger portions
- Smaller tribes get smaller portions
- Distribution by lot (divine selection)
- By tribe names (ancestral allocation)

The lot and the size both factor in—chance and proportion combined.

**The Levites:**
Counted separately (23,000 males from one month old)—an increase of 1,000 from the first census (22,000). They receive no land inheritance.

**Jochebed Named:**
The mother of Moses, Aaron, and Miriam is identified: Jochebed, daughter of Levi, born in Egypt. She married Amram (her nephew). This is the only Torah mention of her name.

**The Verdict:**
"There was not a man of those who were numbered by Moses and Aaron the priest... save Caleb the son of Jephunneh, and Joshua the son of Nun."

The entire first generation has died—as YHWH decreed in chapter 14. Only the two faithful spies survive. The 40-year sentence is complete.

**Archetypal Layer:** The second census represents **generational transition**. The generation that refused the land is gone; the generation that will inherit is now counted. The number is similar, but the people are different.

The survival of Korah's sons despite Korah's destruction shows that **judgment on parents doesn't inevitably destroy children**. The next generation has its own destiny.

**Psychological Reading:** The detailed listing of every family establishes identity and belonging for the new generation. They are not anonymous; each clan is named and counted. This creates corporate identity for conquest.

**Ethical Inversion Applied:**
- The rebellious generation is gone—judgment is complete
- Caleb and Joshua remain—faithfulness is rewarded
- Korah's sons survive—parental sin doesn't automatically condemn children
- Land is proportional—larger tribes, larger allotments
- The lot determines location—divine guidance in distribution

**Modern Equivalent:** Organizations taking stock after crisis often find similar total numbers but different composition. Generational transition brings new people to existing positions. And the principle that children can transcend parental failures offers hope across generations.

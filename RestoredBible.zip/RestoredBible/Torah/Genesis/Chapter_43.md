# Genesis Chapter 43: The Second Journey with Benjamin

*From the Hebrew: Judah's Guarantee*

---

**43:1** And the famine was severe in the land.

**43:2** And it came to pass, when they had eaten up the grain which they had brought from Egypt, that their father said unto them: "Go again, buy us a little food."

**43:3** And Judah spoke unto him, saying: "The man solemnly warned us—הָעֵד הֵעִד (ha'ed he'id)—saying, 'You shall not see my face unless your brother is with you.'

**43:4** "If you will send our brother with us, we will go down and buy you food.

**43:5** "But if you will not send him, we will not go down; for the man said unto us, 'You shall not see my face unless your brother is with you.'"

**43:6** And Israel said: "Why did you do evil unto me, to tell the man that you had another brother?"

**43:7** And they said: "The man asked directly about us and about our kindred, saying, 'Is your father yet alive? Have you another brother?' And we told him according to these words. Could we possibly know that he would say, 'Bring your brother down'?"

**43:8** And Judah said unto Israel his father: "Send the lad with me, and we will arise and go, that we may live and not die—both we and you and also our little ones.

**43:9** "I will be surety for him—אָנֹכִי אֶעֶרְבֶנּוּ (anochi e'ervenu); from my hand you shall require him. If I do not bring him unto you and set him before you, then I shall bear the blame—וְחָטָאתִי לְךָ (ve-chatati lecha)—to you all my days.

**43:10** "For if we had not delayed, surely by now we could have returned twice."

**43:11** And their father Israel said unto them: "If it must be so, then do this: take of the choice fruits of the land in your vessels—a little balm—צֳרִי (tsori)—and a little honey, spices and myrrh, pistachios and almonds.

**43:12** "And take double money in your hand; and the money that was returned in the mouth of your sacks carry back in your hand; perhaps it was an oversight—מִשְׁגֶּה (mishgeh).

**43:13** "And take your brother, and arise, go again unto the man.

**43:14** "And El Shaddai give you mercy—רַחֲמִים (rachamim)—before the man, that he may release to you your other brother and Benjamin. And as for me, if I am bereaved—שָׁכֹלְתִּי שָׁכָלְתִּי (shakholti shakhalti)—I am bereaved."

**43:15** And the men took that present, and double money they took in their hand, and Benjamin; and they rose up and went down to Egypt and stood before Joseph.

**43:16** And Joseph saw Benjamin with them, and he said to the one who was over his house: "Bring the men into the house, and slaughter an animal and prepare it, for the men shall eat with me at noon."

**43:17** And the man did as Joseph said, and the man brought the men into Joseph's house.

**43:18** And the men were afraid because they were brought into Joseph's house; and they said: "Because of the money that was returned in our sacks at the first we are brought in, that he may roll himself upon us—לְהִתְגֹּלֵל עָלֵינוּ (le-hitgolel aleinu)—and fall upon us, and take us for slaves and our donkeys."

**43:19** And they came near to the man who was over Joseph's house, and they spoke unto him at the door of the house,

**43:20** And said: "O my lord, we indeed came down at the first to buy food.

**43:21** "And it came to pass, when we came to the lodging place, that we opened our sacks, and behold, every man's money was in the mouth of his sack, our money in full weight; and we have brought it back in our hand.

**43:22** "And other money have we brought down in our hand to buy food. We do not know who put our money in our sacks."

**43:23** And he said: "Peace be unto you, fear not; your Consciousness and the Consciousness of your father has given you treasure in your sacks. Your money came to me." And he brought Simeon out unto them.

**43:24** And the man brought the men into Joseph's house, and gave them water, and they washed their feet; and he gave their donkeys fodder.

**43:25** And they prepared the present for Joseph's coming at noon; for they heard that they would eat bread there.

**43:26** And Joseph came into the house; and they brought him the present which was in their hand into the house, and bowed down to him to the earth.

**43:27** And he asked them of their welfare—שָׁלוֹם (shalom)—and said: "Is your father well—הֲשָׁלוֹם (ha-shalom)—the old man of whom you spoke? Is he yet alive?"

**43:28** And they said: "Your servant our father is well; he is yet alive." And they bowed and prostrated themselves.

**43:29** And he lifted up his eyes and saw Benjamin his brother, his mother's son, and said: "Is this your youngest brother, of whom you spoke unto me?" And he said: "God be gracious to you, my son—אֱלֹהִים יָחְנְךָ בְּנִי (Elohim yachnecha beni)."

**43:30** And Joseph hurried, for his compassion was kindled toward his brother—כִּי־נִכְמְרוּ רַחֲמָיו (ki-nichm'ru rachamav)—and he sought to weep; and he entered into the chamber and wept there.

**43:31** And he washed his face and came out; and he restrained himself—וַיִּתְאַפַּק (va-yit'appaq)—and said: "Serve bread."

**43:32** And they served him by himself, and them by themselves, and the Egyptians who ate with him by themselves; because the Egyptians could not eat bread with the Hebrews, for that is an abomination unto the Egyptians.

**43:33** And they sat before him, the firstborn according to his birthright—כִּבְכֹרָתוֹ (ki-vechorato)—and the youngest according to his youth; and the men looked at one another in astonishment.

**43:34** And he sent portions unto them from before him; and Benjamin's portion was five times as much as any of theirs—חָמֵשׁ יָדוֹת (chamesh yadot). And they drank and were merry with him.

---

## Synthesis Notes

**Key Restorations:**

**Judah Steps Forward:**
Where Reuben failed to persuade Jacob (42:37-38), Judah succeeds. His argument is practical and his guarantee personal:
- "I will be surety for him" (אֶעֶרְבֶנּוּ, e'ervenu)—the same root as "pledge" (עֵרָבוֹן) that Tamar demanded from him (38:17-18)
- "I shall bear the blame all my days"—permanent moral responsibility

This is the same Judah who proposed selling Joseph. He has transformed.

**Jacob's Resignation:**
"If I am bereaved, I am bereaved" (שָׁכֹלְתִּי שָׁכָלְתִּי)—the doubling expresses resignation. Jacob releases Benjamin because he must, not because he trusts the outcome. He prays to El Shaddai for mercy (*rachamim*—from the womb, maternal compassion).

**The Gifts:**
Jacob sends the products of Canaan that famine could not destroy—balm, honey, spices, myrrh, pistachios, almonds. These luxury goods are meant to appease "the man." The irony: these are the same trade goods the Ishmaelites carried when they bought Joseph (37:25).

**The Brothers' Fear:**
Being brought into Joseph's house terrifies them. They expect entrapment—to be enslaved for the "stolen" money. Guilty conscience interprets generosity as trap.

**The Steward's Reassurance:**
"Your Consciousness and the Consciousness of your father has given you treasure in your sacks." The steward—presumably instructed by Joseph—interprets the money return as divine gift, not error. This calms them.

**Simeon Released:**
Simeon, held hostage since the first visit, is returned. The family is nearly complete—only the disguised Joseph remains separated.

**Joseph Sees Benjamin:**
Benjamin is Joseph's only full brother—both sons of Rachel. Joseph's blessing ("God be gracious to you, my son") echoes the priestly blessing. He calls Benjamin "my son"—an intimate, perhaps unconscious, slip.

**Joseph Weeps Again:**
*Nichm'ru rachamav* (נִכְמְרוּ רַחֲמָיו)—"his compassion was kindled/stirred." The word for compassion is related to *rechem* (womb); it is visceral, maternal emotion. Joseph cannot contain himself and retreats to weep privately.

**"He Restrained Himself":**
*Va-yit'appaq* (וַיִּתְאַפַּק)—Joseph forces composure. He is not ready to reveal himself. The test must continue.

**Separate Tables:**
Three groups eat separately:
- Joseph (alone, as Egyptian lord)
- The brothers (Hebrews)
- Egyptian servants (who won't eat with Hebrews—"abomination" is ritual/cultural, not moral)

Joseph navigates between worlds—Hebrew by birth, Egyptian by position.

**The Seating Arrangement:**
The brothers are seated in birth order—"the firstborn according to his birthright, the youngest according to his youth." They are astonished. How could the Egyptian vizier know their birth order? This is uncanny but not yet revealing.

**Benjamin's Fivefold Portion:**
Joseph gives Benjamin five times more than the others. This tests whether the brothers will resent the favored son—as they resented Joseph. The test of jealousy.

**"They Drank and Were Merry":**
The Hebrew suggests they became intoxicated—*va-yishkeru* (וַיִּשְׁכְּרוּ). The tension releases into festivity. For the moment, all seems well.

**Archetypal Layer:** The meal at the ruler's table is the threshold of reconciliation—breaking bread, drinking together, being served by the one they wronged. But reconciliation is not complete; the cup has not yet been planted, the final test awaits.

**Psychological Reading:** Joseph cannot reveal himself without completing the test. He must know: have they changed? Will they abandon Benjamin as they abandoned him? The fivefold portion is the provocation—if jealousy rises, they are the same; if they rejoice with Benjamin, they have transformed.

**Ethical Inversion Applied:**
- Traditional reading celebrates Joseph's masterful testing
- **Restored reading**: Notes the brothers' terror and Joseph's manipulation
- They are genuinely afraid of enslavement—trauma response
- Joseph prolongs their anxiety even as he weeps for them
- The test may be necessary, but it is also painful
- Power dynamics shape how reconciliation proceeds

**Modern Equivalent:** Reconciliation often requires demonstration, not just words. Those who hurt us must show they have changed, not simply claim it. But testing others also involves power—the one testing controls the process. Joseph's tears show he is not unmoved; his restraint shows the work is not finished.

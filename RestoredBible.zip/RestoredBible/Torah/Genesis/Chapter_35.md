# Genesis Chapter 35: Return to Bethel

*From the Hebrew: Deaths and Renewals*

---

**35:1** And Consciousness said unto Jacob: "Arise, go up to Bethel and dwell there; and make there an altar unto the Consciousness who appeared unto you when you fled from the face of Esau your brother."

**35:2** And Jacob said unto his household and to all who were with him: "Put away the foreign gods—אֱלֹהֵי הַנֵּכָר (elohei ha-nechar)—that are among you, and purify yourselves, and change your garments.

**35:3** "And let us arise and go up to Bethel; and I will make there an altar unto the Consciousness who answered me in the day of my distress and was with me in the way which I went."

**35:4** And they gave unto Jacob all the foreign gods which were in their hand, and the rings which were in their ears; and Jacob buried them under the oak—הָאֵלָה (ha-elah)—which was by Shechem.

**35:5** And they journeyed; and the terror of Consciousness—חִתַּת אֱלֹהִים (chittat Elohim)—was upon the cities that were round about them, and they did not pursue after the sons of Jacob.

**35:6** And Jacob came to Luz, which is in the land of Canaan—that is, Bethel—he and all the people that were with him.

**35:7** And he built there an altar and called the place El-Bethel—אֵל בֵּית־אֵל (El Beit-El), "God of the House of God"—because there Consciousness was revealed unto him when he fled from the face of his brother.

**35:8** And Deborah, Rebekah's nurse, died, and she was buried below Bethel under the oak; and the name of it was called Allon-bacuth—אַלּוֹן בָּכוּת (Allon Bakut), "Oak of Weeping."

**35:9** And Consciousness appeared unto Jacob again when he came from Paddan-aram, and blessed him.

**35:10** And Consciousness said unto him: "Your name is Jacob; your name shall no longer be called Jacob, but Israel shall be your name." And Consciousness called his name Israel.

**35:11** And Consciousness said unto him: "I am El Shaddai; be fruitful and multiply. A nation and a congregation of nations—גּוֹי וּקְהַל גּוֹיִם (goy u-qehal goyim)—shall be from you, and kings shall come out of your loins.

**35:12** "And the land which I gave to Abraham and to Isaac, to you I will give it; and to your seed after you I will give the land."

**35:13** And Consciousness went up from him in the place where Consciousness had spoken with him.

**35:14** And Jacob set up a pillar in the place where Consciousness had spoken with him, a pillar of stone; and he poured out a drink offering upon it, and poured oil upon it.

**35:15** And Jacob called the name of the place where Consciousness had spoken with him, Bethel.

---

**35:16** And they journeyed from Bethel; and there was still some distance to come to Ephrath; and Rachel travailed, and she had hard labor.

**35:17** And it came to pass, when she was in hard labor, that the midwife said unto her: "Fear not, for this also is a son for you."

**35:18** And it came to pass, as her soul was departing—for she died—that she called his name Ben-oni—בֶּן־אוֹנִי (Ben-Oni), "Son of My Sorrow"; but his father called him Benjamin—בִּנְיָמִין (Binyamin), "Son of the Right Hand."

**35:19** And Rachel died and was buried on the way to Ephrath, which is Bethlehem.

**35:20** And Jacob set up a pillar upon her grave; it is the pillar of Rachel's grave unto this day.

**35:21** And Israel journeyed and pitched his tent beyond Migdal-eder—מִגְדַּל־עֵדֶר (Migdal Eder), "Tower of the Flock."

**35:22** And it came to pass, while Israel dwelt in that land, that Reuben went and lay with Bilhah his father's concubine; and Israel heard of it.

---

Now the sons of Jacob were twelve:

**35:23** The sons of Leah: Reuben, Jacob's firstborn, and Simeon, and Levi, and Judah, and Issachar, and Zebulun.

**35:24** The sons of Rachel: Joseph and Benjamin.

**35:25** And the sons of Bilhah, Rachel's maidservant: Dan and Naphtali.

**35:26** And the sons of Zilpah, Leah's maidservant: Gad and Asher. These are the sons of Jacob who were born to him in Paddan-aram.

**35:27** And Jacob came unto Isaac his father to Mamre, to Kiriath-arba, which is Hebron, where Abraham and Isaac had sojourned.

**35:28** And the days of Isaac were one hundred and eighty years.

**35:29** And Isaac expired and died, and was gathered unto his people, old and full of days; and Esau and Jacob his sons buried him.

---

## Synthesis Notes

**Key Restorations:**

**The Return to Bethel:**
Consciousness commands Jacob to return to Bethel—the place of the ladder dream and vow (Chapter 28). The journey becomes pilgrimage; the vow must be fulfilled.

**The Purification:**
Before going to Bethel, Jacob requires his household to:
- Put away foreign gods (including Rachel's stolen teraphim?)
- Purify themselves
- Change garments

This is the first household reformation—a cleansing before sacred encounter. The gods and earrings (perhaps amulets) are buried under an oak at Shechem, the site of recent violence. The old is interred.

**The Terror of Consciousness:**
*Chittat Elohim* (חִתַּת אֱלֹהִים)—divine terror falls on surrounding cities so they don't attack despite the Shechem massacre. This is neither endorsement nor condemnation of the violence—it is protection for the journey.

**El-Bethel:**
"God of the House of God"—the altar name acknowledges that God was revealed there. This is the fulfillment of the Bethel vow.

**Deborah's Death:**
Rebekah's nurse—a figure never mentioned before—dies and is mourned. The "Oak of Weeping" suggests deep grief. This is the only mention of Deborah; we never learn when she joined Jacob's household. Some suggest this symbolizes news of Rebekah's death (which is never recorded).

**The Second Naming:**
Jacob is renamed Israel *again* (first at Peniel, 32:28). Some scholars see different source traditions; others see confirmation and completion. The Bethel renaming confirms what the wrestling initiated.

**The Promise Renewed:**
El Shaddai (the patriarchal divine name) repeats the Abrahamic promises:
- Be fruitful and multiply
- Nation and congregation of nations
- Kings from your loins
- The land given to Abraham and Isaac, now to you

**Rachel's Death:**
The beloved wife dies in childbirth. Her final act is naming her son *Ben-Oni*—"Son of My Sorrow" or "Son of My Vigor" (אוֹן can mean either strength or sorrow). Jacob changes it to *Binyamin*—"Son of the Right Hand" (the favored hand, the place of honor).

Rachel, who once cried "Give me children or I die!" (30:1), dies giving birth. The irony is tragic. She is buried not in the family tomb at Machpelah but on the road, and Jacob marks the spot with a pillar.

**Reuben's Transgression:**
In a single verse without elaboration, Reuben sleeps with Bilhah, his father's concubine. "And Israel heard of it." The Hebrew stops abruptly—no recorded response. But Jacob remembers: on his deathbed, he will strip Reuben of firstborn rights for this (49:3-4).

**The Twelve Sons Listed:**
The tribal list is complete: six from Leah, two from Rachel, two from Bilhah, two from Zilpah. The nation-to-be is named.

**Isaac's Death:**
Isaac dies at 180, old and full of days. Esau and Jacob bury him together—as they did with Abraham. The reconciliation holds at least for burial.

**Archetypal Layer:** This chapter is a sequence of deaths and renewals:
- Death of foreign gods (buried)
- Death of Deborah (mourned)
- Death of the old name (Jacob → Israel confirmed)
- Death of Rachel (lamented)
- Death of Reuben's standing (through transgression)
- Death of Isaac (completed)

Between deaths: new altars, new promise, new son (Benjamin). The pattern is death-and-renewal throughout.

**Psychological Reading:** Return to Bethel is return to the site of original transformation. The purification required before that return suggests we cannot re-enter sacred space carrying the accumulations of our wandering. Foreign gods must be buried—the false objects of devotion released.

**Ethical Inversion Applied:**
- Rachel's death in childbirth follows Jacob's unknowing curse (31:32: "With whomever you find your gods, that one shall not live")
- The text doesn't make the connection explicit, but the tradition does
- The beloved, who stole the gods, dies
- Reuben's violation goes unremarked in narrative but not forgotten

**Modern Equivalent:** Returning to places of original encounter requires preparation—what have we accumulated that must be put away? The deaths of those we love mark our journeys. And the things we say ("that one shall not live") may have consequences we never intended.

# Genesis Chapter 7: The Waters of Dissolution

*From the Hebrew: The Mabbul Descends*

---

**7:1** And YHWH said unto Noah: "Come, you and all your household, into the ark; for you I have seen as righteous before me in this generation.

**7:2** "From all the clean beasts you shall take for yourself seven pairs, male and female; and from the beasts that are not clean, two, male and female.

**7:3** "Also of the winged beings of the sky, seven pairs, male and female, to keep seed alive upon the face of all the earth.

**7:4** "For in seven days I am causing rain upon the earth forty days and forty nights; and I will wipe away every living substance that I have made from upon the face of the ground."

**7:5** And Noah did according to all that YHWH commanded him.

**7:6** And Noah was six hundred years old when the flood of waters was upon the earth.

**7:7** And Noah went in, and his sons, and his partner, and his sons' partners with him, into the ark, from before the waters of the flood.

**7:8** Of the clean beasts, and of the beasts that are not clean, and of the winged beings, and of everything that creeps upon the ground,

**7:9** Two by two they came unto Noah into the ark, male and female, as Consciousness had commanded Noah.

**7:10** And it came to pass after seven days that the waters of the flood were upon the earth.

**7:11** In the six hundredth year of Noah's life, in the second month, on the seventeenth day of the month, on that day all the fountains of the great deep—תְּהוֹם רַבָּה (tehom rabbah)—burst open, and the windows of the sky—אֲרֻבֹּת הַשָּׁמַיִם (arubot ha-shamayim)—were opened.

**7:12** And the rain was upon the earth forty days and forty nights.

**7:13** On that very day Noah entered, and Shem and Ham and Japheth the sons of Noah, and Noah's partner, and the three partners of his sons with them, into the ark—

**7:14** They, and every living being according to its kind, and every beast according to its kind, and every creeping thing that creeps upon the earth according to its kind, and every winged being according to its kind, every bird of every wing.

**7:15** And they came unto Noah into the ark, two by two of all flesh in which is the breath of life.

**7:16** And those that entered, male and female of all flesh, went in as Consciousness had commanded him; and YHWH closed the door behind him.

**7:17** And the flood was forty days upon the earth; and the waters increased and lifted up the ark, and it rose above the earth.

**7:18** And the waters prevailed and increased greatly upon the earth; and the ark moved upon the face of the waters.

**7:19** And the waters prevailed exceedingly upon the earth; and all the high mountains under all the sky were covered.

**7:20** Fifteen cubits upward the waters prevailed; and the mountains were covered.

**7:21** And all flesh that moved upon the earth expired—וַיִּגְוַע (va-yigva)—winged beings and beasts and living creatures and every swarming thing that swarms upon the earth, and all humanity.

**7:22** All in whose nostrils was the breath of the spirit of life, of all that was on dry land, died.

**7:23** And every living substance was wiped away that was upon the face of the ground—from human to beast to creeping thing to winged being of the sky; and they were wiped away from the earth; and only Noah remained, and those with him in the ark.

**7:24** And the waters prevailed upon the earth one hundred and fifty days.

---

## Synthesis Notes

**Key Restorations:**

- *Tehom rabbah* (תְּהוֹם רַבָּה): "The great deep"—the same *tehom* from Genesis 1:2, the primordial waters over which creative consciousness moved. The Flood is not merely rain but the eruption of the cosmic deep—the return of pre-creation chaos.

- *Arubot ha-shamayim* (אֲרֻבֹּת הַשָּׁמַיִם): "Windows of the sky"—the membrane (firmament) that separated the waters above from the waters below (Genesis 1:6-7) is breached. Creation's structure temporarily collapses.

- **Forty days and forty nights**: Forty is the number of transformation, testing, and transition throughout Scripture (Moses on Sinai, Israel in wilderness, Jesus in desert). The dissolution is a transformative passage.

- **YHWH closed the door**: Consciousness itself seals the ark. This is not Noah's achievement but divine action completing the protection.

- *Va-yigva* (וַיִּגְוַע): "Expired"—a term for the departure of breath/spirit, used for significant deaths (Abraham, Isaac, Ishmael). All flesh outside the ark undergoes this expiration.

- **One hundred and fifty days**: The waters prevail for 150 days—marking the completion of the dissolution phase before the restoration begins.

**Archetypal Layer:** The Flood is the universal myth of dissolution—the undoing of cosmic order so that a purified order may emerge. The waters above and below reunite, dissolving the membrane of differentiation. What survives is only what is contained within the vessel of conscious intention (the ark).

**Psychological Reading:** Psychological dissolution—the flooding of the ego by unconscious contents—is terrifying and necessary when the old structures have become corrupt. The "ark" is the therapeutic container, the stable witnessing awareness, the core self that can hold paired opposites (every kind, male and female) while the flood passes.

**Water Symbolism (from key):** *Water/Flood* = Collective unconscious, renewal, emotional overflow. The mabbul is the overwhelming return of repressed collective content—both destructive and ultimately renewing.

**Ecological Reading:** The planet's systems have thresholds. When violence and corruption exceed carrying capacity, the system resets. This is not punishment but consequence—the earth's own self-regulation through catastrophe.

**Modern Equivalent:** The "forty days" of dissolution represent any period of necessary breakdown—personal crisis, societal collapse, ecological reset. The question is not whether dissolution comes but whether we have built arks capable of carrying essential life through the waters.

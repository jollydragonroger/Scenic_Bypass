# Genesis Chapter 36: The Generations of Esau

*From the Hebrew: תּוֹלְדוֹת עֵשָׂו (Toledot Esav) — Edom's Origin*

---

**36:1** And these are the generations of Esau, who is Edom.

**36:2** Esau took his wives from the daughters of Canaan: Adah the daughter of Elon the Hittite, and Oholibamah the daughter of Anah, the daughter of Zibeon the Hivite,

**36:3** And Basemath, Ishmael's daughter, sister of Nebaioth.

**36:4** And Adah bore to Esau Eliphaz; and Basemath bore Reuel.

**36:5** And Oholibamah bore Jeush and Jalam and Korah. These are the sons of Esau who were born to him in the land of Canaan.

**36:6** And Esau took his wives and his sons and his daughters and all the souls of his house, and his livestock and all his beasts and all his possessions which he had acquired in the land of Canaan, and went into a land away from his brother Jacob.

**36:7** For their possessions were too great for them to dwell together; and the land of their sojournings could not bear them because of their livestock.

**36:8** And Esau dwelt in the hill country of Seir; Esau, he is Edom.

**36:9** And these are the generations of Esau, the father of Edom, in the hill country of Seir.

**36:10** These are the names of Esau's sons: Eliphaz the son of Adah the wife of Esau; Reuel the son of Basemath the wife of Esau.

**36:11** And the sons of Eliphaz were Teman, Omar, Zepho, Gatam, and Kenaz.

**36:12** And Timna was concubine to Eliphaz, Esau's son; and she bore to Eliphaz Amalek. These are the sons of Adah, Esau's wife.

**36:13** And these are the sons of Reuel: Nahath and Zerah, Shammah and Mizzah. These were the sons of Basemath, Esau's wife.

**36:14** And these were the sons of Oholibamah the daughter of Anah, the daughter of Zibeon, Esau's wife; and she bore to Esau Jeush and Jalam and Korah.

**36:15** These are the chiefs—אַלּוּפֵי (allufei)—of the sons of Esau. The sons of Eliphaz, the firstborn of Esau: chief Teman, chief Omar, chief Zepho, chief Kenaz,

**36:16** Chief Korah, chief Gatam, chief Amalek. These are the chiefs of Eliphaz in the land of Edom; these are the sons of Adah.

**36:17** And these are the sons of Reuel, Esau's son: chief Nahath, chief Zerah, chief Shammah, chief Mizzah. These are the chiefs of Reuel in the land of Edom; these are the sons of Basemath, Esau's wife.

**36:18** And these are the sons of Oholibamah, Esau's wife: chief Jeush, chief Jalam, chief Korah. These are the chiefs that came of Oholibamah the daughter of Anah, Esau's wife.

**36:19** These are the sons of Esau, and these are their chiefs; he is Edom.

---

**36:20** These are the sons of Seir the Horite, the inhabitants of the land: Lotan and Shobal and Zibeon and Anah,

**36:21** And Dishon and Ezer and Dishan. These are the chiefs of the Horites, the sons of Seir in the land of Edom.

**36:22** And the sons of Lotan were Hori and Hemam; and Lotan's sister was Timna.

**36:23** And these are the sons of Shobal: Alvan and Manahath and Ebal, Shepho and Onam.

**36:24** And these are the sons of Zibeon: Aiah and Anah—this is the Anah who found the hot springs—הַיֵּמִם (ha-yemim)—in the wilderness, as he pastured the donkeys of Zibeon his father.

**36:25** And these are the children of Anah: Dishon and Oholibamah the daughter of Anah.

**36:26** And these are the sons of Dishon: Hemdan and Eshban and Ithran and Cheran.

**36:27** These are the sons of Ezer: Bilhan and Zaavan and Akan.

**36:28** These are the sons of Dishan: Uz and Aran.

**36:29** These are the chiefs of the Horites: chief Lotan, chief Shobal, chief Zibeon, chief Anah,

**36:30** Chief Dishon, chief Ezer, chief Dishan. These are the chiefs of the Horites, according to their chiefs in the land of Seir.

---

**36:31** And these are the kings that reigned in the land of Edom, before any king reigned over the children of Israel.

**36:32** And Bela the son of Beor reigned in Edom; and the name of his city was Dinhabah.

**36:33** And Bela died, and Jobab the son of Zerah of Bozrah reigned in his place.

**36:34** And Jobab died, and Husham of the land of the Temanites reigned in his place.

**36:35** And Husham died, and Hadad the son of Bedad, who struck Midian in the field of Moab, reigned in his place; and the name of his city was Avith.

**36:36** And Hadad died, and Samlah of Masrekah reigned in his place.

**36:37** And Samlah died, and Shaul of Rehoboth-by-the-River reigned in his place.

**36:38** And Shaul died, and Baal-hanan the son of Achbor reigned in his place.

**36:39** And Baal-hanan the son of Achbor died, and Hadar reigned in his place; and the name of his city was Pau; and his wife's name was Mehetabel, the daughter of Matred, the daughter of Me-zahab.

**36:40** And these are the names of the chiefs of Esau, according to their families, according to their places, by their names: chief Timna, chief Alvah, chief Jetheth,

**36:41** Chief Oholibamah, chief Elah, chief Pinon,

**36:42** Chief Kenaz, chief Teman, chief Mibzar,

**36:43** Chief Magdiel, chief Iram. These are the chiefs of Edom, according to their habitations in the land of their possession. This is Esau, the father of Edom.

---

## Synthesis Notes

**Key Restorations:**

**Why This Chapter:**
Before the Joseph narrative begins (Chapter 37), the text provides a complete genealogy of Esau/Edom. The "rejected" brother is not erased but given a full accounting. His descendants, their chiefs, their kings, their territories—all are recorded.

**Esau = Edom:**
The identification is repeated (36:1, 8, 19, 43). Esau becomes the father of the Edomites, Israel's southeastern neighbors and frequent rivals. The relationship between the nations mirrors the brothers' relationship.

**The Separation:**
As with Abraham and Lot (Chapter 13), the land cannot support both brothers' wealth. Esau voluntarily moves to Seir, leaving Canaan to Jacob. The blessing-thief inherits the land; the dispossessed brother establishes elsewhere.

**The Horites:**
The indigenous population of Seir before Esau's arrival. The genealogy shows intermarriage between Esau's descendants and the Horites (e.g., Timna becomes a concubine; Oholibamah is of Horite descent). Edom absorbs and merges with the earlier inhabitants.

**Amalek:**
Notably, Amalek appears as a grandson of Esau (36:12). The Amalekites become Israel's perpetual enemy (Exodus 17:8-16; 1 Samuel 15). The seeds of future conflict are embedded in the genealogy.

**"Before Any King Reigned Over Israel":**
This phrase (36:31) is a later editorial note, written after Israel had kings (post-Saul/David). It indicates the text was compiled or edited long after the events described.

**Eight Kings of Edom:**
Unlike later Israelite monarchy, Edomite kingship was not dynastic—each king seems from a different family/city. This suggests elective or charismatic kingship, not hereditary succession.

**Names and Places:**
Many of these names appear elsewhere in biblical and ancient Near Eastern records:
- *Teman*: Associated with wisdom (Job's friend Eliphaz is a Temanite)
- *Bozrah*: Major Edomite city, appears in prophetic literature
- *Uz*: The land of Job (Job 1:1)

**Archetypal Layer:** The "rejected" line is given full genealogical dignity. Esau is not villainized but documented. His descendants establish territory, chiefs, and kings—a parallel development to Israel. The brothers go different directions but both generate nations.

**Ethical Inversion Applied:**
- Traditional reading subordinates Esau's line as the unchosen
- **Restored reading**: Esau's descendants are fully honored with detailed genealogy
- Edom develops kingship *before* Israel—not inferiority but different path
- The text records, does not dismiss

**Psychological Reading:** The shadow (Esau) is not destroyed but develops its own territory, its own structures, its own history. What we do not choose becomes something else, not nothing. The unwalked path generates its own descendants.

**Modern Equivalent:** Those who leave the main family line—those who go elsewhere, who don't inherit the central promise—still have their own genealogies, their own stories, their own kings. The "unchosen" build nations too.

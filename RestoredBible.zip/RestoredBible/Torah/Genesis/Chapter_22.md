# Genesis Chapter 22: The Binding of Isaac

*From the Hebrew: עֲקֵדַת יִצְחָק (Aqedat Yitschaq) — The Aqedah*

---

**22:1** And it came to pass after these things that Consciousness tested—נִסָּה (nissah)—Abraham, and said unto him: "Abraham!" And he said: "Here I am—הִנֵּנִי (hineni)."

**22:2** And Consciousness said: "Take now your son, your only son—יְחִידְךָ (yechidecha)—whom you love, Isaac, and go to the land of Moriah; and offer him there as a burnt offering upon one of the mountains which I will tell you."

**22:3** And Abraham rose early in the morning and saddled his donkey, and took two of his young men with him, and Isaac his son; and he split the wood for the burnt offering, and rose up and went unto the place of which Consciousness had told him.

**22:4** On the third day Abraham lifted up his eyes and saw the place from afar.

**22:5** And Abraham said unto his young men: "Stay here with the donkey, and I and the lad will go yonder; and we will worship, and we will return unto you."

**22:6** And Abraham took the wood of the burnt offering and laid it upon Isaac his son; and he took in his hand the fire and the knife; and the two of them went together—יַחְדָּו (yachdav).

**22:7** And Isaac spoke unto Abraham his father and said: "My father!" And he said: "Here I am, my son." And Isaac said: "Behold the fire and the wood, but where is the lamb for the burnt offering?"

**22:8** And Abraham said: "Consciousness will provide—יִרְאֶה (yir'eh)—for itself the lamb for the burnt offering, my son." And the two of them went together.

**22:9** And they came to the place of which Consciousness had told him; and Abraham built the altar there and arranged the wood, and bound—וַיַּעֲקֹד (va-ya'aqod)—Isaac his son and laid him on the altar upon the wood.

**22:10** And Abraham stretched forth his hand and took the knife to slaughter his son.

**22:11** And the messenger of YHWH called unto him from the heavens and said: "Abraham! Abraham!" And he said: "Here I am."

**22:12** And the messenger said: "Do not stretch forth your hand unto the lad, and do not do anything to him; for now I know that you are one who holds Consciousness in awe—יְרֵא אֱלֹהִים (yere Elohim)—and you have not withheld your son, your only son, from me."

**22:13** And Abraham lifted up his eyes and looked, and behold, behind him a ram caught in the thicket by its horns; and Abraham went and took the ram and offered it as a burnt offering in place of his son.

**22:14** And Abraham called the name of that place "YHWH Yir'eh"—יהוה יִרְאֶה (YHWH Yir'eh), "YHWH Will Provide" or "YHWH Will Be Seen"—as it is said to this day: "On the mountain of YHWH it shall be provided" or "On the mountain of YHWH He shall be seen."

**22:15** And the messenger of YHWH called unto Abraham a second time from the heavens,

**22:16** And said: "By myself I have sworn—נִשְׁבַּעְתִּי (nishba'ti)—declares YHWH—because you have done this thing and have not withheld your son, your only son,

**22:17** "That I will surely bless you, and I will surely multiply your seed as the stars of the heavens and as the sand which is upon the seashore; and your seed shall possess the gate of their enemies.

**22:18** "And in your seed all the nations of the earth shall be blessed—וְהִתְבָּרְכוּ (ve-hitbarchu)—because you have listened to my voice."

**22:19** And Abraham returned unto his young men, and they rose up and went together to Beer-sheba; and Abraham dwelt at Beer-sheba.

**22:20** And it came to pass after these things that it was told to Abraham, saying: "Behold, Milcah, she also has borne children unto your brother Nahor:

**22:21** "Uz his firstborn, and Buz his brother, and Kemuel the father of Aram,

**22:22** "And Chesed, and Hazo, and Pildash, and Jidlaph, and Bethuel."

**22:23** And Bethuel begot Rebekah. These eight Milcah bore to Nahor, Abraham's brother.

**22:24** And his concubine, whose name was Reumah, she also bore Tebah, and Gaham, and Tahash, and Maacah.

---

## Synthesis Notes

**Key Restorations:**

**The Test (נִסָּה, nissah):**
The text explicitly states this is a test. The question is: what is being tested, and what does the test reveal?

**"Your Only Son" (יְחִידְךָ, yechidecha):**
But Ishmael also lives. The term means "unique one" or "specially beloved"—Isaac is the son of promise, but calling him "only" after Ishmael's expulsion intensifies the moral weight.

**The Silence:**
- Abraham does not argue, does not negotiate (as he did for Sodom)
- He does not consult Sarah
- Isaac does not resist (though he is old enough to carry wood and ask questions)
- The two of them go "together" (יַחְדָּו)—emphasizing their unity while walking toward violence

**Isaac's Question:**
"Where is the lamb?" Isaac sees the components of sacrifice but not the victim. Abraham's answer is either prophetic trust or evasion: "Consciousness will provide."

**The Binding (עֲקֵדָה, aqedah):**
- Abraham binds Isaac—this is not sacrifice of an infant but restraint of a youth
- Isaac does not struggle (or the text doesn't record it)
- The knife is raised

**The Interruption:**
- The messenger calls "Abraham! Abraham!"—the double name signals urgency
- "Do not stretch forth your hand"—the action is stopped
- "Now I know that you are God-fearing"—the test has revealed something

**The Ram:**
A substitute appears—caught, already present, provided. The system accepts substitution; the child is released.

**YHWH Yir'eh:**
The wordplay is rich:
- יִרְאֶה (yir'eh) = "will provide" or "will see" or "will be seen"
- The mountain of provision/vision
- Later identified with the Temple Mount in Jerusalem

**Ethical Inversion — The Central Problem:**

Traditional reading: Abraham's willingness to sacrifice Isaac demonstrates supreme faith and obedience.

**The restoration must ask the hard questions:**

1. **Is this a test of obedience or a test to end child sacrifice?**
   - Ancient Near Eastern cultures practiced child sacrifice
   - YHWH's intervention establishes: this God does NOT require child sacrifice
   - The point is the ram—substitution—not the willingness to kill

2. **Who is the moral center?**
   - If Abraham had refused, saying "I will not kill my child even if You command it," would that have been failure or the highest faith?
   - The text doesn't explore this alternative
   - Some later Jewish interpreters imagined Isaac as willing participant; others saw trauma

3. **What does it mean that the messenger stops it?**
   - Consciousness commands; the messenger interrupts
   - Perhaps the test was always to see if Abraham would continue past the point of reason
   - Perhaps "now I know" means the divine learned something

4. **The silence of Isaac and Sarah:**
   - Isaac never speaks after this chapter until he is much older
   - Sarah dies in the next chapter—some midrash connects her death to hearing of the Aqedah
   - The trauma is real

**The restoration's synthesis:**
- The Aqedah ends child sacrifice by demonstrating divine intervention against it
- Abraham's faith is acknowledged, but the text also reveals the cost of unquestioning obedience
- The moral center is the voice that says "Do not"—the messenger who stops the knife
- The ram is the gift—substitutionary provision that allows life to continue

**Archetypal Layer:** This is the death-and-rebirth of the father-son bond. Isaac "dies" symbolically (is bound, laid on the altar) and is "reborn" (released, replaced by ram). Abraham's identity as father is transformed—he has faced the ultimate demand and been released from it. The mountain becomes the axis of meeting between absolute demand and merciful provision.

**Psychological Reading:** The father's willingness to sacrifice the future (the son) represents the ego's capacity to surrender even its most cherished attachment. But the test reveals that such literal surrender is NOT required—the psyche is asked whether it is willing, then provided an alternative. The danger is when religious systems demand the literal sacrifice without providing the ram.

**Modern Equivalent:** Religious and ideological systems that demand the sacrifice of children (literal or metaphorical) must be interrupted. The voice that says "Do not stretch forth your hand" is the moral center. True faith is demonstrated not by completing the violence but by being willing to release attachment AND receiving the substitute. The mountain of vision is where we see that our most extreme sacrifices are not ultimately required.

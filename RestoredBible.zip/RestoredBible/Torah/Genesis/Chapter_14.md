# Genesis Chapter 14: The War of Kings and Melchizedek

*From the Hebrew: Abram the Warrior and the Priest-King of Salem*

---

**14:1** And it came to pass in the days of Amraphel king of Shinar, Arioch king of Ellasar, Chedorlaomer king of Elam, and Tidal king of Goiim,

**14:2** That they made war with Bera king of Sodom, and with Birsha king of Gomorrah, Shinab king of Admah, and Shemeber king of Zeboiim, and the king of Bela, which is Zoar.

**14:3** All these joined together in the Valley of Siddim, which is the Salt Sea.

**14:4** Twelve years they had served Chedorlaomer, and in the thirteenth year they rebelled.

**14:5** And in the fourteenth year Chedorlaomer came, and the kings that were with him, and they struck the Rephaim in Ashteroth-karnaim, and the Zuzim in Ham, and the Emim in Shaveh-kiriathaim,

**14:6** And the Horites in their mountain Seir, unto El-paran, which is by the wilderness.

**14:7** And they returned and came to En-mishpat, which is Kadesh, and struck all the country of the Amalekites, and also the Amorites who dwelt in Hazazon-tamar.

**14:8** And there went out the king of Sodom, and the king of Gomorrah, and the king of Admah, and the king of Zeboiim, and the king of Bela, which is Zoar; and they set battle in array against them in the Valley of Siddim:

**14:9** Against Chedorlaomer king of Elam, and Tidal king of Goiim, and Amraphel king of Shinar, and Arioch king of Ellasar—four kings against five.

**14:10** And the Valley of Siddim was full of bitumen pits; and the kings of Sodom and Gomorrah fled and fell there, and those who remained fled to the mountain.

**14:11** And they took all the goods of Sodom and Gomorrah, and all their provisions, and went their way.

**14:12** And they took Lot, Abram's brother's son, who dwelt in Sodom, and his goods, and departed.

**14:13** And one who had escaped came and told Abram the Hebrew—הָעִבְרִי (ha-Ivri); and he was dwelling by the oaks of Mamre the Amorite, brother of Eshcol and brother of Aner; and these were allies of Abram—בַּעֲלֵי בְרִית (ba'alei berit).

**14:14** And when Abram heard that his kinsman was taken captive, he armed his trained servants—חֲנִיכָיו (chanikav)—born in his house, three hundred and eighteen, and pursued unto Dan.

**14:15** And he divided himself against them by night, he and his servants, and struck them, and pursued them unto Hobah, which is on the left of Damascus.

**14:16** And he brought back all the goods, and also brought back his kinsman Lot and his goods, and also the women and the people.

**14:17** And the king of Sodom went out to meet him, after his return from striking Chedorlaomer and the kings that were with him, at the Valley of Shaveh, which is the King's Valley.

**14:18** And Melchizedek—מַלְכִּי־צֶדֶק (Malki-Tsedeq)—king of Salem, brought forth bread and wine; and he was priest of El Elyon—אֵל עֶלְיוֹן (El Elyon), God Most High.

**14:19** And he blessed him and said: "Blessed be Abram of El Elyon, Possessor of heaven and earth.

**14:20** "And blessed be El Elyon, who has delivered your enemies into your hand." And Abram gave him a tenth of all.

**14:21** And the king of Sodom said unto Abram: "Give me the persons, and take the goods for yourself."

**14:22** And Abram said unto the king of Sodom: "I have lifted my hand unto YHWH, El Elyon, Possessor of heaven and earth,

**14:23** "That I will not take from a thread to a sandal-strap, nor anything that is yours, lest you should say, 'I have made Abram rich.'

**14:24** "Nothing for me—only what the young men have eaten, and the portion of the men who went with me: Aner, Eshcol, and Mamre—let them take their portion."

---

## Synthesis Notes

**Key Restorations:**

- *Ha-Ivri* (הָעִבְרִי): "The Hebrew"—first occurrence of this term. From the root עָבַר (avar), "to cross over." Abram is the one who has crossed over—from Mesopotamia, from his old identity, from one world to another. "Hebrew" means "crosser," "boundary-transgressor."

- **The geopolitical context**: This chapter suddenly shifts to international warfare—four eastern kings (Mesopotamian empire) versus five Canaanite city-kings. Abram is drawn in when Lot is captured. The pastoral nomad becomes a military commander.

- *Chanikav* (חֲנִיכָיו): "Trained ones"—from the root חָנַךְ (chanak), "to dedicate" or "to train" (same root as Hanukkah). Abram has 318 household warriors. He is not a simple shepherd but a significant power.

- **The Rephaim, Zuzim, Emim**: Ancient giant peoples—echoes of the Nephilim tradition. The eastern kings defeat these legendary inhabitants before confronting the city-kings.

**Melchizedek — The Mysterious Priest-King:**

- *Malki-Tsedeq* (מַלְכִּי־צֶדֶק): "My king is righteousness" or "King of Righteousness"
- King of *Salem* (שָׁלֵם)—"peace" or "wholeness"—later identified with Jerusalem
- Priest of *El Elyon* (אֵל עֶלְיוֹן)—"God Most High"—a Canaanite divine title that Abram immediately adopts

**Melchizedek appears from nowhere and disappears**: No genealogy, no origin, no death recorded. He simply IS—the archetypal priest-king who blesses the patriarch and receives his tithe.

- **Bread and wine**: The elements of sacred meal, covenant, communion. Melchizedek offers the symbols of transformed substance—grain become bread, grape become wine.

- **Abram tithes to Melchizedek**: The patriarch acknowledges the priest-king's spiritual authority. This is not Israelite priesthood (which doesn't exist yet) but an earlier, universal priesthood.

- **El Elyon = YHWH**: Abram identifies them (14:22). The Canaanite high god and the Hebrew covenant god are equated—a remarkable theological claim.

**Abram refuses the king of Sodom's wealth**: Having accepted blessing from Melchizedek, Abram refuses enrichment from Sodom's king. He will not be beholden to the corrupt city. His wealth comes from El Elyon, not from alliance with dysfunction.

**Archetypal Layer:** Melchizedek is the **axis figure**—the mountain/temple of the symbol map, the meeting point of realms. He combines kingship and priesthood, blessing and receiving, giving bread and wine. He represents the possibility of integrated authority—righteousness and peace united.

The contrast: Melchizedek (king of righteousness, king of peace) versus the king of Sodom (king of a wicked city). Abram receives from one, refuses the other.

**Psychological Reading:** When we rescue what has been captured (Lot = the part of ourselves drawn toward Sodom), we encounter two kinds of authority: the integrated priest-king who blesses and nourishes, and the corrupt king who offers material reward for alliance. The choice of whom to be enriched by shapes destiny.

**Modern Equivalent:** In any recovery of what was lost, we encounter competing claims. Some authorities offer genuine blessing—nourishment, integration, acknowledgment of the higher source. Others offer transactional reward that would create obligation to corrupt systems. The tithe to Melchizedek and the refusal of Sodom's wealth represent discernment about the sources of true prosperity.

# Genesis Chapter 37: Joseph and His Brothers

*From the Hebrew: וַיֵּשֶׁב (Vayeshev) — And He Dwelt*

---

**37:1** And Jacob dwelt in the land of his father's sojournings, in the land of Canaan.

**37:2** These are the generations of Jacob. Joseph, being seventeen years old, was shepherding the flock with his brothers; and he was a lad with the sons of Bilhah and with the sons of Zilpah, his father's wives; and Joseph brought unto his father their evil report—דִּבָּתָם רָעָה (dibbatam ra'ah).

**37:3** And Israel loved Joseph more than all his sons, because he was the son of his old age; and he made him a coat of many colors—כְּתֹנֶת פַּסִּים (ketonet passim).

**37:4** And his brothers saw that their father loved him more than all his brothers; and they hated him and could not speak peaceably unto him—לְשָׁלֹם (le-shalom).

**37:5** And Joseph dreamed a dream, and he told it to his brothers; and they hated him yet more.

**37:6** And he said unto them: "Please hear this dream which I have dreamed:

**37:7** "Behold, we were binding sheaves—אֲלֻמִּים (alummim)—in the field, and behold, my sheaf arose and also stood upright; and behold, your sheaves gathered around and bowed down to my sheaf."

**37:8** And his brothers said to him: "Will you indeed reign over us? Or will you indeed have dominion over us?" And they hated him yet more for his dreams and for his words.

**37:9** And he dreamed yet another dream and told it to his brothers, and said: "Behold, I have dreamed yet a dream: and behold, the sun and the moon and eleven stars were bowing down to me."

**37:10** And he told it to his father and to his brothers; and his father rebuked him and said unto him: "What is this dream that you have dreamed? Shall I and your mother and your brothers indeed come to bow down to the earth before you?"

**37:11** And his brothers were jealous of him—וַיְקַנְאוּ־בוֹ (va-yeqan'u-vo); but his father kept the matter in mind—שָׁמַר אֶת־הַדָּבָר (shamar et-ha-davar).

**37:12** And his brothers went to shepherd their father's flock at Shechem.

**37:13** And Israel said unto Joseph: "Are not your brothers shepherding at Shechem? Come, and I will send you unto them." And he said unto him: "Here I am—הִנֵּנִי (hineni)."

**37:14** And Israel said unto him: "Go now, see the welfare—שְׁלוֹם (shalom)—of your brothers and the welfare of the flock, and bring me word back." And he sent him from the valley of Hebron, and he came to Shechem.

**37:15** And a man found him, and behold, he was wandering in the field; and the man asked him, saying: "What are you seeking?"

**37:16** And he said: "I am seeking my brothers; tell me, please, where they are shepherding."

**37:17** And the man said: "They have journeyed from here, for I heard them saying, 'Let us go to Dothan.'" And Joseph went after his brothers and found them at Dothan.

**37:18** And they saw him from afar, and before he came near unto them, they conspired against him to kill him—וַיִּתְנַכְּלוּ אֹתוֹ לַהֲמִיתוֹ (va-yitnakkelu oto la-hamito).

**37:19** And they said to one another: "Behold, the dreamer—בַּעַל הַחֲלֹמוֹת (ba'al ha-chalomot)—comes!

**37:20** "Now therefore come, let us kill him and cast him into one of the pits; and we will say, 'A wild beast has devoured him'; and we shall see what will become of his dreams."

**37:21** And Reuben heard, and he delivered him from their hand, and said: "Let us not take his life—נֶפֶשׁ (nefesh)."

**37:22** And Reuben said unto them: "Shed no blood; cast him into this pit that is in the wilderness, but do not lay a hand upon him"—in order to deliver him from their hand, to restore him to his father.

**37:23** And it came to pass, when Joseph came unto his brothers, that they stripped Joseph of his coat, the coat of many colors that was upon him.

**37:24** And they took him and cast him into the pit; and the pit was empty—there was no water in it.

**37:25** And they sat down to eat bread; and they lifted up their eyes and looked, and behold, a caravan of Ishmaelites was coming from Gilead, and their camels were bearing spices and balm and myrrh, going down to Egypt.

**37:26** And Judah said unto his brothers: "What profit is it if we kill our brother and conceal his blood?

**37:27** "Come, let us sell him to the Ishmaelites, and let our hand not be upon him, for he is our brother, our flesh." And his brothers listened.

**37:28** And Midianite traders passed by; and they drew Joseph up and lifted him out of the pit, and sold Joseph to the Ishmaelites for twenty pieces of silver; and they brought Joseph into Egypt.

**37:29** And Reuben returned to the pit, and behold, Joseph was not in the pit; and he tore his garments.

**37:30** And he returned unto his brothers and said: "The child is not! And I, where shall I go?"

**37:31** And they took Joseph's coat, and slaughtered a male goat, and dipped the coat in the blood.

**37:32** And they sent the coat of many colors, and brought it to their father, and said: "This we have found; please examine it: is it your son's coat or not?"

**37:33** And he examined it and said: "It is my son's coat! A wild beast has devoured him! Joseph is surely torn—טָרֹף טֹרַף יוֹסֵף (tarof toraf Yosef)!"

**37:34** And Jacob tore his garments, and put sackcloth upon his loins, and mourned for his son many days.

**37:35** And all his sons and all his daughters rose up to comfort him, but he refused to be comforted, and he said: "For I will go down to my son mourning, to Sheol—שְׁאֹלָה (she'olah)." And his father wept for him.

**37:36** And the Medanites sold him into Egypt, unto Potiphar, an officer of Pharaoh, the captain of the guard.

---

## Synthesis Notes

**Key Restorations:**

**The Evil Report:**
Joseph brings *dibbatam ra'ah*—"their bad report" or "slander about them." From the beginning, Joseph is positioned between his brothers and his father, carrying information. This creates resentment.

**The Coat of Many Colors:**
*Ketonet passim* (כְּתֹנֶת פַּסִּים): The translation "many colors" is traditional but uncertain. It could mean a long-sleeved robe, an ornamented tunic, or a garment reaching to the extremities. Whatever it was, it marked Joseph as favored—a visible sign of preferential love.

**The Repetition of Favoritism:**
Jacob loved Rachel more than Leah; now Jacob loves Joseph (Rachel's son) more than his other sons. The pattern of preferential love continues across generations.

**The Dreams:**
Two dreams, both of dominion:
1. Sheaves bowing—agricultural imagery
2. Sun, moon, eleven stars bowing—cosmic imagery

Joseph tells these dreams to his brothers—tactlessly, perhaps arrogantly. The dreams are prophetic (they will come true), but the telling inflames hatred.

**Jacob's Mixed Response:**
He rebukes Joseph ("Shall we bow to you?") but also "keeps the matter"—holds it in memory. Jacob recognizes something in the dreams even as he corrects.

**"Here I Am" (הִנֵּנִי, hineni):**
Joseph's response to Jacob's commission echoes Abraham at the Aqedah (22:1) and Jacob at Bethel (31:11). The word signals readiness for mission—even when the mission leads to disaster.

**Shechem:**
The brothers are at Shechem—the site of the recent massacre. The text doesn't comment, but the location resonates with violence.

**The Conspiracy:**
"The dreamer comes!"—מBa'al ha-chalomot*, literally "the master of dreams." They want to kill him and destroy his dreams. "We shall see what becomes of his dreams"—ironic, since the dreams will come true precisely because of their attempt to prevent them.

**Reuben's Intervention:**
Reuben (the firstborn, who lost his standing by sleeping with Bilhah) tries to save Joseph—planning to return him to Jacob. His motive may be genuine care or an attempt to regain favor.

**Judah's Proposal:**
Judah suggests selling rather than killing—"What profit if we kill him?" The moral reasoning is minimal ("he is our brother"), the profit motive is central. Yet this saves Joseph's life.

**The Ishmaelites/Midianites:**
The text uses both names (37:25, 28, 36). These may be interchangeable terms for trading peoples, or the text may weave multiple traditions. Joseph is sold for twenty pieces of silver—later tradition will connect this to Judas's thirty pieces (Matthew 26:15).

**The Deception with Blood:**
The brothers use a goat's blood on the coat to deceive Jacob—exactly as Jacob used goatskins to deceive Isaac. The deceiver is deceived by his own children using similar methods.

**Jacob's Inconsolable Grief:**
"I will go down mourning to Sheol"—Jacob expects to die grieving. He is deceived for years while Joseph lives. The irony is cruel.

**Sheol (שְׁאוֹל):**
The underworld, the realm of the dead—not hell but the shadowy place of departed spirits. Jacob expects to carry his grief to death.

**Archetypal Layer:** The dreamer is cast into the pit—the descent that precedes elevation. The favored son must be rejected, stripped, sold, and given up for dead before he can rise to save the very ones who rejected him. This is the death-and-resurrection pattern.

**Psychological Reading:** Joseph represents the ego's unconscious grandiosity—the dreams of dominion that the psyche produces. The brothers represent the parts of self that cannot tolerate this inflation. The stripping and pit are the humiliation that must precede genuine maturation. Joseph will become what the dreams foretold, but only after the pit.

**Ethical Inversion Applied:**
- Traditional reading: Joseph is the innocent victim
- **Restored reading**: Joseph is favored, perhaps arrogant, certainly tactless
- The brothers' hatred is understandable (not justified) given the family dynamics
- No one in this chapter is purely innocent or purely villainous
- Jacob's favoritism, Joseph's dreams, the brothers' envy—all contribute

**Modern Equivalent:** Family systems generate these patterns—favoritism breeds resentment, which generates violence (actual or symbolic). The one who is "special" may be cast out precisely because of that specialness. And the methods of deception cycle through generations—how Jacob deceived Isaac, so his sons deceive him.

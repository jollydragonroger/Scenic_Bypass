# Genesis Chapter 33: The Reconciliation with Esau

*From the Hebrew: Brothers Meet Again*

---

**33:1** And Jacob lifted up his eyes and looked, and behold, Esau was coming, and with him four hundred men. And he divided the children unto Leah and unto Rachel and unto the two maidservants.

**33:2** And he put the maidservants and their children first, and Leah and her children after, and Rachel and Joseph last.

**33:3** And he himself passed over before them and bowed himself to the ground seven times, until he came near to his brother.

**33:4** And Esau ran to meet him, and embraced him, and fell on his neck, and kissed him—וַיִּשָּׁקֵהוּ (va-yishshaqehu)—and they wept.

**33:5** And Esau lifted up his eyes and saw the women and the children, and said: "Who are these with you?" And Jacob said: "The children whom Consciousness has graciously given your servant."

**33:6** And the maidservants came near, they and their children, and they bowed.

**33:7** And Leah also and her children came near and bowed; and afterward Joseph and Rachel came near and bowed.

**33:8** And Esau said: "What do you mean by all this company which I met?" And Jacob said: "To find favor in the eyes of my lord."

**33:9** And Esau said: "I have enough—יֶשׁ־לִי רָב (yesh-li rav), my brother; let what you have be yours."

**33:10** And Jacob said: "No, please, if now I have found favor in your eyes, then receive my present from my hand; for therefore I have seen your face, as one sees the face of Consciousness—כִּרְאֹת פְּנֵי אֱלֹהִים (kir'ot penei Elohim)—and you have received me favorably.

**33:11** "Please take my blessing—בִּרְכָתִי (birchati)—that has been brought to you, because Consciousness has dealt graciously with me, and because I have all." And he urged him, and he took it.

**33:12** And Esau said: "Let us journey and go, and I will go alongside you."

**33:13** And Jacob said unto him: "My lord knows that the children are tender, and the nursing flocks and herds are upon me; and if they overdrive them one day, all the flock will die.

**33:14** "Let my lord, please, pass over before his servant, and I will lead on gently—אֶתְנַהֲלָה לְאִטִּי (etnahahlah le-itti)—according to the pace of the livestock that are before me and according to the pace of the children, until I come unto my lord at Seir."

**33:15** And Esau said: "Let me leave with you some of the people who are with me." And Jacob said: "Why? Let me find favor in the eyes of my lord."

**33:16** So Esau returned that day on his way to Seir.

**33:17** And Jacob journeyed to Succoth, and built for himself a house, and for his livestock he made booths—סֻכֹּת (sukkot). Therefore the name of the place is called Succoth.

**33:18** And Jacob came in peace—שָׁלֵם (shalem)—to the city of Shechem, which is in the land of Canaan, when he came from Paddan-aram; and he encamped before the city.

**33:19** And he bought the portion of the field where he had pitched his tent, from the hand of the children of Hamor, Shechem's father, for a hundred qesitah.

**33:20** And he set up there an altar, and called it El-Elohe-Israel—אֵל אֱלֹהֵי יִשְׂרָאֵל (El Elohei Yisra'el), "God, the God of Israel."

---

## Synthesis Notes

**Key Restorations:**

**The Arrangement:**
Jacob arranges his family with the maidservants and their children first (most vulnerable), then Leah and her children, then Rachel and Joseph last (most protected). The hierarchy of affection is visible and painful.

**The Seven Bows:**
Jacob bows to the ground seven times as he approaches—complete submission. The blessing-thief prostrates before the brother he wronged. "My lord... your servant"—the language of vassalage.

**Esau's Response — The Shock:**
Instead of attack, Esau runs, embraces, kisses, and weeps. The four hundred men were not an army of vengeance but perhaps an honor guard. 

*Va-yishshaqehu* (וַיִּשָּׁקֵהוּ): In the Masoretic text, this word has dots above each letter—a scribal mark indicating something unusual. Some traditions suggest Esau's kiss was insincere; others that it was surprisingly genuine. The text preserves ambiguity.

**"I Have Enough" vs. "I Have All":**
- Esau: "I have enough" (יֶשׁ־לִי רָב, yesh-li rav)—plenty, abundance
- Jacob: "I have all" (יֶשׁ־לִי כֹל, yesh-li chol)—everything, completeness

Esau speaks of quantity; Jacob speaks of wholeness. Jacob has wrestled with God and is now *shalem*—complete.

**"Like Seeing the Face of God":**
Jacob says seeing Esau's accepting face is like seeing God's face. This connects to Peniel—he saw God's face and survived; now he sees his brother's face and receives grace. The human reconciliation mirrors the divine encounter.

**"Take My Blessing" (בִּרְכָתִי, birchati):**
The very word for what Jacob stole. He now offers it back—not the original blessing, but a blessing of abundance. The stolen *berachah* is symbolically restored through the *minchah*.

**The Non-Reunion:**
Despite the reconciliation, Jacob does not go to Seir with Esau:
- He claims the children are tender
- He promises to come "unto my lord at Seir"
- But he goes instead to Succoth, then Shechem
- He never goes to Seir

Is this prudent caution? Continued deception? The reconciliation was real but the relationship remains distant. They will meet again only to bury Isaac (35:29).

**Succoth and Shechem:**
Jacob builds a house (permanent structure) and makes booths (sukkot) for livestock. He is settling, not sojourning. He buys land at Shechem—the second land purchase in Canaan (after Machpelah), this one by Jacob.

**The Altar's Name:**
*El Elohei Yisra'el* (אֵל אֱלֹהֵי יִשְׂרָאֵל)—"God, the God of Israel." Jacob uses his new name in naming the altar. He is now Israel, and God is his God. This is the completion of the Bethel vow: "Then YHWH shall be my God" (28:21).

**Archetypal Layer:** The dreaded encounter becomes grace. The enemy runs not to attack but to embrace. The stolen blessing is symbolically returned. But full reunion doesn't happen—the brothers reconcile and separate. Some relationships can heal but not restore intimacy. The altar marks the new identity achieved through the journey.

**Psychological Reading:** Facing the shadow (Esau) after wrestling with God, Jacob discovers the shadow is not monstrous but human, capable of generosity. The one we wronged may be more ready to forgive than we expect. Yet Jacob maintains distance—complete trust is not restored. The wound heals but leaves a scar.

**Ethical Inversion Applied:**
- Traditional reading focuses on Jacob's restoration
- **Restored reading**: Esau is the moral hero of this chapter
- He who was wronged runs with embrace, says "I have enough," offers to escort
- Jacob, the receiver of blessing, still schemes ("I'll meet you at Seir"—but doesn't)
- Esau models forgiveness; Jacob models caution

**Modern Equivalent:** Some reconciliations are real but limited. The one we wronged may forgive; we may offer restoration; yet the relationship doesn't return to what it was. Jacob and Esau weep together, then go separate ways. Sometimes that's enough. The altar is built where we are, not where we thought we'd be.

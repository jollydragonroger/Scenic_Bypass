# Genesis Chapter 26: Isaac and Abimelech

*From the Hebrew: The Middle Patriarch*

---

**26:1** And there was a famine in the land, besides the first famine that was in the days of Abraham. And Isaac went unto Abimelech king of the Philistines unto Gerar.

**26:2** And YHWH appeared unto him and said: "Do not go down to Egypt; dwell in the land which I shall tell you.

**26:3** "Sojourn in this land, and I will be with you and bless you; for unto you and unto your seed I will give all these lands, and I will establish the oath which I swore unto Abraham your father.

**26:4** "And I will multiply your seed as the stars of the heavens, and will give unto your seed all these lands; and in your seed shall all the nations of the earth be blessed—וְהִתְבָּרְכוּ (ve-hitbarchu)—

**26:5** "Because Abraham listened to my voice and kept my charge, my commandments, my statutes, and my teachings."

**26:6** And Isaac dwelt in Gerar.

**26:7** And the men of the place asked about his wife; and he said: "She is my sister"—for he feared to say, "my wife"—"lest the men of the place kill me because of Rebekah, for she is fair to look upon."

**26:8** And it came to pass, when he had been there a long time, that Abimelech king of the Philistines looked out through a window, and saw, and behold, Isaac was sporting—מְצַחֵק (metsacheq)—with Rebekah his wife.

**26:9** And Abimelech called Isaac and said: "Behold, surely she is your wife! How then did you say, 'She is my sister'?" And Isaac said unto him: "Because I said, 'Lest I die because of her.'"

**26:10** And Abimelech said: "What is this you have done unto us? One of the people might easily have lain with your wife, and you would have brought guilt—אָשָׁם (asham)—upon us."

**26:11** And Abimelech commanded all the people, saying: "He who touches this man or his wife shall surely be put to death."

**26:12** And Isaac sowed in that land, and found in that year a hundredfold; and YHWH blessed him.

**26:13** And the man grew great, and went forward, and grew until he was very great.

**26:14** And he had possessions of flocks and possessions of herds, and a great household; and the Philistines envied him.

**26:15** And all the wells which his father's servants had dug in the days of Abraham his father, the Philistines had stopped up and filled with earth.

**26:16** And Abimelech said unto Isaac: "Go from us, for you are much mightier than we."

**26:17** And Isaac departed from there and encamped in the valley of Gerar, and dwelt there.

**26:18** And Isaac dug again the wells of water which had been dug in the days of Abraham his father, and which the Philistines had stopped up after the death of Abraham; and he called their names after the names by which his father had called them.

**26:19** And Isaac's servants dug in the valley, and found there a well of living water—בְּאֵר מַיִם חַיִּים (be'er mayim chayyim).

**26:20** And the herdsmen of Gerar quarreled with Isaac's herdsmen, saying: "The water is ours!" And he called the name of the well Esek—עֵשֶׂק (Eseq), meaning "contention"—because they contended with him.

**26:21** And they dug another well, and they quarreled over that also; and he called the name of it Sitnah—שִׂטְנָה (Sitnah), meaning "opposition."

**26:22** And he moved from there and dug another well, and they did not quarrel over it; and he called the name of it Rehoboth—רְחֹבוֹת (Rechovot), meaning "wide spaces"—and he said: "For now YHWH has made room for us, and we shall be fruitful in the land."

**26:23** And he went up from there to Beer-sheba.

**26:24** And YHWH appeared unto him that night and said: "I am the Consciousness of Abraham your father; fear not, for I am with you, and will bless you and multiply your seed for my servant Abraham's sake."

**26:25** And he built an altar there

 and called upon the name of YHWH, and pitched his tent there; and there Isaac's servants dug a well.

**26:26** And Abimelech went to him from Gerar, and Ahuzzath his friend, and Phicol the commander of his army.

**26:27** And Isaac said unto them: "Why have you come unto me, seeing you hate me and have sent me away from you?"

**26:28** And they said: "We have certainly seen that YHWH has been with you; and we said: 'Let there now be an oath between us, between us and you, and let us cut a covenant with you,

**26:29** "'That you will do us no harm, just as we have not touched you, and just as we have done unto you only good, and have sent you away in peace. You now are the blessed of YHWH.'"

**26:30** And he made them a feast, and they ate and drank.

**26:31** And they rose early in the morning and swore each to the other; and Isaac sent them away, and they departed from him in peace.

**26:32** And it came to pass the same day that Isaac's servants came and told him concerning the well which they had dug, and said unto him: "We have found water!"

**26:33** And he called it Sheba—שִׁבְעָה (Shiv'ah); therefore the name of the city is Beer-sheba unto this day.

**26:34** And Esau was forty years old when he took to wife Judith the daughter of Beeri the Hittite, and Basemath the daughter of Elon the Hittite.

**26:35** And they were a bitterness of spirit—מֹרַת רוּחַ (morat ruach)—unto Isaac and unto Rebekah.

---

## Synthesis Notes

**Key Restorations:**

**The Pattern Repeats Again:**
This is the third "sister-wife" episode (Abraham twice, now Isaac). The pattern is nearly identical:
- Famine drives the patriarch to a foreign land
- Fear leads to the lie about the wife being a sister
- The foreign king discovers the truth and acts with integrity
- The patriarch is protected and prospers

**Metsacheq (מְצַחֵק):**
Abimelech sees Isaac "sporting" with Rebekah—the same root as Isaac's name (צחק). The pun is intentional: "Laughter was laughing with his wife." The intimacy revealed them as husband and wife, not siblings.

**Abimelech's Integrity (Again):**
Once again, the Philistine king demonstrates moral clarity:
- He recognizes the deception immediately
- He expresses concern about communal guilt
- He protects the couple with a death penalty for violation
- He is honest about why he sends Isaac away (envy, not hatred)

**The Wells:**
Wells are life in an arid land. The narrative of well-digging and well-naming connects Isaac to Abraham:

- The Philistines stopped up Abraham's wells after his death—erasing his legacy
- Isaac re-digs them and restores their names—reclaiming the inheritance
- New wells bring new conflicts:
  - *Eseq* (עֵשֶׂק) = Contention
  - *Sitnah* (שִׂטְנָה) = Opposition (related to Satan—the opposer)
  - *Rechovot* (רְחֹבוֹת) = Wide spaces, room

The progression: contention → opposition → finally, spaciousness. This is the pattern of conflict resolution through persistence and movement.

**"Living Water" (מַיִם חַיִּים):**
Not just any water but spring water, flowing water—the most valuable kind. Isaac finds the source of life.

**The Covenant at Beer-sheba:**
The same location as Abraham's covenant with Abimelech (21:31-32). Isaac reestablishes what his father established. The Philistines recognize YHWH's blessing on Isaac and seek peace.

**Esau's Wives:**
The chapter ends with a discordant note: Esau marries Hittite women, causing his parents "bitterness of spirit." This sets up the tension for the coming chapters—Esau has assimilated; Jacob remains within the family's endogamous pattern.

**Archetypal Layer:** Isaac is the transitional figure—between the heroic Abraham and the complex Jacob. His role is to maintain, to re-dig, to persist through opposition until space opens. He embodies continuation rather than origination.

**Psychological Reading:** Sometimes our work is not to create something new but to recover what has been stopped up—to clear the wells our ancestors dug, to restore the names they gave. The progression from Contention through Opposition to Wide Spaces is the path of conflict that doesn't give up.

**Ethical Inversion Applied:**
- Traditional reading emphasizes Isaac's blessing despite deception
- **Restored reading**: Abimelech (the "pagan") again demonstrates superior ethics
- Isaac's fear-based deception is not model behavior but repeated failure
- The moral center is the honest confrontation and the protection offered

**Modern Equivalent:** Some generations innovate; others maintain. Isaac's role is to re-dig the wells—to recover lost resources, restore proper names, and persist through opposition until there is room. Not every generation must be revolutionary; some must be faithful.

# Genesis Chapter 39: Joseph in Potiphar's House

*From the Hebrew: The Rise and Fall and Rise*

---

**39:1** And Joseph was brought down to Egypt; and Potiphar, an officer of Pharaoh, the captain of the guard, an Egyptian man, bought him from the hand of the Ishmaelites who had brought him down there.

**39:2** And YHWH was with Joseph, and he was a successful man—אִישׁ מַצְלִיחַ (ish matsliach); and he was in the house of his master the Egyptian.

**39:3** And his master saw that YHWH was with him, and that YHWH made all that he did to prosper in his hand.

**39:4** And Joseph found favor in his eyes, and he served him; and he made him overseer over his house, and all that he had he put into his hand.

**39:5** And it came to pass, from the time that he made him overseer in his house and over all that he had, that YHWH blessed the Egyptian's house for Joseph's sake; and the blessing of YHWH was upon all that he had, in the house and in the field.

**39:6** And he left all that he had in Joseph's hand; and he knew not anything he had, except the bread which he ate. And Joseph was beautiful in form and beautiful in appearance—יְפֵה־תֹאַר וִיפֵה מַרְאֶה (yefeh-to'ar vi-yefeh mar'eh).

**39:7** And it came to pass after these things, that his master's wife lifted up her eyes unto Joseph, and she said: "Lie with me."

**39:8** And he refused, and said unto his master's wife: "Behold, my master does not know what is with me in the house, and all that he has he has put into my hand.

**39:9** "There is none greater in this house than I; and he has not withheld anything from me except you, because you are his wife. How then can I do this great evil, and sin against Consciousness—וְחָטָאתִי לֵאלֹהִים (ve-chatati l'Elohim)?"

**39:10** And it came to pass, as she spoke to Joseph day by day, that he did not listen to her, to lie with her or to be with her.

**39:11** And it came to pass on a certain day, that he went into the house to do his work, and none of the men of the house were there in the house.

**39:12** And she caught him by his garment, saying: "Lie with me!" And he left his garment in her hand, and fled, and went outside.

**39:13** And it came to pass, when she saw that he had left his garment in her hand and had fled outside,

**39:14** That she called unto the men of her house, and spoke unto them, saying: "See, he has brought unto us a Hebrew man—אִישׁ עִבְרִי (ish Ivri)—to mock us! He came in unto me to lie with me, and I cried out with a loud voice.

**39:15** "And it came to pass, when he heard that I lifted up my voice and cried out, that he left his garment beside me and fled and went outside."

**39:16** And she laid up his garment beside her until his master came home.

**39:17** And she spoke unto him according to these words, saying: "The Hebrew servant whom you brought unto us came in unto me to mock me.

**39:18** "And it came to pass, when I lifted up my voice and cried out, that he left his garment beside me and fled outside."

**39:19** And it came to pass, when his master heard the words of his wife, which she spoke unto him, saying, "According to these things your servant did to me," that his anger was kindled.

**39:20** And Joseph's master took him and put him into the prison—בֵּית הַסֹּהַר (beit ha-sohar)—the place where the king's prisoners were bound; and he was there in the prison.

**39:21** And YHWH was with Joseph, and extended kindness—חֶסֶד (chesed)—unto him, and gave him favor in the eyes of the keeper of the prison.

**39:22** And the keeper of the prison committed to Joseph's hand all the prisoners that were in the prison; and whatever they did there, he was the doer of it.

**39:23** The keeper of the prison did not look to anything that was in his hand, because YHWH was with him; and whatever he did, YHWH made it prosper.

---

## Synthesis Notes

**Key Restorations:**

**The Resumption:**
After the Judah-Tamar interlude (Chapter 38), the narrative returns to Joseph in Egypt. The contrast is sharp: Judah succumbed to sexual temptation; Joseph resists it.

**"YHWH Was With Joseph":**
This phrase appears repeatedly (39:2, 3, 21, 23). Divine presence accompanies Joseph in slavery, in service, and in prison. Success follows him—not freedom, but success within constraint.

**The Pattern of Rise:**
Joseph rises in Potiphar's house exactly as he will later rise in prison and then in Pharaoh's court. The pattern is consistent: he is placed in a low position, demonstrates competence and integrity, and is elevated to overseer.

**"Beautiful in Form and Appearance":**
*Yefeh-to'ar vi-yefeh mar'eh*—the exact phrase used for Rachel (29:17). Joseph inherits his mother's beauty. This beauty becomes the occasion for his next crisis.

**Potiphar's Wife:**
She is never named. Her approach is direct: "Lie with me"—two words in Hebrew (שִׁכְבָה עִמִּי, shikhvah immi). The demand is repeated "day by day" (39:10). This is persistent sexual harassment by one with power over the enslaved Joseph.

**Joseph's Refusal:**
His reasoning is twofold:
1. Loyalty to Potiphar: "He has put everything in my hand... except you"
2. Theological: "How can I sin against Consciousness?"

Joseph names the moral stakes clearly. The sin is not merely social (against Potiphar) but cosmic (against Elohim).

**The Garment:**
Joseph loses his garment—again. First his brothers stripped his coat; now Potiphar's wife seizes his garment. Both garments become false evidence against him. Both strippings precede descent (to the pit, to prison).

**"A Hebrew Man... To Mock Us":**
The wife uses ethnic slur ("Hebrew") and xenophobia to frame her accusation. She appeals to household solidarity against the foreign slave. The accusation inverts reality: she pursued him; she claims he attacked her.

**Potiphar's Response:**
His "anger was kindled"—but against whom? He puts Joseph in prison but does not execute him (which would be typical for attempted rape of a master's wife). Some interpreters suggest Potiphar suspects the truth but must act publicly.

**The Royal Prison:**
Joseph ends up in the prison for royal officials—a specific, high-status prison. This positions him to meet Pharaoh's servants (Chapter 40), which leads to Pharaoh himself. The "disaster" is providentially located.

**YHWH in Prison:**
Even in prison, "YHWH was with Joseph." The keeper of the prison trusts him completely—the same pattern as with Potiphar. Joseph cannot prevent injustice against himself, but he embodies competence and blessing wherever he is placed.

**Archetypal Layer:** The pattern of descent-rise-descent-rise structures Joseph's journey. Each stripping (coat, garment) precedes a descent (pit, prison), and each descent leads to eventual elevation. The hero must lose everything repeatedly before final exaltation.

**Psychological Reading:** Joseph is the ego that maintains integrity under pressure—refusing to merge with the powerful feminine (Potiphar's wife) even at cost. The garment left behind is the persona that must be surrendered; the self that flees naked is the core that cannot be compromised.

**Ethical Inversion Applied:**
- Traditional reading: Joseph is the moral hero; the wife is the temptress
- **Restored reading**: This is also a story of power and vulnerability
- Joseph is enslaved—he cannot simply leave or report to HR
- His resistance is admirable, but the situation is structurally coercive
- The wife's false accusation uses power dynamics (master/slave, native/foreigner) as weapons
- The prison is unjust—Joseph suffers for integrity

**Modern Equivalent:** Those without power (enslaved, employed, dependent) face impossible situations when those with power make demands. Joseph's refusal is heroic; his imprisonment is unjust; and the pattern of the powerful accusing the powerless of what the powerful attempted continues. Divine presence does not prevent injustice but accompanies through it.

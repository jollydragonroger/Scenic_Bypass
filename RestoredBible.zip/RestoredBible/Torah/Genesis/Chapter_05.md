# Genesis Chapter 5: The Generations of Adam

*From the Hebrew: סֵפֶר תּוֹלְדֹת אָדָם (Sefer Toledot Adam) — The Book of Human Generations*

---

**5:1** This is the book of the generations of Adam—the human. In the day that Consciousness created the human, in the likeness of Consciousness it was made.

**5:2** Male and female Consciousness created them; and blessed them, and called their name Adam—Human—in the day they were created.

**5:3** And Adam lived one hundred and thirty years, and begot in his likeness, according to his image, and called his name Seth.

**5:4** And the days of Adam after he had begotten Seth were eight hundred years; and he begot sons and daughters.

**5:5** And all the days that Adam lived were nine hundred and thirty years; and he transformed—וַיָּמֹת (va-yamot).

**5:6** And Seth lived one hundred and five years, and begot Enosh.

**5:7** And Seth lived after he begot Enosh eight hundred and seven years, and begot sons and daughters.

**5:8** And all the days of Seth were nine hundred and twelve years; and he transformed.

**5:9** And Enosh lived ninety years, and begot Kenan.

**5:10** And Enosh lived after he begot Kenan eight hundred and fifteen years, and begot sons and daughters.

**5:11** And all the days of Enosh were nine hundred and five years; and he transformed.

**5:12** And Kenan lived seventy years, and begot Mahalalel.

**5:13** And Kenan lived after he begot Mahalalel eight hundred and forty years, and begot sons and daughters.

**5:14** And all the days of Kenan were nine hundred and ten years; and he transformed.

**5:15** And Mahalalel lived sixty-five years, and begot Jared.

**5:16** And Mahalalel lived after he begot Jared eight hundred and thirty years, and begot sons and daughters.

**5:17** And all the days of Mahalalel were eight hundred and ninety-five years; and he transformed.

**5:18** And Jared lived one hundred and sixty-two years, and begot Enoch.

**5:19** And Jared lived after he begot Enoch eight hundred years, and begot sons and daughters.

**5:20** And all the days of Jared were nine hundred and sixty-two years; and he transformed.

**5:21** And Enoch lived sixty-five years, and begot Methuselah.

**5:22** And Enoch walked with Consciousness—וַיִּתְהַלֵּךְ חֲנוֹךְ אֶת־הָאֱלֹהִים (va-yithallech Chanoch et-ha-Elohim)—after he begot Methuselah three hundred years, and begot sons and daughters.

**5:23** And all the days of Enoch were three hundred and sixty-five years.

**5:24** And Enoch walked with Consciousness; and he was not, for Consciousness took him—כִּי־לָקַח אֹתוֹ אֱלֹהִים (ki-laqach oto Elohim).

**5:25** And Methuselah lived one hundred and eighty-seven years, and begot Lamech.

**5:26** And Methuselah lived after he begot Lamech seven hundred and eighty-two years, and begot sons and daughters.

**5:27** And all the days of Methuselah were nine hundred and sixty-nine years; and he transformed.

**5:28** And Lamech lived one hundred and eighty-two years, and begot a son.

**5:29** And he called his name Noah—נֹחַ (Noach)—saying: "This one shall comfort us—יְנַחֲמֵנוּ (yenachamenu)—from our work and from the toil of our hands, from the ground which YHWH has transformed."

**5:30** And Lamech lived after he begot Noah five hundred and ninety-five years, and begot sons and daughters.

**5:31** And all the days of Lamech were seven hundred and seventy-seven years; and he transformed.

**5:32** And Noah was five hundred years old; and Noah begot Shem, Ham, and Japheth.

---

## Synthesis Notes

**Key Restorations:**

- *Va-yamot* (וַיָּמֹת): Traditionally "and he died"—restored as "and he transformed." Death in this genealogy is transition, not termination. The formula emphasizes continuity through generation.

- **The great ages**: Whether understood literally, symbolically, or as reflecting different time-reckoning systems, these ages represent the era of proto-humanity—beings closer to the source, before the "shortening of days" that comes after the Flood.

- *Enoch walked with Consciousness* (וַיִּתְהַלֵּךְ...אֶת־הָאֱלֹהִים): The verb is reflexive/intensive—"walked himself with"—suggesting intimate, continuous companionship with creative awareness.

- **Enoch "was not, for Consciousness took him"**: The exceptional figure who does not undergo the standard transformation but is directly integrated. In later tradition (1 Enoch), he becomes the visionary who receives cosmic revelation. He represents the human capacity for direct conscious union.

- *Noach* (נֹחַ): From the root meaning "rest" or "comfort." The name prophetically anticipates the resolution after the coming deluge—the restoration of balance.

- **The Sethite lineage**: This chapter traces the "line of promise" through Seth (replacing Abel), culminating in Noah. It parallels but contrasts with Cain's lineage in Chapter 4—both lines produce civilization, but Seth's line maintains conscious connection with YHWH.

**Numerical Patterns:**
- Enoch's lifespan: 365 years = solar cycle
- Lamech's lifespan: 777 years = triple completeness
- The tenth generation (Noah) brings renewal

**Archetypal Layer:** Genealogies are not merely records but structures of meaning. Ten generations from Adam to Noah mirrors ten generations from Noah to Abraham—the pattern of completion and new beginning. Each name carries etymological significance, creating a narrative arc through naming.

**Modern Equivalent:** The genealogy represents the long arc of human development from the first self-awareness (Adam) through civilization's complexity, marked by the singular figure (Enoch) who achieves integration, toward the crisis point (Noah) that will require systemic renewal.

# Genesis Chapter 25: Abraham's Death and Jacob and Esau

*From the Hebrew: תּוֹלְדֹת יִצְחָק (Toledot Yitschaq) — The Generations of Isaac*

---

**25:1** And Abraham took another wife, and her name was Keturah—קְטוּרָה (Qeturah).

**25:2** And she bore him Zimran, and Jokshan, and Medan, and Midian, and Ishbak, and Shuah.

**25:3** And Jokshan begot Sheba and Dedan. And the sons of Dedan were Asshurim, and Letushim, and Leummim.

**25:4** And the sons of Midian: Ephah, and Epher, and Hanoch, and Abida, and Eldaah. All these were the children of Keturah.

**25:5** And Abraham gave all that he had unto Isaac.

**25:6** And unto the sons of the concubines that Abraham had, Abraham gave gifts; and he sent them away from Isaac his son, while he yet lived, eastward, unto the east country.

**25:7** And these are the days of the years of Abraham's life which he lived: one hundred and seventy-five years.

**25:8** And Abraham expired and died in a good old age—בְּשֵׂיבָה טוֹבָה (be-seivah tovah)—old and full—זָקֵן וְשָׂבֵעַ (zaqen ve-save'a); and he was gathered to his people.

**25:9** And Isaac and Ishmael his sons buried him in the cave of Machpelah, in the field of Ephron the son of Zohar the Hittite, which is before Mamre—

**25:10** The field which Abraham purchased from the children of Heth; there was Abraham buried, and Sarah his wife.

**25:11** And it came to pass after the death of Abraham that Consciousness blessed Isaac his son; and Isaac dwelt by Beer-lahai-roi.

---

**25:12** And these are the generations of Ishmael, Abraham's son, whom Hagar the Egyptian, Sarah's maidservant, bore unto Abraham.

**25:13** And these are the names of the sons of Ishmael, by their names, according to their generations: the firstborn of Ishmael, Nebaioth; and Kedar, and Adbeel, and Mibsam,

**25:14** And Mishma, and Dumah, and Massa,

**25:15** Hadad, and Tema, Jetur, Naphish, and Kedemah.

**25:16** These are the sons of Ishmael, and these are their names, by their villages and by their encampments: twelve princes—נְשִׂיאִם (nesi'im)—according to their nations.

**25:17** And these are the years of the life of Ishmael: one hundred and thirty-seven years; and he expired and died, and was gathered unto his people.

**25:18** And they dwelt from Havilah unto Shur, which is before Egypt, as you go toward Assyria; before the face of all his brothers he settled.

---

**25:19** And these are the generations of Isaac, Abraham's son: Abraham begot Isaac.

**25:20** And Isaac was forty years old when he took Rebekah, the daughter of Bethuel the Aramean of Paddan-aram, the sister of Laban the Aramean, to be his wife.

**25:21** And Isaac prayed—וַיֶּעְתַּר (va-ye'tar)—to YHWH on behalf of his wife, because she was barren; and YHWH was entreated—וַיֵּעָתֶר (va-ye'ater)—by him, and Rebekah his wife conceived.

**25:22** And the children struggled together—וַיִּתְרֹצְצוּ (va-yitrotsatsu)—within her; and she said: "If it is so, why am I thus?" And she went to inquire of YHWH.

**25:23** And YHWH said unto her: "Two nations are in your womb, and two peoples shall be separated from your body; and one people shall be stronger than the other people; and the elder shall serve the younger—וְרַב יַעֲבֹד צָעִיר (ve-rav ya'avod tsa'ir)."

**25:24** And when her days were fulfilled to give birth, behold, there were twins in her womb.

**25:25** And the first came out red—אַדְמוֹנִי (admoni)—all over like a hairy garment; and they called his name Esau—עֵשָׂו (Esav).

**25:26** And after that came out his brother, and his hand was holding Esau's heel—עָקֵב (aqev); and his name was called Jacob—יַעֲקֹב (Ya'aqov). And Isaac was sixty years old when she bore them.

**25:27** And the boys grew; and Esau was a man skilled in hunting, a man of the field; and Jacob was a quiet man—אִישׁ תָּם (ish tam)—dwelling in tents.

**25:28** And Isaac loved Esau, because game was in his mouth; but Rebekah loved Jacob.

**25:29** And Jacob cooked a stew; and Esau came from the field, and he was exhausted.

**25:30** And Esau said to Jacob: "Please let me gulp down—הַלְעִיטֵנִי (hal'iteni)—some of this red, red stuff—הָאָדֹם הָאָדֹם (ha-adom ha-adom)—for I am exhausted." Therefore his name was called Edom—אֱדוֹם (Edom).

**25:31** And Jacob said: "Sell me today your birthright—בְּכֹרָתְךָ (bechoratecha)."

**25:32** And Esau said: "Behold, I am going to die; and what is this birthright to me?"

**25:33** And Jacob said: "Swear to me today." And he swore to him; and he sold his birthright to Jacob.

**25:34** And Jacob gave Esau bread and stew of lentils; and he ate and drank, and rose up and went his way. Thus Esau despised—וַיִּבֶז (va-yivez)—his birthright.

---

## Synthesis Notes

**Key Restorations:**

**Keturah:**
Abraham's third wife (or concubine, according to 1 Chronicles 1:32). She bears six sons who become ancestors of Arabian peoples (Midian notably). Abraham's legacy extends far beyond Isaac—he is truly "father of many nations."

**Isaac and Ishmael Together:**
At Abraham's burial, both sons appear together (25:9). Whatever their earlier separation, they reunite to bury their father. The reconciliation is quiet but significant.

**"Gathered to His People":**
This phrase suggests continued existence beyond death—joining the ancestors. Abraham joins the community of the dead, not simply ceasing to exist.

**The Twelve Princes of Ishmael:**
As promised (17:20), Ishmael fathers twelve princes—paralleling the twelve tribes that will descend from Jacob. Both lines are organized, both are "nations."

**Isaac at Beer-lahai-roi:**
Again, Isaac dwells by Hagar's well—the well named by the woman his mother expelled. The threads of the family remain intertwined.

**The Struggle in the Womb:**
- *Va-yitrotsatsu* (וַיִּתְרֹצְצוּ): "Struggled" or "crushed each other"—violent conflict from the beginning
- Rebekah's anguished question: "If it is so, why am I thus?"—why exist if existence is this painful?
- She goes directly to YHWH to inquire—Rebekah has her own prophetic access

**The Oracle (25:23):**
"The elder shall serve the younger" (וְרַב יַעֲבֹד צָעִיר)—but the Hebrew is ambiguous. It could also read: "The greater shall serve the younger" or even "The elder, the younger shall serve." The ambiguity is intentional—the relationship between the brothers will be complex.

**The Names:**
- *Esav* (עֵשָׂו): Connected to שֵׂעָר (se'ar), "hair"—he is born hairy
- *Admoni* (אַדְמוֹנִי): "Red/ruddy"—connecting him to אֱדוֹם (Edom) and אֲדָמָה (adamah), earth
- *Ya'aqov* (יַעֲקֹב): From עָקֵב (aqev), "heel"—the heel-grabber, the supplanter

**The Character Contrast:**
- Esau: man of the field, hunter, outdoorsman, impulsive
- Jacob: *ish tam* (אִישׁ תָּם)—"quiet man" or "whole/complete man"—tent-dweller, domestic, calculating

**The Parental Split:**
"Isaac loved Esau... but Rebekah loved Jacob." The division of parental love sets up the coming conflict.

**The Birthright Sale:**
- Esau returns exhausted, sees the red stew, demands it crudely (הַלְעִיטֵנִי—"let me gulp down")
- Jacob seizes the opportunity to acquire the birthright
- Esau swears and sells for a meal
- The narrator's judgment: "Esau despised (וַיִּבֶז) his birthright"

**Ethical Complexity:**
Neither brother is entirely sympathetic:
- Esau: impulsive, present-oriented, willing to trade future for immediate gratification
- Jacob: calculating, exploitative, taking advantage of his brother's weakness

The text presents both; the restoration refuses to fully justify either.

**Archetypal Layer:** The twin brothers represent fundamental polarities—nature/culture, impulse/calculation, body/mind, hunter/shepherd. Their struggle begins in the womb and continues through life. The "younger serving the elder" reverses the expected order—a constant biblical theme (Abel over Cain, Isaac over Ishmael, now Jacob over Esau).

**Psychological Reading:** Within each person are both Esau (instinct, appetite, immediacy) and Jacob (planning, delay, calculation). The question is which "inherits"—which becomes primary. Esau's despising of the birthright is the devaluation of the future for the present; Jacob's manipulation is the exploitation of weakness for gain.

**Modern Equivalent:** We are constantly choosing between immediate gratification and long-term value. The "birthright" represents what we inherit and what we can become. Selling it for "red stuff" when we're tired is perennial. And the Jacobs among us are ready to buy.

# Genesis Chapter 12: The Call of Abram

*From the Hebrew: לֶךְ־לְךָ (Lech-Lecha) — Go Forth to Yourself*

---

**12:1** And YHWH said unto Abram: "Go forth—לֶךְ־לְךָ (lech-lecha)—from your land, and from your birthplace, and from your father's house, to the land that I will show you.

**12:2** "And I will make you into a great nation, and I will bless you, and I will make your name great; and you shall be a blessing.

**12:3** "And I will bless those who bless you, and the one who curses you I will curse; and through you all the families of the earth shall be blessed—וְנִבְרְכוּ בְךָ כֹּל מִשְׁפְּחֹת הָאֲדָמָה (ve-nivrechu vecha kol mishpechot ha-adamah)."

**12:4** And Abram went, as YHWH had spoken unto him; and Lot went with him. And Abram was seventy-five years old when he departed from Haran.

**12:5** And Abram took Sarai his partner, and Lot his brother's son, and all their possessions that they had gathered, and the souls they had acquired in Haran; and they went forth to go to the land of Canaan, and to the land of Canaan they came.

**12:6** And Abram passed through the land unto the place of Shechem, unto the oak of Moreh—אֵלוֹן מוֹרֶה (elon Moreh). And the Canaanite was then in the land.

**12:7** And YHWH appeared unto Abram and said: "To your seed I will give this land." And there he built an altar to YHWH, who had appeared to him.

**12:8** And he moved from there to the mountain east of Bethel, and pitched his tent with Bethel on the west and Ai on the east; and there he built an altar to YHWH and called upon the name of YHWH.

**12:9** And Abram journeyed, going and journeying toward the Negev.

**12:10** And there was a famine in the land; and Abram went down to Egypt to sojourn there, for the famine was severe in the land.

**12:11** And it came to pass, when he drew near to enter Egypt, that he said unto Sarai his partner: "Behold now, I know that you are a woman beautiful in appearance.

**12:12** "And it will come to pass, when the Egyptians see you, that they will say, 'This is his wife'; and they will kill me, but you they will keep alive.

**12:13** "Please say that you are my sister, so that it may go well with me because of you, and my soul may live on your account."

**12:14** And it came to pass, when Abram came into Egypt, that the Egyptians saw the woman, that she was very beautiful.

**12:15** And the princes of Pharaoh saw her and praised her to Pharaoh; and the woman was taken into Pharaoh's house.

**12:16** And he treated Abram well because of her; and Abram had sheep and cattle and male donkeys and male servants and female servants and female donkeys and camels.

**12:17** And YHWH struck Pharaoh and his house with great plagues—נְגָעִים גְּדֹלִים (nega'im gedolim)—because of Sarai, Abram's partner.

**12:18** And Pharaoh called Abram and said: "What is this you have done to me? Why did you not tell me that she was your partner?

**12:19** "Why did you say, 'She is my sister,' so that I took her to be my wife? And now, behold, your partner—take her and go."

**12:20** And Pharaoh commanded men concerning him; and they sent him away, and his partner, and all that he had.

---

## Synthesis Notes

**Key Restorations:**

- *Lech-lecha* (לֶךְ־לְךָ): Literally "go to yourself" or "go for yourself"—the journey outward is simultaneously a journey inward. The call is not merely geographic but psychological and spiritual: leave the familiar, the inherited, the assumed, and discover who you truly are.

- **The threefold leaving**: Land, birthplace, father's house—increasingly intimate spheres of identity. Abram must release cultural, regional, and familial conditioning to become the recipient of blessing.

- **"All families of the earth shall be blessed"**: The blessing given to one is meant to flow to all. This is the counter-movement to Babel's failed unity—genuine blessing through particularity, not imposed uniformity.

- *Elon Moreh* (אֵלוֹן מוֹרֶה): "Oak of the Teacher" or "Oak of Instruction"—a sacred site, likely already holy to the Canaanites. Abram builds an altar at an existing sacred place, layering traditions.

- **"The Canaanite was then in the land"**: The narrator's note acknowledges that the "promised land" is already inhabited. This honest observation creates tension with later conquest narratives.

**The Egypt Episode — Ethical Complexity:**

The traditional reading often apologizes for Abram or moralizes. The restored reading observes:

- Abram, the father of faith, immediately endangers his wife to save himself
- He profits from her objectification (12:16)
- It is Pharaoh—the pagan ruler—who acts with integrity: "What is this you have done to me?"
- YHWH intervenes to protect Sarai, not to reward Abram

**The moral center is the one who acts with integrity—in this case, Pharaoh.** Abram's faith is real, but it does not make him morally superior in every situation. The text does not hide this.

This pattern (patriarch endangers wife in foreign court) repeats three times in Genesis (12, 20, 26). The repetition signals archetypal significance: the feminine principle (Sarai) is repeatedly endangered by the masculine's survival anxiety.

**Archetypal Layer:** The call to leave father's house is the universal hero's departure—the first stage of the journey. Abram represents the emergence of individual calling from collective identity. But immediately, the hero fails a moral test. The journey does not confer instant virtue; it initiates a process.

**Psychological Reading:** Leaving "father's house" means releasing inherited patterns, beliefs, and identities. This is terrifying; the first response may be regression and self-protective deception (the sister-wife ruse). Growth is not linear.

**Modern Equivalent:** Every genuine calling requires leaving what is known. The promise is vast (nation, blessing, legacy), but the journey immediately encounters famine, compromise, and moral failure. The blessing is not earned by perfection but carried through imperfect vessels. The question is whether we keep journeying despite our failures.

# Genesis Chapter 9: The Covenant of the Rainbow

*From the Hebrew: The New Order After the Waters*

---

**9:1** And Consciousness blessed Noah and his sons, and said unto them: "Be fruitful and multiply, and fill the earth.

**9:2** "And the fear of you and the dread of you shall be upon every living being of the earth, and upon every winged being of the sky, upon all that moves upon the ground, and upon all the fish of the sea; into your hand they are given.

**9:3** "Every moving thing that lives shall be food for you; as with the green herb, I have given you all things.

**9:4** "But flesh with its life—נֶפֶשׁ (nephesh)—which is its blood, you shall not eat.

**9:5** "And surely your blood of your lives I will require; from every living being I will require it, and from the hand of humanity, from the hand of each person's brother, I will require the life of the human.

**9:6** "Whoever sheds human blood, by human shall their blood be shed; for in the image of Consciousness the human was made.

**9:7** "And you, be fruitful and multiply; swarm upon the earth and multiply in it."

**9:8** And Consciousness spoke unto Noah and unto his sons with him, saying:

**9:9** "And I, behold, I establish my covenant—בְּרִיתִי (beriti)—with you, and with your seed after you,

**9:10** "And with every living soul that is with you—of the winged beings, of the beasts, and of every living thing of the earth with you—from all that went out of the ark to every living thing of the earth.

**9:11** "And I establish my covenant with you: never again shall all flesh be cut off by the waters of the flood, and never again shall there be a flood to destroy the earth."

**9:12** And Consciousness said: "This is the sign of the covenant—אוֹת הַבְּרִית (ot ha-berit)—which I give between me and you and every living soul that is with you, for generations forever:

**9:13** "My bow—קַשְׁתִּי (qashti)—I have set in the cloud, and it shall be for a sign of covenant between me and the earth.

**9:14** "And it shall come to pass, when I bring clouds over the earth, and the bow is seen in the cloud,

**9:15** "That I will remember my covenant which is between me and you and every living soul in all flesh; and the waters shall never again become a flood to destroy all flesh.

**9:16** "And the bow shall be in the cloud, and I will see it, to remember the everlasting covenant—בְּרִית עוֹלָם (berit olam)—between Consciousness and every living soul in all flesh that is upon the earth."

**9:17** And Consciousness said unto Noah: "This is the sign of the covenant which I have established between me and all flesh that is upon the earth."

**9:18** And the sons of Noah who went forth from the ark were Shem, Ham, and Japheth; and Ham was the father of Canaan.

**9:19** These three were the sons of Noah, and from these the whole earth was populated.

**9:20** And Noah began to be a man of the ground, and he planted a vineyard.

**9:21** And he drank of the wine and became intoxicated, and he uncovered himself within his tent.

**9:22** And Ham, the father of Canaan, saw the nakedness of his father and told his two brothers outside.

**9:23** And Shem and Japheth took the garment and placed it upon both their shoulders, and walked backward and covered the nakedness of their father; and their faces were backward, and the nakedness of their father they did not see.

**9:24** And Noah awoke from his wine and knew what his youngest son had done to him.

**9:25** And he said: "Cursed is Canaan; a servant of servants shall he be unto his brothers."

**9:26** And he said: "Blessed is YHWH, the Consciousness of Shem; and Canaan shall be servant unto them.

**9:27** "Consciousness shall enlarge Japheth, and he shall dwell in the tents of Shem; and Canaan shall be servant unto them."

**9:28** And Noah lived after the flood three hundred and fifty years.

**9:29** And all the days of Noah were nine hundred and fifty years; and he transformed.

---

## Synthesis Notes

**Key Restorations:**

- **The new order includes violence**: Unlike Eden's fruit-eating, post-Flood humanity may eat flesh. But with limits: not blood (the nephesh/life), and human blood requires accounting. This is not ideal but realistic—Consciousness works with humanity as it is.

- *Qashti* (קַשְׁתִּי): "My bow"—the Hebrew word for rainbow is simply "bow" (as in weapon). Consciousness sets aside the war-bow in the sky, a symbol of laid-down violence. The warrior's bow becomes the sign of peace.

- *Berit olam* (בְּרִית עוֹלָם): The "everlasting covenant"—unconditional, not dependent on human behavior. This covenant includes **all living flesh**, not just humans. It is the first ecological covenant.

- **The covenant is for Consciousness's remembering**: "I will see it, to remember" (9:16). The rainbow is a reminder to Consciousness itself—a binding of divine action, a self-limitation.

**The Noah-and-Sons Narrative (9:20-27):**

This passage has been catastrophically misused to justify slavery and racism. The restored reading:

- Noah, the righteous survivor, becomes intoxicated—even the best of humanity struggles post-trauma. This is descriptive, not prescriptive.

- "Saw the nakedness of his father"—the Hebrew idiom often implies more than looking; some scholars suggest sexual violation or mockery. The text is ambiguous.

- **The curse falls on Canaan, not Ham**—this is later political polemic. The text was shaped by Israelites who would conquer Canaan; it justifies their conquest. This is the **power structure shaping the narrative** (historical-context lens).

- **The curse has no divine origin**: Noah speaks it, not YHWH. It is a father's angry pronouncement, not divine decree. The restoration recognizes: human curses do not carry divine authority.

- **This passage must not be used to justify hierarchy**: Per the meta-rule, "if an interpretation reinforces hierarchy, reapply inversion to restore balance."

**Archetypal Layer:** After the great transformation (Flood), new structures must be established. The rainbow-covenant represents the integration of the destructive flood experience into a new stability. But the human family immediately manifests dysfunction—the pattern of shame, voyeurism, and generational curse begins again. Renewal does not mean perfection.

**Psychological Reading:** Post-crisis, survivors often self-medicate (Noah's wine). Family systems carry trauma differently—some members expose vulnerability (Ham), others cover it (Shem, Japheth). The "curse" on Canaan represents how unprocessed trauma passes to grandchildren—the third generation carries the weight.

**Modern Equivalent:** The rainbow covenant is the promise of systemic stability despite human limitation. Climate will cycle, seasons will continue, catastrophic dissolution will not recur in the same way. But this does not mean human behavior is without consequence—violence still requires accounting, and family dysfunction propagates across generations unless consciously healed.

# Genesis Chapter 45: Joseph Reveals Himself

*From the Hebrew: The Unveiling*

---

**45:1** And Joseph could not restrain himself—וְלֹא־יָכֹל יוֹסֵף לְהִתְאַפֵּק (ve-lo-yachol Yosef le-hit'appeq)—before all who stood by him, and he cried: "Cause every man to go out from me!" And no man stood with him while Joseph made himself known unto his brothers.

**45:2** And he gave forth his voice in weeping—וַיִּתֵּן אֶת־קֹלוֹ בִּבְכִי (va-yitten et-qolo bi-vechi); and the Egyptians heard, and the house of Pharaoh heard.

**45:3** And Joseph said unto his brothers: "I am Joseph—אֲנִי יוֹסֵף (ani Yosef). Is my father yet alive?" And his brothers could not answer him, for they were terrified—נִבְהֲלוּ (nivhalu)—at his presence.

**45:4** And Joseph said unto his brothers: "Please come near unto me." And they came near. And he said: "I am Joseph your brother, whom you sold into Egypt.

**45:5** "And now, do not be grieved and do not be angry with yourselves—אַל־יִחַר בְּעֵינֵיכֶם (al-yichar be-eineichem)—that you sold me here; for Consciousness sent me before you to preserve life—לְמִחְיָה (le-michyah).

**45:6** "For these two years the famine has been in the land, and there are yet five years in which there shall be neither plowing nor harvest.

**45:7** "And Consciousness sent me before you to set for you a remnant—שְׁאֵרִית (she'erit)—in the earth, and to keep you alive by a great deliverance—לִפְלֵיטָה גְדֹלָה (li-fleitah gedolah).

**45:8** "So now it was not you who sent me here, but Consciousness; and Consciousness has made me a father to Pharaoh, and lord of all his house, and ruler over all the land of Egypt.

**45:9** "Hurry and go up to my father and say unto him: 'Thus says your son Joseph: Consciousness has made me lord of all Egypt; come down unto me, do not delay.

**45:10** "'And you shall dwell in the land of Goshen, and you shall be near unto me—you, and your children, and your children's children, and your flocks, and your herds, and all that you have.

**45:11** "'And I will sustain you there—for there are yet five years of famine—lest you and your household and all that you have come to poverty.'"

**45:12** "And behold, your eyes see, and the eyes of my brother Benjamin, that it is my mouth that speaks unto you.

**45:13** "And you shall tell my father of all my glory in Egypt, and of all that you have seen; and you shall hurry and bring my father down here."

**45:14** And he fell upon his brother Benjamin's neck and wept; and Benjamin wept upon his neck.

**45:15** And he kissed all his brothers and wept upon them; and after that his brothers spoke with him.

**45:16** And the report was heard in Pharaoh's house, saying: "Joseph's brothers have come." And it was good in the eyes of Pharaoh and in the eyes of his servants.

**45:17** And Pharaoh said unto Joseph: "Say unto your brothers: 'This do: load your beasts and go, enter into the land of Canaan.

**45:18** "'And take your father and your households and come unto me; and I will give you the good of the land of Egypt, and you shall eat the fat of the land.'

**45:19** "And you are commanded—this do: take for yourselves wagons from the land of Egypt for your little ones and for your wives, and bring your father and come.

**45:20** "And let not your eye spare your goods, for the good of all the land of Egypt is yours."

**45:21** And the sons of Israel did so; and Joseph gave them wagons according to the commandment of Pharaoh, and gave them provisions for the way.

**45:22** To each of them he gave changes of garments; but to Benjamin he gave three hundred pieces of silver and five changes of garments.

**45:23** And to his father he sent like this: ten donkeys laden with the good things of Egypt, and ten female donkeys laden with grain and bread and provisions for his father for the way.

**45:24** And he sent his brothers away, and they departed; and he said unto them: "Do not quarrel on the way—אַל־תִּרְגְּזוּ בַּדָּרֶךְ (al-tirgezu ba-derech)."

**45:25** And they went up out of Egypt and came into the land of Canaan unto Jacob their father.

**45:26** And they told him, saying: "Joseph is yet alive, and he is ruler over all the land of Egypt." And his heart grew numb—וַיָּפָג לִבּוֹ (va-yafag libbo)—for he did not believe them.

**45:27** And they spoke unto him all the words of Joseph which he had spoken unto them; and he saw the wagons which Joseph had sent to carry him; and the spirit of Jacob their father revived—וַתְּחִי רוּחַ יַעֲקֹב (va-techi ruach Ya'aqov).

**45:28** And Israel said: "Enough! Joseph my son is yet alive. I will go and see him before I die."

---

## Synthesis Notes

**Key Restorations:**

**"I Could Not Restrain Myself":**
The verb *hit'appeq* (הִתְאַפֵּק) appeared in 43:31 when Joseph "restrained himself." Now the dam breaks. Judah's plea has made continuation impossible. Joseph sends out all Egyptians—this is a family matter.

**The Weeping:**
Joseph's weeping is loud enough that "the Egyptians heard, and the house of Pharaoh heard." This is not private tears but a cry of release, grief, and joy mingled. Twenty years of separation, disguise, and testing collapse into this moment.

**"I Am Joseph" (אֲנִי יוֹסֵף):**
Three Hebrew words that change everything. The disguise dissolves. The brothers are "terrified" (*nivhalu*)—a word suggesting confusion, dismay, and fear. The one they sold is the one who holds their lives.

**"Is My Father Yet Alive?":**
Joseph has been asking about Jacob through the testing, but now he asks directly, with his own voice. The question is personal, urgent—he needs to know immediately.

**The Theological Interpretation:**

Joseph provides the interpretive framework:
- "You sold me" (factual acknowledgment of their action)
- "But Consciousness sent me" (divine purpose within human sin)
- "To preserve life" (the purpose was salvation)
- "It was not you but Consciousness" (divine agency superseding human agency)

This is **not erasure of their guilt** but interpretation of how divine purpose works through human action. The brothers acted freely and sinfully; Consciousness used their sin for preservation.

**Key Terms:**
- *Michyah* (מִחְיָה): "Preservation of life"—the purpose
- *She'erit* (שְׁאֵרִית): "Remnant"—what survives catastrophe
- *Fleitah* (פְלֵיטָה): "Deliverance/escape"—salvation from destruction

**"A Father to Pharaoh":**
An Egyptian honorific title for a high vizier. Joseph describes his position in Egyptian court language.

**The Embrace:**
Joseph embraces Benjamin first—his full brother, Rachel's son—then kisses all his brothers. "After that his brothers spoke with him"—only after the physical reconciliation can speech resume. They were too terrified to speak; the embrace releases them.

**Pharaoh's Generosity:**
Pharaoh himself invites Jacob's family:
- "The good of the land of Egypt" will be theirs
- Wagons provided for transport
- "Do not spare your goods"—leave everything behind, Egypt will provide

This hospitality is genuine (for now). The Exodus will invert it completely.

**Gifts:**
- Each brother: change of garments (they stripped Joseph; now he clothes them)
- Benjamin: 300 silver pieces and five changes (again, the favored one gets more—but the brothers don't resent it)
- Jacob: twenty donkeys with Egypt's finest goods

**"Do Not Quarrel on the Way":**
*Al-tirgezu* (אַל־תִּרְגְּזוּ): Could mean "do not be agitated/fearful" or "do not quarrel." Joseph knows his brothers—the journey home may produce blame, recrimination, anxiety. He urges peace.

**Jacob's Heart "Grew Numb":**
*Va-yafag libbo* (וַיָּפָג לִבּוֹ): His heart "fainted" or "grew cold"—shock, disbelief. For twenty years he believed Joseph dead. The news is too much to absorb.

**"The Spirit of Jacob Revived":**
Seeing the wagons—tangible evidence—brings him back. The text shifts from "Jacob" (the suffering old man) to "Israel" (the patriarch with purpose): "Enough! I will go and see him before I die."

**Archetypal Layer:** The revelation of the hidden savior, the reconciliation of the divided family, the transformation of betrayal into providence—these are universal patterns. Joseph is the wounded healer who uses his wound to save those who wounded him. The weeping and embracing enact the death of the old relationship and the birth of a new one.

**Psychological Reading:** Joseph's interpretation—"it was not you but Consciousness"—is a mature integration of trauma. He does not deny what they did, nor does he pretend it didn't hurt. But he finds meaning: their evil was metabolized into salvation. This is not immediate forgiveness but theological re-framing that makes continued relationship possible.

**Ethical Inversion Applied:**
- Traditional reading: Divine providence overrides human sin
- **Restored reading**: Both are real and remain in tension
- The brothers sold Joseph—that was their choice, their sin
- Consciousness worked through it—that was divine sovereignty
- Joseph's interpretation does not excuse the brothers; it contextualizes their action within a larger story
- Forgiveness is not erasure but integration

**Modern Equivalent:** Those who have been deeply wronged face the question: how to make meaning of it? Joseph's model is not "it wasn't so bad" or "I've forgotten" but "it was used for something greater." This requires the passage of time, the achievement of perspective, and willingness to re-enter relationship. Not everyone can do this; that Joseph can is his particular grace.

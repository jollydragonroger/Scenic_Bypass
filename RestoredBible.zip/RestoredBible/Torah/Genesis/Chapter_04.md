# Genesis Chapter 4: Cain, Abel, and the Birth of Civilization

*From the Hebrew: The First Generation of Conscious Humanity*

---

**4:1** And the human knew—יָדַע (yada)—Eve his partner; and she conceived and bore Cain—קַיִן (Qayin)—and said: "I have acquired—קָנִיתִי (qaniti)—a man with YHWH."

**4:2** And she continued to bear his brother Abel—הֶבֶל (Hevel), meaning "breath" or "vapor." And Abel became a keeper of flocks, and Cain became a worker of the ground.

**4:3** And in the course of time, Cain brought from the fruit of the ground an offering to YHWH.

**4:4** And Abel also brought from the firstborn of his flock and from their fat portions. And YHWH regarded—וַיִּשַׁע (va-yisha)—Abel and his offering;

**4:5** But to Cain and to his offering, YHWH did not regard. And Cain burned with intensity, and his countenance fell.

**4:6** And YHWH said unto Cain: "Why does this burn within you? And why has your countenance fallen?

**4:7** "Is it not so: if you do well—הֲלוֹא אִם־תֵּיטִיב (halo im-teitiv)—there is elevation; and if you do not do well, at the opening, a failure-impulse—חַטָּאת (chatat)—crouches; and toward you is its longing—תְּשׁוּקָה (teshuqah)—but you can master it—וְאַתָּה תִּמְשָׁל־בּוֹ (ve-atah timshol-bo)."

**4:8** And Cain spoke unto Abel his brother; and it came to pass when they were in the field, that Cain rose up against Abel his brother and killed him.

**4:9** And YHWH said unto Cain: "Where is Abel your brother?" And he said: "I do not know. Am I my brother's guardian?"

**4:10** And YHWH said: "What have you done? The voice of your brother's blood—דְּמֵי אָחִיךָ (demei achicha)—cries out unto me from the ground.

**4:11** "And now, you are more cursed than the ground which has opened its mouth to receive your brother's blood from your hand.

**4:12** "When you work the ground, it shall not continue to give its strength to you; a wanderer and a fugitive—נָע וָנָד (na va-nad)—shall you be in the earth."

**4:13** And Cain said unto YHWH: "My iniquity—עֲוֹנִי (avoni)—is greater than I can bear.

**4:14** "Behold, you have driven me out this day from the face of the ground; and from your presence I shall be hidden; and I shall be a wanderer and fugitive in the earth; and it shall come to pass that whoever finds me shall slay me."

**4:15** And YHWH said unto him: "Therefore, whoever slays Cain, vengeance shall be taken on him sevenfold." And YHWH set a mark—אוֹת (ot)—upon Cain, so that anyone finding him would not strike him.

**4:16** And Cain went out from the presence of YHWH, and dwelt in the land of Nod—נוֹד (Nod), meaning "wandering"—east of Eden.

**4:17** And Cain knew his partner, and she conceived and bore Enoch—חֲנוֹךְ (Chanoch), meaning "dedicated." And Cain was building a city, and he called the name of the city after the name of his son, Enoch.

**4:18** And to Enoch was born Irad; and Irad begot Mehujael; and Mehujael begot Methushael; and Methushael begot Lamech.

**4:19** And Lamech took for himself two partners: the name of one was Adah, and the name of the second was Zillah.

**4:20** And Adah bore Jabal; he was the father of those who dwell in tents and have livestock.

**4:21** And his brother's name was Jubal; he was the father of all who handle the lyre and pipe.

**4:22** And Zillah also bore Tubal-cain, an instructor of every craftsman in bronze and iron; and the sister of Tubal-cain was Naamah.

**4:23** And Lamech said unto his partners: "Adah and Zillah, hear my voice; partners of Lamech, give ear to my speech: For I have slain a man for wounding me, and a young man for bruising me.

**4:24** "If Cain shall be avenged sevenfold, then Lamech seventy-sevenfold."

**4:25** And the human knew his partner again; and she bore a son and called his name Seth—שֵׁת (Shet), meaning "appointed" or "placed"—for she said: "Consciousness has appointed for me another seed in place of Abel, whom Cain slew."

**4:26** And to Seth also was born a son; and he called his name Enosh—אֱנוֹשׁ (Enosh), meaning "mortal human." Then began the calling upon the name of YHWH.

---

## Synthesis Notes

**Key Restorations:**

- *Qayin/Cain* (קַיִן): From the root "to acquire" or "to forge"—the maker, the craftsman, the one who shapes. Cain represents the active, transformative principle in humanity.

- *Hevel/Abel* (הֶבֶל): Literally "breath," "vapor," "transience"—the same word used throughout Ecclesiastes ("vanity"). Abel represents the ephemeral, the pastoral, the contemplative mode that does not impose upon nature.

- **The rejected offering**: The text does not explain why YHWH regarded Abel's offering and not Cain's. Traditional interpretations invented moral reasons; the restored reading sees this as the arbitrary wound that initiates the human drama of perceived injustice and response.

- *Chatat* (חַטָּאת): Usually translated "sin"—but literally means "missing the mark," a failure-impulse that crouches like a predator. It is not a moral condemnation but a psychological reality: when we feel rejected, destructive impulses arise.

- **"You can master it"** (תִּמְשָׁל־בּוֹ): YHWH does not condemn Cain but coaches him. The capacity for mastery exists. The failure is not predetermined.

- *Ot* (אוֹת): The "mark of Cain"—not a curse but a **protection**. YHWH protects the murderer from vengeance, instituting the first limit on violence.

- **Cain builds the first city**: The murderer becomes the founder of civilization. This is not condemnation but acknowledgment—human civilization emerges from rupture, violence, and exile. The descendants of Cain create animal husbandry (Jabal), music (Jubal), and metallurgy (Tubal-cain).

- **Lamech's escalation**: From Cain's sevenfold protection to Lamech's seventy-sevenfold boast, violence escalates. This is descriptive, not prescriptive—showing how vengeance culture amplifies.

**Archetypal Layer:** Cain and Abel represent the fundamental split in human activity: cultivation/transformation (Cain) versus tending/receiving (Abel). The conflict between them is the tension between doing and being, making and accepting. When one polarity kills the other, wandering and exile result—but also civilization.

**Psychological Reading:** Abel is the "inner life" of contemplation that gets sacrificed to Cain's drive for achievement and recognition. When we kill our own capacity for being in pursuit of doing, we become wanderers—productive but rootless. The task is integration, not the elimination of either principle.

**Ethical Inversion:** Traditional reading: Cain is the villain, Abel the victim. Restored reading: Both brothers represent necessary human capacities. The tragedy is not that Cain was evil but that he could not contain his pain. YHWH's protection of Cain—the first restraint on retributive violence—is the moral center of the story.

**Modern Equivalent:** The birth of industrial civilization involved the "killing" of pastoral, contemplative modes of existence. We are the children of Cain, building cities, forging metal, making music—wandering east of Eden. The question is not whether to undo this but how to integrate what was lost.

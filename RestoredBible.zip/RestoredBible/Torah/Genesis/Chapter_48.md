# Genesis Chapter 48: Jacob Blesses Ephraim and Manasseh

*From the Hebrew: The Crossed Hands*

---

**48:1** And it came to pass after these things, that one said to Joseph: "Behold, your father is sick." And he took with him his two sons, Manasseh and Ephraim.

**48:2** And one told Jacob and said: "Behold, your son Joseph comes unto you." And Israel strengthened himself and sat upon the bed.

**48:3** And Jacob said unto Joseph: "El Shaddai appeared unto me at Luz in the land of Canaan, and blessed me.

**48:4** "And El Shaddai said unto me: 'Behold, I will make you fruitful and multiply you, and I will make of you a congregation of peoples—קְהַל עַמִּים (qehal ammim)—and will give this land to your seed after you for an everlasting possession.'

**48:5** "And now your two sons, who were born unto you in the land of Egypt before I came unto you into Egypt, are mine—אֶפְרַיִם וּמְנַשֶּׁה כִּרְאוּבֵן וְשִׁמְעוֹן יִהְיוּ־לִי (Efrayim u-Menasheh ki-Re'uven ve-Shim'on yihyu-li); Ephraim and Manasseh, as Reuben and Simeon, shall be mine.

**48:6** "And your offspring whom you beget after them shall be yours; by the name of their brothers they shall be called in their inheritance.

**48:7** "And as for me, when I came from Paddan, Rachel died unto me—מֵתָה עָלַי רָחֵל (metah alai Rachel)—in the land of Canaan on the way, when there was still some distance to come to Ephrath; and I buried her there on the way to Ephrath, which is Bethlehem."

**48:8** And Israel saw Joseph's sons and said: "Who are these?"

**48:9** And Joseph said unto his father: "They are my sons, whom Consciousness has given me here." And Jacob said: "Please bring them unto me, and I will bless them."

**48:10** And the eyes of Israel were heavy—כָּבְדוּ (kavedu)—from age; he could not see. And Joseph brought them near unto him; and he kissed them and embraced them.

**48:11** And Israel said unto Joseph: "I had not thought to see your face; and behold, Consciousness has shown me your seed also."

**48:12** And Joseph brought them out from between his knees, and he bowed with his face to the earth.

**48:13** And Joseph took them both—Ephraim in his right hand toward Israel's left, and Manasseh in his left hand toward Israel's right—and brought them near unto him.

**48:14** And Israel stretched out his right hand and laid it upon Ephraim's head, who was the younger, and his left hand upon Manasseh's head—guiding his hands knowingly—שִׂכֵּל אֶת־יָדָיו (sikkel et-yadav)—for Manasseh was the firstborn.

**48:15** And he blessed Joseph and said: "The Consciousness before whom my fathers Abraham and Isaac walked, the Consciousness who has been my shepherd—הָרֹעֶה אֹתִי (ha-ro'eh oti)—all my life unto this day,

**48:16** "The messenger who has redeemed me—הַמַּלְאָךְ הַגֹּאֵל אֹתִי (ha-malach ha-go'el oti)—from all evil, bless the lads; and let my name be named on them, and the name of my fathers Abraham and Isaac; and let them grow into a multitude—וְיִדְגּוּ לָרֹב (ve-yidgu la-rov)—in the midst of the earth."

**48:17** And Joseph saw that his father laid his right hand upon the head of Ephraim, and it was evil in his eyes; and he took hold of his father's hand to remove it from Ephraim's head unto Manasseh's head.

**48:18** And Joseph said unto his father: "Not so, my father, for this one is the firstborn; put your right hand upon his head."

**48:19** And his father refused and said: "I know, my son, I know. He also shall become a people, and he also shall be great; but his younger brother shall be greater than he, and his seed shall become a fullness of nations—מְלֹא־הַגּוֹיִם (melo-ha-goyim)."

**48:20** And he blessed them that day, saying: "By you shall Israel bless, saying: 'May Consciousness make you as Ephraim and as Manasseh.'" And he set Ephraim before Manasseh.

**48:21** And Israel said unto Joseph: "Behold, I am dying; and Consciousness will be with you and will bring you back unto the land of your fathers.

**48:22** "And I have given to you one portion—שְׁכֶם אַחַד (shechem echad)—above your brothers, which I took from the hand of the Amorite with my sword and with my bow."

---

## Synthesis Notes

**Key Restorations:**

**Adoption as Tribes:**
Jacob formally adopts Ephraim and Manasseh as his own sons—equal in status to Reuben and Simeon. This doubles Joseph's portion; he receives two tribal territories instead of one. The "birthright" of the firstborn (which Reuben lost through his transgression, 35:22) effectively passes to Joseph through his sons.

**The Memory of Rachel:**
In the middle of blessing Joseph's sons, Jacob speaks of Rachel's death. *Metah alai* (מֵתָה עָלַי)—"she died upon me"—the weight of loss still pressing on him decades later. He buried her by the road, not in Machpelah. The grief is unfinished.

**"Who Are These?":**
Jacob's eyes are dim (like Isaac's before blessing). He cannot see clearly. But unlike Isaac, who was deceived, Jacob acts knowingly—*sikkel et-yadav* (שִׂכֵּל אֶת־יָדָיו), "he guided his hands with wisdom/understanding."

**The Crossed Hands:**
Joseph carefully positions his sons—Manasseh (firstborn) toward Jacob's right hand, Ephraim (younger) toward the left. But Jacob deliberately crosses his arms, placing his right hand (the hand of power and blessing) on the younger son's head.

The pattern repeats: younger over elder (Isaac over Ishmael, Jacob over Esau, now Ephraim over Manasseh). The divine choosing consistently inverts human expectation.

**The Threefold Blessing (48:15-16):**

Jacob invokes three aspects of the divine:
1. "The Consciousness before whom my fathers walked"—the God of Abraham and Isaac
2. "The Consciousness who has been my shepherd"—the God who guided him personally
3. "The messenger who has redeemed me"—the angel who protected and delivered

This is remarkable trinitarian-like formulation—Consciousness, Shepherd, Redeeming Messenger—unified in blessing.

**"Let Them Grow Like Fish" (וְיִדְגּוּ):**
From דָּג (dag), "fish." Fish multiply abundantly and invisibly, beneath the surface. The blessing is for unseen, prolific growth.

**Joseph's Protest:**
Joseph, the dream-interpreter who understood divine reversals, objects to his father's crossing of hands. Even Joseph expects the natural order. But Jacob knows: "I know, my son, I know."

**"A Fullness of Nations" (מְלֹא־הַגּוֹיִם):**
Ephraim's descendants will become *melo-ha-goyim*—a "fullness of nations." This phrase appears later in Paul's writings (Romans 11:25) regarding the inclusion of Gentiles. The blessing anticipates abundance beyond tribal boundaries.

**Shechem:**
Jacob gives Joseph "one *shechem* above your brothers." The word *shechem* means both "shoulder" (portion) and refers to the city Shechem. The reference to "sword and bow" is puzzling—Jacob's sons took Shechem by violence (Chapter 34), but Jacob expressed horror at that. Perhaps this refers to a different tradition of conquest, or Jacob retrospectively claims what his sons won.

**Archetypal Layer:** The blind patriarch blessing with crossed hands enacts the mystery of divine election—the reversal of natural order, the choosing of the younger, the wisdom that sees what eyes cannot. Jacob becomes Isaac (old, blind, blessing) but with full awareness rather than deception.

**Psychological Reading:** Jacob, who supplanted Esau, now deliberately enacts supplanting of the firstborn. He has internalized the pattern not as sin but as divine way. What he once stole, he now bestows—the preference for the younger is no longer his grasping but his vision.

**Ethical Inversion Applied:**
- Traditional reading: Divine election overrides birth order
- **Restored reading**: The pattern is consistent but never explained
- Why does God prefer the younger? The text never says
- The pattern may critique primogeniture (eldest inherits all)
- It may assert divine freedom against human assumption
- It may reflect historical reality (Ephraim became dominant over Manasseh)
- The mystery remains

**Modern Equivalent:** Institutions often assume the first, the eldest, the original has priority. The biblical pattern consistently subverts this—the younger, the later, the unexpected receives the blessing. This is not automatic (not every younger is chosen) but possible. Birth order is not destiny.

# Genesis Chapter 42: The Brothers Come to Egypt

*From the Hebrew: The First Encounter*

---

**42:1** And Jacob saw that there was grain in Egypt; and Jacob said unto his sons: "Why do you look at one another?"

**42:2** And he said: "Behold, I have heard that there is grain in Egypt; go down there and buy for us from there, that we may live and not die."

**42:3** And Joseph's ten brothers went down to buy grain from Egypt.

**42:4** But Benjamin, Joseph's brother, Jacob did not send with his brothers; for he said: "Lest harm befall him—פֶּן־יִקְרָאֶנּוּ אָסוֹן (pen-yiqra'ennu ason)."

**42:5** And the sons of Israel came to buy among those that came, for the famine was in the land of Canaan.

**42:6** And Joseph was the governor over the land; he was the one who sold to all the people of the land. And Joseph's brothers came and bowed down to him with their faces to the earth.

**42:7** And Joseph saw his brothers and recognized them, but he made himself a stranger—וַיִּתְנַכֵּר (va-yitnakker)—unto them and spoke harshly—קָשׁוֹת (qashot)—with them; and he said unto them: "From where do you come?" And they said: "From the land of Canaan to buy food."

**42:8** And Joseph recognized his brothers, but they did not recognize him.

**42:9** And Joseph remembered the dreams which he had dreamed about them, and said unto them: "You are spies—מְרַגְּלִים (meraggelim)! You have come to see the nakedness of the land—עֶרְוַת הָאָרֶץ (ervat ha-arets)!"

**42:10** And they said unto him: "No, my lord, but your servants have come to buy food.

**42:11** "We are all sons of one man; we are honest—כֵּנִים (kenim); your servants are not spies."

**42:12** And he said unto them: "No, but you have come to see the nakedness of the land."

**42:13** And they said: "Your servants are twelve brothers, the sons of one man in the land of Canaan; and behold, the youngest is with our father today, and one is no more—וְהָאֶחָד אֵינֶנּוּ (ve-ha-echad einennu)."

**42:14** And Joseph said unto them: "It is as I spoke unto you, saying: 'You are spies.'

**42:15** "By this you shall be tested: by the life of Pharaoh, you shall not go forth from here unless your youngest brother comes here.

**42:16** "Send one of you and let him fetch your brother, and you shall be bound, that your words may be tested, whether there is truth in you; or else, by the life of Pharaoh, surely you are spies."

**42:17** And he put them together into custody—מִשְׁמָר (mishmar)—for three days.

**42:18** And Joseph said unto them on the third day: "This do and live, for I fear Consciousness—אֶת־הָאֱלֹהִים אֲנִי יָרֵא (et-ha-Elohim ani yare):

**42:19** "If you are honest, let one of your brothers be bound in the house of your custody; and you, go and carry grain for the famine of your houses.

**42:20** "But bring your youngest brother unto me, and your words shall be verified, and you shall not die." And they did so.

**42:21** And they said to one another: "Truly we are guilty—אֲשֵׁמִים (ashemim)—concerning our brother, in that we saw the distress of his soul—צָרַת נַפְשׁוֹ (tsarat nafsho)—when he pleaded with us, and we did not listen. Therefore this distress has come upon us."

**42:22** And Reuben answered them, saying: "Did I not speak unto you, saying, 'Do not sin against the child'? But you did not listen. And also his blood—behold, it is required—נִדְרָשׁ (nidrash)."

**42:23** And they did not know that Joseph understood, for the interpreter was between them.

**42:24** And he turned away from them and wept; and he returned to them and spoke with them, and took from them Simeon—שִׁמְעוֹן (Shim'on)—and bound him before their eyes.

**42:25** And Joseph commanded that their vessels be filled with grain, and that each man's money be restored to his sack, and that provisions be given them for the way; and thus it was done for them.

**42:26** And they loaded their donkeys with their grain and departed from there.

**42:27** And one of them opened his sack to give his donkey fodder at the lodging place, and he saw his money; and behold, it was in the mouth of his sack.

**42:28** And he said unto his brothers: "My money has been restored! And behold, it is in my sack!" And their hearts went out—וַיֵּצֵא לִבָּם (va-yetse libbam)—and they trembled to one another, saying: "What is this that Consciousness has done unto us?"

**42:29** And they came unto Jacob their father unto the land of Canaan, and told him all that had befallen them, saying:

**42:30** "The man, the lord of the land, spoke harshly with us and took us for spies of the land.

**42:31** "And we said unto him: 'We are honest; we are not spies.

**42:32** "'We are twelve brothers, sons of our father; one is no more, and the youngest is today with our father in the land of Canaan.'

**42:33** "And the man, the lord of the land, said unto us: 'By this I shall know that you are honest: leave one of your brothers with me, and take for the famine of your houses and go.

**42:34** "'And bring your youngest brother unto me; then I shall know that you are not spies but that you are honest; I will give you your brother, and you shall trade in the land.'"

**42:35** And it came to pass as they emptied their sacks, that behold, every man's bundle of money was in his sack; and they saw their bundles of money, they and their father, and they were afraid.

**42:36** And Jacob their father said unto them: "You have bereaved me—אֹתִי שִׁכַּלְתֶּם (oti shikkalttem): Joseph is no more, and Simeon is no more, and Benjamin you would take! Upon me are all these things!"

**42:37** And Reuben spoke unto his father, saying: "My two sons you may put to death if I do not bring him back to you. Give him into my hand, and I will return him unto you."

**42:38** And Jacob said: "My son shall not go down with you, for his brother is dead and he alone remains. If harm should befall him on the way upon which you go, then you would bring down my gray hairs in sorrow to Sheol."

---

## Synthesis Notes

**Key Restorations:**

**The Bowing:**
"Joseph's brothers came and bowed down to him with their faces to the earth." The dream of the sheaves (37:7) is fulfilled—the brothers bow before Joseph without knowing him.

**Recognition and Disguise:**
Joseph recognizes them immediately; they do not recognize him. Twenty years have passed; he was 17 when sold, now 30+ as vizier. He has Egyptian dress, Egyptian name, speaks through interpreters. The power differential is absolute.

**"He Made Himself a Stranger":**
*Va-yitnakker* (וַיִּתְנַכֵּר): From the root נָכַר (nakar), "to recognize" with reflexive form meaning "to make oneself unrecognizable" or "to act like a stranger." Joseph's disguise is deliberate performance.

**The Spy Accusation:**
Why does Joseph accuse them? Possible motives:
- Testing their character—have they changed?
- Protecting Benjamin—if they sold one favored son, would they sell another?
- Emotional complexity—working through trauma
- Information gathering—learning about his father and brother

**"One Is No More" (וְהָאֶחָד אֵינֶנּוּ):**
The brothers' description of Joseph. They believe him dead—or at least gone forever. Joseph hears himself erased.

**The Confession (42:21):**
Unprompted, the brothers confess to one another—in Joseph's hearing:
- "We are guilty concerning our brother"
- "We saw the distress of his soul when he pleaded with us"
- "We did not listen"

This is new information: Joseph pleaded; they ignored his cries. The trauma is named. Joseph hears his brothers' guilt and memory.

**Reuben's "I Told You So":**
Reuben reminds them of his objection (37:21-22). "His blood is required"—they interpret their current distress as divine retribution. They experience their treatment by the vizier as consequence of their sin against Joseph.

**Joseph Weeps:**
He turns away to weep—the first of seven times Joseph weeps in the narrative. His emotional response is real, even as his actions remain disguised.

**Why Simeon?**
Joseph binds Simeon specifically. Simeon was the second-oldest after Reuben (who tried to save Joseph). Perhaps Simeon was a leader in the violence? Or simply available as hostage after Reuben's partial exoneration?

**The Restored Money:**
Joseph secretly returns their money. This creates terror, not gratitude—they fear accusation of theft. The gift feels like a trap.

**"What Has God Done to Us?":**
The brothers interpret everything as divine action. Their guilty consciences make every event judgment.

**Jacob's Grief:**
"You have bereaved me!" Jacob accuses his sons of causing his losses:
- Joseph is no more
- Simeon is no more (held hostage)
- Benjamin you would take

He does not know the truth, but his accusation is accurate—they did bereave him of Joseph.

**Reuben's Desperate Offer:**
"Kill my two sons if I don't return Benjamin." This is extreme, impractical—Jacob would never kill his grandchildren. It shows desperation but not wisdom. Jacob refuses.

**"He Alone Remains":**
Jacob calls Benjamin the only remaining son of Rachel. Joseph is presumed dead. The favoritism continues—the sons of Rachel are still privileged in Jacob's heart.

**Archetypal Layer:** The disguised ruler testing those who harmed him is a universal motif. Joseph's elaborate process forces the brothers to confront their guilt, to speak of their crime, to experience helplessness and fear of death. The test is not arbitrary cruelty but structured moral reckoning.

**Psychological Reading:** Joseph cannot simply reveal himself—the trauma is too deep, the relationship too broken. The disguise creates space for the brothers to reveal who they have become. Their spontaneous confession indicates conscience is alive. But the test is not complete—Benjamin must be involved to see if they would abandon another favored son.

**Ethical Inversion Applied:**
- Traditional reading: Joseph tests the brothers righteously
- **Restored reading**: The testing is also Joseph's processing
- He has power now; he uses it to control and observe
- The brothers suffer genuine fear and deprivation
- Whether Joseph's methods are "right" or traumatic repetition is ambiguous
- The process leads to reconciliation, but the means are manipulative

**Modern Equivalent:** Those who were victimized, when they gain power, face choices about how to relate to their victimizers. Joseph's elaborate testing is neither simple revenge nor simple forgiveness. It is a process—perhaps necessary, perhaps excessive—of working through what was done.

# Genesis Chapter 29: Jacob, Rachel, and Leah

*From the Hebrew: The Deceiver Deceived*

---

**29:1** And Jacob lifted up his feet and went to the land of the people of the east.

**29:2** And he looked, and behold, a well in the field; and behold, three flocks of sheep lying beside it, for out of that well they watered the flocks; and the stone upon the mouth of the well was great.

**29:3** And all the flocks would be gathered there, and they would roll the stone from the mouth of the well and water the sheep, and put the stone back upon the mouth of the well in its place.

**29:4** And Jacob said unto them: "My brothers, where are you from?" And they said: "We are from Haran."

**29:5** And he said unto them: "Do you know Laban the son of Nahor?" And they said: "We know him."

**29:6** And he said unto them: "Is it well with him?" And they said: "It is well; and behold, Rachel his daughter is coming with the sheep."

**29:7** And he said: "Behold, the day is still high; it is not time for the livestock to be gathered; water the sheep and go pasture them."

**29:8** And they said: "We cannot, until all the flocks are gathered together; then they roll the stone from the mouth of the well, and we water the sheep."

**29:9** While he was still speaking with them, Rachel came with her father's sheep, for she was a shepherdess.

**29:10** And it came to pass, when Jacob saw Rachel the daughter of Laban his mother's brother, and the sheep of Laban his mother's brother, that Jacob went near and rolled the stone from the mouth of the well and watered the flock of Laban his mother's brother.

**29:11** And Jacob kissed Rachel and lifted up his voice and wept.

**29:12** And Jacob told Rachel that he was a kinsman of her father, and that he was the son of Rebekah; and she ran and told her father.

**29:13** And it came to pass, when Laban heard the report of Jacob his sister's son, that he ran to meet him, and embraced him and kissed him and brought him to his house. And Jacob told Laban all these things.

**29:14** And Laban said to him: "Surely you are my bone and my flesh." And he stayed with him a month of days.

---

**29:15** And Laban said unto Jacob: "Because you are my kinsman, should you therefore serve me for nothing? Tell me, what shall your wages be?"

**29:16** And Laban had two daughters: the name of the elder was Leah—לֵאָה (Le'ah)—and the name of the younger was Rachel—רָחֵל (Rachel).

**29:17** And Leah's eyes were weak—רַכּוֹת (rakkot); but Rachel was beautiful in form and beautiful in appearance.

**29:18** And Jacob loved Rachel; and he said: "I will serve you seven years for Rachel your younger daughter."

**29:19** And Laban said: "It is better that I give her to you than that I should give her to another man; stay with me."

**29:20** And Jacob served for Rachel seven years; and they were in his eyes as but a few days—כְּיָמִים אֲחָדִים (ke-yamim achadim)—because of his love for her.

**29:21** And Jacob said unto Laban: "Give me my wife, for my days are fulfilled, that I may go in unto her."

**29:22** And Laban gathered all the men of the place and made a feast.

**29:23** And it came to pass in the evening that he took Leah his daughter and brought her unto Jacob; and he went in unto her.

**29:24** And Laban gave Zilpah his maidservant unto Leah his daughter as a maidservant.

**29:25** And it came to pass in the morning, and behold, it was Leah! And Jacob said to Laban: "What is this you have done to me? Did I not serve with you for Rachel? Why then have you deceived me—לָמָּה רִמִּיתָנִי (lamah rimmitani)?"

**29:26** And Laban said: "It is not done so in our place, to give the younger before the firstborn.

**29:27** "Fulfill the week of this one, and we will give you the other one also for the service which you shall serve with me yet another seven years."

**29:28** And Jacob did so and fulfilled her week; and Laban gave him Rachel his daughter to be his wife.

**29:29** And Laban gave to Rachel his daughter Bilhah his maidservant, to be her maidservant.

**29:30** And Jacob also went in unto Rachel, and he also loved Rachel more than Leah; and he served with Laban yet another seven years.

---

**29:31** And YHWH saw that Leah was unloved—שְׂנוּאָה (senu'ah), literally "hated"—and opened her womb; but Rachel was barren.

**29:32** And Leah conceived and bore a son, and she called his name Reuben—רְאוּבֵן (Re'uven)—for she said: "Because YHWH has seen—רָאָה (ra'ah)—my affliction; for now my husband will love me."

**29:33** And she conceived again and bore a son, and said: "Because YHWH has heard—שָׁמַע (shama)—that I am unloved, and has given me this one also." And she called his name Simeon—שִׁמְעוֹן (Shim'on).

**29:34** And she conceived again and bore a son, and said: "Now this time my husband will be joined—יִלָּוֶה (yillaveh)—unto me, for I have borne him three sons." Therefore she called his name Levi—לֵוִי (Levi).

**29:35** And she conceived again and bore a son, and said: "This time I will praise—אוֹדֶה (odeh)—YHWH." Therefore she called his name Judah—יְהוּדָה (Yehudah). And she ceased bearing.

---

## Synthesis Notes

**Key Restorations:**

**The Well Scene:**
Like Abraham's servant finding Rebekah (ch. 24), Jacob meets his future wife at a well. But this time Jacob is the active hero—he single-handedly rolls away the stone that normally requires multiple shepherds.

**Jacob's Emotion:**
He kisses Rachel and weeps. This is raw emotion—relief at finding family, attraction, the end of solitary flight. The text does not hide the patriarch's tears.

**Laban's Character:**
Notice that Laban ran to meet Jacob when he "heard the report" (29:13)—just as he ran when he saw the servant's jewelry (24:30). Laban's hospitality has calculation behind it.

**The Two Sisters:**

- *Le'ah* (לֵאָה): Possibly "weary" or "cow"—unflattering. Her eyes are *rakkot*—"soft" or "weak" or "tender"—the meaning is debated. Perhaps lacking sparkle, perhaps diseased, perhaps simply gentle.
- *Rachel* (רָחֵל): "Ewe"—both sisters have animal names. She is described as beautiful in form and face.

**Seven Years "Like a Few Days":**
Jacob's love transforms his perception of time. This is one of the Bible's most romantic statements.

**The Deceiver Deceived:**

The supreme irony: Jacob, who disguised himself as Esau to steal the blessing, is now given Leah disguised as Rachel. He cries out: "Why have you deceived me?" (רִמִּיתָנִי)

Laban's justification: "It is not done in our place to give the younger before the firstborn." The man who supplanted his elder brother is now subject to the rights of the firstborn.

**The Poetic Justice is Precise:**
- Jacob deceived his blind father through disguise; he is deceived in the darkness of the wedding night
- He stole the firstborn's blessing; he receives the firstborn daughter he didn't want
- He used goatskins to pretend to be hairy Esau; Leah uses veils/darkness to pretend to be Rachel

**Leah the Unloved:**

*Senu'ah* (שְׂנוּאָה)—"hated" is strong, but it means "less loved," the unfavored wife. YHWH sees her condition and opens her womb. The unloved wife bears sons; the beloved wife is barren.

**The Sons' Names Tell the Story:**

- *Reuben* (רְאוּבֵן): "See, a son" or "He has seen my affliction"—Leah's hope that a son will earn love
- *Simeon* (שִׁמְעוֹן): "Hearing"—YHWH has heard that she is unloved
- *Levi* (לֵוִי): "Joining"—now surely her husband will be joined to her
- *Judah* (יְהוּדָה): "Praise"—finally, she stops seeking Jacob's love and simply praises YHWH

The progression: affliction → hearing → hope of connection → praise. Leah's spiritual journey through the names.

**Archetypal Layer:** The beloved (Rachel) and the unloved (Leah) are the two wives—a triangle of desire, duty, and fertility. The deceiver experiences his own methods turned against him. The well, which was a place of meeting and promise, becomes the site where Jacob enters a system (Laban's household) that will manipulate him as he manipulated others.

**Psychological Reading:** Jacob's shadow (his own deceptiveness) is mirrored back to him through Laban. What we do to others returns to us. The unloved Leah represents the rejected aspect that nonetheless proves fertile. The beloved Rachel remains barren—desire and fulfillment do not align simply.

**Ethical Inversion Applied:**
- Traditional readings focus on Jacob's love for Rachel as romantic
- **Restored reading**: Leah is the moral center of suffering
- Her children's names are a record of unmet longing
- YHWH's opening of her womb is divine attention to the overlooked
- The "hated" wife becomes the mother of Levi (priests) and Judah (kings)

**Modern Equivalent:** What goes around comes around. Those who deceive are deceived. And in the complex systems of relationship (marriages, families, organizations), those who are overlooked may prove to be the most generative. Leah's journey from seeking human love to offering divine praise is the transformation available to the unfavored.

# Genesis Chapter 16: Hagar and Ishmael

*From the Hebrew: The Egyptian Woman and the God Who Sees*

---

**16:1** Now Sarai, Abram's partner, had borne him no children; and she had an Egyptian maidservant whose name was Hagar—הָגָר (Hagar).

**16:2** And Sarai said unto Abram: "Behold now, YHWH has restrained me from bearing; please go in unto my maidservant; perhaps I shall be built up—אִבָּנֶה (ibbaneh)—through her." And Abram listened to the voice of Sarai.

**16:3** And Sarai, Abram's partner, took Hagar the Egyptian, her maidservant—after Abram had dwelt ten years in the land of Canaan—and gave her to Abram her husband to be his woman.

**16:4** And he went in unto Hagar, and she conceived; and when she saw that she had conceived, her mistress was diminished in her eyes—וַתֵּקַל גְּבִרְתָּהּ בְּעֵינֶיהָ (va-teqal gevirtah be-eineiha).

**16:5** And Sarai said unto Abram: "My wrong is upon you! I gave my maidservant into your embrace; and when she saw that she had conceived, I was diminished in her eyes. YHWH judge between me and you!"

**16:6** And Abram said unto Sarai: "Behold, your maidservant is in your hand; do to her what is good in your eyes." And Sarai afflicted her—וַתְּעַנֶּהָ (va-te'anneha)—and she fled from before her.

**16:7** And the messenger of YHWH—מַלְאַךְ יהוה (malach YHWH)—found her by a spring of water in the wilderness, by the spring on the way to Shur.

**16:8** And the messenger said: "Hagar, maidservant of Sarai, from where have you come and where are you going?" And she said: "From before Sarai my mistress I am fleeing."

**16:9** And the messenger of YHWH said unto her: "Return to your mistress and submit yourself under her hands."

**16:10** And the messenger of YHWH said unto her: "I will greatly multiply your seed, and it shall not be counted for multitude."

**16:11** And the messenger of YHWH said unto her: "Behold, you are pregnant and shall bear a son; and you shall call his name Ishmael—יִשְׁמָעֵאל (Yishma'el)—because YHWH has heard—שָׁמַע (shama)—your affliction.

**16:12** "And he shall be a wild donkey of a man—פֶּרֶא אָדָם (pere adam); his hand against everyone and everyone's hand against him; and before the face of all his brothers he shall dwell."

**16:13** And she called the name of YHWH who spoke to her: "You are El Roi—אֵל רֳאִי (El Ro'i)"—for she said: "Have I also here seen after the one who sees me?—הֲגַם הֲלֹם רָאִיתִי אַחֲרֵי רֹאִי (ha-gam halom ra'iti acharei ro'i)."

**16:14** Therefore the well was called Beer-lahai-roi—בְּאֵר לַחַי רֹאִי (Be'er Lachai Ro'i), "Well of the Living One Who Sees Me"; behold, it is between Kadesh and Bered.

**16:15** And Hagar bore Abram a son; and Abram called the name of his son, whom Hagar bore, Ishmael.

**16:16** And Abram was eighty-six years old when Hagar bore Ishmael to Abram.

---

## Synthesis Notes

**Key Restorations:**

- *Hagar* (הָגָר): Possibly meaning "stranger" or "flight"—an Egyptian woman, enslaved, given as property. She has no voice in the arrangement.

- *Ibbaneh* (אִבָּנֶה): "I shall be built up"—from the root בָּנָה (banah), "to build," also related to בֵּן (ben), "son." Sarai seeks to build her house through Hagar's body. This is legal in ancient Near Eastern custom but morally complex.

- **The power dynamics**: Sarai initiates; Abram complies; Hagar has no recorded consent. When Hagar conceives, the power relation shifts—she has what Sarai lacks—and contempt enters.

- *Va-te'anneha* (וַתְּעַנֶּהָ): "Afflicted her"—the same root (עָנָה, anah) used for Israel's affliction in Egypt (15:13). **Sarai afflicts Hagar the Egyptian as Egypt will later afflict Sarai's descendants.** The text does not hide this irony.

- **Abram's passivity**: "Your maidservant is in your hand"—he abandons Hagar to Sarai's abuse. The father of faith refuses responsibility for his actions.

**Hagar's Theophany — Remarkable:**

- Hagar is the **first person in Scripture to receive a visit from the malach YHWH** (messenger/angel of YHWH)
- She is the **only person in Scripture to name God**: El Roi, "God Who Sees"
- She is an enslaved Egyptian woman—the marginalized of the marginalized
- YHWH hears her affliction (the meaning of Ishmael) and sees her (her naming of God)

**The troubling instruction**: "Return to your mistress and submit"—this has been used to justify submission to abuse. The restored reading recognizes:
- The text records the instruction without endorsing it as universal principle
- Hagar's return ensures her son's legal status and inheritance claim
- The promise attached (seed multiplication) empowers her return
- **The agent who names God and receives promise is the moral center**

- *Pere adam* (פֶּרֶא אָדָם): "Wild donkey of a man"—the wild ass is free, untameable, dwelling in the wilderness. This is **not an insult** but a description of fierce independence. Ishmael's descendants will not be domesticated by empire.

- *El Ro'i* (אֵל רֳאִי): "God Who Sees"—Hagar's theology emerges from her experience. The God she names is the one who sees the invisible, hears the unheard, meets the fugitive in the wilderness.

- *Be'er Lachai Ro'i* (בְּאֵר לַחַי רֹאִי): "Well of the Living One Who Sees Me"—this site becomes sacred, marking the place where the enslaved woman encountered the divine. It will appear again in Genesis (24:62, 25:11).

**Archetypal Layer:** Hagar represents the shadow side of the promise—what is used and discarded to build the chosen lineage. But YHWH meets her precisely in her marginalization. The well in the wilderness is the unexpected source of life; the God who sees is found by those whom society makes invisible.

**Ethical Inversion Applied:**
- Traditional reading often centers Sarai and Abram, treating Hagar as instrument
- **Restored reading centers Hagar**: She is the one who receives theophany, names God, and carries promise
- Ishmael is not the rejected son but the **first son**, blessed with multitude, fierce and free
- The later rivalry between descendants does not erase the original blessing

**Psychological Reading:** The household contains Sarai (the legitimate but barren), Hagar (the fertile but enslaved), and Abram (passive between them). The triangle generates projection, contempt, and violence. Hagar's flight is the escape of the used part of the psyche; her return, with divine witness, is integration rather than elimination.

**Modern Equivalent:** The systems we build to achieve our goals often exploit the vulnerable. When they resist or flee, we may pursue or afflict. But the God who sees meets the fugitive in the wilderness. Those whom we instrumentalize carry their own blessing and become ancestors of nations. The well they name remains sacred.

# Genesis Chapter 46: Jacob's Journey to Egypt

*From the Hebrew: The Descent*

---

**46:1** And Israel journeyed with all that he had, and came to Beer-sheba, and offered sacrifices unto the Consciousness of his father Isaac.

**46:2** And Consciousness spoke unto Israel in the visions of the night, and said: "Jacob! Jacob!" And he said: "Here I am—הִנֵּנִי (hineni)."

**46:3** And Consciousness said: "I am the Consciousness—הָאֵל (ha-El)—the Consciousness of your father. Do not fear to go down to Egypt, for I will make you into a great nation there.

**46:4** "I will go down with you to Egypt, and I will also surely bring you up again; and Joseph shall put his hand upon your eyes."

**46:5** And Jacob rose up from Beer-sheba; and the sons of Israel carried Jacob their father, and their little ones, and their wives, in the wagons which Pharaoh had sent to carry him.

**46:6** And they took their livestock and their possessions which they had acquired in the land of Canaan, and came into Egypt—Jacob and all his seed with him:

**46:7** His sons and his sons' sons with him, his daughters and his sons' daughters, and all his seed he brought with him into Egypt.

---

**46:8** And these are the names of the children of Israel who came into Egypt—Jacob and his sons: Reuben, Jacob's firstborn.

**46:9** And the sons of Reuben: Hanoch and Pallu and Hezron and Carmi.

**46:10** And the sons of Simeon: Jemuel and Jamin and Ohad and Jachin and Zohar, and Shaul the son of a Canaanite woman.

**46:11** And the sons of Levi: Gershon, Kohath, and Merari.

**46:12** And the sons of Judah: Er and Onan and Shelah and Perez and Zerah—but Er and Onan died in the land of Canaan. And the sons of Perez were Hezron and Hamul.

**46:13** And the sons of Issachar: Tola and Puvah and Iob and Shimron.

**46:14** And the sons of Zebulun: Sered and Elon and Jahleel.

**46:15** These are the sons of Leah, whom she bore unto Jacob in Paddan-aram, with Dinah his daughter; all the souls of his sons and his daughters were thirty-three.

**46:16** And the sons of Gad: Ziphion and Haggi, Shuni and Ezbon, Eri and Arodi and Areli.

**46:17** And the sons of Asher: Imnah and Ishvah and Ishvi and Beriah, and Serah their sister. And the sons of Beriah: Heber and Malchiel.

**46:18** These are the sons of Zilpah, whom Laban gave to Leah his daughter; and she bore these unto Jacob—sixteen souls.

**46:19** The sons of Rachel, Jacob's wife: Joseph and Benjamin.

**46:20** And unto Joseph in the land of Egypt were born Manasseh and Ephraim, whom Asenath the daughter of Poti-phera priest of On bore unto him.

**46:21** And the sons of Benjamin: Bela and Becher and Ashbel, Gera and Naaman, Ehi and Rosh, Muppim and Huppim and Ard.

**46:22** These are the sons of Rachel who were born to Jacob—fourteen souls in all.

**46:23** And the sons of Dan: Hushim.

**46:24** And the sons of Naphtali: Jahzeel and Guni and Jezer and Shillem.

**46:25** These are the sons of Bilhah, whom Laban gave unto Rachel his daughter; and she bore these unto Jacob—seven souls in all.

**46:26** All the souls that came with Jacob into Egypt, who came out of his body, besides Jacob's sons' wives—sixty-six souls in all.

**46:27** And the sons of Joseph who were born to him in Egypt were two souls. All the souls of the house of Jacob who came into Egypt were seventy—שִׁבְעִים (shiv'im).

---

**46:28** And he sent Judah before him unto Joseph, to direct the way before him unto Goshen; and they came into the land of Goshen.

**46:29** And Joseph made ready his chariot and went up to meet Israel his father at Goshen; and he appeared unto him, and fell on his neck, and wept on his neck a long time—וַיֵּבְךְּ עַל־צַוָּארָיו עוֹד (va-yevk al-tsavvarav od).

**46:30** And Israel said unto Joseph: "Now let me die, since I have seen your face, that you are yet alive."

**46:31** And Joseph said unto his brothers and unto his father's house: "I will go up and tell Pharaoh, and will say unto him: 'My brothers and my father's house, who were in the land of Canaan, have come unto me.

**46:32** "'And the men are shepherds of flocks, for they have been keepers of livestock; and they have brought their flocks and their herds and all that they have.'

**46:33** "And it shall come to pass, when Pharaoh calls you and says, 'What is your occupation?'

**46:34** "That you shall say, 'Your servants have been keepers of livestock from our youth even until now, both we and our fathers'—in order that you may dwell in the land of Goshen; for every shepherd is an abomination to the Egyptians—תּוֹעֲבַת מִצְרַיִם (to'avat Mitsrayim)."

---

## Synthesis Notes

**Key Restorations:**

**Beer-sheba:**
Jacob stops at Beer-sheba—the southern boundary of the promised land, where his father Isaac had lived (26:23-25). This is threshold territory, the edge of departure. He offers sacrifices to "the Consciousness of his father Isaac"—honoring the chain of transmission.

**The Night Vision:**
Consciousness speaks to "Israel" (not "Jacob")—the covenantal name. The double call "Jacob! Jacob!" echoes Abraham at the Aqedah (22:11) and Moses at the burning bush (Exodus 3:4). Jacob responds with "Hineni" (Here I am)—the same readiness.

**The Promise:**
- "Do not fear to go down to Egypt"—acknowledging the fear
- "I will make you into a great nation there"—the promise continues in exile
- "I will go down with you"—divine accompaniment
- "I will bring you up again"—promise of return (fulfilled in Exodus)
- "Joseph shall put his hand upon your eyes"—Joseph will be present at Jacob's death, closing his eyes (a child's duty to a parent)

**The Seventy:**
The genealogy lists seventy descendants who enter Egypt. Seventy is a significant number—the traditional number of nations in the world (Genesis 10), the elders who will later ascend Sinai (Exodus 24:1). Israel enters Egypt as a microcosm of humanity.

**The Genealogical List:**
- Leah's line: 33 (including Dinah)
- Zilpah's line: 16
- Rachel's line: 14 (including Joseph and his sons already in Egypt)
- Bilhah's line: 7
- Total: 70

Note: The numbers don't add perfectly; some count Jacob himself, others include those who died (Er, Onan) for completeness. The total of seventy is the theological point.

**"Shaul the Son of a Canaanite Woman":**
Simeon's son by a Canaanite—evidence that the patriarchal prohibition against Canaanite marriage was not universally followed. The text records without commentary.

**Judah Sent Ahead:**
Judah—now the leader among the brothers—goes first to prepare the way to Goshen. His transformation from Chapter 37 (selling Joseph) to Chapter 44 (offering himself) to Chapter 46 (leading the family) is complete.

**The Reunion:**
"He fell on his neck and wept on his neck a long time"—the Hebrew *od* (עוֹד) means "more" or "still"—Joseph kept weeping. This is the release of twenty-two years of separation.

**"Now Let Me Die":**
Jacob's statement is not suicidal but complete: "I have seen your face... Now I can die fulfilled." His purpose extends to death, not beyond this moment. Seeing Joseph alive is enough.

**The Occupation Strategy:**
Joseph coaches his family: identify as shepherds. This seems counterintuitive since "every shepherd is an abomination to the Egyptians." But this ensures they will be settled in Goshen—separate from Egyptian population centers—maintaining their identity. The Egyptian prejudice against shepherds becomes the mechanism of Israel's preservation as a distinct people.

**Archetypal Layer:** The descent to Egypt is the descent into the "belly of the whale"—the foreign land where the family will become a nation. The promise of return ("I will bring you up") makes this descent a stage, not a destination. The seventy who go down will become the multitude who come up.

**Psychological Reading:** Jacob's willingness to descend to Egypt requires divine reassurance. He has lost Rachel, believed he lost Joseph, and now must leave the promised land. The vision provides what he needs: accompaniment ("I will go down with you") and promise of closure ("Joseph shall put his hand upon your eyes"). He can surrender now.

**Historical-Context Lens:** The movement of Semitic peoples into Egypt during famines is historically attested. The Hyksos period saw significant Semitic presence in Egypt. The genealogy anchors the tribes to specific ancestors, establishing identity claims for later times.

**Modern Equivalent:** Sometimes we must leave the promised land—the place of calling and identity—for survival. The question is whether identity can be maintained in exile. Joseph's strategy (use Egyptian prejudice to ensure separation) is a minority survival technique: let them exclude us, and we'll remain ourselves. Diaspora identity is formed in this tension.

# Genesis Chapter 50: Jacob's Burial and Joseph's Death

*From the Hebrew: The End of the Beginning*

---

**50:1** And Joseph fell upon his father's face, and wept upon him, and kissed him.

**50:2** And Joseph commanded his servants the physicians to embalm his father; and the physicians embalmed Israel.

**50:3** And forty days were fulfilled for him, for so are fulfilled the days of embalming; and the Egyptians wept for him seventy days.

**50:4** And when the days of weeping for him were past, Joseph spoke unto the house of Pharaoh, saying: "If now I have found favor in your eyes, please speak in the ears of Pharaoh, saying:

**50:5** "'My father made me swear, saying: "Behold, I am dying; in my grave which I have dug for myself in the land of Canaan, there shall you bury me." Now therefore, please let me go up and bury my father, and I will return.'"

**50:6** And Pharaoh said: "Go up and bury your father, as he made you swear."

**50:7** And Joseph went up to bury his father; and with him went up all the servants of Pharaoh, the elders of his house, and all the elders of the land of Egypt,

**50:8** And all the house of Joseph, and his brothers, and his father's house; only their little ones and their flocks and their herds they left in the land of Goshen.

**50:9** And there went up with him both chariots and horsemen; and it was a very great company—מַחֲנֶה כָּבֵד מְאֹד (machaneh kaved me'od).

**50:10** And they came to the threshing floor of Atad, which is beyond the Jordan; and there they mourned with a very great and heavy lamentation; and he made a mourning for his father seven days.

**50:11** And when the inhabitants of the land, the Canaanites, saw the mourning at the threshing floor of Atad, they said: "This is a grievous mourning for Egypt—אֵבֶל כָּבֵד זֶה לְמִצְרָיִם (evel kaved zeh le-Mitsrayim)." Therefore its name was called Abel-mizraim—אָבֵל מִצְרַיִם (Avel Mitsrayim), "Mourning of Egypt"—which is beyond the Jordan.

**50:12** And his sons did unto him as he had commanded them.

**50:13** And his sons carried him into the land of Canaan, and buried him in the cave of the field of Machpelah, which Abraham bought with the field for a possession of a burial place from Ephron the Hittite, before Mamre.

**50:14** And Joseph returned into Egypt—he, and his brothers, and all that went up with him to bury his father—after he had buried his father.

---

**50:15** And Joseph's brothers saw that their father was dead, and they said: "Perhaps Joseph will hate us—יִשְׂטְמֵנוּ (yistemenu)—and will fully repay us all the evil which we did unto him."

**50:16** And they sent a message unto Joseph, saying: "Your father commanded before he died, saying:

**50:17** "'Thus shall you say unto Joseph: "Please forgive—שָׂא נָא (sa na)—the transgression of your brothers and their sin, for they did evil unto you."' And now, please forgive the transgression of the servants of the Consciousness of your father." And Joseph wept when they spoke unto him.

**50:18** And his brothers also went and fell down before him; and they said: "Behold, we are your servants."

**50:19** And Joseph said unto them: "Fear not; for am I in the place of Consciousness—הֲתַחַת אֱלֹהִים אָנִי (ha-tachat Elohim ani)?

**50:20** "And as for you, you meant evil against me—חֲשַׁבְתֶּם עָלַי רָעָה (chashavtem alai ra'ah)—but Consciousness meant it for good—וֵאלֹהִים חֲשָׁבָהּ לְטֹבָה (v'Elohim chashavah le-tovah)—in order to bring about, as it is this day, to keep alive a great people.

**50:21** "And now fear not; I will sustain you and your little ones." And he comforted them and spoke to their hearts.

---

**50:22** And Joseph dwelt in Egypt—he and his father's house; and Joseph lived one hundred and ten years.

**50:23** And Joseph saw Ephraim's children of the third generation; also the children of Machir the son of Manasseh were born upon Joseph's knees.

**50:24** And Joseph said unto his brothers: "I am dying; and Consciousness will surely visit you—פָּקֹד יִפְקֹד אֱלֹהִים אֶתְכֶם (paqod yifqod Elohim etchem)—and will bring you up out of this land unto the land which was sworn unto Abraham, unto Isaac, and unto Jacob."

**50:25** And Joseph made the children of Israel swear, saying: "Consciousness will surely visit you, and you shall carry up my bones from here."

**50:26** And Joseph died, being one hundred and ten years old; and they embalmed him, and he was put in a coffin in Egypt.

---

## Synthesis Notes

**Key Restorations:**

**Egyptian Mourning:**
Forty days for embalming, seventy days of mourning—Egyptian royal protocol. Israel/Jacob receives the treatment of an Egyptian dignitary. Joseph's position ensures his father is honored by the empire.

**The Funeral Procession:**
A massive company—all Pharaoh's servants, elders of Egypt, chariots and horsemen. This is a state funeral. The Canaanites observe and name the place "Mourning of Egypt"—foreigners mourning in their land.

**The Return to Canaan:**
Jacob's body is carried to Machpelah as promised. He joins Abraham, Sarah, Isaac, Rebekah, and Leah in the family tomb. The promised land receives his bones even though he died in Egypt.

**The Brothers' Fear:**
With Jacob dead, the brothers fear Joseph will finally take revenge. Their question reveals they never fully believed in his forgiveness—or they project their own capacity for grudge onto him. Perhaps Jacob's presence had been restraining Joseph?

**The Fabricated Message:**
The brothers claim Jacob left a final command for Joseph to forgive them. There is no record of Jacob actually saying this. They may be inventing it out of fear. Or Jacob may have spoken it privately. The text leaves the question open.

**"Am I in the Place of God?":**
Joseph refuses the role of judge: "Am I in the place of Consciousness?" He will not usurp divine prerogative. Judgment belongs to God; Joseph's role is different.

**The Theological Summary (50:20):**

This verse is the interpretive key to the entire Joseph narrative:

- *Chashavtem alai ra'ah* (חֲשַׁבְתֶּם עָלַי רָעָה): "You meant/planned evil against me"—their intention was genuinely evil
- *V'Elohim chashavah le-tovah* (וֵאלֹהִים חֲשָׁבָהּ לְטֹבָה): "But Consciousness meant/planned it for good"—divine intention was genuinely good
- *Le-hachayot am rav* (לְהַחֲיֹת עַם־רָב): "To keep alive a great people"—the purpose: preservation of life

Both intentions are real. The brothers' evil was not an illusion; God's good purpose was not erasure of the evil. They coexist. Divine providence does not excuse human sin but transforms its outcome.

**Joseph's Comfort:**
He speaks "to their hearts" (אֶל־לִבָּם, el-libbam)—the same phrase used of courtship and comfort. He reassures them with action (sustaining them) not just words.

**Joseph's Death:**
He lives to 110—the Egyptian ideal lifespan (as 120 was for Israel). He sees great-grandchildren. He dies fulfilled.

**The Final Prophecy:**
"Consciousness will surely visit you"—פָּקֹד יִפְקֹד (paqod yifqod)—the doubled verb emphasizes certainty. This phrase will be the recognition sign in Exodus (3:16; 4:31). Moses will use these words to authenticate his mission.

**The Bones:**
Joseph makes Israel swear to carry his bones when they leave Egypt. He will not be buried in Machpelah but will travel with the Exodus. His bones are finally buried at Shechem (Joshua 24:32)—the portion Jacob gave him (48:22).

**The Coffin in Egypt:**
Genesis ends with Joseph in a coffin in Egypt. The book that began with creation, with life, with "it was good," ends with death in a foreign land. But the coffin contains promise—the bones await the visitation.

**Archetypal Layer:** The death of the patriarch(s) marks the end of the ancestral age. What was family becomes nation. The bones in the coffin are seed planted for Exodus. Genesis is prelude; the story continues.

**Psychological Reading:** Joseph's response models post-traumatic integration. He acknowledges the evil done to him (no minimization), recognizes divine purpose working through it (meaning-making), refuses the role of judge (releasing the need for revenge), and commits to ongoing relationship (sustaining the brothers). This is mature forgiveness—not forgetting, not pretending, but transforming.

**Ethical Inversion Applied:**
- "You meant evil... God meant good"—both are true simultaneously
- Human agency and divine sovereignty coexist without canceling each other
- The brothers are not excused; they are forgiven
- Forgiveness does not require pretending the harm didn't happen
- Joseph becomes the model of gracious power—having the ability to harm, choosing to sustain

**The End of Genesis:**
The book ends with Israel in Egypt, Joseph in a coffin, and a promise of visitation. The setup for Exodus is complete. A new king will arise who did not know Joseph (Exodus 1:8), and the children of Israel will multiply, and the system Joseph built will enslave them. But the bones wait, and the visitation will come.

---

## Synthesis Notes for the Book of Genesis

Genesis traces the arc from creation to coffin:
- Chapters 1-11: Primeval history—creation, fall, flood, Babel
- Chapters 12-25: Abraham cycle—call, covenant, near-sacrifice, death
- Chapters 25-36: Jacob cycle—rivalry, exile, wrestling, return
- Chapters 37-50: Joseph cycle—dreams, descent, deliverance, death

The themes interweave:
- **Election and reversal**: The younger over the elder, consistently
- **Promise and delay**: Land promised but not possessed; descendants promised but endangered
- **Deception and consequence**: Jacob deceives and is deceived; patterns repeat across generations
- **Divine presence in exile**: God meets Jacob at Bethel, accompanies Joseph in prison, promises to go down to Egypt with Israel
- **Death and continuation**: Each patriarch dies; the promise continues through death into the next generation

Genesis ends not with arrival but with anticipation. The land is not yet inherited. The people are not yet free. The bones await their journey. Everything is incomplete—and therefore everything is still possible.

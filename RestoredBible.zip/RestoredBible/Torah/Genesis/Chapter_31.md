# Genesis Chapter 31: Jacob's Flight from Laban

*From the Hebrew: The Departure and Pursuit*

---

**31:1** And Jacob heard the words of Laban's sons, saying: "Jacob has taken all that belonged to our father, and from what belonged to our father he has made all this wealth—הַכָּבֹד (ha-kavod)."

**31:2** And Jacob saw the face of Laban, and behold, it was not toward him as before.

**31:3** And YHWH said unto Jacob: "Return to the land of your fathers and to your kindred, and I will be with you."

**31:4** And Jacob sent and called Rachel and Leah to the field, to his flock,

**31:5** And said unto them: "I see your father's face, that it is not toward me as before; but the Consciousness of my father has been with me.

**31:6** "And you know that with all my strength I have served your father.

**31:7** "And your father has cheated me and changed my wages ten times; but Consciousness did not allow him to harm me.

**31:8** "If he said, 'The speckled shall be your wages,' then all the flock bore speckled; and if he said, 'The striped shall be your wages,' then all the flock bore striped.

**31:9** "Thus Consciousness has taken away the livestock of your father and given them to me.

**31:10** "And it came to pass at the time the flock conceived, that I lifted up my eyes and saw in a dream, and behold, the rams that leaped upon the flock were striped, speckled, and spotted.

**31:11** "And the messenger of Consciousness said unto me in the dream, 'Jacob!' And I said, 'Here I am.'

**31:12** "And the messenger said, 'Lift up now your eyes and see: all the rams that leap upon the flock are striped, speckled, and spotted; for I have seen all that Laban is doing to you.

**31:13** "'I am the Consciousness of Bethel, where you anointed the pillar, where you vowed a vow unto me. Now arise, get out from this land, and return to the land of your kindred.'"

**31:14** And Rachel and Leah answered and said unto him: "Is there yet any portion or inheritance for us in our father's house?

**31:15** "Are we not counted by him as foreigners? For he has sold us, and has also completely consumed our money.

**31:16** "For all the wealth which Consciousness has taken from our father belongs to us and to our children. Now then, whatever Consciousness has said unto you, do."

**31:17** And Jacob rose up and set his sons and his wives upon the camels.

**31:18** And he drove away all his livestock and all his possessions which he had acquired, the livestock of his acquiring which he had acquired in Paddan-aram, to go to Isaac his father in the land of Canaan.

**31:19** And Laban had gone to shear his sheep; and Rachel stole the teraphim—הַתְּרָפִים (ha-teraphim)—that belonged to her father.

**31:20** And Jacob deceived—וַיִּגְנֹב (va-yignov), "stole"—the heart of Laban the Aramean, in that he did not tell him that he was fleeing.

**31:21** And he fled with all that he had; and he rose up and crossed over the River, and set his face toward the hill country of Gilead.

**31:22** And it was told Laban on the third day that Jacob had fled.

**31:23** And he took his kinsmen with him and pursued after him seven days' journey; and he overtook him in the hill country of Gilead.

**31:24** And Consciousness came to Laban the Aramean in a dream of the night and said unto him: "Guard yourself lest you speak to Jacob either good or bad."

**31:25** And Laban overtook Jacob. And Jacob had pitched his tent in the hill country; and Laban with his kinsmen pitched in the hill country of Gilead.

**31:26** And Laban said to Jacob: "What have you done, that you have stolen my heart, and carried away my daughters as captives of the sword?

**31:27** "Why did you flee secretly, and steal away from me, and did not tell me? I would have sent you away with joy and with songs, with timbrel and with lyre.

**31:28** "And you did not allow me to kiss my sons and my daughters. Now you have done foolishly.

**31:29** "It is in the power of my hand to do you harm; but the Consciousness of your father spoke unto me last night, saying, 'Guard yourself from speaking to Jacob either good or bad.'

**31:30** "And now, you have surely gone because you longed greatly for your father's house; but why did you steal my gods?"

**31:31** And Jacob answered and said to Laban: "Because I was afraid, for I said, 'Lest you tear your daughters from me.'

**31:32** "With whomever you find your gods, that one shall not live. Before our kinsmen, identify for yourself what is with me, and take it." For Jacob did not know that Rachel had stolen them.

**31:33** And Laban went into Jacob's tent, and into Leah's tent, and into the tent of the two maidservants, but he did not find them. And he went out of Leah's tent and entered into Rachel's tent.

**31:34** And Rachel had taken the teraphim and put them in the camel's saddle, and sat upon them. And Laban searched all the tent but did not find them.

**31:35** And she said to her father: "Let it not be displeasing in the eyes of my lord that I cannot rise before you, for the way of women is upon me—דֶּרֶךְ נָשִׁים (derech nashim)." And he searched but did not find the teraphim.

**31:36** And Jacob was angry and quarreled with Laban; and Jacob answered and said to Laban: "What is my transgression? What is my sin, that you have hotly pursued me?

**31:37** "Though you have searched through all my goods, what have you found of all your household goods? Set it here before my kinsmen and your kinsmen, that they may judge between us two.

**31:38** "These twenty years I have been with you; your ewes and your female goats have not miscarried, and the rams of your flock I have not eaten.

**31:39** "That which was torn by beasts I did not bring to you; I bore the loss of it. From my hand you required it, whether stolen by day or stolen by night.

**31:40** "Thus I was: in the day the drought consumed me, and the frost by night; and my sleep fled from my eyes.

**31:41** "These twenty years I have been in your house; I served you fourteen years for your two daughters, and six years for your flock; and you changed my wages ten times.

**31:42** "Except the Consciousness of my father, the Consciousness of Abraham, and the Fear of Isaac—פַּחַד יִצְחָק (Pachad Yitschaq)—had been with me, surely now you would have sent me away empty. Consciousness has seen my affliction and the labor of my hands, and rebuked you last night."

**31:43** And Laban answered and said unto Jacob: "The daughters are my daughters, and the children are my children, and the flock is my flock, and all that you see is mine. And to my daughters, what can I do to them today, or to their children whom they have borne?

**31:44** "Now therefore, come, let us cut a covenant, you and I; and let it be for a witness between me and you."

**31:45** And Jacob took a stone and set it up as a pillar.

**31:46** And Jacob said to his kinsmen: "Gather stones." And they took stones and made a heap; and they ate there upon the heap.

**31:47** And Laban called it Jegar-sahadutha—יְגַר שָׂהֲדוּתָא (Aramaic: "Heap of Witness")—and Jacob called it Galeed—גַּלְעֵד (Hebrew: "Heap of Witness").

**31:48** And Laban said: "This heap is a witness between me and you today." Therefore its name was called Galeed,

**31:49** And Mizpah—הַמִּצְפָּה (Ha-Mitspah), "The Watchtower"—for Laban said: "May YHWH watch—יִצֶף (yitsef)—between me and you when we are hidden from one another.

**31:50** "If you afflict my daughters, or if you take wives besides my daughters, no man is with us; see, Consciousness is witness between me and you."

**31:51** And Laban said to Jacob: "Behold this heap, and behold the pillar which I have set between me and you.

**31:52** "This heap is witness, and the pillar is witness, that I will not pass over this heap to you, and you will not pass over this heap and this pillar unto me, for harm.

**31:53** "The Consciousness of Abraham and the Consciousness of Nahor, the Consciousness of their father, shall judge between us." And Jacob swore by the Fear of Isaac his father.

**31:54** And Jacob slaughtered a sacrifice on the mountain and called his kinsmen to eat bread; and they ate bread and lodged on the mountain.

**31:55** And Laban rose up early in the morning and kissed his sons and his daughters and blessed them; and Laban departed and returned to his place.

---

## Synthesis Notes

**Key Restorations:**

**The Revelation of Divine Action:**
Jacob reveals (31:10-12) that his success with the flocks was not merely clever technique but divinely directed. The dream showed him what to do; Consciousness orchestrated the breeding. His human cunning worked within divine purpose.

**"The God of Bethel":**
Consciousness identifies as "the Consciousness of Bethel"—the God of the ladder-dream, the God of the vow. The promise of return (28:15) is now being fulfilled.

**Rachel and Leah Unite:**
For once, the rival sisters speak together and agree: their father has treated them as foreigners, sold them, consumed their bride-price. They have no inheritance in Laban's house. Their loyalty shifts to Jacob.

**The Teraphim (הַתְּרָפִים):**
Household gods, probably small figurines used for divination and inheritance claims. Rachel steals them—why?
- For protection on the journey?
- To claim inheritance rights?
- To deprive her father of his gods?
- To transition from his religion to YHWH worship?

The text doesn't explain her motive. She hides them under her and claims menstruation prevents her from rising—using a bodily taboo to protect the theft.

**Jacob's Unwitting Death Sentence:**
"With whomever you find your gods, that one shall not live." Jacob unknowingly condemns Rachel. Some interpreters connect this to Rachel's death in childbirth (35:18).

**Jacob's Defense (31:36-42):**
A powerful speech of self-justification:
- Twenty years of faithful service
- No animals lost without payment
- Exposure to heat and cold
- Sleep deprivation
- Wages changed ten times
- Only divine protection prevented total exploitation

**"The Fear of Isaac" (פַּחַד יִצְחָק, Pachad Yitschaq):**
A unique divine title—either "the one whom Isaac fears" or "the Dread/Terror of Isaac." It appears only here and in 31:53. It suggests the numinous dread Isaac experienced at Moriah.

**The Bilingual Cairn:**
Laban names the heap in Aramaic (יְגַר שָׂהֲדוּתָא); Jacob names it in Hebrew (גַּלְעֵד). Same meaning, two languages—marking the boundary between peoples and tongues.

**The Mizpah "Blessing":**
"May YHWH watch between us when we are hidden from one another" sounds beautiful but is actually a threat: may God watch you because I don't trust you. This is a covenant of mutual suspicion, not affection.

**Archetypal Layer:** The flight from the devouring father-in-law, the pursuit, the confrontation, and the boundary covenant—this is the pattern of individuation from an engulfing system. Jacob must separate from Laban (as he separated from Isaac and Esau) to become himself. The heap of stones marks the threshold between phases of life.

**Psychological Reading:** Twenty years with Laban has been Jacob's education in receiving what he once gave. He deceived; he was deceived. He supplanted; he was exploited. Now, having been on the receiving end, he departs with his family, his wealth, and his grievances. The boundary covenant ensures he will not return.

**Modern Equivalent:** Leaving a toxic system (family, workplace, relationship) often involves pursuit, accusation, and finally a boundary-setting negotiation. The Mizpah covenant is the uncomfortable agreement between parties who don't trust each other but must disentangle. "May God watch between us" = "I'm watching you, and God had better be too."

# Genesis Chapter 30: The Birth of the Tribes

*From the Hebrew: The Fertility Competition*

---

**30:1** And Rachel saw that she bore Jacob no children; and Rachel envied her sister and said unto Jacob: "Give me children, or else I die!"

**30:2** And Jacob's anger burned against Rachel, and he said: "Am I in the place of Consciousness, who has withheld from you the fruit of the womb?"

**30:3** And she said: "Behold, my maidservant Bilhah; go in unto her, that she may bear upon my knees, and I also may be built up—אִבָּנֶה (ibbaneh)—through her."

**30:4** And she gave him Bilhah her maidservant as a wife; and Jacob went in unto her.

**30:5** And Bilhah conceived and bore Jacob a son.

**30:6** And Rachel said: "Consciousness has judged me—דָּנַנִּי (dananni)—and has also heard my voice, and has given me a son." Therefore she called his name Dan—דָּן (Dan).

**30:7** And Bilhah, Rachel's maidservant, conceived again and bore Jacob a second son.

**30:8** And Rachel said: "With wrestlings of God—נַפְתּוּלֵי אֱלֹהִים (naftulei Elohim)—have I wrestled with my sister, and have prevailed." And she called his name Naphtali—נַפְתָּלִי (Naftali).

**30:9** And Leah saw that she had ceased bearing, and she took Zilpah her maidservant and gave her to Jacob as a wife.

**30:10** And Zilpah, Leah's maidservant, bore Jacob a son.

**30:11** And Leah said: "Fortune has come!—בָּא גָד (ba gad)." And she called his name Gad—גָּד (Gad).

**30:12** And Zilpah, Leah's maidservant, bore Jacob a second son.

**30:13** And Leah said: "In my happiness!—בְּאָשְׁרִי (be-oshri)—for the daughters will call me happy." And she called his name Asher—אָשֵׁר (Asher).

**30:14** And Reuben went in the days of wheat harvest and found mandrakes—דּוּדָאִים (duda'im)—in the field and brought them unto his mother Leah. And Rachel said to Leah: "Please give me some of your son's mandrakes."

**30:15** And Leah said unto her: "Is it a small matter that you have taken away my husband? And would you take away my son's mandrakes also?" And Rachel said: "Therefore he shall lie with you tonight for your son's mandrakes."

**30:16** And Jacob came from the field in the evening, and Leah went out to meet him and said: "Unto me you shall come, for I have surely hired you—שָׂכֹר שְׂכַרְתִּיךָ (sachor secharticha)—with my son's mandrakes." And he lay with her that night.

**30:17** And Consciousness heard Leah, and she conceived and bore Jacob a fifth son.

**30:18** And Leah said: "Consciousness has given me my wages—שְׂכָרִי (sechari)—because I gave my maidservant to my husband." And she called his name Issachar—יִשָּׂשכָר (Yissachar).

**30:19** And Leah conceived again and bore Jacob a sixth son.

**30:20** And Leah said: "Consciousness has endowed me with a good endowment—זֶבֶד טוֹב (zeved tov); now my husband will dwell with me—יִזְבְּלֵנִי (yizbeleni)—for I have borne him six sons." And she called his name Zebulun—זְבֻלוּן (Zevulun).

**30:21** And afterwards she bore a daughter, and called her name Dinah—דִּינָה (Dinah).

**30:22** And Consciousness remembered Rachel, and Consciousness heard her and opened her womb.

**30:23** And she conceived and bore a son, and said: "Consciousness has taken away—אָסַף (asaf)—my reproach."

**30:24** And she called his name Joseph—יוֹסֵף (Yosef)—saying: "May YHWH add—יֹסֵף (yosef)—to me another son."

---

**30:25** And it came to pass, when Rachel had borne Joseph, that Jacob said unto Laban: "Send me away, that I may go unto my own place and to my land.

**30:26** "Give me my wives and my children for whom I have served you, and let me go; for you know my service with which I have served you."

**30:27** And Laban said unto him: "If now I have found favor in your eyes—I have learned by divination—נִחַשְׁתִּי (nichashti)—that YHWH has blessed me because of you."

**30:28** And he said: "Name your wages—נְקָבָה שְׂכָרְךָ (noqvah secharecha)—and I will give it."

**30:29** And Jacob said unto him: "You know how I have served you, and how your livestock has fared with me.

**30:30** "For it was little which you had before I came, and it has increased unto a multitude; and YHWH has blessed you wherever I turned. And now, when shall I provide for my own house also?"

**30:31** And Laban said: "What shall I give you?" And Jacob said: "You shall not give me anything. If you will do this thing for me, I will again pasture and keep your flock:

**30:32** "Let me pass through all your flock today, removing from there every speckled and spotted sheep, and every dark-colored sheep among the lambs, and the spotted and speckled among the goats; and these shall be my wages.

**30:33** "So shall my righteousness answer for me in the day to come, when you come to look upon my wages: every one that is not speckled and spotted among the goats and dark among the lambs, that is found with me, shall be counted as stolen."

**30:34** And Laban said: "Behold, let it be according to your word."

**30:35** And he removed that day the male goats that were striped and spotted, and all the female goats that were speckled and spotted, every one that had white in it, and all the dark ones among the lambs, and gave them into the hand of his sons.

**30:36** And he set three days' journey between himself and Jacob; and Jacob pastured the rest of Laban's flock.

**30:37** And Jacob took for himself rods of fresh poplar, and of almond, and of plane tree, and peeled white streaks in them, exposing the white which was in the rods.

**30:38** And he set the rods which he had peeled in the troughs, in the watering channels where the flocks came to drink, opposite the flocks; and they would conceive when they came to drink.

**30:39** And the flocks conceived before the rods, and the flocks brought forth streaked, speckled, and spotted.

**30:40** And Jacob separated the lambs, and set the faces of the flocks toward the streaked and all the dark in the flock of Laban; and he put his own droves apart and did not put them with Laban's flock.

**30:41** And it came to pass, whenever the stronger of the flock conceived, that Jacob would set the rods before the eyes of the flock in the troughs, that they might conceive among the rods.

**30:42** But when the flock was feeble, he would not set them; so the feebler were Laban's and the stronger Jacob's.

**30:43** And the man increased exceedingly and had large flocks, and female servants and male servants, and camels and donkeys.

---

## Synthesis Notes

**Key Restorations:**

**The Fertility Competition:**

The household becomes a battleground of reproduction. Rachel and Leah compete through their own bodies and through their maidservants, producing twelve sons (and one named daughter) who become the tribes of Israel.

**The Children's Names (continued):**

- *Dan* (דָּן): "He judged"—Rachel feels vindicated
- *Naphtali* (נַפְתָּלִי): "My wrestling"—the sisters' struggle
- *Gad* (גָּד): "Fortune"—luck has arrived
- *Asher* (אָשֵׁר): "Happy"—Leah celebrates
- *Issachar* (יִשָּׂשכָר): "Wages"—hired with mandrakes
- *Zebulun* (זְבֻלוּן): "Dwelling"—hoping Jacob will now live with her
- *Dinah* (דִּינָה): "Judgment"—the only daughter named
- *Joseph* (יוֹסֵף): "May He add"—Rachel's first biological son, with prayer for another

**The Mandrakes (דּוּדָאִים, duda'im):**
A plant believed to promote fertility and love (related to דּוֹד, "beloved"). Rachel trades a night with Jacob for them—yet it is Leah who conceives. The "fertility drug" doesn't work for Rachel; Consciousness works independently of magic.

**"I Have Hired You":**
Leah must purchase access to her own husband with mandrakes. The degradation of the marriage is complete—Jacob is currency between the sisters.

**"Consciousness Remembered Rachel":**
Finally, Rachel conceives. The verb "remembered" (זָכַר, zachar) signals divine attention turning toward her, as it did toward Noah (8:1) and Hannah (1 Samuel 1:19).

**Laban's Divination:**
*Nichashti* (נִחַשְׁתִּי)—from the root for "serpent" (נָחָשׁ), meaning divination or observing omens. Laban uses pagan practices to discern that Jacob brings blessing.

**The Flock Arrangement:**
Jacob proposes taking only the unusual animals (speckled, spotted, dark)—which should be rare. Laban immediately cheats by removing all such animals first. Jacob responds with his own cunning.

**The Striped Rods:**
Ancient animal husbandry belief held that what animals saw at conception influenced offspring. Jacob's rod-peeling is folk magic or psychological manipulation of the flock—but 31:10-12 will reveal divine intervention. The text allows both readings.

**Jacob's Selection:**
He breeds the strong animals to be spotted (his) and leaves the weak ones solid-colored (Laban's). The deceiver is now deceiving his deceiving father-in-law.

**Archetypal Layer:** The household of four women bearing children is the origin-matrix of a nation. The competition, the jealousy, the maidservant surrogacy—all the dysfunction produces the twelve tribes. Consciousness works through the mess, not despite it.

**Psychological Reading:** Rachel's cry—"Give me children or I die!"—is the desperation of unfulfilled longing. Leah's repeated naming pattern shows a woman seeking love through achievement. Neither sister has what she most wants: Rachel has love but no children; Leah has children but no love.

**Ethical Complexity:**
- The maidservants (Bilhah, Zilpah) have no recorded consent
- Jacob is passive, going where directed by the wives
- The flock manipulation is deceptive, even if justified by Laban's prior cheating
- The text describes without endorsing

**Modern Equivalent:** Families are complicated. Fertility, jealousy, and competition shape relationships in ways that produce both trauma and legacy. The tribes of Israel—the entire people—emerge from this dysfunction. Nations are not born from perfect families but from real ones.

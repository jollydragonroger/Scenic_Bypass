# Genesis Chapter 27: The Stolen Blessing

*From the Hebrew: Jacob's Deception of Isaac*

---

**27:1** And it came to pass when Isaac was old and his eyes were dim so that he could not see, that he called Esau his elder son and said unto him: "My son." And he said unto him: "Here I am."

**27:2** And Isaac said: "Behold now, I am old; I know not the day of my death.

**27:3** "Now therefore take, please, your weapons, your quiver and your bow, and go out to the field and hunt game for me.

**27:4** "And make me savory food—מַטְעַמִּים (mat'ammim)—such as I love, and bring it to me that I may eat, so that my soul may bless you before I die."

**27:5** And Rebekah heard when Isaac spoke to Esau his son. And Esau went to the field to hunt game to bring.

**27:6** And Rebekah spoke unto Jacob her son, saying: "Behold, I heard your father speak unto Esau your brother, saying:

**27:7** "'Bring me game and make me savory food, that I may eat and bless you before YHWH before my death.'

**27:8** "Now therefore, my son, listen to my voice according to what I command you.

**27:9** "Go now to the flock and take for me from there two good kids of the goats; and I will make them savory food for your father, such as he loves.

**27:10** "And you shall bring it to your father, that he may eat, so that he may bless you before his death."

**27:11** And Jacob said to Rebekah his mother: "Behold, Esau my brother is a hairy man, and I am a smooth man.

**27:12** "Perhaps my father will feel me, and I shall seem to him as a deceiver—כִמְתַעְתֵּעַ (ki-meta'te'a); and I shall bring upon myself a curse and not a blessing."

**27:13** And his mother said to him: "Upon me be your curse, my son; only listen to my voice and go fetch them for me."

**27:14** And he went and took them and brought them to his mother; and his mother made savory food such as his father loved.

**27:15** And Rebekah took the choice garments of Esau her elder son, which were with her in the house, and put them upon Jacob her younger son.

**27:16** And the skins of the kids of the goats she put upon his hands and upon the smooth of his neck.

**27:17** And she gave the savory food and the bread which she had prepared into the hand of her son Jacob.

**27:18** And he came unto his father and said: "My father." And he said: "Here I am; who are you, my son?"

**27:19** And Jacob said unto his father: "I am Esau your firstborn; I have done as you told me. Please arise, sit and eat of my game, that your soul may bless me."

**27:20** And Isaac said unto his son: "How is it that you have found it so quickly, my son?" And he said: "Because YHWH your Consciousness caused it to happen before me."

**27:21** And Isaac said unto Jacob: "Come near, please, that I may feel you, my son, whether you are really my son Esau or not."

**27:22** And Jacob came near unto Isaac his father; and he felt him and said: "The voice is the voice of Jacob, but the hands are the hands of Esau."

**27:23** And he did not recognize him, because his hands were hairy like his brother Esau's hands; so he blessed him.

**27:24** And he said: "Are you really my son Esau?" And he said: "I am."

**27:25** And Isaac said: "Bring it near to me and I will eat of my son's game, that my soul may bless you." And he brought it near to him and he ate; and he brought him wine and he drank.

**27:26** And his father Isaac said unto him: "Come near now and kiss me, my son."

**27:27** And he came near and kissed him; and Isaac smelled the smell of his garments and blessed him and said: "See, the smell of my son is as the smell of a field which YHWH has blessed.

**27:28** "And may the Consciousness give you of the dew of the heavens and of the fatness of the earth, and plenty of grain and wine.

**27:29** "Let peoples serve you and nations bow down to you; be lord over your brothers, and let your mother's sons bow down to you. Cursed be those who curse you, and blessed be those who bless you."

**27:30** And it came to pass, as soon as Isaac had finished blessing Jacob, and Jacob had scarcely gone out from the presence of Isaac his father, that Esau his brother came in from his hunting.

**27:31** And he also made savory food and brought it unto his father; and he said unto his father: "Let my father arise and eat of his son's game, that your soul may bless me."

**27:32** And Isaac his father said unto him: "Who are you?" And he said: "I am your son, your firstborn, Esau."

**27:33** And Isaac trembled with a very great trembling—וַיֶּחֱרַד יִצְחָק חֲרָדָה גְּדֹלָה עַד־מְאֹד (va-yecherad Yitschaq charadah gedolah ad-me'od)—and said: "Who then was he who hunted game and brought it to me, and I ate of all before you came, and I blessed him? Indeed, blessed he shall be—גַּם־בָּרוּךְ יִהְיֶה (gam-baruch yihyeh)."

**27:34** When Esau heard the words of his father, he cried with an exceedingly great and bitter cry—צְעָקָה גְּדֹלָה וּמָרָה (tse'aqah gedolah u-marah)—and said unto his father: "Bless me, me also, my father!"

**27:35** And Isaac said: "Your brother came with deceit—בְּמִרְמָה (be-mirmah)—and has taken your blessing."

**27:36** And Esau said: "Is he not rightly named Jacob—יַעֲקֹב (Ya'aqov)—for he has supplanted me—וַיַּעְקְבֵנִי (va-ya'qeveni)—these two times? He took my birthright, and behold, now he has taken my blessing." And he said: "Have you not reserved a blessing for me?"

**27:37** And Isaac answered and said unto Esau: "Behold, I have made him lord over you, and all his brothers I have given to him for servants; and with grain and wine I have sustained him. And what then shall I do for you, my son?"

**27:38** And Esau said unto his father: "Have you but one blessing, my father? Bless me, me also, my father!" And Esau lifted up his voice and wept.

**27:39** And Isaac his father answered and said unto him: "Behold, away from the fatness of the earth shall your dwelling be, and away from the dew of the heavens from above.

**27:40** "And by your sword you shall live, and your brother you shall serve; and it shall come to pass when you break free, that you shall shake his yoke from upon your neck."

**27:41** And Esau hated Jacob because of the blessing with which his father blessed him; and Esau said in his heart: "The days of mourning for my father are near; then I will kill my brother Jacob."

**27:42** And the words of Esau her elder son were told to Rebekah; and she sent and called Jacob her younger son and said unto him: "Behold, your brother Esau is consoling himself concerning you by planning to kill you.

**27:43** "Now therefore, my son, listen to my voice: arise, flee unto Laban my brother, to Haran.

**27:44** "And dwell with him some days, until your brother's fury turns away—

**27:45** "Until your brother's anger turns away from you and he forgets what you have done to him; then I will send and fetch you from there. Why should I be bereaved of you both in one day?"

**27:46** And Rebekah said to Isaac: "I am weary of my life because of the daughters of Heth. If Jacob takes a wife of the daughters of Heth, such as these, of the daughters of the land, what good shall my life be to me?"

---

## Synthesis Notes

**Key Restorations:**

**The Setup:**
Isaac is old and blind. He wants to bless Esau, his favorite. But Rebekah, who received the oracle that "the elder shall serve the younger" (25:23), engineers the blessing's transfer to Jacob.

**The Deception:**
- Rebekah plans it; Jacob executes it
- Jacob's concern is not moral but practical: "I shall seem as a deceiver"
- Rebekah assumes responsibility: "Upon me be your curse"
- Jacob lies directly: "I am Esau your firstborn"
- Jacob invokes YHWH in his lie: "YHWH your Consciousness caused it to happen"

**"The Voice is Jacob's, but the Hands are Esau's":**
Isaac's suspicion is accurate, but he trusts touch over hearing. The blessing proceeds despite doubt.

**The Blessing (27:28-29):**
- Material abundance (dew, fatness, grain, wine)
- Political dominance (peoples serving, nations bowing)
- Protection (cursed be those who curse, blessed be those who bless)

**Isaac's Trembling:**
When Esau arrives, Isaac trembles with violent intensity. He realizes what has happened—but then says: "Indeed, blessed he shall be" (גַּם־בָּרוּךְ יִהְיֶה). The blessing, once given, cannot be retracted. Words have power.

**Esau's Cry:**
"צְעָקָה גְּדֹלָה וּמָרָה"—a great and bitter cry. This is the grief of the dispossessed, the one whose inheritance has been stolen. The text does not mock Esau's pain; it records it with full emotional weight.

**The Name Etymology:**
Esau himself makes the connection: יַעֲקֹב (Ya'aqov) from עָקַב (aqav)—to supplant, to undermine, to heel. "He has supplanted me twice."

**Esau's "Blessing" (27:39-40):**
Isaac's words to Esau are not blessing but destiny:
- Away from fatness and dew (the opposite of Jacob's blessing)
- By the sword you shall live (violence as way of life)
- You shall serve your brother
- But: "when you break free, you shall shake his yoke"—there is eventual liberation

**The Murder Plot:**
Esau plans fratricide—"then I will kill my brother Jacob." The pattern of Cain and Abel threatens to repeat.

**Rebekah's Management:**
She sends Jacob away to her brother Laban, framing it to Isaac as concern about foreign wives. She expects "some days" (27:44)—it will be twenty years. She will never see Jacob again.

**Ethical Inversion — The Central Problem:**

Traditional readings often justify Jacob's deception as fulfilling divine destiny or note that Esau had "despised" his birthright.

**The restoration observes:**
- The deception is deception. Jacob lies, uses God's name falsely, and steals from his brother.
- Rebekah orchestrates but does not receive divine commendation in the text.
- Esau's pain is real and sympathetically portrayed.
- The consequences are severe: family rupture, exile, and twenty years of separation.

**The moral center is not clear.** Perhaps the text deliberately refuses to provide one. Perhaps the point is that divine purpose works through human complexity, not despite it.

**Archetypal Layer:** The blind father, the conflicting sons, the choosing mother—this is the family system as a site of betrayal and destiny. The blessing that cannot be retracted represents the irrevocable nature of words, promises, and patterns once set in motion. Jacob becomes Israel not by moral perfection but through a journey that begins in deception.

**Psychological Reading:** The family is split by parental favoritism (Isaac/Esau, Rebekah/Jacob). The blessing that should unite becomes a weapon of division. Esau's cry is the cry of the unfavored child who discovers that what he thought was secure has been given to another. Jacob's flight is the exile of the one who has gained everything and lost home.

**Modern Equivalent:** Family systems often feature favoritism, deception, and contested inheritance. Words once spoken cannot be unsaid. The one who "wins" may have to flee. The one who "loses" may carry bitterness toward violence. And sometimes, eventually, there is reconciliation (Chapter 33).

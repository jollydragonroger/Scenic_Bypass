# Genesis Chapter 44: The Silver Cup and Judah's Plea

*From the Hebrew: The Final Test*

---

**44:1** And he commanded the one who was over his house, saying: "Fill the men's sacks with food, as much as they can carry, and put each man's money in the mouth of his sack.

**44:2** "And put my cup—גְּבִיעִי (gevi'i)—the silver cup, in the mouth of the sack of the youngest, with his grain money." And he did according to the word that Joseph had spoken.

**44:3** The morning was light, and the men were sent away, they and their donkeys.

**44:4** They had gone out of the city and were not yet far off, when Joseph said unto the one who was over his house: "Arise, pursue after the men; and when you overtake them, say unto them: 'Why have you repaid evil for good?

**44:5** "'Is not this the cup from which my lord drinks, and by which he indeed divines—נַחֵשׁ יְנַחֵשׁ (nachesh yenachesh)? You have done evil in what you have done.'"

**44:6** And he overtook them and spoke unto them these words.

**44:7** And they said unto him: "Why does my lord speak such words as these? Far be it from your servants to do such a thing!

**44:8** "Behold, the money which we found in the mouth of our sacks we brought back unto you from the land of Canaan; how then should we steal silver or gold from your lord's house?

**44:9** "With whomever of your servants it is found, let him die; and we also will be my lord's slaves."

**44:10** And he said: "Now also let it be according to your words: he with whom it is found shall be my slave, and you shall be blameless."

**44:11** And they hurried, and each man lowered his sack to the ground, and each man opened his sack.

**44:12** And he searched, beginning with the eldest and ending with the youngest; and the cup was found in Benjamin's sack.

**44:13** And they tore their garments—וַיִּקְרְעוּ שִׂמְלֹתָם (va-yiqre'u simlotam); and each man loaded his donkey, and they returned to the city.

**44:14** And Judah and his brothers came to Joseph's house, and he was still there; and they fell before him to the ground.

**44:15** And Joseph said unto them: "What deed is this that you have done? Did you not know that such a man as I surely divines?"

**44:16** And Judah said: "What shall we say unto my lord? What shall we speak? And how shall we justify ourselves? Consciousness has found out the iniquity of your servants—הָאֱלֹהִים מָצָא אֶת־עֲוֺן עֲבָדֶיךָ (ha-Elohim matsa et-avon avadecha). Behold, we are my lord's slaves, both we and he in whose hand the cup was found."

**44:17** And Joseph said: "Far be it from me to do so! The man in whose hand the cup was found, he shall be my slave; and as for you, go up in peace unto your father."

**44:18** And Judah came near unto him and said: "O my lord, please let your servant speak a word in my lord's ears, and let not your anger burn against your servant, for you are as Pharaoh.

**44:19** "My lord asked his servants, saying: 'Have you a father or a brother?'

**44:20** "And we said unto my lord: 'We have a father, an old man, and a child of his old age, a little one; and his brother is dead, and he alone is left of his mother, and his father loves him.'

**44:21** "And you said unto your servants: 'Bring him down unto me, that I may set my eyes upon him.'

**44:22** "And we said unto my lord: 'The lad cannot leave his father; for if he should leave his father, his father would die.'

**44:23** "And you said unto your servants: 'Unless your youngest brother comes down with you, you shall not see my face again.'

**44:24** "And it came to pass, when we came up unto your servant my father, that we told him the words of my lord.

**44:25** "And our father said: 'Go again, buy us a little food.'

**44:26** "And we said: 'We cannot go down; if our youngest brother is with us, then we will go down; for we cannot see the man's face unless our youngest brother is with us.'

**44:27** "And your servant my father said unto us: 'You know that my wife bore me two sons.

**44:28** "'And one went out from me, and I said: "Surely he is torn, torn to pieces—טָרֹף טֹרָף (tarof toraf)"—and I have not seen him since.

**44:29** "'And if you take this one also from me, and harm befalls him, you shall bring down my gray hairs in evil unto Sheol.'

**44:30** "Now therefore, when I come to your servant my father, and the lad is not with us—seeing that his soul is bound up in the lad's soul—נַפְשׁוֹ קְשׁוּרָה בְנַפְשׁוֹ (nafsho qeshurah ve-nafsho)—

**44:31** "It shall come to pass, when he sees that the lad is not with us, that he will die; and your servants shall bring down the gray hairs of your servant our father in sorrow to Sheol.

**44:32** "For your servant became surety for the lad unto my father, saying: 'If I do not bring him unto you, then I shall bear the blame to my father forever.'

**44:33** "Now therefore, please let your servant remain instead of the lad as a slave to my lord; and let the lad go up with his brothers.

**44:34** "For how shall I go up to my father if the lad is not with me? Lest I see the evil that shall befall my father."

---

## Synthesis Notes

**Key Restorations:**

**The Planted Cup:**
Joseph orchestrates the final test. The silver cup—his divining cup—is placed in Benjamin's sack. This creates the scenario: Benjamin appears guilty of theft, and the brothers must choose whether to abandon him (as they abandoned Joseph) or stand with him.

**Divination (נַחֵשׁ, nachesh):**
The same root as "serpent" (נָחָשׁ). Joseph's cup is apparently used for divination—reading omens in liquid. Whether Joseph actually practiced this or it was cover for his prophetic gifts is ambiguous. The text presents it as Egyptian court practice.

**The Brothers' Confidence:**
They are so certain of innocence that they offer: "Let the guilty one die, and the rest become slaves." Their confidence condemns them when the cup appears.

**The Search:**
The steward searches eldest to youngest—prolonging suspense—and finds the cup in Benjamin's sack. The brothers tear their garments (mourning/distress gesture) and all return together. They do not abandon Benjamin.

**"Consciousness Has Found Out Our Iniquity":**
Judah's confession is remarkable. He doesn't say "Benjamin's iniquity" but "the iniquity of your servants"—he speaks of collective guilt. He interprets this crisis as divine exposure of their sin against Joseph (still not knowing he's speaking to Joseph). The guilty conscience applies current suffering to past crime.

**Joseph's Offer:**
"Let Benjamin be my slave; the rest of you go free." This is the precise test: will they abandon the favored son to save themselves? This is what they did to Joseph twenty years ago.

**Judah's Plea — The Climax:**

Judah's speech (44:18-34) is the emotional and moral peak of the entire Joseph narrative:

1. **He approaches** (וַיִּגַּשׁ, va-yiggash)—the Torah portion is named for this approach
2. **He recounts the whole story** from the Egyptian lord's perspective—reminding Joseph of Joseph's own demands
3. **He reveals Jacob's heart**: "My wife bore me two sons"—Jacob still speaks of Rachel as his primary wife; "his soul is bound up in the lad's soul"
4. **He quotes Jacob on Joseph**: "Surely he is torn, torn to pieces"—Joseph hears his father's grief spoken aloud
5. **He offers himself**: "Let me remain as slave instead of the lad"

This is complete reversal:
- The one who said "let's sell him" now says "take me instead"
- The one who proposed profit from Joseph now offers self-sacrifice for Benjamin
- The one who brought the bloodied coat now protects the surviving favored son

**"How Shall I Go Up If the Lad Is Not With Me?":**
Judah cannot face his father with another loss. He has learned what it cost Jacob to lose Joseph. He will not participate in that grief again.

**Archetypal Layer:** The test is complete. The brothers—specifically Judah—have demonstrated transformation. They will not repeat the crime. The one who led in selling Joseph now leads in offering himself. The arc from betrayal to substitutionary sacrifice is complete.

**Psychological Reading:** Judah's speech forces Joseph to hear his father's grief, his family's pain, and his brothers' growth. Joseph has been testing them; now they test him—can he continue the game after hearing this? Judah's plea penetrates Joseph's disguise and demands response.

**Ethical Inversion Applied:**
- Traditional reading: Joseph wisely tests, brothers pass
- **Restored reading**: Judah becomes the moral center
- He takes responsibility for what he cannot change (Benjamin's apparent guilt)
- He offers himself without demanding reciprocity
- His transformation is demonstrated in action, not words
- The agent who regains moral agency is Judah

**Modern Equivalent:** True change is demonstrated under pressure. Anyone can claim transformation when the cost is low. Judah's offer—to become a slave so Benjamin can go free—proves he is not the man who sold Joseph. Character is revealed when sacrifice is required.

# Genesis Chapter 15: The Covenant of the Pieces

*From the Hebrew: בְּרִית בֵּין הַבְּתָרִים (Berit Bein Ha-Betarim) — The Covenant Between the Parts*

---

**15:1** After these things the word of YHWH came unto Abram in a vision—בַּמַּחֲזֶה (ba-machazeh)—saying: "Fear not, Abram; I am your shield—מָגֵן (magen)—your reward shall be very great."

**15:2** And Abram said: "Lord YHWH, what will you give me, seeing I go childless, and the heir of my house is Eliezer of Damascus?"

**15:3** And Abram said: "Behold, to me you have given no seed; and behold, one born in my house is my heir."

**15:4** And behold, the word of YHWH came unto him, saying: "This one shall not be your heir; but one who shall come forth from your own body—מִמֵּעֶיךָ (mi-me'echa)—shall be your heir."

**15:5** And YHWH brought him outside and said: "Look now toward the heavens and count the stars, if you are able to count them." And YHWH said unto him: "So shall your seed be."

**15:6** And he believed in YHWH—וְהֶאֱמִן בַּיהוָה (ve-he'emin ba-YHWH); and YHWH reckoned it to him as righteousness—צְדָקָה (tsedaqah).

**15:7** And YHWH said unto him: "I am YHWH who brought you out of Ur of the Chaldeans, to give you this land to inherit it."

**15:8** And he said: "Lord YHWH, by what shall I know that I will inherit it?"

**15:9** And YHWH said unto him: "Take for me a heifer of three years, and a female goat of three years, and a ram of three years, and a turtledove, and a young pigeon."

**15:10** And he took for YHWH all these, and divided them in the middle, and placed each piece opposite its counterpart; but the birds he did not divide.

**15:11** And the birds of prey—הָעַיִט (ha-ayit)—came down upon the carcasses, and Abram drove them away.

**15:12** And it came to pass, as the sun was going down, that a deep sleep—תַּרְדֵּמָה (tardemah)—fell upon Abram; and behold, a terror of great darkness—אֵימָה חֲשֵׁכָה גְדֹלָה (eimah chashechah gedolah)—fell upon him.

**15:13** And YHWH said unto Abram: "Know surely that your seed shall be strangers in a land that is not theirs, and shall serve them, and they shall afflict them four hundred years.

**15:14** "And also that nation whom they shall serve I will judge; and afterward they shall come out with great substance.

**15:15** "And you shall go to your fathers in peace; you shall be buried in a good old age.

**15:16** "And in the fourth generation they shall return here; for the iniquity of the Amorites is not yet complete."

**15:17** And it came to pass, when the sun had gone down and it was dark, that behold, a smoking furnace—תַּנּוּר עָשָׁן (tannur ashan)—and a flaming torch—לַפִּיד אֵשׁ (lappid esh)—passed between those pieces.

**15:18** On that day YHWH cut a covenant—כָּרַת בְּרִית (karat berit)—with Abram, saying: "To your seed I have given this land, from the river of Egypt unto the great river, the river Euphrates:

**15:19** "The Kenite, and the Kenizzite, and the Kadmonite,

**15:20** "And the Hittite, and the Perizzite, and the Rephaim,

**15:21** "And the Amorite, and the Canaanite, and the Girgashite, and the Jebusite."

---

## Synthesis Notes

**Key Restorations:**

- *Machazeh* (מַחֲזֶה): "Vision"—from the root "to see." This is visionary experience, not ordinary perception. The covenant is established in altered consciousness.

- *Magen* (מָגֵן): "Shield"—YHWH as protector. After Abram's military victory, the language is martial. But the promise is not more conquest—it is seed.

- **Abram's complaint**: He challenges YHWH directly: "What will you give me, seeing I go childless?" This is not impiety but honest relationship. Abram names his despair.

- *He'emin* (הֶאֱמִן): "Believed"—from the root אָמַן (aman), "to be firm, reliable, trustworthy." Abram's response to the star-promise is not intellectual assent but existential trust—he leans his weight on YHWH's word.

- *Tsedaqah* (צְדָקָה): "Righteousness"—not moral perfection but right-relationship, alignment, covenant-faithfulness. Abram's trust is "reckoned" (חָשַׁב, chashav—counted, imputed) as righteousness.

**The Covenant Ritual:**

- **Cutting animals in half**: Ancient Near Eastern covenant practice. The parties would walk between the pieces, implicitly saying: "May I become like these animals if I break this covenant."

- **But only YHWH passes through**: The smoking furnace and flaming torch (symbols of divine presence) pass between the pieces. Abram does not. This is **unilateral covenant**—YHWH binds YHWH-self, taking all the obligation.

- *Tannur ashan* (תַּנּוּר עָשָׁן): "Smoking oven/furnace"—industrial fire, the fire of transformation. *Lappid esh* (לַפִּיד אֵשׁ): "Torch of fire"—illuminating fire. Both fire symbols together: **fire as transformation and revelation** (from the symbol map).

- *Tardemah* (תַּרְדֵּמָה): The same "deep sleep" that fell on Adam when Eve was formed (2:21). Covenant-making happens in the liminal space of altered consciousness—the ego must step aside.

- *Eimah chashechah gedolah* (אֵימָה חֲשֵׁכָה גְדֹלָה): "Terror of great darkness"—the numinous dread that accompanies divine encounter. This is not comfortable religion but terrifying contact with the infinite.

**The Prophecy of Bondage:**

- Four hundred years of servitude foretold—the Egypt experience is known in advance
- "The iniquity of the Amorites is not yet complete"—the conquest is delayed because the current inhabitants have not yet exhausted their moral credit
- This remarkable statement implies that **even the promised land comes with moral conditions**—not Israelite entitlement but Amorite exhaustion

**Archetypal Layer:** The covenant ritual is a death-and-resurrection structure. The animals die, are divided, and between their pieces the fire of transformation passes. Abram undergoes symbolic death (tardemah, terror, darkness) and awakens to a new reality—covenanted. The promise is vast (from Egypt's river to Euphrates) but the path goes through four centuries of suffering.

**Psychological Reading:** Deep promises are received in darkness—in the descent, the depression, the surrender of control. The ego's "deep sleep" allows the deeper self to be imprinted with covenant. The "terror of great darkness" is the experience of the unconscious overwhelming ordinary awareness. What emerges is transformed identity.

**Modern Equivalent:** Authentic commitment involves walking through death—the death of alternatives, the narrowing of possibility into promise. The smoking furnace and flaming torch of divine passage represent the transformative and illuminating fires that seal genuine covenant. But the promise includes honest prophecy: there will be centuries of bondage before arrival. Trust is not naive optimism but eyes-open commitment to a multi-generational arc.

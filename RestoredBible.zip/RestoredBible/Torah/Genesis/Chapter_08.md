# Genesis Chapter 8: The Emergence from the Waters

*From the Hebrew: The Restoration Begins*

---

**8:1** And Consciousness remembered—וַיִּזְכֹּר (va-yizkor)—Noah, and every living thing, and all the beasts that were with him in the ark; and Consciousness caused a wind—רוּחַ (ruach)—to pass over the earth, and the waters subsided.

**8:2** And the fountains of the deep and the windows of the sky were closed, and the rain from the sky was restrained.

**8:3** And the waters returned from upon the earth, going and returning; and the waters decreased at the end of one hundred and fifty days.

**8:4** And the ark rested—וַתָּנַח (va-tanach)—in the seventh month, on the seventeenth day of the month, upon the mountains of Ararat.

**8:5** And the waters continued to decrease until the tenth month; in the tenth month, on the first day of the month, the tops of the mountains were seen.

**8:6** And it came to pass at the end of forty days that Noah opened the window of the ark which he had made.

**8:7** And he sent forth the raven—הָעֹרֵב (ha-orev)—and it went forth, going and returning, until the waters were dried up from upon the earth.

**8:8** And he sent forth the dove—הַיּוֹנָה (ha-yonah)—from him, to see if the waters had subsided from upon the face of the ground.

**8:9** But the dove found no resting place for the sole of her foot, and she returned unto him to the ark, for the waters were upon the face of all the earth; and he reached out his hand and took her and brought her unto him into the ark.

**8:10** And he waited yet another seven days, and again sent forth the dove from the ark.

**8:11** And the dove came unto him at evening time, and behold, in her mouth was a freshly plucked olive leaf—עֲלֵה־זַיִת (aleh-zayit); and Noah knew that the waters had subsided from upon the earth.

**8:12** And he waited yet another seven days, and sent forth the dove, and she did not return unto him again.

**8:13** And it came to pass in the six hundred and first year, in the first month, on the first day of the month, the waters were dried from upon the earth; and Noah removed the covering of the ark and looked, and behold, the face of the ground was dry.

**8:14** And in the second month, on the twenty-seventh day of the month, the earth was fully dry.

**8:15** And Consciousness spoke unto Noah, saying:

**8:16** "Go forth from the ark—you and your partner and your sons and your sons' partners with you.

**8:17** "Every living thing that is with you of all flesh—of winged beings and of beasts and of every creeping thing that creeps upon the earth—bring forth with you, and let them swarm upon the earth and be fruitful and multiply upon the earth."

**8:18** And Noah went forth, and his sons, and his partner, and his sons' partners with him.

**8:19** Every living thing, every creeping thing, and every winged being—everything that moves upon the earth—according to their families went forth from the ark.

**8:20** And Noah built an altar to YHWH, and took from every clean beast and from every clean winged being, and offered burnt offerings—עֹלֹת (olot)—upon the altar.

**8:21** And YHWH breathed in the soothing aroma—רֵיחַ הַנִּיחֹחַ (reiach ha-nichoach)—and YHWH said in the heart: "I will not again curse—קַלֵּל (qallel)—the ground because of the human, for the formation of the human heart is toward harm from youth; and I will not again strike every living thing as I have done.

**8:22** "While the earth remains, seedtime and harvest, and cold and heat, and summer and winter, and day and night shall not cease."

---

## Synthesis Notes

**Key Restorations:**

- *Va-yizkor* (וַיִּזְכֹּר): "Remembered"—not that Consciousness forgot, but that the divine attention now turns toward restoration. To remember is to act upon relationship.

- *Ruach* (רוּחַ): The same word for "wind," "breath," and "spirit"—the ruach that moved over the waters in Genesis 1:2 now passes over again, initiating a new creation.

- *Va-tanach* (וַתָּנַח): "Rested"—the same root as Noah's name (נֹחַ). The ark "Noahs" upon Ararat. The vessel of rest comes to rest.

- **The Raven and the Dove**: The raven (עֹרֵב, orev) goes "going and returning"—ceaseless motion, scavenging, never settling. The dove (יוֹנָה, yonah) seeks rest and returns with evidence of new life. Two modes of post-disaster response: restless opportunism versus patient seeking of renewal.

- *Aleh-zayit* (עֲלֵה־זַיִת): The olive leaf—symbol of peace, oil, anointing, healing. The first sign of regeneration is the olive, tree of endurance and blessing.

- **First day of the first month**: The new beginning aligns with the calendar's new beginning—a reset of time itself.

- *Olot* (עֹלֹת): "Burnt offerings"—from the root עָלָה (alah), "to go up." The offerings ascend as smoke, representing the return of transformed substance to the source.

- *Reiach ha-nichoach* (רֵיחַ הַנִּיחֹחַ): "Soothing aroma"—again the root נוח (rest/comfort). The offering brings rest to Consciousness. This is the third wordplay on Noah's name.

- **"The formation of the human heart is toward harm from youth"**: This is not a curse but an acknowledgment. Consciousness will not again destroy all flesh precisely **because** human inclination is problematic—destruction doesn't solve it. The post-Flood covenant is unconditional.

- **"Seedtime and harvest shall not cease"**: The promise of cyclical stability—the rhythms of earth will be maintained regardless of human behavior. This is grace, not reward.

**Archetypal Layer:** The emergence from the waters is the universal rebirth—the hero returning from the underworld, the initiate emerging from the baptismal waters, the psyche reconstituting after dissolution. The raven and dove are the two aspects of post-trauma consciousness: the restless, scavenging survivor-mind and the peace-seeking, life-detecting soul.

**Psychological Reading:** After psychological dissolution (breakdown, grief, dark night), there is a period of waiting. One sends out probes—the raven of anxious checking, the dove of hopeful seeking. Eventually the dove returns with evidence that ground has reappeared, that new life is possible. The altar represents the integration of the experience through conscious acknowledgment.

**Ecological Reading:** After collapse, ecosystems regenerate. The olive is among the first to return—hardy, resilient, requiring minimal water. The promise of "seedtime and harvest" is the observation that planetary cycles persist through catastrophe. Life returns.

**Modern Equivalent:** The aftermath of crisis requires patient waiting, repeated testing for ground, and eventual emergence into a world that is the same yet entirely new. The covenant that follows (Chapter 9) will establish the new parameters for life after the reset.

# Genesis Chapter 10: The Table of Nations

*From the Hebrew: תּוֹלְדֹת בְּנֵי־נֹחַ (Toledot Benei-Noach) — The Generations of Noah's Sons*

---

**10:1** Now these are the generations of the sons of Noah: Shem, Ham, and Japheth; and sons were born to them after the flood.

**10:2** The sons of Japheth: Gomer, and Magog, and Madai, and Javan, and Tubal, and Meshech, and Tiras.

**10:3** And the sons of Gomer: Ashkenaz, and Riphath, and Togarmah.

**10:4** And the sons of Javan: Elishah, and Tarshish, Kittim, and Dodanim.

**10:5** From these the coastland peoples spread in their lands, each according to their tongue, according to their clans, in their nations.

**10:6** And the sons of Ham: Cush, and Mizraim, and Put, and Canaan.

**10:7** And the sons of Cush: Seba, and Havilah, and Sabtah, and Raamah, and Sabteca; and the sons of Raamah: Sheba and Dedan.

**10:8** And Cush begot Nimrod; he began to be a mighty one—גִּבֹּר (gibbor)—in the earth.

**10:9** He was a mighty hunter—גִּבֹּר־צַיִד (gibbor-tsayid)—before YHWH; therefore it is said: "Like Nimrod, a mighty hunter before YHWH."

**10:10** And the beginning of his kingdom was Babel, and Erech, and Accad, and Calneh, in the land of Shinar.

**10:11** From that land he went forth to Assyria—אַשּׁוּר (Asshur)—and built Nineveh, and Rehoboth-Ir, and Calah,

**10:12** And Resen between Nineveh and Calah; that is the great city.

**10:13** And Mizraim begot the Ludim, and the Anamim, and the Lehabim, and the Naphtuhim,

**10:14** And the Pathrusim, and the Casluhim, from whom came the Philistines, and the Caphtorim.

**10:15** And Canaan begot Sidon his firstborn, and Heth,

**10:16** And the Jebusite, and the Amorite, and the Girgashite,

**10:17** And the Hivite, and the Arkite, and the Sinite,

**10:18** And the Arvadite, and the Zemarite, and the Hamathite; and afterward the clans of the Canaanites spread abroad.

**10:19** And the border of the Canaanite was from Sidon, as you go toward Gerar, unto Gaza; as you go toward Sodom and Gomorrah and Admah and Zeboiim, unto Lasha.

**10:20** These are the sons of Ham, according to their clans, according to their tongues, in their lands, in their nations.

**10:21** And to Shem also were born children; he was the father of all the children of Eber, the elder brother of Japheth.

**10:22** The sons of Shem: Elam, and Asshur, and Arpachshad, and Lud, and Aram.

**10:23** And the sons of Aram: Uz, and Hul, and Gether, and Mash.

**10:24** And Arpachshad begot Shelah, and Shelah begot Eber.

**10:25** And to Eber were born two sons: the name of one was Peleg—פֶּלֶג (Peleg), meaning "division"—for in his days the earth was divided; and his brother's name was Joktan.

**10:26** And Joktan begot Almodad, and Sheleph, and Hazarmaveth, and Jerah,

**10:27** And Hadoram, and Uzal, and Diklah,

**10:28** And Obal, and Abimael, and Sheba,

**10:29** And Ophir, and Havilah, and Jobab; all these were the sons of Joktan.

**10:30** And their dwelling was from Mesha, as you go toward Sephar, the mountain of the east.

**10:31** These are the sons of Shem, according to their clans, according to their tongues, in their lands, according to their nations.

**10:32** These are the clans of the sons of Noah, according to their generations, in their nations; and from these the nations were divided in the earth after the flood.

---

## Synthesis Notes

**Key Restorations:**

- **The Table of Nations**: This is the ancient world's attempt at comprehensive ethnography—mapping known peoples to common ancestry. It represents the **unity of humanity** despite diversity: all nations descend from one family.

- *Nimrod* (נִמְרֹד): From a root meaning "to rebel." He is the first גִּבֹּר (gibbor)—mighty one—after the flood. His kingdom begins at Babel and extends to Assyria (Nineveh). He represents the emergence of **empire**—the concentration of power that will be critiqued in Chapter 11.

- **"Before YHWH"**: The phrase "mighty hunter before YHWH" (לִפְנֵי יהוה) is ambiguous—either "in YHWH's presence/approval" or "in opposition to YHWH." The tradition has read it both ways. Empire-building may be mighty, but its relationship to Consciousness is complex.

- *Peleg* (פֶּלֶג): "Division"—in his days the earth was divided. This refers either to the Babel dispersion (Chapter 11) or to some other division (geographic, political, linguistic). The wordplay marks a turning point.

- **The three branches**: 
  - **Japheth** = Indo-European peoples (Gomer/Cimmerians, Madai/Medes, Javan/Greeks, etc.)
  - **Ham** = African and Near Eastern peoples (Cush/Ethiopia, Mizraim/Egypt, Canaan)
  - **Shem** = Semitic peoples (Elam, Aram/Arameans, Eber/Hebrews)

**Historical-Context Lens:**

This chapter reflects the geopolitical knowledge and interests of its ancient Israelite authors. It:
- Places Israel (through Eber/Shem) in a specific genealogical position
- Names nations that would become enemies, allies, and subjects
- Was used (and misused) to construct racial hierarchies

**The restoration recognizes**: All nations share common origin. The text itself affirms human unity. Later hierarchical interpretations invert this meaning.

**Archetypal Layer:** After the Flood's reset, humanity differentiates into the seventy nations (a traditional count)—the full spectrum of human cultural possibility. This is not a fall but a flowering. Diversity is the natural expression of post-diluvian creativity.

**Ecological-Systemic Reading:** The Table of Nations is an early attempt at systems thinking—mapping human diversity as an interconnected tree. It recognizes that peoples exist in relationship to lands, languages, and one another.

**Modern Equivalent:** We are all one human family, recently diverged. The genetic evidence confirms what the Table of Nations symbolically asserts: common ancestry, recent differentiation, fundamental kinship. The empires that emerge (Nimrod's Babel, Nineveh) represent the centralization of power that will repeatedly rise and fall throughout the biblical narrative.

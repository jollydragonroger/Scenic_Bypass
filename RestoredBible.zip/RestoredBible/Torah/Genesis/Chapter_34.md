# Genesis Chapter 34: Dinah and Shechem

*From the Hebrew: Violence and Its Consequences*

---

**34:1** And Dinah the daughter of Leah, whom she had borne unto Jacob, went out to see the daughters of the land.

**34:2** And Shechem the son of Hamor the Hivite, prince of the land, saw her; and he took her—וַיִּקַּח (va-yiqqach)—and lay with her—וַיִּשְׁכַּב אֹתָהּ (va-yishkav otah)—and violated her—וַיְעַנֶּהָ (va-ye'anneha).

**34:3** And his soul clung—וַתִּדְבַּק (va-tidbaq)—unto Dinah the daughter of Jacob, and he loved the young woman, and spoke to the heart of the young woman.

**34:4** And Shechem spoke unto his father Hamor, saying: "Take for me this girl as a wife."

**34:5** And Jacob heard that he had defiled—טִמֵּא (timme)—Dinah his daughter; and his sons were with his livestock in the field; and Jacob held his peace until they came.

**34:6** And Hamor the father of Shechem went out unto Jacob to speak with him.

**34:7** And the sons of Jacob came in from the field when they heard; and the men were grieved and very angry, because he had done a disgraceful thing in Israel—נְבָלָה בְיִשְׂרָאֵל (nevalah be-Yisra'el)—by lying with Jacob's daughter; and such a thing ought not to be done.

**34:8** And Hamor spoke with them, saying: "The soul of my son Shechem longs for your daughter; please give her to him as a wife.

**34:9** "And intermarry with us; give your daughters unto us, and take our daughters unto you.

**34:10** "And you shall dwell with us; and the land shall be before you; dwell and trade in it, and acquire property in it."

**34:11** And Shechem said unto her father and unto her brothers: "Let me find favor in your eyes, and whatever you say unto me I will give.

**34:12** "Ask of me ever so much dowry and gift—מֹהַר וּמַתָּן (mohar u-mattan)—and I will give according as you say unto me; only give me the young woman as a wife."

**34:13** And the sons of Jacob answered Shechem and Hamor his father with deceit—בְּמִרְמָה (be-mirmah)—and spoke, because he had defiled Dinah their sister.

**34:14** And they said unto them: "We cannot do this thing, to give our sister to one who has a foreskin; for that would be a reproach unto us.

**34:15** "Only on this condition will we consent unto you: if you will be as we are, that every male of you be circumcised.

**34:16** "Then we will give our daughters unto you, and we will take your daughters to us, and we will dwell with you, and we will become one people.

**34:17** "But if you will not listen to us to be circumcised, then we will take our daughter and we will go."

**34:18** And their words were good in the eyes of Hamor and in the eyes of Shechem, Hamor's son.

**34:19** And the young man did not delay to do the thing, because he had delight in Jacob's daughter; and he was more honored than all the house of his father.

**34:20** And Hamor and Shechem his son came unto the gate of their city and spoke unto the men of their city, saying:

**34:21** "These men are peaceful with us; let them dwell in the land and trade in it; for behold, the land is large enough for them. Let us take their daughters to us as wives, and let us give them our daughters.

**34:22** "Only on this condition will the men consent unto us to dwell with us, to become one people: that every male among us be circumcised, as they are circumcised.

**34:23** "Shall not their livestock and their possessions and all their beasts be ours? Only let us consent unto them, and they will dwell with us."

**34:24** And unto Hamor and unto Shechem his son listened all who went out of the gate of his city; and every male was circumcised, all who went out of the gate of his city.

**34:25** And it came to pass on the third day, when they were in pain, that two of the sons of Jacob, Simeon and Levi, Dinah's brothers, each took his sword and came upon the city unawares—בֶּטַח (betach), "securely/unsuspecting"—and killed every male.

**34:26** And they killed Hamor and Shechem his son with the edge of the sword, and took Dinah out of Shechem's house, and went out.

**34:27** The sons of Jacob came upon the slain and plundered the city, because they had defiled their sister.

**34:28** They took their flocks and their herds and their donkeys, and that which was in the city and that which was in the field.

**34:29** And all their wealth and all their little ones and their wives they took captive, and plundered all that was in the house.

**34:30** And Jacob said to Simeon and Levi: "You have troubled me—עֲכַרְתֶּם אֹתִי (achartem oti)—by making me odious among the inhabitants of the land, among the Canaanites and the Perizzites; and I being few in number, they will gather themselves together against me and strike me, and I shall be destroyed, I and my house."

**34:31** And they said: "Should he treat our sister as a prostitute—הַכְזוֹנָה (ha-che-zonah)?"

---

## Synthesis Notes

**Key Restorations:**

**What Happened to Dinah:**

The Hebrew uses three verbs in sequence:
- *Va-yiqqach* (וַיִּקַּח): "took her"—seizure
- *Va-yishkav otah* (וַיִּשְׁכַּב אֹתָהּ): "lay with her"—sexual intercourse
- *Va-ye'anneha* (וַיְעַנֶּהָ): "violated/humiliated her"—the same root as Hagar's affliction (16:6) and Israel's affliction in Egypt

This is not seduction but assault. The text is clear: Dinah was violated.

**Shechem's "Love":**
After the assault, Shechem's soul "clings" (דָּבַק, davaq—the same word as "cleave" in 2:24 for marriage). He "loves" her and "speaks to her heart" (words of comfort/persuasion). He wants to marry her.

This pattern—assault followed by claimed love and desire to marry—does not make the assault acceptable. The restoration refuses to romanticize it.

**Dinah's Silence:**
Dinah has no recorded speech in the entire chapter. She is acted upon—by Shechem, then retrieved by her brothers—but never speaks. Her perspective is erased.

**The Deceit (מִרְמָה, mirmah):**
The same word used for Jacob's deception of Isaac (27:35). The sons become like their father—using deception to achieve their ends. They weaponize circumcision, turning the covenant sign into a trap.

**The Massacre:**
Simeon and Levi kill all the males of Shechem while they are recovering from circumcision—helpless, in pain, unsuspecting. They kill not only the rapist but the entire male population. The other brothers then plunder, taking women and children as captives.

The violence is disproportionate. One crime is answered with genocide.

**Jacob's Response:**
Jacob does not speak of justice or Dinah's welfare. He speaks of **practical consequences**: "You have made me odious... I will be destroyed." His concern is self-preservation and reputation, not his daughter.

**The Brothers' Final Word:**
"Should he treat our sister as a prostitute?" This is honor culture—the issue is family honor, not Dinah's trauma. Yet within their framework, they assert: our sister matters, and what was done to her demands response.

**Ethical Complexity — No Simple Reading:**

1. **Dinah was violated**—this is unambiguous wrong
2. **Shechem's "love" does not excuse the assault**—claiming to love someone you've raped does not constitute redemption
3. **The brothers' deception weaponizes sacred covenant**—circumcision as trap profanes the sign
4. **The massacre is disproportionate**—killing an entire city for one man's crime is collective punishment
5. **Jacob's response prioritizes self-interest**—he never addresses Dinah or her healing
6. **Dinah remains voiceless**—the victim is not centered in her own story

**The restoration refuses to identify a clear "moral center."** The text presents a cascade of violations and violences without endorsing any response.

**Archetypal Layer:** This is the shadow side of family loyalty—honor that demands blood, protection that becomes atrocity. The daughter who "went out" becomes the occasion for tribal violence. The integration of peoples (Hamor's proposal) is destroyed by deception and massacre.

**Psychological Reading:** Trauma generates trauma. The assault on Dinah generates rage in her brothers that exceeds proportion. Jacob's passivity (he "held his peace") forces the sons to act, but they act destructively. The family system that produced Jacob the deceiver now produces Simeon and Levi the killers.

**Historical-Context Lens:** This story may reflect inter-tribal conflicts between Israelites and Hivite/Canaanite populations. It provides etiology for later animosity and explains why Simeon and Levi's tribes were scattered (Genesis 49:5-7).

**Modern Equivalent:** Sexual assault, honor violence, disproportionate revenge, silenced victims—this chapter resonates with contemporary concerns. The restoration insists on naming: the assault was wrong; the massacre was wrong; and Dinah's voice was never recorded. We still struggle with all of this.

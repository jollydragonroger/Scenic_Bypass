# Genesis Chapter 18: The Three Visitors and Abraham's Intercession

*From the Hebrew: Hospitality and the Negotiation for Sodom*

---

**18:1** And YHWH appeared unto him by the oaks of Mamre; and he was sitting at the tent door in the heat of the day.

**18:2** And he lifted up his eyes and looked, and behold, three men—שְׁלֹשָׁה אֲנָשִׁים (sheloshah anashim)—stood before him; and when he saw them, he ran from the tent door to meet them, and bowed himself to the ground.

**18:3** And he said: "My lord, if now I have found favor in your eyes, please do not pass by your servant.

**18:4** "Let a little water be brought, and wash your feet, and rest yourselves under the tree.

**18:5** "And I will fetch a morsel of bread, and refresh your hearts; after that you may pass on, since you have passed by your servant." And they said: "Do so, as you have spoken."

**18:6** And Abraham hurried into the tent unto Sarah, and said: "Quickly, three measures of fine flour—knead it and make cakes."

**18:7** And Abraham ran unto the herd, and took a calf, tender and good, and gave it unto the servant, and he hurried to prepare it.

**18:8** And he took butter and milk and the calf which he had prepared, and set it before them; and he stood by them under the tree, and they ate.

**18:9** And they said unto him: "Where is Sarah your partner?" And he said: "Behold, in the tent."

**18:10** And one said: "I will surely return unto you at the time of life—כָּעֵת חַיָּה (ka-et chayyah)—and behold, Sarah your partner shall have a son." And Sarah heard at the tent door, which was behind him.

**18:11** Now Abraham and Sarah were old, advanced in days; it had ceased to be with Sarah after the manner of women.

**18:12** And Sarah laughed within herself—וַתִּצְחַק שָׂרָה בְּקִרְבָּהּ (va-titschaq Sarah be-qirbah)—saying: "After I am worn out, shall I have pleasure—עֶדְנָה (ednah)—my lord also being old?"

**18:13** And YHWH said unto Abraham: "Why did Sarah laugh, saying, 'Shall I indeed bear a child, when I am old?'

**18:14** "Is anything too wondrous for YHWH?—הֲיִפָּלֵא מֵיהוָה דָּבָר (ha-yippale me-YHWH davar). At the appointed time I will return unto you, at the time of life, and Sarah shall have a son."

**18:15** And Sarah denied, saying: "I did not laugh"—for she was afraid. And YHWH said: "No, but you did laugh."

**18:16** And the men rose up from there and looked toward Sodom; and Abraham went with them to see them on their way.

**18:17** And YHWH said: "Shall I hide from Abraham what I am doing,

**18:18** "Seeing that Abraham shall surely become a great and mighty nation, and all the nations of the earth shall be blessed through him?

**18:19** "For I have known him—יְדַעְתִּיו (yeda'tiv)—so that he will command his children and his household after him, and they shall keep the way of YHWH, to do righteousness and justice—צְדָקָה וּמִשְׁפָּט (tsedaqah u-mishpat)—so that YHWH may bring upon Abraham what has been spoken concerning him."

**18:20** And YHWH said: "The outcry of Sodom and Gomorrah—זַעֲקַת סְדֹם וַעֲמֹרָה (za'aqat Sedom va-Amorah)—is great, and their sin is very heavy.

**18:21** "I will go down now and see whether they have done altogether according to the outcry that has come unto me; and if not, I will know."

**18:22** And the men turned from there and went toward Sodom; and Abraham remained standing before YHWH.

**18:23** And Abraham drew near and said: "Will you also sweep away the righteous with the wicked?

**18:24** "Perhaps there are fifty righteous within the city; will you also sweep away and not spare the place for the fifty righteous that are within it?

**18:25** "Far be it from you to do such a thing—to slay the righteous with the wicked, so that the righteous should be as the wicked. Far be it from you! Shall not the Judge of all the earth do justice—הֲשֹׁפֵט כָּל־הָאָרֶץ לֹא יַעֲשֶׂה מִשְׁפָּט (ha-shofet kol-ha-aretz lo ya'aseh mishpat)?"

**18:26** And YHWH said: "If I find in Sodom fifty righteous within the city, then I will spare all the place for their sake."

**18:27** And Abraham answered and said: "Behold now, I have ventured to speak unto the Lord, though I am but dust and ashes.

**18:28** "Perhaps the fifty righteous will lack five; will you destroy all the city for lack of five?" And YHWH said: "I will not destroy it if I find forty-five there."

**18:29** And he spoke unto YHWH yet again and said: "Perhaps forty shall be found there." And YHWH said: "I will not do it for the sake of forty."

**18:30** And he said: "Let not the Lord be angry, and I will speak: Perhaps thirty shall be found there." And YHWH said: "I will not do it if I find thirty there."

**18:31** And he said: "Behold now, I have ventured to speak unto the Lord: Perhaps twenty shall be found there." And YHWH said: "I will not destroy it for the sake of twenty."

**18:32** And he said: "Let not the Lord be angry, and I will speak but this once: Perhaps ten shall be found there." And YHWH said: "I will not destroy it for the sake of ten."

**18:33** And YHWH went away when finished speaking with Abraham; and Abraham returned to his place.

---

## Synthesis Notes

**Key Restorations:**

**The Three Visitors:**
- The text moves fluidly between "three men," "they," and "YHWH." This is divine visitation in human form—theophany through hospitality.
- Abraham's extravagant welcome (running, bowing, washing feet, killing a calf) demonstrates the sacred obligation of hospitality—the contrast with Sodom's treatment of visitors in Chapter 19.

- *Ednah* (עֶדְנָה): Sarah's word for "pleasure"—related to Eden. The question is whether delight, fertility, and Edenic renewal are possible for the aged.

**Sarah's Laughter:**
- Both Abraham (17:17) and Sarah (18:12) laugh at the promise
- Sarah's laughter is internal—"within herself"
- When confronted, she denies from fear; YHWH gently insists: "No, but you did laugh"
- The laughter is not condemned—it becomes Isaac's name. Human incredulity at divine promise is incorporated into the promise itself.

**"Is anything too wondrous for YHWH?"** (הֲיִפָּלֵא מֵיהוָה דָּבָר):
- *Pala* (פלא) = to be wonderful, extraordinary, beyond normal capacity
- The question is rhetorical but genuine—Consciousness asks whether we can receive the impossible

**The Purpose of Knowing Abraham** (18:19):
- YHWH "knows" Abraham so that Abraham will teach "righteousness and justice" (צְדָקָה וּמִשְׁפָּט)
- This is the purpose of election—not privilege but transmission of ethical practice
- The covenant exists to spread justice

**The Outcry (זַעֲקָה, za'aqah):**
- The same word used for Israel's cry from Egyptian slavery (Exodus 2:23, 3:7)
- Sodom's sin generates an outcry that rises to heaven—the cry of the oppressed, the violated
- YHWH descends to investigate—remarkably, divine judgment requires verification

**Abraham's Intercession:**
- Abraham challenges YHWH's justice: "Shall not the Judge of all the earth do justice?"
- He negotiates from 50 down to 10 righteous—each time YHWH agrees
- This is not impudence but covenant partnership; Abraham exercises the moral agency that makes him worthy of being "known"

**The negotiation stops at ten**: Abraham doesn't go lower. Whether from exhaustion, embarrassment, or assumption that surely ten righteous exist, he stops. Ten will become the quorum (minyan) for Jewish communal prayer.

**Archetypal Layer:** The three visitors represent the numinous arriving in ordinary form—hospitality to strangers is hospitality to the divine. Sarah's laughter in the tent is the interior resistance to impossible promise. Abraham's intercession models the human capacity to challenge divine action on moral grounds—the creature can invoke justice against the Creator.

**Psychological Reading:** The internal laughter (Sarah) and the external challenge (Abraham) are two responses to the overwhelming. One doubts privately; the other argues publicly. Both are honored. The negotiation for Sodom is the ego's insistence that consciousness (YHWH) operate by moral principles the ego can recognize.

**Ethical Inversion Applied:**
- Traditional readings emphasize Sodom's coming destruction
- The restored reading emphasizes Abraham's intercession—**the human who argues for mercy is the moral center**
- YHWH agrees to every request; it is Abraham who stops asking

**Modern Equivalent:** How do we receive visitors—the stranger, the unexpected, the divine in disguise? And when systems are condemned for destruction, do we intercede? The question "Shall not the Judge of all the earth do justice?" remains the foundation of prophetic challenge to every authority, including the divine.

# Genesis Chapter 32: Jacob Wrestles with the Divine

*From the Hebrew: וַיִּשְׁלַח (Vayishlach) — And He Sent*

---

**32:1** And Jacob went on his way, and the messengers of Consciousness—מַלְאֲכֵי אֱלֹהִים (malakhei Elohim)—met him.

**32:2** And Jacob said when he saw them: "This is the camp of Consciousness—מַחֲנֵה אֱלֹהִים (machaneh Elohim)." And he called the name of that place Mahanaim—מַחֲנָיִם (Machanayim), meaning "Two Camps."

**32:3** And Jacob sent messengers before him to Esau his brother, to the land of Seir, the field of Edom.

**32:4** And he commanded them, saying: "Thus shall you say to my lord Esau: 'Thus says your servant Jacob: I have sojourned with Laban and stayed until now.

**32:5** "'And I have oxen and donkeys, flocks and male servants and female servants; and I have sent to tell my lord, to find favor in your eyes.'"

**32:6** And the messengers returned to Jacob, saying: "We came to your brother Esau, and he also is coming to meet you, and four hundred men with him."

**32:7** And Jacob was greatly afraid and distressed—וַיִּירָא יַעֲקֹב מְאֹד וַיֵּצֶר לוֹ (va-yira Ya'aqov me'od va-yetser lo); and he divided the people that were with him, and the flocks and the herds and the camels, into two camps.

**32:8** And he said: "If Esau comes to one camp and strikes it, then the camp that is left shall escape."

**32:9** And Jacob said: "O Consciousness of my father Abraham and Consciousness of my father Isaac, YHWH who said unto me, 'Return to your land and to your kindred, and I will do you good'—

**32:10** "I am less than all the kindnesses—חֲסָדִים (chasadim)—and all the truth which you have shown unto your servant; for with only my staff I crossed over this Jordan, and now I have become two camps.

**32:11** "Deliver me, please, from the hand of my brother, from the hand of Esau; for I fear him, lest he come and strike me, mother with children.

**32:12** "And you said, 'I will surely do you good, and will make your seed as the sand of the sea, which cannot be counted for multitude.'"

**32:13** And he lodged there that night; and he took from what came to his hand a present—מִנְחָה (minchah)—for Esau his brother:

**32:14** Two hundred female goats and twenty male goats, two hundred ewes and twenty rams,

**32:15** Thirty milking camels and their young, forty cows and ten bulls, twenty female donkeys and ten male donkeys.

**32:16** And he delivered them into the hand of his servants, each drove by itself, and said unto his servants: "Pass over before me, and put a space between drove and drove."

**32:17** And he commanded the first, saying: "When Esau my brother meets you and asks you, saying, 'Whose are you, and where are you going, and whose are these before you?'

**32:18** "Then you shall say, 'They belong to your servant Jacob; it is a present sent unto my lord Esau; and behold, he also is behind us.'"

**32:19** And he commanded also the second, also the third, also all that followed the droves, saying: "According to this word shall you speak unto Esau when you find him.

**32:20** "And you shall say, 'Moreover, behold, your servant Jacob is behind us.'" For he said: "I will appease his face—אֲכַפְּרָה פָנָיו (achaparah fanav)—with the present that goes before me, and afterward I will see his face; perhaps he will lift up my face—יִשָּׂא פָנָי (yissa fanai)."

**32:21** So the present passed over before him; and he lodged that night in the camp.

---

**32:22** And he rose up that night and took his two wives and his two maidservants and his eleven children, and crossed over the ford of the Jabbok—מַעֲבַר יַבֹּק (ma'avar Yabboq).

**32:23** And he took them and sent them across the stream, and sent across what he had.

**32:24** And Jacob was left alone—וַיִּוָּתֵר יַעֲקֹב לְבַדּוֹ (va-yivvater Ya'aqov levado); and a man wrestled with him—וַיֵּאָבֵק אִישׁ עִמּוֹ (va-ye'aveq ish immo)—until the breaking of dawn.

**32:25** And when the man saw that he could not prevail against him, he touched the socket of his thigh; and the socket of Jacob's thigh was dislocated as he wrestled with him.

**32:26** And the man said: "Let me go, for dawn is breaking." And Jacob said: "I will not let you go unless you bless me."

**32:27** And the man said unto him: "What is your name?" And he said: "Jacob."

**32:28** And the man said: "Your name shall no longer be called Jacob, but Israel—יִשְׂרָאֵל (Yisra'el)—for you have striven with Consciousness and with humans—כִּי־שָׂרִיתָ עִם־אֱלֹהִים וְעִם־אֲנָשִׁים (ki-sarita im-Elohim ve-im-anashim)—and have prevailed."

**32:29** And Jacob asked and said: "Tell me, please, your name." And the man said: "Why is it that you ask my name?" And he blessed him there.

**32:30** And Jacob called the name of the place Peniel—פְּנִיאֵל (Peni'el), "Face of God"—for he said: "I have seen Consciousness face to face—פָּנִים אֶל־פָּנִים (panim el-panim)—and my life has been preserved—וַתִּנָּצֵל נַפְשִׁי (va-tinnatsel nafshi)."

**32:31** And the sun rose upon him as he passed over Penuel—פְּנוּאֵל (Penu'el)—and he was limping on his thigh.

**32:32** Therefore the children of Israel do not eat the sinew of the thigh-socket—גִּיד הַנָּשֶׁה (gid ha-nasheh)—which is upon the socket of the thigh, unto this day; because the man touched the socket of Jacob's thigh, on the sinew of the thigh-socket.

---

## Synthesis Notes

**Key Restorations:**

**Mahanaim — "Two Camps":**
Jacob encounters divine messengers immediately after separating from Laban. The name he gives—"Two Camps"—foreshadows his division of his own company in fear of Esau. The divine camp and the human camp; the camp for survival and the camp for sacrifice.

**The Terror of Esau:**
"Greatly afraid and distressed" (וַיִּירָא...וַיֵּצֶר)—two different Hebrew words for fear/anxiety. Jacob dreads the brother he wronged. Twenty years have passed, but the debt remains.

**Jacob's Prayer (32:9-12):**
His first recorded prayer—humble, specific, honest:
- Acknowledges he is unworthy of God's kindness
- Recalls the promise made to him
- Names his fear explicitly
- Asks for deliverance
- Reminds God of God's own promise

This is mature prayer: gratitude, honesty, petition, appeal to covenant.

**The Gift Strategy:**
*Minchah* (מִנְחָה)—"present" or "tribute." Jacob sends 550+ animals in waves, each announced as "a present for my lord Esau." The language is political submission—"your servant Jacob," "my lord Esau."

*Achaparah fanav* (אֲכַפְּרָה פָנָיו)—"I will cover/appease his face." The root כָּפַר (kapar) is the same as "atonement." Jacob attempts to atone for his theft of the blessing.

**The Wrestling — Central Mystery:**

- *Va-yivvater Ya'aqov levado* (וַיִּוָּתֵר יַעֲקֹב לְבַדּוֹ): "Jacob was left alone"—complete isolation, the prerequisite for transformation
- *Va-ye'aveq ish immo* (וַיֵּאָבֵק אִישׁ עִמּוֹ): "A man wrestled with him"—wordplay on Jacob (יַעֲקֹב) and Jabbok (יַבֹּק) and wrestled (יֵאָבֵק). The sounds interweave.

**Who is "the man"?**
- An angel? (Hosea 12:4 says "he strove with an angel")
- YHWH? (Jacob says "I have seen God face to face")
- Esau's guardian spirit?
- Jacob's own shadow/past?
- All of these?

The text preserves the mystery. The adversary is called "ish" (man) but has power to bless, to rename, and cannot endure daylight.

**The Wound:**
The adversary cannot defeat Jacob, so he dislocates his hip. Jacob prevails but is permanently wounded. He will limp for the rest of his life. **Victory includes wounding.**

**"I Will Not Let You Go Unless You Bless Me":**
The blessing-thief now demands blessing from the divine adversary. What he stole from Esau through deception, he now wrests from God through perseverance.

**The Name Change:**
- *Ya'aqov* (יַעֲקֹב): "Heel-grabber, supplanter"—the name of deception
- *Yisra'el* (יִשְׂרָאֵל): "He strives with God" or "God strives" or "Prince of God"

The etymology given: "You have striven with Elohim and with humans and have prevailed." Jacob's wrestling is not just with God but with his whole life of human conflict—with Esau, with Laban, with himself.

**The Unnamed Adversary:**
"Why do you ask my name?"—the divine does not give a name. To know the name is to have power over. Jacob receives blessing but not mastery.

**Peniel — "Face of God":**
"I have seen Consciousness face to face and my life was preserved." This should be impossible (Exodus 33:20: "No one can see my face and live"). Yet Jacob survives—transformed, limping, renamed.

**The Dietary Law:**
The chapter ends with etiology—why Israel doesn't eat the sciatic nerve. The wrestling is remembered in every kosher slaughter.

**Archetypal Layer:** This is the supreme transformation narrative. Alone at the ford, between the old life (Laban) and the feared confrontation (Esau), Jacob meets the adversary who is also the source of blessing. The wrestling is with God and with his own shadow. The wound is the mark of authentic transformation—we don't emerge from such encounters unscathed. The new name is the new identity that emerges from the ordeal.

**Psychological Reading:** Before facing Esau (the wronged brother, the shadow projection), Jacob must face himself in the form of the numinous adversary. The wrestling is internal integration—the ego struggles with the Self, demands blessing, receives new identity, and is wounded. The limp is the mark of the initiated—those who have truly transformed carry visible signs.

**Modern Equivalent:** The night before the encounter we dread—facing what we've wronged, what we've fled—we wrestle. Sometimes the opponent is divine, sometimes our own conscience, sometimes both. We may prevail, but we emerge limping. The new name awaits those who refuse to let go until blessed. Israel—the entire people—is named for this single night of wrestling.

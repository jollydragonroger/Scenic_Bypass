# Genesis Chapter 11: The Tower and the Scattering

*From the Hebrew: Babel and the Line to Abraham*

---

**11:1** And all the earth was of one language—שָׂפָה אֶחָת (safah echat)—and of unified words—דְּבָרִים אֲחָדִים (devarim achadim).

**11:2** And it came to pass, as they journeyed from the east, that they found a plain in the land of Shinar; and they dwelt there.

**11:3** And they said to one another: "Come, let us make bricks and burn them thoroughly." And they had brick for stone, and bitumen they had for mortar.

**11:4** And they said: "Come, let us build for ourselves a city, and a tower with its top in the sky—וְרֹאשׁוֹ בַשָּׁמַיִם (ve-rosho va-shamayim)—and let us make for ourselves a name—שֵׁם (shem)—lest we be scattered upon the face of all the earth."

**11:5** And YHWH descended to see the city and the tower which the children of humanity were building.

**11:6** And YHWH said: "Behold, they are one people with one language for all of them, and this is what they begin to do; and now nothing that they purpose to do will be withheld from them—לֹא־יִבָּצֵר מֵהֶם (lo-yibatser mehem).

**11:7** "Come, let us go down and confuse—וְנָבְלָה (ve-navlah)—their language there, so that they will not understand one another's speech."

**11:8** And YHWH scattered them from there upon the face of all the earth; and they ceased building the city.

**11:9** Therefore its name was called Babel—בָּבֶל (Bavel)—because there YHWH confused—בָּלַל (balal)—the language of all the earth; and from there YHWH scattered them upon the face of all the earth.

---

**11:10** These are the generations of Shem. Shem was one hundred years old, and begot Arpachshad two years after the flood.

**11:11** And Shem lived after he begot Arpachshad five hundred years, and begot sons and daughters.

**11:12** And Arpachshad lived thirty-five years, and begot Shelah.

**11:13** And Arpachshad lived after he begot Shelah four hundred and three years, and begot sons and daughters.

**11:14** And Shelah lived thirty years, and begot Eber.

**11:15** And Shelah lived after he begot Eber four hundred and three years, and begot sons and daughters.

**11:16** And Eber lived thirty-four years, and begot Peleg.

**11:17** And Eber lived after he begot Peleg four hundred and thirty years, and begot sons and daughters.

**11:18** And Peleg lived thirty years, and begot Reu.

**11:19** And Peleg lived after he begot Reu two hundred and nine years, and begot sons and daughters.

**11:20** And Reu lived thirty-two years, and begot Serug.

**11:21** And Reu lived after he begot Serug two hundred and seven years, and begot sons and daughters.

**11:22** And Serug lived thirty years, and begot Nahor.

**11:23** And Serug lived after he begot Nahor two hundred years, and begot sons and daughters.

**11:24** And Nahor lived twenty-nine years, and begot Terah.

**11:25** And Nahor lived after he begot Terah one hundred and nineteen years, and begot sons and daughters.

**11:26** And Terah lived seventy years, and begot Abram, Nahor, and Haran.

---

**11:27** Now these are the generations of Terah. Terah begot Abram, Nahor, and Haran; and Haran begot Lot.

**11:28** And Haran died in the presence of his father Terah, in the land of his birth, in Ur of the Chaldeans.

**11:29** And Abram and Nahor took partners for themselves; the name of Abram's partner was Sarai, and the name of Nahor's partner was Milcah, the daughter of Haran, the father of Milcah and the father of Iscah.

**11:30** And Sarai was barren—עֲקָרָה (aqarah); she had no child.

**11:31** And Terah took Abram his son, and Lot the son of Haran, his grandson, and Sarai his daughter-in-law, the partner of Abram his son; and they went forth with them from Ur of the Chaldeans to go to the land of Canaan; and they came to Haran and dwelt there.

**11:32** And the days of Terah were two hundred and five years; and Terah transformed in Haran.

---

## Synthesis Notes

**Key Restorations:**

**The Tower of Babel — Ethical Inversion Applied:**

Traditional reading: Humans arrogantly tried to reach heaven; God punished them with confusion and scattering.

**Restored reading**: The Babel narrative is a critique of **imperial centralization**, not human aspiration.

- The builders want to "make a name for themselves" (שֵׁם)—to establish permanent fame and power
- They fear being "scattered"—they seek to prevent the natural diversification commanded in 9:1 ("fill the earth")
- They use artificial materials (brick for stone, bitumen for mortar)—manufactured uniformity replacing natural diversity
- The tower "with its top in the sky" represents the ziggurat—the Mesopotamian temple-state complex, the architecture of empire

**The "confusion" is actually liberation:**

- YHWH's action disperses humanity across the earth—**fulfilling the original blessing**, not punishing ambition
- Linguistic diversity prevents totalitarian unity—one language under one power
- The "scattering" creates the conditions for the Table of Nations' diversity

**Nimrod's Babel** (from 10:10) is the **beast/machine** of the symbol map—"uncontrolled systemic appetite, bureaucracy." YHWH's intervention breaks the machine.

- *Bavel/balal* (בָּבֶל/בָּלַל): The wordplay means "confusion," but Babylon itself claimed the name meant "Gate of God" (Bab-ili). The Hebrew text subverts imperial propaganda.

**The Decreasing Lifespans:**

Notice how lifespans drop from Shem (600 years) through the generations toward Abraham. The genealogy marks the transition from the mythic age of the patriarchs to the more "historical" era. Time is condensing.

**Sarai's Barrenness:**

The introduction of Sarai as עֲקָרָה (barren) sets up the central tension of the Abraham narrative. In the ancient world, barrenness was social death. The promise to Abraham will directly confront this impossibility.

**Ur of the Chaldeans:**

The journey begins in the heart of Mesopotamian civilization—leaving Babylon's orbit for an unknown destination.

**Archetypal Layer:** Babel represents the shadow side of human cooperation—unity that becomes uniformity, shared purpose that becomes totalitarian control. The diversity that results from Babel is not punishment but the necessary condition for genuine creativity. Monoculture (one language, one city, one name) is stagnation.

**Psychological Reading:** The ego's attempt to build a tower to heaven—to achieve transcendence through force of will and collective effort—must be disrupted. True connection to the transcendent cannot be manufactured. The dispersion forces individuation; only differentiated individuals can later choose authentic unity.

**Modern Equivalent:** Every empire, every totalizing system, every attempt to impose one language, one currency, one ideology upon all humanity is a Babel project. The "confusion" that breaks such projects is ultimately liberating. Diversity is not the problem to be solved but the solution that emerges when imperial projects fail.

The genealogy then narrows from the scattered nations to one family, one man—Abram—through whom a different kind of blessing will flow: not empire but covenant.

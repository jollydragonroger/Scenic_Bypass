# Genesis Chapter 40: The Dreams in Prison

*From the Hebrew: The Cupbearer and the Baker*

---

**40:1** And it came to pass after these things, that the cupbearer of the king of Egypt—מַשְׁקֵה מֶלֶךְ־מִצְרַיִם (mashqeh melech-Mitsrayim)—and the baker—הָאֹפֶה (ha-ofeh)—offended their lord, the king of Egypt.

**40:2** And Pharaoh was angry with his two officers, with the chief cupbearer and with the chief baker.

**40:3** And he put them in custody in the house of the captain of the guard, into the prison—בֵּית הַסֹּהַר (beit ha-sohar)—the place where Joseph was bound.

**40:4** And the captain of the guard charged Joseph with them, and he served them; and they were in custody for some days.

**40:5** And they both dreamed a dream, each man his dream in one night, each man according to the interpretation of his dream—the cupbearer and the baker of the king of Egypt, who were bound in the prison.

**40:6** And Joseph came in unto them in the morning and saw them, and behold, they were troubled—זֹעֲפִים (zo'afim).

**40:7** And he asked Pharaoh's officers who were with him in custody in his master's house, saying: "Why are your faces evil—רָעִים (ra'im)—today?"

**40:8** And they said unto him: "We have dreamed a dream, and there is no interpreter for it." And Joseph said unto them: "Do not interpretations belong to Consciousness—הֲלוֹא לֵאלֹהִים פִּתְרֹנִים (ha-lo l'Elohim pitronim)? Tell it to me, please."

**40:9** And the chief cupbearer told his dream to Joseph, and said unto him: "In my dream, behold, a vine was before me.

**40:10** "And on the vine were three branches; and it was as though it budded—its blossoms shot forth, and its clusters brought forth ripe grapes.

**40:11** "And Pharaoh's cup was in my hand; and I took the grapes and pressed them into Pharaoh's cup, and I placed the cup upon Pharaoh's palm."

**40:12** And Joseph said unto him: "This is the interpretation: The three branches are three days.

**40:13** "In three days Pharaoh will lift up your head—יִשָּׂא פַרְעֹה אֶת־רֹאשֶׁךָ (yissa Par'oh et-roshecha)—and will restore you unto your position; and you shall place Pharaoh's cup into his hand, according to the former manner when you were his cupbearer.

**40:14** "But remember me—כִּי אִם־זְכַרְתַּנִי (ki im-zechartani)—when it is well with you, and please deal kindly—חֶסֶד (chesed)—with me, and mention me unto Pharaoh, and bring me out of this house.

**40:15** "For indeed I was stolen—גֻּנֹּב גֻּנַּבְתִּי (gunnov gunnabti)—from the land of the Hebrews; and here also I have done nothing that they should put me into the pit—הַבּוֹר (ha-bor)."

**40:16** And the chief baker saw that the interpretation was good, and he said unto Joseph: "I also was in my dream, and behold, three baskets of white bread—סַלֵּי חֹרִי (sallei chori)—were upon my head.

**40:17** "And in the uppermost basket were all manner of baked goods for Pharaoh, and the birds were eating them out of the basket upon my head."

**40:18** And Joseph answered and said: "This is the interpretation: The three baskets are three days.

**40:19** "In three days Pharaoh will lift up your head from upon you—יִשָּׂא פַרְעֹה אֶת־רֹאשְׁךָ מֵעָלֶיךָ (yissa Par'oh et-roshcha me'alecha)—and will hang you upon a tree; and the birds shall eat your flesh from upon you."

**40:20** And it came to pass on the third day, Pharaoh's birthday—יוֹם הֻלֶּדֶת אֶת־פַּרְעֹה (yom hulledet et-Par'oh)—that Pharaoh made a feast for all his servants; and he lifted up the head of the chief cupbearer and the head of the chief baker among his servants.

**40:21** And he restored the chief cupbearer unto his cupbearing; and he placed the cup upon Pharaoh's palm.

**40:22** And the chief baker he hanged, as Joseph had interpreted unto them.

**40:23** And the chief cupbearer did not remember Joseph, and forgot him—וַיִּשְׁכָּחֵהוּ (va-yishkachehu).

---

## Synthesis Notes

**Key Restorations:**

**The Officials:**
The *mashqeh* (cupbearer) and *ofeh* (baker) are high court officials—the cupbearer personally serves Pharaoh's drink (a position of intimate trust), and the baker oversees royal food. Both are in prison for unspecified offenses against Pharaoh.

**Joseph as Servant:**
Even in prison, Joseph is assigned to serve others. His pattern continues: wherever placed, he rises to responsibility, even among the incarcerated.

**The Troubled Faces:**
Joseph notices their distress and asks. This attentiveness—seeing others' states and inquiring—is characteristic of his later wisdom. He does not merely survive prison; he engages with those around him.

**"Do Not Interpretations Belong to Consciousness?":**
Joseph immediately redirects the interpretive authority to the divine. He is not claiming personal magical power but serving as a channel for divine insight. This will be his consistent stance before Pharaoh as well (41:16).

**The Dreams:**
Both dreams involve threes (branches, baskets), both involve Pharaoh, both have clear symbolic actions. But the outcomes differ completely:
- Cupbearer: vine flourishes → grapes pressed → cup placed in Pharaoh's hand = restoration
- Baker: bread baskets → birds eating from basket = execution

**The Wordplay:**
"Lift up your head" (יִשָּׂא...רֹאשֶׁךָ) appears in both interpretations—but with opposite meanings:
- Cupbearer: Pharaoh will "lift up your head" = restore your honor
- Baker: Pharaoh will "lift up your head from upon you" = decapitate/hang you

The same phrase, twisted, reveals opposite fates.

**Joseph's Request:**
He asks the cupbearer to remember him—*zechartani*, "remember me." He reveals his story:
- "Stolen" from the land of the Hebrews (he doesn't mention his brothers' betrayal to this Egyptian)
- "Done nothing" to deserve the pit (he uses *bor*, the same word for the pit his brothers threw him into)

Joseph asserts his innocence and requests advocacy.

**The Pharaoh's Birthday:**
The fulfillment occurs on Pharaoh's birthday—a day of royal celebration and judgment. Both outcomes happen as Joseph predicted. The cupbearer is restored; the baker is executed.

**The Forgetting:**
"The chief cupbearer did not remember Joseph, and forgot him." The doubling (*lo zachar...va-yishkachehu*) emphasizes the completeness of the failure. Joseph waits two more years in prison (41:1) because of this forgetting.

**Archetypal Layer:** Joseph is the dream-interpreter who cannot control his own fate. He sees clearly into others' futures but remains stuck in prison. The cupbearer's forgetting is the delay that tests perseverance—the promise of rescue that doesn't come when expected.

**Psychological Reading:** The ability to interpret dreams—to access unconscious meaning—does not exempt one from suffering or waiting. Joseph can decode the psyche's symbols but cannot accelerate his own liberation. The ego's gifts do not override the timing of the larger process.

**Ethical Inversion Applied:**
- Traditional reading focuses on Joseph's interpretive gift
- **Restored reading**: Notes the pathos of the forgetting
- Joseph does everything right—serves, observes, interprets, requests—and is still forgotten
- The cupbearer's failure is not malice but ordinary human self-absorption
- Divine timing includes inexplicable delays

**Modern Equivalent:** Those who help others in crisis often find that when the crisis passes, they are forgotten. "Remember me when it is well with you" is a request that goes unfulfilled constantly. The helper in the pit waits while the helped returns to normal life. And sometimes, eventually, something triggers remembrance (41:9).

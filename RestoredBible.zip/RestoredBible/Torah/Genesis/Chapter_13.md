# Genesis Chapter 13: The Separation of Abram and Lot

*From the Hebrew: Choosing the Land*

---

**13:1** And Abram went up from Egypt—he, and his partner, and all that he had, and Lot with him—into the Negev.

**13:2** And Abram was very wealthy—כָּבֵד מְאֹד (kaved me'od)—in livestock, in silver, and in gold.

**13:3** And he went on his journeys from the Negev unto Bethel, unto the place where his tent had been at the beginning, between Bethel and Ai,

**13:4** Unto the place of the altar which he had made there at first; and there Abram called upon the name of YHWH.

**13:5** And Lot also, who went with Abram, had flocks and herds and tents.

**13:6** And the land could not bear them dwelling together, for their possessions were great, and they could not dwell together.

**13:7** And there was strife between the herders of Abram's livestock and the herders of Lot's livestock. And the Canaanite and the Perizzite were then dwelling in the land.

**13:8** And Abram said unto Lot: "Please let there be no strife between me and you, and between my herders and your herders, for we are people who are brothers—אֲנָשִׁים אַחִים (anashim achim).

**13:9** "Is not all the land before you? Please separate from me. If you go to the left, then I will go to the right; or if you go to the right, then I will go to the left."

**13:10** And Lot lifted up his eyes and saw all the plain of the Jordan, that it was well-watered everywhere—before YHWH destroyed Sodom and Gomorrah—like the garden of YHWH, like the land of Egypt, as you come to Zoar.

**13:11** And Lot chose for himself all the plain of the Jordan; and Lot journeyed eastward. And they separated, each from his brother.

**13:12** Abram dwelt in the land of Canaan, and Lot dwelt in the cities of the plain, and pitched his tent toward Sodom.

**13:13** And the men of Sodom were exceedingly wicked and sinful—רָעִים וְחַטָּאִים (ra'im ve-chatta'im)—against YHWH.

**13:14** And YHWH said unto Abram, after Lot had separated from him: "Lift up now your eyes and look from the place where you are—northward and southward and eastward and westward.

**13:15** "For all the land which you see, to you I will give it, and to your seed, forever.

**13:16** "And I will make your seed as the dust of the earth; so that if one can count the dust of the earth, then your seed also can be counted.

**13:17** "Arise, walk through the land in its length and in its breadth, for to you I will give it."

**13:18** And Abram moved his tent and came and dwelt by the oaks of Mamre—אֵלֹנֵי מַמְרֵא (elonei Mamre)—which are in Hebron; and there he built an altar to YHWH.

---

## Synthesis Notes

**Key Restorations:**

- *Kaved* (כָּבֵד): "Heavy" or "wealthy"—the same root as "glory" (kavod). Abram's material weight has increased through his Egypt sojourn. Prosperity is not condemned, but it creates new problems.

- **The strife over resources**: Ecological limits generate conflict. The land cannot sustain both households together. This is presented as natural consequence, not moral failure.

- **Abram's generosity**: He offers Lot first choice, deferring to his nephew. This contrasts with the self-protective deception of Chapter 12. Character develops unevenly.

- **Lot's choice**: He looks toward what appears most abundant—the well-watered Jordan plain, compared to Eden and Egypt. But the narrator immediately notes: "the men of Sodom were exceedingly wicked." Lot chooses by appearance; the deeper reality is unseen.

- **"Pitched his tent toward Sodom"**: The Hebrew emphasizes direction and attraction. Lot's trajectory is toward the city of dysfunction, drawn by its apparent abundance.

- *Ra'im ve-chatta'im* (רָעִים וְחַטָּאִים): "Wicked and sinful"—the text foreshadows Sodom's fate without yet specifying the nature of its wickedness. Later chapters will reveal it as violence, inhospitality, and exploitation of the vulnerable.

- **The land promise renewed**: After separation from Lot, YHWH expands the promise. Abram is told to walk the land—to embody his claim through physical presence. The promise is to "seed" (זֶרַע, zera)—descendants, but also metaphorically, whatever grows from what is planted.

- *Elonei Mamre* (אֵלֹנֵי מַמְרֵא): "Oaks of Mamre"—another sacred grove. Mamre will become a central location for Abram/Abraham's encounters with the divine. The oak/terebinth is the axis mundi, the meeting place of realms.

**Archetypal Layer:** Separation from kin is a necessary stage of individuation. Abram and Lot represent two paths: Abram remains in the highlands, dwelling by sacred trees, building altars; Lot descends to the plain, attracted to urban wealth. The highlands/lowlands contrast maps onto consciousness/unconsciousness, spiritual aspiration/material absorption.

**Psychological Reading:** The choice between Abram's path and Lot's path is the choice between delayed gratification (the seemingly less fertile highland) and immediate abundance (the lush plain that hides corruption). Lot chooses what looks good; Abram receives what is promised. Both are family; both will survive; but their fates diverge.

**Ecological Reading:** Resource competition generates conflict. The solution here is geographical separation—expanding the territory. But this is a temporary solution; the larger narrative will show that Lot's rich plain is unsustainable (Sodom's destruction). Apparent abundance can mask systemic dysfunction.

**Modern Equivalent:** Prosperity creates new problems. When resources strain, families and communities must negotiate separation or conflict. The choice "toward Sodom"—toward apparent wealth that conceals exploitation—is perennial. The alternative is dwelling by the oaks, in apparent scarcity, but connected to deeper sources.

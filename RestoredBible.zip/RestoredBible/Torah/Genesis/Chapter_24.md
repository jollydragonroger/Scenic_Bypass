# Genesis Chapter 24: The Finding of Rebekah

*From the Hebrew: The Servant's Mission*

---

**24:1** And Abraham was old, advanced in days; and YHWH had blessed Abraham in all things.

**24:2** And Abraham said unto his servant, the elder of his house who ruled over all that he had: "Please place your hand under my thigh—תַּחַת יְרֵכִי (tachat yerechi).

**24:3** "And I will make you swear by YHWH, the Consciousness of the heavens and the Consciousness of the earth, that you will not take a wife for my son from the daughters of the Canaanites among whom I dwell.

**24:4** "But to my land and to my kindred you shall go, and take a wife for my son Isaac."

**24:5** And the servant said unto him: "Perhaps the woman will not be willing to follow me unto this land; shall I then bring your son back unto the land from which you came?"

**24:6** And Abraham said unto him: "Guard yourself lest you bring my son there again.

**24:7** "YHWH, the Consciousness of the heavens, who took me from my father's house and from the land of my kindred, and who spoke unto me and who swore unto me, saying, 'To your seed I will give this land'—YHWH will send the messenger before you, and you shall take a wife for my son from there.

**24:8** "And if the woman is not willing to follow you, then you shall be clear from this my oath; only do not bring my son there again."

**24:9** And the servant placed his hand under the thigh of Abraham his master, and swore to him concerning this matter.

**24:10** And the servant took ten camels from the camels of his master, and departed; and all the goods of his master were in his hand; and he arose and went to Aram-naharaim, to the city of Nahor.

**24:11** And he made the camels kneel down outside the city by the well of water, at evening time, the time when the women go out to draw water.

**24:12** And he said: "YHWH, Consciousness of my master Abraham, please cause it to happen before me today, and show kindness—חֶסֶד (chesed)—unto my master Abraham.

**24:13** "Behold, I am standing by the spring of water, and the daughters of the men of the city are coming out to draw water.

**24:14** "And let it be that the young woman to whom I shall say, 'Please let down your jar that I may drink,' and she shall say, 'Drink, and I will also give your camels drink'—let her be the one you have appointed for your servant Isaac; and by this I shall know that you have shown kindness unto my master."

**24:15** And it came to pass, before he had finished speaking, that behold, Rebekah—רִבְקָה (Rivqah)—came out, who was born to Bethuel the son of Milcah, the wife of Nahor, Abraham's brother; and her jar was upon her shoulder.

**24:16** And the young woman was very fair to look upon, a virgin—בְּתוּלָה (betulah)—and no man had known her; and she went down to the spring and filled her jar and came up.

**24:17** And the servant ran to meet her and said: "Please let me drink a little water from your jar."

**24:18** And she said: "Drink, my lord"; and she hurried and let down her jar upon her hand, and gave him drink.

**24:19** And when she had finished giving him drink, she said: "I will also draw for your camels, until they have finished drinking."

**24:20** And she hurried and emptied her jar into the trough, and ran again unto the well to draw, and drew for all his camels.

**24:21** And the man gazed at her in silence, to know whether YHWH had made his journey successful or not.

**24:22** And it came to pass, when the camels had finished drinking, that the man took a gold ring—נֶזֶם זָהָב (nezem zahav)—of half a shekel weight, and two bracelets for her hands of ten shekels weight of gold,

**24:23** And said: "Whose daughter are you? Tell me, please: is there room in your father's house for us to lodge?"

**24:24** And she said unto him: "I am the daughter of Bethuel the son of Milcah, whom she bore unto Nahor."

**24:25** And she said unto him: "We have both straw and feed in plenty, and room to lodge."

**24:26** And the man bowed his head and worshipped YHWH.

**24:27** And he said: "Blessed be YHWH, the Consciousness of my master Abraham, who has not forsaken the kindness—חֶסֶד (chesed)—and the truth—אֱמֶת (emet)—toward my master; as for me, YHWH has led me on the way to the house of my master's kinsmen."

**24:28** And the young woman ran and told her mother's house these things.

**24:29** And Rebekah had a brother whose name was Laban; and Laban ran out unto the man, to the spring.

**24:30** And it came to pass, when he saw the ring and the bracelets upon his sister's hands, and when he heard the words of Rebekah his sister saying, "Thus spoke the man unto me," that he came unto the man; and behold, he was standing by the camels at the spring.

**24:31** And he said: "Come in, blessed of YHWH! Why do you stand outside? For I have prepared the house, and room for the camels."

**24:32** And the man came into the house; and Laban ungirded the camels, and gave straw and feed to the camels, and water to wash his feet and the feet of the men who were with him.

**24:33** And food was set before him to eat; but he said: "I will not eat until I have spoken my words." And Laban said: "Speak."

**24:34** And he said: "I am Abraham's servant.

**24:35** "And YHWH has greatly blessed my master, and he has become great; and YHWH has given him flocks and herds, and silver and gold, and male servants and female servants, and camels and donkeys.

**24:36** "And Sarah my master's wife bore a son to my master after she had grown old; and he has given him all that he has.

**24:37** "And my master made me swear, saying: 'You shall not take a wife for my son from the daughters of the Canaanites in whose land I dwell;

**24:38** "But you shall go unto my father's house and to my family, and take a wife for my son.'

**24:39** "And I said unto my master: 'Perhaps the woman will not follow me.'

**24:40** "And he said unto me: 'YHWH, before whom I have walked, will send the messenger with you and prosper your way; and you shall take a wife for my son from my family and from my father's house.

**24:41** "Then you shall be clear from my oath, when you come to my family; and if they give her not to you, you shall be clear from my oath.'

**24:42** "And I came today unto the spring and said: 'YHWH, Consciousness of my master Abraham, if now you are prospering my way upon which I go—

**24:43** "Behold, I am standing by the spring of water; and let it be that the young woman who comes out to draw, to whom I shall say, "Please give me a little water from your jar to drink,"

**24:44** "And she shall say unto me, "Both drink yourself, and I will also draw for your camels"—let her be the woman whom YHWH has appointed for my master's son.'

**24:45** "Before I had finished speaking in my heart, behold, Rebekah came out with her jar upon her shoulder; and she went down unto the spring and drew; and I said unto her: 'Please let me drink.'

**24:46** "And she hurried and let down her jar from upon her and said: 'Drink, and I will also give your camels drink'; so I drank, and she gave the camels drink also.

**24:47** "And I asked her and said: 'Whose daughter are you?' And she said: 'The daughter of Bethuel, son of Nahor, whom Milcah bore unto him.' And I put the ring upon her nose and the bracelets upon her hands.

**24:48** "And I bowed my head and worshipped YHWH, and blessed YHWH, the Consciousness of my master Abraham, who had led me on the right way to take my master's brother's daughter for his son.

**24:49** "And now, if you will deal kindly and truly—חֶסֶד וֶאֱמֶת (chesed ve-emet)—with my master, tell me; and if not, tell me, that I may turn to the right or to the left."

**24:50** And Laban and Bethuel answered and said: "The thing comes forth from YHWH; we cannot speak unto you bad or good.

**24:51** "Behold, Rebekah is before you; take her and go, and let her be wife to your master's son, as YHWH has spoken."

**24:52** And it came to pass, when Abraham's servant heard their words, that he worshipped YHWH, bowing to the ground.

**24:53** And the servant brought forth vessels of silver and vessels of gold and garments, and gave them to Rebekah; and precious things he gave to her brother and to her mother.

**24:54** And they ate and drank, he and the men who were with him, and lodged. And they rose in the morning, and he said: "Send me away unto my master."

**24:55** And her brother and her mother said: "Let the young woman stay with us a few days, at least ten; after that she shall go."

**24:56** And he said unto them: "Do not delay me, seeing that YHWH has prospered my way; send me away that I may go to my master."

**24:57** And they said: "We will call the young woman and ask her mouth."

**24:58** And they called Rebekah and said unto her: "Will you go with this man?" And she said: "I will go—אֵלֵךְ (elech)."

**24:59** And they sent away Rebekah their sister and her nurse, and Abraham's servant and his men.

**24:60** And they blessed Rebekah and said unto her: "Our sister, may you become thousands of ten thousands, and may your seed possess the gate of those who hate them."

**24:61** And Rebekah arose, and her young women, and they rode upon the camels and followed the man; and the servant took Rebekah and went.

**24:62** And Isaac had come from the way of Beer-lahai-roi—בְּאֵר לַחַי רֹאִי; for he was dwelling in the land of the Negev.

**24:63** And Isaac went out to meditate—לָשׂוּחַ (lasuach)—in the field toward evening; and he lifted up his eyes and looked, and behold, camels were coming.

**24:64** And Rebekah lifted up her eyes and saw Isaac; and she alighted from the camel.

**24:65** And she said unto the servant: "Who is that man walking in the field to meet us?" And the servant said: "It is my master." And she took the veil and covered herself.

**24:66** And the servant told Isaac all the things that he had done.

**24:67** And Isaac brought her into the tent of Sarah his mother; and he took Rebekah, and she became his wife, and he loved her; and Isaac was comforted after his mother.

---

## Synthesis Notes

**Key Restorations:**

**The Oath Under the Thigh:**
- *Tachat yerechi* (תַּחַת יְרֵכִי): "Under my thigh"—a euphemism related to the genitals and thus to descendants. The oath concerns Isaac's marriage; the gesture invokes the very source of seed.

**The Servant:**
- Though traditionally identified with Eliezer (15:2), he is unnamed throughout this chapter
- He acts with perfect faithfulness, representing how covenant obligations are carried out
- His prayer is immediate and specific; the answer is immediate and complete

**Chesed and Emet (חֶסֶד וֶאֱמֶת):**
- "Kindness/loyalty and truth/faithfulness"—the paired virtues that characterize covenant relationship
- The servant uses these words for YHWH's guidance (24:27) and asks them of the family (24:49)

**Rebekah's Agency:**
- She is described as beautiful, virgin, hospitable, energetic (runs, draws water for ten camels—hundreds of gallons)
- Critically: **she is asked for her consent** (24:57-58)
- Her response—"I will go" (אֵלֵךְ)—echoes Abraham's "lech-lecha"
- She leaves her land, her kindred, her father's house—the same pattern as Abraham

**Laban's Motivation:**
The text notes (24:30) that Laban saw the jewelry before running to welcome the servant. This foreshadows Laban's character in Jacob's story—hospitality with an eye to profit.

**Beer-lahai-roi:**
Isaac dwells by "the Well of the Living One Who Sees"—Hagar's well (16:14). The son of Sarah lives by the well named by Sarah's rival. The threads interweave.

**Isaac Meditating:**
- *Lasuach* (לָשׂוּחַ): "To meditate" or "to commune"—Isaac is contemplative, introspective. This is almost his only recorded action in the chapter. He is passive compared to the energetic Rebekah.

**"Comforted After His Mother":**
The chapter ends with Isaac finding comfort after Sarah's death through Rebekah. The wife replaces the mother; the tent continues; grief is eased but not erased.

**Archetypal Layer:** This is the sacred marriage—the finding of the bride through divine guidance, tests of character (hospitality, generosity), and mutual consent. The servant represents the psyche's faithful function that seeks the appropriate match. Rebekah's "I will go" is the feminine answering the call, leaving the familiar for the unknown.

**Psychological Reading:** Isaac, traumatized and passive after the Aqedah, waits in meditation. The bride must be found and brought to him. Rebekah's energy and agency complement his contemplative stillness. The marriage integrates active and receptive, journey and waiting.

**Modern Equivalent:** How do we find life partners? The servant models: clear criteria (family, values), prayer, attention to signs (character revealed in action), respect for the other's consent. Rebekah models: the willingness to leap, to leave the known, to say "I will go" when the opportunity appears.

# Genesis Chapter 49: Jacob's Blessing of the Twelve Sons

*From the Hebrew: וַיְחִי (Vayechi) — And He Lived*

---

**49:1** And Jacob called unto his sons and said: "Gather yourselves together, that I may tell you what shall befall you in the end of days—בְּאַחֲרִית הַיָּמִים (be-acharit ha-yamim).

**49:2** "Assemble and hear, sons of Jacob; and listen unto Israel your father.

---

**49:3** "Reuben, you are my firstborn, my might and the beginning of my strength—רֵאשִׁית אוֹנִי (reshit oni); preeminent in dignity and preeminent in power.

**49:4** "Unstable as water—פַּחַז כַּמַּיִם (pachaz ka-mayim)—you shall not have preeminence, because you went up to your father's bed; then you defiled it—he went up to my couch."

---

**49:5** "Simeon and Levi are brothers; instruments of violence are their swords—כְּלֵי חָמָס מְכֵרֹתֵיהֶם (kelei chamas mecheroteihem).

**49:6** "Into their council let my soul not come; unto their assembly let my glory not be united; for in their anger they killed men, and in their willfulness they hamstrung oxen.

**49:7** "Cursed be their anger, for it was fierce, and their wrath, for it was cruel. I will divide them in Jacob and scatter them in Israel."

---

**49:8** "Judah, you—your brothers shall praise you—יוֹדוּךָ (yoducha); your hand shall be on the neck of your enemies; your father's sons shall bow down before you.

**49:9** "Judah is a lion's cub—גּוּר אַרְיֵה (gur aryeh); from the prey, my son, you have gone up. He stooped down, he crouched as a lion, and as a lioness—who shall rouse him?

**49:10** "The scepter shall not depart from Judah, nor the ruler's staff from between his feet, until Shiloh comes—עַד כִּי־יָבֹא שִׁילֹה (ad ki-yavo Shiloh)—and unto him shall be the obedience of the peoples.

**49:11** "Binding his foal unto the vine, and his donkey's colt unto the choice vine; he washes his garments in wine and his robe in the blood of grapes.

**49:12** "His eyes are darker than wine, and his teeth whiter than milk."

---

**49:13** "Zebulun shall dwell at the shore of the sea; and he shall be a haven for ships, and his border shall be unto Sidon."

---

**49:14** "Issachar is a strong donkey—חֲמֹר גָּרֶם (chamor garem)—crouching between the sheepfolds.

**49:15** "And he saw that rest was good and that the land was pleasant; and he bowed his shoulder to bear, and became a servant under taskwork."

---

**49:16** "Dan shall judge his people—דָּן יָדִין עַמּוֹ (Dan yadin ammo)—as one of the tribes of Israel.

**49:17** "Dan shall be a serpent by the way—נָחָשׁ עֲלֵי־דֶרֶךְ (nachash alei-derech)—an adder in the path, that bites the horse's heels, so that his rider falls backward.

**49:18** "For your salvation I wait, O YHWH!—לִישׁוּעָתְךָ קִוִּיתִי יהוה (li-yeshu'atecha qivviti YHWH)."

---

**49:19** "Gad—a raiding band shall raid him—גָּד גְּדוּד יְגוּדֶנּוּ (Gad gedud yegudennu)—but he shall raid at their heel."

---

**49:20** "From Asher, his bread shall be fat—שְׁמֵנָה לַחְמוֹ (shemenah lachmo)—and he shall yield royal delicacies."

---

**49:21** "Naphtali is a hind let loose—אַיָּלָה שְׁלֻחָה (ayyalah sheluchah)—who gives beautiful words."

---

**49:22** "Joseph is a fruitful bough—בֵּן פֹּרָת יוֹסֵף (ben porat Yosef)—a fruitful bough by a spring; his branches run over the wall.

**49:23** "The archers bitterly attacked him, and shot at him, and hated him.

**49:24** "But his bow remained steady, and his arms were made agile by the hands of the Mighty One of Jacob, by the name of the Shepherd, the Stone of Israel—אֶבֶן יִשְׂרָאֵל (Even Yisra'el).

**49:25** "By the God of your father who will help you, and by Shaddai who will bless you—blessings of the heavens above, blessings of the deep that couches beneath, blessings of the breasts and of the womb.

**49:26** "The blessings of your father have prevailed above the blessings of my progenitors, unto the utmost bound of the everlasting hills. They shall be upon the head of Joseph, and upon the crown of the head of the one set apart—נְזִיר (nezir)—from his brothers."

---

**49:27** "Benjamin is a ravenous wolf—זְאֵב יִטְרָף (ze'ev yitraf); in the morning he devours the prey, and at evening he divides the spoil."

---

**49:28** All these are the twelve tribes of Israel, and this is what their father spoke unto them and blessed them; each according to his blessing he blessed them.

**49:29** And he commanded them and said unto them: "I am to be gathered unto my people; bury me with my fathers in the cave that is in the field of Ephron the Hittite,

**49:30** "In the cave that is in the field of Machpelah, which is before Mamre, in the land of Canaan, which Abraham bought with the field from Ephron the Hittite for a possession of a burial place.

**49:31** "There they buried Abraham and Sarah his wife; there they buried Isaac and Rebekah his wife; and there I buried Leah.

**49:32** "The purchase of the field and of the cave that is therein was from the children of Heth."

**49:33** And Jacob finished commanding his sons, and he gathered up his feet into the bed, and expired, and was gathered unto his people.

---

## Synthesis Notes

**Key Restorations:**

**"The End of Days" (בְּאַחֲרִית הַיָּמִים):**
Jacob's blessing is prophetic—not merely describing character but foretelling destiny. "The end of days" suggests distant future, eschatological horizon.

**Reuben — The Fallen Firstborn:**
Despite being firstborn with natural preeminence, Reuben loses his status. "Unstable as water" (פַּחַז כַּמַּיִם)—the transgression with Bilhah (35:22) disqualifies him. His descendants never achieve prominence.

**Simeon and Levi — Scattered for Violence:**
The massacre at Shechem (Chapter 34) is remembered and condemned. Their anger was "fierce," their wrath "cruel." The curse: they will be divided and scattered. Simeon is later absorbed into Judah's territory; Levi has no territorial inheritance but becomes the priestly tribe—the scattering becomes sacred service.

**Judah — The Royal Tribe:**

The longest and most significant blessing:
- Lion imagery—power, majesty, danger
- "Your brothers shall praise you"—wordplay on Judah/yodah (praise)
- "The scepter shall not depart"—royal authority promised

*Shiloh* (שִׁילֹה): This phrase is famously difficult. Interpretations include:
- "Until he comes to Shiloh" (a place)
- "Until Shiloh comes" (a person/messiah)
- *Shay-lo* (שַׁי לוֹ)—"tribute to him"
- *Shello* (שֶׁלּוֹ)—"that which is his"

Messianic tradition reads this as prophecy of a coming ruler from Judah. The restoration notes the ambiguity without forcing resolution.

**Zebulun — Maritime Tribe:**
Assigned to the seacoast and ships, though historically Zebulun's territory was inland. The blessing may reflect trade relationships or aspirations.

**Issachar — The Burden-Bearer:**
A strong donkey who sees the pleasant land and accepts servitude for rest. This may reflect Issachar's agricultural role or subjugation to Canaanite labor demands.

**Dan — The Serpent Judge:**
*Dan* means "judge" (דָּן/דִּין). The serpent imagery is striking—Dan bites at heels like the serpent in Eden. Samson, the most famous Danite, embodies this guerrilla-warrior quality. 

The sudden interjection—"For your salvation I wait, O YHWH!"—may be Jacob's prayer mid-prophecy, or a later liturgical addition.

**Gad — Raided and Raiding:**
Wordplay on *Gad/gedud* (raiding band). A border tribe facing constant attack, but resilient.

**Asher — Abundance:**
Rich food, royal delicacies—Asher's coastal territory was agriculturally fertile.

**Naphtali — Swift and Eloquent:**
A freed deer giving beautiful words—perhaps referring to swift warriors or eloquent speakers.

**Joseph — The Blessed Prince:**

The second-longest blessing, lavish in imagery:
- "Fruitful bough"—abundance and growth
- "Archers attacked him"—reference to his brothers' hatred and his Egyptian trials
- "His bow remained steady"—he endured and prevailed
- Divine titles: "Mighty One of Jacob," "Shepherd," "Stone of Israel"—unique names appearing only here
- Blessings of heaven, deep, breasts, womb—comprehensive fertility blessing

*Nezir* (נְזִיר): "Separated one" or "consecrated one"—the same root as Nazirite. Joseph was set apart from his brothers by destiny.

**Benjamin — The Predator:**
A ravenous wolf—aggressive, successful in war. The tribe of Benjamin produced Saul (first king) and was known for fierce warriors (Judges 20).

**Jacob's Death:**
He commands burial at Machpelah—with Abraham, Sarah, Isaac, Rebekah, and Leah. Note: Rachel is not there; she is buried on the road to Bethlehem. Even in death, Jacob joins Leah, not Rachel.

"Gathered his feet into the bed"—he had been sitting or dangling his legs; now he draws them up, lies down, and dies. "Gathered unto his people"—joining the ancestors.

**Archetypal Layer:** The dying patriarch's blessing distributes destiny among his sons. Each receives according to his nature and deed—character becomes fate. The twelve become the structure of a nation, each with distinctive identity.

**Psychological Reading:** Jacob's final words integrate his entire experience. He acknowledges failures (Reuben's transgression, Simeon and Levi's violence), elevates the transformed (Judah, Joseph), and assigns roles to all. This is the final act of patriarchal consciousness—organizing the future through naming and blessing.

**Ethical Inversion Applied:**
- The blessings are not uniformly positive—Reuben, Simeon, and Levi receive critique
- Violence (Shechem) is condemned even decades later
- The firstborn loses preeminence; Judah and Joseph are elevated
- The pattern of inversion continues through the tribal blessings

**Modern Equivalent:** How we end matters. Jacob's last words shape his sons' futures. The dying often speak truths that life's busyness obscured. And the distribution of blessing/legacy among descendants carries forward the complexities of family history.

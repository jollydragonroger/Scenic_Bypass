# Genesis Chapter 38: Judah and Tamar

*From the Hebrew: A Narrative Interlude*

---

**38:1** And it came to pass at that time that Judah went down from his brothers, and turned aside to a certain Adullamite, whose name was Hirah.

**38:2** And Judah saw there a daughter of a certain Canaanite whose name was Shua; and he took her and went in unto her.

**38:3** And she conceived and bore a son, and he called his name Er—עֵר (Er).

**38:4** And she conceived again and bore a son, and she called his name Onan—אוֹנָן (Onan).

**38:5** And she yet again bore a son, and she called his name Shelah—שֵׁלָה (Shelah); and Judah was at Chezib when she bore him.

**38:6** And Judah took a wife for Er his firstborn, and her name was Tamar—תָּמָר (Tamar).

**38:7** And Er, Judah's firstborn, was evil in the eyes of YHWH; and YHWH put him to death.

**38:8** And Judah said unto Onan: "Go in unto your brother's wife and perform the duty of a brother-in-law—וְיַבֵּם (ve-yabbem)—unto her, and raise up seed unto your brother."

**38:9** And Onan knew that the seed would not be his; and it came to pass, when he went in unto his brother's wife, that he spilled it on the ground, so as not to give seed unto his brother.

**38:10** And what he did was evil in the eyes of YHWH; and YHWH put him to death also.

**38:11** And Judah said unto Tamar his daughter-in-law: "Remain a widow in your father's house until Shelah my son grows up"—for he said in his heart, "Lest he also die like his brothers." And Tamar went and dwelt in her father's house.

**38:12** And the days multiplied, and the daughter of Shua, Judah's wife, died; and Judah was comforted, and went up unto his sheep-shearers at Timnah, he and his friend Hirah the Adullamite.

**38:13** And it was told to Tamar, saying: "Behold, your father-in-law is going up to Timnah to shear his sheep."

**38:14** And she put off her widow's garments from her, and covered herself with a veil—וַתִּתְעַלָּף (va-tit'allaf)—and wrapped herself, and sat at the entrance of Enaim, which is on the way to Timnah; for she saw that Shelah was grown, and she had not been given unto him as wife.

**38:15** And Judah saw her, and thought her to be a prostitute—זוֹנָה (zonah)—for she had covered her face.

**38:16** And he turned aside unto her by the way and said: "Come, please, let me come in unto you"—for he did not know that she was his daughter-in-law. And she said: "What will you give me, that you may come in unto me?"

**38:17** And he said: "I will send a kid of the goats from the flock." And she said: "Will you give me a pledge—עֵרָבוֹן (eravon)—until you send it?"

**38:18** And he said: "What pledge shall I give you?" And she said: "Your seal—חֹתָמְךָ (chotamecha)—and your cord—פְתִילֶךָ (petilecha)—and your staff—מַטְּךָ (mattecha)—that is in your hand." And he gave them to her, and came in unto her, and she conceived by him.

**38:19** And she arose and went away, and put off her veil from her, and put on her widow's garments.

**38:20** And Judah sent the kid of the goats by the hand of his friend the Adullamite, to receive the pledge from the hand of the woman; but he did not find her.

**38:21** And he asked the men of her place, saying: "Where is the sacred prostitute—קְדֵשָׁה (qedeshah)—who was at Enaim by the wayside?" And they said: "There has been no sacred prostitute here."

**38:22** And he returned to Judah and said: "I have not found her; and also the men of the place said, 'There has been no sacred prostitute here.'"

**38:23** And Judah said: "Let her keep them, lest we become a laughingstock—בּוּז (buz); behold, I sent this kid, but you did not find her."

**38:24** And it came to pass, about three months later, that it was told to Judah, saying: "Tamar your daughter-in-law has played the prostitute; and moreover, behold, she is pregnant by prostitution—הָרָה לִזְנוּנִים (harah li-zenunim)." And Judah said: "Bring her out, and let her be burned!"

**38:25** As she was being brought out, she sent to her father-in-law, saying: "By the man whose these are, I am pregnant." And she said: "Please examine—הַכֶּר־נָא (hakker-na)—whose are this seal and cord and staff."

**38:26** And Judah examined them and said: "She is more righteous than I—צָדְקָה מִמֶּנִּי (tsadqah mimmeni)—because I did not give her to Shelah my son." And he did not know her again.

**38:27** And it came to pass at the time of her giving birth, that behold, there were twins in her womb.

**38:28** And it came to pass as she gave birth, that one put out a hand; and the midwife took and bound upon his hand a scarlet thread—שָׁנִי (shani)—saying: "This one came out first."

**38:29** And it came to pass, as he drew back his hand, that behold, his brother came out; and she said: "What a breach you have made for yourself!" And his name was called Perez—פֶּרֶץ (Perets), meaning "Breach."

**38:30** And afterward his brother came out, who had the scarlet thread upon his hand; and his name was called Zerah—זֶרַח (Zerach), meaning "Brightness" or "Scarlet."

---

## Synthesis Notes

**Key Restorations:**

**The Interruption:**
This chapter interrupts the Joseph narrative at its most tense moment—Joseph has just been sold into Egypt. The story now shifts entirely to Judah. Why? The text weaves the fates of the brothers together; what happens to Judah parallels and illuminates what will happen to Joseph.

**Judah "Goes Down":**
The verb יָרַד (yarad), "went down," echoes Joseph's descent to Egypt. Both brothers descend—Judah morally and geographically, Joseph literally.

**Canaanite Intermarriage:**
Judah marries a Canaanite woman (daughter of Shua)—the very thing Abraham and Isaac explicitly prohibited. The patriarchal standards are abandoned.

**Er's Evil:**
The text never specifies what Er did. "Evil in the eyes of YHWH" and death—that is all. The focus is not on Er's sin but on its consequences for Tamar.

**Levirate Duty:**
*Yibum* (יִבּוּם): The obligation of a brother-in-law to marry his deceased brother's childless widow and produce offspring in the dead brother's name. This preserves the dead man's lineage and provides for the widow.

**Onan's Sin:**
Onan refuses to impregnate Tamar fully—"he spilled it on the ground." His sin is not sexuality per se but **refusal of responsibility**: he takes the pleasure of the relationship without accepting the duty. He cheats both Tamar (who needs a son for security) and his dead brother (whose name would continue).

**Judah's Fear:**
After two sons die, Judah fears Shelah will die too. He tells Tamar to wait but never intends to give Shelah. He abandons Tamar to permanent widowhood without legal release.

**Tamar's Action:**
Seeing she will never receive Shelah, Tamar takes desperate action. She removes widow's garments (which mark her as belonging to Judah's household) and disguises herself at a crossroads. She does not become a prostitute; she appears as one, once, to trap Judah into fulfilling his obligation indirectly.

**Zonah vs. Qedeshah:**
- *Zonah* (זוֹנָה): Common prostitute—Judah's perception
- *Qedeshah* (קְדֵשָׁה): Sacred/cultic prostitute—what Hirah asks about

The text distinguishes: Judah saw a zonah; the locals know of no qedeshah. Tamar was neither—she was a desperate widow claiming her rights.

**The Pledge (עֵרָבוֹן, eravon):**
Tamar demands Judah's most personal identifiers: seal, cord, and staff—ancient equivalents of ID, signature, and family emblem. She holds proof of paternity.

**"Please Examine" (הַכֶּר־נָא, hakker-na):**
The exact phrase Judah's brothers used when presenting Joseph's bloodied coat to Jacob (37:32). The echo is deliberate. Judah, who deceived his father with evidence of "death," is now confronted with evidence of his own actions.

**"She Is More Righteous Than I":**
*Tsadqah mimmeni* (צָדְקָה מִמֶּנִּי): Judah's confession. Tamar acted rightly—within the framework of her options—while Judah failed his obligations. This is the turning point of Judah's character. He acknowledges wrong, does not execute Tamar, and takes responsibility.

**The Twins:**
Another set of struggling twins (like Jacob and Esau). Perez, who "breaches" past his brother, becomes the ancestor of David (Ruth 4:18-22) and thus of the messianic line. The "illegitimate" union produces royalty.

**Archetypal Layer:** Tamar is the marginalized woman who uses the only power available to her—her sexuality as leverage—to claim what is rightfully hers. She is not villain but hero of this narrative. The patriarch is exposed; the outcast is vindicated; the line continues through the "scandalous" union.

**Ethical Inversion Applied:**
- Traditional reading often focuses on sexual impropriety
- **Restored reading**: Tamar is the moral center
- She was wronged by Er (whatever he did), by Onan (who exploited her), by Judah (who abandoned her)
- Her action exposes Judah's failure and forces him to justice
- "She is more righteous than I"—Judah's own verdict

**Psychological Reading:** Judah, who participated in selling Joseph and deceiving Jacob, now experiences being trapped by his own devices. The cord and seal that identify him are his exposure. Recognition of guilt ("more righteous than I") is the beginning of transformation. By Chapter 44, Judah will offer himself in place of Benjamin—a complete reversal.

**Modern Equivalent:** Those without power use what means they have. Tamar's "prostitution" was a legal claim in disguise. Systems that fail the vulnerable force desperate measures. And the children born of "scandal" may carry the line forward. The genealogy of Jesus (Matthew 1:3) includes Tamar—not hidden but named.

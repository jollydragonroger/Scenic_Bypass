# Genesis Chapter 17: The Covenant of Circumcision

*From the Hebrew: Abraham and Sarah Renamed*

---

**17:1** And when Abram was ninety-nine years old, YHWH appeared to Abram and said unto him: "I am El Shaddai—אֵל שַׁדַּי (El Shaddai); walk before me and be whole—תָּמִים (tamim).

**17:2** "And I will establish my covenant between me and you, and will multiply you exceedingly."

**17:3** And Abram fell on his face; and Consciousness spoke with him, saying:

**17:4** "As for me, behold, my covenant is with you, and you shall be a father of a multitude of nations—אַב־הֲמוֹן גּוֹיִם (av-hamon goyim).

**17:5** "And your name shall no longer be called Abram—אַבְרָם (Avram), but your name shall be Abraham—אַבְרָהָם (Avraham); for I have made you a father of a multitude of nations.

**17:6** "And I will make you exceedingly fruitful, and I will make nations of you, and kings shall come forth from you.

**17:7** "And I will establish my covenant between me and you and your seed after you throughout their generations, for an everlasting covenant—בְּרִית עוֹלָם (berit olam)—to be a Consciousness unto you and to your seed after you.

**17:8** "And I will give unto you, and to your seed after you, the land of your sojournings—אֶרֶץ מְגֻרֶיךָ (eretz megurecha)—all the land of Canaan, for an everlasting possession; and I will be their Consciousness."

**17:9** And Consciousness said unto Abraham: "And you shall keep my covenant—you, and your seed after you, throughout their generations.

**17:10** "This is my covenant which you shall keep, between me and you and your seed after you: every male among you shall be circumcised—הִמּוֹל (himmol).

**17:11** "And you shall circumcise the flesh of your foreskin; and it shall be a sign of covenant—אוֹת בְּרִית (ot berit)—between me and you.

**17:12** "And at eight days old every male among you shall be circumcised throughout your generations—he that is born in the house, or bought with money from any foreigner who is not of your seed.

**17:13** "He that is born in your house and he that is bought with your money must be circumcised; and my covenant shall be in your flesh for an everlasting covenant.

**17:14** "And the uncircumcised male whose flesh of his foreskin is not circumcised—that soul shall be cut off from his people; he has broken my covenant."

**17:15** And Consciousness said unto Abraham: "As for Sarai your partner, you shall not call her name Sarai—שָׂרַי (Sarai), but Sarah—שָׂרָה (Sarah) shall be her name.

**17:16** "And I will bless her, and moreover I will give you a son from her; and I will bless her, and she shall become nations; kings of peoples shall come from her."

**17:17** And Abraham fell upon his face and laughed—וַיִּצְחָק (va-yitschaq)—and said in his heart: "Shall a child be born unto one who is a hundred years old? And shall Sarah, who is ninety years old, bear?"

**17:18** And Abraham said unto Consciousness: "O that Ishmael might live before you!"

**17:19** And Consciousness said: "Nevertheless—אֲבָל (aval)—Sarah your partner shall bear you a son, and you shall call his name Isaac—יִצְחָק (Yitschaq); and I will establish my covenant with him for an everlasting covenant for his seed after him.

**17:20** "And as for Ishmael, I have heard you; behold, I have blessed him, and will make him fruitful, and will multiply him exceedingly; twelve princes shall he beget, and I will make him into a great nation.

**17:21** "But my covenant I will establish with Isaac, whom Sarah shall bear unto you at this set time next year."

**17:22** And Consciousness finished speaking with him, and Consciousness went up from Abraham.

**17:23** And Abraham took Ishmael his son, and all that were born in his house, and all that were bought with his money—every male among the men of Abraham's house—and circumcised the flesh of their foreskin on that very day, as Consciousness had spoken with him.

**17:24** And Abraham was ninety-nine years old when he was circumcised in the flesh of his foreskin.

**17:25** And Ishmael his son was thirteen years old when he was circumcised in the flesh of his foreskin.

**17:26** On that very day Abraham was circumcised, and Ishmael his son.

**17:27** And all the men of his house—born in the house and bought with money from the foreigner—were circumcised with him.

---

## Synthesis Notes

**Key Restorations:**

- *El Shaddai* (אֵל שַׁדַּי): Often translated "God Almighty," but the etymology is uncertain. Possibilities include "God of the Mountain," "God of the Breast" (שַׁד, shad = breast, suggesting nurturing), or "God Who Is Sufficient." This is the name associated with the patriarchal promises.

- *Tamim* (תָּמִים): "Whole, complete, integrated"—not moral perfection but wholeness of being. The same word used for unblemished sacrificial animals. "Walk before me and be whole."

- **The name changes**:
  - *Avram* → *Avraham*: The added ה (hey) may represent the breath of God, or connect to הָמוֹן (hamon), "multitude." The name expands with the promise.
  - *Sarai* → *Sarah*: Both mean "princess," but the change marks new identity. She receives her own blessing and promise.

**Circumcision — The Covenant Sign:**

- A mark in the flesh, permanent, generational
- On the organ of reproduction—the promise concerns seed, descendants
- The eighth day: seven is completion; eight is new beginning
- Applied to all males of the household, including slaves—creating household identity

**The ethical complexity**: The text includes slaves ("bought with money") in the covenant community through circumcision. This acknowledges the reality of ancient slavery while also extending covenant identity to the enslaved. The restoration neither endorses slavery nor pretends it isn't present in the text.

**Abraham laughs**: The laughter (צחק, tsachaq) becomes Isaac's name (יִצְחָק, Yitschaq—"he laughs"). The promise is so absurd that even the patriarch laughs. This is not punished—it becomes the child's identity.

**"O that Ishmael might live before you!"**: Abraham advocates for his first son. He loves Ishmael and wishes the promise could rest on him. YHWH's response honors this:
- Ishmael is blessed, will be fruitful, will father twelve princes, will become a great nation
- But the specific covenant line runs through Isaac

**Both sons are blessed**: The text does not reject Ishmael—it distinguishes between the covenantal line (Isaac) and the blessed-but-different line (Ishmael). Both are Abraham's sons; both are blessed; both become nations.

**Archetypal Layer:** The name change marks transformation of identity. Abram becomes Abraham—the self expands to match the promise. Circumcision inscribes the covenant in the body, making the spiritual physical. The laughter at impossibility becomes the child's name—acknowledging that the promise exceeds rational expectation.

**Psychological Reading:** At 99, when generativity seems impossible, the promise is renewed with greater specificity. The ego (Abraham) advocates for the existing accomplishment (Ishmael) but is directed toward a new emergence (Isaac). Both the existing and the coming are honored, but the covenant's future lies with what is not yet born.

**Modern Equivalent:** Covenant identity requires embodiment—not just belief but physical practice, community ritual, intergenerational transmission. The laughter at impossible promise is not disqualifying but becomes the name of the fulfillment. What we advocate for (Ishmael) may be blessed but distinguished from what Consciousness calls us toward (Isaac).

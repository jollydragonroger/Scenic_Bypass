# Genesis Chapter 6: The Nephilim and the Coming Waters

*From the Hebrew: The Corruption and the Ark*

---

**6:1** And it came to pass, when humanity began to multiply on the face of the ground, and daughters were born to them,

**6:2** That the sons of the powers—בְנֵי־הָאֱלֹהִים (benei ha-Elohim)—saw the daughters of humanity, that they were fair; and they took for themselves partners from all whom they chose.

**6:3** And YHWH said: "My spirit shall not strive within humanity indefinitely, for they are also flesh; yet their days shall be one hundred and twenty years."

**6:4** The Nephilim—הַנְּפִלִים (ha-Nephilim), the fallen ones or the giants—were in the earth in those days, and also afterward, when the sons of the powers came unto the daughters of humanity and they bore children to them; these were the mighty ones—הַגִּבֹּרִים (ha-gibborim)—of old, people of renown—אַנְשֵׁי הַשֵּׁם (anshei ha-shem).

**6:5** And YHWH saw that the wickedness of humanity was great in the earth, and that every formation of the thoughts of the heart—יֵצֶר מַחְשְׁבֹת לִבּוֹ (yetser machshevot libo)—was only toward harm—רַע (ra)—all the day.

**6:6** And YHWH was grieved—וַיִּנָּחֶם (va-yinnachem)—that the human had been made upon the earth, and it pained Consciousness to the heart.

**6:7** And YHWH said: "I will wipe away—אֶמְחֶה (emcheh)—the humanity which I have created from the face of the ground; from human to beast to creeping thing to winged beings of the sky; for I am grieved that I have made them."

**6:8** But Noah found favor—חֵן (chen)—in the eyes of YHWH.

**6:9** These are the generations of Noah. Noah was a righteous man—אִישׁ צַדִּיק (ish tsaddiq)—whole in his generations—תָּמִים (tamim). Noah walked with Consciousness.

**6:10** And Noah begot three sons: Shem, Ham, and Japheth.

**6:11** And the earth was corrupted—וַתִּשָּׁחֵת (va-tishachet)—before Consciousness, and the earth was filled with violence—חָמָס (chamas).

**6:12** And Consciousness saw the earth, and behold it was corrupted; for all flesh had corrupted its way upon the earth.

**6:13** And Consciousness said unto Noah: "The end of all flesh has come before me, for the earth is filled with violence through them; and behold, I am about to corrupt them with the earth.

**6:14** "Make for yourself an ark—תֵּבַת (tevat)—of gopher wood; with chambers shall you make the ark, and you shall cover it inside and outside with pitch—כֹּפֶר (kofer).

**6:15** "And this is how you shall make it: the length of the ark three hundred cubits, its breadth fifty cubits, and its height thirty cubits.

**6:16** "A window—צֹהַר (tsohar), meaning 'light-opening'—you shall make for the ark, and to a cubit you shall finish it above; and the door of the ark you shall set in its side; with lower, second, and third stories you shall make it.

**6:17** "And I, behold, I am bringing the flood—הַמַּבּוּל (ha-mabbul)—of waters upon the earth to destroy all flesh in which is the breath of life from under the sky; everything that is on the earth shall expire.

**6:18** "But I will establish my covenant—בְּרִיתִי (beriti)—with you; and you shall enter the ark—you, and your sons, and your partner, and your sons' partners with you.

**6:19** "And from all living things, from all flesh, two of every kind you shall bring into the ark to keep alive with you; male and female they shall be.

**6:20** "Of the winged beings according to their kind, and of the beasts according to their kind, of every creeping thing of the ground according to its kind—two of every kind shall come unto you to keep alive.

**6:21** "And you, take for yourself from all food that is eaten, and gather it unto you; and it shall be for you and for them for nourishment."

**6:22** And Noah did according to all that Consciousness commanded him; so he did.

---

## Synthesis Notes

**Key Restorations:**

- *Benei ha-Elohim* (בְנֵי־הָאֱלֹהִים): "Sons of God" traditionally—but Elohim is plural and can mean "powers," "divine beings," or "those with authority." These represent higher-order influences (whether cosmic, angelic, or the ruling class claiming divine descent) intermingling with common humanity.

- *Nephilim* (הַנְּפִלִים): From the root נָפַל (nafal), "to fall"—the fallen ones, or those who cause others to fall. These "giants" or "mighty ones" represent the emergence of hybrid power—the combination of elevated consciousness with embodied desire, producing beings of great capacity but imbalanced integration.

- *Anshei ha-shem* (אַנְשֵׁי הַשֵּׁם): "People of the name/renown"—the famous, the powerful, the celebrities of the ancient world. The text connects the Nephilim to the culture of fame and might.

- *Ra* (רַע): Traditionally "evil"—but the same word used in the Tree of Knowledge (tov va-ra). The yetser (formation/inclination) of human thoughts was entirely toward distinction/fragmentation without integration. Not moral evil but systemic imbalance.

- *Va-yinnachem* (וַיִּנָּחֶם): Often translated "repented"—but this is the same root as Noah's name (נֹחַ). Consciousness was "Noahed"—grieved, sighed, was moved to bring rest/resolution.

- *Chamas* (חָמָס): Violence, wrongdoing, injustice—the systemic breakdown of social relationship. The earth itself is corrupted by human violence.

- *Tevat* (תֵּבַת): "Ark"—the same word used for the basket that will carry baby Moses (Exodus 2:3). The vessel of salvation is a container that floats upon destructive waters.

- *Kofer* (כֹּפֶר): "Pitch" to seal the ark—but the same root as כָּפַר (kapar), "to cover, to atone." The ark is sealed with atonement.

- *Ha-mabbul* (הַמַּבּוּל): "The Flood"—this specific word appears only for the Genesis flood. From a root suggesting "confusion" or "mixing"—the dissolution of boundaries.

**Archetypal Layer:** The Flood represents the return of differentiated creation to the primal waters of chaos—the collective unconscious overwhelming the structures of conscious development. When systems become irredeemably corrupted (filled with chamas), dissolution is necessary for renewal. The ark is the container of essential patterns that survives dissolution—the seed-vault of consciousness.

**Psychological Reading:** When the "sons of the powers" (inflated ego-complexes, grandiose identifications) merge uncontrollably with embodied life, producing the Nephilim (hybrid complexes of power and desire), the psyche becomes flooded with chaotic content. The "ark" is the stable center of awareness that can contain paired opposites (male/female of each kind) through the dissolution.

**Ecological-Systemic Reading:** When a civilization's violence and corruption reach systemic saturation, ecological and social collapse follow. The flood is not punishment from outside but consequence from within—the earth itself responds to being "filled with violence." Noah represents the carrying-forward of essential knowledge and biodiversity through collapse.

**Modern Equivalent:** Climate change, ecological overshoot, and civilizational violence are the contemporary "flood waters rising." The task is to build arks—containers of essential knowledge, seeds, relationships, and wisdom—that can survive systemic dissolution and enable renewal.

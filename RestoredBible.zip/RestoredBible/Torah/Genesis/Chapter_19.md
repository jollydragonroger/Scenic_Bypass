# Genesis Chapter 19: The Destruction of Sodom

*From the Hebrew: Violence, Hospitality, and Transformation*

---

**19:1** And the two messengers came to Sodom in the evening; and Lot was sitting in the gate of Sodom. And Lot saw them and rose up to meet them, and bowed with his face to the ground.

**19:2** And he said: "Behold now, my lords, please turn aside unto your servant's house and lodge, and wash your feet, and you shall rise early and go on your way." And they said: "No, but we will lodge in the open square."

**19:3** And he pressed upon them greatly; and they turned aside unto him and entered into his house. And he made them a feast, and baked unleavened bread, and they ate.

**19:4** Before they lay down, the men of the city—the men of Sodom—surrounded the house, both young and old, all the people from every quarter.

**19:5** And they called unto Lot and said unto him: "Where are the men who came unto you tonight? Bring them out unto us, that we may know them—וְנֵדְעָה אֹתָם (ve-neda'ah otam)."

**19:6** And Lot went out unto them to the door, and shut the door behind him,

**19:7** And said: "Please, my brothers, do not do this wickedness—אַל־נָא תָרֵעוּ (al-na tare'u).

**19:8** "Behold now, I have two daughters who have not known a man; let me bring them out unto you, and do to them as is good in your eyes; only unto these men do nothing, for therefore they came under the shadow of my roof."

**19:9** And they said: "Stand back!" And they said: "This one came to sojourn, and he acts as a judge!—וַיִּשְׁפֹּט שָׁפוֹט (va-yishpot shafot). Now we will deal worse with you than with them." And they pressed hard upon the man Lot, and drew near to break the door.

**19:10** And the men reached out their hand and brought Lot into the house unto them, and shut the door.

**19:11** And the men at the door of the house they struck with blindness—בַּסַּנְוֵרִים (ba-sanverim)—both small and great, so that they wearied themselves trying to find the door.

**19:12** And the men said unto Lot: "Who else have you here? Son-in-law, and your sons, and your daughters, and whoever you have in the city—bring them out of the place.

**19:13** "For we are destroying this place, because the outcry against them has grown great before YHWH; and YHWH has sent us to destroy it."

**19:14** And Lot went out and spoke unto his sons-in-law, who were to marry his daughters, and said: "Arise, get out of this place, for YHWH is destroying the city." But he was as one who jests—כִמְצַחֵק (ki-metsacheq)—in the eyes of his sons-in-law.

**19:15** And when dawn arose, the messengers urged Lot, saying: "Arise, take your partner and your two daughters who are here, lest you be swept away in the iniquity of the city."

**19:16** And he lingered; and the men seized his hand, and the hand of his partner, and the hand of his two daughters—YHWH being merciful unto him—and they brought him out and set him outside the city.

**19:17** And it came to pass, when they had brought them outside, that one said: "Escape for your life! Do not look behind you, nor stay anywhere in the plain; escape to the mountain, lest you be swept away."

**19:18** And Lot said unto them: "Please, not so, my lord.

**19:19** "Behold now, your servant has found favor in your eyes, and you have magnified your kindness which you have shown unto me in saving my life; but I cannot escape to the mountain, lest the disaster overtake me and I die.

**19:20** "Behold now, this city is near to flee unto, and it is small—מִצְעָר (mits'ar); let me escape there—is it not small?—and my soul shall live."

**19:21** And he said unto him: "Behold, I have accepted you in this matter also, that I will not overthrow this city of which you have spoken.

**19:22** "Hurry, escape there, for I cannot do anything until you arrive there." Therefore the name of the city was called Zoar—צוֹעַר (Tso'ar), meaning "small."

**19:23** The sun had risen upon the earth when Lot came to Zoar.

**19:24** And YHWH rained upon Sodom and upon Gomorrah brimstone and fire—גָּפְרִית וָאֵשׁ (gafrit va-esh)—from YHWH out of the heavens.

**19:25** And YHWH overthrew those cities, and all the plain, and all the inhabitants of the cities, and that which grew upon the ground.

**19:26** And his partner looked back from behind him, and she became a pillar of salt—נְצִיב מֶלַח (netsiv melach).

**19:27** And Abraham rose early in the morning to the place where he had stood before YHWH.

**19:28** And he looked toward Sodom and Gomorrah, and toward all the land of the plain; and he saw, and behold, the smoke of the land went up as the smoke of a furnace.

**19:29** And it came to pass, when Consciousness destroyed the cities of the plain, that Consciousness remembered Abraham, and sent Lot out of the midst of the overthrow, when the cities were overthrown in which Lot dwelt.

**19:30** And Lot went up out of Zoar and dwelt in the mountain, and his two daughters with him; for he feared to dwell in Zoar; and he dwelt in a cave—בַּמְּעָרָה (ba-me'arah)—he and his two daughters.

**19:31** And the firstborn said unto the younger: "Our father is old, and there is no man in the earth to come unto us according to the way of all the earth.

**19:32** "Come, let us make our father drink wine, and we will lie with him, that we may preserve seed from our father."

**19:33** And they made their father drink wine that night; and the firstborn went in and lay with her father; and he knew not when she lay down nor when she arose.

**19:34** And it came to pass on the morrow that the firstborn said unto the younger: "Behold, I lay last night with my father; let us make him drink wine tonight also, and you go in and lie with him, that we may preserve seed from our father."

**19:35** And they made their father drink wine that night also; and the younger arose and lay with him; and he knew not when she lay down nor when she arose.

**19:36** And both the daughters of Lot conceived by their father.

**19:37** And the firstborn bore a son and called his name Moab—מוֹאָב (Mo'av); he is the father of the Moabites unto this day.

**19:38** And the younger also bore a son and called his name Ben-ammi—בֶּן־עַמִּי (Ben-Ammi); he is the father of the children of Ammon unto this day.

---

## Synthesis Notes

**Key Restorations:**

**The Sin of Sodom — What Was It?**

Traditional readings have focused on sexuality. The text reveals something different:

- *Ve-neda'ah otam* (וְנֵדְעָה אֹתָם): "That we may know them"—yes, this implies sexual violence, but the nature is **gang rape**, not consensual sexuality
- The mob is "all the people from every quarter"—universal participation in violence
- They attack Lot for "judging" them—hostility to anyone who names wrongdoing
- Compare with Chapter 18: Abraham's hospitality vs. Sodom's predatory mob

**Ezekiel 16:49 states explicitly**: "Behold, this was the iniquity of your sister Sodom: pride, fullness of bread, and careless ease was in her and in her daughters; and she did not strengthen the hand of the poor and needy."

The sin is **violent inhospitality, exploitation of the vulnerable, systemic injustice**—not sexuality per se. The restoration refuses to use this text to condemn what it does not address.

**Lot's Offer of His Daughters (19:8):**
- This is horrifying and the text does not endorse it
- Lot attempts to preserve hospitality to guests by sacrificing his daughters
- He treats women as property to appease male violence
- The messengers do not accept this "solution"—they rescue everyone

**The ethical center**: The messengers who protect the vulnerable, not Lot who trades some vulnerable for others.

**Lot's Lingering:**
- Even facing destruction, Lot hesitates
- The messengers must physically seize and drag the family out
- This is the gravitational pull of the familiar, even when it is toxic

**"Do Not Look Back":**
- Lot's wife becomes a pillar of salt—frozen in the act of looking back
- The Dead Sea region is full of salt formations
- Symbolically: attachment to what is being destroyed transforms the one who cannot release

- *Netsiv melach* (נְצִיב מֶלַח): A "pillar" (monument) of salt—she becomes a permanent marker of the inability to move forward

**Fire and Brimstone (גָּפְרִית וָאֵשׁ):**
- **Fire = transformation, revelation, purification** (from symbol map)
- The destruction is not arbitrary punishment but systemic consequence—the "outcry" of the oppressed finally answered
- The cities are "overthrown" (הָפַךְ, hafach)—inverted, turned upside down

**The Cave Narrative (19:30-38):**
- Lot's daughters, believing all men destroyed, initiate incest to preserve the family line
- The text presents this without explicit condemnation—it records what happened
- The resulting peoples (Moab, Ammon) become Israel's neighbors and sometimes enemies
- This is etiology—origin story explaining neighboring peoples

**The restoration notes**: The daughters act from perceived necessity in a situation created by catastrophe and their father's choices. They are neither heroines nor villains but survivors making desperate decisions.

**Archetypal Layer:** Sodom represents the city-system that has become completely predatory—inhospitality elevated to social norm. Its destruction is the inevitable collapse of such systems. Lot's wife, looking back, represents the psyche unable to release attachment to the old order. The cave afterward is the regression to primitive survival when civilization has failed.

**Psychological Reading:** The destruction of Sodom is the demolition of an internal complex that has become purely predatory. The escape requires not looking back—not re-investing attention in what must be left behind. The cave narrative represents the desperate, regressive measures the psyche takes when all normal structures have been destroyed.

**Modern Equivalent:** Systems built on exploitation and violent inhospitality generate outcry that eventually brings destruction. The escape requires release of attachment. Those who cannot stop looking back at what they've lost become monuments to their own nostalgia. And in the aftermath, survivors do what they must to continue.

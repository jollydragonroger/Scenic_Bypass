# Genesis Chapter 20: Abraham, Sarah, and Abimelech

*From the Hebrew: The Sister-Wife Deception Repeated*

---

**20:1** And Abraham journeyed from there toward the land of the Negev, and dwelt between Kadesh and Shur; and he sojourned in Gerar.

**20:2** And Abraham said of Sarah his partner: "She is my sister." And Abimelech king of Gerar sent and took Sarah.

**20:3** And Consciousness came to Abimelech in a dream of the night and said to him: "Behold, you are a dead man because of the woman whom you have taken, for she is a man's partner."

**20:4** And Abimelech had not come near her; and he said: "Lord, will you slay a nation even though righteous?

**20:5** "Did he not himself say unto me, 'She is my sister'? And she, even she herself said, 'He is my brother.' In the integrity of my heart—בְּתָם־לְבָבִי (be-tom-levavi)—and in the innocence of my hands—בְּנִקְיֹן כַּפַּי (be-niqyon kappai)—have I done this."

**20:6** And Consciousness said unto him in the dream: "Yes, I know that in the integrity of your heart you have done this; and I also withheld you from sinning against me; therefore I did not allow you to touch her.

**20:7** "Now therefore restore the man's partner, for he is a prophet—נָבִיא (navi)—and he shall pray for you, and you shall live. But if you do not restore her, know that you shall surely die—you, and all that are yours."

**20:8** And Abimelech rose early in the morning and called all his servants, and spoke all these words in their ears; and the men were very afraid.

**20:9** And Abimelech called Abraham and said unto him: "What have you done unto us? And how have I sinned against you, that you have brought upon me and upon my kingdom a great sin? Things that ought not to be done you have done unto me."

**20:10** And Abimelech said unto Abraham: "What did you see, that you have done this thing?"

**20:11** And Abraham said: "Because I thought, 'Surely there is no fear of God in this place, and they will slay me because of my partner.'

**20:12** "And moreover she is indeed my sister, the daughter of my father but not the daughter of my mother; and she became my partner.

**20:13** "And it came to pass, when Consciousness caused me to wander from my father's house, that I said unto her: 'This is your kindness which you shall do for me: at every place where we come, say of me, "He is my brother."'"

**20:14** And Abimelech took sheep and cattle, and male servants and female servants, and gave them unto Abraham; and he restored unto him Sarah his partner.

**20:15** And Abimelech said: "Behold, my land is before you; dwell where it is good in your eyes."

**20:16** And unto Sarah he said: "Behold, I have given your brother a thousand pieces of silver; behold, it is for you a covering of the eyes—כְּסוּת עֵינַיִם (kesut einayim)—for all who are with you; and before all you are vindicated."

**20:17** And Abraham prayed unto Consciousness; and Consciousness healed Abimelech, and his partner, and his maidservants; and they bore children.

**20:18** For YHWH had completely closed up every womb of the house of Abimelech, because of Sarah, Abraham's partner.

---

## Synthesis Notes

**Key Restorations:**

**The Pattern Repeats:**
This is the second "sister-wife" episode (after Chapter 12 with Pharaoh). Abraham uses the same deception, with the same result: a foreign ruler acts with more integrity than the patriarch.

**Abimelech's Integrity:**
- He claims תָם־לֵבָב (tom-levav)—"integrity of heart"—and נִקְיֹן כַּפַּיִם (niqyon kappayim)—"innocence of hands"
- Consciousness confirms this: "I know that in the integrity of your heart you have done this"
- Consciousness **protected Abimelech** from sinning—actively preventing the violation
- The pagan king is morally innocent; the prophet deceived him

**Abraham's Assumption Exposed:**
- "I thought, 'Surely there is no fear of God in this place'"
- Abraham assumed the foreign people would be lawless
- He was wrong—they had more integrity than he showed
- His prejudice against outsiders led him to endanger Sarah again

**The Half-Truth:**
- Abraham reveals Sarah is his half-sister (same father, different mother)
- This was the arrangement from the beginning of his wandering
- Sarah has been complicit in this deception throughout
- The text does not condemn the marriage itself (different norms) but the weaponization of the relationship

**"He is a Prophet" (נָבִיא, navi):**
- First use of this title in Scripture
- Applied to Abraham despite his moral failure in this episode
- Prophetic calling does not guarantee moral perfection
- Abraham's prayer heals Abimelech's household—his intercession is effective even when his behavior is not exemplary

**Abimelech's Generosity:**
- Unlike Pharaoh who expelled Abraham, Abimelech gives gifts AND land rights
- "Dwell where it is good in your eyes"—complete hospitality
- The "covering of the eyes" (כְּסוּת עֵינַיִם) is either vindication money or a veil metaphor—removing shame

**Ethical Inversion Applied:**
- Traditional reading: Abraham is protected by God despite circumstances
- **Restored reading**: Abimelech is the moral center—he acts with integrity, is protected from unwitting sin, and responds with generosity when wronged
- Abraham's prejudice ("no fear of God in this place") is exposed as false
- The "pagan" proves more righteous than the prophet

**Archetypal Layer:** The repeated pattern (endangering the feminine for male survival) reveals an unhealed wound in the patriarch. The foreign king represents the shadow—the outsider we assume is lawless but who may embody virtues we lack. Consciousness protects the innocent regardless of their religious identity.

**Psychological Reading:** We project our own potential for wrongdoing onto strangers and then act in ways that make us less ethical than those we feared. Abraham's assumption that Gerar had "no fear of God" was projection. The healing comes through honest confrontation (Abimelech's questions) and prayer (Abraham's intercession).

**Modern Equivalent:** Religious identity does not guarantee moral behavior. Those outside our tradition may demonstrate integrity we lack. Prejudicial assumptions about "godless" outsiders often reveal more about our own anxieties than about them. And even when we fail morally, we may still be called to serve—the prophet prays, and healing comes.

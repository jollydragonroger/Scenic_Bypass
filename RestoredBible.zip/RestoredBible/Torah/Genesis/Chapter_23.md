# Genesis Chapter 23: The Death of Sarah and the Cave of Machpelah

*From the Hebrew: חַיֵּי שָׂרָה (Chayyei Sarah) — The Life of Sarah*

---

**23:1** And the life of Sarah was one hundred years and twenty years and seven years—the years of the life of Sarah.

**23:2** And Sarah died in Kiriath-arba—קִרְיַת אַרְבַּע (Qiryat Arba), which is Hebron—in the land of Canaan; and Abraham came to mourn for Sarah and to weep for her.

**23:3** And Abraham rose up from before his dead, and spoke unto the children of Heth, saying:

**23:4** "I am a stranger and a sojourner—גֵּר־וְתוֹשָׁב (ger-ve-toshav)—among you; give me a possession of a burial site among you, that I may bury my dead from before me."

**23:5** And the children of Heth answered Abraham, saying unto him:

**23:6** "Hear us, my lord: you are a prince of God—נְשִׂיא אֱלֹהִים (nesi Elohim)—among us; in the choice of our burial sites bury your dead; none of us will withhold from you his burial site for burying your dead."

**23:7** And Abraham rose and bowed to the people of the land, to the children of Heth.

**23:8** And he spoke with them, saying: "If it is your will that I bury my dead from before me, hear me and entreat for me Ephron the son of Zohar,

**23:9** "That he may give me the cave of Machpelah—מְעָרַת הַמַּכְפֵּלָה (me'arat ha-Machpelah)—which belongs to him, which is at the end of his field; for the full price let him give it to me among you for a possession of a burial site."

**23:10** And Ephron was sitting among the children of Heth; and Ephron the Hittite answered Abraham in the hearing of the children of Heth, of all who entered the gate of his city, saying:

**23:11** "No, my lord, hear me: the field I give to you, and the cave that is in it, to you I give it; in the presence of the sons of my people I give it to you; bury your dead."

**23:12** And Abraham bowed before the people of the land.

**23:13** And he spoke unto Ephron in the hearing of the people of the land, saying: "But if you will, please hear me: I give the price of the field; take it from me, and I will bury my dead there."

**23:14** And Ephron answered Abraham, saying unto him:

**23:15** "My lord, hear me: land worth four hundred shekels of silver—אֶרֶץ אַרְבַּע מֵאֹת שֶׁקֶל־כֶּסֶף (eretz arba me'ot sheqel-kesef)—what is that between me and you? So bury your dead."

**23:16** And Abraham listened to Ephron; and Abraham weighed out to Ephron the silver which he had named in the hearing of the children of Heth—four hundred shekels of silver, current with the merchant.

**23:17** And the field of Ephron which was in Machpelah, which was before Mamre—the field and the cave which was in it, and all the trees that were in the field, that were in all its borders round about—was established

**23:18** To Abraham as a possession in the presence of the children of Heth, before all who entered the gate of his city.

**23:19** And after this Abraham buried Sarah his partner in the cave of the field of Machpelah before Mamre—which is Hebron—in the land of Canaan.

**23:20** And the field, and the cave that was in it, were established to Abraham as a possession of a burial site, from the children of Heth.

---

## Synthesis Notes

**Key Restorations:**

**The Paradox of the Parshah Name:**
The Torah portion is called "Chayyei Sarah" (חַיֵּי שָׂרָה)—"The Life of Sarah"—yet it begins with her death. This signals that her "life" continues through what is established at her death.

**Sarah's Age:**
The unique formulation—"one hundred years and twenty years and seven years"—emphasizes each component. Rabbinic tradition finds meaning in each segment: at 100 like 20 in beauty, at 20 like 7 in innocence. The total (127 years) is the only woman's age recorded in the Torah.

**The Timing:**
Sarah dies immediately after the Aqedah narrative. While the text doesn't connect them explicitly, the juxtaposition invites interpretation. Did Sarah learn what happened on the mountain? Did grief take her? The text is silent; the tradition speculates.

**"Stranger and Sojourner" (גֵּר־וְתוֹשָׁב, ger-ve-toshav):**
Abraham, to whom the land was promised, identifies himself as a resident alien. He has been in Canaan for decades but owns nothing. This paradox—promise without possession—defines the patriarchal experience.

**The Negotiation:**

This is one of the Torah's most detailed commercial transactions. The apparent generosity follows ancient Near Eastern bargaining patterns:

1. Ephron offers the field "free"—but this creates obligation
2. Abraham insists on paying—establishing clear ownership
3. Ephron names an exorbitant price (400 shekels—compare: Jeremiah later buys a field for 17 shekels)
4. Abraham pays without negotiating—the transaction is public and binding

**Why the detail?**
- The cave of Machpelah becomes the first legal land purchase in Canaan
- It establishes a stake in the land that cannot be disputed
- All the patriarchs and matriarchs will be buried here (Abraham, Sarah, Isaac, Rebekah, Jacob, Leah)

**Nesi Elohim (נְשִׂיא אֱלֹהִים):**
The Hittites call Abraham "a prince of God"—recognizing his status among them. He is honored by the indigenous peoples, not feared.

**The Cave of Machpelah (מְעָרַת הַמַּכְפֵּלָה):**
- *Machpelah* may mean "double" or "folded"—perhaps a double cave, or a cave with two chambers
- Located at Hebron, it remains a sacred site to this day (the Cave of the Patriarchs / Ibrahimi Mosque)
- The only piece of the promised land Abraham ever legally owns is a grave

**Archetypal Layer:** The first possession in the promised land is a burial site—inheritance begins with death. The cave becomes the axis point connecting generations. Those who will inherit the land are buried in it, their bodies becoming part of it. Death precedes possession; the ancestors are planted like seeds.

**Psychological Reading:** Before we can truly inhabit a place, we must bury our dead there. The land becomes ours when we have dead in it—when our grief has marked it, when our loved ones are part of its soil. Abraham's purchase of a grave is the deepest form of claiming.

**Modern Equivalent:** The negotiation between Abraham and Ephron reveals the complexity of land transactions—public formality, apparent generosity masking high price, the importance of witnesses and clear title. Legal ownership matters; verbal promises are not enough. And the land we most truly own is often the land where our dead are buried.

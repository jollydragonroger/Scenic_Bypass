# Genesis Chapter 47: Jacob Before Pharaoh and the Famine Administration

*From the Hebrew: Settlement and Consolidation*

---

**47:1** And Joseph came and told Pharaoh, and said: "My father and my brothers, and their flocks and their herds and all that they have, have come from the land of Canaan; and behold, they are in the land of Goshen."

**47:2** And from among his brothers he took five men and presented them before Pharaoh.

**47:3** And Pharaoh said unto his brothers: "What is your occupation?" And they said unto Pharaoh: "Your servants are shepherds, both we and our fathers."

**47:4** And they said unto Pharaoh: "We have come to sojourn in the land, for there is no pasture for your servants' flocks, for the famine is severe in the land of Canaan. Now therefore, please let your servants dwell in the land of Goshen."

**47:5** And Pharaoh spoke unto Joseph, saying: "Your father and your brothers have come unto you.

**47:6** "The land of Egypt is before you; in the best of the land settle your father and your brothers; let them dwell in the land of Goshen. And if you know any capable men among them, then make them overseers of my livestock."

**47:7** And Joseph brought in Jacob his father and set him before Pharaoh; and Jacob blessed Pharaoh—וַיְבָרֶךְ יַעֲקֹב אֶת־פַּרְעֹה (va-yevarech Ya'aqov et-Par'oh).

**47:8** And Pharaoh said unto Jacob: "How many are the days of the years of your life?"

**47:9** And Jacob said unto Pharaoh: "The days of the years of my sojournings—מְגוּרַי (megurai)—are one hundred and thirty years. Few and evil have been the days of the years of my life, and they have not attained unto the days of the years of the life of my fathers in the days of their sojournings."

**47:10** And Jacob blessed Pharaoh and went out from before Pharaoh.

**47:11** And Joseph settled his father and his brothers and gave them a possession in the land of Egypt, in the best of the land, in the land of Rameses, as Pharaoh had commanded.

**47:12** And Joseph sustained his father and his brothers and all his father's household with bread, according to the little ones.

---

**47:13** And there was no bread in all the land, for the famine was very severe; and the land of Egypt and the land of Canaan languished—וַתֵּלַהּ (va-telah)—by reason of the famine.

**47:14** And Joseph gathered up all the money that was found in the land of Egypt and in the land of Canaan for the grain which they bought; and Joseph brought the money into Pharaoh's house.

**47:15** And when the money was spent in the land of Egypt and in the land of Canaan, all Egypt came unto Joseph, saying: "Give us bread! For why should we die before you? For the money is gone."

**47:16** And Joseph said: "Give your livestock, and I will give you bread for your livestock, if the money is gone."

**47:17** And they brought their livestock unto Joseph; and Joseph gave them bread in exchange for the horses and for the flocks of sheep and for the herds of cattle and for the donkeys; and he sustained them with bread in exchange for all their livestock that year.

**47:18** And that year ended, and they came unto him the second year and said unto him: "We will not hide from my lord that the money is spent, and the herds of livestock are my lord's; nothing is left before my lord but our bodies and our land.

**47:19** "Why should we die before your eyes, both we and our land? Buy us and our land for bread, and we and our land will be slaves to Pharaoh—וַעֲבָדִים לְפַרְעֹה (va-avadim le-Far'oh); and give us seed, that we may live and not die, and that the land may not be desolate."

**47:20** And Joseph bought all the land of Egypt for Pharaoh; for the Egyptians sold every man his field, because the famine was severe upon them; and the land became Pharaoh's.

**47:21** And as for the people, he removed them to the cities—הֶעֱבִיר אֹתוֹ לֶעָרִים (he'evir oto le-arim)—from one end of the border of Egypt to the other end.

**47:22** Only the land of the priests he did not buy, for the priests had a portion from Pharaoh, and they ate their portion which Pharaoh gave them; therefore they did not sell their land.

**47:23** And Joseph said unto the people: "Behold, I have bought you today and your land for Pharaoh. Here is seed for you, and you shall sow the land.

**47:24** "And it shall come to pass at the harvests, that you shall give a fifth unto Pharaoh, and four parts shall be your own, for seed of the field and for your food and for those of your households and for food for your little ones."

**47:25** And they said: "You have saved our lives—הֶחֱיִתָנוּ (hecheyitanu)! Let us find favor in the eyes of my lord, and we will be slaves to Pharaoh."

**47:26** And Joseph made it a statute unto this day concerning the land of Egypt: Pharaoh should have the fifth. Only the land of the priests alone did not become Pharaoh's.

---

**47:27** And Israel dwelt in the land of Egypt, in the land of Goshen; and they got possessions in it, and were fruitful and multiplied exceedingly.

**47:28** And Jacob lived in the land of Egypt seventeen years; and the days of Jacob, the years of his life, were one hundred and forty-seven years.

**47:29** And the days of Israel drew near to die; and he called his son Joseph and said unto him: "If now I have found favor in your eyes, please put your hand under my thigh—תַּחַת יְרֵכִי (tachat yerechi)—and deal with me in kindness and truth—חֶסֶד וֶאֱמֶת (chesed ve-emet); please do not bury me in Egypt.

**47:30** "But when I lie down with my fathers, you shall carry me out of Egypt and bury me in their burial place." And Joseph said: "I will do according to your word."

**47:31** And Jacob said: "Swear unto me." And he swore unto him. And Israel bowed upon the head of the bed—עַל־רֹאשׁ הַמִּטָּה (al-rosh ha-mittah).

---

## Synthesis Notes

**Key Restorations:**

**Jacob Blesses Pharaoh:**
Twice (47:7, 10) Jacob blesses Pharaoh. The Hebrew patriarch blesses the Egyptian god-king. This is remarkable—the lesser does not bless the greater in ancient protocol. Yet Jacob, representative of divine promise, confers blessing on the most powerful ruler of the known world.

**"Few and Evil":**
Jacob's self-assessment: 130 years, "few and evil" compared to his fathers (Abraham lived 175 years, Isaac 180). This is not false modesty but genuine reflection on a life of conflict, loss, deception, and grief. Jacob does not romanticize his journey.

**"Sojournings" (מְגוּרַי, megurai):**
Jacob describes his entire life as *megurim*—sojourning, temporary dwelling. Even at 130, he has never truly settled. He is a pilgrim, not a possessor.

**The Land of Rameses:**
An anachronistic place name—Rameses refers to the later dynasty of Rameses II. The text was written or edited after the Exodus, reflecting later geography onto earlier events.

**The Famine Administration — A Complex Legacy:**

Joseph's management of the famine creates absolute state power:

1. **Year One**: People buy grain with money → all money flows to Pharaoh
2. **Year Two**: Money exhausted, people trade livestock for grain → all livestock to Pharaoh
3. **Year Three**: Nothing left but bodies and land → people sell themselves and their land → all land to Pharaoh (except priests')
4. **Result**: The entire population becomes tenant farmers, paying 20% tax in perpetuity; Pharaoh owns everything

**"We Will Be Slaves to Pharaoh":**
The people offer themselves as *avadim* (slaves/servants) in exchange for survival. Joseph accepts. This is the creation of a totalitarian agricultural state.

**The Ethical Complexity:**

The text presents this without clear moral commentary. The people say "You have saved our lives" (הֶחֱיִתָנוּ). Joseph did save them from starvation. But:
- He had stored the grain they grew during abundance
- He sold it back to them until they had nothing
- He acquired their land, livestock, and freedom
- Pharaoh—and Joseph as his agent—became absolute owners

**Traditional readings** praise Joseph's wisdom and the people's gratitude.

**Restored reading** observes: This is the creation of the system that will later enslave Israel. The same mechanisms Joseph uses to consolidate Egyptian power will be turned against his own descendants. Joseph builds the machine that becomes the Exodus oppressor.

**The Priestly Exception:**
Priests maintain their land because they receive state stipends. Religious power is preserved; common people lose everything. This reflects the alliance between palace and temple throughout ancient history.

**Israel in Goshen:**
While Egypt becomes enslaved to Pharaoh, "Israel dwelt in the land of Egypt... and were fruitful and multiplied exceedingly." The family that came as seventy grows. They are protected, provided for, separate—beneficiaries of the system Joseph built.

**Jacob's Final Request:**
The oath "under the thigh" (as Abraham's servant swore, 24:2) binds Joseph to carry Jacob's body back to Canaan, to the cave of Machpelah. Jacob refuses to be buried in Egypt. His body belongs to the promised land.

**Archetypal Layer:** Joseph is the savior who becomes (unwittingly?) the architect of oppression. The wisdom that preserves life also consolidates power. The narrative does not resolve this tension—it presents it.

**Systemic-Ecological Reading:** Joseph's program converts a crisis into permanent restructuring of power. Free farmers become state tenants. Local ownership becomes centralized control. The famine is real; the response is effective; the long-term consequences reshape society. Crisis capitalism is ancient.

**Modern Equivalent:** Emergency measures often create permanent changes in power structure. Those who manage crisis gain control. The gratitude of the saved ("You have saved our lives!") can coexist with the loss of their autonomy. Joseph is both savior and agent of the state. The Exodus story begins with the system Joseph built.

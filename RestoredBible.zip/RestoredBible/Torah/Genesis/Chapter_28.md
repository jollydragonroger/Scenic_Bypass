# Genesis Chapter 28: Jacob's Ladder

*From the Hebrew: וַיֵּצֵא (Vayetse) — And He Went Out*

---

**28:1** And Isaac called Jacob and blessed him, and commanded him and said unto him: "You shall not take a wife from the daughters of Canaan.

**28:2** "Arise, go to Paddan-aram, to the house of Bethuel your mother's father; and take from there a wife from the daughters of Laban your mother's brother.

**28:3** "And El Shaddai bless you, and make you fruitful, and multiply you, that you may become a congregation of peoples.

**28:4** "And may El Shaddai give you the blessing of Abraham, to you and to your seed with you, that you may inherit the land of your sojournings, which Consciousness gave unto Abraham."

**28:5** And Isaac sent Jacob away; and he went to Paddan-aram, unto Laban son of Bethuel the Aramean, the brother of Rebekah, Jacob's and Esau's mother.

**28:6** And Esau saw that Isaac had blessed Jacob and sent him away to Paddan-aram to take for himself a wife from there; and that when he blessed him he commanded him, saying, "You shall not take a wife from the daughters of Canaan";

**28:7** And that Jacob had listened to his father and to his mother and had gone to Paddan-aram.

**28:8** And Esau saw that the daughters of Canaan were displeasing—רָעוֹת (ra'ot)—in the eyes of Isaac his father.

**28:9** And Esau went unto Ishmael and took Mahalath the daughter of Ishmael, Abraham's son, the sister of Nebaioth, to be his wife, in addition to his other wives.

---

**28:10** And Jacob went out from Beer-sheba and went toward Haran.

**28:11** And he came upon a certain place—וַיִּפְגַּע בַּמָּקוֹם (va-yifga ba-maqom)—and lodged there, because the sun had set; and he took from the stones of the place and put them under his head, and lay down in that place.

**28:12** And he dreamed, and behold, a ladder—סֻלָּם (sullam)—was set up on the earth, and its top reached to the heavens; and behold, the messengers of Consciousness—מַלְאֲכֵי אֱלֹהִים (malakhei Elohim)—were ascending and descending on it.

**28:13** And behold, YHWH stood above it and said: "I am YHWH, the Consciousness of Abraham your father and the Consciousness of Isaac; the land upon which you lie, to you I will give it and to your seed.

**28:14** "And your seed shall be as the dust of the earth, and you shall spread abroad to the west and to the east and to the north and to the south; and in you and in your seed shall all the families of the earth be blessed.

**28:15** "And behold, I am with you and will keep you wherever you go, and will bring you back unto this land; for I will not leave you until I have done that which I have spoken to you."

**28:16** And Jacob awoke from his sleep and said: "Surely YHWH is in this place—יֵשׁ יהוה בַּמָּקוֹם הַזֶּה (yesh YHWH ba-maqom ha-zeh)—and I, I did not know."

**28:17** And he was afraid and said: "How awesome is this place!—מַה־נּוֹרָא הַמָּקוֹם הַזֶּה (mah-nora ha-maqom ha-zeh)—This is none other than the house of Consciousness—בֵּית אֱלֹהִים (beit Elohim)—and this is the gate of the heavens."

**28:18** And Jacob rose early in the morning and took the stone that he had put under his head, and set it up as a pillar—מַצֵּבָה (matsevah)—and poured oil upon the top of it.

**28:19** And he called the name of that place Bethel—בֵּית־אֵל (Beit-El), "House of God"; but the name of the city was Luz at the first.

**28:20** And Jacob vowed a vow, saying: "If Consciousness will be with me and will keep me in this way that I go, and will give me bread to eat and clothing to wear,

**28:21** "And I return in peace to my father's house—then YHWH shall be my Consciousness.

**28:22** "And this stone, which I have set up as a pillar, shall be a house of Consciousness; and of all that you give me I will surely give a tenth unto you."

---

## Synthesis Notes

**Key Restorations:**

**Isaac's Second Blessing:**
Despite the deception, Isaac now blesses Jacob openly and intentionally, passing on "the blessing of Abraham." The stolen blessing is confirmed by a freely given one.

**Esau's Response:**
Seeing Jacob sent for a non-Canaanite wife, Esau tries to please his parents by marrying into Ishmael's family. It is too late—the damage is done—but the gesture shows his desire for parental approval.

**"He Came Upon the Place" (וַיִּפְגַּע בַּמָּקוֹם):**
The verb פָּגַע (paga) suggests unexpected encounter—he collided with the place, stumbled upon it. The sacred is not sought but encountered.

**The Sullam (סֻלָּם):**
Often translated "ladder," but possibly a stairway, ramp, or ziggurat-like structure. The word appears only here in the Hebrew Bible. It connects earth and heaven—the axis mundi of the symbol map.

**Ascending and Descending:**
Note the order: the messengers are **ascending** first, then descending. They begin from earth and go up, then return. The divine presence is already here; the messengers report and return.

**YHWH's Promise:**
- Land: where you lie
- Seed: like dust of the earth, spreading in all directions
- Blessing: through you and your seed, all families blessed
- Presence: I am with you wherever you go
- Return: I will bring you back

This is the Abrahamic promise renewed to the deceiver, the fugitive, the exile. Grace precedes merit.

**"YHWH Is in This Place, and I Did Not Know":**
The revelation that the divine can be present in unexpected, unmarked places. Jacob encountered holiness without recognizing it. The awareness comes after the dream.

**"How Awesome Is This Place":**
*Nora* (נוֹרָא) = awesome, fearsome, terrifying. This is numinous dread—not comfortable religion but overwhelming encounter.

**Beit Elohim and Sha'ar Ha-Shamayim:**
"House of God" and "Gate of Heaven"—the place becomes a threshold between realms, a portal. This is the **mountain/temple** of the symbol map—"axis of integration, meeting of realms."

**The Matsevah (מַצֵּבָה):**
A standing stone, a pillar—later condemned when associated with Canaanite worship, but here a legitimate memorial. Jacob marks the sacred spot.

**Jacob's Conditional Vow:**
"IF Consciousness will be with me... THEN YHWH shall be my Consciousness." This is bargaining, negotiation—characteristically Jacob. He offers a tithe (tenth) in exchange for protection and provision.

**Archetypal Layer:** The ladder/stairway vision is the universal image of connection between dimensions—the shamanic world tree, the mystical ascent, the axis around which cosmos and consciousness organize. Jacob, fleeing family destruction he caused, encounters the numinous at the threshold of exile. The promise given is precisely what he needs: presence, protection, return.

**Psychological Reading:** At the point of greatest rupture (leaving home, fleeing a murder threat), the unconscious produces a vision of connection. The messengers ascending and descending are the flow of awareness between conscious and unconscious, between personal and transpersonal. The "place" that seemed ordinary is revealed as sacred—every place contains the potential for this recognition.

**The Stone Pillow:**
Jacob sleeps on stone—hard, uncomfortable, grounding. The dream comes through discomfort. The stone becomes the pillar—the very hardness that received his head becomes the monument.

**Modern Equivalent:** Sometimes the sacred encounters us precisely when we are in flight, in rupture, in the wilderness between who we were and who we will become. "Surely YHWH was in this place, and I did not know" is the retrospective recognition that what seemed like desolation was actually threshold. The conditional vow ("if... then") is honest bargaining—we negotiate our way into faith.

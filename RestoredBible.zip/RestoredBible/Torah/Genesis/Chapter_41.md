# Genesis Chapter 41: Pharaoh's Dreams and Joseph's Rise

*From the Hebrew: מִקֵּץ (Miqqets) — At the End*

---

**41:1** And it came to pass at the end of two full years, that Pharaoh dreamed; and behold, he was standing by the River—הַיְאֹר (ha-Ye'or), the Nile.

**41:2** And behold, there came up out of the River seven cows, beautiful in appearance and fat in flesh—יְפוֹת מַרְאֶה וּבְרִיאֹת בָּשָׂר (yefot mar'eh u-veri'ot basar); and they grazed in the reed grass.

**41:3** And behold, seven other cows came up after them out of the River, ugly in appearance and lean in flesh—רָעוֹת מַרְאֶה וְדַקּוֹת בָּשָׂר (ra'ot mar'eh ve-daqqot basar); and they stood beside the other cows on the bank of the River.

**41:4** And the ugly and lean cows ate up the seven beautiful and fat cows. And Pharaoh awoke.

**41:5** And he slept and dreamed a second time; and behold, seven ears of grain—שִׁבֳּלִים (shibbolim)—came up on one stalk, fat and good.

**41:6** And behold, seven ears, thin and blasted by the east wind—קְדִים (qadim)—sprouted after them.

**41:7** And the thin ears swallowed up the seven fat and full ears. And Pharaoh awoke, and behold, it was a dream.

**41:8** And it came to pass in the morning that his spirit was troubled—וַתִּפָּעֶם רוּחוֹ (va-tippa'em rucho); and he sent and called for all the magicians of Egypt—חַרְטֻמֵּי מִצְרַיִם (chartummei Mitsrayim)—and all its wise men; and Pharaoh told them his dream, but there was none who could interpret them unto Pharaoh.

**41:9** And the chief cupbearer spoke unto Pharaoh, saying: "I remember my offenses—חֲטָאַי (chata'ai)—today.

**41:10** "Pharaoh was angry with his servants and put me in custody in the house of the captain of the guard, me and the chief baker.

**41:11** "And we dreamed a dream in one night, I and he; each man according to the interpretation of his dream we dreamed.

**41:12** "And there was with us there a Hebrew youth—נַעַר עִבְרִי (na'ar Ivri)—a servant to the captain of the guard; and we told him, and he interpreted our dreams to us; to each man according to his dream he interpreted.

**41:13** "And it came to pass, as he interpreted to us, so it was: me he restored unto my office, and him he hanged."

**41:14** And Pharaoh sent and called Joseph, and they brought him hastily out of the pit—מִן־הַבּוֹר (min-ha-bor); and he shaved and changed his garments and came in unto Pharaoh.

**41:15** And Pharaoh said unto Joseph: "I have dreamed a dream, and there is no interpreter for it; and I have heard concerning you that you hear a dream to interpret it."

**41:16** And Joseph answered Pharaoh, saying: "Not I—בִּלְעָדָי (bil'adai); Consciousness will answer for the welfare of Pharaoh—אֱלֹהִים יַעֲנֶה אֶת־שְׁלוֹם פַּרְעֹה (Elohim ya'aneh et-shelom Par'oh)."

**41:17** And Pharaoh spoke unto Joseph: "In my dream, behold, I was standing upon the bank of the River.

**41:18** "And behold, there came up out of the River seven cows, fat in flesh and beautiful in form; and they grazed in the reed grass.

**41:19** "And behold, seven other cows came up after them, poor and very ugly in form and lean in flesh—such as I have never seen in all the land of Egypt for badness.

**41:20** "And the lean and ugly cows ate up the first seven fat cows.

**41:21** "And when they had eaten them up, it could not be known that they had eaten them, for they were still as ugly as at the beginning. And I awoke.

**41:22** "And I saw in my dream, and behold, seven ears came up on one stalk, full and good.

**41:23** "And behold, seven ears, withered, thin, blasted by the east wind, sprouted after them.

**41:24** "And the thin ears swallowed up the seven good ears. And I told this unto the magicians, but there was none who could declare it to me."

**41:25** And Joseph said unto Pharaoh: "The dream of Pharaoh is one; what Consciousness is about to do, Consciousness has declared unto Pharaoh.

**41:26** "The seven good cows are seven years, and the seven good ears are seven years; the dream is one.

**41:27** "And the seven lean and ugly cows that came up after them are seven years, and the seven empty ears blasted by the east wind—they are seven years of famine.

**41:28** "This is the thing which I spoke unto Pharaoh: what Consciousness is about to do, Consciousness has shown Pharaoh.

**41:29** "Behold, seven years are coming of great abundance throughout all the land of Egypt.

**41:30** "And there shall arise after them seven years of famine, and all the abundance shall be forgotten in the land of Egypt; and the famine shall consume the land.

**41:31** "And the abundance shall not be known in the land by reason of that famine following, for it shall be very severe.

**41:32** "And as for the doubling of the dream unto Pharaoh twice, it is because the thing is established by Consciousness, and Consciousness will hasten to do it.

**41:33** "Now therefore let Pharaoh look for a man discerning and wise—נָבוֹן וְחָכָם (navon ve-chakham)—and set him over the land of Egypt.

**41:34** "Let Pharaoh do this: let him appoint overseers over the land, and take a fifth—וְחִמֵּשׁ (ve-chimmesh)—of the land of Egypt during the seven years of abundance.

**41:35** "And let them gather all the food of these good years that are coming, and store up grain under Pharaoh's hand for food in the cities, and let them keep it.

**41:36** "And the food shall be a reserve for the land for the seven years of famine which shall be in the land of Egypt, so that the land may not perish through the famine."

**41:37** And the thing was good in the eyes of Pharaoh and in the eyes of all his servants.

**41:38** And Pharaoh said unto his servants: "Can we find such a one as this, a man in whom is the spirit of Consciousness—רוּחַ אֱלֹהִים (ruach Elohim)?"

**41:39** And Pharaoh said unto Joseph: "Since Consciousness has made all this known unto you, there is none so discerning and wise as you.

**41:40** "You shall be over my house, and according to your word shall all my people be governed; only in the throne will I be greater than you."

**41:41** And Pharaoh said unto Joseph: "See, I have set you over all the land of Egypt."

**41:42** And Pharaoh removed his signet ring—טַבַּעְתּוֹ (tabba'to)—from his hand and put it upon Joseph's hand, and clothed him in garments of fine linen—בִּגְדֵי־שֵׁשׁ (bigdei-shesh)—and put a gold chain—רְבִד הַזָּהָב (revid ha-zahav)—about his neck.

**41:43** And he had him ride in the second chariot which was his; and they cried before him, "Abrech!—אַבְרֵךְ"—and thus he set him over all the land of Egypt.

**41:44** And Pharaoh said unto Joseph: "I am Pharaoh, and without you no man shall lift up his hand or his foot in all the land of Egypt."

**41:45** And Pharaoh called Joseph's name Zaphenath-paneah—צָפְנַת פַּעְנֵחַ (Tsafenat Pa'neach); and he gave him as wife Asenath—אָסְנַת (Asenat)—the daughter of Poti-phera—פּוֹטִי פֶרַע (Poti Fera)—priest of On. And Joseph went out over the land of Egypt.

**41:46** And Joseph was thirty years old when he stood before Pharaoh king of Egypt. And Joseph went out from before Pharaoh and passed through all the land of Egypt.

**41:47** And the earth produced in the seven years of abundance by handfuls.

**41:48** And he gathered all the food of the seven years which were in the land of Egypt, and stored the food in the cities; the food of the field which was round about each city he stored in it.

**41:49** And Joseph stored up grain as the sand of the sea, very much, until he ceased to count, for it was beyond measure.

**41:50** And unto Joseph were born two sons before the year of famine came, whom Asenath the daughter of Poti-phera priest of On bore unto him.

**41:51** And Joseph called the name of the firstborn Manasseh—מְנַשֶּׁה (Menasheh)—"for," he said, "Consciousness has made me forget—נַשַּׁנִי (nashshani)—all my trouble and all my father's house."

**41:52** And the name of the second he called Ephraim—אֶפְרָיִם (Efrayim)—"for Consciousness has made me fruitful—הִפְרַנִי (hifrani)—in the land of my affliction."

**41:53** And the seven years of abundance that was in the land of Egypt came to an end.

**41:54** And the seven years of famine began to come, as Joseph had said; and there was famine in all lands, but in all the land of Egypt there was bread.

**41:55** And when all the land of Egypt was famished, the people cried to Pharaoh for bread; and Pharaoh said unto all Egypt: "Go unto Joseph; what he says to you, do."

**41:56** And the famine was over all the face of the earth; and Joseph opened all that was in them and sold to Egypt; and the famine was severe in the land of Egypt.

**41:57** And all countries came into Egypt to Joseph to buy grain, because the famine was severe in all the earth.

---

## Synthesis Notes

**Key Restorations:**

**Two Full Years:**
Joseph waits two additional years in prison after interpreting the cupbearer's dream. The total imprisonment is significant—perhaps 10-13 years (sold at 17, now 30).

**The River (הַיְאֹר, Ye'or):**
The Nile—source of Egypt's life, the divine river. Pharaoh dreams at its bank; the cows emerge from it. Egypt's fate rises from its sacred waters.

**The Egyptian Magicians:**
*Chartummim* (חַרְטֻמִּים): This word appears for Egyptian priestly magicians here and in Exodus. They cannot interpret—their expertise fails where divine revelation is needed.

**"Not I" (בִּלְעָדָי, bil'adai):**
Joseph's immediate deflection. He claims no personal power—"Consciousness will answer." This humility contrasts with the youthful arrogance of sharing his dominion dreams.

**The Interpretation:**
Joseph not only interprets but **advises**—moving from dream-reading to economic policy. He proposes the solution (storage during abundance) along with the problem (famine coming). This is wisdom beyond interpretation.

**"The Dream Is One":**
Both visions (cows, grain) carry the same message—seven years of plenty, seven of famine. The doubling confirms certainty: "The thing is established by Consciousness."

**The Fifth (וְחִמֵּשׁ, ve-chimmesh):**
A 20% tax during abundance—Joseph proposes the creation of a state granary system. This will save Egypt but also, as Chapter 47 will show, consolidate Pharaoh's power absolutely.

**Joseph's Investiture:**
- Signet ring: Authority to act in Pharaoh's name
- Fine linen garments: Royal dress (contrast with stripped garments of ch. 37, 39)
- Gold chain: Mark of highest office
- Second chariot: Public procession of authority
- "Abrech!": The cry before him—meaning uncertain, perhaps "Bow!" or "Attention!"

**Zaphenath-paneah:**
Joseph's Egyptian name—meaning debated. Possibly "God speaks and lives" or "Revealer of secrets." He becomes Egyptian in name and marriage.

**Asenath, Daughter of Poti-phera:**
Joseph marries into Egyptian priesthood. Poti-phera ("gift of Ra") is a priest of On (Heliopolis), center of sun worship. Joseph is fully absorbed into Egyptian elite society.

**The Sons' Names:**
- *Menasheh* (מְנַשֶּׁה): "Making forget"—God has made him forget his trouble and father's house
- *Ephraim* (אֶפְרָיִם): "Fruitfulness"—God has made him fruitful in affliction

The names tell his emotional journey: first, release from pain; second, recognition of blessing.

**All Countries Came:**
The famine is international; Egypt alone has food. Joseph becomes the dispenser of survival to "all the earth." This sets up the brothers' arrival.

**Archetypal Layer:** The dreamer becomes the interpreter of dreams; the prisoner becomes the prince. The pattern of descent-ascent completes its first major cycle. Joseph's rise is precisely to the position his childhood dreams foretold—but achieved through suffering, not arrogance.

**Psychological Reading:** Joseph at 30 has matured. His first response to Pharaoh is humility ("Not I"). He has learned that his gifts are channels, not possessions. The naming of his sons reveals psychological processing: Manasseh = letting go of trauma; Ephraim = finding meaning in affliction.

**Systemic Reading (New Lens):**
Joseph creates a centralized food storage system that will save millions but also consolidate absolute power in Pharaoh's hands. The "salvation" has costs that Chapter 47 will reveal—the people eventually sell everything, including themselves, to survive. Liberation and control intertwine.

**Modern Equivalent:** Crisis creates opportunity for both service and power consolidation. Those who see what's coming and prepare can save nations—or acquire them. Joseph's wisdom serves both Egypt's survival and Pharaoh's empire. The question of whose interests are served by crisis response remains relevant.

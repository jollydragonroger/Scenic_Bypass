# Genesis Chapter 21: The Birth of Isaac and the Expulsion of Hagar

*From the Hebrew: Laughter Born, and the Wilderness Encounter*

---

**21:1** And YHWH visited Sarah as had been spoken, and YHWH did unto Sarah as had been promised.

**21:2** And Sarah conceived and bore Abraham a son in his old age, at the appointed time of which Consciousness had spoken to him.

**21:3** And Abraham called the name of his son who was born to him, whom Sarah bore to him, Isaac—יִצְחָק (Yitschaq).

**21:4** And Abraham circumcised his son Isaac when he was eight days old, as Consciousness had commanded him.

**21:5** And Abraham was a hundred years old when his son Isaac was born unto him.

**21:6** And Sarah said: "Laughter—צְחֹק (tsechoq)—has Consciousness made for me; everyone who hears will laugh with me."

**21:7** And she said: "Who would have said unto Abraham that Sarah would nurse children? For I have borne him a son in his old age."

**21:8** And the child grew and was weaned; and Abraham made a great feast on the day that Isaac was weaned.

**21:9** And Sarah saw the son of Hagar the Egyptian, whom she had borne unto Abraham, laughing—מְצַחֵק (metsacheq).

**21:10** And she said unto Abraham: "Cast out this bondwoman and her son! For the son of this bondwoman shall not inherit with my son, with Isaac."

**21:11** And the matter was very grievous in Abraham's eyes—וַיֵּרַע הַדָּבָר מְאֹד בְּעֵינֵי אַבְרָהָם (va-yera ha-davar me'od be-einei Avraham)—because of his son.

**21:12** And Consciousness said unto Abraham: "Let it not be grievous in your eyes because of the lad and because of your bondwoman; in all that Sarah says unto you, listen to her voice; for in Isaac shall your seed be called.

**21:13** "And also the son of the bondwoman I will make into a nation, because he is your seed."

**21:14** And Abraham rose early in the morning and took bread and a skin of water, and gave it unto Hagar, putting it on her shoulder, and the child, and sent her away. And she departed and wandered in the wilderness of Beer-sheba.

**21:15** And the water in the skin was spent, and she cast the child under one of the shrubs.

**21:16** And she went and sat down opposite him, a bowshot away; for she said: "Let me not see the death of the child." And she sat opposite him, and lifted up her voice and wept.

**21:17** And Consciousness heard the voice of the lad; and the messenger of Consciousness called to Hagar from the heavens and said unto her: "What troubles you, Hagar? Fear not, for Consciousness has heard the voice of the lad where he is.

**21:18** "Arise, lift up the lad and hold him with your hand, for I will make him into a great nation."

**21:19** And Consciousness opened her eyes, and she saw a well of water; and she went and filled the skin with water and gave the lad drink.

**21:20** And Consciousness was with the lad, and he grew; and he dwelt in the wilderness and became an archer.

**21:21** And he dwelt in the wilderness of Paran; and his mother took for him a wife from the land of Egypt.

**21:22** And it came to pass at that time that Abimelech and Phicol the commander of his army spoke unto Abraham, saying: "Consciousness is with you in all that you do.

**21:23** "Now therefore swear unto me here by Consciousness that you will not deal falsely with me, nor with my offspring, nor with my posterity; but according to the kindness that I have done unto you, you shall do unto me and unto the land in which you have sojourned."

**21:24** And Abraham said: "I will swear."

**21:25** And Abraham reproved Abimelech because of the well of water which Abimelech's servants had seized.

**21:26** And Abimelech said: "I do not know who has done this thing; and you also did not tell me, and I also have not heard of it until today."

**21:27** And Abraham took sheep and cattle and gave them unto Abimelech; and the two of them cut a covenant.

**21:28** And Abraham set seven ewe lambs of the flock by themselves.

**21:29** And Abimelech said unto Abraham: "What are these seven ewe lambs which you have set by themselves?"

**21:30** And he said: "These seven ewe lambs you shall take from my hand, that it may be a witness for me that I have dug this well."

**21:31** Therefore he called that place Beer-sheba—בְּאֵר שָׁבַע (Be'er Shava)—because there the two of them swore.

**21:32** And they cut a covenant at Beer-sheba; and Abimelech rose, and Phicol the commander of his army, and they returned unto the land of the Philistines.

**21:33** And Abraham planted a tamarisk tree—אֶשֶׁל (eshel)—in Beer-sheba, and called there on the name of YHWH, El Olam—אֵל עוֹלָם (El Olam), the Everlasting God.

**21:34** And Abraham sojourned in the land of the Philistines many days.

---

## Synthesis Notes

**Key Restorations:**

**Isaac's Name:**
- *Yitschaq* (יִצְחָק) = "He laughs" or "He will laugh"
- Both parents laughed at the promise; now laughter is born
- Sarah's statement is ambiguous: "Everyone who hears will laugh with me"—is it joy or mockery?

**The Expulsion of Hagar and Ishmael:**

- *Metsacheq* (מְצַחֵק): Ishmael was "laughing" or "playing"—the same root as Isaac's name. Some translations add "mocking," but the Hebrew is simply "laughing." Perhaps Sarah saw Ishmael's laughter as threatening Isaac's uniqueness—the firstborn also "laughs."

- Sarah demands expulsion: "Cast out this bondwoman and her son"—dehumanizing language
- Abraham is grieved—he loves Ishmael
- Consciousness tells Abraham to listen to Sarah, but **immediately promises to bless Ishmael**

**The Ethical Complexity:**
- The text records Sarah's demand and Consciousness's accommodation without fully endorsing either
- Hagar and Ishmael are expelled with minimal provisions—bread and a skin of water
- This is not divine justice but divine working-through human dysfunction
- The restoration refuses to pretend this is fair to Hagar and Ishmael

**Hagar's Second Theophany:**
- Again, the messenger of YHWH meets Hagar in the wilderness
- Again, she is heard and seen by the God she named "El Roi"
- Consciousness hears "the voice of the lad"—the meaning of Ishmael's name ("God hears")
- A well appears; life is sustained; the promise is renewed

**"Consciousness was with the lad"**: Ishmael receives the same blessing formula that Isaac will receive. Both sons are accompanied by divine presence.

**The Beer-sheba Covenant:**
- Abraham and Abimelech formalize their relationship
- *Be'er Shava* (בְּאֵר שָׁבַע): "Well of Seven" or "Well of the Oath"—double meaning from the seven lambs and the swearing
- Abraham plants a tamarisk (אֶשֶׁל)—a long-lived desert tree, symbol of permanence

**El Olam (אֵל עוֹלָם):**
- "The Everlasting God" or "God of Eternity"
- Another divine name, likely originally Canaanite, now integrated into Abraham's worship
- The patriarchs encounter and name multiple aspects of the divine

**Archetypal Layer:** The birth of the "promised child" often requires the displacement of the "natural child." This is not endorsement but observation of how promise-fulfillment can involve painful exclusions. The wilderness, however, becomes a place of theophany—Hagar and Ishmael are not abandoned by the divine, only by the human family.

**Psychological Reading:** The household cannot contain both children—Sarah's anxiety makes coexistence impossible. Abraham's grief indicates his awareness of the injustice. The expulsion represents the painful separation of possibilities—choosing one path means others are not taken. But the unchosen path is not destroyed; it continues, blessed, in the wilderness.

**Ethical Inversion Applied:**
- Traditional reading centers Isaac as the chosen, Ishmael as the rejected
- **Restored reading**: Both are blessed, both become nations, both are accompanied by Consciousness
- Hagar and Ishmael's story continues—they are not erased but establish their own lineage
- The "rejected" son is the ancestor of nations; rejection by one household is not rejection by the divine

**Modern Equivalent:** Family systems often cannot contain all members; exclusions happen. The question is whether the excluded find their own well, their own blessing, their own continuation. Divine presence accompanies those sent into the wilderness, not only those who remain in the tent.

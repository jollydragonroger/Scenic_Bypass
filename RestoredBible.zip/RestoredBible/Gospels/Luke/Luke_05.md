# Luke 5: Calling Disciples and Controversies Begin

*From the Greek: Ἐγένετο δὲ ἐν τῷ τὸν ὄχλον ἐπικεῖσθαι αὐτῷ (Egeneto de en tō ton Ochlon Epikeisthai Autō) — Now It Came to Pass, While the Multitude Pressed upon Him*

---

## The Miraculous Catch of Fish (5:1-11)

**5:1** Now it came to pass, while the multitude pressed upon him and heard the word of God, that he was standing by the lake of Gennesaret;

**5:2** And he saw two boats standing by the lake: but the fishermen had gone out of them, and were washing their nets.

**5:3** And he entered into one of the boats, which was Simon's, and asked him to put out a little from the land. And he sat down and taught the multitudes out of the boat.

**5:4** And when he had left speaking, he said unto Simon: "Put out into the deep, and let down your nets for a draught."

**5:5** And Simon answered and said: "Master, we toiled all night, and took nothing: but at your word I will let down the nets."

**5:6** And when they had done this, they enclosed a great multitude of fishes; and their nets were breaking;

**5:7** And they beckoned unto their partners in the other boat, that they should come and help them. And they came, and filled both the boats, so that they began to sink.

**5:8** But Simon Peter, when he saw it, fell down at Yeshua's knees, saying: "Depart from me; for I am a sinful man, O Lord."

**5:9** For he was amazed, and all that were with him, at the draught of the fishes which they had taken;

**5:10** And so were also James and John, sons of Zebedee, who were partners with Simon. And Yeshua said unto Simon: "Fear not; from henceforth you shall catch men."

**5:11** And when they had brought their boats to land, they left all, and followed him.

---

## Cleansing a Leper (5:12-16)

**5:12** And it came to pass, while he was in one of the cities, behold, a man full of leprosy: and when he saw Yeshua, he fell on his face, and besought him, saying: "Lord, if you will, you can make me clean."

**5:13** And he stretched forth his hand, and touched him, saying: "I will; be made clean." And straightway the leprosy departed from him.

**5:14** And he charged him to tell no man: "But go, and show yourself to the priest, and offer for your cleansing, according as Moses commanded, for a testimony unto them."

**5:15** But so much the more went abroad the report concerning him: and great multitudes came together to hear, and to be healed of their infirmities.

**5:16** But he withdrew himself in the deserts, and prayed.

---

## The Paralytic Forgiven and Healed (5:17-26)

**5:17** And it came to pass on one of those days, that he was teaching; and there were Pharisees and doctors of the law sitting by, who were come out of every village of Galilee and Judaea and Jerusalem: and the power of the Lord was with him to heal.

**5:18** And behold, men bring on a bed a man that was palsied: and they sought to bring him in, and to lay him before him.

**5:19** And not finding by what way they might bring him in because of the multitude, they went up to the housetop, and let him down through the tiles with his couch into the midst before Yeshua.

**5:20** And seeing their faith, he said: "Man, your sins are forgiven you."

**5:21** And the scribes and the Pharisees began to reason, saying: "Who is this that speaks blasphemies? Who can forgive sins, but God alone?"

**5:22** But Yeshua perceiving their reasonings, answered and said unto them: "Why reason you in your hearts?

**5:23** "Which is easier, to say, 'Your sins are forgiven you'; or to say, 'Arise and walk'?

**5:24** "But that you may know that the Son of man has authority on earth to forgive sins" (he said unto him that was palsied), "I say unto you, Arise, and take up your couch, and go unto your house."

**5:25** And immediately he rose up before them, and took up that whereon he lay, and departed to his house, glorifying God.

**5:26** And amazement took hold on all, and they glorified God; and they were filled with fear, saying: "We have seen strange things today."

---

## The Calling of Levi (5:27-32)

**5:27** And after these things he went forth, and beheld a publican, named Levi, sitting at the place of toll, and said unto him: "Follow me."

**5:28** And he forsook all, and rose up and followed him.

**5:29** And Levi made him a great feast in his house: and there was a great multitude of publicans and of others that were sitting at meat with them.

**5:30** And the Pharisees and their scribes murmured against his disciples, saying: "Why do you eat and drink with the publicans and sinners?"

**5:31** And Yeshua answering said unto them: "They that are whole have no need of a physician; but they that are sick.

**5:32** "I am not come to call the righteous but sinners to repentance."

---

## The Question about Fasting (5:33-39)

**5:33** And they said unto him: "The disciples of John fast often, and make supplications; likewise also the disciples of the Pharisees; but yours eat and drink."

**5:34** And Yeshua said unto them: "Can you make the sons of the bride-chamber fast, while the bridegroom is with them?

**5:35** "But the days will come; and when the bridegroom shall be taken away from them, then will they fast in those days."

**5:36** And he spoke also a parable unto them: "No man tears a piece from a new garment and puts it upon an old garment; else he will rend the new, and also the piece from the new will not agree with the old.

**5:37** "And no man puts new wine into old wine-skins; else the new wine will burst the skins, and itself will be spilled, and the skins will perish.

**5:38** "But new wine must be put into fresh wine-skins.

**5:39** "And no man having drunk old wine desires new; for he says, 'The old is good.'"

---

## Synthesis Notes

**Key Restorations:**

**Miraculous Catch of Fish (5:1-11):**
"'The multitude pressed upon him and heard the word of God.'"

*En tō ton ochlon epikeisthai autō kai akouein ton logon tou theou*—pressed.

"'He was standing by the lake of Gennesaret.'"

*Kai autos ēn hestōs para tēn limnēn Gennēsaret*—Gennesaret.

"'He entered into one of the boats, which was Simon's.'"

*Embas de eis hen tōn ploiōn ho ēn Simōnos*—Simon's boat.

"''Put out into the deep, and let down your nets for a draught.''"

*Epanagage eis to bathos kai chalasate ta diktya hymōn eis agran*—deep.

"''Master, we toiled all night, and took nothing.''"

*Epistata di' holēs nyktos kopiasantes ouden elabomen*—nothing.

"''But at your word I will let down the nets.''"

*Epi de tō rhēmati sou chalasō ta diktya*—at your word.

"'They enclosed a great multitude of fishes; and their nets were breaking.'"

*Synekleisan plēthos ichthyōn poly dierrhēsseto de ta diktya autōn*—great catch.

"'They filled both the boats, so that they began to sink.'"

*Kai eplēsan amphotera ta ploia hōste bythizesthai auta*—sinking.

"''Depart from me; for I am a sinful man, O Lord.''"

*Exelthe ap' emou hoti anēr hamartōlos eimi kyrie*—sinful.

"''Fear not; from henceforth you shall catch men.''"

*Mē phobou apo tou nyn anthrōpous esē zōgrōn*—catch men.

**Zōgreō:**
"Catch alive"—fishing for life.

"'They left all, and followed him.'"

*Kai katagagontes ta ploia epi tēn gēn aphentes panta ēkolouthēsan autō*—left all.

**Cleansing a Leper (5:12-16):**
"'A man full of leprosy.'"

*Anēr plērēs lepras*—full of leprosy.

"''Lord, if you will, you can make me clean.''"

*Kyrie ean thelēs dynasai me katharisai*—if you will.

"''I will; be made clean.''"

*Thelō katharisthēti*—I will.

"''Show yourself to the priest, and offer for your cleansing, according as Moses commanded.''"

*Deixon seauton tō hierei kai prosenenke peri tou katharismou sou kathōs prosetaxen Mōusēs*—Moses.

"'He withdrew himself in the deserts, and prayed.'"

*Autos de ēn hypochōrōn en tais erēmois kai proseuchomenos*—prayed.

**Lukan Theme:**
Yeshua's prayer life.

**Paralytic Forgiven and Healed (5:17-26):**
"'Pharisees and doctors of the law sitting by, who were come out of every village of Galilee and Judaea and Jerusalem.'"

*Kai ēsan kathēmenoi Pharisaioi kai nomodidaskaloi hoi ēsan elēlythotes ek pasēs kōmēs tēs Galilaias kai Ioudaias kai Hierousalēm*—widespread.

"'The power of the Lord was with him to heal.'"

*Kai dynamis kyriou ēn eis to iasthai auton*—power to heal.

"'They went up to the housetop, and let him down through the tiles.'"

*Anabantes epi to dōma dia tōn keramōn kathēkan auton*—tiles.

**Luke's Detail:**
Tile roof (Greco-Roman style).

"''Man, your sins are forgiven you.''"

*Anthrōpe aphēontai soi hai hamartiai sou*—forgiven.

"''Who is this that speaks blasphemies? Who can forgive sins, but God alone?''"

*Tis estin houtos hos lalei blasphēmias tis dynatai hamartias apheinai ei mē monos ho theos*—blasphemy.

"''Which is easier, to say, Your sins are forgiven you; or to say, Arise and walk?''"

*Ti estin eukopōteron eipein aphēontai soi hai hamartiai sou ē eipein egeire kai peripatei*—which easier?

"''That you may know that the Son of man has authority on earth to forgive sins.''"

*Hina de eidēte hoti ho huios tou anthrōpou exousian echei epi tēs gēs aphienai hamartias*—authority.

"''We have seen strange things today.''"

*Eidomen paradoxa sēmeron*—strange things.

**Calling of Levi (5:27-32):**
"'He beheld a publican, named Levi, sitting at the place of toll.'"

*Etheasato telōnēn onomati Leuin kathēmenon epi to telōnion*—Levi.

"''Follow me.' And he forsook all, and rose up and followed him.''"

*Akolouthei moi kai katalipōn panta anastas ēkolouthei autō*—forsook all.

"'Levi made him a great feast in his house.'"

*Kai epoiēsen dochēn megalēn Leuis autō en tē oikia autou*—great feast.

"''Why do you eat and drink with the publicans and sinners?''"

*Dia ti meta tōn telōnōn kai hamartōlōn esthiete kai pinete*—why eat?

"''They that are whole have no need of a physician; but they that are sick.''"

*Ou chreian echousin hoi hygiainontes iatrou alla hoi kakōs echontes*—physician.

"''I am not come to call the righteous but sinners to repentance.''"

*Ouk elēlytha kalesai dikaious alla hamartōlous eis metanoian*—repentance.

**Only Luke:**
Adds "to repentance."

**Fasting Question (5:33-39):**
"''The disciples of John fast often, and make supplications.''"

*Hoi mathētai Iōannou nēsteuousin pykna kai deēseis poiountai*—fast, pray.

"''Can you make the sons of the bride-chamber fast, while the bridegroom is with them?''"

*Mē dynasthe tous huious tou nymphōnos en hō ho nymphios met' autōn estin poiēsai nēsteusai*—bridegroom.

"''When the bridegroom shall be taken away from them, then will they fast.''"

*Hotan de aparthē ap' autōn ho nymphios tote nēsteusousin en ekeinais tais hēmerais*—taken away.

"''No man tears a piece from a new garment and puts it upon an old.''"

*Oudeis epiblēma apo himatiou kainou schisas epiballei epi himation palaion*—new patch.

"''No man puts new wine into old wine-skins.''"

*Kai oudeis ballei oinon neon eis askous palaious*—new wine.

"''New wine must be put into fresh wine-skins.''"

*Alla oinon neon eis askous kainous blēteon*—fresh skins.

"''No man having drunk old wine desires new; for he says, The old is good.''"

*Kai oudeis piōn palaion thelei neon legei gar ho palaios chrēstos estin*—old is good.

**Only Luke:**
This verse—sympathy for tradition.

**Archetypal Layer:** Luke 5 contains **miraculous catch of fish (5:1-11)** (unique to Luke): teaching from Simon's boat, "Put out into the deep," toiled all night and caught nothing, "at your word I will let down the nets," nets breaking, boats sinking, **"Depart from me; for I am a sinful man, O Lord" (5:8)**, **"Fear not; from henceforth you shall catch men" (5:10)**, "they left all, and followed him" (5:11), **cleansing a leper (5:12-16)**: "full of leprosy," "he withdrew himself in the deserts, and prayed" (5:16), **paralytic forgiven and healed (5:17-26)**: "the power of the Lord was with him to heal" (5:17), through the tiles (5:19), **"Man, your sins are forgiven you" (5:20)**, **"the Son of man has authority on earth to forgive sins" (5:24)**, "We have seen strange things today" (5:26), **calling of Levi (5:27-32)**: great feast, "They that are whole have no need of a physician" (5:31), **"I am not come to call the righteous but sinners to repentance" (5:32)**, and **fasting question (5:33-39)**: bridegroom present, new wine in fresh skins, **"no man having drunk old wine desires new" (5:39)** (unique to Luke).

**Modern Equivalent:** Luke 5 begins Yeshua's Galilean ministry with the unique miraculous catch (5:1-11). Peter's response—"Depart from me; for I am a sinful man" (5:8)—shows the holiness encounter. "From henceforth you shall catch men" (5:10) commissions the disciples. Luke emphasizes Yeshua's prayer life (5:16). The paralytic story demonstrates authority to forgive (5:24). Levi's feast (5:29) shows Yeshua's table fellowship with sinners. The unique verse about preferring old wine (5:39) shows sympathetic understanding of those slow to accept the new.

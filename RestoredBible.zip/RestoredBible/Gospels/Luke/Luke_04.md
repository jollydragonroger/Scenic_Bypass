# Luke 4: Temptation, Nazareth Rejection, and Galilean Ministry

*From the Greek: Ἰησοῦς δὲ πλήρης πνεύματος ἁγίου (Iēsous de Plērēs Pneumatos Hagiou) — And Yeshua, Full of the Holy Spirit*

---

## The Temptation (4:1-13)

**4:1** And Yeshua, full of the Holy Spirit, returned from the Jordan, and was led in the Spirit in the wilderness

**4:2** During forty days, being tempted of the devil. And he ate nothing in those days: and when they were completed, he hungered.

**4:3** And the devil said unto him: "If you are the Son of God, command this stone that it become bread."

**4:4** And Yeshua answered unto him: "It is written, 'Man shall not live by bread alone.'"

**4:5** And he led him up, and showed him all the kingdoms of the world in a moment of time.

**4:6** And the devil said unto him: "To you will I give all this authority, and the glory of them: for it has been delivered unto me; and to whomsoever I will I give it.

**4:7** "If you therefore will worship before me, it shall all be yours."

**4:8** And Yeshua answered and said unto him: "It is written, 'You shall worship the Lord your God, and him only shall you serve.'"

**4:9** And he led him to Jerusalem, and set him on the pinnacle of the temple, and said unto him: "If you are the Son of God, cast yourself down from hence:

**4:10** "For it is written, 'He shall give his angels charge concerning you, to guard you':

**4:11** "And, 'On their hands they shall bear you up, lest haply you dash your foot against a stone.'"

**4:12** And Yeshua answering said unto him: "It is said, 'You shall not make trial of the Lord your God.'"

**4:13** And when the devil had completed every temptation, he departed from him for a season.

---

## Yeshua Rejected at Nazareth (4:14-30)

**4:14** And Yeshua returned in the power of the Spirit into Galilee: and a fame went out concerning him through all the region round about.

**4:15** And he taught in their synagogues, being glorified of all.

**4:16** And he came to Nazareth, where he had been brought up: and he entered, as his custom was, into the synagogue on the sabbath day, and stood up to read.

**4:17** And there was delivered unto him the book of the prophet Isaiah. And he opened the book, and found the place where it was written:

**4:18** "The Spirit of the Lord is upon me, because he anointed me to preach good tidings to the poor: he has sent me to proclaim release to the captives, and recovering of sight to the blind, to set at liberty them that are bruised,

**4:19** "To proclaim the acceptable year of the Lord."

**4:20** And he closed the book, and gave it back to the attendant, and sat down: and the eyes of all in the synagogue were fastened on him.

**4:21** And he began to say unto them: "Today has this scripture been fulfilled in your ears."

**4:22** And all bare him witness, and wondered at the words of grace which proceeded out of his mouth: and they said: "Is not this Joseph's son?"

**4:23** And he said unto them: "Doubtless you will say unto me this parable, 'Physician, heal yourself: whatsoever we have heard done at Capernaum, do also here in your own country.'"

**4:24** And he said: "Verily I say unto you, No prophet is acceptable in his own country.

**4:25** "But of a truth I say unto you, There were many widows in Israel in the days of Elijah, when the heaven was shut up three years and six months, when there came a great famine over all the land;

**4:26** "And unto none of them was Elijah sent, but only to Zarephath, in the land of Sidon, unto a woman that was a widow.

**4:27** "And there were many lepers in Israel in the time of Elisha the prophet; and none of them was cleansed, but only Naaman the Syrian."

**4:28** And they were all filled with wrath in the synagogue, as they heard these things;

**4:29** And they rose up, and cast him forth out of the city, and led him unto the brow of the hill whereon their city was built, that they might throw him down headlong.

**4:30** But he passing through the midst of them went his way.

---

## Ministry in Capernaum (4:31-37)

**4:31** And he came down to Capernaum, a city of Galilee. And he was teaching them on the sabbath day:

**4:32** And they were astonished at his teaching; for his word was with authority.

**4:33** And in the synagogue there was a man, that had a spirit of an unclean demon; and he cried out with a loud voice:

**4:34** "Ah! What have we to do with you, Yeshua of Nazareth? Have you come to destroy us? I know you who you are, the Holy One of God."

**4:35** And Yeshua rebuked him, saying: "Hold your peace, and come out of him." And when the demon had thrown him down in the midst, he came out of him, having done him no hurt.

**4:36** And amazement came upon all, and they spoke together, one with another, saying: "What is this word? For with authority and power he commands the unclean spirits, and they come out."

**4:37** And there went forth a rumour concerning him into every place of the region round about.

---

## Healings at Simon's House (4:38-41)

**4:38** And he rose up from the synagogue, and entered into the house of Simon. And Simon's wife's mother was holden with a great fever; and they besought him for her.

**4:39** And he stood over her, and rebuked the fever; and it left her: and immediately she rose up and ministered unto them.

**4:40** And when the sun was setting, all they that had any sick with divers diseases brought them unto him; and he laid his hands on every one of them, and healed them.

**4:41** And demons also came out from many, crying out, and saying: "You are the Son of God." And rebuking them, he permitted them not to speak, because they knew that he was the Anointed.

---

## Preaching in Judaea (4:42-44)

**4:42** And when it was day, he came out and went into a desert place: and the multitudes sought after him, and came unto him, and would have stayed him, that he should not go from them.

**4:43** But he said unto them: "I must preach the good tidings of the kingdom of God to the other cities also: for therefore was I sent."

**4:44** And he was preaching in the synagogues of Judaea.

---

## Synthesis Notes

**Key Restorations:**

**The Temptation (4:1-13):**
"'Yeshua, full of the Holy Spirit, returned from the Jordan.'"

*Iēsous de plērēs pneumatos hagiou hypestrepsen apo tou Iordanou*—full of Spirit.

"'Was led in the Spirit in the wilderness during forty days, being tempted of the devil.'"

*Kai ēgeto en tō pneumati en tē erēmō hēmeras tessarakonta peirazomenos hypo tou diabolou*—forty days.

"''If you are the Son of God, command this stone that it become bread.''"

*Ei huios ei tou theou eipe tō lithō toutō hina genētai artos*—bread.

"''Man shall not live by bread alone.''"

*Ouk ep' artō monō zēsetai ho anthrōpos*—Deuteronomy 8:3.

"'He led him up, and showed him all the kingdoms of the world in a moment of time.'"

*Kai anagagōn auton edeixen autō pasas tas basileias tēs oikoumenēs en stigmē chronou*—kingdoms.

**Luke's Order:**
Different from Matthew—kingdoms second, temple third.

"''To you will I give all this authority, and the glory of them.''"

*Soi dōsō tēn exousian tautēn hapasan kai tēn doxan autōn*—authority.

"''You shall worship the Lord your God, and him only shall you serve.''"

*Kyrion ton theon sou proskynēseis kai autō monō latreuseis*—Deuteronomy 6:13.

"'He led him to Jerusalem, and set him on the pinnacle of the temple.'"

*Ēgagen de auton eis Hierousalēm kai estēsen epi to pterygion tou hierou*—pinnacle.

"''He shall give his angels charge concerning you.''"

*Tois angelois autou enteleitai peri sou*—Psalm 91:11-12.

"''You shall not make trial of the Lord your God.''"

*Ouk ekpeiraseis kyrion ton theon sou*—Deuteronomy 6:16.

"'When the devil had completed every temptation, he departed from him for a season.'"

*Kai syntelesas panta peirasmon ho diabolos apestē ap' autou achri kairou*—for a season.

**Nazareth Rejection (4:14-30):**
"'Yeshua returned in the power of the Spirit into Galilee.'"

*Kai hypestrepsen ho Iēsous en tē dynamei tou pneumatos eis tēn Galilaian*—power.

"'He came to Nazareth, where he had been brought up.'"

*Kai ēlthen eis Nazara hou ēn tethrammenos*—brought up.

"'He entered, as his custom was, into the synagogue on the sabbath day.'"

*Kai eisēlthen kata to eiōthos autō en tē hēmera tōn sabbatōn eis tēn synagōgēn*—custom.

"'There was delivered unto him the book of the prophet Isaiah.'"

*Kai epedothē autō biblion tou prophētou Ēsaiou*—Isaiah scroll.

"''The Spirit of the Lord is upon me, because he anointed me to preach good tidings to the poor.''"

*Pneuma kyriou ep' eme hou heineken echrisen me euangelisasthai ptōchois*—Isaiah 61:1-2.

"''He has sent me to proclaim release to the captives.''"

*Apestalken me kēryxai aichmalōtois aphesin*—release.

"''Recovering of sight to the blind, to set at liberty them that are bruised.''"

*Kai typhlois anablepsin aposteilai tethrausmenous en aphesei*—sight, liberty.

"''To proclaim the acceptable year of the Lord.''"

*Kēryxai eniauton kyriou dekton*—Jubilee.

**Stops Mid-Verse:**
Omits "the day of vengeance of our God."

"''Today has this scripture been fulfilled in your ears.''"

*Sēmeron peplērōtai hē graphē hautē en tois ōsin hymōn*—today.

"''Is not this Joseph's son?''"

*Ouchi huios estin Iōsēph houtos*—Joseph's son.

"''Physician, heal yourself.''"

*Iatre therapeuson seauton*—proverb.

"''No prophet is acceptable in his own country.''"

*Oudeis prophētēs dektos estin en tē patridi autou*—proverb.

"''There were many widows in Israel in the days of Elijah... unto none of them was Elijah sent, but only to Zarephath.''"

*Pollai chērai ēsan en tais hēmerais Ēliou en tō Israēl... kai pros oudemian autōn epemphthē Ēlias ei mē eis Sarepta*—Zarephath.

**1 Kings 17.**

"''There were many lepers in Israel in the time of Elisha the prophet; and none of them was cleansed, but only Naaman the Syrian.''"

*Kai polloi leproi ēsan en tō Israēl epi Elisaiou tou prophētou kai oudeis autōn ekatharisthē ei mē Naiman ho Syros*—Naaman.

**2 Kings 5.**

"'They were all filled with wrath... and led him unto the brow of the hill... that they might throw him down headlong.'"

*Kai eplēsthēsan pantes thymou... kai ēgagon auton heōs ophryos tou orous... hōste katakrēmnisai auton*—wrath.

"'But he passing through the midst of them went his way.'"

*Autos de dielthōn dia mesou autōn eporeueto*—passed through.

**Capernaum Ministry (4:31-37):**
"'He came down to Capernaum, a city of Galilee.'"

*Kai katēlthen eis Kapharnaoum polin tēs Galilaias*—Capernaum.

"'His word was with authority.'"

*En exousia ēn ho logos autou*—authority.

"''What have we to do with you, Yeshua of Nazareth? Have you come to destroy us?''"

*Ea ti hēmin kai soi Iēsou Nazarēne ēlthes apolesai hēmas*—demons recognize.

"''I know you who you are, the Holy One of God.''"

*Oida se tis ei ho hagios tou theou*—Holy One.

"''Hold your peace, and come out of him.''"

*Phimōthēti kai exelthe ap' autou*—be silent.

"'When the demon had thrown him down in the midst, he came out of him, having done him no hurt.'"

*Kai rhipsan auton to daimonion eis to meson exēlthen ap' autou mēden blapsan auton*—no hurt.

**Healings at Simon's House (4:38-41):**
"'Simon's wife's mother was holden with a great fever.'"

*Penthera de tou Simōnos ēn synechomenē pyretō megalō*—great fever.

"'He stood over her, and rebuked the fever.'"

*Kai epistas epanō autēs epetimēsen tō pyretō*—rebuked fever.

"'Immediately she rose up and ministered unto them.'"

*Kai parachrēma anastasa diēkonei autois*—ministered.

"'He laid his hands on every one of them, and healed them.'"

*Ho de heni hekastō autōn tas cheiras epititheis etherapeusen autous*—every one.

"''You are the Son of God.''"

*Sy ei ho huios tou theou*—demons confess.

"'He permitted them not to speak, because they knew that he was the Anointed.'"

*Kai epitimōn ouk eia auta lalein hoti ēdeisan ton Christon auton einai*—messianic secret.

**Preaching in Judaea (4:42-44):**
"''I must preach the good tidings of the kingdom of God to the other cities also.''"

*Kai tais heterais polesin euangelisasthai me dei tēn basileian tou theou*—must preach.

"''For therefore was I sent.''"

*Hoti eis touto apestalēn*—sent.

"'He was preaching in the synagogues of Judaea.'"

*Kai ēn kēryssōn eis tas synagōgas tēs Ioudaias*—Judaea.

**Archetypal Layer:** Luke 4 contains **temptation in the wilderness (4:1-13)**: full of the Holy Spirit, forty days, three temptations (bread, kingdoms, temple), Yeshua answers with Deuteronomy, devil departs "for a season" (4:13), **Nazareth rejection (4:14-30)**: sabbath synagogue, Isaiah 61:1-2, **"The Spirit of the Lord is upon me... to preach good tidings to the poor... release to the captives... recovering of sight to the blind... the acceptable year of the Lord" (4:18-19)**, **"Today has this scripture been fulfilled in your ears" (4:21)**, "Is not this Joseph's son?" (4:22), "No prophet is acceptable in his own country" (4:24), **Elijah to Zarephath widow (4:26)**, **Elisha and Naaman the Syrian (4:27)**, wrath and attempted murder (4:28-29), passes through their midst (4:30), **Capernaum ministry (4:31-37)**: authority, exorcism, "the Holy One of God" (4:34), **healings at Simon's house (4:38-41)**, and **"I must preach the good tidings of the kingdom of God to the other cities also: for therefore was I sent" (4:43)**.

**Modern Equivalent:** Luke 4 is programmatic for Luke's Gospel. The temptation (4:1-13) shows Yeshua overcoming Satan with scripture. The Nazareth sermon (4:16-30) is Luke's keynote: Yeshua reads Isaiah 61 (release, sight, liberty, Jubilee) and declares "Today has this scripture been fulfilled" (4:21). The references to Elijah and Elisha serving Gentiles (4:25-27) provoke murderous rage—foreshadowing rejection and Gentile mission. Passing through their midst (4:30) shows divine protection. Capernaum ministry demonstrates authority over demons and disease.

# Luke 3: John the Immerser and Yeshua's Genealogy

*From the Greek: Ἐν ἔτει δὲ πεντεκαιδεκάτῳ (En Etei de Pentekaidekato) — Now in the Fifteenth Year*

---

## John's Ministry (3:1-6)

**3:1** Now in the fifteenth year of the reign of Tiberius Caesar, Pontius Pilate being governor of Judaea, and Herod being tetrarch of Galilee, and his brother Philip tetrarch of the region of Ituraea and Trachonitis, and Lysanias tetrarch of Abilene,

**3:2** In the high-priesthood of Annas and Caiaphas, the word of God came unto John the son of Zacharias in the wilderness.

**3:3** And he came into all the region round about the Jordan, proclaiming the immersion of repentance unto remission of sins;

**3:4** As it is written in the book of the words of Isaiah the prophet: "The voice of one crying in the wilderness, Prepare the way of the Lord, make his paths straight.

**3:5** "Every valley shall be filled, and every mountain and hill shall be brought low; and the crooked shall become straight, and the rough ways smooth;

**3:6** "And all flesh shall see the salvation of God."

---

## John's Preaching (3:7-14)

**3:7** He said therefore to the multitudes that went out to be immersed of him: "You offspring of vipers, who warned you to flee from the wrath to come?

**3:8** "Bring forth therefore fruits worthy of repentance, and begin not to say within yourselves, 'We have Abraham to our father': for I say unto you, that God is able of these stones to raise up children unto Abraham.

**3:9** "And even now the axe also lies at the root of the trees: every tree therefore that brings not forth good fruit is hewn down, and cast into the fire."

**3:10** And the multitudes asked him, saying: "What then must we do?"

**3:11** And he answered and said unto them: "He that has two coats, let him impart to him that has none; and he that has food, let him do likewise."

**3:12** And there came also publicans to be immersed, and they said unto him: "Teacher, what must we do?"

**3:13** And he said unto them: "Extort no more than that which is appointed you."

**3:14** And soldiers also asked him, saying: "And we, what must we do?" And he said unto them: "Extort from no man by violence, neither accuse any one wrongfully; and be content with your wages."

---

## John's Testimony about the Anointed (3:15-18)

**3:15** And as the people were in expectation, and all men reasoned in their hearts concerning John, whether haply he were the Anointed;

**3:16** John answered, saying unto them all: "I indeed immerse you with water; but there comes he that is mightier than I, the latchet of whose shoes I am not worthy to unloose: he shall immerse you in the Holy Spirit and in fire:

**3:17** "Whose fan is in his hand, thoroughly to cleanse his threshing-floor, and to gather the wheat into his garner; but the chaff he will burn up with unquenchable fire."

**3:18** With many other exhortations therefore proclaimed he good tidings unto the people.

---

## John's Imprisonment (3:19-20)

**3:19** But Herod the tetrarch, being reproved by him for Herodias his brother's wife, and for all the evil things which Herod had done,

**3:20** Added this also to them all, that he shut up John in prison.

---

## The Immersion of Yeshua (3:21-22)

**3:21** Now it came to pass, when all the people were immersed, that, Yeshua also having been immersed, and praying, the heaven was opened,

**3:22** And the Holy Spirit descended in a bodily form, as a dove, upon him, and a voice came out of heaven: "You are my beloved Son; in you I am well pleased."

---

## The Genealogy of Yeshua (3:23-38)

**3:23** And Yeshua himself, when he began to teach, was about thirty years of age, being the son (as was supposed) of Joseph, the son of Heli,

**3:24** The son of Matthat, the son of Levi, the son of Melchi, the son of Jannai, the son of Joseph,

**3:25** The son of Mattathias, the son of Amos, the son of Nahum, the son of Esli, the son of Naggai,

**3:26** The son of Maath, the son of Mattathias, the son of Semein, the son of Josech, the son of Joda,

**3:27** The son of Joanan, the son of Rhesa, the son of Zerubbabel, the son of Shealtiel, the son of Neri,

**3:28** The son of Melchi, the son of Addi, the son of Cosam, the son of Elmadam, the son of Er,

**3:29** The son of Joshua, the son of Eliezer, the son of Jorim, the son of Matthat, the son of Levi,

**3:30** The son of Simeon, the son of Judah, the son of Joseph, the son of Jonam, the son of Eliakim,

**3:31** The son of Melea, the son of Menna, the son of Mattatha, the son of Nathan, the son of David,

**3:32** The son of Jesse, the son of Obed, the son of Boaz, the son of Salmon, the son of Nahshon,

**3:33** The son of Amminadab, the son of Admin, the son of Arni, the son of Hezron, the son of Perez, the son of Judah,

**3:34** The son of Jacob, the son of Isaac, the son of Abraham, the son of Terah, the son of Nahor,

**3:35** The son of Serug, the son of Reu, the son of Peleg, the son of Eber, the son of Shelah,

**3:36** The son of Cainan, the son of Arphaxad, the son of Shem, the son of Noah, the son of Lamech,

**3:37** The son of Methuselah, the son of Enoch, the son of Jared, the son of Mahalaleel, the son of Cainan,

**3:38** The son of Enos, the son of Seth, the son of Adam, the son of God.

---

## Synthesis Notes

**Key Restorations:**

**John's Ministry (3:1-6):**
"'In the fifteenth year of the reign of Tiberius Caesar.'"

*En etei de pentekaidekato tēs hēgemonias Tiberiou Kaisaros*—15th year.

**~28-29 CE.**

"'Pontius Pilate being governor of Judaea.'"

*Hēgemoneuontos Pontiou Pilatou tēs Ioudaias*—Pilate.

"'Herod being tetrarch of Galilee.'"

*Tetrarchountos tēs Galilaias Hērōdou*—Herod Antipas.

"'In the high-priesthood of Annas and Caiaphas.'"

*Epi archiereōs Anna kai Kaiaphas*—dual high priesthood.

"'The word of God came unto John the son of Zacharias in the wilderness.'"

*Egeneto rhēma theou epi Iōannēn ton Zachariou huion en tē erēmō*—prophetic call.

"'Proclaiming the immersion of repentance unto remission of sins.'"

*Kēryssōn baptisma metanoias eis aphesin hamartiōn*—repentance.

"''The voice of one crying in the wilderness.''"

*Phōnē boōntos en tē erēmō*—Isaiah 40:3-5.

"''Every valley shall be filled, and every mountain and hill shall be brought low.''"

*Pasa pharagx plērōthēsetai kai pan oros kai bounos tapeinōthēsetai*—leveling.

"''All flesh shall see the salvation of God.''"

*Kai opsetai pasa sarx to sōtērion tou theou*—all flesh.

**Only Luke:**
Extends Isaiah quotation to include "all flesh."

**John's Preaching (3:7-14):**
"''You offspring of vipers, who warned you to flee from the wrath to come?''"

*Gennēmata echidnōn tis hypedeixen hymin phygein apo tēs mellousēs orgēs*—vipers.

"''Bring forth therefore fruits worthy of repentance.''"

*Poiēsate oun karpous axious tēs metanoias*—fruits.

"''Begin not to say within yourselves, We have Abraham to our father.''"

*Kai mē arxēsthe legein en heautois patera echomen ton Abraam*—Abraham.

"''God is able of these stones to raise up children unto Abraham.''"

*Dynatai ho theos ek tōn lithōn toutōn egeirai tekna tō Abraam*—stones.

"''Even now the axe also lies at the root of the trees.''"

*Ēdē de kai hē axinē pros tēn rhizan tōn dendrōn keitai*—axe.

"''What then must we do?''"

*Ti oun poiēsōmen*—practical ethics.

**Only Luke:**
This detailed ethical teaching.

"''He that has two coats, let him impart to him that has none.''"

*Ho echōn dyo chitōnas metadotō tō mē echonti*—share.

"''Extort no more than that which is appointed you.''"

*Mēden pleon para to diatetagmenon hymin prassete*—tax collectors.

"''Extort from no man by violence, neither accuse any one wrongfully.''"

*Mēdena diaseiēsēte mēde sykophantēsēte*—soldiers.

"''Be content with your wages.''"

*Kai arkeisthe tois opsōniois hymōn*—content.

**John's Testimony (3:15-18):**
"'As the people were in expectation... whether haply he were the Anointed.'"

*Prosdokōntos de tou laou... mēpote autos eiē ho Christos*—expectation.

"''I indeed immerse you with water.''"

*Egō men hydati baptizō hymas*—water.

"''There comes he that is mightier than I.''"

*Erchetai de ho ischyroteros mou*—mightier.

"''He shall immerse you in the Holy Spirit and in fire.''"

*Autos hymas baptisei en pneumati hagiō kai pyri*—Spirit and fire.

"''Whose fan is in his hand, thoroughly to cleanse his threshing-floor.''"

*Hou to ptyon en tē cheiri autou diakatharai tēn halōna autou*—winnowing.

"''To gather the wheat into his garner; but the chaff he will burn up with unquenchable fire.''"

*Kai synagagein ton siton eis tēn apothēkēn autou to de achyron katakausei pyri asbestō*—judgment.

**John's Imprisonment (3:19-20):**
"'Herod the tetrarch, being reproved by him for Herodias his brother's wife.'"

*Ho de Hērōdēs ho tetraarchēs elenchomenos hyp' autou peri Hērōdiados tēs gynaikos tou adelphou autou*—reproved.

"'He shut up John in prison.'"

*Katekleisen ton Iōannēn en phylakē*—imprisoned.

**Luke's Placement:**
Mentions imprisonment before Yeshua's immersion.

**Immersion of Yeshua (3:21-22):**
"'When all the people were immersed, that, Yeshua also having been immersed, and praying.'"

*En tō baptisthēnai hapanta ton laon kai Iēsou baptisthentos kai proseuchomenou*—praying.

**Only Luke:**
Mentions Yeshua praying.

"'The heaven was opened.'"

*Aneōchthēnai ton ouranon*—opened.

"'The Holy Spirit descended in a bodily form, as a dove, upon him.'"

*Kai katabēnai to pneuma to hagion sōmatikō eidei hōs peristeran ep' auton*—bodily form.

"''You are my beloved Son; in you I am well pleased.''"

*Sy ei ho huios mou ho agapētos en soi eudokēsa*—beloved Son.

**Psalm 2:7 + Isaiah 42:1.**

**Genealogy of Yeshua (3:23-38):**
"'Yeshua himself, when he began to teach, was about thirty years of age.'"

*Kai autos ēn Iēsous archomenos hōsei etōn triakonta*—30 years.

"'Being the son (as was supposed) of Joseph.'"

*Ōn huios hōs enomizeto Iōsēph*—as supposed.

"'The son of Nathan, the son of David.'"

*Tou Nathan tou David*—Nathan line.

**Different from Matthew:**
Luke traces through Nathan, not Solomon.

"'The son of Adam, the son of God.'"

*Tou Adam tou theou*—to God.

**Luke's Genealogy:**
Traces backward from Joseph to Adam to God—universal scope.

**Archetypal Layer:** Luke 3 contains **historical synchronism (3:1-2)**: Tiberius's 15th year, Pilate, Herod, Philip, Lysanias, Annas and Caiaphas, **"the word of God came unto John... in the wilderness" (3:2)**, **Isaiah 40:3-5 extended (3:4-6)**: "all flesh shall see the salvation of God" (3:6), **"You offspring of vipers" (3:7)**, **"God is able of these stones to raise up children unto Abraham" (3:8)**, **"the axe also lies at the root of the trees" (3:9)**, **ethical preaching unique to Luke (3:10-14)**: share coats and food, tax collectors don't extort, soldiers don't oppress, **"he shall immerse you in the Holy Spirit and in fire" (3:16)**, **winnowing fork (3:17)**, **John imprisoned (3:19-20)**, **Yeshua's immersion while praying (3:21-22)**: heaven opened, Spirit in bodily form as dove, **"You are my beloved Son; in you I am well pleased" (3:22)**, and **genealogy (3:23-38)**: from Joseph backward through Nathan to David to Abraham to Adam to God.

**Modern Equivalent:** Luke 3 sets Yeshua's ministry in world history (3:1-2)—six rulers named. Isaiah's prophecy extends to "all flesh shall see the salvation of God" (3:6)—Luke's universal emphasis. John's ethical preaching (3:10-14) is unique to Luke: practical instructions for crowds, tax collectors, and soldiers. Luke mentions Yeshua praying at his immersion (3:21)—a Lukan theme. The genealogy (3:23-38) traces backward to Adam, son of God—emphasizing universal humanity, not just Jewish identity.

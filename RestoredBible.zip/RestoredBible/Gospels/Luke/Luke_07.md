# Luke 7: Faith, Compassion, and the Sinful Woman

*From the Greek: Ἐπειδὴ ἐπλήρωσεν πάντα τὰ ῥήματα αὐτοῦ (Epeidē Eplērōsen Panta ta Rhēmata Autou) — After He Had Ended All His Sayings*

---

## The Centurion's Servant (7:1-10)

**7:1** After he had ended all his sayings in the ears of the people, he entered into Capernaum.

**7:2** And a certain centurion's servant, who was dear unto him, was sick and at the point of death.

**7:3** And when he heard concerning Yeshua, he sent unto him elders of the Jews, asking him that he would come and save his servant.

**7:4** And they, when they came to Yeshua, besought him earnestly, saying: "He is worthy that you should do this for him;

**7:5** "For he loves our nation, and himself built us our synagogue."

**7:6** And Yeshua went with them. And when he was now not far from the house, the centurion sent friends to him, saying unto him: "Lord, trouble not yourself; for I am not worthy that you should come under my roof:

**7:7** "Wherefore neither thought I myself worthy to come unto you: but say the word, and my servant shall be healed.

**7:8** "For I also am a man set under authority, having under myself soldiers: and I say to this one, 'Go,' and he goes; and to another, 'Come,' and he comes; and to my servant, 'Do this,' and he does it."

**7:9** And when Yeshua heard these things, he marvelled at him, and turned and said unto the multitude that followed him: "I say unto you, I have not found so great faith, no, not in Israel."

**7:10** And they that were sent, returning to the house, found the servant whole.

---

## Raising the Widow's Son at Nain (7:11-17)

**7:11** And it came to pass soon afterwards, that he went to a city called Nain; and his disciples went with him, and a great multitude.

**7:12** Now when he drew near to the gate of the city, behold, there was carried out one that was dead, the only son of his mother, and she was a widow: and much people of the city was with her.

**7:13** And when the Lord saw her, he had compassion on her, and said unto her: "Weep not."

**7:14** And he came near and touched the bier: and the bearers stood still. And he said: "Young man, I say unto you, Arise."

**7:15** And he that was dead sat up, and began to speak. And he gave him to his mother.

**7:16** And fear took hold on all: and they glorified God, saying: "A great prophet is arisen among us": and, "God has visited his people."

**7:17** And this report went forth concerning him in the whole of Judaea, and all the region round about.

---

## John's Question and Yeshua's Answer (7:18-35)

**7:18** And the disciples of John told him of all these things.

**7:19** And John calling unto him two of his disciples sent them to the Lord, saying: "Are you he that comes, or look we for another?"

**7:20** And when the men were come unto him, they said: "John the Immerser has sent us unto you, saying, 'Are you he that comes, or look we for another?'"

**7:21** In that hour he cured many of diseases and plagues and evil spirits; and on many that were blind he bestowed sight.

**7:22** And he answered and said unto them: "Go and tell John the things which you have seen and heard; the blind receive their sight, the lame walk, the lepers are cleansed, and the deaf hear, the dead are raised up, the poor have good tidings preached to them.

**7:23** "And blessed is he, whosoever shall find no occasion of stumbling in me."

**7:24** And when the messengers of John were departed, he began to say unto the multitudes concerning John: "What went you out into the wilderness to behold? A reed shaken with the wind?

**7:25** "But what went you out to see? A man clothed in soft raiment? Behold, they that are gorgeously apparelled, and live delicately, are in kings' courts.

**7:26** "But what went you out to see? A prophet? Yea, I say unto you, and much more than a prophet.

**7:27** "This is he of whom it is written: 'Behold, I send my messenger before your face, who shall prepare your way before you.'

**7:28** "I say unto you, Among them that are born of women there is none greater than John: yet he that is but little in the kingdom of God is greater than he."

**7:29** And all the people when they heard, and the publicans, justified God, having been immersed with the immersion of John.

**7:30** But the Pharisees and the lawyers rejected for themselves the counsel of God, not having been immersed of him.

**7:31** "Whereunto then shall I liken the men of this generation, and to what are they like?

**7:32** "They are like unto children that sit in the marketplace, and call one to another; who say, 'We piped unto you, and you did not dance; we wailed, and you did not weep.'

**7:33** "For John the Immerser is come eating no bread nor drinking wine; and you say, 'He has a demon.'

**7:34** "The Son of man is come eating and drinking; and you say, 'Behold, a gluttonous man, and a winebibber, a friend of publicans and sinners!'

**7:35** "And wisdom is justified of all her children."

---

## The Sinful Woman Anoints Yeshua (7:36-50)

**7:36** And one of the Pharisees desired him that he would eat with him. And he entered into the Pharisee's house, and sat down to meat.

**7:37** And behold, a woman who was in the city, a sinner; and when she knew that he was sitting at meat in the Pharisee's house, she brought an alabaster cruse of ointment,

**7:38** And standing behind at his feet, weeping, she began to wet his feet with her tears, and wiped them with the hair of her head, and kissed his feet, and anointed them with the ointment.

**7:39** Now when the Pharisee that had bidden him saw it, he spoke within himself, saying: "This man, if he were a prophet, would have perceived who and what manner of woman this is that touches him, that she is a sinner."

**7:40** And Yeshua answering said unto him: "Simon, I have somewhat to say unto you." And he says: "Teacher, say on."

**7:41** "A certain lender had two debtors: the one owed five hundred pence, and the other fifty.

**7:42** "When they had not wherewith to pay, he forgave them both. Which of them therefore will love him most?"

**7:43** Simon answered and said: "He, I suppose, to whom he forgave the most." And he said unto him: "You have rightly judged."

**7:44** And turning to the woman, he said unto Simon: "See you this woman? I entered into your house, you gave me no water for my feet: but she has wetted my feet with her tears, and wiped them with her hair.

**7:45** "You gave me no kiss: but she, since the time I came in, has not ceased to kiss my feet.

**7:46** "My head with oil you did not anoint: but she has anointed my feet with ointment.

**7:47** "Wherefore I say unto you, Her sins, which are many, are forgiven; for she loved much: but to whom little is forgiven, the same loves little."

**7:48** And he said unto her: "Your sins are forgiven."

**7:49** And they that sat at meat with him began to say within themselves: "Who is this that even forgives sins?"

**7:50** And he said unto the woman: "Your faith has saved you; go in peace."

---

## Synthesis Notes

**Key Restorations:**

**Centurion's Servant (7:1-10):**
"'A certain centurion's servant, who was dear unto him, was sick and at the point of death.'"

*Hekatontarchou de tinos doulos kakōs echōn ēmellen teleutan hos ēn autō entimos*—dear servant.

"'He sent unto him elders of the Jews.'"

*Apesteilen pros auton presbyterous tōn Ioudaiōn*—elders.

**Luke's Detail:**
Intermediaries—centurion doesn't come personally.

"''He is worthy that you should do this for him; for he loves our nation, and himself built us our synagogue.''"

*Axios estin hō parexē touto agapa gar to ethnos hēmōn kai tēn synagōgēn autos ōkodomēsen hēmin*—built synagogue.

"''Lord, trouble not yourself; for I am not worthy that you should come under my roof.''"

*Kyrie mē skyllou ou gar hikanos eimi hina hypo tēn stegēn mou eiselthēs*—not worthy.

"''Say the word, and my servant shall be healed.''"

*Alla eipe logō kai iathētō ho pais mou*—say the word.

"''For I also am a man set under authority.''"

*Kai gar egō anthrōpos eimi hypo exousian tassomenos*—authority.

"''I have not found so great faith, no, not in Israel.''"

*Oude en tō Israēl tosautēn pistin heuron*—great faith.

**Raising the Widow's Son at Nain (7:11-17):**
"'He went to a city called Nain.'"

*Eporeuthē eis polin kaloumenēn Nain*—Nain.

**Only Luke:**
This story unique to Luke.

"'There was carried out one that was dead, the only son of his mother, and she was a widow.'"

*Idou exekomizeto tethnēkōs monogenēs huios tē mētri autou kai autē ēn chēra*—only son, widow.

"'When the Lord saw her, he had compassion on her.'"

*Kai idōn autēn ho kyrios esplanchnisthē ep' autē*—compassion.

"''Weep not.''"

*Mē klaie*—don't weep.

"'He came near and touched the bier.'"

*Kai proselthōn hēpsato tēs sorou*—touched bier.

"''Young man, I say unto you, Arise.''"

*Neaniske soi legō egerthēti*—arise.

"'He that was dead sat up, and began to speak.'"

*Kai anekathisen ho nekros kai ērxato lalein*—sat up.

"'He gave him to his mother.'"

*Kai edōken auton tē mētri autou*—gave to mother.

**1 Kings 17:23 Echo:**
Elijah and the widow's son.

"''A great prophet is arisen among us... God has visited his people.''"

*Prophētēs megas ēgerthē en hēmin kai hoti epeskepsato ho theos ton laon autou*—visited.

**John's Question (7:18-35):**
"''Are you he that comes, or look we for another?''"

*Sy ei ho erchomenos ē allon prosdokōmen*—the Coming One.

"'In that hour he cured many of diseases and plagues and evil spirits.'"

*En ekeinē tē hōra etherapeusen pollous apo nosōn kai mastigōn kai pneumatōn ponērōn*—cured.

"''Go and tell John the things which you have seen and heard.''"

*Poreuthentes apangeilate Iōannē ha eidete kai ēkousate*—report.

"''The blind receive their sight, the lame walk, the lepers are cleansed, and the deaf hear, the dead are raised up, the poor have good tidings preached to them.''"

*Typhloi anablepousin chōloi peripatousin leproi katharizontai kai kōphoi akouousin nekroi egeirontai ptōchoi euangelizontai*—Isaiah 35, 61.

"''Blessed is he, whosoever shall find no occasion of stumbling in me.''"

*Kai makarios estin hos ean mē skandalisthē en emoi*—not stumble.

"''What went you out into the wilderness to behold? A reed shaken with the wind?''"

*Ti exēlthate eis tēn erēmon theasasthai kalamon hypo anemou saleuomenon*—reed.

"''Much more than a prophet.''"

*Perissoteron prophētou*—more.

"''Behold, I send my messenger before your face.''"

*Idou apostellō ton angelon mou pro prosōpou sou*—Malachi 3:1.

"''Among them that are born of women there is none greater than John.''"

*Meizōn en gennētois gynaikōn Iōannou oudeis estin*—greatest.

"''Yet he that is but little in the kingdom of God is greater than he.''"

*Ho de mikroteros en tē basileia tou theou meizōn autou estin*—least greater.

"'All the people... justified God, having been immersed with the immersion of John.''"

*Kai pas ho laos... edikaiōsan ton theon baptisthentes to baptisma Iōannou*—justified God.

"'The Pharisees and the lawyers rejected for themselves the counsel of God.'"

*Hoi de Pharisaioi kai hoi nomikoi tēn boulēn tou theou ēthetēsan eis heautous*—rejected.

"''We piped unto you, and you did not dance; we wailed, and you did not weep.''"

*Ēulēsamen hymin kai ouk ōrchēsasthe ethrēnēsamen kai ouk eklausate*—children's game.

"''John the Immerser is come eating no bread nor drinking wine; and you say, He has a demon.''"

*Elēlythen gar Iōannēs ho baptistēs mē esthiōn arton mēte pinōn oinon kai legete daimonion echei*—demon.

"''The Son of man is come eating and drinking; and you say, Behold, a gluttonous man, and a winebibber, a friend of publicans and sinners!''"

*Elēlythen ho huios tou anthrōpou esthiōn kai pinōn kai legete idou anthrōpos phagos kai oinopotēs philos telōnōn kai hamartōlōn*—friend of sinners.

"''Wisdom is justified of all her children.''"

*Kai edikaiōthē hē sophia apo pantōn tōn teknōn autēs*—wisdom.

**Sinful Woman Anoints Yeshua (7:36-50):**
"'One of the Pharisees desired him that he would eat with him.'"

*Ērōta de tis auton tōn Pharisaiōn hina phagē met' autou*—Pharisee.

"'A woman who was in the city, a sinner.'"

*Kai idou gynē hētis ēn en tē polei hamartōlos*—sinner.

"'She brought an alabaster cruse of ointment.'"

*Komisasa alabastron myrou*—ointment.

"'Standing behind at his feet, weeping, she began to wet his feet with her tears.'"

*Kai stasa opisō para tous podas autou klaiousa tois dakrysin ērxato brechein tous podas autou*—tears.

"'Wiped them with the hair of her head, and kissed his feet, and anointed them with the ointment.'"

*Kai tais thrixin tēs kephalēs autēs exemassen kai katephilei tous podas autou kai ēleiphen tō myrō*—kissed, anointed.

"''This man, if he were a prophet, would have perceived who and what manner of woman this is.''"

*Houtos ei ēn prophētēs eginōsken an tis kai potapē hē gynē hētis haptetai autou*—if prophet.

"''A certain lender had two debtors: the one owed five hundred pence, and the other fifty.''"

*Dyo chreopheiletai ēsan daneistē tini ho heis ōpheilen dēnaria pentakosia ho de heteros pentēkonta*—debtors.

"''When they had not wherewith to pay, he forgave them both.''"

*Mē echontōn autōn apodounai amphoterois echarisato*—forgave.

"''Which of them therefore will love him most?''"

*Tis oun autōn pleion agapēsei auton*—love most.

"''I entered into your house, you gave me no water for my feet.''"

*Eisēlthon sou eis tēn oikian hydōr moi epi podas ouk edōkas*—no water.

"''You gave me no kiss.''"

*Philēma moi ouk edōkas*—no kiss.

"''My head with oil you did not anoint.''"

*Elaiō tēn kephalēn mou ouk ēleipsas*—no oil.

"''Her sins, which are many, are forgiven; for she loved much.''"

*Aphēontai hai hamartiai autēs hai pollai hoti ēgapēsen poly*—loved much.

"''To whom little is forgiven, the same loves little.''"

*Hō de oligon aphietai oligon agapa*—little forgiven.

"''Your sins are forgiven.''"

*Aphēontai sou hai hamartiai*—forgiven.

"''Who is this that even forgives sins?''"

*Tis houtos estin hos kai hamartias aphiēsin*—who forgives?

"''Your faith has saved you; go in peace.''"

*Hē pistis sou sesōken se poreuou eis eirēnēn*—faith saves.

**Archetypal Layer:** Luke 7 contains **centurion's servant (7:1-10)**: "He loves our nation, and himself built us our synagogue" (7:5), "I am not worthy that you should come under my roof" (7:6), "say the word, and my servant shall be healed" (7:7), **"I have not found so great faith, no, not in Israel" (7:9)**, **raising the widow's son at Nain (7:11-17)** (unique to Luke): "he had compassion on her" (7:13), "Young man, I say unto you, Arise" (7:14), **"A great prophet is arisen among us... God has visited his people" (7:16)**, **John's question: "Are you he that comes, or look we for another?" (7:19)**, **"the blind receive their sight, the lame walk, the lepers are cleansed, and the deaf hear, the dead are raised up, the poor have good tidings preached to them" (7:22)**, **"none greater than John: yet he that is but little in the kingdom of God is greater than he" (7:28)**, **"Wisdom is justified of all her children" (7:35)**, and **the sinful woman anoints Yeshua (7:36-50)** (unique to Luke): tears, hair, kisses, ointment, two debtors parable, **"Her sins, which are many, are forgiven; for she loved much" (7:47)**, **"Your faith has saved you; go in peace" (7:50)**.

**Modern Equivalent:** Luke 7 shows faith, compassion, and forgiveness. The centurion's faith (7:1-10) exceeds Israel's. The widow of Nain story (7:11-17), unique to Luke, echoes Elijah. John's question (7:19) receives an Isaiah-based answer (7:22). The sinful woman story (7:36-50), unique to Luke, contrasts the Pharisee's hospitality failure with her extravagant devotion. The parable of the two debtors (7:41-43) explains: those forgiven much, love much. "Your faith has saved you" (7:50)—faith, not works, brings salvation.

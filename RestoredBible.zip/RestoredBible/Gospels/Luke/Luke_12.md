# Luke 12: Warnings, Parables, and Watchfulness

*From the Greek: Ἐν οἷς ἐπισυναχθεισῶν τῶν μυριάδων τοῦ ὄχλου (En Hois Episynachtheisōn tōn Myriadōn tou Ochlou) — In the Mean Time, When the Many Thousands of the Multitude Were Gathered Together*

---

## Warning against Hypocrisy (12:1-3)

**12:1** In the mean time, when the many thousands of the multitude were gathered together, insomuch that they trod one upon another, he began to say unto his disciples first of all: "Beware of the leaven of the Pharisees, which is hypocrisy.

**12:2** "But there is nothing covered up, that shall not be revealed; and hid, that shall not be known.

**12:3** "Wherefore whatsoever you have said in the darkness shall be heard in the light; and what you have spoken in the ear in the inner chambers shall be proclaimed upon the housetops."

---

## Whom to Fear (12:4-7)

**12:4** "And I say unto you my friends, Be not afraid of them that kill the body, and after that have no more that they can do.

**12:5** "But I will warn you whom you shall fear: Fear him, who after he has killed has power to cast into Gehenna; yea, I say unto you, Fear him.

**12:6** "Are not five sparrows sold for two farthings? And not one of them is forgotten in the sight of God.

**12:7** "But the very hairs of your head are all numbered. Fear not: you are of more value than many sparrows."

---

## Confessing the Son of Man (12:8-12)

**12:8** "And I say unto you, Every one who shall confess me before men, him shall the Son of man also confess before the angels of God:

**12:9** "But he that denies me in the presence of men shall be denied in the presence of the angels of God.

**12:10** "And every one who shall speak a word against the Son of man, it shall be forgiven him: but unto him that blasphemes against the Holy Spirit it shall not be forgiven.

**12:11** "And when they bring you before the synagogues, and the rulers, and the authorities, be not anxious how or what you shall answer, or what you shall say:

**12:12** "For the Holy Spirit shall teach you in that very hour what you ought to say."

---

## The Parable of the Rich Fool (12:13-21)

**12:13** And one out of the multitude said unto him: "Teacher, bid my brother divide the inheritance with me."

**12:14** But he said unto him: "Man, who made me a judge or a divider over you?"

**12:15** And he said unto them: "Take heed, and keep yourselves from all covetousness: for a man's life consists not in the abundance of the things which he possesses."

**12:16** And he spoke a parable unto them, saying: "The ground of a certain rich man brought forth plentifully:

**12:17** "And he reasoned within himself, saying, 'What shall I do, because I have not where to bestow my fruits?'

**12:18** "And he said, 'This will I do: I will pull down my barns, and build greater; and there will I bestow all my grain and my goods.

**12:19** "'And I will say to my soul, Soul, you have much goods laid up for many years; take your ease, eat, drink, be merry.'

**12:20** "But God said unto him, 'You foolish one, this night is your soul required of you; and the things which you have prepared, whose shall they be?'

**12:21** "So is he that lays up treasure for himself, and is not rich toward God."

---

## Do Not Be Anxious (12:22-34)

**12:22** And he said unto his disciples: "Therefore I say unto you, Be not anxious for your life, what you shall eat; nor yet for your body, what you shall put on.

**12:23** "For the life is more than the food, and the body than the raiment.

**12:24** "Consider the ravens, that they sow not, neither reap; which have no store-chamber nor barn; and God feeds them: of how much more value are you than the birds!

**12:25** "And which of you by being anxious can add a cubit unto the measure of his life?

**12:26** "If then you are not able to do even that which is least, why are you anxious concerning the rest?

**12:27** "Consider the lilies, how they grow: they toil not, neither do they spin; yet I say unto you, Even Solomon in all his glory was not arrayed like one of these.

**12:28** "But if God so clothes the grass in the field, which today is, and tomorrow is cast into the oven; how much more shall he clothe you, O you of little faith?

**12:29** "And seek not what you shall eat, and what you shall drink, neither be of doubtful mind.

**12:30** "For all these things do the nations of the world seek after: but your Father knows that you have need of these things.

**12:31** "Yet seek his kingdom, and these things shall be added unto you.

**12:32** "Fear not, little flock; for it is your Father's good pleasure to give you the kingdom.

**12:33** "Sell what you have, and give alms; make for yourselves purses which wax not old, a treasure in the heavens that fails not, where no thief draws near, neither moth destroys.

**12:34** "For where your treasure is, there will your heart be also."

---

## Watchful Servants (12:35-40)

**12:35** "Let your loins be girded about, and your lamps burning;

**12:36** "And be yourselves like unto men looking for their lord, when he shall return from the marriage feast; that, when he comes and knocks, they may straightway open unto him.

**12:37** "Blessed are those servants, whom the lord when he comes shall find watching: verily I say unto you, that he shall gird himself, and make them sit down to meat, and shall come and serve them.

**12:38** "And if he shall come in the second watch, and if in the third, and find them so, blessed are those servants.

**12:39** "But know this, that if the master of the house had known in what hour the thief was coming, he would have watched, and not have left his house to be broken through.

**12:40** "Be also ready: for in an hour that you think not the Son of man comes."

---

## The Faithful and Unfaithful Steward (12:41-48)

**12:41** And Peter said: "Lord, do you speak this parable unto us, or even unto all?"

**12:42** And the Lord said: "Who then is the faithful and wise steward, whom his lord shall set over his household, to give them their portion of food in due season?

**12:43** "Blessed is that servant, whom his lord when he comes shall find so doing.

**12:44** "Of a truth I say unto you, that he will set him over all that he has.

**12:45** "But if that servant shall say in his heart, 'My lord delays his coming'; and shall begin to beat the menservants and the maidservants, and to eat and drink, and to be drunken;

**12:46** "The lord of that servant shall come in a day when he expects not, and in an hour when he knows not, and shall cut him asunder, and appoint his portion with the unfaithful.

**12:47** "And that servant, who knew his lord's will, and made not ready, nor did according to his will, shall be beaten with many stripes;

**12:48** "But he that knew not, and did things worthy of stripes, shall be beaten with few stripes. And to whomsoever much is given, of him shall much be required: and to whom they commit much, of him will they ask the more."

---

## Yeshua the Cause of Division (12:49-53)

**12:49** "I came to cast fire upon the earth; and what do I desire, if it is already kindled?

**12:50** "But I have an immersion to be immersed with; and how am I straitened till it be accomplished!

**12:51** "Think you that I am come to give peace in the earth? I tell you, Nay; but rather division:

**12:52** "For there shall be from henceforth five in one house divided, three against two, and two against three.

**12:53** "They shall be divided, father against son, and son against father; mother against daughter, and daughter against her mother; mother in law against her daughter in law, and daughter in law against her mother in law."

---

## Interpreting the Times (12:54-59)

**12:54** And he said to the multitudes also: "When you see a cloud rising in the west, straightway you say, 'There comes a shower'; and so it comes to pass.

**12:55** "And when you see a south wind blowing, you say, 'There will be a scorching heat'; and it comes to pass.

**12:56** "You hypocrites, you know how to interpret the face of the earth and the heaven; but how is it that you know not how to interpret this time?

**12:57** "And why even of yourselves judge you not what is right?

**12:58** "For as you are going with your adversary before the magistrate, on the way give diligence to be quit of him; lest haply he drag you unto the judge, and the judge shall deliver you to the officer, and the officer shall cast you into prison.

**12:59** "I say unto you, You shall by no means come out thence, till you have paid the very last mite."

---

## Synthesis Notes

**Key Restorations:**

**Warning against Hypocrisy (12:1-3):**
"'When the many thousands of the multitude were gathered together.'"

*En hois episynachtheisōn tōn myriadōn tou ochlou*—myriads.

"''Beware of the leaven of the Pharisees, which is hypocrisy.''"

*Prosechete heautois apo tēs zymēs hētis estin hypokrisis tōn Pharisaiōn*—hypocrisy.

"''There is nothing covered up, that shall not be revealed.''"

*Ouden de synkekalymmenon estin ho ouk apokalyphthēsetai*—revealed.

**Whom to Fear (12:4-7):**
"''Be not afraid of them that kill the body.''"

*Mē phobēthēte apo tōn apokteinontōn to sōma*—don't fear.

"''Fear him, who after he has killed has power to cast into Gehenna.''"

*Phobēthēte ton meta to apokteinai echonta exousian embalein eis tēn geennan*—Gehenna.

"''Are not five sparrows sold for two farthings?''"

*Ouchi pente strouthia pōlountai assariōn dyo*—five sparrows.

**Luke's Detail:**
Matthew has two sparrows for one penny.

"''The very hairs of your head are all numbered.''"

*Alla kai hai triches tēs kephalēs hymōn pasai ērithmēntai*—numbered.

**Confessing the Son of Man (12:8-12):**
"''Every one who shall confess me before men.''"

*Pas hos an homologēsē en emoi emprosthen tōn anthrōpōn*—confess.

"''Him shall the Son of man also confess before the angels of God.''"

*Kai ho huios tou anthrōpou homologēsei en autō emprosthen tōn angelōn tou theou*—angels.

"''Unto him that blasphemes against the Holy Spirit it shall not be forgiven.''"

*Tō de eis to hagion pneuma blasphēmēsanti ouk aphethēsetai*—unforgivable.

"''The Holy Spirit shall teach you in that very hour what you ought to say.''"

*To gar hagion pneuma didaxei hymas en autē tē hōra ha dei eipein*—Spirit teaches.

**Rich Fool (12:13-21):**
"''Teacher, bid my brother divide the inheritance with me.''"

*Didaskale eipe tō adelphō mou merisasthai met' emou tēn klēronomian*—inheritance.

"''Man, who made me a judge or a divider over you?''"

*Anthrōpe tis me katestēsen kritēn ē meristēn eph' hymas*—not judge.

"''A man's life consists not in the abundance of the things which he possesses.''"

*Ouk en tō perisseuein tini hē zōē autou estin ek tōn hyparchontōn autō*—not possessions.

**Only Luke:**
This parable unique to Luke.

"''Soul, you have much goods laid up for many years; take your ease, eat, drink, be merry.''"

*Psychē echeis polla agatha keimena eis etē polla anapauou phage pie euphrainou*—eat, drink.

"''You foolish one, this night is your soul required of you.''"

*Aphrōn tautē tē nykti tēn psychēn sou apaitousin apo sou*—this night.

"''So is he that lays up treasure for himself, and is not rich toward God.''"

*Houtōs ho thēsaurizōn heautō kai mē eis theon ploutōn*—rich toward God.

**Do Not Be Anxious (12:22-34):**
"''Be not anxious for your life, what you shall eat.''"

*Mē merimnate tē psychē ti phagēte*—don't be anxious.

"''Consider the ravens, that they sow not, neither reap.''"

*Katanoēsate tous korakas hoti ou speirousin oude therizousin*—ravens.

**Luke's Detail:**
"Ravens" instead of Matthew's "birds."

"''Which of you by being anxious can add a cubit unto the measure of his life?''"

*Tis de ex hymōn merimnōn dynatai epi tēn hēlikian autou prostheinai pēchyn*—cubit.

"''Consider the lilies, how they grow.''"

*Katanoēsate ta krina pōs auxanei*—lilies.

"''Even Solomon in all his glory was not arrayed like one of these.''"

*Oude Solomōn en pasē tē doxē autou periebalet hōs hen toutōn*—Solomon.

"''Seek his kingdom, and these things shall be added unto you.''"

*Plēn zēteite tēn basileian autou kai tauta prostethēsetai hymin*—seek kingdom.

"''Fear not, little flock; for it is your Father's good pleasure to give you the kingdom.''"

*Mē phobou to mikron poimnion hoti eudokēsen ho patēr hymōn dounai hymin tēn basileian*—little flock.

**Only Luke:**
This verse unique to Luke.

"''Sell what you have, and give alms.''"

*Pōlēsate ta hyparchonta hymōn kai dote eleēmosynēn*—sell, give.

"''Where your treasure is, there will your heart be also.''"

*Hopou gar estin ho thēsauros hymōn ekei kai hē kardia hymōn estai*—heart.

**Watchful Servants (12:35-40):**
"''Let your loins be girded about, and your lamps burning.''"

*Estōsan hymōn hai osphyes periezōsmenai kai hoi lychnoi kaiomenoi*—ready.

"''He shall gird himself, and make them sit down to meat, and shall come and serve them.''"

*Perizōsetai kai anaklinei autous kai parelthōn diakonēsei autois*—master serves.

**Remarkable Reversal:**
Master serves the servants.

"''If the master of the house had known in what hour the thief was coming.''"

*Touto de ginōskete hoti ei ēdei ho oikodespotēs poia hōra ho kleptēs erchetai*—thief.

"''Be also ready: for in an hour that you think not the Son of man comes.''"

*Kai hymeis ginesthe hetoimoi hoti hē hōra ou dokeite ho huios tou anthrōpou erchetai*—unexpected.

**Faithful and Unfaithful Steward (12:41-48):**
"''Lord, do you speak this parable unto us, or even unto all?''"

*Kyrie pros hēmas tēn parabolēn tautēn legeis ē kai pros pantas*—Peter's question.

**Only Luke:**
Peter's question unique to Luke.

"''Who then is the faithful and wise steward?''"

*Tis ara estin ho pistos oikonomos ho phronimos*—steward.

"''He will set him over all that he has.''"

*Epi pasin tois hyparchousin autou katastēsei auton*—set over.

"''If that servant shall say in his heart, My lord delays his coming.''"

*Ean de eipē ho doulos ekeinos en tē kardia autou chronizei ho kyrios mou erchesthai*—delays.

"''To whomsoever much is given, of him shall much be required.''"

*Panti de hō edothē poly poly zētēthēsetai par' autou*—much required.

**Yeshua the Cause of Division (12:49-53):**
"''I came to cast fire upon the earth.''"

*Pyr ēlthon balein epi tēn gēn*—fire.

"''I have an immersion to be immersed with.''"

*Baptisma de echō baptisthēnai*—immersion = death.

"''How am I straitened till it be accomplished!''"

*Kai pōs synechomai heōs hotou telesthē*—straitened.

"''Think you that I am come to give peace in the earth? I tell you, Nay; but rather division.''"

*Dokeite hoti eirēnēn paregenomēn dounai en tē gē ouchi legō hymin all' ē diamerismon*—division.

**Interpreting the Times (12:54-59):**
"''When you see a cloud rising in the west.''"

*Hotan idēte tēn nephelēn anatellousan epi dysmōn*—cloud.

"''You hypocrites, you know how to interpret the face of the earth and the heaven.''"

*Hypokritai to prosōpon tēs gēs kai tou ouranou oidate dokimazein*—interpret.

"''How is it that you know not how to interpret this time?''"

*Ton kairon de touton pōs ouk oidate dokimazein*—this time.

"''Give diligence to be quit of him.''"

*En tē hodō dos ergasian apēllachthai ap' autou*—settle.

**Archetypal Layer:** Luke 12 contains **warning against hypocrisy (12:1-3)**, **whom to fear (12:4-7)**: "Fear him, who... has power to cast into Gehenna" (12:5), five sparrows, hairs numbered, **confessing the Son of man (12:8-12)**: blasphemy against Holy Spirit (12:10), Spirit teaches (12:12), **the rich fool (12:13-21)** (unique to Luke): "a man's life consists not in the abundance of the things which he possesses" (12:15), "You foolish one, this night is your soul required of you" (12:20), **"is not rich toward God" (12:21)**, **do not be anxious (12:22-34)**: ravens, lilies, Solomon, **"Fear not, little flock; for it is your Father's good pleasure to give you the kingdom" (12:32)** (unique to Luke), "Sell what you have, and give alms" (12:33), **"where your treasure is, there will your heart be also" (12:34)**, **watchful servants (12:35-40)**: master serves servants (12:37), thief image, **"Be also ready" (12:40)**, **faithful and unfaithful steward (12:41-48)**: Peter's question (12:41), **"to whomsoever much is given, of him shall much be required" (12:48)**, **Yeshua the cause of division (12:49-53)**: "I came to cast fire" (12:49), **"I have an immersion to be immersed with" (12:50)**, and **interpreting the times (12:54-59)**: "how is it that you know not how to interpret this time?" (12:56).

**Modern Equivalent:** Luke 12 addresses fear, possessions, and readiness. Don't fear those who kill only the body (12:4-5). The rich fool (12:13-21), unique to Luke, warns against covetousness. "Fear not, little flock" (12:32) is precious reassurance. The watchful servants parable (12:35-40) includes the remarkable reversal: the master serves (12:37). "To whomsoever much is given, of him shall much be required" (12:48) teaches accountability. Yeshua's "immersion" (12:50) is his death. Division, not peace, follows discipleship (12:51-53).

# Luke 10: The Seventy, the Good Samaritan, and Mary and Martha

*From the Greek: Μετὰ δὲ ταῦτα ἀνέδειξεν ὁ κύριος (Meta de Tauta Anedeixen ho Kyrios) — Now After These Things the Lord Appointed*

---

## The Mission of the Seventy (10:1-16)

**10:1** Now after these things the Lord appointed seventy others, and sent them two and two before his face into every city and place, where he himself was about to come.

**10:2** And he said unto them: "The harvest indeed is plenteous, but the labourers are few: pray therefore the Lord of the harvest, that he send forth labourers into his harvest.

**10:3** "Go your ways; behold, I send you forth as lambs in the midst of wolves.

**10:4** "Carry no purse, no wallet, no shoes; and salute no man on the way.

**10:5** "And into whatsoever house you shall enter, first say, 'Peace be to this house.'

**10:6** "And if a son of peace be there, your peace shall rest upon him: but if not, it shall turn to you again.

**10:7** "And in that same house remain, eating and drinking such things as they give: for the labourer is worthy of his hire. Go not from house to house.

**10:8** "And into whatsoever city you enter, and they receive you, eat such things as are set before you:

**10:9** "And heal the sick that are therein, and say unto them, 'The kingdom of God is come near unto you.'

**10:10** "But into whatsoever city you shall enter, and they receive you not, go out into the streets thereof and say:

**10:11** "'Even the dust from your city, that cleaves to our feet, we wipe off against you: nevertheless know this, that the kingdom of God is come near.'

**10:12** "I say unto you, it shall be more tolerable in that day for Sodom, than for that city.

**10:13** "Woe unto you, Chorazin! Woe unto you, Bethsaida! For if the mighty works had been done in Tyre and Sidon, which were done in you, they would have repented long ago, sitting in sackcloth and ashes.

**10:14** "But it shall be more tolerable for Tyre and Sidon in the judgment, than for you.

**10:15** "And you, Capernaum, shall you be exalted unto heaven? You shall be brought down unto Hades.

**10:16** "He that hears you hears me; and he that rejects you rejects me; and he that rejects me rejects him that sent me."

---

## The Return of the Seventy (10:17-20)

**10:17** And the seventy returned with joy, saying: "Lord, even the demons are subject unto us in your name."

**10:18** And he said unto them: "I beheld Satan fallen as lightning from heaven.

**10:19** "Behold, I have given you authority to tread upon serpents and scorpions, and over all the power of the enemy: and nothing shall in any wise hurt you.

**10:20** "Nevertheless in this rejoice not, that the spirits are subject unto you; but rejoice that your names are written in heaven."

---

## Yeshua Rejoices in the Spirit (10:21-24)

**10:21** In that same hour he rejoiced in the Holy Spirit, and said: "I thank you, O Father, Lord of heaven and earth, that you did hide these things from the wise and understanding, and did reveal them unto babes: yea, Father; for so it was well-pleasing in your sight.

**10:22** "All things have been delivered unto me of my Father: and no one knows who the Son is, save the Father; and who the Father is, save the Son, and he to whomsoever the Son wills to reveal him."

**10:23** And turning to the disciples, he said privately: "Blessed are the eyes which see the things that you see:

**10:24** "For I say unto you, that many prophets and kings desired to see the things which you see, and saw them not; and to hear the things which you hear, and heard them not."

---

## The Good Samaritan (10:25-37)

**10:25** And behold, a certain lawyer stood up and made trial of him, saying: "Teacher, what shall I do to inherit eternal life?"

**10:26** And he said unto him: "What is written in the law? How do you read?"

**10:27** And he answering said: "You shall love the Lord your God with all your heart, and with all your soul, and with all your strength, and with all your mind; and your neighbour as yourself."

**10:28** And he said unto him: "You have answered right: this do, and you shall live."

**10:29** But he, desiring to justify himself, said unto Yeshua: "And who is my neighbour?"

**10:30** Yeshua made answer and said: "A certain man was going down from Jerusalem to Jericho; and he fell among robbers, who both stripped him and beat him, and departed, leaving him half dead.

**10:31** "And by chance a certain priest was going down that way: and when he saw him, he passed by on the other side.

**10:32** "And in like manner a Levite also, when he came to the place, and saw him, passed by on the other side.

**10:33** "But a certain Samaritan, as he journeyed, came where he was: and when he saw him, he was moved with compassion,

**10:34** "And came to him, and bound up his wounds, pouring on them oil and wine; and he set him on his own beast, and brought him to an inn, and took care of him.

**10:35** "And on the morrow he took out two pence, and gave them to the host, and said, 'Take care of him; and whatsoever you spend more, I, when I come back again, will repay you.'

**10:36** "Which of these three, think you, proved neighbour unto him that fell among the robbers?"

**10:37** And he said: "He that showed mercy on him." And Yeshua said unto him: "Go, and do likewise."

---

## Mary and Martha (10:38-42)

**10:38** Now as they went on their way, he entered into a certain village: and a certain woman named Martha received him into her house.

**10:39** And she had a sister called Mary, who also sat at the Lord's feet, and heard his word.

**10:40** But Martha was cumbered about much serving; and she came up to him, and said: "Lord, do you not care that my sister left me to serve alone? Bid her therefore that she help me."

**10:41** But the Lord answered and said unto her: "Martha, Martha, you are anxious and troubled about many things:

**10:42** "But one thing is needful: for Mary has chosen the good part, which shall not be taken away from her."

---

## Synthesis Notes

**Key Restorations:**

**Mission of the Seventy (10:1-16):**
"'The Lord appointed seventy others, and sent them two and two.'"

*Anedeixen ho kyrios heterous hebdomēkonta kai apesteilen autous ana dyo*—seventy.

**Only Luke:**
This mission unique to Luke.

"''The harvest indeed is plenteous, but the labourers are few.''"

*Ho men therismos polys hoi de ergatai oligoi*—harvest.

"''I send you forth as lambs in the midst of wolves.''"

*Apostellō hymas hōs arnas en mesō lykōn*—lambs.

"''Carry no purse, no wallet, no shoes.''"

*Mē bastazete balantion mē pēran mē hypodēmata*—nothing.

"''Salute no man on the way.''"

*Kai mēdena kata tēn hodon aspasēsthe*—urgency.

"''Peace be to this house.''"

*Eirēnē tō oikō toutō*—peace.

"''If a son of peace be there, your peace shall rest upon him.''"

*Kai ean ekei ē huios eirēnēs epanapahsetai ep' auton hē eirēnē hymōn*—son of peace.

"''The labourer is worthy of his hire.''"

*Axios gar ho ergatēs tou misthou autou*—worthy.

"''The kingdom of God is come near unto you.''"

*Ēngiken eph' hymas hē basileia tou theou*—near.

"''Even the dust from your city, that cleaves to our feet, we wipe off against you.''"

*Kai ton koniorton ton kollēthenta hēmin ek tēs poleōs hymōn eis tous podas apomassometha hymin*—dust.

"''Woe unto you, Chorazin! Woe unto you, Bethsaida!''"

*Ouai soi Chorazin ouai soi Bēthsaida*—woe.

"''Capernaum, shall you be exalted unto heaven? You shall be brought down unto Hades.''"

*Kai sy Kapharnaoum mē heōs ouranou hypsōthēsē heōs tou hadou katabēsē*—Hades.

"''He that hears you hears me; and he that rejects you rejects me.''"

*Ho akouōn hymōn emou akouei kai ho athetōn hymas eme athetei*—representation.

**Return of the Seventy (10:17-20):**
"''Lord, even the demons are subject unto us in your name.''"

*Kyrie kai ta daimonia hypotassetai hēmin en tō onomati sou*—subject.

"''I beheld Satan fallen as lightning from heaven.''"

*Etheōroun ton Satanan hōs astrapēn ek tou ouranou pesonta*—Satan fell.

"''I have given you authority to tread upon serpents and scorpions.''"

*Idou dedōka hymin tēn exousian tou patein epanō opheōn kai skorpiōn*—authority.

"''Nothing shall in any wise hurt you.''"

*Kai ouden hymas ou mē adikēsē*—unhurt.

"''Rejoice that your names are written in heaven.''"

*Chairete de hoti ta onomata hymōn engegraptai en tois ouranois*—written.

**Yeshua Rejoices in the Spirit (10:21-24):**
"'He rejoiced in the Holy Spirit.'"

*Ēgalliasato tō pneumati tō hagiō*—rejoiced.

**Only Luke:**
Notes Yeshua rejoicing.

"''I thank you, O Father, Lord of heaven and earth, that you did hide these things from the wise and understanding, and did reveal them unto babes.''"

*Exomologoumai soi pater kyrie tou ouranou kai tēs gēs hoti apekrypsas tauta apo sophōn kai synetōn kai apekalypsas auta nēpiois*—babes.

"''All things have been delivered unto me of my Father.''"

*Panta moi paredothē hypo tou patros mou*—all things.

"''No one knows who the Son is, save the Father; and who the Father is, save the Son.''"

*Kai oudeis ginōskei tis estin ho huios ei mē ho patēr kai tis estin ho patēr ei mē ho huios*—mutual knowledge.

"''Blessed are the eyes which see the things that you see.''"

*Makarioi hoi ophthalmoi hoi blepontes ha blepete*—blessed.

**Good Samaritan (10:25-37):**
"''Teacher, what shall I do to inherit eternal life?''"

*Didaskale ti poiēsas zōēn aiōnion klēronomēsō*—eternal life.

"''What is written in the law? How do you read?''"

*En tō nomō ti gegraptai pōs anaginōskeis*—law.

"''You shall love the Lord your God with all your heart... and your neighbour as yourself.''"

*Agapēseis kyrion ton theon sou ex holēs tēs kardias sou... kai ton plēsion sou hōs seauton*—Deuteronomy 6:5, Leviticus 19:18.

"''This do, and you shall live.''"

*Touto poiei kai zēsē*—do and live.

"''And who is my neighbour?''"

*Kai tis estin mou plēsion*—who?

"'A certain man was going down from Jerusalem to Jericho; and he fell among robbers.'"

*Anthrōpos tis katebainen apo Hierousalēm eis Ierichō kai lēstais periepesen*—robbers.

"'A certain priest was going down that way: and when he saw him, he passed by on the other side.'"

*Hiereus tis katebainen en tē hodō ekeinē kai idōn auton antiparēlthen*—passed by.

"'A Levite also... passed by on the other side.'"

*Homoiōs de kai Leuitēs... antiparēlthen*—passed by.

"'A certain Samaritan, as he journeyed, came where he was: and when he saw him, he was moved with compassion.'"

*Samaritēs de tis hodeuōn ēlthen kat' auton kai idōn esplanchnisthē*—compassion.

"'Bound up his wounds, pouring on them oil and wine.'"

*Kai proselthōn katedēsen ta traumata autou epicheōn elaion kai oinon*—bound.

"'Set him on his own beast, and brought him to an inn.'"

*Epibibasas de auton epi to idion ktēnos ēgagen auton eis pandocheion*—inn.

"''Take care of him; and whatsoever you spend more, I... will repay you.''"

*Epimelēthēti autou kai ho ti an prosdapanēsēs egō... apodōsō soi*—repay.

"''Which of these three, think you, proved neighbour unto him that fell among the robbers?''"

*Tis toutōn tōn triōn plēsion dokei soi gegonenai tou empesontos eis tous lēstas*—which neighbor?

"''He that showed mercy on him.''"

*Ho poiēsas to eleos met' autou*—showed mercy.

"''Go, and do likewise.''"

*Poreuou kai sy poiei homoiōs*—do likewise.

**Mary and Martha (10:38-42):**
"'A certain woman named Martha received him into her house.'"

*Gynē de tis onomati Martha hypedexato auton*—Martha.

**Only Luke:**
This story unique to Luke.

"'She had a sister called Mary, who also sat at the Lord's feet, and heard his word.'"

*Kai tēde ēn adelphē kaloumenē Mariam hē kai parakathestheisa pros tous podas tou kyriou ēkouen ton logon autou*—feet.

"'Martha was cumbered about much serving.'"

*Hē de Martha periespato peri pollēn diakonian*—cumbered.

"''Lord, do you not care that my sister left me to serve alone?''"

*Kyrie ou melei soi hoti hē adelphē mou monēn me kateleipen diakonein*—alone.

"''Martha, Martha, you are anxious and troubled about many things.''"

*Martha Martha merimnạs kai thorybazē peri polla*—anxious.

"''One thing is needful.''"

*Henos de estin chreia*—one thing.

"''Mary has chosen the good part, which shall not be taken away from her.''"

*Mariam gar tēn agathēn merida exelexato hētis ouk aphairethēsetai autēs*—good part.

**Archetypal Layer:** Luke 10 contains **mission of the seventy (10:1-16)** (unique to Luke): "The harvest indeed is plenteous, but the labourers are few" (10:2), "I send you forth as lambs in the midst of wolves" (10:3), "Peace be to this house" (10:5), "The kingdom of God is come near" (10:9), woes to Chorazin, Bethsaida, Capernaum (10:13-15), **"He that hears you hears me" (10:16)**, **return of the seventy (10:17-20)**: **"I beheld Satan fallen as lightning from heaven" (10:18)**, "authority to tread upon serpents and scorpions" (10:19), **"rejoice that your names are written in heaven" (10:20)**, **Yeshua rejoices in the Holy Spirit (10:21-24)**: revealed to babes, hidden from the wise, **"All things have been delivered unto me of my Father" (10:22)**, **the Good Samaritan (10:25-37)** (unique to Luke): lawyer's question, love God and neighbor, "And who is my neighbour?" (10:29), priest and Levite pass by, **Samaritan "moved with compassion" (10:33)**, **"Go, and do likewise" (10:37)**, and **Mary and Martha (10:38-42)** (unique to Luke): **"Mary has chosen the good part" (10:42)**.

**Modern Equivalent:** Luke 10 expands mission to seventy (10:1-16), prefiguring Gentile mission. Satan's fall (10:18) signals cosmic victory. The mutual knowledge saying (10:22) is "Johannine" in character. The Good Samaritan (10:25-37) redefines neighbor: not "who is my neighbor?" but "to whom can I be neighbor?" The despised Samaritan shows mercy while religious leaders pass by. Mary and Martha (10:38-42) contrasts active service with contemplative listening—both valid, but sitting at Yeshua's feet is "the good part."

# Luke 1: Prologue, Annunciations, and the Magnificat

*From the Greek: Ἐπειδήπερ πολλοὶ ἐπεχείρησαν (Epeidēper Polloi Epecheirēsan) — Forasmuch As Many Have Taken in Hand*

---

## Prologue (1:1-4)

**1:1** Forasmuch as many have taken in hand to draw up a narrative concerning those matters which have been fulfilled among us,

**1:2** Even as they delivered them unto us, who from the beginning were eyewitnesses and ministers of the word,

**1:3** It seemed good to me also, having traced the course of all things accurately from the first, to write unto you in order, most excellent Theophilus;

**1:4** That you might know the certainty concerning the things wherein you were instructed.

---

## The Birth of John Foretold (1:5-25)

**1:5** There was in the days of Herod, king of Judaea, a certain priest named Zacharias, of the course of Abijah: and he had a wife of the daughters of Aaron, and her name was Elizabeth.

**1:6** And they were both righteous before God, walking in all the commandments and ordinances of the Lord blameless.

**1:7** And they had no child, because that Elizabeth was barren, and they both were now well stricken in years.

**1:8** Now it came to pass, while he executed the priest's office before God in the order of his course,

**1:9** According to the custom of the priest's office, his lot was to enter into the temple of the Lord and burn incense.

**1:10** And the whole multitude of the people were praying without at the hour of incense.

**1:11** And there appeared unto him an angel of the Lord standing on the right side of the altar of incense.

**1:12** And Zacharias was troubled when he saw him, and fear fell upon him.

**1:13** But the angel said unto him: "Fear not, Zacharias; because your supplication is heard, and your wife Elizabeth shall bear you a son, and you shall call his name John.

**1:14** "And you shall have joy and gladness; and many shall rejoice at his birth.

**1:15** "For he shall be great in the sight of the Lord, and he shall drink no wine nor strong drink; and he shall be filled with the Holy Spirit, even from his mother's womb.

**1:16** "And many of the children of Israel shall he turn unto the Lord their God.

**1:17** "And he shall go before his face in the spirit and power of Elijah, to turn the hearts of the fathers to the children, and the disobedient to walk in the wisdom of the just; to make ready for the Lord a people prepared."

**1:18** And Zacharias said unto the angel: "Whereby shall I know this? For I am an old man, and my wife well stricken in years."

**1:19** And the angel answering said unto him: "I am Gabriel, that stand in the presence of God; and I was sent to speak unto you, and to bring you these good tidings.

**1:20** "And behold, you shall be silent and not able to speak, until the day that these things shall come to pass, because you believed not my words, which shall be fulfilled in their season."

**1:21** And the people were waiting for Zacharias, and they marvelled while he tarried in the temple.

**1:22** And when he came out, he could not speak unto them: and they perceived that he had seen a vision in the temple: and he continued making signs unto them, and remained dumb.

**1:23** And it came to pass, when the days of his ministration were fulfilled, he departed unto his house.

**1:24** And after these days Elizabeth his wife conceived; and she hid herself five months, saying:

**1:25** "Thus has the Lord done unto me in the days wherein he looked upon me, to take away my reproach among men."

---

## The Annunciation to Mary (1:26-38)

**1:26** Now in the sixth month the angel Gabriel was sent from God unto a city of Galilee, named Nazareth,

**1:27** To a virgin betrothed to a man whose name was Joseph, of the house of David; and the virgin's name was Mary.

**1:28** And he came in unto her, and said: "Hail, you that are highly favoured, the Lord is with you."

**1:29** But she was greatly troubled at the saying, and cast in her mind what manner of salutation this might be.

**1:30** And the angel said unto her: "Fear not, Mary: for you have found favour with God.

**1:31** "And behold, you shall conceive in your womb, and bring forth a son, and shall call his name YESHUA.

**1:32** "He shall be great, and shall be called the Son of the Most High: and the Lord God shall give unto him the throne of his father David:

**1:33** "And he shall reign over the house of Jacob for ever; and of his kingdom there shall be no end."

**1:34** And Mary said unto the angel: "How shall this be, seeing I know not a man?"

**1:35** And the angel answered and said unto her: "The Holy Spirit shall come upon you, and the power of the Most High shall overshadow you: wherefore also the holy thing which is begotten shall be called the Son of God.

**1:36** "And behold, Elizabeth your kinswoman, she also has conceived a son in her old age; and this is the sixth month with her that was called barren.

**1:37** "For no word from God shall be void of power."

**1:38** And Mary said: "Behold, the handmaid of the Lord; be it unto me according to your word." And the angel departed from her.

---

## Mary Visits Elizabeth (1:39-45)

**1:39** And Mary arose in these days and went into the hill country with haste, into a city of Judah;

**1:40** And entered into the house of Zacharias and saluted Elizabeth.

**1:41** And it came to pass, when Elizabeth heard the salutation of Mary, the babe leaped in her womb; and Elizabeth was filled with the Holy Spirit;

**1:42** And she lifted up her voice with a loud cry, and said: "Blessed are you among women, and blessed is the fruit of your womb.

**1:43** "And whence is this to me, that the mother of my Lord should come unto me?

**1:44** "For behold, when the voice of your salutation came into my ears, the babe leaped in my womb for joy.

**1:45** "And blessed is she that believed; for there shall be a fulfilment of the things which have been spoken to her from the Lord."

---

## The Magnificat (1:46-56)

**1:46** And Mary said:

"My soul does magnify the Lord,

**1:47** And my spirit has rejoiced in God my Saviour.

**1:48** For he has looked upon the low estate of his handmaid:
For behold, from henceforth all generations shall call me blessed.

**1:49** For he that is mighty has done to me great things;
And holy is his name.

**1:50** And his mercy is unto generations and generations
On them that fear him.

**1:51** He has showed strength with his arm;
He has scattered the proud in the imagination of their heart.

**1:52** He has put down princes from their thrones,
And has exalted them of low degree.

**1:53** The hungry he has filled with good things;
And the rich he has sent empty away.

**1:54** He has given help to Israel his servant,
That he might remember mercy

**1:55** (As he spoke unto our fathers)
Toward Abraham and his seed for ever."

**1:56** And Mary abode with her about three months, and returned unto her house.

---

## The Birth of John (1:57-66)

**1:57** Now Elizabeth's time was fulfilled that she should be delivered; and she brought forth a son.

**1:58** And her neighbours and her kinsfolk heard that the Lord had magnified his mercy towards her; and they rejoiced with her.

**1:59** And it came to pass on the eighth day, that they came to circumcise the child; and they would have called him Zacharias, after the name of his father.

**1:60** And his mother answered and said: "Not so; but he shall be called John."

**1:61** And they said unto her: "There is none of your kindred that is called by this name."

**1:62** And they made signs to his father, what he would have him called.

**1:63** And he asked for a writing tablet, and wrote, saying: "His name is John." And they marvelled all.

**1:64** And his mouth was opened immediately, and his tongue loosed, and he spoke, blessing God.

**1:65** And fear came on all that dwelt round about them: and all these sayings were noised abroad throughout all the hill country of Judaea.

**1:66** And all that heard them laid them up in their heart, saying: "What then shall this child be?" For the hand of the Lord was with him.

---

## The Benedictus (1:67-80)

**1:67** And his father Zacharias was filled with the Holy Spirit, and prophesied, saying:

**1:68** "Blessed be the Lord, the God of Israel;
For he has visited and wrought redemption for his people,

**1:69** And has raised up a horn of salvation for us
In the house of his servant David

**1:70** (As he spoke by the mouth of his holy prophets that have been from of old),

**1:71** Salvation from our enemies, and from the hand of all that hate us;

**1:72** To show mercy towards our fathers,
And to remember his holy covenant;

**1:73** The oath which he swore unto Abraham our father,

**1:74** To grant unto us that we being delivered out of the hand of our enemies
Should serve him without fear,

**1:75** In holiness and righteousness before him all our days.

**1:76** And you, child, shall be called the prophet of the Most High:
For you shall go before the face of the Lord to make ready his ways;

**1:77** To give knowledge of salvation unto his people
In the remission of their sins,

**1:78** Because of the tender mercy of our God,
Whereby the dayspring from on high shall visit us,

**1:79** To shine upon them that sit in darkness and the shadow of death;
To guide our feet into the way of peace."

**1:80** And the child grew, and waxed strong in spirit, and was in the deserts till the day of his showing unto Israel.

---

## Synthesis Notes

**Key Restorations:**

**Prologue (1:1-4):**
"'Forasmuch as many have taken in hand to draw up a narrative.'"

*Epeidēper polloi epecheirēsan anataxasthai diēgēsin*—narrative.

"'Those matters which have been fulfilled among us.'"

*Peri tōn peplērophorēmenōn en hēmin pragmatōn*—fulfilled.

"'Eyewitnesses and ministers of the word.'"

*Hoi ap' archēs autoptai kai hypēretai genomenoi tou logou*—eyewitnesses.

"'Having traced the course of all things accurately from the first.'"

*Parēkolouthēkoti anōthen pasin akribōs*—accurately.

"'Most excellent Theophilus.'"

*Kratiste Theophile*—Theophilus.

**Theophilos:**
"Lover of God"—possibly a title or name.

"'That you might know the certainty.'"

*Hina epignōs... tēn asphaleian*—certainty.

**John's Birth Foretold (1:5-25):**
"'In the days of Herod, king of Judaea.'"

*En tais hēmerais Hērōdou basileos tēs Ioudaias*—Herod.

"'A certain priest named Zacharias, of the course of Abijah.'"

*Hiereus tis onomati Zacharias ex ephēmerias Abia*—priestly course.

"'A wife of the daughters of Aaron, and her name was Elizabeth.'"

*Gynē autō ek tōn thugatrōn Aarōn kai to onoma autēs Elisabet*—Elizabeth.

"'Both righteous before God, walking in all the commandments and ordinances of the Lord blameless.'"

*Ēsan de dikaioi amphoteroi enantion tou theou poreuomenoi en pasais tais entolais kai dikaiōmasin tou kyriou amemptoi*—blameless.

"''Fear not, Zacharias; because your supplication is heard.''"

*Mē phobou Zacharia dioti eisēkousthē hē deēsis sou*—heard.

"''Your wife Elizabeth shall bear you a son, and you shall call his name John.''"

*Kai hē gynē sou Elisabet gennēsei huion soi kai kaleseis to onoma autou Iōannēn*—John.

**Iōannēs:**
Hebrew Yohanan = "Yahweh is gracious."

"''He shall be great in the sight of the Lord.''"

*Estai gar megas enōpion tou kyriou*—great.

"''He shall drink no wine nor strong drink.''"

*Kai oinon kai sikera ou mē piē*—Nazirite.

"''He shall be filled with the Holy Spirit, even from his mother's womb.''"

*Kai pneumatos hagiou plēsthēsetai eti ek koilias mētros autou*—from womb.

"''He shall go before his face in the spirit and power of Elijah.''"

*Kai autos proeleusetai enōpion autou en pneumati kai dynamei Ēliou*—Elijah.

**Malachi 4:5-6.**

"''I am Gabriel, that stand in the presence of God.''"

*Egō eimi Gabriēl ho parestēkōs enōpion tou theou*—Gabriel.

"''You shall be silent and not able to speak, until the day that these things shall come to pass.''"

*Kai idou esē siōpōn kai mē dynamenos lalēsai achri hēs hēmeras genētai tauta*—silent.

**Annunciation to Mary (1:26-38):**
"'In the sixth month the angel Gabriel was sent from God unto a city of Galilee, named Nazareth.'"

*En de tō mēni tō hektō apestalē ho angelos Gabriēl apo tou theou eis polin tēs Galilaias hē onoma Nazareth*—sixth month.

"'To a virgin betrothed to a man whose name was Joseph, of the house of David.'"

*Pros parthenon emnēsteumenēn andri hō onoma Iōsēph ex oikou David*—David's house.

"''Hail, you that are highly favoured, the Lord is with you.''"

*Chaire kecharitōmenē ho kyrios meta sou*—favoured.

"''Fear not, Mary: for you have found favour with God.''"

*Mē phobou Mariam heures gar charin para tō theō*—favour.

"''You shall conceive in your womb, and bring forth a son, and shall call his name YESHUA.''"

*Kai idou syllēmpsē en gastri kai texē huion kai kaleseis to onoma autou Iēsoun*—Yeshua.

"''He shall be great, and shall be called the Son of the Most High.''"

*Houtos estai megas kai huios hypsistou klēthēsetai*—Son of Most High.

"''The Lord God shall give unto him the throne of his father David.''"

*Kai dōsei autō kyrios ho theos ton thronon David tou patros autou*—David's throne.

"''He shall reign over the house of Jacob for ever; and of his kingdom there shall be no end.''"

*Kai basileusei epi ton oikon Iakōb eis tous aiōnas kai tēs basileias autou ouk estai telos*—eternal kingdom.

"''How shall this be, seeing I know not a man?''"

*Pōs estai touto epei andra ou ginōskō*—how?

"''The Holy Spirit shall come upon you, and the power of the Most High shall overshadow you.''"

*Pneuma hagion epeleusetai epi se kai dynamis hypsistou episkiasei soi*—overshadow.

"''The holy thing which is begotten shall be called the Son of God.''"

*Dio kai to gennōmenon hagion klēthēsetai huios theou*—Son of God.

"''For no word from God shall be void of power.''"

*Hoti ouk adynatēsei para tou theou pan rhēma*—nothing impossible.

"''Behold, the handmaid of the Lord; be it unto me according to your word.''"

*Idou hē doulē kyriou genoito moi kata to rhēma sou*—fiat.

**Mary Visits Elizabeth (1:39-45):**
"'The babe leaped in her womb; and Elizabeth was filled with the Holy Spirit.'"

*Eskirtēsen to brephos en tē koilia autēs kai eplēsthē pneumatos hagiou hē Elisabet*—leaped.

"''Blessed are you among women, and blessed is the fruit of your womb.''"

*Eulogēmenē sy en gynaiksin kai eulogēmenos ho karpos tēs koilias sou*—blessed.

"''The mother of my Lord.''"

*Hē mētēr tou kyriou mou*—Lord.

"''Blessed is she that believed.''"

*Kai makaria hē pisteusasa*—believed.

**The Magnificat (1:46-56):**
"''My soul does magnify the Lord.''"

*Megalynei hē psychē mou ton kyrion*—magnify.

**1 Samuel 2:1-10 Parallel:**
Hannah's song.

"''He has looked upon the low estate of his handmaid.''"

*Hoti epeblepsen epi tēn tapeinōsin tēs doulēs autou*—low estate.

"''He that is mighty has done to me great things; and holy is his name.''"

*Hoti epoiēsen moi megala ho dynatos kai hagion to onoma autou*—mighty.

"''He has scattered the proud... put down princes from their thrones, and has exalted them of low degree.''"

*Dieskorpisen hyperēphanous... katheilen dynastas apo thronōn kai hypsōsen tapeinous*—reversal.

"''The hungry he has filled with good things; and the rich he has sent empty away.''"

*Peinōntas eneplēsen agathōn kai ploutountas exapesteilen kenous*—reversal.

**John's Birth (1:57-66):**
"''Not so; but he shall be called John.''"

*Ouchi alla klēthēsetai Iōannēs*—John.

"'He asked for a writing tablet, and wrote, saying: His name is John.'"

*Kai aitēsas pinakidion egrapsen legōn Iōannēs estin onoma autou*—wrote.

"'His mouth was opened immediately, and his tongue loosed.'"

*Aneōchthē de to stoma autou parachrēma kai hē glōssa autou*—opened.

**The Benedictus (1:67-80):**
"''Blessed be the Lord, the God of Israel; for he has visited and wrought redemption for his people.''"

*Eulogētos kyrios ho theos tou Israēl hoti epeskepsato kai epoiēsen lytrōsin tō laō autou*—visited.

"''A horn of salvation for us in the house of his servant David.''"

*Kai ēgeiren keras sōtērias hēmin en oikō David paidos autou*—horn.

"''Salvation from our enemies.''"

*Sōtērian ex echthrōn hēmōn*—salvation.

"''To remember his holy covenant; the oath which he swore unto Abraham.''"

*Mnēsthēnai diathēkēs hagias autou horkon hon ōmosen pros Abraam ton patera hēmōn*—covenant.

"''You, child, shall be called the prophet of the Most High.''"

*Kai sy de paidion prophētēs hypsistou klēthēsē*—prophet.

"''To give knowledge of salvation unto his people in the remission of their sins.''"

*Tou dounai gnōsin sōtērias tō laō autou en aphesei hamartiōn autōn*—remission.

"''The dayspring from on high shall visit us.''"

*Episkepsetai hēmas anatolē ex hypsous*—dayspring.

"''To shine upon them that sit in darkness and the shadow of death.''"

*Epiphanai tois en skotei kai skia thanatou kathēmenois*—Isaiah 9:2.

**Archetypal Layer:** Luke 1 contains **prologue to Theophilus (1:1-4)**: eyewitnesses, accuracy, certainty, **annunciation to Zacharias (1:5-25)**: righteous priest, Elizabeth barren, Gabriel announces John, Nazirite from womb, spirit and power of Elijah, Zacharias struck silent, **annunciation to Mary (1:26-38)**: Gabriel to Nazareth, virgin betrothed to Joseph, "Hail, you that are highly favoured," "you shall call his name YESHUA," "Son of the Most High," throne of David, kingdom without end, "The Holy Spirit shall come upon you," "no word from God shall be void of power," Mary's fiat, **Mary visits Elizabeth (1:39-45)**: babe leaps, "Blessed are you among women," "the mother of my Lord," **the Magnificat (1:46-56)**: "My soul does magnify the Lord," reversal theme, **John's birth (1:57-66)**: "His name is John," Zacharias's mouth opened, and **the Benedictus (1:67-80)**: "Blessed be the Lord, the God of Israel," horn of salvation, covenant with Abraham, "the prophet of the Most High," "dayspring from on high."

**Modern Equivalent:** Luke 1 is the infancy narrative's first half. The prologue (1:1-4) is unique—Luke writes as historian to Theophilus. The parallel annunciations to Zacharias (1:5-25) and Mary (1:26-38) contrast doubt and faith. John will be Elijah's successor (1:17); Yeshua will be Son of the Most High with David's throne forever (1:32-33). Mary's Magnificat (1:46-55) echoes Hannah's song (1 Samuel 2) and proclaims reversal: proud scattered, princes dethroned, hungry filled, rich emptied. Zacharias's Benedictus (1:67-79) praises God for visiting Israel, raising a horn of salvation, remembering the covenant, and sending the dayspring to illumine those in darkness.

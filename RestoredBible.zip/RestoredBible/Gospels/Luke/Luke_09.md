# Luke 9: Mission, Revelation, and the Journey Begins

*From the Greek: Συγκαλεσάμενος δὲ τοὺς δώδεκα (Synkalesamenos de tous Dōdeka) — And He Called the Twelve Together*

---

## The Mission of the Twelve (9:1-6)

**9:1** And he called the twelve together, and gave them power and authority over all demons, and to cure diseases.

**9:2** And he sent them forth to proclaim the kingdom of God, and to heal the sick.

**9:3** And he said unto them: "Take nothing for your journey, neither staff, nor wallet, nor bread, nor money; neither have two coats.

**9:4** "And into whatsoever house you enter, there abide, and thence depart.

**9:5** "And as many as receive you not, when you depart from that city, shake off the dust from your feet for a testimony against them."

**9:6** And they departed, and went throughout the villages, preaching the good news, and healing everywhere.

---

## Herod's Perplexity (9:7-9)

**9:7** Now Herod the tetrarch heard of all that was done: and he was much perplexed, because that it was said by some, that John was risen from the dead;

**9:8** And by some, that Elijah had appeared; and by others, that one of the old prophets was risen again.

**9:9** And Herod said: "John I beheaded: but who is this, about whom I hear such things?" And he sought to see him.

---

## Feeding the Five Thousand (9:10-17)

**9:10** And the apostles, when they were returned, declared unto him what things they had done. And he took them, and withdrew apart to a city called Bethsaida.

**9:11** But the multitudes perceiving it followed him: and he welcomed them, and spoke to them of the kingdom of God, and them that had need of healing he healed.

**9:12** And the day began to wear away; and the twelve came, and said unto him: "Send the multitude away, that they may go into the villages and country round about, and lodge, and get provisions: for we are here in a desert place."

**9:13** But he said unto them: "Give them to eat." And they said: "We have no more than five loaves and two fishes; except we should go and buy food for all this people."

**9:14** For they were about five thousand men. And he said unto his disciples: "Make them sit down in companies, about fifty each."

**9:15** And they did so, and made them all sit down.

**9:16** And he took the five loaves and the two fishes, and looking up to heaven, he blessed them, and broke; and gave to the disciples to set before the multitude.

**9:17** And they ate, and were all filled: and there was taken up that which remained over to them of broken pieces, twelve baskets.

---

## Peter's Confession (9:18-22)

**9:18** And it came to pass, as he was praying apart, the disciples were with him: and he asked them, saying: "Who do the multitudes say that I am?"

**9:19** And they answering said: "John the Immerser; but others say, Elijah; and others, that one of the old prophets is risen again."

**9:20** And he said unto them: "But who say you that I am?" And Peter answering said: "The Anointed of God."

**9:21** But he charged them, and commanded them to tell this to no man;

**9:22** Saying: "The Son of man must suffer many things, and be rejected of the elders and chief priests and scribes, and be killed, and the third day be raised up."

---

## Taking Up the Cross (9:23-27)

**9:23** And he said unto all: "If any man would come after me, let him deny himself, and take up his cross daily, and follow me.

**9:24** "For whosoever would save his life shall lose it; but whosoever shall lose his life for my sake, the same shall save it.

**9:25** "For what is a man profited, if he gain the whole world, and lose or forfeit his own self?

**9:26** "For whosoever shall be ashamed of me and of my words, of him shall the Son of man be ashamed, when he comes in his own glory, and the glory of the Father, and of the holy angels.

**9:27** "But I tell you of a truth, There are some of them that stand here, who shall in no wise taste of death, till they see the kingdom of God."

---

## The Transfiguration (9:28-36)

**9:28** And it came to pass about eight days after these sayings, that he took with him Peter and John and James, and went up into the mountain to pray.

**9:29** And as he was praying, the fashion of his countenance was altered, and his raiment became white and dazzling.

**9:30** And behold, there talked with him two men, who were Moses and Elijah;

**9:31** Who appeared in glory, and spoke of his departure which he was about to accomplish at Jerusalem.

**9:32** Now Peter and they that were with him were heavy with sleep: but when they were fully awake, they saw his glory, and the two men that stood with him.

**9:33** And it came to pass, as they were parting from him, Peter said unto Yeshua: "Master, it is good for us to be here: and let us make three tabernacles; one for you, and one for Moses, and one for Elijah": not knowing what he said.

**9:34** And while he said these things, there came a cloud, and overshadowed them: and they feared as they entered into the cloud.

**9:35** And a voice came out of the cloud, saying: "This is my Son, my chosen: hear him."

**9:36** And when the voice came, Yeshua was found alone. And they held their peace, and told no man in those days any of the things which they had seen.

---

## Healing the Epileptic Boy (9:37-43a)

**9:37** And it came to pass, on the next day, when they were come down from the mountain, a great multitude met him.

**9:38** And behold, a man from the multitude cried, saying: "Teacher, I beseech you to look upon my son; for he is my only child:

**9:39** "And behold, a spirit takes him, and he suddenly cries out; and it tears him that he foams, and it hardly departs from him, bruising him sorely.

**9:40** "And I besought your disciples to cast it out; and they could not."

**9:41** And Yeshua answered and said: "O faithless and perverse generation, how long shall I be with you, and bear with you? Bring your son here."

**9:42** And as he was yet coming, the demon dashed him down, and tore him grievously. But Yeshua rebuked the unclean spirit, and healed the boy, and gave him back to his father.

**9:43a** And they were all astonished at the majesty of God.

---

## Second Prediction of the Passion (9:43b-45)

**9:43b** But while all were marvelling at all the things which he did, he said unto his disciples:

**9:44** "Let these words sink into your ears: for the Son of man shall be delivered up into the hands of men."

**9:45** But they understood not this saying, and it was concealed from them, that they should not perceive it; and they were afraid to ask him about this saying.

---

## Who Is Greatest? (9:46-48)

**9:46** And there arose a reasoning among them, which of them was the greatest.

**9:47** But when Yeshua saw the reasoning of their heart, he took a little child, and set him by his side,

**9:48** And said unto them: "Whosoever shall receive this little child in my name receives me: and whosoever shall receive me receives him that sent me: for he that is least among you all, the same is great."

---

## The Strange Exorcist (9:49-50)

**9:49** And John answered and said: "Master, we saw one casting out demons in your name; and we forbade him, because he follows not with us."

**9:50** But Yeshua said unto him: "Forbid him not: for he that is not against you is for you."

---

## The Journey to Jerusalem Begins (9:51-56)

**9:51** And it came to pass, when the days were well-nigh come that he should be received up, he steadfastly set his face to go to Jerusalem,

**9:52** And sent messengers before his face: and they went, and entered into a village of the Samaritans, to make ready for him.

**9:53** And they did not receive him, because his face was as though he were going to Jerusalem.

**9:54** And when his disciples James and John saw this, they said: "Lord, will you that we bid fire to come down from heaven, and consume them?"

**9:55** But he turned, and rebuked them.

**9:56** And they went to another village.

---

## The Cost of Following Yeshua (9:57-62)

**9:57** And as they went on the way, a certain man said unto him: "I will follow you wherever you go."

**9:58** And Yeshua said unto him: "The foxes have holes, and the birds of the heaven have nests; but the Son of man has not where to lay his head."

**9:59** And he said unto another: "Follow me." But he said: "Lord, permit me first to go and bury my father."

**9:60** But he said unto him: "Leave the dead to bury their own dead; but go and proclaim the kingdom of God."

**9:61** And another also said: "I will follow you, Lord; but first permit me to bid farewell to them that are at my house."

**9:62** But Yeshua said unto him: "No man, having put his hand to the plow, and looking back, is fit for the kingdom of God."

---

## Synthesis Notes

**Key Restorations:**

**Mission of the Twelve (9:1-6):**
"'He called the twelve together, and gave them power and authority over all demons, and to cure diseases.'"

*Synkalesamenos de tous dōdeka edōken autois dynamin kai exousian epi panta ta daimonia kai nosous therapeuein*—power, authority.

"''Take nothing for your journey.''"

*Mēden airete eis tēn hodon*—nothing.

"''Shake off the dust from your feet for a testimony against them.''"

*Ton koniorton apo tōn podōn hymōn apotinassete eis martyrion ep' autous*—dust.

**Herod's Perplexity (9:7-9):**
"'Herod the tetrarch heard of all that was done: and he was much perplexed.'"

*Ēkousen de Hērōdēs ho tetraarchēs ta ginomena panta kai diēporei*—perplexed.

"''John I beheaded: but who is this?''"

*Iōannēn egō apekephalisa tis de estin houtos*—who?

**Feeding the Five Thousand (9:10-17):**
"''Give them to eat.''"

*Dote autois hymeis phagein*—give.

"'About five thousand men.'"

*Ēsan gar hōsei andres pentakischilioi*—five thousand.

"'He took the five loaves and the two fishes, and looking up to heaven, he blessed them.'"

*Labōn de tous pente artous kai tous dyo ichthyas anablepsas eis ton ouranon eulogēsen autous*—blessed.

"'Twelve baskets.'"

*Kophinoi dōdeka*—twelve baskets.

**Peter's Confession (9:18-22):**
"'As he was praying apart, the disciples were with him.'"

*En tō einai auton proseuchomenon kata monas synēsan autō hoi mathētai*—praying.

**Lukan Theme:**
Yeshua praying at key moments.

"''Who do the multitudes say that I am?''"

*Tina me hoi ochloi legousin einai*—who say?

"''The Anointed of God.''"

*Ton Christon tou theou*—Anointed.

"''The Son of man must suffer many things.''"

*Dei ton huion tou anthrōpou polla pathein*—must suffer.

**Taking Up the Cross (9:23-27):**
"''Let him deny himself, and take up his cross daily, and follow me.''"

*Arnēsasthō heauton kai aratō ton stauron autou kath' hēmeran kai akoloutheitō moi*—daily.

**Only Luke:**
"Daily" added.

"''Whosoever would save his life shall lose it.''"

*Hos gar an thelē tēn psychēn autou sōsai apolesei autēn*—save/lose.

"''What is a man profited, if he gain the whole world, and lose or forfeit his own self?''"

*Ti gar ōpheleitai anthrōpos kerdēsas ton kosmon holon heauton de apolesas ē zēmiōtheis*—forfeit self.

**Transfiguration (9:28-36):**
"'About eight days after these sayings.'"

*Egeneto de meta tous logous toutous hōsei hēmerai oktō*—eight days.

**Luke's Count:**
"About eight days" vs. Mark's "after six days."

"'He took with him Peter and John and James, and went up into the mountain to pray.'"

*Paralabōn Petron kai Iōannēn kai Iakōbon anebē eis to oros proseuxasthai*—to pray.

"'As he was praying, the fashion of his countenance was altered.'"

*Kai egeneto en tō proseuchesthai auton to eidos tou prosōpou autou heteron*—while praying.

"'His raiment became white and dazzling.'"

*Kai ho himatismos autou leukos exastraptōn*—dazzling.

"'Moses and Elijah; who appeared in glory, and spoke of his departure which he was about to accomplish at Jerusalem.'"

*Mōusēs kai Ēlias hoi ophthentes en doxē elegon tēn exodon autou hēn ēmellen plēroun en Hierousalēm*—departure.

**Exodos:**
"Departure/exodus"—Luke's unique term for Yeshua's death.

"''This is my Son, my chosen: hear him.''"

*Houtos estin ho huios mou ho eklelegmenos autou akouete*—chosen.

**Luke's Reading:**
"Chosen" instead of "beloved."

**Healing the Epileptic Boy (9:37-43a):**
"''He is my only child.''"

*Monogenēs moi estin*—only child.

"''O faithless and perverse generation.''"

*Ō genea apistos kai diestrammenē*—faithless.

"'They were all astonished at the majesty of God.'"

*Exeplēssonto de pantes epi tē megaleiotēti tou theou*—majesty.

**Second Passion Prediction (9:43b-45):**
"''Let these words sink into your ears.''"

*Thesthe hymeis eis ta ōta hymōn tous logous toutous*—sink in.

"''The Son of man shall be delivered up into the hands of men.''"

*Ho gar huios tou anthrōpou mellei paradidosthai eis cheiras anthrōpōn*—delivered.

"'It was concealed from them, that they should not perceive it.'"

*Kai ēn parakekalymmenon ap' autōn hina mē aisthōntai auto*—concealed.

**Who Is Greatest? (9:46-48):**
"'He took a little child, and set him by his side.'"

*Epilabomenos paidion estēsen auto par' heautō*—beside him.

"''Whosoever shall receive this little child in my name receives me.''"

*Hos ean dexētai touto to paidion epi tō onomati mou eme dechetai*—receives me.

"''He that is least among you all, the same is great.''"

*Ho gar mikroteros en pasin hymin hyparchōn houtos estin megas*—least is great.

**Strange Exorcist (9:49-50):**
"''He that is not against you is for you.''"

*Hos gar ouk estin kath' hymōn hyper hymōn estin*—for you.

**Journey to Jerusalem Begins (9:51-56):**
"'When the days were well-nigh come that he should be received up.'"

*En tō symplērousthai tas hēmeras tēs analēmpseōs autou*—received up.

**Analēmpsis:**
"Taking up"—refers to ascension.

"'He steadfastly set his face to go to Jerusalem.'"

*Kai autos to prosōpon estērixen tou poreuesthai eis Hierousalēm*—set his face.

**Travel Narrative Begins:**
Luke 9:51-19:27 is the journey to Jerusalem.

"''Lord, will you that we bid fire to come down from heaven, and consume them?''"

*Kyrie theleis eipōmen pyr katabēnai apo tou ouranou kai analōsai autous*—fire.

**2 Kings 1:10 Reference.**

"'He turned, and rebuked them.'"

*Strapheis de epetimēsen autois*—rebuked.

**Cost of Following (9:57-62):**
"''The foxes have holes, and the birds of the heaven have nests; but the Son of man has not where to lay his head.''"

*Hai alōpekes phōleous echousin kai ta peteina tou ouranou kataskēnōseis ho de huios tou anthrōpou ouk echei pou tēn kephalēn klinē*—homeless.

"''Leave the dead to bury their own dead; but go and proclaim the kingdom of God.''"

*Aphes tous nekrous thapsai tous heautōn nekrous sy de apelthōn diaggelle tēn basileian tou theou*—proclaim.

"''No man, having put his hand to the plow, and looking back, is fit for the kingdom of God.''"

*Oudeis epibalōn tēn cheira ep' arotron kai blepōn eis ta opisō euthetos estin tē basileia tou theou*—plow.

**Only Luke:**
This third would-be disciple (9:61-62).

**Archetypal Layer:** Luke 9 contains **mission of the Twelve (9:1-6)**, **Herod's perplexity: "Who is this?" (9:9)**, **feeding the five thousand (9:10-17)**, **Peter's confession while Yeshua prayed (9:18-22)**: "The Anointed of God" (9:20), first passion prediction (9:22), **"take up his cross daily" (9:23)**, **Transfiguration (9:28-36)**: while praying, Moses and Elijah "spoke of his departure (exodos) which he was about to accomplish at Jerusalem" (9:31), **"This is my Son, my chosen: hear him" (9:35)**, **healing the epileptic boy (9:37-43)**, **second passion prediction (9:44-45)**: "concealed from them," **who is greatest: "he that is least... is great" (9:48)**, **strange exorcist: "he that is not against you is for you" (9:50)**, **journey to Jerusalem begins (9:51)**: "he steadfastly set his face to go to Jerusalem," Samaritan rejection (9:52-53), James and John want fire (9:54), rebuked (9:55), and **cost of following (9:57-62)**: foxes have holes, leave dead to bury dead, **"No man, having put his hand to the plow, and looking back, is fit for the kingdom of God" (9:62)**.

**Modern Equivalent:** Luke 9 is a pivotal chapter. Peter's confession (9:20) is followed immediately by the first passion prediction (9:22). Luke adds "daily" to cross-bearing (9:23). The Transfiguration (9:28-36) occurs while praying; Moses and Elijah discuss Yeshua's "exodus" (9:31)—his death/departure in Jerusalem. At 9:51, Luke's Travel Narrative begins: Yeshua "steadfastly set his face to go to Jerusalem." The journey will occupy 9:51-19:27. The cost of discipleship is absolute (9:57-62).

# Luke 11: Teaching on Prayer and Confronting the Pharisees

*From the Greek: Καὶ ἐγένετο ἐν τῷ εἶναι αὐτὸν ἐν τόπῳ τινὶ προσευχόμενον (Kai Egeneto en tō Einai Auton en Topō Tini Proseuchomenon) — And It Came to Pass, As He Was Praying in a Certain Place*

---

## The Lord's Prayer (11:1-4)

**11:1** And it came to pass, as he was praying in a certain place, that when he ceased, one of his disciples said unto him: "Lord, teach us to pray, even as John also taught his disciples."

**11:2** And he said unto them: "When you pray, say:

"Father, Hallowed be your name.
Your kingdom come.

**11:3** "Give us day by day our daily bread.

**11:4** "And forgive us our sins; for we ourselves also forgive every one that is indebted to us.
And bring us not into temptation."

---

## The Friend at Midnight (11:5-8)

**11:5** And he said unto them: "Which of you shall have a friend, and shall go unto him at midnight, and say to him, 'Friend, lend me three loaves;

**11:6** "'For a friend of mine is come to me from a journey, and I have nothing to set before him';

**11:7** "And he from within shall answer and say, 'Trouble me not: the door is now shut, and my children are with me in bed; I cannot rise and give to you'?

**11:8** "I say unto you, Though he will not rise and give him because he is his friend, yet because of his importunity he will arise and give him as many as he needs."

---

## Ask, Seek, Knock (11:9-13)

**11:9** "And I say unto you, Ask, and it shall be given you; seek, and you shall find; knock, and it shall be opened unto you.

**11:10** "For every one that asks receives; and he that seeks finds; and to him that knocks it shall be opened.

**11:11** "And of which of you that is a father shall his son ask a loaf, and he give him a stone? Or a fish, and he for a fish give him a serpent?

**11:12** "Or if he shall ask an egg, will he give him a scorpion?

**11:13** "If you then, being evil, know how to give good gifts unto your children, how much more shall your heavenly Father give the Holy Spirit to them that ask him?"

---

## Yeshua and Beelzebub (11:14-26)

**11:14** And he was casting out a demon that was dumb. And it came to pass, when the demon was gone out, the dumb man spoke; and the multitudes marvelled.

**11:15** But some of them said: "By Beelzebub the prince of the demons casts he out demons."

**11:16** And others, trying him, sought of him a sign from heaven.

**11:17** But he, knowing their thoughts, said unto them: "Every kingdom divided against itself is brought to desolation; and a house divided against a house falls.

**11:18** "And if Satan also is divided against himself, how shall his kingdom stand? Because you say that I cast out demons by Beelzebub.

**11:19** "And if I by Beelzebub cast out demons, by whom do your sons cast them out? Therefore shall they be your judges.

**11:20** "But if I by the finger of God cast out demons, then is the kingdom of God come upon you.

**11:21** "When the strong man fully armed guards his own court, his goods are in peace:

**11:22** "But when a stronger than he shall come upon him, and overcome him, he takes from him his whole armour wherein he trusted, and divides his spoils.

**11:23** "He that is not with me is against me; and he that gathers not with me scatters.

**11:24** "The unclean spirit when he is gone out of the man, passes through waterless places, seeking rest; and finding none, he says, 'I will turn back unto my house whence I came out.'

**11:25** "And when he is come, he finds it swept and garnished.

**11:26** "Then goes he, and takes to him seven other spirits more evil than himself; and they enter in and dwell there: and the last state of that man becomes worse than the first."

---

## True Blessedness (11:27-28)

**11:27** And it came to pass, as he said these things, a certain woman out of the multitude lifted up her voice, and said unto him: "Blessed is the womb that bore you, and the breasts which you did suck."

**11:28** But he said: "Yea rather, blessed are they that hear the word of God, and keep it."

---

## The Sign of Jonah (11:29-32)

**11:29** And when the multitudes were gathering together unto him, he began to say: "This generation is an evil generation: it seeks after a sign; and there shall no sign be given to it but the sign of Jonah.

**11:30** "For even as Jonah became a sign unto the Ninevites, so shall also the Son of man be to this generation.

**11:31** "The queen of the south shall rise up in the judgment with the men of this generation, and shall condemn them: for she came from the ends of the earth to hear the wisdom of Solomon; and behold, a greater than Solomon is here.

**11:32** "The men of Nineveh shall stand up in the judgment with this generation, and shall condemn it: for they repented at the preaching of Jonah; and behold, a greater than Jonah is here."

---

## The Lamp of the Body (11:33-36)

**11:33** "No man, when he has lighted a lamp, puts it in a cellar, neither under the bushel, but on the stand, that they which enter in may see the light.

**11:34** "The lamp of your body is your eye: when your eye is single, your whole body also is full of light; but when it is evil, your body also is full of darkness.

**11:35** "Look therefore whether the light that is in you be not darkness.

**11:36** "If therefore your whole body be full of light, having no part dark, it shall be wholly full of light, as when the lamp with its bright shining gives you light."

---

## Woes to the Pharisees and Lawyers (11:37-54)

**11:37** Now as he spoke, a Pharisee asks him to dine with him: and he went in, and sat down to meat.

**11:38** And when the Pharisee saw it, he marvelled that he had not first washed before dinner.

**11:39** And the Lord said unto him: "Now you Pharisees cleanse the outside of the cup and of the platter; but your inward part is full of extortion and wickedness.

**11:40** "You foolish ones, did not he that made the outside make the inside also?

**11:41** "But give for alms those things which are within; and behold, all things are clean unto you.

**11:42** "But woe unto you Pharisees! For you tithe mint and rue and every herb, and pass over justice and the love of God: but these ought you to have done, and not to leave the other undone.

**11:43** "Woe unto you Pharisees! For you love the chief seats in the synagogues, and the salutations in the marketplaces.

**11:44** "Woe unto you! For you are as the tombs which appear not, and the men that walk over them know it not."

**11:45** And one of the lawyers answering says unto him: "Teacher, in saying this you reproach us also."

**11:46** And he said: "Woe unto you lawyers also! For you load men with burdens grievous to be borne, and you yourselves touch not the burdens with one of your fingers.

**11:47** "Woe unto you! For you build the tombs of the prophets, and your fathers killed them.

**11:48** "So you are witnesses and consent unto the works of your fathers: for they killed them, and you build their tombs.

**11:49** "Therefore also said the wisdom of God, 'I will send unto them prophets and apostles; and some of them they shall kill and persecute';

**11:50** "That the blood of all the prophets, which was shed from the foundation of the world, may be required of this generation;

**11:51** "From the blood of Abel unto the blood of Zachariah, who perished between the altar and the sanctuary: yea, I say unto you, it shall be required of this generation.

**11:52** "Woe unto you lawyers! For you took away the key of knowledge: you entered not in yourselves, and them that were entering in you hindered."

**11:53** And when he was come out from thence, the scribes and the Pharisees began to press upon him vehemently, and to provoke him to speak of many things;

**11:54** Laying wait for him, to catch something out of his mouth.

---

## Synthesis Notes

**Key Restorations:**

**The Lord's Prayer (11:1-4):**
"'As he was praying in a certain place.'"

*En tō einai auton en topō tini proseuchomenon*—praying.

"''Lord, teach us to pray, even as John also taught his disciples.''"

*Kyrie didaxon hēmas proseuchesthai kathōs kai Iōannēs edidaxen tous mathētas autou*—teach.

"''Father, Hallowed be your name.''"

*Pater hagiasthētō to onoma sou*—Father.

**Luke's Shorter Version.**

"''Your kingdom come.''"

*Elthetō hē basileia sou*—kingdom.

"''Give us day by day our daily bread.''"

*Ton arton hēmōn ton epiousion didou hēmin to kath' hēmeran*—daily.

"''Forgive us our sins; for we ourselves also forgive every one that is indebted to us.''"

*Kai aphes hēmin tas hamartias hēmōn kai gar autoi aphiomen panti opheilonti hēmin*—forgive.

"''Bring us not into temptation.''"

*Kai mē eisenenكēs hēmas eis peirasmon*—temptation.

**Friend at Midnight (11:5-8):**
"''Which of you shall have a friend, and shall go unto him at midnight.''"

*Tis ex hymōn hexei philon kai poreusetai pros auton mesonyktiou*—midnight.

**Only Luke:**
This parable unique to Luke.

"''Because of his importunity he will arise and give him as many as he needs.''"

*Dia ge tēn anaideian autou egertheis dōsei autō hosōn chrēzei*—importunity.

**Anaideia:**
"Shameless persistence."

**Ask, Seek, Knock (11:9-13):**
"''Ask, and it shall be given you; seek, and you shall find; knock, and it shall be opened unto you.''"

*Kagō hymin legō aiteite kai dothēsetai hymin zēteite kai heurēsete krouete kai anoigēsetai hymin*—ask, seek, knock.

"''If he shall ask an egg, will he give him a scorpion?''"

*Ē kai aitēsei ōon epidōsei autō skorpion*—egg, scorpion.

**Only Luke:**
Egg/scorpion example.

"''How much more shall your heavenly Father give the Holy Spirit to them that ask him?''"

*Posō mallon ho patēr ho ex ouranou dōsei pneuma hagion tois aitousin auton*—Holy Spirit.

**Luke's Emphasis:**
"Holy Spirit" instead of "good things."

**Yeshua and Beelzebub (11:14-26):**
"''By Beelzebub the prince of the demons casts he out demons.''"

*En Beelzeboul tō archonti tōn daimoniōn ekballei ta daimonia*—Beelzebub.

"''Every kingdom divided against itself is brought to desolation.''"

*Pasa basileia eph' heautēn diameristheisa erēmoutai*—divided.

"''If I by the finger of God cast out demons, then is the kingdom of God come upon you.''"

*Ei de en daktylō theou ekballō ta daimonia ara ephthasen eph' hymas hē basileia tou theou*—finger of God.

**Finger of God:**
Exodus 8:19—Luke's phrase (Matthew has "Spirit of God").

"''When the strong man fully armed guards his own court.''"

*Hotan ho ischyros kathōplismenos phylassē tēn heautou aulēn*—strong man.

"''When a stronger than he shall come upon him, and overcome him.''"

*Epan de ischyroteros autou epelthōn nikēsē auton*—stronger.

"''He that is not with me is against me.''"

*Ho mē ōn met' emou kat' emou estin*—with or against.

**True Blessedness (11:27-28):**
"''Blessed is the womb that bore you, and the breasts which you did suck.''"

*Makaria hē koilia hē bastasasa se kai mastoi hous ethēlasas*—blessed womb.

**Only Luke:**
This exchange unique to Luke.

"''Yea rather, blessed are they that hear the word of God, and keep it.''"

*Menoun makarioi hoi akouontes ton logon tou theou kai phylassontes*—hear and keep.

**Sign of Jonah (11:29-32):**
"''There shall no sign be given to it but the sign of Jonah.''"

*Sēmeion ou dothēsetai autē ei mē to sēmeion Iōna*—Jonah.

"''As Jonah became a sign unto the Ninevites, so shall also the Son of man be.''"

*Kathōs gar egeneto Iōnas tois Nineuitais sēmeion houtōs estai kai ho huios tou anthrōpou tē genea tautē*—sign.

"''A greater than Solomon is here... a greater than Jonah is here.''"

*Pleion Solomōnos hōde... pleion Iōna hōde*—greater.

**Lamp of the Body (11:33-36):**
"''The lamp of your body is your eye: when your eye is single, your whole body also is full of light.''"

*Ho lychnos tou sōmatos estin ho ophthalmos sou hotan ho ophthalmos sou haplous ē kai holon to sōma sou phōteinon estin*—single eye.

"''Look therefore whether the light that is in you be not darkness.''"

*Skopei oun mē to phōs to en soi skotos estin*—light/darkness.

**Woes to Pharisees and Lawyers (11:37-54):**
"'He had not first washed before dinner.'"

*Ou prōton ebaptisthē pro tou aristou*—no washing.

"''You Pharisees cleanse the outside of the cup and of the platter; but your inward part is full of extortion.''"

*Nyn hymeis hoi Pharisaioi to exōthen tou potēriou kai tou pinakos katharizete to de esōthen hymōn gemei harpagēs kai ponērias*—outside/inside.

"''Give for alms those things which are within; and behold, all things are clean unto you.''"

*Plēn ta enonta dote eleēmosynēn kai idou panta kathara hymin estin*—alms.

"''You tithe mint and rue and every herb, and pass over justice and the love of God.''"

*Apodekatoute to hēdyosmon kai to pēganon kai pan lachanon kai parerchesthe tēn krisin kai tēn agapēn tou theou*—tithe herbs.

"''You are as the tombs which appear not.''"

*Este hōs ta mnēmeia ta adēla*—hidden tombs.

"''You load men with burdens grievous to be borne.''"

*Phortizete tous anthrōpous phortia dysbastaकta*—burdens.

"''You build the tombs of the prophets, and your fathers killed them.''"

*Oikodomeite ta mnēmeia tōn prophētōn hoi de pateres hymōn apekteinan autous*—tombs.

"''The wisdom of God said, I will send unto them prophets and apostles.''"

*Dia touto kai hē sophia tou theou eipen apostelō eis autous prophētas kai apostolous*—wisdom of God.

"''From the blood of Abel unto the blood of Zachariah.''"

*Apo haimatos Abel heōs haimatos Zachariou*—Abel to Zechariah.

"''You took away the key of knowledge.''"

*Ērate tēn kleida tēs gnōseōs*—key of knowledge.

**Archetypal Layer:** Luke 11 contains **the Lord's Prayer (11:1-4)** (Luke's shorter version): "Father," kingdom come, daily bread, forgive sins, not into temptation, **the friend at midnight (11:5-8)** (unique to Luke): importunity, **ask, seek, knock (11:9-13)**: **"how much more shall your heavenly Father give the Holy Spirit" (11:13)**, **Yeshua and Beelzebub (11:14-26)**: **"if I by the finger of God cast out demons" (11:20)**, strong man and stronger (11:21-22), "He that is not with me is against me" (11:23), returning unclean spirit (11:24-26), **true blessedness: "blessed are they that hear the word of God, and keep it" (11:28)**, **sign of Jonah (11:29-32)**: "a greater than Solomon... a greater than Jonah is here," **lamp of the body (11:33-36)**, and **woes to Pharisees and lawyers (11:37-54)**: outside/inside, tithe herbs but pass over justice, hidden tombs, burdens, build prophets' tombs, **"the wisdom of God said" (11:49)**, Abel to Zechariah, **"you took away the key of knowledge" (11:52)**.

**Modern Equivalent:** Luke 11 focuses on prayer. The Lord's Prayer (11:2-4) is Luke's shorter version. The friend at midnight (11:5-8) teaches persistent prayer. The promise culminates: the Father gives the Holy Spirit (11:13). The Beelzebub controversy (11:14-23) uses "finger of God" (Exodus 8:19). True blessedness is hearing and keeping God's word (11:28). The woes (11:37-52) address both Pharisees and lawyers—hypocrisy, burden-making, prophet-killing, and taking away the key of knowledge.

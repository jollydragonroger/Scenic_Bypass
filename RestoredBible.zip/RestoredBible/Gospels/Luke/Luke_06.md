# Luke 6: Sabbath Controversies and the Sermon on the Plain

*From the Greek: Ἐγένετο δὲ ἐν σαββάτῳ (Egeneto de en Sabbatō) — Now It Came to Pass on a Sabbath*

---

## Lord of the Sabbath (6:1-5)

**6:1** Now it came to pass on a sabbath, that he was going through the grain fields; and his disciples plucked the ears, and ate, rubbing them in their hands.

**6:2** But certain of the Pharisees said: "Why do you that which it is not lawful to do on the sabbath day?"

**6:3** And Yeshua answering them said: "Have you not read even this, what David did, when he was hungry, he, and they that were with him;

**6:4** "How he entered into the house of God, and took and ate the showbread, and gave also to them that were with him; which it is not lawful to eat save for the priests alone?"

**6:5** And he said unto them: "The Son of man is lord of the sabbath."

---

## Healing on the Sabbath (6:6-11)

**6:6** And it came to pass on another sabbath, that he entered into the synagogue and taught: and there was a man there, and his right hand was withered.

**6:7** And the scribes and the Pharisees watched him, whether he would heal on the sabbath; that they might find how to accuse him.

**6:8** But he knew their thoughts; and he said to the man that had his hand withered: "Rise up, and stand forth in the midst." And he arose and stood forth.

**6:9** And Yeshua said unto them: "I ask you, Is it lawful on the sabbath to do good, or to do harm? To save a life, or to destroy it?"

**6:10** And he looked round about on them all, and said unto him: "Stretch forth your hand." And he did so: and his hand was restored.

**6:11** But they were filled with madness; and communed one with another what they might do to Yeshua.

---

## Choosing the Twelve (6:12-16)

**6:12** And it came to pass in these days, that he went out into the mountain to pray; and he continued all night in prayer to God.

**6:13** And when it was day, he called his disciples; and he chose from them twelve, whom also he named apostles:

**6:14** Simon, whom he also named Peter, and Andrew his brother, and James and John, and Philip and Bartholomew,

**6:15** And Matthew and Thomas, and James the son of Alphaeus, and Simon who was called the Zealot,

**6:16** And Judas the son of James, and Judas Iscariot, who became a traitor.

---

## The Sermon on the Plain: Beatitudes and Woes (6:17-26)

**6:17** And he came down with them, and stood on a level place, and a great multitude of his disciples, and a great number of the people from all Judaea and Jerusalem, and the sea coast of Tyre and Sidon, who came to hear him, and to be healed of their diseases;

**6:18** And they that were troubled with unclean spirits were healed.

**6:19** And all the multitude sought to touch him; for power came forth from him, and healed them all.

**6:20** And he lifted up his eyes on his disciples, and said:

"Blessed are you poor: for yours is the kingdom of God.

**6:21** "Blessed are you that hunger now: for you shall be filled.
"Blessed are you that weep now: for you shall laugh.

**6:22** "Blessed are you, when men shall hate you, and when they shall separate you from their company, and reproach you, and cast out your name as evil, for the Son of man's sake.

**6:23** "Rejoice in that day, and leap for joy: for behold, your reward is great in heaven; for in the same manner did their fathers unto the prophets.

**6:24** "But woe unto you that are rich! For you have received your consolation.

**6:25** "Woe unto you, you that are full now! For you shall hunger.
"Woe unto you, you that laugh now! For you shall mourn and weep.

**6:26** "Woe unto you, when all men shall speak well of you! For in the same manner did their fathers to the false prophets."

---

## Love for Enemies (6:27-36)

**6:27** "But I say unto you that hear, Love your enemies, do good to them that hate you,

**6:28** "Bless them that curse you, pray for them that despitefully use you.

**6:29** "To him that smites you on the one cheek offer also the other; and from him that takes away your cloak withhold not your coat also.

**6:30** "Give to every one that asks you; and of him that takes away your goods ask them not again.

**6:31** "And as you would that men should do to you, do also to them likewise.

**6:32** "And if you love them that love you, what thank have you? For even sinners love those that love them.

**6:33** "And if you do good to them that do good to you, what thank have you? For even sinners do the same.

**6:34** "And if you lend to them of whom you hope to receive, what thank have you? Even sinners lend to sinners, to receive again as much.

**6:35** "But love your enemies, and do good, and lend, never despairing; and your reward shall be great, and you shall be sons of the Most High: for he is kind toward the unthankful and evil.

**6:36** "Be merciful, even as your Father is merciful."

---

## Judging Others (6:37-42)

**6:37** "And judge not, and you shall not be judged: and condemn not, and you shall not be condemned: release, and you shall be released:

**6:38** "Give, and it shall be given unto you; good measure, pressed down, shaken together, running over, shall they give into your bosom. For with what measure you mete it shall be measured to you again."

**6:39** And he spoke also a parable unto them: "Can the blind guide the blind? Shall they not both fall into a pit?

**6:40** "The disciple is not above his teacher: but every one when he is perfected shall be as his teacher.

**6:41** "And why do you behold the mote that is in your brother's eye, but consider not the beam that is in your own eye?

**6:42** "Or how can you say to your brother, 'Brother, let me cast out the mote that is in your eye,' when you yourself do not behold the beam that is in your own eye? You hypocrite, cast out first the beam out of your own eye, and then shall you see clearly to cast out the mote that is in your brother's eye."

---

## A Tree and Its Fruit (6:43-45)

**6:43** "For there is no good tree that brings forth corrupt fruit; nor again a corrupt tree that brings forth good fruit.

**6:44** "For each tree is known by its own fruit. For of thorns men do not gather figs, nor of a bramble bush gather they grapes.

**6:45** "The good man out of the good treasure of his heart brings forth that which is good; and the evil man out of the evil treasure brings forth that which is evil: for out of the abundance of the heart his mouth speaks."

---

## Building on the Rock (6:46-49)

**6:46** "And why call you me, 'Lord, Lord,' and do not the things which I say?

**6:47** "Every one that comes to me, and hears my words, and does them, I will show you to whom he is like:

**6:48** "He is like a man building a house, who dug and went deep, and laid a foundation upon the rock: and when a flood arose, the stream broke against that house, and could not shake it: because it had been well built.

**6:49** "But he that hears, and does not, is like a man that built a house upon the earth without a foundation; against which the stream broke, and straightway it fell in; and the ruin of that house was great."

---

## Synthesis Notes

**Key Restorations:**

**Lord of the Sabbath (6:1-5):**
"'On a sabbath... his disciples plucked the ears, and ate, rubbing them in their hands.'"

*En sabbatō... etillon hoi mathētai autou kai ēsthion tous stachyas psōchontes tais chersin*—rubbing.

"''Why do you that which it is not lawful to do on the sabbath day?''"

*Ti poieite ho ouk exestin tois sabbasin*—not lawful.

"''Have you not read even this, what David did?''"

*Oude touto anegnōte ho epoiēsen David*—David.

**1 Samuel 21:1-6.**

"''The Son of man is lord of the sabbath.''"

*Kyrios estin tou sabbatou ho huios tou anthrōpou*—lord.

**Healing on the Sabbath (6:6-11):**
"'There was a man there, and his right hand was withered.'"

*Kai ēn anthrōpos ekei kai hē cheir autou hē dexia ēn xēra*—right hand.

**Only Luke:**
Specifies "right" hand.

"'The scribes and the Pharisees watched him.'"

*Paretērounto de auton hoi grammateis kai hoi Pharisaioi*—watched.

"''I ask you, Is it lawful on the sabbath to do good, or to do harm? To save a life, or to destroy it?''"

*Eperōtō hymas ei exestin tō sabbatō agathopoiēsai ē kakopoiēsai psychēn sōsai ē apolesai*—good or harm.

"'They were filled with madness.'"

*Autoi de eplēsthēsan anoias*—madness.

**Choosing the Twelve (6:12-16):**
"'He went out into the mountain to pray; and he continued all night in prayer to God.'"

*Exēlthen eis to oros proseuxasthai kai ēn dianyktereúōn en tē proseuchē tou theou*—all night.

**Only Luke:**
All-night prayer before choosing.

"'He chose from them twelve, whom also he named apostles.'"

*Kai exelexamenos ap' autōn dōdeka hous kai apostolous ōnomasen*—apostles.

**Beatitudes and Woes (6:17-26):**
"'He came down with them, and stood on a level place.'"

*Kai katabas met' autōn estē epi topou pedinou*—level place.

**Sermon on the Plain:**
Luke's version differs from Matthew's Sermon on the Mount.

"''Blessed are you poor: for yours is the kingdom of God.''"

*Makarioi hoi ptōchoi hoti hymetera estin hē basileia tou theou*—poor.

**Direct Address:**
"You poor" rather than "the poor in spirit."

"''Blessed are you that hunger now.''"

*Makarioi hoi peinōntes nyn*—hunger now.

"''Blessed are you that weep now.''"

*Makarioi hoi klaiontes nyn*—weep now.

"''Blessed are you, when men shall hate you.''"

*Makarioi este hotan misēsōsin hymas hoi anthrōpoi*—hated.

"''Rejoice in that day, and leap for joy.''"

*Charēte en ekeinē tē hēmera kai skirtēsate*—leap.

"''Woe unto you that are rich!''"

*Plēn ouai hymin tois plousiois*—woe rich.

**Only Luke:**
Four woes corresponding to four beatitudes.

"''Woe unto you, you that are full now!''"

*Ouai hymin hoi empeplēsmenoi nyn*—full.

"''Woe unto you, you that laugh now!''"

*Ouai hoi gelōntes nyn*—laugh.

"''Woe unto you, when all men shall speak well of you!''"

*Ouai hotan hymas kalōs eipōsin pantes hoi anthrōpoi*—well spoken of.

**Love for Enemies (6:27-36):**
"''Love your enemies, do good to them that hate you.''"

*Agapate tous echthrous hymōn kalōs poieite tois misousin hymas*—love enemies.

"''Bless them that curse you, pray for them that despitefully use you.''"

*Eulogeite tous katarōmenous hymas proseuchesthe peri tōn epēreazontōn hymas*—bless, pray.

"''To him that smites you on the one cheek offer also the other.''"

*Tō typtoni se epi tēn siagona pareche kai tēn allēn*—other cheek.

"''As you would that men should do to you, do also to them likewise.''"

*Kai kathōs thelete hina poiōsin hymin hoi anthrōpoi poieite autois homoiōs*—Golden Rule.

"''Even sinners love those that love them.''"

*Kai gar hoi hamartōloi tous agapōntas autous agapōsin*—sinners.

"''Your reward shall be great, and you shall be sons of the Most High.''"

*Kai estai ho misthos hymōn polys kai esesthe huioi hypsistou*—sons.

"''For he is kind toward the unthankful and evil.''"

*Hoti autos chrēstos estin epi tous acharistous kai ponērous*—kind.

"''Be merciful, even as your Father is merciful.''"

*Ginesthe oiktirmones kathōs ho patēr hymōn oiktirmōn estin*—merciful.

**Luke's Emphasis:**
"Merciful" rather than Matthew's "perfect."

**Judging Others (6:37-42):**
"''Judge not, and you shall not be judged.''"

*Kai mē krinete kai ou mē krithēte*—don't judge.

"''Condemn not, and you shall not be condemned.''"

*Kai mē katadikazete kai ou mē katadikasthēte*—don't condemn.

"''Release, and you shall be released.''"

*Apolyete kai apolythēsesthe*—release.

"''Give, and it shall be given unto you; good measure, pressed down, shaken together, running over.''"

*Didote kai dothēsetai hymin metron kalon pepiesmenon sesaleumenon hyperekchynnomenon*—overflowing.

"''With what measure you mete it shall be measured to you again.''"

*Hō gar metrō metreite antimetrēthēsetai hymin*—measure.

"''Can the blind guide the blind?''"

*Mēti dynatai typhlos typhlon hodēgein*—blind.

"''Why do you behold the mote that is in your brother's eye?''"

*Ti de blepeis to karphos to en tō ophthalmō tou adelphou sou*—mote.

**Tree and Its Fruit (6:43-45):**
"''Each tree is known by its own fruit.''"

*Hekaston gar dendron ek tou idiou karpou ginōsketai*—known by fruit.

"''Out of the abundance of the heart his mouth speaks.''"

*Ek gar perissevmatos kardias lalei to stoma autou*—heart speaks.

**Building on the Rock (6:46-49):**
"''Why call you me, Lord, Lord, and do not the things which I say?''"

*Ti de me kaleite kyrie kyrie kai ou poieite ha legō*—Lord, Lord.

"'He is like a man building a house, who dug and went deep, and laid a foundation upon the rock.'"

*Homoios estin anthrōpō oikodomounti oikian hos eskapsen kai ebathynen kai ethēken themelion epi tēn petran*—foundation.

"''And the ruin of that house was great.''"

*Kai egeneto to rhēgma tēs oikias ekeinēs mega*—great ruin.

**Archetypal Layer:** Luke 6 contains **Lord of the sabbath (6:1-5)**, **healing the withered right hand on sabbath (6:6-11)**: "Is it lawful on the sabbath to do good, or to do harm?" (6:9), "they were filled with madness" (6:11), **choosing the Twelve after all-night prayer (6:12-16)**, **Sermon on the Plain (6:17-49)**: "stood on a level place" (6:17), **four beatitudes (6:20-23)**: "Blessed are you poor," "you that hunger now," "you that weep now," "when men shall hate you," **four woes (6:24-26)**: "Woe unto you that are rich," "that are full," "that laugh now," "when all men shall speak well of you," **love for enemies (6:27-36)**: "do good to them that hate you," "bless them that curse you," "offer also the other cheek," **Golden Rule (6:31)**, "you shall be sons of the Most High" (6:35), **"Be merciful, even as your Father is merciful" (6:36)**, **judging others (6:37-42)**: "good measure, pressed down, shaken together, running over" (6:38), blind guides, mote and beam, **tree and fruit (6:43-45)**: "out of the abundance of the heart his mouth speaks" (6:45), and **building on the rock (6:46-49)**.

**Modern Equivalent:** Luke 6 contains the Sermon on the Plain—Luke's parallel to Matthew's Sermon on the Mount. Luke's beatitudes are direct ("you poor") and paired with woes (6:24-26). The ethic of enemy-love (6:27-36) is radical. Luke's distinctive: "Be merciful, even as your Father is merciful" (6:36). Generosity brings overflowing return (6:38). The sermon concludes with the contrast between hearing and doing—foundation on rock versus sand (6:46-49).

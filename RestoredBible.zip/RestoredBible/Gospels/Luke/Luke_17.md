# Luke 17: Faith, Gratitude, and the Coming Kingdom

*From the Greek: Εἶπεν δὲ πρὸς τοὺς μαθητὰς αὐτοῦ (Eipen de pros tous Mathētas Autou) — And He Said unto His Disciples*

---

## Warnings and Faith (17:1-6)

**17:1** And he said unto his disciples: "It is impossible but that occasions of stumbling should come; but woe unto him, through whom they come!

**17:2** "It were well for him if a millstone were hanged about his neck, and he were thrown into the sea, rather than that he should cause one of these little ones to stumble.

**17:3** "Take heed to yourselves: if your brother sin, rebuke him; and if he repent, forgive him.

**17:4** "And if he sin against you seven times in the day, and seven times turn again to you, saying, 'I repent'; you shall forgive him."

**17:5** And the apostles said unto the Lord: "Increase our faith."

**17:6** And the Lord said: "If you had faith as a grain of mustard seed, you would say unto this sycamine tree, 'Be rooted up, and be planted in the sea'; and it would obey you."

---

## Unworthy Servants (17:7-10)

**17:7** "But who is there of you, having a servant plowing or keeping sheep, that will say unto him, when he is come in from the field, 'Come straightway and sit down to meat';

**17:8** "And will not rather say unto him, 'Make ready wherewith I may sup, and gird yourself, and serve me, till I have eaten and drunken; and afterward you shall eat and drink'?

**17:9** "Does he thank the servant because he did the things that were commanded?

**17:10** "Even so you also, when you shall have done all the things that are commanded you, say, 'We are unprofitable servants; we have done that which it was our duty to do.'"

---

## The Ten Lepers (17:11-19)

**17:11** And it came to pass, as they were on the way to Jerusalem, that he was passing along the borders of Samaria and Galilee.

**17:12** And as he entered into a certain village, there met him ten men that were lepers, who stood afar off:

**17:13** And they lifted up their voices, saying: "Yeshua, Master, have mercy on us."

**17:14** And when he saw them, he said unto them: "Go and show yourselves unto the priests." And it came to pass, as they went, they were cleansed.

**17:15** And one of them, when he saw that he was healed, turned back, with a loud voice glorifying God;

**17:16** And he fell upon his face at his feet, giving him thanks: and he was a Samaritan.

**17:17** And Yeshua answering said: "Were not the ten cleansed? But where are the nine?

**17:18** "Were there none found that returned to give glory to God, save this stranger?"

**17:19** And he said unto him: "Arise, and go your way: your faith has made you whole."

---

## The Coming of the Kingdom (17:20-37)

**17:20** And being asked by the Pharisees, when the kingdom of God comes, he answered them and said: "The kingdom of God comes not with observation:

**17:21** "Neither shall they say, 'Lo, here!' or, 'There!' for lo, the kingdom of God is within you."

**17:22** And he said unto the disciples: "The days will come, when you shall desire to see one of the days of the Son of man, and you shall not see it.

**17:23** "And they shall say to you, 'Lo, there!' 'Lo, here!' Go not away, nor follow after them:

**17:24** "For as the lightning, when it flashes out of the one part under the heaven, shines unto the other part under heaven; so shall the Son of man be in his day.

**17:25** "But first must he suffer many things and be rejected of this generation.

**17:26** "And as it came to pass in the days of Noah, even so shall it be also in the days of the Son of man.

**17:27** "They ate, they drank, they married, they were given in marriage, until the day that Noah entered into the ark, and the flood came, and destroyed them all.

**17:28** "Likewise even as it came to pass in the days of Lot; they ate, they drank, they bought, they sold, they planted, they built;

**17:29** "But in the day that Lot went out from Sodom, it rained fire and brimstone from heaven, and destroyed them all:

**17:30** "After the same manner shall it be in the day that the Son of man is revealed.

**17:31** "In that day, he that shall be on the housetop, and his goods in the house, let him not go down to take them away: and let him that is in the field likewise not return back.

**17:32** "Remember Lot's wife.

**17:33** "Whosoever shall seek to gain his life shall lose it: but whosoever shall lose his life shall preserve it.

**17:34** "I say unto you, In that night there shall be two men on one bed; the one shall be taken, and the other shall be left.

**17:35** "There shall be two women grinding together; the one shall be taken, and the other shall be left."

**17:36** [Two men shall be in the field; the one shall be taken, and the other shall be left.]

**17:37** And they answering say unto him: "Where, Lord?" And he said unto them: "Where the body is, there will the eagles also be gathered together."

---

## Synthesis Notes

**Key Restorations:**

**Warnings and Faith (17:1-6):**
"''It is impossible but that occasions of stumbling should come.''"

*Anendekton estin tou ta skandala mē elthein*—impossible.

"''Woe unto him, through whom they come!''"

*Plēn ouai di' hou erchetai*—woe.

"''It were well for him if a millstone were hanged about his neck.''"

*Lysitelei autō ei lithos mylikos perikeitai peri ton trachēlon autou*—millstone.

"''If your brother sin, rebuke him; and if he repent, forgive him.''"

*Ean hamartē ho adelphos sou epitimēson autō kai ean metanoēsē aphes autō*—rebuke, forgive.

"''If he sin against you seven times in the day, and seven times turn again to you, saying, I repent; you shall forgive him.''"

*Kai ean heptakis tēs hēmeras hamartēsē eis se kai heptakis epistrepsē pros se legōn metanoō aphēseis autō*—seven times.

"''Increase our faith.''"

*Prosthes hēmin pistin*—increase.

"''If you had faith as a grain of mustard seed.''"

*Ei echete pistin hōs kokkon sinapeōs*—mustard seed.

"''You would say unto this sycamine tree, Be rooted up, and be planted in the sea.''"

*Elegete an tē sykaminō tautē ekrizōthēti kai phyteutēti en tē thalassē*—sycamine.

**Unworthy Servants (17:7-10):**
"''Who is there of you, having a servant plowing or keeping sheep.''"

*Tis de ex hymōn doulon echōn arotriōnta ē poimainonta*—servant.

**Only Luke:**
This parable unique to Luke.

"''Make ready wherewith I may sup, and gird yourself, and serve me.''"

*Hetoimason ti deipnēsō kai perizōsamenos diakonei moi*—serve.

"''Does he thank the servant because he did the things that were commanded?''"

*Mē echei charin tō doulō hoti epoiēsen ta diatachthenta*—no thanks.

"''We are unprofitable servants; we have done that which it was our duty to do.''"

*Douloi achreioi esmen ho ōpheilomen poiēsai pepoiēkamen*—unprofitable.

**Ten Lepers (17:11-19):**
"'He was passing along the borders of Samaria and Galilee.'"

*Kai autos diērcheto dia meson Samareias kai Galilaias*—border.

**Only Luke:**
This story unique to Luke.

"'Ten men that were lepers, who stood afar off.'"

*Apēntēsan autō deka leproi andres hoi estēsan porrōthen*—ten lepers.

"''Yeshua, Master, have mercy on us.''"

*Iēsou epistata eleēson hēmas*—mercy.

"''Go and show yourselves unto the priests.''"

*Poreuthentes epideixate heautous tois hiereusin*—priests.

"'As they went, they were cleansed.'"

*Kai egeneto en tō hypagein autous ekatharisthēsan*—cleansed going.

"'One of them, when he saw that he was healed, turned back, with a loud voice glorifying God.'"

*Heis de ex autōn idōn hoti iathē hypestrepsen meta phōnēs megalēs doxazōn ton theon*—turned back.

"'He fell upon his face at his feet, giving him thanks: and he was a Samaritan.'"

*Kai epesen epi prosōpon para tous podas autou eucharistōn autō kai autos ēn Samaritēs*—Samaritan.

"''Were not the ten cleansed? But where are the nine?''"

*Ouch hoi deka ekatharisthēsan hoi de ennea pou*—where are nine?

"''Were there none found that returned to give glory to God, save this stranger?''"

*Ouch heurethēsan hypostrepsantes dounai doxan tō theō ei mē ho allogenes houtos*—stranger.

**Allogenes:**
"Foreigner/stranger"—the Samaritan.

"''Your faith has made you whole.''"

*Hē pistis sou sesōken se*—faith saves.

**Coming of the Kingdom (17:20-37):**
"''The kingdom of God comes not with observation.''"

*Ouk erchetai hē basileia tou theou meta paratērēseōs*—not observation.

"''Neither shall they say, Lo, here! or, There!''"

*Oude erousin idou hōde ē ekei*—not here or there.

"''The kingdom of God is within you.''"

*Idou gar hē basileia tou theou entos hymōn estin*—within/among.

**Entos Hymōn:**
"Within you" or "among you/in your midst."

"''The days will come, when you shall desire to see one of the days of the Son of man.''"

*Eleusontai hēmerai hote epithymēsete mian tōn hēmerōn tou huiou tou anthrōpou idein*—desire.

"''Go not away, nor follow after them.''"

*Mē apelthēte mēde diōxēte*—don't follow.

"''For as the lightning, when it flashes out of the one part under the heaven, shines unto the other part under heaven.''"

*Hōsper gar hē astrapē astraptousa ek tēs hypo ton ouranon eis tēn hyp' ouranon lampei*—lightning.

"''First must he suffer many things and be rejected of this generation.''"

*Prōton de dei auton polla pathein kai apodokimasthēnai apo tēs geneas tautēs*—suffer first.

"''As it came to pass in the days of Noah.''"

*Kai kathōs egeneto en tais hēmerais Nōe*—Noah.

"''They ate, they drank, they married, they were given in marriage, until the day that Noah entered into the ark.''"

*Ēsthion epinon egamoun egamizonto achri hēs hēmeras eisēlthen Nōe eis tēn kibōton*—eating, drinking.

"''Likewise even as it came to pass in the days of Lot.''"

*Homoiōs kathōs egeneto en tais hēmerais Lōt*—Lot.

**Only Luke:**
Lot example unique to Luke.

"''In the day that Lot went out from Sodom, it rained fire and brimstone from heaven.''"

*Hē de hēmera exēlthen Lōt apo Sodomōn ebrexen pyr kai theion ap' ouranou*—fire.

"''Remember Lot's wife.''"

*Mnēmoneuete tēs gynaikos Lōt*—Lot's wife.

**Only Luke:**
This saying unique to Luke.

"''Whosoever shall seek to gain his life shall lose it: but whosoever shall lose his life shall preserve it.''"

*Hos ean zētēsē tēn psychēn autou peripoiēsasthai apolesei autēn kai hos ean apolesē zōogonēsei autēn*—lose/preserve.

"''In that night there shall be two men on one bed; the one shall be taken, and the other shall be left.''"

*Tautē tē nykti esontai dyo epi klinēs mias ho heis paralēmphthēsetai kai ho heteros aphethēsetai*—taken, left.

"''Where the body is, there will the eagles also be gathered together.''"

*Hopou to sōma ekei kai hoi aetoi episynachthēsontai*—eagles.

**Archetypal Layer:** Luke 17 contains **warnings about stumbling (17:1-2)**, **rebuke and forgive (17:3-4)**: seven times a day, **"Increase our faith" (17:5)**, **faith as mustard seed (17:6)**, **unworthy servants (17:7-10)** (unique to Luke): **"We are unprofitable servants; we have done that which it was our duty to do" (17:10)**, **the ten lepers (17:11-19)** (unique to Luke): ten cleansed, one returns, **"he was a Samaritan" (17:16)**, "Were not the ten cleansed? But where are the nine?" (17:17), **"Were there none found... save this stranger?" (17:18)**, "Your faith has made you whole" (17:19), **the coming of the kingdom (17:20-37)**: **"The kingdom of God comes not with observation" (17:20)**, **"the kingdom of God is within you" (17:21)**, lightning (17:24), **"first must he suffer many things" (17:25)**, days of Noah (17:26-27), **days of Lot (17:28-30)** (unique to Luke), **"Remember Lot's wife" (17:32)** (unique to Luke), two on one bed (17:34), two grinding (17:35), "Where the body is, there will the eagles also be gathered together" (17:37).

**Modern Equivalent:** Luke 17 addresses faith, gratitude, and eschatology. The ten lepers (17:11-19), unique to Luke, contrasts nine ungrateful Jews with one grateful Samaritan. "The kingdom of God is within you" (17:21) challenges observable expectations. The coming of the Son of man will be sudden (like lightning), after suffering and rejection. Luke uniquely includes the Lot example (17:28-30) and "Remember Lot's wife" (17:32)—a warning against looking back. The chapter emphasizes readiness and not clinging to possessions or life.

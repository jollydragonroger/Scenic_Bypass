# Luke 2: The Birth, Shepherds, and Temple Presentation

*From the Greek: Ἐγένετο δὲ ἐν ταῖς ἡμέραις ἐκείναις (Egeneto de en tais Hēmerais Ekeinais) — Now It Came to Pass in Those Days*

---

## The Birth of Yeshua (2:1-7)

**2:1** Now it came to pass in those days, there went out a decree from Caesar Augustus, that all the world should be enrolled.

**2:2** This was the first enrollment made when Quirinius was governor of Syria.

**2:3** And all went to enroll themselves, every one to his own city.

**2:4** And Joseph also went up from Galilee, out of the city of Nazareth, into Judaea, to the city of David, which is called Bethlehem, because he was of the house and family of David;

**2:5** To enroll himself with Mary, who was betrothed to him, being great with child.

**2:6** And it came to pass, while they were there, the days were fulfilled that she should be delivered.

**2:7** And she brought forth her firstborn son; and she wrapped him in swaddling clothes, and laid him in a manger, because there was no room for them in the inn.

---

## The Shepherds and the Angels (2:8-20)

**2:8** And there were shepherds in the same country abiding in the field, and keeping watch by night over their flock.

**2:9** And an angel of the Lord stood by them, and the glory of the Lord shone round about them: and they were sore afraid.

**2:10** And the angel said unto them: "Be not afraid; for behold, I bring you good tidings of great joy which shall be to all the people:

**2:11** "For there is born to you this day in the city of David a Saviour, who is Anointed Lord.

**2:12** "And this is the sign unto you: You shall find a babe wrapped in swaddling clothes, and lying in a manger."

**2:13** And suddenly there was with the angel a multitude of the heavenly host praising God, and saying:

**2:14** "Glory to God in the highest,
And on earth peace among men in whom he is well pleased."

**2:15** And it came to pass, when the angels went away from them into heaven, the shepherds said one to another: "Let us now go even unto Bethlehem, and see this thing that is come to pass, which the Lord has made known unto us."

**2:16** And they came with haste, and found both Mary and Joseph, and the babe lying in the manger.

**2:17** And when they saw it, they made known concerning the saying which was spoken to them about this child.

**2:18** And all that heard it wondered at the things which were spoken unto them by the shepherds.

**2:19** But Mary kept all these sayings, pondering them in her heart.

**2:20** And the shepherds returned, glorifying and praising God for all the things that they had heard and seen, even as it was spoken unto them.

---

## The Circumcision and Presentation (2:21-24)

**2:21** And when eight days were fulfilled for circumcising him, his name was called YESHUA, which was so called by the angel before he was conceived in the womb.

**2:22** And when the days of their purification according to the law of Moses were fulfilled, they brought him up to Jerusalem, to present him to the Lord

**2:23** (As it is written in the law of the Lord: "Every male that opens the womb shall be called holy to the Lord"),

**2:24** And to offer a sacrifice according to that which is said in the law of the Lord: "A pair of turtledoves, or two young pigeons."

---

## Simeon's Prophecy (2:25-35)

**2:25** And behold, there was a man in Jerusalem, whose name was Simeon; and this man was righteous and devout, looking for the consolation of Israel: and the Holy Spirit was upon him.

**2:26** And it had been revealed unto him by the Holy Spirit, that he should not see death, before he had seen the Lord's Anointed.

**2:27** And he came in the Spirit into the temple: and when the parents brought in the child Yeshua, that they might do concerning him after the custom of the law,

**2:28** Then he received him into his arms, and blessed God, and said:

**2:29** "Now let your servant depart, Lord,
According to your word, in peace;

**2:30** For my eyes have seen your salvation,

**2:31** Which you have prepared before the face of all peoples;

**2:32** A light for revelation to the Gentiles,
And the glory of your people Israel."

**2:33** And his father and his mother were marvelling at the things which were spoken concerning him;

**2:34** And Simeon blessed them, and said unto Mary his mother: "Behold, this child is set for the falling and the rising of many in Israel; and for a sign which is spoken against;

**2:35** "Yea and a sword shall pierce through your own soul; that thoughts out of many hearts may be revealed."

---

## Anna the Prophetess (2:36-38)

**2:36** And there was one Anna, a prophetess, the daughter of Phanuel, of the tribe of Asher (she was of a great age, having lived with a husband seven years from her virginity,

**2:37** And she had been a widow even unto fourscore and four years), who departed not from the temple, worshipping with fastings and supplications night and day.

**2:38** And coming up at that very hour she gave thanks unto God, and spoke of him to all them that were looking for the redemption of Jerusalem.

---

## Return to Nazareth (2:39-40)

**2:39** And when they had accomplished all things that were according to the law of the Lord, they returned into Galilee, to their own city Nazareth.

**2:40** And the child grew, and waxed strong, filled with wisdom: and the grace of God was upon him.

---

## The Boy Yeshua in the Temple (2:41-52)

**2:41** And his parents went every year to Jerusalem at the feast of the Passover.

**2:42** And when he was twelve years old, they went up after the custom of the feast;

**2:43** And when they had fulfilled the days, as they were returning, the boy Yeshua tarried behind in Jerusalem; and his parents knew it not;

**2:44** But supposing him to be in the company, they went a day's journey; and they sought for him among their kinsfolk and acquaintance:

**2:45** And when they found him not, they returned to Jerusalem, seeking for him.

**2:46** And it came to pass, after three days they found him in the temple, sitting in the midst of the teachers, both hearing them, and asking them questions:

**2:47** And all that heard him were amazed at his understanding and his answers.

**2:48** And when they saw him, they were astonished; and his mother said unto him: "Son, why have you dealt with us so? Behold, your father and I sought you sorrowing."

**2:49** And he said unto them: "How is it that you sought me? Did you not know that I must be in my Father's house?"

**2:50** And they understood not the saying which he spoke unto them.

**2:51** And he went down with them, and came to Nazareth; and he was subject unto them: and his mother kept all these sayings in her heart.

**2:52** And Yeshua advanced in wisdom and stature, and in favour with God and men.

---

## Synthesis Notes

**Key Restorations:**

**Birth of Yeshua (2:1-7):**
"'A decree from Caesar Augustus, that all the world should be enrolled.'"

*Exēlthen dogma para Kaisaros Augoustou apographesthai pasan tēn oikoumenēn*—census.

"'This was the first enrollment made when Quirinius was governor of Syria.'"

*Hautē apographē prōtē egeneto hēgemoneuontos tēs Syrias Kyrēniou*—Quirinius.

"'Joseph also went up from Galilee, out of the city of Nazareth, into Judaea, to the city of David, which is called Bethlehem.'"

*Anebē de kai Iōsēph apo tēs Galilaias ek poleōs Nazareth eis tēn Ioudaian eis polin David hētis kaleitai Bēthleem*—Bethlehem.

"'Because he was of the house and family of David.'"

*Dia to einai auton ex oikou kai patrias David*—David's line.

"'She brought forth her firstborn son.'"

*Kai eteken ton huion autēs ton prōtotokon*—firstborn.

"'She wrapped him in swaddling clothes, and laid him in a manger.'"

*Kai esparganōsen auton kai aneklinen auton en phatnē*—manger.

**Phatnē:**
"Feeding trough."

"'There was no room for them in the inn.'"

*Dioti ouk ēn autois topos en tō katalymati*—no room.

**Shepherds and Angels (2:8-20):**
"'There were shepherds in the same country abiding in the field.'"

*Kai poimenes ēsan en tē chōra tē autē agraulountes*—shepherds.

"'Keeping watch by night over their flock.'"

*Kai phylassontes phylakas tēs nyktos epi tēn poimnēn autōn*—watch.

"'An angel of the Lord stood by them, and the glory of the Lord shone round about them.'"

*Kai angelos kyriou epestē autois kai doxa kyriou perielampsen autous*—glory.

"''Be not afraid; for behold, I bring you good tidings of great joy.''"

*Mē phobeisthe idou gar euangelizomai hymin charan megalēn*—good tidings.

**Euangelizomai:**
"I bring good news."

"''For there is born to you this day in the city of David a Saviour, who is Anointed Lord.''"

*Hoti etechthē hymin sēmeron sōtēr hos estin Christos kyrios en polei David*—Savior, Anointed, Lord.

"''You shall find a babe wrapped in swaddling clothes, and lying in a manger.''"

*Heurēsete brephos esparganōmenon kai keimenon en phatnē*—sign.

"'Suddenly there was with the angel a multitude of the heavenly host.'"

*Kai exaiphnēs egeneto syn tō angelō plēthos stratias ouraniou*—host.

"''Glory to God in the highest, and on earth peace among men in whom he is well pleased.''"

*Doxa en hypsistois theō kai epi gēs eirēnē en anthrōpois eudokias*—Gloria.

"'Mary kept all these sayings, pondering them in her heart.'"

*Hē de Maria panta synetērei ta rhēmata tauta symballousa en tē kardia autēs*—pondering.

**Circumcision and Presentation (2:21-24):**
"'When eight days were fulfilled for circumcising him, his name was called YESHUA.'"

*Kai hote eplēsthēsan hēmerai oktō tou peritemein auton kai eklēthē to onoma autou Iēsous*—eighth day.

"'When the days of their purification according to the law of Moses were fulfilled.'"

*Kai hote eplēsthēsan hai hēmerai tou katharismou autōn kata ton nomon Mōuseōs*—purification.

**Leviticus 12:2-8.**

"'They brought him up to Jerusalem, to present him to the Lord.'"

*Anēgagon auton eis Hierosolyma parastēsai tō kyriō*—present.

"''Every male that opens the womb shall be called holy to the Lord.''"

*Pan arsen dianoigon mētran hagion tō kyriō klēthēsetai*—Exodus 13:2.

"''A pair of turtledoves, or two young pigeons.''"

*Zeugos trygonōn ē duo neossous peristerōn*—offering.

**Poverty Offering:**
Leviticus 12:8—for those who couldn't afford a lamb.

**Simeon's Prophecy (2:25-35):**
"'A man in Jerusalem, whose name was Simeon.'"

*Anthrōpos ēn en Hierousalēm hō onoma Symeōn*—Simeon.

"'Righteous and devout, looking for the consolation of Israel.'"

*Kai ho anthrōpos houtos dikaios kai eulabēs prosdechomenos paraklēsin tou Israēl*—consolation.

"'The Holy Spirit was upon him.'"

*Kai pneuma ēn hagion ep' auton*—Spirit.

"'He should not see death, before he had seen the Lord's Anointed.'"

*Mē idein thanaton prin an idē ton Christon kyriou*—Lord's Anointed.

"''Now let your servant depart, Lord, according to your word, in peace.''"

*Nyn apolyeis ton doulon sou despota kata to rhēma sou en eirēnē*—Nunc Dimittis.

"''My eyes have seen your salvation.''"

*Hoti eidon hoi ophthalmoi mou to sōtērion sou*—salvation.

"''Which you have prepared before the face of all peoples.''"

*Ho hētoimasas kata prosōpon pantōn tōn laōn*—all peoples.

"''A light for revelation to the Gentiles, and the glory of your people Israel.''"

*Phōs eis apokalypsin ethnōn kai doxan laou sou Israēl*—light, glory.

**Isaiah 42:6, 49:6.**

"''This child is set for the falling and the rising of many in Israel.''"

*Houtos keitai eis ptōsin kai anastasin pollōn en tō Israēl*—falling, rising.

"''For a sign which is spoken against.''"

*Kai eis sēmeion antilegomenon*—opposed.

"''A sword shall pierce through your own soul.''"

*Kai sou de autēs tēn psychēn dieleusetai rhomphaia*—sword.

**Anna the Prophetess (2:36-38):**
"'Anna, a prophetess, the daughter of Phanuel, of the tribe of Asher.'"

*Kai ēn Anna prophētis thugatēr Phanouēl ek phylēs Asēr*—Asher.

"'A widow even unto fourscore and four years.'"

*Hautē chēra heōs etōn ogdoēkonta tessarōn*—84 years.

"'Who departed not from the temple, worshipping with fastings and supplications night and day.'"

*Hē ouk aphistato tou hierou nēsteiais kai deēsesin latreuousa nykta kai hēmeran*—devoted.

"'She gave thanks unto God, and spoke of him to all them that were looking for the redemption of Jerusalem.'"

*Kai autē tē hōra epistasa anthōmologeito tō theō kai elalei peri autou pasin tois prosdechomenois lytrōsin Hierousalēm*—redemption.

**Return to Nazareth (2:39-40):**
"'They returned into Galilee, to their own city Nazareth.'"

*Hypestrepsan eis tēn Galilaian eis polin heautōn Nazareth*—Nazareth.

"'The child grew, and waxed strong, filled with wisdom: and the grace of God was upon him.'"

*To de paidion ēuxanen kai ekrataiouto plēroumenon sophia kai charis theou ēn ep' auto*—grew.

**Boy Yeshua in the Temple (2:41-52):**
"'His parents went every year to Jerusalem at the feast of the Passover.'"

*Kai eporeuonto hoi goneis autou kat' etos eis Hierousalēm tē heortē tou pascha*—Passover.

"'When he was twelve years old.'"

*Hote egeneto etōn dōdeka*—twelve.

**Bar Mitzvah Age:**
Near age of religious responsibility.

"'The boy Yeshua tarried behind in Jerusalem.'"

*Hypemeinen Iēsous ho pais en Hierousalēm*—remained.

"'After three days they found him in the temple, sitting in the midst of the teachers.'"

*Kai egeneto meta hēmeras treis heuron auton en tō hierō kathezomenon en mesō tōn didaskalōn*—teachers.

"'Both hearing them, and asking them questions.'"

*Kai akouonta autōn kai eperōtōnta autous*—dialogue.

"'All that heard him were amazed at his understanding and his answers.'"

*Existanto de pantes hoi akouontes autou epi tē synesei kai tais apokrisesin autou*—amazed.

"''Son, why have you dealt with us so?''"

*Teknon ti epoiēsas hēmin houtōs*—why?

"''Did you not know that I must be in my Father's house?''"

*Ouk ēdeite hoti en tois tou patros mou dei einai me*—Father's house.

**First Words of Yeshua:**
Consciousness of unique relationship with God.

"'They understood not the saying.'"

*Kai autoi ou synēkan to rhēma ho elalēsen autois*—didn't understand.

"'His mother kept all these sayings in her heart.'"

*Kai hē mētēr autou dietērei panta ta rhēmata en tē kardia autēs*—kept.

"'Yeshua advanced in wisdom and stature, and in favour with God and men.'"

*Kai Iēsous proekopten en tē sophia kai hēlikia kai chariti para theō kai anthrōpois*—advanced.

**1 Samuel 2:26 Echo.**

**Archetypal Layer:** Luke 2 contains **birth of Yeshua (2:1-7)**: Caesar's census, Bethlehem, "no room in the inn," laid in a manger, **shepherds and angels (2:8-20)**: "good tidings of great joy," "born to you this day... a Saviour, who is Anointed Lord" (2:11), **"Glory to God in the highest, and on earth peace" (2:14)**, **"Mary kept all these sayings, pondering them in her heart" (2:19)**, **circumcision on eighth day (2:21)**, **presentation in temple (2:22-24)**: poverty offering, **Simeon's prophecy (2:25-35)**: Nunc Dimittis, "my eyes have seen your salvation" (2:30), "a light for revelation to the Gentiles, and the glory of your people Israel" (2:32), "set for the falling and the rising of many" (2:34), "a sword shall pierce through your own soul" (2:35), **Anna the prophetess (2:36-38)**: looking for redemption, **return to Nazareth (2:39-40)**, and **boy Yeshua in the temple (2:41-52)**: age twelve, "in my Father's house" (2:49), "advanced in wisdom and stature" (2:52).

**Modern Equivalent:** Luke 2 is the Christmas narrative. The census brings Mary and Joseph to Bethlehem. The manger birth (2:7) signifies humble beginnings. Shepherds (2:8-20) are the first to receive the good news—socially marginal, yet chosen. Simeon's Nunc Dimittis (2:29-32) announces salvation for all peoples, light for Gentiles. His prophecy to Mary includes the ominous sword (2:35). Anna represents faithful Israel awaiting redemption. The temple incident at age twelve (2:41-52) is Yeshua's first recorded words, revealing awareness of unique sonship: "my Father's house" (2:49).

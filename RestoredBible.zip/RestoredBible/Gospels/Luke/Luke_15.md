# Luke 15: The Lost and Found — Sheep, Coin, and Son

*From the Greek: Ἦσαν δὲ αὐτῷ ἐγγίζοντες (Ēsan de Autō Engizontes) — Now All the Publicans and Sinners Were Drawing Near*

---

## The Lost Sheep (15:1-7)

**15:1** Now all the publicans and sinners were drawing near unto him to hear him.

**15:2** And both the Pharisees and the scribes murmured, saying: "This man receives sinners, and eats with them."

**15:3** And he spoke unto them this parable, saying:

**15:4** "What man of you, having a hundred sheep, and having lost one of them, does not leave the ninety and nine in the wilderness, and go after that which is lost, until he find it?

**15:5** "And when he has found it, he lays it on his shoulders, rejoicing.

**15:6** "And when he comes home, he calls together his friends and his neighbours, saying unto them, 'Rejoice with me, for I have found my sheep which was lost.'

**15:7** "I say unto you, that even so there shall be joy in heaven over one sinner that repents, more than over ninety and nine righteous persons, who need no repentance."

---

## The Lost Coin (15:8-10)

**15:8** "Or what woman having ten pieces of silver, if she lose one piece, does not light a lamp, and sweep the house, and seek diligently until she find it?

**15:9** "And when she has found it, she calls together her friends and neighbours, saying, 'Rejoice with me, for I have found the piece which I had lost.'

**15:10** "Even so, I say unto you, there is joy in the presence of the angels of God over one sinner that repents."

---

## The Prodigal Son (15:11-32)

**15:11** And he said: "A certain man had two sons:

**15:12** "And the younger of them said to his father, 'Father, give me the portion of your substance that falls to me.' And he divided unto them his living.

**15:13** "And not many days after, the younger son gathered all together and took his journey into a far country; and there he wasted his substance with riotous living.

**15:14** "And when he had spent all, there arose a mighty famine in that country; and he began to be in want.

**15:15** "And he went and joined himself to one of the citizens of that country; and he sent him into his fields to feed swine.

**15:16** "And he would fain have filled his belly with the husks that the swine did eat: and no man gave unto him.

**15:17** "But when he came to himself he said, 'How many hired servants of my father's have bread enough and to spare, and I perish here with hunger!

**15:18** "'I will arise and go to my father, and will say unto him, Father, I have sinned against heaven, and in your sight:

**15:19** "'I am no more worthy to be called your son: make me as one of your hired servants.'

**15:20** "And he arose, and came to his father. But while he was yet afar off, his father saw him, and was moved with compassion, and ran, and fell on his neck, and kissed him.

**15:21** "And the son said unto him, 'Father, I have sinned against heaven, and in your sight: I am no more worthy to be called your son.'

**15:22** "But the father said to his servants, 'Bring forth quickly the best robe, and put it on him; and put a ring on his hand, and shoes on his feet:

**15:23** "'And bring the fatted calf, and kill it, and let us eat, and make merry:

**15:24** "'For this my son was dead, and is alive again; he was lost, and is found.' And they began to be merry.

**15:25** "Now his elder son was in the field: and as he came and drew near to the house, he heard music and dancing.

**15:26** "And he called to him one of the servants, and inquired what these things might be.

**15:27** "And he said unto him, 'Your brother is come; and your father has killed the fatted calf, because he has received him safe and sound.'

**15:28** "But he was angry, and would not go in: and his father came out, and entreated him.

**15:29** "But he answered and said to his father, 'Lo, these many years do I serve you, and I never transgressed a commandment of yours; and yet you never gave me a kid, that I might make merry with my friends:

**15:30** "'But when this your son came, who has devoured your living with harlots, you killed for him the fatted calf.'

**15:31** "And he said unto him, 'Son, you are ever with me, and all that is mine is yours.

**15:32** "'But it was meet to make merry and be glad: for this your brother was dead, and is alive again; and was lost, and is found.'"

---

## Synthesis Notes

**Key Restorations:**

**The Lost Sheep (15:1-7):**
"'All the publicans and sinners were drawing near unto him to hear him.'"

*Ēsan de autō engizontes pantes hoi telōnai kai hoi hamartōloi akouein autou*—drawing near.

"'The Pharisees and the scribes murmured, saying: This man receives sinners, and eats with them.'"

*Kai diegoggyzon hoi te Pharisaioi kai hoi grammateis legontes hoti houtos hamartōlous prosdechetai kai synesthiei autois*—receives sinners.

"''What man of you, having a hundred sheep, and having lost one of them.''"

*Tis anthrōpos ex hymōn echōn hekaton probata kai apolesas ex autōn hen*—hundred sheep.

"''Does not leave the ninety and nine in the wilderness, and go after that which is lost, until he find it?''"

*Ou kataleipei ta ennenēkonta ennea en tē erēmō kai poreuetai epi to apolōlos heōs heurē auto*—go after.

"''When he has found it, he lays it on his shoulders, rejoicing.''"

*Kai heurōn epitithēsin epi tous ōmous autou chairōn*—shoulders.

"''Rejoice with me, for I have found my sheep which was lost.''"

*Syncharēte moi hoti heuron to probaton mou to apolōlos*—rejoice.

"''There shall be joy in heaven over one sinner that repents.''"

*Houtōs chara en tō ouranō estai epi heni hamartōlō metanoounti*—joy in heaven.

"''More than over ninety and nine righteous persons, who need no repentance.''"

*Ē epi ennenēkonta ennea dikaiois hoitines ou chreian echousin metanoias*—more joy.

**The Lost Coin (15:8-10):**
"''What woman having ten pieces of silver, if she lose one piece.''"

*Ē tis gynē drachmas echousa deka ean apolesē drachmēn mian*—ten drachmas.

**Only Luke:**
This parable unique to Luke.

"''Does not light a lamp, and sweep the house, and seek diligently until she find it?''"

*Ouchi haptei lychnon kai saroi tēn oikian kai zētei epimelōs heōs hou heurē*—seek diligently.

"''Rejoice with me, for I have found the piece which I had lost.''"

*Syncharēte moi hoti heuron tēn drachmēn hēn apōlesa*—rejoice.

"''There is joy in the presence of the angels of God over one sinner that repents.''"

*Houtōs legō hymin ginetai chara enōpion tōn angelōn tou theou epi heni hamartōlō metanoounti*—angels rejoice.

**The Prodigal Son (15:11-32):**
"''A certain man had two sons.''"

*Anthrōpos tis eichen dyo huious*—two sons.

**Only Luke:**
This parable unique to Luke.

"''Father, give me the portion of your substance that falls to me.''"

*Pater dos moi to epiballon meros tēs ousias*—inheritance.

"''He divided unto them his living.''"

*Kai dieilen autois ton bion*—divided.

"''He wasted his substance with riotous living.''"

*Kai ekei dieskorpisen tēn ousian autou zōn asōtōs*—riotous.

"''There arose a mighty famine in that country; and he began to be in want.''"

*Egeneto limos ischyra kata tēn chōran ekeinēn kai autos ērxato hystereisthai*—famine.

"''He went and joined himself to one of the citizens of that country; and he sent him into his fields to feed swine.''"

*Kai poreutheis ekollēthē heni tōn politōn tēs chōras ekeinēs kai epempsen auton eis tous agrous autou boskein choirous*—swine.

**Degradation:**
For a Jew, feeding pigs was ultimate humiliation.

"''He would fain have filled his belly with the husks that the swine did eat.''"

*Kai epethymei chortasthēnai ek tōn keratiōn hōn ēsthion hoi choiroi*—husks.

"''No man gave unto him.''"

*Kai oudeis edidou autō*—no one gave.

"''When he came to himself.''"

*Eis heauton de elthōn*—came to himself.

"''How many hired servants of my father's have bread enough and to spare, and I perish here with hunger!''"

*Posoi misthioi tou patros mou perisseuontai artōn egō de limō hōde apollymai*—servants have bread.

"''I will arise and go to my father.''"

*Anastas poreusomai pros ton patera mou*—arise.

"''Father, I have sinned against heaven, and in your sight.''"

*Pater hēmarton eis ton ouranon kai enōpion sou*—sinned.

"''I am no more worthy to be called your son.''"

*Ouketi eimi axios klēthēnai huios sou*—unworthy.

"''Make me as one of your hired servants.''"

*Poiēson me hōs hena tōn misthiōn sou*—hired servant.

"''While he was yet afar off, his father saw him, and was moved with compassion.''"

*Eti de autou makran apechontos eiden auton ho patēr autou kai esplanchnisthē*—compassion.

"''Ran, and fell on his neck, and kissed him.''"

*Kai dramōn epepesen epi ton trachēlon autou kai katephilēsen auton*—ran, kissed.

"''Bring forth quickly the best robe, and put it on him.''"

*Tachy exenenkate stolēn tēn prōtēn kai endysate auton*—best robe.

"''Put a ring on his hand, and shoes on his feet.''"

*Kai dote daktylion eis tēn cheira autou kai hypodēmata eis tous podas*—ring, shoes.

"''Bring the fatted calf, and kill it, and let us eat, and make merry.''"

*Kai pherete ton moschon ton siteuton thysate kai phagontes euphranthōmen*—fatted calf.

"''This my son was dead, and is alive again; he was lost, and is found.''"

*Hoti houtos ho huios mou nekros ēn kai anezēsen ēn apolōlōs kai heurethē*—dead, alive.

"''His elder son was in the field.''"

*Ēn de ho huios autou ho presbyteros en agrō*—elder son.

"''He heard music and dancing.''"

*Ēkousen symphōnias kai chorōn*—music, dancing.

"''Your brother is come; and your father has killed the fatted calf.''"

*Ho adelphos sou hēkei kai ethysen ho patēr sou ton moschon ton siteuton*—brother come.

"''He was angry, and would not go in.''"

*Ōrgisthē de kai ouk ēthelen eiselthein*—angry.

"''His father came out, and entreated him.''"

*Ho de patēr autou exelthōn parekalei auton*—father entreated.

"''Lo, these many years do I serve you, and I never transgressed a commandment of yours.''"

*Idou tosauta etē douleuō soi kai oudepote entolēn sou parēlthon*—served.

"''You never gave me a kid, that I might make merry with my friends.''"

*Kai emoi oudepote edōkas eriphon hina meta tōn philōn mou euphranثō*—no kid.

"''When this your son came, who has devoured your living with harlots.''"

*Hote de ho huios sou houtos ho kataphagōn sou ton bion meta pornōn ēlthen*—this your son.

"''Son, you are ever with me, and all that is mine is yours.''"

*Teknon sy pantote met' emou ei kai panta ta ema sa estin*—all mine is yours.

"''It was meet to make merry and be glad.''"

*Euphranthēnai de kai charēnai edei*—meet.

"''This your brother was dead, and is alive again; and was lost, and is found.''"

*Hoti ho adelphos sou houtos nekros ēn kai ezēsen kai apolōlōs kai heurethē*—your brother.

**Archetypal Layer:** Luke 15 is the chapter of the lost and found, containing **the lost sheep (15:1-7)**: "This man receives sinners, and eats with them" (15:2), one of a hundred, carried on shoulders, **"joy in heaven over one sinner that repents, more than over ninety and nine righteous persons" (15:7)**, **the lost coin (15:8-10)** (unique to Luke): one of ten drachmas, "joy in the presence of the angels of God" (15:10), and **the prodigal son (15:11-32)** (unique to Luke): younger son demands inheritance, wastes it in far country, feeds swine, "came to himself" (15:17), **"I will arise and go to my father" (15:18)**, **"I have sinned against heaven, and in your sight" (15:18, 21)**, **father sees him afar off, moved with compassion, ran, fell on his neck, kissed him (15:20)**, best robe, ring, shoes, fatted calf, **"this my son was dead, and is alive again; he was lost, and is found" (15:24, 32)**, **elder son angry (15:28)**, "these many years do I serve you" (15:29), **"Son, you are ever with me, and all that is mine is yours" (15:31)**, **"your brother" (15:32)**.

**Modern Equivalent:** Luke 15 responds to criticism that Yeshua "receives sinners" (15:2). Three parables of lostness and finding show God's heart. The lost sheep (15:3-7) and lost coin (15:8-10) demonstrate joy over recovery. The prodigal son (15:11-32), unique to Luke, is the gospel in miniature: the father's compassion, running to meet the returning son, lavishing restoration. The elder brother represents those who resent grace to sinners—he is invited but refuses the feast. The father's appeal—"your brother was dead, and is alive" (15:32)—remains open-ended.

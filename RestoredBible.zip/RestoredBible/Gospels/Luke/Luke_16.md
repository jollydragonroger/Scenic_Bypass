# Luke 16: Wealth, Stewardship, and the Rich Man and Lazarus

*From the Greek: Ἔλεγεν δὲ καὶ πρὸς τοὺς μαθητάς (Elegen de kai pros tous Mathētas) — And He Said Also unto the Disciples*

---

## The Shrewd Manager (16:1-13)

**16:1** And he said also unto the disciples: "There was a certain rich man, who had a steward; and the same was accused unto him that he was wasting his goods.

**16:2** "And he called him, and said unto him, 'What is this that I hear of you? Render the account of your stewardship; for you can be no longer steward.'

**16:3** "And the steward said within himself, 'What shall I do, seeing that my lord takes away the stewardship from me? I have not strength to dig; to beg I am ashamed.

**16:4** "'I am resolved what to do, that, when I am put out of the stewardship, they may receive me into their houses.'

**16:5** "And calling to him each one of his lord's debtors, he said to the first, 'How much do you owe unto my lord?'

**16:6** "And he said, 'A hundred measures of oil.' And he said unto him, 'Take your bond, and sit down quickly and write fifty.'

**16:7** "Then said he to another, 'And how much do you owe?' And he said, 'A hundred measures of wheat.' He says unto him, 'Take your bond, and write fourscore.'

**16:8** "And his lord commended the unrighteous steward because he had done wisely: for the sons of this world are for their own generation wiser than the sons of the light.

**16:9** "And I say unto you, Make to yourselves friends by means of the mammon of unrighteousness; that, when it shall fail, they may receive you into the eternal tabernacles.

**16:10** "He that is faithful in a very little is faithful also in much: and he that is unrighteous in a very little is unrighteous also in much.

**16:11** "If therefore you have not been faithful in the unrighteous mammon, who will commit to your trust the true riches?

**16:12** "And if you have not been faithful in that which is another's, who will give you that which is your own?

**16:13** "No servant can serve two masters: for either he will hate the one, and love the other; or else he will hold to one, and despise the other. You cannot serve God and mammon."

---

## The Pharisees Rebuked (16:14-18)

**16:14** And the Pharisees, who were lovers of money, heard all these things; and they scoffed at him.

**16:15** And he said unto them: "You are they that justify yourselves in the sight of men; but God knows your hearts: for that which is exalted among men is an abomination in the sight of God.

**16:16** "The law and the prophets were until John: from that time the good tidings of the kingdom of God is preached, and every man enters violently into it.

**16:17** "But it is easier for heaven and earth to pass away, than for one tittle of the law to fall.

**16:18** "Every one that puts away his wife, and marries another, commits adultery: and he that marries one that is put away from a husband commits adultery."

---

## The Rich Man and Lazarus (16:19-31)

**16:19** "Now there was a certain rich man, and he was clothed in purple and fine linen, faring sumptuously every day:

**16:20** "And a certain beggar named Lazarus was laid at his gate, full of sores,

**16:21** "And desiring to be fed with the crumbs that fell from the rich man's table; yea, even the dogs came and licked his sores.

**16:22** "And it came to pass, that the beggar died, and that he was carried away by the angels into Abraham's bosom: and the rich man also died, and was buried.

**16:23** "And in Hades he lifted up his eyes, being in torments, and sees Abraham afar off, and Lazarus in his bosom.

**16:24** "And he cried and said, 'Father Abraham, have mercy on me, and send Lazarus, that he may dip the tip of his finger in water, and cool my tongue; for I am in anguish in this flame.'

**16:25** "But Abraham said, 'Son, remember that you in your lifetime received your good things, and Lazarus in like manner evil things: but now here he is comforted, and you are in anguish.

**16:26** "'And besides all this, between us and you there is a great gulf fixed, that they that would pass from hence to you may not be able, and that none may cross over from thence to us.'

**16:27** "And he said, 'I pray you therefore, father, that you would send him to my father's house;

**16:28** "'For I have five brethren; that he may testify unto them, lest they also come into this place of torment.'

**16:29** "But Abraham says, 'They have Moses and the prophets; let them hear them.'

**16:30** "And he said, 'Nay, father Abraham: but if one go to them from the dead, they will repent.'

**16:31** "And he said unto him, 'If they hear not Moses and the prophets, neither will they be persuaded, if one rise from the dead.'"

---

## Synthesis Notes

**Key Restorations:**

**The Shrewd Manager (16:1-13):**
"''There was a certain rich man, who had a steward.''"

*Anthrōpos tis ēn plousios hos eichen oikonomon*—steward.

**Only Luke:**
This parable unique to Luke.

"''He was wasting his goods.''"

*Diaskorpizōn ta hyparchonta autou*—wasting.

"''Render the account of your stewardship; for you can be no longer steward.''"

*Apodos ton logon tēs oikonomias sou ou gar dynē eti oikonomein*—account.

"''I have not strength to dig; to beg I am ashamed.''"

*Skaptein ouk ischyō epaitein aischynomai*—dig, beg.

"''How much do you owe unto my lord?''"

*Poson opheileis tō kyriō mou*—how much?

"''A hundred measures of oil... Take your bond, and sit down quickly and write fifty.''"

*Hekaton batous elaiou... dexai sou ta grammata kai kathisas tacheōs grapson pentēkonta*—half.

"''A hundred measures of wheat... Take your bond, and write fourscore.''"

*Hekaton korous sitou... dexai sou ta grammata kai grapson ogdoēkonta*—eighty.

"''His lord commended the unrighteous steward because he had done wisely.''"

*Kai epēnesen ho kyrios ton oikonomon tēs adikias hoti phronimōs epoiēsen*—commended.

"''The sons of this world are for their own generation wiser than the sons of the light.''"

*Hoi huioi tou aiōnos toutou phronimōteroi hyper tous huious tou phōtos eis tēn genean tēn heautōn eisin*—worldly wisdom.

"''Make to yourselves friends by means of the mammon of unrighteousness.''"

*Poiēsate heautois philous ek tou mamōna tēs adikias*—mammon.

"''That, when it shall fail, they may receive you into the eternal tabernacles.''"

*Hina hotan eklipē dexōntai hymas eis tas aiōnious skēnas*—eternal tabernacles.

"''He that is faithful in a very little is faithful also in much.''"

*Ho pistos en elachistō kai en pollō pistos estin*—faithful.

"''If therefore you have not been faithful in the unrighteous mammon, who will commit to your trust the true riches?''"

*Ei oun en tō adikō mamōna pistoi ouk egenesthe to alēthinon tis hymin pisteusei*—true riches.

"''No servant can serve two masters.''"

*Oudeis oiketēs dynatai dysi kyriois douleuein*—two masters.

"''You cannot serve God and mammon.''"

*Ou dynasthe theō douleuein kai mamōna*—God or mammon.

**Pharisees Rebuked (16:14-18):**
"'The Pharisees, who were lovers of money, heard all these things; and they scoffed at him.'"

*Ēkouon de tauta panta hoi Pharisaioi philargyroi hyparchontes kai exemyktērizon auton*—scoffed.

"''You are they that justify yourselves in the sight of men; but God knows your hearts.''"

*Hymeis este hoi dikaiountes heautous enōpion tōn anthrōpōn ho de theos ginōskei tas kardias hymōn*—God knows.

"''That which is exalted among men is an abomination in the sight of God.''"

*Hoti to en anthrōpois hypsēlon bdelygma enōpion tou theou*—abomination.

"''The law and the prophets were until John: from that time the good tidings of the kingdom of God is preached.''"

*Ho nomos kai hoi prophētai mechri Iōannou apo tote hē basileia tou theou euangelizetai*—John.

"''Every man enters violently into it.''"

*Kai pas eis autēn biazetai*—violently.

"''It is easier for heaven and earth to pass away, than for one tittle of the law to fall.''"

*Eukopōteron de estin ton ouranon kai tēn gēn parelthein ē tou nomou mian keraian pesein*—tittle.

**Rich Man and Lazarus (16:19-31):**
"''There was a certain rich man, and he was clothed in purple and fine linen, faring sumptuously every day.''"

*Anthrōpos de tis ēn plousios kai enedidysketo porphyran kai bysson euphrainomenos kath' hēmeran lamprōs*—purple, linen.

**Only Luke:**
This parable unique to Luke.

"''A certain beggar named Lazarus was laid at his gate, full of sores.''"

*Ptōchos de tis onomati Lazaros ebeblēto pros ton pylōna autou heilkōmenos*—Lazarus.

**Only Named Character:**
In Yeshua's parables.

"''Desiring to be fed with the crumbs that fell from the rich man's table.''"

*Kai epithymōn chortasthēnai apo tōn piptontōn apo tēs trapezēs tou plousiou*—crumbs.

"''Even the dogs came and licked his sores.''"

*Alla kai hoi kynes erchomenoi epeleichon ta helkē autou*—dogs.

"''The beggar died, and that he was carried away by the angels into Abraham's bosom.''"

*Egeneto de apothanein ton ptōchon kai apenechthēnai auton hypo tōn angelōn eis ton kolpon Abraam*—Abraham's bosom.

"''The rich man also died, and was buried.''"

*Apethanen de kai ho plousios kai etaphē*—buried.

"''In Hades he lifted up his eyes, being in torments.''"

*Kai en tō hadē eparas tous ophthalmous autou hyparchōn en basanois*—Hades.

"''Father Abraham, have mercy on me, and send Lazarus.''"

*Pater Abraam eleēson me kai pempson Lazaron*—mercy.

"''That he may dip the tip of his finger in water, and cool my tongue.''"

*Hina bapsē to akron tou daktylou autou hydatos kai katapsyxē tēn glōssan mou*—water.

"''I am in anguish in this flame.''"

*Odynōmai en tē phlogi tautē*—flame.

"''Son, remember that you in your lifetime received your good things, and Lazarus in like manner evil things.''"

*Teknon mnēsthēti hoti apelabes ta agatha sou en tē zōē sou kai Lazaros homoiōs ta kaka*—reversal.

"''Now here he is comforted, and you are in anguish.''"

*Nyn de hōde parakaleitai sy de odynasai*—comforted.

"''Between us and you there is a great gulf fixed.''"

*Kai en pasin toutois metaxy hēmōn kai hymōn chasma mega estēriktai*—gulf.

"''I have five brethren; that he may testify unto them.''"

*Echō gar pente adelphous hopōs diamarturētai autois*—five brothers.

"''They have Moses and the prophets; let them hear them.''"

*Echousin Mōusea kai tous prophētas akousatōsan autōn*—Moses, prophets.

"''If one go to them from the dead, they will repent.''"

*Ean tis apo nekrōn poreuthē pros autous metanoēsousin*—from dead.

"''If they hear not Moses and the prophets, neither will they be persuaded, if one rise from the dead.''"

*Ei Mōuseōs kai tōn prophētōn ouk akouousin oude ean tis ek nekrōn anastē peisthēsontai*—not persuaded.

**Archetypal Layer:** Luke 16 contains **the shrewd manager (16:1-13)** (unique to Luke): wasting goods, reducing debts, **"his lord commended the unrighteous steward because he had done wisely" (16:8)**, **"the sons of this world are... wiser than the sons of the light" (16:8)**, **"Make to yourselves friends by means of the mammon of unrighteousness" (16:9)**, **"He that is faithful in a very little is faithful also in much" (16:10)**, **"You cannot serve God and mammon" (16:13)**, **Pharisees rebuked (16:14-18)**: "lovers of money" (16:14), "God knows your hearts" (16:15), "The law and the prophets were until John" (16:16), and **the rich man and Lazarus (16:19-31)** (unique to Luke): purple and fine linen vs. sores and crumbs, **reversal after death (16:22-25)**, Abraham's bosom vs. Hades, **"between us and you there is a great gulf fixed" (16:26)**, five brothers, **"They have Moses and the prophets; let them hear them" (16:29)**, **"neither will they be persuaded, if one rise from the dead" (16:31)**.

**Modern Equivalent:** Luke 16 addresses wealth. The shrewd manager (16:1-13) is puzzling—the master commends shrewdness, not dishonesty. The lesson: use worldly resources wisely for eternal benefit. "You cannot serve God and mammon" (16:13) is decisive. The rich man and Lazarus (16:19-31), unique to Luke, shows ultimate reversal. The rich man ignored Lazarus at his gate; now an unbridgeable gulf separates them. The climax: even resurrection won't convince those who ignore Moses and the prophets (16:31)—a pointed reference to Yeshua's own resurrection.

# Luke 14: Table Fellowship and the Cost of Discipleship

*From the Greek: Καὶ ἐγένετο ἐν τῷ ἐλθεῖν αὐτὸν (Kai Egeneto en tō Elthein Auton) — And It Came to Pass, When He Went*

---

## Healing on the Sabbath (14:1-6)

**14:1** And it came to pass, when he went into the house of one of the rulers of the Pharisees on a sabbath to eat bread, that they were watching him.

**14:2** And behold, there was before him a certain man that had the dropsy.

**14:3** And Yeshua answering spoke unto the lawyers and Pharisees, saying: "Is it lawful to heal on the sabbath, or not?"

**14:4** But they held their peace. And he took him, and healed him, and let him go.

**14:5** And he said unto them: "Which of you shall have an ass or an ox fallen into a well, and will not straightway draw him up on a sabbath day?"

**14:6** And they could not answer again unto these things.

---

## Humility at Banquets (14:7-11)

**14:7** And he spoke a parable unto those that were bidden, when he marked how they chose out the chief seats; saying unto them:

**14:8** "When you are bidden of any man to a marriage feast, sit not down in the chief seat; lest haply a more honourable man than you be bidden of him,

**14:9** "And he that bade you and him shall come and say to you, 'Give this man place'; and then you shall begin with shame to take the lowest place.

**14:10** "But when you are bidden, go and sit down in the lowest place; that when he that has bidden you comes, he may say to you, 'Friend, go up higher': then shall you have glory in the presence of all that sit at meat with you.

**14:11** "For every one that exalts himself shall be humbled; and he that humbles himself shall be exalted."

---

## Inviting the Poor (14:12-14)

**14:12** And he said to him also that had bidden him: "When you make a dinner or a supper, call not your friends, nor your brethren, nor your kinsmen, nor rich neighbours; lest haply they also bid you again, and a recompense be made you.

**14:13** "But when you make a feast, bid the poor, the maimed, the lame, the blind:

**14:14** "And you shall be blessed; because they have not wherewith to recompense you: for you shall be recompensed in the resurrection of the just."

---

## The Great Banquet (14:15-24)

**14:15** And when one of them that sat at meat with him heard these things, he said unto him: "Blessed is he that shall eat bread in the kingdom of God."

**14:16** But he said unto him: "A certain man made a great supper; and he bade many:

**14:17** "And he sent forth his servant at supper time to say to them that were bidden, 'Come; for all things are now ready.'

**14:18** "And they all with one consent began to make excuse. The first said unto him, 'I have bought a field, and I must needs go out and see it; I pray you have me excused.'

**14:19** "And another said, 'I have bought five yoke of oxen, and I go to prove them; I pray you have me excused.'

**14:20** "And another said, 'I have married a wife, and therefore I cannot come.'

**14:21** "And the servant came, and told his lord these things. Then the master of the house being angry said to his servant, 'Go out quickly into the streets and lanes of the city, and bring in hither the poor and maimed and blind and lame.'

**14:22** "And the servant said, 'Lord, what you did command is done, and yet there is room.'

**14:23** "And the lord said unto the servant, 'Go out into the highways and hedges, and constrain them to come in, that my house may be filled.

**14:24** "'For I say unto you, that none of those men that were bidden shall taste of my supper.'"

---

## The Cost of Discipleship (14:25-33)

**14:25** Now there went with him great multitudes: and he turned, and said unto them:

**14:26** "If any man comes to me, and hates not his own father, and mother, and wife, and children, and brethren, and sisters, yea, and his own life also, he cannot be my disciple.

**14:27** "Whosoever does not bear his own cross, and come after me, cannot be my disciple.

**14:28** "For which of you, desiring to build a tower, does not first sit down and count the cost, whether he has wherewith to complete it?

**14:29** "Lest haply, when he has laid a foundation, and is not able to finish, all that behold begin to mock him,

**14:30** "Saying, 'This man began to build, and was not able to finish.'

**14:31** "Or what king, as he goes to encounter another king in war, will not sit down first and take counsel whether he is able with ten thousand to meet him that comes against him with twenty thousand?

**14:32** "Or else, while the other is yet a great way off, he sends an ambassage, and asks conditions of peace.

**14:33** "So therefore whosoever he be of you that renounces not all that he has, he cannot be my disciple."

---

## Salt without Taste (14:34-35)

**14:34** "Salt therefore is good: but if even the salt have lost its savour, wherewith shall it be seasoned?

**14:35** "It is fit neither for the land nor for the dunghill: men cast it out. He that has ears to hear, let him hear."

---

## Synthesis Notes

**Key Restorations:**

**Healing on the Sabbath (14:1-6):**
"'He went into the house of one of the rulers of the Pharisees on a sabbath to eat bread.'"

*En tō elthein auton eis oikon tinos tōn archontōn tōn Pharisaiōn sabbatō phagein arton*—Pharisee's house.

"'They were watching him.'"

*Kai autoi ēsan paratēroumenoi auton*—watching.

"'A certain man that had the dropsy.'"

*Anthrōpos tis ēn hydrōpikos emprosthen autou*—dropsy.

**Only Luke:**
This healing unique to Luke.

"''Is it lawful to heal on the sabbath, or not?''"

*Exestin tō sabbatō therapeusai ē ou*—lawful?

"'They held their peace.'"

*Hoi de hēsychasan*—silent.

"''Which of you shall have an ass or an ox fallen into a well?''"

*Tinos hymōn huios ē bous eis phrear peseitai*—well.

**Humility at Banquets (14:7-11):**
"'He marked how they chose out the chief seats.'"

*Epechōn pōs tas prōtoklisias exelegonto*—chief seats.

**Only Luke:**
This teaching unique to Luke.

"''When you are bidden of any man to a marriage feast, sit not down in the chief seat.''"

*Hotan klēthēs hypo tinos eis gamous mē kataklithēs eis tēn prōtoklisian*—not chief.

"''Give this man place'; and then you shall begin with shame to take the lowest place.''"

*Dos toutō topon kai tote arxē meta aischynēs ton eschaton topon katechein*—shame.

"''Go and sit down in the lowest place.''"

*Poreuثeis anapese eis ton eschaton topon*—lowest.

"''Friend, go up higher.''"

*Phile prosanabēthi anōteron*—higher.

"''Every one that exalts himself shall be humbled; and he that humbles himself shall be exalted.''"

*Hoti pas ho hypsōn heauton tapeinōthēsetai kai ho tapeinōn heauton hypsōthēsetai*—humbled/exalted.

**Inviting the Poor (14:12-14):**
"''When you make a dinner or a supper, call not your friends, nor your brethren, nor your kinsmen, nor rich neighbours.''"

*Hotan poiēs ariston ē deipnon mē phōnei tous philous sou mēde tous adelphous sou mēde tous syngeneis sou mēde geitonas plousious*—not friends.

**Only Luke:**
This teaching unique to Luke.

"''Lest haply they also bid you again, and a recompense be made you.''"

*Mēpote kai autoi antikalesōsin se kai genētai antapodoma soi*—reciprocity.

"''Bid the poor, the maimed, the lame, the blind.''"

*Alla hotan dochēn poiēs kalei ptōchous anapeirous chōlous typhlous*—poor, maimed.

"''You shall be recompensed in the resurrection of the just.''"

*Antapodothēsetai gar soi en tē anastasei tōn dikaiōn*—resurrection.

**Great Banquet (14:15-24):**
"''Blessed is he that shall eat bread in the kingdom of God.''"

*Makarios hostis phagetai arton en tē basileia tou theou*—kingdom feast.

"''A certain man made a great supper; and he bade many.''"

*Anthrōpos tis epoiei deipnon mega kai ekalesen pollous*—great supper.

"''Come; for all things are now ready.''"

*Erchesthe hoti ēdē hetoima estin*—ready.

"''I have bought a field, and I must needs go out and see it.''"

*Agron ēgorasa kai echō anankēn exelthōn idein auton*—field.

"''I have bought five yoke of oxen, and I go to prove them.''"

*Zeugē boōn ēgorasa pente kai poreuomai dokimasai auta*—oxen.

"''I have married a wife, and therefore I cannot come.''"

*Gynaika egēma kai dia touto ou dynamai elthein*—wife.

"''Go out quickly into the streets and lanes of the city, and bring in hither the poor and maimed and blind and lame.''"

*Exelthe tacheōs eis tas plateias kai rhymas tēs poleōs kai tous ptōchous kai anapeirous kai typhlous kai chōlous eisagage hōde*—poor.

"''Go out into the highways and hedges, and constrain them to come in.''"

*Exelthe eis tas hodous kai phragmous kai anankason eiselthein*—compel.

"''None of those men that were bidden shall taste of my supper.''"

*Oudeis tōn andrōn ekeinōn tōn keklēmenōn geusetai mou tou deipnou*—excluded.

**Cost of Discipleship (14:25-33):**
"'There went with him great multitudes.'"

*Syneporeuonto de autō ochloi polloi*—multitudes.

"''If any man comes to me, and hates not his own father, and mother, and wife, and children, and brethren, and sisters, yea, and his own life also, he cannot be my disciple.''"

*Ei tis erchetai pros me kai ou misei ton patera heautou kai tēn mētera kai tēn gynaika kai ta tekna kai tous adelphous kai tas adelphas eti te kai tēn psychēn heautou ou dynatai einai mou mathētēs*—hate.

**Semitic Idiom:**
"Hate" = love less by comparison.

"''Whosoever does not bear his own cross, and come after me, cannot be my disciple.''"

*Hostis ou bastazei ton stauron heautou kai erchetai opisō mou ou dynatai einai mou mathētēs*—cross.

"''Which of you, desiring to build a tower, does not first sit down and count the cost?''"

*Tis gar ex hymōn thelōn pyrgon oikodomēsai ouchi prōton kathisas psēphizei tēn dapanēn*—count cost.

**Only Luke:**
Tower and king parables unique to Luke.

"''What king, as he goes to encounter another king in war, will not sit down first and take counsel?''"

*Ē tis basileus poreuomenos heterō basilei symbalein eis polemon ouchi kathisas prōton bouleusetal*—king.

"''Whosoever he be of you that renounces not all that he has, he cannot be my disciple.''"

*Houtōs oun pas ex hymōn hos ouk apotassetai pasin tois heautou hyparchousin ou dynatai einai mou mathētēs*—renounce all.

**Salt without Taste (14:34-35):**
"''If even the salt have lost its savour, wherewith shall it be seasoned?''"

*Ean de kai to halas mōranthē en tini artythēsetai*—lost savour.

"''It is fit neither for the land nor for the dunghill.''"

*Oute eis gēn oute eis koprian eutheton estin*—useless.

"''He that has ears to hear, let him hear.''"

*Ho echōn ōta akouein akouetō*—ears.

**Archetypal Layer:** Luke 14 contains **healing the man with dropsy on sabbath (14:1-6)** (unique to Luke): "Is it lawful to heal on the sabbath?" (14:3), ox or ass in well (14:5), **humility at banquets (14:7-11)** (unique to Luke): don't take chief seat, "Friend, go up higher" (14:10), **"every one that exalts himself shall be humbled; and he that humbles himself shall be exalted" (14:11)**, **inviting the poor (14:12-14)** (unique to Luke): don't invite friends for reciprocity, "bid the poor, the maimed, the lame, the blind" (14:13), **"recompensed in the resurrection of the just" (14:14)**, **the great banquet (14:15-24)**: excuses (field, oxen, wife), **"Go out quickly into the streets... bring in... the poor and maimed and blind and lame" (14:21)**, **"Go out into the highways and hedges, and constrain them to come in" (14:23)**, **cost of discipleship (14:25-33)**: **"If any man comes to me, and hates not his own father... he cannot be my disciple" (14:26)**, "bear his own cross" (14:27), **count the cost (14:28-32)** (unique to Luke): tower builder, king going to war, **"whosoever... renounces not all that he has, he cannot be my disciple" (14:33)**, and **salt without taste (14:34-35)**.

**Modern Equivalent:** Luke 14 is set at a Pharisee's table. Sabbath healing (14:1-6) continues the theme. The teaching on humility (14:7-11) and inviting the poor (14:12-14) subvert social norms. The great banquet (14:15-24) shows the original guests refusing with excuses while the poor, maimed, and outsiders fill the house. The cost of discipleship (14:25-33) is stark: "hate" family (Semitic comparison idiom), bear the cross, count the cost, renounce all. The tower and king parables (14:28-32), unique to Luke, emphasize deliberate commitment.

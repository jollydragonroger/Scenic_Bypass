# Luke 13: Repentance, the Kingdom, and the Narrow Door

*From the Greek: Παρῆσαν δέ τινες ἐν αὐτῷ τῷ καιρῷ (Parēsan de Tines en Autō tō Kairō) — Now There Were Some Present at That Very Season*

---

## Repent or Perish (13:1-5)

**13:1** Now there were some present at that very season who told him of the Galilaeans, whose blood Pilate had mingled with their sacrifices.

**13:2** And he answered and said unto them: "Think you that these Galilaeans were sinners above all the Galilaeans, because they have suffered these things?

**13:3** "I tell you, Nay: but, except you repent, you shall all in like manner perish.

**13:4** "Or those eighteen, upon whom the tower in Siloam fell, and killed them, think you that they were offenders above all the men that dwell in Jerusalem?

**13:5** "I tell you, Nay: but, except you repent, you shall all likewise perish."

---

## The Parable of the Barren Fig Tree (13:6-9)

**13:6** And he spoke this parable: "A certain man had a fig tree planted in his vineyard; and he came seeking fruit thereon, and found none.

**13:7** "And he said unto the vinedresser, 'Behold, these three years I come seeking fruit on this fig tree, and find none: cut it down; why does it also cumber the ground?'

**13:8** "And he answering says unto him, 'Lord, let it alone this year also, till I shall dig about it, and dung it:

**13:9** "'And if it bear fruit thenceforth, well; but if not, you shall cut it down.'"

---

## Healing on the Sabbath (13:10-17)

**13:10** And he was teaching in one of the synagogues on the sabbath day.

**13:11** And behold, a woman that had a spirit of infirmity eighteen years; and she was bowed together, and could in no wise lift herself up.

**13:12** And when Yeshua saw her, he called her, and said to her: "Woman, you are loosed from your infirmity."

**13:13** And he laid his hands upon her: and immediately she was made straight, and glorified God.

**13:14** And the ruler of the synagogue, being moved with indignation because Yeshua had healed on the sabbath, answered and said to the multitude: "There are six days in which men ought to work: in them therefore come and be healed, and not on the day of the sabbath."

**13:15** But the Lord answered him, and said: "You hypocrites, does not each one of you on the sabbath loose his ox or his ass from the stall, and lead him away to watering?

**13:16** "And ought not this woman, being a daughter of Abraham, whom Satan had bound, lo, these eighteen years, to have been loosed from this bond on the day of the sabbath?"

**13:17** And as he said these things, all his adversaries were put to shame: and all the multitude rejoiced for all the glorious things that were done by him.

---

## The Mustard Seed and Leaven (13:18-21)

**13:18** He said therefore: "Unto what is the kingdom of God like? And whereunto shall I liken it?

**13:19** "It is like unto a grain of mustard seed, which a man took, and cast into his own garden; and it grew, and became a tree; and the birds of the heaven lodged in the branches thereof."

**13:20** And again he said: "Whereunto shall I liken the kingdom of God?

**13:21** "It is like unto leaven, which a woman took and hid in three measures of meal, till it was all leavened."

---

## The Narrow Door (13:22-30)

**13:22** And he went on his way through cities and villages, teaching, and journeying on unto Jerusalem.

**13:23** And one said unto him: "Lord, are they few that are saved?" And he said unto them:

**13:24** "Strive to enter in by the narrow door: for many, I say unto you, shall seek to enter in, and shall not be able.

**13:25** "When once the master of the house is risen up, and has shut to the door, and you begin to stand without, and to knock at the door, saying, 'Lord, open to us'; and he shall answer and say to you, 'I know you not whence you are';

**13:26** "Then shall you begin to say, 'We ate and drank in your presence, and you taught in our streets';

**13:27** "And he shall say, 'I tell you, I know not whence you are; depart from me, all you workers of iniquity.'

**13:28** "There shall be the weeping and the gnashing of teeth, when you shall see Abraham, and Isaac, and Jacob, and all the prophets, in the kingdom of God, and yourselves cast forth without.

**13:29** "And they shall come from the east and west, and from the north and south, and shall sit down in the kingdom of God.

**13:30** "And behold, there are last who shall be first, and there are first who shall be last."

---

## Lament over Jerusalem (13:31-35)

**13:31** In that very hour there came certain Pharisees, saying to him: "Get out, and go hence: for Herod would fain kill you."

**13:32** And he said unto them: "Go and say to that fox, Behold, I cast out demons and perform cures today and tomorrow, and the third day I am perfected.

**13:33** "Nevertheless I must go on my way today and tomorrow and the day following: for it cannot be that a prophet perish out of Jerusalem.

**13:34** "O Jerusalem, Jerusalem, that kills the prophets, and stones them that are sent unto her! How often would I have gathered your children together, even as a hen gathers her own brood under her wings, and you would not!

**13:35** "Behold, your house is left unto you desolate: and I say unto you, You shall not see me, until you shall say, 'Blessed is he that comes in the name of the Lord.'"

---

## Synthesis Notes

**Key Restorations:**

**Repent or Perish (13:1-5):**
"'The Galilaeans, whose blood Pilate had mingled with their sacrifices.'"

*Tōn Galilaiōn hōn to haima Pilatos emixen meta tōn thysiōn autōn*—massacre.

**Only Luke:**
This incident unique to Luke.

"''Think you that these Galilaeans were sinners above all the Galilaeans?''"

*Dokeite hoti hoi Galilaioi houtoi hamartōloi para pantas tous Galilaious egenonto*—sinners?

"''Except you repent, you shall all in like manner perish.''"

*Ean mē metanoēte pantes homoiōs apoleisthe*—repent.

"''Those eighteen, upon whom the tower in Siloam fell.''"

*Ekeinoi hoi dekaoktō eph' hous epesen ho pyrgos en tō Silōam*—Siloam.

**Only Luke:**
This incident unique to Luke.

**Barren Fig Tree (13:6-9):**
"''A certain man had a fig tree planted in his vineyard.''"

*Sykēn eichen tis pephyteumenēn en tō ampelōni autou*—fig tree.

**Only Luke:**
This parable unique to Luke.

"''These three years I come seeking fruit on this fig tree, and find none.''"

*Idou tria etē aph' hou erchomai zētōn karpon en tē sykē tautē kai ouch heuriskō*—three years.

"''Cut it down; why does it also cumber the ground?''"

*Ekkoson autēn hina ti kai tēn gēn katargei*—cut down.

"''Lord, let it alone this year also, till I shall dig about it, and dung it.''"

*Kyrie aphes autēn kai touto to etos heōs hotou skapsō peri autēn kai balō kopria*—one more year.

"''If it bear fruit thenceforth, well; but if not, you shall cut it down.''"

*Kan men poiēsē karpon eis to mellon ei de mē ge ekkopseis autēn*—chance.

**Healing on the Sabbath (13:10-17):**
"'A woman that had a spirit of infirmity eighteen years.'"

*Gynē pneuma echousa astheneias etē dekaoktō*—eighteen years.

**Only Luke:**
This healing unique to Luke.

"'She was bowed together, and could in no wise lift herself up.'"

*Kai ēn synkyptousa kai mē dynamienos anakupsai eis to panteles*—bent.

"''Woman, you are loosed from your infirmity.''"

*Gynai apolelusai tēs astheneias sou*—loosed.

"'Immediately she was made straight, and glorified God.'"

*Kai parachrēma anōrthōthē kai edoxazen ton theon*—straight.

"''There are six days in which men ought to work.''"

*Hex hēmerai eisin en hais dei ergazesthai*—six days.

"''You hypocrites, does not each one of you on the sabbath loose his ox or his ass?''"

*Hypokritai hekastos hymōn tō sabbatō ou lyei ton boun autou ē ton onon apo tēs phatnēs*—ox, ass.

"''This woman, being a daughter of Abraham, whom Satan had bound, lo, these eighteen years.''"

*Tautēn de thygatera Abraam ousan hēn edēsen ho Satanas idou deka kai oktō etē*—daughter of Abraham.

"''Ought not... to have been loosed from this bond on the day of the sabbath?''"

*Ouk edei lythēnai apo tou desmou toutou tē hēmera tou sabbatou*—loosed.

**Mustard Seed and Leaven (13:18-21):**
"''It is like unto a grain of mustard seed.''"

*Homoia estin kokkō sinapeōs*—mustard.

"''It grew, and became a tree; and the birds of the heaven lodged in the branches thereof.''"

*Kai ēuxēsen kai egeneto eis dendron kai ta peteina tou ouranou kateskēnōsen en tois kladois autou*—tree.

"''It is like unto leaven, which a woman took and hid in three measures of meal.''"

*Homoia estin zymē hēn labousa gynē ekrypsen eis aleurou sata tria*—leaven.

**Narrow Door (13:22-30):**
"'He went on his way through cities and villages, teaching, and journeying on unto Jerusalem.'"

*Kai dieporeueto kata poleis kai kōmas didaskōn kai poreian poioumenos eis Hierousalēm*—Jerusalem journey.

"''Lord, are they few that are saved?''"

*Kyrie ei oligoi hoi sōzomenoi*—few saved?

"''Strive to enter in by the narrow door.''"

*Agōnizesthe eiselthein dia tēs stenēs thyras*—strive.

**Agōnizomai:**
"Struggle, agonize."

"''Many, I say unto you, shall seek to enter in, and shall not be able.''"

*Polloi legō hymin zētēsousin eiselthein kai ouk ischysousin*—unable.

"''When once the master of the house is risen up, and has shut to the door.''"

*Aph' hou an egerthē ho oikodespotēs kai apokleisē tēn thyran*—shut.

"''We ate and drank in your presence, and you taught in our streets.''"

*Ephagomen enōpion sou kai epiomen kai en tais plateiais hēmōn edidaxas*—ate, drank.

"''I know not whence you are; depart from me, all you workers of iniquity.''"

*Ouk oida hymas pothen este apostēte ap' emou pantes ergatai adikias*—depart.

"''They shall come from the east and west, and from the north and south.''"

*Kai hēxousin apo anatolōn kai dysmōn kai apo borra kai notou*—all directions.

"''There are last who shall be first, and there are first who shall be last.''"

*Kai idou eisin eschatoi hoi esontai prōtoi kai eisin prōtoi hoi esontai eschatoi*—reversal.

**Lament over Jerusalem (13:31-35):**
"''Get out, and go hence: for Herod would fain kill you.''"

*Exelthe kai poreuou enteuthen hoti Hērōdēs thelei se apokteinai*—Herod.

"''Go and say to that fox.''"

*Poreuthentes eipate tē alōpeki tautē*—fox.

"''I cast out demons and perform cures today and tomorrow, and the third day I am perfected.''"

*Idou ekballō daimonia kai iaseis apotelo sēmeron kai aurion kai tē tritē teleioumai*—perfected.

"''It cannot be that a prophet perish out of Jerusalem.''"

*Ouk endechetai prophētēn apolesthai exō Hierousalēm*—prophet in Jerusalem.

"''O Jerusalem, Jerusalem, that kills the prophets.''"

*Hierousalēm Hierousalēm hē apokteinousa tous prophētas*—kills prophets.

"''How often would I have gathered your children together, even as a hen gathers her own brood under her wings.''"

*Posakis ēthelēsa episynaxai ta tekna sou hon tropon ornis tēn heautēs nossian hypo tas pterygas*—hen.

"''Your house is left unto you desolate.''"

*Idou aphietai hymin ho oikos hymōn*—desolate.

"''Blessed is he that comes in the name of the Lord.''"

*Eulogēmenos ho erchomenos en onomati kyriou*—Psalm 118:26.

**Archetypal Layer:** Luke 13 contains **repent or perish (13:1-5)** (unique to Luke): Galileans' blood, tower of Siloam, **"except you repent, you shall all... perish" (13:3, 5)**, **parable of the barren fig tree (13:6-9)** (unique to Luke): three years, one more year, **healing the bent woman on sabbath (13:10-17)** (unique to Luke): "spirit of infirmity eighteen years" (13:11), **"this woman, being a daughter of Abraham, whom Satan had bound" (13:16)**, **mustard seed and leaven (13:18-21)**, **the narrow door (13:22-30)**: **"Strive to enter in by the narrow door" (13:24)**, door shut, "I know you not whence you are" (13:25), **"they shall come from the east and west, and from the north and south" (13:29)**, **"there are last who shall be first" (13:30)**, and **lament over Jerusalem (13:31-35)**: **"Go and say to that fox" (13:32)**, "the third day I am perfected" (13:32), **"it cannot be that a prophet perish out of Jerusalem" (13:33)**, **"O Jerusalem, Jerusalem" (13:34)**, hen gathering brood.

**Modern Equivalent:** Luke 13 calls for repentance. The Galileans' massacre and Siloam tower (13:1-5), unique to Luke, counter the assumption that suffering indicates greater sin. The barren fig tree (13:6-9) warns of judgment with a year's grace. The bent woman (13:10-17), "a daughter of Abraham," is loosed from Satan's bond on the Sabbath. The narrow door (13:22-30) warns against presumption—mere proximity to Yeshua doesn't save. The lament over Jerusalem (13:31-35) shows prophetic grief: "How often would I have gathered your children... and you would not!"

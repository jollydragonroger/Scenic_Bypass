# Luke 18: Persistence in Prayer, Humility, and Following Yeshua

*From the Greek: Ἔλεγεν δὲ παραβολὴν αὐτοῖς (Elegen de Parabolēn Autois) — And He Spoke a Parable unto Them*

---

## The Persistent Widow (18:1-8)

**18:1** And he spoke a parable unto them to the end that they ought always to pray, and not to faint;

**18:2** Saying: "There was in a city a judge, who feared not God, and regarded not man:

**18:3** "And there was a widow in that city; and she came oft unto him, saying, 'Avenge me of my adversary.'

**18:4** "And he would not for a while: but afterward he said within himself, 'Though I fear not God, nor regard man;

**18:5** "'Yet because this widow troubles me, I will avenge her, lest she wear me out by her continual coming.'"

**18:6** And the Lord said: "Hear what the unrighteous judge says.

**18:7** "And shall not God avenge his elect, that cry to him day and night, and yet he is longsuffering over them?

**18:8** "I say unto you, that he will avenge them speedily. Nevertheless, when the Son of man comes, shall he find faith on the earth?"

---

## The Pharisee and the Publican (18:9-14)

**18:9** And he spoke also this parable unto certain who trusted in themselves that they were righteous, and set all others at nought:

**18:10** "Two men went up into the temple to pray; the one a Pharisee, and the other a publican.

**18:11** "The Pharisee stood and prayed thus with himself, 'God, I thank you, that I am not as the rest of men, extortioners, unjust, adulterers, or even as this publican.

**18:12** "'I fast twice in the week; I give tithes of all that I get.'

**18:13** "But the publican, standing afar off, would not lift up so much as his eyes unto heaven, but smote his breast, saying, 'God, be merciful to me a sinner.'

**18:14** "I say unto you, This man went down to his house justified rather than the other: for every one that exalts himself shall be humbled; but he that humbles himself shall be exalted."

---

## Blessing the Children (18:15-17)

**18:15** And they were bringing unto him also their babes, that he should touch them: but when the disciples saw it, they rebuked them.

**18:16** But Yeshua called them unto him, saying: "Suffer the little children to come unto me, and forbid them not: for to such belongs the kingdom of God.

**18:17** "Verily I say unto you, Whosoever shall not receive the kingdom of God as a little child, he shall in no wise enter therein."

---

## The Rich Ruler (18:18-30)

**18:18** And a certain ruler asked him, saying: "Good Teacher, what shall I do to inherit eternal life?"

**18:19** And Yeshua said unto him: "Why do you call me good? None is good, save one, even God.

**18:20** "You know the commandments: Do not commit adultery, Do not kill, Do not steal, Do not bear false witness, Honour your father and mother."

**18:21** And he said: "All these things have I observed from my youth."

**18:22** And when Yeshua heard it, he said unto him: "One thing you lack yet: sell all that you have, and distribute unto the poor, and you shall have treasure in heaven: and come, follow me."

**18:23** But when he heard these things, he became exceeding sorrowful; for he was very rich.

**18:24** And Yeshua seeing him said: "How hardly shall they that have riches enter into the kingdom of God!

**18:25** "For it is easier for a camel to enter in through a needle's eye, than for a rich man to enter into the kingdom of God."

**18:26** And they that heard it said: "Then who can be saved?"

**18:27** But he said: "The things which are impossible with men are possible with God."

**18:28** And Peter said: "Lo, we have left our own, and followed you."

**18:29** And he said unto them: "Verily I say unto you, There is no man that has left house, or wife, or brethren, or parents, or children, for the kingdom of God's sake,

**18:30** "Who shall not receive manifold more in this time, and in the world to come eternal life."

---

## Third Prediction of the Passion (18:31-34)

**18:31** And he took unto him the twelve, and said unto them: "Behold, we go up to Jerusalem, and all the things that are written through the prophets shall be accomplished unto the Son of man.

**18:32** "For he shall be delivered up unto the Gentiles, and shall be mocked, and shamefully treated, and spit upon:

**18:33** "And they shall scourge and kill him: and the third day he shall rise again."

**18:34** And they understood none of these things; and this saying was hid from them, and they perceived not the things that were said.

---

## Healing a Blind Beggar near Jericho (18:35-43)

**18:35** And it came to pass, as he drew near unto Jericho, a certain blind man sat by the way side begging:

**18:36** And hearing a multitude going by, he inquired what this meant.

**18:37** And they told him, that Yeshua of Nazareth passes by.

**18:38** And he cried, saying: "Yeshua, son of David, have mercy on me."

**18:39** And they that went before rebuked him, that he should hold his peace: but he cried out the more a great deal: "Son of David, have mercy on me."

**18:40** And Yeshua stood, and commanded him to be brought unto him: and when he was come near, he asked him:

**18:41** "What will you that I should do unto you?" And he said: "Lord, that I may receive my sight."

**18:42** And Yeshua said unto him: "Receive your sight: your faith has made you whole."

**18:43** And immediately he received his sight, and followed him, glorifying God: and all the people, when they saw it, gave praise unto God.

---

## Synthesis Notes

**Key Restorations:**

**The Persistent Widow (18:1-8):**
"'He spoke a parable unto them to the end that they ought always to pray, and not to faint.'"

*Elegen de parabolēn autois pros to dein pantote proseuchesthai autous kai mē enkakein*—always pray.

**Only Luke:**
This parable unique to Luke.

"''There was in a city a judge, who feared not God, and regarded not man.''"

*Kritēs tis ēn en tini polei ton theon mē phoboumenos kai anthrōpon mē entrepomenos*—unjust judge.

"''There was a widow in that city; and she came oft unto him, saying, Avenge me of my adversary.''"

*Chēra de ēn en tē polei ekeinē kai ērcheto pros auton legousa ekdikēson me apo tou antidikou mou*—avenge.

"''Because this widow troubles me, I will avenge her, lest she wear me out by her continual coming.''"

*Dia ge to parechein moi kopon tēn chēran tautēn ekdikēsō autēn hina mē eis telos erchomenē hypōpiazē me*—wear out.

**Hypōpiazō:**
"Give a black eye/wear out completely."

"''Shall not God avenge his elect, that cry to him day and night?''"

*Ho de theos ou mē poiēsē tēn ekdikēsin tōn eklektōn autou tōn boōntōn autō hēmeras kai nyktos*—elect.

"''He will avenge them speedily.''"

*Poiēsei tēn ekdikēsin autōn en tachei*—speedily.

"''When the Son of man comes, shall he find faith on the earth?''"

*Plēn ho huios tou anthrōpou elthōn ara heurēsei tēn pistin epi tēs gēs*—find faith?

**Pharisee and Publican (18:9-14):**
"'This parable unto certain who trusted in themselves that they were righteous, and set all others at nought.'"

*Eipen de kai pros tinas tous pepoithotas eph' heautois hoti eisin dikaioi kai exouthenountas tous loipous*—self-righteous.

**Only Luke:**
This parable unique to Luke.

"''Two men went up into the temple to pray; the one a Pharisee, and the other a publican.''"

*Anthrōpoi dyo anebēsan eis to hieron proseuxasthai ho heis Pharisaios kai ho heteros telōnēs*—two men.

"''God, I thank you, that I am not as the rest of men.''"

*Ho theos eucharistō soi hoti ouk eimi hōsper hoi loipoi tōn anthrōpōn*—not like others.

"''Extortioners, unjust, adulterers, or even as this publican.''"

*Harpages adikoi moichoi ē kai hōs houtos ho telōnēs*—list.

"''I fast twice in the week; I give tithes of all that I get.''"

*Nēsteuō dis tou sabbatou apodekatō panta hosa ktōmai*—fasting, tithing.

"''The publican, standing afar off, would not lift up so much as his eyes unto heaven.''"

*Ho de telōnēs makrothen hestōs ouk ēthelen oude tous ophthalmous eparai eis ton ouranon*—afar off.

"''Smote his breast, saying, God, be merciful to me a sinner.''"

*All' etypten to stēthos autou legōn ho theos hilasthēti moi tō hamartōlō*—merciful.

**Hilasthēti:**
"Be propitiated/merciful"—Day of Atonement language.

"''This man went down to his house justified rather than the other.''"

*Katebē houtos dedikaiōmenos eis ton oikon autou par' ekeinon*—justified.

"''Every one that exalts himself shall be humbled; but he that humbles himself shall be exalted.''"

*Hoti pas ho hypsōn heauton tapeinōthēsetai ho de tapeinōn heauton hypsōthēsetai*—humbled/exalted.

**Blessing the Children (18:15-17):**
"'They were bringing unto him also their babes, that he should touch them.'"

*Prosepheron de autō kai ta brephē hina autōn haptētai*—babes.

"''Suffer the little children to come unto me, and forbid them not.''"

*Aphete ta paidia erchesthai pros me kai mē kōlyete auta*—let come.

"''To such belongs the kingdom of God.''"

*Tōn gar toioutōn estin hē basileia tou theou*—kingdom.

"''Whosoever shall not receive the kingdom of God as a little child.''"

*Hos an mē dexētai tēn basileian tou theou hōs paidion*—as child.

**Rich Ruler (18:18-30):**
"'A certain ruler asked him.'"

*Epērōtēsen tis auton archōn*—ruler.

**Only Luke:**
Identifies him as a "ruler."

"''Good Teacher, what shall I do to inherit eternal life?''"

*Didaskale agathe ti poiēsas zōēn aiōnion klēronomēsō*—eternal life.

"''Why do you call me good? None is good, save one, even God.''"

*Ti me legeis agathon oudeis agathos ei mē heis ho theos*—God alone good.

"''One thing you lack yet: sell all that you have, and distribute unto the poor.''"

*Eti hen soi leipei panta hosa echeis pōlēson kai diados ptōchois*—sell all.

"''You shall have treasure in heaven: and come, follow me.''"

*Kai hexeis thēsauron en ouranois kai deuro akolouthei moi*—follow.

"'He became exceeding sorrowful; for he was very rich.'"

*Perilypos egenēthē ēn gar plousios sphodra*—very rich.

"''It is easier for a camel to enter in through a needle's eye.''"

*Eukopōteron gar estin kamēlon dia trēmatos belonēs eiselthein*—camel, needle.

"''The things which are impossible with men are possible with God.''"

*Ta adynata para anthrōpois dynata para tō theō estin*—possible with God.

"''There is no man that has left house... for the kingdom of God's sake.''"

*Oudeis estin hos aphēken oikian... heneken tēs basileias tou theou*—left.

"''Who shall not receive manifold more in this time, and in the world to come eternal life.''"

*Hos ouchi mē apolabē pollaplasiona en tō kairō toutō kai en tō aiōni tō erchomenō zōēn aiōnion*—manifold.

**Third Passion Prediction (18:31-34):**
"''Behold, we go up to Jerusalem.''"

*Idou anabainomen eis Hierousalēm*—Jerusalem.

"''All the things that are written through the prophets shall be accomplished unto the Son of man.''"

*Kai telesthēsetai panta ta gegrammena dia tōn prophētōn tō huiō tou anthrōpou*—prophets.

"''He shall be delivered up unto the Gentiles.''"

*Paradothēsetai gar tois ethnesin*—Gentiles.

"''Shall be mocked, and shamefully treated, and spit upon.''"

*Kai empaichthēsetai kai hybristhēsetai kai emptysthēsetai*—mocked.

"''They shall scourge and kill him: and the third day he shall rise again.''"

*Kai mastigōsantes apoktenousin auton kai tē hēmera tē tritē anastēsetai*—scourge, kill, rise.

"'They understood none of these things; and this saying was hid from them.'"

*Kai autoi ouden toutōn synēkan kai ēn to rhēma touto kekrymmenon ap' autōn*—hidden.

**Blind Beggar near Jericho (18:35-43):**
"'As he drew near unto Jericho, a certain blind man sat by the way side begging.'"

*Egeneto de en tō engizein auton eis Ierichō typhlos tis ekathēto para tēn hodon epaitōn*—Jericho.

"''Yeshua, son of David, have mercy on me.''"

*Iēsou huie David eleēson me*—son of David.

"'They that went before rebuked him, that he should hold his peace.'"

*Kai hoi proagontes epetimōn autō hina sigēsē*—rebuked.

"'He cried out the more a great deal: Son of David, have mercy on me.'"

*Autos de pollō mallon ekrazen huie David eleēson me*—cried more.

"''What will you that I should do unto you?' 'Lord, that I may receive my sight.''"

*Ti soi theleis poiēsō ho de eipen kyrie hina anablepsō*—sight.

"''Receive your sight: your faith has made you whole.''"

*Anablepson hē pistis sou sesōken se*—faith.

"'He received his sight, and followed him, glorifying God.'"

*Kai parachrēma aneblepsen kai ēkolouthei autō doxazōn ton theon*—followed.

**Archetypal Layer:** Luke 18 contains **the persistent widow (18:1-8)** (unique to Luke): "they ought always to pray, and not to faint" (18:1), unjust judge, **"shall not God avenge his elect?" (18:7)**, **"when the Son of man comes, shall he find faith on the earth?" (18:8)**, **the Pharisee and the publican (18:9-14)** (unique to Luke): Pharisee thanks God he's not like others, fasts twice, tithes all, publican afar off, **"God, be merciful to me a sinner" (18:13)**, **"This man went down to his house justified rather than the other" (18:14)**, "he that humbles himself shall be exalted" (18:14), **blessing the children (18:15-17)**: "to such belongs the kingdom of God" (18:16), "receive the kingdom of God as a little child" (18:17), **the rich ruler (18:18-30)**: "None is good, save one, even God" (18:19), "One thing you lack yet: sell all" (18:22), "exceeding sorrowful; for he was very rich" (18:23), **"easier for a camel to enter in through a needle's eye" (18:25)**, **"The things which are impossible with men are possible with God" (18:27)**, **third passion prediction (18:31-34)**: most detailed, "they understood none of these things" (18:34), and **healing the blind beggar near Jericho (18:35-43)**: "Son of David, have mercy on me" (18:38), "your faith has made you whole" (18:42).

**Modern Equivalent:** Luke 18 teaches prayer and humility. The persistent widow (18:1-8) encourages perseverance. The Pharisee and publican (18:9-14), unique to Luke, contrasts self-righteousness with repentance—the tax collector goes home justified. Children exemplify kingdom reception (18:15-17). The rich ruler (18:18-30) shows wealth's obstacle, but "with God" impossible things become possible (18:27). The third passion prediction (18:31-34) is most detailed, yet disciples understand nothing. The blind beggar (18:35-43), like the publican, cries for mercy and receives it.

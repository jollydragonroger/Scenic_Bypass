# Luke 8: Parables, Power, and Compassion

*From the Greek: Καὶ ἐγένετο ἐν τῷ καθεξῆς (Kai Egeneto en tō Kathexēs) — And It Came to Pass Soon Afterwards*

---

## Women Who Followed Yeshua (8:1-3)

**8:1** And it came to pass soon afterwards, that he went about through cities and villages, proclaiming and bringing the good tidings of the kingdom of God, and with him the twelve,

**8:2** And certain women who had been healed of evil spirits and infirmities: Mary that was called Magdalene, from whom seven demons had gone out,

**8:3** And Joanna the wife of Chuza Herod's steward, and Susanna, and many others, who ministered unto them of their substance.

---

## The Parable of the Sower (8:4-15)

**8:4** And when a great multitude came together, and they of every city resorted unto him, he spoke by a parable:

**8:5** "The sower went forth to sow his seed: and as he sowed, some fell by the way side; and it was trodden under foot, and the birds of the heaven devoured it.

**8:6** "And other fell on the rock; and as soon as it grew, it withered away, because it had no moisture.

**8:7** "And other fell amidst the thorns; and the thorns grew with it, and choked it.

**8:8** "And other fell into the good ground, and grew, and brought forth fruit a hundredfold." As he said these things, he cried: "He that has ears to hear, let him hear."

**8:9** And his disciples asked him what this parable might be.

**8:10** And he said: "Unto you it is given to know the mysteries of the kingdom of God: but to the rest in parables; that seeing they may not see, and hearing they may not understand.

**8:11** "Now the parable is this: The seed is the word of God.

**8:12** "And those by the way side are they that have heard; then comes the devil, and takes away the word from their heart, that they may not believe and be saved.

**8:13** "And those on the rock are they who, when they have heard, receive the word with joy; and these have no root, who for a while believe, and in time of temptation fall away.

**8:14** "And that which fell among the thorns, these are they that have heard, and as they go on their way they are choked with cares and riches and pleasures of this life, and bring no fruit to perfection.

**8:15** "And that in the good ground, these are such as in an honest and good heart, having heard the word, hold it fast, and bring forth fruit with patience."

---

## The Lamp and the Hidden (8:16-18)

**8:16** "And no man, when he has lighted a lamp, covers it with a vessel, or puts it under a bed; but puts it on a stand, that they that enter in may see the light.

**8:17** "For nothing is hid, that shall not be made manifest; nor anything secret, that shall not be known and come to light.

**8:18** "Take heed therefore how you hear: for whosoever has, to him shall be given; and whosoever has not, from him shall be taken away even that which he thinks he has."

---

## Yeshua's True Kindred (8:19-21)

**8:19** And there came to him his mother and brethren, and they could not come at him for the crowd.

**8:20** And it was told him: "Your mother and your brethren stand without, desiring to see you."

**8:21** But he answered and said unto them: "My mother and my brethren are these that hear the word of God, and do it."

---

## Stilling the Storm (8:22-25)

**8:22** Now it came to pass on one of those days, that he entered into a boat, himself and his disciples; and he said unto them: "Let us go over unto the other side of the lake." And they launched forth.

**8:23** But as they sailed he fell asleep: and there came down a storm of wind on the lake; and they were filling with water, and were in jeopardy.

**8:24** And they came to him, and awoke him, saying: "Master, master, we perish." And he awoke, and rebuked the wind and the raging of the water: and they ceased, and there was a calm.

**8:25** And he said unto them: "Where is your faith?" And being afraid they marvelled, saying one to another: "Who then is this, that he commands even the winds and the water, and they obey him?"

---

## The Gerasene Demoniac (8:26-39)

**8:26** And they arrived at the country of the Gerasenes, which is over against Galilee.

**8:27** And when he was come forth upon the land, there met him a certain man out of the city, who had demons; and for a long time he had worn no clothes, and abode not in any house, but in the tombs.

**8:28** And when he saw Yeshua, he cried out, and fell down before him, and with a loud voice said: "What have I to do with you, Yeshua, Son of the Most High God? I beseech you, torment me not."

**8:29** For he was commanding the unclean spirit to come out from the man. For oftentimes it had seized him: and he was kept under guard, and bound with chains and fetters; and breaking the bands asunder, he was driven of the demon into the deserts.

**8:30** And Yeshua asked him: "What is your name?" And he said: "Legion"; for many demons were entered into him.

**8:31** And they entreated him that he would not command them to depart into the abyss.

**8:32** Now there was there a herd of many swine feeding on the mountain: and they entreated him that he would give them leave to enter into them. And he gave them leave.

**8:33** And the demons came out from the man, and entered into the swine: and the herd rushed down the steep into the lake, and were drowned.

**8:34** And when they that fed them saw what had come to pass, they fled, and told it in the city and in the country.

**8:35** And they went out to see what had come to pass; and they came to Yeshua, and found the man, from whom the demons were gone out, sitting, clothed and in his right mind, at the feet of Yeshua: and they were afraid.

**8:36** And they that saw it told them how he that was possessed with demons was made whole.

**8:37** And all the people of the country of the Gerasenes round about asked him to depart from them; for they were holden with great fear: and he entered into a boat, and returned.

**8:38** But the man from whom the demons were gone out prayed him that he might be with him: but he sent him away, saying:

**8:39** "Return to your house, and declare how great things God has done for you." And he went his way, publishing throughout the whole city how great things Yeshua had done for him.

---

## Jairus's Daughter and the Woman with the Issue (8:40-56)

**8:40** And as Yeshua returned, the multitude welcomed him; for they were all waiting for him.

**8:41** And behold, there came a man named Jairus, and he was a ruler of the synagogue: and he fell down at Yeshua's feet, and besought him to come into his house;

**8:42** For he had an only daughter, about twelve years of age, and she was dying. But as he went the multitudes thronged him.

**8:43** And a woman having an issue of blood twelve years, who had spent all her living upon physicians, and could not be healed of any,

**8:44** Came behind him, and touched the border of his garment: and immediately the issue of her blood stanched.

**8:45** And Yeshua said: "Who is it that touched me?" And when all denied, Peter said, and they that were with him: "Master, the multitudes press you and crush you."

**8:46** But Yeshua said: "Some one did touch me; for I perceived that power had gone forth from me."

**8:47** And when the woman saw that she was not hid, she came trembling, and falling down before him declared in the presence of all the people for what cause she touched him, and how she was healed immediately.

**8:48** And he said unto her: "Daughter, your faith has made you whole; go in peace."

**8:49** While he yet spoke, there comes one from the ruler of the synagogue's house, saying: "Your daughter is dead; trouble not the Teacher."

**8:50** But Yeshua hearing it, answered him: "Fear not: only believe, and she shall be made whole."

**8:51** And when he came to the house, he permitted not any man to enter in with him, save Peter, and John, and James, and the father of the maiden and her mother.

**8:52** And all were weeping, and bewailing her: but he said: "Weep not; for she is not dead, but sleeps."

**8:53** And they laughed him to scorn, knowing that she was dead.

**8:54** But he, taking her by the hand, called, saying: "Maiden, arise."

**8:55** And her spirit returned, and she rose up immediately: and he commanded that something be given her to eat.

**8:56** And her parents were amazed: but he charged them to tell no man what had been done.

---

## Synthesis Notes

**Key Restorations:**

**Women Who Followed Yeshua (8:1-3):**
"'He went about through cities and villages, proclaiming and bringing the good tidings of the kingdom of God.'"

*Kai autos diōdeusen kata polin kai kōmēn kēryssōn kai euangelizomenos tēn basileian tou theou*—proclaiming.

"'Mary that was called Magdalene, from whom seven demons had gone out.'"

*Maria hē kaloumenē Magdalēnē aph' hēs daimonia hepta exelēlythei*—Magdalene.

"'Joanna the wife of Chuza Herod's steward.'"

*Kai Iōanna gynē Chouza epitropou Hērōdou*—Joanna.

**Only Luke:**
This unique passage about women supporters.

"'Who ministered unto them of their substance.'"

*Haitines diēkonoun autois ek tōn hyparchontōn autais*—financial support.

**Parable of the Sower (8:4-15):**
"''The sower went forth to sow his seed.''"

*Exēlthen ho speirōn tou speirai ton sporon autou*—sower.

"''He that has ears to hear, let him hear.''"

*Ho echōn ōta akouein akouetō*—ears.

"''Unto you it is given to know the mysteries of the kingdom of God.''"

*Hymin dedotai gnōnai ta mystēria tēs basileias tou theou*—mysteries.

"''The seed is the word of God.''"

*Ho sporos estin ho logos tou theou*—word.

"''Then comes the devil, and takes away the word from their heart, that they may not believe and be saved.''"

*Eita erchetai ho diabolos kai airei ton logon apo tēs kardias autōn hina mē pisteusantes sōthōsin*—believe, saved.

"''In time of temptation fall away.''"

*En kairō peirasmou aphistantai*—fall away.

"''Choked with cares and riches and pleasures of this life.''"

*Hypo merimnōn kai ploutou kai hēdonōn tou biou*—pleasures.

"''In an honest and good heart, having heard the word, hold it fast, and bring forth fruit with patience.''"

*En kardia kalē kai agathē akousantes ton logon katechousin kai karpophorousin en hypomonē*—patience.

**Lamp and the Hidden (8:16-18):**
"''No man, when he has lighted a lamp, covers it with a vessel.''"

*Oudeis de lychnon hapsas kalyptei auton skeuei*—lamp.

"''Nothing is hid, that shall not be made manifest.''"

*Ou gar estin krypton ho ou phaneron genēsetai*—manifest.

"''Take heed therefore how you hear.''"

*Blepete oun pōs akouete*—how you hear.

**Yeshua's True Kindred (8:19-21):**
"''My mother and my brethren are these that hear the word of God, and do it.''"

*Mētēr mou kai adelphoi mou houtoi eisin hoi ton logon tou theou akouontes kai poiountes*—hear and do.

**Stilling the Storm (8:22-25):**
"'As they sailed he fell asleep.'"

*Pleontōn de autōn aphypnōsen*—asleep.

"'A storm of wind on the lake.'"

*Kai katebē lailaps anemou eis tēn limnēn*—storm.

"''Master, master, we perish.''"

*Epistata epistata apollymetha*—perish.

"'He awoke, and rebuked the wind and the raging of the water.'"

*Ho de diegertheis epetimēsen tō anemō kai tō klydōni tou hydatos*—rebuked.

"''Where is your faith?''"

*Pou hē pistis hymōn*—where faith?

"''Who then is this, that he commands even the winds and the water, and they obey him?''"

*Tis ara houtos estin hoti kai tois anemois epitassei kai tō hydati kai hypakouousin autō*—who?

**Gerasene Demoniac (8:26-39):**
"'A certain man out of the city, who had demons.'"

*Anēr tis ek tēs poleōs echōn daimonia*—demons.

"'For a long time he had worn no clothes, and abode not in any house, but in the tombs.'"

*Kai chronō hikanō ouk enedysato himation kai en oikia ouk emenen all' en tois mnēmasin*—tombs.

"''What have I to do with you, Yeshua, Son of the Most High God?''"

*Ti emoi kai soi Iēsou huie tou theou tou hypsistou*—Most High.

"''What is your name?' And he said: 'Legion.''"

*Ti soi onoma estin ho de eipen Legiōn*—Legion.

"'They entreated him that he would not command them to depart into the abyss.'"

*Kai parekaloun auton hina mē epitaxē autois eis tēn abysson apelthein*—abyss.

**Abyssos:**
"Bottomless pit"—place of demonic imprisonment.

"'The herd rushed down the steep into the lake, and were drowned.'"

*Kai hōrmēsen hē agelē kata tou krēmnou eis tēn limnēn kai apepnigē*—drowned.

"'Sitting, clothed and in his right mind, at the feet of Yeshua.'"

*Kathēmenon himatismenon kai sōphronounta para tous podas tou Iēsou*—transformed.

"''Return to your house, and declare how great things God has done for you.''"

*Hypostrephe eis ton oikon sou kai diēgou hosa soi epoiēsen ho theos*—declare.

"'He went his way, publishing throughout the whole city how great things Yeshua had done for him.'"

*Kath' holēn tēn polin kēryssōn hosa epoiēsen autō ho Iēsous*—Yeshua = God.

**Jairus's Daughter and the Woman (8:40-56):**
"'A man named Jairus, and he was a ruler of the synagogue.'"

*Anēr hō onoma Iairos kai houtos archōn tēs synagōgēs hypērchen*—Jairus.

"'He had an only daughter, about twelve years of age, and she was dying.'"

*Hoti thugatēr monogenēs ēn autō hōs etōn dōdeka kai autē apethnēsken*—only daughter.

"'A woman having an issue of blood twelve years.'"

*Kai gynē ousa en rhysei haimatos apo etōn dōdeka*—twelve years.

"'Had spent all her living upon physicians, and could not be healed of any.'"

*Hētis iatrois prosanalōsasa holon ton bion ouk ischysen hyp' oudenos therapeuθēnai*—couldn't heal.

"'Touched the border of his garment: and immediately the issue of her blood stanched.'"

*Hēpsato tou kraspedou tou himatiou autou kai parachrēma estē hē rhysis tou haimatos autēs*—stanched.

"''Who is it that touched me?''"

*Tis ho hapsamenos mou*—who touched?

"''I perceived that power had gone forth from me.''"

*Egō gar egnōn dynamin exelēlythuian ap' emou*—power.

"''Daughter, your faith has made you whole; go in peace.''"

*Thugatēr hē pistis sou sesōken se poreuou eis eirēnēn*—faith saves.

"''Your daughter is dead; trouble not the Teacher.''"

*Tethnēken hē thugatēr sou mēketi skylle ton didaskalon*—dead.

"''Fear not: only believe, and she shall be made whole.''"

*Mē phobou monon pisteuson kai sōthēsetai*—believe.

"'He permitted not any man to enter in with him, save Peter, and John, and James.'"

*Ouk aphēken eiselthein tina syn autō ei mē Petron kai Iōannēn kai Iakōbon*—inner three.

"''Weep not; for she is not dead, but sleeps.''"

*Mē klaiete ou gar apethanen alla katheudei*—sleeps.

"''Maiden, arise.''"

*Hē pais egeire*—arise.

"'Her spirit returned, and she rose up immediately.'"

*Kai epestrepsen to pneuma autēs kai anestē parachrēma*—spirit returned.

**Archetypal Layer:** Luke 8 contains **women who followed Yeshua (8:1-3)** (unique to Luke): Mary Magdalene, Joanna, Susanna, "who ministered unto them of their substance," **parable of the sower (8:4-15)**: "The seed is the word of God" (8:11), "bring forth fruit with patience" (8:15), **lamp on a stand (8:16-18)**: "Take heed therefore how you hear" (8:18), **Yeshua's true kindred (8:19-21)**: "hear the word of God, and do it," **stilling the storm (8:22-25)**: "Where is your faith?" (8:25), "Who then is this?" (8:25), **Gerasene demoniac (8:26-39)**: "Son of the Most High God" (8:28), "Legion" (8:30), demons into abyss/swine (8:31-33), "sitting, clothed and in his right mind" (8:35), "declare how great things God has done for you" (8:39), and **Jairus's daughter and the woman (8:40-56)**: only daughter, twelve years, "I perceived that power had gone forth from me" (8:46), **"Daughter, your faith has made you whole" (8:48)**, **"Fear not: only believe" (8:50)**, "Maiden, arise" (8:54).

**Modern Equivalent:** Luke 8 highlights women's roles (8:1-3)—unique to Luke, showing women as financial supporters of Yeshua's ministry. The sower parable (8:4-15) emphasizes patience (8:15). True family is defined by hearing and doing God's word (8:21). The storm stilling (8:22-25) prompts the question "Who is this?" The Gerasene demoniac (8:26-39) shows transformation from chaos to sanity. The intercalated story of Jairus's daughter and the hemorrhaging woman (8:40-56) connects two "daughters" and the number twelve. Faith saves and heals (8:48, 50).

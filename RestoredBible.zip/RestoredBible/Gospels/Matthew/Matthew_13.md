# Matthew 13: The Parables of the Kingdom

*From the Greek: Ἐν τῇ ἡμέρᾳ ἐκείνῃ ἐξελθὼν ὁ Ἰησοῦς (En tē Hēmera Ekeinē Exelthōn ho Iesous) — On That Day Yeshua Went Out*

---

## The Parable of the Sower (13:1-23)

**13:1** On that day went Yeshua out of the house, and sat by the sea side.

**13:2** And there were gathered unto him great multitudes, so that he entered into a boat, and sat; and all the multitude stood on the beach.

**13:3** And he spoke to them many things in parables, saying: "Behold, the sower went forth to sow;

**13:4** "And as he sowed, some seeds fell by the way side, and the birds came and devoured them:

**13:5** "And others fell upon the rocky places, where they had not much earth: and straightway they sprang up, because they had no deepness of earth:

**13:6** "And when the sun was risen, they were scorched; and because they had no root, they withered away.

**13:7** "And others fell upon the thorns; and the thorns grew up and choked them:

**13:8** "And others fell upon the good ground, and yielded fruit, some a hundredfold, some sixty, some thirty.

**13:9** "He that has ears, let him hear."

**13:10** And the disciples came, and said unto him: "Why do you speak unto them in parables?"

**13:11** And he answered and said unto them: "Unto you it is given to know the mysteries of the kingdom of heaven, but to them it is not given.

**13:12** "For whosoever has, to him shall be given, and he shall have abundance: but whosoever has not, from him shall be taken away even that which he has.

**13:13** "Therefore speak I to them in parables; because seeing they see not, and hearing they hear not, neither do they understand.

**13:14** "And unto them is fulfilled the prophecy of Isaiah, which says: 'By hearing you shall hear, and shall in no wise understand; and seeing you shall see, and shall in no wise perceive:

**13:15** "'For this people's heart is waxed gross, and their ears are dull of hearing, and their eyes they have closed; lest haply they should perceive with their eyes, and hear with their ears, and understand with their heart, and should turn again, and I should heal them.'

**13:16** "But blessed are your eyes, for they see; and your ears, for they hear.

**13:17** "For verily I say unto you, that many prophets and righteous men desired to see the things which you see, and saw them not; and to hear the things which you hear, and heard them not.

**13:18** "Hear then the parable of the sower.

**13:19** "When any one hears the word of the kingdom, and understands it not, then comes the evil one, and snatches away that which has been sown in his heart. This is he that was sown by the way side.

**13:20** "And he that was sown upon the rocky places, this is he that hears the word, and straightway with joy receives it;

**13:21** "Yet has he not root in himself, but endures for a while; and when tribulation or persecution arises because of the word, straightway he stumbles.

**13:22** "And he that was sown among the thorns, this is he that hears the word; and the care of the world, and the deceitfulness of riches, choke the word, and he becomes unfruitful.

**13:23** "And he that was sown upon the good ground, this is he that hears the word, and understands it; who verily bears fruit, and brings forth, some a hundredfold, some sixty, some thirty."

---

## The Parable of the Tares (13:24-30, 36-43)

**13:24** Another parable set he before them, saying: "The kingdom of heaven is likened unto a man that sowed good seed in his field:

**13:25** "But while men slept, his enemy came and sowed tares also among the wheat, and went away.

**13:26** "But when the blade sprang up and brought forth fruit, then appeared the tares also.

**13:27** "And the servants of the householder came and said unto him: 'Sir, did you not sow good seed in your field? Whence then has it tares?'

**13:28** "And he said unto them: 'An enemy has done this.' And the servants say unto him: 'Will you then that we go and gather them up?'

**13:29** "But he says: 'Nay; lest haply while you gather up the tares, you root up the wheat with them.

**13:30** "'Let both grow together until the harvest: and in the time of the harvest I will say to the reapers, Gather up first the tares, and bind them in bundles to burn them; but gather the wheat into my barn.'"

---

## Parables of Mustard Seed and Leaven (13:31-35)

**13:31** Another parable set he before them, saying: "The kingdom of heaven is like unto a grain of mustard seed, which a man took, and sowed in his field:

**13:32** "Which indeed is less than all seeds; but when it is grown, it is greater than the herbs, and becomes a tree, so that the birds of the heaven come and lodge in the branches thereof."

**13:33** Another parable spoke he unto them: "The kingdom of heaven is like unto leaven, which a woman took, and hid in three measures of meal, till it was all leavened."

**13:34** All these things spoke Yeshua in parables unto the multitudes; and without a parable spoke he nothing unto them:

**13:35** That it might be fulfilled which was spoken through the prophet, saying: "I will open my mouth in parables; I will utter things hidden from the foundation of the world."

---

## Explanation of the Tares (13:36-43)

**13:36** Then he left the multitudes, and went into the house: and his disciples came unto him, saying: "Explain unto us the parable of the tares of the field."

**13:37** And he answered and said: "He that sows the good seed is the Son of man;

**13:38** "And the field is the world; and the good seed, these are the sons of the kingdom; and the tares are the sons of the evil one;

**13:39** "And the enemy that sowed them is the devil; and the harvest is the end of the world; and the reapers are angels.

**13:40** "As therefore the tares are gathered up and burned with fire; so shall it be in the end of the world.

**13:41** "The Son of man shall send forth his angels, and they shall gather out of his kingdom all things that cause stumbling, and them that do iniquity,

**13:42** "And shall cast them into the furnace of fire: there shall be the weeping and the gnashing of teeth.

**13:43** "Then shall the righteous shine forth as the sun in the kingdom of their Father. He that has ears, let him hear."

---

## Parables of Treasure, Pearl, and Net (13:44-50)

**13:44** "The kingdom of heaven is like unto a treasure hidden in the field; which a man found, and hid; and in his joy he goes and sells all that he has, and buys that field.

**13:45** "Again, the kingdom of heaven is like unto a man that is a merchant seeking goodly pearls:

**13:46** "And having found one pearl of great price, he went and sold all that he had, and bought it.

**13:47** "Again, the kingdom of heaven is like unto a net, that was cast into the sea, and gathered of every kind:

**13:48** "Which, when it was filled, they drew up on the beach; and they sat down, and gathered the good into vessels, but the bad they cast away.

**13:49** "So shall it be in the end of the world: the angels shall come forth, and sever the wicked from among the righteous,

**13:50** "And shall cast them into the furnace of fire: there shall be the weeping and the gnashing of teeth."

---

## The Householder and Rejection at Nazareth (13:51-58)

**13:51** "Have you understood all these things?" They say unto him: "Yea."

**13:52** And he said unto them: "Therefore every scribe who has been made a disciple to the kingdom of heaven is like unto a man that is a householder, who brings forth out of his treasure things new and old."

**13:53** And it came to pass, when Yeshua had finished these parables, he departed thence.

**13:54** And coming into his own country he taught them in their synagogue, insomuch that they were astonished, and said: "Whence has this man this wisdom, and these mighty works?

**13:55** "Is not this the carpenter's son? Is not his mother called Mary? And his brethren, James, and Joseph, and Simon, and Judas?

**13:56** "And his sisters, are they not all with us? Whence then has this man all these things?"

**13:57** And they were offended in him. But Yeshua said unto them: "A prophet is not without honour, save in his own country, and in his own house."

**13:58** And he did not many mighty works there because of their unbelief.

---

## Synthesis Notes

**Key Restorations:**

**Parable of the Sower (13:1-23):**
**The Key Verses (13:3-9):**
"''The sower went forth to sow.''"

*Idou exēlthen ho speirōn tou speirein*—sower.

**Four Soils:**
Wayside (birds devour), rocky (no root), thorns (choked), good ground (fruit).

"''Some a hundredfold, some sixty, some thirty.''"

*Ho men hekaton ho de hexēkonta ho de triakonta*—yields.

**The Key Verses (13:10-17):**
"''Why do you speak unto them in parables?''"

*Dia ti en parabolais laleis autois*—why parables?

"''Unto you it is given to know the mysteries of the kingdom of heaven.''"

*Hymin dedotai gnōnai ta mystēria tēs basileias tōn ouranōn*—mysteries.

"''Whosoever has, to him shall be given... whosoever has not, from him shall be taken away.''"

*Hostis gar echei dothēsetai autō... hostis de ouk echei kai ho echei arthēsetai ap' autou*—paradox.

**Isaiah 6:9-10:**
"''By hearing you shall hear, and shall in no wise understand.''"

"''Blessed are your eyes, for they see; and your ears, for they hear.''"

*Hymōn de makarioi hoi ophthalmoi hoti blepousin kai ta ōta hymōn hoti akouousin*—blessed.

**The Key Verses (13:18-23):**
**Interpretation:**
Wayside = doesn't understand, evil one snatches.
Rocky = no root, stumbles at persecution.
Thorns = cares of world, deceitfulness of riches choke.
Good ground = hears, understands, bears fruit.

**Parable of the Tares (13:24-30, 36-43):**
**The Key Verses (13:24-30):**
"''The kingdom of heaven is likened unto a man that sowed good seed.''"

*Hōmoiōthē hē basileia tōn ouranōn anthrōpō speiranti kalon sperma*—good seed.

"''His enemy came and sowed tares also among the wheat.''"

*Ēlthen autou ho echthros kai epespeiren zizania ana meson tou sitou*—tares.

**Zizania:**
Darnel—looks like wheat until harvest.

"''Let both grow together until the harvest.''"

*Aphete synauxanesthai amphotera heōs tou therismou*—together.

**The Key Verses (13:37-43):**
"''He that sows the good seed is the Son of man.''"

*Ho speirōn to kalon sperma estin ho huios tou anthrōpou*—Son of man.

"''The field is the world.''"

*Ho de agros estin ho kosmos*—world.

"''The good seed... are the sons of the kingdom.''"

*To de kalon sperma houtoi eisin hoi huioi tēs basileias*—sons of kingdom.

"''The tares are the sons of the evil one.''"

*Ta de zizania eisin hoi huioi tou ponērou*—sons of evil.

"''The harvest is the end of the world.''"

*Ho de therismos synteleia aiōnos estin*—end of age.

"''Then shall the righteous shine forth as the sun.''"

*Tote hoi dikaioi eklampsoúsin hōs ho hēlios*—shine.

**Daniel 12:3.**

**Mustard Seed and Leaven (13:31-35):**
**The Key Verses (13:31-33):**
"''The kingdom of heaven is like unto a grain of mustard seed.''"

*Homoia estin hē basileia tōn ouranōn kokkō sinapeōs*—mustard seed.

"''Less than all seeds; but when it is grown, it is greater than the herbs.''"

*Ho mikroteron... meizon tōn lachanōn estin*—small to great.

"''The birds of the heaven come and lodge in the branches.''"

*Ta peteina tou ouranou kai kataskēnoun en tois kladois autou*—birds lodge.

"''The kingdom of heaven is like unto leaven.''"

*Homoia estin hē basileia tōn ouranōn zymē*—leaven.

"''Till it was all leavened.''"

*Heōs hou ezymōthē holon*—all leavened.

**Psalm 78:2:**
"''I will open my mouth in parables.''"

**Treasure, Pearl, Net (13:44-50):**
**The Key Verses (13:44-50):**
"''The kingdom of heaven is like unto a treasure hidden in the field.''"

*Homoia estin hē basileia tōn ouranōn thēsaurō kekrymmenō en tō agrō*—treasure.

"''In his joy he goes and sells all that he has, and buys that field.''"

*Apo tēs charas autou hypagei kai pōlei panta hosa echei kai agorazei ton agron ekeinon*—sells all.

"''One pearl of great price.''"

*Hena polytimon margaritēn*—great pearl.

"''He went and sold all that he had, and bought it.''"

*Apelthōn pepraken panta hosa eichen kai ēgorasen auton*—bought.

"''A net, that was cast into the sea, and gathered of every kind.''"

*Sagēnē blētheisē eis tēn thalassan kai ek pantos genous synagagousē*—net.

"''Gathered the good into vessels, but the bad they cast away.''"

*Synelexan ta kala eis angē ta de sapra exō ebalon*—sort.

"''The angels shall come forth, and sever the wicked from among the righteous.''"

*Exeleusontai hoi angeloi kai aphoriousin tous ponērous ek mesou tōn dikaiōn*—sever.

**Rejection at Nazareth (13:51-58):**
**The Key Verses (13:51-58):**
"''Every scribe who has been made a disciple to the kingdom of heaven.''"

*Pas grammateus mathēteutheis tē basileia tōn ouranōn*—scribe-disciple.

"''Brings forth out of his treasure things new and old.''"

*Ekballei ek tou thēsaurou autou kaina kai palaia*—new and old.

"''Is not this the carpenter's son?''"

*Ouch houtos estin ho tou tektonos huios*—carpenter's son.

"''Is not his mother called Mary? And his brethren, James, and Joseph, and Simon, and Judas?''"

*Ouch hē mētēr autou legetai Mariam kai hoi adelphoi autou Iakōbos kai Iōsēph kai Simōn kai Ioudas*—family.

"''A prophet is not without honour, save in his own country.''"

*Ouk estin prophētēs atimos ei mē en tē patridi kai en tē oikia autou*—prophet.

"'He did not many mighty works there because of their unbelief.'"

*Kai ouk epoiēsen ekei dynameis pollas dia tēn apistian autōn*—unbelief.

**Archetypal Layer:** Matthew 13 is the **parable chapter**, containing **parable of the sower and four soils (13:3-23)**, **"Unto you it is given to know the mysteries of the kingdom of heaven" (13:11)**, **Isaiah 6:9-10 fulfilled (13:14-15)**, **"blessed are your eyes, for they see" (13:16)**, **parable of the tares (13:24-30, 36-43)**, **mustard seed (13:31-32)**, **leaven (13:33)**, **"I will open my mouth in parables" (Psalm 78:2) (13:35)**, **"The Son of man shall send forth his angels... the righteous shine forth as the sun" (13:41-43)**, **hidden treasure (13:44)**, **pearl of great price (13:45-46)**, **dragnet (13:47-50)**, **"things new and old" (13:52)**, and **rejection at Nazareth: "A prophet is not without honour, save in his own country" (13:57)**.

**Modern Equivalent:** Matthew 13 contains seven parables of the kingdom. The sower parable (13:3-23) explains varied responses to the word. The tares (13:24-30) teach patience—judgment waits until harvest. Mustard seed and leaven (13:31-33) show small beginnings with great results. Treasure and pearl (13:44-46) emphasize the kingdom's supreme value—worth everything. The net (13:47-50) returns to judgment themes. Rejection at Nazareth (13:54-58) shows familiarity breeding contempt—unbelief limits even Yeshua's works.

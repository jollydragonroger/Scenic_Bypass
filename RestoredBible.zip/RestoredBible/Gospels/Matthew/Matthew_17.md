# Matthew 17: The Transfiguration and Faith

*From the Greek: Καὶ μεθ᾽ ἡμέρας ἓξ (Kai Meth' Hēmeras Hex) — And After Six Days*

---

## The Transfiguration (17:1-13)

**17:1** And after six days Yeshua takes with him Peter, and James, and John his brother, and brings them up into a high mountain apart:

**17:2** And he was transfigured before them; and his face did shine as the sun, and his garments became white as the light.

**17:3** And behold, there appeared unto them Moses and Elijah talking with him.

**17:4** And Peter answered, and said unto Yeshua: "Lord, it is good for us to be here: if you will, I will make here three tabernacles; one for you, and one for Moses, and one for Elijah."

**17:5** While he was yet speaking, behold, a bright cloud overshadowed them: and behold, a voice out of the cloud, saying: "This is my beloved Son, in whom I am well pleased; hear him."

**17:6** And when the disciples heard it, they fell on their face, and were sore afraid.

**17:7** And Yeshua came and touched them and said: "Arise, and be not afraid."

**17:8** And lifting up their eyes, they saw no one, save Yeshua only.

**17:9** And as they were coming down from the mountain, Yeshua commanded them, saying: "Tell the vision to no man, until the Son of man be risen from the dead."

**17:10** And his disciples asked him, saying: "Why then say the scribes that Elijah must first come?"

**17:11** And he answered and said: "Elijah indeed comes, and shall restore all things:

**17:12** "But I say unto you, that Elijah is come already, and they knew him not, but did unto him whatsoever they would. Even so shall the Son of man also suffer of them."

**17:13** Then understood the disciples that he spoke unto them of John the Immerser.

---

## The Demon-Possessed Boy (17:14-21)

**17:14** And when they were come to the multitude, there came to him a man, kneeling to him, and saying:

**17:15** "Lord, have mercy on my son: for he is epileptic, and suffers grievously; for oft-times he falls into the fire, and oft-times into the water.

**17:16** "And I brought him to your disciples, and they could not cure him."

**17:17** And Yeshua answered and said: "O faithless and perverse generation, how long shall I be with you? How long shall I bear with you? Bring him here to me."

**17:18** And Yeshua rebuked him; and the demon went out from him: and the boy was cured from that hour.

**17:19** Then came the disciples to Yeshua apart, and said: "Why could not we cast it out?"

**17:20** And he says unto them: "Because of your little faith: for verily I say unto you, If you have faith as a grain of mustard seed, you shall say unto this mountain, 'Remove hence to yonder place'; and it shall remove; and nothing shall be impossible unto you.

**17:21** [But this kind goes not out save by prayer and fasting.]

---

## Second Prediction of the Passion (17:22-23)

**17:22** And while they abode in Galilee, Yeshua said unto them: "The Son of man shall be delivered up into the hands of men;

**17:23** "And they shall kill him, and the third day he shall be raised up." And they were exceeding sorry.

---

## The Temple Tax (17:24-27)

**17:24** And when they were come to Capernaum, they that received the half-shekel came to Peter, and said: "Does not your teacher pay the half-shekel?"

**17:25** He says: "Yea." And when he came into the house, Yeshua spoke first to him, saying: "What think you, Simon? The kings of the earth, from whom do they receive toll or tribute? From their sons, or from strangers?"

**17:26** And when he said: "From strangers," Yeshua said unto him: "Therefore the sons are free.

**17:27** "But, lest we cause them to stumble, go to the sea, and cast a hook, and take up the fish that first comes up; and when you have opened his mouth, you shall find a shekel: that take, and give unto them for me and for you."

---

## Synthesis Notes

**Key Restorations:**

**The Transfiguration (17:1-13):**
**The Key Verses (17:1-3):**
"'After six days Yeshua takes with him Peter, and James, and John.'"

*Kai meth' hēmeras hex paralambanei ho Iēsous ton Petron kai Iakōbon kai Iōannēn ton adelphon autou*—inner three.

"'Brings them up into a high mountain apart.'"

*Kai anapherei autous eis oros hypsēlon kat' idian*—high mountain.

**Traditionally:**
Mount Tabor or Mount Hermon.

"'He was transfigured before them.'"

*Kai metemorphōthē emprosthen autōn*—transfigured.

**Metamorphoō:**
"Changed in form"—same root as "metamorphosis."

"'His face did shine as the sun.'"

*Kai elampsen to prosōpon autou hōs ho hēlios*—shining face.

**Echoes Moses:**
Exodus 34:29-35—Moses' shining face.

"'His garments became white as the light.'"

*Ta de himatia autou egeneto leuka hōs to phōs*—white garments.

"'There appeared unto them Moses and Elijah talking with him.'"

*Kai idou ōphthē autois Mōusēs kai Ēlias syllalountes met' autou*—Moses, Elijah.

**Moses and Elijah:**
Law and Prophets; both had unusual departures from earth.

**The Key Verses (17:4-8):**
"''Lord, it is good for us to be here.''"

*Kyrie kalon estin hēmas hōde einai*—good to be here.

"''If you will, I will make here three tabernacles.''"

*Ei theleis poiēsō hōde treis skēnas*—three tabernacles.

"'A bright cloud overshadowed them.'"

*Idou nephelē phōteinē epeskiasen autous*—bright cloud.

**Shekinah:**
Divine presence cloud.

"''This is my beloved Son, in whom I am well pleased; hear him.''"

*Houtos estin ho huios mou ho agapētos en hō eudokēsa akouete autou*—beloved Son.

**Hear Him:**
Added to baptism declaration—Deuteronomy 18:15 (prophet like Moses).

"'They fell on their face, and were sore afraid.'"

*Kai akousantes hoi mathētai epesan epi prosōpon autōn kai ephobēthēsan sphodra*—afraid.

"''Arise, and be not afraid.''"

*Egerthēte kai mē phobeisthe*—don't fear.

"'They saw no one, save Yeshua only.'"

*Ouden eidon ei mē auton Iēsoun monon*—Yeshua alone.

**The Key Verses (17:9-13):**
"''Tell the vision to no man, until the Son of man be risen from the dead.''"

*Mēdeni eipēte to horama heōs hou ho huios tou anthrōpou ek nekrōn egerthē*—secrecy.

"''Why then say the scribes that Elijah must first come?''"

*Ti oun hoi grammateis legousin hoti Ēlian dei elthein prōton*—Elijah first.

**Malachi 4:5.**

"''Elijah indeed comes, and shall restore all things.''"

*Ēlias men erchetai kai apokatastēsei panta*—restore.

"''Elijah is come already, and they knew him not.''"

*Legō de hymin hoti Ēlias ēdē ēlthen kai ouk epegnōsan auton*—already came.

"'They... did unto him whatsoever they would.'"

*Alla epoiēsan en autō hosa ēthelēsan*—did what they wanted.

"'Then understood the disciples that he spoke unto them of John the Immerser.'"

*Tote synēkan hoi mathētai hoti peri Iōannou tou baptistou eipen autois*—John.

**Demon-Possessed Boy (17:14-21):**
**The Key Verses (17:14-18):**
"''Have mercy on my son: for he is epileptic, and suffers grievously.''"

*Kyrie eleēson mou ton huion hoti selēniazetai kai kakōs paschei*—epileptic.

**Selēniazomai:**
"Moonstruck"—ancient term for epilepsy.

"''Oft-times he falls into the fire, and oft-times into the water.''"

*Pollakis gar piptei eis to pyr kai pollakis eis to hydōr*—dangerous.

"''I brought him to your disciples, and they could not cure him.''"

*Kai prosēnenka auton tois mathētais sou kai ouk ēdynēthēsan auton therapeusai*—couldn't cure.

"''O faithless and perverse generation.''"

*Ō genea apistos kai diestrammenē*—faithless.

"''How long shall I be with you? How long shall I bear with you?''"

*Heōs pote esomai meth' hymōn heōs pote anexomai hymōn*—how long.

"'Yeshua rebuked him; and the demon went out from him.'"

*Kai epetimēsen autō ho Iēsous kai exēlthen ap' autou to daimonion*—rebuked.

**The Key Verses (17:19-21):**
"''Why could not we cast it out?''"

*Dia ti hēmeis ouk ēdynēthēmen ekbalein auto*—why not us.

"''Because of your little faith.''"

*Dia tēn oligopistian hymōn*—little faith.

"''If you have faith as a grain of mustard seed.''"

*Ean echēte pistin hōs kokkon sinapeōs*—mustard seed.

"''You shall say unto this mountain, Remove hence to yonder place; and it shall remove.''"

*Ereite tō orei toutō metaba enthen ekei kai metabēsetai*—move mountain.

"''Nothing shall be impossible unto you.''"

*Kai ouden adynatēsei hymin*—nothing impossible.

"''This kind goes not out save by prayer and fasting.''"

*Touto de to genos ouk ekporeuetai ei mē en proseuchē kai nēsteia*—prayer, fasting.

**Textual Note:**
Verse 21 absent in earliest manuscripts.

**Second Passion Prediction (17:22-23):**
**The Key Verses (17:22-23):**
"''The Son of man shall be delivered up into the hands of men.''"

*Mellei ho huios tou anthrōpou paradidosthai eis cheiras anthrōpōn*—delivered.

"''They shall kill him, and the third day he shall be raised up.''"

*Kai apoktenousin auton kai tē tritē hēmera egerthēsetai*—killed, raised.

"'They were exceeding sorry.'"

*Kai elypēthēsan sphodra*—grieved.

**Temple Tax (17:24-27):**
**The Key Verses (17:24-27):**
"'They that received the half-shekel came to Peter.'"

*Ēlthon hoi ta didrachma lambanontes tō Petrō*—half-shekel.

**Didrachma:**
Two-drachma coin = half-shekel; annual temple tax (Exodus 30:13).

"''Does not your teacher pay the half-shekel?''"

*Ho didaskalos hymōn ou telei ta didrachma*—pays tax?

"''The kings of the earth, from whom do they receive toll or tribute?''"

*Hoi basileis tēs gēs apo tinōn lambanousin telē ē kēnson*—toll.

"''From their sons, or from strangers?''"

*Apo tōn huiōn autōn ē apo tōn allotriōn*—sons or strangers?

"''From strangers... Therefore the sons are free.''"

*Apo tōn allotriōn... ara ge eleutheroi eisin hoi huioi*—sons free.

**Implication:**
As God's Son, Yeshua is exempt from temple tax.

"''Lest we cause them to stumble.''"

*Hina de mē skandalisōmen autous*—not offend.

"''Go to the sea, and cast a hook.''"

*Poreueis eis thalassan bale ankistron*—fish.

"''You shall find a shekel.''"

*Heurēseis statēra*—stater coin.

**Stater:**
Four-drachma coin = one shekel; covers two people.

"''Give unto them for me and for you.''"

*Dos autois anti emou kai sou*—for both.

**Archetypal Layer:** Matthew 17 contains **the Transfiguration (17:1-8)**: after six days, high mountain, Peter, James, John, **"he was transfigured before them; and his face did shine as the sun" (17:2)**, **Moses and Elijah appearing (17:3)**, **"This is my beloved Son, in whom I am well pleased; hear him" (17:5)**, **"they saw no one, save Yeshua only" (17:8)**, **"Tell the vision to no man, until the Son of man be risen from the dead" (17:9)**, **"Elijah is come already... John the Immerser" (17:12-13)**, **the epileptic boy healed (17:14-18)**, **"O faithless and perverse generation" (17:17)**, **"If you have faith as a grain of mustard seed... nothing shall be impossible unto you" (17:20)**, **second passion prediction (17:22-23)**, and **the temple tax paid from a fish's mouth (17:24-27)**.

**Modern Equivalent:** Matthew 17 reveals glory before suffering. The Transfiguration (17:1-8) shows Yeshua's divine glory—face shining, Moses and Elijah present, the Father's voice adding "hear him." The vision confirms Peter's confession (16:16). Descending, they encounter human need and disciples' failure (17:14-16). "Faithless generation" (17:17) includes even disciples. Faith like a mustard seed moves mountains (17:20). The second passion prediction (17:22-23) reiterates the cross. The temple tax episode (17:24-27) shows Yeshua as Son yet voluntarily submitting to avoid offense.

# Matthew 28: The Resurrection and Great Commission

*From the Greek: Ὀψὲ δὲ σαββάτων (Opse de Sabbatōn) — Now Late on the Sabbath Day*

---

## The Empty Tomb (28:1-10)

**28:1** Now late on the sabbath day, as it began to dawn toward the first day of the week, came Mary Magdalene and the other Mary to see the sepulchre.

**28:2** And behold, there was a great earthquake; for an angel of the Lord descended from heaven, and came and rolled away the stone, and sat upon it.

**28:3** His appearance was as lightning, and his raiment white as snow:

**28:4** And for fear of him the watchers did quake, and became as dead men.

**28:5** And the angel answered and said unto the women: "Fear not: for I know that you seek Yeshua, who has been crucified.

**28:6** "He is not here; for he is risen, even as he said. Come, see the place where the Lord lay.

**28:7** "And go quickly, and tell his disciples, 'He is risen from the dead; and lo, he goes before you into Galilee; there shall you see him': lo, I have told you."

**28:8** And they departed quickly from the tomb with fear and great joy, and ran to bring his disciples word.

**28:9** And behold, Yeshua met them, saying: "All hail." And they came and took hold of his feet, and worshipped him.

**28:10** Then says Yeshua unto them: "Fear not: go tell my brethren that they depart into Galilee, and there shall they see me."

---

## The Report of the Guard (28:11-15)

**28:11** Now while they were going, behold, some of the guard came into the city, and told unto the chief priests all the things that were come to pass.

**28:12** And when they were assembled with the elders, and had taken counsel, they gave much money unto the soldiers,

**28:13** Saying: "Say, 'His disciples came by night, and stole him away while we slept.'

**28:14** "And if this come to the governor's ears, we will persuade him, and rid you of care."

**28:15** So they took the money, and did as they were taught: and this saying was spread abroad among the Jews, and continues until this day.

---

## The Great Commission (28:16-20)

**28:16** But the eleven disciples went into Galilee, unto the mountain where Yeshua had appointed them.

**28:17** And when they saw him, they worshipped him; but some doubted.

**28:18** And Yeshua came to them and spoke unto them, saying: "All authority has been given unto me in heaven and on earth.

**28:19** "Go therefore, and make disciples of all the nations, immersing them into the name of the Father and of the Son and of the Holy Spirit:

**28:20** "Teaching them to observe all things whatsoever I commanded you: and lo, I am with you always, even unto the end of the world."

---

## Synthesis Notes

**Key Restorations:**

**The Empty Tomb (28:1-10):**
**The Key Verses (28:1-4):**
"'Late on the sabbath day, as it began to dawn toward the first day of the week.'"

*Opse de sabbatōn tē epiphōskousē eis mian sabbatōn*—dawn, first day.

"'Came Mary Magdalene and the other Mary to see the sepulchre.'"

*Ēlthen Mariam hē Magdalēnē kai hē allē Maria theōrēsai ton taphon*—two Marys.

"'There was a great earthquake.'"

*Kai idou seismos egeneto megas*—earthquake.

"'An angel of the Lord descended from heaven, and came and rolled away the stone.'"

*Angelos gar kyriou katabas ex ouranou kai proselthōn apekulisen ton lithon*—angel.

"'His appearance was as lightning, and his raiment white as snow.'"

*Ēn de hē eidea autou hōs astrapē kai to endyma autou leukon hōs chiōn*—lightning, white.

"'For fear of him the watchers did quake, and became as dead men.'"

*Apo de tou phobou autou eseisthēsan hoi tērountes kai egenēthēsan hōs nekroi*—guards.

**The Key Verses (28:5-7):**
"''Fear not: for I know that you seek Yeshua, who has been crucified.''"

*Mē phobeisthe hymeis oida gar hoti Iēsoun ton estaurōmenon zēteite*—fear not.

"''He is not here; for he is risen, even as he said.''"

*Ouk estin hōde ēgerthē gar kathōs eipen*—risen.

"''Come, see the place where the Lord lay.''"

*Deute idete ton topon hopou ekeito*—see the place.

"''Go quickly, and tell his disciples, He is risen from the dead.''"

*Kai tachy poreuthesai eipate tois mathētais autou hoti ēgerthē apo tōn nekrōn*—tell disciples.

"''He goes before you into Galilee; there shall you see him.''"

*Kai idou proagei hymas eis tēn Galilaian ekei auton opsesthe*—Galilee.

**The Key Verses (28:8-10):**
"'They departed quickly from the tomb with fear and great joy.'"

*Kai apelthousai tachy apo tou mnēmeiou meta phobou kai charas megalēs*—fear, joy.

"'Yeshua met them, saying: All hail.'"

*Kai idou Iēsous hypēntēsen autais legōn chairete*—hail.

"'They came and took hold of his feet, and worshipped him.'"

*Hai de proselthousai ekratēsan autou tous podas kai prosekynēsan autō*—worshipped.

"''Fear not: go tell my brethren that they depart into Galilee.''"

*Mē phobeisthe hypagete apangeilate tois adelphois mou hina apelthōsin eis tēn Galilaian*—brethren.

**Report of the Guard (28:11-15):**
**The Key Verses (28:11-15):**
"'Some of the guard came into the city, and told unto the chief priests all the things that were come to pass.'"

*Tines tēs koustōdias elthontes eis tēn polin apēngeilan tois archiereusin hapanta ta genomena*—report.

"'They gave much money unto the soldiers.'"

*Argyria hikana edōkan tois stratiōtais*—bribed.

"''Say, His disciples came by night, and stole him away while we slept.''"

*Eipate hoti hoi mathētai autou nyktos elthontes eklepsan auton hēmōn koimōmenōn*—lie.

"''If this come to the governor's ears, we will persuade him.''"

*Kai ean akousthē touto epi tou hēgemonos hēmeis peisomen auton*—persuade.

"'This saying was spread abroad among the Jews, and continues until this day.'"

*Kai diephēmisthē ho logos houtos para Ioudaiois mechri tēs sēmeron hēmeras*—until today.

**The Great Commission (28:16-20):**
**The Key Verses (28:16-17):**
"'The eleven disciples went into Galilee, unto the mountain where Yeshua had appointed them.'"

*Hoi de hendeka mathētai eporeuthēsan eis tēn Galilaian eis to oros hou etaxato autois ho Iēsous*—appointed mountain.

"'When they saw him, they worshipped him; but some doubted.'"

*Kai idontes auton prosekynēsan hoi de edistasan*—worshipped, doubted.

**The Key Verses (28:18-20):**
"''All authority has been given unto me in heaven and on earth.''"

*Edothē moi pasa exousia en ouranō kai epi gēs*—all authority.

**Pasa Exousia:**
"All authority"—universal sovereignty.

"''Go therefore, and make disciples of all the nations.''"

*Poreuthentes oun mathēteusate panta ta ethnē*—make disciples.

**Mathēteusate:**
"Make disciples"—the main imperative.

"''Immersing them into the name of the Father and of the Son and of the Holy Spirit.''"

*Baptizontes autous eis to onoma tou patros kai tou huiou kai tou hagiou pneumatos*—trinitarian formula.

**Eis to Onoma:**
"Into the name"—identification with.

"''Teaching them to observe all things whatsoever I commanded you.''"

*Didaskontes autous tērein panta hosa eneteilamēn hymin*—teaching.

"''Lo, I am with you always, even unto the end of the world.''"

*Kai idou egō meth' hymōn eimi pasas tas hēmeras heōs tēs synteleias tou aiōnos*—always with you.

**Synteleias tou Aiōnos:**
"End of the age."

**Archetypal Layer:** Matthew 28 is the **resurrection and commissioning chapter**, containing **"Now late on the sabbath day, as it began to dawn toward the first day of the week" (28:1)**, **great earthquake, angel descends, rolls away stone (28:2)**, **"His appearance was as lightning, and his raiment white as snow" (28:3)**, **guards become as dead men (28:4)**, **"Fear not... He is not here; for he is risen, even as he said" (28:5-6)**, **"Come, see the place where the Lord lay" (28:6)**, **"Go quickly, and tell his disciples, He is risen from the dead" (28:7)**, **"He goes before you into Galilee" (28:7)**, **women meet Yeshua, hold his feet, worship him (28:9)**, **"go tell my brethren" (28:10)**, **guards bribed: "Say, His disciples came by night, and stole him away" (28:13)**, **"the eleven disciples went into Galilee, unto the mountain" (28:16)**, **"they worshipped him; but some doubted" (28:17)**, **"All authority has been given unto me in heaven and on earth" (28:18)**, **"Go therefore, and make disciples of all the nations" (28:19)**, **"immersing them into the name of the Father and of the Son and of the Holy Spirit" (28:19)**, **"Teaching them to observe all things whatsoever I commanded you" (28:20)**, and **"lo, I am with you always, even unto the end of the world" (28:20)**.

**Modern Equivalent:** Matthew 28 concludes with resurrection and commission. The earthquake and angel (28:2-3) signal divine intervention. The message: "He is not here; for he is risen" (28:6). The women become the first witnesses, meeting the risen Yeshua (28:9). The guard's bribery (28:11-15) is the alternative explanation that circulated. The Great Commission (28:18-20) is Matthew's climax: universal authority given, therefore go to all nations, make disciples, immerse, teach. The trinitarian formula is explicit. The promise "I am with you always" (28:20) echoes "Emmanuel, God with us" (1:23)—Matthew's gospel begins and ends with divine presence.

# Matthew 22: The Wedding Feast and Controversies

*From the Greek: Καὶ ἀποκριθεὶς ὁ Ἰησοῦς πάλιν εἶπεν (Kai Apokritheis ho Iesous Palin Eipen) — And Yeshua Answered and Spoke Again*

---

## The Parable of the Wedding Feast (22:1-14)

**22:1** And Yeshua answered and spoke unto them again in parables, saying:

**22:2** "The kingdom of heaven is likened unto a certain king, who made a marriage feast for his son,

**22:3** "And sent forth his servants to call them that were bidden to the marriage feast: and they would not come.

**22:4** "Again he sent forth other servants, saying: 'Tell them that are bidden, Behold, I have made ready my dinner; my oxen and my fatlings are killed, and all things are ready: come to the marriage feast.'

**22:5** "But they made light of it, and went their ways, one to his own farm, another to his merchandise;

**22:6** "And the rest laid hold on his servants, and treated them shamefully, and killed them.

**22:7** "But the king was angry; and he sent his armies, and destroyed those murderers, and burned their city.

**22:8** "Then says he to his servants: 'The wedding is ready, but they that were bidden were not worthy.

**22:9** "'Go therefore unto the partings of the highways, and as many as you shall find, bid to the marriage feast.'

**22:10** "And those servants went out into the highways, and gathered together all as many as they found, both bad and good: and the wedding was filled with guests.

**22:11** "But when the king came in to behold the guests, he saw there a man who had not on a wedding-garment:

**22:12** "And he says unto him: 'Friend, how did you come in here not having a wedding-garment?' And he was speechless.

**22:13** "Then the king said to the servants: 'Bind him hand and foot, and cast him out into the outer darkness; there shall be the weeping and the gnashing of teeth.'

**22:14** "For many are called, but few chosen."

---

## Paying Tribute to Caesar (22:15-22)

**22:15** Then went the Pharisees, and took counsel how they might ensnare him in his talk.

**22:16** And they send to him their disciples, with the Herodians, saying: "Teacher, we know that you are true, and teach the way of God in truth, and care not for any one: for you regard not the person of men.

**22:17** "Tell us therefore, What do you think? Is it lawful to give tribute unto Caesar, or not?"

**22:18** But Yeshua perceived their wickedness, and said: "Why do you try me, you hypocrites?

**22:19** "Show me the tribute money." And they brought unto him a denarius.

**22:20** And he says unto them: "Whose is this image and superscription?"

**22:21** They say unto him: "Caesar's." Then says he unto them: "Render therefore unto Caesar the things that are Caesar's; and unto God the things that are God's."

**22:22** And when they heard it, they marvelled, and left him, and went away.

---

## The Resurrection Question (22:23-33)

**22:23** On that day there came to him Sadducees, they that say that there is no resurrection: and they asked him,

**22:24** Saying: "Teacher, Moses said, 'If a man die, having no children, his brother shall marry his wife, and raise up seed unto his brother.'

**22:25** "Now there were with us seven brethren: and the first married and deceased, and having no seed left his wife unto his brother;

**22:26** "In like manner the second also, and the third, unto the seventh.

**22:27** "And after them all, the woman died.

**22:28** "In the resurrection therefore whose wife shall she be of the seven? For they all had her."

**22:29** But Yeshua answered and said unto them: "You err, not knowing the scriptures, nor the power of God.

**22:30** "For in the resurrection they neither marry, nor are given in marriage, but are as angels in heaven.

**22:31** "But as touching the resurrection of the dead, have you not read that which was spoken unto you by God, saying:

**22:32** "'I am the God of Abraham, and the God of Isaac, and the God of Jacob'? God is not the God of the dead, but of the living."

**22:33** And when the multitudes heard it, they were astonished at his teaching.

---

## The Great Commandment (22:34-40)

**22:34** But the Pharisees, when they heard that he had put the Sadducees to silence, gathered themselves together.

**22:35** And one of them, a lawyer, asked him a question, trying him:

**22:36** "Teacher, which is the great commandment in the law?"

**22:37** And he said unto him: "'You shall love the Lord your God with all your heart, and with all your soul, and with all your mind.'

**22:38** "This is the great and first commandment.

**22:39** "And a second like unto it is this: 'You shall love your neighbour as yourself.'

**22:40** "On these two commandments the whole law hangs, and the prophets."

---

## David's Son and Lord (22:41-46)

**22:41** Now while the Pharisees were gathered together, Yeshua asked them a question,

**22:42** Saying: "What think you of the Anointed? Whose son is he?" They say unto him: "The son of David."

**22:43** He says unto them: "How then does David in the Spirit call him Lord, saying:

**22:44** "'The Lord said unto my Lord, Sit on my right hand, till I put your enemies underneath your feet'?

**22:45** "If David then calls him Lord, how is he his son?"

**22:46** And no one was able to answer him a word, neither dared any man from that day forth ask him any more questions.

---

## Synthesis Notes

**Key Restorations:**

**Wedding Feast Parable (22:1-14):**
**The Key Verses (22:1-7):**
"''The kingdom of heaven is likened unto a certain king, who made a marriage feast for his son.''"

*Hōmoiōthē hē basileia tōn ouranōn anthrōpō basilei hostis epoiēsen gamous tō huiō autou*—wedding feast.

"''Sent forth his servants to call them that were bidden.''"

*Kai apesteilen tous doulous autou kalesai tous keklēmenous eis tous gamous*—called.

"''They would not come.''"

*Kai ouk ēthelon elthein*—wouldn't come.

"''Behold, I have made ready my dinner.''"

*Idou to ariston mou hētoimaka*—ready.

"''My oxen and my fatlings are killed, and all things are ready.''"

*Hoi tauroi mou kai ta sitista tethymena kai panta hetoima*—prepared.

"''They made light of it.''"

*Hoi de amelēsantes apēlthon*—made light.

"''The rest laid hold on his servants, and treated them shamefully, and killed them.''"

*Hoi de loipoi kratēsantes tous doulous autou hybrisan kai apekteinan*—killed servants.

"''The king was angry; and he sent his armies, and destroyed those murderers, and burned their city.''"

*Ho de basileus ōrgisthē kai pempsas ta strateumata autou apōlesen tous phoneis ekeinous kai tēn polin autōn enepрēsen*—destroyed city.

**The Key Verses (22:8-14):**
"''The wedding is ready, but they that were bidden were not worthy.''"

*Ho men gamos hetoimos estin hoi de keklēmenoi ouk ēsan axioi*—not worthy.

"''Go therefore unto the partings of the highways.''"

*Poreuesthe oun epi tas diexodous tōn hodōn*—highways.

"''As many as you shall find, bid to the marriage feast.''"

*Kai hosous ean heurēte kalesate eis tous gamous*—invite all.

"''Gathered together all as many as they found, both bad and good.''"

*Kai synēgagon pantas hous heuron ponērous te kai agathous*—bad and good.

"''The wedding was filled with guests.''"

*Kai eplēsthē ho gamos anakeimenōn*—filled.

"''He saw there a man who had not on a wedding-garment.''"

*Eiden ekei anthrōpon ouk endedymenon endyma gamou*—no wedding garment.

"''Friend, how did you come in here not having a wedding-garment?''"

*Hetaire pōs eisēlthes hōde mē echōn endyma gamou*—how?

"''Cast him out into the outer darkness.''"

*Ekbalete auton eis to skotos to exōteron*—outer darkness.

"''Many are called, but few chosen.''"

*Polloi gar eisin klētoi oligoi de eklektoi*—called, chosen.

**Tribute to Caesar (22:15-22):**
**The Key Verses (22:15-22):**
"'The Pharisees... took counsel how they might ensnare him in his talk.'"

*Tote poreuthentes hoi Pharisaioi symboulion elabon hopōs auton pagideuسōsin en logō*—ensnare.

"'They send to him their disciples, with the Herodians.'"

*Kai apostellousin autō tous mathētas autōn meta tōn Hērōdianōn*—Herodians.

**Unusual Alliance:**
Pharisees (anti-Rome) + Herodians (pro-Rome).

"''Is it lawful to give tribute unto Caesar, or not?''"

*Exestin dounai kēnson Kaisari ē ou*—lawful?

"''Why do you try me, you hypocrites?''"

*Ti me peirazete hypokritai*—hypocrites.

"''Show me the tribute money.''"

*Epideixate moi to nomisma tou kēnsou*—show coin.

"''Whose is this image and superscription?''"

*Tinos hē eikōn hautē kai hē epigraphē*—whose image?

"''Caesar's.''"

*Kaisaros*—Caesar's.

"''Render therefore unto Caesar the things that are Caesar's.''"

*Apodote oun ta Kaisaros Kaisari*—render to Caesar.

"''And unto God the things that are God's.''"

*Kai ta tou theou tō theō*—and to God.

"'When they heard it, they marvelled.'"

*Kai akousantes ethaumasan*—marvelled.

**Resurrection Question (22:23-33):**
**The Key Verses (22:23-28):**
"'Sadducees, they that say that there is no resurrection.'"

*Prosēlthon autō Saddoukaioi hoi legontes mē einai anastasin*—no resurrection.

"''Moses said, If a man die, having no children, his brother shall marry his wife.''"

*Mōusēs eipen ean tis apothanē mē echōn tekna epigambreusei ho adelphos autou tēn gynaika autou*—levirate marriage.

**Deuteronomy 25:5-6.**

"''There were with us seven brethren.''"

*Ēsan de par' hēmin hepta adelphoi*—seven brothers.

"''In the resurrection therefore whose wife shall she be of the seven?''"

*En tē anastasei oun tinos tōn hepta estai gynē*—whose wife?

**The Key Verses (22:29-33):**
"''You err, not knowing the scriptures, nor the power of God.''"

*Planasthe mē eidotes tas graphas mēde tēn dynamin tou theou*—err.

"''In the resurrection they neither marry, nor are given in marriage.''"

*En gar tē anastasei oute gamousin oute gamizontai*—no marriage.

"''But are as angels in heaven.''"

*All' hōs angeloi en tō ouranō eisin*—like angels.

"''I am the God of Abraham, and the God of Isaac, and the God of Jacob.''"

*Egō eimi ho theos Abraam kai ho theos Isaak kai ho theos Iakōb*—I am God of.

**Exodus 3:6.**

"''God is not the God of the dead, but of the living.''"

*Ouk estin ho theos nekrōn alla zōntōn*—God of living.

"'They were astonished at his teaching.'"

*Exeplēssonto epi tē didachē autou*—astonished.

**Great Commandment (22:34-40):**
**The Key Verses (22:34-40):**
"'One of them, a lawyer, asked him a question, trying him.'"

*Heis ex autōn nomikos epērōtēsen peirazōn auton*—lawyer, testing.

"''Which is the great commandment in the law?''"

*Poia entolē megalē en tō nomō*—great commandment?

"''You shall love the Lord your God with all your heart.''"

*Agapēseis kyrion ton theon sou en holē tē kardia sou*—all heart.

"''And with all your soul, and with all your mind.''"

*Kai en holē tē psychē sou kai en holē tē dianoia sou*—soul, mind.

**Deuteronomy 6:5.**

"''This is the great and first commandment.''"

*Hautē estin hē megalē kai prōtē entolē*—first.

"''A second like unto it is this: You shall love your neighbour as yourself.''"

*Deutera de homoia autē agapēseis ton plēsion sou hōs seauton*—second.

**Leviticus 19:18.**

"''On these two commandments the whole law hangs, and the prophets.''"

*En tautais tais dysin entolais holos ho nomos krematai kai hoi prophētai*—whole law.

**David's Son and Lord (22:41-46):**
**The Key Verses (22:41-46):**
"''What think you of the Anointed? Whose son is he?''"

*Ti hymin dokei peri tou Christou tinos huios estin*—whose son?

"''The son of David.''"

*Tou David*—David's.

"''How then does David in the Spirit call him Lord?''"

*Pōs oun David en pneumati kalei auton kyrion*—David calls Lord.

"''The Lord said unto my Lord, Sit on my right hand.''"

*Eipen kyrios tō kyriō mou kathou ek dexiōn mou*—Lord to Lord.

**Psalm 110:1.**

"''Till I put your enemies underneath your feet.''"

*Heōs an thō tous echthrous sou hypokاتō tōn podōn sou*—enemies.

"''If David then calls him Lord, how is he his son?''"

*Ei oun David kalei auton kyrion pōs huios autou estin*—how son?

"'No one was able to answer him a word.'"

*Kai oudeis edynato apokrithēnai autō logon*—couldn't answer.

"'Neither dared any man from that day forth ask him any more questions.'"

*Oude etolmēsen tis ap' ekeinēs tēs hēmeras eperōtēsai auton ouketi*—no more questions.

**Archetypal Layer:** Matthew 22 contains **parable of the wedding feast (22:1-14)**: invited refuse, city burned, highways invited, wedding garment required, **"many are called, but few chosen" (22:14)**, **"Render unto Caesar the things that are Caesar's; and unto God the things that are God's" (22:21)**, **Sadducees' resurrection question (22:23-28)**, **"You err, not knowing the scriptures, nor the power of God" (22:29)**, **"in the resurrection they neither marry, nor are given in marriage" (22:30)**, **"God is not the God of the dead, but of the living" (22:32)**, **the great commandment (22:37-40)**: love God with all heart, soul, mind + love neighbor as self, **"On these two commandments the whole law hangs, and the prophets" (22:40)**, **David's Son and Lord (22:41-46)**: Psalm 110:1 riddle, and **no one could answer or dared ask more questions (22:46)**.

**Modern Equivalent:** Matthew 22 contains the wedding feast parable (22:1-14)—invitation rejected, outsiders brought in, but a wedding garment (righteousness) is still required. The Caesar question (22:15-22) sidesteps a political trap with profound wisdom. The Sadducees are silenced by Exodus 3:6—"I am" proves ongoing relationship with the patriarchs, thus resurrection (22:32). The great commandment (22:37-40) summarizes all Torah in love for God and neighbor. The David's Lord riddle (22:41-46) implies Messiah is more than David's son—He is David's Lord.

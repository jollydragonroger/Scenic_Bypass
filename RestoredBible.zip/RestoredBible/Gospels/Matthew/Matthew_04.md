# Matthew 4: The Temptation and Beginning of Ministry

*From the Greek: Τότε ὁ Ἰησοῦς ἀνήχθη εἰς τὴν ἔρημον (Tote ho Iesous Anechthē eis tēn Erēmon) — Then Yeshua Was Led Up into the Wilderness*

---

## The Temptation (4:1-11)

**4:1** Then was Yeshua led up of the Spirit into the wilderness to be tempted of the devil.

**4:2** And when he had fasted forty days and forty nights, he afterward hungered.

**4:3** And the tempter came and said unto him: "If you are the Son of God, command that these stones become bread."

**4:4** But he answered and said: "It is written, 'Man shall not live by bread alone, but by every word that proceeds out of the mouth of God.'"

**4:5** Then the devil takes him into the holy city; and he set him on the pinnacle of the temple,

**4:6** And says unto him: "If you are the Son of God, cast yourself down: for it is written, 'He shall give his angels charge concerning you: and, On their hands they shall bear you up, lest haply you dash your foot against a stone.'"

**4:7** Yeshua said unto him: "Again it is written, 'You shall not tempt the Lord your God.'"

**4:8** Again, the devil takes him unto an exceeding high mountain, and shows him all the kingdoms of the world, and the glory of them;

**4:9** And he said unto him: "All these things will I give you, if you will fall down and worship me."

**4:10** Then says Yeshua unto him: "Get behind me, Satan: for it is written, 'You shall worship the Lord your God, and him only shall you serve.'"

**4:11** Then the devil leaves him; and behold, angels came and ministered unto him.

---

## Beginning of Ministry in Galilee (4:12-17)

**4:12** Now when he heard that John was delivered up, he withdrew into Galilee;

**4:13** And leaving Nazareth, he came and dwelt in Capernaum, which is by the sea, in the borders of Zebulun and Naphtali:

**4:14** That it might be fulfilled which was spoken through Isaiah the prophet, saying:

**4:15** "The land of Zebulun and the land of Naphtali, toward the sea, beyond the Jordan, Galilee of the Gentiles—

**4:16** "The people that sat in darkness saw a great light, and to them that sat in the region and shadow of death, to them did light spring up."

**4:17** From that time began Yeshua to proclaim, and to say: "Repent; for the kingdom of heaven is at hand."

---

## Calling of the First Disciples (4:18-22)

**4:18** And walking by the sea of Galilee, he saw two brethren, Simon who is called Peter, and Andrew his brother, casting a net into the sea; for they were fishers.

**4:19** And he says unto them: "Come after me, and I will make you fishers of men."

**4:20** And they straightway left the nets, and followed him.

**4:21** And going on from thence he saw two other brethren, James the son of Zebedee, and John his brother, in the boat with Zebedee their father, mending their nets; and he called them.

**4:22** And they straightway left the boat and their father, and followed him.

---

## Ministry of Healing (4:23-25)

**4:23** And Yeshua went about in all Galilee, teaching in their synagogues, and proclaiming the good news of the kingdom, and healing all manner of disease and all manner of sickness among the people.

**4:24** And the report of him went forth into all Syria: and they brought unto him all that were sick, holden with divers diseases and torments, possessed with demons, and epileptic, and palsied; and he healed them.

**4:25** And there followed him great multitudes from Galilee and Decapolis and Jerusalem and Judaea and from beyond the Jordan.

---

## Synthesis Notes

**Key Restorations:**

**The Temptation (4:1-11):**
**The Key Verses (4:1-2):**
"'Yeshua led up of the Spirit into the wilderness.'"

*Ho Iēsous anēchthē eis tēn erēmon hypo tou pneumatos*—Spirit led.

"'To be tempted of the devil.'"

*Peirasthēnai hypo tou diabolou*—tempted.

**Diabolos:**
"Slanderer/Accuser"—Greek equivalent of Hebrew *Satan*.

"'When he had fasted forty days and forty nights.'"

*Kai nēsteusas hēmeras tesserakonta kai nyktas tesserakonta*—forty days.

**Forty Days:**
Echoes Moses (Exodus 34:28), Elijah (1 Kings 19:8), Israel's forty years.

"'He afterward hungered.'"

*Hysteron epeinasen*—hungered.

**The Key Verses (4:3-4):**
"''If you are the Son of God, command that these stones become bread.''"

*Ei huios ei tou theou eipe hina hoi lithoi houtoi artoi genōntai*—stones to bread.

"''It is written, Man shall not live by bread alone.''"

*Gegraptai ouk ep' artō monō zēsetai ho anthrōpos*—written.

**Deuteronomy 8:3.**

"''But by every word that proceeds out of the mouth of God.''"

*All' epi panti rhēmati ekporeuomenō dia stomatos theou*—every word.

**The Key Verses (4:5-7):**
"'The devil takes him into the holy city.'"

*Tote paralambanei auton ho diabolos eis tēn hagian polin*—holy city.

"'Set him on the pinnacle of the temple.'"

*Kai estēsen auton epi to pterygion tou hierou*—pinnacle.

"''If you are the Son of God, cast yourself down.''"

*Ei huios ei tou theou bale seauton katō*—cast down.

"''For it is written, He shall give his angels charge concerning you.''"

*Gegraptai gar hoti tois angelois autou enteleitai peri sou*—angels.

**Psalm 91:11-12:**
Satan quotes Scripture—out of context.

"''You shall not tempt the Lord your God.''"

*Ouk ekpeiraseis kyrion ton theon sou*—don't tempt.

**Deuteronomy 6:16.**

**The Key Verses (4:8-11):**
"'The devil takes him unto an exceeding high mountain.'"

*Palin paralambanei auton ho diabolos eis oros hypsēlon lian*—high mountain.

"'Shows him all the kingdoms of the world, and the glory of them.'"

*Kai deiknusin autō pasas tas basileias tou kosmou kai tēn doxan autōn*—kingdoms.

"''All these things will I give you, if you will fall down and worship me.''"

*Tauta soi panta dōsō ean pesōn proskynēsēs moi*—worship me.

"''Get behind me, Satan.''"

*Hypage Satana*—get behind.

"''You shall worship the Lord your God, and him only shall you serve.''"

*Kyrion ton theon sou proskynēseis kai autō monō latreuseis*—worship God only.

**Deuteronomy 6:13.**

"'The devil leaves him; and behold, angels came and ministered unto him.'"

*Tote aphiēsin auton ho diabolos kai idou angeloi prosēlthon kai diēkonoun autō*—angels minister.

**Beginning of Ministry (4:12-17):**
**The Key Verses (4:12-17):**
"'When he heard that John was delivered up.'"

*Akousas de hoti Iōannēs paredothē*—John arrested.

"'He withdrew into Galilee.'"

*Anechōrēsen eis tēn Galilaian*—Galilee.

"'Leaving Nazareth, he came and dwelt in Capernaum.'"

*Kai katalipōn tēn Nazara elthōn katōkēsen eis Kapharnaoum*—Capernaum.

"'Which is by the sea, in the borders of Zebulun and Naphtali.'"

*Tēn parathalassian en horiois Zaboulōn kai Nephthalim*—sea, tribes.

"''The land of Zebulun and the land of Naphtali.''"

*Gē Zaboulōn kai gē Nephthalim*—Zebulun, Naphtali.

**Isaiah 9:1-2.**

"''Galilee of the Gentiles.''"

*Galilaia tōn ethnōn*—Gentile region.

"''The people that sat in darkness saw a great light.''"

*Ho laos ho kathēmenos en skotei phōs eiden mega*—great light.

"''To them that sat in the region and shadow of death, to them did light spring up.''"

*Kai tois kathēmenois en chōra kai skia thanatou phōs aneteilen autois*—light.

"''Repent; for the kingdom of heaven is at hand.''"

*Metanoeite ēngiken gar hē basileia tōn ouranōn*—repent.

**Same Message as John:**
John's message (3:2) now Yeshua's.

**Calling of First Disciples (4:18-22):**
**The Key Verses (4:18-22):**
"'Walking by the sea of Galilee.'"

*Peripatōn de para tēn thalassan tēs Galilaias*—walking.

"'He saw two brethren, Simon who is called Peter, and Andrew his brother.'"

*Eiden dyo adelphous Simōna ton legomenon Petron kai Andrean ton adelphon autou*—Simon, Andrew.

"'Casting a net into the sea; for they were fishers.'"

*Ballontas amphiblestron eis tēn thalassan ēsan gar halieis*—fishers.

"''Come after me, and I will make you fishers of men.''"

*Deute opisō mou kai poiēsō hymas halieis anthrōpōn*—fishers of men.

"'They straightway left the nets, and followed him.'"

*Hoi de eutheōs aphentes ta diktya ēkolouthēsan autō*—followed.

"'Two other brethren, James the son of Zebedee, and John his brother.'"

*Allous dyo adelphous Iakōbon ton tou Zebedaiou kai Iōannēn ton adelphon autou*—James, John.

"'In the boat with Zebedee their father, mending their nets.'"

*En tō ploiō meta Zebedaiou tou patros autōn katartizontas ta diktya autōn*—mending.

"'They straightway left the boat and their father, and followed him.'"

*Hoi de eutheōs aphentes to ploion kai ton patera autōn ēkolouthēsan autō*—left father.

**Ministry of Healing (4:23-25):**
**The Key Verses (4:23-25):**
"'Yeshua went about in all Galilee.'"

*Kai periēgen en holē tē Galilaia ho Iēsous*—went about.

"'Teaching in their synagogues.'"

*Didaskōn en tais synagōgais autōn*—teaching.

"'Proclaiming the good news of the kingdom.'"

*Kai kēryssōn to euangelion tēs basileias*—proclaiming.

**Euangelion:**
"Good news/Gospel."

"'Healing all manner of disease and all manner of sickness.'"

*Kai therapeuōn pasan noson kai pasan malakian en tō laō*—healing.

"'The report of him went forth into all Syria.'"

*Kai apēlthen hē akoē autou eis holēn tēn Syrian*—Syria.

"'They brought unto him all that were sick.'"

*Kai prosēnenkan autō pantas tous kakōs echontas*—brought sick.

"'Holden with divers diseases and torments, possessed with demons, and epileptic, and palsied.'"

*Poikilais nosois kai basanois synechomenous kai daimonizomenous kai selēniazomenous kai paralytikous*—various afflictions.

"'He healed them.'"

*Kai etherapeusen autous*—healed.

"'Great multitudes from Galilee and Decapolis and Jerusalem and Judaea and from beyond the Jordan.'"

*Kai ēkolouthēsan autō ochloi polloi apo tēs Galilaias kai Dekapoleōs kai Hierosolymōn kai Ioudaias kai peran tou Iordanou*—multitudes.

**Archetypal Layer:** Matthew 4 contains **Yeshua led by Spirit into wilderness for forty days (4:1-2)**, **three temptations: stones to bread (4:3-4), pinnacle of temple (4:5-7), kingdoms of the world (4:8-10)**, **Yeshua answers each with Deuteronomy: 8:3, 6:16, 6:13**, **"Get behind me, Satan" (4:10)**, **angels ministering after temptation (4:11)**, **Isaiah 9:1-2 fulfilled: "The people that sat in darkness saw a great light" (4:15-16)**, **"Repent; for the kingdom of heaven is at hand" (4:17)**, **calling of Simon Peter, Andrew, James, John (4:18-22)**, **"I will make you fishers of men" (4:19)**, and **summary of teaching, proclaiming, healing ministry (4:23-25)**.

**Ethical Inversion Applied:**
- "'Yeshua led up of the Spirit into the wilderness'"—Spirit led
- "'To be tempted of the devil'"—tempted
- "'When he had fasted forty days and forty nights'"—forty days
- "''If you are the Son of God, command that these stones become bread''"—first temptation
- "''It is written, Man shall not live by bread alone''"—Deuteronomy 8:3
- "'The devil takes him into the holy city'"—temple
- "''If you are the Son of God, cast yourself down''"—second temptation
- "''You shall not tempt the Lord your God''"—Deuteronomy 6:16
- "'The devil takes him unto an exceeding high mountain'"—mountain
- "'Shows him all the kingdoms of the world'"—kingdoms
- "''All these things will I give you, if you will fall down and worship me''"—third temptation
- "''Get behind me, Satan''"—rebuke
- "''You shall worship the Lord your God, and him only shall you serve''"—Deuteronomy 6:13
- "'The devil leaves him; and behold, angels came and ministered unto him'"—angels
- "'When he heard that John was delivered up'"—John arrested
- "'He withdrew into Galilee'"—Galilee
- "'Leaving Nazareth, he came and dwelt in Capernaum'"—Capernaum
- "''The land of Zebulun and the land of Naphtali''"—Isaiah 9:1-2
- "''Galilee of the Gentiles''"—Gentiles
- "''The people that sat in darkness saw a great light''"—light
- "''Repent; for the kingdom of heaven is at hand''"—repent
- "'He saw two brethren, Simon who is called Peter, and Andrew'"—Peter, Andrew
- "''Come after me, and I will make you fishers of men''"—fishers of men
- "'They straightway left the nets, and followed him'"—followed
- "'James the son of Zebedee, and John his brother'"—James, John
- "'They straightway left the boat and their father, and followed him'"—left all
- "'Teaching in their synagogues'"—teaching
- "'Proclaiming the good news of the kingdom'"—proclaiming
- "'Healing all manner of disease'"—healing
- "'Great multitudes... followed him'"—multitudes

**Modern Equivalent:** Matthew 4 shows Yeshua recapitulating Israel's wilderness testing but succeeding where Israel failed. Each answer is from Deuteronomy—the book of Israel's wilderness lessons. The temptations target identity ("if you are the Son of God"), provision, protection, and power. After victory, Yeshua begins public ministry with John's message: "Repent; for the kingdom of heaven is at hand." The calling of fishermen to become "fishers of men" signals the new community being formed.

# Matthew 3: John the Immerser and Yeshua's Immersion

*From the Greek: Ἐν δὲ ταῖς ἡμέραις ἐκείναις παραγίνεται Ἰωάννης ὁ βαπτιστής (En de tais Hēmerais Ekeinais Paraginetai Iōannēs ho Baptistēs) — In Those Days Comes John the Immerser*

---

## John's Ministry (3:1-12)

**3:1** In those days comes John the Immerser, proclaiming in the wilderness of Judaea,

**3:2** Saying: "Repent, for the kingdom of heaven is at hand."

**3:3** For this is he that was spoken of through Isaiah the prophet, saying: "The voice of one crying in the wilderness, Prepare the way of the Lord, make his paths straight."

**3:4** Now John himself had his raiment of camel's hair, and a leather belt about his loins; and his food was locusts and wild honey.

**3:5** Then went out unto him Jerusalem, and all Judaea, and all the region round about the Jordan;

**3:6** And they were immersed of him in the river Jordan, confessing their sins.

**3:7** But when he saw many of the Pharisees and Sadducees coming to his immersion, he said unto them: "You offspring of vipers, who warned you to flee from the wrath to come?

**3:8** "Bring forth therefore fruit worthy of repentance:

**3:9** "And think not to say within yourselves: 'We have Abraham to our father'; for I say unto you, that God is able of these stones to raise up children unto Abraham.

**3:10** "And even now the axe lies at the root of the trees: every tree therefore that brings not forth good fruit is hewn down, and cast into the fire.

**3:11** "I indeed immerse you in water unto repentance: but he that comes after me is mightier than I, whose sandals I am not worthy to bear: he shall immerse you in the Holy Spirit and in fire:

**3:12** "Whose fan is in his hand, and he will thoroughly cleanse his threshing-floor; and he will gather his wheat into the garner, but the chaff he will burn up with unquenchable fire."

---

## The Immersion of Yeshua (3:13-17)

**3:13** Then comes Yeshua from Galilee to the Jordan unto John, to be immersed of him.

**3:14** But John would have hindered him, saying: "I have need to be immersed of you, and come you to me?"

**3:15** But Yeshua answering said unto him: "Permit it now: for thus it becomes us to fulfil all righteousness." Then he permits him.

**3:16** And Yeshua, when he was immersed, went up straightway from the water: and lo, the heavens were opened unto him, and he saw the Spirit of God descending as a dove, and coming upon him;

**3:17** And lo, a voice out of the heavens, saying: "This is my beloved Son, in whom I am well pleased."

---

## Synthesis Notes

**Key Restorations:**

**John's Ministry (3:1-12):**
**The Key Verses (3:1-3):**
"'In those days comes John the Immerser.'"

*En de tais hēmerais ekeinais paraginetai Iōannēs ho baptistēs*—John comes.

**Baptistēs:**
"Immerser/Baptizer"—from *baptizō*, "to immerse, dip."

"'Proclaiming in the wilderness of Judaea.'"

*Kēryssōn en tē erēmō tēs Ioudaias*—wilderness.

"''Repent, for the kingdom of heaven is at hand.''"

*Metanoeite ēngiken gar hē basileia tōn ouranōn*—repent.

**Metanoia:**
"Change of mind/heart"—repentance.

**Basileia tōn Ouranōn:**
"Kingdom of heaven"—Matthew's Jewish circumlocution for "kingdom of God."

"'This is he that was spoken of through Isaiah the prophet.'"

*Houtos gar estin ho rhētheis dia Ēsaiou tou prophētou*—Isaiah.

"''The voice of one crying in the wilderness.''"

*Phōnē boōntos en tē erēmō*—voice crying.

**Isaiah 40:3.**

"''Prepare the way of the Lord, make his paths straight.''"

*Hetoimasate tēn hodon kyriou eutheias poieite tas tribous autou*—prepare way.

**The Key Verses (3:4-6):**
"'John himself had his raiment of camel's hair.'"

*Autos de ho Iōannēs eichen to endyma autou apo trichōn kamēlou*—camel's hair.

"'A leather belt about his loins.'"

*Kai zōnēn dermatinēn peri tēn osphyn autou*—leather belt.

**Elijah's Garb:**
2 Kings 1:8—Elijah wore similar clothing.

"'His food was locusts and wild honey.'"

*Hē de trophē ēn autou akrides kai meli agrion*—locusts, honey.

"'Then went out unto him Jerusalem, and all Judaea.'"

*Tote exeporeueto pros auton Hierosolyma kai pasa hē Ioudaia*—crowds.

"'They were immersed of him in the river Jordan, confessing their sins.'"

*Kai ebaptizonto en tō Iordanē potamō hyp' autou exomologoumenoi tas hamartias autōn*—immersed, confessing.

**The Key Verses (3:7-10):**
"'When he saw many of the Pharisees and Sadducees coming to his immersion.'"

*Idōn de pollous tōn Pharisaiōn kai Saddoukaiōn erchomenous epi to baptisma autou*—Pharisees, Sadducees.

"''You offspring of vipers.''"

*Gennēmata echidnōn*—vipers.

"''Who warned you to flee from the wrath to come?''"

*Tis hypedeixen hymin phygein apo tēs mellousēs orgēs*—flee wrath.

"''Bring forth therefore fruit worthy of repentance.''"

*Poiēsate oun karpon axion tēs metanoias*—worthy fruit.

"''Think not to say within yourselves: We have Abraham to our father.''"

*Kai mē doxēte legein en heautois patera echomen ton Abraam*—don't presume.

"''God is able of these stones to raise up children unto Abraham.''"

*Dynatai ho theos ek tōn lithōn toutōn egeirai tekna tō Abraam*—stones to children.

"''Even now the axe lies at the root of the trees.''"

*Ēdē de hē axinē pros tēn rhizan tōn dendrōn keitai*—axe at root.

"''Every tree therefore that brings not forth good fruit is hewn down, and cast into the fire.''"

*Pan oun dendron mē poioun karpon kalon ekkoptetai kai eis pyr balletai*—cut, burned.

**The Key Verses (3:11-12):**
"''I indeed immerse you in water unto repentance.''"

*Egō men hymas baptizō en hydati eis metanoian*—water immersion.

"''He that comes after me is mightier than I.''"

*Ho de opisō mou erchomenos ischyroteros mou estin*—mightier.

"''Whose sandals I am not worthy to bear.''"

*Hou ouk eimi hikanos ta hypodēmata bastasai*—not worthy.

"''He shall immerse you in the Holy Spirit and in fire.''"

*Autos hymas baptisei en pneumati hagiō kai pyri*—Spirit and fire.

"''Whose fan is in his hand.''"

*Hou to ptyon en tē cheiri autou*—winnowing fan.

"''He will thoroughly cleanse his threshing-floor.''"

*Kai diakathariei tēn halōna autou*—cleanse.

"''Gather his wheat into the garner.''"

*Kai synaxei ton siton autou eis tēn apothēkēn*—gather wheat.

"''The chaff he will burn up with unquenchable fire.''"

*To de achyron katakausei pyri asbestō*—burn chaff.

**Immersion of Yeshua (3:13-17):**
**The Key Verses (3:13-15):**
"'Then comes Yeshua from Galilee to the Jordan unto John, to be immersed of him.'"

*Tote paraginetai ho Iēsous apo tēs Galilaias epi ton Iordanēn pros ton Iōannēn tou baptisthēnai hyp' autou*—to be immersed.

"''I have need to be immersed of you, and come you to me?''"

*Egō chreian echō hypo sou baptisthēnai kai sy erchē pros me*—John's protest.

"''Permit it now: for thus it becomes us to fulfil all righteousness.''"

*Aphes arti houtōs gar prepon estin hēmin plērōsai pasan dikaiosynēn*—fulfil righteousness.

**Plērōsai Pasan Dikaiosynēn:**
"To fulfil all righteousness"—Yeshua identifies with Israel.

"'Then he permits him.'"

*Tote aphiēsin auton*—permits.

**The Key Verses (3:16-17):**
"'Yeshua, when he was immersed, went up straightway from the water.'"

*Baptistheis de ho Iēsous euthys anebē apo tou hydatos*—went up.

"'The heavens were opened unto him.'"

*Kai idou ēneōchthēsan autō hoi ouranoi*—heavens opened.

"'He saw the Spirit of God descending as a dove, and coming upon him.'"

*Kai eiden to pneuma tou theou katabainon hōsei peristeran kai erchomenon ep' auton*—Spirit descending.

**Spirit as Dove:**
Symbol of peace, new creation (Genesis 8:8-12).

"'A voice out of the heavens, saying.'"

*Kai idou phōnē ek tōn ouranōn legousa*—voice.

"''This is my beloved Son, in whom I am well pleased.''"

*Houtos estin ho huios mou ho agapētos en hō eudokēsa*—beloved Son.

**Psalm 2:7 + Isaiah 42:1:**
Combined allusions—royal and servant.

**Trinitarian Theophany:**
Father speaks, Son immersed, Spirit descends.

**Archetypal Layer:** Matthew 3 contains **"In those days comes John the Immerser" (3:1)**, **"Repent, for the kingdom of heaven is at hand" (3:2)**, **Isaiah 40:3 fulfilled: "The voice of one crying in the wilderness" (3:3)**, **John's Elijah-like garb: camel's hair and leather belt (3:4)**, **"You offspring of vipers, who warned you to flee from the wrath to come?" (3:7)**, **"Think not to say within yourselves: We have Abraham to our father" (3:9)**, **"God is able of these stones to raise up children unto Abraham" (3:9)**, **"the axe lies at the root of the trees" (3:10)**, **"he shall immerse you in the Holy Spirit and in fire" (3:11)**, **"Permit it now: for thus it becomes us to fulfil all righteousness" (3:15)**, **"the heavens were opened unto him, and he saw the Spirit of God descending as a dove" (3:16)**, and **"This is my beloved Son, in whom I am well pleased" (3:17)**.

**Ethical Inversion Applied:**
- "'In those days comes John the Immerser'"—John
- "'Proclaiming in the wilderness of Judaea'"—wilderness
- "''Repent, for the kingdom of heaven is at hand''"—repent
- "'This is he that was spoken of through Isaiah'"—Isaiah
- "''The voice of one crying in the wilderness''"—voice
- "''Prepare the way of the Lord''"—prepare
- "'John himself had his raiment of camel's hair'"—camel's hair
- "'A leather belt about his loins'"—leather belt
- "'His food was locusts and wild honey'"—locusts, honey
- "'They were immersed of him in the river Jordan'"—immersed
- "'Confessing their sins'"—confessing
- "''You offspring of vipers''"—vipers
- "''Who warned you to flee from the wrath to come?''"—wrath
- "''Bring forth therefore fruit worthy of repentance''"—worthy fruit
- "''Think not to say... We have Abraham to our father''"—don't presume
- "''God is able of these stones to raise up children unto Abraham''"—stones
- "''Even now the axe lies at the root of the trees''"—axe
- "''Every tree therefore that brings not forth good fruit is hewn down''"—cut
- "''I indeed immerse you in water unto repentance''"—water
- "''He that comes after me is mightier than I''"—mightier
- "''Whose sandals I am not worthy to bear''"—not worthy
- "''He shall immerse you in the Holy Spirit and in fire''"—Spirit, fire
- "''Whose fan is in his hand''"—winnowing
- "''He will gather his wheat... the chaff he will burn''"—wheat, chaff
- "'Then comes Yeshua from Galilee to the Jordan'"—Yeshua comes
- "''I have need to be immersed of you''"—John's humility
- "''Permit it now: for thus it becomes us to fulfil all righteousness''"—fulfil
- "'The heavens were opened unto him'"—heavens opened
- "'He saw the Spirit of God descending as a dove'"—Spirit descending
- "'A voice out of the heavens'"—voice
- "''This is my beloved Son, in whom I am well pleased''"—beloved Son

**Modern Equivalent:** Matthew 3 presents John as Elijah-figure (clothing matches 2 Kings 1:8) and as Isaiah's wilderness voice. His preaching warns against presumption on Abrahamic descent—fruit matters, not genealogy. Yeshua's immersion is not for sin but "to fulfil all righteousness" (3:15)—He identifies with Israel. The trinitarian theophany (Father speaks, Spirit descends, Son is immersed) inaugurates Yeshua's public ministry.

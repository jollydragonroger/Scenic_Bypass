# Matthew 1: The Genealogy and Birth of Yeshua

*From the Greek: Βίβλος γενέσεως Ἰησοῦ Χριστοῦ (Biblos Geneseos Iesou Christou) — The Book of the Generation of Yeshua the Anointed*

---

## The Genealogy of Yeshua (1:1-17)

**1:1** The book of the generation of Yeshua the Anointed, the son of David, the son of Abraham.

**1:2** Abraham begot Isaac; and Isaac begot Jacob; and Jacob begot Judah and his brethren;

**1:3** And Judah begot Perez and Zerah of Tamar; and Perez begot Hezron; and Hezron begot Ram;

**1:4** And Ram begot Amminadab; and Amminadab begot Nahshon; and Nahshon begot Salmon;

**1:5** And Salmon begot Boaz of Rahab; and Boaz begot Obed of Ruth; and Obed begot Jesse;

**1:6** And Jesse begot David the king. And David begot Solomon of her that had been the wife of Uriah;

**1:7** And Solomon begot Rehoboam; and Rehoboam begot Abijah; and Abijah begot Asa;

**1:8** And Asa begot Jehoshaphat; and Jehoshaphat begot Joram; and Joram begot Uzziah;

**1:9** And Uzziah begot Jotham; and Jotham begot Ahaz; and Ahaz begot Hezekiah;

**1:10** And Hezekiah begot Manasseh; and Manasseh begot Amon; and Amon begot Josiah;

**1:11** And Josiah begot Jechoniah and his brethren, at the time of the carrying away to Babylon.

**1:12** And after the carrying away to Babylon, Jechoniah begot Shealtiel; and Shealtiel begot Zerubbabel;

**1:13** And Zerubbabel begot Abiud; and Abiud begot Eliakim; and Eliakim begot Azor;

**1:14** And Azor begot Sadoc; and Sadoc begot Achim; and Achim begot Eliud;

**1:15** And Eliud begot Eleazar; and Eleazar begot Matthan; and Matthan begot Jacob;

**1:16** And Jacob begot Joseph the husband of Mary, of whom was born Yeshua, who is called the Anointed.

**1:17** So all the generations from Abraham unto David are fourteen generations; and from David unto the carrying away to Babylon fourteen generations; and from the carrying away to Babylon unto the Anointed fourteen generations.

---

## The Birth of Yeshua (1:18-25)

**1:18** Now the birth of Yeshua the Anointed was on this wise: When his mother Mary had been betrothed to Joseph, before they came together she was found with child of the Holy Spirit.

**1:19** And Joseph her husband, being a righteous man, and not willing to make her a public example, was minded to put her away privily.

**1:20** But when he thought on these things, behold, an angel of the Lord appeared unto him in a dream, saying: "Joseph, son of David, fear not to take unto you Mary your wife; for that which is conceived in her is of the Holy Spirit.

**1:21** "And she shall bring forth a son; and you shall call his name Yeshua; for it is he that shall save his people from their sins."

**1:22** Now all this is come to pass, that it might be fulfilled which was spoken by the Lord through the prophet, saying:

**1:23** "Behold, the virgin shall be with child, and shall bring forth a son, and they shall call his name Immanuel"; which is, being interpreted, "God with us."

**1:24** And Joseph arose from his sleep, and did as the angel of the Lord commanded him, and took unto him his wife;

**1:25** And knew her not till she had brought forth a son: and he called his name Yeshua.

---

## Synthesis Notes

**Key Restorations:**

**Genealogy (1:1-17):**
**The Key Verse (1:1):**
"The book of the generation of Yeshua the Anointed."

*Biblos geneseos Iesou Christou*—book of generation.

**Yeshua:**
Hebrew *Yehoshua/Yeshua* = "YHWH saves." Greek *Iesous*. English "Jesus."

**Christos:**
Greek for Hebrew *Mashiach* = "Anointed One." Not a surname but a title.

"The son of David, the son of Abraham."

*Huiou David huiou Abraam*—Davidic and Abrahamic lineage.

**The Key Verses (1:2-6):**
"Abraham begot Isaac; and Isaac begot Jacob; and Jacob begot Judah."

Patriarchal line through Judah (not Joseph).

"Judah begot Perez and Zerah of Tamar."

**Tamar:**
First of four women mentioned—Gentile or irregular unions.

"Salmon begot Boaz of Rahab."

**Rahab:**
Canaanite prostitute who aided Israel (Joshua 2).

"Boaz begot Obed of Ruth."

**Ruth:**
Moabite great-grandmother of David.

"David begot Solomon of her that had been the wife of Uriah."

**Bathsheba:**
Mentioned indirectly—"wife of Uriah."

**The Key Verses (1:7-16):**
Davidic kings through Solomon to Jechoniah (Jehoiachin).

Post-exile: Shealtiel, Zerubbabel (cf. Haggai, Zechariah).

"Jacob begot Joseph the husband of Mary, of whom was born Yeshua."

*Ex hes egennethē Iesous*—"of whom" is feminine singular, referring to Mary.

**The Key Verse (1:17):**
"All the generations from Abraham unto David are fourteen generations."

*Pasai oun hai geneai... dekatessares*—14+14+14.

**Numerical Symbolism:**
David's name in Hebrew gematria = 4+6+4 = 14.

**Birth of Yeshua (1:18-25):**
**The Key Verses (1:18-19):**
"When his mother Mary had been betrothed to Joseph."

*Mnēsteutheisēs tēs mētros autou Marias tō Iōsēph*—betrothed.

**Betrothal:**
Legally binding, requiring divorce to dissolve.

"Before they came together she was found with child of the Holy Spirit."

*Prin ē synelthein autous heurethē en gastri echousa ek pneumatos hagiou*—of Holy Spirit.

"Joseph her husband, being a righteous man."

*Iōsēph ho anēr autēs dikaios ōn*—righteous.

"Not willing to make her a public example."

*Mē thelōn autēn deigmatisai*—not expose.

"Was minded to put her away privily."

*Eboulēthē lathra apolusai autēn*—private divorce.

**The Key Verses (1:20-21):**
"An angel of the Lord appeared unto him in a dream."

*Angelos kuriou kat' onar ephanē autō*—angel, dream.

"'Joseph, son of David.'"

*Iōsēph huios David*—Davidic lineage.

"'Fear not to take unto you Mary your wife.'"

*Mē phobēthēs paralabein Marian tēn gunaika sou*—take Mary.

"'That which is conceived in her is of the Holy Spirit.'"

*To gar en autē gennēthen ek pneumatos estin hagiou*—of Spirit.

"'She shall bring forth a son; and you shall call his name Yeshua.'"

*Texetai de huion kai kaleseis to onoma autou Iēsoun*—call Yeshua.

"'For it is he that shall save his people from their sins.'"

*Autos gar sōsei ton laon autou apo tōn hamartiōn autōn*—save from sins.

**Yeshua = YHWH Saves:**
The name explains the mission.

**The Key Verses (1:22-23):**
"That it might be fulfilled which was spoken by the Lord through the prophet."

*Hina plērōthē to rhēthen hypo kuriou dia tou prophētou*—fulfill.

"'Behold, the virgin shall be with child.'"

*Idou hē parthenos en gastri hexei*—virgin.

**Isaiah 7:14:**
Hebrew *almah* = "young woman." Greek *parthenos* = "virgin."

"'They shall call his name Immanuel.'"

*Kalesousin to onoma autou Emmanouēl*—Immanuel.

"'God with us.'"

*Meth' hēmōn ho theos*—with us God.

**The Key Verses (1:24-25):**
"Joseph arose from his sleep, and did as the angel of the Lord commanded him."

*Egertheis de ho Iōsēph... epoiēsen hōs prosetaxen autō ho angelos kuriou*—obeyed.

"Took unto him his wife."

*Parelaben tēn gunaika autou*—took wife.

"Knew her not till she had brought forth a son."

*Ouk eginōsken autēn heōs hou eteken huion*—knew not until.

"He called his name Yeshua."

*Ekalesen to onoma autou Iēsoun*—named Yeshua.

**Archetypal Layer:** Matthew 1 contains **"The book of the generation of Yeshua the Anointed, the son of David, the son of Abraham" (1:1)**, **the genealogy through Abraham, David, and the exile (1:2-17)**, **four women: Tamar, Rahab, Ruth, Bathsheba (1:3-6)**, **14+14+14 generations (1:17)**, **"before they came together she was found with child of the Holy Spirit" (1:18)**, **Joseph as righteous man planning quiet divorce (1:19)**, **"Joseph, son of David, fear not to take unto you Mary your wife" (1:20)**, **"you shall call his name Yeshua; for it is he that shall save his people from their sins" (1:21)**, **Isaiah 7:14 fulfilled: "the virgin shall be with child... they shall call his name Immanuel" (1:23)**, and **"he called his name Yeshua" (1:25)**.

**Ethical Inversion Applied:**
- "The book of the generation of Yeshua the Anointed"—generation
- "The son of David, the son of Abraham"—Davidic, Abrahamic
- "Abraham begot Isaac"—patriarchs
- "Judah begot Perez and Zerah of Tamar"—Tamar
- "Salmon begot Boaz of Rahab"—Rahab
- "Boaz begot Obed of Ruth"—Ruth
- "David begot Solomon of her that had been the wife of Uriah"—Bathsheba
- "Jacob begot Joseph the husband of Mary"—Joseph husband
- "Of whom was born Yeshua, who is called the Anointed"—born of Mary
- "All the generations... are fourteen generations"—14+14+14
- "When his mother Mary had been betrothed to Joseph"—betrothed
- "She was found with child of the Holy Spirit"—of Spirit
- "Joseph her husband, being a righteous man"—righteous
- "Not willing to make her a public example"—not expose
- "Was minded to put her away privily"—private divorce
- "An angel of the Lord appeared unto him in a dream"—angel, dream
- "'Joseph, son of David'"—Davidic
- "'Fear not to take unto you Mary your wife'"—take Mary
- "'That which is conceived in her is of the Holy Spirit'"—of Spirit
- "'She shall bring forth a son'"—son
- "'You shall call his name Yeshua'"—name Yeshua
- "'He shall save his people from their sins'"—save from sins
- "That it might be fulfilled"—fulfillment
- "'The virgin shall be with child'"—virgin
- "'They shall call his name Immanuel'"—Immanuel
- "'God with us'"—God with us
- "Joseph... did as the angel of the Lord commanded him"—obeyed
- "Took unto him his wife"—took wife
- "Knew her not till she had brought forth a son"—knew not until
- "He called his name Yeshua"—named Yeshua

**Modern Equivalent:** Matthew 1 establishes Yeshua's identity as Davidic Messiah and son of Abraham. The genealogy includes four women with irregular or Gentile connections—Tamar, Rahab, Ruth, Bathsheba—foreshadowing Yeshua's inclusive mission. The name "Yeshua" means "YHWH saves," directly explained: "he shall save his people from their sins" (1:21). "Immanuel" = "God with us" (1:23) declares the incarnation. Joseph, though not biological father, provides Davidic legal lineage.

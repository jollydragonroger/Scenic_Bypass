# Matthew 2: The Magi, Flight to Egypt, and Return

*From the Greek: Τοῦ δὲ Ἰησοῦ γεννηθέντος ἐν Βηθλέεμ (Tou de Iesou Gennēthentos en Bēthleem) — Now When Yeshua Was Born in Bethlehem*

---

## The Magi from the East (2:1-12)

**2:1** Now when Yeshua was born in Bethlehem of Judaea in the days of Herod the king, behold, wise men from the east came to Jerusalem,

**2:2** Saying: "Where is he that is born King of the Jews? For we saw his star in the east, and are come to worship him."

**2:3** And when Herod the king heard it, he was troubled, and all Jerusalem with him.

**2:4** And gathering together all the chief priests and scribes of the people, he inquired of them where the Anointed should be born.

**2:5** And they said unto him: "In Bethlehem of Judaea; for thus it is written through the prophet:

**2:6** "'And you Bethlehem, land of Judah, are in no wise least among the princes of Judah: for out of you shall come forth a governor, who shall be shepherd of my people Israel.'"

**2:7** Then Herod privily called the wise men, and learned of them exactly what time the star appeared.

**2:8** And he sent them to Bethlehem, and said: "Go and search out exactly concerning the young child; and when you have found him, bring me word, that I also may come and worship him."

**2:9** And they, having heard the king, went their way; and lo, the star, which they saw in the east, went before them, till it came and stood over where the young child was.

**2:10** And when they saw the star, they rejoiced with exceeding great joy.

**2:11** And they came into the house and saw the young child with Mary his mother; and they fell down and worshipped him; and opening their treasures they offered unto him gifts, gold and frankincense and myrrh.

**2:12** And being warned of God in a dream that they should not return to Herod, they departed into their own country another way.

---

## The Flight to Egypt (2:13-15)

**2:13** Now when they were departed, behold, an angel of the Lord appears to Joseph in a dream, saying: "Arise and take the young child and his mother, and flee into Egypt, and be there until I tell you: for Herod will seek the young child to destroy him."

**2:14** And he arose and took the young child and his mother by night, and departed into Egypt;

**2:15** And was there until the death of Herod: that it might be fulfilled which was spoken by the Lord through the prophet, saying: "Out of Egypt did I call my son."

---

## The Slaughter of the Innocents (2:16-18)

**2:16** Then Herod, when he saw that he was mocked of the wise men, was exceeding wroth, and sent forth, and slew all the male children that were in Bethlehem, and in all the borders thereof, from two years old and under, according to the time which he had exactly learned of the wise men.

**2:17** Then was fulfilled that which was spoken through Jeremiah the prophet, saying:

**2:18** "A voice was heard in Ramah, weeping and great mourning, Rachel weeping for her children; and she would not be comforted, because they are not."

---

## The Return to Nazareth (2:19-23)

**2:19** But when Herod was dead, behold, an angel of the Lord appears in a dream to Joseph in Egypt, saying:

**2:20** "Arise and take the young child and his mother, and go into the land of Israel: for they are dead that sought the young child's life."

**2:21** And he arose and took the young child and his mother, and came into the land of Israel.

**2:22** But when he heard that Archelaus was reigning over Judaea in the room of his father Herod, he was afraid to go thither; and being warned of God in a dream, he withdrew into the parts of Galilee,

**2:23** And came and dwelt in a city called Nazareth; that it might be fulfilled which was spoken through the prophets, that he should be called a Nazarene.

---

## Synthesis Notes

**Key Restorations:**

**The Magi (2:1-12):**
**The Key Verses (2:1-2):**
"'When Yeshua was born in Bethlehem of Judaea.'"

*Tou de Iesou gennēthentos en Bēthleem tēs Ioudaias*—Bethlehem.

"'In the days of Herod the king.'"

*En hēmerais Hērōdou tou basileōs*—Herod the Great, died 4 BCE.

"'Wise men from the east came to Jerusalem.'"

*Magoi apo anatolōn paregenonto eis Hierosolyma*—Magi.

**Magoi:**
Persian priestly caste; astrologers/wise men. Number unspecified.

"''Where is he that is born King of the Jews?''"

*Pou estin ho techtheis basileus tōn Ioudaiōn*—born King.

"''We saw his star in the east.''"

*Eidomen gar autou ton astera en tē anatolē*—his star.

"''Are come to worship him.''"

*Kai ēlthomen proskynēsai autō*—worship.

**The Key Verses (2:3-6):**
"'Herod the king... was troubled, and all Jerusalem with him.'"

*Akousas de ho basileus Hērōdēs etarachthē kai pasa Hierosolyma met' autou*—troubled.

"'Gathering together all the chief priests and scribes.'"

*Synagagōn pantas tous archiereis kai grammateis tou laou*—gathered.

"'He inquired of them where the Anointed should be born.'"

*Epynthaneto par' autōn pou ho Christos gennatai*—where born.

"''In Bethlehem of Judaea.''"

*En Bēthleem tēs Ioudaias*—Bethlehem.

"''For thus it is written through the prophet.''"

*Houtōs gar gegraptai dia tou prophētou*—written.

**Micah 5:2:**
Quoted with modifications.

"''Out of you shall come forth a governor, who shall be shepherd of my people Israel.''"

*Ek sou gar exeleusetai hēgoumenos hostis poimanei ton laon mou ton Israēl*—governor, shepherd.

**The Key Verses (2:7-12):**
"'Herod privily called the wise men.'"

*Tote Hērōdēs lathra kalesas tous magous*—secretly.

"'Learned of them exactly what time the star appeared.'"

*Ēkribōsen par' autōn ton chronon tou phainomenou asteros*—star's time.

"''Go and search out exactly concerning the young child.''"

*Poreuthentes exetasate akribōs peri tou paidiou*—search.

"''When you have found him, bring me word, that I also may come and worship him.''"

*Epan de heurēte apangeilate moi hopōs kagō elthōn proskynēsō autō*—deceit.

"'The star... went before them, till it came and stood over where the young child was.'"

*Ho astēr... proēgen autous heōs elthōn estathē epanō hou ēn to paidion*—star leads.

"'They rejoiced with exceeding great joy.'"

*Echarēsan charan megalēn sphodra*—great joy.

"'They came into the house and saw the young child with Mary his mother.'"

*Elthontes eis tēn oikian eidon to paidion meta Marias tēs mētros autou*—house, not manger.

"'They fell down and worshipped him.'"

*Pesontes prosekynēsan autō*—worshipped.

"'Opening their treasures they offered unto him gifts, gold and frankincense and myrrh.'"

*Anoixantes tous thēsaurous autōn prosēnenkan autō dōra chryson kai libanon kai smyrnan*—three gifts.

**Gold, Frankincense, Myrrh:**
Traditionally: kingship, deity, death/burial.

"'Being warned of God in a dream that they should not return to Herod.'"

*Chrēmatisthentes kat' onar mē anakampsai pros Hērōdēn*—warned.

"'They departed into their own country another way.'"

*Di' allēs hodou anechōrēsan eis tēn chōran autōn*—another way.

**Flight to Egypt (2:13-15):**
**The Key Verses (2:13-15):**
"'An angel of the Lord appears to Joseph in a dream.'"

*Angelos kyriou phainetai kat' onar tō Iōsēph*—angel, dream.

"''Arise and take the young child and his mother, and flee into Egypt.''"

*Egertheis paralabe to paidion kai tēn mētera autou kai pheuge eis Aigypton*—flee Egypt.

"''Herod will seek the young child to destroy him.''"

*Mellei gar Hērōdēs zētein to paidion tou apolesai auto*—destroy.

"'He arose and took the young child and his mother by night.'"

*Ho de egertheis parelaben to paidion kai tēn mētera autou nyktos*—by night.

"'Was there until the death of Herod.'"

*Kai ēn ekei heōs tēs teleutēs Hērōdou*—until Herod's death.

"''Out of Egypt did I call my son.''"

*Ex Aigyptou ekalesa ton huion mou*—out of Egypt.

**Hosea 11:1:**
Originally about Israel; Matthew applies to Yeshua as true Israel.

**Slaughter of the Innocents (2:16-18):**
**The Key Verses (2:16-18):**
"'Herod... was exceeding wroth.'"

*Tote Hērōdēs... ethymōthē lian*—wroth.

"'Slew all the male children that were in Bethlehem... from two years old and under.'"

*Anellen pantas tous paidas tous en Bēthleem... apo dietous kai katōterō*—slew children.

"'According to the time which he had exactly learned of the wise men.'"

*Kata ton chronon hon ēkribōsen para tōn magōn*—calculated time.

"''A voice was heard in Ramah, weeping and great mourning.''"

*Phōnē en Rhama ēkousthē klauthmοs kai odyrmos polys*—weeping.

**Jeremiah 31:15:**
Rachel weeping for children.

"''Rachel weeping for her children.''"

*Rhachēl klaiousa ta tekna autēs*—Rachel.

"''She would not be comforted, because they are not.''"

*Kai ouk ēthelen paraklēthēnai hoti ouk eisin*—not comforted.

**Return to Nazareth (2:19-23):**
**The Key Verses (2:19-23):**
"'When Herod was dead... an angel of the Lord appears in a dream to Joseph.'"

*Teleutēsantos de tou Hērōdou... angelos kyriou phainetai kat' onar tō Iōsēph*—after death.

"''Arise and take the young child and his mother, and go into the land of Israel.''"

*Egertheis paralabe to paidion kai tēn mētera autou kai poreuou eis gēn Israēl*—to Israel.

"''They are dead that sought the young child's life.''"

*Tethnekasin gar hoi zētountes tēn psychēn tou paidiou*—dead.

**Echoes Exodus 4:19:**
"All the men are dead who sought your life."

"'Archelaus was reigning over Judaea in the room of his father Herod.'"

*Archelaos basileuei tēs Ioudaias anti tou patros autou Hērōdou*—Archelaus.

"'Being warned of God in a dream, he withdrew into the parts of Galilee.'"

*Chrēmatistheis de kat' onar anechōrēsen eis ta merē tēs Galilaias*—Galilee.

"'Came and dwelt in a city called Nazareth.'"

*Elthōn katōkēsen eis polin legomenēn Nazaret*—Nazareth.

"''He should be called a Nazarene.''"

*Hoti Nazōraios klēthēsetai*—Nazarene.

**Nazōraios:**
Possibly wordplay on *netzer* (branch, Isaiah 11:1) or *nazir* (consecrated one).

**Archetypal Layer:** Matthew 2 contains **"wise men from the east came to Jerusalem" (2:1)**, **"Where is he that is born King of the Jews? For we saw his star in the east" (2:2)**, **Herod troubled, all Jerusalem with him (2:3)**, **Micah 5:2 fulfilled: "Out of you [Bethlehem] shall come forth a governor, who shall be shepherd of my people Israel" (2:6)**, **"they fell down and worshipped him; and... offered unto him gifts, gold and frankincense and myrrh" (2:11)**, **"flee into Egypt... for Herod will seek the young child to destroy him" (2:13)**, **Hosea 11:1 fulfilled: "Out of Egypt did I call my son" (2:15)**, **Herod slaying children two years and under (2:16)**, **Jeremiah 31:15 fulfilled: "Rachel weeping for her children" (2:18)**, and **"he should be called a Nazarene" (2:23)**.

**Ethical Inversion Applied:**
- "'When Yeshua was born in Bethlehem of Judaea'"—Bethlehem
- "'In the days of Herod the king'"—Herod
- "'Wise men from the east came to Jerusalem'"—Magi
- "''Where is he that is born King of the Jews?''"—born King
- "''We saw his star in the east''"—star
- "''Are come to worship him''"—worship
- "'Herod the king... was troubled'"—troubled
- "'All Jerusalem with him'"—Jerusalem troubled
- "'Gathering together all the chief priests and scribes'"—gathered
- "''In Bethlehem of Judaea''"—Bethlehem
- "''Out of you shall come forth a governor''"—governor
- "''Who shall be shepherd of my people Israel''"—shepherd
- "'Herod privily called the wise men'"—secretly
- "'Learned of them exactly what time the star appeared'"—star's time
- "''Go and search out exactly concerning the young child''"—search
- "'The star... went before them'"—star leads
- "'They rejoiced with exceeding great joy'"—great joy
- "'They came into the house'"—house
- "'Saw the young child with Mary his mother'"—Mary
- "'They fell down and worshipped him'"—worshipped
- "'Offered unto him gifts, gold and frankincense and myrrh'"—three gifts
- "'Being warned of God in a dream'"—warned
- "'They departed into their own country another way'"—another way
- "'An angel of the Lord appears to Joseph in a dream'"—angel
- "''Flee into Egypt''"—flee Egypt
- "''Herod will seek the young child to destroy him''"—destroy
- "'He arose and took the young child and his mother by night'"—by night
- "''Out of Egypt did I call my son''"—out of Egypt
- "'Herod... was exceeding wroth'"—wroth
- "'Slew all the male children... from two years old and under'"—slew children
- "''A voice was heard in Ramah, weeping''"—weeping
- "''Rachel weeping for her children''"—Rachel
- "'Archelaus was reigning over Judaea'"—Archelaus
- "'Being warned of God in a dream'"—warned
- "'He withdrew into the parts of Galilee'"—Galilee
- "'Came and dwelt in a city called Nazareth'"—Nazareth
- "''He should be called a Nazarene''"—Nazarene

**Modern Equivalent:** Matthew 2 presents Yeshua as the true King of the Jews, threatened by the false king Herod. The Magi (Gentiles) recognize and worship Him while Jewish leaders merely inform Herod. Four OT passages are "fulfilled": Micah 5:2 (Bethlehem), Hosea 11:1 (out of Egypt), Jeremiah 31:15 (Rachel weeping), and a prophetic wordplay on "Nazarene." Yeshua recapitulates Israel's story: born in David's city, goes to Egypt, called back, threatened by a murderous king.

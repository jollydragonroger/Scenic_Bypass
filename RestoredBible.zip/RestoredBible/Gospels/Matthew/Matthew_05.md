# Matthew 5: The Sermon on the Mount — Beatitudes and Greater Righteousness

*From the Greek: Ἰδὼν δὲ τοὺς ὄχλους ἀνέβη εἰς τὸ ὄρος (Idōn de tous Ochlous Anebē eis to Oros) — And Seeing the Multitudes, He Went Up into the Mountain*

---

## The Beatitudes (5:1-12)

**5:1** And seeing the multitudes, he went up into the mountain: and when he had sat down, his disciples came unto him:

**5:2** And he opened his mouth and taught them, saying:

**5:3** "Blessed are the poor in spirit: for theirs is the kingdom of heaven.

**5:4** "Blessed are they that mourn: for they shall be comforted.

**5:5** "Blessed are the meek: for they shall inherit the earth.

**5:6** "Blessed are they that hunger and thirst after righteousness: for they shall be filled.

**5:7** "Blessed are the merciful: for they shall obtain mercy.

**5:8** "Blessed are the pure in heart: for they shall see God.

**5:9** "Blessed are the peacemakers: for they shall be called sons of God.

**5:10** "Blessed are they that have been persecuted for righteousness' sake: for theirs is the kingdom of heaven.

**5:11** "Blessed are you when men shall reproach you, and persecute you, and say all manner of evil against you falsely, for my sake.

**5:12** "Rejoice, and be exceeding glad: for great is your reward in heaven: for so persecuted they the prophets that were before you."

---

## Salt and Light (5:13-16)

**5:13** "You are the salt of the earth: but if the salt have lost its savour, wherewith shall it be salted? It is thenceforth good for nothing, but to be cast out and trodden under foot of men.

**5:14** "You are the light of the world. A city set on a hill cannot be hid.

**5:15** "Neither do men light a lamp, and put it under the bushel, but on the stand; and it shines unto all that are in the house.

**5:16** "Even so let your light shine before men; that they may see your good works, and glorify your Father who is in heaven."

---

## Yeshua and the Torah (5:17-20)

**5:17** "Think not that I came to destroy the law or the prophets: I came not to destroy, but to fulfil.

**5:18** "For verily I say unto you, Till heaven and earth pass away, one jot or one tittle shall in no wise pass away from the law, till all things be accomplished.

**5:19** "Whosoever therefore shall break one of these least commandments, and shall teach men so, shall be called least in the kingdom of heaven: but whosoever shall do and teach them, he shall be called great in the kingdom of heaven.

**5:20** "For I say unto you, that except your righteousness shall exceed the righteousness of the scribes and Pharisees, you shall in no wise enter into the kingdom of heaven."

---

## Six Antitheses (5:21-48)

**5:21** "You have heard that it was said to them of old time, 'You shall not kill'; and whosoever shall kill shall be in danger of the judgment:

**5:22** "But I say unto you, that every one who is angry with his brother shall be in danger of the judgment; and whosoever shall say to his brother, 'Raca,' shall be in danger of the council; and whosoever shall say, 'You fool,' shall be in danger of the Gehenna of fire.

**5:23** "If therefore you are offering your gift at the altar, and there remember that your brother has aught against you,

**5:24** "Leave there your gift before the altar, and go your way, first be reconciled to your brother, and then come and offer your gift.

**5:25** "Agree with your adversary quickly, while you are with him in the way; lest haply the adversary deliver you to the judge, and the judge deliver you to the officer, and you be cast into prison.

**5:26** "Verily I say unto you, You shall by no means come out thence, till you have paid the last farthing.

**5:27** "You have heard that it was said, 'You shall not commit adultery':

**5:28** "But I say unto you, that every one that looks on a woman to lust after her has committed adultery with her already in his heart.

**5:29** "And if your right eye causes you to stumble, pluck it out, and cast it from you: for it is profitable for you that one of your members should perish, and not your whole body be cast into Gehenna.

**5:30** "And if your right hand causes you to stumble, cut it off, and cast it from you: for it is profitable for you that one of your members should perish, and not your whole body go into Gehenna.

**5:31** "It was said also, 'Whosoever shall put away his wife, let him give her a writing of divorcement':

**5:32** "But I say unto you, that every one that puts away his wife, saving for the cause of fornication, makes her an adulteress: and whosoever shall marry her when she is put away commits adultery.

**5:33** "Again, you have heard that it was said to them of old time, 'You shall not forswear yourself, but shall perform unto the Lord your oaths':

**5:34** "But I say unto you, Swear not at all; neither by the heaven, for it is the throne of God;

**5:35** "Nor by the earth, for it is the footstool of his feet; nor by Jerusalem, for it is the city of the great King.

**5:36** "Neither shall you swear by your head, for you cannot make one hair white or black.

**5:37** "But let your speech be, Yea, yea; Nay, nay: and whatsoever is more than these is of the evil one.

**5:38** "You have heard that it was said, 'An eye for an eye, and a tooth for a tooth':

**5:39** "But I say unto you, Resist not him that is evil: but whosoever smites you on your right cheek, turn to him the other also.

**5:40** "And if any man would go to law with you, and take away your coat, let him have your cloak also.

**5:41** "And whosoever shall compel you to go one mile, go with him two.

**5:42** "Give to him that asks of you, and from him that would borrow of you turn not away.

**5:43** "You have heard that it was said, 'You shall love your neighbour, and hate your enemy':

**5:44** "But I say unto you, Love your enemies, and pray for them that persecute you;

**5:45** "That you may be sons of your Father who is in heaven: for he makes his sun to rise on the evil and the good, and sends rain on the just and the unjust.

**5:46** "For if you love them that love you, what reward have you? Do not even the publicans the same?

**5:47** "And if you salute your brethren only, what do you more than others? Do not even the Gentiles the same?

**5:48** "You therefore shall be perfect, as your heavenly Father is perfect."

---

## Synthesis Notes

**Key Restorations:**

**The Beatitudes (5:1-12):**
**The Key Verses (5:1-2):**
"'Seeing the multitudes, he went up into the mountain.'"

*Idōn de tous ochlous anebē eis to oros*—mountain.

**Mountain:**
Echoes Sinai—Yeshua as new Moses.

"'When he had sat down, his disciples came unto him.'"

*Kai kathisantos autou prosēlthon autō hoi mathētai autou*—sat.

**Sitting:**
Posture of authoritative teaching.

**The Key Verses (5:3-12):**
"''Blessed are the poor in spirit.''"

*Makarioi hoi ptōchoi tō pneumati*—poor in spirit.

**Makarios:**
"Blessed/happy/fortunate"—not mere emotion but divine favor.

"''For theirs is the kingdom of heaven.''"

*Hoti autōn estin hē basileia tōn ouranōn*—kingdom.

"''Blessed are they that mourn: for they shall be comforted.''"

*Makarioi hoi penthountes hoti autoi paraklēthēsontai*—comforted.

"''Blessed are the meek: for they shall inherit the earth.''"

*Makarioi hoi praeis hoti autoi klēronomēsousin tēn gēn*—inherit earth.

**Psalm 37:11.**

"''Blessed are they that hunger and thirst after righteousness.''"

*Makarioi hoi peinōntes kai dipsōntes tēn dikaiosynēn*—hunger, thirst.

"''Blessed are the merciful: for they shall obtain mercy.''"

*Makarioi hoi eleēmones hoti autoi eleēthēsontai*—mercy.

"''Blessed are the pure in heart: for they shall see God.''"

*Makarioi hoi katharoi tē kardia hoti autoi ton theon opsontai*—see God.

"''Blessed are the peacemakers: for they shall be called sons of God.''"

*Makarioi hoi eirēnopoioi hoti autoi huioi theou klēthēsontai*—peacemakers.

"''Blessed are they that have been persecuted for righteousness' sake.''"

*Makarioi hoi dediōgmenoi heneken dikaiosynēs*—persecuted.

"''Blessed are you when men shall reproach you, and persecute you.''"

*Makarioi este hotan oneidisōsin hymas kai diōxōsin*—reproach.

"''Rejoice, and be exceeding glad: for great is your reward in heaven.''"

*Chairete kai agalliasthe hoti ho misthos hymōn polys en tois ouranois*—rejoice.

"''So persecuted they the prophets that were before you.''"

*Houtōs gar ediōxan tous prophētas tous pro hymōn*—prophets.

**Salt and Light (5:13-16):**
**The Key Verses (5:13-16):**
"''You are the salt of the earth.''"

*Hymeis este to halas tēs gēs*—salt.

"''If the salt have lost its savour, wherewith shall it be salted?''"

*Ean de to halas mōranthē en tini halisthēsetai*—lost savour.

"''You are the light of the world.''"

*Hymeis este to phōs tou kosmou*—light.

"''A city set on a hill cannot be hid.''"

*Ou dynatai polis krybēnai epanō orous keimenē*—city on hill.

"''Let your light shine before men.''"

*Houtōs lampsatō to phōs hymōn emprosthen tōn anthrōpōn*—shine.

"''That they may see your good works, and glorify your Father who is in heaven.''"

*Hopōs idōsin hymōn ta kala erga kai doxasōsin ton patera hymōn ton en tois ouranois*—glorify Father.

**Yeshua and the Torah (5:17-20):**
**The Key Verses (5:17-20):**
"''Think not that I came to destroy the law or the prophets.''"

*Mē nomisēte hoti ēlthon katalysai ton nomon ē tous prophētas*—not destroy.

"''I came not to destroy, but to fulfil.''"

*Ouk ēlthon katalysai alla plērōsai*—fulfil.

**Plērōsai:**
"To fulfil/fill full"—bring to intended meaning.

"''Till heaven and earth pass away, one jot or one tittle shall in no wise pass away from the law.''"

*Heōs an parelthē ho ouranos kai hē gē iōta hen ē mia keraia ou mē parelthē apo tou nomou*—jot, tittle.

**Iōta:**
Hebrew *yod*, smallest letter.

**Keraia:**
"Tittle/horn"—smallest stroke distinguishing letters.

"''Except your righteousness shall exceed the righteousness of the scribes and Pharisees.''"

*Ean mē perisseusē hymōn hē dikaiosynē pleon tōn grammateōn kai Pharisaiōn*—exceed.

**Six Antitheses (5:21-48):**
**Structure:**
"You have heard... but I say unto you"—intensifying, not abolishing.

**First Antithesis (5:21-26):**
"''You shall not kill.''"—Extends to anger, insults.

**Raca:**
Aramaic insult, "empty-headed."

**Gehenna:**
Valley of Hinnom, symbol of judgment.

**Second Antithesis (5:27-30):**
"''You shall not commit adultery.''"—Extends to lustful looking.

**Third Antithesis (5:31-32):**
Divorce—restricts to *porneia* (sexual immorality).

**Fourth Antithesis (5:33-37):**
Oaths—simple yes/no instead.

**Fifth Antithesis (5:38-42):**
"''An eye for an eye.''"—Non-retaliation, going beyond.

**"Turn the other cheek":**
Right cheek struck = backhanded insult; offer left = demand equal treatment.

**"Go with him two":**
Roman soldiers could compel civilians to carry loads one mile.

**Sixth Antithesis (5:43-48):**
"''Love your neighbour.''"—Extends to enemies.

"''Be perfect, as your heavenly Father is perfect.''"

*Esesthe oun hymeis teleioi hōs ho patēr hymōn ho ouranios teleios estin*—perfect.

**Teleios:**
"Complete/mature/whole"—not sinless perfection.

**Archetypal Layer:** Matthew 5 contains **the Beatitudes (5:3-12)**: poor in spirit, mourning, meek, hunger for righteousness, merciful, pure in heart, peacemakers, persecuted, **"You are the salt of the earth... the light of the world" (5:13-14)**, **"Think not that I came to destroy the law or the prophets: I came not to destroy, but to fulfil" (5:17)**, **"one jot or one tittle shall in no wise pass away from the law" (5:18)**, **"except your righteousness shall exceed the righteousness of the scribes and Pharisees" (5:20)**, **six antitheses intensifying Torah (5:21-48)**: anger/murder, lust/adultery, divorce, oaths, retaliation, love of enemies, and **"You therefore shall be perfect, as your heavenly Father is perfect" (5:48)**.

**Modern Equivalent:** Matthew 5 begins the Sermon on the Mount (5-7), Yeshua's definitive ethical teaching. The Beatitudes reverse worldly values—the poor, mourning, meek, and persecuted are blessed. "Fulfil" (5:17) means bringing Torah to its intended goal, not abolishing it. The six antitheses don't contradict Torah but intensify it—from external compliance to heart transformation. "Be perfect" (5:48) calls for wholeness, completeness in love like the Father's indiscriminate love.

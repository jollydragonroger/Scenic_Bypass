# Matthew 6: The Sermon on the Mount — True Piety and Trust

*From the Greek: Προσέχετε τὴν δικαιοσύνην ὑμῶν (Prosechete tēn Dikaiosynēn Hymōn) — Take Heed That You Do Not Your Righteousness*

---

## True Piety: Almsgiving, Prayer, Fasting (6:1-18)

**6:1** "Take heed that you do not your righteousness before men, to be seen of them: else you have no reward with your Father who is in heaven.

**6:2** "When therefore you do alms, sound not a trumpet before you, as the hypocrites do in the synagogues and in the streets, that they may have glory of men. Verily I say unto you, They have received their reward.

**6:3** "But when you do alms, let not your left hand know what your right hand does:

**6:4** "That your alms may be in secret: and your Father who sees in secret shall recompense you.

**6:5** "And when you pray, you shall not be as the hypocrites: for they love to stand and pray in the synagogues and in the corners of the streets, that they may be seen of men. Verily I say unto you, They have received their reward.

**6:6** "But you, when you pray, enter into your inner chamber, and having shut your door, pray to your Father who is in secret, and your Father who sees in secret shall recompense you.

**6:7** "And in praying use not vain repetitions, as the Gentiles do: for they think that they shall be heard for their much speaking.

**6:8** "Be not therefore like unto them: for your Father knows what things you have need of, before you ask him.

**6:9** "After this manner therefore pray: Our Father who art in heaven, Hallowed be your name.

**6:10** "Your kingdom come. Your will be done, as in heaven, so on earth.

**6:11** "Give us this day our daily bread.

**6:12** "And forgive us our debts, as we also have forgiven our debtors.

**6:13** "And bring us not into temptation, but deliver us from the evil one.

**6:14** "For if you forgive men their trespasses, your heavenly Father will also forgive you.

**6:15** "But if you forgive not men their trespasses, neither will your Father forgive your trespasses.

**6:16** "Moreover when you fast, be not, as the hypocrites, of a sad countenance: for they disfigure their faces, that they may be seen of men to fast. Verily I say unto you, They have received their reward.

**6:17** "But you, when you fast, anoint your head, and wash your face;

**6:18** "That you be not seen of men to fast, but of your Father who is in secret: and your Father, who sees in secret, shall recompense you."

---

## Treasures and the Eye (6:19-24)

**6:19** "Lay not up for yourselves treasures upon the earth, where moth and rust consume, and where thieves break through and steal:

**6:20** "But lay up for yourselves treasures in heaven, where neither moth nor rust consumes, and where thieves do not break through nor steal:

**6:21** "For where your treasure is, there will your heart be also.

**6:22** "The lamp of the body is the eye: if therefore your eye be single, your whole body shall be full of light.

**6:23** "But if your eye be evil, your whole body shall be full of darkness. If therefore the light that is in you be darkness, how great is the darkness!

**6:24** "No man can serve two masters: for either he will hate the one, and love the other; or else he will hold to one, and despise the other. You cannot serve God and mammon."

---

## Anxiety and Trust (6:25-34)

**6:25** "Therefore I say unto you, Be not anxious for your life, what you shall eat, or what you shall drink; nor yet for your body, what you shall put on. Is not the life more than the food, and the body than the raiment?

**6:26** "Behold the birds of the heaven, that they sow not, neither do they reap, nor gather into barns; and your heavenly Father feeds them. Are not you of much more value than they?

**6:27** "And which of you by being anxious can add one cubit unto the measure of his life?

**6:28** "And why are you anxious concerning raiment? Consider the lilies of the field, how they grow; they toil not, neither do they spin:

**6:29** "Yet I say unto you, that even Solomon in all his glory was not arrayed like one of these.

**6:30** "But if God so clothe the grass of the field, which today is, and tomorrow is cast into the oven, shall he not much more clothe you, O you of little faith?

**6:31** "Be not therefore anxious, saying, What shall we eat? or, What shall we drink? or, Wherewithal shall we be clothed?

**6:32** "For after all these things do the Gentiles seek; for your heavenly Father knows that you have need of all these things.

**6:33** "But seek first his kingdom, and his righteousness; and all these things shall be added unto you.

**6:34** "Be not therefore anxious for the morrow: for the morrow will be anxious for itself. Sufficient unto the day is the evil thereof."

---

## Synthesis Notes

**Key Restorations:**

**True Piety (6:1-18):**
**The Key Verses (6:1-4):**
"''Take heed that you do not your righteousness before men, to be seen of them.''"

*Prosechete tēn dikaiosynēn hymōn mē poiein emprosthen tōn anthrōpōn pros to theathēnai autois*—not for show.

"''When therefore you do alms, sound not a trumpet before you.''"

*Hotan oun poiēs eleēmosynēn mē salpisēs emprosthen sou*—no trumpet.

"''As the hypocrites do.''"

*Hōsper hoi hypokritai poiousin*—hypocrites.

**Hypokritēs:**
Originally "actor"—one who plays a role.

"''They have received their reward.''"

*Apechousin ton misthon autōn*—received in full.

"''Let not your left hand know what your right hand does.''"

*Mē gnōtō hē aristera sou ti poiei hē dexia sou*—secret.

"''Your Father who sees in secret shall recompense you.''"

*Ho patēr sou ho blepōn en tō kryptō apodōsei soi*—Father sees.

**The Key Verses (6:5-8):**
"''When you pray, you shall not be as the hypocrites.''"

*Kai hotan proseuchēsthe ouk esesthe hōs hoi hypokritai*—not like hypocrites.

"''They love to stand and pray in the synagogues and in the corners of the streets.''"

*Hoti philousin en tais synagōgais kai en tais gōniais tōn plateiōn hestōtes proseuchesthai*—public display.

"''Enter into your inner chamber, and having shut your door.''"

*Eiselthe eis to tameion sou kai kleisas tēn thyran sou*—private.

"''In praying use not vain repetitions, as the Gentiles do.''"

*Proseuchomenoi de mē battalogēsēte hōsper hoi ethnikoi*—no babbling.

"''Your Father knows what things you have need of, before you ask him.''"

*Oiden gar ho patēr hymōn hōn chreian echete pro tou hymas aitēsai auton*—Father knows.

**The Lord's Prayer (6:9-13):**
"''Our Father who art in heaven.''"

*Pater hēmōn ho en tois ouranois*—Father in heaven.

"''Hallowed be your name.''"

*Hagiasthētō to onoma sou*—sanctified.

"''Your kingdom come.''"

*Elthetō hē basileia sou*—kingdom come.

"''Your will be done, as in heaven, so on earth.''"

*Genēthētō to thelēma sou hōs en ouranō kai epi gēs*—will done.

"''Give us this day our daily bread.''"

*Ton arton hēmōn ton epiousion dos hēmin sēmeron*—daily bread.

**Epiousios:**
"Daily/necessary/for today"—unique word.

"''Forgive us our debts, as we also have forgiven our debtors.''"

*Kai aphes hēmin ta opheilēmata hēmōn hōs kai hēmeis aphēkamen tois opheiletais hēmōn*—debts.

"''Bring us not into temptation, but deliver us from the evil one.''"

*Kai mē eisenegkēs hēmas eis peirasmon alla rhysai hēmas apo tou ponērou*—temptation, evil one.

**The Key Verses (6:14-18):**
"''If you forgive men their trespasses, your heavenly Father will also forgive you.''"

*Ean gar aphēte tois anthrōpois ta paraptōmata autōn aphēsei kai hymin ho patēr hymōn ho ouranios*—forgive, forgiven.

"''When you fast, be not, as the hypocrites, of a sad countenance.''"

*Hotan de nēsteuēte mē ginesthe hōs hoi hypokritai skythrōpoi*—not sad.

"''They disfigure their faces, that they may be seen of men to fast.''"

*Aphanizousin gar ta prosōpa autōn hopōs phanōsin tois anthrōpois nēsteuontes*—disfigure.

"''Anoint your head, and wash your face.''"

*Aleipsai sou tēn kephalēn kai to prosōpon sou nipsai*—anoint, wash.

**Treasures and the Eye (6:19-24):**
**The Key Verses (6:19-24):**
"''Lay not up for yourselves treasures upon the earth.''"

*Mē thēsaurizete hymin thēsaurous epi tēs gēs*—not on earth.

"''Where moth and rust consume, and where thieves break through and steal.''"

*Hopou sēs kai brōsis aphanizei kai hopou kleptai dioryssousin kai kleptousin*—moth, rust, thieves.

"''Lay up for yourselves treasures in heaven.''"

*Thēsaurizete de hymin thēsaurous en ouranō*—in heaven.

"''Where your treasure is, there will your heart be also.''"

*Hopou gar estin ho thēsauros sou ekei estai kai hē kardia sou*—treasure, heart.

"''The lamp of the body is the eye.''"

*Ho lychnos tou sōmatos estin ho ophthalmos*—eye is lamp.

"''If therefore your eye be single, your whole body shall be full of light.''"

*Ean oun ē ho ophthalmos sou haplous holon to sōma sou phōteinon estai*—single eye.

**Haplous:**
"Single/simple/generous"—undivided loyalty.

"''If your eye be evil, your whole body shall be full of darkness.''"

*Ean de ho ophthalmos sou ponēros ē holon to sōma sou skoteinon estai*—evil eye.

**Ponēros Ophthalmos:**
"Evil eye"—stinginess, envy in Semitic idiom.

"''No man can serve two masters.''"

*Oudeis dynatai dysi kyriois douleuein*—two masters.

"''You cannot serve God and mammon.''"

*Ou dynasthe theō douleuein kai mamōna*—God and mammon.

**Mamōna:**
Aramaic for wealth/possessions personified.

**Anxiety and Trust (6:25-34):**
**The Key Verses (6:25-34):**
"''Be not anxious for your life.''"

*Mē merimnate tē psychē hymōn*—don't worry.

"''Is not the life more than the food, and the body than the raiment?''"

*Ouchi hē psychē pleion estin tēs trophēs kai to sōma tou endymatos*—life more.

"''Behold the birds of the heaven.''"

*Emblepsate eis ta peteina tou ouranou*—birds.

"''Your heavenly Father feeds them.''"

*Ho patēr hymōn ho ouranios trephei auta*—Father feeds.

"''Are not you of much more value than they?''"

*Ouch hymeis mallon diapherete autōn*—more value.

"''Which of you by being anxious can add one cubit unto the measure of his life?''"

*Tis de ex hymōn merimnōn dynatai prostheinai epi tēn hēlikian autou pēchyn hena*—add to life.

"''Consider the lilies of the field.''"

*Katamathete ta krina tou agrou*—lilies.

"''Even Solomon in all his glory was not arrayed like one of these.''"

*Oude Solomōn en pasē tē doxē autou periebaleto hōs hen toutōn*—Solomon.

"''O you of little faith.''"

*Oligopistoi*—little faith.

"''Seek first his kingdom, and his righteousness.''"

*Zēteite de prōton tēn basileian tou theou kai tēn dikaiosynēn autou*—seek first.

"''All these things shall be added unto you.''"

*Kai tauta panta prostethēsetai hymin*—added.

"''Be not therefore anxious for the morrow.''"

*Mē oun merimnēsēte eis tēn aurion*—not tomorrow.

"''Sufficient unto the day is the evil thereof.''"

*Arketon tē hēmera hē kakia autēs*—sufficient.

**Archetypal Layer:** Matthew 6 contains **three acts of piety done secretly: almsgiving (6:2-4), prayer (6:5-15), fasting (6:16-18)**, **"They have received their reward" (6:2, 5, 16)**, **the Lord's Prayer (6:9-13)**: "Our Father... Hallowed be your name... Your kingdom come... Your will be done... Give us this day our daily bread... Forgive us our debts... Bring us not into temptation... deliver us from the evil one", **"If you forgive men their trespasses, your heavenly Father will also forgive you" (6:14)**, **"Where your treasure is, there will your heart be also" (6:21)**, **"The lamp of the body is the eye" (6:22)**, **"You cannot serve God and mammon" (6:24)**, **"Behold the birds of the heaven" (6:26)**, **"Consider the lilies of the field" (6:28)**, **"Solomon in all his glory was not arrayed like one of these" (6:29)**, **"Seek first his kingdom, and his righteousness" (6:33)**, and **"Be not therefore anxious for the morrow" (6:34)**.

**Modern Equivalent:** Matthew 6 addresses religious practice (almsgiving, prayer, fasting) and material anxiety. The key theme: secrecy versus display. The Father "who sees in secret" rewards genuine piety. The Lord's Prayer is the model prayer—brief, comprehensive, God-centered. "You cannot serve God and mammon" (6:24) presents an absolute choice. The antidote to anxiety is trust in the Father who feeds birds and clothes lilies. "Seek first his kingdom" (6:33) is the priority that resolves anxiety.

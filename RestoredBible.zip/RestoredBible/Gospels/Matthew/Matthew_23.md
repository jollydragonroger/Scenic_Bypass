# Matthew 23: Woes to the Scribes and Pharisees

*From the Greek: Τότε ὁ Ἰησοῦς ἐλάλησεν τοῖς ὄχλοις (Tote ho Iesous Elalēsen tois Ochlois) — Then Yeshua Spoke to the Multitudes*

---

## Warning against Hypocrisy (23:1-12)

**23:1** Then spoke Yeshua to the multitudes and to his disciples,

**23:2** Saying: "The scribes and the Pharisees sit on Moses' seat:

**23:3** "All things therefore whatsoever they bid you, these do and observe: but do not after their works; for they say, and do not.

**23:4** "Yea, they bind heavy burdens and grievous to be borne, and lay them on men's shoulders; but they themselves will not move them with their finger.

**23:5** "But all their works they do to be seen of men: for they make broad their phylacteries, and enlarge the borders of their garments,

**23:6** "And love the chief place at feasts, and the chief seats in the synagogues,

**23:7** "And the salutations in the marketplaces, and to be called of men, 'Rabbi.'

**23:8** "But be not called 'Rabbi': for one is your teacher, and all you are brethren.

**23:9** "And call no man your father on the earth: for one is your Father, even he who is in heaven.

**23:10** "Neither be called masters: for one is your master, even the Anointed.

**23:11** "But he that is greatest among you shall be your servant.

**23:12** "And whosoever shall exalt himself shall be humbled; and whosoever shall humble himself shall be exalted."

---

## Seven Woes (23:13-36)

**23:13** "But woe unto you, scribes and Pharisees, hypocrites! Because you shut the kingdom of heaven against men: for you enter not in yourselves, neither permit them that are entering in to enter.

**23:14** [Woe unto you, scribes and Pharisees, hypocrites! For you devour widows' houses, even while for a pretence you make long prayers: therefore you shall receive greater condemnation.]

**23:15** "Woe unto you, scribes and Pharisees, hypocrites! For you compass sea and land to make one proselyte; and when he is become so, you make him twofold more a son of Gehenna than yourselves.

**23:16** "Woe unto you, blind guides, that say: 'Whosoever shall swear by the temple, it is nothing; but whosoever shall swear by the gold of the temple, he is a debtor.'

**23:17** "You fools and blind: for which is greater, the gold, or the temple that has sanctified the gold?

**23:18** "And, 'Whosoever shall swear by the altar, it is nothing; but whosoever shall swear by the gift that is upon it, he is a debtor.'

**23:19** "You blind: for which is greater, the gift, or the altar that sanctifies the gift?

**23:20** "He therefore that swears by the altar, swears by it, and by all things thereon.

**23:21** "And he that swears by the temple, swears by it, and by him that dwells therein.

**23:22** "And he that swears by the heaven, swears by the throne of God, and by him that sits thereon.

**23:23** "Woe unto you, scribes and Pharisees, hypocrites! For you tithe mint and anise and cummin, and have left undone the weightier matters of the law, justice, and mercy, and faith: but these you ought to have done, and not to have left the other undone.

**23:24** "You blind guides, that strain out the gnat, and swallow the camel!

**23:25** "Woe unto you, scribes and Pharisees, hypocrites! For you cleanse the outside of the cup and of the platter, but within they are full from extortion and excess.

**23:26** "You blind Pharisee, cleanse first the inside of the cup and of the platter, that the outside thereof may become clean also.

**23:27** "Woe unto you, scribes and Pharisees, hypocrites! For you are like unto whited sepulchres, which outwardly appear beautiful, but inwardly are full of dead men's bones, and of all uncleanness.

**23:28** "Even so you also outwardly appear righteous unto men, but inwardly you are full of hypocrisy and iniquity.

**23:29** "Woe unto you, scribes and Pharisees, hypocrites! For you build the sepulchres of the prophets, and garnish the tombs of the righteous,

**23:30** "And say: 'If we had been in the days of our fathers, we should not have been partakers with them in the blood of the prophets.'

**23:31** "Therefore you witness to yourselves, that you are sons of them that slew the prophets.

**23:32** "Fill up then the measure of your fathers.

**23:33** "You serpents, you offspring of vipers, how shall you escape the judgment of Gehenna?

**23:34** "Therefore, behold, I send unto you prophets, and wise men, and scribes: some of them shall you kill and crucify; and some of them shall you scourge in your synagogues, and persecute from city to city:

**23:35** "That upon you may come all the righteous blood shed on the earth, from the blood of Abel the righteous unto the blood of Zachariah son of Barachiah, whom you slew between the sanctuary and the altar.

**23:36** "Verily I say unto you, All these things shall come upon this generation."

---

## Lament over Jerusalem (23:37-39)

**23:37** "O Jerusalem, Jerusalem, that kills the prophets, and stones them that are sent unto her! How often would I have gathered your children together, even as a hen gathers her chickens under her wings, and you would not!

**23:38** "Behold, your house is left unto you desolate.

**23:39** "For I say unto you, You shall not see me henceforth, till you shall say, 'Blessed is he that comes in the name of the Lord.'"

---

## Synthesis Notes

**Key Restorations:**

**Warning against Hypocrisy (23:1-12):**
**The Key Verses (23:1-7):**
"''The scribes and the Pharisees sit on Moses' seat.''"

*Epi tēs Mōuseōs kathedras ekathisan hoi grammateis kai hoi Pharisaioi*—Moses' seat.

**Moses' Seat:**
Position of teaching authority.

"''All things therefore whatsoever they bid you, these do and observe.''"

*Panta oun hosa ean eipōsin hymin poiēsate kai tēreite*—do what they say.

"''Do not after their works; for they say, and do not.''"

*Kata de ta erga autōn mē poieite legousin gar kai ou poiousin*—don't do as they do.

"''They bind heavy burdens and grievous to be borne.''"

*Desmeuousin de phortia barea kai dysbastaکta*—heavy burdens.

"''Lay them on men's shoulders; but they themselves will not move them with their finger.''"

*Kai epititheasin epi tous ōmous tōn anthrōpōn autoi de tō daktylo autōn ou thelousin kinēsai auta*—won't lift finger.

"''All their works they do to be seen of men.''"

*Panta de ta erga autōn poiousin pros to theathēnai tois anthrōpois*—seen.

"''They make broad their phylacteries.''"

*Platynousi gar ta phylaktēria autōn*—phylacteries.

**Phylacteries (Tefillin):**
Small boxes containing Scripture, worn during prayer.

"''Enlarge the borders of their garments.''"

*Kai megalynousi ta kraspeda*—fringes.

"''Love the chief place at feasts, and the chief seats in the synagogues.''"

*Philousi de tēn prōtoklisian en tois deipnois kai tas prōtokathedrias en tais synagōgais*—honor seats.

"''To be called of men, Rabbi.''"

*Kai kaleisthai hypo tōn anthrōpōn rhabbi*—Rabbi.

**The Key Verses (23:8-12):**
"''Be not called Rabbi: for one is your teacher, and all you are brethren.''"

*Hymeis de mē klēthēte rhabbi heis gar estin hymōn ho didaskalos pantes de hymeis adelphoi este*—one teacher.

"''Call no man your father on the earth: for one is your Father, even he who is in heaven.''"

*Kai patera mē kalesēte hymōn epi tēs gēs heis gar estin hymōn ho patēr ho ouranios*—one Father.

"''Neither be called masters: for one is your master, even the Anointed.''"

*Mēde klēthēte kathēgētai hoti kathēgētēs hymōn estin heis ho Christos*—one master.

"''He that is greatest among you shall be your servant.''"

*Ho de meizōn hymōn estai hymōn diakonos*—servant.

"''Whosoever shall exalt himself shall be humbled.''"

*Hostis de hypsōsei heauton tapeinōthēsetai*—humbled.

"''Whosoever shall humble himself shall be exalted.''"

*Kai hostis tapeinōsei heauton hypsōthēsetai*—exalted.

**Seven Woes (23:13-36):**
**First Woe (23:13):**
"''Woe unto you, scribes and Pharisees, hypocrites!''"

*Ouai de hymin grammateis kai Pharisaioi hypokritai*—woe.

"''You shut the kingdom of heaven against men.''"

*Hoti kleiete tēn basileian tōn ouranōn emprosthen tōn anthrōpōn*—shut.

"''You enter not in yourselves, neither permit them that are entering in to enter.''"

*Hymeis gar ouk eiserchesthe oude tous eiserchomenous aphiete eiselthein*—prevent.

**Second Woe (23:15):**
"''You compass sea and land to make one proselyte.''"

*Periagete tēn thalassan kai tēn xēran poiēsai hena prosēlytoن*—proselyte.

"''When he is become so, you make him twofold more a son of Gehenna than yourselves.''"

*Kai hotan genētai poieite auton huion geennēs diplounteron hymōn*—son of Gehenna.

**Third Woe (23:16-22):**
"''Blind guides, that say: Whosoever shall swear by the temple, it is nothing.''"

*Ouai hymin hodēgoi typhloi hoi legontes hos an omosē en tō naō ouden estin*—oath casuistry.

"''Whosoever shall swear by the gold of the temple, he is a debtor.''"

*Hos d' an omosē en tō chrysō tou naou opheilei*—gold binds.

"''Which is greater, the gold, or the temple that has sanctified the gold?''"

*Tis gar meizōn estin ho chrysos ē ho naos ho hagiasas ton chryson*—temple sanctifies.

**Fourth Woe (23:23-24):**
"''You tithe mint and anise and cummin.''"

*Apodekatoute to hēdyosmon kai to anēthon kai to kyminon*—tithe herbs.

"''Have left undone the weightier matters of the law, justice, and mercy, and faith.''"

*Kai aphēkate ta barytera tou nomou tēn krisin kai to eleos kai tēn pistin*—weightier matters.

"''These you ought to have done, and not to have left the other undone.''"

*Tauta edei poiēsai kakeina mē aphienai*—do both.

"''You blind guides, that strain out the gnat, and swallow the camel!''"

*Hodēgoi typhloi hoi diylزontes ton kōnōpa tēn de kamēlon katapinontes*—gnat, camel.

**Fifth Woe (23:25-26):**
"''You cleanse the outside of the cup and of the platter.''"

*Katharizete to exōthen tou potēriou kai tēs paropsidos*—outside.

"''Within they are full from extortion and excess.''"

*Esōthen de gemousin ex harpagēs kai akrasias*—inside.

"''Cleanse first the inside of the cup.''"

*Katharison prōton to entos tou potēriou*—inside first.

**Sixth Woe (23:27-28):**
"''You are like unto whited sepulchres.''"

*Paromoiazete taphois kekoniamenois*—whitewashed tombs.

"''Outwardly appear beautiful, but inwardly are full of dead men's bones.''"

*Hoitines exōthen men phainontai hōraioi esōthen de gemousin osteōn nekrōn*—bones.

"''Inwardly you are full of hypocrisy and iniquity.''"

*Esōthen de mestoi este hypokrisēos kai anomias*—hypocrisy.

**Seventh Woe (23:29-36):**
"''You build the sepulchres of the prophets.''"

*Oikodomeite tous taphous tōn prophētōn*—tombs.

"''Garnish the tombs of the righteous.''"

*Kai kosmeite ta mnēmeia tōn dikaiōn*—decorate.

"''If we had been in the days of our fathers, we should not have been partakers.''"

*Ei ēmetha en tais hēmerais tōn paterōn hēmōn ouk an ēmetha autōn koinōnoi*—wouldn't participate.

"''You witness to yourselves, that you are sons of them that slew the prophets.''"

*Hōste martyreite heautois hoti huioi este tōn phoneusantōn tous prophētas*—sons.

"''Fill up then the measure of your fathers.''"

*Kai hymeis plērōsate to metron tōn paterōn hymōn*—fill measure.

"''You serpents, you offspring of vipers.''"

*Opheis gennēmata echidnōn*—serpents.

"''How shall you escape the judgment of Gehenna?''"

*Pōs phygēte apo tēs kriseōs tēs geennēs*—escape?

"''I send unto you prophets, and wise men, and scribes.''"

*Idou egō apostellō pros hymas prophētas kai sophous kai grammateis*—I send.

"''Some of them shall you kill and crucify.''"

*Ex autōn apoktenete kai staurōsete*—kill, crucify.

"''That upon you may come all the righteous blood shed on the earth.''"

*Hopōs elthē eph' hymas pan haima dikaion ekchynnomenon epi tēs gēs*—blood.

"''From the blood of Abel... unto the blood of Zachariah son of Barachiah.''"

*Apo tou haimatos Habel tou dikaiou heōs tou haimatos Zachariou huiou Barachiou*—Abel to Zechariah.

**Abel (Genesis 4) to Zechariah (2 Chronicles 24:20-21):**
First and last martyrs in Hebrew Bible canon.

"''All these things shall come upon this generation.''"

*Panta tauta hēxei epi tēn genean tautēn*—this generation.

**Lament over Jerusalem (23:37-39):**
**The Key Verses (23:37-39):**
"''O Jerusalem, Jerusalem, that kills the prophets.''"

*Ierousalēm Ierousalēm hē apokteinousa tous prophētas*—kills prophets.

"''How often would I have gathered your children together.''"

*Posakis ēthelēsa episynagagein ta tekna sou*—gather.

"''Even as a hen gathers her chickens under her wings.''"

*Hon tropon ornis episynagei ta nossia autēs hypo tas pterygas*—hen.

"''You would not!''"

*Kai ouk ēthelēsate*—wouldn't.

"''Your house is left unto you desolate.''"

*Idou aphietai hymin ho oikos hymōn erēmos*—desolate.

"''You shall not see me henceforth, till you shall say, Blessed is he that comes in the name of the Lord.''"

*Ou mē me idēte ap' arti heōs an eipēte eulogēmenos ho erchomenos en onomati kyriou*—Psalm 118:26.

**Archetypal Layer:** Matthew 23 is the **woe chapter**, containing **"The scribes and the Pharisees sit on Moses' seat" (23:2)**, **"they say, and do not" (23:3)**, **"bind heavy burdens" (23:4)**, **"all their works they do to be seen of men" (23:5)**, **"be not called Rabbi... call no man your father" (23:8-9)**, **"he that is greatest among you shall be your servant" (23:11)**, **"whosoever shall exalt himself shall be humbled" (23:12)**, **seven woes (23:13-36)**: shutting kingdom, making proselytes worse, blind oath casuistry, tithing herbs while neglecting justice/mercy/faith, cleaning outside while inside is corrupt, whitewashed tombs, building prophets' tombs while being sons of their killers, **"you serpents, you offspring of vipers" (23:33)**, **"all the righteous blood shed on the earth, from the blood of Abel... unto the blood of Zachariah" (23:35)**, **"O Jerusalem, Jerusalem" (23:37)**, and **"your house is left unto you desolate" (23:38)**.

**Modern Equivalent:** Matthew 23 is Yeshua's most severe denunciation. The seven woes expose religious hypocrisy: external piety without internal transformation, burden-making without burden-bearing, oath-evasion, tithing minutiae while neglecting justice/mercy/faith (23:23), cleaning the outside while inside is corrupt (23:25), appearing righteous while full of iniquity (23:28). The lament (23:37-39) shows Yeshua's grief—He would have gathered Jerusalem, but she refused. The house (temple) will be left desolate.

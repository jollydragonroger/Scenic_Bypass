# Matthew 27: The Crucifixion and Death

*From the Greek: Πρωΐας δὲ γενομένης (Prōias de Genomenēs) — Now When Morning Was Come*

---

## Yeshua Delivered to Pilate (27:1-2)

**27:1** Now when morning was come, all the chief priests and the elders of the people took counsel against Yeshua to put him to death:

**27:2** And they bound him, and led him away, and delivered him up to Pilate the governor.

---

## The Death of Judas (27:3-10)

**27:3** Then Judas, who betrayed him, when he saw that he was condemned, repented himself, and brought back the thirty pieces of silver to the chief priests and elders,

**27:4** Saying: "I have sinned in that I betrayed innocent blood." But they said: "What is that to us? See to it yourself."

**27:5** And he cast down the pieces of silver into the sanctuary, and departed; and he went away and hanged himself.

**27:6** And the chief priests took the pieces of silver, and said: "It is not lawful to put them into the treasury, since it is the price of blood."

**27:7** And they took counsel, and bought with them the potter's field, to bury strangers in.

**27:8** Wherefore that field was called, The field of blood, unto this day.

**27:9** Then was fulfilled that which was spoken through Jeremiah the prophet, saying: "And they took the thirty pieces of silver, the price of him that was priced, whom certain of the children of Israel did price;

**27:10** "And they gave them for the potter's field, as the Lord appointed me."

---

## Before Pilate (27:11-26)

**27:11** Now Yeshua stood before the governor: and the governor asked him, saying: "Are you the King of the Jews?" And Yeshua said unto him: "You say."

**27:12** And when he was accused by the chief priests and elders, he answered nothing.

**27:13** Then says Pilate unto him: "Do you not hear how many things they witness against you?"

**27:14** And he gave him no answer, not even to one word: insomuch that the governor marvelled greatly.

**27:15** Now at the feast the governor was accustomed to release unto the multitude one prisoner, whom they would.

**27:16** And they had then a notable prisoner, called Barabbas.

**27:17** When therefore they were gathered together, Pilate said unto them: "Whom will you that I release unto you? Barabbas, or Yeshua who is called the Anointed?"

**27:18** For he knew that for envy they had delivered him up.

**27:19** And while he was sitting on the judgment-seat, his wife sent unto him, saying: "Have nothing to do with that righteous man; for I have suffered many things this day in a dream because of him."

**27:20** Now the chief priests and the elders persuaded the multitudes that they should ask for Barabbas, and destroy Yeshua.

**27:21** But the governor answered and said unto them: "Which of the two will you that I release unto you?" And they said: "Barabbas."

**27:22** Pilate says unto them: "What then shall I do unto Yeshua who is called the Anointed?" They all say: "Let him be crucified."

**27:23** And he said: "Why, what evil has he done?" But they cried out exceedingly, saying: "Let him be crucified."

**27:24** So when Pilate saw that he prevailed nothing, but rather that a tumult was arising, he took water, and washed his hands before the multitude, saying: "I am innocent of the blood of this righteous man; see to it yourselves."

**27:25** And all the people answered and said: "His blood be on us, and on our children."

**27:26** Then released he unto them Barabbas; but Yeshua he scourged and delivered to be crucified.

---

## The Soldiers Mock Yeshua (27:27-31)

**27:27** Then the soldiers of the governor took Yeshua into the Praetorium, and gathered unto him the whole band.

**27:28** And they stripped him, and put on him a scarlet robe.

**27:29** And they plaited a crown of thorns and put it upon his head, and a reed in his right hand; and they kneeled down before him, and mocked him, saying: "Hail, King of the Jews!"

**27:30** And they spat upon him, and took the reed and smote him on the head.

**27:31** And when they had mocked him, they took off from him the robe, and put on him his garments, and led him away to crucify him.

---

## The Crucifixion (27:32-44)

**27:32** And as they came out, they found a man of Cyrene, Simon by name: him they compelled to go with them, that he might bear his cross.

**27:33** And when they were come unto a place called Golgotha, that is to say, The place of a skull,

**27:34** They gave him wine to drink mingled with gall: and when he had tasted it, he would not drink.

**27:35** And when they had crucified him, they parted his garments among them, casting lots;

**27:36** And they sat and watched him there.

**27:37** And they set up over his head his accusation written: THIS IS YESHUA THE KING OF THE JEWS.

**27:38** Then are there crucified with him two robbers, one on the right hand and one on the left.

**27:39** And they that passed by railed on him, wagging their heads,

**27:40** And saying: "You that destroy the temple, and build it in three days, save yourself: if you are the Son of God, come down from the cross."

**27:41** In like manner also the chief priests mocking him, with the scribes and elders, said:

**27:42** "He saved others; himself he cannot save. He is the King of Israel; let him now come down from the cross, and we will believe on him.

**27:43** "He trusts on God; let him deliver him now, if he desires him: for he said, 'I am the Son of God.'"

**27:44** And the robbers also that were crucified with him cast upon him the same reproach.

---

## The Death of Yeshua (27:45-56)

**27:45** Now from the sixth hour there was darkness over all the land until the ninth hour.

**27:46** And about the ninth hour Yeshua cried with a loud voice, saying: "Eli, Eli, lama sabachthani?" That is: "My God, my God, why have you forsaken me?"

**27:47** And some of them that stood there, when they heard it, said: "This man calls Elijah."

**27:48** And straightway one of them ran, and took a sponge, and filled it with vinegar, and put it on a reed, and gave him to drink.

**27:49** And the rest said: "Let be; let us see whether Elijah comes to save him."

**27:50** And Yeshua cried again with a loud voice, and yielded up his spirit.

**27:51** And behold, the veil of the temple was rent in two from the top to the bottom; and the earth did quake; and the rocks were rent;

**27:52** And the tombs were opened; and many bodies of the saints that had fallen asleep were raised;

**27:53** And coming forth out of the tombs after his resurrection they entered into the holy city and appeared unto many.

**27:54** Now the centurion, and they that were with him watching Yeshua, when they saw the earthquake, and the things that were done, feared exceedingly, saying: "Truly this was the Son of God."

**27:55** And many women were there beholding from afar, who had followed Yeshua from Galilee, ministering unto him:

**27:56** Among whom was Mary Magdalene, and Mary the mother of James and Joses, and the mother of the sons of Zebedee.

---

## The Burial of Yeshua (27:57-66)

**27:57** And when even was come, there came a rich man from Arimathaea, named Joseph, who also himself was Yeshua's disciple:

**27:58** This man went to Pilate, and asked for the body of Yeshua. Then Pilate commanded it to be given up.

**27:59** And Joseph took the body, and wrapped it in a clean linen cloth,

**27:60** And laid it in his own new tomb, which he had hewn out in the rock: and he rolled a great stone to the door of the tomb, and departed.

**27:61** And Mary Magdalene was there, and the other Mary, sitting over against the sepulchre.

**27:62** Now on the morrow, which is the day after the Preparation, the chief priests and the Pharisees were gathered together unto Pilate,

**27:63** Saying: "Sir, we remember that that deceiver said while he was yet alive, 'After three days I rise again.'

**27:64** "Command therefore that the sepulchre be made sure until the third day, lest haply his disciples come and steal him away, and say unto the people, 'He is risen from the dead': and the last error will be worse than the first."

**27:65** Pilate said unto them: "You have a guard: go, make it as sure as you can."

**27:66** So they went, and made the sepulchre sure, sealing the stone, the guard being with them.

---

## Synthesis Notes

**Key Restorations:**

**Delivered to Pilate (27:1-2):**
"'All the chief priests and the elders... took counsel against Yeshua to put him to death.'"

*Symboulion elabon... kata tou Iēsou hōste thanatōsai auton*—death.

"'They bound him, and led him away, and delivered him up to Pilate the governor.'"

*Kai dēsantes auton apēgagon kai paredōkan Pilatō tō hēgemoni*—Pilate.

**Death of Judas (27:3-10):**
"'Judas... when he saw that he was condemned, repented himself.'"

*Ioudas... idōn hoti katekrithē metamelētheis*—repented.

"''I have sinned in that I betrayed innocent blood.''"

*Hēmarton paradous haima athōon*—innocent blood.

"''What is that to us? See to it yourself.''"

*Ti pros hēmas sy opsē*—see to it.

"'He cast down the pieces of silver into the sanctuary... and hanged himself.'"

*Kai rhipsas ta argyria eis ton naon anechōrēsen kai apelthōn apēnxato*—hanged.

"'They bought with them the potter's field, to bury strangers in.'"

*Ēgorasan ex autōn ton agron tou kerameōs eis taphēn tois xenois*—potter's field.

"'That field was called, The field of blood.'"

*Dio eklēthē ho agros ekeinos agros haimatos*—blood field.

**Zechariah 11:12-13 + Jeremiah 32:6-9.**

**Before Pilate (27:11-26):**
"''Are you the King of the Jews?' And Yeshua said unto him: 'You say.''"

*Sy ei ho basileus tōn Ioudaiōn ho de Iēsous ephē sy legeis*—you say.

"'He gave him no answer, not even to one word.'"

*Kai ouk apekrithē autō pros oude hen rhēma*—silent.

**Isaiah 53:7.**

"'They had then a notable prisoner, called Barabbas.'"

*Eichon de tote desmion episēmon legomenon Barabban*—Barabbas.

**Barabbas:**
"Son of the father"—ironic contrast.

"''Whom will you that I release unto you? Barabbas, or Yeshua who is called the Anointed?''"

*Tina thelete apolusō hymin Barabban ē Iēsoun ton legomenon Christon*—choice.

"'His wife sent unto him, saying: Have nothing to do with that righteous man.'"

*Apesteilen pros auton hē gynē autou legousa mēden soi kai tō dikaiō ekeinō*—dream.

"''What then shall I do unto Yeshua?' They all say: 'Let him be crucified.''"

*Ti oun poiēsō Iēsoun... staurōthētō*—crucify.

"'Pilate... took water, and washed his hands before the multitude.'"

*Labōn hydōr apenipsato tas cheiras apenanti tou ochlou*—washed hands.

"''I am innocent of the blood of this righteous man.''"

*Athōos eimi apo tou haimatos toutou*—innocent.

"''His blood be on us, and on our children.''"

*To haima autou eph' hēmas kai epi ta tekna hēmōn*—blood on us.

"'Yeshua he scourged and delivered to be crucified.'"

*Ton de Iēsoun phragellōsas paredōken hina staurōthē*—scourged.

**Soldiers Mock (27:27-31):**
"'They stripped him, and put on him a scarlet robe.'"

*Kai ekdysantes auton chlamyda kokkinēn periethēkan autō*—scarlet robe.

"'They plaited a crown of thorns and put it upon his head.'"

*Kai plexantes stephanon ex akanthōn epethēkan epi tēs kephalēs autou*—thorns.

"''Hail, King of the Jews!''"

*Chaire basileu tōn Ioudaiōn*—mock hail.

"'They spat upon him, and took the reed and smote him on the head.'"

*Kai emptysantes eis auton elabon ton kalamon kai etypton eis tēn kephalēn autou*—spit, struck.

**Crucifixion (27:32-44):**
"'They found a man of Cyrene, Simon by name: him they compelled to go with them, that he might bear his cross.'"

*Heuron anthrōpon Kyrēnaion onomati Simōna touton ēngareusan hina arē ton stauron autou*—Simon.

"'A place called Golgotha, that is to say, The place of a skull.'"

*Eis topon legomenon Golgotha ho estin kraniou topos legomenos*—Golgotha.

"'They gave him wine to drink mingled with gall.'"

*Edōkan autō piein oinon meta cholēs memigmenon*—gall.

**Psalm 69:21.**

"'When they had crucified him, they parted his garments among them, casting lots.'"

*Staurōsantes de auton diemerisanto ta himatia autou ballontes klēron*—lots.

**Psalm 22:18.**

"'They set up over his head his accusation written: THIS IS YESHUA THE KING OF THE JEWS.'"

*Kai epethēkan epanō tēs kephalēs autou tēn aitian autou gegrammenēn houtos estin Iēsous ho basileus tōn Ioudaiōn*—accusation.

"''You that destroy the temple, and build it in three days, save yourself.''"

*Ho katalyōn ton naon kai en trisin hēmerais oikodomōn sōson seauton*—taunt.

"''He saved others; himself he cannot save.''"

*Allous esōsen heauton ou dynatai sōsai*—ironic truth.

"''He trusts on God; let him deliver him now, if he desires him.''"

*Pepoithen epi ton theon rhysasthō nyn ei thelei auton*—Psalm 22:8.

**Death of Yeshua (27:45-56):**
"'From the sixth hour there was darkness over all the land until the ninth hour.'"

*Apo de hektēs hōras skotos egeneto epi pasan tēn gēn heōs hōras enatēs*—darkness.

**Noon to 3 PM.**

"''Eli, Eli, lama sabachthani?' That is: 'My God, my God, why have you forsaken me?'''"

*Ēli ēli lema sabachthani tout' estin thee mou thee mou hinati me enkatelipes*—Psalm 22:1.

"'Yeshua cried again with a loud voice, and yielded up his spirit.'"

*Ho de Iēsous palin kraxas phōnē megalē aphēken to pneuma*—yielded spirit.

"'The veil of the temple was rent in two from the top to the bottom.'"

*Kai idou to katapetasma tou naou eschisthē ap' anōthen heōs katō eis dyo*—veil torn.

"'The earth did quake; and the rocks were rent.'"

*Kai hē gē eseisthē kai hai petrai eschisthēsan*—earthquake.

"'The tombs were opened; and many bodies of the saints that had fallen asleep were raised.'"

*Kai ta mnēmeia aneōchthēsan kai polla sōmata tōn kekoimēmenōn hagiōn ēgerthēsan*—raised.

"''Truly this was the Son of God.''"

*Alēthōs theou huios ēn houtos*—centurion's confession.

"'Many women were there beholding from afar.'"

*Ēsan de ekei gynaikes pollai apo makrothen theōrousai*—women.

**Burial (27:57-66):**
"'A rich man from Arimathaea, named Joseph, who also himself was Yeshua's disciple.'"

*Anthrōpos plousios apo Harimathaias tounoma Iōsēph hos kai autos emathēteusen tō Iēsou*—Joseph.

"'He... asked for the body of Yeshua.'"

*Ētēsato to sōma tou Iēsou*—asked.

"'Joseph took the body, and wrapped it in a clean linen cloth.'"

*Kai labōn to sōma ho Iōsēph enetylixen auto en sindoni kathara*—linen.

"'Laid it in his own new tomb, which he had hewn out in the rock.'"

*Kai ethēken auto en tō kainō autou mnēmeiō ho elatomēsen en tē petra*—new tomb.

"'He rolled a great stone to the door of the tomb.'"

*Kai prosekulisen lithon megan tē thyra tou mnēmeiou*—stone.

"''We remember that that deceiver said... After three days I rise again.''"

*Emnēsthēmen hoti ekeinos ho planos eipen... meta treis hēmeras egeiromai*—deceiver.

"'So they went, and made the sepulchre sure, sealing the stone, the guard being with them.'"

*Hoi de poreuthentes ēsphalisanto ton taphon sphragisantes ton lithon meta tēs koustōdias*—sealed, guarded.

**Archetypal Layer:** Matthew 27 contains **delivered to Pilate (27:1-2)**, **Judas's remorse, return of silver, and hanging (27:3-10)**, **"I have sinned in that I betrayed innocent blood" (27:4)**, **potter's field (Zechariah 11:12-13)**, **"Are you the King of the Jews?" "You say" (27:11)**, **Yeshua's silence (Isaiah 53:7)**, **Barabbas released (27:15-21)**, **"Let him be crucified" (27:22-23)**, **Pilate washes hands: "I am innocent of the blood of this righteous man" (27:24)**, **"His blood be on us, and on our children" (27:25)**, **scarlet robe, crown of thorns, mocking (27:27-31)**, **Simon of Cyrene bears the cross (27:32)**, **Golgotha (27:33)**, **garments divided by lots (Psalm 22:18) (27:35)**, **accusation: "THIS IS YESHUA THE KING OF THE JEWS" (27:37)**, **taunts echoing Psalm 22:8 (27:43)**, **darkness from sixth to ninth hour (27:45)**, **"Eli, Eli, lama sabachthani?" (Psalm 22:1) (27:46)**, **Yeshua yields up his spirit (27:50)**, **veil torn, earthquake, tombs opened (27:51-53)**, **"Truly this was the Son of God" (27:54)**, **women watching (27:55-56)**, **Joseph of Arimathaea buries Yeshua in new tomb (27:57-60)**, and **guard set, tomb sealed (27:62-66)**.

**Modern Equivalent:** Matthew 27 narrates the crucifixion. Judas's regret (27:3-5) fulfills Zechariah's prophecy. Pilate's handwashing (27:24) attempts to evade responsibility. The mockery (27:27-31) ironically proclaims truth: "King of the Jews." Psalm 22 pervades the crucifixion: garments divided (27:35), taunts (27:43), the cry of forsakenness (27:46). The veil torn (27:51) signifies access to God's presence. The centurion's confession (27:54) is the pagan's recognition: "Son of God." The burial (27:57-60) and sealing (27:66) set up the resurrection.

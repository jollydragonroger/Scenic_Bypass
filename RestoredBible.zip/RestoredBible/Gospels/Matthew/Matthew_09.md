# Matthew 9: Healings, Calling of Matthew, and New Wine

*From the Greek: Καὶ ἐμβὰς εἰς πλοῖον διεπέρασεν (Kai Embas eis Ploion Dieperasen) — And He Entered into a Boat, and Crossed Over*

---

## The Paralytic Forgiven and Healed (9:1-8)

**9:1** And he entered into a boat, and crossed over, and came into his own city.

**9:2** And behold, they brought to him a man sick of the palsy, lying on a bed: and Yeshua seeing their faith said unto the sick of the palsy: "Son, be of good cheer; your sins are forgiven."

**9:3** And behold, certain of the scribes said within themselves: "This man blasphemes."

**9:4** And Yeshua knowing their thoughts said: "Why think you evil in your hearts?

**9:5** "For which is easier, to say, 'Your sins are forgiven'; or to say, 'Arise, and walk'?

**9:6** "But that you may know that the Son of man has authority on earth to forgive sins"—then says he to the sick of the palsy—"Arise, and take up your bed, and go unto your house."

**9:7** And he arose, and departed to his house.

**9:8** But when the multitudes saw it, they were afraid, and glorified God, who had given such authority unto men.

---

## The Calling of Matthew (9:9-13)

**9:9** And as Yeshua passed by from thence, he saw a man, called Matthew, sitting at the place of toll: and he says unto him: "Follow me." And he arose, and followed him.

**9:10** And it came to pass, as he sat at meat in the house, behold, many publicans and sinners came and sat down with Yeshua and his disciples.

**9:11** And when the Pharisees saw it, they said unto his disciples: "Why does your Teacher eat with the publicans and sinners?"

**9:12** But when he heard it, he said: "They that are whole have no need of a physician, but they that are sick.

**9:13** "But go and learn what this means, 'I desire mercy, and not sacrifice': for I came not to call the righteous, but sinners."

---

## The Question about Fasting (9:14-17)

**9:14** Then come to him the disciples of John, saying: "Why do we and the Pharisees fast oft, but your disciples fast not?"

**9:15** And Yeshua said unto them: "Can the sons of the bride-chamber mourn, as long as the bridegroom is with them? But the days will come, when the bridegroom shall be taken away from them, and then will they fast.

**9:16** "And no man puts a piece of undressed cloth upon an old garment; for that which should fill it up takes from the garment, and a worse rent is made.

**9:17** "Neither do men put new wine into old wine-skins: else the skins burst, and the wine is spilled, and the skins perish: but they put new wine into fresh wine-skins, and both are preserved."

---

## The Ruler's Daughter and the Woman with the Issue (9:18-26)

**9:18** While he spoke these things unto them, behold, there came a ruler, and worshipped him, saying: "My daughter is even now dead: but come and lay your hand upon her, and she shall live."

**9:19** And Yeshua arose, and followed him, and so did his disciples.

**9:20** And behold, a woman, who had an issue of blood twelve years, came behind him, and touched the border of his garment:

**9:21** For she said within herself: "If I do but touch his garment, I shall be made whole."

**9:22** But Yeshua turning and seeing her said: "Daughter, be of good cheer; your faith has made you whole." And the woman was made whole from that hour.

**9:23** And when Yeshua came into the ruler's house, and saw the flute-players, and the crowd making a tumult,

**9:24** He said: "Give place: for the damsel is not dead, but sleeps." And they laughed him to scorn.

**9:25** But when the crowd was put forth, he entered in, and took her by the hand; and the damsel arose.

**9:26** And the fame hereof went forth into all that land.

---

## Two Blind Men and a Mute Demoniac (9:27-34)

**9:27** And as Yeshua passed by from thence, two blind men followed him, crying out, and saying: "Have mercy on us, Son of David."

**9:28** And when he was come into the house, the blind men came to him: and Yeshua says unto them: "Believe you that I am able to do this?" They say unto him: "Yea, Lord."

**9:29** Then touched he their eyes, saying: "According to your faith be it done unto you."

**9:30** And their eyes were opened. And Yeshua strictly charged them, saying: "See that no man know it."

**9:31** But they went forth, and spread abroad his fame in all that land.

**9:32** And as they went forth, behold, there was brought to him a dumb man possessed with a demon.

**9:33** And when the demon was cast out, the dumb man spoke: and the multitudes marvelled, saying: "It was never so seen in Israel."

**9:34** But the Pharisees said: "By the prince of the demons casts he out demons."

---

## The Harvest and the Laborers (9:35-38)

**9:35** And Yeshua went about all the cities and the villages, teaching in their synagogues, and proclaiming the good news of the kingdom, and healing all manner of disease and all manner of sickness.

**9:36** But when he saw the multitudes, he was moved with compassion for them, because they were distressed and scattered, as sheep not having a shepherd.

**9:37** Then says he unto his disciples: "The harvest indeed is plenteous, but the laborers are few.

**9:38** "Pray therefore the Lord of the harvest, that he send forth laborers into his harvest."

---

## Synthesis Notes

**Key Restorations:**

**The Paralytic (9:1-8):**
**The Key Verses (9:1-8):**
"'He... came into his own city.'"

*Ēlthen eis tēn idian polin*—Capernaum.

"'They brought to him a man sick of the palsy.'"

*Prosepheron autō paralytikon*—paralytic.

"'Yeshua seeing their faith.'"

*Kai idōn ho Iēsous tēn pistin autōn*—their faith.

"''Son, be of good cheer; your sins are forgiven.''"

*Tharsei teknon aphientai sou hai hamartiai*—forgiven.

"'Certain of the scribes said within themselves: This man blasphemes.'"

*Houtos blasphēmei*—blasphemy.

"''Which is easier, to say, Your sins are forgiven; or to say, Arise, and walk?''"

*Ti gar estin eukopōteron eipein aphientai sou hai hamartiai ē eipein egeire kai peripatei*—easier.

"''That you may know that the Son of man has authority on earth to forgive sins.''"

*Hina de eidēte hoti exousian echei ho huios tou anthrōpou epi tēs gēs aphienai hamartias*—authority.

"'The multitudes... glorified God, who had given such authority unto men.'"

*Edoxasan ton theon ton donta exousian toiautēn tois anthrōpois*—glorified.

**Calling of Matthew (9:9-13):**
**The Key Verses (9:9-13):**
"'He saw a man, called Matthew, sitting at the place of toll.'"

*Eiden anthrōpon kathēmenon epi to telōnion Maththaion legomenon*—Matthew.

**Telōnion:**
Tax/toll booth—despised profession.

"''Follow me.' And he arose, and followed him.'"

*Akolouthei moi kai anastas ēkolouthēsen autō*—followed.

"'Many publicans and sinners came and sat down with Yeshua.'"

*Polloi telōnai kai hamartōloi... synanekeinto tō Iēsou*—ate together.

"''Why does your Teacher eat with the publicans and sinners?''"

*Dia ti meta tōn telōnōn kai hamartōlōn esthiei ho didaskalos hymōn*—why eat.

"''They that are whole have no need of a physician, but they that are sick.''"

*Ou chreian echousin hoi ischyontes iatrou all' hoi kakōs echontes*—physician.

"''I desire mercy, and not sacrifice.''"

*Eleos thelō kai ou thysian*—mercy, not sacrifice.

**Hosea 6:6.**

"''I came not to call the righteous, but sinners.''"

*Ou gar ēlthon kalesai dikaious alla hamartōlous*—call sinners.

**Fasting Question (9:14-17):**
**The Key Verses (9:14-17):**
"''Why do we and the Pharisees fast oft, but your disciples fast not?''"

*Dia ti hēmeis kai hoi Pharisaioi nēsteuomen polla hoi de mathētai sou ou nēsteuousin*—fasting.

"''Can the sons of the bride-chamber mourn, as long as the bridegroom is with them?''"

*Mē dynantai hoi huioi tou nymphōnos penthein eph' hoson met' autōn estin ho nymphios*—bridegroom.

"''The bridegroom shall be taken away from them, and then will they fast.''"

*Eleusontai de hēmerai hotan aparthē ap' autōn ho nymphios kai tote nēsteusousin*—taken.

"''No man puts a piece of undressed cloth upon an old garment.''"

*Oudeis de epiballei epiblēma hrakous agnaphou epi himatiō palaiō*—new patch.

"''Neither do men put new wine into old wine-skins.''"

*Oude ballousin oinon neon eis askous palaious*—new wine.

"''They put new wine into fresh wine-skins, and both are preserved.''"

*Ballousin oinon neon eis askous kainous kai amphoteroi syntērountai*—both preserved.

**Ruler's Daughter and Woman (9:18-26):**
**The Key Verses (9:18-26):**
"'There came a ruler, and worshipped him.'"

*Archōn heis proselthōn prosekunei autō*—ruler.

"''My daughter is even now dead: but come and lay your hand upon her.''"

*Hē thugatēr mou arti eteleutēsen alla elthōn epithes tēn cheira sou ep' autēn*—daughter dead.

"'A woman, who had an issue of blood twelve years.'"

*Gynē haimorroousa dōdeka etē*—twelve years.

"'Touched the border of his garment.'"

*Hēpsato tou kraspedou tou himatiou autou*—touched fringe.

**Kraspedon:**
Tassels/fringes—Numbers 15:38-40.

"''If I do but touch his garment, I shall be made whole.''"

*Ean monon hapsōmai tou himatiou autou sōthēsomai*—touch, whole.

"''Daughter, be of good cheer; your faith has made you whole.''"

*Tharsei thygater hē pistis sou sesōken se*—faith saves.

"''The damsel is not dead, but sleeps.''"

*Ou gar apethanen to korasion alla katheudei*—sleeps.

"'They laughed him to scorn.'"

*Kai kategelōn autou*—laughed.

"'He entered in, and took her by the hand; and the damsel arose.'"

*Eiselthōn ekratēsen tēs cheiros autēs kai ēgerthē to korasion*—arose.

**Blind Men and Mute Demoniac (9:27-34):**
**The Key Verses (9:27-34):**
"'Two blind men followed him, crying out... Have mercy on us, Son of David.'"

*Duo typhloi... krazontes kai legontes eleēson hēmas huie David*—Son of David.

"''Believe you that I am able to do this?''"

*Pisteuete hoti dynamai touto poiēsai*—believe?

"''According to your faith be it done unto you.''"

*Kata tēn pistin hymōn genēthētō hymin*—according to faith.

"'Their eyes were opened.'"

*Kai ēneōchthēsan autōn hoi ophthalmoi*—opened.

"'A dumb man possessed with a demon.'"

*Anthrōpon kōphon daimonizomenon*—mute demoniac.

"'The dumb man spoke: and the multitudes marvelled.'"

*Kai ekbēlthentos tou daimoniou elalēsen ho kōphos kai ethaumasan hoi ochloi*—spoke.

"''It was never so seen in Israel.''"

*Oudepote ephanē houtōs en tō Israēl*—never seen.

"''By the prince of the demons casts he out demons.''"

*En tō archonti tōn daimoniōn ekballei ta daimonia*—prince of demons.

**Harvest and Laborers (9:35-38):**
**The Key Verses (9:35-38):**
"'Yeshua went about all the cities and the villages.'"

*Kai periēgen ho Iēsous tas poleis pasas kai tas kōmas*—all cities.

"'Teaching... proclaiming... healing.'"

*Didaskōn... kēryssōn... therapeuōn*—three-fold ministry.

"'He was moved with compassion for them.'"

*Esplanchnisthē peri autōn*—compassion.

"'They were distressed and scattered, as sheep not having a shepherd.'"

*Ēsan eskylmenoi kai errimmenoi hōsei probata mē echonta poimena*—no shepherd.

"''The harvest indeed is plenteous, but the laborers are few.''"

*Ho men therismos polys hoi de ergatai oligoi*—harvest, laborers.

"''Pray therefore the Lord of the harvest, that he send forth laborers into his harvest.''"

*Deēthēte oun tou kyriou tou therismou hopōs ekbalē ergatas eis ton therismon autou*—pray.

**Archetypal Layer:** Matthew 9 contains **"Son, be of good cheer; your sins are forgiven" (9:2)**, **"the Son of man has authority on earth to forgive sins" (9:6)**, **calling of Matthew the tax collector (9:9)**, **"I desire mercy, and not sacrifice" (Hosea 6:6) (9:13)**, **"I came not to call the righteous, but sinners" (9:13)**, **bridegroom present (9:15)**, **new wine in new wineskins (9:17)**, **"your faith has made you whole" (9:22)**, **"the damsel is not dead, but sleeps" (9:24)**, **"Son of David" (9:27)**, **"According to your faith be it done unto you" (9:29)**, **Pharisees accuse: "By the prince of the demons casts he out demons" (9:34)**, **"sheep not having a shepherd" (9:36)**, and **"The harvest indeed is plenteous, but the laborers are few" (9:37)**.

**Modern Equivalent:** Matthew 9 shows authority to forgive sins (9:6)—the paralytic's healing proves it. Matthew's call (9:9) and table fellowship with sinners (9:10) demonstrate Yeshua's mission: "I came not to call the righteous, but sinners" (9:13). The new wine/wineskins (9:17) signals new era incompatible with old forms. Faith heals the bleeding woman (9:22) and opens blind eyes (9:29). The chapter ends with compassion for shepherdless sheep (9:36) and the call to pray for harvest laborers (9:37-38)—setting up the mission of chapter 10.

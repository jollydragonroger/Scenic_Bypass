# Matthew 10: The Mission of the Twelve

*From the Greek: Καὶ προσκαλεσάμενος τοὺς δώδεκα μαθητὰς αὐτοῦ (Kai Proskalesamenos tous Dōdeka Mathētas Autou) — And He Called unto Him His Twelve Disciples*

---

## The Twelve Commissioned (10:1-15)

**10:1** And he called unto him his twelve disciples, and gave them authority over unclean spirits, to cast them out, and to heal all manner of disease and all manner of sickness.

**10:2** Now the names of the twelve apostles are these: The first, Simon, who is called Peter, and Andrew his brother; James the son of Zebedee, and John his brother;

**10:3** Philip, and Bartholomew; Thomas, and Matthew the publican; James the son of Alphaeus, and Thaddaeus;

**10:4** Simon the Cananaean, and Judas Iscariot, who also betrayed him.

**10:5** These twelve Yeshua sent forth, and charged them, saying: "Go not into any way of the Gentiles, and enter not into any city of the Samaritans:

**10:6** "But go rather to the lost sheep of the house of Israel.

**10:7** "And as you go, proclaim, saying: 'The kingdom of heaven is at hand.'

**10:8** "Heal the sick, raise the dead, cleanse the lepers, cast out demons: freely you received, freely give.

**10:9** "Get you no gold, nor silver, nor brass in your purses;

**10:10** "No wallet for your journey, neither two coats, nor shoes, nor staff: for the laborer is worthy of his food.

**10:11** "And into whatsoever city or village you shall enter, search out who in it is worthy; and there abide till you go forth.

**10:12** "And as you enter into the house, salute it.

**10:13** "And if the house be worthy, let your peace come upon it: but if it be not worthy, let your peace return to you.

**10:14** "And whosoever shall not receive you, nor hear your words, as you go forth out of that house or that city, shake off the dust of your feet.

**10:15** "Verily I say unto you, It shall be more tolerable for the land of Sodom and Gomorrah in the day of judgment, than for that city."

---

## Persecution Foretold (10:16-25)

**10:16** "Behold, I send you forth as sheep in the midst of wolves: be therefore wise as serpents, and harmless as doves.

**10:17** "But beware of men: for they will deliver you up to councils, and in their synagogues they will scourge you;

**10:18** "Yea and before governors and kings shall you be brought for my sake, for a testimony to them and to the Gentiles.

**10:19** "But when they deliver you up, be not anxious how or what you shall speak: for it shall be given you in that hour what you shall speak.

**10:20** "For it is not you that speak, but the Spirit of your Father that speaks in you.

**10:21** "And brother shall deliver up brother to death, and the father his child: and children shall rise up against parents, and cause them to be put to death.

**10:22** "And you shall be hated of all men for my name's sake: but he that endures to the end, the same shall be saved.

**10:23** "But when they persecute you in this city, flee into the next: for verily I say unto you, You shall not have gone through the cities of Israel, till the Son of man be come.

**10:24** "A disciple is not above his teacher, nor a servant above his lord.

**10:25** "It is enough for the disciple that he be as his teacher, and the servant as his lord. If they have called the master of the house Beelzebub, how much more them of his household!"

---

## Fear God, Not Men (10:26-33)

**10:26** "Fear them not therefore: for there is nothing covered, that shall not be revealed; and hid, that shall not be known.

**10:27** "What I tell you in the darkness, speak in the light; and what you hear in the ear, proclaim upon the housetops.

**10:28** "And be not afraid of them that kill the body, but are not able to kill the soul: but rather fear him who is able to destroy both soul and body in Gehenna.

**10:29** "Are not two sparrows sold for a penny? And not one of them shall fall on the ground without your Father:

**10:30** "But the very hairs of your head are all numbered.

**10:31** "Fear not therefore: you are of more value than many sparrows.

**10:32** "Every one therefore who shall confess me before men, him will I also confess before my Father who is in heaven.

**10:33** "But whosoever shall deny me before men, him will I also deny before my Father who is in heaven."

---

## Division and the Cross (10:34-42)

**10:34** "Think not that I came to send peace on the earth: I came not to send peace, but a sword.

**10:35** "For I came to set a man at variance against his father, and the daughter against her mother, and the daughter in law against her mother in law:

**10:36** "And a man's foes shall be they of his own household.

**10:37** "He that loves father or mother more than me is not worthy of me; and he that loves son or daughter more than me is not worthy of me.

**10:38** "And he that does not take his cross and follow after me, is not worthy of me.

**10:39** "He that finds his life shall lose it; and he that loses his life for my sake shall find it.

**10:40** "He that receives you receives me, and he that receives me receives him that sent me.

**10:41** "He that receives a prophet in the name of a prophet shall receive a prophet's reward: and he that receives a righteous man in the name of a righteous man shall receive a righteous man's reward.

**10:42** "And whosoever shall give to drink unto one of these little ones a cup of cold water only, in the name of a disciple, verily I say unto you he shall in no wise lose his reward."

---

## Synthesis Notes

**Key Restorations:**

**The Twelve Commissioned (10:1-15):**
**The Key Verses (10:1-4):**
"'He called unto him his twelve disciples.'"

*Proskalesamenos tous dōdeka mathētas autou*—twelve.

"'Gave them authority over unclean spirits.'"

*Edōken autois exousian pneumatōn akathartōn*—authority.

**The Twelve:**
Simon Peter, Andrew, James, John, Philip, Bartholomew, Thomas, Matthew, James son of Alphaeus, Thaddaeus, Simon the Cananaean, Judas Iscariot.

**The Key Verses (10:5-8):**
"''Go not into any way of the Gentiles.''"

*Eis hodon ethnōn mē apelthēte*—not to Gentiles.

"''Enter not into any city of the Samaritans.''"

*Kai eis polin Samareitōn mē eiselthēte*—not Samaritans.

"''Go rather to the lost sheep of the house of Israel.''"

*Poreuesthe de mallon pros ta probata ta apolōlota oikou Israēl*—lost sheep.

"''The kingdom of heaven is at hand.''"

*Ēngiken hē basileia tōn ouranōn*—kingdom near.

"''Heal the sick, raise the dead, cleanse the lepers, cast out demons.''"

*Asthenountas therapeuete nekrous egeirete leprous katharizete daimonia ekballete*—four-fold ministry.

"''Freely you received, freely give.''"

*Dōrean elabete dōrean dote*—freely.

**The Key Verses (10:9-15):**
"''Get you no gold, nor silver, nor brass in your purses.''"

*Mē ktēsēsthe chryson mēde argyron mēde chalkon eis tas zōnas hymōn*—no money.

"''The laborer is worthy of his food.''"

*Axios gar ho ergatēs tēs trophēs autou*—worthy.

"''Shake off the dust of your feet.''"

*Ektinaxate ton koniorton tōn podōn hymōn*—shake dust.

"''More tolerable for the land of Sodom and Gomorrah in the day of judgment.''"

*Anektoteron estai gē Sodomōn kai Gomorrōn en hēmera kriseōs ē tē polei ekeinē*—Sodom.

**Persecution Foretold (10:16-25):**
**The Key Verses (10:16-23):**
"''I send you forth as sheep in the midst of wolves.''"

*Idou egō apostellō hymas hōs probata en mesō lykōn*—sheep, wolves.

"''Be therefore wise as serpents, and harmless as doves.''"

*Ginesthe oun phronimoi hōs hoi opheis kai akeraioi hōs hai peristerai*—wise, harmless.

"''They will deliver you up to councils.''"

*Paradōsousin hymas eis synedria*—councils.

"''In their synagogues they will scourge you.''"

*Kai en tais synagōgais autōn mastigōsousin hymas*—scourge.

"''Before governors and kings shall you be brought for my sake.''"

*Kai epi hēgemonas de kai basileis achthēsesthe heneken emou*—governors, kings.

"''It shall be given you in that hour what you shall speak.''"

*Dothēsetai gar hymin en ekeinē tē hōra ti lalēsēte*—given.

"''It is not you that speak, but the Spirit of your Father.''"

*Ou gar hymeis este hoi lalountes alla to pneuma tou patros hymōn*—Spirit speaks.

"''Brother shall deliver up brother to death.''"

*Paradōsei de adelphos adelphon eis thanaton*—family betrayal.

"''You shall be hated of all men for my name's sake.''"

*Kai esesthe misoumenoi hypo pantōn dia to onoma mou*—hated.

"''He that endures to the end, the same shall be saved.''"

*Ho de hypomeinas eis telos houtos sōthēsetai*—endures.

"''You shall not have gone through the cities of Israel, till the Son of man be come.''"

*Ou mē telesēte tas poleis tou Israēl heōs an elthē ho huios tou anthrōpou*—Son of man comes.

**The Key Verses (10:24-25):**
"''A disciple is not above his teacher.''"

*Ouk estin mathētēs hyper ton didaskalon*—not above.

"''If they have called the master of the house Beelzebub.''"

*Ei ton oikodespotēn Beelzeboul epekalesan*—Beelzebub.

**Fear God, Not Men (10:26-33):**
**The Key Verses (10:26-33):**
"''Fear them not therefore.''"

*Mē oun phobēthēte autous*—fear not.

"''There is nothing covered, that shall not be revealed.''"

*Ouden gar estin kekalymmenon ho ouk apokalyphthēsetai*—revealed.

"''What I tell you in the darkness, speak in the light.''"

*Ho legō hymin en tē skotia eipate en tō phōti*—speak in light.

"''Be not afraid of them that kill the body, but are not able to kill the soul.''"

*Mē phobeisthe apo tōn apoktennontōn to sōma tēn de psychēn mē dynamenōn apokteinai*—body, not soul.

"''Fear him who is able to destroy both soul and body in Gehenna.''"

*Phobeisthe de mallon ton dynamenon kai psychēn kai sōma apolesai en geennē*—fear God.

"''Are not two sparrows sold for a penny?''"

*Ouchi duo strouthia assariou pōleitai*—sparrows.

"''Not one of them shall fall on the ground without your Father.''"

*Kai hen ex autōn ou peseitai epi tēn gēn aneu tou patros hymōn*—Father knows.

"''The very hairs of your head are all numbered.''"

*Hymōn de kai hai triches tēs kephalēs pasai ērithmēmenai eisin*—hairs numbered.

"''You are of more value than many sparrows.''"

*Pollōn oun strouthiōn diapherete hymeis*—more value.

"''Every one therefore who shall confess me before men.''"

*Pas oun hostis homologēsei en emoi emprosthen tōn anthrōpōn*—confess.

"''Him will I also confess before my Father who is in heaven.''"

*Homologēsō kagō en autō emprosthen tou patros mou tou en tois ouranois*—confess before Father.

**Division and the Cross (10:34-42):**
**The Key Verses (10:34-39):**
"''Think not that I came to send peace on the earth.''"

*Mē nomisēte hoti ēlthon balein eirēnēn epi tēn gēn*—not peace.

"''I came not to send peace, but a sword.''"

*Ouk ēlthon balein eirēnēn alla machairan*—sword.

"''I came to set a man at variance against his father.''"

*Ēlthon gar dichasai anthrōpon kata tou patros autou*—variance.

**Micah 7:6.**

"''A man's foes shall be they of his own household.''"

*Kai echthroi tou anthrōpou hoi oikiakoi autou*—household foes.

"''He that loves father or mother more than me is not worthy of me.''"

*Ho philōn patera ē mētera hyper eme ouk estin mou axios*—not worthy.

"''He that does not take his cross and follow after me, is not worthy of me.''"

*Kai hos ou lambanei ton stauron autou kai akolouthei opisō mou ouk estin mou axios*—take cross.

**First Mention of Cross:**
Before the crucifixion—cross as discipleship image.

"''He that finds his life shall lose it.''"

*Ho heurōn tēn psychēn autou apolesei autēn*—lose life.

"''He that loses his life for my sake shall find it.''"

*Kai ho apolesas tēn psychēn autou heneken emou heurēsei autēn*—find life.

**The Key Verses (10:40-42):**
"''He that receives you receives me.''"

*Ho dechomenos hymas eme dechetai*—receives.

"''He that receives me receives him that sent me.''"

*Kai ho eme dechomenos dechetai ton aposteilanta me*—sent me.

"''Whosoever shall give to drink unto one of these little ones a cup of cold water only.''"

*Hos an potisē hena tōn mikrōn toutōn potērion psychrou monon*—cup of water.

"''He shall in no wise lose his reward.''"

*Ou mē apolesē ton misthon autou*—reward.

**Archetypal Layer:** Matthew 10 contains **the Twelve commissioned (10:1-4)**, **"Go... to the lost sheep of the house of Israel" (10:6)**, **"The kingdom of heaven is at hand" (10:7)**, **"freely you received, freely give" (10:8)**, **"the laborer is worthy of his food" (10:10)**, **"shake off the dust of your feet" (10:14)**, **"I send you forth as sheep in the midst of wolves" (10:16)**, **"wise as serpents, and harmless as doves" (10:16)**, **"it is not you that speak, but the Spirit of your Father" (10:20)**, **"he that endures to the end, the same shall be saved" (10:22)**, **"be not afraid of them that kill the body, but are not able to kill the soul" (10:28)**, **"the very hairs of your head are all numbered" (10:30)**, **"I came not to send peace, but a sword" (10:34)**, **"he that does not take his cross and follow after me, is not worthy of me" (10:38)**, and **"he that loses his life for my sake shall find it" (10:39)**.

**Modern Equivalent:** Matthew 10 is Yeshua's mission discourse. The Twelve are sent initially to Israel only (10:5-6). They're given authority and sent without provisions, trusting hospitality (10:8-10). Persecution is promised (10:17-23). Fear God, not humans (10:28). Divine providence extends to sparrows and hairs (10:29-30). Discipleship means family division, cross-bearing, and life-losing (10:34-39). Receiving disciples = receiving Yeshua = receiving the Father (10:40).

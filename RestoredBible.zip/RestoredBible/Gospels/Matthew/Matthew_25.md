# Matthew 25: Parables of Readiness and the Final Judgment

*From the Greek: Τότε ὁμοιωθήσεται ἡ βασιλεία τῶν οὐρανῶν (Tote Homoiōthēsetai hē Basileia tōn Ouranōn) — Then Shall the Kingdom of Heaven Be Likened*

---

## The Parable of the Ten Virgins (25:1-13)

**25:1** "Then shall the kingdom of heaven be likened unto ten virgins, who took their lamps, and went forth to meet the bridegroom.

**25:2** "And five of them were foolish, and five were wise.

**25:3** "For the foolish, when they took their lamps, took no oil with them:

**25:4** "But the wise took oil in their vessels with their lamps.

**25:5** "Now while the bridegroom tarried, they all slumbered and slept.

**25:6** "But at midnight there is a cry, 'Behold, the bridegroom! Come forth to meet him.'

**25:7** "Then all those virgins arose, and trimmed their lamps.

**25:8** "And the foolish said unto the wise: 'Give us of your oil; for our lamps are going out.'

**25:9** "But the wise answered, saying: 'Peradventure there will not be enough for us and you: go rather to them that sell, and buy for yourselves.'

**25:10** "And while they went away to buy, the bridegroom came; and they that were ready went in with him to the marriage feast: and the door was shut.

**25:11** "Afterward came also the other virgins, saying: 'Lord, Lord, open to us.'

**25:12** "But he answered and said: 'Verily I say unto you, I know you not.'

**25:13** "Watch therefore, for you know not the day nor the hour."

---

## The Parable of the Talents (25:14-30)

**25:14** "For it is as when a man, going into another country, called his own servants, and delivered unto them his goods.

**25:15** "And unto one he gave five talents, to another two, to another one; to each according to his several ability; and he went on his journey.

**25:16** "Straightway he that received the five talents went and traded with them, and made other five talents.

**25:17** "In like manner he also that received the two gained other two.

**25:18** "But he that received the one went away and dug in the earth, and hid his lord's money.

**25:19** "Now after a long time the lord of those servants comes, and makes a reckoning with them.

**25:20** "And he that received the five talents came and brought other five talents, saying: 'Lord, you delivered unto me five talents: lo, I have gained other five talents.'

**25:21** "His lord said unto him: 'Well done, good and faithful servant: you have been faithful over a few things, I will set you over many things; enter into the joy of your lord.'

**25:22** "And he also that received the two talents came and said: 'Lord, you delivered unto me two talents: lo, I have gained other two talents.'

**25:23** "His lord said unto him: 'Well done, good and faithful servant: you have been faithful over a few things, I will set you over many things; enter into the joy of your lord.'

**25:24** "And he also that had received the one talent came and said: 'Lord, I knew you that you are a hard man, reaping where you did not sow, and gathering where you did not scatter;

**25:25** "'And I was afraid, and went away and hid your talent in the earth: lo, you have what is yours.'

**25:26** "But his lord answered and said unto him: 'You wicked and slothful servant, you knew that I reap where I sowed not, and gather where I did not scatter;

**25:27** "'You ought therefore to have put my money to the bankers, and at my coming I should have received back my own with interest.

**25:28** "'Take away therefore the talent from him, and give it unto him that has the ten talents.

**25:29** "'For unto every one that has shall be given, and he shall have abundance: but from him that has not, even that which he has shall be taken away.

**25:30** "'And cast out the unprofitable servant into the outer darkness: there shall be the weeping and the gnashing of teeth.'"

---

## The Sheep and the Goats (25:31-46)

**25:31** "But when the Son of man shall come in his glory, and all the angels with him, then shall he sit on the throne of his glory:

**25:32** "And before him shall be gathered all the nations: and he shall separate them one from another, as the shepherd separates the sheep from the goats;

**25:33** "And he shall set the sheep on his right hand, but the goats on the left.

**25:34** "Then shall the King say unto them on his right hand: 'Come, you blessed of my Father, inherit the kingdom prepared for you from the foundation of the world:

**25:35** "'For I was hungry, and you gave me to eat; I was thirsty, and you gave me drink; I was a stranger, and you took me in;

**25:36** "'Naked, and you clothed me; I was sick, and you visited me; I was in prison, and you came unto me.'

**25:37** "Then shall the righteous answer him, saying: 'Lord, when saw we you hungry, and fed you? Or athirst, and gave you drink?

**25:38** "'And when saw we you a stranger, and took you in? Or naked, and clothed you?

**25:39** "'And when saw we you sick, or in prison, and came unto you?'

**25:40** "And the King shall answer and say unto them: 'Verily I say unto you, Inasmuch as you did it unto one of these my brethren, even these least, you did it unto me.'

**25:41** "Then shall he say also unto them on the left hand: 'Depart from me, you cursed, into the eternal fire which is prepared for the devil and his angels:

**25:42** "'For I was hungry, and you gave me no food; I was thirsty, and you gave me no drink;

**25:43** "'I was a stranger, and you took me not in; naked, and you clothed me not; sick, and in prison, and you visited me not.'

**25:44** "Then shall they also answer, saying: 'Lord, when saw we you hungry, or athirst, or a stranger, or naked, or sick, or in prison, and did not minister unto you?'

**25:45** "Then shall he answer them, saying: 'Verily I say unto you, Inasmuch as you did it not unto one of these least, you did it not unto me.'

**25:46** "And these shall go away into eternal punishment: but the righteous into eternal life."

---

## Synthesis Notes

**Key Restorations:**

**Ten Virgins (25:1-13):**
**The Key Verses (25:1-6):**
"''The kingdom of heaven be likened unto ten virgins.''"

*Tote homoiōthēsetai hē basileia tōn ouranōn deka parthenois*—ten virgins.

"''Who took their lamps, and went forth to meet the bridegroom.''"

*Haitines labousai tas lampadas heautōn exēlthon eis hypantēsin tou nymphiou*—bridegroom.

"''Five of them were foolish, and five were wise.''"

*Pente de ex autōn ēsan mōrai kai pente phronimoi*—foolish, wise.

"''The foolish... took no oil with them.''"

*Hai gar mōrai labousai tas lampadas ouk elabon meth' heautōn elaion*—no oil.

"''The wise took oil in their vessels with their lamps.''"

*Hai de phronimoi elabon elaion en tois angeiois meta tōn lampadōn heautōn*—oil.

"''While the bridegroom tarried, they all slumbered and slept.''"

*Chronizontos de tou nymphiou enystaxan pasai kai ekatheudon*—all slept.

"''At midnight there is a cry, Behold, the bridegroom!''"

*Mesēs de nyktos kraugē gegonen idou ho nymphios*—midnight cry.

**The Key Verses (25:7-13):**
"''All those virgins arose, and trimmed their lamps.''"

*Tote ēgerthēsan pasai hai parthenoi ekeinai kai ekosmēsan tas lampadas heautōn*—trimmed.

"''Give us of your oil; for our lamps are going out.''"

*Dote hēmin ek tou elaiou hymōn hoti hai lampades hēmōn sbennyntai*—going out.

"''Go rather to them that sell, and buy for yourselves.''"

*Poreuesthe mallon pros tous pōlountas kai agorasate heautais*—buy.

"''While they went away to buy, the bridegroom came.''"

*Aperchomenōn de autōn agorasai ēlthen ho nymphios*—came.

"''They that were ready went in with him to the marriage feast.''"

*Kai hai hetoimoi eisēlthon met' autou eis tous gamous*—ready entered.

"''The door was shut.''"

*Kai ekleisthē hē thyra*—door shut.

"''Lord, Lord, open to us.''"

*Kyrie kyrie anoixon hēmin*—open.

"''I know you not.''"

*Ouk oida hymas*—don't know.

"''Watch therefore, for you know not the day nor the hour.''"

*Grēgoreite oun hoti ouk oidate tēn hēmeran oude tēn hōran*—watch.

**Talents (25:14-30):**
**The Key Verses (25:14-18):**
"''A man, going into another country, called his own servants, and delivered unto them his goods.''"

*Hōsper gar anthrōpos apodēmōn ekalesen tous idious doulous kai paredōken autois ta hyparchonta autou*—delivered.

"''Unto one he gave five talents, to another two, to another one.''"

*Kai hō men edōken pente talanta hō de dyo hō de hen*—five, two, one.

**Talent:**
Large sum—about 20 years' wages.

"''To each according to his several ability.''"

*Hekastō kata tēn idian dynamin*—ability.

"''He that received the five talents went and traded with them, and made other five.''"

*Poreutheis ho ta pente talanta labōn ērgasato en autois kai epoiēsen alla pente talanta*—doubled.

"''He that received the one went away and dug in the earth, and hid his lord's money.''"

*Ho de to hen labōn apelthōn ōryxen gēn kai ekrypsen to argyrion tou kyriou autou*—hid.

**The Key Verses (25:19-23):**
"''After a long time the lord of those servants comes, and makes a reckoning.''"

*Meta de polyn chronon erchetai ho kyrios tōn doulōn ekeinōn kai synairei logon met' autōn*—reckoning.

"''Lord, you delivered unto me five talents: lo, I have gained other five.''"

*Kyrie pente talanta moi paredōkas ide alla pente talanta ekerdēsa*—report.

"''Well done, good and faithful servant.''"

*Eu doule agathe kai piste*—well done.

"''You have been faithful over a few things, I will set you over many things.''"

*Epi oliga ēs pistos epi pollōn se katastēsō*—few to many.

"''Enter into the joy of your lord.''"

*Eiselthe eis tēn charan tou kyriou sou*—joy.

**The Key Verses (25:24-30):**
"''Lord, I knew you that you are a hard man.''"

*Kyrie egnōn se hoti sklēros ei anthrōpos*—hard man.

"''Reaping where you did not sow, and gathering where you did not scatter.''"

*Therizōn hopou ouk espeiras kai synagōn hothen ou dieskorpisas*—reaping.

"''I was afraid, and went away and hid your talent.''"

*Kai phobētheis apelthōn ekrypsa to talanton sou en tē gē*—afraid.

"''You wicked and slothful servant.''"

*Ponēre doule kai oknēre*—wicked, slothful.

"''You ought therefore to have put my money to the bankers.''"

*Edei se oun balein ta argyria mou tois trapezitais*—bankers.

"''At my coming I should have received back my own with interest.''"

*Kai elthōn egō ekomismēn an to emon syn tokō*—interest.

"''Unto every one that has shall be given, and he shall have abundance.''"

*Tō gar echonti panti dothēsetai kai perisseuthēsetai*—given.

"''From him that has not, even that which he has shall be taken away.''"

*Tou de mē echontos kai ho echei arthēsetai ap' autou*—taken.

"''Cast out the unprofitable servant into the outer darkness.''"

*Kai ton achreion doulon ekbalete eis to skotos to exōteron*—outer darkness.

**Sheep and Goats (25:31-46):**
**The Key Verses (25:31-36):**
"''When the Son of man shall come in his glory, and all the angels with him.''"

*Hotan de elthē ho huios tou anthrōpou en tē doxē autou kai pantes hoi angeloi met' autou*—glory.

"''Then shall he sit on the throne of his glory.''"

*Tote kathisei epi thronou doxēs autou*—throne.

"''Before him shall be gathered all the nations.''"

*Kai synachthēsontai emprosthen autou panta ta ethnē*—all nations.

"''He shall separate them one from another, as the shepherd separates the sheep from the goats.''"

*Kai aphorisei autous ap' allēlōn hōsper ho poimēn aphorizei ta probata apo tōn eriphōn*—separate.

"''He shall set the sheep on his right hand, but the goats on the left.''"

*Kai stēsei ta men probata ek dexiōn autou ta de eriphia ex euōnymōn*—right, left.

"''Come, you blessed of my Father, inherit the kingdom prepared for you from the foundation of the world.''"

*Deute hoi eulogēmenoi tou patros mou klēronomēsate tēn hētoimasmenēn hymin basileian apo katabolēs kosmou*—inherit.

"''I was hungry, and you gave me to eat.''"

*Epeinasa gar kai edōkate moi phagein*—fed.

"''I was thirsty, and you gave me drink.''"

*Edipsēsa kai epotisate me*—drink.

"''I was a stranger, and you took me in.''"

*Xenos ēmēn kai synēgagete me*—stranger.

"''Naked, and you clothed me.''"

*Gymnos kai periebalete me*—clothed.

"''I was sick, and you visited me.''"

*Ēsthenēsa kai epeskepsasthe me*—sick.

"''I was in prison, and you came unto me.''"

*En phylakē ēmēn kai ēlthate pros me*—prison.

**The Key Verses (25:37-46):**
"''Lord, when saw we you hungry, and fed you?''"

*Kyrie pote se eidomen peinōnta kai ethrepsamen*—when?

"''Inasmuch as you did it unto one of these my brethren, even these least, you did it unto me.''"

*Eph' hoson epoiēsate heni toutōn tōn adelphōn mou tōn elachistōn emoi epoiēsate*—unto me.

"''Depart from me, you cursed, into the eternal fire.''"

*Poreuesthe ap' emou hoi katēramenoi eis to pyr to aiōnion*—eternal fire.

"''Which is prepared for the devil and his angels.''"

*To hētoimasmenon tō diabolō kai tois angelois autou*—prepared.

"''I was hungry, and you gave me no food.''"

*Epeinasa gar kai ouk edōkate moi phagein*—didn't feed.

"''Inasmuch as you did it not unto one of these least, you did it not unto me.''"

*Eph' hoson ouk epoiēsate heni toutōn tōn elachistōn oude emoi epoiēsate*—didn't do.

"''These shall go away into eternal punishment.''"

*Kai apeleusontai houtoi eis kolasin aiōnion*—eternal punishment.

"''But the righteous into eternal life.''"

*Hoi de dikaioi eis zōēn aiōnion*—eternal life.

**Archetypal Layer:** Matthew 25 contains **parable of the ten virgins (25:1-13)**: five wise with oil, five foolish without, bridegroom delays, midnight cry, door shut, **"I know you not" (25:12)**, **"Watch therefore, for you know not the day nor the hour" (25:13)**, **parable of the talents (25:14-30)**: five, two, one talent, faithful servants doubled, fearful servant hid, **"Well done, good and faithful servant... enter into the joy of your lord" (25:21, 23)**, **"unto every one that has shall be given" (25:29)**, **sheep and goats judgment (25:31-46)**: all nations gathered, separated right and left, **six acts of mercy**: hungry, thirsty, stranger, naked, sick, imprisoned, **"Inasmuch as you did it unto one of these my brethren, even these least, you did it unto me" (25:40)**, **"Depart from me, you cursed, into the eternal fire" (25:41)**, and **"eternal punishment... eternal life" (25:46)**.

**Modern Equivalent:** Matthew 25 continues the Olivet Discourse with three parables of readiness. The ten virgins (25:1-13) teach that preparation cannot be borrowed at the last moment—be ready. The talents (25:14-30) teach faithful stewardship—risk and invest, don't hide. The sheep and goats (25:31-46) is the final judgment: the criterion is treatment of "the least of these my brethren." Serving the hungry, thirsty, stranger, naked, sick, and imprisoned is serving Christ Himself. Neglect is equally significant—what we fail to do matters.

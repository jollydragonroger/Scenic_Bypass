# Matthew 21: Triumphal Entry and Temple Confrontations

*From the Greek: Καὶ ὅτε ἤγγισαν εἰς Ἱεροσόλυμα (Kai Hote Ēngisan eis Hierosolyma) — And When They Drew Near to Jerusalem*

---

## The Triumphal Entry (21:1-11)

**21:1** And when they drew near unto Jerusalem, and came unto Bethphage, unto the mount of Olives, then Yeshua sent two disciples,

**21:2** Saying unto them: "Go into the village that is over against you, and straightway you shall find an ass tied, and a colt with her: loose them, and bring them unto me.

**21:3** "And if any one say aught unto you, you shall say, 'The Lord has need of them'; and straightway he will send them."

**21:4** Now this is come to pass, that it might be fulfilled which was spoken through the prophet, saying:

**21:5** "Tell the daughter of Zion, Behold, your King comes unto you, meek, and riding upon an ass, and upon a colt the foal of an ass."

**21:6** And the disciples went, and did even as Yeshua appointed them,

**21:7** And brought the ass, and the colt, and put on them their garments; and he sat thereon.

**21:8** And the most part of the multitude spread their garments in the way; and others cut branches from the trees, and spread them in the way.

**21:9** And the multitudes that went before him, and that followed, cried, saying: "Hosanna to the son of David: Blessed is he that comes in the name of the Lord; Hosanna in the highest."

**21:10** And when he was come into Jerusalem, all the city was stirred, saying: "Who is this?"

**21:11** And the multitudes said: "This is the prophet, Yeshua, from Nazareth of Galilee."

---

## Cleansing the Temple (21:12-17)

**21:12** And Yeshua entered into the temple of God, and cast out all them that sold and bought in the temple, and overthrew the tables of the money-changers, and the seats of them that sold the doves;

**21:13** And he says unto them: "It is written, 'My house shall be called a house of prayer': but you make it a den of robbers."

**21:14** And the blind and the lame came to him in the temple; and he healed them.

**21:15** But when the chief priests and the scribes saw the wonderful things that he did, and the children that were crying in the temple and saying: "Hosanna to the son of David"; they were moved with indignation,

**21:16** And said unto him: "Do you hear what these are saying?" And Yeshua says unto them: "Yea: did you never read, 'Out of the mouth of babes and sucklings you have perfected praise'?"

**21:17** And he left them, and went forth out of the city to Bethany, and lodged there.

---

## The Fig Tree Cursed (21:18-22)

**21:18** Now in the morning as he returned to the city, he hungered.

**21:19** And seeing a fig tree by the way side, he came to it, and found nothing thereon, but leaves only; and he says unto it: "Let there be no fruit from you henceforward for ever." And immediately the fig tree withered away.

**21:20** And when the disciples saw it, they marvelled, saying: "How did the fig tree immediately wither away?"

**21:21** And Yeshua answered and said unto them: "Verily I say unto you, If you have faith, and doubt not, you shall not only do what is done to the fig tree, but even if you shall say unto this mountain, 'Be removed, and be cast into the sea,' it shall be done.

**21:22** "And all things, whatsoever you shall ask in prayer, believing, you shall receive."

---

## The Authority of Yeshua Questioned (21:23-27)

**21:23** And when he was come into the temple, the chief priests and the elders of the people came unto him as he was teaching, and said: "By what authority do you do these things? And who gave you this authority?"

**21:24** And Yeshua answered and said unto them: "I also will ask you one question, which if you tell me, I likewise will tell you by what authority I do these things.

**21:25** "The immersion of John, whence was it? From heaven or from men?" And they reasoned with themselves, saying: "If we shall say, 'From heaven'; he will say unto us, 'Why then did you not believe him?'

**21:26** "But if we shall say, 'From men'; we fear the multitude; for all hold John as a prophet."

**21:27** And they answered Yeshua, and said: "We know not." He also said unto them: "Neither tell I you by what authority I do these things."

---

## Parable of the Two Sons (21:28-32)

**21:28** "But what think you? A man had two sons; and he came to the first, and said: 'Son, go work today in the vineyard.'

**21:29** "And he answered and said: 'I will not': but afterward he repented himself, and went.

**21:30** "And he came to the second, and said likewise. And he answered and said: 'I go, sir': and went not.

**21:31** "Which of the two did the will of his father?" They say: "The first." Yeshua says unto them: "Verily I say unto you, that the publicans and the harlots go into the kingdom of God before you.

**21:32** "For John came unto you in the way of righteousness, and you believed him not; but the publicans and the harlots believed him: and you, when you saw it, did not even repent yourselves afterward, that you might believe him."

---

## Parable of the Wicked Tenants (21:33-46)

**21:33** "Hear another parable: There was a man that was a householder, who planted a vineyard, and set a hedge about it, and dug a winepress in it, and built a tower, and let it out to husbandmen, and went into another country.

**21:34** "And when the season of the fruits drew near, he sent his servants to the husbandmen, to receive his fruits.

**21:35** "And the husbandmen took his servants, and beat one, and killed another, and stoned another.

**21:36** "Again, he sent other servants more than the first: and they did unto them in like manner.

**21:37** "But afterward he sent unto them his son, saying: 'They will reverence my son.'

**21:38** "But the husbandmen, when they saw the son, said among themselves: 'This is the heir; come, let us kill him, and take his inheritance.'

**21:39** "And they took him, and cast him forth out of the vineyard, and killed him.

**21:40** "When therefore the lord of the vineyard shall come, what will he do unto those husbandmen?"

**21:41** They say unto him: "He will miserably destroy those miserable men, and will let out the vineyard unto other husbandmen, who shall render him the fruits in their seasons."

**21:42** Yeshua says unto them: "Did you never read in the scriptures: 'The stone which the builders rejected, the same was made the head of the corner; this was from the Lord, and it is marvellous in our eyes'?

**21:43** "Therefore say I unto you, The kingdom of God shall be taken away from you, and shall be given to a nation bringing forth the fruits thereof.

**21:44** "And he that falls on this stone shall be broken to pieces: but on whomsoever it shall fall, it will scatter him as dust."

**21:45** And when the chief priests and the Pharisees heard his parables, they perceived that he spoke of them.

**21:46** And when they sought to lay hold on him, they feared the multitudes, because they took him for a prophet.

---

## Synthesis Notes

**Key Restorations:**

**Triumphal Entry (21:1-11):**
**The Key Verses (21:1-5):**
"'When they drew near unto Jerusalem, and came unto Bethphage, unto the mount of Olives.'"

*Kai hote ēngisan eis Hierosolyma kai ēlthon eis Bēthphagē eis to oros tōn elaiōn*—Mount of Olives.

"''Go into the village... you shall find an ass tied, and a colt with her.''"

*Poreuesthe eis tēn kōmēn... heurēsete onon dedemenēn kai pōlon met' autēs*—donkey, colt.

"''The Lord has need of them.''"

*Ho kyrios autōn chreian echei*—Lord needs.

"''Tell the daughter of Zion, Behold, your King comes unto you, meek.''"

*Eipate tē thygatri Siōn idou ho basileus sou erchetai soi praus*—meek King.

**Zechariah 9:9 + Isaiah 62:11.**

"''Riding upon an ass, and upon a colt the foal of an ass.''"

*Epibebēkōs epi onon kai epi pōlon huion hypozugiou*—donkey, colt.

**The Key Verses (21:6-11):**
"'The most part of the multitude spread their garments in the way.'"

*Ho de pleistos ochlos estrōsan heautōn ta himatia en tē hodō*—garments.

"'Others cut branches from the trees.'"

*Alloi de ekopton kladous apo tōn dendrōn*—branches.

"''Hosanna to the son of David.''"

*Hōsanna tō huiō David*—Hosanna.

**Hosanna:**
Hebrew "Save now!" (Psalm 118:25).

"''Blessed is he that comes in the name of the Lord.''"

*Eulogēmenos ho erchomenos en onomati kyriou*—blessed.

**Psalm 118:26.**

"''Hosanna in the highest.''"

*Hōsanna en tois hypsistois*—highest.

"'All the city was stirred, saying: Who is this?'"

*Eseisthē pasa hē polis legousa tis estin houtos*—stirred.

"''This is the prophet, Yeshua, from Nazareth of Galilee.''"

*Houtos estin ho prophētēs Iēsous ho apo Nazareth tēs Galilaias*—prophet.

**Cleansing the Temple (21:12-17):**
**The Key Verses (21:12-17):**
"'Yeshua entered into the temple of God.'"

*Kai eisēlthen Iēsous eis to hieron*—temple.

"'Cast out all them that sold and bought in the temple.'"

*Kai exebalen pantas tous pōlountas kai agorazontas en tō hierō*—cast out.

"'Overthrew the tables of the money-changers.'"

*Kai tas trapezas tōn kollybistōn katestrepsen*—tables.

"''My house shall be called a house of prayer.''"

*Ho oikos mou oikos proseuchēs klēthēsetai*—prayer.

**Isaiah 56:7.**

"''You make it a den of robbers.''"

*Hymeis de auton poieite spēlaion lēstōn*—robbers.

**Jeremiah 7:11.**

"'The blind and the lame came to him in the temple; and he healed them.'"

*Kai prosēlthon autō typhloi kai chōloi en tō hierō kai etherapeusen autous*—healed.

"''Out of the mouth of babes and sucklings you have perfected praise.''"

*Ek stomatos nēpiōn kai thēlazontōn katērtisō ainon*—children's praise.

**Psalm 8:2.**

**Fig Tree Cursed (21:18-22):**
**The Key Verses (21:18-22):**
"'Seeing a fig tree by the way side, he came to it, and found nothing thereon, but leaves only.'"

*Kai idōn sykēn mian epi tēs hodou ēlthen ep' autēn kai ouden heuren en autē ei mē phylla monon*—leaves only.

"''Let there be no fruit from you henceforward for ever.''"

*Ou mēketi ek sou karpos genētai eis ton aiōna*—no fruit.

"'Immediately the fig tree withered away.'"

*Kai exēranthē parachrēma hē sykē*—withered.

**Symbolic:**
Israel's fruitlessness.

"''If you have faith, and doubt not.''"

*Ean echēte pistin kai mē diakrithēte*—faith.

"''If you shall say unto this mountain, Be removed, and be cast into the sea, it shall be done.''"

*Kan tō orei toutō eipēte arthēti kai blēthēti eis tēn thalassan genēsetai*—mountain.

"''All things, whatsoever you shall ask in prayer, believing, you shall receive.''"

*Kai panta hosa an aitēsēte en tē proseuchē pisteuontes lēmpsesthe*—receive.

**Authority Questioned (21:23-27):**
**The Key Verses (21:23-27):**
"''By what authority do you do these things?''"

*En poia exousia tauta poieis*—what authority?

"''The immersion of John, whence was it? From heaven or from men?''"

*To baptisma to Iōannou pothen ēn ex ouranou ē ex anthrōpōn*—heaven or men?

"'They reasoned with themselves.'"

*Hoi de dielogizonto en heautois*—reasoned.

"''If we shall say, From heaven; he will say unto us, Why then did you not believe him?''"

*Ean eipōmen ex ouranou erei hēmin dia ti oun ouk episteusate autō*—trapped.

"''We fear the multitude.''"

*Phoboumetha ton ochlon*—fear crowd.

"'We know not.'"

*Ouk oidamen*—don't know.

"''Neither tell I you by what authority I do these things.''"

*Oude egō legō hymin en poia exousia tauta poiō*—neither do I tell.

**Two Sons (21:28-32):**
**The Key Verses (21:28-32):**
"''A man had two sons.''"

*Anthrōpos eichen tekna dyo*—two sons.

"''Son, go work today in the vineyard.''"

*Teknon hypage sēmeron ergazou en tō ampelōni*—work.

"''I will not': but afterward he repented himself, and went.''"

*Ou thelō hysteron de metamelētheis apēlthen*—repented.

"''I go, sir': and went not.''"

*Egō kyrie kai ouk apēlthen*—didn't go.

"''Which of the two did the will of his father?''"

*Tis ek tōn dyo epoiēsen to thelēma tou patros*—which?

"''The publicans and the harlots go into the kingdom of God before you.''"

*Hoi telōnai kai hai pornai proagousin hymas eis tēn basileian tou theou*—before you.

"''John came unto you in the way of righteousness, and you believed him not.''"

*Ēlthen gar Iōannēs pros hymas en hodō dikaiosynēs kai ouk episteusate autō*—didn't believe.

**Wicked Tenants (21:33-46):**
**The Key Verses (21:33-41):**
"''There was a man that was a householder, who planted a vineyard.''"

*Anthrōpos ēn oikodespotēs hostis ephyteusen ampelōna*—vineyard.

**Isaiah 5:1-7:**
Vineyard = Israel.

"''Set a hedge about it, and dug a winepress in it, and built a tower.''"

*Kai phragmon autō periethēken kai ōryxen en autō lēnon kai ōkodomēsen pyrgon*—vineyard details.

"''Let it out to husbandmen.''"

*Kai exedeto auton geōrgois*—tenants.

"''He sent his servants to the husbandmen, to receive his fruits.''"

*Apesteilen tous doulous autou pros tous geōrgous labein tous karpous autou*—servants = prophets.

"''The husbandmen took his servants, and beat one, and killed another.''"

*Kai labontes hoi geōrgoi tous doulous autou hon men edeiran hon de apekteinan*—killed.

"''But afterward he sent unto them his son.''"

*Hysteron de apesteilen pros autous ton huion autou*—son.

"''This is the heir; come, let us kill him, and take his inheritance.''"

*Houtos estin ho klēronomos deute apokteinōmen auton kai schōmen tēn klēronomian autou*—kill heir.

"''They took him, and cast him forth out of the vineyard, and killed him.''"

*Kai labontes auton exebalon exō tou ampelōnos kai apekteinan*—killed son.

**The Key Verses (21:42-46):**
"''The stone which the builders rejected, the same was made the head of the corner.''"

*Lithon hon apedokimasan hoi oikodomountes houtos egenēthē eis kephalēn gōnias*—cornerstone.

**Psalm 118:22-23.**

"''The kingdom of God shall be taken away from you, and shall be given to a nation bringing forth the fruits thereof.''"

*Dia touto legō hymin hoti arthēsetai aph' hymōn hē basileia tou theou kai dothēsetai ethnei poiounti tous karpous autēs*—given to nation.

"''He that falls on this stone shall be broken to pieces.''"

*Kai ho pesōn epi ton lithon touton synthlasthēsetai*—broken.

"'They perceived that he spoke of them.'"

*Egnōsan hoti peri autōn legei*—about them.

"'They feared the multitudes, because they took him for a prophet.'"

*Ephobēthēsan tous ochlous epei eis prophētēn auton eichon*—prophet.

**Archetypal Layer:** Matthew 21 contains **triumphal entry (21:1-11)**: Zechariah 9:9 fulfilled, "Hosanna to the son of David" (Psalm 118:25-26), **cleansing the temple (21:12-17)**: "My house shall be called a house of prayer... you make it a den of robbers" (Isaiah 56:7, Jeremiah 7:11), **cursing of the fig tree (21:18-22)**: symbolic of Israel's fruitlessness, **authority questioned (21:23-27)**: John's immersion dilemma, **parable of the two sons (21:28-32)**: "the publicans and the harlots go into the kingdom of God before you", **parable of the wicked tenants (21:33-46)**: vineyard, servants killed, son killed, **"The stone which the builders rejected" (Psalm 118:22-23)**, and **"The kingdom of God shall be taken away from you, and shall be given to a nation bringing forth the fruits" (21:43)**.

**Modern Equivalent:** Matthew 21 marks Yeshua's entry into Jerusalem as king—fulfilling Zechariah 9:9. The temple cleansing (21:12-17) combines Isaiah 56:7 and Jeremiah 7:11, condemning commercial corruption. The fig tree (21:18-22) symbolizes Israel's outward appearance without fruit. The two sons (21:28-32) contrast religious profession with actual obedience—sinners who repent outpace respectable unbelievers. The wicked tenants (21:33-46) is transparently about Israel's leaders rejecting prophets and now the Son—the kingdom will be given to others.

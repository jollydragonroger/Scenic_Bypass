# Matthew 18: The Community Discourse — Humility, Forgiveness, Reconciliation

*From the Greek: Ἐν ἐκείνῃ τῇ ὥρᾳ (En Ekeinē tē Hōra) — In That Hour*

---

## The Greatest in the Kingdom (18:1-5)

**18:1** In that hour came the disciples unto Yeshua, saying: "Who then is greatest in the kingdom of heaven?"

**18:2** And he called to him a little child, and set him in the midst of them,

**18:3** And said: "Verily I say unto you, Except you turn, and become as little children, you shall in no wise enter into the kingdom of heaven.

**18:4** "Whosoever therefore shall humble himself as this little child, the same is the greatest in the kingdom of heaven.

**18:5** "And whoso shall receive one such little child in my name receives me."

---

## Warnings about Stumbling (18:6-9)

**18:6** "But whoso shall cause one of these little ones that believe on me to stumble, it is profitable for him that a great millstone should be hanged about his neck, and that he should be sunk in the depth of the sea.

**18:7** "Woe unto the world because of occasions of stumbling! For it must needs be that the occasions come; but woe to that man through whom the occasion comes!

**18:8** "And if your hand or your foot causes you to stumble, cut it off, and cast it from you: it is good for you to enter into life maimed or halt, rather than having two hands or two feet to be cast into the eternal fire.

**18:9** "And if your eye causes you to stumble, pluck it out, and cast it from you: it is good for you to enter into life with one eye, rather than having two eyes to be cast into the Gehenna of fire."

---

## The Lost Sheep (18:10-14)

**18:10** "See that you despise not one of these little ones; for I say unto you, that in heaven their angels do always behold the face of my Father who is in heaven.

**18:11** [For the Son of man came to save that which was lost.]

**18:12** "How think you? If any man have a hundred sheep, and one of them be gone astray, does he not leave the ninety and nine, and go unto the mountains, and seek that which goes astray?

**18:13** "And if so be that he find it, verily I say unto you, he rejoices over it more than over the ninety and nine which have not gone astray.

**18:14** "Even so it is not the will of your Father who is in heaven, that one of these little ones should perish."

---

## Discipline in the Assembly (18:15-20)

**18:15** "And if your brother sin against you, go, show him his fault between you and him alone: if he hear you, you have gained your brother.

**18:16** "But if he hear you not, take with you one or two more, that at the mouth of two witnesses or three every word may be established.

**18:17** "And if he refuse to hear them, tell it unto the assembly: and if he refuse to hear the assembly also, let him be unto you as the Gentile and the publican.

**18:18** "Verily I say unto you, What things soever you shall bind on earth shall be bound in heaven; and what things soever you shall loose on earth shall be loosed in heaven.

**18:19** "Again I say unto you, that if two of you shall agree on earth as touching anything that they shall ask, it shall be done for them of my Father who is in heaven.

**18:20** "For where two or three are gathered together in my name, there am I in the midst of them."

---

## The Unforgiving Servant (18:21-35)

**18:21** Then came Peter and said to him: "Lord, how oft shall my brother sin against me, and I forgive him? Until seven times?"

**18:22** Yeshua says unto him: "I say not unto you, Until seven times; but, Until seventy times seven.

**18:23** "Therefore is the kingdom of heaven likened unto a certain king, who would make a reckoning with his servants.

**18:24** "And when he had begun to reckon, one was brought unto him, that owed him ten thousand talents.

**18:25** "But forasmuch as he had not wherewith to pay, his lord commanded him to be sold, and his wife, and children, and all that he had, and payment to be made.

**18:26** "The servant therefore fell down and worshipped him, saying: 'Lord, have patience with me, and I will pay you all.'

**18:27** "And the lord of that servant, being moved with compassion, released him, and forgave him the debt.

**18:28** "But that servant went out, and found one of his fellow-servants, who owed him a hundred pence; and he laid hold on him, and took him by the throat, saying: 'Pay what you owe.'

**18:29** "So his fellow-servant fell down and besought him, saying: 'Have patience with me, and I will pay you.'

**18:30** "And he would not: but went and cast him into prison, till he should pay that which was due.

**18:31** "So when his fellow-servants saw what was done, they were exceeding sorry, and came and told unto their lord all that was done.

**18:32** "Then his lord called him unto him, and says to him: 'You wicked servant, I forgave you all that debt, because you begged me:

**18:33** "'Should you not also have had mercy on your fellow-servant, even as I had mercy on you?'

**18:34** "And his lord was angry, and delivered him to the tormentors, till he should pay all that was due.

**18:35** "So shall also my heavenly Father do unto you, if you forgive not every one his brother from your hearts."

---

## Synthesis Notes

**Key Restorations:**

**Greatest in the Kingdom (18:1-5):**
**The Key Verses (18:1-5):**
"''Who then is greatest in the kingdom of heaven?''"

*Tis ara meizōn estin en tē basileia tōn ouranōn*—greatest?

"'He called to him a little child, and set him in the midst of them.'"

*Kai proskalesamenos paidion estēsen auto en mesō autōn*—child.

"''Except you turn, and become as little children.''"

*Ean mē straphēte kai genēsthe hōs ta paidia*—become children.

"''You shall in no wise enter into the kingdom of heaven.''"

*Ou mē eiselthēte eis tēn basileian tōn ouranōn*—not enter.

"''Whosoever therefore shall humble himself as this little child.''"

*Hostis oun tapeinōsei heauton hōs to paidion touto*—humble.

"''The same is the greatest in the kingdom of heaven.''"

*Houtos estin ho meizōn en tē basileia tōn ouranōn*—greatest.

"''Whoso shall receive one such little child in my name receives me.''"

*Kai hos ean dexētai hen paidion toiouton epi tō onomati mou eme dechetai*—receives me.

**Stumbling Warnings (18:6-9):**
**The Key Verses (18:6-9):**
"''Whoso shall cause one of these little ones that believe on me to stumble.''"

*Hos d' an skandalisē hena tōn mikrōn toutōn tōn pisteuontōn eis eme*—cause stumbling.

"''It is profitable for him that a great millstone should be hanged about his neck.''"

*Sympherei autō hina kremasthē mylos onikos peri ton trachēlon autou*—millstone.

**Mylos Onikos:**
Millstone turned by a donkey—large, heavy.

"''Sunk in the depth of the sea.''"

*Kai katapontisthē en tō pelagei tēs thalassēs*—drowned.

"''Woe unto the world because of occasions of stumbling!''"

*Ouai tō kosmō apo tōn skandalōn*—woe.

"''It must needs be that the occasions come.''"

*Anankē gar elthein ta skandala*—must come.

"''Woe to that man through whom the occasion comes!''"

*Plēn ouai tō anthrōpō di' hou to skandalon erchetai*—woe to that man.

"''If your hand or your foot causes you to stumble, cut it off.''"

*Ei de hē cheir sou ē ho pous sou skandalizei se ekkopson auton*—cut off.

"''It is good for you to enter into life maimed.''"

*Kalon soi estin eiselthein eis tēn zōēn kyllon ē chōlon*—enter maimed.

**Lost Sheep (18:10-14):**
**The Key Verses (18:10-14):**
"''See that you despise not one of these little ones.''"

*Horate mē kataphronēsēte henos tōn mikrōn toutōn*—don't despise.

"''In heaven their angels do always behold the face of my Father.''"

*Hoi angeloi autōn en ouranois dia pantos blepousin to prosōpon tou patros mou*—guardian angels.

"''If any man have a hundred sheep, and one of them be gone astray.''"

*Ean genētai tini anthrōpō hekaton probata kai planēthē hen ex autōn*—one lost.

"''Does he not leave the ninety and nine, and go unto the mountains, and seek that which goes astray?''"

*Ouchi apheis ta enenēkonta ennea epi ta orē poreueis zētei to planōmenon*—seek.

"''If so be that he find it... he rejoices over it more than over the ninety and nine.''"

*Kai ean genētai heurein auto... chairei ep' autō mallon ē epi tois enenēkonta ennea*—rejoices.

"''It is not the will of your Father who is in heaven, that one of these little ones should perish.''"

*Houtōs ouk estin thelēma emprosthen tou patros hymōn tou en ouranois hina apolētai hen tōn mikrōn toutōn*—Father's will.

**Discipline in the Assembly (18:15-20):**
**The Key Verses (18:15-17):**
"''If your brother sin against you, go, show him his fault between you and him alone.''"

*Ean de hamartēsē eis se ho adelphos sou hypage elengxon auton metaxy sou kai autou monou*—private.

"''If he hear you, you have gained your brother.''"

*Ean sou akousē ekerdēsas ton adelphon sou*—gained.

"''Take with you one or two more, that at the mouth of two witnesses or three every word may be established.''"

*Paralabe met' sou eti hena ē dyo hina epi stomatos dyo martyrōn ē triōn stathē pan rhēma*—witnesses.

**Deuteronomy 19:15.**

"''Tell it unto the assembly.''"

*Eipe tē ekklēsia*—assembly.

"''If he refuse to hear the assembly also, let him be unto you as the Gentile and the publican.''"

*Ean de kai tēs ekklēsias parakousē estō soi hōsper ho ethnikos kai ho telōnēs*—outsider.

**The Key Verses (18:18-20):**
"''What things soever you shall bind on earth shall be bound in heaven.''"

*Hosa ean dēsēte epi tēs gēs estai dedemena en ouranō*—bind.

"''What things soever you shall loose on earth shall be loosed in heaven.''"

*Kai hosa ean lysēte epi tēs gēs estai lelymena en ouranō*—loose.

"''If two of you shall agree on earth as touching anything that they shall ask.''"

*Ean dyo symphōnēsōsin ex hymōn epi tēs gēs peri pantos pragmatos hou ean aitēsōntai*—agree.

"''It shall be done for them of my Father who is in heaven.''"

*Genēsetai autois para tou patros mou tou en ouranois*—done.

"''Where two or three are gathered together in my name, there am I in the midst of them.''"

*Hou gar eisin dyo ē treis synēgmenoi eis to emon onoma ekei eimi en mesō autōn*—in the midst.

**Unforgiving Servant (18:21-35):**
**The Key Verses (18:21-27):**
"''How oft shall my brother sin against me, and I forgive him? Until seven times?''"

*Posakis hamartēsei eis eme ho adelphos mou kai aphēsō autō heōs heptakis*—seven times?

"''Until seventy times seven.''"

*Heōs hebdomēkontakis hepta*—seventy times seven.

**490 Times:**
Essentially unlimited forgiveness.

"''The kingdom of heaven likened unto a certain king, who would make a reckoning with his servants.''"

*Hōmoiōthē hē basileia tōn ouranōn anthrōpō basilei hos ēthelēsen synarai logon meta tōn doulōn autou*—reckoning.

"''One was brought unto him, that owed him ten thousand talents.''"

*Prosēnechthē autō heis opheiletēs myriōn talantōn*—10,000 talents.

**Ten Thousand Talents:**
Astronomical debt—millions of denarii; unpayable.

"''His lord... being moved with compassion, released him, and forgave him the debt.''"

*Splanchnistheis de ho kyrios tou doulou ekeinou apelysen auton kai to daneion aphēken autō*—forgave.

**The Key Verses (18:28-35):**
"''That servant went out, and found one of his fellow-servants, who owed him a hundred pence.''"

*Exelthōn de ho doulos ekeinos heuren hena tōn syndoulōn autou hos ōpheilen autō hekaton dēnaria*—100 denarii.

**100 Denarii:**
About 3 months' wages—trivial compared to 10,000 talents.

"''He laid hold on him, and took him by the throat, saying: Pay what you owe.''"

*Kai kratēsas auton epnigen legōn apodos ei ti opheileis*—choked him.

"''He would not: but went and cast him into prison.''"

*Ho de ouk ēthelen alla apelthōn ebalen auton eis phylakēn*—prison.

"''You wicked servant, I forgave you all that debt, because you begged me.''"

*Doule ponēre pasan tēn opheilēn ekeinēn aphēka soi epei parekalesas me*—wicked servant.

"''Should you not also have had mercy on your fellow-servant, even as I had mercy on you?''"

*Ouk edei kai se eleēsai ton syndoulon sou hōs kagō se ēleēsa*—should have mercy.

"''His lord was angry, and delivered him to the tormentors.''"

*Kai orgistheis ho kyrios autou paredōken auton tois basanistais*—tormentors.

"''So shall also my heavenly Father do unto you, if you forgive not every one his brother from your hearts.''"

*Houtōs kai ho patēr mou ho ouranios poiēsei hymin ean mē aphēte hekastos tō adelphō autou apo tōn kardiōn hymōn*—from hearts.

**Archetypal Layer:** Matthew 18 is the **community discourse**, containing **"Who then is greatest in the kingdom of heaven?" (18:1)**, **"Except you turn, and become as little children" (18:3)**, **"Whosoever therefore shall humble himself as this little child, the same is the greatest" (18:4)**, **millstone warning for causing little ones to stumble (18:6)**, **"Woe unto the world because of occasions of stumbling!" (18:7)**, **"in heaven their angels do always behold the face of my Father" (18:10)**, **parable of the lost sheep (18:12-14)**, **"It is not the will of your Father... that one of these little ones should perish" (18:14)**, **discipline process: private, witnesses, assembly (18:15-17)**, **"Where two or three are gathered together in my name, there am I in the midst of them" (18:20)**, **"how oft shall my brother sin against me, and I forgive him? Until seven times?" (18:21)**, **"Until seventy times seven" (18:22)**, **parable of the unforgiving servant: 10,000 talents vs. 100 denarii (18:23-35)**, and **"if you forgive not every one his brother from your hearts" (18:35)**.

**Modern Equivalent:** Matthew 18 addresses community life. Greatness is measured by child-like humility (18:3-4). Causing believers to stumble warrants severe judgment (18:6-7). The lost sheep parable (18:12-14) shows God's concern for each one. Discipline follows progressive steps (18:15-17) with heavenly authority (18:18). Two or three gathered in Yeshua's name have His presence (18:20). Forgiveness is unlimited (18:22)—the parable of the unforgiving servant (18:23-35) contrasts our massive debt forgiven by God with our refusal to forgive others' minor offenses. Unforgiveness revokes received mercy.

# Matthew 8: Healings and the Cost of Discipleship

*From the Greek: Καταβάντος δὲ αὐτοῦ ἀπὸ τοῦ ὄρους (Katabantos de Autou apo tou Orous) — And When He Was Come Down from the Mountain*

---

## The Leper Cleansed (8:1-4)

**8:1** And when he was come down from the mountain, great multitudes followed him.

**8:2** And behold, there came to him a leper and worshipped him, saying: "Lord, if you will, you can make me clean."

**8:3** And he stretched forth his hand, and touched him, saying: "I will; be made clean." And straightway his leprosy was cleansed.

**8:4** And Yeshua says unto him: "See you tell no man; but go, show yourself to the priest, and offer the gift that Moses commanded, for a testimony unto them."

---

## The Centurion's Servant (8:5-13)

**8:5** And when he was entered into Capernaum, there came unto him a centurion, beseeching him,

**8:6** And saying: "Lord, my servant lies in the house sick of the palsy, grievously tormented."

**8:7** And he says unto him: "I will come and heal him."

**8:8** And the centurion answered and said: "Lord, I am not worthy that you should come under my roof; but only say the word, and my servant shall be healed.

**8:9** "For I also am a man under authority, having under myself soldiers: and I say to this one, 'Go,' and he goes; and to another, 'Come,' and he comes; and to my servant, 'Do this,' and he does it."

**8:10** And when Yeshua heard it, he marvelled, and said to them that followed: "Verily I say unto you, I have not found so great faith, no, not in Israel.

**8:11** "And I say unto you, that many shall come from the east and the west, and shall sit down with Abraham, and Isaac, and Jacob, in the kingdom of heaven:

**8:12** "But the sons of the kingdom shall be cast forth into the outer darkness: there shall be the weeping and the gnashing of teeth."

**8:13** And Yeshua said unto the centurion: "Go your way; as you have believed, so be it done unto you." And the servant was healed in that hour.

---

## Peter's Mother-in-Law and Many Healed (8:14-17)

**8:14** And when Yeshua was come into Peter's house, he saw his wife's mother lying sick of a fever.

**8:15** And he touched her hand, and the fever left her; and she arose, and ministered unto him.

**8:16** And when even was come, they brought unto him many possessed with demons: and he cast out the spirits with a word, and healed all that were sick:

**8:17** That it might be fulfilled which was spoken through Isaiah the prophet, saying: "Himself took our infirmities, and bare our diseases."

---

## The Cost of Following Yeshua (8:18-22)

**8:18** Now when Yeshua saw great multitudes about him, he gave commandment to depart unto the other side.

**8:19** And there came a scribe, and said unto him: "Teacher, I will follow you whithersoever you go."

**8:20** And Yeshua says unto him: "The foxes have holes, and the birds of the heaven have nests; but the Son of man has not where to lay his head."

**8:21** And another of the disciples said unto him: "Lord, permit me first to go and bury my father."

**8:22** But Yeshua says unto him: "Follow me; and leave the dead to bury their own dead."

---

## Stilling the Storm (8:23-27)

**8:23** And when he was entered into a boat, his disciples followed him.

**8:24** And behold, there arose a great tempest in the sea, insomuch that the boat was covered with the waves: but he was asleep.

**8:25** And they came to him, and awoke him, saying: "Save, Lord; we perish."

**8:26** And he says unto them: "Why are you fearful, O you of little faith?" Then he arose, and rebuked the winds and the sea; and there was a great calm.

**8:27** And the men marvelled, saying: "What manner of man is this, that even the winds and the sea obey him?"

---

## The Gadarene Demoniacs (8:28-34)

**8:28** And when he was come to the other side into the country of the Gadarenes, there met him two possessed with demons, coming forth out of the tombs, exceeding fierce, so that no man could pass by that way.

**8:29** And behold, they cried out, saying: "What have we to do with you, Son of God? Have you come here to torment us before the time?"

**8:30** Now there was afar off from them a herd of many swine feeding.

**8:31** And the demons besought him, saying: "If you cast us out, send us away into the herd of swine."

**8:32** And he said unto them: "Go." And they came out, and went into the swine: and behold, the whole herd rushed down the steep into the sea, and perished in the waters.

**8:33** And they that fed them fled, and went away into the city, and told everything, and what was befallen to them that were possessed with demons.

**8:34** And behold, all the city came out to meet Yeshua: and when they saw him, they besought him that he would depart from their borders.

---

## Synthesis Notes

**Key Restorations:**

**The Leper Cleansed (8:1-4):**
**The Key Verses (8:1-4):**
"'When he was come down from the mountain, great multitudes followed him.'"

*Katabantos de autou apo tou orous ēkolouthēsan autō ochloi polloi*—multitudes.

"'There came to him a leper and worshipped him.'"

*Kai idou lepros proselthōn prosekunei autō*—leper.

"''Lord, if you will, you can make me clean.''"

*Kyrie ean thelēs dynasai me katharisai*—if you will.

"'He stretched forth his hand, and touched him.'"

*Kai ekteinas tēn cheira hēpsato autou*—touched.

**Touched Leper:**
Levitically defiling; Yeshua reverses the flow—purity spreads.

"''I will; be made clean.''"

*Thelō katharisthēti*—I will.

"'Straightway his leprosy was cleansed.'"

*Kai eutheōs ekatharisthē autou hē lepra*—cleansed.

"''Show yourself to the priest, and offer the gift that Moses commanded.''"

*Deixon seauton tō hierei kai prosenenkon to dōron ho prosetaxen Mōusēs*—Moses commanded.

**Leviticus 14:**
Priestly verification and offerings.

**The Centurion's Servant (8:5-13):**
**The Key Verses (8:5-9):**
"'There came unto him a centurion.'"

*Prosēlthen autō hekatontarchos*—centurion.

**Hekatontarchos:**
Commander of 100 soldiers—Roman Gentile.

"''My servant lies in the house sick of the palsy, grievously tormented.''"

*Ho pais mou beblētai en tē oikia paralytikos deinōs basanizomenos*—paralyzed.

"''I am not worthy that you should come under my roof.''"

*Kyrie ouk eimi hikanos hina mou hypo tēn stegēn eiselthēs*—not worthy.

"''Only say the word, and my servant shall be healed.''"

*Alla monon eipe logō kai iathēsetai ho pais mou*—just speak.

"''I also am a man under authority, having under myself soldiers.''"

*Kai gar egō anthrōpos eimi hypo exousian echōn hyp' emauton stratiōtas*—authority.

**The Key Verses (8:10-13):**
"'Yeshua heard it, he marvelled.'"

*Akousas de ho Iēsous ethaumasen*—marvelled.

"''I have not found so great faith, no, not in Israel.''"

*Par' oudeni tosautēn pistin en tō Israēl heuron*—greatest faith.

"''Many shall come from the east and the west.''"

*Polloi apo anatolōn kai dysmōn hēxousin*—east, west.

"''Shall sit down with Abraham, and Isaac, and Jacob, in the kingdom of heaven.''"

*Kai anaklithēsontai meta Abraam kai Isaak kai Iakōb en tē basileia tōn ouranōn*—patriarchs.

"''The sons of the kingdom shall be cast forth into the outer darkness.''"

*Hoi de huioi tēs basileias ekblēthēsontai eis to skotos to exōteron*—cast out.

"''There shall be the weeping and the gnashing of teeth.''"

*Ekei estai ho klauthmοs kai ho brygmos tōn odontōn*—weeping.

"''As you have believed, so be it done unto you.''"

*Hōs episteusas genēthētō soi*—as believed.

"'The servant was healed in that hour.'"

*Kai iathē ho pais autou en tē hōra ekeinē*—healed.

**Peter's Mother-in-Law (8:14-17):**
**The Key Verses (8:14-17):**
"'Yeshua was come into Peter's house.'"

*Kai elthōn ho Iēsous eis tēn oikian Petrou*—Peter's house.

"'He saw his wife's mother lying sick of a fever.'"

*Eiden tēn pentheran autou beblēmenēn kai pyressousan*—fever.

"'He touched her hand, and the fever left her.'"

*Kai hēpsato tēs cheiros autēs kai aphēken autēn ho pyretos*—touched.

"'She arose, and ministered unto him.'"

*Kai ēgerthē kai diēkonei autō*—ministered.

"'They brought unto him many possessed with demons.'"

*Prosēnenkan autō daimonizomenous pollous*—many.

"'He cast out the spirits with a word, and healed all that were sick.'"

*Kai exebalen ta pneumata logō kai pantas tous kakōs echontas etherapeusen*—healed all.

"''Himself took our infirmities, and bare our diseases.''"

*Autos tas astheneias hēmōn elaben kai tas nosous ebastasen*—took, bare.

**Isaiah 53:4:**
Suffering Servant prophecy.

**Cost of Following (8:18-22):**
**The Key Verses (8:18-22):**
"'A scribe... said unto him: Teacher, I will follow you whithersoever you go.'"

*Heis grammateus... eipen autō didaskale akolouthēsō soi hopou ean aperchē*—follow anywhere.

"''The foxes have holes, and the birds of the heaven have nests.''"

*Hai alōpekes phōleous echousin kai ta peteina tou ouranou kataskēnōseis*—foxes, birds.

"''But the Son of man has not where to lay his head.''"

*Ho de huios tou anthrōpou ouk echei pou tēn kephalēn klinē*—no home.

**Son of Man:**
Yeshua's favorite self-designation; from Daniel 7:13.

"''Lord, permit me first to go and bury my father.''"

*Kyrie epitrepson moi prōton apelthein kai thapsai ton patera mou*—bury father.

"''Follow me; and leave the dead to bury their own dead.''"

*Akolouthei moi kai aphes tous nekrous thapsai tous heautōn nekrous*—let dead bury dead.

**Stilling the Storm (8:23-27):**
**The Key Verses (8:23-27):**
"'There arose a great tempest in the sea.'"

*Kai idou seismos megas egeneto en tē thalassē*—great tempest.

"'The boat was covered with the waves: but he was asleep.'"

*Hōste to ploion kalyptesthai hypo tōn kymatōn autos de ekatheuden*—asleep.

"''Save, Lord; we perish.''"

*Kyrie sōson apollymetha*—save.

"''Why are you fearful, O you of little faith?''"

*Ti deiloi este oligopistoi*—little faith.

"'He arose, and rebuked the winds and the sea.'"

*Tote egertheis epetimēsen tois anemois kai tē thalassē*—rebuked.

"'There was a great calm.'"

*Kai egeneto galēnē megalē*—great calm.

"''What manner of man is this, that even the winds and the sea obey him?''"

*Potapos estin houtos hoti kai hoi anemoi kai hē thalassa autō hypakouousin*—what manner.

**Gadarene Demoniacs (8:28-34):**
**The Key Verses (8:28-34):**
"'Two possessed with demons, coming forth out of the tombs.'"

*Duo daimonizomenoi ek tōn mnēmeiōn exerchomenoi*—two demoniacs.

"'Exceeding fierce, so that no man could pass by that way.'"

*Chalepoi lian hōste mē ischyein tina parelthein dia tēs hodou ekeinēs*—fierce.

"''What have we to do with you, Son of God?''"

*Ti hēmin kai soi huie tou theou*—Son of God.

"''Have you come here to torment us before the time?''"

*Ēlthes hōde pro kairou basanisai hēmas*—before time.

"''If you cast us out, send us away into the herd of swine.''"

*Ei ekballeis hēmas aposteilon hēmas eis tēn agelēn tōn choirōn*—swine.

"''Go.''"

*Hypagete*—go.

"'The whole herd rushed down the steep into the sea.'"

*Kai idou hōrmēsen pasa hē agelē kata tou krēmnou eis tēn thalassan*—rushed.

"'They besought him that he would depart from their borders.'"

*Parekaloun hopōs metabē apo tōn horiōn autōn*—depart.

**Archetypal Layer:** Matthew 8 contains **the leper cleansed (8:1-4)**, **"I will; be made clean" (8:3)**, **the centurion's faith (8:5-13)**, **"I have not found so great faith, no, not in Israel" (8:10)**, **"many shall come from the east and the west, and shall sit down with Abraham" (8:11)**, **Isaiah 53:4 fulfilled: "Himself took our infirmities, and bare our diseases" (8:17)**, **"The foxes have holes... but the Son of man has not where to lay his head" (8:20)**, **"Follow me; and leave the dead to bury their own dead" (8:22)**, **stilling the storm (8:23-27)**, **"What manner of man is this, that even the winds and the sea obey him?" (8:27)**, **the Gadarene demoniacs (8:28-34)**, and **"What have we to do with you, Son of God? Have you come here to torment us before the time?" (8:29)**.

**Modern Equivalent:** Matthew 8 groups miracle stories showing Yeshua's authority over disease, nature, and demons. The leper's cleansing reverses ritual impurity. The centurion's faith exceeds Israel's—Gentile inclusion is announced (8:11). Isaiah 53:4 is applied to healing ministry (8:17). The cost of discipleship: homelessness and urgency that supersedes family duty (8:20-22). Power over storm (8:26) and demons (8:32) reveals divine authority. Even demons recognize "Son of God" and the coming judgment (8:29).

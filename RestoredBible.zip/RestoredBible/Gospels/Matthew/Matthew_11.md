# Matthew 11: John's Question and Yeshua's Invitation

*From the Greek: Καὶ ἐγένετο ὅτε ἐτέλεσεν ὁ Ἰησοῦς (Kai Egeneto Hote Etelesen ho Iesous) — And It Came to Pass When Yeshua Had Finished*

---

## John's Question (11:1-6)

**11:1** And it came to pass when Yeshua had finished commanding his twelve disciples, he departed thence to teach and proclaim in their cities.

**11:2** Now when John heard in the prison the works of the Anointed, he sent by his disciples

**11:3** And said unto him: "Are you he that comes, or look we for another?"

**11:4** And Yeshua answered and said unto them: "Go and tell John the things which you hear and see:

**11:5** "The blind receive their sight, and the lame walk, the lepers are cleansed, and the deaf hear, and the dead are raised up, and the poor have good tidings preached to them.

**11:6** "And blessed is he, whosoever shall find no occasion of stumbling in me."

---

## Yeshua's Testimony about John (11:7-19)

**11:7** And as these went their way, Yeshua began to say unto the multitudes concerning John: "What went you out into the wilderness to behold? A reed shaken with the wind?

**11:8** "But what went you out to see? A man clothed in soft raiment? Behold, they that wear soft raiment are in kings' houses.

**11:9** "But what went you out to see? A prophet? Yea, I say unto you, and much more than a prophet.

**11:10** "This is he, of whom it is written: 'Behold, I send my messenger before your face, who shall prepare your way before you.'

**11:11** "Verily I say unto you, Among them that are born of women there has not arisen a greater than John the Immerser: yet he that is but little in the kingdom of heaven is greater than he.

**11:12** "And from the days of John the Immerser until now the kingdom of heaven suffers violence, and men of violence take it by force.

**11:13** "For all the prophets and the law prophesied until John.

**11:14** "And if you are willing to receive it, this is Elijah, that is to come.

**11:15** "He that has ears to hear, let him hear.

**11:16** "But whereunto shall I liken this generation? It is like unto children sitting in the marketplaces, who call unto their fellows

**11:17** "And say: 'We piped unto you, and you did not dance; we wailed, and you did not mourn.'

**11:18** "For John came neither eating nor drinking, and they say: 'He has a demon.'

**11:19** "The Son of man came eating and drinking, and they say: 'Behold, a gluttonous man and a winebibber, a friend of publicans and sinners!' And wisdom is justified by her works."

---

## Woes on Unrepentant Cities (11:20-24)

**11:20** Then began he to upbraid the cities wherein most of his mighty works were done, because they repented not.

**11:21** "Woe unto you, Chorazin! Woe unto you, Bethsaida! For if the mighty works had been done in Tyre and Sidon which were done in you, they would have repented long ago in sackcloth and ashes.

**11:22** "But I say unto you, it shall be more tolerable for Tyre and Sidon in the day of judgment than for you.

**11:23** "And you, Capernaum, shall you be exalted unto heaven? You shall go down unto Hades: for if the mighty works had been done in Sodom which were done in you, it would have remained until this day.

**11:24** "But I say unto you that it shall be more tolerable for the land of Sodom in the day of judgment, than for you."

---

## Come unto Me (11:25-30)

**11:25** At that season Yeshua answered and said: "I thank you, O Father, Lord of heaven and earth, that you did hide these things from the wise and understanding, and did reveal them unto babes:

**11:26** "Yea, Father, for so it was well-pleasing in your sight.

**11:27** "All things have been delivered unto me of my Father: and no one knows the Son, save the Father; neither does any know the Father, save the Son, and he to whomsoever the Son wills to reveal him.

**11:28** "Come unto me, all you that labour and are heavy laden, and I will give you rest.

**11:29** "Take my yoke upon you, and learn of me; for I am meek and lowly in heart: and you shall find rest unto your souls.

**11:30** "For my yoke is easy, and my burden is light."

---

## Synthesis Notes

**Key Restorations:**

**John's Question (11:1-6):**
**The Key Verses (11:1-6):**
"'When John heard in the prison the works of the Anointed.'"

*Ho de Iōannēs akousas en tō desmōtēriō ta erga tou Christou*—in prison.

"''Are you he that comes, or look we for another?''"

*Sy ei ho erchomenos ē heteron prosdokōmen*—the Coming One.

**Ho Erchomenos:**
"The Coming One"—messianic title.

"''Go and tell John the things which you hear and see.''"

*Poreuthentes apangeilate Iōannē ha akouete kai blepete*—report.

"''The blind receive their sight, and the lame walk.''"

*Typhloi anablepousin kai chōloi peripatousin*—blind, lame.

"''The lepers are cleansed, and the deaf hear.''"

*Leproi katharizontai kai kōphoi akouousin*—lepers, deaf.

"''The dead are raised up, and the poor have good tidings preached to them.''"

*Nekroi egeirontai kai ptōchoi euangelizontai*—dead, poor.

**Isaiah 35:5-6, 61:1:**
Messianic signs.

"''Blessed is he, whosoever shall find no occasion of stumbling in me.''"

*Makarios estin hos ean mē skandalisthē en emoi*—not stumble.

**Testimony about John (11:7-19):**
**The Key Verses (11:7-15):**
"''What went you out into the wilderness to behold? A reed shaken with the wind?''"

*Ti exēlthate eis tēn erēmon theasasthai kalamon hypo anemou saleuomenon*—reed?

"''A man clothed in soft raiment?''"

*Anthrōpon en malakois ēmphiesmenon*—soft clothing?

"''A prophet? Yea... and much more than a prophet.''"

*Prophētēn nai legō hymin kai perissoteron prophētou*—more than prophet.

"''Behold, I send my messenger before your face.''"

*Idou egō apostellō ton angelon mou pro prosōpou sou*—messenger.

**Malachi 3:1.**

"''Among them that are born of women there has not arisen a greater than John.''"

*Ouk egēgertai en gennētois gynaikōn meizōn Iōannou tou baptistou*—greatest.

"''Yet he that is but little in the kingdom of heaven is greater than he.''"

*Ho de mikroteros en tē basileia tōn ouranōn meizōn autou estin*—least greater.

"''The kingdom of heaven suffers violence, and men of violence take it by force.''"

*Hē basileia tōn ouranōn biazetai kai biastai harpazousin autēn*—violence.

"''This is Elijah, that is to come.''"

*Autos estin Ēlias ho mellōn erchesthai*—Elijah.

**Malachi 4:5.**

"''He that has ears to hear, let him hear.''"

*Ho echōn ōta akouein akouetō*—ears to hear.

**The Key Verses (11:16-19):**
"''It is like unto children sitting in the marketplaces.''"

*Homoia estin paidiois kathēmenois en tais agorais*—children.

"''We piped unto you, and you did not dance.''"

*Ēulēsamen hymin kai ouk ōrchēsasthe*—didn't dance.

"''We wailed, and you did not mourn.''"

*Ethrēnēsamen kai ouk ekopsasthe*—didn't mourn.

"''John came neither eating nor drinking, and they say: He has a demon.''"

*Ēlthen gar Iōannēs mēte esthiōn mēte pinōn kai legousin daimonion echei*—demon.

"''The Son of man came eating and drinking, and they say: Behold, a gluttonous man and a winebibber.''"

*Ēlthen ho huios tou anthrōpou esthiōn kai pinōn kai legousin idou anthrōpos phagos kai oinopotēs*—gluttonous.

"''A friend of publicans and sinners!''"

*Telōnōn philos kai hamartōlōn*—friend of sinners.

"''Wisdom is justified by her works.''"

*Kai edikaiōthē hē sophia apo tōn ergōn autēs*—wisdom justified.

**Woes on Cities (11:20-24):**
**The Key Verses (11:20-24):**
"'He began to upbraid the cities wherein most of his mighty works were done.'"

*Tote ērxato oneidizein tas poleis en hais egenonto hai pleistai dynameis autou*—upbraid.

"''Woe unto you, Chorazin! Woe unto you, Bethsaida!''"

*Ouai soi Chorazin ouai soi Bēthsaida*—woe.

"''If the mighty works had been done in Tyre and Sidon... they would have repented.''"

*Ei en Tyrō kai Sidōni egenonto hai dynameis... palai an en sakkō kai spodō metenoēsan*—Tyre, Sidon.

"''You, Capernaum, shall you be exalted unto heaven? You shall go down unto Hades.''"

*Kai sy Kapharnaoum mē heōs ouranou hypsōthēsē heōs hadou katabēsē*—Hades.

"''If the mighty works had been done in Sodom... it would have remained.''"

*Ei en Sodomois egenēthēsan hai dynameis... emeinen an mechri tēs sēmeron*—Sodom.

**Come unto Me (11:25-30):**
**The Key Verses (11:25-27):**
"''I thank you, O Father, Lord of heaven and earth.''"

*Exomologoumai soi pater kyrie tou ouranou kai tēs gēs*—thank Father.

"''You did hide these things from the wise and understanding.''"

*Hoti ekrypsas tauta apo sophōn kai synetōn*—hidden from wise.

"''Did reveal them unto babes.''"

*Kai apekalypsas auta nēpiois*—revealed to babes.

"''All things have been delivered unto me of my Father.''"

*Panta moi paredothē hypo tou patros mou*—all delivered.

"''No one knows the Son, save the Father.''"

*Kai oudeis epiginōskei ton huion ei mē ho patēr*—knows Son.

"''Neither does any know the Father, save the Son.''"

*Oude ton patera tis epiginōskei ei mē ho huios*—knows Father.

"''And he to whomsoever the Son wills to reveal him.''"

*Kai hō ean boulētai ho huios apokalypsai*—Son reveals.

**The Key Verses (11:28-30):**
"''Come unto me, all you that labour and are heavy laden.''"

*Deute pros me pantes hoi kopiōntes kai pephortismenoi*—come.

"''I will give you rest.''"

*Kagō anapausō hymas*—rest.

"''Take my yoke upon you, and learn of me.''"

*Arate ton zygon mou eph' hymas kai mathete ap' emou*—yoke.

"''I am meek and lowly in heart.''"

*Hoti praus eimi kai tapeinos tē kardia*—meek, lowly.

"''You shall find rest unto your souls.''"

*Kai heurēsete anapausin tais psychais hymōn*—rest for souls.

**Jeremiah 6:16.**

"''My yoke is easy, and my burden is light.''"

*Ho gar zygos mou chrēstos kai to phortion mou elaphron estin*—easy, light.

**Archetypal Layer:** Matthew 11 contains **John's question from prison: "Are you he that comes?" (11:3)**, **Yeshua's answer: messianic signs from Isaiah 35, 61 (11:5)**, **"blessed is he, whosoever shall find no occasion of stumbling in me" (11:6)**, **"Among them that are born of women there has not arisen a greater than John... yet he that is but little in the kingdom of heaven is greater than he" (11:11)**, **"this is Elijah, that is to come" (11:14)**, **"a friend of publicans and sinners" (11:19)**, **woes on Chorazin, Bethsaida, Capernaum (11:20-24)**, **"you did hide these things from the wise... and did reveal them unto babes" (11:25)**, **"no one knows the Son, save the Father; neither does any know the Father, save the Son" (11:27)**, and **"Come unto me, all you that labour and are heavy laden, and I will give you rest" (11:28-30)**.

**Modern Equivalent:** Matthew 11 addresses John's doubt with deeds, not claims (11:4-5). John is greatest of the old era, but the least in the kingdom surpasses him (11:11). "This is Elijah" (11:14) identifies John with Malachi's prophecy. The generation is compared to petulant children—rejecting both John's asceticism and Yeshua's feasting (11:16-19). The woes on Galilean cities (11:20-24) show privilege brings greater accountability. The chapter climaxes with the tender invitation: "Come unto me... I will give you rest" (11:28-30)—Yeshua's yoke replaces burdensome religion.

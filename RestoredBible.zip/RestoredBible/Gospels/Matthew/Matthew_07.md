# Matthew 7: The Sermon on the Mount — Judgment, Prayer, and the Two Ways

*From the Greek: Μὴ κρίνετε, ἵνα μὴ κριθῆτε (Mē Krinete, Hina Mē Krithēte) — Judge Not, That You Be Not Judged*

---

## Judging Others (7:1-6)

**7:1** "Judge not, that you be not judged.

**7:2** "For with what judgment you judge, you shall be judged: and with what measure you mete, it shall be measured unto you.

**7:3** "And why behold the mote that is in your brother's eye, but consider not the beam that is in your own eye?

**7:4** "Or how will you say to your brother, 'Let me cast out the mote out of your eye'; and lo, the beam is in your own eye?

**7:5** "You hypocrite, cast out first the beam out of your own eye; and then shall you see clearly to cast out the mote out of your brother's eye.

**7:6** "Give not that which is holy unto the dogs, neither cast your pearls before the swine, lest haply they trample them under their feet, and turn and rend you."

---

## Ask, Seek, Knock (7:7-12)

**7:7** "Ask, and it shall be given you; seek, and you shall find; knock, and it shall be opened unto you:

**7:8** "For every one that asks receives; and he that seeks finds; and to him that knocks it shall be opened.

**7:9** "Or what man is there of you, who, if his son shall ask him for a loaf, will give him a stone;

**7:10** "Or if he shall ask for a fish, will give him a serpent?

**7:11** "If you then, being evil, know how to give good gifts unto your children, how much more shall your Father who is in heaven give good things to them that ask him?

**7:12** "All things therefore whatsoever you would that men should do unto you, even so do also unto them: for this is the law and the prophets."

---

## The Two Ways (7:13-14)

**7:13** "Enter in by the narrow gate: for wide is the gate, and broad is the way, that leads to destruction, and many are they that enter in thereby.

**7:14** "For narrow is the gate, and straitened the way, that leads unto life, and few are they that find it."

---

## False Prophets and Fruit (7:15-23)

**7:15** "Beware of false prophets, who come to you in sheep's clothing, but inwardly are ravening wolves.

**7:16** "By their fruits you shall know them. Do men gather grapes of thorns, or figs of thistles?

**7:17** "Even so every good tree brings forth good fruit; but the corrupt tree brings forth evil fruit.

**7:18** "A good tree cannot bring forth evil fruit, neither can a corrupt tree bring forth good fruit.

**7:19** "Every tree that brings not forth good fruit is hewn down, and cast into the fire.

**7:20** "Therefore by their fruits you shall know them.

**7:21** "Not every one that says unto me, 'Lord, Lord,' shall enter into the kingdom of heaven; but he that does the will of my Father who is in heaven.

**7:22** "Many will say to me in that day, 'Lord, Lord, did we not prophesy by your name, and by your name cast out demons, and by your name do many mighty works?'

**7:23** "And then will I profess unto them, 'I never knew you: depart from me, you that work iniquity.'"

---

## The Two Builders (7:24-29)

**7:24** "Every one therefore that hears these words of mine, and does them, shall be likened unto a wise man, who built his house upon the rock:

**7:25** "And the rain descended, and the floods came, and the winds blew, and beat upon that house; and it fell not: for it was founded upon the rock.

**7:26** "And every one that hears these words of mine, and does them not, shall be likened unto a foolish man, who built his house upon the sand:

**7:27** "And the rain descended, and the floods came, and the winds blew, and smote upon that house; and it fell: and great was the fall thereof."

**7:28** And it came to pass, when Yeshua had finished these words, the multitudes were astonished at his teaching:

**7:29** For he taught them as one having authority, and not as their scribes.

---

## Synthesis Notes

**Key Restorations:**

**Judging Others (7:1-6):**
**The Key Verses (7:1-5):**
"''Judge not, that you be not judged.''"

*Mē krinete hina mē krithēte*—don't judge.

"''With what judgment you judge, you shall be judged.''"

*En hō gar krimati krinete krithēsesthe*—reciprocal judgment.

"''With what measure you mete, it shall be measured unto you.''"

*Kai en hō metrō metreite metrēthēsetai hymin*—measure.

"''Why behold the mote that is in your brother's eye?''"

*Ti de blepeis to karphos to en tō ophthalmō tou adelphou sou*—mote.

**Karphos:**
"Speck/splinter/mote."

"''Consider not the beam that is in your own eye?''"

*Tēn de en tō sō ophthalmō dokon ou katanoeis*—beam.

**Dokos:**
"Log/beam"—vastly larger than speck.

"''You hypocrite, cast out first the beam out of your own eye.''"

*Hypokrita ekbale prōton ek tou ophthalmou sou tēn dokon*—first beam.

**The Key Verse (7:6):**
"''Give not that which is holy unto the dogs.''"

*Mē dōte to hagion tois kysin*—not to dogs.

"''Neither cast your pearls before the swine.''"

*Mēde balēte tous margaritas hymōn emprosthen tōn choirōn*—not pearls to swine.

"''Lest haply they trample them under their feet, and turn and rend you.''"

*Mēpote katapatēsousin autous en tois posin autōn kai straphentes rhēxōsin hymas*—trample, rend.

**Ask, Seek, Knock (7:7-12):**
**The Key Verses (7:7-11):**
"''Ask, and it shall be given you.''"

*Aiteite kai dothēsetai hymin*—ask.

"''Seek, and you shall find.''"

*Zēteite kai heurēsete*—seek.

"''Knock, and it shall be opened unto you.''"

*Krouete kai anoigēsetai hymin*—knock.

**Progressive Intensity:**
Ask, seek, knock—increasing persistence.

"''Every one that asks receives; and he that seeks finds.''"

*Pas gar ho aitōn lambanei kai ho zētōn heuriskei*—receives, finds.

"''What man is there of you, who, if his son shall ask him for a loaf, will give him a stone?''"

*Ē tis estin ex hymōn anthrōpos hon aitēsei ho huios autou arton mē lithon epidōsei autō*—bread, not stone.

"''If he shall ask for a fish, will give him a serpent?''"

*Ē kai ichthyn aitēsei mē ophin epidōsei autō*—fish, not serpent.

"''If you then, being evil, know how to give good gifts unto your children.''"

*Ei oun hymeis ponēroi ontes oidate domata agatha didonai tois teknois hymōn*—evil, good gifts.

"''How much more shall your Father who is in heaven give good things to them that ask him?''"

*Posō mallon ho patēr hymōn ho en tois ouranois dōsei agatha tois aitousin auton*—how much more.

**The Key Verse (7:12):**
"''All things therefore whatsoever you would that men should do unto you, even so do also unto them.''"

*Panta oun hosa ean thelēte hina poiōsin hymin hoi anthrōpoi houtōs kai hymeis poieite autois*—Golden Rule.

"''For this is the law and the prophets.''"

*Houtos gar estin ho nomos kai hoi prophētai*—law and prophets.

**The Two Ways (7:13-14):**
**The Key Verses (7:13-14):**
"''Enter in by the narrow gate.''"

*Eiselthate dia tēs stenēs pylēs*—narrow gate.

"''Wide is the gate, and broad is the way, that leads to destruction.''"

*Hoti plateia hē pylē kai eurychōros hē hodos hē apagousa eis tēn apōleian*—wide, destruction.

"''Many are they that enter in thereby.''"

*Kai polloi eisin hoi eiserchomenoi di' autēs*—many.

"''Narrow is the gate, and straitened the way, that leads unto life.''"

*Hoti stenē hē pylē kai tethlimmenē hē hodos hē apagousa eis tēn zōēn*—narrow, life.

"''Few are they that find it.''"

*Kai oligoi eisin hoi heuriskontes autēn*—few.

**False Prophets and Fruit (7:15-23):**
**The Key Verses (7:15-20):**
"''Beware of false prophets, who come to you in sheep's clothing.''"

*Prosechete apo tōn pseudoprophētōn hoitines erchontai pros hymas en endymasin probatōn*—sheep's clothing.

"''Inwardly are ravening wolves.''"

*Esōthen de eisin lykoi harpages*—wolves.

"''By their fruits you shall know them.''"

*Apo tōn karpōn autōn epignōsesthe autous*—fruits.

"''Do men gather grapes of thorns, or figs of thistles?''"

*Mēti syllegousin apo akanthōn staphylas ē apo tribolōn syka*—grapes, figs.

"''Every good tree brings forth good fruit.''"

*Houtōs pan dendron agathon karpous kalous poiei*—good fruit.

"''A good tree cannot bring forth evil fruit.''"

*Ou dynatai dendron agathon karpous ponērous poiein*—cannot.

"''Every tree that brings not forth good fruit is hewn down, and cast into the fire.''"

*Pan dendron mē poioun karpon kalon ekkoptetai kai eis pyr balletai*—hewn, fire.

**The Key Verses (7:21-23):**
"''Not every one that says unto me, Lord, Lord, shall enter into the kingdom of heaven.''"

*Ou pas ho legōn moi kyrie kyrie eiseleusetai eis tēn basileian tōn ouranōn*—not everyone.

"''But he that does the will of my Father who is in heaven.''"

*All' ho poiōn to thelēma tou patros mou tou en tois ouranois*—does will.

"''Many will say to me in that day, Lord, Lord, did we not prophesy by your name?''"

*Polloi erousin moi en ekeinē tē hēmera kyrie kyrie ou tō sō onomati eprophēteusamen*—many claim.

"''By your name cast out demons, and by your name do many mighty works?''"

*Kai tō sō onomati daimonia exebalomen kai tō sō onomati dynameis pollas epoiēsamen*—miracles.

"''I never knew you: depart from me, you that work iniquity.''"

*Kai tote homologēsō autois hoti oudepote egnōn hymas apochōreite ap' emou hoi ergazomenoi tēn anomian*—never knew.

**Anomia:**
"Lawlessness/iniquity."

**The Two Builders (7:24-29):**
**The Key Verses (7:24-29):**
"''Every one therefore that hears these words of mine, and does them.''"

*Pas oun hostis akouei mou tous logous toutous kai poiei autous*—hears, does.

"''Shall be likened unto a wise man, who built his house upon the rock.''"

*Homoiōthēsetai andri phronimō hostis ōkodomēsen autou tēn oikian epi tēn petran*—rock.

"''The rain descended, and the floods came, and the winds blew.''"

*Kai katebē hē brochē kai ēlthon hoi potamoi kai epneusan hoi anemoi*—rain, floods, winds.

"''It fell not: for it was founded upon the rock.''"

*Kai ouk epesen tethemeliōto gar epi tēn petran*—founded.

"''Every one that hears these words of mine, and does them not.''"

*Kai pas ho akouōn mou tous logous toutous kai mē poiōn autous*—hears, not does.

"''Shall be likened unto a foolish man, who built his house upon the sand.''"

*Homoiōthēsetai andri mōrō hostis ōkodomēsen autou tēn oikian epi tēn ammon*—sand.

"''It fell: and great was the fall thereof.''"

*Kai epesen kai ēn hē ptōsis autēs megalē*—great fall.

"'The multitudes were astonished at his teaching.'"

*Exeplēssonto hoi ochloi epi tē didachē autou*—astonished.

"'He taught them as one having authority, and not as their scribes.'"

*Ēn gar didaskōn autous hōs exousian echōn kai ouch hōs hoi grammateis autōn*—authority.

**Archetypal Layer:** Matthew 7 concludes the Sermon on the Mount with **"Judge not, that you be not judged" (7:1)**, **mote and beam (7:3-5)**, **"Give not that which is holy unto the dogs, neither cast your pearls before the swine" (7:6)**, **"Ask, and it shall be given you; seek, and you shall find; knock, and it shall be opened unto you" (7:7)**, **the Golden Rule: "All things therefore whatsoever you would that men should do unto you, even so do also unto them: for this is the law and the prophets" (7:12)**, **the narrow and wide gates (7:13-14)**, **"Beware of false prophets, who come to you in sheep's clothing, but inwardly are ravening wolves" (7:15)**, **"By their fruits you shall know them" (7:16)**, **"Not every one that says unto me, Lord, Lord, shall enter into the kingdom of heaven" (7:21)**, **"I never knew you: depart from me, you that work iniquity" (7:23)**, **the wise and foolish builders (7:24-27)**, and **"he taught them as one having authority" (7:29)**.

**Modern Equivalent:** Matthew 7 concludes the Sermon on the Mount. "Judge not" (7:1) doesn't forbid discernment but condemns hypocritical, merciless judgment. The Golden Rule (7:12) summarizes "the law and the prophets." The two ways (7:13-14), two trees (7:17-18), two claims (7:21-23), and two builders (7:24-27) all stress that hearing without doing is worthless. "I never knew you" (7:23) is the most sobering warning: religious activity without relationship fails. The crowds recognize Yeshua's unique authority (7:29).

# Matthew 12: Lord of the Sabbath and the Unforgivable Sin

*From the Greek: Ἐν ἐκείνῳ τῷ καιρῷ (En Ekeinō tō Kairō) — At That Season*

---

## Lord of the Sabbath (12:1-14)

**12:1** At that season Yeshua went on the sabbath day through the grain fields; and his disciples were hungry and began to pluck ears and to eat.

**12:2** But the Pharisees, when they saw it, said unto him: "Behold, your disciples do that which it is not lawful to do upon the sabbath."

**12:3** But he said unto them: "Have you not read what David did, when he was hungry, and they that were with him;

**12:4** "How he entered into the house of God, and ate the showbread, which it was not lawful for him to eat, neither for them that were with him, but only for the priests?

**12:5** "Or have you not read in the law, that on the sabbath day the priests in the temple profane the sabbath, and are guiltless?

**12:6** "But I say unto you, that one greater than the temple is here.

**12:7** "But if you had known what this means, 'I desire mercy, and not sacrifice,' you would not have condemned the guiltless.

**12:8** "For the Son of man is lord of the sabbath."

**12:9** And he departed thence, and went into their synagogue:

**12:10** And behold, a man having a withered hand. And they asked him, saying: "Is it lawful to heal on the sabbath day?" that they might accuse him.

**12:11** And he said unto them: "What man shall there be of you, that shall have one sheep, and if this fall into a pit on the sabbath day, will he not lay hold on it, and lift it out?

**12:12** "How much then is a man of more value than a sheep! Therefore it is lawful to do good on the sabbath day."

**12:13** Then says he to the man: "Stretch forth your hand." And he stretched it forth; and it was restored whole, as the other.

**12:14** But the Pharisees went out, and took counsel against him, how they might destroy him.

---

## The Chosen Servant (12:15-21)

**12:15** And Yeshua perceiving it withdrew from thence: and many followed him; and he healed them all,

**12:16** And charged them that they should not make him known:

**12:17** That it might be fulfilled which was spoken through Isaiah the prophet, saying:

**12:18** "Behold, my servant whom I have chosen; my beloved in whom my soul is well pleased: I will put my Spirit upon him, and he shall declare judgment to the Gentiles.

**12:19** "He shall not strive, nor cry aloud; neither shall any one hear his voice in the streets.

**12:20** "A bruised reed shall he not break, and smoking flax shall he not quench, till he send forth judgment unto victory.

**12:21** "And in his name shall the Gentiles hope."

---

## Beelzebub Controversy (12:22-37)

**12:22** Then was brought unto him one possessed with a demon, blind and dumb: and he healed him, insomuch that the dumb man spoke and saw.

**12:23** And all the multitudes were amazed, and said: "Can this be the son of David?"

**12:24** But when the Pharisees heard it, they said: "This man does not cast out demons, but by Beelzebub the prince of the demons."

**12:25** And knowing their thoughts he said unto them: "Every kingdom divided against itself is brought to desolation; and every city or house divided against itself shall not stand:

**12:26** "And if Satan casts out Satan, he is divided against himself; how then shall his kingdom stand?

**12:27** "And if I by Beelzebub cast out demons, by whom do your sons cast them out? Therefore shall they be your judges.

**12:28** "But if I by the Spirit of God cast out demons, then is the kingdom of God come upon you.

**12:29** "Or how can one enter into the house of the strong man, and spoil his goods, except he first bind the strong man? And then he will spoil his house.

**12:30** "He that is not with me is against me; and he that gathers not with me scatters.

**12:31** "Therefore I say unto you, Every sin and blasphemy shall be forgiven unto men; but the blasphemy against the Spirit shall not be forgiven.

**12:32** "And whosoever shall speak a word against the Son of man, it shall be forgiven him; but whosoever shall speak against the Holy Spirit, it shall not be forgiven him, neither in this world, nor in that which is to come.

**12:33** "Either make the tree good, and its fruit good; or make the tree corrupt, and its fruit corrupt: for the tree is known by its fruit.

**12:34** "You offspring of vipers, how can you, being evil, speak good things? For out of the abundance of the heart the mouth speaks.

**12:35** "The good man out of his good treasure brings forth good things: and the evil man out of his evil treasure brings forth evil things.

**12:36** "And I say unto you, that every idle word that men shall speak, they shall give account thereof in the day of judgment.

**12:37** "For by your words you shall be justified, and by your words you shall be condemned."

---

## The Sign of Jonah (12:38-45)

**12:38** Then certain of the scribes and Pharisees answered him, saying: "Teacher, we would see a sign from you."

**12:39** But he answered and said unto them: "An evil and adulterous generation seeks after a sign; and there shall no sign be given to it but the sign of Jonah the prophet:

**12:40** "For as Jonah was three days and three nights in the belly of the whale; so shall the Son of man be three days and three nights in the heart of the earth.

**12:41** "The men of Nineveh shall stand up in the judgment with this generation, and shall condemn it: for they repented at the preaching of Jonah; and behold, a greater than Jonah is here.

**12:42** "The queen of the south shall rise up in the judgment with this generation, and shall condemn it: for she came from the ends of the earth to hear the wisdom of Solomon; and behold, a greater than Solomon is here.

**12:43** "But the unclean spirit, when he is gone out of the man, passes through waterless places, seeking rest, and finds it not.

**12:44** "Then he says: 'I will return into my house whence I came out'; and when he is come, he finds it empty, swept, and garnished.

**12:45** "Then goes he, and takes with himself seven other spirits more evil than himself, and they enter in and dwell there: and the last state of that man becomes worse than the first. Even so shall it be also unto this evil generation."

---

## Yeshua's True Family (12:46-50)

**12:46** While he was yet speaking to the multitudes, behold, his mother and his brethren stood without, seeking to speak to him.

**12:47** And one said unto him: "Behold, your mother and your brethren stand without, seeking to speak to you."

**12:48** But he answered and said unto him that told him: "Who is my mother? And who are my brethren?"

**12:49** And he stretched forth his hand towards his disciples, and said: "Behold, my mother and my brethren!

**12:50** "For whosoever shall do the will of my Father who is in heaven, he is my brother, and sister, and mother."

---

## Synthesis Notes

**Key Restorations:**

**Lord of the Sabbath (12:1-14):**
**The Key Verses (12:1-8):**
"'His disciples... began to pluck ears and to eat.'"

*Hoi mathētai autou... ērxanto tillein stachyas kai esthiein*—pluck grain.

"''Your disciples do that which it is not lawful to do upon the sabbath.''"

*Hoi mathētai sou poiousin ho ouk exestin poiein en sabbatō*—not lawful.

"''Have you not read what David did?''"

*Ouk anegnōte ti epoiēsen David*—David.

**1 Samuel 21:1-6:**
David ate showbread.

"''The priests in the temple profane the sabbath, and are guiltless?''"

*Hoi hiereis en tō hierō to sabbaton bebēlousin kai anaitioi eisin*—priests work.

"''One greater than the temple is here.''"

*Tou hierou meizon estin hōde*—greater than temple.

"''I desire mercy, and not sacrifice.''"

*Eleos thelō kai ou thysian*—mercy.

**Hosea 6:6—second citation.**

"''The Son of man is lord of the sabbath.''"

*Kyrios gar estin tou sabbatou ho huios tou anthrōpou*—lord of sabbath.

**The Key Verses (12:9-14):**
"''Is it lawful to heal on the sabbath day?''"

*Ei exestin tois sabbasin therapeuein*—heal on sabbath?

"''What man... if this fall into a pit on the sabbath day, will he not lay hold on it?''"

*Tis estai ex hymōn anthrōpos hos hexei probaton hen kai ean empesē touto tois sabbasin eis bothynon ouchi kratēsei auto*—sheep in pit.

"''How much then is a man of more value than a sheep!''"

*Posō oun diapherei anthrōpos probatou*—man more valuable.

"''It is lawful to do good on the sabbath day.''"

*Hōste exestin tois sabbasin kalōs poiein*—lawful to do good.

"'The Pharisees... took counsel against him, how they might destroy him.'"

*Hoi de Pharisaioi... symboulion elabon kat' autou hopōs auton apolesōsin*—destroy him.

**Chosen Servant (12:15-21):**
**The Key Verses (12:15-21):**
"'He healed them all.'"

*Kai etherapeusen autous pantas*—healed all.

"'He charged them that they should not make him known.'"

*Kai epetimēsen autois hina mē phaneron auton poiēsōsin*—not make known.

**Isaiah 42:1-4:**
"''Behold, my servant whom I have chosen.''"

*Idou ho pais mou hon hēretisa*—servant.

"''I will put my Spirit upon him.''"

*Thēsō to pneuma mou ep' auton*—Spirit.

"''He shall not strive, nor cry aloud.''"

*Ouk erisei oude kraugasei*—not strive.

"''A bruised reed shall he not break.''"

*Kalamon syntetrimmenon ou kateaxei*—bruised reed.

"''Smoking flax shall he not quench.''"

*Kai linon typhomenon ou sbesei*—smoking flax.

"''In his name shall the Gentiles hope.''"

*Kai tō onomati autou ethnē elpiousin*—Gentiles hope.

**Beelzebub Controversy (12:22-37):**
**The Key Verses (12:22-30):**
"''Can this be the son of David?''"

*Mēti houtos estin ho huios David*—son of David?

"''This man does not cast out demons, but by Beelzebub.''"

*Houtos ouk ekballei ta daimonia ei mē en tō Beelzeboul*—Beelzebub.

"''Every kingdom divided against itself is brought to desolation.''"

*Pasa basileia meristheisa kath' heautēs erēmoutai*—divided kingdom.

"''If Satan casts out Satan, he is divided against himself.''"

*Kai ei ho Satanas ton Satanan ekballei eph' heauton emeristhē*—divided.

"''If I by the Spirit of God cast out demons, then is the kingdom of God come upon you.''"

*Ei de en pneumati theou egō ekballō ta daimonia ara ephthasen eph' hymas hē basileia tou theou*—kingdom come.

"''How can one enter into the house of the strong man, and spoil his goods?''"

*Ē pōs dynatai tis eiselthein eis tēn oikian tou ischyrou kai ta skeuē autou harpasai*—strong man.

"''He that is not with me is against me.''"

*Ho mē ōn met' emou kat' emou estin*—with or against.

**The Key Verses (12:31-37):**
"''Every sin and blasphemy shall be forgiven unto men.''"

*Pasa hamartia kai blasphēmia aphethēsetai tois anthrōpois*—forgiven.

"''But the blasphemy against the Spirit shall not be forgiven.''"

*Hē de tou pneumatos blasphēmia ouk aphethēsetai*—unforgivable.

"''Whosoever shall speak against the Holy Spirit, it shall not be forgiven him.''"

*Hos d' an eipē kata tou pneumatos tou hagiou ouk aphethēsetai autō*—not forgiven.

"''The tree is known by its fruit.''"

*Ek gar tou karpou to dendron ginōsketai*—known by fruit.

"''Out of the abundance of the heart the mouth speaks.''"

*Ek gar tou perisseumatos tēs kardias to stoma lalei*—heart speaks.

"''Every idle word that men shall speak, they shall give account thereof.''"

*Pan rhēma argon ho lalēsousin hoi anthrōpoi apodōsousin peri autou logon*—account.

"''By your words you shall be justified, and by your words you shall be condemned.''"

*Ek gar tōn logōn sou dikaiōthēsē kai ek tōn logōn sou katadikasthēsē*—words judge.

**Sign of Jonah (12:38-45):**
**The Key Verses (12:38-42):**
"''Teacher, we would see a sign from you.''"

*Didaskale thelomen apo sou sēmeion idein*—sign.

"''An evil and adulterous generation seeks after a sign.''"

*Genea ponēra kai moichalis sēmeion epizētei*—evil generation.

"''There shall no sign be given to it but the sign of Jonah the prophet.''"

*Kai sēmeion ou dothēsetai autē ei mē to sēmeion Iōna tou prophētou*—Jonah's sign.

"''As Jonah was three days and three nights in the belly of the whale.''"

*Hōsper gar ēn Iōnas en tē koilia tou kētous treis hēmeras kai treis nyktas*—three days.

"''So shall the Son of man be three days and three nights in the heart of the earth.''"

*Houtōs estai ho huios tou anthrōpou en tē kardia tēs gēs treis hēmeras kai treis nyktas*—heart of earth.

"''A greater than Jonah is here.''"

*Idou pleion Iōna hōde*—greater than Jonah.

"''A greater than Solomon is here.''"

*Idou pleion Solomōnos hōde*—greater than Solomon.

**True Family (12:46-50):**
**The Key Verses (12:46-50):**
"'His mother and his brethren stood without, seeking to speak to him.'"

*Hē mētēr autou kai hoi adelphoi autou heistēkeisan exō zētountes autō lalēsai*—family.

"''Who is my mother? And who are my brethren?''"

*Tis estin hē mētēr mou kai tines eisin hoi adelphoi mou*—who?

"''Behold, my mother and my brethren!''"

*Idou hē mētēr mou kai hoi adelphoi mou*—disciples.

"''Whosoever shall do the will of my Father who is in heaven, he is my brother, and sister, and mother.''"

*Hostis gar an poiēsē to thelēma tou patros mou tou en ouranois autos mou adelphos kai adelphē kai mētēr estin*—true family.

**Archetypal Layer:** Matthew 12 contains **"The Son of man is lord of the sabbath" (12:8)**, **"one greater than the temple is here" (12:6)**, **"I desire mercy, and not sacrifice" (Hosea 6:6) (12:7)**, **"It is lawful to do good on the sabbath day" (12:12)**, **Isaiah 42:1-4 fulfilled: servant, bruised reed, smoking flax (12:18-21)**, **"If I by the Spirit of God cast out demons, then is the kingdom of God come upon you" (12:28)**, **binding the strong man (12:29)**, **"He that is not with me is against me" (12:30)**, **"the blasphemy against the Spirit shall not be forgiven" (12:31-32)**, **"out of the abundance of the heart the mouth speaks" (12:34)**, **sign of Jonah: "three days and three nights in the heart of the earth" (12:40)**, **"a greater than Jonah... a greater than Solomon is here" (12:41-42)**, and **"whosoever shall do the will of my Father... is my brother, and sister, and mother" (12:50)**.

**Modern Equivalent:** Matthew 12 shows escalating conflict. Yeshua claims to be "greater than the temple" (12:6), "lord of the sabbath" (12:8), greater than Jonah and Solomon (12:41-42). The Pharisees attribute His exorcisms to Satan—prompting the warning about blasphemy against the Spirit (12:31-32). The sign of Jonah (12:40) predicts resurrection. True family is redefined by doing the Father's will (12:50), transcending biological ties.

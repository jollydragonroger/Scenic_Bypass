# Matthew 24: The Olivet Discourse — Signs of the End

*From the Greek: Καὶ ἐξελθὼν ὁ Ἰησοῦς ἀπὸ τοῦ ἱεροῦ (Kai Exelthōn ho Iesous apo tou Hierou) — And Yeshua Went Out from the Temple*

---

## The Temple's Destruction Foretold (24:1-2)

**24:1** And Yeshua went out from the temple, and was going on his way; and his disciples came to him to show him the buildings of the temple.

**24:2** But he answered and said unto them: "See you not all these things? Verily I say unto you, There shall not be left here one stone upon another, that shall not be thrown down."

---

## Signs of the End (24:3-14)

**24:3** And as he sat on the mount of Olives, the disciples came unto him privately, saying: "Tell us, when shall these things be? And what shall be the sign of your coming, and of the end of the world?"

**24:4** And Yeshua answered and said unto them: "Take heed that no man lead you astray.

**24:5** "For many shall come in my name, saying, 'I am the Anointed'; and shall lead many astray.

**24:6** "And you shall hear of wars and rumors of wars; see that you be not troubled: for these things must needs come to pass; but the end is not yet.

**24:7** "For nation shall rise against nation, and kingdom against kingdom; and there shall be famines and earthquakes in divers places.

**24:8** "But all these things are the beginning of travail.

**24:9** "Then shall they deliver you up unto tribulation, and shall kill you: and you shall be hated of all the nations for my name's sake.

**24:10** "And then shall many stumble, and shall deliver up one another, and shall hate one another.

**24:11** "And many false prophets shall arise, and shall lead many astray.

**24:12** "And because iniquity shall be multiplied, the love of the many shall wax cold.

**24:13** "But he that endures to the end, the same shall be saved.

**24:14** "And this good news of the kingdom shall be proclaimed in the whole world for a testimony unto all the nations; and then shall the end come."

---

## The Abomination of Desolation (24:15-28)

**24:15** "When therefore you see the abomination of desolation, which was spoken of through Daniel the prophet, standing in the holy place (let him that reads understand),

**24:16** "Then let them that are in Judaea flee unto the mountains:

**24:17** "Let him that is on the housetop not go down to take out the things that are in his house:

**24:18** "And let him that is in the field not return back to take his cloak.

**24:19** "But woe unto them that are with child and to them that nurse in those days!

**24:20** "And pray that your flight be not in the winter, neither on a sabbath:

**24:21** "For then shall be great tribulation, such as has not been from the beginning of the world until now, no, nor ever shall be.

**24:22** "And except those days had been shortened, no flesh would have been saved: but for the elect's sake those days shall be shortened.

**24:23** "Then if any man shall say unto you, 'Lo, here is the Anointed,' or, 'Here'; believe it not.

**24:24** "For there shall arise false anointed ones, and false prophets, and shall show great signs and wonders; so as to lead astray, if possible, even the elect.

**24:25** "Behold, I have told you beforehand.

**24:26** "If therefore they shall say unto you, 'Behold, he is in the wilderness'; go not forth: 'Behold, he is in the inner chambers'; believe it not.

**24:27** "For as the lightning comes forth from the east, and is seen even unto the west; so shall be the coming of the Son of man.

**24:28** "Wheresoever the carcase is, there will the eagles be gathered together."

---

## The Coming of the Son of Man (24:29-35)

**24:29** "But immediately after the tribulation of those days the sun shall be darkened, and the moon shall not give her light, and the stars shall fall from heaven, and the powers of the heavens shall be shaken:

**24:30** "And then shall appear the sign of the Son of man in heaven: and then shall all the tribes of the earth mourn, and they shall see the Son of man coming on the clouds of heaven with power and great glory.

**24:31** "And he shall send forth his angels with a great sound of a trumpet, and they shall gather together his elect from the four winds, from one end of heaven to the other.

**24:32** "Now from the fig tree learn her parable: when her branch is now become tender, and puts forth its leaves, you know that the summer is near;

**24:33** "Even so you also, when you see all these things, know that he is near, even at the doors.

**24:34** "Verily I say unto you, This generation shall not pass away, till all these things be accomplished.

**24:35** "Heaven and earth shall pass away, but my words shall not pass away."

---

## Exhortation to Watchfulness (24:36-51)

**24:36** "But of that day and hour knows no one, not even the angels of heaven, neither the Son, but the Father only.

**24:37** "And as were the days of Noah, so shall be the coming of the Son of man.

**24:38** "For as in those days which were before the flood they were eating and drinking, marrying and giving in marriage, until the day that Noah entered into the ark,

**24:39** "And they knew not until the flood came, and took them all away; so shall be the coming of the Son of man.

**24:40** "Then shall two men be in the field; one is taken, and one is left:

**24:41** "Two women shall be grinding at the mill; one is taken, and one is left.

**24:42** "Watch therefore: for you know not on what day your Lord comes.

**24:43** "But know this, that if the master of the house had known in what watch the thief was coming, he would have watched, and would not have allowed his house to be broken through.

**24:44** "Therefore be also ready; for in an hour that you think not the Son of man comes.

**24:45** "Who then is the faithful and wise servant, whom his lord has set over his household, to give them their food in due season?

**24:46** "Blessed is that servant, whom his lord when he comes shall find so doing.

**24:47** "Verily I say unto you, that he will set him over all that he has.

**24:48** "But if that evil servant shall say in his heart, 'My lord delays';

**24:49** "And shall begin to beat his fellow-servants, and shall eat and drink with the drunken;

**24:50** "The lord of that servant shall come in a day when he expects not, and in an hour when he knows not,

**24:51** "And shall cut him asunder, and appoint his portion with the hypocrites: there shall be the weeping and the gnashing of teeth."

---

## Synthesis Notes

**Key Restorations:**

**Temple's Destruction (24:1-2):**
**The Key Verses (24:1-2):**
"'His disciples came to him to show him the buildings of the temple.'"

*Prosēlthon hoi mathētai autou epideixai autō tas oikodomas tou hierou*—temple buildings.

"''There shall not be left here one stone upon another, that shall not be thrown down.''"

*Ou mē aphethē hōde lithos epi lithon hos ou katalythēsetai*—destroyed.

**70 CE Fulfillment:**
Temple destroyed by Romans.

**Signs of the End (24:3-14):**
**The Key Verses (24:3-8):**
"'As he sat on the mount of Olives.'"

*Kathēmenou de autou epi tou orous tōn elaiōn*—Olivet.

"''When shall these things be? And what shall be the sign of your coming, and of the end of the world?''"

*Pote tauta estai kai ti to sēmeion tēs sēs parousias kai synteleias tou aiōnos*—three questions.

**Parousia:**
"Coming/presence/arrival."

**Synteleia tou Aiōnos:**
"End of the age."

"''Take heed that no man lead you astray.''"

*Blepete mē tis hymas planēsē*—don't be deceived.

"''Many shall come in my name, saying, I am the Anointed.''"

*Polloi gar eleusontai epi tō onomati mou legontes egō eimi ho Christos*—false messiahs.

"''Wars and rumors of wars... the end is not yet.''"

*Mellēsete de akouein polemous kai akoas polemōn... oupō estin to telos*—not yet.

"''Nation shall rise against nation.''"

*Egerthēsetai gar ethnos epi ethnos*—nation against nation.

"''Famines and earthquakes in divers places.''"

*Limoi kai seismoi kata topous*—famines, earthquakes.

"''All these things are the beginning of travail.''"

*Panta de tauta archē ōdinōn*—birth pains.

**The Key Verses (24:9-14):**
"''They deliver you up unto tribulation, and shall kill you.''"

*Paradōsousin hymas eis thlipsin kai apoktenousin hymas*—persecution.

"''You shall be hated of all the nations for my name's sake.''"

*Kai esesthe misoumenoi hypo pantōn tōn ethnōn dia to onoma mou*—hated.

"''Many shall stumble, and shall deliver up one another.''"

*Kai tote skandalisthēsontai polloi kai allēlous paradōsousin*—betray.

"''Many false prophets shall arise.''"

*Kai polloi pseudoprophētai egerthēsontai*—false prophets.

"''Because iniquity shall be multiplied, the love of the many shall wax cold.''"

*Kai dia to plēthynthēnai tēn anomian psygēsetai hē agapē tōn pollōn*—love cold.

"''He that endures to the end, the same shall be saved.''"

*Ho de hypomeinas eis telos houtos sōthēsetai*—endure.

"''This good news of the kingdom shall be proclaimed in the whole world.''"

*Kai kērychthēsetai touto to euangelion tēs basileias en holē tē oikoumenē*—worldwide.

"''Then shall the end come.''"

*Kai tote hēxei to telos*—end.

**Abomination of Desolation (24:15-28):**
**The Key Verses (24:15-22):**
"''The abomination of desolation, which was spoken of through Daniel the prophet.''"

*To bdelygma tēs erēmōseōs to rhēthen dia Daniēl tou prophētou*—abomination.

**Daniel 9:27, 11:31, 12:11.**

"''Standing in the holy place.''"

*Hestos en topō hagiō*—holy place.

"''Let them that are in Judaea flee unto the mountains.''"

*Tote hoi en tē Ioudaia pheugetōsan eis ta orē*—flee.

"''Let him that is on the housetop not go down.''"

*Ho epi tou dōmatos mē katabatō*—urgency.

"''Pray that your flight be not in the winter, neither on a sabbath.''"

*Proseuchesthe de hina mē genētai hē phygē hymōn cheimōnos mēde sabbatō*—pray.

"''Then shall be great tribulation.''"

*Estai gar tote thlipsis megalē*—great tribulation.

"''Such as has not been from the beginning of the world until now.''"

*Hoia ou gegonen ap' archēs kosmou heōs tou nyn oud' ou mē genētai*—unprecedented.

"''For the elect's sake those days shall be shortened.''"

*Dia de tous eklektous kolοbōthēsontai hai hēmerai ekeinai*—shortened.

**The Key Verses (24:23-28):**
"''If any man shall say unto you, Lo, here is the Anointed... believe it not.''"

*Ean tis hymin eipē idou hōde ho Christos... mē pisteusēte*—don't believe.

"''False anointed ones, and false prophets... great signs and wonders.''"

*Egerthēsontai gar pseudochristoi kai pseudoprophētai kai dōsousin sēmeia megala kai terata*—signs.

"''So as to lead astray, if possible, even the elect.''"

*Hōste planēsai ei dynaton kai tous eklektous*—even elect.

"''As the lightning comes forth from the east, and is seen even unto the west.''"

*Hōsper gar hē astrapē exerchetai apo anatolōn kai phainetai heōs dysmōn*—unmistakable.

"''So shall be the coming of the Son of man.''"

*Houtōs estai hē parousia tou huiou tou anthrōpou*—parousia.

**Coming of the Son of Man (24:29-35):**
**The Key Verses (24:29-31):**
"''Immediately after the tribulation of those days.''"

*Eutheōs de meta tēn thlipsin tōn hēmerōn ekeinōn*—immediately after.

"''The sun shall be darkened, and the moon shall not give her light.''"

*Ho hēlios skotisthēsetai kai hē selēnē ou dōsei to phengos autēs*—cosmic signs.

**Isaiah 13:10, 34:4.**

"''The stars shall fall from heaven, and the powers of the heavens shall be shaken.''"

*Kai hoi asteres pesountai apo tou ouranou kai hai dynameis tōn ouranōn saleuthēsontai*—shaken.

"''Then shall appear the sign of the Son of man in heaven.''"

*Kai tote phanēsetai to sēmeion tou huiou tou anthrōpou en ouranō*—sign.

"''All the tribes of the earth mourn.''"

*Kai tote kopsontai pasai hai phylai tēs gēs*—mourn.

**Zechariah 12:10-14.**

"''They shall see the Son of man coming on the clouds of heaven with power and great glory.''"

*Kai opsontai ton huion tou anthrōpou erchomenon epi tōn nephelōn tou ouranou meta dynameōs kai doxēs pollēs*—coming.

**Daniel 7:13-14.**

"''He shall send forth his angels with a great sound of a trumpet.''"

*Kai apostelei tous angelous autou meta salpingos megalēs*—trumpet.

"''They shall gather together his elect from the four winds.''"

*Kai episynaxousin tous eklektous autou ek tōn tessarōn anemōn*—gather.

**The Key Verses (24:32-35):**
"''From the fig tree learn her parable.''"

*Apo de tēs sykēs mathete tēn parabolēn*—fig tree.

"''When you see all these things, know that he is near, even at the doors.''"

*Houtōs kai hymeis hotan idēte panta tauta ginōskete hoti engys estin epi thyrais*—near.

"''This generation shall not pass away, till all these things be accomplished.''"

*Amēn legō hymin ou mē parelthē hē genea hautē heōs an panta tauta genētai*—generation.

"''Heaven and earth shall pass away, but my words shall not pass away.''"

*Ho ouranos kai hē gē pareleusontai hoi de logoi mou ou mē parelthōsin*—words endure.

**Exhortation to Watchfulness (24:36-51):**
**The Key Verses (24:36-44):**
"''Of that day and hour knows no one, not even the angels of heaven, neither the Son, but the Father only.''"

*Peri de tēs hēmeras ekeinēs kai hōras oudeis oiden oude hoi angeloi tōn ouranōn oude ho huios ei mē ho patēr monos*—unknown.

"''As were the days of Noah, so shall be the coming of the Son of man.''"

*Hōsper gar hai hēmerai tou Nōe houtōs estai hē parousia tou huiou tou anthrōpou*—Noah.

"''They knew not until the flood came, and took them all away.''"

*Kai ouk egnōsan heōs ēlthen ho kataklysmos kai ēren hapantas*—sudden.

"''One is taken, and one is left.''"

*Paralambanizetai heis kai aphietai heis*—taken, left.

"''Watch therefore: for you know not on what day your Lord comes.''"

*Grēgoreite oun hoti ouk oidate poia hēmera ho kyrios hymōn erchetai*—watch.

"''If the master of the house had known in what watch the thief was coming.''"

*Ekeino de ginōskete hoti ei ēdei ho oikodespotēs poia phylakē ho kleptēs erchetai*—thief.

"''Be also ready; for in an hour that you think not the Son of man comes.''"

*Dia touto kai hymeis ginesthe hetoimoi hoti hē ου dokei hōra ho huios tou anthrōpou erchetai*—ready.

**The Key Verses (24:45-51):**
"''Who then is the faithful and wise servant?''"

*Tis ara estin ho pistos doulos kai phronimos*—faithful servant.

"''Whom his lord has set over his household.''"

*Hon katestēsen ho kyrios epi tēs oiketeias autou*—over household.

"''Blessed is that servant, whom his lord when he comes shall find so doing.''"

*Makarios ho doulos ekeinos hon elthōn ho kyrios autou heurēsei houtōs poiounta*—blessed.

"''He will set him over all that he has.''"

*Epi pasin tois hyparchousin autou katastēsei auton*—reward.

"''If that evil servant shall say in his heart, My lord delays.''"

*Ean de eipē ho kakos doulos ekeinos en tē kardia autou chronizei mou ho kyrios*—delays.

"''Shall begin to beat his fellow-servants, and shall eat and drink with the drunken.''"

*Kai arxētai typtein tous syndoulous autou esthiē de kai pinē meta tōn methyontōn*—abuse.

"''The lord of that servant shall come in a day when he expects not.''"

*Hēxei ho kyrios tou doulou ekeinou en hēmera hē ou prosdoka*—unexpected.

"''Appoint his portion with the hypocrites.''"

*Kai to meros autou meta tōn hypokritōn thēsei*—hypocrites.

**Archetypal Layer:** Matthew 24 is the **Olivet Discourse**, containing **"There shall not be left here one stone upon another" (24:2)**, **"what shall be the sign of your coming, and of the end of the world?" (24:3)**, **"Take heed that no man lead you astray" (24:4)**, **"wars and rumors of wars... the end is not yet" (24:6)**, **"the beginning of travail" (24:8)**, **"you shall be hated of all the nations for my name's sake" (24:9)**, **"the love of the many shall wax cold" (24:12)**, **"he that endures to the end, the same shall be saved" (24:13)**, **"this good news of the kingdom shall be proclaimed in the whole world" (24:14)**, **"the abomination of desolation" (Daniel) (24:15)**, **"great tribulation" (24:21)**, **"false anointed ones, and false prophets... great signs and wonders" (24:24)**, **"as the lightning... so shall be the coming of the Son of man" (24:27)**, **cosmic signs (24:29)**, **"the Son of man coming on the clouds of heaven with power and great glory" (Daniel 7:13) (24:30)**, **"of that day and hour knows no one... but the Father only" (24:36)**, **"as were the days of Noah" (24:37)**, **"one is taken, and one is left" (24:40-41)**, **"Watch therefore" (24:42)**, and **parable of faithful and evil servants (24:45-51)**.

**Modern Equivalent:** Matthew 24 answers the disciples' question about the temple's destruction and the end of the age. The discourse blends near (70 CE) and far (parousia) horizons. Signs include false messiahs, wars, famines, earthquakes (birth pains), persecution, false prophets, and love growing cold. The abomination of desolation (Daniel) signals urgency. The coming will be unmistakable like lightning. No one knows the day/hour—not angels, not even the Son. Watchfulness is the response: like Noah's days, judgment comes suddenly. The faithful servant contrasts with the evil one who abuses delay.

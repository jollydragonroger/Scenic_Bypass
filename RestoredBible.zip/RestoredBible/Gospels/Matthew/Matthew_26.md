# Matthew 26: The Passion Begins — Betrayal, Last Supper, Arrest

*From the Greek: Καὶ ἐγένετο ὅτε ἐτέλεσεν ὁ Ἰησοῦς (Kai Egeneto Hote Etelesen ho Iesous) — And It Came to Pass When Yeshua Had Finished*

---

## The Plot and the Anointing (26:1-16)

**26:1** And it came to pass, when Yeshua had finished all these words, he said unto his disciples:

**26:2** "You know that after two days the Passover comes, and the Son of man is delivered up to be crucified."

**26:3** Then were gathered together the chief priests, and the elders of the people, unto the court of the high priest, who was called Caiaphas;

**26:4** And they took counsel together that they might take Yeshua by subtlety, and kill him.

**26:5** But they said: "Not during the feast, lest a tumult arise among the people."

**26:6** Now when Yeshua was in Bethany, in the house of Simon the leper,

**26:7** There came unto him a woman having an alabaster cruse of exceeding precious ointment, and she poured it upon his head, as he sat at meat.

**26:8** But when the disciples saw it, they had indignation, saying: "To what purpose is this waste?

**26:9** "For this ointment might have been sold for much, and given to the poor."

**26:10** But Yeshua perceiving it said unto them: "Why trouble you the woman? For she has wrought a good work upon me.

**26:11** "For you have the poor always with you; but me you have not always.

**26:12** "For in that she poured this ointment upon my body, she did it to prepare me for burial.

**26:13** "Verily I say unto you, Wheresoever this good news shall be proclaimed in the whole world, that also which this woman has done shall be spoken of for a memorial of her."

**26:14** Then one of the twelve, who was called Judas Iscariot, went unto the chief priests,

**26:15** And said: "What are you willing to give me, and I will deliver him unto you?" And they weighed unto him thirty pieces of silver.

**26:16** And from that time he sought opportunity to deliver him unto them.

---

## The Last Supper (26:17-30)

**26:17** Now on the first day of unleavened bread the disciples came to Yeshua, saying: "Where will you that we make ready for you to eat the Passover?"

**26:18** And he said: "Go into the city to such a man, and say unto him, 'The Teacher says, My time is at hand; I keep the Passover at your house with my disciples.'"

**26:19** And the disciples did as Yeshua appointed them; and they made ready the Passover.

**26:20** Now when even was come, he was sitting at meat with the twelve disciples;

**26:21** And as they were eating, he said: "Verily I say unto you, that one of you shall betray me."

**26:22** And they were exceeding sorrowful, and began to say unto him every one: "Is it I, Lord?"

**26:23** And he answered and said: "He that dipped his hand with me in the dish, the same shall betray me.

**26:24** "The Son of man goes, even as it is written of him: but woe unto that man through whom the Son of man is betrayed! Good were it for that man if he had not been born."

**26:25** And Judas, who betrayed him, answered and said: "Is it I, Rabbi?" He says unto him: "You have said."

**26:26** And as they were eating, Yeshua took bread, and blessed, and broke it; and he gave to the disciples, and said: "Take, eat; this is my body."

**26:27** And he took a cup, and gave thanks, and gave to them, saying: "Drink of it, all of you;

**26:28** "For this is my blood of the covenant, which is poured out for many unto remission of sins.

**26:29** "But I say unto you, I shall not drink henceforth of this fruit of the vine, until that day when I drink it new with you in my Father's kingdom."

**26:30** And when they had sung a hymn, they went out unto the mount of Olives.

---

## Peter's Denial Foretold (26:31-35)

**26:31** Then says Yeshua unto them: "All you shall be offended in me this night: for it is written, 'I will smite the shepherd, and the sheep of the flock shall be scattered abroad.'

**26:32** "But after I am raised up, I will go before you into Galilee."

**26:33** But Peter answered and said unto him: "If all shall be offended in you, I will never be offended."

**26:34** Yeshua said unto him: "Verily I say unto you, that this night, before the cock crow, you shall deny me thrice."

**26:35** Peter says unto him: "Even if I must die with you, yet will I not deny you." Likewise also said all the disciples.

---

## Gethsemane (26:36-46)

**26:36** Then comes Yeshua with them unto a place called Gethsemane, and says unto the disciples: "Sit here, while I go yonder and pray."

**26:37** And he took with him Peter and the two sons of Zebedee, and began to be sorrowful and sore troubled.

**26:38** Then says he unto them: "My soul is exceeding sorrowful, even unto death: abide here, and watch with me."

**26:39** And he went forward a little, and fell on his face, and prayed, saying: "O my Father, if it be possible, let this cup pass away from me: nevertheless, not as I will, but as you will."

**26:40** And he comes unto the disciples, and finds them sleeping, and says unto Peter: "What, could you not watch with me one hour?

**26:41** "Watch and pray, that you enter not into temptation: the spirit indeed is willing, but the flesh is weak."

**26:42** Again a second time he went away, and prayed, saying: "O my Father, if this cannot pass away, except I drink it, your will be done."

**26:43** And he came again and found them sleeping, for their eyes were heavy.

**26:44** And he left them again, and went away, and prayed a third time, saying again the same words.

**26:45** Then comes he to the disciples, and says unto them: "Sleep on now, and take your rest: behold, the hour is at hand, and the Son of man is betrayed into the hands of sinners.

**26:46** "Arise, let us be going: behold, he is at hand that betrays me."

---

## The Arrest (26:47-56)

**26:47** And while he yet spoke, lo, Judas, one of the twelve, came, and with him a great multitude with swords and staves, from the chief priests and elders of the people.

**26:48** Now he that betrayed him gave them a sign, saying: "Whomsoever I shall kiss, that is he: take him."

**26:49** And straightway he came to Yeshua, and said: "Hail, Rabbi"; and kissed him.

**26:50** And Yeshua said unto him: "Friend, do that for which you are come." Then they came and laid hands on Yeshua, and took him.

**26:51** And behold, one of them that were with Yeshua stretched out his hand, and drew his sword, and smote the servant of the high priest, and struck off his ear.

**26:52** Then says Yeshua unto him: "Put up again your sword into its place: for all they that take the sword shall perish with the sword.

**26:53** "Or do you think that I cannot beseech my Father, and he shall even now send me more than twelve legions of angels?

**26:54** "How then should the scriptures be fulfilled, that thus it must be?"

**26:55** In that hour said Yeshua to the multitudes: "Are you come out as against a robber with swords and staves to seize me? I sat daily in the temple teaching, and you took me not.

**26:56** "But all this is come to pass, that the scriptures of the prophets might be fulfilled." Then all the disciples left him, and fled.

---

## Before the Sanhedrin (26:57-68)

**26:57** And they that had taken Yeshua led him away to the house of Caiaphas the high priest, where the scribes and the elders were gathered together.

**26:58** But Peter followed him afar off, unto the court of the high priest, and entered in, and sat with the officers, to see the end.

**26:59** Now the chief priests and the whole council sought false witness against Yeshua, that they might put him to death;

**26:60** And they found it not, though many false witnesses came. But afterward came two,

**26:61** And said: "This man said, 'I am able to destroy the temple of God, and to build it in three days.'"

**26:62** And the high priest stood up, and said unto him: "Do you answer nothing? What is it which these witness against you?"

**26:63** But Yeshua held his peace. And the high priest said unto him: "I adjure you by the living God, that you tell us whether you are the Anointed, the Son of God."

**26:64** Yeshua says unto him: "You have said: nevertheless I say unto you, Henceforth you shall see the Son of man sitting at the right hand of Power, and coming on the clouds of heaven."

**26:65** Then the high priest tore his garments, saying: "He has spoken blasphemy: what further need have we of witnesses? Behold, now you have heard the blasphemy:

**26:66** "What think you?" They answered and said: "He is worthy of death."

**26:67** Then did they spit in his face and buffet him: and some smote him with the palms of their hands,

**26:68** Saying: "Prophesy unto us, you Anointed: who is he that struck you?"

---

## Peter's Denial (26:69-75)

**26:69** Now Peter was sitting without in the court: and a maid came unto him, saying: "You also were with Yeshua the Galilaean."

**26:70** But he denied before them all, saying: "I know not what you say."

**26:71** And when he was gone out into the porch, another maid saw him, and says unto them that were there: "This man also was with Yeshua of Nazareth."

**26:72** And again he denied with an oath: "I know not the man."

**26:73** And after a little while they that stood by came and said to Peter: "Of a truth you also are one of them; for your speech makes you known."

**26:74** Then began he to curse and to swear: "I know not the man." And straightway the cock crew.

**26:75** And Peter remembered the word which Yeshua had said: "Before the cock crow, you shall deny me thrice." And he went out, and wept bitterly.

---

## Synthesis Notes

**Key Restorations:**

**Plot and Anointing (26:1-16):**
**The Key Verses (26:1-5):**
"''After two days the Passover comes, and the Son of man is delivered up to be crucified.''"

*Oidate hoti meta dyo hēmeras to pascha ginetai kai ho huios tou anthrōpou paradidotai eis to staurōthēnai*—Passover, crucified.

"'The chief priests, and the elders... took counsel together that they might take Yeshua by subtlety, and kill him.'"

*Synēchthēsan hoi archiereis kai hoi presbyteroi... kai synebouleusanto hina ton Iēsoun dolō kratēsōsin kai apokteinōsin*—plot.

"''Not during the feast, lest a tumult arise.''"

*Mē en tē heortē hina mē thorybos genētai en tō laō*—not during feast.

**The Key Verses (26:6-13):**
"'A woman having an alabaster cruse of exceeding precious ointment.'"

*Prosēlthen autō gynē echousa alabastron myrou barytimou*—precious ointment.

"'She poured it upon his head.'"

*Katecheen epi tēs kephalēs autou anakeimenou*—anointed.

"''To what purpose is this waste?''"

*Eis ti hē apōleia hautē*—waste.

"''She has wrought a good work upon me.''"

*Ergon gar kalon eirgasato eis eme*—good work.

"''She did it to prepare me for burial.''"

*Pros to entaphiasai me epoiēsen*—burial.

"''Wheresoever this good news shall be proclaimed... that also which this woman has done shall be spoken of for a memorial of her.''"

*Hopou ean kērychthē to euangelion touto... lalēthēsetai kai ho epoiēsen hautē eis mnēmosynon autēs*—memorial.

**The Key Verses (26:14-16):**
"'Judas Iscariot, went unto the chief priests.'"

*Tote poreutheis heis tōn dōdeka ho legomenos Ioudas Iskariōtēs pros tous archiereis*—Judas.

"''What are you willing to give me, and I will deliver him unto you?''"

*Ti thelete moi dounai kagō hymin paradōsō auton*—betray.

"'They weighed unto him thirty pieces of silver.'"

*Hoi de estēsan autō triakonta argyria*—thirty silver.

**Zechariah 11:12.**

**Last Supper (26:17-30):**
**The Key Verses (26:17-25):**
"'On the first day of unleavened bread.'"

*Tē de prōtē tōn azymōn*—unleavened bread.

"''The Teacher says, My time is at hand.''"

*Ho didaskalos legei ho kairos mou engys estin*—time at hand.

"''One of you shall betray me.''"

*Heis ex hymōn paradōsei me*—betray.

"''He that dipped his hand with me in the dish, the same shall betray me.''"

*Ho embapsas met' emou tēn cheira en tō trybiō houtos me paradōsei*—dipped.

"''Woe unto that man through whom the Son of man is betrayed!''"

*Ouai de tō anthrōpō ekeinō di' hou ho huios tou anthrōpou paradidotai*—woe.

"''Good were it for that man if he had not been born.''"

*Kalon ēn autō ei ouk egennēthē ho anthrōpos ekeinos*—better not born.

"''Is it I, Rabbi?' He says unto him: 'You have said.''"

*Mēti egō eimi rhabbi legei autō sy eipas*—you said.

**The Key Verses (26:26-30):**
"'Yeshua took bread, and blessed, and broke it.'"

*Labōn ho Iēsous arton kai eulogēsas eklasen*—bread.

"''Take, eat; this is my body.''"

*Labete phagete touto estin to sōma mou*—body.

"'He took a cup, and gave thanks.'"

*Kai labōn potērion kai eucharistēsas*—cup.

"''Drink of it, all of you.''"

*Piete ex autou pantes*—drink.

"''This is my blood of the covenant, which is poured out for many unto remission of sins.''"

*Touto gar estin to haima mou tēs diathēkēs to peri pollōn ekchynnomenon eis aphesin hamartiōn*—blood, covenant, remission.

"''I shall not drink henceforth of this fruit of the vine, until that day when I drink it new with you in my Father's kingdom.''"

*Ou mē piō ap' arti ek toutou tou genēmatos tēs ampelou heōs tēs hēmeras ekeinēs hotan auto pinō meth' hymōn kainon en tē basileia tou patros mou*—new in kingdom.

"'When they had sung a hymn.'"

*Kai hymnēsantes*—Hallel psalms.

**Peter's Denial Foretold (26:31-35):**
"''I will smite the shepherd, and the sheep of the flock shall be scattered abroad.''"

*Pataxō ton poimena kai diaskorpisthēsontai ta probata tēs poimnēs*—smite shepherd.

**Zechariah 13:7.**

"''Before the cock crow, you shall deny me thrice.''"

*Prin alektora phōnēsai tris aparnēsē me*—thrice.

**Gethsemane (26:36-46):**
**The Key Verses (26:36-46):**
"'A place called Gethsemane.'"

*Chōrion legomenon Gethsēmani*—Gethsemane.

**Gethsemane:**
"Oil press."

"''My soul is exceeding sorrowful, even unto death.''"

*Perilypos estin hē psychē mou heōs thanatou*—sorrowful.

"''O my Father, if it be possible, let this cup pass away from me.''"

*Pater mou ei dynaton estin parelthato ap' emou to potērion touto*—cup.

"''Nevertheless, not as I will, but as you will.''"

*Plēn ouch hōs egō thelō all' hōs sy*—your will.

"''Could you not watch with me one hour?''"

*Houtōs ouk ischysate mian hōran grēgorēsai met' emou*—one hour.

"''Watch and pray, that you enter not into temptation.''"

*Grēgoreite kai proseuchesthe hina mē eiselthēte eis peirasmon*—watch, pray.

"''The spirit indeed is willing, but the flesh is weak.''"

*To men pneuma prothymon hē de sarx asthenēs*—spirit, flesh.

"''Your will be done.''"

*Genēthētō to thelēma sou*—your will.

**Arrest (26:47-56):**
"''Whomsoever I shall kiss, that is he.''"

*Hon an philēsō autos estin*—kiss.

"''Hail, Rabbi'; and kissed him.''"

*Chaire rhabbi kai katephilēsen auton*—kissed.

"''All they that take the sword shall perish with the sword.''"

*Pantes gar hoi labontes machairan en machaira apolountai*—sword.

"''I cannot beseech my Father, and he shall even now send me more than twelve legions of angels?''"

*Ē dokeis hoti ou dynamai parakalesai ton patera mou kai parastēsei moi arti pleiō dōdeka legionas angelōn*—twelve legions.

"''How then should the scriptures be fulfilled?''"

*Pōs oun plērōthōsin hai graphai hoti houtōs dei genesthai*—scriptures.

"'All the disciples left him, and fled.'"

*Tote hoi mathētai pantes aphentes auton ephygon*—fled.

**Before the Sanhedrin (26:57-68):**
"'The chief priests and the whole council sought false witness against Yeshua.'"

*Hoi de archiereis kai to synedrion holon ezētoun pseudomartyrian kata tou Iēsou*—false witness.

"''This man said, I am able to destroy the temple of God, and to build it in three days.''"

*Houtos ephē dynamai katalysai ton naon tou theou kai dia triōn hēmerōn oikodomēsai*—temple.

"''I adjure you by the living God, that you tell us whether you are the Anointed, the Son of God.''"

*Exorkizō se kata tou theou tou zōntos hina hēmin eipēs ei sy ei ho Christos ho huios tou theou*—adjure.

"''You have said: nevertheless I say unto you, Henceforth you shall see the Son of man sitting at the right hand of Power, and coming on the clouds of heaven.''"

*Sy eipas plēn legō hymin ap' arti opsesthe ton huion tou anthrōpou kathēmenon ek dexiōn tēs dynameōs kai erchomenon epi tōn nephelōn tou ouranou*—Psalm 110:1, Daniel 7:13.

"'The high priest tore his garments, saying: He has spoken blasphemy.'"

*Tote ho archiereus dierrhēxen ta himatia autou legōn eblasphēmēsen*—blasphemy.

"''He is worthy of death.''"

*Enochos thanatou estin*—worthy of death.

**Peter's Denial (26:69-75):**
"''You also were with Yeshua the Galilaean.' But he denied.''"

*Kai sy ēstha meta Iēsou tou Galilaiou ho de ērnēsato*—denied.

"''I know not the man.''... 'I know not the man.''... 'I know not the man.''"

*Ouk oida ton anthrōpon*—three denials.

"'Straightway the cock crew.'"

*Kai eutheōs alektōr ephōnēsen*—cock crew.

"'Peter remembered... And he went out, and wept bitterly.'"

*Kai emnēsthē ho Petros... kai exelthōn exō eklausen pikrōs*—wept bitterly.

**Archetypal Layer:** Matthew 26 contains **"after two days the Passover comes, and the Son of man is delivered up to be crucified" (26:2)**, **anointing at Bethany: "she did it to prepare me for burial" (26:12)**, **Judas's betrayal for thirty pieces of silver (26:15)** (Zechariah 11:12), **the Last Supper (26:17-30)**: "Take, eat; this is my body" (26:26), "This is my blood of the covenant, which is poured out for many unto remission of sins" (26:28), **"I will smite the shepherd" (Zechariah 13:7) (26:31)**, **Peter's denial foretold (26:34)**, **Gethsemane (26:36-46)**: "My soul is exceeding sorrowful, even unto death" (26:38), "O my Father, if it be possible, let this cup pass away from me: nevertheless, not as I will, but as you will" (26:39), "the spirit indeed is willing, but the flesh is weak" (26:41), **arrest with Judas's kiss (26:47-50)**, **"all they that take the sword shall perish with the sword" (26:52)**, **trial before Caiaphas (26:57-68)**, **"You shall see the Son of man sitting at the right hand of Power, and coming on the clouds of heaven" (26:64)**, **"He is worthy of death" (26:66)**, and **Peter's three denials and bitter weeping (26:69-75)**.

**Modern Equivalent:** Matthew 26 begins the Passion narrative. The anointing (26:6-13) is prophetic burial preparation. Judas's thirty silver pieces (26:15) fulfills Zechariah 11:12. The Last Supper (26:26-28) institutes the new covenant in Yeshua's blood for sin's remission. Gethsemane (26:36-46) shows Yeshua's anguish and submission: "not as I will, but as you will." The arrest (26:47-56) includes Yeshua's refusal of violence and acceptance of scripture's fulfillment. The trial (26:57-68) culminates in Yeshua's claim combining Psalm 110:1 and Daniel 7:13—resulting in the blasphemy charge. Peter's denial (26:69-75) fulfills Yeshua's prediction and shows human weakness.

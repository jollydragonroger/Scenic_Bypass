# Matthew 16: Peter's Confession and the Way of the Cross

*From the Greek: Καὶ προσελθόντες οἱ Φαρισαῖοι καὶ Σαδδουκαῖοι (Kai Proselthontes hoi Pharisaioi kai Saddoukaioi) — And the Pharisees and Sadducees Came*

---

## The Sign of Jonah (16:1-4)

**16:1** And the Pharisees and Sadducees came, and trying him asked him to show them a sign from heaven.

**16:2** But he answered and said unto them: "When it is evening, you say, 'It will be fair weather: for the heaven is red.'

**16:3** "And in the morning, 'It will be foul weather today: for the heaven is red and lowering.' You know how to discern the face of the heaven; but you cannot discern the signs of the times.

**16:4** "An evil and adulterous generation seeks after a sign; and there shall no sign be given unto it, but the sign of Jonah." And he left them, and departed.

---

## The Leaven of the Pharisees (16:5-12)

**16:5** And the disciples came to the other side and forgot to take bread.

**16:6** And Yeshua said unto them: "Take heed and beware of the leaven of the Pharisees and Sadducees."

**16:7** And they reasoned among themselves, saying: "We took no bread."

**16:8** And Yeshua perceiving it said: "O you of little faith, why reason you among yourselves, because you have no bread?

**16:9** "Do you not yet perceive, neither remember the five loaves of the five thousand, and how many baskets you took up?

**16:10** "Neither the seven loaves of the four thousand, and how many baskets you took up?

**16:11** "How is it that you do not perceive that I spoke not to you concerning bread? But beware of the leaven of the Pharisees and Sadducees."

**16:12** Then understood they that he bade them not beware of the leaven of bread, but of the teaching of the Pharisees and Sadducees.

---

## Peter's Confession (16:13-20)

**16:13** Now when Yeshua came into the parts of Caesarea Philippi, he asked his disciples, saying: "Who do men say that the Son of man is?"

**16:14** And they said: "Some say John the Immerser; some, Elijah; and others, Jeremiah, or one of the prophets."

**16:15** He says unto them: "But who say you that I am?"

**16:16** And Simon Peter answered and said: "You are the Anointed, the Son of the living God."

**16:17** And Yeshua answered and said unto him: "Blessed are you, Simon Bar-Jonah: for flesh and blood has not revealed it unto you, but my Father who is in heaven.

**16:18** "And I also say unto you, that you are Peter, and upon this rock I will build my assembly; and the gates of Hades shall not prevail against it.

**16:19** "I will give unto you the keys of the kingdom of heaven: and whatsoever you shall bind on earth shall be bound in heaven; and whatsoever you shall loose on earth shall be loosed in heaven."

**16:20** Then charged he the disciples that they should tell no man that he was the Anointed.

---

## First Prediction of the Passion (16:21-23)

**16:21** From that time began Yeshua to show unto his disciples, that he must go unto Jerusalem, and suffer many things of the elders and chief priests and scribes, and be killed, and the third day be raised up.

**16:22** And Peter took him, and began to rebuke him, saying: "Be it far from you, Lord: this shall never be unto you."

**16:23** But he turned, and said unto Peter: "Get behind me, Satan: you are a stumbling-block unto me: for you mind not the things of God, but the things of men."

---

## Taking Up the Cross (16:24-28)

**16:24** Then said Yeshua unto his disciples: "If any man would come after me, let him deny himself, and take up his cross, and follow me.

**16:25** "For whosoever would save his life shall lose it: and whosoever shall lose his life for my sake shall find it.

**16:26** "For what shall a man be profited, if he shall gain the whole world, and forfeit his life? Or what shall a man give in exchange for his life?

**16:27** "For the Son of man shall come in the glory of his Father with his angels; and then shall he render unto every man according to his deeds.

**16:28** "Verily I say unto you, there are some of them that stand here, who shall in no wise taste of death, till they see the Son of man coming in his kingdom."

---

## Synthesis Notes

**Key Restorations:**

**Sign of Jonah (16:1-4):**
**The Key Verses (16:1-4):**
"'The Pharisees and Sadducees came, and trying him asked him to show them a sign from heaven.'"

*Kai proselthontes hoi Pharisaioi kai Saddoukaioi peirazontes epērōtēsan auton sēmeion ek tou ouranou epideixai autois*—testing.

**Unusual Alliance:**
Pharisees and Sadducees rarely agreed—united against Yeshua.

"''You know how to discern the face of the heaven; but you cannot discern the signs of the times.''"

*To men prosōpon tou ouranou ginōskete diakrinein ta de sēmeia tōn kairōn ou dynasthe*—signs of times.

"''An evil and adulterous generation seeks after a sign.''"

*Genea ponēra kai moichalis sēmeion epizētei*—evil generation.

"''There shall no sign be given unto it, but the sign of Jonah.''"

*Kai sēmeion ou dothēsetai autē ei mē to sēmeion Iōna*—sign of Jonah.

**Leaven of the Pharisees (16:5-12):**
**The Key Verses (16:5-12):**
"''Take heed and beware of the leaven of the Pharisees and Sadducees.''"

*Horate kai prosechete apo tēs zymēs tōn Pharisaiōn kai Saddoukaiōn*—leaven.

"'They reasoned among themselves, saying: We took no bread.'"

*Hoi de dielogizonto en heautois legontes hoti artous ouk elabomen*—literal thinking.

"''O you of little faith.''"

*Oligopistoi*—little faith.

"''Do you not yet perceive, neither remember the five loaves of the five thousand?''"

*Oupō noeite oude mnēmoneuete tous pente artous tōn pentakischiliōn*—remember.

"''Neither the seven loaves of the four thousand?''"

*Oude tous hepta artous tōn tetrakischiliōn*—seven loaves.

"'Then understood they... the teaching of the Pharisees and Sadducees.'"

*Tote synēkan hoti ouk eipen prosechein apo tēs zymēs tōn artōn alla apo tēs didachēs tōn Pharisaiōn kai Saddoukaiōn*—teaching.

**Peter's Confession (16:13-20):**
**The Key Verses (16:13-16):**
"'When Yeshua came into the parts of Caesarea Philippi.'"

*Elthōn de ho Iēsous eis ta merē Kaisareias tēs Philippou*—Caesarea Philippi.

**Caesarea Philippi:**
Pagan area with shrines; strategic location for this question.

"''Who do men say that the Son of man is?''"

*Tina legousin hoi anthrōpoi einai ton huion tou anthrōpou*—who do men say.

"'Some say John the Immerser; some, Elijah; and others, Jeremiah, or one of the prophets.'"

*Hoi men Iōannēn ton baptistēn alloi de Ēlian heteroi de Ieremian ē hena tōn prophētōn*—opinions.

"''But who say you that I am?''"

*Hymeis de tina me legete einai*—you.

"''You are the Anointed, the Son of the living God.''"

*Sy ei ho Christos ho huios tou theou tou zōntos*—confession.

**Ho Christos:**
The Anointed One = Messiah.

**The Key Verses (16:17-20):**
"''Blessed are you, Simon Bar-Jonah.''"

*Makarios ei Simōn Bariōna*—blessed.

**Bar-Yonah:**
"Son of Jonah."

"''Flesh and blood has not revealed it unto you, but my Father who is in heaven.''"

*Hoti sarx kai haima ouk apekalypsen soi all' ho patēr mou ho en tois ouranois*—revelation.

"''You are Peter, and upon this rock I will build my assembly.''"

*Kagō de soi legō hoti sy ei Petros kai epi tautē tē petra oikodomēsō mou tēn ekklēsian*—rock.

**Petros/Petra:**
Petros (masculine) = stone; Petra (feminine) = rock/bedrock.

**Ekklēsia:**
"Assembly/church"—first use in Gospels.

"''The gates of Hades shall not prevail against it.''"

*Kai pylai hadou ou katischysousin autēs*—Hades' gates.

"''I will give unto you the keys of the kingdom of heaven.''"

*Dōsō soi tas kleidas tēs basileias tōn ouranōn*—keys.

"''Whatsoever you shall bind on earth shall be bound in heaven.''"

*Kai ho ean dēsēs epi tēs gēs estai dedemenon en tois ouranois*—bind.

"''Whatsoever you shall loose on earth shall be loosed in heaven.''"

*Kai ho ean lysēs epi tēs gēs estai lelumenon en tois ouranois*—loose.

"'He charged... that they should tell no man that he was the Anointed.'"

*Tote diesteilato tois mathētais hina mēdeni eipōsin hoti autos estin ho Christos*—messianic secret.

**First Passion Prediction (16:21-23):**
**The Key Verses (16:21-23):**
"'From that time began Yeshua to show unto his disciples, that he must go unto Jerusalem.'"

*Apo tote ērxato ho Iēsous deiknynai tois mathētais autou hoti dei auton eis Hierosolyma apelthein*—must go.

"'Suffer many things of the elders and chief priests and scribes.'"

*Kai polla pathein apo tōn presbyterōn kai archiereōn kai grammateōn*—suffer.

"'Be killed, and the third day be raised up.'"

*Kai apoktanthēnai kai tē tritē hēmera egerthēnai*—killed, raised.

"'Peter took him, and began to rebuke him.'"

*Kai proslabomenos auton ho Petros ērxato epitiman autō*—rebuke.

"''Be it far from you, Lord: this shall never be unto you.''"

*Hileōs soi kyrie ou mē estai soi touto*—never happen.

"''Get behind me, Satan.''"

*Hypage opisō mou Satana*—Satan.

"''You are a stumbling-block unto me.''"

*Skandalon ei emou*—stumbling-block.

"''You mind not the things of God, but the things of men.''"

*Hoti ou phroneis ta tou theou alla ta tōn anthrōpōn*—human thinking.

**Taking Up the Cross (16:24-28):**
**The Key Verses (16:24-28):**
"''If any man would come after me, let him deny himself.''"

*Ei tis thelei opisō mou elthein aparnēsasthō heauton*—deny self.

"''Take up his cross, and follow me.''"

*Kai aratō ton stauron autou kai akoloutheitō moi*—take cross.

"''Whosoever would save his life shall lose it.''"

*Hos gar ean thelē tēn psychēn autou sōsai apolesei autēn*—lose life.

"''Whosoever shall lose his life for my sake shall find it.''"

*Hos d' an apolesē tēn psychēn autou heneken emou heurēsei autēn*—find life.

"''What shall a man be profited, if he shall gain the whole world, and forfeit his life?''"

*Ti gar ōphelēthēsetai anthrōpos ean ton kosmon holon kerdēsē tēn de psychēn autou zēmiōthē*—profit?

"''The Son of man shall come in the glory of his Father with his angels.''"

*Mellei gar ho huios tou anthrōpou erchesthai en tē doxē tou patros autou meta tōn angelōn autou*—coming.

"''Then shall he render unto every man according to his deeds.''"

*Kai tote apodōsei hekastō kata tēn praxin autou*—render.

"''There are some of them that stand here, who shall in no wise taste of death, till they see the Son of man coming in his kingdom.''"

*Eisin tines tōn hōde hestōtōn hoitines ou mē geusōntai thanatou heōs an idōsin ton huion tou anthrōpou erchomenon en tē basileia autou*—see coming.

**Archetypal Layer:** Matthew 16 contains **"You cannot discern the signs of the times" (16:3)**, **"the sign of Jonah" (16:4)**, **"beware of the leaven of the Pharisees and Sadducees" (16:6)** = their teaching (16:12), **"Who do men say that the Son of man is?" (16:13)**, **Peter's confession: "You are the Anointed, the Son of the living God" (16:16)**, **"Blessed are you, Simon Bar-Jonah: for flesh and blood has not revealed it unto you" (16:17)**, **"You are Peter, and upon this rock I will build my assembly" (16:18)**, **"the gates of Hades shall not prevail against it" (16:18)**, **"the keys of the kingdom of heaven" (16:19)**, **"bind... loose" (16:19)**, **first passion prediction (16:21)**, **"Get behind me, Satan" (16:23)**, **"let him deny himself, and take up his cross, and follow me" (16:24)**, **"whosoever would save his life shall lose it" (16:25)**, and **"what shall a man be profited, if he shall gain the whole world, and forfeit his life?" (16:26)**.

**Modern Equivalent:** Matthew 16 is pivotal. Peter's confession (16:16) is the Gospel's climax—Yeshua is Messiah and Son of God. The "rock" (16:18) has been variously interpreted: Peter himself, Peter's confession, or Yeshua Himself. Immediately after this high point comes the first passion prediction (16:21) and Peter's rebuke ("Get behind me, Satan," 16:23). The cross is the path for both Yeshua and disciples (16:24-25). Gaining the world while forfeiting the soul is ultimate loss (16:26).

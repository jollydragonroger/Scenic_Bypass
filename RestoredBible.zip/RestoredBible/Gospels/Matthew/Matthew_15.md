# Matthew 15: Tradition, the Canaanite Woman, and Feeding the Four Thousand

*From the Greek: Τότε προσέρχονται τῷ Ἰησοῦ (Tote Proserchontai tō Iesou) — Then There Come to Yeshua*

---

## Tradition of the Elders (15:1-20)

**15:1** Then there come to Yeshua from Jerusalem Pharisees and scribes, saying:

**15:2** "Why do your disciples transgress the tradition of the elders? For they wash not their hands when they eat bread."

**15:3** And he answered and said unto them: "Why do you also transgress the commandment of God because of your tradition?

**15:4** "For God said, 'Honour your father and your mother'; and, 'He that speaks evil of father or mother, let him die the death.'

**15:5** "But you say, 'Whosoever shall say to his father or his mother, That wherewith you might have been profited by me is given to God;

**15:6** "'He shall not honour his father.' And you have made void the word of God because of your tradition.

**15:7** "You hypocrites, well did Isaiah prophesy of you, saying:

**15:8** "'This people honours me with their lips; but their heart is far from me.

**15:9** "'But in vain do they worship me, teaching as their doctrines the precepts of men.'"

**15:10** And he called to him the multitude, and said unto them: "Hear, and understand:

**15:11** "Not that which enters into the mouth defiles the man; but that which proceeds out of the mouth, this defiles the man."

**15:12** Then came the disciples, and said unto him: "Do you know that the Pharisees were offended, when they heard this saying?"

**15:13** But he answered and said: "Every plant which my heavenly Father planted not, shall be rooted up.

**15:14** "Let them alone: they are blind guides. And if the blind guide the blind, both shall fall into a pit."

**15:15** And Peter answered and said unto him: "Explain unto us the parable."

**15:16** And he said: "Are you also even yet without understanding?

**15:17** "Perceive you not, that whatsoever goes into the mouth passes into the belly, and is cast out into the draught?

**15:18** "But the things which proceed out of the mouth come forth out of the heart; and they defile the man.

**15:19** "For out of the heart come forth evil thoughts, murders, adulteries, fornications, thefts, false witness, railings:

**15:20** "These are the things which defile the man; but to eat with unwashed hands defiles not the man."

---

## The Canaanite Woman's Faith (15:21-28)

**15:21** And Yeshua went out thence, and withdrew into the parts of Tyre and Sidon.

**15:22** And behold, a Canaanite woman came out from those borders, and cried, saying: "Have mercy on me, O Lord, son of David; my daughter is grievously vexed with a demon."

**15:23** But he answered her not a word. And his disciples came and besought him, saying: "Send her away; for she cries after us."

**15:24** But he answered and said: "I was not sent but unto the lost sheep of the house of Israel."

**15:25** But she came and worshipped him, saying: "Lord, help me."

**15:26** And he answered and said: "It is not right to take the children's bread and cast it to the dogs."

**15:27** But she said: "Yea, Lord: for even the dogs eat of the crumbs which fall from their masters' table."

**15:28** Then Yeshua answered and said unto her: "O woman, great is your faith: be it done unto you even as you will." And her daughter was healed from that hour.

---

## Healings by the Sea (15:29-31)

**15:29** And Yeshua departed thence, and came near unto the sea of Galilee; and he went up into the mountain, and sat there.

**15:30** And there came unto him great multitudes, having with them the lame, blind, dumb, maimed, and many others, and they cast them down at his feet; and he healed them:

**15:31** Insomuch that the multitude wondered, when they saw the dumb speaking, the maimed whole, and the lame walking, and the blind seeing: and they glorified the God of Israel.

---

## Feeding the Four Thousand (15:32-39)

**15:32** And Yeshua called unto him his disciples, and said: "I have compassion on the multitude, because they continue with me now three days and have nothing to eat: and I would not send them away fasting, lest haply they faint on the way."

**15:33** And the disciples say unto him: "Whence should we have so many loaves in a desert place as to fill so great a multitude?"

**15:34** And Yeshua says unto them: "How many loaves have you?" And they said: "Seven, and a few small fishes."

**15:35** And he commanded the multitude to sit down on the ground;

**15:36** And he took the seven loaves and the fishes; and he gave thanks and broke, and gave to the disciples, and the disciples to the multitudes.

**15:37** And they all ate, and were filled: and they took up that which remained over of the broken pieces, seven baskets full.

**15:38** And they that ate were four thousand men, besides women and children.

**15:39** And he sent away the multitudes, and entered into the boat, and came into the borders of Magadan.

---

## Synthesis Notes

**Key Restorations:**

**Tradition of the Elders (15:1-20):**
**The Key Verses (15:1-6):**
"''Why do your disciples transgress the tradition of the elders?''"

*Dia ti hoi mathētai sou parabainousin tēn paradosin tōn presbyterōn*—tradition.

"''They wash not their hands when they eat bread.''"

*Ou gar niptontai tas cheiras autōn hotan arton esthiōsin*—hand washing.

**Ritual Hand Washing:**
Pharisaic tradition, not Torah requirement.

"''Why do you also transgress the commandment of God because of your tradition?''"

*Dia ti kai hymeis parabainete tēn entolēn tou theou dia tēn paradosin hymōn*—commandment vs. tradition.

"''Honour your father and your mother.''"

*Tima ton patera kai tēn mētera*—honor parents.

**Exodus 20:12, Deuteronomy 5:16.**

"''Whosoever shall say to his father or his mother, That wherewith you might have been profited by me is given to God.''"

*Hos an eipē tō patri ē tē mētri dōron ho ean ex emou ōphelēthēs*—Corban.

**Corban:**
Dedicating resources to God to avoid supporting parents.

"''You have made void the word of God because of your tradition.''"

*Kai ēkyrōsate ton logon tou theou dia tēn paradosin hymōn*—made void.

**The Key Verses (15:7-11):**
"''You hypocrites, well did Isaiah prophesy of you.''"

*Hypokritai kalōs eprophēteusen peri hymōn Ēsaias*—hypocrites.

**Isaiah 29:13:**
"''This people honours me with their lips; but their heart is far from me.''"

"''In vain do they worship me, teaching as their doctrines the precepts of men.''"

*Matēn de sebontai me didaskontes didaskalias entalmata anthrōpōn*—precepts of men.

"''Not that which enters into the mouth defiles the man.''"

*Ou to eiserchomenon eis to stoma koinoi ton anthrōpon*—not what enters.

"''But that which proceeds out of the mouth, this defiles the man.''"

*Alla to ekporeuomenon ek tou stomatos touto koinoi ton anthrōpon*—what proceeds.

**The Key Verses (15:12-20):**
"''Every plant which my heavenly Father planted not, shall be rooted up.''"

*Pasa phyteia hēn ouk ephyteusen ho patēr mou ho ouranios ekrizōthēsetai*—rooted up.

"''They are blind guides. And if the blind guide the blind, both shall fall into a pit.''"

*Typhloi eisin hodēgoi typhlōn typhlos de typhlon ean hodēgē amphoteroi eis bothynon pesountai*—blind guides.

"''Whatsoever goes into the mouth passes into the belly, and is cast out.''"

*Pan to eisporeuomenon eis to stoma eis tēn koilian chōrei kai eis aphedrōna ekballetai*—passes through.

"''The things which proceed out of the mouth come forth out of the heart.''"

*Ta de ekporeuomena ek tou stomatos ek tēs kardias exerchetai*—from heart.

"''Out of the heart come forth evil thoughts, murders, adulteries, fornications, thefts, false witness, railings.''"

*Ek gar tēs kardias exerchontai dialogismoi ponēroi phonoi moicheiai porneiai klopai pseudomartyriai blasphēmiai*—evil list.

"''These are the things which defile the man.''"

*Tauta estin ta koinounta ton anthrōpon*—defile.

**Canaanite Woman (15:21-28):**
**The Key Verses (15:21-28):**
"'Yeshua went out thence, and withdrew into the parts of Tyre and Sidon.'"

*Kai exelthōn ekeithen ho Iēsous anechōrēsen eis ta merē Tyrou kai Sidōnos*—Gentile territory.

"'A Canaanite woman came out from those borders.'"

*Kai idou gynē Chananaia apo tōn horiōn ekeinōn exelthousa*—Canaanite.

"''Have mercy on me, O Lord, son of David.''"

*Eleēson me kyrie huios David*—son of David.

"''My daughter is grievously vexed with a demon.''"

*Hē thugatēr mou kakōs daimonizetai*—demon-possessed.

"'He answered her not a word.'"

*Ho de ouk apekrithē autē logon*—silence.

"''Send her away; for she cries after us.''"

*Apoluson autēn hoti krazei opisthen hēmōn*—send away.

"''I was not sent but unto the lost sheep of the house of Israel.''"

*Ouk apestalēn ei mē eis ta probata ta apolōlota oikou Israēl*—lost sheep.

"''Lord, help me.''"

*Kyrie boēthei moi*—help.

"''It is not right to take the children's bread and cast it to the dogs.''"

*Ouk estin kalon labein ton arton tōn teknōn kai balein tois kynariois*—children's bread.

**Kynaria:**
"Little dogs/puppies"—household pets, not wild dogs.

"''Even the dogs eat of the crumbs which fall from their masters' table.''"

*Kai gar ta kynaria esthiei apo tōn psichiōn tōn piptontōn apo tēs trapezēs tōn kyriōn autōn*—crumbs.

"''O woman, great is your faith.''"

*Ō gynai megalē sou hē pistis*—great faith.

"''Be it done unto you even as you will.''"

*Genēthētō soi hōs theleis*—as you will.

"'Her daughter was healed from that hour.'"

*Kai iathē hē thugatēr autēs apo tēs hōras ekeinēs*—healed.

**Healings by the Sea (15:29-31):**
**The Key Verses (15:29-31):**
"'He went up into the mountain, and sat there.'"

*Kai anabas eis to oros ekathēto ekei*—mountain.

"'Great multitudes, having with them the lame, blind, dumb, maimed.'"

*Ochloi polloi echontes meth' heautōn chōlous typhlous kyllous kōphous*—afflicted.

"'They cast them down at his feet; and he healed them.'"

*Kai erripsan autous para tous podas autou kai etherapeusen autous*—healed.

"'They glorified the God of Israel.'"

*Kai edoxasan ton theon Israēl*—glorified.

**Feeding the Four Thousand (15:32-39):**
**The Key Verses (15:32-39):**
"''I have compassion on the multitude.''"

*Splanchnizomai epi ton ochlon*—compassion.

"''They continue with me now three days and have nothing to eat.''"

*Hoti ēdē hēmerai treis prosmenousin moi kai ouk echousin ti phagōsin*—three days.

"''Lest haply they faint on the way.''"

*Mēpote eklythōsin en tē hodō*—faint.

"''Whence should we have so many loaves in a desert place?''"

*Pothen hēmin en erēmia artoi tosoutoi*—where from?

"''How many loaves have you?' And they said: 'Seven.''"

*Posous artous echete hoi de eipan hepta*—seven loaves.

"'He took the seven loaves and the fishes; and he gave thanks and broke.'"

*Elaben tous hepta artous kai tous ichthyas kai eucharistēsas eklasen*—gave thanks.

"'They all ate, and were filled.'"

*Kai ephagon pantes kai echortasthēsan*—filled.

"'They took up that which remained over... seven baskets full.'"

*Kai to perisseuon tōn klasmatōn ēran hepta spyridas plēreis*—seven baskets.

**Spyris:**
Large basket—different word than 12 baskets (kophinos) in 14:20.

"'Four thousand men, besides women and children.'"

*Hoi de esthiontes ēsan tetrakischilioi andres chōris gynaikōn kai paidiōn*—four thousand.

"'He... came into the borders of Magadan.'"

*Kai embas eis to ploion ēlthen eis ta horia Magadan*—Magadan.

**Archetypal Layer:** Matthew 15 contains **"Why do your disciples transgress the tradition of the elders?" (15:2)**, **"Why do you also transgress the commandment of God because of your tradition?" (15:3)**, **Corban loophole voiding the word of God (15:5-6)**, **Isaiah 29:13: "This people honours me with their lips; but their heart is far from me" (15:8)**, **"Not that which enters into the mouth defiles the man; but that which proceeds out of the mouth" (15:11)**, **"they are blind guides" (15:14)**, **"out of the heart come forth evil thoughts, murders, adulteries" (15:19)**, **the Canaanite woman's persistence (15:21-28)**, **"I was not sent but unto the lost sheep of the house of Israel" (15:24)**, **"O woman, great is your faith" (15:28)**, **healings on the mountain (15:29-31)**, and **feeding the four thousand with seven loaves (15:32-39)**.

**Modern Equivalent:** Matthew 15 contrasts human tradition with divine command. The Corban loophole (15:5-6) used religious dedication to evade parental care—tradition nullifying Torah. Defilement is internal, not external (15:11, 18-19). The Canaanite woman (15:21-28) is a Gentile whose persistent faith breaks through initial silence and apparent rejection—"great is your faith" contrasts with Israel's unbelief. The second feeding (15:32-39) shows continued compassion and provision.

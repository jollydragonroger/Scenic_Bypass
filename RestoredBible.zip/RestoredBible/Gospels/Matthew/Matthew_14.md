# Matthew 14: Death of John, Feeding the Five Thousand, Walking on Water

*From the Greek: Ἐν ἐκείνῳ τῷ καιρῷ ἤκουσεν Ἡρῴδης (En Ekeinō tō Kairō Ēkousen Hērōdēs) — At That Season Herod Heard*

---

## The Death of John the Immerser (14:1-12)

**14:1** At that season Herod the tetrarch heard the report concerning Yeshua,

**14:2** And said unto his servants: "This is John the Immerser; he is risen from the dead; and therefore do these powers work in him."

**14:3** For Herod had laid hold on John, and bound him, and put him in prison for the sake of Herodias, his brother Philip's wife.

**14:4** For John said unto him: "It is not lawful for you to have her."

**14:5** And when he would have put him to death, he feared the multitude, because they counted him as a prophet.

**14:6** But when Herod's birthday came, the daughter of Herodias danced in the midst, and pleased Herod.

**14:7** Whereupon he promised with an oath to give her whatsoever she should ask.

**14:8** And she, being put forward by her mother, says: "Give me here on a platter the head of John the Immerser."

**14:9** And the king was grieved; but for the sake of his oaths, and of them that sat at meat with him, he commanded it to be given;

**14:10** And he sent, and beheaded John in the prison.

**14:11** And his head was brought on a platter, and given to the damsel: and she brought it to her mother.

**14:12** And his disciples came, and took up the corpse, and buried him; and they went and told Yeshua.

---

## Feeding the Five Thousand (14:13-21)

**14:13** Now when Yeshua heard it, he withdrew from thence in a boat, to a desert place apart: and when the multitudes heard thereof, they followed him on foot from the cities.

**14:14** And he came forth, and saw a great multitude, and he had compassion on them, and healed their sick.

**14:15** And when even was come, the disciples came to him, saying: "The place is desert, and the time is already past; send the multitudes away, that they may go into the villages, and buy themselves food."

**14:16** But Yeshua said unto them: "They have no need to go away; give them to eat."

**14:17** And they say unto him: "We have here but five loaves, and two fishes."

**14:18** And he said: "Bring them here to me."

**14:19** And he commanded the multitudes to sit down on the grass; and he took the five loaves, and the two fishes, and looking up to heaven, he blessed, and broke and gave the loaves to the disciples, and the disciples to the multitudes.

**14:20** And they all ate, and were filled: and they took up that which remained over of the broken pieces, twelve baskets full.

**14:21** And they that ate were about five thousand men, besides women and children.

---

## Walking on the Water (14:22-33)

**14:22** And straightway he constrained the disciples to enter into the boat, and to go before him unto the other side, till he should send the multitudes away.

**14:23** And after he had sent the multitudes away, he went up into the mountain apart to pray: and when even was come, he was there alone.

**14:24** But the boat was now in the midst of the sea, distressed by the waves; for the wind was contrary.

**14:25** And in the fourth watch of the night he came unto them, walking upon the sea.

**14:26** And when the disciples saw him walking on the sea, they were troubled, saying: "It is a ghost"; and they cried out for fear.

**14:27** But straightway Yeshua spoke unto them, saying: "Be of good cheer; it is I; be not afraid."

**14:28** And Peter answered him and said: "Lord, if it be you, bid me come unto you upon the waters."

**14:29** And he said: "Come." And Peter went down from the boat, and walked upon the waters to come to Yeshua.

**14:30** But when he saw the wind, he was afraid; and beginning to sink, he cried out, saying: "Lord, save me."

**14:31** And immediately Yeshua stretched forth his hand, and took hold of him, and says unto him: "O you of little faith, why did you doubt?"

**14:32** And when they were gone up into the boat, the wind ceased.

**14:33** And they that were in the boat worshipped him, saying: "Of a truth you are the Son of God."

---

## Healings at Gennesaret (14:34-36)

**14:34** And when they had crossed over, they came to the land, unto Gennesaret.

**14:35** And when the men of that place knew him, they sent into all that region round about, and brought unto him all that were sick,

**14:36** And they besought him that they might only touch the border of his garment: and as many as touched were made whole.

---

## Synthesis Notes

**Key Restorations:**

**Death of John (14:1-12):**
**The Key Verses (14:1-5):**
"'Herod the tetrarch heard the report concerning Yeshua.'"

*En ekeinō tō kairō ēkousen Hērōdēs ho tetraarchēs tēn akoēn Iēsou*—Herod hears.

**Herod Antipas:**
Son of Herod the Great; tetrarch of Galilee and Perea.

"''This is John the Immerser; he is risen from the dead.''"

*Houtos estin Iōannēs ho baptistēs autos ēgerthē apo tōn nekrōn*—risen.

"'Herod had laid hold on John, and bound him, and put him in prison.'"

*Ho gar Hērōdēs kratēsas ton Iōannēn edēsen auton kai en phylakē apetheto*—imprisoned.

"'For the sake of Herodias, his brother Philip's wife.'"

*Dia Hērōdiada tēn gynaika Philippou tou adelphou autou*—Herodias.

"''It is not lawful for you to have her.''"

*Ouk exestin soi echein autēn*—not lawful.

**Leviticus 18:16, 20:21:**
Prohibited marrying brother's wife.

**The Key Verses (14:6-12):**
"'The daughter of Herodias danced in the midst, and pleased Herod.'"

*Orchēsamenēs tēs thygatros tēs Hērōdiados en tō mesō ēresen tō Hērōdē*—danced.

"'He promised with an oath to give her whatsoever she should ask.'"

*Hothen meth' horkou hōmologēsen autē dounai ho ean aitēsētai*—oath.

"''Give me here on a platter the head of John the Immerser.''"

*Dos moi hōde epi pinaki tēn kephalēn Iōannou tou baptistou*—head on platter.

"'The king was grieved; but for the sake of his oaths... he commanded it to be given.'"

*Kai lypētheis ho basileus dia tous horkous... ekeleusen dothēnai*—gave.

"'He sent, and beheaded John in the prison.'"

*Kai pempsas apekephalisen Iōannēn en tē phylakē*—beheaded.

"'His disciples came, and took up the corpse, and buried him.'"

*Kai proselthontes hoi mathētai autou ēran to ptōma kai ethapsan auton*—buried.

"'They went and told Yeshua.'"

*Kai elthontes apēngeilan tō Iēsou*—told Yeshua.

**Feeding the Five Thousand (14:13-21):**
**The Key Verses (14:13-17):**
"'When Yeshua heard it, he withdrew from thence in a boat, to a desert place apart.'"

*Akousas de ho Iēsous anechōrēsen ekeithen en ploiō eis erēmon topon kat' idian*—withdrew.

"'When the multitudes heard thereof, they followed him on foot.'"

*Kai akousantes hoi ochloi ēkolouthēsan autō pezē apo tōn poleōn*—followed.

"'He saw a great multitude, and he had compassion on them.'"

*Kai exelthōn eiden polyn ochlon kai esplanchnisthē ep' autois*—compassion.

"'He healed their sick.'"

*Kai etherapeusen tous arrōstous autōn*—healed.

"''Send the multitudes away, that they may go into the villages, and buy themselves food.''"

*Apoluson tous ochlous hina apelthontes eis tas kōmas agorasōsin heautois brōmata*—send away.

"''They have no need to go away; give them to eat.''"

*Ou chreian echousin apelthein dote autois hymeis phagein*—give food.

"''We have here but five loaves, and two fishes.''"

*Ouk echomen hōde ei mē pente artous kai dyo ichthyas*—five loaves, two fish.

**The Key Verses (14:18-21):**
"''Bring them here to me.''"

*Pherete moi hōde autous*—bring.

"'He commanded the multitudes to sit down on the grass.'"

*Kai keleusas tous ochlous anaklithēnai epi tous chortous*—sit.

"'He took the five loaves, and the two fishes, and looking up to heaven, he blessed.'"

*Labōn tous pente artous kai tous dyo ichthyas anablepsas eis ton ouranon eulogēsen*—blessed.

"'Broke and gave the loaves to the disciples, and the disciples to the multitudes.'"

*Kai klasas edōken tois mathētais tous artous hoi de mathētai tois ochlois*—distributed.

"'They all ate, and were filled.'"

*Kai ephagon pantes kai echortasthēsan*—filled.

"'They took up that which remained over of the broken pieces, twelve baskets full.'"

*Kai ēran to perisseuon tōn klasmatōn dōdeka kophinous plēreis*—twelve baskets.

"'About five thousand men, besides women and children.'"

*Hoi de esthiontes ēsan andres hōsei pentakischilioi chōris gynaikōn kai paidiōn*—five thousand.

**Walking on Water (14:22-33):**
**The Key Verses (14:22-27):**
"'He constrained the disciples to enter into the boat.'"

*Ēnankasan tous mathētas embēnai eis to ploion*—constrained.

"'He went up into the mountain apart to pray.'"

*Anebē eis to oros kat' idian proseuxasthai*—pray.

"'The boat was now in the midst of the sea, distressed by the waves.'"

*To de ploion ēdē stadious pollous apo tēs gēs apeichen basanizomenon hypo tōn kymatōn*—distressed.

"'In the fourth watch of the night he came unto them, walking upon the sea.'"

*Tetartē de phylakē tēs nyktos ēlthen pros autous peripatōn epi tēn thalassan*—walking on sea.

**Fourth Watch:**
3-6 AM.

"''It is a ghost'; and they cried out for fear.'"

*Phantasma estin kai apo tou phobou ekraxan*—ghost.

"''Be of good cheer; it is I; be not afraid.''"

*Tharseite egō eimi mē phobeisthe*—I am.

**Egō Eimi:**
"I am"—divine self-identification (cf. Exodus 3:14).

**The Key Verses (14:28-33):**
"''Lord, if it be you, bid me come unto you upon the waters.''"

*Kyrie ei sy ei keleuson me elthein pros se epi ta hydata*—Peter's request.

"''Come.''"

*Elthe*—come.

"'Peter went down from the boat, and walked upon the waters.'"

*Kai katabas apo tou ploiou Petros periepatēsen epi ta hydata*—Peter walked.

"'When he saw the wind, he was afraid; and beginning to sink.'"

*Blepōn de ton anemon ischyron ephobēthē kai arxamenos katapontizesthai*—sinking.

"''Lord, save me.''"

*Kyrie sōson me*—save.

"'Immediately Yeshua stretched forth his hand, and took hold of him.'"

*Eutheōs de ho Iēsous ekteinas tēn cheira epelabeto autou*—took hold.

"''O you of little faith, why did you doubt?''"

*Oligopiste eis ti edistasas*—little faith.

"'When they were gone up into the boat, the wind ceased.'"

*Kai anabantōn autōn eis to ploion ekopasen ho anemos*—wind ceased.

"'They that were in the boat worshipped him.'"

*Hoi de en tō ploiō prosekynēsan autō*—worshipped.

"''Of a truth you are the Son of God.''"

*Alēthōs theou huios ei*—Son of God.

**Healings at Gennesaret (14:34-36):**
**The Key Verses (14:34-36):**
"'They came to the land, unto Gennesaret.'"

*Diaperasantes ēlthon epi tēn gēn eis Gennēsaret*—Gennesaret.

"'They sent into all that region round about, and brought unto him all that were sick.'"

*Apesteilan eis holēn tēn perichōron ekeinēn kai prosēnenkan autō pantas tous kakōs echontas*—brought sick.

"'They besought him that they might only touch the border of his garment.'"

*Kai parekaloun auton hina monon hapsōntai tou kraspedou tou himatiou autou*—touch fringe.

"'As many as touched were made whole.'"

*Kai hosoi hēpsanto diesōthēsan*—made whole.

**Archetypal Layer:** Matthew 14 contains **death of John the Immerser (14:1-12)**: Herod's oath, Herodias's scheming, the head on a platter, **"Yeshua heard it, he withdrew" (14:13)**, **feeding the five thousand (14:13-21)**: compassion, five loaves and two fish, "looking up to heaven, he blessed," all filled, twelve baskets left over, **Yeshua praying alone on the mountain (14:23)**, **walking on water (14:22-33)**: "Be of good cheer; it is I; be not afraid" (egō eimi), Peter walking then sinking, "O you of little faith, why did you doubt?", **"Of a truth you are the Son of God" (14:33)**, and **healings at Gennesaret (14:34-36)**.

**Modern Equivalent:** Matthew 14 juxtaposes death and life. John's execution by Herod (14:1-12) shows the cost of prophetic witness. The feeding miracle (14:13-21) echoes Moses and manna—Yeshua provides abundantly. Walking on water (14:22-33) reveals divine power over chaos; "egō eimi" (14:27) echoes God's name. Peter's attempt (14:28-31) shows faith's reality and fragility. The disciples confess: "Of a truth you are the Son of God" (14:33)—a major christological moment.

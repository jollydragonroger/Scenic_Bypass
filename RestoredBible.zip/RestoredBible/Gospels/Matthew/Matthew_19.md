# Matthew 19: Marriage, Children, and Riches

*From the Greek: Καὶ ἐγένετο ὅτε ἐτέλεσεν ὁ Ἰησοῦς (Kai Egeneto Hote Etelesen ho Iesous) — And It Came to Pass When Yeshua Had Finished*

---

## Marriage and Divorce (19:1-12)

**19:1** And it came to pass when Yeshua had finished these words, he departed from Galilee, and came into the borders of Judaea beyond the Jordan;

**19:2** And great multitudes followed him; and he healed them there.

**19:3** And there came unto him Pharisees, trying him, and saying: "Is it lawful for a man to put away his wife for every cause?"

**19:4** And he answered and said: "Have you not read, that he who made them from the beginning made them male and female,

**19:5** "And said, 'For this cause shall a man leave his father and mother, and shall cleave to his wife; and the two shall become one flesh'?

**19:6** "So that they are no more two, but one flesh. What therefore God has joined together, let not man put asunder."

**19:7** They say unto him: "Why then did Moses command to give a writing of divorcement, and to put her away?"

**19:8** He says unto them: "Moses for your hardness of heart permitted you to put away your wives: but from the beginning it has not been so.

**19:9** "And I say unto you, Whosoever shall put away his wife, except for fornication, and shall marry another, commits adultery: and he that marries her when she is put away commits adultery."

**19:10** The disciples say unto him: "If the case of the man is so with his wife, it is not expedient to marry."

**19:11** But he said unto them: "Not all men can receive this saying, but they to whom it is given.

**19:12** "For there are eunuchs, that were so born from their mother's womb: and there are eunuchs, that were made eunuchs by men: and there are eunuchs, that made themselves eunuchs for the kingdom of heaven's sake. He that is able to receive it, let him receive it."

---

## Blessing the Children (19:13-15)

**19:13** Then were there brought unto him little children, that he should lay his hands on them, and pray: and the disciples rebuked them.

**19:14** But Yeshua said: "Suffer the little children, and forbid them not, to come unto me: for to such belongs the kingdom of heaven."

**19:15** And he laid his hands on them, and departed thence.

---

## The Rich Young Ruler (19:16-30)

**19:16** And behold, one came to him and said: "Teacher, what good thing shall I do, that I may have eternal life?"

**19:17** And he said unto him: "Why do you ask me concerning that which is good? One there is who is good: but if you would enter into life, keep the commandments."

**19:18** He says unto him: "Which?" And Yeshua said: "You shall not kill, You shall not commit adultery, You shall not steal, You shall not bear false witness,

**19:19** "Honour your father and your mother; and, You shall love your neighbour as yourself."

**19:20** The young man says unto him: "All these things have I observed: what lack I yet?"

**19:21** Yeshua said unto him: "If you would be perfect, go, sell that which you have, and give to the poor, and you shall have treasure in heaven: and come, follow me."

**19:22** But when the young man heard the saying, he went away sorrowful; for he was one that had great possessions.

**19:23** And Yeshua said unto his disciples: "Verily I say unto you, It is hard for a rich man to enter into the kingdom of heaven.

**19:24** "And again I say unto you, It is easier for a camel to go through a needle's eye, than for a rich man to enter into the kingdom of God."

**19:25** And when the disciples heard it, they were astonished exceedingly, saying: "Who then can be saved?"

**19:26** And Yeshua looking upon them said unto them: "With men this is impossible; but with God all things are possible."

**19:27** Then answered Peter and said unto him: "Lo, we have left all, and followed you; what then shall we have?"

**19:28** And Yeshua said unto them: "Verily I say unto you, that you who have followed me, in the regeneration when the Son of man shall sit on the throne of his glory, you also shall sit upon twelve thrones, judging the twelve tribes of Israel.

**19:29** "And every one that has left houses, or brethren, or sisters, or father, or mother, or children, or lands, for my name's sake, shall receive a hundredfold, and shall inherit eternal life.

**19:30** "But many shall be last that are first; and first that are last."

---

## Synthesis Notes

**Key Restorations:**

**Marriage and Divorce (19:1-12):**
**The Key Verses (19:3-6):**
"''Is it lawful for a man to put away his wife for every cause?''"

*Ei exestin anthrōpō apolysai tēn gynaika autou kata pasan aitian*—any cause?

**Pharisaic Debate:**
School of Hillel (any cause) vs. School of Shammai (adultery only).

"''Have you not read, that he who made them from the beginning made them male and female?''"

*Ouk anegnōte hoti ho ktisas ap' archēs arsen kai thēly epoiēsen autous*—from beginning.

**Genesis 1:27.**

"''For this cause shall a man leave his father and mother, and shall cleave to his wife.''"

*Heneka toutou kataleipsei anthrōpos ton patera kai tēn mētera kai kollēthēsetai tē gynaiki autou*—leave, cleave.

**Genesis 2:24.**

"''The two shall become one flesh.''"

*Kai esontai hoi dyo eis sarka mian*—one flesh.

"''What therefore God has joined together, let not man put asunder.''"

*Ho oun ho theos synezeuxen anthrōpos mē chōrizetō*—don't separate.

**The Key Verses (19:7-9):**
"''Why then did Moses command to give a writing of divorcement?''"

*Ti oun Mōusēs eneteilato dounai biblion apostasiou kai apolysai autēn*—Moses command?

**Deuteronomy 24:1-4.**

"''Moses for your hardness of heart permitted you.''"

*Pros tēn sklērokardian hymōn epetrepsen hymin*—hardness of heart.

"''But from the beginning it has not been so.''"

*Ap' archēs de ou gegonen houtōs*—not from beginning.

"''Whosoever shall put away his wife, except for fornication, and shall marry another, commits adultery.''"

*Hos an apolysē tēn gynaika autou mē epi porneia kai gamēsē allēn moichatai*—except porneia.

**Porneia:**
Sexual immorality—Matthew's exception clause.

**The Key Verses (19:10-12):**
"''If the case of the man is so with his wife, it is not expedient to marry.''"

*Ei houtōs estin hē aitia tou anthrōpou meta tēs gynaikos ou sympherei gamēsai*—not expedient.

"''Not all men can receive this saying.''"

*Ou pantes chōrousin ton logon touton*—not all.

"''There are eunuchs, that made themselves eunuchs for the kingdom of heaven's sake.''"

*Kai eisin eunouchoi hoitines eunouchisan heautous dia tēn basileian tōn ouranōn*—celibacy.

"''He that is able to receive it, let him receive it.''"

*Ho dynamenos chōrein chōreitō*—able.

**Blessing the Children (19:13-15):**
**The Key Verses (19:13-15):**
"'There were brought unto him little children.'"

*Tote prosēnechthēsan autō paidia*—children.

"'The disciples rebuked them.'"

*Hoi de mathētai epetimēsan autois*—rebuked.

"''Suffer the little children, and forbid them not, to come unto me.''"

*Aphete ta paidia kai mē kōlyete auta elthein pros me*—let come.

"''For to such belongs the kingdom of heaven.''"

*Tōn gar toioutōn estin hē basileia tōn ouranōn*—kingdom.

"'He laid his hands on them.'"

*Kai epitheis tas cheiras autois*—blessed.

**Rich Young Ruler (19:16-30):**
**The Key Verses (19:16-22):**
"''What good thing shall I do, that I may have eternal life?''"

*Didaskale ti agathon poiēsō hina schō zōēn aiōnion*—eternal life.

"''Why do you ask me concerning that which is good? One there is who is good.''"

*Ti me erōtas peri tou agathou heis estin ho agathos*—one good.

"''If you would enter into life, keep the commandments.''"

*Ei de theleis eis tēn zōēn eiselthein tērei tas entolas*—keep commandments.

"''Which?''"

*Poias*—which ones?

"''You shall not kill, You shall not commit adultery, You shall not steal, You shall not bear false witness.''"

*To ou phoneuseis ou moicheuseis ou klepseis ou pseudomartyrēseis*—commandments.

"''Honour your father and your mother.''"

*Tima ton patera kai tēn mētera*—honor parents.

"''You shall love your neighbour as yourself.''"

*Kai agapēseis ton plēsion sou hōs seauton*—love neighbor.

**Leviticus 19:18.**

"''All these things have I observed: what lack I yet?''"

*Panta tauta ephylaxa ti eti hysterō*—what lack?

"''If you would be perfect, go, sell that which you have, and give to the poor.''"

*Ei theleis teleios einai hypage pōlēson sou ta hyparchonta kai dos ptōchois*—sell, give.

"''You shall have treasure in heaven: and come, follow me.''"

*Kai hexeis thēsauron en ouranois kai deuro akolouthei moi*—follow.

"'He went away sorrowful; for he was one that had great possessions.'"

*Apēlthen lypoumenos ēn gar echōn ktēmata polla*—sorrowful.

**The Key Verses (19:23-26):**
"''It is hard for a rich man to enter into the kingdom of heaven.''"

*Dyskolōs plousios eiseleusetai eis tēn basileian tōn ouranōn*—hard.

"''It is easier for a camel to go through a needle's eye.''"

*Eukopōteron estin kamēlon dia trēmatos rhaphidos dielthein*—camel, needle.

"''Than for a rich man to enter into the kingdom of God.''"

*Ē plousion eiselthein eis tēn basileian tou theou*—rich man.

"''Who then can be saved?''"

*Tis ara dynatai sōthēnai*—who saved?

"''With men this is impossible; but with God all things are possible.''"

*Para anthrōpois touto adynaton estin para de theō panta dynata*—with God possible.

**The Key Verses (19:27-30):**
"''We have left all, and followed you; what then shall we have?''"

*Idou hēmeis aphēkamen panta kai ēkolouthēsamen soi ti ara estai hēmin*—what reward?

"''In the regeneration when the Son of man shall sit on the throne of his glory.''"

*En tē palingenesia hotan kathisē ho huios tou anthrōpou epi thronou doxēs autou*—regeneration.

**Palingenesia:**
"Regeneration/renewal"—eschatological renewal.

"''You also shall sit upon twelve thrones, judging the twelve tribes of Israel.''"

*Kathēsesthe kai hymeis epi dōdeka thronous krinontes tas dōdeka phylas tou Israēl*—twelve thrones.

"''Every one that has left houses, or brethren... for my name's sake, shall receive a hundredfold.''"

*Kai pas hostis aphēken oikias ē adelphous... heneken tou onomatos mou hekatontaplasiona lēmpsetai*—hundredfold.

"''And shall inherit eternal life.''"

*Kai zōēn aiōnion klēronomēsei*—eternal life.

"''Many shall be last that are first; and first that are last.''"

*Polloi de esontai prōtoi eschatoi kai eschatoi prōtoi*—first, last.

**Archetypal Layer:** Matthew 19 contains **"Is it lawful for a man to put away his wife for every cause?" (19:3)**, **"from the beginning" (19:4, 8)**, **"he who made them... made them male and female" (19:4)**, **"the two shall become one flesh" (19:5)**, **"What therefore God has joined together, let not man put asunder" (19:6)**, **"Moses for your hardness of heart permitted you" (19:8)**, **exception clause: "except for fornication" (19:9)**, **"eunuchs for the kingdom of heaven's sake" (19:12)**, **"Suffer the little children, and forbid them not, to come unto me" (19:14)**, **"to such belongs the kingdom of heaven" (19:14)**, **"If you would be perfect, go, sell that which you have, and give to the poor" (19:21)**, **"he went away sorrowful; for he was one that had great possessions" (19:22)**, **"It is easier for a camel to go through a needle's eye" (19:24)**, **"With men this is impossible; but with God all things are possible" (19:26)**, **"in the regeneration... you also shall sit upon twelve thrones" (19:28)**, and **"many shall be last that are first; and first that are last" (19:30)**.

**Modern Equivalent:** Matthew 19 addresses marriage, children, and wealth. Yeshua appeals to creation (Genesis 1-2), not Deuteronomy's concession—marriage is lifelong union (19:4-6). Hardness of heart necessitated divorce provisions (19:8). Celibacy for the kingdom is a gift for some (19:12). Children exemplify kingdom membership (19:14). The rich young ruler (19:16-22) kept commandments but couldn't part with wealth—the one thing he lacked. Riches hinder entry (19:23-24) but "with God all things are possible" (19:26). Those who sacrifice for Yeshua receive exponentially more (19:29), and worldly rankings are reversed (19:30).

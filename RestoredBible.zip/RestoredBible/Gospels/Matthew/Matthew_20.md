# Matthew 20: The Laborers, Third Passion Prediction, and Servanthood

*From the Greek: Ὁμοία γάρ ἐστιν ἡ βασιλεία τῶν οὐρανῶν (Homoia Gar Estin hē Basileia tōn Ouranōn) — For the Kingdom of Heaven Is Like*

---

## The Laborers in the Vineyard (20:1-16)

**20:1** "For the kingdom of heaven is like unto a man that is a householder, who went out early in the morning to hire laborers into his vineyard.

**20:2** "And when he had agreed with the laborers for a denarius a day, he sent them into his vineyard.

**20:3** "And he went out about the third hour, and saw others standing in the marketplace idle;

**20:4** "And to them he said: 'Go also into the vineyard, and whatsoever is right I will give you.' And they went their way.

**20:5** "Again he went out about the sixth and the ninth hour, and did likewise.

**20:6** "And about the eleventh hour he went out, and found others standing; and he says unto them: 'Why stand you here all the day idle?'

**20:7** "They say unto him: 'Because no man has hired us.' He says unto them: 'Go also into the vineyard.'

**20:8** "And when even was come, the lord of the vineyard says unto his steward: 'Call the laborers, and pay them their hire, beginning from the last unto the first.'

**20:9** "And when they came that were hired about the eleventh hour, they received every man a denarius.

**20:10** "And when the first came, they supposed that they would receive more; and they likewise received every man a denarius.

**20:11** "And when they received it, they murmured against the householder,

**20:12** "Saying: 'These last have spent but one hour, and you have made them equal unto us, who have borne the burden of the day and the scorching heat.'

**20:13** "But he answered and said to one of them: 'Friend, I do you no wrong: did you not agree with me for a denarius?

**20:14** "'Take up that which is yours, and go your way; it is my will to give unto this last, even as unto you.

**20:15** "'Is it not lawful for me to do what I will with my own? Or is your eye evil, because I am good?'

**20:16** "So the last shall be first, and the first last."

---

## Third Prediction of the Passion (20:17-19)

**20:17** And as Yeshua was going up to Jerusalem, he took the twelve disciples apart, and on the way he said unto them:

**20:18** "Behold, we go up to Jerusalem; and the Son of man shall be delivered unto the chief priests and scribes; and they shall condemn him to death,

**20:19** "And shall deliver him unto the Gentiles to mock, and to scourge, and to crucify: and the third day he shall be raised up."

---

## The Request of Zebedee's Sons (20:20-28)

**20:20** Then came to him the mother of the sons of Zebedee with her sons, worshipping him, and asking a certain thing of him.

**20:21** And he said unto her: "What will you?" She says unto him: "Command that these my two sons may sit, one on your right hand, and one on your left hand, in your kingdom."

**20:22** But Yeshua answered and said: "You know not what you ask. Are you able to drink the cup that I am about to drink?" They say unto him: "We are able."

**20:23** He says unto them: "My cup indeed you shall drink: but to sit on my right hand, and on my left hand, is not mine to give; but it is for them for whom it has been prepared of my Father."

**20:24** And when the ten heard it, they were moved with indignation concerning the two brethren.

**20:25** But Yeshua called them unto him, and said: "You know that the rulers of the Gentiles lord it over them, and their great ones exercise authority over them.

**20:26** "Not so shall it be among you: but whosoever would become great among you shall be your minister;

**20:27** "And whosoever would be first among you shall be your servant:

**20:28** "Even as the Son of man came not to be ministered unto, but to minister, and to give his life a ransom for many."

---

## Two Blind Men at Jericho (20:29-34)

**20:29** And as they went out from Jericho, a great multitude followed him.

**20:30** And behold, two blind men sitting by the way side, when they heard that Yeshua was passing by, cried out, saying: "Lord, have mercy on us, son of David."

**20:31** And the multitude rebuked them, that they should hold their peace: but they cried out the more, saying: "Lord, have mercy on us, son of David."

**20:32** And Yeshua stood still, and called them, and said: "What will you that I should do unto you?"

**20:33** They say unto him: "Lord, that our eyes may be opened."

**20:34** And Yeshua, being moved with compassion, touched their eyes; and straightway they received their sight, and followed him.

---

## Synthesis Notes

**Key Restorations:**

**Laborers in the Vineyard (20:1-16):**
**The Key Verses (20:1-7):**
"''The kingdom of heaven is like unto a man that is a householder.''"

*Homoia gar estin hē basileia tōn ouranōn anthrōpō oikodespotē*—householder.

"''Who went out early in the morning to hire laborers into his vineyard.''"

*Hostis exēlthen hama prōi misthōsasthai ergatas eis ton ampelōna autou*—early morning.

"''When he had agreed with the laborers for a denarius a day.''"

*Symphōnēsas de meta tōn ergatōn ek dēnariou tēn hēmeran*—denarius.

**Denarius:**
Standard day's wage.

"''He went out about the third hour.''"

*Kai exelthōn peri tritēn hōran*—9 AM.

"''About the sixth and the ninth hour.''"

*Peri hektēn kai enatēn hōran*—noon, 3 PM.

"''About the eleventh hour.''"

*Peri de tēn hendekatēn*—5 PM.

"''Why stand you here all the day idle?''"

*Ti hōde hestēkate holēn tēn hēmeran argoi*—idle.

"''Because no man has hired us.''"

*Hoti oudeis hēmas emisthōsato*—not hired.

**The Key Verses (20:8-16):**
"''Call the laborers, and pay them their hire, beginning from the last unto the first.''"

*Kaleson tous ergatas kai apodos autois ton misthon arxamenos apo tōn eschatōn heōs tōn prōtōn*—last to first.

"''When they came that were hired about the eleventh hour, they received every man a denarius.''"

*Kai elthontes hoi peri tēn hendekatēn hōran elabon ana dēnarion*—eleventh hour paid.

"''When the first came, they supposed that they would receive more.''"

*Elthontes de hoi prōtoi enomisan hoti pleion lēmpsontai*—supposed more.

"''They murmured against the householder.''"

*Kai labontes egongyzon kata tou oikodespotou*—murmured.

"''These last have spent but one hour, and you have made them equal unto us.''"

*Houtoi hoi eschatoi mian hōran epoiēsan kai isous hēmin autous epoiēsas*—equal.

"''Who have borne the burden of the day and the scorching heat.''"

*Tois bastasasi to baros tēs hēmeras kai ton kausōna*—burden, heat.

"''Friend, I do you no wrong.''"

*Hetaire ouk adikō se*—no wrong.

"''Did you not agree with me for a denarius?''"

*Ouchi dēnariou synephōnēsas moi*—agreed.

"''It is my will to give unto this last, even as unto you.''"

*Thelō de toutō tō eschatō dounai hōs kai soi*—my will.

"''Is it not lawful for me to do what I will with my own?''"

*Ē ouk exestin moi ho thelō poiēsai en tois emois*—lawful.

"''Is your eye evil, because I am good?''"

*Ē ho ophthalmos sou ponēros estin hoti egō agathos eimi*—evil eye.

"''So the last shall be first, and the first last.''"

*Houtōs esontai hoi eschatoi prōtoi kai hoi prōtoi eschatoi*—reversal.

**Third Passion Prediction (20:17-19):**
**The Key Verses (20:17-19):**
"'As Yeshua was going up to Jerusalem.'"

*Kai anabainōn ho Iēsous eis Hierosolyma*—going up.

"'He took the twelve disciples apart.'"

*Parelaben tous dōdeka mathētas kat' idian*—apart.

"''Behold, we go up to Jerusalem.''"

*Idou anabainomen eis Hierosolyma*—Jerusalem.

"''The Son of man shall be delivered unto the chief priests and scribes.''"

*Kai ho huios tou anthrōpou paradothēsetai tois archiereusin kai grammateusin*—delivered.

"''They shall condemn him to death.''"

*Kai katakrinousin auton thanatō*—condemn.

"''Shall deliver him unto the Gentiles.''"

*Kai paradōsousin auton tois ethnesin*—Gentiles.

"''To mock, and to scourge, and to crucify.''"

*Eis to emaixai kai mastigōsai kai staurōsai*—mock, scourge, crucify.

**Most Detailed Prediction:**
Includes Roman involvement (Gentiles), mocking, scourging, crucifixion.

"''The third day he shall be raised up.''"

*Kai tē tritē hēmera egerthēsetai*—raised.

**Request of Zebedee's Sons (20:20-28):**
**The Key Verses (20:20-23):**
"'The mother of the sons of Zebedee with her sons.'"

*Tote prosēlthen autō hē mētēr tōn huiōn Zebedaiou meta tōn huiōn autēs*—mother.

"''Command that these my two sons may sit, one on your right hand, and one on your left.''"

*Eipe hina kathisōsin houtoi hoi dyo huioi mou heis ek dexiōn sou kai heis ex euōnymōn sou en tē basileia sou*—positions.

"''You know not what you ask.''"

*Ouk oidate ti aiteisthe*—don't know.

"''Are you able to drink the cup that I am about to drink?''"

*Dynasthe piein to potērion ho egō mellō pinein*—cup.

**The Cup:**
Suffering, death.

"''We are able.''"

*Dynametha*—able.

"''My cup indeed you shall drink.''"

*To men potērion mou piesthe*—you will drink.

"''To sit on my right hand, and on my left hand, is not mine to give.''"

*To de kathisai ek dexiōn mou kai ex euōnymōn ouk estin emon dounai*—not mine to give.

"''It is for them for whom it has been prepared of my Father.''"

*All' hois hētoimastai hypo tou patros mou*—prepared by Father.

**The Key Verses (20:24-28):**
"'The ten... were moved with indignation concerning the two brethren.'"

*Kai akousantes hoi deka ēganaktēsan peri tōn dyo adelphōn*—indignation.

"''You know that the rulers of the Gentiles lord it over them.''"

*Oidate hoti hoi archontes tōn ethnōn katakyrieousin autōn*—lord it over.

"''Their great ones exercise authority over them.''"

*Kai hoi megaloi katexousiazousin autōn*—authority over.

"''Not so shall it be among you.''"

*Ouch houtōs estai en hymin*—not so.

"''Whosoever would become great among you shall be your minister.''"

*Hos ean thelē en hymin megas genesthai estai hymōn diakonos*—servant.

**Diakonos:**
"Servant/minister."

"''Whosoever would be first among you shall be your servant.''"

*Kai hos an thelē en hymin einai prōtos estai hymōn doulos*—slave.

**Doulos:**
"Slave"—even stronger than diakonos.

"''The Son of man came not to be ministered unto, but to minister.''"

*Hōsper ho huios tou anthrōpou ouk ēlthen diakonēthēnai alla diakonēsai*—came to serve.

"''To give his life a ransom for many.''"

*Kai dounai tēn psychēn autou lytron anti pollōn*—ransom.

**Lytron Anti Pollōn:**
"Ransom for many"—substitutionary atonement.

**Two Blind Men at Jericho (20:29-34):**
**The Key Verses (20:29-34):**
"'As they went out from Jericho.'"

*Kai ekporeuomenōn autōn apo Ierichō*—Jericho.

"'Two blind men sitting by the way side.'"

*Dyo typhloi kathēmenoi para tēn hodon*—two blind.

"''Lord, have mercy on us, son of David.''"

*Eleēson hēmas kyrie huios David*—son of David.

"'The multitude rebuked them, that they should hold their peace.'"

*Ho de ochlos epetimēsen autois hina siōpēsōsin*—rebuked.

"'They cried out the more.'"

*Hoi de meizon ekraxan*—cried more.

"''What will you that I should do unto you?''"

*Ti thelete poiēsō hymin*—what do you want?

"''Lord, that our eyes may be opened.''"

*Kyrie hina anoigōsin hoi ophthalmoi hēmōn*—opened.

"'Yeshua, being moved with compassion, touched their eyes.'"

*Splanchnistheis de ho Iēsous hēpsato tōn ommatōn autōn*—compassion.

"'Straightway they received their sight, and followed him.'"

*Kai eutheōs aneblepsan kai ēkolouthēsan autō*—followed.

**Archetypal Layer:** Matthew 20 contains **parable of the laborers in the vineyard (20:1-16)**: hired at different hours, all paid equally, **"Is it not lawful for me to do what I will with my own? Or is your eye evil, because I am good?" (20:15)**, **"So the last shall be first, and the first last" (20:16)**, **third passion prediction (20:17-19)**: most detailed—mocking, scourging, crucifixion, resurrection, **mother of James and John requesting positions (20:20-21)**, **"You know not what you ask" (20:22)**, **"Are you able to drink the cup?" (20:22)**, **"the rulers of the Gentiles lord it over them... Not so shall it be among you" (20:25-26)**, **"whosoever would become great among you shall be your minister" (20:26)**, **"the Son of man came not to be ministered unto, but to minister, and to give his life a ransom for many" (20:28)**, and **two blind men healed at Jericho (20:29-34)**.

**Modern Equivalent:** Matthew 20 opens with the vineyard parable (20:1-16) illustrating grace: all receive the same regardless of when they came. The "evil eye" (20:15) is envy at God's generosity. The third passion prediction (20:17-19) is most explicit—crucifixion by Gentiles, then resurrection. The Zebedee sons' request (20:20-21) prompts Yeshua's teaching on servant leadership (20:25-28). Greatness = service; Yeshua came "to give his life a ransom for many" (20:28)—one of the Gospel's clearest atonement statements. The blind men's healing (20:29-34) shows faith's persistence rewarded.

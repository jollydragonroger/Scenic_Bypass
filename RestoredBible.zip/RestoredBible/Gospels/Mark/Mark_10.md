# Mark 10: Marriage, Riches, and the Way to Jerusalem

*From the Greek: Καὶ ἐκεῖθεν ἀναστὰς (Kai Ekeithen Anastas) — And He Arose from Thence*

---

## Teaching on Divorce (10:1-12)

**10:1** And he arose from thence, and comes into the borders of Judaea and beyond the Jordan: and multitudes come together unto him again; and, as he was accustomed, he taught them again.

**10:2** And there came unto him Pharisees, and asked him: "Is it lawful for a man to put away his wife?" trying him.

**10:3** And he answered and said unto them: "What did Moses command you?"

**10:4** And they said: "Moses permitted to write a bill of divorcement, and to put her away."

**10:5** But Yeshua said unto them: "For your hardness of heart he wrote you this commandment.

**10:6** "But from the beginning of the creation, Male and female made he them.

**10:7** "For this cause shall a man leave his father and mother, and shall cleave to his wife;

**10:8** "And the two shall become one flesh: so that they are no more two, but one flesh.

**10:9** "What therefore God has joined together, let not man put asunder."

**10:10** And in the house the disciples asked him again of this matter.

**10:11** And he says unto them: "Whosoever shall put away his wife, and marry another, commits adultery against her:

**10:12** "And if she herself shall put away her husband, and marry another, she commits adultery."

---

## Blessing the Children (10:13-16)

**10:13** And they were bringing unto him little children, that he should touch them: and the disciples rebuked them.

**10:14** But when Yeshua saw it, he was moved with indignation, and said unto them: "Suffer the little children to come unto me; forbid them not: for to such belongs the kingdom of God.

**10:15** "Verily I say unto you, Whosoever shall not receive the kingdom of God as a little child, he shall in no wise enter therein."

**10:16** And he took them in his arms, and blessed them, laying his hands upon them.

---

## The Rich Man (10:17-31)

**10:17** And as he was going forth into the way, there ran one to him, and kneeled to him, and asked him: "Good Teacher, what shall I do that I may inherit eternal life?"

**10:18** And Yeshua said unto him: "Why do you call me good? None is good save one, even God.

**10:19** "You know the commandments: Do not kill, Do not commit adultery, Do not steal, Do not bear false witness, Do not defraud, Honour your father and mother."

**10:20** And he said unto him: "Teacher, all these things have I observed from my youth."

**10:21** And Yeshua looking upon him loved him, and said unto him: "One thing you lack: go, sell whatsoever you have, and give to the poor, and you shall have treasure in heaven: and come, follow me."

**10:22** But his countenance fell at the saying, and he went away sorrowful: for he was one that had great possessions.

**10:23** And Yeshua looked round about, and says unto his disciples: "How hardly shall they that have riches enter into the kingdom of God!"

**10:24** And the disciples were amazed at his words. But Yeshua answers again, and says unto them: "Children, how hard is it for them that trust in riches to enter into the kingdom of God!

**10:25** "It is easier for a camel to go through a needle's eye, than for a rich man to enter into the kingdom of God."

**10:26** And they were astonished exceedingly, saying unto him: "Then who can be saved?"

**10:27** Yeshua looking upon them says: "With men it is impossible, but not with God: for all things are possible with God."

**10:28** Peter began to say unto him: "Lo, we have left all, and have followed you."

**10:29** Yeshua said: "Verily I say unto you, There is no man that has left house, or brethren, or sisters, or mother, or father, or children, or lands, for my sake, and for the good news' sake,

**10:30** "But he shall receive a hundredfold now in this time, houses, and brethren, and sisters, and mothers, and children, and lands, with persecutions; and in the world to come eternal life.

**10:31** "But many that are first shall be last; and the last first."

---

## Third Prediction of the Passion (10:32-34)

**10:32** And they were on the way, going up to Jerusalem; and Yeshua was going before them: and they were amazed; and they that followed were afraid. And he took again the twelve, and began to tell them the things that were to happen unto him,

**10:33** Saying: "Behold, we go up to Jerusalem; and the Son of man shall be delivered unto the chief priests and the scribes; and they shall condemn him to death, and shall deliver him unto the Gentiles:

**10:34** "And they shall mock him, and shall spit upon him, and shall scourge him, and shall kill him; and after three days he shall rise again."

---

## The Request of James and John (10:35-45)

**10:35** And there come near unto him James and John, the sons of Zebedee, saying unto him: "Teacher, we would that you should do for us whatsoever we shall ask of you."

**10:36** And he said unto them: "What would you that I should do for you?"

**10:37** And they said unto him: "Grant unto us that we may sit, one on your right hand, and one on your left hand, in your glory."

**10:38** But Yeshua said unto them: "You know not what you ask. Are you able to drink the cup that I drink? Or to be immersed with the immersion that I am immersed with?"

**10:39** And they said unto him: "We are able." And Yeshua said unto them: "The cup that I drink you shall drink; and with the immersion that I am immersed with shall you be immersed:

**10:40** "But to sit on my right hand or on my left hand is not mine to give; but it is for them for whom it has been prepared."

**10:41** And when the ten heard it, they began to be moved with indignation concerning James and John.

**10:42** And Yeshua called them to him, and says unto them: "You know that they who are accounted to rule over the Gentiles lord it over them; and their great ones exercise authority over them.

**10:43** "But it is not so among you: but whosoever would become great among you, shall be your minister;

**10:44** "And whosoever would be first among you, shall be servant of all.

**10:45** "For the Son of man also came not to be ministered unto, but to minister, and to give his life a ransom for many."

---

## Blind Bartimaeus (10:46-52)

**10:46** And they come to Jericho: and as he went out from Jericho, with his disciples and a great multitude, the son of Timaeus, Bartimaeus, a blind beggar, was sitting by the way side.

**10:47** And when he heard that it was Yeshua the Nazarene, he began to cry out, and say: "Yeshua, son of David, have mercy on me."

**10:48** And many rebuked him, that he should hold his peace: but he cried out the more a great deal: "Son of David, have mercy on me."

**10:49** And Yeshua stood still, and said: "Call him." And they call the blind man, saying unto him: "Be of good cheer: rise, he calls you."

**10:50** And he, casting away his garment, sprang up, and came to Yeshua.

**10:51** And Yeshua answered him, and said: "What will you that I should do unto you?" And the blind man said unto him: "Rabboni, that I may receive my sight."

**10:52** And Yeshua said unto him: "Go your way; your faith has made you whole." And straightway he received his sight, and followed him in the way.

---

## Synthesis Notes

**Key Restorations:**

**Teaching on Divorce (10:1-12):**
**The Key Verses (10:1-9):**
"''Is it lawful for a man to put away his wife?' trying him.'"

*Ei exestin andri gynaika apolysai peirazontes auton*—testing.

"''What did Moses command you?''"

*Ti hymin eneteilato Mōusēs*—Moses command?

"''Moses permitted to write a bill of divorcement.''"

*Epetrepsen Mōusēs biblion apostasiou grapsai kai apolysai*—Deuteronomy 24:1.

"''For your hardness of heart he wrote you this commandment.''"

*Pros tēn sklērokardian hymōn egrapsen hymin tēn entolēn tautēn*—hardness.

"''From the beginning of the creation, Male and female made he them.''"

*Apo de archēs ktiseōs arsen kai thēly epoiēsen autous*—Genesis 1:27.

"''For this cause shall a man leave his father and mother.''"

*Heneken toutou kataleipsei anthrōpos ton patera autou kai tēn mētera*—Genesis 2:24.

"''The two shall become one flesh.''"

*Kai esontai hoi dyo eis sarka mian*—one flesh.

"''What therefore God has joined together, let not man put asunder.''"

*Ho oun ho theos synezeuxen anthrōpos mē chōrizetō*—don't separate.

**The Key Verses (10:10-12):**
"''Whosoever shall put away his wife, and marry another, commits adultery against her.''"

*Hos an apolysē tēn gynaika autou kai gamēsē allēn moichatai ep' autēn*—adultery.

"''If she herself shall put away her husband, and marry another, she commits adultery.''"

*Kai ean autē apolysasa ton andra autēs gamēsē allon moichatai*—wife divorcing.

**Roman Context:**
Women could initiate divorce under Roman law.

**Blessing the Children (10:13-16):**
**The Key Verses (10:13-16):**
"'They were bringing unto him little children, that he should touch them.'"

*Kai prosepheron autō paidia hina autōn hapsētai*—touch.

"'The disciples rebuked them.'"

*Hoi de mathētai epetimēsan autois*—rebuked.

"'Yeshua saw it, he was moved with indignation.'"

*Idōn de ho Iēsous ēganaktēsen*—indignation.

**Only Mark:**
Mentions Yeshua's indignation.

"''Suffer the little children to come unto me; forbid them not.''"

*Aphete ta paidia erchesthai pros me mē kōlyete auta*—let come.

"''To such belongs the kingdom of God.''"

*Tōn gar toioutōn estin hē basileia tou theou*—kingdom.

"''Whosoever shall not receive the kingdom of God as a little child.''"

*Hos an mē dexētai tēn basileian tou theou hōs paidion*—as child.

"'He took them in his arms, and blessed them, laying his hands upon them.'"

*Kai enankalisamenos auta kateulogei titheis tas cheiras ep' auta*—blessed.

**Rich Man (10:17-31):**
**The Key Verses (10:17-22):**
"''Good Teacher, what shall I do that I may inherit eternal life?''"

*Didaskale agathe ti poiēsō hina zōēn aiōnion klēronomēsō*—eternal life.

"''Why do you call me good? None is good save one, even God.''"

*Ti me legeis agathon oudeis agathos ei mē heis ho theos*—God good.

"''Do not defraud.''"

*Mē aposterēsēs*—unique to Mark.

"''All these things have I observed from my youth.''"

*Tauta panta ephylaxamēn ek neotētos mou*—kept.

"'Yeshua looking upon him loved him.'"

*Ho de Iēsous emblepsas autō ēgapēsen auton*—loved him.

**Only Mark:**
Mentions Yeshua loving him.

"''One thing you lack.''"

*Hen se hysterei*—one thing.

"''Go, sell whatsoever you have, and give to the poor.''"

*Hypage hosa echeis pōlēson kai dos tois ptōchois*—sell, give.

"''You shall have treasure in heaven: and come, follow me.''"

*Kai hexeis thēsauron en ouranō kai deuro akolouthei moi*—follow.

"'His countenance fell... for he was one that had great possessions.'"

*Ho de stygnasas epi tō logō apēlthen lypoumenos ēn gar echōn ktēmata polla*—great possessions.

**The Key Verses (10:23-31):**
"''How hardly shall they that have riches enter into the kingdom of God!''"

*Pōs dyskolōs hoi ta chrēmata echontes eis tēn basileian tou theou eiseleusontai*—hard.

"''It is easier for a camel to go through a needle's eye.''"

*Eukopōteron estin kamēlon dia tēs trymalias tēs rhaphidos dielthein*—camel, needle.

"''Then who can be saved?''"

*Kai tis dynatai sōthēnai*—who saved?

"''With men it is impossible, but not with God: for all things are possible with God.''"

*Para anthrōpois adynaton all' ou para theō panta gar dynata para tō theō*—possible.

"''We have left all, and have followed you.''"

*Idou hēmeis aphēkamen panta kai ēkolouthēkamen soi*—left all.

"''There is no man that has left house... for my sake, and for the good news' sake.''"

*Oudeis estin hos aphēken oikian... heneken emou kai heneken tou euangeliou*—for Gospel's sake.

"''He shall receive a hundredfold now in this time... with persecutions.''"

*Ean mē labē hekatontaplasiona nyn en tō kairō toutō... meta diōgmōn*—with persecutions.

**Only Mark:**
Adds "with persecutions."

"''Many that are first shall be last; and the last first.''"

*Polloi de esontai prōtoi eschatoi kai hoi eschatoi prōtoi*—reversal.

**Third Passion Prediction (10:32-34):**
**The Key Verses (10:32-34):**
"'They were on the way, going up to Jerusalem; and Yeshua was going before them.'"

*Ēsan de en tē hodō anabainontes eis Hierosolyma kai ēn proagōn autous ho Iēsous*—going before.

"'They were amazed; and they that followed were afraid.'"

*Kai ethambοunto hoi de akolouthountes ephobounto*—afraid.

"''The Son of man shall be delivered unto the chief priests and the scribes.''"

*Ho huios tou anthrōpou paradothēsetai tois archiereusin kai tois grammateusin*—delivered.

"''They shall condemn him to death, and shall deliver him unto the Gentiles.''"

*Kai katakrinousin auton thanatō kai paradōsousin auton tois ethnesin*—Gentiles.

"''They shall mock him, and shall spit upon him, and shall scourge him, and shall kill him.''"

*Kai empaixousin autō kai emptysousin autō kai mastigōsousin auton kai apoktenousin*—details.

"''After three days he shall rise again.''"

*Kai meta treis hēmeras anastēsetai*—rise.

**Request of James and John (10:35-45):**
**The Key Verses (10:35-40):**
"''Grant unto us that we may sit, one on your right hand, and one on your left hand, in your glory.''"

*Dos hēmin hina heis sou ek dexiōn kai heis ex aristērōn kathisōmen en tē doxē sou*—positions.

"''You know not what you ask.''"

*Ouk oidate ti aiteisthe*—don't know.

"''Are you able to drink the cup that I drink? Or to be immersed with the immersion that I am immersed with?''"

*Dynasthe piein to potērion ho egō pinō ē to baptisma ho egō baptizomai baptisthēnai*—cup, immersion.

"''We are able.' 'The cup that I drink you shall drink.''"

*Dynametha... to potērion ho egō pinō piesthe*—you will drink.

"''To sit on my right hand or on my left hand is not mine to give.''"

*To de kathisai ek dexiōn mou ē ex euōnymōn ouk estin emon dounai*—not mine.

**The Key Verses (10:41-45):**
"'The ten heard it, they began to be moved with indignation.'"

*Kai akousantes hoi deka ērxanto aganaktein peri Iakōbou kai Iōannou*—indignation.

"''They who are accounted to rule over the Gentiles lord it over them.''"

*Hoi dokountes archein tōn ethnōn katakyrieousin autōn*—lord it over.

"''It is not so among you.''"

*Ouch houtōs de estin en hymin*—not so.

"''Whosoever would become great among you, shall be your minister.''"

*Hos an thelē megas genesthai en hymin estai hymōn diakonos*—servant.

"''Whosoever would be first among you, shall be servant of all.''"

*Kai hos an thelē en hymin einai prōtos estai pantōn doulos*—slave.

"''The Son of man also came not to be ministered unto, but to minister.''"

*Kai gar ho huios tou anthrōpou ouk ēlthen diakonēthēnai alla diakonēsai*—to serve.

"''To give his life a ransom for many.''"

*Kai dounai tēn psychēn autou lytron anti pollōn*—ransom.

**Lytron Anti Pollōn:**
"Ransom for many"—substitutionary language.

**Blind Bartimaeus (10:46-52):**
**The Key Verses (10:46-52):**
"'The son of Timaeus, Bartimaeus, a blind beggar.'"

*Ho huios Timaiou Bartimaios typhlos prosaitēs*—Bartimaeus.

"''Yeshua, son of David, have mercy on me.''"

*Huie David Iēsou eleēson me*—son of David.

"'Many rebuked him... but he cried out the more.'"

*Kai epetimōn autō polloi... ho de pollō mallon ekrazen*—cried more.

"''Call him.' And they call the blind man, saying: 'Be of good cheer: rise, he calls you.''"

*Phōnēsate auton kai phōnousin ton typhlon legontes autō tharsei egeire phōnei se*—calls.

"'He, casting away his garment, sprang up, and came to Yeshua.'"

*Ho de apobalōn to himation autou anapēdēsas ēlthen pros ton Iēsoun*—sprang up.

"''Rabboni, that I may receive my sight.''"

*Rabbouni hina anablepsō*—Rabboni.

"''Go your way; your faith has made you whole.''"

*Hypage hē pistis sou sesōken se*—faith.

"'He received his sight, and followed him in the way.'"

*Kai euthys aneblepsen kai ēkolouthei autō en tē hodō*—followed.

**Archetypal Layer:** Mark 10 contains **teaching on divorce (10:1-12)**: "For your hardness of heart" (10:5), "from the beginning of the creation" (10:6), "What therefore God has joined together, let not man put asunder" (10:9), **blessing the children (10:13-16)**: Yeshua's indignation (10:14), "to such belongs the kingdom of God" (10:14), "Whosoever shall not receive the kingdom of God as a little child" (10:15), **rich man (10:17-31)**: "Yeshua looking upon him loved him" (10:21), "One thing you lack" (10:21), "It is easier for a camel to go through a needle's eye" (10:25), "With men it is impossible, but not with God" (10:27), "with persecutions" (10:30), **third passion prediction (10:32-34)**: most detailed, **James and John's request (10:35-45)**: "You know not what you ask" (10:38), "the cup... the immersion" (10:38), **"It is not so among you" (10:43)**, **"The Son of man also came not to be ministered unto, but to minister, and to give his life a ransom for many" (10:45)**, and **blind Bartimaeus (10:46-52)**: "Rabboni, that I may receive my sight" (10:51), "your faith has made you whole" (10:52), "followed him in the way" (10:52).

**Modern Equivalent:** Mark 10 prepares for Jerusalem. Divorce teaching (10:1-12) appeals to creation, not Mosaic concession. Children (10:13-16) exemplify kingdom reception. The rich man (10:17-22) is loved by Yeshua but goes away sorrowful—riches are hard obstacles (10:23-25), yet "with God all things are possible" (10:27). The third passion prediction (10:32-34) is most detailed. James and John's request (10:35-45) prompts the Gospel's central saying: the Son of man came "to give his life a ransom for many" (10:45). Bartimaeus (10:46-52) contrasts with the disciples' blindness—he sees and follows "in the way" (10:52).

# Mark 5: Power over Demons, Disease, and Death

*From the Greek: Καὶ ἦλθον εἰς τὸ πέραν τῆς θαλάσσης (Kai Ēlthon eis to Peran tēs Thalassēs) — And They Came to the Other Side of the Sea*

---

## The Gerasene Demoniac (5:1-20)

**5:1** And they came to the other side of the sea, into the country of the Gerasenes.

**5:2** And when he was come out of the boat, straightway there met him out of the tombs a man with an unclean spirit,

**5:3** Who had his dwelling in the tombs: and no man could any more bind him, no, not with a chain;

**5:4** Because that he had been often bound with fetters and chains, and the chains had been rent asunder by him, and the fetters broken in pieces: and no man had strength to tame him.

**5:5** And always, night and day, in the tombs and in the mountains, he was crying out, and cutting himself with stones.

**5:6** And when he saw Yeshua from afar, he ran and worshipped him;

**5:7** And crying out with a loud voice, he says: "What have I to do with you, Yeshua, Son of the Most High God? I adjure you by God, torment me not."

**5:8** For he said unto him: "Come forth, you unclean spirit, out of the man."

**5:9** And he asked him: "What is your name?" And he says unto him: "My name is Legion; for we are many."

**5:10** And he besought him much that he would not send them away out of the country.

**5:11** Now there was there on the mountain side a great herd of swine feeding.

**5:12** And they besought him, saying: "Send us into the swine, that we may enter into them."

**5:13** And he gave them leave. And the unclean spirits came out, and entered into the swine: and the herd rushed down the steep into the sea, in number about two thousand; and they were drowned in the sea.

**5:14** And they that fed them fled, and told it in the city, and in the country. And they came to see what it was that had come to pass.

**5:15** And they come to Yeshua, and behold him that was possessed with demons sitting, clothed and in his right mind, even him that had the legion: and they were afraid.

**5:16** And they that saw it declared unto them how it befell him that was possessed with demons, and concerning the swine.

**5:17** And they began to beseech him to depart from their borders.

**5:18** And as he was entering into the boat, he that had been possessed with demons besought him that he might be with him.

**5:19** And he permitted him not, but says unto him: "Go to your house unto your friends, and tell them how great things the Lord has done for you, and how he had mercy on you."

**5:20** And he went his way, and began to proclaim in Decapolis how great things Yeshua had done for him: and all men marvelled.

---

## Jairus's Daughter and the Woman with the Issue (5:21-43)

**5:21** And when Yeshua had crossed over again in the boat unto the other side, a great multitude was gathered unto him; and he was by the sea.

**5:22** And there comes one of the rulers of the synagogue, Jairus by name; and seeing him, he falls at his feet,

**5:23** And beseeches him much, saying: "My little daughter is at the point of death: I pray, come and lay your hands on her, that she may be made whole, and live."

**5:24** And he went with him; and a great multitude followed him, and they thronged him.

**5:25** And a woman, who had an issue of blood twelve years,

**5:26** And had suffered many things of many physicians, and had spent all that she had, and was nothing bettered, but rather grew worse,

**5:27** Having heard the things concerning Yeshua, came in the crowd behind, and touched his garment.

**5:28** For she said: "If I touch but his garments, I shall be made whole."

**5:29** And straightway the fountain of her blood was dried up; and she felt in her body that she was healed of her plague.

**5:30** And straightway Yeshua, perceiving in himself that the power proceeding from him had gone forth, turned him about in the crowd, and said: "Who touched my garments?"

**5:31** And his disciples said unto him: "You see the multitude thronging you, and you say, 'Who touched me?'"

**5:32** And he looked round about to see her that had done this thing.

**5:33** But the woman fearing and trembling, knowing what had been done to her, came and fell down before him, and told him all the truth.

**5:34** And he said unto her: "Daughter, your faith has made you whole; go in peace, and be whole of your plague."

**5:35** While he yet spoke, they come from the ruler of the synagogue's house, saying: "Your daughter is dead: why trouble the Teacher any further?"

**5:36** But Yeshua, not heeding the word spoken, says unto the ruler of the synagogue: "Fear not, only believe."

**5:37** And he permitted no man to follow with him, save Peter, and James, and John the brother of James.

**5:38** And they come to the house of the ruler of the synagogue; and he beholds a tumult, and many weeping and wailing greatly.

**5:39** And when he was entered in, he says unto them: "Why make you a tumult, and weep? The child is not dead, but sleeps."

**5:40** And they laughed him to scorn. But he, having put them all forth, takes the father of the child and her mother and them that were with him, and goes in where the child was.

**5:41** And taking the child by the hand, he says unto her: "Talitha cumi"; which is, being interpreted, "Damsel, I say unto you, Arise."

**5:42** And straightway the damsel rose up, and walked; for she was twelve years old. And they were amazed straightway with a great amazement.

**5:43** And he charged them much that no man should know this: and he commanded that something should be given her to eat.

---

## Synthesis Notes

**Key Restorations:**

**Gerasene Demoniac (5:1-20):**
**The Key Verses (5:1-5):**
"'They came to the other side of the sea, into the country of the Gerasenes.'"

*Kai ēlthon eis to peran tēs thalassēs eis tēn chōran tōn Gerasēnōn*—Gerasenes.

"'There met him out of the tombs a man with an unclean spirit.'"

*Euthys hypēntēsen autō ek tōn mnēmeiōn anthrōpos en pneumati akathartō*—from tombs.

"'No man could any more bind him, no, not with a chain.'"

*Kai oudeis edynato auton dēsai oude halysei*—couldn't bind.

"'The chains had been rent asunder by him, and the fetters broken in pieces.'"

*Dia to auton pollakis pedais kai halysesin dedesthai kai diespasthai hyp' autou tas halyseis kai tas pedas syntetriphthai*—broken.

"'No man had strength to tame him.'"

*Kai oudeis ischyen auton damasai*—untameable.

"'Always, night and day, in the tombs and in the mountains, he was crying out, and cutting himself with stones.'"

*Kai dia pantos nyktos kai hēmeras en tois mnēmasin kai en tois oresin ēn krazōn kai katakoptōn heauton lithois*—self-harm.

**The Key Verses (5:6-13):**
"'When he saw Yeshua from afar, he ran and worshipped him.'"

*Kai idōn ton Iēsoun apo makrothen edramen kai prosekynēsen autō*—worshipped.

"''What have I to do with you, Yeshua, Son of the Most High God?''"

*Ti emoi kai soi Iēsou huie tou theou tou hypsistou*—Most High God.

"''I adjure you by God, torment me not.''"

*Horkizō se ton theon mē me basanisēs*—adjure.

"''Come forth, you unclean spirit, out of the man.''"

*Exelthe to pneuma to akatharton ek tou anthrōpou*—come forth.

"''What is your name?' And he says unto him: 'My name is Legion; for we are many.''"

*Ti onoma soi kai legei autō Legiōn onoma moi hoti polloi esmen*—Legion.

**Legion:**
Roman military unit of ~6,000 soldiers.

"'The herd rushed down the steep into the sea, in number about two thousand.'"

*Kai hōrmēsen hē agelē kata tou krēmnou eis tēn thalassan hōs dischilioi*—two thousand swine.

**The Key Verses (5:14-20):**
"'They behold him that was possessed with demons sitting, clothed and in his right mind.'"

*Kai theorousin ton daimonizomenon kathēmenon himatismenon kai sōphronounta*—transformed.

"'They were afraid.'"

*Kai ephobēthēsan*—afraid.

"'They began to beseech him to depart from their borders.'"

*Kai ērxanto parakalein auton apelthein apo tōn horiōn autōn*—depart.

"''Go to your house unto your friends, and tell them how great things the Lord has done for you.''"

*Hypage eis ton oikon sou pros tous sous kai apangeilon autois hosa ho kyrios soi pepoiēken*—tell.

**Exception to Messianic Secret:**
In Gentile territory, told to proclaim.

"'He went his way, and began to proclaim in Decapolis.'"

*Kai apēlthen kai ērxato kēryssein en tē Dekapolei*—Decapolis.

**Jairus's Daughter and the Woman (5:21-43):**
**The Key Verses (5:21-24):**
"'One of the rulers of the synagogue, Jairus by name.'"

*Heis tōn archisynagōgōn onomati Iairos*—Jairus.

"''My little daughter is at the point of death.''"

*To thygatrion mou eschatōs echei*—dying.

"''Come and lay your hands on her, that she may be made whole, and live.''"

*Hina elthōn epithēs tas cheiras autē hina sōthē kai zēsē*—lay hands.

**The Key Verses (5:25-34):**
"'A woman, who had an issue of blood twelve years.'"

*Kai gynē ousa en rhysei haimatos dōdeka etē*—twelve years.

"'Had suffered many things of many physicians, and had spent all that she had.'"

*Kai polla pathousa hypo pollōn iatrōn kai dapanēsasa ta par' autēs panta*—suffered, spent.

"'Was nothing bettered, but rather grew worse.'"

*Kai mēden ōphelētheisa alla mallon eis to cheiron elthousa*—worse.

"''If I touch but his garments, I shall be made whole.''"

*Ean hapsōmai kan tōn himatiōn autou sōthēsomai*—touch garments.

"'Straightway the fountain of her blood was dried up.'"

*Kai euthys exēranthē hē pēgē tou haimatos autēs*—healed.

"'She felt in her body that she was healed of her plague.'"

*Kai egnō tō sōmati hoti iatai apo tēs mastigos*—felt healed.

"'Yeshua, perceiving in himself that the power proceeding from him had gone forth.'"

*Kai euthys ho Iēsous epignous en heautō tēn ex autou dynamin exelthousan*—power gone.

"''Who touched my garments?''"

*Tis mou hēpsato tōn himatiōn*—who touched?

"'The woman fearing and trembling... came and fell down before him, and told him all the truth.'"

*Hē de gynē phobētheisa kai tremousa... ēlthen kai prosepesen autō kai eipen autō pasan tēn alētheian*—truth.

"''Daughter, your faith has made you whole.''"

*Thygatēr hē pistis sou sesōken se*—faith saves.

"''Go in peace, and be whole of your plague.''"

*Hypage eis eirēnēn kai isthi hygiēs apo tēs mastigos sou*—peace.

**The Key Verses (5:35-43):**
"''Your daughter is dead: why trouble the Teacher any further?''"

*Hē thugatēr sou apethanen ti eti skylleis ton didaskalon*—dead.

"''Fear not, only believe.''"

*Mē phobou monon pisteue*—only believe.

"'He permitted no man to follow with him, save Peter, and James, and John.'"

*Kai ouk aphēken oudena met' autou synakolouthēsai ei mē ton Petron kai Iakōbon kai Iōannēn*—inner three.

"''Why make you a tumult, and weep? The child is not dead, but sleeps.''"

*Ti thorubeisthe kai klaiete to paidion ouk apethanen alla katheudei*—sleeps.

"'They laughed him to scorn.'"

*Kai kategelōn autou*—laughed.

"''Talitha cumi'; which is, being interpreted, 'Damsel, I say unto you, Arise.''"

*Talitha koum ho estin methermēneuomenon to korasion soi legō egeire*—Aramaic.

**Talitha Cumi:**
Aramaic: "Little girl, arise!"

"'Straightway the damsel rose up, and walked; for she was twelve years old.'"

*Kai euthys anestē to korasion kai periepatei ēn gar etōn dōdeka*—twelve years.

**Twelve Years:**
Woman suffered twelve years; girl was twelve years old.

"'He charged them much that no man should know this.'"

*Kai diesteilato autois polla hina mēdeis gnoi touto*—messianic secret.

"'He commanded that something should be given her to eat.'"

*Kai eipen dothēnai autē phagein*—eat.

**Archetypal Layer:** Mark 5 contains **the Gerasene demoniac (5:1-20)**: man living in tombs, unchainable, self-harming, **"What have I to do with you, Yeshua, Son of the Most High God?" (5:7)**, **"My name is Legion; for we are many" (5:9)**, **swine rush into sea (5:13)**, **"sitting, clothed and in his right mind" (5:15)**, **"Go... and tell them how great things the Lord has done for you" (5:19)**, **Jairus's daughter (5:21-24, 35-43)**, **woman with the issue of blood twelve years (5:25-34)** (intercalated story), **"had suffered many things of many physicians... was nothing bettered, but rather grew worse" (5:26)**, **"If I touch but his garments, I shall be made whole" (5:28)**, **"Daughter, your faith has made you whole" (5:34)**, **"Fear not, only believe" (5:36)**, **"Talitha cumi" (Aramaic) (5:41)**, **girl twelve years old rises (5:42)**, and **"he commanded that something should be given her to eat" (5:43)**.

**Modern Equivalent:** Mark 5 demonstrates power over demons, disease, and death. The Gerasene demoniac (5:1-20) is Mark's most dramatic exorcism—a man transformed from tomb-dwelling self-destruction to "sitting, clothed and in his right mind" (5:15). In Gentile territory, he's told to proclaim (5:19). The intercalated story (5:21-43) connects two "daughters" and the number twelve. The woman's faith (5:34) and Jairus's faith (5:36) are emphasized. "Talitha cumi" (5:41) preserves Yeshua's Aramaic—the girl immediately rises and walks. The practical command to feed her (5:43) confirms physical resurrection.

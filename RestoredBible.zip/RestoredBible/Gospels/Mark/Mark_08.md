# Mark 8: The Turning Point — Peter's Confession

*From the Greek: Ἐν ἐκείναις ταῖς ἡμέραις (En Ekeinais tais Hēmerais) — In Those Days*

---

## Feeding the Four Thousand (8:1-10)

**8:1** In those days, when there was again a great multitude, and they had nothing to eat, he called unto him his disciples, and says unto them:

**8:2** "I have compassion on the multitude, because they continue with me now three days, and have nothing to eat:

**8:3** "And if I send them away fasting to their home, they will faint on the way; and some of them are come from far."

**8:4** And his disciples answered him: "Whence shall one be able to fill these men with bread here in a desert place?"

**8:5** And he asked them: "How many loaves have you?" And they said: "Seven."

**8:6** And he commanded the multitude to sit down on the ground: and he took the seven loaves, and having given thanks, he broke, and gave to his disciples, to set before them; and they set them before the multitude.

**8:7** And they had a few small fishes: and having blessed them, he commanded to set these also before them.

**8:8** And they ate, and were filled: and they took up, of broken pieces that remained over, seven baskets.

**8:9** And they were about four thousand: and he sent them away.

**8:10** And straightway he entered into the boat with his disciples, and came into the parts of Dalmanutha.

---

## The Pharisees Demand a Sign (8:11-13)

**8:11** And the Pharisees came forth, and began to question with him, seeking of him a sign from heaven, trying him.

**8:12** And he sighed deeply in his spirit, and says: "Why does this generation seek a sign? Verily I say unto you, There shall no sign be given unto this generation."

**8:13** And he left them, and again entering into the boat departed to the other side.

---

## The Leaven of the Pharisees and Herod (8:14-21)

**8:14** And they forgot to take bread; and they had not in the boat with them more than one loaf.

**8:15** And he charged them, saying: "Take heed, beware of the leaven of the Pharisees and the leaven of Herod."

**8:16** And they reasoned one with another, saying: "We have no bread."

**8:17** And Yeshua perceiving it says unto them: "Why reason you, because you have no bread? Do you not yet perceive, neither understand? Have you your heart hardened?

**8:18** "Having eyes, see you not? And having ears, hear you not? And do you not remember?

**8:19** "When I broke the five loaves among the five thousand, how many baskets full of broken pieces took you up?" They say unto him: "Twelve."

**8:20** "And when the seven among the four thousand, how many baskets full of broken pieces took you up?" And they say unto him: "Seven."

**8:21** And he said unto them: "Do you not yet understand?"

---

## The Blind Man at Bethsaida (8:22-26)

**8:22** And they come unto Bethsaida. And they bring to him a blind man, and beseech him to touch him.

**8:23** And he took hold of the blind man by the hand, and brought him out of the village; and when he had spat on his eyes, and laid his hands upon him, he asked him: "See you aught?"

**8:24** And he looked up, and said: "I see men; for I behold them as trees, walking."

**8:25** Then again he laid his hands upon his eyes; and he looked steadfastly, and was restored, and saw all things clearly.

**8:26** And he sent him away to his home, saying: "Do not even enter into the village."

---

## Peter's Confession (8:27-30)

**8:27** And Yeshua went forth, and his disciples, into the villages of Caesarea Philippi: and on the way he asked his disciples, saying unto them: "Who do men say that I am?"

**8:28** And they told him, saying: "John the Immerser; and others, Elijah; but others, One of the prophets."

**8:29** And he asked them: "But who say you that I am?" Peter answers and says unto him: "You are the Anointed."

**8:30** And he charged them that they should tell no man of him.

---

## First Prediction of the Passion (8:31-33)

**8:31** And he began to teach them, that the Son of man must suffer many things, and be rejected by the elders, and the chief priests, and the scribes, and be killed, and after three days rise again.

**8:32** And he spoke the saying openly. And Peter took him, and began to rebuke him.

**8:33** But he turning about, and seeing his disciples, rebuked Peter, and says: "Get behind me, Satan; for you mind not the things of God, but the things of men."

---

## Taking Up the Cross (8:34-9:1)

**8:34** And he called unto him the multitude with his disciples, and said unto them: "If any man would come after me, let him deny himself, and take up his cross, and follow me.

**8:35** "For whosoever would save his life shall lose it; and whosoever shall lose his life for my sake and the good news' sake shall save it.

**8:36** "For what does it profit a man, to gain the whole world, and forfeit his life?

**8:37** "For what should a man give in exchange for his life?

**8:38** "For whosoever shall be ashamed of me and of my words in this adulterous and sinful generation, the Son of man also shall be ashamed of him, when he comes in the glory of his Father with the holy angels."

**9:1** And he said unto them: "Verily I say unto you, There are some here of them that stand by, who shall in no wise taste of death, till they see the kingdom of God come with power."

---

## Synthesis Notes

**Key Restorations:**

**Feeding the Four Thousand (8:1-10):**
**The Key Verses (8:1-10):**
"''I have compassion on the multitude.''"

*Splanchnizomai epi ton ochlon*—compassion.

"''They continue with me now three days, and have nothing to eat.''"

*Hoti ēdē hēmerais trisin prosmenousin moi kai ouk echousin ti phagōsin*—three days.

"''If I send them away fasting to their home, they will faint on the way.''"

*Kai ean apolusō autous nēsteis eis oikon autōn eklythēsontai en tē hodō*—faint.

"''Whence shall one be able to fill these men with bread here in a desert place?''"

*Pothen toutous dynēsetai tis hōde chortasai artōn ep' erēmias*—where from?

"''How many loaves have you?' And they said: 'Seven.''"

*Posous echete artous hoi de eipan hepta*—seven.

"'They took up, of broken pieces that remained over, seven baskets.'"

*Kai ēran perisseumata klasmatōn hepta spyridas*—seven baskets.

**Spyris:**
Large basket (different from *kophinos* in 6:43).

"'They were about four thousand.'"

*Ēsan de hōs tetrakischilioi*—four thousand.

**Pharisees Demand a Sign (8:11-13):**
**The Key Verses (8:11-13):**
"'The Pharisees came forth, and began to question with him, seeking of him a sign from heaven.'"

*Kai exēlthon hoi Pharisaioi kai ērxanto syzētein autō zētountes par' autou sēmeion apo tou ouranou*—sign.

"'He sighed deeply in his spirit.'"

*Kai anastenaxas tō pneumati autou*—sighed.

"''Why does this generation seek a sign?''"

*Ti hē genea hautē zētei sēmeion*—why seek?

"''There shall no sign be given unto this generation.''"

*Ei dothēsetai tē genea tautē sēmeion*—no sign.

**Hebrew Oath Formula:**
"If a sign be given..." = emphatic denial.

**Leaven of the Pharisees and Herod (8:14-21):**
**The Key Verses (8:14-21):**
"'They had not in the boat with them more than one loaf.'"

*Kai ei mē hena arton ouk eichon meth' heautōn en tō ploiō*—one loaf.

"''Beware of the leaven of the Pharisees and the leaven of Herod.''"

*Horate blepete apo tēs zymēs tōn Pharisaiōn kai tēs zymēs Hērōdou*—leaven.

"'They reasoned one with another, saying: We have no bread.'"

*Kai dielogizonto pros allēlous hoti artous ouk echousin*—no bread.

"''Do you not yet perceive, neither understand? Have you your heart hardened?''"

*Oupō noeite oude syniete pepōrōmenēn echete tēn kardian hymōn*—hardened heart.

"''Having eyes, see you not? And having ears, hear you not?''"

*Ophthalmous echontes ou blepete kai ōta echontes ouk akouete*—Jeremiah 5:21.

"''When I broke the five loaves among the five thousand, how many baskets full... took you up?' 'Twelve.''"

*Hote tous pente artous eklasa eis tous pentakischilious posous kophinous klasmatōn plēreis ērate legousin autō dōdeka*—twelve.

"''When the seven among the four thousand... how many baskets?' 'Seven.''"

*Hote tous hepta eis tous tetrakischilious posōn spyridōn plērōmata klasmatōn ērate kai legousin hepta*—seven.

"''Do you not yet understand?''"

*Oupō syniete*—don't understand?

**Blind Man at Bethsaida (8:22-26):**
**The Key Verses (8:22-26):**
"'They bring to him a blind man, and beseech him to touch him.'"

*Kai pherousin autō typhlon kai parakalousin auton hina autou hapsētai*—touch.

"'He took hold of the blind man by the hand, and brought him out of the village.'"

*Kai epilabomenos tēs cheiros tou typhlou exēnenken auton exō tēs kōmēs*—outside village.

"'When he had spat on his eyes, and laid his hands upon him.'"

*Kai ptysas eis ta ommata autou epitheis tas cheiras autō*—spit, hands.

"''See you aught?''"

*Ei ti blepeis*—see anything?

"''I see men; for I behold them as trees, walking.''"

*Blepō tous anthrōpous hoti hōs dendra horō peripatountas*—partial sight.

**Two-Stage Healing:**
Unique in Gospels—parabolic of disciples' partial understanding.

"'Then again he laid his hands upon his eyes; and he looked steadfastly, and was restored, and saw all things clearly.'"

*Eita palin epethēken tas cheiras epi tous ophthalmous autou kai dieblepsen kai apekatestē kai eneblepsen tēlaugōs hapanta*—clear sight.

**Peter's Confession (8:27-30):**
**The Key Verses (8:27-30):**
"'Into the villages of Caesarea Philippi.'"

*Eis tas kōmas Kaisareias tēs Philippou*—Caesarea Philippi.

"''Who do men say that I am?''"

*Tina me legousin hoi anthrōpoi einai*—who say?

"''John the Immerser; and others, Elijah; but others, One of the prophets.''"

*Iōannēn ton baptistēn kai alloi Ēlian alloi de hoti heis tōn prophētōn*—opinions.

"''But who say you that I am?''"

*Hymeis de tina me legete einai*—you.

"''You are the Anointed.''"

*Sy ei ho Christos*—Anointed.

"'He charged them that they should tell no man of him.'"

*Kai epetimēsen autois hina mēdeni legōsin peri autou*—messianic secret.

**First Passion Prediction (8:31-33):**
**The Key Verses (8:31-33):**
"''The Son of man must suffer many things.''"

*Dei ton huion tou anthrōpou polla pathein*—must suffer.

"''Be rejected by the elders, and the chief priests, and the scribes.''"

*Kai apodokimasthēnai hypo tōn presbyterōn kai tōn archiereōn kai tōn grammateōn*—rejected.

"''Be killed, and after three days rise again.''"

*Kai apoktanthēnai kai meta treis hēmeras anastēnai*—killed, rise.

"'He spoke the saying openly.'"

*Kai parrēsia ton logon elalei*—openly.

"'Peter took him, and began to rebuke him.'"

*Kai proslabomenos ho Petros auton ērxato epitiman autō*—rebuke.

"''Get behind me, Satan.''"

*Hypage opisō mou Satana*—Satan.

"''You mind not the things of God, but the things of men.''"

*Hoti ou phroneis ta tou theou alla ta tōn anthrōpōn*—human thinking.

**Taking Up the Cross (8:34-9:1):**
**The Key Verses (8:34-38):**
"''If any man would come after me, let him deny himself, and take up his cross, and follow me.''"

*Ei tis thelei opisō mou akolouthein aparnēsasthō heauton kai aratō ton stauron autou kai akoloutheitō moi*—cross.

"''Whosoever would save his life shall lose it.''"

*Hos gar ean thelē tēn psychēn autou sōsai apolesei autēn*—lose life.

"''Whosoever shall lose his life for my sake and the good news' sake shall save it.''"

*Hos d' an apolesē tēn psychēn autou heneken emou kai tou euangeliou sōsei autēn*—save.

"''What does it profit a man, to gain the whole world, and forfeit his life?''"

*Ti gar ōphelei anthrōpon kerdēsai ton kosmon holon kai zēmiōthēnai tēn psychēn autou*—profit?

"''Whosoever shall be ashamed of me and of my words... the Son of man also shall be ashamed of him.''"

*Hos gar ean epaischynthē me kai tous emous logous... kai ho huios tou anthrōpou epaischynthēsetai auton*—ashamed.

"''When he comes in the glory of his Father with the holy angels.''"

*Hotan elthē en tē doxē tou patros autou meta tōn angelōn tōn hagiōn*—coming.

**Archetypal Layer:** Mark 8 is the **Gospel's turning point**, containing **feeding the four thousand (8:1-10)**: compassion, seven loaves, seven baskets, **Pharisees seek a sign; sigh, no sign given (8:11-13)**, **"beware of the leaven of the Pharisees and the leaven of Herod" (8:15)**, **"Do you not yet perceive, neither understand? Have you your heart hardened?" (8:17)**, **five loaves/five thousand/twelve baskets vs. seven loaves/four thousand/seven baskets (8:19-20)**, **two-stage healing of blind man at Bethsaida (8:22-26)**: "I see men... as trees, walking" (8:24), **Peter's confession: "You are the Anointed" (8:29)**, **first passion prediction (8:31)**: must suffer, be rejected, be killed, rise after three days, **Peter rebukes; "Get behind me, Satan" (8:32-33)**, **"let him deny himself, and take up his cross, and follow me" (8:34)**, **"whosoever would save his life shall lose it" (8:35)**, **"what does it profit a man, to gain the whole world, and forfeit his life?" (8:36)**, and **"whosoever shall be ashamed of me... the Son of man also shall be ashamed of him" (8:38)**.

**Modern Equivalent:** Mark 8 is the Gospel's hinge. The two feedings are recalled (8:19-20), but disciples still don't understand. The two-stage healing of the blind man (8:22-26) symbolizes the disciples' partial sight. Peter's confession (8:29) correctly identifies Yeshua as Messiah, but immediately the first passion prediction (8:31) redefines messiahship through suffering. Peter's rebuke earns "Get behind me, Satan" (8:33)—human thinking opposes divine purpose. Discipleship means cross-bearing (8:34) and losing life to save it (8:35).

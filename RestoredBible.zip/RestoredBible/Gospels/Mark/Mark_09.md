# Mark 9: Transfiguration, Exorcism, and Servanthood

*From the Greek: Καὶ μετὰ ἡμέρας ἓξ (Kai Meta Hēmeras Hex) — And After Six Days*

---

## The Transfiguration (9:2-13)

**9:2** And after six days Yeshua takes with him Peter, and James, and John, and brings them up into a high mountain apart by themselves: and he was transfigured before them;

**9:3** And his garments became glistering, exceeding white, so as no fuller on earth can whiten them.

**9:4** And there appeared unto them Elijah with Moses: and they were talking with Yeshua.

**9:5** And Peter answers and says to Yeshua: "Rabbi, it is good for us to be here: and let us make three tabernacles; one for you, and one for Moses, and one for Elijah."

**9:6** For he knew not what to answer; for they became sore afraid.

**9:7** And there came a cloud overshadowing them: and there came a voice out of the cloud: "This is my beloved Son: hear him."

**9:8** And suddenly looking round about, they saw no one any more, save Yeshua only with themselves.

**9:9** And as they were coming down from the mountain, he charged them that they should tell no man what things they had seen, save when the Son of man should have risen again from the dead.

**9:10** And they kept the saying, questioning among themselves what the rising again from the dead should mean.

**9:11** And they asked him, saying: "How is it that the scribes say that Elijah must first come?"

**9:12** And he said unto them: "Elijah indeed comes first, and restores all things: and how is it written of the Son of man, that he should suffer many things and be set at nought?

**9:13** "But I say unto you, that Elijah is come, and they have also done unto him whatsoever they would, even as it is written of him."

---

## The Epileptic Boy (9:14-29)

**9:14** And when they came to the disciples, they saw a great multitude about them, and scribes questioning with them.

**9:15** And straightway all the multitude, when they saw him, were greatly amazed, and running to him saluted him.

**9:16** And he asked them: "What question you with them?"

**9:17** And one of the multitude answered him: "Teacher, I brought unto you my son, who has a dumb spirit;

**9:18** "And wheresoever it takes him, it dashes him down: and he foams, and grinds his teeth, and pines away: and I spoke to your disciples that they should cast it out; and they were not able."

**9:19** And he answers them and says: "O faithless generation, how long shall I be with you? How long shall I bear with you? Bring him unto me."

**9:20** And they brought him unto him: and when he saw him, straightway the spirit tore him grievously; and he fell on the ground, and wallowed foaming.

**9:21** And he asked his father: "How long time is it since this has come unto him?" And he said: "From a child.

**9:22** "And oft-times it has cast him both into the fire and into the waters, to destroy him: but if you can do anything, have compassion on us, and help us."

**9:23** And Yeshua said unto him: "'If you can!' All things are possible to him that believes."

**9:24** Straightway the father of the child cried out, and said: "I believe; help my unbelief."

**9:25** And when Yeshua saw that a multitude came running together, he rebuked the unclean spirit, saying unto him: "You dumb and deaf spirit, I command you, come out of him, and enter no more into him."

**9:26** And having cried out, and torn him much, it came out: and the boy became as one dead; insomuch that the more part said: "He is dead."

**9:27** But Yeshua took him by the hand, and raised him up; and he arose.

**9:28** And when he was come into the house, his disciples asked him privately: "How is it that we could not cast it out?"

**9:29** And he said unto them: "This kind can come out by nothing, save by prayer."

---

## Second Prediction of the Passion (9:30-32)

**9:30** And they went forth from thence, and passed through Galilee; and he would not that any man should know it.

**9:31** For he taught his disciples, and said unto them: "The Son of man is delivered up into the hands of men, and they shall kill him; and when he is killed, after three days he shall rise again."

**9:32** But they understood not the saying, and were afraid to ask him.

---

## Who Is the Greatest? (9:33-37)

**9:33** And they came to Capernaum: and when he was in the house he asked them: "What were you reasoning on the way?"

**9:34** But they held their peace: for they had disputed one with another on the way, who was the greatest.

**9:35** And he sat down, and called the twelve; and he says unto them: "If any man would be first, he shall be last of all, and minister of all."

**9:36** And he took a little child, and set him in the midst of them: and taking him in his arms, he said unto them:

**9:37** "Whosoever shall receive one of such little children in my name, receives me: and whosoever receives me, receives not me, but him that sent me."

---

## The Strange Exorcist (9:38-41)

**9:38** John said unto him: "Teacher, we saw one casting out demons in your name; and we forbade him, because he followed not us."

**9:39** But Yeshua said: "Forbid him not: for there is no man who shall do a mighty work in my name, and be able quickly to speak evil of me.

**9:40** "For he that is not against us is for us.

**9:41** "For whosoever shall give you a cup of water to drink, because you are Messiah's, verily I say unto you, he shall in no wise lose his reward."

---

## Warnings about Stumbling (9:42-50)

**9:42** "And whosoever shall cause one of these little ones that believe on me to stumble, it were better for him if a great millstone were hanged about his neck, and he were cast into the sea.

**9:43** "And if your hand cause you to stumble, cut it off: it is good for you to enter into life maimed, rather than having your two hands to go into Gehenna, into the unquenchable fire.

**9:44** [Where their worm dies not, and the fire is not quenched.]

**9:45** "And if your foot cause you to stumble, cut it off: it is good for you to enter into life halt, rather than having your two feet to be cast into Gehenna.

**9:46** [Where their worm dies not, and the fire is not quenched.]

**9:47** "And if your eye cause you to stumble, cast it out: it is good for you to enter into the kingdom of God with one eye, rather than having two eyes to be cast into Gehenna;

**9:48** "Where their worm dies not, and the fire is not quenched.

**9:49** "For every one shall be salted with fire.

**9:50** "Salt is good: but if the salt have lost its saltness, wherewith will you season it? Have salt in yourselves, and be at peace one with another."

---

## Synthesis Notes

**Key Restorations:**

**Transfiguration (9:2-13):**
**The Key Verses (9:2-8):**
"'After six days Yeshua takes with him Peter, and James, and John.'"

*Kai meta hēmeras hex paralambanei ho Iēsous ton Petron kai ton Iakōbon kai ton Iōannēn*—inner three.

"'Brings them up into a high mountain apart by themselves.'"

*Kai anapherei autous eis oros hypsēlon kat' idian monous*—high mountain.

"'He was transfigured before them.'"

*Kai metemorphōthē emprosthen autōn*—transfigured.

"'His garments became glistering, exceeding white.'"

*Kai ta himatia autou egeneto stilbonta leuka lian*—white.

"'So as no fuller on earth can whiten them.'"

*Hoia gnapheus epi tēs gēs ou dynatai houtōs leukanai*—fuller.

"'There appeared unto them Elijah with Moses.'"

*Kai ōphthē autois Ēlias syn Mōusei*—Elijah, Moses.

**Mark's Order:**
Elijah first, then Moses.

"''Rabbi, it is good for us to be here.''

*Rhabbi kalon estin hēmas hōde einai*—good.

"''Let us make three tabernacles.''"

*Kai poiēsōmen treis skēnas*—tabernacles.

"'For he knew not what to answer; for they became sore afraid.'"

*Ou gar ēdei ti apokrithē ekphoboi gar egenonto*—afraid.

"'There came a cloud overshadowing them.'"

*Kai egeneto nephelē episkiazousa autois*—cloud.

"''This is my beloved Son: hear him.''"

*Houtos estin ho huios mou ho agapētos akouete autou*—hear him.

"'They saw no one any more, save Yeshua only.'"

*Ouketi oudena eidon alla ton Iēsoun monon meth' heautōn*—Yeshua only.

**The Key Verses (9:9-13):**
"''Tell no man... save when the Son of man should have risen again from the dead.''"

*Hina mēdeni ha eidon diēgēsōntai ei mē hotan ho huios tou anthrōpou ek nekrōn anastē*—secrecy.

"'Questioning among themselves what the rising again from the dead should mean.'"

*Ton logon ekratēsan pros heautous syzētountes ti estin to ek nekrōn anastēnai*—puzzled.

"''Elijah indeed comes first, and restores all things.''"

*Ēlias men elthōn prōton apokathistanei panta*—restores.

"''Elijah is come, and they have also done unto him whatsoever they would.''"

*Alla legō hymin hoti kai Ēlias elēlythen kai epoiēsan autō hosa ēthelon*—John.

**Epileptic Boy (9:14-29):**
**The Key Verses (9:14-24):**
"''I brought unto you my son, who has a dumb spirit.''"

*Ēnenka ton huion mou pros se echonta pneuma alalon*—dumb spirit.

"''Wheresoever it takes him, it dashes him down: and he foams, and grinds his teeth, and pines away.''"

*Kai hopou ean auton katalabē rhēssei auton kai aphrizei kai trizei tous odontas kai xērainetai*—symptoms.

"''I spoke to your disciples that they should cast it out; and they were not able.''"

*Kai eipa tois mathētais sou hina auto ekbalōsin kai ouk ischysan*—couldn't.

"''O faithless generation, how long shall I be with you?''"

*Ō genea apistos heōs pote pros hymas esomai*—faithless.

"''From a child.'"

*Ek paidiothen*—childhood.

"''If you can do anything, have compassion on us, and help us.''"

*All' ei ti dynē boēthēson hēmin splanchnistheis eph' hēmas*—if you can.

"''If you can!' All things are possible to him that believes.''"

*To ei dynē panta dynata tō pisteuonti*—all possible.

"''I believe; help my unbelief.''"

*Pisteuō boēthei mou tē apistia*—believe, unbelief.

**The Key Verses (9:25-29):**
"''You dumb and deaf spirit, I command you, come out of him, and enter no more into him.''"

*To alalon kai kōphon pneuma egō epitassō soi exelthe ex autou kai mēketi eiselthēs eis auton*—command.

"'The boy became as one dead... But Yeshua took him by the hand, and raised him up.'"

*Kai egeneto hōsei nekros... ho de Iēsous kratēsas tēs cheiros autou ēgeiren auton*—raised.

"''This kind can come out by nothing, save by prayer.''"

*Touto to genos en oudeni dynatai exelthein ei mē en proseuchē*—prayer.

**Second Passion Prediction (9:30-32):**
"''The Son of man is delivered up into the hands of men.''"

*Ho huios tou anthrōpou paradidotai eis cheiras anthrōpōn*—delivered.

"''They shall kill him; and when he is killed, after three days he shall rise again.''"

*Kai apoktenousin auton kai apoktantheis meta treis hēmeras anastēsetai*—killed, rise.

"'They understood not the saying, and were afraid to ask him.'"

*Hoi de ēgnooun to rhēma kai ephobounto auton eperōtēsai*—didn't understand.

**Who Is Greatest? (9:33-37):**
"''What were you reasoning on the way?''"

*Ti en tē hodō dielogizesthe*—reasoning.

"'They had disputed one with another on the way, who was the greatest.'"

*Pros allēlous gar dielechthēsan en tē hodō tis meizōn*—greatest.

"''If any man would be first, he shall be last of all, and minister of all.''"

*Ei tis thelei prōtos einai estai pantōn eschatos kai pantōn diakonos*—last, servant.

"'He took a little child, and set him in the midst of them.'"

*Kai labōn paidion estēsen auto en mesō autōn*—child.

"''Whosoever shall receive one of such little children in my name, receives me.''"

*Hos an hen tōn toioutōn paidiōn dexētai epi tō onomati mou eme dechetai*—receives me.

**Strange Exorcist (9:38-41):**
"''We saw one casting out demons in your name; and we forbade him.''"

*Eidomen tina en tō onomati sou ekballonta daimonia kai ekōlyomen auton*—forbade.

"''Forbid him not.''"

*Mē kōlyete auton*—don't forbid.

"''He that is not against us is for us.''"

*Hos gar ouk estin kath' hēmōn hyper hēmōn estin*—for us.

"''Whosoever shall give you a cup of water to drink, because you are Messiah's.''"

*Hos gar an potisē hymas potērion hydatos en onomati hoti Christou este*—cup of water.

**Stumbling Warnings (9:42-50):**
"''Whosoever shall cause one of these little ones that believe on me to stumble.''"

*Kai hos an skandalisē hena tōn mikrōn toutōn tōn pisteuontōn eis eme*—stumble.

"''It were better for him if a great millstone were hanged about his neck.''"

*Kalon estin autō mallon ei perikeitai mylos onikos peri ton trachēlon autou*—millstone.

"''If your hand cause you to stumble, cut it off.''"

*Kai ean skandalizē se hē cheir sou apokopson autēn*—cut off.

"''It is good for you to enter into life maimed.''"

*Kalon estin se kyllon eiselthein eis tēn zōēn*—enter maimed.

"''Where their worm dies not, and the fire is not quenched.''"

*Hopou ho skōlēx autōn ou teleuta kai to pyr ou sbennutai*—Isaiah 66:24.

"''For every one shall be salted with fire.''"

*Pas gar pyri halisthēsetai*—salted.

"''Have salt in yourselves, and be at peace one with another.''"

*Echete en heautois hala kai eirēneuete en allēlois*—salt, peace.

**Archetypal Layer:** Mark 9 contains **Transfiguration (9:2-8)**: "transfigured before them" (9:2), garments whiter than any fuller can make, Elijah with Moses, "This is my beloved Son: hear him" (9:7), **"Tell no man... save when the Son of man should have risen again from the dead" (9:9)**, **"Elijah is come" = John (9:13)**, **epileptic boy (9:14-29)**: disciples couldn't cast out, "O faithless generation" (9:19), **"'If you can!' All things are possible to him that believes" (9:23)**, **"I believe; help my unbelief" (9:24)**, "This kind can come out by nothing, save by prayer" (9:29), **second passion prediction (9:31)**, **"who was the greatest" dispute (9:34)**, **"If any man would be first, he shall be last of all, and minister of all" (9:35)**, **child in their midst (9:36-37)**, **strange exorcist: "Forbid him not" (9:39)**, **"he that is not against us is for us" (9:40)**, **millstone warning (9:42)**, **hand, foot, eye: "cut it off... enter into life maimed" (9:43-47)**, **"Where their worm dies not, and the fire is not quenched" (Isaiah 66:24) (9:48)**, and **"Have salt in yourselves, and be at peace one with another" (9:50)**.

**Modern Equivalent:** Mark 9 shows glory and suffering together. The Transfiguration (9:2-8) reveals Yeshua's divine glory; "hear him" (9:7) echoes Deuteronomy 18:15. Descending, they encounter disciples' failure (9:18). The father's cry "I believe; help my unbelief" (9:24) is profoundly honest. The second passion prediction (9:31) meets incomprehension. The greatness dispute (9:34) is answered with servanthood (9:35) and a child (9:36). The strange exorcist teaches tolerance (9:39-40). The stumbling warnings (9:42-48) use hyperbole to stress serious consequences.

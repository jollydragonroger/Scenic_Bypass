# Mark 15: The Crucifixion and Death

*From the Greek: Καὶ εὐθὺς πρωῒ (Kai Euthys Prōi) — And Straightway in the Morning*

---

## Before Pilate (15:1-15)

**15:1** And straightway in the morning the chief priests with the elders and scribes, and the whole council, held a consultation, and bound Yeshua, and carried him away, and delivered him up to Pilate.

**15:2** And Pilate asked him: "Are you the King of the Jews?" And he answering says unto him: "You say."

**15:3** And the chief priests accused him of many things.

**15:4** And Pilate again asked him, saying: "Do you answer nothing? Behold how many things they accuse you of."

**15:5** But Yeshua no more answered anything; insomuch that Pilate marvelled.

**15:6** Now at the feast he was accustomed to release unto them one prisoner, whom they asked of him.

**15:7** And there was one called Barabbas, lying bound with them that had made insurrection, men who in the insurrection had committed murder.

**15:8** And the multitude went up and began to ask him to do as he was accustomed to do unto them.

**15:9** And Pilate answered them, saying: "Will you that I release unto you the King of the Jews?"

**15:10** For he perceived that for envy the chief priests had delivered him up.

**15:11** But the chief priests stirred up the multitude, that he should rather release Barabbas unto them.

**15:12** And Pilate again answered and said unto them: "What then shall I do unto him whom you call the King of the Jews?"

**15:13** And they cried out again: "Crucify him."

**15:14** And Pilate said unto them: "Why, what evil has he done?" But they cried out exceedingly: "Crucify him."

**15:15** And Pilate, wishing to content the multitude, released unto them Barabbas, and delivered Yeshua, when he had scourged him, to be crucified.

---

## The Soldiers Mock Yeshua (15:16-20)

**15:16** And the soldiers led him away within the court, which is the Praetorium; and they call together the whole band.

**15:17** And they clothe him with purple, and platting a crown of thorns, they put it on him;

**15:18** And they began to salute him: "Hail, King of the Jews!"

**15:19** And they smote his head with a reed, and spat upon him, and bowing their knees worshipped him.

**15:20** And when they had mocked him, they took off from him the purple, and put on him his garments. And they lead him out to crucify him.

---

## The Crucifixion (15:21-32)

**15:21** And they compel one passing by, Simon of Cyrene, coming from the country, the father of Alexander and Rufus, to go with them, that he might bear his cross.

**15:22** And they bring him unto the place Golgotha, which is, being interpreted, The place of a skull.

**15:23** And they offered him wine mingled with myrrh: but he received it not.

**15:24** And they crucify him, and part his garments among them, casting lots upon them, what each should take.

**15:25** And it was the third hour, and they crucified him.

**15:26** And the superscription of his accusation was written over: THE KING OF THE JEWS.

**15:27** And with him they crucify two robbers; one on his right hand, and one on his left.

**15:28** [And the scripture was fulfilled, which says: "And he was reckoned with transgressors."]

**15:29** And they that passed by railed on him, wagging their heads, and saying: "Ha! You that destroy the temple, and build it in three days,

**15:30** "Save yourself, and come down from the cross."

**15:31** In like manner also the chief priests mocking him among themselves with the scribes said: "He saved others; himself he cannot save.

**15:32** "Let the Anointed, the King of Israel, now come down from the cross, that we may see and believe." And they that were crucified with him reproached him.

---

## The Death of Yeshua (15:33-41)

**15:33** And when the sixth hour was come, there was darkness over the whole land until the ninth hour.

**15:34** And at the ninth hour Yeshua cried with a loud voice: "Eloi, Eloi, lama sabachthani?" which is, being interpreted, "My God, my God, why have you forsaken me?"

**15:35** And some of them that stood by, when they heard it, said: "Behold, he calls Elijah."

**15:36** And one ran, and filling a sponge full of vinegar, put it on a reed, and gave him to drink, saying: "Let be; let us see whether Elijah comes to take him down."

**15:37** And Yeshua uttered a loud voice, and gave up the spirit.

**15:38** And the veil of the temple was rent in two from the top to the bottom.

**15:39** And when the centurion, who stood by over against him, saw that he so gave up the spirit, he said: "Truly this man was the Son of God."

**15:40** And there were also women beholding from afar: among whom were both Mary Magdalene, and Mary the mother of James the less and of Joses, and Salome;

**15:41** Who, when he was in Galilee, followed him, and ministered unto him; and many other women that came up with him unto Jerusalem.

---

## The Burial of Yeshua (15:42-47)

**15:42** And when even was now come, because it was the Preparation, that is, the day before the sabbath,

**15:43** There came Joseph of Arimathaea, a councillor of honourable estate, who also himself was looking for the kingdom of God; and he boldly went in unto Pilate, and asked for the body of Yeshua.

**15:44** And Pilate marvelled if he were already dead: and calling unto him the centurion, he asked him whether he had been any while dead.

**15:45** And when he learned it of the centurion, he granted the corpse to Joseph.

**15:46** And he bought a linen cloth, and taking him down, wound him in the linen cloth, and laid him in a tomb which had been hewn out of a rock; and he rolled a stone against the door of the tomb.

**15:47** And Mary Magdalene and Mary the mother of Joses beheld where he was laid.

---

## Synthesis Notes

**Key Restorations:**

**Before Pilate (15:1-15):**
**The Key Verses (15:1-5):**
"'Straightway in the morning the chief priests with the elders and scribes, and the whole council, held a consultation.'"

*Kai euthys prōi symboulion poiēsantes hoi archiereis meta tōn presbyterōn kai grammateōn kai holon to synedrion*—council.

"'Bound Yeshua, and carried him away, and delivered him up to Pilate.'"

*Dēsantes ton Iēsoun apēnenkan kai paredōkan Pilatō*—delivered.

"''Are you the King of the Jews?' And he answering says unto him: 'You say.''"

*Sy ei ho basileus tōn Ioudaiōn ho de apokritheis autō legei sy legeis*—you say.

"'Yeshua no more answered anything; insomuch that Pilate marvelled.'"

*Ho de Iēsous ouketi ouden apekrithē hōste thaumazein ton Pilaton*—silent.

**Isaiah 53:7.**

**The Key Verses (15:6-15):**
"'There was one called Barabbas, lying bound with them that had made insurrection.'"

*Ēn de ho legomenos Barabbas meta tōn stasiastōn dedemenοs*—Barabbas.

"'Men who in the insurrection had committed murder.'"

*Hoitines en tē stasei phonon pepoiēkeisan*—murder.

"''Will you that I release unto you the King of the Jews?''"

*Thelete apolusō hymin ton basilea tōn Ioudaiōn*—release.

"'He perceived that for envy the chief priests had delivered him up.'"

*Eginōsken gar hoti dia phthonon paradedōkeisan auton hoi archiereis*—envy.

"'The chief priests stirred up the multitude.'"

*Hoi de archiereis aneseisan ton ochlon*—stirred.

"''What then shall I do unto him whom you call the King of the Jews?''"

*Ti oun poiēsō hon legete ton basilea tōn Ioudaiōn*—what do?

"''Crucify him.' 'Why, what evil has he done?' 'Crucify him.''"

*Staurōson auton... ti gar epoiēsen kakon... staurōson auton*—crucify.

"'Pilate, wishing to content the multitude.'"

*Ho de Pilatos boulomenos tō ochlō to hikanon poiēsai*—content crowd.

"'Delivered Yeshua, when he had scourged him, to be crucified.'"

*Paredōken ton Iēsoun phragellōsas hina staurōthē*—scourged.

**Soldiers Mock (15:16-20):**
"'The soldiers led him away within the court, which is the Praetorium.'"

*Hoi de stratiōtai apēgagon auton esō tēs aulēs ho estin praitōrion*—Praetorium.

"'They clothe him with purple.'"

*Kai endidyskousin auton porphyran*—purple.

"'Platting a crown of thorns, they put it on him.'"

*Kai peritheasin autō plexantes akanthinon stephanon*—thorns.

"''Hail, King of the Jews!''"

*Chaire basileu tōn Ioudaiōn*—hail.

"'They smote his head with a reed, and spat upon him.'"

*Kai etypton autou tēn kephalēn kalamō kai eneptyon autō*—struck.

**Crucifixion (15:21-32):**
**The Key Verses (15:21-28):**
"'They compel one passing by, Simon of Cyrene, coming from the country.'"

*Kai angareuousin paragonاta tina Simōna Kyrēnaion erchomenon ap' agrou*—Simon.

"'The father of Alexander and Rufus.'"

*Ton patera Alexandrou kai Rhouphou*—known family.

**Only Mark:**
Names Alexander and Rufus—known to Mark's community.

"'The place Golgotha, which is, being interpreted, The place of a skull.'"

*Ton Golgotha topon ho estin methermēneuomenon kraniou topos*—skull.

"'They offered him wine mingled with myrrh: but he received it not.'"

*Kai edidoun autō esmyrnismenon oinon hos de ouk elaben*—myrrh.

"'They crucify him, and part his garments among them, casting lots.'"

*Kai staurousin auton kai diamerizontai ta himatia autou ballontes klēron ep' auta*—lots.

**Psalm 22:18.**

"'It was the third hour, and they crucified him.'"

*Ēn de hōra tritē kai estaurōsan auton*—9 AM.

"'The superscription of his accusation was written over: THE KING OF THE JEWS.'"

*Kai ēn hē epigraphē tēs aitias autou epigegrammenē ho basileus tōn Ioudaiōn*—accusation.

"'With him they crucify two robbers.'"

*Kai syn autō staurousin dyo lēstas*—robbers.

**The Key Verses (15:29-32):**
"'They that passed by railed on him, wagging their heads.'"

*Kai hoi paraporeuomenoi eblasphēmoun auton kinountes tas kephalas autōn*—wagging.

**Psalm 22:7.**

"''Ha! You that destroy the temple, and build it in three days.''"

*Oua ho katalyōn ton naon kai oikodomōn en trisin hēmerais*—temple.

"''Save yourself, and come down from the cross.''"

*Sōson seauton katabas apo tou staurou*—save self.

"''He saved others; himself he cannot save.''"

*Allous esōsen heauton ou dynatai sōsai*—ironic truth.

"''Let the Anointed, the King of Israel, now come down from the cross, that we may see and believe.''"

*Ho Christos ho basileus Israēl katabatō nyn apo tou staurou hina idōmen kai pisteusōmen*—come down.

**Death of Yeshua (15:33-41):**
**The Key Verses (15:33-39):**
"'When the sixth hour was come, there was darkness over the whole land until the ninth hour.'"

*Kai genomenēs hōras hektēs skotos egeneto eph' holēn tēn gēn heōs hōras enatēs*—noon to 3 PM.

"'At the ninth hour Yeshua cried with a loud voice.'"

*Kai tē enatē hōra eboēsen ho Iēsous phōnē megalē*—loud cry.

"''Eloi, Eloi, lama sabachthani?''"

*Elōi elōi lema sabachthani*—Aramaic.

**Psalm 22:1:**
"''My God, my God, why have you forsaken me?''"

"'Some of them that stood by... said: Behold, he calls Elijah.'"

*Tines tōn hestēkotōn... elegon ide Ēlian phōnei*—Elijah.

"'One ran, and filling a sponge full of vinegar, put it on a reed.'"

*Dramōn de tis kai gemisas spongon oxous peritheis kalamō*—vinegar.

**Psalm 69:21.**

"'Yeshua uttered a loud voice, and gave up the spirit.'"

*Ho de Iēsous apheis phōnēn megalēn exepneusen*—gave up spirit.

"'The veil of the temple was rent in two from the top to the bottom.'"

*Kai to katapetasma tou naou eschisthē eis dyo ap' anōthen heōs katō*—veil torn.

**Schizō:**
Same word as heavens "torn" at baptism (1:10).

"'When the centurion... saw that he so gave up the spirit, he said: Truly this man was the Son of God.'"

*Idōn de ho kentyriōn... hoti houtōs exepneusen eipen alēthōs houtos ho anthrōpos huios theou ēn*—Son of God.

**Gospel's Climax:**
A Gentile centurion confesses what the reader knows.

**The Key Verses (15:40-41):**
"'There were also women beholding from afar.'"

*Ēsan de kai gynaikes apo makrothen theōrousai*—women.

"'Mary Magdalene, and Mary the mother of James the less and of Joses, and Salome.'"

*En hais kai Mariam hē Magdalēnē kai Maria hē Iakōbou tou mikrou kai Iōsētos mētēr kai Salōmē*—named.

"'When he was in Galilee, followed him, and ministered unto him.'"

*Hai hote ēn en tē Galilaia ēkolouthoun autō kai diēkonoun autō*—ministered.

**Burial (15:42-47):**
**The Key Verses (15:42-47):**
"'When even was now come, because it was the Preparation, that is, the day before the sabbath.'"

*Kai ēdē opsias genomenēs epei ēn paraskeuē ho estin prosabbaton*—Preparation.

"'Joseph of Arimathaea, a councillor of honourable estate.'"

*Elthōn Iōsēph ho apo Harimathaias euschēmōn bouleytēs*—councillor.

"'Who also himself was looking for the kingdom of God.'"

*Hos kai autos ēn prosdechomenos tēn basileian tou theou*—kingdom.

"'He boldly went in unto Pilate, and asked for the body of Yeshua.'"

*Tolmēsas eisēlthen pros ton Pilaton kai ētēsato to sōma tou Iēsou*—boldly.

"'Pilate marvelled if he were already dead.'"

*Ho de Pilatos ethaumasen ei ēdē tethnēken*—marvelled.

"'He bought a linen cloth, and taking him down, wound him in the linen cloth.'"

*Kai agorasas sindona kathelōn auton eneilēsen tē sindoni*—linen.

"'Laid him in a tomb which had been hewn out of a rock.'"

*Kai ethēken auton en mnēmeiō ho ēn lelatomēmenon ek petras*—rock tomb.

"'He rolled a stone against the door of the tomb.'"

*Kai prosekulisen lithon epi tēn thyran tou mnēmeiou*—stone.

"'Mary Magdalene and Mary the mother of Joses beheld where he was laid.'"

*Hē de Maria hē Magdalēnē kai Maria hē Iōsētos etheōroun pou tetheiתai*—witnessed.

**Archetypal Layer:** Mark 15 contains **delivered to Pilate (15:1)**, **"Are you the King of the Jews?" "You say" (15:2)**, **Yeshua's silence (Isaiah 53:7) (15:5)**, **Barabbas released (15:6-15)**, **"for envy the chief priests had delivered him up" (15:10)**, **"Crucify him" (15:13-14)**, **scourged and delivered (15:15)**, **soldiers' mockery: purple, thorns, "Hail, King of the Jews!" (15:16-20)**, **Simon of Cyrene, father of Alexander and Rufus (15:21)**, **Golgotha (15:22)**, **garments divided by lots (Psalm 22:18) (15:24)**, **"third hour" = 9 AM (15:25)**, **accusation: THE KING OF THE JEWS (15:26)**, **"He saved others; himself he cannot save" (15:31)**, **darkness from sixth to ninth hour (15:33)**, **"Eloi, Eloi, lama sabachthani?" (Psalm 22:1) (15:34)**, **"Yeshua uttered a loud voice, and gave up the spirit" (15:37)**, **veil torn in two (15:38)** (same word as heavens torn at baptism), **centurion's confession: "Truly this man was the Son of God" (15:39)**, **women watching (15:40-41)**, **Joseph of Arimathaea asks for body (15:43)**, **Pilate confirms death (15:44-45)**, **burial in rock tomb, stone rolled (15:46)**, and **women witness burial place (15:47)**.

**Modern Equivalent:** Mark 15 narrates the crucifixion. Pilate perceives envy (15:10) but yields to the crowd. The mockery (15:16-20) ironically proclaims truth. Simon of Cyrene (15:21) is known to Mark's community. Psalm 22 pervades the scene: garments divided (15:24), head-wagging (15:29), the cry of forsakenness (15:34). The darkness (15:33) signals cosmic significance. The veil's tearing (15:38) uses the same Greek word (*schizō*) as the heavens' tearing at baptism (1:10)—an inclusio. The centurion's confession (15:39) is the Gospel's climactic moment: a Gentile recognizes what readers know from 1:1.

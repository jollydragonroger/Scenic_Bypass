# Mark 11: Triumphal Entry, Temple, and Authority

*From the Greek: Καὶ ὅτε ἐγγίζουσιν εἰς Ἱεροσόλυμα (Kai Hote Engizousin eis Hierosolyma) — And When They Draw Near unto Jerusalem*

---

## The Triumphal Entry (11:1-11)

**11:1** And when they draw near unto Jerusalem, unto Bethphage and Bethany, at the mount of Olives, he sends two of his disciples,

**11:2** And says unto them: "Go into the village that is over against you: and straightway as you enter into it, you shall find a colt tied, whereon no man ever yet sat; loose him, and bring him.

**11:3** "And if any one say unto you, 'Why do you this?' say, 'The Lord has need of him'; and straightway he will send him back here."

**11:4** And they went away, and found a colt tied at the door without in the open street; and they loose him.

**11:5** And certain of them that stood there said unto them: "What do you, loosing the colt?"

**11:6** And they said unto them even as Yeshua had said: and they let them go.

**11:7** And they bring the colt unto Yeshua, and cast on him their garments; and he sat upon him.

**11:8** And many spread their garments upon the way; and others branches, which they had cut from the fields.

**11:9** And they that went before, and they that followed, cried: "Hosanna; Blessed is he that comes in the name of the Lord:

**11:10** "Blessed is the kingdom that comes, the kingdom of our father David: Hosanna in the highest."

**11:11** And he entered into Jerusalem, into the temple; and when he had looked round about upon all things, it being now eventide, he went out unto Bethany with the twelve.

---

## The Fig Tree Cursed (11:12-14)

**11:12** And on the morrow, when they were come out from Bethany, he hungered.

**11:13** And seeing a fig tree afar off having leaves, he came, if haply he might find anything thereon: and when he came to it, he found nothing but leaves; for it was not the season of figs.

**11:14** And he answered and said unto it: "No man eat fruit from you henceforward for ever." And his disciples heard it.

---

## Cleansing the Temple (11:15-19)

**11:15** And they come to Jerusalem: and he entered into the temple, and began to cast out them that sold and them that bought in the temple, and overthrew the tables of the money-changers, and the seats of them that sold the doves;

**11:16** And he would not suffer that any man should carry a vessel through the temple.

**11:17** And he taught, and said unto them: "Is it not written, 'My house shall be called a house of prayer for all the nations'? But you have made it a den of robbers."

**11:18** And the chief priests and the scribes heard it, and sought how they might destroy him: for they feared him, for all the multitude was astonished at his teaching.

**11:19** And every evening he went forth out of the city.

---

## The Lesson of the Withered Fig Tree (11:20-26)

**11:20** And as they passed by in the morning, they saw the fig tree withered away from the roots.

**11:21** And Peter calling to remembrance says unto him: "Rabbi, behold, the fig tree which you cursed is withered away."

**11:22** And Yeshua answering says unto them: "Have faith in God.

**11:23** "Verily I say unto you, Whosoever shall say unto this mountain, 'Be taken up and cast into the sea,' and shall not doubt in his heart, but shall believe that what he says comes to pass; he shall have it.

**11:24** "Therefore I say unto you, All things whatsoever you pray and ask for, believe that you receive them, and you shall have them.

**11:25** "And whensoever you stand praying, forgive, if you have aught against any one; that your Father also who is in heaven may forgive you your trespasses.

**11:26** [But if you do not forgive, neither will your Father who is in heaven forgive your trespasses.]"

---

## The Authority of Yeshua Questioned (11:27-33)

**11:27** And they come again to Jerusalem: and as he was walking in the temple, there come to him the chief priests, and the scribes, and the elders;

**11:28** And they said unto him: "By what authority do you do these things? Or who gave you this authority to do these things?"

**11:29** And Yeshua said unto them: "I will ask of you one question, and answer me, and I will tell you by what authority I do these things.

**11:30** "The immersion of John, was it from heaven, or from men? Answer me."

**11:31** And they reasoned with themselves, saying: "If we shall say, 'From heaven'; he will say, 'Why then did you not believe him?'

**11:32** "But should we say, 'From men'—" they feared the people: for all verily held John to be a prophet.

**11:33** And they answered Yeshua and say: "We know not." And Yeshua says unto them: "Neither tell I you by what authority I do these things."

---

## Synthesis Notes

**Key Restorations:**

**Triumphal Entry (11:1-11):**
**The Key Verses (11:1-6):**
"'When they draw near unto Jerusalem, unto Bethphage and Bethany, at the mount of Olives.'"

*Kai hote engizousin eis Hierosolyma eis Bēthphagē kai Bēthanian pros to oros tōn elaiōn*—Mount of Olives.

"''You shall find a colt tied, whereon no man ever yet sat.''"

*Heurēsete pōlon dedemenon eph' hon oudeis oupō anthrōpōn ekathisen*—unridden colt.

**Zechariah 9:9.**

"''The Lord has need of him.''"

*Ho kyrios autou chreian echei*—Lord needs.

**The Key Verses (11:7-11):**
"'They bring the colt unto Yeshua, and cast on him their garments.'"

*Kai pherousin ton pōlon pros ton Iēsoun kai epiballousin autō ta himatia autōn*—garments.

"'Many spread their garments upon the way.'"

*Kai polloi ta himatia autōn estrōsan eis tēn hodon*—spread.

"'Others branches, which they had cut from the fields.'"

*Alloi de stibadas kopsantes ek tōn agrōn*—branches.

"''Hosanna; Blessed is he that comes in the name of the Lord.''"

*Hōsanna eulogēmenos ho erchomenos en onomati kyriou*—Psalm 118:25-26.

"''Blessed is the kingdom that comes, the kingdom of our father David.''"

*Eulogēmenē hē erchomenē basileia tou patros hēmōn David*—David's kingdom.

"''Hosanna in the highest.''"

*Hōsanna en tois hypsistois*—highest.

"'He entered into Jerusalem, into the temple; and when he had looked round about upon all things.'"

*Kai eisēlthen eis Hierosolyma eis to hieron kai periblepsamenos panta*—surveyed.

"'It being now eventide, he went out unto Bethany with the twelve.'"

*Opsias ēdē ousēs tēs hōras exēlthen eis Bēthanian meta tōn dōdeka*—Bethany.

**Fig Tree Cursed (11:12-14):**
**The Key Verses (11:12-14):**
"'On the morrow, when they were come out from Bethany, he hungered.'"

*Kai tē epaurion exelthontōn autōn apo Bēthanias epeinasen*—hungry.

"'Seeing a fig tree afar off having leaves.'"

*Kai idōn sykēn apo makrothen echousan phylla*—leaves.

"'He came, if haply he might find anything thereon.'"

*Ēlthen ei ara ti heurēsei en autē*—perhaps find.

"'He found nothing but leaves; for it was not the season of figs.'"

*Kai elthōn ep' autēn ouden heuren ei mē phylla ho gar kairos ouk ēn sykōn*—not season.

"''No man eat fruit from you henceforward for ever.''"

*Mēketi eis ton aiōna ek sou mēdeis karpon phagoi*—no fruit.

"'His disciples heard it.'"

*Kai ēkouon hoi mathētai autou*—heard.

**Cleansing the Temple (11:15-19):**
**The Key Verses (11:15-19):**
"'He entered into the temple, and began to cast out them that sold and them that bought.'"

*Kai eiselthōn eis to hieron ērxato ekballein tous pōlountas kai tous agorazontas en tō hierō*—cast out.

"'Overthrew the tables of the money-changers.'"

*Kai tas trapezas tōn kollybistōn katestrepsen*—tables.

"'The seats of them that sold the doves.'"

*Kai tas kathedras tōn pōlountōn tas peristeras*—doves.

"'He would not suffer that any man should carry a vessel through the temple.'"

*Kai ouk ēphien hina tis dienenকē skeuos dia tou hierou*—no vessels.

**Only Mark:**
This detail about prohibiting carrying vessels.

"''My house shall be called a house of prayer for all the nations.''"

*Ho oikos mou oikos proseuchēs klēthēsetai pasin tois ethnesin*—all nations.

**Isaiah 56:7.**

"''But you have made it a den of robbers.''"

*Hymeis de pepoiēkate auton spēlaion lēstōn*—robbers.

**Jeremiah 7:11.**

"'The chief priests and the scribes heard it, and sought how they might destroy him.'"

*Kai ēkousan hoi archiereis kai hoi grammateis kai ezētoun pōs auton apolesōsin*—destroy.

"'They feared him, for all the multitude was astonished at his teaching.'"

*Ephobounto gar auton pas gar ho ochlos exeplēsseto epi tē didachē autou*—astonished.

**Withered Fig Tree (11:20-26):**
**The Key Verses (11:20-26):**
"'They saw the fig tree withered away from the roots.'"

*Eidon tēn sykēn exērammenēn ek rhizōn*—from roots.

"''Rabbi, behold, the fig tree which you cursed is withered away.''"

*Rhabbi ide hē sykē hēn katērasō exērantai*—withered.

"''Have faith in God.''"

*Echete pistin theou*—faith in God.

"''Whosoever shall say unto this mountain, Be taken up and cast into the sea.''"

*Hos an eipē tō orei toutō arthēti kai blēthēti eis tēn thalassan*—mountain.

"''Shall not doubt in his heart, but shall believe that what he says comes to pass.''"

*Kai mē diakrithi en tē kardia autou alla pisteue hoti ho lalei ginetai*—believe.

"''All things whatsoever you pray and ask for, believe that you receive them, and you shall have them.''"

*Panta hosa proseuchesthe kai aiteisthe pisteuete hoti elabete kai estai hymin*—receive.

"''Whensoever you stand praying, forgive.''"

*Kai hotan stēkete proseuchomenoi aphiete*—forgive.

"''That your Father also who is in heaven may forgive you your trespasses.''"

*Hina kai ho patēr hymōn ho en tois ouranois aphē hymin ta paraptōmata hymōn*—Father forgive.

**Authority Questioned (11:27-33):**
**The Key Verses (11:27-33):**
"'The chief priests, and the scribes, and the elders.'"

*Hoi archiereis kai hoi grammateis kai hoi presbyteroi*—leaders.

"''By what authority do you do these things?''"

*En poia exousia tauta poieis*—authority.

"''The immersion of John, was it from heaven, or from men?''"

*To baptisma to Iōannou ex ouranou ēn ē ex anthrōpōn*—heaven or men?

"'They reasoned with themselves.'"

*Kai dielogizonto pros heautous*—reasoned.

"''If we shall say, From heaven; he will say, Why then did you not believe him?''"

*Ean eipōmen ex ouranou erei dia ti oun ouk episteusate autō*—trapped.

"''But should we say, From men—they feared the people.''"

*Alla eipōmen ex anthrōpōn ephobounto ton ochlon*—feared.

"'We know not.'"

*Ouk oidamen*—don't know.

"''Neither tell I you by what authority I do these things.''"

*Oude egō legō hymin en poia exousia tauta poiō*—neither.

**Archetypal Layer:** Mark 11 contains **triumphal entry (11:1-11)**: colt "whereon no man ever yet sat" (11:2), garments and branches, **"Hosanna; Blessed is he that comes in the name of the Lord" (Psalm 118:25-26) (11:9)**, **"Blessed is the kingdom that comes, the kingdom of our father David" (11:10)**, Yeshua surveys temple but departs to Bethany (11:11), **fig tree cursed (11:12-14)**: "for it was not the season of figs" (11:13), **cleansing the temple (11:15-19)**: money-changers, dove-sellers, no vessels through temple, **"My house shall be called a house of prayer for all the nations" (Isaiah 56:7) (11:17)**, **"you have made it a den of robbers" (Jeremiah 7:11) (11:17)**, **withered fig tree (11:20-26)**: "Have faith in God" (11:22), **"Whosoever shall say unto this mountain, Be taken up and cast into the sea" (11:23)**, **"believe that you receive them, and you shall have them" (11:24)**, **"whensoever you stand praying, forgive" (11:25)**, and **authority questioned (11:27-33)**: John's immersion dilemma.

**Modern Equivalent:** Mark 11 begins Passion Week. The triumphal entry (11:1-11) fulfills Zechariah 9:9. The fig tree incident (11:12-14, 20-25) brackets the temple cleansing—symbolic of Israel's fruitlessness despite outward appearance. "Not the season of figs" (11:13) heightens the symbolic nature. The temple cleansing (11:15-19) combines Isaiah 56:7 ("for all the nations") and Jeremiah 7:11 ("den of robbers"). The withered fig tree prompts teaching on faith and prayer (11:22-25), with forgiveness as prerequisite. The authority question (11:27-33) shows leaders' bad faith—they can't answer honestly, so Yeshua won't answer either.

# Mark 3: The Twelve and the Beelzebub Controversy

*From the Greek: Καὶ εἰσῆλθεν πάλιν εἰς τὴν συναγωγήν (Kai Eisēlthen Palin eis tēn Synagōgēn) — And He Entered Again into the Synagogue*

---

## Healing on the Sabbath (3:1-6)

**3:1** And he entered again into the synagogue; and there was a man there who had his hand withered.

**3:2** And they watched him, whether he would heal him on the sabbath day; that they might accuse him.

**3:3** And he says unto the man that had his hand withered: "Stand forth."

**3:4** And he says unto them: "Is it lawful on the sabbath day to do good, or to do harm? To save a life, or to kill?" But they held their peace.

**3:5** And when he had looked round about on them with anger, being grieved at the hardening of their heart, he says unto the man: "Stretch forth your hand." And he stretched it forth; and his hand was restored.

**3:6** And the Pharisees went out, and straightway with the Herodians took counsel against him, how they might destroy him.

---

## Crowds Follow Yeshua (3:7-12)

**3:7** And Yeshua with his disciples withdrew to the sea: and a great multitude from Galilee followed; and from Judaea,

**3:8** And from Jerusalem, and from Idumaea, and beyond the Jordan, and about Tyre and Sidon, a great multitude, hearing what great things he did, came unto him.

**3:9** And he spoke to his disciples, that a little boat should wait on him because of the crowd, lest they should throng him:

**3:10** For he had healed many; insomuch that as many as had plagues pressed upon him that they might touch him.

**3:11** And the unclean spirits, whenever they beheld him, fell down before him, and cried, saying: "You are the Son of God."

**3:12** And he charged them much that they should not make him known.

---

## The Appointing of the Twelve (3:13-19)

**3:13** And he goes up into the mountain, and calls unto him whom he himself would; and they went unto him.

**3:14** And he appointed twelve, that they might be with him, and that he might send them forth to proclaim,

**3:15** And to have authority to cast out demons:

**3:16** And Simon he surnamed Peter;

**3:17** And James the son of Zebedee, and John the brother of James; and them he surnamed Boanerges, which is, Sons of thunder:

**3:18** And Andrew, and Philip, and Bartholomew, and Matthew, and Thomas, and James the son of Alphaeus, and Thaddaeus, and Simon the Cananaean,

**3:19** And Judas Iscariot, who also betrayed him.

---

## Yeshua and Beelzebub (3:20-30)

**3:20** And he comes into a house. And the multitude comes together again, so that they could not so much as eat bread.

**3:21** And when his friends heard it, they went out to lay hold on him: for they said: "He is beside himself."

**3:22** And the scribes that came down from Jerusalem said: "He has Beelzebub, and, By the prince of the demons casts he out the demons."

**3:23** And he called them unto him, and said unto them in parables: "How can Satan cast out Satan?

**3:24** "And if a kingdom be divided against itself, that kingdom cannot stand.

**3:25** "And if a house be divided against itself, that house will not be able to stand.

**3:26** "And if Satan has risen up against himself, and is divided, he cannot stand, but has an end.

**3:27** "But no one can enter into the house of the strong man, and spoil his goods, except he first bind the strong man; and then he will spoil his house.

**3:28** "Verily I say unto you, All their sins shall be forgiven unto the sons of men, and their blasphemies wherewith soever they shall blaspheme:

**3:29** "But whosoever shall blaspheme against the Holy Spirit has never forgiveness, but is guilty of an eternal sin":

**3:30** Because they said: "He has an unclean spirit."

---

## Yeshua's True Family (3:31-35)

**3:31** And there come his mother and his brethren; and, standing without, they sent unto him, calling him.

**3:32** And a multitude was sitting about him; and they say unto him: "Behold, your mother and your brethren without seek for you."

**3:33** And he answers them, and says: "Who is my mother and my brethren?"

**3:34** And looking round on them that sat round about him, he says: "Behold, my mother and my brethren!

**3:35** "For whosoever shall do the will of God, the same is my brother, and sister, and mother."

---

## Synthesis Notes

**Key Restorations:**

**Healing on the Sabbath (3:1-6):**
**The Key Verses (3:1-6):**
"'There was a man there who had his hand withered.'"

*Kai ēn ekei anthrōpos exērammenēn echōn tēn cheira*—withered hand.

"'They watched him, whether he would heal him on the sabbath day; that they might accuse him.'"

*Kai paretēroun auton ei tois sabbasin therapeusei auton hina katēgorēsōsin autou*—watched.

"''Stand forth.''"

*Egeire eis to meson*—stand in midst.

"''Is it lawful on the sabbath day to do good, or to do harm? To save a life, or to kill?''"

*Exestin tois sabbasin agathon poiēsai ē kakopoiēsai psychēn sōsai ē apokteinai*—good or harm?

"'They held their peace.'"

*Hoi de esiōpōn*—silent.

"'When he had looked round about on them with anger.'"

*Kai periblepsamenos autous met' orgēs*—anger.

**Only Mark:**
Mentions Yeshua's anger and grief.

"'Being grieved at the hardening of their heart.'"

*Syllypoumenos epi tē pōrōsei tēs kardias autōn*—grieved.

"''Stretch forth your hand.' And he stretched it forth; and his hand was restored.'"

*Ekteinon tēn cheira kai exeteinen kai apekatestathē hē cheir autou*—restored.

"'The Pharisees went out, and straightway with the Herodians took counsel against him, how they might destroy him.'"

*Kai exelthontes hoi Pharisaioi euthys meta tōn Hērōdianōn symboulion edidoun kat' autou hopōs auton apolesōsin*—destroy.

**Pharisees + Herodians:**
Unusual alliance.

**Crowds Follow (3:7-12):**
**The Key Verses (3:7-12):**
"'Yeshua with his disciples withdrew to the sea.'"

*Kai ho Iēsous meta tōn mathētōn autou anechōrēsen pros tēn thalassan*—withdrew.

"'A great multitude from Galilee followed; and from Judaea, and from Jerusalem, and from Idumaea, and beyond the Jordan, and about Tyre and Sidon.'"

*Kai poly plēthos apo tēs Galilaias ēkolouthēsen kai apo tēs Ioudaias kai apo Hierosolymōn kai apo tēs Idoumaias kai peran tou Iordanou kai peri Tyron kai Sidōna*—wide region.

"'As many as had plagues pressed upon him that they might touch him.'"

*Hosoi eichon mastigas epepiptoت autō hina autou hapsōntai*—touch.

"''You are the Son of God.''"

*Sy ei ho huios tou theou*—demons confess.

"'He charged them much that they should not make him known.'"

*Kai polla epetima autois hina mē auton phaneron poiēsōsin*—messianic secret.

**Appointing the Twelve (3:13-19):**
**The Key Verses (3:13-19):**
"'He goes up into the mountain, and calls unto him whom he himself would.'"

*Kai anabainei eis to oros kai proskaleitai hous ēthelen autos*—he chose.

"'He appointed twelve, that they might be with him.'"

*Kai epoiēsen dōdeka hina ōsin met' autou*—be with him.

"'That he might send them forth to proclaim.'"

*Kai hina apostellē autous kēryssein*—proclaim.

"'To have authority to cast out demons.'"

*Kai echein exousian ekballein ta daimonia*—authority.

"'Simon he surnamed Peter.'"

*Kai epethēken onoma tō Simōni Petron*—Peter.

"'James... and John... he surnamed Boanerges, which is, Sons of thunder.'"

*Iakōbon... kai Iōannēn... kai epethēken autois onoma Boanērges ho estin huioi brontēs*—Boanerges.

**The Twelve:**
Peter, James, John, Andrew, Philip, Bartholomew, Matthew, Thomas, James son of Alphaeus, Thaddaeus, Simon the Cananaean, Judas Iscariot.

**Beelzebub Controversy (3:20-30):**
**The Key Verses (3:20-27):**
"'They could not so much as eat bread.'"

*Hōste mē dynasthai autous mēde arton phagein*—couldn't eat.

"'His friends... said: He is beside himself.'"

*Hoi par' autou... elegon gar hoti exestē*—beside himself.

"''He has Beelzebub, and, By the prince of the demons casts he out the demons.''"

*Beelzeboul echei kai hoti en tō archonti tōn daimoniōn ekballei ta daimonia*—Beelzebub.

"''How can Satan cast out Satan?''"

*Pōs dynatai Satanas Satanan ekballein*—logical.

"''If a kingdom be divided against itself, that kingdom cannot stand.''"

*Kai ean basileia eph' heautēn meristhē ou dynatai stathēnai hē basileia ekeinē*—divided kingdom.

"''No one can enter into the house of the strong man, and spoil his goods, except he first bind the strong man.''"

*All' ou dynatai oudeis eis tēn oikian tou ischurou eiselthōn ta skeuē autou diarpasai ean mē prōton ton ischyron dēsē*—bind strong man.

**The Key Verses (3:28-30):**
"''All their sins shall be forgiven unto the sons of men, and their blasphemies.''"

*Panta aphethēsetai tois huiois tōn anthrōpōn ta hamartēmata kai hai blasphēmiai*—forgiven.

"''But whosoever shall blaspheme against the Holy Spirit has never forgiveness.''"

*Hos d' an blasphēmēsē eis to pneuma to hagion ouk echei aphesin eis ton aiōna*—never forgiveness.

"''But is guilty of an eternal sin.''"

*Alla enochos estin aiōniou hamartēmatos*—eternal sin.

"'Because they said: He has an unclean spirit.'"

*Hoti elegon pneuma akatharton echei*—called Spirit unclean.

**True Family (3:31-35):**
**The Key Verses (3:31-35):**
"'There come his mother and his brethren; and, standing without, they sent unto him.'"

*Kai erchontai hē mētēr autou kai hoi adelphoi autou kai exō stēkontes apesteilan pros auton kalountes auton*—family.

"''Behold, your mother and your brethren without seek for you.''"

*Idou hē mētēr sou kai hoi adelphoi sou exō zētousin se*—seeking.

"''Who is my mother and my brethren?''"

*Tis estin hē mētēr mou kai hoi adelphoi mou*—who?

"'Looking round on them that sat round about him.'"

*Kai periblepsamenos tous peri auton kyklō kathēmenous*—looked round.

"''Behold, my mother and my brethren!''"

*Ide hē mētēr mou kai hoi adelphoi mou*—disciples.

"''Whosoever shall do the will of God, the same is my brother, and sister, and mother.''"

*Hos an poiēsē to thelēma tou theou houtos adelphos mou kai adelphē kai mētēr estin*—true family.

**Archetypal Layer:** Mark 3 contains **healing of the withered hand on sabbath (3:1-6)**, **"Is it lawful on the sabbath day to do good, or to do harm? To save a life, or to kill?" (3:4)**, **Yeshua's anger and grief at hardness of heart (3:5)**, **Pharisees and Herodians plot to destroy him (3:6)**, **crowds from all regions (3:7-8)**, **demons confess "You are the Son of God" but silenced (3:11-12)**, **appointing the Twelve (3:13-19)**: "that they might be with him, and that he might send them forth to proclaim, and to have authority to cast out demons" (3:14-15), **Boanerges = Sons of thunder (3:17)**, **"He is beside himself" (3:21)**, **Beelzebub accusation (3:22)**, **"How can Satan cast out Satan?" (3:23)**, **"a kingdom... divided against itself... cannot stand" (3:24)**, **binding the strong man (3:27)**, **"whosoever shall blaspheme against the Holy Spirit has never forgiveness, but is guilty of an eternal sin" (3:29)**, and **true family = those who do God's will (3:35)**.

**Modern Equivalent:** Mark 3 intensifies conflict. The sabbath healing (3:1-6) ends with Pharisees and Herodians plotting murder—a sabbath devoted to death. The Twelve are appointed for three purposes: being with Yeshua, proclaiming, and casting out demons (3:14-15). The Beelzebub charge (3:22) elicits the strong man parable (3:27): Yeshua is plundering Satan's house. Blasphemy against the Spirit (3:29) is calling the Spirit's work demonic (3:30). True family is defined by doing God's will, not biology (3:35).

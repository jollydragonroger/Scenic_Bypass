# Mark 16: The Resurrection

*From the Greek: Καὶ διαγενομένου τοῦ σαββάτου (Kai Diagenomenou tou Sabbatou) — And When the Sabbath Was Past*

---

## The Empty Tomb (16:1-8)

**16:1** And when the sabbath was past, Mary Magdalene, and Mary the mother of James, and Salome, bought spices, that they might come and anoint him.

**16:2** And very early on the first day of the week, they come to the tomb when the sun was risen.

**16:3** And they were saying among themselves: "Who shall roll us away the stone from the door of the tomb?"

**16:4** And looking up, they see that the stone is rolled back: for it was exceeding great.

**16:5** And entering into the tomb, they saw a young man sitting on the right side, arrayed in a white robe; and they were amazed.

**16:6** And he says unto them: "Be not amazed: you seek Yeshua, the Nazarene, who has been crucified: he is risen; he is not here: behold, the place where they laid him.

**16:7** "But go, tell his disciples and Peter, 'He goes before you into Galilee: there shall you see him, as he said unto you.'"

**16:8** And they went out, and fled from the tomb; for trembling and astonishment had come upon them: and they said nothing to any one; for they were afraid.

---

## The Longer Ending (16:9-20)

[The following verses are not found in the earliest and most reliable manuscripts, but are included as part of the canonical tradition.]

**16:9** Now when he was risen early on the first day of the week, he appeared first to Mary Magdalene, from whom he had cast out seven demons.

**16:10** She went and told them that had been with him, as they mourned and wept.

**16:11** And they, when they heard that he was alive, and had been seen of her, disbelieved.

**16:12** And after these things he was manifested in another form unto two of them, as they walked, on their way into the country.

**16:13** And they went away and told it unto the rest: neither believed they them.

**16:14** And afterward he was manifested unto the eleven themselves as they sat at meat; and he upbraided them with their unbelief and hardness of heart, because they believed not them that had seen him after he was risen.

**16:15** And he said unto them: "Go into all the world, and proclaim the good news to the whole creation.

**16:16** "He that believes and is immersed shall be saved; but he that disbelieves shall be condemned.

**16:17** "And these signs shall accompany them that believe: in my name shall they cast out demons; they shall speak with new tongues;

**16:18** "They shall take up serpents, and if they drink any deadly thing, it shall in no wise hurt them; they shall lay hands on the sick, and they shall recover."

**16:19** So then the Lord Yeshua, after he had spoken unto them, was received up into heaven, and sat down at the right hand of God.

**16:20** And they went forth, and proclaimed everywhere, the Lord working with them, and confirming the word by the signs that followed. Amen.

---

## Synthesis Notes

**Key Restorations:**

**The Empty Tomb (16:1-8):**
**The Key Verses (16:1-4):**
"'When the sabbath was past, Mary Magdalene, and Mary the mother of James, and Salome.'"

*Kai diagenomenou tou sabbatou Maria hē Magdalēnē kai Maria hē tou Iakōbou kai Salōmē*—three women.

"'Bought spices, that they might come and anoint him.'"

*Ēgorasan arōmata hina elthousai aleipsōsin auton*—anoint.

"'Very early on the first day of the week, they come to the tomb when the sun was risen.'"

*Kai lian prōi tē mia tōn sabbatōn erchontai epi to mnēmeion anateilantos tou hēliou*—sunrise.

"''Who shall roll us away the stone from the door of the tomb?''"

*Tis apokylisei hēmin ton lithon ek tēs thyras tou mnēmeiou*—stone.

"'Looking up, they see that the stone is rolled back: for it was exceeding great.'"

*Kai anablepsasai theōrousin hoti apokekylistai ho lithos ēn gar megas sphodra*—rolled back.

**The Key Verses (16:5-8):**
"'Entering into the tomb, they saw a young man sitting on the right side, arrayed in a white robe.'"

*Kai eiselthousai eis to mnēmeion eidon neaniskon kathēmenon en tois dexiois peribeblēmenon stolēn leukēn*—young man.

**Neaniskos:**
Same word as young man who fled (14:51).

"'They were amazed.'"

*Kai exethambēthēsan*—amazed.

"''Be not amazed.''"

*Mē ekthambeisthe*—don't be amazed.

"''You seek Yeshua, the Nazarene, who has been crucified.''"

*Iēsoun zēteite ton Nazarēnon ton estaurōmenon*—crucified Nazarene.

"''He is risen; he is not here.''"

*Ēgerthē ouk estin hōde*—risen.

"''Behold, the place where they laid him.''"

*Ide ho topos hopou ethēkan auton*—see.

"''Go, tell his disciples and Peter.''"

*Alla hypagete eipate tois mathētais autou kai tō Petrō*—disciples and Peter.

**And Peter:**
Special mention—reconciliation implied after denial.

"''He goes before you into Galilee: there shall you see him, as he said unto you.''"

*Hoti proagei hymas eis tēn Galilaian ekei auton opsesthe kathōs eipen hymin*—Galilee.

**14:28 Fulfilled.**

"'They went out, and fled from the tomb.'"

*Kai exelthousai ephygon apo tou mnēmeiou*—fled.

"'Trembling and astonishment had come upon them.'"

*Eichen gar autas tromos kai ekstasis*—trembling, astonishment.

"'They said nothing to any one; for they were afraid.'"

*Kai oudeni ouden eipan ephobounto gar*—afraid.

**Ephobounto Gar:**
"For they were afraid"—the original ending.

**Textual Note:**
The earliest manuscripts (Sinaiticus, Vaticanus) end at 16:8.

**The Longer Ending (16:9-20):**
**The Key Verses (16:9-14):**
"'He appeared first to Mary Magdalene, from whom he had cast out seven demons.'"

*Anastas de prōi prōtē sabbatou ephanē prōton Maria tē Magdalēnē par' hēs ekbeblēkei hepta daimonia*—Mary first.

"'She went and told them that had been with him, as they mourned and wept.'"

*Ekeinē poreutheisa apēngeilen tois met' autou genomenois penthοusin kai klaiousin*—mourning.

"'They... disbelieved.'"

*Ēpistēsan*—disbelieved.

"'He was manifested in another form unto two of them.'"

*Duo ex autōn peripatousin ephanerōthē en hetera morphē*—two.

**Luke 24:13-35 Parallel:**
Emmaus road.

"'He was manifested unto the eleven themselves as they sat at meat.'"

*Hysteron de anakeimenois autois tois hendeka ephanerōthē*—eleven.

"'He upbraided them with their unbelief and hardness of heart.'"

*Kai ōneidisen tēn apistian autōn kai sklērokardian*—upbraided.

**The Key Verses (16:15-20):**
"''Go into all the world, and proclaim the good news to the whole creation.''"

*Poreuthentes eis ton kosmon hapanta kēryxate to euangelion pasē tē ktisei*—all world.

"''He that believes and is immersed shall be saved.''"

*Ho pisteusas kai baptistheis sōthēsetai*—believes, immersed.

"''He that disbelieves shall be condemned.''"

*Ho de apistēsas katakrithēsetai*—condemned.

"''These signs shall accompany them that believe.''"

*Sēmeia de tois pisteusasin tauta parakolouthēsei*—signs.

"''In my name shall they cast out demons.''"

*En tō onomati mou daimonia ekbalousin*—demons.

"''They shall speak with new tongues.''"

*Glōssais lalēsousin kainais*—tongues.

"''They shall take up serpents.''"

*Opheis arousin*—serpents.

"''If they drink any deadly thing, it shall in no wise hurt them.''"

*Kan thanasimon ti piōsin ou mē autous blapsē*—deadly.

"''They shall lay hands on the sick, and they shall recover.''"

*Epi arrōstous cheiras epithēsousin kai kalōs hexousin*—heal.

"'The Lord Yeshua... was received up into heaven, and sat down at the right hand of God.'"

*Ho men oun kyrios Iēsous... anelēmphthē eis ton ouranon kai ekathisen ek dexiōn tou theou*—ascension.

"'They went forth, and proclaimed everywhere, the Lord working with them.'"

*Ekeinoi de exelthontes ekēryxan pantachou tou kyriou synergountos*—proclaimed.

"'Confirming the word by the signs that followed.'"

*Kai ton logon bebaiountos dia tōn epakolouthountōn sēmeiōn*—signs confirmed.

**Archetypal Layer:** Mark 16 contains **the empty tomb (16:1-8)**: Mary Magdalene, Mary mother of James, and Salome bring spices, **"Who shall roll us away the stone?" (16:3)**, **stone already rolled back (16:4)**, **young man in white robe (16:5)**, **"Be not amazed: you seek Yeshua, the Nazarene, who has been crucified: he is risen; he is not here" (16:6)**, **"tell his disciples and Peter" (16:7)**, **"He goes before you into Galilee" (16:7)**, **"they went out, and fled from the tomb; for trembling and astonishment had come upon them: and they said nothing to any one; for they were afraid" (16:8)**, [**Longer Ending (16:9-20)**]: appearance to Mary Magdalene (16:9), disciples disbelieve (16:11), two on the road (16:12), eleven at table—upbraided for unbelief (16:14), **"Go into all the world, and proclaim the good news to the whole creation" (16:15)**, **"He that believes and is immersed shall be saved" (16:16)**, **signs: cast out demons, speak with new tongues, take up serpents, deadly drink harmless, heal sick (16:17-18)**, **ascension: "sat down at the right hand of God" (16:19)**, and **"they went forth, and proclaimed everywhere" (16:20)**.

**Modern Equivalent:** Mark 16:1-8 is the original ending in the earliest manuscripts. The women find the tomb empty, encounter a young man (angel), hear the resurrection proclamation, and flee in fear. The abrupt ending—"for they were afraid" (*ephobounto gar*)—is deliberate: readers must complete the story. The Longer Ending (16:9-20), though not in the earliest manuscripts, became canonical tradition. It summarizes resurrection appearances, includes the Great Commission ("Go into all the world"), and describes signs following believers. "Tell his disciples and Peter" (16:7) specifically singles out Peter after his denial—restoration is implied.

---

## Textual Note on Mark's Ending

The Gospel of Mark has three possible endings in the manuscript tradition:

1. **The Shorter Ending (16:8)**: The earliest and most reliable manuscripts (Codex Sinaiticus, Codex Vaticanus) end with verse 8: "for they were afraid" (*ephobounto gar*). This abrupt ending is likely original.

2. **The Longer Ending (16:9-20)**: Found in later manuscripts and became part of the canonical text. It provides resurrection appearances and commissioning.

3. **The Shorter Addition**: Some manuscripts have a brief addition after verse 8 before the longer ending.

The abrupt ending at 16:8 may be intentional—inviting readers to continue the story themselves—or the original ending may have been lost. Regardless, the resurrection is proclaimed: "He is risen; he is not here" (16:6).

# Mark 7: Tradition, Defilement, and Gentile Faith

*From the Greek: Καὶ συνάγονται πρὸς αὐτὸν οἱ Φαρισαῖοι (Kai Synagontai pros Auton hoi Pharisaioi) — And There Are Gathered Together unto Him the Pharisees*

---

## Tradition of the Elders (7:1-13)

**7:1** And there are gathered together unto him the Pharisees, and certain of the scribes, who had come from Jerusalem,

**7:2** And had seen that some of his disciples ate their bread with defiled, that is, unwashed, hands.

**7:3** (For the Pharisees, and all the Jews, except they wash their hands diligently, eat not, holding the tradition of the elders;

**7:4** And when they come from the marketplace, except they wash themselves, they eat not; and many other things there are, which they have received to hold, washings of cups, and pots, and brazen vessels.)

**7:5** And the Pharisees and the scribes ask him: "Why walk not your disciples according to the tradition of the elders, but eat their bread with defiled hands?"

**7:6** And he said unto them: "Well did Isaiah prophesy of you hypocrites, as it is written: 'This people honours me with their lips, but their heart is far from me.

**7:7** "'But in vain do they worship me, teaching as their doctrines the precepts of men.'

**7:8** "You leave the commandment of God, and hold fast the tradition of men."

**7:9** And he said unto them: "Full well do you reject the commandment of God, that you may keep your tradition.

**7:10** "For Moses said, 'Honour your father and your mother'; and, 'He that speaks evil of father or mother, let him die the death':

**7:11** "But you say, If a man shall say to his father or his mother, 'That wherewith you might have been profited by me is Corban,' that is to say, Given to God;

**7:12** "You no longer permit him to do anything for his father or his mother;

**7:13** "Making void the word of God by your tradition, which you have delivered: and many such like things you do."

---

## What Defiles a Person (7:14-23)

**7:14** And he called to him the multitude again, and said unto them: "Hear me all of you, and understand:

**7:15** "There is nothing from without the man, that going into him can defile him; but the things which proceed out of the man are those that defile the man.

**7:16** [If any man has ears to hear, let him hear.]

**7:17** And when he was entered into the house from the multitude, his disciples asked of him the parable.

**7:18** And he says unto them: "Are you so without understanding also? Perceive you not, that whatsoever from without goes into the man, it cannot defile him;

**7:19** "Because it goes not into his heart, but into his belly, and goes out into the draught?" This he said, making all meats clean.

**7:20** And he said: "That which proceeds out of the man, that defiles the man.

**7:21** "For from within, out of the heart of men, evil thoughts proceed, fornications, thefts, murders, adulteries,

**7:22** "Covetings, wickednesses, deceit, lasciviousness, an evil eye, railing, pride, foolishness:

**7:23** "All these evil things proceed from within, and defile the man."

---

## The Syrophoenician Woman's Faith (7:24-30)

**7:24** And from thence he arose, and went away into the borders of Tyre and Sidon. And he entered into a house, and would have no man know it; and he could not be hid.

**7:25** But straightway a woman, whose little daughter had an unclean spirit, having heard of him, came and fell down at his feet.

**7:26** Now the woman was a Greek, a Syrophoenician by race. And she besought him that he would cast forth the demon out of her daughter.

**7:27** And he said unto her: "Let the children first be filled: for it is not right to take the children's bread and cast it to the dogs."

**7:28** But she answered and says unto him: "Yea, Lord; even the dogs under the table eat of the children's crumbs."

**7:29** And he said unto her: "For this saying go your way; the demon is gone out of your daughter."

**7:30** And she went away unto her house, and found the child laid upon the bed, and the demon gone out.

---

## Healing a Deaf Man (7:31-37)

**7:31** And again he went out from the borders of Tyre, and came through Sidon unto the sea of Galilee, through the midst of the borders of Decapolis.

**7:32** And they bring unto him one that was deaf, and had an impediment in his speech; and they beseech him to lay his hand upon him.

**7:33** And he took him aside from the multitude privately, and put his fingers into his ears, and he spat, and touched his tongue;

**7:34** And looking up to heaven, he sighed, and says unto him: "Ephphatha," that is, "Be opened."

**7:35** And his ears were opened, and the bond of his tongue was loosed, and he spoke plain.

**7:36** And he charged them that they should tell no man: but the more he charged them, so much the more a great deal they published it.

**7:37** And they were beyond measure astonished, saying: "He has done all things well; he makes even the deaf to hear, and the dumb to speak."

---

## Synthesis Notes

**Key Restorations:**

**Tradition of the Elders (7:1-13):**
**The Key Verses (7:1-8):**
"'The Pharisees, and certain of the scribes, who had come from Jerusalem.'"

*Kai synagontai pros auton hoi Pharisaioi kai tines tōn grammateōn elthontes apo Hierosolymōn*—from Jerusalem.

"'Had seen that some of his disciples ate their bread with defiled, that is, unwashed, hands.'"

*Kai idontes tinas tōn mathētōn autou hoti koinais chersin tout' estin aniptois esthiousin tous artous*—unwashed.

"'The Pharisees, and all the Jews, except they wash their hands diligently, eat not.'"

*Hoi gar Pharisaioi kai pantes hoi Ioudaioi ean mē pygmē nipsōntai tas cheiras ouk esthiousin*—ritual washing.

**Pygmē:**
"With the fist"—vigorous washing.

"''Why walk not your disciples according to the tradition of the elders?''"

*Dia ti ou peripatousin hoi mathētai sou kata tēn paradosin tōn presbyterōn*—tradition.

"''Well did Isaiah prophesy of you hypocrites.''"

*Kalōs eprophēteusen Ēsaias peri hymōn tōn hypokritōn*—Isaiah.

**Isaiah 29:13.**

"''This people honours me with their lips, but their heart is far from me.''"

*Houtos ho laos tois cheilesin me tima hē de kardia autōn porrō apechei ap' emou*—lips/heart.

"''In vain do they worship me, teaching as their doctrines the precepts of men.''"

*Matēn de sebontai me didaskontes didaskalias entalmata anthrōpōn*—precepts of men.

"''You leave the commandment of God, and hold fast the tradition of men.''"

*Aphentes tēn entolēn tou theou krateite tēn paradosin tōn anthrōpōn*—tradition vs. commandment.

**The Key Verses (7:9-13):**
"''Full well do you reject the commandment of God, that you may keep your tradition.''"

*Kalōs atheteite tēn entolēn tou theou hina tēn paradosin hymōn stēsēte*—reject.

"''Honour your father and your mother.''"

*Tima ton patera sou kai tēn mētera sou*—honor parents.

**Exodus 20:12.**

"''That wherewith you might have been profited by me is Corban.''"

*Korban ho estin dōron ho ean ex emou ōphelēthēs*—Corban.

**Korban:**
Hebrew/Aramaic: "offering/dedicated to God."

"''You no longer permit him to do anything for his father or his mother.''"

*Ouketi aphiete auton ouden poiēsai tō patri ē tē mētri*—no longer permit.

"''Making void the word of God by your tradition.''"

*Akyrountes ton logon tou theou tē paradosei hymōn*—making void.

**What Defiles (7:14-23):**
**The Key Verses (7:14-19):**
"''There is nothing from without the man, that going into him can defile him.''"

*Ouden estin exōthen tou anthrōpou eisporeuomenon eis auton ho dynatai koinōsai auton*—nothing outside defiles.

"''The things which proceed out of the man are those that defile the man.''"

*Alla ta ek tou anthrōpou ekporeuomena estin ta koinounta ton anthrōpon*—from within.

"''Whatsoever from without goes into the man, it cannot defile him.''"

*Hoti pan to exōthen eisporeuomenon eis ton anthrōpon ou dynatai auton koinōsai*—cannot defile.

"''Because it goes not into his heart, but into his belly, and goes out into the draught.''"

*Hoti ouk eisporeuetai autou eis tēn kardian all' eis tēn koilian kai eis ton aphedrōna ekporeuetai*—belly.

"'This he said, making all meats clean.'"

*Katharizōn panta ta brōmata*—all foods clean.

**Editorial Comment:**
Mark's interpretive note.

**The Key Verses (7:20-23):**
"''That which proceeds out of the man, that defiles the man.''"

*To ek tou anthrōpou ekporeuomenon ekeino koinoi ton anthrōpon*—defiles.

"''From within, out of the heart of men, evil thoughts proceed.''"

*Esōthen gar ek tēs kardias tōn anthrōpōn hoi dialogismoi hoi kakoi ekporeuontai*—from heart.

**Vice List:**
Fornications, thefts, murders, adulteries, covetings, wickednesses, deceit, lasciviousness, evil eye, railing, pride, foolishness—twelve vices.

"''All these evil things proceed from within, and defile the man.''"

*Panta tauta ta ponēra esōthen ekporeuetai kai koinoi ton anthrōpon*—from within.

**Syrophoenician Woman (7:24-30):**
**The Key Verses (7:24-30):**
"'He arose, and went away into the borders of Tyre and Sidon.'"

*Ekeithen de anastas apēlthen eis ta horia Tyrou*—Gentile territory.

"'He could not be hid.'"

*Kai ouk ēdynasthē lathein*—couldn't hide.

"'The woman was a Greek, a Syrophoenician by race.'"

*Hē de gynē ēn Hellēnis Syrophoinikissa tō genei*—Gentile.

"''Let the children first be filled.''"

*Aphes prōton chortasthēnai ta tekna*—children first.

"''It is not right to take the children's bread and cast it to the dogs.''"

*Ou gar estin kalon labein ton arton tōn teknōn kai tois kynariois balein*—children's bread.

**Kynaria:**
"Little dogs/puppies"—household pets.

"''Yea, Lord; even the dogs under the table eat of the children's crumbs.''"

*Nai kyrie kai ta kynaria hypokatō tēs trapezēs esthiousin apo tōn psichiōn tōn paidiōn*—crumbs.

"''For this saying go your way; the demon is gone out of your daughter.''"

*Dia touton ton logon hypage exelēlythen ek tēs thugatros sou to daimonion*—for this saying.

"'She went away unto her house, and found the child laid upon the bed, and the demon gone out.'"

*Kai apelthousa eis ton oikon autēs heuren to paidion beblēmenon epi tēn klinēn kai to daimonion exelēlythos*—demon gone.

**Healing a Deaf Man (7:31-37):**
**The Key Verses (7:31-37):**
"'He went out from the borders of Tyre, and came through Sidon unto the sea of Galilee, through the midst of the borders of Decapolis.'"

*Kai palin exelthōn ek tōn horiōn Tyrou ēlthen dia Sidōnos eis tēn thalassan tēs Galilaias ana meson tōn horiōn Dekapoleōs*—circuitous route.

"'They bring unto him one that was deaf, and had an impediment in his speech.'"

*Kai pherousin autō kōphon kai mogilalon*—deaf, speech impediment.

**Mogilalos:**
Rare word—also in Isaiah 35:6 (LXX).

"'He took him aside from the multitude privately.'"

*Kai apolabomenos auton apo tou ochlou kat' idian*—private.

"'Put his fingers into his ears, and he spat, and touched his tongue.'"

*Ebalen tous daktylous autou eis ta ōta autou kai ptysas hēpsato tēs glōssēs autou*—physical contact.

"'Looking up to heaven, he sighed.'"

*Kai anablepsas eis ton ouranon estenaxen*—sighed.

"''Ephphatha,' that is, 'Be opened.''"

*Ephphatha ho estin dianoichthēti*—Aramaic.

"'His ears were opened, and the bond of his tongue was loosed.'"

*Kai ēnoigēsan autou hai akoai kai elythē ho desmos tēs glōssēs autou*—opened.

"''He has done all things well; he makes even the deaf to hear, and the dumb to speak.''"

*Kalōs panta pepoiēken kai tous kōphous poiei akouein kai tous alalous lalein*—all things well.

**Isaiah 35:5-6.**

**Archetypal Layer:** Mark 7 contains **tradition of the elders vs. commandment of God (7:1-13)**, **Isaiah 29:13: "This people honours me with their lips, but their heart is far from me" (7:6)**, **"teaching as their doctrines the precepts of men" (7:7)**, **"You leave the commandment of God, and hold fast the tradition of men" (7:8)**, **Corban loophole (7:11-12)**, **"There is nothing from without the man, that going into him can defile him" (7:15)**, **"making all meats clean" (7:19)**, **"from within, out of the heart of men, evil thoughts proceed" (7:21)**, **twelve vices (7:21-22)**, **the Syrophoenician woman (7:24-30)**: "Let the children first be filled" (7:27), "even the dogs under the table eat of the children's crumbs" (7:28), "For this saying go your way" (7:29), **healing the deaf man (7:31-37)**: "Ephphatha" (Aramaic), **"He has done all things well" (7:37)**.

**Modern Equivalent:** Mark 7 addresses purity and boundaries. Human tradition can void God's commandment (7:9-13)—Corban allows religious dedication to evade parental support. Defilement is internal, not external (7:15, 21-23). Mark's editorial "making all meats clean" (7:19) has profound implications for Jewish-Gentile relations. The Syrophoenician woman (7:24-30) accepts the "dogs" metaphor but cleverly argues that even dogs get crumbs—her faith wins healing. The deaf man's healing (7:31-37) echoes Isaiah 35:5-6, signaling messianic fulfillment.

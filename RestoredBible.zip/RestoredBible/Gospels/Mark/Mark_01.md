# Mark 1: The Beginning of the Good News

*From the Greek: Ἀρχὴ τοῦ εὐαγγελίου Ἰησοῦ Χριστοῦ (Archē tou Euangeliou Iesou Christou) — Beginning of the Good News of Yeshua the Anointed*

---

## John the Immerser Prepares the Way (1:1-8)

**1:1** The beginning of the good news of Yeshua the Anointed, the Son of God.

**1:2** Even as it is written in Isaiah the prophet: "Behold, I send my messenger before your face, who shall prepare your way;

**1:3** "The voice of one crying in the wilderness, Prepare the way of the Lord, make his paths straight."

**1:4** John came, who immersed in the wilderness and proclaimed the immersion of repentance unto remission of sins.

**1:5** And there went out unto him all the country of Judaea, and all they of Jerusalem; and they were immersed of him in the river Jordan, confessing their sins.

**1:6** And John was clothed with camel's hair, and had a leather belt about his loins, and ate locusts and wild honey.

**1:7** And he proclaimed, saying: "There comes after me he that is mightier than I, the latchet of whose shoes I am not worthy to stoop down and unloose.

**1:8** "I immersed you in water; but he shall immerse you in the Holy Spirit."

---

## The Immersion and Temptation of Yeshua (1:9-13)

**1:9** And it came to pass in those days, that Yeshua came from Nazareth of Galilee, and was immersed of John in the Jordan.

**1:10** And straightway coming up out of the water, he saw the heavens rent asunder, and the Spirit as a dove descending upon him:

**1:11** And a voice came out of the heavens: "You are my beloved Son, in you I am well pleased."

**1:12** And straightway the Spirit drives him forth into the wilderness.

**1:13** And he was in the wilderness forty days tempted of Satan; and he was with the wild beasts; and the angels ministered unto him.

---

## Yeshua Begins His Ministry in Galilee (1:14-20)

**1:14** Now after John was delivered up, Yeshua came into Galilee, proclaiming the good news of God,

**1:15** And saying: "The time is fulfilled, and the kingdom of God is at hand: repent, and believe in the good news."

**1:16** And passing along by the sea of Galilee, he saw Simon and Andrew the brother of Simon casting a net in the sea; for they were fishers.

**1:17** And Yeshua said unto them: "Come after me, and I will make you to become fishers of men."

**1:18** And straightway they left the nets, and followed him.

**1:19** And going on a little further, he saw James the son of Zebedee, and John his brother, who also were in the boat mending the nets.

**1:20** And straightway he called them: and they left their father Zebedee in the boat with the hired servants, and went after him.

---

## Authority over Unclean Spirits (1:21-28)

**1:21** And they go into Capernaum; and straightway on the sabbath day he entered into the synagogue and taught.

**1:22** And they were astonished at his teaching: for he taught them as having authority, and not as the scribes.

**1:23** And straightway there was in their synagogue a man with an unclean spirit; and he cried out,

**1:24** Saying: "What have we to do with you, Yeshua of Nazareth? Have you come to destroy us? I know who you are, the Holy One of God."

**1:25** And Yeshua rebuked him, saying: "Hold your peace, and come out of him."

**1:26** And the unclean spirit, tearing him and crying with a loud voice, came out of him.

**1:27** And they were all amazed, insomuch that they questioned among themselves, saying: "What is this? A new teaching! With authority he commands even the unclean spirits, and they obey him."

**1:28** And the report of him went out straightway everywhere into all the region of Galilee round about.

---

## Healings at Capernaum (1:29-34)

**1:29** And straightway, when they were come out of the synagogue, they came into the house of Simon and Andrew, with James and John.

**1:30** Now Simon's wife's mother lay sick of a fever; and straightway they tell him of her:

**1:31** And he came and took her by the hand, and raised her up; and the fever left her, and she ministered unto them.

**1:32** And at even, when the sun did set, they brought unto him all that were sick, and them that were possessed with demons.

**1:33** And all the city was gathered together at the door.

**1:34** And he healed many that were sick with divers diseases, and cast out many demons; and he permitted not the demons to speak, because they knew him.

---

## Preaching Tour in Galilee (1:35-39)

**1:35** And in the morning, a great while before day, he rose up and went out, and departed into a desert place, and there prayed.

**1:36** And Simon and they that were with him followed after him;

**1:37** And they found him, and say unto him: "All are seeking you."

**1:38** And he says unto them: "Let us go elsewhere into the next towns, that I may preach there also; for to this end came I forth."

**1:39** And he went into their synagogues throughout all Galilee, preaching and casting out demons.

---

## Cleansing a Leper (1:40-45)

**1:40** And there comes to him a leper, beseeching him, and kneeling down to him, and saying unto him: "If you will, you can make me clean."

**1:41** And being moved with compassion, he stretched forth his hand, and touched him, and says unto him: "I will; be made clean."

**1:42** And straightway the leprosy departed from him, and he was made clean.

**1:43** And he strictly charged him, and straightway sent him out,

**1:44** And says unto him: "See you say nothing to any man: but go, show yourself to the priest, and offer for your cleansing the things which Moses commanded, for a testimony unto them."

**1:45** But he went out, and began to publish it much, and to spread abroad the matter, insomuch that Yeshua could no more openly enter into a city, but was without in desert places: and they came to him from every quarter.

---

## Synthesis Notes

**Key Restorations:**

**Title and Prologue (1:1-3):**
"'The beginning of the good news of Yeshua the Anointed, the Son of God.'"

*Archē tou euangeliou Iēsou Christou huiou theou*—beginning.

**Archē:**
"Beginning"—Mark's abrupt opening.

**Euangelion:**
"Good news/Gospel."

"''Behold, I send my messenger before your face.''"

*Idou apostellō ton angelon mou pro prosōpou sou*—Malachi 3:1.

"''The voice of one crying in the wilderness.''"

*Phōnē boōntos en tē erēmō*—Isaiah 40:3.

**John the Immerser (1:4-8):**
"'John came, who immersed in the wilderness.'"

*Egeneto Iōannēs ho baptizōn en tē erēmō*—appeared.

"'Proclaimed the immersion of repentance unto remission of sins.'"

*Kēryssōn baptisma metanoias eis aphesin hamartiōn*—repentance.

"'Clothed with camel's hair, and had a leather belt about his loins.'"

*Ēn ho Iōannēs endedymenos trichas kamēlou kai zōnēn dermatinēn peri tēn osphyn autou*—Elijah garb.

"''There comes after me he that is mightier than I.''"

*Erchetai ho ischyroteros mou opisō mou*—mightier.

"''The latchet of whose shoes I am not worthy to stoop down and unloose.''"

*Hou ouk eimi hikanos kypsas lysai ton himanta tōn hypodēmatōn autou*—not worthy.

"''I immersed you in water; but he shall immerse you in the Holy Spirit.''"

*Egō ebaptisa hymas hydati autos de baptisei hymas en pneumati hagiō*—Spirit immersion.

**Immersion and Temptation (1:9-13):**
"'Yeshua came from Nazareth of Galilee, and was immersed of John.'"

*Ēlthen Iēsous apo Nazaret tēs Galilaias kai ebaptisthē eis ton Iordanēn hypo Iōannou*—immersed.

"'He saw the heavens rent asunder.'"

*Eiden schizomenous tous ouranous*—torn open.

**Schizō:**
"Torn/split"—violent opening.

"'The Spirit as a dove descending upon him.'"

*To pneuma hōs peristeran katabainon eis auton*—dove.

"''You are my beloved Son, in you I am well pleased.''"

*Sy ei ho huios mou ho agapētos en soi eudokēsa*—beloved Son.

"'Straightway the Spirit drives him forth into the wilderness.'"

*Kai euthys to pneuma auton ekballei eis tēn erēmon*—drives.

**Ekballei:**
"Drives out/casts out"—forceful.

"'Forty days tempted of Satan.'"

*Tessarakonta hēmeras peirazomenos hypo tou Satana*—forty days.

"'He was with the wild beasts; and the angels ministered unto him.'"

*Kai ēn meta tōn thēriōn kai hoi angeloi diēkonoun autō*—wild beasts, angels.

**Galilee Ministry Begins (1:14-20):**
"'After John was delivered up.'"

*Meta de to paradothēnai ton Iōannēn*—delivered up.

"''The time is fulfilled, and the kingdom of God is at hand.''"

*Peplērōtai ho kairos kai ēngiken hē basileia tou theou*—fulfilled.

**Kairos:**
"Appointed time/season."

"''Repent, and believe in the good news.''"

*Metanoeite kai pisteuete en tō euangeliō*—repent, believe.

"''Come after me, and I will make you to become fishers of men.''"

*Deute opisō mou kai poiēsō hymas genesthai halieis anthrōpōn*—fishers of men.

"'Straightway they left the nets, and followed him.'"

*Kai euthys aphentes ta diktya ēkolouthēsan autō*—followed.

**Authority over Unclean Spirits (1:21-28):**
"'He taught them as having authority, and not as the scribes.'"

*Ēn gar didaskōn autous hōs exousian echōn kai ouch hōs hoi grammateis*—authority.

"''What have we to do with you, Yeshua of Nazareth?''"

*Ti hēmin kai soi Iēsou Nazarēne*—what to us?

"''Have you come to destroy us?''"

*Ēlthes apolesai hēmas*—destroy.

"''I know who you are, the Holy One of God.''"

*Oida se tis ei ho hagios tou theou*—Holy One.

"''Hold your peace, and come out of him.''"

*Phimōthēti kai exelthe ex autou*—be silent.

"''What is this? A new teaching! With authority he commands even the unclean spirits.''"

*Ti estin touto didachē kainē kat' exousian kai tois pneumasi tois akathartois epitassei kai hypakouousin autō*—new teaching.

**Healings at Capernaum (1:29-34):**
"'Simon's wife's mother lay sick of a fever.'"

*Hē de penthera Simōnos katekeito pyressousa*—fever.

"'He came and took her by the hand, and raised her up.'"

*Kai proselthōn ēgeiren autēn kratēsas tēs cheiros*—raised.

"'They brought unto him all that were sick, and them that were possessed with demons.'"

*Epheron pros auton pantas tous kakōs echontas kai tous daimonizomenous*—brought.

"'He permitted not the demons to speak, because they knew him.'"

*Kai ouk ēphien lalein ta daimonia hoti ēdeisan auton*—messianic secret.

**Preaching Tour (1:35-39):**
"'In the morning, a great while before day, he rose up... and there prayed.'"

*Kai prōi ennycha lian anastas exēlthen... kai ekei prosēucheto*—prayed.

"''All are seeking you.''"

*Pantes zētousin se*—seeking.

"''Let us go elsewhere into the next towns, that I may preach there also.''"

*Agōmen allachou eis tas echomenas kōmopoleis hina kai ekei kēryxō*—preach.

"''For to this end came I forth.''"

*Eis touto gar exēlthon*—purpose.

**Cleansing a Leper (1:40-45):**
"''If you will, you can make me clean.''"

*Ean thelēs dynasai me katharisai*—if you will.

"'Being moved with compassion, he stretched forth his hand, and touched him.'"

*Kai splanchnistheis ekteinas tēn cheira autou hēpsato*—compassion.

"''I will; be made clean.''"

*Thelō katharisthēti*—I will.

"'Straightway the leprosy departed from him.'"

*Kai euthys apēlthen ap' autou hē lepra*—immediate.

"''Show yourself to the priest, and offer for your cleansing the things which Moses commanded.''"

*Deixon seauton tō hierei kai prosenenke peri tou katharismou sou ha prosetaxen Mōusēs*—Moses commanded.

"'Yeshua could no more openly enter into a city.'"

*Hōste mēketi auton dynasthai phanerōs eis polin eiselthein*—couldn't enter.

**Archetypal Layer:** Mark 1 contains **"The beginning of the good news of Yeshua the Anointed, the Son of God" (1:1)**, **Malachi 3:1 + Isaiah 40:3 combined (1:2-3)**, **John the Immerser in the wilderness (1:4-8)**, **"he shall immerse you in the Holy Spirit" (1:8)**, **Yeshua's immersion: "the heavens rent asunder" (1:10)**, **"You are my beloved Son" (1:11)**, **"the Spirit drives him forth into the wilderness" (1:12)**, **"forty days tempted of Satan... with the wild beasts; and the angels ministered" (1:13)**, **"The time is fulfilled, and the kingdom of God is at hand: repent, and believe in the good news" (1:15)**, **"I will make you to become fishers of men" (1:17)**, **"he taught them as having authority, and not as the scribes" (1:22)**, **"I know who you are, the Holy One of God" (1:24)**, **messianic secret: "he permitted not the demons to speak, because they knew him" (1:34)**, **morning prayer in a desert place (1:35)**, **"for to this end came I forth" (1:38)**, and **cleansing of the leper (1:40-45)**.

**Modern Equivalent:** Mark 1 is fast-paced ("straightway" appears 11 times). The Gospel opens abruptly with John and Yeshua's immersion. The heavens are "torn open" (1:10)—Mark's only use of *schizō* until the temple veil (15:38). The Spirit "drives" Yeshua into the wilderness (1:12). The summary of Yeshua's message: "The time is fulfilled, the kingdom of God is at hand: repent and believe" (1:15). Authority over demons (1:21-28) and disease (1:29-34, 40-45) demonstrates the kingdom's arrival. The messianic secret begins: demons are silenced (1:25, 34).

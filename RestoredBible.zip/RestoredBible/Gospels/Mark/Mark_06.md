# Mark 6: Rejection, Mission, and Miracles

*From the Greek: Καὶ ἐξῆλθεν ἐκεῖθεν (Kai Exēlthen Ekeithen) — And He Went Out from Thence*

---

## Rejection at Nazareth (6:1-6)

**6:1** And he went out from thence; and he comes into his own country; and his disciples follow him.

**6:2** And when the sabbath was come, he began to teach in the synagogue: and many hearing him were astonished, saying: "Whence has this man these things?" And, "What is the wisdom that is given unto this man, and what mean such mighty works wrought by his hands?

**6:3** "Is not this the carpenter, the son of Mary, and brother of James, and Joses, and Judas, and Simon? And are not his sisters here with us?" And they were offended in him.

**6:4** And Yeshua said unto them: "A prophet is not without honour, save in his own country, and among his own kin, and in his own house."

**6:5** And he could there do no mighty work, save that he laid his hands upon a few sick folk, and healed them.

**6:6** And he marvelled because of their unbelief. And he went round about the villages teaching.

---

## The Mission of the Twelve (6:7-13)

**6:7** And he calls unto him the twelve, and began to send them forth by two and two; and he gave them authority over the unclean spirits;

**6:8** And he charged them that they should take nothing for their journey, save a staff only; no bread, no wallet, no money in their purse;

**6:9** But to go shod with sandals: and, said he, put not on two coats.

**6:10** And he said unto them: "Wheresoever you enter into a house, there abide till you depart thence.

**6:11** "And whatsoever place shall not receive you, and they hear you not, as you go forth thence, shake off the dust that is under your feet for a testimony unto them."

**6:12** And they went out, and proclaimed that men should repent.

**6:13** And they cast out many demons, and anointed with oil many that were sick, and healed them.

---

## The Death of John the Immerser (6:14-29)

**6:14** And king Herod heard thereof; for his name had become known: and he said: "John the Immerser is risen from the dead, and therefore do these powers work in him."

**6:15** But others said: "It is Elijah." And others said: "It is a prophet, even as one of the prophets."

**6:16** But Herod, when he heard thereof, said: "John, whom I beheaded, he is risen."

**6:17** For Herod himself had sent forth and laid hold upon John, and bound him in prison for the sake of Herodias, his brother Philip's wife; for he had married her.

**6:18** For John said unto Herod: "It is not lawful for you to have your brother's wife."

**6:19** And Herodias set herself against him, and desired to kill him; and she could not;

**6:20** For Herod feared John, knowing that he was a righteous and holy man, and kept him safe. And when he heard him, he was much perplexed; and he heard him gladly.

**6:21** And when a convenient day was come, that Herod on his birthday made a supper to his lords, and the high captains, and the chief men of Galilee;

**6:22** And when the daughter of Herodias herself came in and danced, she pleased Herod and them that sat at meat with him; and the king said unto the damsel: "Ask of me whatsoever you will, and I will give it you."

**6:23** And he swore unto her: "Whatsoever you shall ask of me, I will give it you, unto the half of my kingdom."

**6:24** And she went out, and said unto her mother: "What shall I ask?" And she said: "The head of John the Immerser."

**6:25** And she came in straightway with haste unto the king, and asked, saying: "I will that you forthwith give me on a platter the head of John the Immerser."

**6:26** And the king was exceeding sorry; but for the sake of his oaths, and of them that sat at meat, he would not reject her.

**6:27** And straightway the king sent forth a soldier of his guard, and commanded to bring his head: and he went and beheaded him in the prison,

**6:28** And brought his head on a platter, and gave it to the damsel; and the damsel gave it to her mother.

**6:29** And when his disciples heard thereof, they came and took up his corpse, and laid it in a tomb.

---

## Feeding the Five Thousand (6:30-44)

**6:30** And the apostles gather themselves together unto Yeshua; and they told him all things, whatsoever they had done, and whatsoever they had taught.

**6:31** And he says unto them: "Come apart into a desert place, and rest a while." For there were many coming and going, and they had no leisure so much as to eat.

**6:32** And they went away in the boat to a desert place apart.

**6:33** And the people saw them going, and many knew them, and they ran together there on foot from all the cities, and outwent them.

**6:34** And he came forth and saw a great multitude, and he had compassion on them, because they were as sheep not having a shepherd: and he began to teach them many things.

**6:35** And when the day was now far spent, his disciples came unto him, and said: "The place is desert, and the day is now far spent;

**6:36** "Send them away, that they may go into the country and villages round about, and buy themselves somewhat to eat."

**6:37** But he answered and said unto them: "Give them to eat." And they say unto him: "Shall we go and buy two hundred pennyworth of bread, and give them to eat?"

**6:38** And he says unto them: "How many loaves have you? Go and see." And when they knew, they say: "Five, and two fishes."

**6:39** And he commanded them that all should sit down by companies upon the green grass.

**6:40** And they sat down in ranks, by hundreds, and by fifties.

**6:41** And he took the five loaves and the two fishes, and looking up to heaven, he blessed, and broke the loaves; and he gave to the disciples to set before them; and the two fishes divided he among them all.

**6:42** And they all ate, and were filled.

**6:43** And they took up broken pieces, twelve baskets full, and also of the fishes.

**6:44** And they that ate the loaves were five thousand men.

---

## Walking on the Water (6:45-52)

**6:45** And straightway he constrained his disciples to enter into the boat, and to go before him unto the other side to Bethsaida, while he himself sends the multitude away.

**6:46** And after he had taken leave of them, he departed into the mountain to pray.

**6:47** And when even was come, the boat was in the midst of the sea, and he alone on the land.

**6:48** And seeing them distressed in rowing, for the wind was contrary unto them, about the fourth watch of the night he comes unto them, walking on the sea; and he would have passed by them:

**6:49** But they, when they saw him walking on the sea, supposed that it was a ghost, and cried out;

**6:50** For they all saw him, and were troubled. But he straightway spoke with them, and says unto them: "Be of good cheer: it is I; be not afraid."

**6:51** And he went up unto them into the boat; and the wind ceased: and they were sore amazed in themselves;

**6:52** For they understood not concerning the loaves, but their heart was hardened.

---

## Healings at Gennesaret (6:53-56)

**6:53** And when they had crossed over, they came to the land unto Gennesaret, and moored to the shore.

**6:54** And when they were come out of the boat, straightway the people knew him,

**6:55** And ran round about that whole region, and began to carry about on their beds those that were sick, where they heard he was.

**6:56** And wheresoever he entered, into villages, or into cities, or into the country, they laid the sick in the marketplaces, and besought him that they might touch if it were but the border of his garment: and as many as touched him were made whole.

---

## Synthesis Notes

**Key Restorations:**

**Rejection at Nazareth (6:1-6):**
"'He comes into his own country.'"

*Erchetai eis tēn patrida autou*—hometown.

"''Whence has this man these things?''"

*Pothen toutō tauta*—where from?

"''Is not this the carpenter, the son of Mary?''"

*Ouch houtos estin ho tektōn ho huios tēs Marias*—carpenter.

**Tektōn:**
"Carpenter/craftsman/builder."

"''A prophet is not without honour, save in his own country.''"

*Ouk estin prophētēs atimos ei mē en tē patridi autou*—proverb.

"'He could there do no mighty work.'"

*Kai ouk edynato ekei poiēsai oudemian dynamin*—couldn't.

"'He marvelled because of their unbelief.'"

*Kai ethaumazen dia tēn apistian autōn*—marvelled.

**Mission of the Twelve (6:7-13):**
"'He calls unto him the twelve, and began to send them forth by two and two.'"

*Kai proskaleitai tous dōdeka kai ērxato autous apostellein dyo dyo*—pairs.

"'He gave them authority over the unclean spirits.'"

*Kai edidou autois exousian tōn pneumatōn tōn akathartōn*—authority.

"'Take nothing for their journey, save a staff only.'"

*Hina mēden airōsin eis hodon ei mē rhabdon monon*—staff only.

"''Shake off the dust that is under your feet for a testimony unto them.''"

*Ektinaxate ton choun ton hypokatō tōn podōn hymōn eis martyrion autois*—dust.

"'They proclaimed that men should repent.'"

*Kai exelthontes ekēryxan hina metanoōsin*—repent.

"'They cast out many demons, and anointed with oil many that were sick.'"

*Kai daimonia polla exeballon kai ēleiphon elaiō pollous arrōstous kai etherapeuon*—oil.

**Death of John (6:14-29):**
"''John the Immerser is risen from the dead.''"

*Iōannēs ho baptizōn egēgertai ek nekrōn*—risen.

"''John, whom I beheaded, he is risen.''"

*Hon egō apekephalisa Iōannēn houtos ēgerthē*—Herod's guilt.

"''It is not lawful for you to have your brother's wife.''"

*Ouk exestin soi echein tēn gynaika tou adelphou sou*—unlawful.

"'Herod feared John, knowing that he was a righteous and holy man.'"

*Ho gar Hērōdēs ephobeito ton Iōannēn eidōs auton andra dikaion kai hagion*—feared.

"'When he heard him, he was much perplexed; and he heard him gladly.'"

*Kai akousas autou polla ēporei kai hēdeōs autou ēkouen*—gladly heard.

"''I will that you forthwith give me on a platter the head of John the Immerser.''"

*Thelō hina exautēs dōs moi epi pinaki tēn kephalēn Iōannou tou baptistou*—head.

"'The king was exceeding sorry; but for the sake of his oaths.'"

*Kai perilypos genomenos ho basileus dia tous horkous*—oaths.

**Feeding the Five Thousand (6:30-44):**
"''Come apart into a desert place, and rest a while.''"

*Deute hymeis autoi kat' idian eis erēmon topon kai anapausasthe oligon*—rest.

"'He had compassion on them, because they were as sheep not having a shepherd.'"

*Esplanchnisthē ep' autous hoti ēsan hōs probata mē echonta poimena*—shepherd.

**Numbers 27:17; 1 Kings 22:17.**

"'He began to teach them many things.'"

*Kai ērxato didaskein autous polla*—teaching.

"''Give them to eat.''"

*Dote autois hymeis phagein*—give.

"''How many loaves have you?''"

*Posous artous echete*—how many?

"'They sat down in ranks, by hundreds, and by fifties.'"

*Kai anepesan prasiai prasiai kata hekaton kai kata pentēkonta*—orderly.

"'Looking up to heaven, he blessed, and broke the loaves.'"

*Kai anablepsas eis ton ouranon eulogēsen kai kateklasen tous artous*—blessed.

"'They took up broken pieces, twelve baskets full.'"

*Kai ēran klasmata dōdeka kophinōn plērōmata*—twelve baskets.

"'Five thousand men.'"

*Pentakischilioi andres*—five thousand.

**Walking on Water (6:45-52):**
"'He departed into the mountain to pray.'"

*Apēlthen eis to oros proseuxasthai*—pray.

"'About the fourth watch of the night he comes unto them, walking on the sea.'"

*Peri tetartēn phylakēn tēs nyktos erchetai pros autous peripatōn epi tēs thalassēs*—walking.

"'He would have passed by them.'"

*Kai ēthelen parelthein autous*—pass by.

**Theophanic Language:**
Exodus 33:19, 22; 1 Kings 19:11.

"''Be of good cheer: it is I; be not afraid.''"

*Tharseite egō eimi mē phobeisthe*—I am.

"'They understood not concerning the loaves, but their heart was hardened.'"

*Ou gar synēkan epi tois artois all' ēn autōn hē kardia pepōrōmenē*—hardened.

**Healings at Gennesaret (6:53-56):**
"'They might touch if it were but the border of his garment.'"

*Hina kan tou kraspedou tou himatiou autou hapsōntai*—touch fringe.

"'As many as touched him were made whole.'"

*Kai hosoi an hēptonto autou esōzonto*—made whole.

**Archetypal Layer:** Mark 6 contains **rejection at Nazareth (6:1-6)**: "Is not this the carpenter?" (6:3), "A prophet is not without honour, save in his own country" (6:4), "he could there do no mighty work" (6:5), **mission of the Twelve (6:7-13)**: sent by two, authority over unclean spirits, take nothing, shake dust, anointing with oil, **death of John the Immerser (6:14-29)**: Herodias's grudge, daughter's dance, head on a platter, **feeding the five thousand (6:30-44)**: "sheep not having a shepherd" (6:34), five loaves and two fish, twelve baskets, **walking on water (6:45-52)**: "it is I" (egō eimi), "he would have passed by them" (6:48), "their heart was hardened" (6:52), and **healings at Gennesaret (6:53-56)**.

**Modern Equivalent:** Mark 6 shows mission and rejection. Nazareth rejects Yeshua—familiarity breeds contempt, and unbelief limits even His power (6:5-6). The Twelve are sent with minimal provisions, depending on hospitality (6:7-13). John's death (6:14-29) foreshadows Yeshua's fate—both prophets killed by political rulers. The feeding of five thousand (6:30-44) shows Yeshua as shepherd (6:34). Walking on water (6:45-52) uses theophanic language ("pass by," "I am"), but the disciples' hearts are hardened (6:52)—they don't understand the loaves' significance.

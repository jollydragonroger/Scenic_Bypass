# Mark 2: Authority to Forgive and Lord of the Sabbath

*From the Greek: Καὶ εἰσελθὼν πάλιν εἰς Καφαρναούμ (Kai Eiselthōn Palin eis Kapharnaoum) — And When He Entered Again into Capernaum*

---

## The Paralytic Forgiven and Healed (2:1-12)

**2:1** And when he entered again into Capernaum after some days, it was noised that he was in the house.

**2:2** And many were gathered together, so that there was no longer room for them, no, not even about the door: and he spoke the word unto them.

**2:3** And they come, bringing unto him a man sick of the palsy, borne of four.

**2:4** And when they could not come near unto him for the crowd, they uncovered the roof where he was: and when they had broken it up, they let down the bed whereon the sick of the palsy lay.

**2:5** And Yeshua seeing their faith says unto the sick of the palsy: "Son, your sins are forgiven."

**2:6** But there were certain of the scribes sitting there, and reasoning in their hearts:

**2:7** "Why does this man thus speak? He blasphemes: who can forgive sins but one, even God?"

**2:8** And straightway Yeshua, perceiving in his spirit that they so reasoned within themselves, says unto them: "Why reason you these things in your hearts?

**2:9** "Which is easier, to say to the sick of the palsy, 'Your sins are forgiven'; or to say, 'Arise, and take up your bed, and walk'?

**2:10** "But that you may know that the Son of man has authority on earth to forgive sins"—he says to the sick of the palsy—

**2:11** "I say unto you, Arise, take up your bed, and go unto your house."

**2:12** And he arose, and straightway took up the bed, and went forth before them all; insomuch that they were all amazed, and glorified God, saying: "We never saw it on this fashion."

---

## The Calling of Levi (2:13-17)

**2:13** And he went forth again by the sea side; and all the multitude resorted unto him, and he taught them.

**2:14** And as he passed by, he saw Levi the son of Alphaeus sitting at the place of toll, and he says unto him: "Follow me." And he arose and followed him.

**2:15** And it came to pass, that he was sitting at meat in his house, and many publicans and sinners sat down with Yeshua and his disciples: for there were many, and they followed him.

**2:16** And the scribes of the Pharisees, when they saw that he was eating with the sinners and publicans, said unto his disciples: "How is it that he eats and drinks with publicans and sinners?"

**2:17** And when Yeshua heard it, he says unto them: "They that are whole have no need of a physician, but they that are sick: I came not to call the righteous, but sinners."

---

## The Question about Fasting (2:18-22)

**2:18** And John's disciples and the Pharisees were fasting: and they come and say unto him: "Why do John's disciples and the disciples of the Pharisees fast, but your disciples fast not?"

**2:19** And Yeshua said unto them: "Can the sons of the bride-chamber fast, while the bridegroom is with them? As long as they have the bridegroom with them, they cannot fast.

**2:20** "But the days will come, when the bridegroom shall be taken away from them, and then will they fast in that day.

**2:21** "No man sews a piece of undressed cloth on an old garment: else that which should fill it up takes from it, the new from the old, and a worse rent is made.

**2:22** "And no man puts new wine into old wine-skins; else the wine will burst the skins, and the wine perishes, and the skins: but they put new wine into fresh wine-skins."

---

## Lord of the Sabbath (2:23-28)

**2:23** And it came to pass, that he was going on the sabbath day through the grain fields; and his disciples began, as they went, to pluck the ears.

**2:24** And the Pharisees said unto him: "Behold, why do they on the sabbath day that which is not lawful?"

**2:25** And he said unto them: "Did you never read what David did, when he had need, and was hungry, he, and they that were with him?

**2:26** "How he entered into the house of God when Abiathar was high priest, and ate the showbread, which it is not lawful to eat save for the priests, and gave also to them that were with him?"

**2:27** And he said unto them: "The sabbath was made for man, and not man for the sabbath:

**2:28** "So that the Son of man is lord even of the sabbath."

---

## Synthesis Notes

**Key Restorations:**

**The Paralytic (2:1-12):**
**The Key Verses (2:1-5):**
"'When he entered again into Capernaum... it was noised that he was in the house.'"

*Kai eiselthōn palin eis Kapharnaoum... ēkousthē hoti en oikō estin*—in house.

"'So that there was no longer room for them, no, not even about the door.'"

*Hōste mēketi chōrein mēde ta pros tēn thyran*—crowded.

"'They uncovered the roof where he was: and when they had broken it up.'"

*Kai apestegasan tēn stegēn hopou ēn kai exoryxantes*—uncovered roof.

**Palestinian Roof:**
Mud and branches—could be dug through.

"'They let down the bed whereon the sick of the palsy lay.'"

*Chalōsi ton krabatton eph' hou ho paralytikos katekeito*—lowered.

"'Yeshua seeing their faith.'"

*Kai idōn ho Iēsous tēn pistin autōn*—their faith.

"''Son, your sins are forgiven.''"

*Teknon aphientai sou hai hamartiai*—forgiven.

**The Key Verses (2:6-12):**
"''He blasphemes: who can forgive sins but one, even God?''"

*Blasphēmei tis dynatai aphienai hamartias ei mē heis ho theos*—blasphemy.

"''Which is easier, to say... Your sins are forgiven; or to say, Arise, and take up your bed, and walk?''"

*Ti estin eukopōteron eipein... aphientai sou hai hamartiai ē eipein egeire kai aron ton krabatton sou kai peripatei*—which easier?

"''That you may know that the Son of man has authority on earth to forgive sins.''"

*Hina de eidēte hoti exousian echei ho huios tou anthrōpou aphienai hamartias epi tēs gēs*—authority.

"'He arose, and straightway took up the bed, and went forth before them all.'"

*Kai ēgerthē kai euthys aras ton krabatton exēlthen emprosthen pantōn*—arose.

"''We never saw it on this fashion.''"

*Hoti houtōs oudepote eidomen*—never saw.

**Calling of Levi (2:13-17):**
**The Key Verses (2:13-17):**
"'He saw Levi the son of Alphaeus sitting at the place of toll.'"

*Eiden Leuin ton tou Halphaiou kathēmenon epi to telōnion*—Levi.

**Levi = Matthew.**

"''Follow me.' And he arose and followed him.'"

*Akolouthei moi kai anastas ēkolouthēsen autō*—followed.

"'Many publicans and sinners sat down with Yeshua and his disciples.'"

*Polloi telōnai kai hamartōloi synanekeinto tō Iēsou kai tois mathētais autou*—ate together.

"''How is it that he eats and drinks with publicans and sinners?''"

*Hoti meta tōn telōnōn kai hamartōlōn esthiei*—why eat?

"''They that are whole have no need of a physician, but they that are sick.''"

*Ou chreian echousin hoi ischyontes iatrou all' hoi kakōs echontes*—physician.

"''I came not to call the righteous, but sinners.''"

*Ouk ēlthon kalesai dikaious alla hamartōlous*—call sinners.

**Fasting Question (2:18-22):**
**The Key Verses (2:18-22):**
"''Why do John's disciples and the disciples of the Pharisees fast, but your disciples fast not?''"

*Dia ti hoi mathētai Iōannou kai hoi mathētai tōn Pharisaiōn nēsteuousin hoi de soi mathētai ou nēsteuousin*—why not fast?

"''Can the sons of the bride-chamber fast, while the bridegroom is with them?''"

*Mē dynantai hoi huioi tou nymphōnos en hō ho nymphios met' autōn estin nēsteuein*—bridegroom present.

"''The bridegroom shall be taken away from them, and then will they fast in that day.''"

*Eleusontai de hēmerai hotan aparthē ap' autōn ho nymphios kai tote nēsteusousin en ekeinē tē hēmera*—taken away.

"''No man sews a piece of undressed cloth on an old garment.''"

*Oudeis epiblēma rhakous agnaphou epirhaptei epi himation palaion*—new patch.

"''No man puts new wine into old wine-skins.''"

*Kai oudeis ballei oinon neon eis askous palaious*—new wine.

"''They put new wine into fresh wine-skins.''"

*Alla oinon neon eis askous kainous*—fresh skins.

**Lord of the Sabbath (2:23-28):**
**The Key Verses (2:23-28):**
"'He was going on the sabbath day through the grain fields; and his disciples began... to pluck the ears.'"

*Egeneto auton en tois sabbasin paraporeuesthai dia tōn sporimōn kai oi mathētai autou ērxanto hodon poiein tillontes tous stachyas*—plucking grain.

"''Why do they on the sabbath day that which is not lawful?''"

*Ide ti poiousin tois sabbasin ho ouk exestin*—not lawful.

"''Did you never read what David did, when he had need, and was hungry?''"

*Oudepote anegnōte ti epoiēsen David hote chreian eschen kai epeinasen autos kai hoi met' autou*—David.

**1 Samuel 21:1-6.**

"''How he entered into the house of God when Abiathar was high priest.''"

*Pōs eisēlthen eis ton oikon tou theou epi Abiathar archiereōs*—Abiathar.

"''Ate the showbread, which it is not lawful to eat save for the priests.''"

*Kai tous artous tēs protheseōs ephagen hous ouk exestin phagein ei mē tous hiereis*—showbread.

"''The sabbath was made for man, and not man for the sabbath.''"

*To sabbaton dia ton anthrōpon egeneto kai ouch ho anthrōpos dia to sabbaton*—for man.

"''So that the Son of man is lord even of the sabbath.''"

*Hōste kyrios estin ho huios tou anthrōpou kai tou sabbatou*—lord of sabbath.

**Archetypal Layer:** Mark 2 contains **the paralytic lowered through the roof (2:1-12)**, **"Son, your sins are forgiven" (2:5)**, **"He blasphemes: who can forgive sins but one, even God?" (2:7)**, **"Which is easier... Your sins are forgiven; or... Arise, and take up your bed, and walk?" (2:9)**, **"the Son of man has authority on earth to forgive sins" (2:10)**, **calling of Levi the tax collector (2:13-14)**, **eating with publicans and sinners (2:15-16)**, **"They that are whole have no need of a physician, but they that are sick" (2:17)**, **"I came not to call the righteous, but sinners" (2:17)**, **bridegroom present = no fasting (2:19)**, **"the bridegroom shall be taken away" (2:20)**, **new wine in fresh wineskins (2:22)**, **plucking grain on sabbath (2:23-24)**, **David and the showbread (2:25-26)**, **"The sabbath was made for man, and not man for the sabbath" (2:27)**, and **"the Son of man is lord even of the sabbath" (2:28)**.

**Modern Equivalent:** Mark 2 introduces five conflict stories. The paralytic (2:1-12) demonstrates authority to forgive sins—the healing proves the forgiveness. Levi's call (2:13-14) and table fellowship (2:15-17) show Yeshua's mission to sinners. The fasting question (2:18-22) introduces the bridegroom metaphor and the incompatibility of new and old. The sabbath grain-plucking (2:23-28) culminates in "the sabbath was made for man" (2:27) and "the Son of man is lord even of the sabbath" (2:28)—human need supersedes ritual, and Yeshua has sabbath authority.

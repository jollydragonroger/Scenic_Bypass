# Mark 14: The Passion Begins — Anointing, Supper, Arrest, Trial

*From the Greek: Ἦν δὲ τὸ πάσχα καὶ τὰ ἄζυμα (Ēn de to Pascha kai ta Azyma) — Now After Two Days Was the Passover and the Unleavened Bread*

---

## The Plot and the Anointing (14:1-11)

**14:1** Now after two days was the feast of the Passover and the unleavened bread: and the chief priests and the scribes sought how they might take him with subtlety, and kill him:

**14:2** For they said: "Not during the feast, lest haply there shall be a tumult of the people."

**14:3** And while he was in Bethany in the house of Simon the leper, as he sat at meat, there came a woman having an alabaster cruse of ointment of pure nard very costly; and she broke the cruse, and poured it over his head.

**14:4** But there were some that had indignation among themselves, saying: "To what purpose has this waste of the ointment been made?

**14:5** "For this ointment might have been sold for above three hundred pence, and given to the poor." And they murmured against her.

**14:6** But Yeshua said: "Let her alone; why trouble you her? She has wrought a good work on me.

**14:7** "For you have the poor always with you, and whensoever you will you can do them good: but me you have not always.

**14:8** "She has done what she could; she has anointed my body beforehand for the burying.

**14:9** "And verily I say unto you, Wheresoever the good news shall be proclaimed throughout the whole world, that also which this woman has done shall be spoken of for a memorial of her."

**14:10** And Judas Iscariot, he that was one of the twelve, went away unto the chief priests, that he might deliver him unto them.

**14:11** And they, when they heard it, were glad, and promised to give him money. And he sought how he might conveniently deliver him unto them.

---

## The Last Supper (14:12-26)

**14:12** And on the first day of unleavened bread, when they sacrificed the Passover, his disciples say unto him: "Where will you that we go and make ready that you may eat the Passover?"

**14:13** And he sends two of his disciples, and says unto them: "Go into the city, and there shall meet you a man bearing a pitcher of water: follow him;

**14:14** "And wheresoever he shall enter in, say to the master of the house, 'The Teacher says, Where is my guest-chamber, where I shall eat the Passover with my disciples?'

**14:15** "And he will himself show you a large upper room furnished and ready: and there make ready for us."

**14:16** And the disciples went forth, and came into the city, and found as he had said unto them: and they made ready the Passover.

**14:17** And when it was evening he comes with the twelve.

**14:18** And as they sat and were eating, Yeshua said: "Verily I say unto you, One of you shall betray me, even he that eats with me."

**14:19** They began to be sorrowful, and to say unto him one by one: "Is it I?"

**14:20** And he said unto them: "It is one of the twelve, he that dips with me in the dish.

**14:21** "For the Son of man goes, even as it is written of him: but woe unto that man through whom the Son of man is betrayed! Good were it for that man if he had not been born."

**14:22** And as they were eating, he took bread, and when he had blessed, he broke it, and gave to them, and said: "Take: this is my body."

**14:23** And he took a cup, and when he had given thanks, he gave to them: and they all drank of it.

**14:24** And he said unto them: "This is my blood of the covenant, which is poured out for many.

**14:25** "Verily I say unto you, I shall no more drink of the fruit of the vine, until that day when I drink it new in the kingdom of God."

**14:26** And when they had sung a hymn, they went out unto the mount of Olives.

---

## Peter's Denial Foretold (14:27-31)

**14:27** And Yeshua says unto them: "All you shall be offended: for it is written, 'I will smite the shepherd, and the sheep shall be scattered abroad.'

**14:28** "However, after I am raised up, I will go before you into Galilee."

**14:29** But Peter said unto him: "Although all shall be offended, yet will not I."

**14:30** And Yeshua says unto him: "Verily I say unto you, that you today, even this night, before the cock crow twice, shall deny me thrice."

**14:31** But he spoke exceeding vehemently: "If I must die with you, I will not deny you." And in like manner also said they all.

---

## Gethsemane (14:32-42)

**14:32** And they come unto a place which was named Gethsemane: and he says unto his disciples: "Sit here, while I pray."

**14:33** And he takes with him Peter and James and John, and began to be greatly amazed, and sore troubled.

**14:34** And he says unto them: "My soul is exceeding sorrowful even unto death: abide here, and watch."

**14:35** And he went forward a little, and fell on the ground, and prayed that, if it were possible, the hour might pass away from him.

**14:36** And he said: "Abba, Father, all things are possible unto you; remove this cup from me: howbeit not what I will, but what you will."

**14:37** And he comes, and finds them sleeping, and says unto Peter: "Simon, are you sleeping? Could you not watch one hour?

**14:38** "Watch and pray, that you enter not into temptation: the spirit indeed is willing, but the flesh is weak."

**14:39** And again he went away, and prayed, saying the same words.

**14:40** And again he came, and found them sleeping, for their eyes were very heavy; and they knew not what to answer him.

**14:41** And he comes the third time, and says unto them: "Sleep on now, and take your rest: it is enough; the hour is come; behold, the Son of man is betrayed into the hands of sinners.

**14:42** "Arise, let us be going: behold, he that betrays me is at hand."

---

## The Arrest (14:43-52)

**14:43** And straightway, while he yet spoke, comes Judas, one of the twelve, and with him a multitude with swords and staves, from the chief priests and the scribes and the elders.

**14:44** Now he that betrayed him had given them a token, saying: "Whomsoever I shall kiss, that is he; take him, and lead him away safely."

**14:45** And when he was come, straightway he came to him, and says: "Rabbi"; and kissed him.

**14:46** And they laid hands on him, and took him.

**14:47** But a certain one of them that stood by drew his sword, and smote the servant of the high priest, and struck off his ear.

**14:48** And Yeshua answered and said unto them: "Are you come out, as against a robber, with swords and staves to seize me?

**14:49** "I was daily with you in the temple teaching, and you took me not: but this is done that the scriptures might be fulfilled."

**14:50** And they all left him, and fled.

**14:51** And a certain young man followed with him, having a linen cloth cast about him, over his naked body: and they lay hold on him;

**14:52** But he left the linen cloth, and fled naked.

---

## Before the Sanhedrin (14:53-65)

**14:53** And they led Yeshua away to the high priest: and there come together with him all the chief priests and the elders and the scribes.

**14:54** And Peter had followed him afar off, even within, into the court of the high priest; and he was sitting with the officers, and warming himself in the light of the fire.

**14:55** Now the chief priests and the whole council sought witness against Yeshua to put him to death; and found it not.

**14:56** For many bare false witness against him, and their witness agreed not together.

**14:57** And there stood up certain, and bare false witness against him, saying:

**14:58** "We heard him say, 'I will destroy this temple that is made with hands, and in three days I will build another made without hands.'"

**14:59** And not even so did their witness agree together.

**14:60** And the high priest stood up in the midst, and asked Yeshua, saying: "Do you answer nothing? What is it which these witness against you?"

**14:61** But he held his peace, and answered nothing. Again the high priest asked him, and says unto him: "Are you the Anointed, the Son of the Blessed?"

**14:62** And Yeshua said: "I am: and you shall see the Son of man sitting at the right hand of Power, and coming with the clouds of heaven."

**14:63** And the high priest tore his clothes, and says: "What further need have we of witnesses?

**14:64** "You have heard the blasphemy: what think you?" And they all condemned him to be worthy of death.

**14:65** And some began to spit on him, and to cover his face, and to buffet him, and to say unto him: "Prophesy": and the officers received him with blows of their hands.

---

## Peter's Denial (14:66-72)

**14:66** And as Peter was beneath in the court, there comes one of the maids of the high priest;

**14:67** And seeing Peter warming himself, she looked upon him, and says: "You also were with the Nazarene, even Yeshua."

**14:68** But he denied, saying: "I neither know, nor understand what you say": and he went out into the porch; and the cock crew.

**14:69** And the maid saw him, and began again to say to them that stood by: "This is one of them."

**14:70** But he again denied it. And after a little while again they that stood by said to Peter: "Of a truth you are one of them; for you are a Galilaean."

**14:71** But he began to curse, and to swear: "I know not this man of whom you speak."

**14:72** And straightway the second time the cock crew. And Peter called to mind the word, how that Yeshua said unto him: "Before the cock crow twice, you shall deny me thrice." And when he thought thereon, he wept.

---

## Synthesis Notes

**Key Restorations:**

**Plot and Anointing (14:1-11):**
"'After two days was the feast of the Passover and the unleavened bread.'"

*Ēn de to pascha kai ta azyma meta dyo hēmeras*—Passover.

"''Not during the feast, lest haply there shall be a tumult.''"

*Mē en tē heortē mēpote estai thorybos tou laou*—not during feast.

"'A woman having an alabaster cruse of ointment of pure nard very costly.'"

*Ēlthen gynē echousa alabastron myrou nardou pistikēs polytimou*—nard.

"'She broke the cruse, and poured it over his head.'"

*Syntripsasa tēn alabastron katecheen autou tēs kephalēs*—poured.

"''For this ointment might have been sold for above three hundred pence.''"

*Edynato gar touto to myron prathēnai epanō dēnariōn triakοsiōn*—300 denarii.

"''She has anointed my body beforehand for the burying.''"

*Proelaben myrisai to sōma mou eis ton entaphiasmon*—burial.

"''Wheresoever the good news shall be proclaimed... that also which this woman has done shall be spoken of for a memorial.''"

*Hopou ean kērychthē to euangelion... kai ho epoiēsen hautē lalēthēsetai eis mnēmosynon autēs*—memorial.

"'Judas Iscariot... went away unto the chief priests.''"

*Kai Ioudas Iskariōth... apēlthen pros tous archiereis*—betrayal.

**Last Supper (14:12-26):**
"'On the first day of unleavened bread, when they sacrificed the Passover.'"

*Kai tē prōtē hēmera tōn azymōn hote to pascha ethyon*—sacrifice.

"''A man bearing a pitcher of water.''"

*Anthrōpos keramion hydatos bastazōn*—man with pitcher.

**Unusual:**
Normally women carried water.

"''A large upper room furnished and ready.''"

*Anagaion mega estrōmenon hetoimon*—upper room.

"''One of you shall betray me, even he that eats with me.''"

*Heis ex hymōn paradōsei me ho esthiōn met' emou*—eats with me.

**Psalm 41:9.**

"''He that dips with me in the dish.''"

*Ho embaptomenos met' emou eis to hen tryblion*—dipping.

"''Woe unto that man through whom the Son of man is betrayed!''"

*Ouai de tō anthrōpō ekeinō di' hou ho huios tou anthrōpou paradidotai*—woe.

"'He took bread, and when he had blessed, he broke it.'"

*Labōn arton eulogēsas eklasen*—bread.

"''Take: this is my body.''"

*Labete touto estin to sōma mou*—body.

"'He took a cup, and when he had given thanks.'"

*Kai labōn potērion eucharistēsas*—cup.

"''This is my blood of the covenant, which is poured out for many.''"

*Touto estin to haima mou tēs diathēkēs to ekchynnomenon hyper pollōn*—blood, covenant.

"''I shall no more drink of the fruit of the vine, until that day when I drink it new in the kingdom of God.''"

*Ouketi ou mē piō ek tou genēmatos tēs ampelou heōs tēs hēmeras ekeinēs hotan auto pinō kainon en tē basileia tou theou*—new.

"'When they had sung a hymn.'"

*Kai hymnēsantes*—Hallel.

**Peter's Denial Foretold (14:27-31):**
"''I will smite the shepherd, and the sheep shall be scattered abroad.''"

*Pataxō ton poimena kai ta probata diaskorpisthēsontai*—Zechariah 13:7.

"''Before the cock crow twice, you shall deny me thrice.''"

*Prin ē dis alektora phōnēsai tris me aparnēsē*—twice, thrice.

**Only Mark:**
"Twice" detail.

**Gethsemane (14:32-42):**
"'A place which was named Gethsemane.'"

*Chōrion hou to onoma Gethsēmani*—Gethsemane.

"'He takes with him Peter and James and John.'"

*Kai paralambanei ton Petron kai ton Iakōbon kai ton Iōannēn*—inner three.

"'Began to be greatly amazed, and sore troubled.'"

*Ērxato ekthambeisthai kai adēmonein*—distressed.

"''My soul is exceeding sorrowful even unto death.''"

*Perilypos estin hē psychē mou heōs thanatou*—sorrowful.

"''Abba, Father, all things are possible unto you.''"

*Abba ho patēr panta dynata soi*—Abba.

**Abba:**
Aramaic "Father"—intimate address.

"''Remove this cup from me: howbeit not what I will, but what you will.''"

*Parenenke to potērion touto ap' emou all' ou ti egō thelō alla ti sy*—your will.

"''Simon, are you sleeping? Could you not watch one hour?''"

*Simōn katheudeis ouk ischysas mian hōran grēgorēsai*—one hour.

"''Watch and pray, that you enter not into temptation.''"

*Grēgoreite kai proseuchesthe hina mē elthēte eis peirasmon*—watch.

"''The spirit indeed is willing, but the flesh is weak.''"

*To men pneuma prothymon hē de sarx asthenēs*—spirit, flesh.

**Arrest (14:43-52):**
"'Comes Judas, one of the twelve, and with him a multitude with swords and staves.'"

*Paraginetai Ioudas heis tōn dōdeka kai met' autou ochlos meta machairōn kai xylōn*—multitude.

"''Whomsoever I shall kiss, that is he.''"

*Hon an philēsō autos estin*—kiss.

"''Rabbi'; and kissed him.''"

*Rhabbi kai katephilēsen auton*—kissed.

"''Are you come out, as against a robber?''"

*Hōs epi lēstēn exēlthate*—robber.

"''This is done that the scriptures might be fulfilled.''"

*All' hina plērōthōsin hai graphai*—scriptures.

"'They all left him, and fled.'"

*Kai aphentes auton ephygon pantes*—fled.

"'A certain young man followed with him, having a linen cloth cast about him, over his naked body.'"

*Kai neaniskos tis synēkolouthei autō peribeblēmenos sindona epi gymnou*—young man.

"'He left the linen cloth, and fled naked.'"

*Ho de katalipōn tēn sindona gymnos ephygen*—fled naked.

**Only Mark:**
This detail—possibly Mark himself.

**Before the Sanhedrin (14:53-65):**
"'The chief priests and the whole council sought witness against Yeshua to put him to death.'"

*Hoi de archiereis kai holon to synedrion ezētoun kata tou Iēsou martyrian eis to thanatōsai auton*—false witness.

"''We heard him say, I will destroy this temple that is made with hands.''"

*Hēmeis ēkousamen autou legontos hoti egō katalysō ton naon touton ton cheiropoiēton*—temple.

"''In three days I will build another made without hands.''"

*Kai dia triōn hēmerōn allon acheiropoiēton oikodomēsō*—without hands.

"'He held his peace, and answered nothing.'"

*Ho de esiōpa kai ouk apekrinato ouden*—silent.

**Isaiah 53:7.**

"''Are you the Anointed, the Son of the Blessed?''"

*Sy ei ho Christos ho huios tou eulogētou*—Blessed.

"''I am: and you shall see the Son of man sitting at the right hand of Power, and coming with the clouds of heaven.''"

*Egō eimi kai opsesthe ton huion tou anthrōpou ek dexiōn kathēmenon tēs dynameōs kai erchomenon meta tōn nephelōn tou ouranou*—I am.

**Egō Eimi + Psalm 110:1 + Daniel 7:13.**

"'The high priest tore his clothes... You have heard the blasphemy.'"

*Ho de archiereus diarrhēxas tous chitōnas autou... ēkousate tēs blasphēmias*—blasphemy.

"'They all condemned him to be worthy of death.'"

*Hoi de pantes katekrinan auton enochon einai thanatou*—death.

**Peter's Denial (14:66-72):**
"''You also were with the Nazarene, even Yeshua.' But he denied.''"

*Kai sy meta tou Nazarēnou ēstha tou Iēsou ho de ērnēsato*—denied.

"''I neither know, nor understand what you say.''"

*Oute oida oute epistamai sy ti legeis*—don't know.

"''You are a Galilaean.''"

*Kai gar Galilaios ei*—Galilean accent.

"'He began to curse, and to swear: I know not this man.'"

*Ho de ērxato anathematizein kai omnynai hoti ouk oida ton anthrōpon touton*—curse.

"'Straightway the second time the cock crew.'"

*Kai euthys ek deuterou alektōr ephōnēsen*—second time.

"'Peter called to mind the word... And when he thought thereon, he wept.'"

*Kai anemnēsthē ho Petros to rhēma... kai epibalōn eklaien*—wept.

**Archetypal Layer:** Mark 14 contains **plot against Yeshua (14:1-2)**, **anointing at Bethany (14:3-9)**: "She has anointed my body beforehand for the burying" (14:8), "a memorial of her" (14:9), **Judas's betrayal (14:10-11)**, **preparation for Passover (14:12-16)**, **"One of you shall betray me, even he that eats with me" (14:18)**, **Last Supper (14:22-25)**: "Take: this is my body" (14:22), "This is my blood of the covenant, which is poured out for many" (14:24), **"I will smite the shepherd" (Zechariah 13:7) (14:27)**, **"before the cock crow twice, you shall deny me thrice" (14:30)**, **Gethsemane (14:32-42)**: "Abba, Father" (14:36), "remove this cup from me: howbeit not what I will, but what you will" (14:36), "the spirit indeed is willing, but the flesh is weak" (14:38), **arrest with Judas's kiss (14:43-46)**, **young man fleeing naked (14:51-52)**, **trial before the Sanhedrin (14:53-65)**: "Are you the Anointed, the Son of the Blessed?" (14:61), **"I am" (egō eimi) (14:62)**, Psalm 110:1 + Daniel 7:13 (14:62), "blasphemy" (14:64), and **Peter's three denials (14:66-72)**: cock crows twice, Peter weeps.

**Modern Equivalent:** Mark 14 begins the Passion narrative. The anointing (14:3-9) is prophetic burial preparation. Judas's betrayal (14:10-11) contrasts with the woman's devotion. The Last Supper (14:22-25) establishes covenant in Yeshua's blood. Gethsemane (14:32-42) shows Yeshua's anguish—"Abba" expresses intimacy; "not what I will, but what you will" shows submission. The arrest (14:43-50) includes the unique young man fleeing naked (14:51-52). The trial (14:53-65) reaches its climax with "I am" (14:62)—combining Exodus 3:14, Psalm 110:1, and Daniel 7:13. Peter's denial (14:66-72) fulfills the prediction, with Mark's specific detail of the cock crowing twice.

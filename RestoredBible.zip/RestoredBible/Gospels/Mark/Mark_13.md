# Mark 13: The Little Apocalypse

*From the Greek: Καὶ ἐκπορευομένου αὐτοῦ ἐκ τοῦ ἱεροῦ (Kai Ekporeuomenou Autou ek tou Hierou) — And As He Went Forth out of the Temple*

---

## The Temple's Destruction Foretold (13:1-4)

**13:1** And as he went forth out of the temple, one of his disciples says unto him: "Teacher, behold, what manner of stones and what manner of buildings!"

**13:2** And Yeshua said unto him: "See you these great buildings? There shall not be left here one stone upon another, which shall not be thrown down."

**13:3** And as he sat on the mount of Olives over against the temple, Peter and James and John and Andrew asked him privately:

**13:4** "Tell us, when shall these things be? And what shall be the sign when these things are all about to be accomplished?"

---

## Signs of the End (13:5-13)

**13:5** And Yeshua began to say unto them: "Take heed that no man lead you astray.

**13:6** "Many shall come in my name, saying, 'I am he'; and shall lead many astray.

**13:7** "And when you shall hear of wars and rumors of wars, be not troubled: these things must needs come to pass; but the end is not yet.

**13:8** "For nation shall rise against nation, and kingdom against kingdom; there shall be earthquakes in divers places; there shall be famines: these things are the beginning of travail.

**13:9** "But take heed to yourselves: for they shall deliver you up to councils; and in synagogues shall you be beaten; and before governors and kings shall you stand for my sake, for a testimony unto them.

**13:10** "And the good news must first be proclaimed unto all the nations.

**13:11** "And when they lead you to judgment, and deliver you up, be not anxious beforehand what you shall speak: but whatsoever shall be given you in that hour, that speak: for it is not you that speak, but the Holy Spirit.

**13:12** "And brother shall deliver up brother to death, and the father his child; and children shall rise up against parents, and cause them to be put to death.

**13:13** "And you shall be hated of all men for my name's sake: but he that endures to the end, the same shall be saved."

---

## The Abomination of Desolation (13:14-23)

**13:14** "But when you see the abomination of desolation standing where he ought not (let him that reads understand), then let them that are in Judaea flee unto the mountains:

**13:15** "And let him that is on the housetop not go down, nor enter in, to take anything out of his house:

**13:16** "And let him that is in the field not return back to take his cloak.

**13:17** "But woe unto them that are with child and to them that nurse in those days!

**13:18** "And pray that it be not in the winter.

**13:19** "For those days shall be tribulation, such as there has not been the like from the beginning of the creation which God created until now, and never shall be.

**13:20** "And except the Lord had shortened the days, no flesh would have been saved; but for the elect's sake, whom he chose, he shortened the days.

**13:21** "And then if any man shall say unto you, 'Lo, here is the Anointed'; or, 'Lo, there'; believe it not:

**13:22** "For there shall arise false anointed ones and false prophets, and shall show signs and wonders, that they may lead astray, if possible, the elect.

**13:23** "But take heed: behold, I have told you all things beforehand."

---

## The Coming of the Son of Man (13:24-27)

**13:24** "But in those days, after that tribulation, the sun shall be darkened, and the moon shall not give her light,

**13:25** "And the stars shall be falling from heaven, and the powers that are in the heavens shall be shaken.

**13:26** "And then shall they see the Son of man coming in clouds with great power and glory.

**13:27** "And then shall he send forth the angels, and shall gather together his elect from the four winds, from the uttermost part of the earth to the uttermost part of heaven."

---

## The Lesson of the Fig Tree (13:28-31)

**13:28** "Now from the fig tree learn her parable: when her branch is now become tender, and puts forth its leaves, you know that the summer is near;

**13:29** "Even so you also, when you see these things coming to pass, know that he is near, even at the doors.

**13:30** "Verily I say unto you, This generation shall not pass away, until all these things be accomplished.

**13:31** "Heaven and earth shall pass away: but my words shall not pass away."

---

## Exhortation to Watchfulness (13:32-37)

**13:32** "But of that day or that hour knows no one, not even the angels in heaven, neither the Son, but the Father.

**13:33** "Take heed, watch and pray: for you know not when the time is.

**13:34** "It is as when a man, sojourning in another country, having left his house, and given authority to his servants, to each one his work, commanded also the porter to watch.

**13:35** "Watch therefore: for you know not when the lord of the house comes, whether at even, or at midnight, or at cock-crowing, or in the morning;

**13:36** "Lest coming suddenly he find you sleeping.

**13:37** "And what I say unto you I say unto all, Watch."

---

## Synthesis Notes

**Key Restorations:**

**Temple's Destruction (13:1-4):**
**The Key Verses (13:1-4):**
"''Teacher, behold, what manner of stones and what manner of buildings!''"

*Didaskale ide potapoi lithoi kai potapai oikodomai*—stones, buildings.

"''See you these great buildings? There shall not be left here one stone upon another.''"

*Blepeis tautas tas megalas oikodomas ou mē aphethē hōde lithos epi lithon*—destroyed.

"'As he sat on the mount of Olives over against the temple.'"

*Kai kathēmenou autou eis to oros tōn elaiōn katenanti tou hierou*—Olivet.

"'Peter and James and John and Andrew asked him privately.'"

*Epērōta auton kat' idian Petros kai Iakōbos kai Iōannēs kai Andreas*—four disciples.

"''When shall these things be? And what shall be the sign?''"

*Eipe hēmin pote tauta estai kai ti to sēmeion*—when, sign.

**Signs of the End (13:5-13):**
**The Key Verses (13:5-8):**
"''Take heed that no man lead you astray.''"

*Blepete mē tis hymas planēsē*—don't be deceived.

"''Many shall come in my name, saying, I am he.''"

*Polloi eleusontai epi tō onomati mou legontes hoti egō eimi*—I am.

"''Wars and rumors of wars... the end is not yet.''"

*Polemous kai akoas polemōn... oupō to telos*—not yet.

"''Nation shall rise against nation.''"

*Egerthēsetai ethnos ep' ethnos*—nation.

"''There shall be earthquakes in divers places; there shall be famines.''"

*Esontai seismoi kata topous esontai limoi*—earthquakes, famines.

"''These things are the beginning of travail.''"

*Archē ōdinōn tauta*—birth pains.

**The Key Verses (13:9-13):**
"''They shall deliver you up to councils; and in synagogues shall you be beaten.''"

*Paradōsousin hymas eis synedria kai eis synagōgas darēsesthe*—councils, synagogues.

"''Before governors and kings shall you stand for my sake.''"

*Kai epi hēgemonōn kai basileōn stathēsesthe heneken emou*—governors, kings.

"''The good news must first be proclaimed unto all the nations.''"

*Kai eis panta ta ethnē prōton dei kērychthēnai to euangelion*—all nations first.

"''Be not anxious beforehand what you shall speak.''"

*Mē promerimنate ti lalēsēte*—don't be anxious.

"''It is not you that speak, but the Holy Spirit.''"

*Ou gar este hymeis hoi lalountes alla to pneuma to hagion*—Holy Spirit.

"''Brother shall deliver up brother to death.''"

*Kai paradōsei adelphos adelphon eis thanaton*—betrayal.

"''You shall be hated of all men for my name's sake.''"

*Kai esesthe misoumenoi hypo pantōn dia to onoma mou*—hated.

"''He that endures to the end, the same shall be saved.''"

*Ho de hypomeinas eis telos houtos sōthēsetai*—endure.

**Abomination of Desolation (13:14-23):**
**The Key Verses (13:14-20):**
"''The abomination of desolation standing where he ought not.''"

*To bdelygma tēs erēmōseōs hestēkota hopou ou dei*—abomination.

**Daniel 9:27, 11:31, 12:11.**

"''Let him that reads understand.''"

*Ho anaginōskōn noeitō*—understand.

"''Let them that are in Judaea flee unto the mountains.''"

*Hoi en tē Ioudaia pheugetōsan eis ta orē*—flee.

"''Let him that is on the housetop not go down.''"

*Ho de epi tou dōmatos mē katabatō*—urgency.

"''Woe unto them that are with child and to them that nurse in those days!''"

*Ouai de tais en gastri echousais kai tais thēlazousais en ekeinais tais hēmerais*—woe.

"''Those days shall be tribulation, such as there has not been the like.''"

*Esontai gar hai hēmerai ekeinai thlipsis hoia ou gegonen toiautē*—unprecedented.

"''Except the Lord had shortened the days, no flesh would have been saved.''"

*Kai ei mē ekolobōsen kyrios tas hēmeras ouk an esōthē pasa sarx*—shortened.

"''For the elect's sake, whom he chose, he shortened the days.''"

*Alla dia tous eklektous hous exelexato ekolobōsen tas hēmeras*—elect.

**The Key Verses (13:21-23):**
"''If any man shall say unto you, Lo, here is the Anointed... believe it not.''"

*Kai tote ean tis hymin eipē ide hōde ho Christos... mē pisteuete*—don't believe.

"''There shall arise false anointed ones and false prophets.''"

*Egerthēsontai gar pseudochristoi kai pseudoprophētai*—false.

"''Shall show signs and wonders, that they may lead astray, if possible, the elect.''"

*Kai dōsousin sēmeia kai terata pros to apoplanān ei dynaton tous eklektous*—signs.

"''Behold, I have told you all things beforehand.''"

*Hymeis de blepete proeirēka hymin panta*—forewarned.

**Coming of the Son of Man (13:24-27):**
**The Key Verses (13:24-27):**
"''In those days, after that tribulation.''"

*Alla en ekeinais tais hēmerais meta tēn thlipsin ekeinēn*—after tribulation.

"''The sun shall be darkened, and the moon shall not give her light.''"

*Ho hēlios skotisthēsetai kai hē selēnē ou dōsei to phengos autēs*—cosmic signs.

**Isaiah 13:10, 34:4.**

"''The stars shall be falling from heaven.''"

*Kai hoi asteres esontai ek tou ouranou piptontes*—stars fall.

"''The powers that are in the heavens shall be shaken.''"

*Kai hai dynameis hai en tois ouranois saleuthēsontai*—powers shaken.

"''They see the Son of man coming in clouds with great power and glory.''"

*Kai tote opsontai ton huion tou anthrōpou erchomenon en nephelais meta dynameōs pollēs kai doxēs*—coming.

**Daniel 7:13-14.**

"''He send forth the angels, and shall gather together his elect from the four winds.''"

*Kai tote apostelei tous angelous kai episynaxei tous eklektous autou ek tōn tessarōn anemōn*—gather.

**Lesson of the Fig Tree (13:28-31):**
**The Key Verses (13:28-31):**
"''From the fig tree learn her parable.''"

*Apo de tēs sykēs mathete tēn parabolēn*—fig tree.

"''When her branch is now become tender, and puts forth its leaves, you know that the summer is near.''"

*Hotan ēdē ho klados autēs hapalos genētai kai ekphyē ta phylla ginōskete hoti engys to theros estin*—summer near.

"''Even so you also, when you see these things coming to pass.''"

*Houtōs kai hymeis hotan idēte tauta ginomena*—see.

"''Know that he is near, even at the doors.''"

*Ginōskete hoti engys estin epi thyrais*—at doors.

"''This generation shall not pass away, until all these things be accomplished.''"

*Amēn legō hymin hoti ou mē parelthē hē genea hautē mechris hou tauta panta genētai*—generation.

"''Heaven and earth shall pass away: but my words shall not pass away.''"

*Ho ouranos kai hē gē pareleusontai hoi de logoi mou ou mē pareleusontai*—words endure.

**Exhortation to Watchfulness (13:32-37):**
**The Key Verses (13:32-37):**
"''Of that day or that hour knows no one, not even the angels in heaven, neither the Son, but the Father.''"

*Peri de tēs hēmeras ekeinēs ē tēs hōras oudeis oiden oude hoi angeloi en ouranō oude ho huios ei mē ho patēr*—unknown.

"''Take heed, watch and pray: for you know not when the time is.''"

*Blepete agrypneite kai proseuchesthe ouk oidate gar pote ho kairos estin*—watch.

"''A man, sojourning in another country, having left his house.''"

*Hōs anthrōpos apodēmos apheis tēn oikian autou*—absent master.

"''Given authority to his servants... commanded also the porter to watch.''"

*Kai dous tois doulois autou tēn exousian... kai tō thyrōrō eneteilato hina grēgorē*—watch.

"''Watch therefore: for you know not when the lord of the house comes.''"

*Grēgoreite oun ouk oidate gar pote ho kyrios tēs oikias erchetai*—watch.

"''Whether at even, or at midnight, or at cock-crowing, or in the morning.''"

*E opse ē mesonyktiou ē alektorophōnias ē prōi*—four watches.

"''Lest coming suddenly he find you sleeping.''"

*Mē elthōn exaiphnēs heurē hymas katheudontas*—sleeping.

"''What I say unto you I say unto all, Watch.''"

*Ho de hymin legō pasin legō grēgoreite*—all.

**Archetypal Layer:** Mark 13 is the **Little Apocalypse/Olivet Discourse**, containing **"There shall not be left here one stone upon another" (13:2)**, **"When shall these things be? And what shall be the sign?" (13:4)**, **"Take heed that no man lead you astray" (13:5)**, **"Many shall come in my name, saying, I am he" (13:6)**, **"wars and rumors of wars... the end is not yet" (13:7)**, **"the beginning of travail" (13:8)**, **"deliver you up to councils... in synagogues shall you be beaten" (13:9)**, **"the good news must first be proclaimed unto all the nations" (13:10)**, **"it is not you that speak, but the Holy Spirit" (13:11)**, **"he that endures to the end, the same shall be saved" (13:13)**, **"the abomination of desolation standing where he ought not" (13:14)**, **"tribulation, such as there has not been the like" (13:19)**, **"for the elect's sake... he shortened the days" (13:20)**, **"false anointed ones and false prophets... signs and wonders" (13:22)**, **cosmic signs: sun darkened, moon, stars (13:24-25)**, **"the Son of man coming in clouds with great power and glory" (Daniel 7:13) (13:26)**, **"gather together his elect from the four winds" (13:27)**, **fig tree parable (13:28-29)**, **"This generation shall not pass away" (13:30)**, **"Heaven and earth shall pass away: but my words shall not pass away" (13:31)**, **"of that day or that hour knows no one, not even the angels in heaven, neither the Son, but the Father" (13:32)**, and **"Watch" (13:33, 35, 37)**.

**Modern Equivalent:** Mark 13 is Yeshua's eschatological discourse. It blends near (70 CE) and far (parousia) horizons. The temple's destruction (13:2) happened in 70 CE. Signs include false messiahs, wars, earthquakes, famines (birth pains), persecution, and betrayal (13:5-13). The abomination of desolation (13:14) signals urgent flight. The tribulation is unprecedented (13:19). After tribulation, cosmic signs precede the Son of man's coming (13:24-26). The key command is "Watch" (13:33-37)—no one knows the day/hour, not even the Son (13:32). Watchfulness is the only proper response to uncertainty.

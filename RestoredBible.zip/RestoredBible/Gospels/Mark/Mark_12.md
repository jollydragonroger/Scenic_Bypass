# Mark 12: Parables and Controversies in Jerusalem

*From the Greek: Καὶ ἤρξατο αὐτοῖς ἐν παραβολαῖς λαλεῖν (Kai Ērxato Autois en Parabolais Lalein) — And He Began to Speak unto Them in Parables*

---

## The Parable of the Wicked Tenants (12:1-12)

**12:1** And he began to speak unto them in parables. "A man planted a vineyard, and set a hedge about it, and dug a pit for the winepress, and built a tower, and let it out to husbandmen, and went into another country.

**12:2** "And at the season he sent to the husbandmen a servant, that he might receive from the husbandmen of the fruits of the vineyard.

**12:3** "And they took him, and beat him, and sent him away empty.

**12:4** "And again he sent unto them another servant; and him they wounded in the head, and handled shamefully.

**12:5** "And he sent another; and him they killed: and many others; beating some, and killing some.

**12:6** "He had yet one, a beloved son: he sent him last unto them, saying, 'They will reverence my son.'

**12:7** "But those husbandmen said among themselves, 'This is the heir; come, let us kill him, and the inheritance shall be ours.'

**12:8** "And they took him, and killed him, and cast him forth out of the vineyard.

**12:9** "What therefore will the lord of the vineyard do? He will come and destroy the husbandmen, and will give the vineyard unto others.

**12:10** "Have you not read even this scripture: 'The stone which the builders rejected, the same was made the head of the corner;

**12:11** "'This was from the Lord, and it is marvellous in our eyes'?"

**12:12** And they sought to lay hold on him; and they feared the multitude; for they perceived that he spoke the parable against them: and they left him, and went away.

---

## Paying Tribute to Caesar (12:13-17)

**12:13** And they send unto him certain of the Pharisees and of the Herodians, that they might catch him in talk.

**12:14** And when they were come, they say unto him: "Teacher, we know that you are true, and care not for any one; for you regard not the person of men, but of a truth teach the way of God: Is it lawful to give tribute unto Caesar, or not?

**12:15** "Shall we give, or shall we not give?" But he, knowing their hypocrisy, said unto them: "Why do you try me? Bring me a denarius, that I may see it."

**12:16** And they brought it. And he says unto them: "Whose is this image and superscription?" And they said unto him: "Caesar's."

**12:17** And Yeshua said unto them: "Render unto Caesar the things that are Caesar's, and unto God the things that are God's." And they marvelled greatly at him.

---

## The Resurrection Question (12:18-27)

**12:18** And there come unto him Sadducees, who say that there is no resurrection; and they asked him, saying:

**12:19** "Teacher, Moses wrote unto us, 'If a man's brother die, and leave a wife behind him, and leave no child, that his brother should take his wife, and raise up seed unto his brother.'

**12:20** "There were seven brethren: and the first took a wife, and dying left no seed;

**12:21** "And the second took her, and died, leaving no seed behind him; and the third likewise:

**12:22** "And the seven left no seed. Last of all the woman also died.

**12:23** "In the resurrection whose wife shall she be of them? For the seven had her to wife."

**12:24** Yeshua said unto them: "Is it not for this cause that you err, that you know not the scriptures, nor the power of God?

**12:25** "For when they shall rise from the dead, they neither marry, nor are given in marriage; but are as angels in heaven.

**12:26** "But as touching the dead, that they are raised; have you not read in the book of Moses, in the place concerning the Bush, how God spoke unto him, saying: 'I am the God of Abraham, and the God of Isaac, and the God of Jacob'?

**12:27** "He is not the God of the dead, but of the living: you do greatly err."

---

## The Great Commandment (12:28-34)

**12:28** And one of the scribes came, and heard them questioning together, and knowing that he had answered them well, asked him: "What commandment is the first of all?"

**12:29** Yeshua answered: "The first is, 'Hear, O Israel; The Lord our God, the Lord is one:

**12:30** "'And you shall love the Lord your God with all your heart, and with all your soul, and with all your mind, and with all your strength.'

**12:31** "The second is this: 'You shall love your neighbour as yourself.' There is none other commandment greater than these."

**12:32** And the scribe said unto him: "Of a truth, Teacher, you have well said that he is one; and there is none other but he:

**12:33** "And to love him with all the heart, and with all the understanding, and with all the strength, and to love his neighbour as himself, is much more than all whole burnt-offerings and sacrifices."

**12:34** And when Yeshua saw that he answered discreetly, he said unto him: "You are not far from the kingdom of God." And no man after that dared ask him any question.

---

## David's Son and Lord (12:35-37)

**12:35** And Yeshua answered and said, as he taught in the temple: "How say the scribes that the Anointed is the son of David?

**12:36** "David himself said in the Holy Spirit: 'The Lord said unto my Lord, Sit on my right hand, till I make your enemies the footstool of your feet.'

**12:37** "David himself calls him Lord; and whence is he his son?" And the common people heard him gladly.

---

## Warning against the Scribes (12:38-40)

**12:38** And in his teaching he said: "Beware of the scribes, who desire to walk in long robes, and to have salutations in the marketplaces,

**12:39** "And chief seats in the synagogues, and chief places at feasts:

**12:40** "They that devour widows' houses, and for a pretence make long prayers; these shall receive greater condemnation."

---

## The Widow's Offering (12:41-44)

**12:41** And he sat down over against the treasury, and beheld how the multitude cast money into the treasury: and many that were rich cast in much.

**12:42** And there came a poor widow, and she cast in two mites, which make a farthing.

**12:43** And he called unto him his disciples, and said unto them: "Verily I say unto you, This poor widow cast in more than all they that are casting into the treasury:

**12:44** "For they all did cast in of their superfluity; but she of her want did cast in all that she had, even all her living."

---

## Synthesis Notes

**Key Restorations:**

**Wicked Tenants (12:1-12):**
**The Key Verses (12:1-9):**
"''A man planted a vineyard, and set a hedge about it.''"

*Ampelōna anthrōpos ephyteusen kai periethēken phragmon*—vineyard.

**Isaiah 5:1-7.**

"''And dug a pit for the winepress, and built a tower.''"

*Kai ōryxen hypolēnion kai ōkodomēsen pyrgon*—tower.

"''Let it out to husbandmen, and went into another country.''"

*Kai exedeto auton geōrgois kai apedēmēsen*—tenants.

"''At the season he sent to the husbandmen a servant.''"

*Kai apesteilen pros tous geōrgous tō kairō doulon*—servant = prophet.

"''They took him, and beat him, and sent him away empty.''"

*Kai labontes auton edeiran kai apesteilan kenon*—beat.

"''He had yet one, a beloved son: he sent him last unto them.''"

*Eti hena eichen huion agapēton apesteilen auton eschaton pros autous*—beloved son.

"''This is the heir; come, let us kill him.''"

*Houtos estin ho klēronomos deute apokteinōmen auton*—kill heir.

"''The inheritance shall be ours.''"

*Kai hēmōn estai hē klēronomia*—inheritance.

"''They took him, and killed him, and cast him forth out of the vineyard.''"

*Kai labontes apekteinan auton kai exebalon auton exō tou ampelōnos*—killed.

"''He will come and destroy the husbandmen, and will give the vineyard unto others.''"

*Eleusetai kai apolesei tous geōrgous kai dōsei ton ampelōna allois*—destroy, give.

**The Key Verses (12:10-12):**
"''The stone which the builders rejected, the same was made the head of the corner.''"

*Lithon hon apedokimasan hoi oikodomountes houtos egenēthē eis kephalēn gōnias*—cornerstone.

**Psalm 118:22-23.**

"''This was from the Lord, and it is marvellous in our eyes.''"

*Para kyriou egeneto hautē kai estin thaumastē en ophthalmois hēmōn*—Lord's doing.

"'They perceived that he spoke the parable against them.'"

*Egnōsan gar hoti pros autous tēn parabolēn eipen*—against them.

**Tribute to Caesar (12:13-17):**
**The Key Verses (12:13-17):**
"'They send unto him certain of the Pharisees and of the Herodians.'"

*Kai apostellousin pros auton tinas tōn Pharisaiōn kai tōn Hērōdianōn*—Pharisees, Herodians.

"''Is it lawful to give tribute unto Caesar, or not?''"

*Exestin dounai kēnson Kaisari ē ou*—lawful?

"'He, knowing their hypocrisy.'"

*Ho de eidōs autōn tēn hypokrisin*—hypocrisy.

"''Bring me a denarius, that I may see it.''"

*Pherete moi dēnarion hina idō*—denarius.

"''Whose is this image and superscription?' 'Caesar's.''"

*Tinos hē eikōn hautē kai hē epigraphē... Kaisaros*—Caesar's.

"''Render unto Caesar the things that are Caesar's, and unto God the things that are God's.''"

*Ta Kaisaros apodote Kaisari kai ta tou theou tō theō*—render.

"'They marvelled greatly at him.'"

*Kai exethaumazon ep' autō*—marvelled.

**Resurrection Question (12:18-27):**
**The Key Verses (12:18-27):**
"'Sadducees, who say that there is no resurrection.'"

*Saddoukaioi hoitines legousin anastasin mē einai*—no resurrection.

"''Moses wrote unto us, If a man's brother die.''"

*Mōusēs egrapsen hēmin hoti ean tinos adelphos apothanē*—Deuteronomy 25:5.

"''In the resurrection whose wife shall she be of them?''"

*En tē anastasei hotan anastōsin tinos autōn estai gynē*—whose wife?

"''You err... you know not the scriptures, nor the power of God.''"

*Ou dia touto planasthe mē eidotes tas graphas mēde tēn dynamin tou theou*—err.

"''When they shall rise from the dead, they neither marry, nor are given in marriage.''"

*Hotan gar ek nekrōn anastōsin oute gamousin oute gamizontai*—no marriage.

"''But are as angels in heaven.''"

*All' eisin hōs angeloi en tois ouranois*—like angels.

"''In the book of Moses, in the place concerning the Bush.''"

*En tē biblō Mōuseōs epi tou batou*—the Bush.

"''I am the God of Abraham, and the God of Isaac, and the God of Jacob.''"

*Egō ho theos Abraam kai ho theos Isaak kai ho theos Iakōb*—Exodus 3:6.

"''He is not the God of the dead, but of the living.''"

*Ouk estin theos nekrōn alla zōntōn*—God of living.

**Great Commandment (12:28-34):**
**The Key Verses (12:28-34):**
"''What commandment is the first of all?''"

*Poia estin entolē prōtē pantōn*—first.

"''Hear, O Israel; The Lord our God, the Lord is one.''"

*Akoue Israēl kyrios ho theos hēmōn kyrios heis estin*—Shema.

**Deuteronomy 6:4-5.**

"''You shall love the Lord your God with all your heart.''"

*Kai agapēseis kyrion ton theon sou ex holēs tēs kardias sou*—love God.

"''With all your soul, and with all your mind, and with all your strength.''"

*Kai ex holēs tēs psychēs sou kai ex holēs tēs dianoias sou kai ex holēs tēs ischyos sou*—all.

"''You shall love your neighbour as yourself.''"

*Agapēseis ton plēsion sou hōs seauton*—neighbor.

**Leviticus 19:18.**

"''There is none other commandment greater than these.''"

*Meizōn toutōn allē entolē ouk estin*—greatest.

"''To love him... is much more than all whole burnt-offerings and sacrifices.''"

*Perissoteron estin pantōn tōn holokautōmatōn kai thysiōn*—more than sacrifices.

"''You are not far from the kingdom of God.''"

*Ou makran ei apo tēs basileias tou theou*—not far.

"'No man after that dared ask him any question.'"

*Kai oudeis ouketi etolma auton eperōtēsai*—no more questions.

**David's Son and Lord (12:35-37):**
**The Key Verses (12:35-37):**
"''How say the scribes that the Anointed is the son of David?''"

*Pōs legousin hoi grammateis hoti ho Christos huios David estin*—David's son.

"''David himself said in the Holy Spirit.''"

*Autos David eipen en tō pneumati tō hagiō*—Holy Spirit.

"''The Lord said unto my Lord, Sit on my right hand.''"

*Eipen kyrios tō kyriō mou kathou ek dexiōn mou*—Psalm 110:1.

"''David himself calls him Lord; and whence is he his son?''"

*Autos David legei auton kyrion kai pothen autou estin huios*—how son?

"'The common people heard him gladly.'"

*Kai ho polys ochlos ēkouen autou hēdeōs*—gladly.

**Warning against Scribes (12:38-40):**
"''Beware of the scribes, who desire to walk in long robes.''"

*Blepete apo tōn grammateōn tōn thelontōn en stolais peripatein*—long robes.

"''Salutations in the marketplaces, and chief seats in the synagogues.''"

*Kai aspasmous en tais agorais kai prōtokathedrias en tais synagōgais*—honor.

"''They that devour widows' houses.''"

*Hoi katesthiontes tas oikias tōn chērōn*—devour.

"''For a pretence make long prayers.''"

*Kai prophasei makra proseuchomenoi*—long prayers.

"''These shall receive greater condemnation.''"

*Houtoi lēmpsontai perissoteron krima*—condemnation.

**Widow's Offering (12:41-44):**
**The Key Verses (12:41-44):**
"'He sat down over against the treasury.'"

*Kai kathisas katenanti tou gazophylakiou*—treasury.

"'Many that were rich cast in much.'"

*Kai polloi plousioi eballon polla*—rich, much.

"'A poor widow... cast in two mites, which make a farthing.'"

*Chēra ptōchē mia... ebalen lepta dyo ho estin kodrантēs*—two mites.

**Lepton:**
Smallest copper coin.

"''This poor widow cast in more than all.''"

*Hē chēra hautē hē ptōchē pleion pantōn ebalen*—more.

"''They all did cast in of their superfluity.''"

*Pantes gar ek tou perisseuontos autois ebalon*—surplus.

"''She of her want did cast in all that she had, even all her living.''"

*Hautē de ek tēs hysterēseōs autēs panta hosa eichen ebalen holon ton bion autēs*—all living.

**Archetypal Layer:** Mark 12 contains **parable of the wicked tenants (12:1-12)**: vineyard, servants beaten/killed, beloved son killed, **"The stone which the builders rejected, the same was made the head of the corner" (Psalm 118:22-23) (12:10-11)**, **"Render unto Caesar the things that are Caesar's, and unto God the things that are God's" (12:17)**, **Sadducees' resurrection question (12:18-27)**, **"You err, that you know not the scriptures, nor the power of God" (12:24)**, **"He is not the God of the dead, but of the living" (12:27)**, **the great commandment (12:28-34)**: Shema (Deuteronomy 6:4-5) + love neighbor (Leviticus 19:18), **"To love him... is much more than all whole burnt-offerings and sacrifices" (12:33)**, **"You are not far from the kingdom of God" (12:34)**, **David's Son and Lord (12:35-37)**: Psalm 110:1, **warning against scribes (12:38-40)**: long robes, chief seats, devouring widows' houses, and **the widow's offering (12:41-44)**: "she of her want did cast in all that she had, even all her living" (12:44).

**Modern Equivalent:** Mark 12 presents Jerusalem controversies. The wicked tenants (12:1-12) transparently indicts Israel's leaders—they will kill the son. The Caesar question (12:13-17) is answered with profound wisdom. The Sadducees' resurrection trap (12:18-27) is refuted from the Torah they accept—the "I am" proves ongoing relationship with the patriarchs. The great commandment (12:28-34) combines love of God and neighbor; the scribe's response earns "not far from the kingdom" (12:34). The David's Lord riddle (12:35-37) implies Messiah is greater than David. The widow's offering (12:41-44) contrasts true devotion with the scribes' exploitation of widows (12:40).

# Mark 4: Parables and Power over Nature

*From the Greek: Καὶ πάλιν ἤρξατο διδάσκειν (Kai Palin Ērxato Didaskein) — And Again He Began to Teach*

---

## The Parable of the Sower (4:1-20)

**4:1** And again he began to teach by the sea side. And there is gathered unto him a very great multitude, so that he entered into a boat, and sat in the sea; and all the multitude were by the sea on the land.

**4:2** And he taught them many things in parables, and said unto them in his teaching:

**4:3** "Hearken: Behold, the sower went forth to sow:

**4:4** "And it came to pass, as he sowed, some seed fell by the way side, and the birds came and devoured it.

**4:5** "And other fell on the rocky ground, where it had not much earth; and straightway it sprang up, because it had no deepness of earth:

**4:6** "And when the sun was risen, it was scorched; and because it had no root, it withered away.

**4:7** "And other fell among the thorns, and the thorns grew up, and choked it, and it yielded no fruit.

**4:8** "And others fell into the good ground, and yielded fruit, growing up and increasing; and brought forth, thirtyfold, and sixtyfold, and a hundredfold."

**4:9** And he said: "Who has ears to hear, let him hear."

**4:10** And when he was alone, they that were about him with the twelve asked of him the parables.

**4:11** And he said unto them: "Unto you is given the mystery of the kingdom of God: but unto them that are without, all things are done in parables:

**4:12** "That seeing they may see, and not perceive; and hearing they may hear, and not understand; lest haply they should turn again, and it should be forgiven them."

**4:13** And he says unto them: "Know you not this parable? And how shall you know all the parables?

**4:14** "The sower sows the word.

**4:15** "And these are they by the way side, where the word is sown; and when they have heard, straightway comes Satan, and takes away the word which has been sown in them.

**4:16** "And these in like manner are they that are sown upon the rocky places, who, when they have heard the word, straightway receive it with joy;

**4:17** "And they have no root in themselves, but endure for a while; then, when tribulation or persecution arises because of the word, straightway they stumble.

**4:18** "And others are they that are sown among the thorns; these are they that have heard the word,

**4:19** "And the cares of the world, and the deceitfulness of riches, and the lusts of other things entering in, choke the word, and it becomes unfruitful.

**4:20** "And those are they that were sown upon the good ground; such as hear the word, and accept it, and bear fruit, thirtyfold, and sixtyfold, and a hundredfold."

---

## The Lamp and the Measure (4:21-25)

**4:21** And he said unto them: "Is the lamp brought to be put under the bushel, or under the bed, and not to be put on the stand?

**4:22** "For there is nothing hid, save that it should be manifested; neither was anything made secret, but that it should come to light.

**4:23** "If any man has ears to hear, let him hear."

**4:24** And he said unto them: "Take heed what you hear: with what measure you mete it shall be measured unto you; and more shall be given unto you.

**4:25** "For he that has, to him shall be given: and he that has not, from him shall be taken away even that which he has."

---

## The Seed Growing Secretly (4:26-29)

**4:26** And he said: "So is the kingdom of God, as if a man should cast seed upon the earth;

**4:27** "And should sleep and rise night and day, and the seed should spring up and grow, he knows not how.

**4:28** "The earth bears fruit of itself; first the blade, then the ear, then the full grain in the ear.

**4:29** "But when the fruit is ripe, straightway he puts forth the sickle, because the harvest is come."

---

## The Mustard Seed (4:30-34)

**4:30** And he said: "How shall we liken the kingdom of God? Or in what parable shall we set it forth?

**4:31** "It is like a grain of mustard seed, which, when it is sown upon the earth, though it be less than all the seeds that are upon the earth,

**4:32** "Yet when it is sown, grows up, and becomes greater than all the herbs, and puts out great branches; so that the birds of the heaven can lodge under the shadow thereof."

**4:33** And with many such parables spoke he the word unto them, as they were able to hear it;

**4:34** And without a parable spoke he not unto them: but privately to his own disciples he expounded all things.

---

## Stilling the Storm (4:35-41)

**4:35** And on that day, when even was come, he says unto them: "Let us go over unto the other side."

**4:36** And leaving the multitude, they take him with them, even as he was, in the boat. And other boats were with him.

**4:37** And there arises a great storm of wind, and the waves beat into the boat, insomuch that the boat was now filling.

**4:38** And he himself was in the stern, asleep on the cushion: and they awake him, and say unto him: "Teacher, do you not care that we perish?"

**4:39** And he awoke, and rebuked the wind, and said unto the sea: "Peace, be still." And the wind ceased, and there was a great calm.

**4:40** And he said unto them: "Why are you fearful? Have you not yet faith?"

**4:41** And they feared exceedingly, and said one to another: "Who then is this, that even the wind and the sea obey him?"

---

## Synthesis Notes

**Key Restorations:**

**Parable of the Sower (4:1-20):**
**The Key Verses (4:1-9):**
"'He entered into a boat, and sat in the sea; and all the multitude were by the sea on the land.'"

*Hōste auton eis ploion embanta kathēsthai en tē thalassē kai pas ho ochlos pros tēn thalassan epi tēs gēs ēsan*—teaching from boat.

"''The sower went forth to sow.''"

*Idou exēlthen ho speirōn speirai*—sower.

**Four Soils:**
Wayside (birds), rocky (no root), thorns (choked), good ground (fruit).

"''Brought forth, thirtyfold, and sixtyfold, and a hundredfold.''"

*Kai epheran hen triakonta kai hen hexēkonta kai hen hekaton*—yields.

"''Who has ears to hear, let him hear.''"

*Hos echei ōta akouein akouetō*—ears to hear.

**The Key Verses (4:10-12):**
"''Unto you is given the mystery of the kingdom of God.''"

*Hymin to mystērion dedotai tēs basileias tou theou*—mystery.

**Mystērion:**
"Mystery/secret"—now revealed to insiders.

"''Unto them that are without, all things are done in parables.''"

*Ekeinois de tois exō en parabolais ta panta ginetai*—outsiders.

"''That seeing they may see, and not perceive.''"

*Hina blepontes blepōsin kai mē idōsin*—Isaiah 6:9-10.

**The Key Verses (4:13-20):**
"''The sower sows the word.''"

*Ho speirōn ton logon speirei*—word.

**Interpretation:**
Wayside = Satan snatches.
Rocky = no root, stumbles at persecution.
Thorns = cares, riches, lusts choke.
Good ground = hears, accepts, bears fruit.

**Lamp and Measure (4:21-25):**
**The Key Verses (4:21-25):**
"''Is the lamp brought to be put under the bushel, or under the bed?''"

*Mēti erchetai ho lychnos hina hypo ton modion tethē ē hypo tēn klinēn*—lamp.

"''Not to be put on the stand?''"

*Ouch hina epi tēn lychnian tethē*—stand.

"''There is nothing hid, save that it should be manifested.''"

*Ou gar estin ti krypton ean mē hina phanerōthē*—revealed.

"''With what measure you mete it shall be measured unto you.''"

*Hō metrō metreite metrēthēsetai hymin*—measure.

"''He that has, to him shall be given.''"

*Hos gar echei dothēsetai autō*—has, given.

"''He that has not, from him shall be taken away even that which he has.''"

*Kai hos ouk echei kai ho echei arthēsetai ap' autou*—has not, taken.

**Seed Growing Secretly (4:26-29):**
**The Key Verses (4:26-29):**
"''So is the kingdom of God, as if a man should cast seed upon the earth.''"

*Houtōs estin hē basileia tou theou hōs anthrōpos balē ton sporon epi tēs gēs*—seed.

"''Should sleep and rise night and day, and the seed should spring up and grow, he knows not how.''"

*Kai katheudē kai egeirētai nykta kai hēmeran kai ho sporos blasta kai mēkynētai hōs ouk oiden autos*—grows.

**Only in Mark:**
This parable unique to Mark.

"''The earth bears fruit of itself.''"

*Automatē hē gē karpophorei*—automatically.

"''First the blade, then the ear, then the full grain in the ear.''"

*Prōton chorton eita stachyn eita plērē siton en tō stachyi*—stages.

"''When the fruit is ripe, straightway he puts forth the sickle.''"

*Hotan de paradoi ho karpos euthys apostellei to drepanon*—harvest.

**Joel 3:13.**

**Mustard Seed (4:30-34):**
**The Key Verses (4:30-34):**
"''How shall we liken the kingdom of God?''"

*Pōs homoiōsōmen tēn basileian tou theou*—how liken?

"''It is like a grain of mustard seed.''"

*Hōs kokkō sinapeōs*—mustard seed.

"''Less than all the seeds that are upon the earth.''"

*Mikroteron on pantōn tōn spermatōn tōn epi tēs gēs*—smallest.

"''Grows up, and becomes greater than all the herbs.''"

*Anabainei kai ginetai meizon pantōn tōn lachanōn*—greatest.

"''The birds of the heaven can lodge under the shadow thereof.''"

*Ta peteina tou ouranou kataskēnoun hypo tēn skian autou*—birds lodge.

"'With many such parables spoke he the word unto them, as they were able to hear it.'"

*Kai toiautais parabolais pollais elalei autois ton logon kathōs ēdynanto akouein*—as able.

"'Without a parable spoke he not unto them.'"

*Chōris de parabolēs ouk elalei autois*—only parables.

"'Privately to his own disciples he expounded all things.'"

*Kat' idian de tois idiois mathētais epelyen panta*—privately explained.

**Stilling the Storm (4:35-41):**
**The Key Verses (4:35-41):**
"''Let us go over unto the other side.''"

*Dielthōmen eis to peran*—other side.

"'There arises a great storm of wind.'"

*Kai ginetai lailaps megalē anemou*—great storm.

"'The waves beat into the boat, insomuch that the boat was now filling.'"

*Kai ta kymata epeballen eis to ploion hōste ēdē gemizesthai to ploion*—filling.

"'He himself was in the stern, asleep on the cushion.'"

*Kai autos ēn en tē prymnē epi to proskephalaion katheudōn*—asleep.

**Only Mark:**
The cushion detail.

"''Teacher, do you not care that we perish?''"

*Didaskale ou melei soi hoti apollymetha*—don't you care?

"'He awoke, and rebuked the wind.'"

*Kai diegertheis epetimēsen tō anemō*—rebuked.

"''Peace, be still.''"

*Siōpa pephimōso*—be silent, be muzzled.

**Same Word:**
*Phimoō* used for demons (1:25).

"'The wind ceased, and there was a great calm.'"

*Kai ekopasen ho anemos kai egeneto galēnē megalē*—great calm.

"''Why are you fearful? Have you not yet faith?''"

*Ti deiloi este oupō echete pistin*—no faith?

"'They feared exceedingly.'"

*Kai ephobēthēsan phobon megan*—feared greatly.

"''Who then is this, that even the wind and the sea obey him?''"

*Tis ara houtos estin hoti kai ho anemos kai hē thalassa hypakouei autō*—who is this?

**Archetypal Layer:** Mark 4 contains **parable of the sower (4:1-20)**: four soils, **"Unto you is given the mystery of the kingdom of God" (4:11)**, **Isaiah 6:9-10 applied (4:12)**, **"The sower sows the word" (4:14)**, **lamp on the stand (4:21-22)**, **"with what measure you mete it shall be measured unto you" (4:24)**, **"he that has, to him shall be given" (4:25)**, **seed growing secretly (4:26-29)** (unique to Mark): "the earth bears fruit of itself," **mustard seed parable (4:30-32)**: smallest becomes greatest, **"without a parable spoke he not unto them" (4:34)**, **stilling the storm (4:35-41)**: "Teacher, do you not care that we perish?" (4:38), **"Peace, be still" (4:39)**, **"Why are you fearful? Have you not yet faith?" (4:40)**, and **"Who then is this, that even the wind and the sea obey him?" (4:41)**.

**Modern Equivalent:** Mark 4 is the parable chapter. The sower (4:1-20) explains varied responses to the word. The mystery of the kingdom is given to insiders (4:11). The seed growing secretly (4:26-29), unique to Mark, emphasizes the kingdom's hidden growth—humans plant, God gives the increase. The mustard seed (4:30-32) shows tiny beginnings becoming great. The storm stilling (4:35-41) demonstrates power over chaos—the disciples' question "Who then is this?" is Mark's central question. The one who commands wind and sea has divine authority.

# Isaiah 5: The Song of the Vineyard and the Six Woes

*From the Hebrew: אָשִׁירָה נָּא לִידִידִי (Ashirah Na Li-Dididi) — Let Me Sing for My Beloved*

---

## The Song of the Vineyard (5:1-7)

**5:1** Let me sing now for my beloved
a song of my beloved concerning his vineyard.
My beloved had a vineyard
in a very fruitful hill.

**5:2** And he digged it, and cleared it of stones,
and planted it with the choicest vine,
and built a tower in the midst of it,
and also hewed out a vat therein;
and he looked that it should bring forth grapes,
and it brought forth wild grapes.

**5:3** And now, O inhabitants of Jerusalem and men of Judah,
judge, I pray you, between me and my vineyard.

**5:4** What could have been done more to my vineyard,
that I have not done in it?
Why, when I looked that it should bring forth grapes,
brought it forth wild grapes?

**5:5** And now I will tell you
what I will do to my vineyard:
I will take away the hedge thereof, and it shall be eaten up;
I will break down the fence thereof, and it shall be trodden down;

**5:6** And I will lay it waste;
it shall not be pruned nor hoed,
but there shall come up briers and thorns;
I will also command the clouds
that they rain no rain upon it.

**5:7** For the vineyard of YHWH of hosts is the house of Israel,
and the men of Judah the plant of his delight;
and he looked for justice, but behold bloodshed;
for righteousness, but behold a cry.

---

## The Six Woes (5:8-23)

**5:8** Woe unto them that join house to house,
that lay field to field, till there be no room,
and you be made to dwell alone in the midst of the land!

**5:9** In my ears said YHWH of hosts:
Of a truth many houses shall be desolate,
even great and fair, without inhabitant.

**5:10** For ten acres of vineyard shall yield one bath,
and a homer of seed shall yield an ephah.

**5:11** Woe unto them that rise up early in the morning,
that they may follow strong drink;
that tarry late into the night,
till wine inflame them!

**5:12** And the harp and the psaltery, the tabret and the pipe,
and wine, are in their feasts;
but they regard not the work of YHWH,
neither have they considered the operation of his hands.

**5:13** Therefore my people are gone into captivity,
for want of knowledge;
and their honorable men are famished,
and their multitude are parched with thirst.

**5:14** Therefore Sheol has enlarged her desire,
and opened her mouth without measure;
and down goes their glory, and their tumult, and their pomp,
and he that rejoices among them.

**5:15** And man is bowed down, and man is humbled,
and the eyes of the lofty are humbled;

**5:16** But YHWH of hosts is exalted through justice,
and God the Holy One is sanctified through righteousness.

**5:17** Then shall the lambs feed as in their pasture,
and the waste places of the fat ones shall strangers eat.

**5:18** Woe unto them that draw iniquity with cords of vanity,
and sin as it were with a cart rope;

**5:19** That say: "Let him make speed, let him hasten his work,
that we may see it;
and let the counsel of the Holy One of Israel draw near and come,
that we may know it!"

**5:20** Woe unto them that call evil good, and good evil;
that put darkness for light, and light for darkness;
that put bitter for sweet, and sweet for bitter!

**5:21** Woe unto them that are wise in their own eyes,
and prudent in their own sight!

**5:22** Woe unto them that are mighty to drink wine,
and men of strength to mingle strong drink;

**5:23** That justify the wicked for a bribe,
and take away the righteousness of the righteous from him!

---

## Judgment Announced (5:24-30)

**5:24** Therefore as the tongue of fire devours the stubble,
and as the chaff is consumed in the flame,
so their root shall be as rottenness,
and their blossom shall go up as dust;
because they have rejected the teaching of YHWH of hosts,
and despised the word of the Holy One of Israel.

**5:25** Therefore is the anger of YHWH kindled against his people,
and he has stretched forth his hand against them, and has smitten them,
and the hills did tremble,
and their carcasses were as refuse in the midst of the streets.
For all this his anger is not turned away,
but his hand is stretched out still.

**5:26** And he will lift up an ensign to the nations from far,
and will hiss unto them from the end of the earth;
and, behold, they shall come with speed swiftly;

**5:27** None shall be weary nor stumble among them;
none shall slumber nor sleep;
neither shall the girdle of their loins be loosed,
nor the latchet of their shoes be broken;

**5:28** Whose arrows are sharp,
and all their bows bent;
their horses' hoofs shall be counted like flint,
and their wheels like a whirlwind;

**5:29** Their roaring shall be like a lion,
they shall roar like young lions, yea, they shall roar,
and lay hold of the prey, and carry it away safe,
and there shall be none to deliver.

**5:30** And they shall roar against them in that day like the roaring of the sea;
and if one look unto the land, behold darkness and distress,
and the light is darkened in the skies thereof.

---

## Synthesis Notes

**Key Restorations:**

**The Vineyard Song (5:1-7):**
"Let me sing now for my beloved."

*Ashirah na li-dididi*—beloved's song.

"A song of my beloved concerning his vineyard."

*Shirat dodi le-kharmo*—vineyard song.

"My beloved had a vineyard in a very fruitful hill."

*Kerem hayah li-dididi be-qeren ben-shamen*—fruitful hill.

"He digged it, and cleared it of stones."

*Va-ye'azzeqehu va-yesaqqlehu*—prepared it.

"Planted it with the choicest vine."

*Va-yitta'ehu soreq*—choice vine planted.

"Built a tower in the midst of it."

*Va-yiven migdal be-tokho*—tower built.

"Also hewed out a vat therein."

*Ve-gam-yeqev chatzev bo*—wine vat hewed.

"He looked that it should bring forth grapes."

*Va-yeqav la'asot anavim*—expected grapes.

"It brought forth wild grapes."

*Va-ya'as be'ushim*—wild grapes instead.

**The Key Verses (5:3-4):**
"Judge, I pray you, between me and my vineyard."

*Shiftu-na beini u-vein karmi*—YHWH invites judgment.

"What could have been done more to my vineyard, that I have not done?"

*Mah-la'asot od le-kharmi ve-lo asiti bo*—everything done.

**Destruction (5:5-6):**
"I will take away the hedge thereof."

*Aser et-mesukato*—hedge removed.

"I will break down the fence thereof."

*Parotz gedero*—fence broken.

"I will lay it waste."

*Va-ashitehu vatah*—waste.

"I will also command the clouds that they rain no rain upon it."

*Ve-al he-avim atzavveh mi-hamtir alav matar*—no rain.

**The Key Verse (5:7):**
"The vineyard of YHWH of hosts is the house of Israel."

*Ki kerem YHWH Tzeva'ot beit Yisra'el*—Israel = vineyard.

"The men of Judah the plant of his delight."

*Ve-ish Yehudah neta sha'ashu'av*—Judah = plant.

"He looked for justice, but behold bloodshed."

*Va-yeqav le-mishpat ve-hinneh mispach*—mishpat/mispach wordplay.

"For righteousness, but behold a cry."

*Li-tzedaqah ve-hinneh tze'aqah*—tzedaqah/tze'aqah wordplay.

**The Six Woes:**

**Woe 1 (5:8-10):** Land-grabbing
"Woe unto them that join house to house."

*Hoy maggiei vayit be-vayit*—land accumulation.

**Woe 2 (5:11-17):** Drunken revelry
"Woe unto them that rise up early in the morning, that they may follow strong drink."

*Hoy mashkimei va-boqer shekhar yirdofu*—early drinking.

**Woe 3 (5:18-19):** Mocking God
"Woe unto them that draw iniquity with cords of vanity."

*Hoy moshekhei he-avon be-chavlei ha-shav*—dragging sin.

**The Key Verse (5:20):**
**Woe 4:** Moral inversion
"Woe unto them that call evil good, and good evil."

*Hoy ha-omerim la-ra tov ve-la-tov ra*—moral inversion.

"That put darkness for light, and light for darkness."

*Samim choshekh le-or ve-or le-choshekh*—light/darkness reversed.

"That put bitter for sweet, and sweet for bitter!"

*Samim mar le-matoq u-matoq le-mar*—sweet/bitter reversed.

**Woe 5 (5:21):** Self-wisdom
"Woe unto them that are wise in their own eyes."

*Hoy chakhamim be-eineihem*—self-wise.

**Woe 6 (5:22-23):** Corrupt judges
"Woe unto them that are mighty to drink wine."

*Hoy gibborim lishtot yayin*—drinking heroes.

"That justify the wicked for a bribe."

*Matzdiqei rasha eqev shochad*—bribery.

**Invading Army (5:26-30):**
"He will lift up an ensign to the nations from far."

*Ve-nasa-nes la-goyim me-rachoq*—signal to distant nations.

"They shall come with speed swiftly."

*Ve-hinneh meherah qal yavo*—swift approach.

"Their arrows are sharp."

*Asher chitzav shenunim*—sharp arrows.

"Their roaring shall be like a lion."

*She'agato ka-lavi*—lion roar.

**Archetypal Layer:** Isaiah 5 contains **the Vineyard Song (5:1-7)** with its brilliant wordplay, and **the six woes (5:8-23)** including the famous moral inversion warning (5:20).

**Ethical Inversion Applied:**
- "My beloved had a vineyard"—YHWH's vineyard
- "He looked that it should bring forth grapes"—expectation
- "It brought forth wild grapes"—disappointment
- "The vineyard of YHWH of hosts is the house of Israel"—interpretation
- "He looked for justice, but behold bloodshed"—mishpat/mispach
- "For righteousness, but behold a cry"—tzedaqah/tze'aqah
- "Woe unto them that join house to house"—land-grabbing
- "Woe unto them that rise up early... that they may follow strong drink"—drunkenness
- "Woe unto them that draw iniquity with cords"—dragging sin
- "Woe unto them that call evil good, and good evil"—moral inversion
- "Woe unto them that are wise in their own eyes"—self-wisdom
- "Woe unto them that are mighty to drink wine"—drinking heroes
- "That justify the wicked for a bribe"—bribery

**Modern Equivalent:** Isaiah 5's Vineyard Song shows divine disappointment. The wordplays (mishpat/mispach, tzedaqah/tze'aqah) connect justice to bloodshed's absence. "Woe to those who call evil good" (5:20) is endlessly quoted for moral clarity.

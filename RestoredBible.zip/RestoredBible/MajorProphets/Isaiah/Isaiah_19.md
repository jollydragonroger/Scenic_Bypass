# Isaiah 19: The Oracle Against Egypt

*From the Hebrew: מַשָּׂא מִצְרָיִם (Massa Mitzrayim) — The Burden of Egypt*

---

## YHWH Comes to Egypt (19:1-4)

**19:1** The burden of Egypt.
Behold, YHWH rides upon a swift cloud, and comes unto Egypt;
and the idols of Egypt shall be moved at his presence,
and the heart of Egypt shall melt in the midst of it.

**19:2** And I will stir up the Egyptians against the Egyptians;
and they shall fight every one against his brother,
and every one against his neighbor;
city against city, and kingdom against kingdom.

**19:3** And the spirit of Egypt shall be made empty in the midst of it;
and I will make void the counsel thereof;
and they shall seek unto the idols, and to the mutterers,
and to the ghosts, and to the familiar spirits.

**19:4** And I will give over the Egyptians into the hand of a cruel lord;
and a fierce king shall rule over them,
says the Lord, YHWH of hosts.

---

## The Nile Fails (19:5-10)

**19:5** And the waters shall fail from the sea,
and the river shall be drained dry.

**19:6** And the rivers shall become foul;
the streams of Egypt shall be diminished and dried up;
the reeds and flags shall wither.

**19:7** The meadows by the Nile, by the brink of the Nile,
and all that is sown by the Nile,
shall become dry, be driven away, and be no more.

**19:8** The fishers also shall lament,
and all they that cast angle into the Nile shall mourn,
and they that spread nets upon the waters shall languish.

**19:9** Moreover they that work in combed flax,
and they that weave cotton, shall be ashamed.

**19:10** And her foundations shall be crushed,
all they that make dams shall be grieved in soul.

---

## Foolish Counsellors (19:11-15)

**19:11** The princes of Zoan are utter fools;
the wisest counsellors of Pharaoh are a senseless counsel;
how can you say unto Pharaoh: "I am the son of the wise,
the son of ancient kings"?

**19:12** Where are they, then, your wise men?
And let them tell you now;
and let them know what YHWH of hosts has purposed concerning Egypt.

**19:13** The princes of Zoan are become fools,
the princes of Noph are deceived;
they have caused Egypt to go astray,
that are the corner-stone of her tribes.

**19:14** YHWH has mingled within her a spirit of perverseness;
and they have caused Egypt to stagger in every work thereof,
as a drunken man staggers in his vomit.

**19:15** Neither shall there be for Egypt any work,
which head or tail, palm-branch or rush, may do.

---

## Egypt Turns to YHWH (19:16-25)

**19:16** In that day shall Egypt be like unto women; and it shall tremble and fear because of the shaking of the hand of YHWH of hosts, which he shakes over it.

**19:17** And the land of Judah shall become a terror unto Egypt; every one to whom mention is made thereof shall be afraid, because of the purpose of YHWH of hosts, which he purposes against it.

**19:18** In that day there shall be five cities in the land of Egypt that speak the language of Canaan, and swear to YHWH of hosts; one shall be called The city of destruction.

**19:19** In that day shall there be an altar to YHWH in the midst of the land of Egypt, and a pillar at the border thereof to YHWH.

**19:20** And it shall be for a sign and for a witness unto YHWH of hosts in the land of Egypt; for they shall cry unto YHWH because of the oppressors, and he will send them a savior, and a defender, who will deliver them.

**19:21** And YHWH shall make himself known to Egypt, and the Egyptians shall know YHWH in that day; yea, they shall worship with sacrifice and offering, and shall vow a vow unto YHWH, and shall perform it.

**19:22** And YHWH will smite Egypt, smiting and healing; and they shall return unto YHWH, and he will be entreated of them, and will heal them.

**19:23** In that day shall there be a highway out of Egypt to Assyria, and the Assyrian shall come into Egypt, and the Egyptian into Assyria; and the Egyptians shall worship with the Assyrians.

**19:24** In that day shall Israel be the third with Egypt and with Assyria, a blessing in the midst of the earth;

**19:25** For that YHWH of hosts has blessed them, saying: "Blessed be Egypt my people, and Assyria the work of my hands, and Israel my inheritance."

---

## Synthesis Notes

**Key Restorations:**

**Title (19:1):**
"The burden of Egypt."

*Massa Mitzrayim*—oracle against Egypt.

**Theophany (19:1):**
"YHWH rides upon a swift cloud, and comes unto Egypt."

*YHWH rokhev al-av qal u-va Mitzrayim*—cloud-riding YHWH.

"The idols of Egypt shall be moved at his presence."

*Ve-na'u elilei Mitzrayim mi-panav*—idols tremble.

"The heart of Egypt shall melt in the midst of it."

*U-levav Mitzrayim yimmass be-qirbo*—melting heart.

**Civil War (19:2):**
"I will stir up the Egyptians against the Egyptians."

*Ve-sikhsakhti Mitzrayim be-Mitzrayim*—Egyptians vs. Egyptians.

"City against city, and kingdom against kingdom."

*Ir be-ir mamlakhah be-mamlakhah*—civil strife.

**Spirit Emptied (19:3):**
"The spirit of Egypt shall be made empty."

*Ve-nabeqah ruach Mitzrayim be-qirbo*—emptied spirit.

"They shall seek unto the idols, and to the mutterers."

*Ve-darreshu el-ha-elilim ve-el-ha-ittim*—seeking spirits.

**Cruel Lord (19:4):**
"I will give over the Egyptians into the hand of a cruel lord."

*Ve-sikkarti et-Mitzrayim be-yad adonim qasheh*—cruel master.

**Nile Fails (19:5-10):**
"The waters shall fail from the sea."

*Ve-nishshetu-mayim me-ha-yam*—waters fail.

"The river shall be drained dry."

*Ve-nahar yecherav ve-yavesh*—Nile dries.

"The reeds and flags shall wither."

*Qaneh va-suf qamel*—vegetation withers.

"The fishers also shall lament."

*Ve-anu ha-dayyagim*—fishers mourn.

"They that work in combed flax... shall be ashamed."

*Ve-boshu ovedei fishtim*—flax workers shamed.

**Foolish Counsel (19:11-15):**
"The princes of Zoan are utter fools."

*Akh-evilim sarei Tzo'an*—Zoan's foolish princes.

"The wisest counsellors of Pharaoh are a senseless counsel."

*Chakhmei yo'atzei Far'oh etzah niv'arah*—senseless advice.

"'I am the son of the wise, the son of ancient kings'?"

*Ben-chakhamim ani ben-malkhei-qedem*—claiming wisdom.

"YHWH has mingled within her a spirit of perverseness."

*YHWH masakh be-qirbah ruach iv'im*—perverse spirit.

"As a drunken man staggers in his vomit."

*Ke-ta'ot shikkkor be-qi'o*—drunken staggering.

**The Key Verses (19:18-25):**
"In that day there shall be five cities in the land of Egypt that speak the language of Canaan."

*Ba-yom ha-hu yihyu chamesh arim be-eretz Mitzrayim medabberot sefat Kena'an*—Hebrew-speaking cities.

"And swear to YHWH of hosts."

*Ve-nishba'ot la-YHWH Tzeva'ot*—swearing to YHWH.

**The Key Verse (19:19):**
"In that day shall there be an altar to YHWH in the midst of the land of Egypt."

*Ba-yom ha-hu yihyeh mizbe'ach la-YHWH be-tokh eretz Mitzrayim*—altar in Egypt.

"And a pillar at the border thereof to YHWH."

*U-matztzevah etzel-gevulah la-YHWH*—pillar at border.

**The Key Verse (19:20):**
"He will send them a savior, and a defender, who will deliver them."

*Ve-yishlach lahem moshi'a va-rav ve-hitzzilam*—savior sent.

**The Key Verse (19:21):**
"YHWH shall make himself known to Egypt."

*Ve-noda YHWH le-Mitzrayim*—YHWH known.

"The Egyptians shall know YHWH in that day."

*Ve-yad'u Mitzrayim et-YHWH ba-yom ha-hu*—Egypt knows YHWH.

**The Key Verse (19:22):**
"YHWH will smite Egypt, smiting and healing."

*Ve-nagaf YHWH et-Mitzrayim nagof ve-rafo*—smiting and healing.

"They shall return unto YHWH."

*Ve-shavu ad-YHWH*—returning.

**The Key Verse (19:23):**
"In that day shall there be a highway out of Egypt to Assyria."

*Ba-yom ha-hu tihyeh mesillah mi-Mitzrayim Ashshurah*—highway.

"The Egyptians shall worship with the Assyrians."

*Ve-avdu Mitzrayim et-Ashshur*—joint worship.

**The Key Verses (19:24-25):**
"In that day shall Israel be the third with Egypt and with Assyria."

*Ba-yom ha-hu yihyeh Yisra'el shelishiyyah le-Mitzrayim u-le-Ashshur*—threesome.

"A blessing in the midst of the earth."

*Berakhah be-qerev ha-aretz*—blessing.

"'Blessed be Egypt my people.'"

*Barukh ammi Mitzrayim*—Egypt = my people.

"'Assyria the work of my hands.'"

*U-ma'aseh yadai Ashshur*—Assyria = my handiwork.

"'Israel my inheritance.'"

*Ve-nachalati Yisra'el*—Israel = inheritance.

**Archetypal Layer:** Isaiah 19 moves from **Egypt's judgment (19:1-15)** to **Egypt's conversion (19:16-25)**. The remarkable climax: Egypt called "my people," Assyria "the work of my hands"—titles previously reserved for Israel.

**Ethical Inversion Applied:**
- "YHWH rides upon a swift cloud"—theophany
- "The idols of Egypt shall be moved"—idols tremble
- "I will stir up the Egyptians against the Egyptians"—civil war
- "The spirit of Egypt shall be made empty"—emptied
- "I will give over the Egyptians into the hand of a cruel lord"—cruel master
- "The river shall be drained dry"—Nile fails
- "The princes of Zoan are utter fools"—foolish rulers
- "In that day there shall be five cities... that speak the language of Canaan"—Hebrew in Egypt
- "An altar to YHWH in the midst of the land of Egypt"—Egyptian altar
- "He will send them a savior"—savior for Egypt
- "YHWH shall make himself known to Egypt"—YHWH known
- "YHWH will smite Egypt, smiting and healing"—discipline and heal
- "A highway out of Egypt to Assyria"—connecting enemies
- "Israel be the third with Egypt and with Assyria"—trinitarian blessing
- "'Blessed be Egypt my people'"—Egypt = my people
- "'Assyria the work of my hands'"—Assyria honored
- "'Israel my inheritance'"—Israel's unique role

**Modern Equivalent:** Isaiah 19:24-25 is among the most universalist passages in the Hebrew Bible. Egypt and Assyria—Israel's oppressors—receive titles of covenant relationship. The vision of enemy nations worshipping YHWH together anticipates Gentile inclusion.

# Isaiah 8: Maher-shalal-hash-baz and the Sanctuary

*From the Hebrew: מַהֵר שָׁלָל חָשׁ בַּז (Maher Shalal Chash Baz) — Swift Is the Spoil, Speedy Is the Prey*

---

## The Sign-Child (8:1-4)

**8:1** And YHWH said unto me: "Take a great tablet, and write upon it in common script: For Maher-shalal-hash-baz;

**8:2** "And I will take unto me faithful witnesses to record, Uriah the priest, and Zechariah the son of Jeberechiah."

**8:3** And I went unto the prophetess; and she conceived, and bore a son. Then said YHWH unto me: "Call his name Maher-shalal-hash-baz.

**8:4** "For before the child shall have knowledge to cry: 'My father, and My mother,' the riches of Damascus and the spoil of Samaria shall be carried away before the king of Assyria."

---

## The Waters of Shiloah and the Flood (8:5-10)

**8:5** And YHWH spoke unto me yet again, saying:

**8:6** "Forasmuch as this people has refused the waters of Shiloah that go softly, and rejoice in Rezin and Remaliah's son;

**8:7** "Now therefore, behold, the Lord brings up upon them the waters of the River, mighty and many, even the king of Assyria and all his glory; and he shall come up over all his channels, and go over all his banks;

**8:8** "And he shall sweep through Judah, he shall overflow and pass through, he shall reach even to the neck; and the stretching out of his wings shall fill the breadth of your land, O Immanuel."

**8:9** Make an uproar, O peoples, and be broken in pieces; and give ear, all far countries; gird yourselves, and be broken in pieces; gird yourselves, and be broken in pieces.

**8:10** Take counsel together, and it shall be brought to nought; speak the word, and it shall not stand; for God is with us.

---

## The Sanctuary and the Stumbling Stone (8:11-15)

**8:11** For YHWH spoke thus to me with a strong hand, and instructed me not to walk in the way of this people, saying:

**8:12** "Say not: 'A conspiracy,' concerning all whereof this people says: 'A conspiracy'; neither fear their fear, nor be in dread thereof.

**8:13** "YHWH of hosts, him shall you sanctify; and let him be your fear, and let him be your dread.

**8:14** "And he shall be for a sanctuary; but for a stone of stumbling and for a rock of offence to both the houses of Israel, for a gin and for a snare to the inhabitants of Jerusalem.

**8:15** "And many among them shall stumble, and fall, and be broken, and be snared, and be taken."

---

## Bind Up the Testimony (8:16-22)

**8:16** Bind up the testimony, seal the teaching among my disciples.

**8:17** And I will wait for YHWH, that hides his face from the house of Jacob, and I will look for him.

**8:18** Behold, I and the children whom YHWH has given me shall be for signs and for wonders in Israel, from YHWH of hosts, who dwells in mount Zion.

**8:19** And when they shall say unto you: "Seek unto the ghosts and the familiar spirits, that chirp and that mutter"; should not a people seek unto their God? On behalf of the living should they seek unto the dead?

**8:20** To the teaching and to the testimony! If they speak not according to this word, surely there is no dawn for them.

**8:21** And they shall pass through it, hard beset and hungry; and it shall come to pass, when they shall be hungry, they shall fret themselves, and curse their king and their God, and turn their faces upward;

**8:22** And they shall look unto the earth, and behold distress and darkness, the gloom of anguish, and outspread thick darkness.

---

## Synthesis Notes

**Key Restorations:**

**Sign-Name (8:1-4):**
"Take a great tablet, and write upon it."

*Qach-lekha gillayon gadol u-khetov alav*—public record.

"Maher-shalal-hash-baz."

*Maher Shalal Chash Baz*—"Swift is the spoil, speedy is the prey."

"Faithful witnesses to record."

*Ve-a'idah li edim ne'emanim*—Uriah and Zechariah.

"I went unto the prophetess."

*Va-eqrav el-ha-nevi'ah*—Isaiah's wife.

"She conceived, and bore a son."

*Va-tahar va-teled ben*—son born.

"Before the child shall have knowledge to cry: 'My father.'"

*Be-terem yeda ha-na'ar qero avi ve-immi*—before speech.

"The riches of Damascus and the spoil of Samaria shall be carried away."

*Yissa et-cheil Dammeseq ve-et shelal Shomeron*—Damascus/Samaria plundered.

**Waters Imagery (8:5-8):**
"This people has refused the waters of Shiloah that go softly."

*Ma'as ha-am ha-zeh et mei ha-Shilo'ach ha-holekhim le-at*—gentle waters rejected.

"Rejoice in Rezin and Remaliah's son."

*U-mesos et-Retzin u-ven-Remalyahu*—trusting enemies.

"The Lord brings up upon them the waters of the River."

*Adonai ma'aleh aleihem et-mei ha-nahar*—Euphrates flood.

"Mighty and many, even the king of Assyria."

*Ha-atzumim ve-ha-rabbim et-melekh Ashshur*—Assyria.

"He shall sweep through Judah, he shall overflow."

*Ve-chalaf bi-Yehudah shataf ve-avar*—Judah flooded.

"He shall reach even to the neck."

*Ad-tzavvar yaggi'a*—neck-deep.

**The Key Verse (8:8, 10):**
"O Immanuel."

*Immanu-El*—God with us.

"For God is with us."

*Ki immanu El*—God with us (8:10).

**Fear YHWH Alone (8:11-13):**
"YHWH spoke thus to me with a strong hand."

*Ki khoh amar YHWH elai ke-chezeqat ha-yad*—strong hand.

"Say not: 'A conspiracy.'"

*Lo-tomrun qesher*—don't say conspiracy.

"Neither fear their fear, nor be in dread thereof."

*Ve-et-mor'ao lo-tir'u ve-lo ta'aritzun*—don't share their fear.

"YHWH of hosts, him shall you sanctify."

*Et-YHWH Tzeva'ot oto taqdishu*—sanctify YHWH.

"Let him be your fear, and let him be your dread."

*Ve-hu mora'akhem ve-hu ma'aritzekhem*—fear YHWH alone.

**The Key Verses (8:14-15):**
"He shall be for a sanctuary."

*Ve-hayah le-miqdash*—sanctuary.

"But for a stone of stumbling."

*U-le-even negef*—stumbling stone.

"For a rock of offence to both the houses of Israel."

*U-le-tzur mikhshol li-shenei vattei Yisra'el*—offense rock.

"For a gin and for a snare to the inhabitants of Jerusalem."

*Le-fach u-le-moqesh le-yoshev Yerushalayim*—trap and snare.

"Many among them shall stumble, and fall."

*Ve-khashelu vahem rabbim ve-nafelu*—stumbling, falling.

**Disciples and Testimony (8:16-18):**
"Bind up the testimony, seal the teaching among my disciples."

*Tzor te'udah chatom torah be-limmudai*—sealed teaching.

"I will wait for YHWH."

*Ve-chikkiti la-YHWH*—waiting.

"That hides his face from the house of Jacob."

*Ha-mastir panav mi-beit Ya'aqov*—hidden face.

"I and the children whom YHWH has given me."

*Hinneh anokhi ve-ha-yeladim asher natan-li YHWH*—Isaiah and children as signs. Hebrews 2:13 quotes this.

**The Key Verse (8:19-20):**
"Seek unto the ghosts and the familiar spirits."

*Dirshu el-ha-ovot ve-el-ha-yiddonim*—necromancy.

"Should not a people seek unto their God?"

*Halo-am el-Elohav yidrosh*—seek God instead.

"On behalf of the living should they seek unto the dead?"

*Be'ad ha-chayyim el-ha-metim*—living consulting dead.

"To the teaching and to the testimony!"

*Le-torah ve-li-te'udah*—to Torah and testimony.

"If they speak not according to this word."

*Im-lo yomeru ka-davar ha-zeh*—if not according.

"Surely there is no dawn for them."

*Asher ein-lo shachat*—no dawn.

**Archetypal Layer:** Isaiah 8 contains **Maher-shalal-hash-baz** (sign-name), **the stumbling stone (8:14)** quoted in Romans 9:33 and 1 Peter 2:8, and **"to the teaching and to the testimony" (8:20)**.

**Ethical Inversion Applied:**
- "Maher-shalal-hash-baz"—"Swift spoil, speedy prey"
- "Before the child shall have knowledge to cry 'My father'"—timing marker
- "This people has refused the waters of Shiloah that go softly"—rejected gentle
- "The Lord brings up upon them the waters of the River"—Euphrates flood
- "He shall reach even to the neck"—near drowning
- "O Immanuel"—God with us
- "For God is with us"—confession
- "Say not: 'A conspiracy'"—no conspiracy fear
- "YHWH of hosts, him shall you sanctify"—sanctify YHWH
- "Let him be your fear"—fear YHWH alone
- "He shall be for a sanctuary"—sanctuary
- "But for a stone of stumbling"—stumbling stone (Romans 9:33)
- "For a rock of offence"—offense rock (1 Peter 2:8)
- "Bind up the testimony, seal the teaching"—preserved testimony
- "I and the children whom YHWH has given me"—Hebrews 2:13
- "To the teaching and to the testimony!"—Torah standard
- "If they speak not according to this word"—testing by Torah

**Modern Equivalent:** Isaiah 8:14's "stone of stumbling and rock of offense" is applied to Christ in Romans 9:33 and 1 Peter 2:8. The "to the teaching and to the testimony" (8:20) establishes Scripture as the testing standard.

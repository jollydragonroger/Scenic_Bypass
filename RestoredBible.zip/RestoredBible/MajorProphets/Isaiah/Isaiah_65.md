# Isaiah 65: New Heavens and New Earth

*From the Hebrew: נִדְרַשְׁתִּי לְלוֹא שָׁאָלוּ (Nidrashti Le-Lo Sha'alu) — I Was Sought by Those Who Did Not Ask*

---

## YHWH's Response to Rebels (65:1-7)

**65:1** I was ready to be sought by those that asked not for me, I was ready to be found by those that sought me not; I said: "Here am I, here am I," unto a nation that was not called by my name.

**65:2** I have spread out my hands all the day unto a rebellious people, that walk in a way that is not good, after their own thoughts;

**65:3** A people that provokes me to my face continually, that sacrifice in gardens, and burn incense upon bricks;

**65:4** That sit among the graves, and lodge in the vaults; that eat swine's flesh, and broth of abominable things is in their vessels;

**65:5** That say: "Stand by yourself, come not near to me, for I am holier than you"; these are a smoke in my nose, a fire that burns all the day.

**65:6** Behold, it is written before me; I will not keep silence, except I have requited, yea, I will requite into their bosom,

**65:7** Your own iniquities, and the iniquities of your fathers together, says YHWH, that have burned incense upon the mountains, and blasphemed me upon the hills; therefore will I first measure their work into their bosom.

---

## YHWH's Servants Blessed (65:8-16)

**65:8** Thus says YHWH: As, when wine is found in the cluster, one says: "Destroy it not, for a blessing is in it," so will I do for my servants' sakes, that I may not destroy them all.

**65:9** And I will bring forth a seed out of Jacob, and out of Judah an inheritor of my mountains; and my chosen shall inherit it, and my servants shall dwell there.

**65:10** And Sharon shall be a fold of flocks, and the valley of Achor a place for herds to lie down in, for my people that have sought me.

**65:11** But you that forsake YHWH, that forget my holy mountain, that prepare a table for Fortune, and that offer mingled wine in full measure unto Destiny,

**65:12** I will destine you to the sword, and you shall all bow down to the slaughter; because when I called, you did not answer, when I spoke, you did not hear; but you did that which was evil in my eyes, and chose that wherein I delighted not.

**65:13** Therefore thus says the Lord YHWH: Behold, my servants shall eat, but you shall be hungry; behold, my servants shall drink, but you shall be thirsty; behold, my servants shall rejoice, but you shall be ashamed;

**65:14** Behold, my servants shall sing for joy of heart, but you shall cry for sorrow of heart, and shall wail for vexation of spirit.

**65:15** And you shall leave your name for a curse unto my chosen, and the Lord YHWH will slay you; and he will call his servants by another name;

**65:16** So that he who blesses himself in the earth shall bless himself by the God of truth; and he that swears in the earth shall swear by the God of truth; because the former troubles are forgotten, and because they are hid from my eyes.

---

## New Heavens and New Earth (65:17-25)

**65:17** For, behold, I create new heavens and a new earth; and the former things shall not be remembered, nor come into mind.

**65:18** But be glad and rejoice forever in that which I create; for, behold, I create Jerusalem a rejoicing, and her people a joy.

**65:19** And I will rejoice in Jerusalem, and joy in my people; and the voice of weeping shall be no more heard in her, nor the voice of crying.

**65:20** There shall be no more thence an infant of days, nor an old man that has not filled his days; for the youngest shall die a hundred years old, and the sinner being a hundred years old shall be accursed.

**65:21** And they shall build houses, and inhabit them; and they shall plant vineyards, and eat the fruit of them.

**65:22** They shall not build, and another inhabit; they shall not plant, and another eat; for as the days of a tree shall be the days of my people, and my chosen shall long enjoy the work of their hands.

**65:23** They shall not labour in vain, nor bring forth for terror; for they are the seed blessed of YHWH, and their offspring with them.

**65:24** And it shall come to pass that, before they call, I will answer; and while they are yet speaking, I will hear.

**65:25** The wolf and the lamb shall feed together, and the lion shall eat straw like the ox; and dust shall be the serpent's food. They shall not hurt nor destroy in all my holy mountain, says YHWH.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (65:1-2):**
"I was ready to be sought by those that asked not for me."

*Nidrashti le-lo sha'alu*—sought by non-seekers. Romans 10:20 quotes this.

"I was ready to be found by those that sought me not."

*Nimtzeiti le-lo viqeshuni*—found by non-finders.

"I said: 'Here am I, here am I.'"

*Amarti hinnenni hinnenni*—"Here am I."

"Unto a nation that was not called by my name."

*El-goy lo-qora vi-shemi*—uncalled nation.

"I have spread out my hands all the day unto a rebellious people."

*Perastti yadai kol-ha-yom el-am sorer*—hands spread to rebels. Romans 10:21 quotes this.

"That walk in a way that is not good."

*Ha-holekhim ha-derekh lo-tov*—bad way.

"After their own thoughts."

*Achar machshevoteihem*—own thoughts.

**Idolatrous Practices (65:3-5):**
"A people that provokes me to my face continually."

*Ha-am ha-mach'isim oti al-panai tamid*—continual provocation.

"That sacrifice in gardens."

*Ha-zovechim ba-gannot*—garden sacrifice.

"Burn incense upon bricks."

*Ve-meqatterim al-ha-levenim*—brick incense.

"Sit among the graves."

*Ha-yoshevim ba-qevarim*—grave-sitting.

"Lodge in the vaults."

*U-va-netzurim yalinun*—vault-lodging.

"Eat swine's flesh."

*Ha-okhelim besar ha-chazir*—swine-eating.

"Broth of abominable things is in their vessels."

*U-feraq piggulim keleihem*—abomination broth.

"'Stand by yourself, come not near to me, for I am holier than you.'"

*Qerav elekha al-tiggash-bi ki qedashtikha*—false holiness.

"These are a smoke in my nose."

*Elleh ashan be-appi*—smoke in nose.

"A fire that burns all the day."

*Esh yoqedet kol-ha-yom*—burning fire.

**Servants vs. Rebels (65:8-16):**
"As, when wine is found in the cluster, one says: 'Destroy it not, for a blessing is in it.'"

*Ka-asher yimmatze ha-tirosh ba-eshkol ve-amar al-tashchittehu ki verakhah bo*—don't destroy cluster.

"So will I do for my servants' sakes."

*Ken e'eseh lema'an avadai*—for servants.

"I will bring forth a seed out of Jacob."

*Ve-hotzeti mi-Ya'aqov zera*—seed from Jacob.

"Out of Judah an inheritor of my mountains."

*U-mi-Yehudah yoresh harai*—inheritor from Judah.

"Sharon shall be a fold of flocks."

*Ve-hayah ha-Sharon li-neveh tzon*—Sharon for flocks.

"The valley of Achor a place for herds to lie down in."

*Ve-emeq Akhor le-revetz baqar*—Achor for herds.

"You that forsake YHWH."

*Ve-attem ozvei YHWH*—YHWH-forsakers.

"That forget my holy mountain."

*Ha-shekechim et-har qodshi*—forget holy mountain.

"That prepare a table for Fortune."

*Ha-orekhim la-Gad shulchan*—table for Gad (Fortune).

"Offer mingled wine... unto Destiny."

*Ve-ha-memal'im la-Meni mimsakhe*—wine for Meni (Destiny).

"I will destine you to the sword."

*U-manithi etkhem la-cherev*—destined to sword.

**The Key Verses (65:13-14):**
"My servants shall eat, but you shall be hungry."

*Hinneh avadai yokhelu ve-attem tir'avu*—servants eat, rebels hunger.

"My servants shall drink, but you shall be thirsty."

*Hinneh avadai yishtu ve-attem titzma'u*—servants drink, rebels thirst.

"My servants shall rejoice, but you shall be ashamed."

*Hinneh avadai yismachu ve-attem tevoshu*—servants rejoice, rebels shamed.

"My servants shall sing for joy of heart."

*Hinneh avadai yaronnu mi-tuv lev*—servants sing.

"You shall cry for sorrow of heart."

*Ve-attem titz'aqu mi-ke'ev lev*—rebels cry.

"Shall wail for vexation of spirit."

*U-mi-shever ruach teyelilu*—wail from broken spirit.

"He will call his servants by another name."

*Ve-la-avadav yiqra shem acher*—new name for servants.

"The God of truth."

*Be-lohei amen*—God of Amen.

"The former troubles are forgotten."

*Ki nishkechu ha-tzarot ha-rishonot*—troubles forgotten.

**The Key Verses (65:17-19):**
"I create new heavens and a new earth."

*Ki-hineni vore shamayim chadashim va-aretz chadashah*—new creation. 2 Peter 3:13; Revelation 21:1 quote this.

"The former things shall not be remembered."

*Ve-lo tizkareana ha-rishonot*—not remembered.

"Nor come into mind."

*Ve-lo ta'alenah al-lev*—not on mind.

"Be glad and rejoice forever in that which I create."

*Ki im-sisu ve-gilu adei-ad asher ani vore*—rejoice forever.

"I create Jerusalem a rejoicing."

*Ki-hineni vore et-Yerushalayim gilah*—Jerusalem = rejoicing.

"Her people a joy."

*Ve-ammah masos*—people = joy.

"I will rejoice in Jerusalem."

*Ve-galtti bi-Yerushalayim*—rejoice in Jerusalem.

"Joy in my people."

*Ve-sasti be-ammi*—joy in people.

"The voice of weeping shall be no more heard in her."

*Ve-lo-yishama vah od qol bekhi*—no weeping. Revelation 21:4 echoes this.

"Nor the voice of crying."

*Ve-qol ze'aqah*—no crying.

**Longevity (65:20-23):**
"There shall be no more thence an infant of days."

*Lo-yihyeh mi-sham od ul yamim*—no infant death.

"Nor an old man that has not filled his days."

*Ve-zaqen asher lo-yemalei et-yamav*—full life.

"The youngest shall die a hundred years old."

*Ki ha-na'ar ben-me'ah shanah yamut*—100-year youth.

"The sinner being a hundred years old shall be accursed."

*Ve-ha-chote ben-me'ah shanah yequllal*—100-year sinner cursed.

"They shall build houses, and inhabit them."

*U-vanu vattim ve-yashavu*—build and inhabit.

"Plant vineyards, and eat the fruit of them."

*Ve-nat'u keramim ve-akhlu piriam*—plant and eat.

"They shall not build, and another inhabit."

*Lo yivnu ve-acher yeshev*—no building for others.

"They shall not plant, and another eat."

*Lo yitt'u ve-acher yokhal*—no planting for others.

"As the days of a tree shall be the days of my people."

*Ki-yemei ha-etz yemei ammi*—tree-length days.

"My chosen shall long enjoy the work of their hands."

*U-ma'aseh yedeihem yevallu vechirai*—long enjoyment.

"They shall not labour in vain."

*Lo yig'u la-riq*—no vain labor.

"Nor bring forth for terror."

*Ve-lo yeldu la-vehalah*—no terror-births.

"They are the seed blessed of YHWH."

*Ki zera verukhei YHWH hemmah*—blessed seed.

"Their offspring with them."

*Ve-tze'etza'eihem ittam*—offspring with them.

**The Key Verse (65:24):**
"Before they call, I will answer."

*Ve-hayah terem-yiqra'u va-ani e'eneh*—answered before calling.

"While they are yet speaking, I will hear."

*Od hem medabberim va-ani eshma*—heard while speaking.

**The Key Verse (65:25):**
"The wolf and the lamb shall feed together."

*Ze'ev ve-taleh yir'u ke-echad*—wolf and lamb together.

"The lion shall eat straw like the ox."

*Ve-aryeh ka-baqar yokhal-teven*—lion eats straw. Echoes 11:6-9.

"Dust shall be the serpent's food."

*Ve-nachash afar lachmo*—serpent's dust (Genesis 3:14).

"They shall not hurt nor destroy in all my holy mountain."

*Lo-yare'u ve-lo-yashchitu be-khol-har qodshi*—no harm in holy mountain.

**Archetypal Layer:** Isaiah 65 contains **"I was ready to be sought by those that asked not" (65:1)**—Romans 10:20, **"I have spread out my hands all the day unto a rebellious people" (65:2)**—Romans 10:21, **"I create new heavens and a new earth" (65:17)**—2 Peter 3:13; Revelation 21:1, and **"the voice of weeping shall be no more heard" (65:19)**—Revelation 21:4.

**Ethical Inversion Applied:**
- "I was ready to be sought by those that asked not for me"—Romans 10:20
- "I was ready to be found by those that sought me not"—Gentile inclusion
- "'Here am I, here am I'"—divine availability
- "I have spread out my hands all the day unto a rebellious people"—Romans 10:21
- "A people that provokes me to my face continually"—provocation
- "That sit among the graves"—necromancy
- "Eat swine's flesh"—unclean eating
- "'I am holier than you'"—false holiness
- "I will bring forth a seed out of Jacob"—remnant
- "Sharon shall be a fold of flocks"—Sharon restored
- "You that forsake YHWH"—forsakers
- "That prepare a table for Fortune"—pagan worship
- "My servants shall eat, but you shall be hungry"—reversal
- "He will call his servants by another name"—new name
- "The God of truth"—Amen-God
- "I create new heavens and a new earth"—2 Peter 3:13; Revelation 21:1
- "The former things shall not be remembered"—old forgotten
- "I create Jerusalem a rejoicing"—joyful Jerusalem
- "The voice of weeping shall be no more heard"—Revelation 21:4
- "The youngest shall die a hundred years old"—longevity
- "As the days of a tree shall be the days of my people"—tree-life
- "Before they call, I will answer"—pre-answered prayer
- "The wolf and the lamb shall feed together"—peaceable kingdom
- "They shall not hurt nor destroy in all my holy mountain"—no harm

**Modern Equivalent:** Isaiah 65:1-2 is quoted in Romans 10:20-21 for Gentile inclusion and Israel's rejection. "New heavens and a new earth" (65:17) is quoted in 2 Peter 3:13 and Revelation 21:1. "No more weeping" (65:19) echoes in Revelation 21:4.

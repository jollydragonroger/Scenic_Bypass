# Isaiah 32: The Righteous King and the Spirit Poured Out

*From the Hebrew: הֵן לְצֶדֶק יִמְלָךְ־מֶלֶךְ (Hen Le-Tzedeq Yimlokh-Melekh) — Behold, a King Shall Reign in Righteousness*

---

## The Righteous King (32:1-8)

**32:1** Behold, a king shall reign in righteousness,
and princes shall rule in justice.

**32:2** And a man shall be as a hiding-place from the wind,
and a covert from the tempest;
as streams of water in a dry place,
as the shadow of a great rock in a weary land.

**32:3** And the eyes of them that see shall not be dim,
and the ears of them that hear shall attend.

**32:4** The heart also of the rash shall understand knowledge,
and the tongue of the stammerers shall be ready to speak plainly.

**32:5** The vile person shall be no more called liberal,
nor the churl said to be bountiful.

**32:6** For the vile person will speak villainy,
and his heart will work iniquity,
to practice ungodliness, and to utter error against YHWH,
to make empty the soul of the hungry,
and to cause the drink of the thirsty to fail.

**32:7** The instruments also of the churl are evil;
he devises wicked devices
to destroy the poor with lying words,
even when the needy speaks right.

**32:8** But the liberal devises liberal things;
and by liberal things shall he stand.

---

## Warning to Complacent Women (32:9-14)

**32:9** Rise up, you women that are at ease, and hear my voice;
you confident daughters, give ear unto my speech.

**32:10** After a year and days shall you be troubled, you confident women;
for the vintage shall fail, the ingathering shall not come.

**32:11** Tremble, you women that are at ease;
be troubled, you confident ones;
strip you, and make you bare, and gird sackcloth upon your loins.

**32:12** Smiting upon the breasts for the pleasant fields,
for the fruitful vine.

**32:13** For the land of my people whereon thorns and briers come up;
yea, for all the houses of joy and the joyous city.

**32:14** For the palace shall be forsaken;
the city with its stir shall be deserted;
the mound and the tower shall be for dens forever,
a joy of wild donkeys, a pasture of flocks;

---

## The Spirit Poured Out (32:15-20)

**32:15** Until the spirit be poured upon us from on high,
and the wilderness become a fruitful field,
and the fruitful field be esteemed as a forest.

**32:16** Then justice shall dwell in the wilderness,
and righteousness shall abide in the fruitful field.

**32:17** And the work of righteousness shall be peace;
and the effect of righteousness quietness and confidence forever.

**32:18** And my people shall abide in a peaceable habitation,
and in secure dwellings, and in quiet resting-places.

**32:19** And it shall hail in the downfall of the forest;
but the city shall be low in a low place.

**32:20** Happy are you that sow beside all waters,
that send forth the feet of the ox and the donkey.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (32:1-2):**
"A king shall reign in righteousness."

*Hen le-tzedeq yimlokh-melekh*—righteous king.

"Princes shall rule in justice."

*Ve-le-sarim le-mishpat yasoru*—just princes.

"A man shall be as a hiding-place from the wind."

*Ve-hayah-ish ke-machave-ruach*—wind-shelter.

"A covert from the tempest."

*U-seter-zerem*—storm-cover.

"As streams of water in a dry place."

*Ke-falgei-mayim be-tzayon*—water in dry land.

"As the shadow of a great rock in a weary land."

*Ke-tzel sela-kaved be-eretz ayefah*—rock-shadow in weary land.

**Transformation (32:3-4):**
"The eyes of them that see shall not be dim."

*Ve-lo tish'eynah einei ro'im*—clear eyes.

"The ears of them that hear shall attend."

*Ve-oznei shom'im tiqshavenah*—attentive ears.

"The heart also of the rash shall understand knowledge."

*U-levav nimharim yavin lada'at*—rash understand.

"The tongue of the stammerers shall be ready to speak plainly."

*U-leshon illegim temaher le-dabber tzachot*—stammerers speak clearly.

**True Character Revealed (32:5-8):**
"The vile person shall be no more called liberal."

*Lo-yiqqare od le-naval nadiv*—fool not called noble.

"Nor the churl said to be bountiful."

*U-le-khilai lo ye'amer shoa*—miser not called generous.

"The vile person will speak villainy."

*Ki naval nevalah yedabber*—fools speak folly.

"His heart will work iniquity."

*Ve-libbo ya'aseh aven*—heart works evil.

"To make empty the soul of the hungry."

*Le-hariq nefesh ra'ev*—emptying hungry.

"To cause the drink of the thirsty to fail."

*U-mashqeh tzame yachsir*—denying thirsty.

"The instruments also of the churl are evil."

*U-khelai kela'av ra'im*—miser's tools evil.

"He devises wicked devices to destroy the poor with lying words."

*Hu zimmot ya'atz le-chabbel aniyim be-imrei-shaqer*—lying to destroy poor.

**The Key Verse (32:8):**
"The liberal devises liberal things."

*Ve-nadiv nedivot ya'atz*—noble plans noble.

"By liberal things shall he stand."

*Ve-hu al-nedivot yaqum*—stands by nobility.

**Complacent Women (32:9-14):**
"Rise up, you women that are at ease."

*Nashim sha'ananot qomnah*—complacent women.

"You confident daughters, give ear unto my speech."

*Shema'nah qoli banot botchot ha'azenah imrati*—confident daughters.

"After a year and days shall you be troubled."

*Yamim al-shanah tirgaznah botchot*—year-plus trouble.

"For the vintage shall fail."

*Ki kalah batzir*—vintage fails.

"Tremble, you women that are at ease."

*Chirdu sha'ananot*—tremble.

"Strip you, and make you bare."

*Peshotah ve-orah*—strip and bare.

"The palace shall be forsaken."

*Ki-armon nuttash*—palace forsaken.

"The mound and the tower shall be for dens forever."

*Ofel u-vachan hayah be'ad me'arot ad-olam*—dens forever.

**The Key Verses (32:15-18):**
"Until the spirit be poured upon us from on high."

*Ad ye'ereh aleinu ruach mi-marom*—Spirit poured out.

"The wilderness become a fruitful field."

*Ve-hayah midbar la-karmel*—wilderness to garden.

"The fruitful field be esteemed as a forest."

*Ve-ha-karmel la-ya'ar yechashev*—garden to forest.

"Justice shall dwell in the wilderness."

*Ve-shakan ba-midbar mishpat*—justice in wilderness.

"Righteousness shall abide in the fruitful field."

*U-tzedaqah ba-karmel teshev*—righteousness in garden.

**The Key Verse (32:17):**
"The work of righteousness shall be peace."

*Ve-hayah ma'aseh ha-tzedaqah shalom*—righteousness produces peace.

"The effect of righteousness quietness and confidence forever."

*Va-avodat ha-tzedaqah hashqet va-vetach ad-olam*—righteousness produces quietness and confidence.

"My people shall abide in a peaceable habitation."

*Ve-yashav ammi bi-neveh shalom*—peaceful dwelling.

"In secure dwellings."

*U-ve-mishkenot mivtachim*—secure homes.

"In quiet resting-places."

*U-vi-menuchot sha'ananot*—quiet rest.

**Blessing (32:19-20):**
"Happy are you that sow beside all waters."

*Ashreikhem zore'ei al-kol-mayim*—happy sowers.

"That send forth the feet of the ox and the donkey."

*Meshallachei regel-ha-shor ve-ha-chamor*—free-ranging animals.

**Archetypal Layer:** Isaiah 32 contains **the righteous king (32:1-2)**, **the Spirit poured out (32:15)**, and **"the work of righteousness shall be peace" (32:17)**.

**Ethical Inversion Applied:**
- "A king shall reign in righteousness"—righteous king
- "Princes shall rule in justice"—just princes
- "A man shall be as a hiding-place from the wind"—shelter
- "As streams of water in a dry place"—water in desert
- "As the shadow of a great rock in a weary land"—rock-shadow
- "The eyes of them that see shall not be dim"—clear vision
- "The tongue of the stammerers shall be ready to speak plainly"—clear speech
- "The vile person shall be no more called liberal"—true labels
- "The liberal devises liberal things"—noble plans noble
- "Rise up, you women that are at ease"—complacent warned
- "Until the spirit be poured upon us from on high"—Spirit outpouring
- "The wilderness become a fruitful field"—wilderness transformed
- "Justice shall dwell in the wilderness"—justice everywhere
- "The work of righteousness shall be peace"—righteousness produces peace
- "The effect of righteousness quietness and confidence forever"—lasting security
- "My people shall abide in a peaceable habitation"—peaceful dwelling

**Modern Equivalent:** Isaiah 32:2's shelter imagery describes the messianic king. The Spirit poured out (32:15) anticipates Pentecost (Acts 2). "The work of righteousness shall be peace" (32:17) connects justice and shalom.

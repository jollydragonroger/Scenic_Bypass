# Isaiah 57: The Righteous Perish and the Contrite Healed

*From the Hebrew: הַצַּדִּיק אָבָד (Ha-Tzaddiq Avad) — The Righteous Perishes*

---

## The Righteous Taken Away (57:1-2)

**57:1** The righteous perishes, and no man lays it to heart, and godly men are taken away, none considering that the righteous is taken away from the evil to come.

**57:2** He enters into peace, they rest in their beds, each one that walks in his uprightness.

---

## Idolatry Condemned (57:3-13)

**57:3** But draw near here, you sons of the sorceress, the seed of the adulterer and the harlot.

**57:4** Against whom do you sport yourselves? Against whom make you a wide mouth, and draw out the tongue? Are you not children of transgression, a seed of falsehood,

**57:5** You that inflame yourselves among the terebinths, under every leafy tree; that slay the children in the valleys, under the clefts of the rocks?

**57:6** Among the smooth stones of the valley is your portion; they, they are your lot; even to them have you poured a drink-offering, you have offered a meal-offering. Should I pacify myself for these things?

**57:7** Upon a high and lofty mountain have you set your bed; there also went you up to offer sacrifice.

**57:8** And behind the doors and the posts have you set up your memorial; for you have uncovered, and are gone up from me, you have enlarged your bed, and made a covenant with them; you loved their bed, you chose a place.

**57:9** And you went to the king with ointment, and did increase your perfumes, and did send your ambassadors far off, even down to Sheol.

**57:10** You were wearied with the length of your way; yet said you not: "There is no hope"; you did find a renewal of your strength, therefore you were not affected.

**57:11** And of whom have you been afraid and in fear, that you would deal falsely, and have not remembered me, nor laid it to your heart? Have not I held my peace even of long time? Therefore you fear me not.

**57:12** I will declare your righteousness; and as for your works, they shall not profit you.

**57:13** When you cry, let them that you have gathered deliver you; but the wind shall carry them all away, a breath shall bear them off; but he that takes refuge in me shall possess the land, and shall inherit my holy mountain.

---

## Healing for the Contrite (57:14-21)

**57:14** And he will say: "Cast up, cast up, clear the way, take up the stumbling-block out of the way of my people."

**57:15** For thus says the high and lofty One that inhabits eternity, whose name is Holy: I dwell in the high and holy place, with him also that is of a contrite and humble spirit, to revive the spirit of the humble, and to revive the heart of the contrite ones.

**57:16** For I will not contend forever, neither will I be always wroth; for the spirit would faint before me, and the souls which I have made.

**57:17** For the iniquity of his covetousness was I wroth and smote him, I hid me and was wroth; and he went on frowardly in the way of his heart.

**57:18** I have seen his ways, and will heal him; I will lead him also, and restore comforts unto him and to his mourners.

**57:19** Peace, peace, to him that is far off and to him that is near, says YHWH that creates it; and I will heal him.

**57:20** But the wicked are like the troubled sea; for it cannot rest, and its waters cast up mire and dirt.

**57:21** There is no peace, says my God, unto the wicked.

---

## Synthesis Notes

**Key Restorations:**

**Righteous Taken (57:1-2):**
"The righteous perishes, and no man lays it to heart."

*Ha-tzaddiq avad ve-ein ish sam al-lev*—righteous dies unnoticed.

"Godly men are taken away."

*Ve-anshei-chesed ne'esafim*—godly gathered.

"None considering that the righteous is taken away from the evil to come."

*Be-ein mevin ki-mippenei ha-ra'ah ne'esaf ha-tzaddiq*—taken from coming evil.

"He enters into peace."

*Yavo shalom*—enters peace.

"They rest in their beds."

*Yanuchu al-mishkevotam*—beds of rest.

"Each one that walks in his uprightness."

*Holekh nekocho*—walks uprightly.

**Idolatry Condemned (57:3-10):**
"Draw near here, you sons of the sorceress."

*Ve-attem qirvu-hennah benei onnenah*—sorceress's sons.

"The seed of the adulterer and the harlot."

*Zera mena'ef va-tizzneh*—adulterer and harlot's seed.

"Against whom do you sport yourselves?"

*Al-mi tit'annagu*—mocking whom?

"Against whom make you a wide mouth?"

*Al-mi tarchivu peh*—wide mouth at whom?

"Draw out the tongue?"

*Ta'ariku lashon*—tongue extended.

"Are you not children of transgression, a seed of falsehood?"

*Halo-attem yaldei fesha zera shaqer*—transgression children.

"You that inflame yourselves among the terebinths."

*Ha-nechamim ba-elim*—passion among oaks.

"Under every leafy tree."

*Tachat kol-etz ra'anan*—under green trees.

"That slay the children in the valleys."

*Shochatei ha-yeladim ba-nechalim*—child sacrifice.

"Under the clefts of the rocks."

*Tachat se'ifei ha-sela'im*—rock clefts.

"Among the smooth stones of the valley is your portion."

*Be-chalqei-nachal chelqekh*—smooth stones as portion.

"They, they are your lot."

*Hem hem goralekh*—they're your lot.

"Upon a high and lofty mountain have you set your bed."

*Al har-gavoah ve-nissa samtt mishkavekh*—bed on high mountain.

"There also went you up to offer sacrifice."

*Gam-sham allit lizbo'ach zavach*—sacrifice there.

"You went to the king with ointment."

*Va-tashuri la-melekh ba-shemen*—went to king.

"Did send your ambassadors far off, even down to Sheol."

*Va-teshalechi tzireikh ad-me-rachoq va-tashpili ad-she'ol*—ambassadors to Sheol.

"You were wearied with the length of your way."

*Be-rov darkkekh yagat*—wearied by journey.

"Yet said you not: 'There is no hope.'"

*Lo amart no'ash*—didn't give up.

"You did find a renewal of your strength."

*Chayyat yadekh matzat*—found strength.

"Therefore you were not affected."

*Al-ken lo chaleit*—not weakened.

**YHWH's Silence (57:11-13):**
"Of whom have you been afraid and in fear?"

*Ve-et-mi da'agt va-tir'i*—whom feared?

"That you would deal falsely."

*Ki tekhazzevi*—lied.

"Have not remembered me."

*Ve-oti lo zakharat*—didn't remember.

"Nor laid it to your heart."

*Lo-samtt al-libbekh*—not on heart.

"Have not I held my peace even of long time?"

*Halo ani machsheh me-olam*—long silence.

"Therefore you fear me not."

*Ve-oti lo tira'i*—don't fear me.

"I will declare your righteousness."

*Ani aggid tzidqatekh*—declare "righteousness."

"As for your works, they shall not profit you."

*Ve-et-ma'asayikh ve-lo yo'ilukh*—works won't profit.

"Let them that you have gathered deliver you."

*Yatztzilukh qibbuzayikh*—let gathered ones deliver.

"The wind shall carry them all away."

*Ve-et-kullam yissa-ruach*—wind carries away.

"He that takes refuge in me shall possess the land."

*Ve-ha-choseh bi yinchal-aretz*—refuge-taker inherits.

"Shall inherit my holy mountain."

*Ve-yirash har-qodshi*—inherits holy mountain.

**The Key Verses (57:14-15):**
"Cast up, cast up, clear the way."

*Sollu sollu pannu-derekh*—prepare way.

"Take up the stumbling-block out of the way of my people."

*Harimu mikhshol mi-derekh ammi*—remove stumbling block.

**The Key Verse (57:15):**
"For thus says the high and lofty One that inhabits eternity."

*Ki koh amar ram ve-nissa shokhen ad*—high, lofty, eternal dweller.

"Whose name is Holy."

*Ve-qadosh shemo*—holy name.

"I dwell in the high and holy place."

*Marom ve-qadosh eshkon*—high and holy dwelling.

"With him also that is of a contrite and humble spirit."

*Ve-et-dakka u-shefal-ruach*—with contrite and humble.

"To revive the spirit of the humble."

*Le-hachayot ruach shefalim*—revive humble's spirit.

"To revive the heart of the contrite ones."

*U-le-hachayot lev nidka'im*—revive contrite's heart.

**Divine Restraint (57:16-19):**
"I will not contend forever."

*Ki lo le-olam ariv*—not forever contending.

"Neither will I be always wroth."

*Ve-lo la-netzach eqtzof*—not always angry.

"For the spirit would faint before me."

*Ki-ruach mi-lefanai ya'atof*—spirit would faint.

"The souls which I have made."

*U-neshamot ani asiti*—souls I made.

"For the iniquity of his covetousness was I wroth."

*Ba-avon bitza'o qatzafti*—angry at covetousness.

"I hid me and was wroth."

*Va-akkehu haster ve-eqtzof*—hid and was angry.

"He went on frowardly in the way of his heart."

*Va-yelekh shovav be-derekh libbo*—went his own way.

**The Key Verses (57:18-19):**
"I have seen his ways, and will heal him."

*Derakav ra'iti ve-erpa'ehu*—seen ways, will heal.

"I will lead him also."

*Ve-anchehhu*—will lead.

"Restore comforts unto him and to his mourners."

*Va-ashalllem nichumim lo ve-la-avelav*—restore comforts.

"Peace, peace, to him that is far off and to him that is near."

*Shalom shalom la-rachoq ve-la-qarov*—peace to far and near. Ephesians 2:17 echoes this.

"Says YHWH that creates it; and I will heal him."

*Amar YHWH u-refa'tiv*—YHWH heals.

**Wicked Troubled (57:20-21):**
"The wicked are like the troubled sea."

*Ve-ha-resha'im ka-yam nigrash*—restless sea.

"It cannot rest."

*Ki hashqet lo yukhal*—can't rest.

"Its waters cast up mire and dirt."

*Va-yigreshu meimav refesh va-tit*—mire and dirt.

**The Key Verse (57:21):**
"There is no peace, says my God, unto the wicked."

*Ein shalom amar Elohai la-resha'im*—no peace for wicked.

This verse ends the second section of Third Isaiah. It's similar to 48:22.

**Archetypal Layer:** Isaiah 57 contains **the righteous taken from evil (57:1-2)**, **"the high and lofty One that inhabits eternity... I dwell... with him also that is of a contrite and humble spirit" (57:15)**, and **"Peace, peace, to him that is far off and to him that is near" (57:19)**—Ephesians 2:17.

**Ethical Inversion Applied:**
- "The righteous perishes, and no man lays it to heart"—unnoticed death
- "The righteous is taken away from the evil to come"—merciful removal
- "He enters into peace, they rest in their beds"—peaceful rest
- "Draw near here, you sons of the sorceress"—idolaters addressed
- "You that inflame yourselves among the terebinths"—tree worship
- "That slay the children in the valleys"—child sacrifice
- "Among the smooth stones of the valley is your portion"—stone worship
- "Upon a high and lofty mountain have you set your bed"—high place worship
- "Have not I held my peace even of long time?"—divine patience
- "He that takes refuge in me shall possess the land"—refuge reward
- "Cast up, cast up, clear the way"—prepare way
- "Take up the stumbling-block out of the way of my people"—remove obstacles
- "The high and lofty One that inhabits eternity"—eternal dweller
- "Whose name is Holy"—holy name
- "I dwell in the high and holy place"—transcendence
- "With him also that is of a contrite and humble spirit"—immanence
- "To revive the spirit of the humble"—reviving humble
- "I will not contend forever"—not forever angry
- "I have seen his ways, and will heal him"—healing promised
- "Peace, peace, to him that is far off and to him that is near"—Ephesians 2:17
- "The wicked are like the troubled sea"—restless wicked
- "There is no peace, says my God, unto the wicked"—section conclusion

**Modern Equivalent:** Isaiah 57:15's paradox—the transcendent God ("high and lofty One that inhabits eternity") dwelling with the humble ("with him also that is of a contrite and humble spirit")—is foundational for understanding divine immanence. "Peace to him that is far off and to him that is near" (57:19) is applied to Jew and Gentile in Ephesians 2:17.

# Isaiah 15: The Oracle Against Moab

*From the Hebrew: מַשָּׂא מוֹאָב (Massa Mo'av) — The Burden of Moab*

---

## Moab's Devastation (15:1-9)

**15:1** The burden of Moab.
For in a night Ar of Moab is laid waste, and brought to ruin;
for in a night Kir of Moab is laid waste, and brought to ruin.

**15:2** He is gone up to Bayith, and to Dibon, to the high places, to weep;
upon Nebo, and upon Medeba, Moab howls;
on all their heads is baldness, every beard is cut off.

**15:3** In their streets they gird themselves with sackcloth;
on their housetops, and in their broad places, every one howls, weeping profusely.

**15:4** And Heshbon cries out, and Elealeh;
their voice is heard even unto Jahaz;
therefore the armed men of Moab cry aloud;
his soul trembles within him.

**15:5** My heart cries out for Moab;
her fugitives reach unto Zoar, a heifer of three years old;
for by the ascent of Luhith with weeping they go up;
for in the way of Horonaim they raise up a cry of destruction.

**15:6** For the waters of Nimrim shall be desolate;
for the grass is withered away, the herbage fails, there is no green thing.

**15:7** Therefore the abundance they have gotten, and that which they have laid up,
shall they carry away to the brook of the willows.

**15:8** For the cry is gone round about the borders of Moab;
the howling thereof unto Eglaim, and the howling thereof unto Beer-elim.

**15:9** For the waters of Dimon are full of blood;
for I will bring yet more upon Dimon,
a lion upon him that escapes of Moab, and upon the remnant of the land.

---

## Synthesis Notes

**Key Restorations:**

**Title (15:1):**
"The burden of Moab."

*Massa Mo'av*—oracle concerning Moab.

Moab was Israel's neighbor east of the Dead Sea, descended from Lot (Genesis 19:37).

**Sudden Destruction (15:1):**
"In a night Ar of Moab is laid waste."

*Ki be-leil shuddad Ar Mo'av nidmah*—night destruction.

"In a night Kir of Moab is laid waste."

*Ki be-leil shuddad Qir Mo'av nidmah*—two cities fall.

**Mourning (15:2-4):**
"He is gone up to Bayith, and to Dibon, to the high places, to weep."

*Alah ha-Bayit ve-Divon ha-bamot le-vekhi*—pilgrimage mourning.

"Upon Nebo, and upon Medeba, Moab howls."

*Al-Nevo ve-al Medeva Mo'av yeyalel*—cities wailing.

"On all their heads is baldness."

*Be-khol-roshav qorchah*—shaved heads (mourning).

"Every beard is cut off."

*Kol-zaqan geru'ah*—cut beards (mourning).

"In their streets they gird themselves with sackcloth."

*Be-chutzotav chageru saq*—sackcloth worn.

"On their housetops, and in their broad places, every one howls."

*Al-gaggotekha u-vi-rechovotekha kulloh yeyalel*—universal wailing.

"Heshbon cries out, and Elealeh."

*Va-tiz'aq Cheshbon ve-El'aleh*—cities cry.

"His soul trembles within him."

*Nafsho yar'ah lo*—trembling soul.

**The Key Verse (15:5):**
"My heart cries out for Moab."

*Libbi le-Mo'av yiz'aq*—prophet's compassion.

"Her fugitives reach unto Zoar."

*Berichekha ad-Tzo'ar*—fleeing to Zoar.

"A heifer of three years old."

*Eglat shelishiyyah*—young heifer (symbol of Moab's prime).

"By the ascent of Luhith with weeping they go up."

*Ki ma'aleh ha-Luchit bi-vekhi ya'aleh-vo*—weeping ascent.

"In the way of Horonaim they raise up a cry of destruction."

*Ki derekh Choronayim za'aqat-shever ye'o'eru*—destruction cry.

**Desolation (15:6-9):**
"The waters of Nimrim shall be desolate."

*Ki-mei Nimrim meshamot yihyu*—waters desolate.

"The grass is withered away."

*Ki-yavesh chatzir*—grass withered.

"The herbage fails, there is no green thing."

*Kalah deshe yereq lo hayah*—no greenery.

"The abundance they have gotten... shall they carry away."

*Al-ken yitrah asah u-fequdatam*—carrying away goods.

"To the brook of the willows."

*Al nachal ha-aravim yissa'um*—willow brook.

"The waters of Dimon are full of blood."

*Ki mei Dimon male'u dam*—blood-filled waters.

"I will bring yet more upon Dimon."

*Ki-ashit al-Dimon nosafot*—more coming.

"A lion upon him that escapes of Moab."

*Li-feleitat Mo'av aryeh*—lion on survivors.

**Archetypal Layer:** Isaiah 15 is a **lament over Moab**—unusually sympathetic. The prophet's heart cries out (15:5). The imagery is of complete devastation and mourning.

**Ethical Inversion Applied:**
- "In a night Ar of Moab is laid waste"—sudden destruction
- "Moab howls"—national wailing
- "On all their heads is baldness"—mourning signs
- "Every beard is cut off"—mourning ritual
- "In their streets they gird themselves with sackcloth"—sackcloth
- "Every one howls, weeping profusely"—universal grief
- "His soul trembles within him"—inner terror
- "My heart cries out for Moab"—prophetic compassion
- "Her fugitives reach unto Zoar"—flight
- "A heifer of three years old"—Moab in prime
- "The waters of Nimrim shall be desolate"—water failure
- "The grass is withered away"—drought
- "The waters of Dimon are full of blood"—bloodshed
- "A lion upon him that escapes"—no escape

**Modern Equivalent:** Isaiah 15's sympathetic lament over an enemy (15:5) models prophetic compassion. Even judgment oracles can contain grief. The thoroughness of destruction—cities, water, vegetation—shows comprehensive judgment.

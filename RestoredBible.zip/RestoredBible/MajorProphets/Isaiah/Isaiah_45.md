# Isaiah 45: Cyrus, YHWH's Anointed

*From the Hebrew: כֹּה־אָמַר יְהוָה לִמְשִׁיחוֹ לְכוֹרֶשׁ (Koh-Amar YHWH Li-Meshicho Le-Khoresh) — Thus Says YHWH to His Anointed, to Cyrus*

---

## YHWH's Commission to Cyrus (45:1-8)

**45:1** Thus says YHWH to his anointed, to Cyrus, whose right hand I have held, to subdue nations before him, and to loose the loins of kings; to open before him doors, and gates shall not be shut:

**45:2** I will go before you, and make the crooked places straight; I will break in pieces the doors of brass, and cut asunder the bars of iron;

**45:3** And I will give you the treasures of darkness, and hidden riches of secret places, that you may know that I am YHWH, who calls you by your name, even the God of Israel.

**45:4** For the sake of Jacob my servant, and Israel my chosen, I have called you by your name, I have surnamed you, though you have not known me.

**45:5** I am YHWH, and there is none else; beside me there is no God; I have girded you, though you have not known me;

**45:6** That they may know from the rising of the sun, and from the west, that there is none beside me; I am YHWH, and there is none else.

**45:7** I form the light, and create darkness; I make peace, and create evil; I am YHWH, that does all these things.

**45:8** Drop down, you heavens, from above, and let the skies pour down righteousness; let the earth open, that they may bring forth salvation, and let her cause righteousness to spring up together; I YHWH have created it.

---

## The Potter and the Clay (45:9-13)

**45:9** Woe unto him that strives with his Maker, as a potsherd with the potsherds of the earth! Shall the clay say to him that fashions it: "What are you making?" Or: "Your work, it has no handles"?

**45:10** Woe unto him that says unto a father: "What are you begetting?" Or to a woman: "With what are you in travail?"

**45:11** Thus says YHWH, the Holy One of Israel, and his Maker: Ask me of the things that are to come; concerning my sons, and concerning the work of my hands, command me.

**45:12** I, even I, have made the earth, and created man upon it; I, even my hands, have stretched out the heavens, and all their host have I commanded.

**45:13** I have roused him up in righteousness, and I will make straight all his ways; he shall build my city, and he shall let my exiles go free, not for price nor reward, says YHWH of hosts.

---

## The Nations Turn to Israel's God (45:14-19)

**45:14** Thus says YHWH: The labour of Egypt, and the merchandise of Cush, and of the Sabeans, men of stature, shall come over unto you, and they shall be yours; they shall go after you, in chains they shall come over; and they shall fall down unto you, they shall make supplication unto you: "Surely God is in you, and there is none else, there is no other God."

**45:15** Verily you are a God that hides yourself, O God of Israel, the Savior.

**45:16** They shall be ashamed, yea, confounded, all of them; they shall go in confusion together that are makers of idols.

**45:17** Israel is saved by YHWH with an everlasting salvation; you shall not be ashamed nor confounded world without end.

**45:18** For thus says YHWH that created the heavens, he is God; that formed the earth and made it, he established it, he created it not a waste, he formed it to be inhabited: I am YHWH, and there is none else.

**45:19** I have not spoken in secret, in a place of the land of darkness; I said not unto the seed of Jacob: "Seek me in vain"; I YHWH speak righteousness, I declare things that are right.

---

## All Nations Invited (45:20-25)

**45:20** Assemble yourselves and come, draw near together, you that are escaped of the nations; they have no knowledge that carry the wood of their graven image, and pray unto a god that cannot save.

**45:21** Declare, and bring them near, yea, let them take counsel together: Who has announced this from ancient time, and declared it of old? Have not I, YHWH? And there is no God else beside me, a just God and a Savior; there is none beside me.

**45:22** Turn unto me, and be saved, all the ends of the earth; for I am God, and there is none else.

**45:23** By myself have I sworn, the word is gone forth from my mouth in righteousness, and shall not come back, that unto me every knee shall bow, every tongue shall swear.

**45:24** Only in YHWH, shall one say of me, is righteousness and strength; unto him shall men come, and all they that were incensed against him shall be ashamed.

**45:25** In YHWH shall all the seed of Israel be justified, and shall glory.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verse (45:1):**
"Thus says YHWH to his anointed, to Cyrus."

*Koh-amar YHWH li-meshicho le-Khoresh*—Cyrus = YHWH's anointed (mashiach/messiah).

"Whose right hand I have held."

*Asher-hechezaqti vi-yemino*—right hand held.

"To subdue nations before him."

*Le-rad-lefanav goyim*—nations subdued.

"To loose the loins of kings."

*U-motnei melakhim aftach*—kings' loins loosed.

"To open before him doors, and gates shall not be shut."

*Liftto'ach lefanav delatayim u-she'arim lo yissageru*—doors opened.

**YHWH Empowers Cyrus (45:2-4):**
"I will go before you."

*Ani lefanekha elekh*—YHWH goes before.

"Make the crooked places straight."

*Va-hadurim ayashsher*—crooked straightened.

"Break in pieces the doors of brass."

*Daltot nechoshet ashabber*—brass doors broken.

"Cut asunder the bars of iron."

*U-verichei varzel agadde'a*—iron bars cut.

"I will give you the treasures of darkness."

*Ve-natatti lekha otzrot choshekh*—dark treasures.

"Hidden riches of secret places."

*U-matmonei mistarim*—hidden riches.

"That you may know that I am YHWH, who calls you by your name."

*Lema'an teda ki-ani YHWH ha-qore ve-shimekha*—know YHWH.

"For the sake of Jacob my servant, and Israel my chosen."

*Lema'an avdi Ya'aqov ve-Yisra'el bechiri*—for Jacob's sake.

"I have called you by your name, I have surnamed you."

*Va-eqra lekha vi-shemekha akannekha*—named, surnamed.

"Though you have not known me."

*Ve-lo yeda'tani*—Cyrus didn't know YHWH.

**The Key Verses (45:5-7):**
"I am YHWH, and there is none else."

*Ani YHWH ve-ein od*—I am YHWH, none else.

"Beside me there is no God."

*Zulati ein Elohim*—no other God.

"I have girded you, though you have not known me."

*Aazzerekha ve-lo yeda'tani*—girded though unknown.

"That they may know from the rising of the sun, and from the west."

*Lema'an yede'u mi-mizrach-shemesh u-mi-ma'aravah*—east to west know.

"That there is none beside me."

*Ki-efes bil'adai*—none beside.

**The Key Verse (45:7):**
"I form the light, and create darkness."

*Yotzer or u-vore choshekh*—light/darkness.

"I make peace, and create evil."

*Oseh shalom u-vore ra*—peace/calamity.

"I am YHWH, that does all these things."

*Ani YHWH oseh khol-elleh*—YHWH does all.

**Translation Note:**
*Ra* here means "calamity/disaster" not moral evil. YHWH sovereignly controls all circumstances, blessing and judgment.

**Heavens Drop Righteousness (45:8):**
"Drop down, you heavens, from above."

*Har'ifu shamayim mi-ma'al*—heavens drip.

"Let the skies pour down righteousness."

*U-shechaqim yizzelu-tzedeq*—skies pour righteousness.

"Let the earth open, that they may bring forth salvation."

*Tiftach-eretz ve-yifru yesha*—earth opens, salvation fruits.

"Let her cause righteousness to spring up together."

*U-tzedaqah tatzmi'ach yachad*—righteousness springs.

**Potter and Clay (45:9-10):**
"Woe unto him that strives with his Maker."

*Hoy rav et-yotzro*—woe to striver. Romans 9:20 references this.

"As a potsherd with the potsherds of the earth."

*Cheres et-charsei adamah*—potsherd among potsherds.

"Shall the clay say to him that fashions it: 'What are you making?'"

*Ha-yomar chomer le-yotzro mah-ta'aseh*—clay questioning potter.

"Woe unto him that says unto a father: 'What are you begetting?'"

*Hoy omer le-av mah-tolid*—questioning parents.

**YHWH's Authority (45:11-13):**
"Ask me of the things that are to come."

*Ha-otiyyot sha'aluni*—ask about future.

"Concerning my sons, and concerning the work of my hands, command me."

*Al-banai ve-al-po'al yadai tetzavvuni*—command concerning my work.

"I, even I, have made the earth, and created man upon it."

*Anokhi asiti eretz ve-adam alekha varati*—Creator.

"I, even my hands, have stretched out the heavens."

*Ani yadai natu shamayim*—stretched heavens.

"I have roused him up in righteousness."

*Anokhi ha'irotihu ve-tzedeq*—roused Cyrus.

"He shall build my city."

*Hu yivneh iri*—builds Jerusalem.

"He shall let my exiles go free."

*Ve-galuti yeshallech*—frees exiles.

"Not for price nor reward."

*Lo vi-mechir ve-lo ve-shochad*—no price.

**Hidden God (45:14-17):**
"'Surely God is in you, and there is none else, there is no other God.'"

*Akh bekha El ve-ein od efes Elohim*—God in Israel.

**The Key Verse (45:15):**
"Verily you are a God that hides yourself."

*Akhen attah El mistatter*—hidden God.

"O God of Israel, the Savior."

*Elohei Yisra'el moshi'a*—Israel's saving God.

**The Key Verse (45:17):**
"Israel is saved by YHWH with an everlasting salvation."

*Yisra'el nosha ba-YHWH teshu'at olamim*—everlasting salvation.

"You shall not be ashamed nor confounded world without end."

*Lo-tevoshu ve-lo-tikkaleemu ad-olmei ad*—never shamed.

**Earth Formed to Be Inhabited (45:18-19):**
"He created it not a waste, he formed it to be inhabited."

*Lo-tohu vera'ah la-shevet yetzarah*—formed for inhabitation.

"I have not spoken in secret."

*Lo va-seter dibbarti*—not in secret.

"I said not unto the seed of Jacob: 'Seek me in vain.'"

*Lo-amarti le-zera Ya'aqov tohu baqqeshuni*—not vain seeking.

"I YHWH speak righteousness, I declare things that are right."

*Ani YHWH dover tzedeq maggd meisharim*—YHWH speaks right.

**The Key Verses (45:21-23):**
"Who has announced this from ancient time?"

*Mi-higgid zot mi-qedem*—ancient announcement.

"Have not I, YHWH?"

*Halo-ani YHWH*—YHWH announced.

"A just God and a Savior; there is none beside me."

*El-tzaddiq u-moshi'a ein zulati*—just and saving God.

**The Key Verse (45:22):**
"Turn unto me, and be saved, all the ends of the earth."

*Penu-elai ve-hivvashe'u kol-afsei-aretz*—turn and be saved.

"For I am God, and there is none else."

*Ki ani-El ve-ein od*—I am God, none else.

**The Key Verse (45:23):**
"By myself have I sworn."

*Bi nishba'ti*—sworn by self.

"The word is gone forth from my mouth in righteousness."

*Yatza mi-pi tzedaqah davar*—righteous word.

"Shall not come back."

*Ve-lo yashov*—won't return empty.

"Unto me every knee shall bow."

*Ki-li tikhra kol-berekh*—every knee bows. Romans 14:11; Philippians 2:10-11 quote this.

"Every tongue shall swear."

*Tishshave'a kol-lashon*—every tongue swears.

**The Key Verse (45:25):**
"In YHWH shall all the seed of Israel be justified, and shall glory."

*Ba-YHWH yitzdequ ve-yithalelu kol-zera Yisra'el*—justified in YHWH.

**Archetypal Layer:** Isaiah 45 contains **Cyrus called YHWH's anointed (45:1)**, **"I form light and create darkness" (45:7)**, **potter/clay (45:9)**—Romans 9:20, **"Turn unto me and be saved, all the ends of the earth" (45:22)**, and **"every knee shall bow" (45:23)**—Philippians 2:10-11.

**Ethical Inversion Applied:**
- "Thus says YHWH to his anointed, to Cyrus"—Cyrus = mashiach
- "Whose right hand I have held"—hand held
- "To subdue nations before him"—nations subdued
- "I will go before you"—YHWH leads
- "I will give you the treasures of darkness"—treasures given
- "That you may know that I am YHWH"—knowledge purpose
- "Though you have not known me"—unknown to Cyrus
- "I am YHWH, and there is none else"—monotheism
- "I form the light, and create darkness; I make peace, and create evil"—sovereignty
- "Drop down, you heavens, from above"—righteousness rain
- "Woe unto him that strives with his Maker"—Romans 9:20
- "Shall the clay say to him that fashions it: 'What are you making?'"—clay's question
- "He shall build my city, and he shall let my exiles go free"—Cyrus's mission
- "Not for price nor reward"—free release
- "Verily you are a God that hides yourself"—hidden God
- "Israel is saved by YHWH with an everlasting salvation"—everlasting salvation
- "He created it not a waste, he formed it to be inhabited"—creation purpose
- "Turn unto me, and be saved, all the ends of the earth"—universal invitation
- "Unto me every knee shall bow, every tongue shall swear"—Philippians 2:10-11
- "In YHWH shall all the seed of Israel be justified"—justification

**Modern Equivalent:** Isaiah 45:1's calling Cyrus "anointed" (mashiach) is remarkable—a pagan king as YHWH's instrument. "Every knee shall bow" (45:23) is quoted in Romans 14:11 and Philippians 2:10-11 for Christ. The potter/clay imagery (45:9) underlies Romans 9:20.

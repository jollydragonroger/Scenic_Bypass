# Isaiah 13: The Oracle Against Babylon

*From the Hebrew: מַשָּׂא בָּבֶל (Massa Bavel) — The Burden of Babylon*

---

## The Summons to War (13:1-5)

**13:1** The burden of Babylon, which Isaiah the son of Amoz did see.

**13:2** Set up an ensign upon the bare mountain,
lift up the voice unto them,
wave the hand, that they may go into the gates of the nobles.

**13:3** I have commanded my consecrated ones,
yea, I have called my mighty men for my anger,
even my proudly exulting ones.

**13:4** The noise of a multitude in the mountains, as of a great people!
The noise of a tumult of the kingdoms of the nations gathered together!
YHWH of hosts is mustering the host for the battle.

**13:5** They come from a far country, from the end of heaven,
even YHWH, and the weapons of his indignation,
to destroy the whole earth.

---

## The Day of YHWH (13:6-16)

**13:6** Wail; for the day of YHWH is at hand;
as destruction from the Almighty shall it come.

**13:7** Therefore shall all hands be slack,
and every heart of man shall melt.

**13:8** And they shall be affrighted; pangs and throes shall take hold of them;
they shall be in pain as a woman in travail;
they shall look aghast one at another;
their faces shall be faces of flame.

**13:9** Behold, the day of YHWH comes,
cruel, and full of wrath and fierce anger;
to make the earth a desolation,
and to destroy the sinners thereof out of it.

**13:10** For the stars of heaven and the constellations thereof
shall not give their light;
the sun shall be darkened in his going forth,
and the moon shall not cause her light to shine.

**13:11** And I will punish the world for their evil,
and the wicked for their iniquity;
and I will cause the arrogancy of the proud to cease,
and will lay low the haughtiness of the tyrants.

**13:12** I will make man more rare than fine gold,
even man than the pure gold of Ophir.

**13:13** Therefore I will make the heavens to tremble,
and the earth shall be shaken out of her place,
in the wrath of YHWH of hosts,
and in the day of his fierce anger.

**13:14** And it shall come to pass, that as the chased gazelle,
and as sheep that no man gathers,
they shall turn every man to his own people,
and shall flee every man to his own land.

**13:15** Every one that is found shall be thrust through;
and every one that is caught shall fall by the sword.

**13:16** Their infants also shall be dashed in pieces before their eyes;
their houses shall be spoiled, and their wives ravished.

---

## The Medes Against Babylon (13:17-22)

**13:17** Behold, I will stir up the Medes against them,
who shall not regard silver,
and as for gold, they shall not delight in it.

**13:18** And their bows shall dash the young men in pieces;
and they shall have no pity on the fruit of the womb;
their eye shall not spare children.

**13:19** And Babylon, the glory of kingdoms, the beauty of the Chaldeans' pride,
shall be as when God overthrew Sodom and Gomorrah.

**13:20** It shall never be inhabited,
neither shall it be dwelt in from generation to generation;
neither shall the Arabian pitch tent there;
neither shall shepherds make their flocks to lie down there.

**13:21** But wild-cats shall lie there;
and their houses shall be full of owls;
and ostriches shall dwell there,
and satyrs shall dance there.

**13:22** And jackals shall howl in their castles,
and wild dogs in the pleasant palaces;
and her time is near to come,
and her days shall not be prolonged.

---

## Synthesis Notes

**Key Restorations:**

**Title (13:1):**
"The burden of Babylon."

*Massa Bavel*—oracle/burden concerning Babylon.

This begins the "Oracles Against the Nations" section (chapters 13-23).

**Divine Army (13:2-5):**
"Set up an ensign upon the bare mountain."

*Al-har nishpeh se'u-nes*—signal banner.

"I have commanded my consecrated ones."

*Ani tzivveiti li-meqaddashay*—sanctified warriors.

"I have called my mighty men for my anger."

*Gam qara'ti gibbborai le-appi*—mighty ones for anger.

"YHWH of hosts is mustering the host for the battle."

*YHWH Tzeva'ot mefaqqed tzeva milchamah*—YHWH musters.

"They come from a far country, from the end of heaven."

*Ba'im me-eretz merchaq mi-qetzeh ha-shamayim*—distant origin.

"Even YHWH, and the weapons of his indignation."

*YHWH u-khelei za'amo*—YHWH's weapons.

**Day of YHWH (13:6-13):**
"Wail; for the day of YHWH is at hand."

*Heililu ki qarov yom YHWH*—day near.

"As destruction from the Almighty shall it come."

*Ke-shod mi-Shaddai yavo*—Shaddai wordplay (shod/Shaddai).

"The day of YHWH comes, cruel, and full of wrath."

*Hinneh yom-YHWH ba akhzari ve-evrah va-charon af*—cruel day.

**The Key Verse (13:10):**
"The stars of heaven and the constellations thereof shall not give their light."

*Ki-khokhevei ha-shamayim u-khesileyhem lo yahelu oram*—stars dark.

"The sun shall be darkened in his going forth."

*Chashakh ha-shemesh be-tzeto*—sun darkened.

"The moon shall not cause her light to shine."

*Ve-yare'ach lo-yaggi'ah oro*—moon dark.

This cosmic imagery appears in Joel 2:31, Matthew 24:29, Revelation 6:12-13.

**The Key Verse (13:11):**
"I will punish the world for their evil."

*U-faqadti al-tevel ra'ah*—world punished.

"I will cause the arrogancy of the proud to cease."

*Ve-hishbatti ge'on zedim*—pride ceased.

"Will lay low the haughtiness of the tyrants."

*Ve-ga'avat aritzim ashpil*—tyrants lowered.

**Babylon's Fall (13:17-22):**
"I will stir up the Medes against them."

*Hineni me'ir aleihem et-Maday*—Medes stirred.

"Who shall not regard silver."

*Asher-kesef lo yachshovu*—silver disregarded.

**The Key Verse (13:19):**
"Babylon, the glory of kingdoms, the beauty of the Chaldeans' pride."

*Ve-haytah Bavel tzevi mamlakhot tif'eret ge'on Kasdim*—Babylon's glory.

"Shall be as when God overthrew Sodom and Gomorrah."

*Ke-mahpekat Elohim et-Sedom ve-et-Amorah*—Sodom/Gomorrah comparison.

**Desolation (13:20-22):**
"It shall never be inhabited."

*Lo-teshev la-netzach*—never inhabited.

"Neither shall the Arabian pitch tent there."

*Ve-lo-ya'hel sham Aravi*—no Arab tents.

"Wild-cats shall lie there."

*Ve-ravetzu sham tziyyim*—wild animals.

"Their houses shall be full of owls."

*U-male'u vatteihem ochim*—owls fill.

"Satyrs shall dance there."

*U-se'irim yeraqedu sham*—goat-demons dance.

**Archetypal Layer:** Isaiah 13 begins the **Oracles Against the Nations** with Babylon—the archetypal enemy. The Day of YHWH (13:6-13) features cosmic upheaval. Babylon falls like Sodom.

**Ethical Inversion Applied:**
- "The burden of Babylon"—oracle begins
- "I have commanded my consecrated ones"—sanctified army
- "YHWH of hosts is mustering the host"—divine general
- "Wail; for the day of YHWH is at hand"—day near
- "As destruction from the Almighty shall it come"—Shaddai/shod
- "The day of YHWH comes, cruel"—cruel day
- "The stars of heaven... shall not give their light"—cosmic darkness
- "The sun shall be darkened"—Matthew 24:29
- "I will punish the world for their evil"—world judgment
- "I will cause the arrogancy of the proud to cease"—pride ended
- "I will stir up the Medes against them"—Medes as instrument
- "Babylon, the glory of kingdoms"—Babylon's pride
- "Shall be as when God overthrew Sodom"—Sodom comparison
- "It shall never be inhabited"—permanent desolation

**Modern Equivalent:** Isaiah 13's cosmic imagery (13:10) recurs in Joel, Jesus' Olivet Discourse (Matthew 24:29), and Revelation. Babylon becomes the archetypal enemy—later symbolic for Rome (1 Peter 5:13, Revelation 17-18).

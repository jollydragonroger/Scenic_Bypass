# Isaiah 42: The Servant of YHWH

*From the Hebrew: הֵן עַבְדִּי אֶתְמָךְ־בּוֹ (Hen Avdi Etmokh-Bo) — Behold My Servant, Whom I Uphold*

---

## The First Servant Song (42:1-9)

**42:1** Behold my servant, whom I uphold; my chosen, in whom my soul delights; I have put my spirit upon him, he shall bring forth justice to the nations.

**42:2** He shall not cry, nor lift up, nor cause his voice to be heard in the street.

**42:3** A bruised reed shall he not break, and a dimly burning wick shall he not quench; he shall bring forth justice in truth.

**42:4** He shall not fail nor be discouraged, till he have set justice in the earth; and the isles shall wait for his teaching.

**42:5** Thus says God YHWH, he that created the heavens, and stretched them forth, he that spread forth the earth and that which comes out of it, he that gives breath unto the people upon it, and spirit to them that walk therein:

**42:6** I YHWH have called you in righteousness, and have taken hold of your hand, and kept you, and set you for a covenant of the people, for a light of the nations;

**42:7** To open the blind eyes, to bring out the prisoners from the dungeon, and them that sit in darkness out of the prison-house.

**42:8** I am YHWH, that is my name; and my glory will I not give to another, neither my praise to graven images.

**42:9** Behold, the former things are come to pass, and new things do I declare; before they spring forth I tell you of them.

---

## A New Song to YHWH (42:10-17)

**42:10** Sing unto YHWH a new song, and his praise from the end of the earth; you that go down to the sea, and all that is therein, the isles, and the inhabitants thereof.

**42:11** Let the wilderness and the cities thereof lift up their voice, the villages that Kedar inhabits; let the inhabitants of Sela exult, let them shout from the top of the mountains.

**42:12** Let them give glory unto YHWH, and declare his praise in the islands.

**42:13** YHWH will go forth as a mighty man, he will stir up jealousy like a man of war; he will cry, yea, he will shout aloud, he will prove himself mighty against his enemies.

**42:14** I have long time held my peace, I have been still, and refrained myself; now will I cry like a travailing woman, gasping and panting at once.

**42:15** I will make waste mountains and hills, and dry up all their herbs; and I will make the rivers islands, and will dry up the pools.

**42:16** And I will bring the blind by a way that they knew not, in paths that they knew not will I lead them; I will make darkness light before them, and crooked places straight. These things will I do, and I will not leave them undone.

**42:17** They shall be turned back, they shall be greatly ashamed, that trust in graven images, that say unto molten images: "You are our gods."

---

## Israel, the Blind Servant (42:18-25)

**42:18** Hear, you deaf, and look, you blind, that you may see.

**42:19** Who is blind, but my servant? Or deaf, as my messenger that I send? Who is blind as he that is wholehearted, and blind as YHWH's servant?

**42:20** You see many things, but you observe not; his ears are open, but he hears not.

**42:21** YHWH was pleased, for his righteousness' sake, to make the teaching great and glorious.

**42:22** But this is a people robbed and spoiled, they are all of them snared in holes, and they are hid in prison-houses; they are for a prey, and none delivers; for a spoil, and none says: "Restore."

**42:23** Who among you will give ear to this? Who will attend and hear for the time to come?

**42:24** Who gave Jacob for a spoil, and Israel to the robbers? Did not YHWH? He against whom we have sinned, and in whose ways they would not walk, neither were they obedient unto his law.

**42:25** Therefore he poured upon him the fury of his anger, and the strength of battle; and it set him on fire round about, yet he knew not; and it burned him, yet he laid it not to heart.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (42:1-4) — First Servant Song:**
"Behold my servant, whom I uphold."

*Hen avdi etmokh-bo*—upheld servant.

"My chosen, in whom my soul delights."

*Bechiri ratzah nafshi*—chosen, soul delights.

"I have put my spirit upon him."

*Natatti ruchi alav*—Spirit upon him. Matthew 12:18-21 quotes this.

"He shall bring forth justice to the nations."

*Mishpat la-goyim yotzi*—justice to nations.

"He shall not cry, nor lift up."

*Lo yitz'aq ve-lo yissa*—no crying/lifting.

"Nor cause his voice to be heard in the street."

*Ve-lo-yashmi'a ba-chutz qolo*—not heard in street.

**The Key Verse (42:3):**
"A bruised reed shall he not break."

*Qaneh ratzutz lo yishbor*—bruised reed unbroken.

"A dimly burning wick shall he not quench."

*U-fishtah kehah lo yekhabbenah*—dim wick unquenched.

"He shall bring forth justice in truth."

*Le-emet yotzi mishpat*—true justice.

**The Key Verse (42:4):**
"He shall not fail nor be discouraged."

*Lo yikheh ve-lo yarutz*—unfailing, undiscouraged.

"Till he have set justice in the earth."

*Ad-yasim ba-aretz mishpat*—justice established.

"The isles shall wait for his teaching."

*U-le-torato iyyim yeyachelu*—islands wait for Torah.

**Creator Description (42:5):**
"God YHWH, he that created the heavens, and stretched them forth."

*Ha-El YHWH bore ha-shamayim ve-notehem*—Creator.

"He that spread forth the earth and that which comes out of it."

*Roqa ha-aretz ve-tze'etza'ekha*—earth spread.

"He that gives breath unto the people upon it."

*Noten neshamah la-am alekha*—breath given.

"And spirit to them that walk therein."

*Ve-ruach la-holekhim bah*—spirit given.

**The Key Verses (42:6-7):**
"I YHWH have called you in righteousness."

*Ani YHWH qerattikha ve-tzedeq*—called in righteousness.

"Have taken hold of your hand, and kept you."

*Ve-achazzeq be-yadekha ve-etzorrekha*—hand held, kept.

"Set you for a covenant of the people."

*Ve-ettenekha li-verit am*—covenant of people.

"For a light of the nations."

*Le-or goyim*—light of nations. Luke 2:32; Acts 13:47; 26:23 quote this.

"To open the blind eyes."

*Lifqo'ach einayim ivrot*—blind eyes opened.

"To bring out the prisoners from the dungeon."

*Le-hotzi mi-masger assir*—prisoners freed.

"Them that sit in darkness out of the prison-house."

*Mi-beit kele yoshevei choshekh*—darkness prisoners.

**The Key Verse (42:8):**
"I am YHWH, that is my name."

*Ani YHWH hu shemi*—YHWH = name.

"My glory will I not give to another."

*U-khevodi le-acher lo-etten*—glory not shared.

"Neither my praise to graven images."

*U-tehillati la-pesilim*—no praise to idols.

**New Song (42:10-12):**
"Sing unto YHWH a new song."

*Shiru la-YHWH shir chadash*—new song.

"His praise from the end of the earth."

*Tehillato mi-qetzeh ha-aretz*—earth's end praise.

"Let the wilderness and the cities thereof lift up their voice."

*Yis'u midbar ve-arav*—wilderness lifts voice.

"The villages that Kedar inhabits."

*Chatzerim teshev Qedar*—Kedar's villages.

"Let the inhabitants of Sela exult."

*Yaronnu yoshevei Sela*—Sela exults.

**YHWH as Warrior (42:13-16):**
"YHWH will go forth as a mighty man."

*YHWH ka-gibbor yetze*—warrior YHWH.

"He will stir up jealousy like a man of war."

*Ke-ish milchamot ya'ir qin'ah*—jealousy stirred.

"I have long time held my peace."

*Hechesheti me-olam*—long silence.

"Now will I cry like a travailing woman."

*Ka-yoledah ef'eh*—travailing cry.

"I will bring the blind by a way that they knew not."

*Ve-holakhti ivrim be-derekh lo yada'u*—leading blind.

"I will make darkness light before them."

*Asim machashakh lifneihem la-or*—darkness to light.

"Crooked places straight."

*U-ma'aqqashim le-mishor*—crooked straightened.

**Blind Servant (42:18-25):**
"Hear, you deaf, and look, you blind, that you may see."

*Ha-chershim shema'u ve-ha-ivrim habbitu lir'ot*—deaf hear, blind see.

**The Key Verse (42:19):**
"Who is blind, but my servant?"

*Mi ivver ki im-avdi*—servant blind.

"Or deaf, as my messenger that I send?"

*Ve-cheresh ke-mal'akhi eshlach*—messenger deaf.

"Who is blind as he that is wholehearted."

*Mi ivver ki-meshullam*—wholehearted blind.

"Blind as YHWH's servant?"

*Ve-ivver ke-eved YHWH*—YHWH's servant blind.

**Distinction:**
Two servant portraits: the ideal Servant (42:1-9) who brings justice, and blind Israel as servant (42:18-25) who needs restoration.

"YHWH was pleased, for his righteousness' sake, to make the teaching great and glorious."

*YHWH chafetz lema'an tzidqo yagdil torah ve-ya'dir*—Torah magnified.

"This is a people robbed and spoiled."

*Ve-hu am-bazuz ve-shasuy*—robbed people.

"Who gave Jacob for a spoil?"

*Mi-natan li-meshissah Ya'aqov*—who gave Jacob?

"Did not YHWH? He against whom we have sinned."

*Halo YHWH zu chatanu lo*—YHWH, against whom sinned.

"He poured upon him the fury of his anger."

*Va-yishpokh alav chemah appo*—anger poured.

"It set him on fire round about, yet he knew not."

*Va-telahatehu mi-saviv ve-lo yada*—burning unknown.

"It burned him, yet he laid it not to heart."

*Va-tiv'ar-bo ve-lo-yasim al-lev*—not laid to heart.

**Archetypal Layer:** Isaiah 42 contains **the First Servant Song (42:1-9)**—quoted in Matthew 12:18-21—and contrasts the ideal Servant with **blind Israel (42:18-25)**.

**Ethical Inversion Applied:**
- "Behold my servant, whom I uphold"—upheld servant
- "My chosen, in whom my soul delights"—chosen, delighted
- "I have put my spirit upon him"—Spirit-anointed
- "He shall bring forth justice to the nations"—justice to nations
- "A bruised reed shall he not break"—gentle ministry
- "A dimly burning wick shall he not quench"—preserving weak
- "He shall not fail nor be discouraged"—unfailing
- "The isles shall wait for his teaching"—Torah awaited
- "I YHWH have called you in righteousness"—righteous calling
- "Set you for a covenant of the people"—covenant role
- "For a light of the nations"—Luke 2:32; Acts 13:47
- "To open the blind eyes"—blind healed
- "To bring out the prisoners from the dungeon"—prisoners freed
- "I am YHWH, that is my name"—name declared
- "My glory will I not give to another"—glory exclusive
- "Sing unto YHWH a new song"—new song
- "YHWH will go forth as a mighty man"—warrior
- "I will bring the blind by a way that they knew not"—leading blind
- "Who is blind, but my servant?"—blind servant Israel
- "YHWH was pleased... to make the teaching great"—Torah magnified
- "This is a people robbed and spoiled"—exile
- "He poured upon him the fury of his anger"—judgment
- "It burned him, yet he laid it not to heart"—unheeding

**Modern Equivalent:** Isaiah 42:1-4 is quoted in Matthew 12:18-21 for Jesus' gentle ministry. "A light of the nations" (42:6) is quoted in Luke 2:32; Acts 13:47; 26:23. The contrast between ideal Servant and blind Israel shows the need for a perfect Servant.

# Isaiah 18: The Oracle Concerning Cush

*From the Hebrew: הוֹי אֶרֶץ צִלְצַל כְּנָפָיִם (Hoy Eretz Tziltzal Kenafayim) — Woe to the Land of the Rustling of Wings*

---

## The Land Beyond the Rivers (18:1-3)

**18:1** Woe to the land of the rustling of wings,
which is beyond the rivers of Cush;

**18:2** That sends ambassadors by the sea,
even in vessels of papyrus upon the waters!
Go, swift messengers, to a nation tall and smooth,
to a people terrible from their beginning onward;
a nation that measures out and treads down,
whose land the rivers divide.

**18:3** All you inhabitants of the world, and you dwellers on the earth,
when an ensign is lifted up on the mountains, see;
and when the horn is blown, hear.

---

## YHWH Watches and Acts (18:4-6)

**18:4** For thus has YHWH said unto me:
"I will be still, and I will look on in my dwelling-place,
like clear heat in sunshine,
like a cloud of dew in the heat of harvest."

**18:5** For before the harvest, when the blossom is over,
and the bud becomes a ripening grape,
he will cut off the sprigs with pruning-hooks,
and the spreading branches will he take away and cut down.

**18:6** They shall be left together unto the ravenous birds of the mountains,
and to the beasts of the earth;
and the ravenous birds shall summer upon them,
and all the beasts of the earth shall winter upon them.

---

## Gifts to YHWH (18:7)

**18:7** In that time shall a present be brought unto YHWH of hosts
from a people tall and smooth,
and from a people terrible from their beginning onward;
a nation that measures out and treads down,
whose land the rivers divide,
to the place of the name of YHWH of hosts, the mount Zion.

---

## Synthesis Notes

**Key Restorations:**

**Title (18:1):**
"Woe to the land of the rustling of wings."

*Hoy eretz tziltzal kenafayim*—whirring/rustling wings (insects or boats).

"Which is beyond the rivers of Cush."

*Asher me-ever le-naharei-Khush*—beyond Cush's rivers (Ethiopia/Nubia).

**Ambassadors (18:2):**
"That sends ambassadors by the sea."

*Ha-sholeach ba-yam tzirim*—sea ambassadors.

"In vessels of papyrus upon the waters."

*U-vi-khelei-gome al-penei mayim*—papyrus boats.

"Go, swift messengers."

*Lekhu mal'akhim qallim*—swift messengers.

"To a nation tall and smooth."

*El-goy memushakh u-morat*—tall and smooth-skinned.

"To a people terrible from their beginning onward."

*El-am nora min-hu va-hal'ah*—feared people.

"A nation that measures out and treads down."

*Goy qav-qav u-mevusah*—conquering nation.

"Whose land the rivers divide."

*Asher baz'u neharot artzo*—river-divided land.

**Universal Witness (18:3):**
"All you inhabitants of the world, and you dwellers on the earth."

*Kol-yoshevei tevel ve-shoknei aretz*—whole world.

"When an ensign is lifted up on the mountains, see."

*Ki-neso-nes harim tir'u*—see the banner.

"When the horn is blown, hear."

*Ve-khi-teqo'a shofar tishma'u*—hear the horn.

**YHWH's Stillness (18:4-6):**
"I will be still, and I will look on in my dwelling-place."

*Eshqotah ve-abbitah vi-mekhoni*—YHWH still and watching.

"Like clear heat in sunshine."

*Ke-chom tzach alei-or*—clear sunshine heat.

"Like a cloud of dew in the heat of harvest."

*Ke-av tal be-chom qatzir*—dew-cloud at harvest.

"Before the harvest, when the blossom is over."

*Ki-lifnei qatzir ke-tom perach*—pre-harvest timing.

"The bud becomes a ripening grape."

*U-voser gomel yihyeh nitztzah*—grape ripening.

"He will cut off the sprigs with pruning-hooks."

*Ve-kharat ha-zalzallim ba-mazmerot*—pruning.

"The spreading branches will he take away and cut down."

*Ve-et-ha-netishod hesir hettaz*—branches removed.

"They shall be left together unto the ravenous birds."

*Ye'azvu yachdav le-eit harim*—left for birds.

"And to the beasts of the earth."

*U-le-behemot ha-aretz*—and beasts.

"The ravenous birds shall summer upon them."

*Ve-qatz alav ha-ayit*—birds summer.

"All the beasts of the earth shall winter upon them."

*Ve-khol-behemot ha-aretz alav techeraf*—beasts winter.

**The Key Verse (18:7):**
"In that time shall a present be brought unto YHWH of hosts."

*Ba-et ha-hi yuval-shay la-YHWH Tzeva'ot*—gift to YHWH.

"From a people tall and smooth."

*Me-am memushakh u-morat*—tall, smooth people.

"A nation that measures out and treads down."

*Goy qav-qav u-mevusah*—powerful nation.

"To the place of the name of YHWH of hosts, the mount Zion."

*El-meqom shem-YHWH Tzeva'ot har-Tziyyon*—to Zion.

**Archetypal Layer:** Isaiah 18 is an **oracle concerning Cush (Ethiopia/Nubia)**. Unlike other oracles, it ends with Cush bringing gifts to Zion (18:7)—a vision of Gentile worship.

**Ethical Inversion Applied:**
- "Woe to the land of the rustling of wings"—Cush addressed
- "Beyond the rivers of Cush"—distant land
- "That sends ambassadors by the sea"—diplomatic mission
- "In vessels of papyrus upon the waters"—papyrus boats
- "To a nation tall and smooth"—Ethiopian description
- "All you inhabitants of the world"—universal summons
- "When an ensign is lifted up on the mountains, see"—see the sign
- "I will be still, and I will look on in my dwelling-place"—YHWH watches
- "Like clear heat in sunshine"—still heat
- "Before the harvest... he will cut off the sprigs"—pre-harvest pruning
- "They shall be left together unto the ravenous birds"—carrion
- "In that time shall a present be brought unto YHWH"—gift to YHWH
- "To the place of the name of YHWH of hosts, the mount Zion"—Zion worship

**Modern Equivalent:** Isaiah 18's vision of Cush bringing gifts to Zion (18:7) anticipates Gentile worship. The Ethiopian eunuch (Acts 8) fulfills this trajectory. YHWH's stillness (18:4) shows divine patience before action.

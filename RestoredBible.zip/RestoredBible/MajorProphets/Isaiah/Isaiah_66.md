# Isaiah 66: The Final Vision

*From the Hebrew: כֹּה אָמַר יְהוָה הַשָּׁמַיִם כִּסְאִי (Koh Amar YHWH Ha-Shamayim Kis'i) — Thus Says YHWH: The Heaven Is My Throne*

---

## True Worship (66:1-4)

**66:1** Thus says YHWH: The heaven is my throne, and the earth is my footstool; where is the house that you may build unto me? And where is the place that may be my resting-place?

**66:2** For all these things has my hand made, and so all these things came to be, says YHWH; but on this one will I look, even on him that is poor and of a contrite spirit, and trembles at my word.

**66:3** He that kills an ox is as if he slew a man; he that sacrifices a lamb, as if he broke a dog's neck; he that offers a meal-offering, as if he offered swine's blood; he that makes a memorial-offering of frankincense, as if he blessed an idol; according as they have chosen their own ways, and their soul delights in their abominations,

**66:4** I also will choose their mockeries, and will bring their fears upon them; because when I called, none did answer; when I spoke, they did not hear; but they did that which was evil in my eyes, and chose that in which I delighted not.

---

## Zion's Sudden Birth (66:5-14)

**66:5** Hear the word of YHWH, you that tremble at his word: Your brethren that hate you, that cast you out for my name's sake, have said: "Let YHWH be glorified, that we may gaze upon your joy," but they shall be ashamed.

**66:6** A voice of tumult from the city, a voice from the temple, a voice of YHWH that renders recompense to his enemies.

**66:7** Before she travailed, she brought forth; before her pain came, she was delivered of a man-child.

**66:8** Who has heard such a thing? Who has seen such things? Is a land born in one day? Is a nation brought forth at once? For as soon as Zion travailed, she brought forth her children.

**66:9** Shall I bring to the birth, and not cause to bring forth? says YHWH; shall I that cause to bring forth shut the womb? says your God.

**66:10** Rejoice with Jerusalem, and be glad with her, all you that love her; rejoice for joy with her, all you that mourn for her;

**66:11** That you may suck and be satisfied with the breast of her consolations; that you may drink deeply with delight of the abundance of her glory.

**66:12** For thus says YHWH: Behold, I will extend peace to her like a river, and the glory of the nations like an overflowing stream, and you shall suck thereof; you shall be borne upon the side, and shall be dandled upon the knees.

**66:13** As one whom his mother comforts, so will I comfort you; and you shall be comforted in Jerusalem.

**66:14** And when you see this, your heart shall rejoice, and your bones shall flourish like young grass; and the hand of YHWH shall be known toward his servants, and he will have indignation against his enemies.

---

## YHWH's Final Judgment (66:15-24)

**66:15** For, behold, YHWH will come in fire, and his chariots shall be like the whirlwind; to render his anger with fury, and his rebuke with flames of fire.

**66:16** For by fire will YHWH contend, and by his sword with all flesh; and the slain of YHWH shall be many.

**66:17** They that sanctify themselves and purify themselves to go unto the gardens, behind one in the midst, eating swine's flesh, and the detestable thing, and the mouse, shall be consumed together, says YHWH.

**66:18** For I know their works and their thoughts; the time comes, that I will gather all nations and tongues; and they shall come, and shall see my glory.

**66:19** And I will set a sign among them, and I will send such as escape of them unto the nations, to Tarshish, Pul, and Lud, that draw the bow, to Tubal and Javan, to the isles afar off, that have not heard my fame, neither have seen my glory; and they shall declare my glory among the nations.

**66:20** And they shall bring all your brethren out of all the nations for an offering unto YHWH, upon horses, and in chariots, and in litters, and upon mules, and upon swift beasts, to my holy mountain Jerusalem, says YHWH, as the children of Israel bring their offering in a clean vessel into the house of YHWH.

**66:21** And of them also will I take for priests and for Levites, says YHWH.

**66:22** For as the new heavens and the new earth, which I will make, shall remain before me, says YHWH, so shall your seed and your name remain.

**66:23** And it shall come to pass, that from one new moon to another, and from one sabbath to another, shall all flesh come to worship before me, says YHWH.

**66:24** And they shall go forth, and look upon the carcasses of the men that have transgressed against me; for their worm shall not die, neither shall their fire be quenched; and they shall be an abhorring unto all flesh.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (66:1-2):**
"The heaven is my throne, and the earth is my footstool."

*Ha-shamayim kis'i ve-ha-aretz hadom raglai*—heaven throne, earth footstool. Acts 7:49 quotes this.

"Where is the house that you may build unto me?"

*Ei-zeh bayit asher tivnu-li*—what house for me?

"Where is the place that may be my resting-place?"

*Ve-ei-zeh maqom menuchati*—what resting place?

"For all these things has my hand made."

*Ve-et-kol-elleh yadi asetah*—hand made all.

"So all these things came to be."

*Va-yihyu khol-elleh*—all came to be.

**The Key Verse (66:2):**
"On this one will I look."

*Ve-el-zeh abbit*—I will look on this one.

"Even on him that is poor and of a contrite spirit."

*El-ani u-nakheh-ruach*—poor and contrite.

"Trembles at my word."

*Ve-chared al-devari*—trembles at word.

**Hypocritical Worship (66:3-4):**
"He that kills an ox is as if he slew a man."

*Shochet ha-shor makkeh-ish*—ox-killer = man-slayer.

"He that sacrifices a lamb, as if he broke a dog's neck."

*Zoveach ha-seh oref kelev*—lamb sacrifice = dog-necking.

"He that offers a meal-offering, as if he offered swine's blood."

*Ma'aleh minchah dam-chazir*—meal offering = swine blood.

"He that makes a memorial-offering of frankincense, as if he blessed an idol."

*Mazkir levonah mevarekh aven*—incense = idol blessing.

"They have chosen their own ways."

*Gam-hemmah bacharu be-darkhehem*—chose own ways.

"Their soul delights in their abominations."

*U-ve-shiqqutzehem nafsham chafetzah*—delight in abominations.

"I also will choose their mockeries."

*Gam-ani evchar be-ta'aluleihem*—choose their mockeries.

"Will bring their fears upon them."

*U-meguroatam avi lahem*—bring fears.

"When I called, none did answer."

*Ya'an qarati ve-ein oneh*—no answer when called.

"When I spoke, they did not hear."

*Dibbarti ve-lo shame'u*—not heard when spoken.

**Zion's Birth (66:5-9):**
"Hear the word of YHWH, you that tremble at his word."

*Shim'u devar-YHWH ha-charedim el-devaro*—tremblers hear.

"Your brethren that hate you."

*Amru acheikhem sone'eikhem*—hating brothers.

"That cast you out for my name's sake."

*Menaddekhem lema'an shemi*—cast out for name.

"'Let YHWH be glorified.'"

*Yikhbad YHWH*—"Let YHWH be glorified."

"But they shall be ashamed."

*Ve-nir'eh ve-simchatkhem ve-hem yevoshu*—they'll be shamed.

"A voice of tumult from the city."

*Qol sha'on me-ir*—city tumult.

"A voice from the temple."

*Qol me-heikhal*—temple voice.

"A voice of YHWH that renders recompense to his enemies."

*Qol YHWH meshallem gemul le-oyvav*—YHWH repays.

**The Key Verses (66:7-9):**
"Before she travailed, she brought forth."

*Be-terem tachil yaladah*—birth before labor.

"Before her pain came, she was delivered of a man-child."

*Be-terem yavo chevel lah ve-himletah zakhar*—son before pain.

"Who has heard such a thing?"

*Mi-shama ka-zot*—who heard this?

"Who has seen such things?"

*Mi ra'ah ka-elleh*—who saw this?

"Is a land born in one day?"

*Ha-yuchal eretz be-yom echad*—land in one day?

"Is a nation brought forth at once?"

*Im-yivvaled goy pa'am echat*—nation at once?

"For as soon as Zion travailed, she brought forth her children."

*Ki-chalah gam-yaladah Tziyyon et-banekha*—Zion's children.

"Shall I bring to the birth, and not cause to bring forth?"

*Ha-ani ashbir ve-lo olid*—will I not deliver?

"Shall I that cause to bring forth shut the womb?"

*Im-ani ha-molid ve-atzarti*—will I shut womb?

**Rejoicing (66:10-14):**
"Rejoice with Jerusalem, and be glad with her."

*Simchu et-Yerushalayim ve-gilu vah*—rejoice with Jerusalem.

"All you that love her."

*Kol-ohavekha*—all lovers.

"Rejoice for joy with her."

*Sisu ittah masos*—joy with her.

"All you that mourn for her."

*Kol-ha-mit'abbelim alekha*—mourners.

"That you may suck and be satisfied with the breast of her consolations."

*Lema'an tinqu u-seva'tem mi-shod tanchumekha*—consolation breast.

"That you may drink deeply with delight of the abundance of her glory."

*Lema'an tamotzu ve-hit'annagtem mi-ziz kevodah*—glory abundance.

**The Key Verse (66:12):**
"I will extend peace to her like a river."

*Hineni noteh elekha kha-nahar shalom*—river peace.

"The glory of the nations like an overflowing stream."

*Ve-khi-nachal shotef kevod goyim*—overflowing glory.

"You shall be borne upon the side."

*U-nesettem al-tzad*—borne on side.

"Shall be dandled upon the knees."

*Ve-al-birkkayim tisha'asha'u*—dandled on knees.

**The Key Verse (66:13):**
"As one whom his mother comforts, so will I comfort you."

*Ke-ish asher immo tenachamennu ken anokhi anachimkhem*—mother-comfort.

"You shall be comforted in Jerusalem."

*U-vi-Yerushalayim tenuchamu*—comforted in Jerusalem.

**Final Judgment (66:15-24):**
"YHWH will come in fire."

*Ki-hinneh YHWH ba-esh yavo*—YHWH in fire.

"His chariots shall be like the whirlwind."

*Ve-kha-sufah markevotav*—whirlwind chariots.

"To render his anger with fury."

*Le-hashiv be-chemah appo*—fury anger.

"His rebuke with flames of fire."

*Ve-ga'arato be-lahavei esh*—fire rebuke.

"By fire will YHWH contend."

*Ki va-esh YHWH nishpat*—fire contention.

"By his sword with all flesh."

*U-ve-charbo et-kol-basar*—sword with flesh.

"The slain of YHWH shall be many."

*Ve-rabbu chalelei YHWH*—many slain.

"They that sanctify themselves and purify themselves to go unto the gardens."

*Ha-mitqaddeshim ve-ha-mittaharim el-ha-gannot*—garden worship.

"Behind one in the midst."

*Achar echad ba-tavekh*—behind one in midst.

"Eating swine's flesh, and the detestable thing, and the mouse."

*Okhelei besar ha-chazir ve-ha-sheqetz ve-ha-akhbar*—eating unclean.

"Shall be consumed together."

*Yachdav yassufu*—consumed together.

**Mission to Nations (66:18-21):**
"I will gather all nations and tongues."

*Meqabbetzet et-kol-ha-goyim ve-ha-leshonot*—gathering nations.

"They shall come, and shall see my glory."

*U-va'u ve-ra'u et-kevodi*—see glory.

"I will set a sign among them."

*Ve-samti vahem ot*—sign among them.

"I will send such as escape of them unto the nations."

*Ve-shillachti mehem pelitim el-ha-goyim*—escapees to nations.

"To Tarshish, Pul, and Lud, that draw the bow."

*Tarshish Pul ve-Lud moshkhei qeshet*—distant nations.

"To Tubal and Javan, to the isles afar off."

*Tuval ve-Yavan ha-iyyim ha-rechoqim*—far islands.

"That have not heard my fame, neither have seen my glory."

*Asher lo-sham'u et-shim'i ve-lo-ra'u et-kevodi*—unheard, unseen.

"They shall declare my glory among the nations."

*Ve-higgidu et-kevodi ba-goyim*—declare glory.

"They shall bring all your brethren out of all the nations for an offering unto YHWH."

*Ve-hevi'u et-kol-acheikhem mi-kol-ha-goyim minchah la-YHWH*—bring brothers.

"Upon horses, and in chariots, and in litters."

*Ba-susim u-va-rekhev u-va-tzabbim*—various conveyances.

"To my holy mountain Jerusalem."

*Al-har qodshi Yerushalayim*—holy mountain.

"Of them also will I take for priests and for Levites."

*Ve-gam-mehem eqqach la-kohanim la-Leviyyim*—Gentile priests/Levites.

**The Key Verses (66:22-24):**
"As the new heavens and the new earth, which I will make, shall remain before me."

*Ki ka-asher ha-shamayim ha-chadashim ve-ha-aretz ha-chadashah asher ani oseh omedim lefanai*—new heavens/earth endure.

"So shall your seed and your name remain."

*Ken ya'amod zar'akhem ve-shimkhem*—seed and name endure.

"From one new moon to another, and from one sabbath to another."

*Mi-ddei chodesh be-chodsho u-mi-ddei shabbat be-shabbatto*—monthly, weekly.

"Shall all flesh come to worship before me."

*Yavo khol-basar le-hishtachavot lefanai*—all flesh worships.

**The Key Verse (66:24):**
"They shall go forth, and look upon the carcasses of the men that have transgressed against me."

*Ve-yatze'u ve-ra'u be-figrei ha-anashim ha-posh'im bi*—see transgressors' corpses.

"For their worm shall not die."

*Ki tola'tam lo tamut*—worm won't die. Mark 9:48 quotes this.

"Neither shall their fire be quenched."

*Ve-isham lo tikhbeh*—fire won't quench.

"They shall be an abhorring unto all flesh."

*Ve-hayu dera'on le-khol-basar*—abhorrence to all.

**Archetypal Layer:** Isaiah 66 concludes with **"the heaven is my throne, and the earth is my footstool" (66:1)**—Acts 7:49, **"on him that is poor and of a contrite spirit, and trembles at my word" (66:2)**, **"as one whom his mother comforts" (66:13)**, **"new heavens and new earth" (66:22)**, and **"their worm shall not die, neither shall their fire be quenched" (66:24)**—Mark 9:48.

**Ethical Inversion Applied:**
- "The heaven is my throne, and the earth is my footstool"—Acts 7:49
- "Where is the house that you may build unto me?"—temple inadequacy
- "On this one will I look, even on him that is poor and of a contrite spirit"—humble valued
- "Trembles at my word"—word-tremblers
- "He that kills an ox is as if he slew a man"—hypocritical worship
- "They have chosen their own ways"—own ways
- "When I called, none did answer"—no answer
- "Before she travailed, she brought forth"—sudden birth
- "Is a nation brought forth at once?"—instant nation
- "Rejoice with Jerusalem, and be glad with her"—rejoice
- "I will extend peace to her like a river"—river peace
- "As one whom his mother comforts, so will I comfort you"—mother-comfort
- "YHWH will come in fire"—fire coming
- "The slain of YHWH shall be many"—many slain
- "I will gather all nations and tongues"—nations gathered
- "They shall come, and shall see my glory"—glory seen
- "I will send such as escape of them unto the nations"—mission
- "They shall declare my glory among the nations"—glory declared
- "Of them also will I take for priests and for Levites"—Gentile priests
- "As the new heavens and the new earth... shall remain"—new creation endures
- "From one new moon to another, and from one sabbath to another"—perpetual worship
- "Shall all flesh come to worship before me"—universal worship
- "Their worm shall not die, neither shall their fire be quenched"—Mark 9:48

**Modern Equivalent:** Isaiah 66:1 is quoted in Acts 7:49 by Stephen. The mother-comfort (66:13) is a beautiful feminine image for God. "Of them also will I take for priests and for Levites" (66:21) anticipates Gentile inclusion in priestly service. "Their worm shall not die" (66:24) is quoted by Jesus in Mark 9:48 for Gehenna.

---

## Book Summary: Isaiah Complete

Isaiah's 66 chapters divide into three major sections:

**First Isaiah (1-39):**
- **1-12**: Judgment and hope for Judah
- **13-23**: Oracles against the nations
- **24-27**: Isaiah Apocalypse
- **28-35**: Woes and promises
- **36-39**: Historical narrative (Hezekiah)

**Second Isaiah (40-55):**
- **40-48**: Comfort, YHWH vs. idols, Cyrus
- **49-55**: Servant Songs, Zion's restoration

**Third Isaiah (56-66):**
- **56-59**: Ethics and sin
- **60-62**: Zion's glory
- **63-66**: Prayer and new creation

**Key Themes:**
- **The Holy One of Israel** (used 26 times)
- **Servant Songs** (42:1-9; 49:1-7; 50:4-9; 52:13-53:12)
- **Comfort** (40:1; 51:3, 12; 52:9; 66:13)
- **New Creation** (65:17; 66:22)
- **Universal Worship** (2:2-4; 56:7; 66:23)

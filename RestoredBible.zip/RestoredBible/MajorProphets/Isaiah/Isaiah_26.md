# Isaiah 26: The Song of Trust and Resurrection

*From the Hebrew: בַּיּוֹם הַהוּא יוּשַׁר הַשִּׁיר־הַזֶּה (Ba-Yom Ha-Hu Yushar Ha-Shir Ha-Zeh) — In That Day Shall This Song Be Sung*

---

## The Song of the Strong City (26:1-6)

**26:1** In that day shall this song be sung in the land of Judah:
We have a strong city; salvation does he appoint for walls and bulwark.

**26:2** Open the gates, that the righteous nation that keeps faithfulness may enter in.

**26:3** The mind stayed on you, you keep in perfect peace, because he trusts in you.

**26:4** Trust in YHWH forever; for in YAH YHWH is an everlasting rock.

**26:5** For he has brought down them that dwell on high, the lofty city,
he lays it low, he lays it low even to the ground,
he brings it even to the dust.

**26:6** The foot shall tread it down, even the feet of the poor,
and the steps of the needy.

---

## The Way of the Righteous (26:7-11)

**26:7** The way of the just is straight;
you, the Upright One, make smooth the path of the just.

**26:8** Yea, in the way of your judgments, O YHWH, have we waited for you;
to your name and to your memorial is the desire of our soul.

**26:9** With my soul have I desired you in the night;
yea, with my spirit within me do I seek you early;
for when your judgments are in the earth,
the inhabitants of the world learn righteousness.

**26:10** Let favor be shown to the wicked, yet will he not learn righteousness;
in the land of uprightness will he deal wrongfully,
and will not behold the majesty of YHWH.

**26:11** YHWH, your hand is lifted up, yet they see not;
they shall see your zeal for the people, and be ashamed;
yea, fire shall devour your adversaries.

---

## Trust in YHWH Alone (26:12-18)

**26:12** YHWH, you will ordain peace for us;
for you have also wrought all our works for us.

**26:13** O YHWH our God, other lords beside you have had dominion over us;
but by you only do we make mention of your name.

**26:14** The dead live not, the shades rise not;
to that end have you punished and destroyed them,
and made all their memory to perish.

**26:15** You have increased the nation, O YHWH,
you have increased the nation, you are glorified;
you have enlarged all the borders of the land.

**26:16** YHWH, in trouble have they sought you,
they poured out a whispered prayer when your chastening was upon them.

**26:17** Like as a woman with child, that draws near the time of her delivery,
is in pain and cries out in her pangs;
so have we been at your presence, O YHWH.

**26:18** We have been with child, we have been in pain,
we have as it were brought forth wind;
we have not wrought any deliverance in the land;
neither are the inhabitants of the world fallen.

---

## Resurrection and Hiding (26:19-21)

**26:19** Your dead shall live, my dead bodies shall arise.
Awake and sing, you that dwell in the dust;
for your dew is as the dew of light,
and the earth shall bring forth the shades.

**26:20** Come, my people, enter into your chambers, and shut your doors about you;
hide yourself for a little moment, until the indignation be overpast.

**26:21** For, behold, YHWH comes forth out of his place
to punish the inhabitants of the earth for their iniquity;
the earth also shall disclose her blood,
and shall no more cover her slain.

---

## Synthesis Notes

**Key Restorations:**

**The Strong City (26:1-2):**
"We have a strong city."

*Ir-oz lanu*—strong city.

"Salvation does he appoint for walls and bulwark."

*Yeshu'ah yashit chomot va-chel*—salvation as walls.

"Open the gates, that the righteous nation that keeps faithfulness may enter in."

*Pitchu she'arim ve-yavo goy-tzaddiq shomer emunim*—gates open for righteous.

**The Key Verses (26:3-4):**
"The mind stayed on you, you keep in perfect peace."

*Yetzer samukh tittzor shalom shalom*—stayed mind, perfect peace.

"Because he trusts in you."

*Ki vekha batu'ach*—trusting.

"Trust in YHWH forever."

*Bitchu va-YHWH adei-ad*—eternal trust.

"For in YAH YHWH is an everlasting rock."

*Ki be-Yah YHWH tzur olamim*—YAH YHWH = eternal rock.

**Lofty City Brought Low (26:5-6):**
"He has brought down them that dwell on high."

*Ki heshach yoshevei marom*—high dwellers lowered.

"The lofty city, he lays it low."

*Qiryah nisgavah yashpilenah*—lofty city brought low.

"He brings it even to the dust."

*Yaggi'enah ad-afar*—to dust.

"The feet of the poor, and the steps of the needy."

*Regel raglei-ani pa'amei dallim*—poor trample it.

**The Way of the Just (26:7-9):**
"The way of the just is straight."

*Orach la-tzaddiq meisharim*—straight path.

"You, the Upright One, make smooth the path of the just."

*Yashar ma'gal tzaddiq tefalles*—smoothed path.

"In the way of your judgments, O YHWH, have we waited for you."

*Af orach mishpatekha YHWH qivvinu-kha*—waiting in judgment-path.

"To your name and to your memorial is the desire of our soul."

*Le-shimkha u-le-zikhrekha ta'avat nafesh*—soul's desire.

"With my soul have I desired you in the night."

*Nafshi ivvitikha ba-laylah*—nighttime desire.

"With my spirit within me do I seek you early."

*Af-ruchi be-qirbi ashacharekka*—early seeking.

**The Key Verse (26:9):**
"When your judgments are in the earth, the inhabitants of the world learn righteousness."

*Ki ka-asher mishpatekha la-aretz tzedeq lamdu yoshevei tevel*—judgments teach righteousness.

**YHWH Alone (26:12-15):**
"YHWH, you will ordain peace for us."

*YHWH tishpot shalom lanu*—peace ordained.

"For you have also wrought all our works for us."

*Ki gam kol-ma'aseinu pa'alta lanu*—YHWH works.

"Other lords beside you have had dominion over us."

*Adonim zulatkha ba'alunu*—other lords ruled.

"But by you only do we make mention of your name."

*Akh-bekha nazkir shemekha*—only YHWH named.

"The dead live not, the shades rise not."

*Metim bal-yichyu refa'im bal-yaqumu*—dead don't rise (the tyrant lords).

**Labor Pains (26:16-18):**
"YHWH, in trouble have they sought you."

*YHWH ba-tzar peqadukha*—sought in trouble.

"They poured out a whispered prayer when your chastening was upon them."

*Tzaqun lachash musarkha lamo*—whispered prayer.

"Like as a woman with child... is in pain and cries out."

*Kemo harah taqriv lalledet tachil tiz'aq*—labor pains.

"We have as it were brought forth wind."

*Kemo yaladnu ruach*—wind-birth (empty effort).

"We have not wrought any deliverance in the land."

*Yeshu'ot bal-na'aseh eretz*—no human salvation.

**The Key Verse (26:19):**
"Your dead shall live, my dead bodies shall arise."

*Yichyu metekha nevilati yequmun*—dead live, bodies arise.

"Awake and sing, you that dwell in the dust."

*Haqitzu ve-rannenu shoknei afar*—dust-dwellers awake.

"For your dew is as the dew of light."

*Ki tal orot tallekha*—light-dew.

"The earth shall bring forth the shades."

*Ve-eretz refa'im tappil*—earth births shades.

**Hiding (26:20-21):**
"Come, my people, enter into your chambers, and shut your doors about you."

*Lekh ammi bo va-chadarekha u-segor delatekha ba'adekha*—enter and hide.

"Hide yourself for a little moment, until the indignation be overpast."

*Chavi khim'at-rega ad-ya'avor za'am*—hide until wrath passes.

"YHWH comes forth out of his place to punish the inhabitants of the earth."

*Ki-hinneh YHWH yotze mi-meqomo lifqod avon yoshev-ha-aretz alav*—YHWH comes to punish.

"The earth also shall disclose her blood."

*Ve-gilletah ha-aretz et-damekha*—blood revealed.

"Shall no more cover her slain."

*Ve-lo-tekhasseh od al-harugeha*—slain uncovered.

**Archetypal Layer:** Isaiah 26 contains **"perfect peace" (26:3)**, **"YAH YHWH is an everlasting rock" (26:4)**, and **the resurrection promise (26:19)**—one of the clearest OT statements of bodily resurrection.

**Ethical Inversion Applied:**
- "We have a strong city"—salvation-walls
- "Open the gates, that the righteous nation... may enter in"—righteous enter
- "The mind stayed on you, you keep in perfect peace"—stayed mind = peace
- "Trust in YHWH forever"—eternal trust
- "In YAH YHWH is an everlasting rock"—eternal rock
- "He has brought down them that dwell on high"—pride lowered
- "The feet of the poor... tread it down"—reversal
- "The way of the just is straight"—straight path
- "When your judgments are in the earth, the inhabitants of the world learn righteousness"—judgments teach
- "Other lords beside you have had dominion over us"—other lords
- "But by you only do we make mention of your name"—YHWH alone
- "We have as it were brought forth wind"—human effort empty
- "Your dead shall live, my dead bodies shall arise"—resurrection
- "Awake and sing, you that dwell in the dust"—dust-dwellers awake
- "Come, my people, enter into your chambers"—hide during wrath
- "The earth also shall disclose her blood"—blood revealed

**Modern Equivalent:** Isaiah 26:3's "perfect peace" (*shalom shalom*) for the stayed mind is a classic peace text. The resurrection promise (26:19) is foundational for later Jewish and Christian belief. The hiding command (26:20) echoes Passover protection.

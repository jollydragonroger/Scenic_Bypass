# Isaiah 40: Comfort My People

*From the Hebrew: נַחֲמוּ נַחֲמוּ עַמִּי (Nachamu Nachamu Ammi) — Comfort, Comfort My People*

---

## The Voice of Comfort (40:1-11)

**40:1** Comfort, comfort my people, says your God.

**40:2** Speak tenderly to Jerusalem, and cry unto her, that her warfare is accomplished, that her iniquity is pardoned; for she has received of YHWH's hand double for all her sins.

**40:3** The voice of one that cries: "In the wilderness prepare the way of YHWH, make straight in the desert a highway for our God.

**40:4** "Every valley shall be exalted, and every mountain and hill shall be made low; and the crooked shall be made straight, and the rough places plain.

**40:5** "And the glory of YHWH shall be revealed, and all flesh shall see it together; for the mouth of YHWH has spoken it."

**40:6** The voice of one saying: "Cry." And one said: "What shall I cry?" "All flesh is grass, and all the goodliness thereof is as the flower of the field.

**40:7** "The grass withers, the flower fades; because the breath of YHWH blows upon it—surely the people is grass.

**40:8** "The grass withers, the flower fades; but the word of our God shall stand forever."

**40:9** O you that tell good tidings to Zion, get up into the high mountain; O you that tell good tidings to Jerusalem, lift up your voice with strength; lift it up, be not afraid; say unto the cities of Judah: "Behold your God!"

**40:10** Behold, the Lord YHWH will come as a mighty one, and his arm will rule for him; behold, his reward is with him, and his recompense before him.

**40:11** He will feed his flock like a shepherd, he will gather the lambs in his arm, and carry them in his bosom, and gently lead those that give suck.

---

## The Incomparable God (40:12-26)

**40:12** Who has measured the waters in the hollow of his hand, and meted out heaven with the span, and comprehended the dust of the earth in a measure, and weighed the mountains in scales, and the hills in a balance?

**40:13** Who has meted out the spirit of YHWH? Or who was his counsellor that he might instruct him?

**40:14** With whom took he counsel, and who instructed him, and taught him in the path of justice, and taught him knowledge, and made him to know the way of discernment?

**40:15** Behold, the nations are as a drop of a bucket, and are counted as the small dust of the balance; behold, he takes up the isles as a very little thing.

**40:16** And Lebanon is not sufficient to burn, nor the beasts thereof sufficient for a burnt-offering.

**40:17** All the nations are as nothing before him; they are accounted by him as things of nought, and vanity.

**40:18** To whom then will you liken God? Or what likeness will you compare unto him?

**40:19** The image! A workman has cast it, and a goldsmith overlays it with gold, and casts for it silver chains.

**40:20** He that is too impoverished for such an offering chooses a tree that will not rot; he seeks unto him a cunning workman to set up an image, that shall not be moved.

**40:21** Have you not known? Have you not heard? Has it not been told you from the beginning? Have you not understood from the foundations of the earth?

**40:22** It is he that sits above the circle of the earth, and the inhabitants thereof are as grasshoppers; that stretches out the heavens as a curtain, and spreads them out as a tent to dwell in;

**40:23** That brings princes to nothing; he makes the judges of the earth as a thing of nought.

**40:24** Scarce are they planted, scarce are they sown, scarce has their stock taken root in the earth; and he blows upon them, and they wither, and the whirlwind takes them away as stubble.

**40:25** "To whom then will you liken me, that I should be equal?" says the Holy One.

**40:26** Lift up your eyes on high, and see: who has created these? He that brings out their host by number, he calls them all by name; by the greatness of his might, and for that he is strong in power, not one fails.

---

## Renewed Strength (40:27-31)

**40:27** Why say you, O Jacob, and speak, O Israel: "My way is hid from YHWH, and my judgment is passed over from my God"?

**40:28** Have you not known? Have you not heard? The everlasting God, YHWH, the Creator of the ends of the earth, faints not, neither is weary; his understanding is unsearchable.

**40:29** He gives power to the faint; and to him that has no might he increases strength.

**40:30** Even the youths shall faint and be weary, and the young men shall utterly fall;

**40:31** But they that wait upon YHWH shall renew their strength; they shall mount up with wings as eagles; they shall run, and not be weary; they shall walk, and not faint.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (40:1-2):**
"Comfort, comfort my people, says your God."

*Nachamu nachamu ammi yomar Eloheikhem*—double comfort (begins "Second Isaiah").

"Speak tenderly to Jerusalem."

*Dabberu al-lev Yerushalayim*—speak to heart.

"Cry unto her, that her warfare is accomplished."

*Ve-qir'u elekha ki male'ah tzeva'ah*—warfare ended.

"Her iniquity is pardoned."

*Ki nirtzah avonah*—iniquity accepted/pardoned.

"She has received of YHWH's hand double for all her sins."

*Ki laqechah mi-yad YHWH kiflayim be-khol-chatto'tekha*—double punishment.

**The Key Verses (40:3-5):**
"The voice of one that cries: 'In the wilderness prepare the way of YHWH.'"

*Qol qore ba-midbar pannu derekh YHWH*—voice in wilderness. All four Gospels quote this for John the Baptist (Matthew 3:3; Mark 1:3; Luke 3:4; John 1:23).

"Make straight in the desert a highway for our God."

*Yashsheru ba-aravah mesillah le-Eloheinu*—straight highway.

"Every valley shall be exalted."

*Kol-gei yinnase*—valleys raised.

"Every mountain and hill shall be made low."

*Ve-khol-har ve-giv'ah yishpalu*—mountains lowered.

"The crooked shall be made straight."

*Ve-hayah he-aqov le-mishor*—crooked straightened.

"The rough places plain."

*Ve-ha-rekhassim le-biq'ah*—rough smoothed.

"The glory of YHWH shall be revealed."

*Ve-niglah kevod YHWH*—glory revealed.

"All flesh shall see it together."

*Ve-ra'u khol-basar yachdav*—all flesh sees.

**The Key Verses (40:6-8):**
"All flesh is grass."

*Kol-ha-basar chatzir*—flesh = grass.

"All the goodliness thereof is as the flower of the field."

*Ve-khol-chasdo ke-tzitz ha-sadeh*—beauty = flower.

"The grass withers, the flower fades."

*Yavesh chatzir navel tzitz*—withers and fades.

"Because the breath of YHWH blows upon it."

*Ki ruach YHWH nashevah bo*—YHWH's breath.

"Surely the people is grass."

*Akhen chatzir ha-am*—people = grass.

"The grass withers, the flower fades."

*Yavesh chatzir navel tzitz*—repeated.

"But the word of our God shall stand forever."

*U-devar Eloheinu yaqum le-olam*—God's word endures. 1 Peter 1:24-25 quotes this.

**The Key Verse (40:9):**
"O you that tell good tidings to Zion."

*Al har-gavoah ali-lakh mevasseret Tziyyon*—herald of good news.

"Lift up your voice with strength."

*Harimi va-kho'ach qolekh*—strong voice.

"Say unto the cities of Judah: 'Behold your God!'"

*Imri le-arei Yehudah hinneh Eloheikhem*—behold God!

**The Key Verse (40:11):**
"He will feed his flock like a shepherd."

*Ka-ro'eh edro yir'eh*—shepherd feeding.

"He will gather the lambs in his arm."

*Bi-zero'o yeqabbetz tela'im*—gathering lambs.

"Carry them in his bosom."

*U-ve-cheiqo yissa*—carrying in bosom.

"Gently lead those that give suck."

*Alot yenahhel*—gentle leading.

**Incomparable God (40:12-26):**
"Who has measured the waters in the hollow of his hand?"

*Mi-madad be-sha'alo mayim*—hand measures waters.

"Meted out heaven with the span."

*Ve-shamayim ba-zeret tikken*—span measures heavens.

"Who has meted out the spirit of YHWH?"

*Mi-tikken et-ruach YHWH*—who measured YHWH's spirit? Romans 11:34 quotes this.

"Who was his counsellor?"

*Ve-ish atzato yodi'ennu*—no counsellor.

"The nations are as a drop of a bucket."

*Hen goyim ke-mar mi-deli*—nations = bucket drop.

"Are counted as the small dust of the balance."

*U-khe-shachaq mozanayim nechshavu*—balance dust.

"To whom then will you liken God?"

*Ve-el-mi tedammeyun El*—God incomparable.

**The Key Verse (40:22):**
"It is he that sits above the circle of the earth."

*Ha-yoshev al-chug ha-aretz*—sits on earth's circle.

"The inhabitants thereof are as grasshoppers."

*Ve-yoshevekha ka-chagavim*—inhabitants like grasshoppers.

"That stretches out the heavens as a curtain."

*Ha-noteh kha-doq shamayim*—stretches heavens.

"Spreads them out as a tent to dwell in."

*Va-yimtachem ka-ohel la-shevet*—tent-heavens.

**The Key Verse (40:25):**
"'To whom then will you liken me, that I should be equal?' says the Holy One."

*Ve-el-mi tedammeyuni ve-eshveh yomar qadosh*—Holy One incomparable.

**The Key Verse (40:26):**
"Lift up your eyes on high, and see: who has created these?"

*Se'u-marom eineikhem u-re'u mi-vara eleh*—look up, who created?

"He that brings out their host by number."

*Ha-motzi be-mispar tzeva'am*—brings out numbered host.

"He calls them all by name."

*Le-khullam be-shem yiqra*—calls by name.

"Not one fails."

*Ish lo ne'dar*—none missing.

**The Key Verses (40:28-31):**
"The everlasting God, YHWH, the Creator of the ends of the earth."

*Elohei olam YHWH bore qetzot ha-aretz*—eternal Creator.

"Faints not, neither is weary."

*Lo yi'af ve-lo yiga*—unfainting.

"His understanding is unsearchable."

*Ein cheqer li-tevunato*—unsearchable understanding.

"He gives power to the faint."

*Noten la-ya'ef ko'ach*—power to faint.

"To him that has no might he increases strength."

*U-le-ein onim otzmah yarbeh*—strength to weak.

"Even the youths shall faint and be weary."

*Ve-yi'afu ne'arim ve-yiga'u*—youths faint.

"The young men shall utterly fall."

*U-vachurim kashol yikkashelu*—young men fall.

**The Key Verse (40:31):**
"They that wait upon YHWH shall renew their strength."

*Ve-qovei YHWH yachalifu kho'ach*—waiters renew strength.

"They shall mount up with wings as eagles."

*Ya'alu ever ka-nesharim*—eagle wings.

"They shall run, and not be weary."

*Yarutzu ve-lo yiga'u*—run unwearied.

"They shall walk, and not faint."

*Yelekhu ve-lo yi'afu*—walk unfainting.

**Archetypal Layer:** Isaiah 40 begins **"Second Isaiah" (chapters 40-55)**—the Book of Comfort. Key themes: **voice in wilderness (40:3)**, **all flesh is grass but God's word endures (40:6-8)**, **God incomparable (40:18-26)**, **eagle wings for waiters (40:31)**.

**Ethical Inversion Applied:**
- "Comfort, comfort my people"—double comfort
- "Her warfare is accomplished"—warfare ended
- "Her iniquity is pardoned"—pardon
- "The voice of one that cries: 'In the wilderness prepare the way'"—John the Baptist
- "Every valley shall be exalted"—leveling
- "The glory of YHWH shall be revealed"—glory revealed
- "All flesh is grass"—human frailty
- "The word of our God shall stand forever"—1 Peter 1:24-25
- "'Behold your God!'"—herald announces
- "He will feed his flock like a shepherd"—shepherd God
- "Who has measured the waters in the hollow of his hand?"—creation scale
- "Who has meted out the spirit of YHWH?"—Romans 11:34
- "The nations are as a drop of a bucket"—nations small
- "To whom then will you liken God?"—incomparable
- "It is he that sits above the circle of the earth"—cosmic throne
- "'To whom then will you liken me?' says the Holy One"—Holy One unique
- "He calls them all by name"—stars named
- "The everlasting God... faints not, neither is weary"—unfainting
- "He gives power to the faint"—power given
- "They that wait upon YHWH shall renew their strength"—renewed strength
- "They shall mount up with wings as eagles"—eagle imagery

**Modern Equivalent:** Isaiah 40 opens "Second Isaiah" with comfort. The "voice in the wilderness" (40:3) is applied to John the Baptist in all four Gospels. "All flesh is grass... but the word of our God shall stand forever" (40:6-8) is quoted in 1 Peter 1:24-25. "They that wait upon YHWH" (40:31) is one of Scripture's most beloved promises.

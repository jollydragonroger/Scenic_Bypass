# Isaiah 12: The Song of Salvation

*From the Hebrew: וְאָמַרְתָּ בַּיּוֹם הַהוּא (Ve-Amarta Ba-Yom Ha-Hu) — And in That Day You Shall Say*

---

## The Song of the Individual (12:1-3)

**12:1** And in that day you shall say:
"I will give thanks unto you, O YHWH;
for though you were angry with me,
your anger is turned away, and you comfort me.

**12:2** "Behold, God is my salvation;
I will trust, and will not be afraid;
for YAH YHWH is my strength and song;
and he is become my salvation."

**12:3** Therefore with joy shall you draw water
out of the wells of salvation.

---

## The Song of the Community (12:4-6)

**12:4** And in that day shall you say:
"Give thanks unto YHWH, call upon his name,
declare his doings among the peoples,
make mention that his name is exalted.

**12:5** "Sing unto YHWH; for he has done gloriously;
this is made known in all the earth.

**12:6** "Cry aloud and shout, you inhabitant of Zion,
for great in the midst of you is the Holy One of Israel."

---

## Synthesis Notes

**Key Restorations:**

**Individual Thanksgiving (12:1):**
"In that day you shall say."

*Ve-amarta ba-yom ha-hu*—eschatological thanksgiving.

"I will give thanks unto you, O YHWH."

*Odekha YHWH*—thanksgiving.

"Though you were angry with me."

*Ki anafta bi*—past anger.

"Your anger is turned away."

*Yashov appekha*—anger turned.

"You comfort me."

*U-tenachameni*—comfort.

**The Key Verse (12:2):**
"Behold, God is my salvation."

*Hinneh El yeshu'ati*—God = salvation.

"I will trust, and will not be afraid."

*Evtach ve-lo efchad*—trust without fear.

"YAH YHWH is my strength and song."

*Ki-ozzi ve-zimrat Yah YHWH*—YAH YHWH = strength and song.

"He is become my salvation."

*Va-yehi-li li-yeshu'ah*—become salvation.

**Translation Note:**
This verse echoes Exodus 15:2 (Song of the Sea). The double divine name "YAH YHWH" emphasizes the name. *Yeshu'ah* (salvation) connects to Yeshua/Jesus.

**The Key Verse (12:3):**
"With joy shall you draw water out of the wells of salvation."

*U-she'avtem mayim be-sason mi-ma'aynei ha-yeshu'ah*—wells of salvation.

This verse is recited during Sukkot water-drawing ceremony (*Simchat Beit Ha-Sho'evah*). Jesus references it in John 7:37-38.

**Community Thanksgiving (12:4-6):**
"Give thanks unto YHWH, call upon his name."

*Hodu la-YHWH qir'u vi-shemo*—thanksgiving and invocation.

"Declare his doings among the peoples."

*Hodi'u va-ammim alilotav*—declare to nations.

"Make mention that his name is exalted."

*Hazkiru ki nisgav shemo*—exalted name.

"Sing unto YHWH; for he has done gloriously."

*Zammeru YHWH ki ge'ut asah*—glorious deeds.

"This is made known in all the earth."

*Muda'at zot be-khol-ha-aretz*—known worldwide.

**The Key Verse (12:6):**
"Cry aloud and shout, you inhabitant of Zion."

*Tzahali va-ronni yoshevet Tziyyon*—Zion rejoices.

"For great in the midst of you is the Holy One of Israel."

*Ki-gadol be-qirbkekh qedosh Yisra'el*—Holy One in midst.

**Archetypal Layer:** Isaiah 12 concludes the "Book of Immanuel" (chapters 7-12) with **a hymn of salvation**. It echoes the Exodus victory song and anticipates eschatological joy.

**Ethical Inversion Applied:**
- "Though you were angry with me, your anger is turned away"—anger to comfort
- "Behold, God is my salvation"—God = salvation
- "I will trust, and will not be afraid"—fearless trust
- "YAH YHWH is my strength and song"—Exodus 15:2 echo
- "He is become my salvation"—yeshu'ah
- "With joy shall you draw water out of the wells of salvation"—Sukkot/John 7
- "Give thanks unto YHWH, call upon his name"—thanksgiving
- "Declare his doings among the peoples"—universal witness
- "Make mention that his name is exalted"—name exaltation
- "Sing unto YHWH; for he has done gloriously"—glory-song
- "This is made known in all the earth"—worldwide knowledge
- "Cry aloud and shout, you inhabitant of Zion"—Zion's joy
- "Great in the midst of you is the Holy One of Israel"—immanent Holy One

**Modern Equivalent:** Isaiah 12 concludes the Immanuel section with celebration. The "wells of salvation" (12:3) connects to Sukkot liturgy and Jesus' invitation (John 7:37-38). The Holy One "in the midst" (12:6) fulfills the Immanuel ("God with us") theme.

---

## Section Summary: Isaiah 1-12 (Book of Immanuel)

Chapters 1-12 form Isaiah's first major section:

**Structure:**
- **Chapter 1**: Prologue/indictment
- **Chapters 2-4**: Day of YHWH and Zion's future
- **Chapter 5**: Vineyard song and six woes
- **Chapter 6**: Isaiah's call
- **Chapters 7-12**: Book of Immanuel
  - **7**: Immanuel sign
  - **8**: Maher-shalal-hash-baz
  - **9**: Light in darkness, child born
  - **10**: Assyria judged, remnant
  - **11**: Branch of Jesse, peaceable kingdom
  - **12**: Salvation song (conclusion)

**Major Themes:**
- **Judgment and salvation** intertwined
- **Immanuel** ("God with us") as hope
- **Remnant** (Shear-jashub) preserved
- **Messianic king** from Jesse's stump
- **Universal peace** and knowledge of YHWH
- **Holy One of Israel** as Isaiah's distinctive title

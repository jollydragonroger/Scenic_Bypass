# Isaiah 63: The Divine Warrior and the Prayer of Remembrance

*From the Hebrew: מִי־זֶה בָּא מֵאֱדוֹם (Mi-Zeh Ba Me-Edom) — Who Is This That Comes from Edom?*

---

## The Divine Warrior from Edom (63:1-6)

**63:1** "Who is this that comes from Edom, with crimsoned garments from Bozrah? This that is glorious in his apparel, marching in the greatness of his strength?" "I that speak in righteousness, mighty to save."

**63:2** "Wherefore is your apparel red, and your garments like his that treads in the winevat?"

**63:3** "I have trodden the winepress alone, and of the peoples there was no man with me; yea, I trod them in my anger, and trampled them in my fury; and their lifeblood is dashed against my garments, and I have stained all my raiment.

**63:4** "For the day of vengeance that was in my heart, and my year of redemption are come.

**63:5** "And I looked, and there was none to help, and I was astonished that there was none to uphold; therefore my own arm brought salvation unto me, and my fury, it upheld me.

**63:6** "And I trod down the peoples in my anger, and made them drunk in my fury, and I poured out their lifeblood on the earth."

---

## Remembering YHWH's Kindness (63:7-14)

**63:7** I will make mention of the lovingkindnesses of YHWH, and the praises of YHWH, according to all that YHWH has bestowed on us; and the great goodness toward the house of Israel, which he has bestowed on them according to his compassions, and according to the multitude of his lovingkindnesses.

**63:8** For he said: "Surely, they are my people, children that will not deal falsely"; so he was their Savior.

**63:9** In all their affliction he was afflicted, and the angel of his presence saved them; in his love and in his pity he redeemed them; and he bore them, and carried them all the days of old.

**63:10** But they rebelled, and grieved his holy spirit; therefore he was turned to be their enemy, himself fought against them.

**63:11** Then his people remembered the days of old, of Moses: "Where is he that brought them up out of the sea with the shepherds of his flock? Where is he that put his holy spirit in the midst of them?

**63:12** "That caused his glorious arm to go at the right hand of Moses? That divided the waters before them, to make himself an everlasting name?

**63:13** "That led them through the depths, as a horse in the wilderness, without stumbling?

**63:14** "As the cattle that go down into the valley, the spirit of YHWH caused them to rest; so did you lead your people, to make yourself a glorious name."

---

## Prayer for Divine Intervention (63:15-19)

**63:15** Look down from heaven, and see, even from your holy and glorious habitation; where is your zeal and your mighty acts? The yearning of your heart and your compassions are restrained toward me.

**63:16** For you are our Father; for Abraham knows us not, and Israel does not acknowledge us; you, O YHWH, are our Father; our Redeemer from everlasting is your name.

**63:17** O YHWH, why do you make us to err from your ways, and harden our heart from your fear? Return for your servants' sake, the tribes of your inheritance.

**63:18** Your holy people possessed it but a little while; our adversaries have trodden down your sanctuary.

**63:19** We are become as they over whom you never bore rule, as they that were not called by your name.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (63:1-3):**
"Who is this that comes from Edom?"

*Mi-zeh ba me-Edom*—coming from Edom.

"With crimsoned garments from Bozrah?"

*Chamuz begadim mi-Botzrah*—crimson from Bozrah.

"This that is glorious in his apparel."

*Zeh hadur bi-levusho*—glorious apparel.

"Marching in the greatness of his strength?"

*Tzo'eh be-rov kocho*—mighty stride.

"'I that speak in righteousness, mighty to save.'"

*Ani medabber bi-tzedaqah rav le-hoshi'a*—righteous, mighty to save.

"'Wherefore is your apparel red?'"

*Maddua adom li-levushekha*—why red?

"'Your garments like his that treads in the winevat?'"

*U-vegadekha ke-dorekh be-gat*—winevat treader.

"'I have trodden the winepress alone.'"

*Purah darakhti levaddi*—alone in winepress. Revelation 19:13-15 echoes this.

"'Of the peoples there was no man with me.'"

*U-me-ammim ein-ish itti*—no man with me.

"'I trod them in my anger.'"

*Ve-edrekom be-appi*—treading in anger.

"'Trampled them in my fury.'"

*Ve-ermesom ba-chamati*—trampling in fury.

"'Their lifeblood is dashed against my garments.'"

*Ve-yez nitzcham al-begadai*—blood on garments.

"'I have stained all my raiment.'"

*Ve-khol-malbushi eg'alti*—stained raiment.

**The Key Verses (63:4-6):**
"'The day of vengeance that was in my heart.'"

*Ki yom naqam be-libbi*—vengeance day in heart.

"'My year of redemption are come.'"

*U-shenat ge'ulai ba'ah*—redemption year.

"'I looked, and there was none to help.'"

*Va-abbit ve-ein ozer*—no helper.

"'I was astonished that there was none to uphold.'"

*Va-eshtomem ve-ein somekh*—no upholder (echoes 59:16).

"'Therefore my own arm brought salvation unto me.'"

*Va-tosha li zero'i*—own arm saves.

"'My fury, it upheld me.'"

*Va-chamati hi semakhatni*—fury upholds.

"'I trod down the peoples in my anger.'"

*Va-evus ammim be-appi*—trampling peoples.

"'Made them drunk in my fury.'"

*Va-ashakkerem ba-chamati*—drunk with fury.

"'I poured out their lifeblood on the earth.'"

*Va-orid la-aretz nitzzcham*—blood poured.

**Remembering Kindness (63:7-9):**
"I will make mention of the lovingkindnesses of YHWH."

*Chasdei YHWH azkir*—YHWH's lovingkindnesses.

"The praises of YHWH."

*Tehillot YHWH*—YHWH's praises.

"According to all that YHWH has bestowed on us."

*Ke-khol asher-gemalanu YHWH*—all bestowed.

"The great goodness toward the house of Israel."

*Ve-rav-tuv le-veit Yisra'el*—great goodness.

"According to his compassions."

*Ke-rachamav*—according to compassions.

"According to the multitude of his lovingkindnesses."

*Ve-khe-rov chasadav*—many lovingkindnesses.

"'Surely, they are my people.'"

*Akh-ammi hemmah*—my people.

"'Children that will not deal falsely.'"

*Banim lo yeshaqeru*—faithful children.

"So he was their Savior."

*Va-yehi lahem le-moshi'a*—their Savior.

**The Key Verse (63:9):**
"In all their affliction he was afflicted."

*Be-khol-tzaratam lo tzar*—afflicted with them.

"The angel of his presence saved them."

*U-mal'akh panav hoshi'am*—angel of presence saves.

"In his love and in his pity he redeemed them."

*Be-ahavato u-ve-chemlato hu ge'alam*—love and pity redeem.

"He bore them, and carried them all the days of old."

*Va-yenassem va-yenatlem kol-yemei olam*—carried always.

**Rebellion (63:10-14):**
"They rebelled, and grieved his holy spirit."

*Ve-hemmah maru ve-itzevu et-ruach qodsho*—grieved holy Spirit. Ephesians 4:30 echoes this.

"He was turned to be their enemy."

*Va-yehappekh lahem le-oyev*—became enemy.

"Himself fought against them."

*Hu nilcham-bam*—fought them.

"Then his people remembered the days of old, of Moses."

*Va-yizkor yemei-olam Mosheh ammo*—remembered Moses days.

"'Where is he that brought them up out of the sea?'"

*Ayyeh ha-ma'alem mi-yam*—where is sea-bringer?

"'Where is he that put his holy spirit in the midst of them?'"

*Ayyeh ha-sam be-qirbo et-ruach qodsho*—where is Spirit-giver?

"'That caused his glorious arm to go at the right hand of Moses?'"

*Molik li-yemin Mosheh zero'a tif'arto*—glorious arm at Moses' right.

"'That divided the waters before them?'"

*Boqe'a mayim mippeneihem*—divided waters.

"'To make himself an everlasting name?'"

*La'asot lo shem olam*—everlasting name.

"'That led them through the depths?'"

*Molikham ba-tehomot*—led through depths.

"'As a horse in the wilderness, without stumbling?'"

*Ka-sus ba-midbar lo yikkashelu*—horse in wilderness.

"'The spirit of YHWH caused them to rest.'"

*Ruach YHWH tenichenu*—Spirit gave rest.

"'So did you lead your people.'"

*Ken nihagta ammekha*—so you led.

"'To make yourself a glorious name.'"

*La'asot lekha shem tif'aret*—glorious name.

**Prayer (63:15-19):**
"Look down from heaven, and see."

*Habbet mi-shamayim u-re'eh*—look from heaven.

"From your holy and glorious habitation."

*Mi-zevul qodshekha ve-tif'artekha*—holy dwelling.

"Where is your zeal and your mighty acts?"

*Ayyeh qin'atekha u-gevurotekha*—where is zeal?

"The yearning of your heart and your compassions are restrained toward me."

*Hamon me'ekha ve-rachamekha elai hit'appaquu*—restrained compassion.

**The Key Verse (63:16):**
"For you are our Father."

*Ki-attah avinu*—you are Father.

"For Abraham knows us not."

*Ki Avraham lo yeda'anu*—Abraham doesn't know us.

"Israel does not acknowledge us."

*Ve-Yisra'el lo yakkranu*—Israel doesn't acknowledge.

"You, O YHWH, are our Father."

*Attah YHWH avinu*—YHWH our Father.

"Our Redeemer from everlasting is your name."

*Go'alenu me-olam shemekha*—everlasting Redeemer.

"O YHWH, why do you make us to err from your ways?"

*Lammah tat'enu YHWH mi-derakhekha*—why make us err?

"Harden our heart from your fear?"

*Taqshi'a libbenu mi-yir'atekha*—harden heart.

"Return for your servants' sake."

*Shuv lema'an avadekha*—return for servants.

"The tribes of your inheritance."

*Shivtei nachalatekha*—inheritance tribes.

"Your holy people possessed it but a little while."

*La-mitz'ar yareshu am-qodshekha*—brief possession.

"Our adversaries have trodden down your sanctuary."

*Tzareinu bossu miqdashekha*—sanctuary trampled.

"We are become as they over whom you never bore rule."

*Hayinu me-olam lo-mashalta bam*—never ruled.

"As they that were not called by your name."

*Lo-niqra shimkha aleihem*—not called by name.

**Archetypal Layer:** Isaiah 63 contains **the divine warrior from Edom (63:1-6)**—Revelation 19:13-15, **"in all their affliction he was afflicted" (63:9)**, **"they rebelled, and grieved his holy spirit" (63:10)**—Ephesians 4:30, and **"you are our Father" (63:16)**.

**Ethical Inversion Applied:**
- "Who is this that comes from Edom?"—divine warrior
- "With crimsoned garments from Bozrah?"—blood-stained
- "'I that speak in righteousness, mighty to save'"—righteous, saving
- "'I have trodden the winepress alone'"—Revelation 19:13-15
- "'Of the peoples there was no man with me'"—alone
- "'The day of vengeance that was in my heart'"—vengeance
- "'My year of redemption are come'"—redemption
- "'My own arm brought salvation unto me'"—own arm saves
- "I will make mention of the lovingkindnesses of YHWH"—lovingkindnesses
- "'Surely, they are my people'"—covenant
- "In all their affliction he was afflicted"—shared affliction
- "The angel of his presence saved them"—presence-angel
- "In his love and in his pity he redeemed them"—love-redemption
- "He bore them, and carried them"—carrying
- "They rebelled, and grieved his holy spirit"—Ephesians 4:30
- "He was turned to be their enemy"—enemy
- "'Where is he that put his holy spirit in the midst of them?'"—Spirit question
- "'That caused his glorious arm to go at the right hand of Moses?'"—Moses' arm
- "Look down from heaven, and see"—prayer
- "For you are our Father"—Father
- "Our Redeemer from everlasting is your name"—everlasting Redeemer
- "O YHWH, why do you make us to err from your ways?"—lament
- "We are become as they over whom you never bore rule"—abandonment feeling

**Modern Equivalent:** Isaiah 63:1-6's divine warrior with blood-stained garments influences Revelation 19:13-15. "In all their affliction he was afflicted" (63:9) shows divine sympathy. "Grieved his holy spirit" (63:10) is echoed in Ephesians 4:30. "You are our Father" (63:16) is rare OT language for God as Father.

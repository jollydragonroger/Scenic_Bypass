# Isaiah 55: Come to the Waters

*From the Hebrew: הוֹי כָּל־צָמֵא לְכוּ לַמָּיִם (Hoy Kol-Tzame Lekhu La-Mayim) — Ho, Every One That Thirsts, Come to the Waters*

---

## The Free Invitation (55:1-5)

**55:1** Ho, every one that thirsts, come to the waters, and he that has no money; come, buy, and eat; yea, come, buy wine and milk without money and without price.

**55:2** Wherefore do you spend money for that which is not bread? And your labour for that which satisfies not? Hearken diligently unto me, and eat that which is good, and let your soul delight itself in fatness.

**55:3** Incline your ear, and come unto me; hear, and your soul shall live; and I will make an everlasting covenant with you, even the sure mercies of David.

**55:4** Behold, I have given him for a witness to the peoples, a prince and commander to the peoples.

**55:5** Behold, you shall call a nation that you know not, and a nation that knew not you shall run unto you, because of YHWH your God, and for the Holy One of Israel, for he has glorified you.

---

## Seek YHWH (55:6-9)

**55:6** Seek YHWH while he may be found, call upon him while he is near;

**55:7** Let the wicked forsake his way, and the man of iniquity his thoughts; and let him return unto YHWH, and he will have compassion upon him; and to our God, for he will abundantly pardon.

**55:8** For my thoughts are not your thoughts, neither are your ways my ways, says YHWH.

**55:9** For as the heavens are higher than the earth, so are my ways higher than your ways, and my thoughts than your thoughts.

---

## The Word Accomplishes (55:10-13)

**55:10** For as the rain comes down and the snow from heaven, and returns not there, except it water the earth, and make it bring forth and bud, and give seed to the sower and bread to the eater;

**55:11** So shall my word be that goes forth out of my mouth: it shall not return unto me void, but it shall accomplish that which I please, and it shall prosper in the thing whereto I sent it.

**55:12** For you shall go out with joy, and be led forth with peace; the mountains and the hills shall break forth before you into singing, and all the trees of the field shall clap their hands.

**55:13** Instead of the thorn shall come up the cypress, and instead of the brier shall come up the myrtle; and it shall be to YHWH for a name, for an everlasting sign that shall not be cut off.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (55:1-2):**
"Ho, every one that thirsts, come to the waters."

*Hoy kol-tzame lekhu la-mayim*—thirsty invited. Revelation 22:17 echoes this.

"He that has no money; come, buy, and eat."

*Va-asher ein-lo kesef lekhu shivru ve-ekhlu*—no money needed.

"Come, buy wine and milk without money and without price."

*U-lekhu shivru be-lo-khesef u-ve-lo mechir yayin ve-chalav*—free wine and milk.

"Wherefore do you spend money for that which is not bread?"

*Lammah tishqelu-khesef be-lo-lechem*—why spend on non-bread?

"Your labour for that which satisfies not?"

*Vi-yegi'akhem be-lo le-sov'ah*—unsatisfying labor.

"Hearken diligently unto me, and eat that which is good."

*Shim'u shamo'a elai ve-ikhlu-tov*—hear and eat good.

"Let your soul delight itself in fatness."

*Ve-tit'annag ba-deshen nafshekhem*—soul delights in fatness.

**The Key Verse (55:3):**
"Incline your ear, and come unto me."

*Hattu oznekhem u-lekhu elai*—incline ear, come.

"Hear, and your soul shall live."

*Shim'u u-techi nafshekhem*—hear and live.

"I will make an everlasting covenant with you."

*Ve-ekhretah lakhem berit olam*—everlasting covenant.

"Even the sure mercies of David."

*Chasdei David ha-ne'emanim*—David's sure mercies. Acts 13:34 quotes this.

**Witness to Nations (55:4-5):**
"I have given him for a witness to the peoples."

*Hen ed le'ummim netattiv*—witness to peoples.

"A prince and commander to the peoples."

*Nagid u-metzavveh le'ummim*—prince and commander.

"You shall call a nation that you know not."

*Hen-goy lo-teda tiqra*—call unknown nation.

"A nation that knew not you shall run unto you."

*Ve-goy lo-yeda'ukha elekha yarutzu*—nations run to you.

"Because of YHWH your God."

*Lema'an YHWH Elohekha*—for YHWH's sake.

"For the Holy One of Israel, for he has glorified you."

*Ve-li-Qedosh Yisra'el ki fe'erakha*—Holy One glorified you.

**The Key Verses (55:6-7):**
"Seek YHWH while he may be found."

*Dirshu YHWH be-himmatze'o*—seek while findable.

"Call upon him while he is near."

*Qera'uhu bi-heyoto qarov*—call while near.

"Let the wicked forsake his way."

*Ya'azov rasha darko*—wicked forsakes way.

"The man of iniquity his thoughts."

*Ve-ish aven machshevotav*—iniquitous forsakes thoughts.

"Let him return unto YHWH."

*Ve-yashov el-YHWH*—return to YHWH.

"He will have compassion upon him."

*Vi-yerachamekhu*—compassion shown.

"To our God, for he will abundantly pardon."

*Ve-el-Eloheinu ki-yarbeh lisslo'ach*—abundant pardon.

**The Key Verses (55:8-9):**
"My thoughts are not your thoughts."

*Ki lo machshevotai machshevoteikhem*—different thoughts.

"Neither are your ways my ways, says YHWH."

*Ve-lo darkheikhem derakhai ne'um-YHWH*—different ways.

"As the heavens are higher than the earth."

*Ki-gavhu shamayim me-aretz*—heavens higher.

"So are my ways higher than your ways."

*Ken gavhu derakhai mi-darkheikhem*—ways higher.

"My thoughts than your thoughts."

*U-machshevotai mi-machshevoteikhem*—thoughts higher.

**The Key Verses (55:10-11):**
"As the rain comes down and the snow from heaven."

*Ki ka-asher yered ha-geshem ve-ha-sheleg min-ha-shamayim*—rain and snow.

"Returns not there, except it water the earth."

*Ve-shammah lo yashov ki im-hirvah et-ha-aretz*—waters earth first.

"Make it bring forth and bud."

*Ve-holidah ve-hitzmichah*—brings forth, buds.

"Give seed to the sower and bread to the eater."

*Ve-natan zera la-zorea ve-lechem la-okhel*—seed and bread.

**The Key Verse (55:11):**
"So shall my word be that goes forth out of my mouth."

*Ken yihyeh devari asher yetze mi-pi*—word from mouth.

"It shall not return unto me void."

*Lo-yashov elai reqam*—not return empty.

"It shall accomplish that which I please."

*Ki im-asah et-asher chafatzti*—accomplishes pleasure.

"It shall prosper in the thing whereto I sent it."

*Ve-hitzliach asher shelachtiv*—prospers in mission.

**The Key Verses (55:12-13):**
"You shall go out with joy."

*Ki ve-simchah tetze'u*—joyful going out.

"Be led forth with peace."

*U-ve-shalom tuvalun*—peaceful leading.

"The mountains and the hills shall break forth before you into singing."

*He-harim ve-ha-geva'ot yiftzechu lifneikhem rinnah*—mountains sing.

"All the trees of the field shall clap their hands."

*Ve-khol-atzei ha-sadeh yimcha'u-khaf*—trees clap.

"Instead of the thorn shall come up the cypress."

*Tachat ha-na'atzutz ya'aleh verosh*—cypress replaces thorn.

"Instead of the brier shall come up the myrtle."

*Ve-tachat ha-sirpad ya'aleh hadas*—myrtle replaces brier.

"It shall be to YHWH for a name."

*Ve-hayah la-YHWH le-shem*—for YHWH's name.

"For an everlasting sign that shall not be cut off."

*Le-ot olam lo yikkaret*—everlasting sign.

**Archetypal Layer:** Isaiah 55 concludes Second Isaiah (chapters 40-55) with **the free invitation (55:1)**—Revelation 22:17, **"the sure mercies of David" (55:3)**—Acts 13:34, **"Seek YHWH while he may be found" (55:6)**, **"my thoughts are not your thoughts" (55:8-9)**, and **"my word... shall not return unto me void" (55:11)**.

**Ethical Inversion Applied:**
- "Ho, every one that thirsts, come to the waters"—Revelation 22:17
- "He that has no money; come, buy, and eat"—free grace
- "Come, buy wine and milk without money and without price"—costless
- "Wherefore do you spend money for that which is not bread?"—questioning waste
- "Let your soul delight itself in fatness"—soul satisfaction
- "Hear, and your soul shall live"—hearing = life
- "I will make an everlasting covenant with you"—everlasting covenant
- "Even the sure mercies of David"—Acts 13:34
- "I have given him for a witness to the peoples"—witness role
- "A nation that knew not you shall run unto you"—nations coming
- "Seek YHWH while he may be found"—urgency
- "Call upon him while he is near"—nearness
- "Let the wicked forsake his way"—repentance
- "He will abundantly pardon"—abundant pardon
- "My thoughts are not your thoughts"—transcendence
- "As the heavens are higher than the earth"—height comparison
- "So are my ways higher than your ways"—higher ways
- "As the rain comes down... and returns not"—rain/snow analogy
- "So shall my word be that goes forth out of my mouth"—word goes forth
- "It shall not return unto me void"—effective word
- "It shall accomplish that which I please"—word accomplishes
- "You shall go out with joy, and be led forth with peace"—joyful, peaceful exodus
- "The mountains and the hills shall break forth... into singing"—cosmic joy
- "All the trees of the field shall clap their hands"—creation praises
- "Instead of the thorn shall come up the cypress"—curse reversed

**Modern Equivalent:** Isaiah 55 is one of Scripture's great invitation chapters. "Come to the waters" (55:1) echoes in Revelation 22:17. "The sure mercies of David" (55:3) is quoted in Acts 13:34. "My word... shall not return void" (55:11) is foundational for confidence in Scripture's power. This chapter concludes Second Isaiah.

---

## Section Summary: Isaiah 40-55 (Second Isaiah / Book of Comfort)

Chapters 40-55 form Isaiah's central section:

**Structure:**
- **40-48**: Comfort, YHWH vs. idols, Cyrus
- **49-55**: Servant Songs, Zion's restoration

**Major Themes:**
- **"Comfort, comfort my people" (40:1)**
- **YHWH incomparable** (40:18-26; 44:6-8; 45:5-7)
- **Cyrus as YHWH's instrument** (44:28-45:1)
- **Four Servant Songs** (42:1-9; 49:1-7; 50:4-9; 52:13-53:12)
- **Idol satire** (44:9-20; 46:1-7)
- **New Exodus** (43:16-21; 48:20-21)
- **"No weapon formed against you shall prosper" (54:17)**
- **Free invitation** (55:1)
- **Word accomplishes** (55:10-11)

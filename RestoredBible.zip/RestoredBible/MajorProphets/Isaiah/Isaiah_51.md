# Isaiah 51: Awake, Awake, O Arm of YHWH

*From the Hebrew: שִׁמְעוּ אֵלַי רֹדְפֵי צֶדֶק (Shim'u Elai Rodefei Tzedeq) — Hearken to Me, You That Follow After Righteousness*

---

## Look to Abraham (51:1-8)

**51:1** Hearken to me, you that follow after righteousness, you that seek YHWH; look unto the rock whence you were hewn, and to the hole of the pit whence you were digged.

**51:2** Look unto Abraham your father, and unto Sarah that bore you; for when he was but one I called him, and I blessed him, and made him many.

**51:3** For YHWH has comforted Zion; he has comforted all her waste places, and has made her wilderness like Eden, and her desert like the garden of YHWH; joy and gladness shall be found therein, thanksgiving, and the voice of melody.

**51:4** Attend unto me, O my people, and give ear unto me, O my nation; for teaching shall go forth from me, and my justice for a light of the peoples will I establish.

**51:5** My righteousness is near, my salvation is gone forth, and my arms shall judge the peoples; the isles shall wait for me, and on my arm shall they trust.

**51:6** Lift up your eyes to the heavens, and look upon the earth beneath; for the heavens shall vanish away like smoke, and the earth shall wax old like a garment, and they that dwell therein shall die in like manner; but my salvation shall be forever, and my righteousness shall not be abolished.

**51:7** Hearken unto me, you that know righteousness, the people in whose heart is my teaching; fear not the reproach of men, neither be afraid of their revilings.

**51:8** For the moth shall eat them up like a garment, and the worm shall eat them like wool; but my righteousness shall be forever, and my salvation unto all generations.

---

## Awake, O Arm of YHWH (51:9-16)

**51:9** Awake, awake, put on strength, O arm of YHWH; awake, as in the days of old, the generations of ancient times. Art thou not it that did hew Rahab in pieces, that did pierce the dragon?

**51:10** Art thou not it that dried up the sea, the waters of the great deep; that made the depths of the sea a way for the redeemed to pass over?

**51:11** And the ransomed of YHWH shall return, and come with singing unto Zion, and everlasting joy shall be upon their heads; they shall obtain gladness and joy, and sorrow and sighing shall flee away.

**51:12** I, even I, am he that comforts you; who are you, that you are afraid of a man that shall die, and of the son of man that shall be made as grass?

**51:13** And have forgotten YHWH your Maker, that stretched forth the heavens, and laid the foundations of the earth; and fear continually all the day because of the fury of the oppressor, as he makes ready to destroy? And where is the fury of the oppressor?

**51:14** The captive exile shall speedily be loosed; and he shall not go down dying into the pit, neither shall his bread fail.

**51:15** For I am YHWH your God, who stirs up the sea, and the waves thereof roar; YHWH of hosts is his name.

**51:16** And I have put my words in your mouth, and have covered you in the shadow of my hand, that I may plant the heavens, and lay the foundations of the earth, and say unto Zion: "You are my people."

---

## Awake, O Jerusalem (51:17-23)

**51:17** Awake, awake, stand up, O Jerusalem, that has drunk at the hand of YHWH the cup of his fury; you have drunken the beaker, even the cup of staggering, and drained it.

**51:18** There is none to guide her among all the sons whom she has brought forth; neither is there any that takes her by the hand of all the sons that she has brought up.

**51:19** These two things are befallen you; who shall bemoan you? Desolation and destruction, and the famine and the sword; how shall I comfort you?

**51:20** Your sons have fainted, they lie at the head of all the streets, as an antelope in a net; they are full of the fury of YHWH, the rebuke of your God.

**51:21** Therefore hear now this, you afflicted, and drunken, but not with wine:

**51:22** Thus says your Lord YHWH, and your God that pleads the cause of his people: Behold, I have taken out of your hand the cup of staggering, even the beaker of the cup of my fury; you shall no more drink it again;

**51:23** And I will put it into the hand of them that afflict you, that have said to your soul: "Bow down, that we may go over"; and you have laid your back as the ground, and as the street, to them that go over.

---

## Synthesis Notes

**Key Restorations:**

**Look to Origins (51:1-2):**
"Hearken to me, you that follow after righteousness."

*Shim'u elai rodefei tzedeq*—righteousness-pursuers.

"You that seek YHWH."

*Mevaqeshei YHWH*—YHWH-seekers.

"Look unto the rock whence you were hewn."

*Habbitu el-tzur chutzavtem*—rock-source.

"To the hole of the pit whence you were digged."

*Ve-el-maqqevet bor nuqqartem*—pit-quarry.

**The Key Verse (51:2):**
"Look unto Abraham your father."

*Habbitu el-Avraham avikhem*—look to Abraham.

"Unto Sarah that bore you."

*Ve-el-Sarah techollalkhem*—look to Sarah.

"When he was but one I called him."

*Ki-echad qerativ*—called when one.

"I blessed him, and made him many."

*Va-avarakhehu ve-arbehu*—blessed and multiplied.

**Zion Comforted (51:3):**
"YHWH has comforted Zion."

*Ki-nicham YHWH Tziyyon*—Zion comforted.

"Has comforted all her waste places."

*Nicham kol-chorvotekha*—waste places comforted.

"Made her wilderness like Eden."

*Va-yasem midbarah ke-Eden*—wilderness = Eden.

"Her desert like the garden of YHWH."

*Ve-arvatah ke-gan-YHWH*—desert = YHWH's garden.

"Joy and gladness shall be found therein."

*Sason ve-simchah yimmatze vah*—joy found.

"Thanksgiving, and the voice of melody."

*Todah ve-qol zimrah*—thanksgiving and song.

**The Key Verses (51:4-6):**
"Teaching shall go forth from me."

*Ki torah me-itti tetze*—Torah from YHWH.

"My justice for a light of the peoples."

*U-mishpati le-or ammim*—justice as light.

"My righteousness is near, my salvation is gone forth."

*Qarov tzidqi yatza yish'i*—near righteousness, forth salvation.

"My arms shall judge the peoples."

*U-zero'ai ammim yishpotu*—arms judge.

"The isles shall wait for me."

*Elai iyyim yeqavvu*—islands wait.

"On my arm shall they trust."

*Ve-el-zero'i yeyachellun*—arm-trust.

**The Key Verse (51:6):**
"Lift up your eyes to the heavens."

*Se'u la-shamayim eineikhem*—look up.

"The heavens shall vanish away like smoke."

*Ki-shamayim ke-ashan nimlakhu*—heavens vanish like smoke.

"The earth shall wax old like a garment."

*Ve-ha-aretz ka-beged tivleh*—earth ages like garment. Hebrews 1:10-12 quotes this.

"They that dwell therein shall die in like manner."

*Ve-yoshevekha kemo-khen yemutun*—inhabitants die.

"My salvation shall be forever."

*Vi-yeshu'ati le-olam tihyeh*—salvation forever.

"My righteousness shall not be abolished."

*Ve-tzidqati lo techat*—righteousness unabolished.

**Fear Not (51:7-8):**
"Hearken unto me, you that know righteousness."

*Shim'u elai yode'ei tzedeq*—righteousness-knowers.

"The people in whose heart is my teaching."

*Am torati ve-libbam*—Torah-hearted.

"Fear not the reproach of men."

*Al-tir'u cherpat enosh*—don't fear reproach.

"Neither be afraid of their revilings."

*U-mi-giddufotam al-techatu*—don't fear revilings.

"The moth shall eat them up like a garment."

*Ki kha-beged yokhelem ash*—moth eats them.

"The worm shall eat them like wool."

*Ve-kha-tzemer yokhelem sas*—worm eats them.

"My righteousness shall be forever."

*Ve-tzidqati le-olam tihyeh*—righteousness forever.

"My salvation unto all generations."

*Vi-yeshu'ati le-dor dorim*—salvation for generations.

**The Key Verses (51:9-11):**
"Awake, awake, put on strength, O arm of YHWH."

*Uri uri livshi-oz zero'a YHWH*—arm awakens.

"Awake, as in the days of old."

*Uri ki-yemei qedem*—ancient days.

"Art thou not it that did hew Rahab in pieces?"

*Ha-lo at hi ha-machatzevet Rahav*—Rahab hewn (primordial chaos).

"That did pierce the dragon?"

*Mecholelet tannin*—dragon pierced.

"Art thou not it that dried up the sea?"

*Ha-lo at hi ha-macharevert yam*—sea dried.

"The waters of the great deep."

*Mei tehom rabbah*—great deep.

"That made the depths of the sea a way for the redeemed to pass over?"

*Ha-samah ma'amaqqei-yam derekh la'avor ge'ulim*—Exodus way.

**The Key Verse (51:11):**
"The ransomed of YHWH shall return."

*U-feduyei YHWH yeshuvun*—ransomed return.

"Come with singing unto Zion."

*U-va'u Tziyyon be-rinnah*—singing to Zion.

"Everlasting joy shall be upon their heads."

*Ve-simchat olam al-rosham*—eternal joy on heads.

"They shall obtain gladness and joy."

*Sason ve-simchah yassiggu*—obtain joy.

"Sorrow and sighing shall flee away."

*Ve-nasu yagon va-anachah*—sorrow flees.

(This verse repeats 35:10.)

**Comfort (51:12-16):**
"I, even I, am he that comforts you."

*Anokhi anokhi hu menachamkhem*—double I, comforter.

"Who are you, that you are afraid of a man that shall die?"

*Mi-at va-tir'i me-enosh yamut*—why fear mortal?

"Of the son of man that shall be made as grass?"

*U-mi-ben-adam chatzir yinnathen*—grass-man.

"Have forgotten YHWH your Maker."

*Va-tishkach YHWH osekha*—Maker forgotten.

"That stretched forth the heavens."

*Noteh shamayim*—stretched heavens.

"Laid the foundations of the earth."

*Ve-yosed aretz*—founded earth.

"I am YHWH your God, who stirs up the sea."

*Va-ani YHWH Elohekha roga ha-yam*—sea-stirrer.

"The waves thereof roar."

*Va-yehemu gallav*—roaring waves.

"YHWH of hosts is his name."

*YHWH Tzeva'ot shemo*—name declared.

"I have put my words in your mouth."

*Va-asim devarai be-fikha*—words in mouth.

"Covered you in the shadow of my hand."

*U-ve-tzel yadi kissitikha*—hand-shadow covering.

"That I may plant the heavens, and lay the foundations of the earth."

*Linta shamayim ve-leyased aretz*—plant/found creation.

"'You are my people.'"

*Ammi-attah*—my people.

**Awake, Jerusalem (51:17-23):**
"Awake, awake, stand up, O Jerusalem."

*Hit'oreri hit'oreri qumi Yerushalayim*—Jerusalem awakes.

"That has drunk at the hand of YHWH the cup of his fury."

*Asher shatit mi-yad YHWH et-kos chamato*—fury cup drunk.

"The beaker, even the cup of staggering."

*Et-qubbe'at kos ha-tar'elah*—staggering cup.

"Drained it."

*Shattit matzit*—drained.

"There is none to guide her."

*Ein-menahhel lah*—no guide.

"These two things are befallen you."

*Shetayim hennah qorotayikh*—two calamities.

"Desolation and destruction, and the famine and the sword."

*Ha-shod ve-ha-shever ve-ha-ra'av ve-ha-cherev*—four disasters (pairs).

**The Key Verses (51:22-23):**
"Behold, I have taken out of your hand the cup of staggering."

*Hinneh laqachti mi-yadek et-kos ha-tar'elah*—cup taken.

"The beaker of the cup of my fury."

*Et-qubbe'at kos chamati*—fury cup.

"You shall no more drink it again."

*Lo-tosifi lishtotah od*—never drink again.

"I will put it into the hand of them that afflict you."

*Ve-samtikha be-yad-mogayikh*—cup to afflicters.

"That have said to your soul: 'Bow down, that we may go over.'"

*Asher-amru le-nafshekh shachi ve-na'avorah*—forced bowing.

"You have laid your back as the ground."

*Va-tasimi kha-aretz gevek*—back as ground.

"As the street, to them that go over."

*Ve-kha-chutz la-overim*—street for walkers.

**Archetypal Layer:** Isaiah 51 calls Israel to look to Abraham (51:1-2), declares heavens/earth aging like garment (51:6)—Hebrews 1:10-12, repeats the ransomed-return song (51:11=35:10), and shows the fury cup transferred (51:22-23).

**Ethical Inversion Applied:**
- "You that follow after righteousness, you that seek YHWH"—addressed
- "Look unto the rock whence you were hewn"—rock-origin
- "Look unto Abraham your father"—Abraham
- "When he was but one I called him"—one to many
- "YHWH has comforted Zion"—comfort
- "Made her wilderness like Eden"—Eden restoration
- "Teaching shall go forth from me"—Torah from YHWH
- "My righteousness is near, my salvation is gone forth"—near salvation
- "The heavens shall vanish away like smoke"—Hebrews 1:10-12
- "The earth shall wax old like a garment"—aging creation
- "My salvation shall be forever"—eternal salvation
- "Fear not the reproach of men"—no fear
- "Awake, awake, put on strength, O arm of YHWH"—arm awakens
- "Art thou not it that did hew Rahab in pieces?"—Rahab
- "That made the depths of the sea a way for the redeemed?"—Exodus
- "The ransomed of YHWH shall return"—ransomed return
- "Sorrow and sighing shall flee away"—sorrow ends
- "I, even I, am he that comforts you"—comforter
- "Who are you, that you are afraid of a man that shall die?"—mortal fear rebuked
- "Awake, awake, stand up, O Jerusalem"—Jerusalem awakens
- "I have taken out of your hand the cup of staggering"—cup removed
- "I will put it into the hand of them that afflict you"—cup transferred

**Modern Equivalent:** Isaiah 51:6's "the heavens shall vanish away like smoke, and the earth shall wax old like a garment" is quoted in Hebrews 1:10-12 for Christ's eternality over creation. "Sorrow and sighing shall flee away" (51:11=35:10) anticipates Revelation 21:4. The fury cup transferred (51:22-23) shows judgment shifted.

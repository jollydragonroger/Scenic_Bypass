# Isaiah 58: True Fasting

*From the Hebrew: קְרָא בְגָרוֹן אַל־תַּחְשֹׂךְ (Qera Ve-Garon Al-Tachsokh) — Cry Aloud, Spare Not*

---

## False Fasting Condemned (58:1-5)

**58:1** Cry aloud, spare not, lift up your voice like a horn, and declare unto my people their transgression, and to the house of Jacob their sins.

**58:2** Yet they seek me daily, and delight to know my ways; as a nation that did righteousness, and forsook not the ordinance of their God, they ask of me righteous ordinances, they delight to draw near unto God.

**58:3** "Wherefore have we fasted, and you see not? Wherefore have we afflicted our soul, and you take no knowledge?" Behold, in the day of your fast you pursue your business, and exact all your labours.

**58:4** Behold, you fast for strife and contention, and to smite with the fist of wickedness; you fast not this day so as to make your voice to be heard on high.

**58:5** Is such the fast that I have chosen? The day for a man to afflict his soul? Is it to bow down his head as a bulrush, and to spread sackcloth and ashes under him? Will you call this a fast, and an acceptable day to YHWH?

---

## True Fasting (58:6-12)

**58:6** Is not this the fast that I have chosen? To loose the fetters of wickedness, to undo the bands of the yoke, and to let the oppressed go free, and that you break every yoke?

**58:7** Is it not to deal your bread to the hungry, and that you bring the poor that are cast out to your house? When you see the naked, that you cover him, and that you hide not yourself from your own flesh?

**58:8** Then shall your light break forth as the morning, and your healing shall spring forth speedily; and your righteousness shall go before you, the glory of YHWH shall be your rearguard.

**58:9** Then shall you call, and YHWH will answer; you shall cry, and he will say: "Here I am." If you take away from the midst of you the yoke, the putting forth of the finger, and speaking wickedness;

**58:10** And if you draw out your soul to the hungry, and satisfy the afflicted soul; then shall your light rise in darkness, and your gloom be as the noonday;

**58:11** And YHWH will guide you continually, and satisfy your soul in dry places, and make strong your bones; and you shall be like a watered garden, and like a spring of water, whose waters fail not.

**58:12** And they that shall be of you shall build the old waste places, you shall raise up the foundations of many generations; and you shall be called the repairer of the breach, the restorer of paths to dwell in.

---

## Sabbath Delight (58:13-14)

**58:13** If you turn away your foot because of the sabbath, from pursuing your business on my holy day; and call the sabbath a delight, and the holy of YHWH honourable; and shall honour it, not doing your own ways, nor pursuing your own business, nor speaking your own words:

**58:14** Then shall you delight yourself in YHWH, and I will make you to ride upon the high places of the earth, and I will feed you with the heritage of Jacob your father; for the mouth of YHWH has spoken it.

---

## Synthesis Notes

**Key Restorations:**

**Prophet's Commission (58:1):**
"Cry aloud, spare not."

*Qera ve-garon al-tachsokh*—cry with full throat.

"Lift up your voice like a horn."

*Ka-shofar harem qolekha*—shofar-voice.

"Declare unto my people their transgression."

*Ve-hagged le-ammi pish'am*—declare transgression.

"To the house of Jacob their sins."

*U-le-veit Ya'aqov chattotam*—declare sins.

**Superficial Religion (58:2-5):**
"They seek me daily, and delight to know my ways."

*Ve-oti yom yom yidroshu ve-da'at derakhay yechpatzun*—daily seeking.

"As a nation that did righteousness."

*Ke-goy asher-tzedaqah asah*—as if righteous.

"Forsook not the ordinance of their God."

*U-mishpat Elohav lo azav*—as if law-keeping.

"They ask of me righteous ordinances."

*Yish'aluni mishpetei-tzedeq*—asking for ordinances.

"They delight to draw near unto God."

*Qirvat Elohim yechpatzun*—desiring nearness.

"'Wherefore have we fasted, and you see not?'"

*Lammah tzamnu ve-lo ra'ita*—fasting complaint.

"'Wherefore have we afflicted our soul, and you take no knowledge?'"

*Inninu nafshenu ve-lo teda*—affliction complaint.

"In the day of your fast you pursue your business."

*Hen be-yom tzomkhem timtze'u-chefetz*—business on fast day.

"Exact all your labours."

*Ve-khol-atzbeikem tingsou*—exacting labor.

"You fast for strife and contention."

*Hen le-riv u-matztzah tatzumu*—strife fasting.

"To smite with the fist of wickedness."

*U-le-hakkot be-egrof resha*—wicked fist.

"Is such the fast that I have chosen?"

*Ha-kha-zeh yihyeh tzom evcharehu*—is this chosen fast?

"The day for a man to afflict his soul?"

*Yom annot adam nafsho*—afflicting day.

"Is it to bow down his head as a bulrush?"

*Ha-lakhof ke-agmon rosho*—bulrush-bowing.

"Spread sackcloth and ashes under him?"

*Ve-saq va-efer yatzia*—sackcloth and ashes.

"Will you call this a fast?"

*Ha-la-zeh tiqra-tzom*—call this fasting?

**The Key Verses (58:6-7):**
"Is not this the fast that I have chosen?"

*Halo zeh tzom evcharehu*—chosen fast.

"To loose the fetters of wickedness."

*Patte'ach chartzzubot resha*—loose wickedness fetters.

"To undo the bands of the yoke."

*Hatter agguddot motah*—undo yoke bands.

"To let the oppressed go free."

*Ve-shallech retzutzim chofshim*—free oppressed.

"That you break every yoke."

*Ve-khol-motah tenattequu*—break every yoke.

"Is it not to deal your bread to the hungry?"

*Halo faros la-ra'ev lachmekha*—share bread with hungry.

"Bring the poor that are cast out to your house."

*Va-aniyyim merudim tavi vayit*—bring homeless poor.

"When you see the naked, that you cover him."

*Ki-tir'eh arom ve-khissito*—cover naked.

"That you hide not yourself from your own flesh."

*U-mi-besarkha lo tit'allem*—don't hide from kin.

**The Key Verses (58:8-9):**
"Then shall your light break forth as the morning."

*Az yibbaqa ka-shachar orekha*—light breaks like dawn.

"Your healing shall spring forth speedily."

*Va-arukhatekha mehera titzmach*—quick healing.

"Your righteousness shall go before you."

*Ve-halakh lefanekha tzidqekha*—righteousness leads.

"The glory of YHWH shall be your rearguard."

*Kevod YHWH ya'asfekha*—YHWH's glory guards rear.

"Then shall you call, and YHWH will answer."

*Az tiqra va-YHWH ya'aneh*—answered call.

"You shall cry, and he will say: 'Here I am.'"

*Teshavve'a ve-yomar hinnenni*—"Here I am."

"If you take away from the midst of you the yoke."

*Im-tasir mi-tokhekha motah*—remove yoke.

"The putting forth of the finger."

*Shelach etzba*—pointing finger.

"Speaking wickedness."

*Ve-dabber-aven*—wicked speech.

**The Key Verses (58:10-12):**
"If you draw out your soul to the hungry."

*Ve-taffeq la-ra'ev nafshekha*—give soul to hungry.

"Satisfy the afflicted soul."

*Ve-nefesh na'anah tasbi'a*—satisfy afflicted.

"Then shall your light rise in darkness."

*Ve-zarach ba-choshekh orekha*—light in darkness.

"Your gloom be as the noonday."

*Va-afelatekha ka-tzohorayim*—gloom to noon.

**The Key Verse (58:11):**
"YHWH will guide you continually."

*Ve-nachakha YHWH tamid*—continual guidance.

"Satisfy your soul in dry places."

*Ve-hisbi'a be-tzachtzachot nafshekha*—satisfied in drought.

"Make strong your bones."

*Ve-atzmotekha yachalitz*—bones strengthened.

"You shall be like a watered garden."

*Ve-hayita ke-gan raveh*—watered garden.

"Like a spring of water, whose waters fail not."

*U-khe-motza mayim asher lo-yekhazzevu meimav*—unfailing spring.

**The Key Verse (58:12):**
"They that shall be of you shall build the old waste places."

*U-vanu mimmekha chorvot olam*—build ancient ruins.

"You shall raise up the foundations of many generations."

*Mosdei dor-va-dor teqomem*—raise generation foundations.

"You shall be called the repairer of the breach."

*Ve-qora lekha goder peretz*—breach repairer.

"The restorer of paths to dwell in."

*Meshobev netivot la-shevet*—path restorer.

**Sabbath (58:13-14):**
"If you turn away your foot because of the sabbath."

*Im-tashiv mi-shabbat raglekha*—foot turned from sabbath.

"From pursuing your business on my holy day."

*Asot chafatzekha be-yom qodshi*—business on holy day.

"Call the sabbath a delight."

*Ve-qarata la-shabbat oneg*—sabbath delight.

"The holy of YHWH honourable."

*Li-qedosh YHWH mekhubbad*—YHWH's holy honored.

"Honour it, not doing your own ways."

*Ve-khiabbadto me-asot derakhekha*—not own ways.

"Nor pursuing your own business."

*Mi-metzo cheftzekha*—not own business.

"Nor speaking your own words."

*Ve-dabber davar*—not own words.

"Then shall you delight yourself in YHWH."

*Az tit'annag al-YHWH*—delight in YHWH.

"I will make you to ride upon the high places of the earth."

*Ve-hirkavttikha al-bamotei-aretz*—ride high places.

"I will feed you with the heritage of Jacob."

*Ve-ha'akaltikha nachalat Ya'aqov avikha*—Jacob's heritage.

**Archetypal Layer:** Isaiah 58 contrasts **false fasting (58:1-5)** with **true fasting (58:6-12)**—social justice, not ritual. Key: **"Is not this the fast that I have chosen? To loose the fetters of wickedness" (58:6)**.

**Ethical Inversion Applied:**
- "Cry aloud, spare not, lift up your voice like a horn"—prophetic call
- "Declare unto my people their transgression"—sin declaration
- "They seek me daily, and delight to know my ways"—superficial seeking
- "'Wherefore have we fasted, and you see not?'"—fasting complaint
- "In the day of your fast you pursue your business"—business on fast day
- "You fast for strife and contention"—strife fasting
- "Is such the fast that I have chosen?"—rhetorical question
- "Is not this the fast that I have chosen?"—true fast defined
- "To loose the fetters of wickedness"—loose wickedness
- "To let the oppressed go free"—free oppressed
- "Is it not to deal your bread to the hungry?"—share bread
- "Bring the poor that are cast out to your house"—house the homeless
- "When you see the naked, that you cover him"—clothe naked
- "That you hide not yourself from your own flesh"—don't ignore kin
- "Then shall your light break forth as the morning"—light breaks
- "Your healing shall spring forth speedily"—quick healing
- "Then shall you call, and YHWH will answer"—answered prayer
- "'Here I am'"—divine response
- "Then shall your light rise in darkness"—light in darkness
- "YHWH will guide you continually"—continual guidance
- "You shall be like a watered garden"—garden imagery
- "Like a spring of water, whose waters fail not"—unfailing spring
- "You shall be called the repairer of the breach"—breach repairer
- "The restorer of paths to dwell in"—path restorer
- "Call the sabbath a delight"—sabbath delight
- "Then shall you delight yourself in YHWH"—delight in YHWH

**Modern Equivalent:** Isaiah 58 redefines fasting as social justice—loosing bonds, feeding hungry, housing homeless, clothing naked. This prophetic priority of justice over ritual appears throughout the prophets (Amos 5:21-24; Micah 6:6-8). Jesus echoes this in Matthew 25:35-40.

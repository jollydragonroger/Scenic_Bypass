# Isaiah 50: The Obedient Servant

*From the Hebrew: כֹּה אָמַר יְהוָה אֵי זֶה סֵפֶר כְּרִיתוּת (Koh Amar YHWH Ei Zeh Sefer Keritut) — Thus Says YHWH: Where Is the Bill of Divorce?*

---

## Israel's Divorce? (50:1-3)

**50:1** Thus says YHWH: Where is the bill of your mother's divorcement, wherewith I have put her away? Or which of my creditors is it to whom I have sold you? Behold, for your iniquities were you sold, and for your transgressions was your mother put away.

**50:2** Wherefore, when I came, was there no man? When I called, was there none to answer? Is my hand shortened at all, that it cannot redeem? Or have I no power to deliver? Behold, at my rebuke I dry up the sea, I make the rivers a wilderness; their fish become foul, because there is no water, and die for thirst.

**50:3** I clothe the heavens with blackness, and I make sackcloth their covering.

---

## The Third Servant Song (50:4-9)

**50:4** The Lord YHWH has given me the tongue of them that are taught, that I should know how to sustain with words him that is weary; he wakens morning by morning, he wakens my ear to hear as they that are taught.

**50:5** The Lord YHWH has opened my ear, and I was not rebellious, neither turned away backward.

**50:6** I gave my back to the smiters, and my cheeks to them that plucked off the hair; I hid not my face from shame and spitting.

**50:7** For the Lord YHWH will help me; therefore have I not been confounded; therefore have I set my face like a flint, and I know that I shall not be ashamed.

**50:8** He is near that justifies me; who will contend with me? Let us stand up together; who is my adversary? Let him come near to me.

**50:9** Behold, the Lord YHWH will help me; who is he that shall condemn me? Behold, they all shall wax old as a garment, the moth shall eat them up.

---

## Trust in YHWH (50:10-11)

**50:10** Who is among you that fears YHWH, that obeys the voice of his servant? Though he walks in darkness, and has no light, let him trust in the name of YHWH, and stay upon his God.

**50:11** Behold, all you that kindle a fire, that gird yourselves with firebrands, walk in the flame of your fire, and among the brands that you have kindled. This shall you have of my hand; you shall lie down in sorrow.

---

## Synthesis Notes

**Key Restorations:**

**No Divorce (50:1-3):**
"Where is the bill of your mother's divorcement?"

*Ei zeh sefer keritut immekhem*—where's divorce certificate?

"Wherewith I have put her away?"

*Asher shillachtikha*—did I divorce?

"Which of my creditors is it to whom I have sold you?"

*O mi mi-noshay asher makharti etkhem lo*—did I sell you to creditors?

"For your iniquities were you sold."

*Hen ba-avonotekhem nimkartem*—sold for iniquities.

"For your transgressions was your mother put away."

*U-ve-fish'ekhem shullechah immekhem*—mother sent away for transgressions.

**YHWH's Power (50:2-3):**
"When I came, was there no man?"

*Maddua bati ve-ein ish*—no one when I came.

"When I called, was there none to answer?"

*Qarati ve-ein oneh*—no answer.

"Is my hand shortened at all, that it cannot redeem?"

*Ha-qatzer qatzrah yadi mi-pedut*—hand too short?

"Have I no power to deliver?"

*Ve-im-ein bi kho'ach le-hatztzil*—no power?

"At my rebuke I dry up the sea."

*Hen be-ga'arati achariv yam*—sea dried.

"I make the rivers a wilderness."

*Asim neharot midbar*—rivers to wilderness.

"I clothe the heavens with blackness."

*Albish shamayim qadrut*—blackness clothing.

"I make sackcloth their covering."

*Ve-saq asim kesuatam*—sackcloth covering.

**The Key Verses (50:4-6) — Third Servant Song:**
"The Lord YHWH has given me the tongue of them that are taught."

*Adonai YHWH natan li leshon limmudim*—taught tongue.

"That I should know how to sustain with words him that is weary."

*Lada'at la'ut et-ya'ef davar*—sustaining the weary.

"He wakens morning by morning."

*Ya'ir ba-boqer ba-boqer*—morning awakening.

"He wakens my ear to hear as they that are taught."

*Ya'ir li ozen lishmo'a ka-limmudim*—ear awakened.

**The Key Verse (50:5):**
"The Lord YHWH has opened my ear."

*Adonai YHWH patach-li ozen*—ear opened.

"I was not rebellious."

*Ve-anokhi lo mariti*—not rebellious.

"Neither turned away backward."

*Achor lo nesogoti*—didn't turn back.

**The Key Verse (50:6):**
"I gave my back to the smiters."

*Gevi natatti le-makkim*—back to strikers.

"My cheeks to them that plucked off the hair."

*U-lechayai le-moretim*—cheeks to hair-pluckers.

"I hid not my face from shame and spitting."

*Panai lo histarti mi-kelimmot va-roq*—face not hidden from shame/spitting.

**The Key Verse (50:7):**
"The Lord YHWH will help me."

*Va-Adonai YHWH ya'azor-li*—YHWH helps.

"Therefore have I not been confounded."

*Al-ken lo nikhllamti*—not confounded.

"Therefore have I set my face like a flint."

*Al-ken samti panai ka-challamish*—flint face.

"I know that I shall not be ashamed."

*Va-eda ki-lo evosh*—won't be ashamed.

**The Key Verses (50:8-9):**
"He is near that justifies me."

*Qarov matzdiqi*—justifier near.

"Who will contend with me?"

*Mi-yariv itti*—who contends?

"Let us stand up together."

*Na'amdah yachad*—stand together.

"Who is my adversary?"

*Mi-ba'al mishpati*—who is adversary?

"Let him come near to me."

*Yiggash elai*—approach.

"Behold, the Lord YHWH will help me."

*Hen Adonai YHWH ya'azor-li*—YHWH helps.

"Who is he that shall condemn me?"

*Mi-hu yarshi'eni*—who condemns? Romans 8:33-34 echoes this.

"They all shall wax old as a garment."

*Hen-kullam ka-beged yivlu*—enemies age like garment.

"The moth shall eat them up."

*Ash yokhelem*—moth eats.

**Trust in Darkness (50:10-11):**
"Who is among you that fears YHWH?"

*Mi vakhem yere YHWH*—YHWH-fearers.

"That obeys the voice of his servant?"

*Shome'a be-qol avdo*—obeys Servant's voice.

"Though he walks in darkness, and has no light."

*Asher halakh chashakhim ve-ein nogah lo*—walking in darkness.

**The Key Verse (50:10):**
"Let him trust in the name of YHWH."

*Yivtach be-shem YHWH*—trust YHWH's name.

"Stay upon his God."

*Ve-yisha'en be-Elohav*—lean on God.

**Self-Made Fire (50:11):**
"All you that kindle a fire."

*Hen kullekem qodechei esh*—fire-kindlers.

"That gird yourselves with firebrands."

*Me'azzerei ziqot*—firebrand-girders.

"Walk in the flame of your fire."

*Lekhu be-ur eshkhem*—walk in your fire.

"Among the brands that you have kindled."

*U-ve-ziqot bi'artem*—kindled brands.

"This shall you have of my hand."

*Mi-yadi hayetah-zot lakhem*—from my hand.

"You shall lie down in sorrow."

*Le-ma'atzevah tishkavun*—lie in sorrow.

**Archetypal Layer:** Isaiah 50 contains **the Third Servant Song (50:4-9)**—the Servant's obedience, suffering, and confidence in vindication. "Who is he that shall condemn me?" (50:9) underlies Romans 8:33-34.

**Ethical Inversion Applied:**
- "Where is the bill of your mother's divorcement?"—no divorce
- "For your iniquities were you sold"—sold for sin
- "When I came, was there no man?"—no response
- "Is my hand shortened at all, that it cannot redeem?"—hand not short
- "At my rebuke I dry up the sea"—power demonstrated
- "The Lord YHWH has given me the tongue of them that are taught"—taught tongue
- "That I should know how to sustain with words him that is weary"—sustaining weary
- "He wakens morning by morning"—daily awakening
- "The Lord YHWH has opened my ear"—ear opened
- "I was not rebellious, neither turned away backward"—obedient
- "I gave my back to the smiters"—suffering accepted
- "My cheeks to them that plucked off the hair"—beard plucked
- "I hid not my face from shame and spitting"—shame/spitting
- "The Lord YHWH will help me"—YHWH helps
- "I set my face like a flint"—flint-faced
- "He is near that justifies me"—justifier near
- "Who will contend with me?"—no contender
- "Who is he that shall condemn me?"—Romans 8:33-34
- "They all shall wax old as a garment"—enemies age
- "Who is among you that fears YHWH?"—YHWH-fearers
- "Though he walks in darkness, and has no light"—dark walking
- "Let him trust in the name of YHWH"—trust in darkness
- "All you that kindle a fire... you shall lie down in sorrow"—self-made fire fails

**Modern Equivalent:** Isaiah 50:6's suffering ("I gave my back to the smiters... shame and spitting") describes Christ's passion. "Who is he that shall condemn me?" (50:9) underlies Paul's triumphant declaration in Romans 8:33-34. Walking in darkness while trusting YHWH (50:10) is foundational for faith in trials.

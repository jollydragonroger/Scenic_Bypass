# Isaiah 31: Woe to Those Who Trust in Egypt

*From the Hebrew: הוֹי הַיֹּרְדִים מִצְרַיִם (Hoy Ha-Yordim Mitzrayim) — Woe to Those Who Go Down to Egypt*

---

## Egypt's Horses vs. YHWH (31:1-3)

**31:1** Woe to them that go down to Egypt for help,
and rely on horses,
and trust in chariots, because they are many,
and in horsemen, because they are very strong;
but they look not unto the Holy One of Israel,
neither seek YHWH!

**31:2** Yet he also is wise, and brings evil,
and does not call back his words;
but will arise against the house of the evil-doers,
and against the help of them that work iniquity.

**31:3** Now the Egyptians are men, and not God,
and their horses flesh, and not spirit;
and when YHWH shall stretch out his hand,
both he that helps shall stumble, and he that is helped shall fall,
and they all shall be consumed together.

---

## YHWH Defends Jerusalem (31:4-9)

**31:4** For thus says YHWH unto me:
Like as the lion, or the young lion, growling over his prey,
though a multitude of shepherds be called forth against him,
will not be dismayed at their voice,
nor abase himself for the noise of them;
so will YHWH of hosts come down to fight upon mount Zion, and upon the hill thereof.

**31:5** As birds hovering, so will YHWH of hosts protect Jerusalem;
he will protect and deliver it, he will pass over and preserve it.

**31:6** Turn unto him from whom you have deeply revolted, O children of Israel.

**31:7** For in that day they shall cast away every man his idols of silver, and his idols of gold, which your own hands have made unto you for a sin.

**31:8** And Assyria shall fall by the sword, not of man,
and the sword, not of men, shall devour him;
and he shall flee from the sword,
and his young men shall become tributary.

**31:9** And his rock shall pass away by reason of terror,
and his princes shall be dismayed at the ensign,
says YHWH, whose fire is in Zion, and his furnace in Jerusalem.

---

## Synthesis Notes

**Key Restorations:**

**Egypt Alliance Condemned (31:1-3):**
"Woe to them that go down to Egypt for help."

*Hoy ha-yordim Mitzrayim le-ezrah*—Egypt-goers.

"Rely on horses."

*Al-susim yisha'enu*—horse-reliance.

"Trust in chariots, because they are many."

*Va-yivtechu al-rekhev ki rav*—chariot trust.

"In horsemen, because they are very strong."

*Ve-al parashim ki-atzmu me'od*—horsemen trust.

"They look not unto the Holy One of Israel."

*Ve-lo sha'u al-Qedosh Yisra'el*—ignored Holy One.

"Neither seek YHWH!"

*Ve-et-YHWH lo darashu*—didn't seek YHWH.

**YHWH's Wisdom (31:2):**
"Yet he also is wise."

*Ve-gam-hu chakham*—YHWH is wise too.

"Brings evil."

*Va-yave ra*—brings calamity.

"Does not call back his words."

*Ve-et-devarav lo hesir*—words stand.

"Will arise against the house of the evil-doers."

*Ve-qam al-beit mere'im*—against evildoers.

"Against the help of them that work iniquity."

*Ve-al ezrat po'alei aven*—against helpers of iniquity.

**The Key Verse (31:3):**
"The Egyptians are men, and not God."

*U-Mitzrayim adam ve-lo-El*—Egypt = man, not God.

"Their horses flesh, and not spirit."

*Ve-suseihem basar ve-lo-ruach*—horses = flesh, not spirit.

"When YHWH shall stretch out his hand."

*Ve-YHWH yatteh yado*—YHWH's hand.

"Both he that helps shall stumble, and he that is helped shall fall."

*Ve-khashal ozer ve-nafal azur*—both fall.

"They all shall be consumed together."

*Ve-yachdav kullam yikhlayun*—consumed together.

**Lion Imagery (31:4):**
"Like as the lion, or the young lion, growling over his prey."

*Ka-asher yehgeh ha-aryeh ve-ha-kefir al-tarfo*—lion over prey.

"Though a multitude of shepherds be called forth against him."

*Asher yiqqare alav melo ro'im*—shepherds called.

"Will not be dismayed at their voice."

*Mi-qolam lo yechat*—undismayed.

"Nor abase himself for the noise of them."

*U-me-hamonam lo ya'aneh*—not abased.

"So will YHWH of hosts come down to fight upon mount Zion."

*Ken yered YHWH Tzeva'ot litzbo al-har Tziyyon*—YHWH fights for Zion.

**The Key Verse (31:5):**
"As birds hovering, so will YHWH of hosts protect Jerusalem."

*Ke-tzipporim afot ken yagen YHWH Tzeva'ot al-Yerushalayim*—hovering protection.

"He will protect and deliver it."

*Ganen ve-hitztzil*—protect and deliver.

"He will pass over and preserve it."

*Paso'ach ve-himlit*—pass over and preserve.

**Translation Note:**
"Pass over" (*paso'ach*) uses the same root as Passover (*Pesach*). YHWH will "passover" Jerusalem as he did the Israelite houses in Egypt.

**Repentance Call (31:6-7):**
"Turn unto him from whom you have deeply revolted."

*Shuvu la-asher he'eqimtem serah benei Yisra'el*—return to him.

"They shall cast away every man his idols of silver."

*Ki ba-yom ha-hu yim'asun ish elilei khaspo*—idols cast away.

"His idols of gold."

*Ve-elilei zehavo*—gold idols.

"Which your own hands have made unto you for a sin."

*Asher asu lakhem yedeikhem chet*—hand-made sin.

**Assyria Falls (31:8-9):**
"Assyria shall fall by the sword, not of man."

*Ve-nafal Ashshur be-cherev lo-ish*—non-human sword.

"The sword, not of men, shall devour him."

*Ve-cherev lo-adam tokhelenu*—not human sword.

"He shall flee from the sword."

*Ve-nas lo mippenei-cherev*—fleeing.

"His young men shall become tributary."

*U-bachurav la-mas yihyu*—young men enslaved.

"His rock shall pass away by reason of terror."

*Ve-sal'o mi-magor ya'avor*—rock passes (king/refuge).

"His princes shall be dismayed at the ensign."

*Ve-chatttu mi-nes sarav*—princes dismayed.

**The Key Verse (31:9):**
"Says YHWH, whose fire is in Zion, and his furnace in Jerusalem."

*Ne'um-YHWH asher-ur lo be-Tziyyon ve-tannur lo bi-Yerushalayim*—YHWH's fire in Zion.

**Archetypal Layer:** Isaiah 31 contrasts **Egyptian horses (flesh)** with **YHWH (spirit)** (31:3), depicts YHWH as **protective lion and hovering bird** (31:4-5), and prophesies **Assyria's supernatural defeat** (31:8).

**Ethical Inversion Applied:**
- "Woe to them that go down to Egypt for help"—Egypt alliance
- "Rely on horses... trust in chariots"—military trust
- "They look not unto the Holy One of Israel"—ignored YHWH
- "Yet he also is wise"—YHWH wise too
- "Does not call back his words"—words stand
- "The Egyptians are men, and not God"—man vs. God
- "Their horses flesh, and not spirit"—flesh vs. spirit
- "Both he that helps shall stumble, and he that is helped shall fall"—mutual fall
- "Like as the lion... growling over his prey"—lion YHWH
- "Will not be dismayed at their voice"—undismayed
- "YHWH of hosts come down to fight upon mount Zion"—YHWH fights
- "As birds hovering, so will YHWH of hosts protect Jerusalem"—bird protection
- "He will pass over and preserve it"—Passover echo
- "Turn unto him from whom you have deeply revolted"—repentance call
- "They shall cast away every man his idols"—idol rejection
- "Assyria shall fall by the sword, not of man"—supernatural defeat
- "YHWH, whose fire is in Zion"—fire in Zion

**Modern Equivalent:** Isaiah 31:3's "Egyptians are men, and not God... horses flesh, and not spirit" is foundational for the flesh/spirit contrast. The "pass over" (31:5) echoes Passover. Assyria's non-human defeat (31:8) was fulfilled in 2 Kings 19:35 (185,000 slain by angel).

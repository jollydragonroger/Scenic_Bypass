# Isaiah 61: The Spirit of the Lord YHWH Is Upon Me

*From the Hebrew: רוּחַ אֲדֹנָי יְהוִה עָלָי (Ruach Adonai YHWH Alai) — The Spirit of the Lord YHWH Is Upon Me*

---

## The Anointed One's Mission (61:1-3)

**61:1** The spirit of the Lord YHWH is upon me; because YHWH has anointed me to bring good tidings unto the humble; he has sent me to bind up the broken-hearted, to proclaim liberty to the captives, and the opening of the eyes to them that are bound;

**61:2** To proclaim the year of YHWH's favour, and the day of vengeance of our God; to comfort all that mourn;

**61:3** To appoint unto them that mourn in Zion, to give unto them a garland for ashes, the oil of joy for mourning, the garment of praise for the spirit of heaviness; that they might be called trees of righteousness, the planting of YHWH, that he might be glorified.

---

## Restoration of the Land (61:4-9)

**61:4** And they shall build the old wastes, they shall raise up the former desolations, and they shall renew the waste cities, the desolations of many generations.

**61:5** And strangers shall stand and feed your flocks, and aliens shall be your plowmen and your vinedressers.

**61:6** But you shall be named the priests of YHWH, men shall call you the ministers of our God; you shall eat the wealth of the nations, and in their glory shall you boast yourselves.

**61:7** For your shame you shall have double, and for confusion they shall rejoice in their portion; therefore in their land they shall possess double, everlasting joy shall be unto them.

**61:8** For I YHWH love justice, I hate robbery with burnt-offering; and I will give them their recompense in truth, and I will make an everlasting covenant with them.

**61:9** And their seed shall be known among the nations, and their offspring among the peoples; all that see them shall acknowledge them, that they are the seed which YHWH has blessed.

---

## The Garments of Salvation (61:10-11)

**61:10** I will greatly rejoice in YHWH, my soul shall be joyful in my God; for he has clothed me with the garments of salvation, he has covered me with the robe of righteousness, as a bridegroom decks himself with a garland, and as a bride adorns herself with her jewels.

**61:11** For as the earth brings forth her growth, and as the garden causes the things that are sown in it to spring forth; so the Lord YHWH will cause righteousness and praise to spring forth before all the nations.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (61:1-2):**
"The spirit of the Lord YHWH is upon me."

*Ruach Adonai YHWH alai*—Spirit upon speaker.

"Because YHWH has anointed me."

*Ya'an mashach YHWH oti*—anointed by YHWH.

"To bring good tidings unto the humble."

*Le-vasser anavim*—good news to humble.

"He has sent me to bind up the broken-hearted."

*Shelachani la-chabosh le-nishberei-lev*—bind broken hearts.

"To proclaim liberty to the captives."

*Liqro li-shevuyim deror*—liberty proclaimed.

"The opening of the eyes to them that are bound."

*Ve-la-asurim peqach-qo'ach*—eyes opened/prisoners freed.

"To proclaim the year of YHWH's favour."

*Liqro shenat-ratzon la-YHWH*—year of favor.

"The day of vengeance of our God."

*Ve-yom naqam le-Eloheinu*—vengeance day.

"To comfort all that mourn."

*Le-nachem kol-avelim*—comfort mourners.

**Translation Note:**
Jesus read this passage in the Nazareth synagogue (Luke 4:18-19) and stopped mid-verse at "the year of YHWH's favour," omitting "the day of vengeance of our God"—distinguishing his first coming (grace) from his second (judgment).

**The Key Verse (61:3):**
"To appoint unto them that mourn in Zion."

*Lasum la-avelei Tziyyon*—for Zion's mourners.

"To give unto them a garland for ashes."

*Latet lahem pe'er tachat efer*—garland for ashes.

"The oil of joy for mourning."

*Shemen sason tachat evel*—joy-oil for mourning.

"The garment of praise for the spirit of heaviness."

*Ma'ateh tehillah tachat ruach kehah*—praise-garment for heaviness.

"That they might be called trees of righteousness."

*Ve-qora lahem eilei ha-tzedeq*—righteousness oaks.

"The planting of YHWH."

*Matta YHWH*—YHWH's planting.

"That he might be glorified."

*Le-hitpa'er*—for glory.

**Restoration (61:4-7):**
"They shall build the old wastes."

*U-vanu chorvot olam*—build ancient ruins.

"Raise up the former desolations."

*Shomemot rishonim yeqomemu*—raise desolations.

"Renew the waste cities."

*Ve-chiddeshu arei chorev*—renew waste cities.

"The desolations of many generations."

*Shomemot dor va-dor*—multi-generation desolations.

"Strangers shall stand and feed your flocks."

*Ve-amdu zarim ve-ra'u tzonkhem*—strangers as shepherds.

"Aliens shall be your plowmen and your vinedressers."

*U-venei nekhar ikkarekhem ve-khoremekhem*—aliens as farmers.

**The Key Verse (61:6):**
"You shall be named the priests of YHWH."

*Ve-attem kohanei YHWH tiqqare'u*—priests of YHWH. 1 Peter 2:9; Revelation 1:6 echoes this.

"Men shall call you the ministers of our God."

*Mesharetei Eloheinu ye'amer lakhem*—God's ministers.

"You shall eat the wealth of the nations."

*Cheil goyim tokhelu*—nations' wealth.

"In their glory shall you boast yourselves."

*U-vi-khevedam titeyammaru*—boast in glory.

"For your shame you shall have double."

*Tachat boshtkhem mishneh*—double for shame.

"For confusion they shall rejoice in their portion."

*Ve-khelimmah yaronnu chelqam*—rejoice in portion.

"In their land they shall possess double."

*Lakhen be-artzam mishneh yirashuu*—double inheritance.

"Everlasting joy shall be unto them."

*Simchat olam tihyeh lahem*—everlasting joy.

**The Key Verses (61:8-9):**
"I YHWH love justice."

*Ki ani YHWH ohev mishpat*—YHWH loves justice.

"I hate robbery with burnt-offering."

*Sone gazel be-olah*—hates robbery with offering.

"I will give them their recompense in truth."

*Ve-natatti fe'ullatam be-emet*—true recompense.

"I will make an everlasting covenant with them."

*U-verit olam ekhrot lahem*—everlasting covenant.

"Their seed shall be known among the nations."

*Ve-noda ba-goyim zar'am*—seed known.

"They are the seed which YHWH has blessed."

*Ki hem zera berakh YHWH*—YHWH-blessed seed.

**The Key Verses (61:10-11):**
"I will greatly rejoice in YHWH."

*Sos asis ba-YHWH*—rejoicing in YHWH.

"My soul shall be joyful in my God."

*Tagel nafshi be-Elohai*—soul joyful.

"He has clothed me with the garments of salvation."

*Ki hilbishani bigdei-yesha*—salvation garments.

"He has covered me with the robe of righteousness."

*Me'il tzedaqah ye'atani*—righteousness robe.

"As a bridegroom decks himself with a garland."

*Ka-chatan yekhahen pe'er*—groom with garland.

"As a bride adorns herself with her jewels."

*Ve-kha-kallah ta'deh khelekha*—bride with jewels.

"As the earth brings forth her growth."

*Ki kha-aretz totzi tzimchah*—earth sprouts.

"As the garden causes the things that are sown in it to spring forth."

*Ve-kha-gannah zeru'ekha tatzmyach*—garden grows.

"So the Lord YHWH will cause righteousness and praise to spring forth before all the nations."

*Ken Adonai YHWH yatzmyach tzedaqah u-tehillah neged kol-ha-goyim*—righteousness/praise spring.

**Archetypal Layer:** Isaiah 61 contains **"The Spirit of the Lord YHWH is upon me" (61:1)**—quoted by Jesus in Luke 4:18-19, **"a garland for ashes, the oil of joy for mourning" (61:3)**, and **"you shall be named the priests of YHWH" (61:6)**—1 Peter 2:9; Revelation 1:6.

**Ethical Inversion Applied:**
- "The spirit of the Lord YHWH is upon me"—Spirit anointing
- "YHWH has anointed me"—anointed
- "To bring good tidings unto the humble"—good news
- "To bind up the broken-hearted"—heart-binding
- "To proclaim liberty to the captives"—liberty
- "The opening of the eyes to them that are bound"—eyes opened
- "To proclaim the year of YHWH's favour"—year of favor
- "The day of vengeance of our God"—vengeance day
- "To comfort all that mourn"—comfort
- "A garland for ashes"—exchange
- "The oil of joy for mourning"—joy for mourning
- "The garment of praise for the spirit of heaviness"—praise for heaviness
- "Trees of righteousness, the planting of YHWH"—planted righteousness
- "They shall build the old wastes"—rebuild ruins
- "Strangers shall stand and feed your flocks"—strangers serve
- "You shall be named the priests of YHWH"—1 Peter 2:9
- "You shall eat the wealth of the nations"—nations' wealth
- "For your shame you shall have double"—double for shame
- "Everlasting joy shall be unto them"—everlasting joy
- "I YHWH love justice"—YHWH loves justice
- "I will make an everlasting covenant with them"—everlasting covenant
- "He has clothed me with the garments of salvation"—salvation garments
- "He has covered me with the robe of righteousness"—righteousness robe
- "As a bridegroom... as a bride"—wedding imagery
- "So the Lord YHWH will cause righteousness and praise to spring forth"—righteousness springs

**Modern Equivalent:** Isaiah 61:1-2 is quoted by Jesus in Luke 4:18-19 as his inaugural sermon—"This day is this scripture fulfilled in your ears." The "year of YHWH's favour" anticipates Jubilee release. "Priests of YHWH" (61:6) underlies the NT's royal priesthood (1 Peter 2:9; Revelation 1:6).

# Isaiah 37: Hezekiah's Prayer and Deliverance

*From the Hebrew: וַיְהִי כִּשְׁמֹעַ הַמֶּלֶךְ חִזְקִיָּהוּ (Va-Yehi Ki-Shemo'a Ha-Melekh Chizkiyyahu) — And It Came to Pass, When King Hezekiah Heard*

---

## Hezekiah Seeks Isaiah (37:1-7)

**37:1** And it came to pass, when king Hezekiah heard it, that he rent his clothes, and covered himself with sackcloth, and went into the house of YHWH.

**37:2** And he sent Eliakim, who was over the household, and Shebna the scribe, and the elders of the priests, covered with sackcloth, unto Isaiah the prophet the son of Amoz.

**37:3** And they said unto him: "Thus says Hezekiah: This day is a day of trouble, and of rebuke, and of contumely; for the children are come to the birth, and there is not strength to bring forth.

**37:4** "It may be YHWH your God will hear the words of Rabshakeh, whom the king of Assyria his master has sent to taunt the living God, and will rebuke the words which YHWH your God has heard; wherefore lift up your prayer for the remnant that is left."

**37:5** So the servants of king Hezekiah came to Isaiah.

**37:6** And Isaiah said unto them: "Thus shall you say to your master: Thus says YHWH: Be not afraid of the words that you have heard, wherewith the servants of the king of Assyria have blasphemed me.

**37:7** "Behold, I will put a spirit in him, and he shall hear a rumor, and shall return unto his own land; and I will cause him to fall by the sword in his own land."

---

## Sennacherib's Letter (37:8-13)

**37:8** So Rabshakeh returned, and found the king of Assyria warring against Libnah; for he had heard that he was departed from Lachish.

**37:9** And he heard say concerning Tirhakah king of Cush: "He is come out to fight against you." And when he heard it, he sent messengers to Hezekiah, saying:

**37:10** "Thus shall you speak to Hezekiah king of Judah, saying: 'Let not your God in whom you trust deceive you, saying: Jerusalem shall not be given into the hand of the king of Assyria.

**37:11** "'Behold, you have heard what the kings of Assyria have done to all lands, by destroying them utterly; and shall you be delivered?

**37:12** "'Have the gods of the nations delivered them, which my fathers have destroyed, Gozan, and Haran, and Rezeph, and the children of Eden that were in Telassar?

**37:13** "'Where is the king of Hamath, and the king of Arpad, and the king of the city of Sepharvaim, of Hena, and Ivvah?'"

---

## Hezekiah's Prayer (37:14-20)

**37:14** And Hezekiah received the letter from the hand of the messengers, and read it; and Hezekiah went up unto the house of YHWH, and spread it before YHWH.

**37:15** And Hezekiah prayed unto YHWH, saying:

**37:16** "O YHWH of hosts, the God of Israel, that sits upon the cherubim, you are the God, even you alone, of all the kingdoms of the earth; you have made heaven and earth.

**37:17** "Incline your ear, O YHWH, and hear; open your eyes, O YHWH, and see; and hear all the words of Sennacherib, who has sent to taunt the living God.

**37:18** "Of a truth, YHWH, the kings of Assyria have laid waste all the countries, and their land,

**37:19** "And have cast their gods into the fire; for they were no gods, but the work of men's hands, wood and stone; therefore they have destroyed them.

**37:20** "Now therefore, O YHWH our God, save us from his hand, that all the kingdoms of the earth may know that you are YHWH, even you only."

---

## Isaiah's Oracle Against Sennacherib (37:21-35)

**37:21** Then Isaiah the son of Amoz sent unto Hezekiah, saying: "Thus says YHWH, the God of Israel: Whereas you have prayed to me against Sennacherib king of Assyria,

**37:22** "This is the word which YHWH has spoken concerning him: The virgin daughter of Zion has despised you, and laughed you to scorn; the daughter of Jerusalem has shaken her head at you.

**37:23** "Whom have you taunted and blasphemed? And against whom have you exalted your voice? Yea, you have lifted up your eyes on high, even against the Holy One of Israel!

**37:24** "By your servants you have taunted the Lord, and have said: 'With the multitude of my chariots am I come up to the height of the mountains, to the innermost parts of Lebanon; and I have cut down the tall cedars thereof, and the choice cypress-trees thereof; and I have entered into his farthest height, the forest of his fruitful field.

**37:25** "'I have digged and drunk water, and with the sole of my feet have I dried up all the rivers of Egypt.'

**37:26** "Have you not heard? Long ago I made it, in ancient times I fashioned it; now have I brought it to pass, that you should lay waste fortified cities into ruinous heaps.

**37:27** "Therefore their inhabitants were of small power, they were dismayed and confounded; they were as the grass of the field, and as the green herb, as the grass on the housetops, and as a field of grain before it is grown up.

**37:28** "But I know your sitting down, and your going out, and your coming in, and your raging against me.

**37:29** "Because of your raging against me, and for that your tumult is come up into my ears, therefore will I put my hook in your nose, and my bridle in your lips, and I will turn you back by the way by which you came.

**37:30** "And this shall be the sign unto you: You shall eat this year that which grows of itself, and in the second year that which springs of the same; and in the third year sow, and reap, and plant vineyards, and eat the fruit thereof.

**37:31** "And the remnant that is escaped of the house of Judah shall again take root downward, and bear fruit upward.

**37:32** "For out of Jerusalem shall go forth a remnant, and out of mount Zion they that shall escape; the zeal of YHWH of hosts shall perform this.

**37:33** "Therefore thus says YHWH concerning the king of Assyria: He shall not come unto this city, nor shoot an arrow there, neither shall he come before it with shield, nor cast a mound against it.

**37:34** "By the way that he came, by the same shall he return, and he shall not come unto this city, says YHWH.

**37:35** "For I will defend this city to save it, for my own sake, and for my servant David's sake."

---

## The Angel's Slaughter and Sennacherib's Death (37:36-38)

**37:36** And the angel of YHWH went forth, and smote in the camp of the Assyrians a hundred and fourscore and five thousand; and when men arose early in the morning, behold, they were all dead corpses.

**37:37** So Sennacherib king of Assyria departed, and went and returned, and dwelt at Nineveh.

**37:38** And it came to pass, as he was worshipping in the house of Nisroch his god, that Adrammelech and Sharezer his sons smote him with the sword; and they escaped into the land of Ararat. And Esarhaddon his son reigned in his stead.

---

## Synthesis Notes

**Key Restorations:**

**Hezekiah's Response (37:1-4):**
"He rent his clothes, and covered himself with sackcloth."

*Va-yiqra et-begadav va-yitkass ba-saq*—mourning response.

"Went into the house of YHWH."

*Va-yavo beit-YHWH*—temple.

"This day is a day of trouble, and of rebuke, and of contumely."

*Yom-tzarah u-tokhechah u-ne'atzah ha-yom ha-zeh*—crisis day.

"The children are come to the birth, and there is not strength to bring forth."

*Ki va'u vanim ad-mashber ve-kho'ach ayin le-ledah*—birth metaphor.

"To taunt the living God."

*Le-charef Elohim chay*—living God.

**Isaiah's First Response (37:6-7):**
"Be not afraid of the words that you have heard."

*Al-tira mippenei ha-devarim asher shama'ta*—don't fear.

"The servants of the king of Assyria have blasphemed me."

*Asher giddefu na'arei melekh-Ashshur oti*—blasphemy.

"I will put a spirit in him."

*Hineni noten bo ruach*—spirit (rumor).

"He shall hear a rumor, and shall return unto his own land."

*Ve-shama shemu'ah ve-shav el-artzo*—return.

"I will cause him to fall by the sword in his own land."

*Ve-hippaltiv ba-cherev be-artzo*—sword in his land.

**Sennacherib's Letter (37:10-13):**
"'Let not your God in whom you trust deceive you.'"

*Al-yashshiakha Elohekha asher attah bote'ach bo*—don't trust God.

"'Jerusalem shall not be given into the hand of the king of Assyria.'"

*Lo tinnaten Yerushalayim be-yad melekh-Ashshur*—Jerusalem challenge.

**The Key Verses (37:14-20):**
"Hezekiah received the letter from the hand of the messengers, and read it."

*Va-yiqqach Chizkiyyahu et-ha-sefarim mi-yad ha-mal'akhim va-yiqra'em*—letter received.

"Hezekiah went up unto the house of YHWH, and spread it before YHWH."

*Va-ya'al beit-YHWH va-yifreshehu lifnei YHWH*—spread before YHWH.

"O YHWH of hosts, the God of Israel, that sits upon the cherubim."

*YHWH Tzeva'ot Elohei Yisra'el yoshev ha-keruvim*—enthroned on cherubim.

"You are the God, even you alone, of all the kingdoms of the earth."

*Attah-hu ha-Elohim levaddekha le-khol mamlakhot ha-aretz*—only God.

"You have made heaven and earth."

*Attah asita et-ha-shamayim ve-et-ha-aretz*—Creator.

"Hear all the words of Sennacherib, who has sent to taunt the living God."

*U-shema et kol-divrei Sancheriv asher shalach le-charef Elohim chay*—hear taunts.

"They were no gods, but the work of men's hands."

*Ki lo elohim hemmah ki im-ma'aseh yedei-adam*—not gods.

"Save us from his hand, that all the kingdoms of the earth may know that you are YHWH."

*Hoshi'enu mi-yado ve-yede'u kol-mamlakhot ha-aretz ki-attah YHWH levaddekha*—salvation for witness.

**Isaiah's Oracle (37:21-35):**
"The virgin daughter of Zion has despised you, and laughed you to scorn."

*Bazah lekha la'agah lekha betulat bat-Tziyyon*—virgin Zion mocks.

"The daughter of Jerusalem has shaken her head at you."

*Acharekha rosh heni'ah bat Yerushalayim*—head-shaking.

"Against whom have you exalted your voice?"

*Ve-al-mi harimota qol*—voice against whom?

"Against the Holy One of Israel!"

*El-Qedosh Yisra'el*—Holy One.

**The Key Verses (37:26-29):**
"Have you not heard? Long ago I made it, in ancient times I fashioned it."

*Halo-shama'ta le-merachoq otah asiti mi-mei-qedem vi-yetzartiha*—YHWH planned.

"Now have I brought it to pass."

*Attah hevi'tiha*—YHWH executes.

"I know your sitting down, and your going out, and your coming in."

*Ve-shivetekha ve-tzeteekha u-vo'akha yadati*—YHWH knows all.

"Your raging against me."

*Ve-et hitragazekha elai*—rage against YHWH.

"I will put my hook in your nose, and my bridle in your lips."

*Ve-samti chachi be-appekha u-mitgi bi-sefatekha*—hook and bridle.

"I will turn you back by the way by which you came."

*Va-hashivotikha ba-derekh asher-bata bah*—turned back.

**The Key Verses (37:31-32):**
"The remnant that is escaped of the house of Judah shall again take root downward."

*Ve-yasefah peleitat beit-Yehudah ha-nish'arah shoresh lemattah*—remnant roots.

"Bear fruit upward."

*Ve-asah peri lema'lah*—fruit upward.

"Out of Jerusalem shall go forth a remnant."

*Ki mi-Yerushalayim tetze she'erit*—remnant from Jerusalem.

"The zeal of YHWH of hosts shall perform this."

*Qin'at YHWH Tzeva'ot ta'aseh zot*—YHWH's zeal.

**Deliverance (37:33-38):**
"He shall not come unto this city, nor shoot an arrow there."

*Lo yavo el-ha-ir ha-zot ve-lo-yoreh sham chetz*—no arrow.

"Neither shall he come before it with shield."

*Ve-lo-yeqadmenah magen*—no shield.

"Nor cast a mound against it."

*Ve-lo-yishpokh alekha solelah*—no siege mound.

"For I will defend this city to save it."

*Ve-gannoti al-ha-ir ha-zot le-hoshi'ah*—defend city.

"For my own sake, and for my servant David's sake."

*Lema'ani u-lema'an David avdi*—for YHWH and David.

**The Key Verse (37:36):**
"The angel of YHWH went forth, and smote in the camp of the Assyrians."

*Va-yetze mal'akh YHWH va-yakh be-machaneh Ashshur*—angel strikes.

"A hundred and fourscore and five thousand."

*Me'ah shemonim va-chamishah elef*—185,000 slain.

"They were all dead corpses."

*Ve-hinneh khullam pegerim metim*—all dead.

"Sennacherib king of Assyria departed... and dwelt at Nineveh."

*Va-yissa va-yelekh va-yashov Sancheriv melekh-Ashshur va-yeshev be-Nineveh*—returned to Nineveh.

"Adrammelech and Sharezer his sons smote him with the sword."

*Adrammelekh ve-Sar'etzer vanav hikkuhu va-cherev*—assassinated by sons.

"Esarhaddon his son reigned in his stead."

*Va-yimlokh Esar-Chaddon beno tachtav*—Esarhaddon succeeds.

**Archetypal Layer:** Isaiah 37 shows **Hezekiah's faithful prayer response**, **Isaiah's oracle against Assyrian pride**, and **the miraculous deliverance by the angel of YHWH**. YHWH defends Zion for his own sake and David's.

**Ethical Inversion Applied:**
- "He rent his clothes, and covered himself with sackcloth"—humility
- "Went into the house of YHWH"—seeking YHWH
- "The children are come to the birth, and there is not strength"—desperate
- "To taunt the living God"—living God challenged
- "Be not afraid of the words"—Isaiah's comfort
- "I will put a spirit in him"—YHWH controls
- "Hezekiah... spread it before YHWH"—spreading letter before God
- "You are the God, even you alone"—only God
- "You have made heaven and earth"—Creator
- "They were no gods, but the work of men's hands"—idols not gods
- "Save us from his hand, that all the kingdoms of the earth may know"—witness purpose
- "The virgin daughter of Zion has despised you"—Zion mocks Assyria
- "Against the Holy One of Israel!"—blasphemy target
- "Have you not heard? Long ago I made it"—YHWH planned history
- "I will put my hook in your nose"—YHWH controls Assyria
- "The remnant... shall again take root"—remnant preserved
- "The zeal of YHWH of hosts shall perform this"—YHWH's zeal
- "He shall not come unto this city, nor shoot an arrow"—no attack
- "For my own sake, and for my servant David's sake"—YHWH's and David's sake
- "The angel of YHWH went forth, and smote... 185,000"—angelic deliverance
- "His sons smote him with the sword"—Sennacherib assassinated

**Modern Equivalent:** Isaiah 37 is confirmed by Assyrian records (Sennacherib's Prism) which mention Hezekiah but significantly omit capturing Jerusalem. The 185,000 slain by the angel is unexplained in secular records but may relate to a plague. Sennacherib's assassination by his sons is confirmed by Assyrian records.

# Isaiah 20: The Sign Against Egypt and Cush

*From the Hebrew: בִּשְׁנַת בֹּא תַרְתָּן (Bi-Shenat Bo Tartan) — In the Year That Tartan Came*

---

## Isaiah's Symbolic Act (20:1-6)

**20:1** In the year that Tartan came unto Ashdod, when Sargon the king of Assyria sent him, and he fought against Ashdod and took it;

**20:2** At that time YHWH spoke by Isaiah the son of Amoz, saying: "Go, and loose the sackcloth from off your loins, and put your shoe from off your foot." And he did so, walking naked and barefoot.

**20:3** And YHWH said: "Like as my servant Isaiah has walked naked and barefoot three years for a sign and a wonder concerning Egypt and concerning Cush,

**20:4** "So shall the king of Assyria lead away the captives of Egypt, and the exiles of Cush, young and old, naked and barefoot, and with buttocks uncovered, to the shame of Egypt.

**20:5** "And they shall be dismayed and ashamed, because of Cush their expectation, and of Egypt their glory.

**20:6** "And the inhabitant of this coast-land shall say in that day: 'Behold, such is our expectation, whither we fled for help to be delivered from the king of Assyria; and how shall we escape?'"

---

## Synthesis Notes

**Key Restorations:**

**Historical Setting (20:1):**
"In the year that Tartan came unto Ashdod."

*Bi-shenat bo Tartan Ashdodah*—Tartan = Assyrian military title.

"When Sargon the king of Assyria sent him."

*Bi-shelo'ach oto Sargon melekh Ashshur*—Sargon II (722-705 BCE).

"He fought against Ashdod and took it."

*Va-yillachem be-Ashdod va-yilkedah*—Ashdod captured (711 BCE).

**Symbolic Act (20:2):**
"Go, and loose the sackcloth from off your loins."

*Lekh u-fittachta ha-saq me-al motnekha*—remove sackcloth.

"Put your shoe from off your foot."

*Ve-na'alkha tachalatz me-al raglekha*—remove sandals.

"He did so, walking naked and barefoot."

*Va-ya'as ken halokh arom ve-yachef*—naked and barefoot.

**Three Years (20:3):**
"My servant Isaiah has walked naked and barefoot three years."

*Halakh avdi Yeshayahu arom ve-yachef shalosh shanim*—three-year sign.

"For a sign and a wonder concerning Egypt and concerning Cush."

*Ot u-mofet al-Mitzrayim ve-al-Kush*—sign against Egypt/Cush.

**Captivity Depicted (20:4):**
"The king of Assyria lead away the captives of Egypt."

*Ken yinhag melekh-Ashshur et-shevi Mitzrayim*—Egypt captive.

"The exiles of Cush."

*Ve-et-golat Kush*—Cush exiled.

"Young and old, naked and barefoot."

*Ne'arim u-zeqenim arom ve-yachef*—all ages.

"With buttocks uncovered, to the shame of Egypt."

*Va-chasufei shet ervat Mitzrayim*—shameful exposure.

**False Hope (20:5-6):**
"They shall be dismayed and ashamed."

*Ve-chatu va-voshu*—dismayed and shamed.

"Because of Cush their expectation."

*Mi-Kush mabbatam*—Cush disappointed.

"Of Egypt their glory."

*U-min-Mitzrayim tif'artam*—Egypt disappointed.

"The inhabitant of this coast-land."

*Yoshev ha-i ha-zeh*—coastland inhabitants (Philistia, Judah).

"'Such is our expectation, whither we fled for help.'"

*Hinneh-khoh mabbatenu asher-nasnu sham le-ezrah*—failed hope.

"'To be delivered from the king of Assyria.'"

*Le-hinnatzzel mippenei melekh Ashshur*—escape Assyria.

"'How shall we escape?'"

*Ve-eikh nimmalet anachnu*—no escape.

**Archetypal Layer:** Isaiah 20 is a **prophetic sign-act**—Isaiah walks naked for three years to depict Egypt and Cush's coming captivity. The message: don't trust Egypt; Assyria will defeat them.

**Ethical Inversion Applied:**
- "In the year that Tartan came unto Ashdod"—dated oracle
- "Sargon the king of Assyria"—named Assyrian king
- "Go, and loose the sackcloth from off your loins"—commanded nakedness
- "He did so, walking naked and barefoot"—obedient sign-act
- "Three years for a sign and a wonder"—extended prophetic drama
- "The king of Assyria lead away the captives of Egypt"—Egypt captive
- "Young and old, naked and barefoot"—complete humiliation
- "With buttocks uncovered, to the shame of Egypt"—shameful exposure
- "They shall be dismayed and ashamed"—false hope fails
- "Because of Cush their expectation"—disappointed in Cush
- "'Such is our expectation, whither we fled for help'"—misplaced trust
- "'How shall we escape?'"—no escape through alliances

**Modern Equivalent:** Isaiah 20's three-year sign-act shows prophetic embodiment—the message lived, not just spoken. The warning against trusting Egypt/Cush (rather than YHWH) applies to all misplaced political trust.

# Isaiah 62: Zion's New Name

*From the Hebrew: לְמַעַן צִיּוֹן לֹא אֶחֱשֶׁה (Lema'an Tziyyon Lo Echesheh) — For Zion's Sake I Will Not Hold My Peace*

---

## The Prophet's Persistence (62:1-5)

**62:1** For Zion's sake I will not hold my peace, and for Jerusalem's sake I will not rest, until her righteousness go forth as brightness, and her salvation as a torch that burns.

**62:2** And the nations shall see your righteousness, and all kings your glory; and you shall be called by a new name, which the mouth of YHWH shall mark out.

**62:3** You shall also be a crown of beauty in the hand of YHWH, and a royal diadem in the open hand of your God.

**62:4** You shall no more be termed Forsaken, neither shall your land any more be termed Desolate; but you shall be called Hephzibah, and your land Beulah; for YHWH delights in you, and your land shall be married.

**62:5** For as a young man marries a virgin, so shall your sons marry you; and as the bridegroom rejoices over the bride, so shall your God rejoice over you.

---

## Watchmen on the Walls (62:6-9)

**62:6** I have set watchmen upon your walls, O Jerusalem, who shall never hold their peace day nor night; you that are YHWH's remembrancers, take no rest,

**62:7** And give him no rest, till he establish, and till he make Jerusalem a praise in the earth.

**62:8** YHWH has sworn by his right hand, and by the arm of his strength: Surely I will no more give your grain to be food for your enemies; and foreigners shall not drink your wine, for which you have laboured;

**62:9** But they that have garnered it shall eat it, and praise YHWH, and they that have gathered it shall drink it in my holy courts.

---

## Prepare the Way (62:10-12)

**62:10** Go through, go through the gates, clear the way of the people; cast up, cast up the highway, gather out the stones; lift up an ensign over the peoples.

**62:11** Behold, YHWH has proclaimed unto the end of the earth: Say to the daughter of Zion: "Behold, your salvation comes; behold, his reward is with him, and his recompense before him."

**62:12** And they shall call them the holy people, the redeemed of YHWH; and you shall be called Sought out, a city not forsaken.

---

## Synthesis Notes

**Key Restorations:**

**Prophet's Persistence (62:1):**
"For Zion's sake I will not hold my peace."

*Lema'an Tziyyon lo echesheh*—won't be silent.

"For Jerusalem's sake I will not rest."

*U-lema'an Yerushalayim lo eshqot*—won't rest.

"Until her righteousness go forth as brightness."

*Ad-yetze kha-nogah tzidqah*—righteousness shines.

"Her salvation as a torch that burns."

*Vi-yeshu'atah ke-lappid yiv'ar*—salvation burns.

**New Name (62:2-4):**
"The nations shall see your righteousness."

*Ve-ra'u goyim tzidqekh*—nations see righteousness.

"All kings your glory."

*Ve-khol-melakhim kevodekh*—kings see glory.

"You shall be called by a new name."

*Ve-qora lakh shem chadash*—new name.

"Which the mouth of YHWH shall mark out."

*Asher pi YHWH yiqqevenu*—YHWH names.

"You shall also be a crown of beauty in the hand of YHWH."

*Ve-hayit ateret tif'eret be-yad YHWH*—beauty crown.

"A royal diadem in the open hand of your God."

*U-tzniph melukha be-khaf Elohayikh*—royal diadem.

**The Key Verse (62:4):**
"You shall no more be termed Forsaken."

*Lo-ye'amer lakh od Azuvah*—not "Forsaken."

"Neither shall your land any more be termed Desolate."

*U-le-artzekh lo-ye'amer od Shemamah*—not "Desolate."

"But you shall be called Hephzibah."

*Ki lakh yiqqare Cheftzibah*—Hephzibah = "My Delight Is in Her."

"Your land Beulah."

*U-le-artzekh Be'ulah*—Beulah = "Married."

"For YHWH delights in you."

*Ki-chafetz YHWH bakh*—YHWH delights.

"Your land shall be married."

*Ve-artzekh tibba'el*—land married.

**The Key Verse (62:5):**
"As a young man marries a virgin."

*Ki-yiv'al bachur betulah*—young man marries virgin.

"So shall your sons marry you."

*Yiv'alukh banayikh*—sons marry you.

"As the bridegroom rejoices over the bride."

*U-mesos chatan al-kallah*—groom rejoices over bride.

"So shall your God rejoice over you."

*Yasis alayikh Elohayikh*—God rejoices over you.

**Watchmen (62:6-7):**
"I have set watchmen upon your walls, O Jerusalem."

*Al-chomotayikh Yerushalayim hifqadti shomerim*—wall watchmen.

"Who shall never hold their peace day nor night."

*Kol-ha-yom ve-khol-ha-laylah tamid lo yechashu*—never silent.

"You that are YHWH's remembrancers."

*Ha-mazkrim et-YHWH*—reminding YHWH.

"Take no rest."

*Al-domi lakhem*—no rest for you.

"Give him no rest."

*Ve-al-titenu domi lo*—give him no rest.

"Till he establish."

*Ad-yekhohen*—until established.

"Till he make Jerusalem a praise in the earth."

*Ve-ad-yasim et-Yerushalayim tehillah ba-aretz*—Jerusalem = earth's praise.

**YHWH's Oath (62:8-9):**
"YHWH has sworn by his right hand."

*Nishba YHWH bi-yemino*—right-hand oath.

"By the arm of his strength."

*U-vi-zero'a uzzo*—strong-arm oath.

"I will no more give your grain to be food for your enemies."

*Im-etten od deganekh ma'akhal le-oyvayikh*—grain not to enemies.

"Foreigners shall not drink your wine."

*Ve-im-yishtu venei-nekhar tiroshekh*—wine not to foreigners.

"They that have garnered it shall eat it, and praise YHWH."

*Ki me'asefav yokheluhu ve-hilelu et-YHWH*—gatherers eat and praise.

"They that have gathered it shall drink it in my holy courts."

*U-meqabbetzav yishtuhu be-chatzrot qodshi*—gatherers drink in courts.

**Prepare the Way (62:10-12):**
"Go through, go through the gates."

*Ivru ivru ba-she'arim*—go through gates.

"Clear the way of the people."

*Pannu derekh ha-am*—clear way.

"Cast up, cast up the highway."

*Sollu sollu ha-mesillah*—prepare highway.

"Gather out the stones."

*Saqqelu me-aven*—remove stones.

"Lift up an ensign over the peoples."

*Harimu nes al-ha-ammim*—raise standard.

**The Key Verse (62:11):**
"YHWH has proclaimed unto the end of the earth."

*Hinneh YHWH hishmi'a el-qetzeh ha-aretz*—proclamation to earth's end.

"Say to the daughter of Zion: 'Behold, your salvation comes.'"

*Imru le-vat-Tziyyon hinneh yish'ekh ba*—salvation comes. Matthew 21:5 echoes this.

"Behold, his reward is with him."

*Hinneh sekharo itto*—reward with him.

"His recompense before him."

*U-fe'ullato lefanav*—recompense before.

**The Key Verse (62:12):**
"They shall call them the holy people."

*Ve-qar'u lahem am-ha-qodesh*—holy people.

"The redeemed of YHWH."

*Ge'ulei YHWH*—YHWH's redeemed.

"You shall be called Sought out."

*Ve-lakh yiqqare Derushah*—Sought Out.

"A city not forsaken."

*Ir lo ne'ezavah*—not forsaken.

**Archetypal Layer:** Isaiah 62 contains **new names (62:2, 4, 12)**—Hephzibah, Beulah, Sought Out—**"as the bridegroom rejoices over the bride, so shall your God rejoice over you" (62:5)**, and **"Behold, your salvation comes" (62:11)**—Matthew 21:5.

**Ethical Inversion Applied:**
- "For Zion's sake I will not hold my peace"—prophetic persistence
- "For Jerusalem's sake I will not rest"—no rest
- "Until her righteousness go forth as brightness"—righteousness shines
- "Her salvation as a torch that burns"—burning salvation
- "The nations shall see your righteousness"—nations see
- "You shall be called by a new name"—new name
- "Which the mouth of YHWH shall mark out"—YHWH names
- "You shall also be a crown of beauty in the hand of YHWH"—beauty crown
- "You shall no more be termed Forsaken"—not "Forsaken"
- "Neither shall your land any more be termed Desolate"—not "Desolate"
- "But you shall be called Hephzibah"—"My Delight Is in Her"
- "Your land Beulah"—"Married"
- "For YHWH delights in you"—YHWH's delight
- "Your land shall be married"—married land
- "As the bridegroom rejoices over the bride"—bridal joy
- "So shall your God rejoice over you"—God's joy
- "I have set watchmen upon your walls"—wall watchmen
- "Who shall never hold their peace day nor night"—never silent
- "Give him no rest"—no rest for YHWH
- "Till he make Jerusalem a praise in the earth"—Jerusalem praised
- "YHWH has sworn by his right hand"—oath
- "I will no more give your grain to be food for your enemies"—protection
- "Go through, go through the gates"—prepare way
- "Say to the daughter of Zion: 'Behold, your salvation comes'"—Matthew 21:5
- "They shall call them the holy people"—holy people
- "The redeemed of YHWH"—redeemed
- "You shall be called Sought out, a city not forsaken"—Sought Out

**Modern Equivalent:** Isaiah 62's new names (Hephzibah = "My Delight Is in Her"; Beulah = "Married") show identity transformation. "Behold, your salvation comes" (62:11) is echoed in Matthew 21:5 for Palm Sunday. The watchmen who give YHWH no rest (62:6-7) model persistent intercessory prayer.

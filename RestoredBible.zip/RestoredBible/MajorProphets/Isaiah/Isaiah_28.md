# Isaiah 28: Woe to Ephraim and the Cornerstone

*From the Hebrew: הוֹי עֲטֶרֶת גֵּאוּת (Hoy Ateret Ge'ut) — Woe to the Crown of Pride*

---

## Woe to Ephraim (28:1-6)

**28:1** Woe to the crown of pride of the drunkards of Ephraim,
and to the fading flower of his glorious beauty,
which is on the head of the fat valley of them that are overcome with wine!

**28:2** Behold, the Lord has a mighty and strong one;
as a storm of hail, a tempest of destruction,
as a storm of mighty waters overflowing,
he casts down to the earth with violence.

**28:3** The crown of pride of the drunkards of Ephraim
shall be trodden under foot;

**28:4** And the fading flower of his glorious beauty,
which is on the head of the fat valley,
shall be as the first-ripe fig before the summer,
which when one sees, while it is yet in his hand he swallows it.

**28:5** In that day shall YHWH of hosts be for a crown of glory,
and for a diadem of beauty, unto the residue of his people;

**28:6** And for a spirit of justice to him that sits in judgment,
and for strength to them that turn back the battle at the gate.

---

## The Priests and Prophets of Jerusalem (28:7-13)

**28:7** But these also reel through wine, and stagger through strong drink;
the priest and the prophet reel through strong drink,
they are confused because of wine, they stagger because of strong drink;
they reel in vision, they totter in judgment.

**28:8** For all tables are full of filthy vomit,
without a single clean place.

**28:9** "Whom shall he teach knowledge?
And whom shall he make to understand the message?
Them that are weaned from the milk,
them that are drawn from the breasts?

**28:10** "For it is precept upon precept, precept upon precept,
line upon line, line upon line;
here a little, there a little."

**28:11** For with stammering lips and with a strange tongue
shall it be spoken to this people;

**28:12** To whom it was said: "This is the rest, give rest to the weary;
and this is the refreshing";
yet they would not hear.

**28:13** And so the word of YHWH is unto them
precept upon precept, precept upon precept,
line upon line, line upon line;
here a little, there a little;
that they may go, and fall backward, and be broken,
and snared, and taken.

---

## The Covenant with Death and the Cornerstone (28:14-22)

**28:14** Wherefore hear the word of YHWH, you scoffers,
that rule this people that is in Jerusalem:

**28:15** Because you have said: "We have made a covenant with death,
and with Sheol are we at agreement;
when the overflowing scourge shall pass through, it shall not come unto us;
for we have made lies our refuge, and in falsehood have we hid ourselves";

**28:16** Therefore thus says the Lord YHWH:
"Behold, I lay in Zion for a foundation a stone,
a tried stone, a precious corner-stone of sure foundation;
he that believes shall not make haste.

**28:17** "And I will make justice the line, and righteousness the plummet;
and the hail shall sweep away the refuge of lies,
and the waters shall overflow the hiding-place.

**28:18** "And your covenant with death shall be annulled,
and your agreement with Sheol shall not stand;
when the overflowing scourge shall pass through,
then you shall be trodden down by it.

**28:19** "As often as it passes through, it shall take you;
for morning by morning shall it pass through,
by day and by night;
and it shall be nothing but terror to understand the message."

**28:20** For the bed is too short for a man to stretch himself;
and the covering too narrow when he gathers himself up.

**28:21** For YHWH shall rise up as in mount Perazim,
he shall be wroth as in the valley of Gibeon;
that he may do his work, his strange work,
and bring to pass his act, his strange act.

**28:22** Now therefore be not scoffers,
lest your bands be made strong;
for an extermination wholly determined have I heard
from the Lord, YHWH of hosts, upon the whole land.

---

## The Parable of the Farmer (28:23-29)

**28:23** Give ear, and hear my voice; attend, and hear my speech.

**28:24** Does he that plows for sowing plow continually?
Does he continually open and harrow his ground?

**28:25** When he has leveled the face thereof,
does he not cast abroad the black cummin, and scatter the cummin,
and put in the wheat in rows and the barley in the appointed place
and the spelt in the border thereof?

**28:26** For his God does instruct him aright, and does teach him.

**28:27** For the black cummin is not threshed with a threshing-sledge,
neither is a cart-wheel turned about upon the cummin;
but the black cummin is beaten out with a staff,
and the cummin with a rod.

**28:28** Is bread grain crushed?
No, one does not thresh it forever;
and though the wheel of his cart and his horses scatter it,
he does not crush it.

**28:29** This also comes forth from YHWH of hosts:
wonderful is his counsel, and great his wisdom.

---

## Synthesis Notes

**Key Restorations:**

**Ephraim's Drunkenness (28:1-4):**
"Woe to the crown of pride of the drunkards of Ephraim."

*Hoy ateret ge'ut shikkorei Efrayim*—proud drunkards.

"The fading flower of his glorious beauty."

*Ve-tzitz novel tzevi tif'arto*—fading beauty.

"On the head of the fat valley of them that are overcome with wine."

*Asher al-rosh gei-shemanim halumei yayin*—fat valley (Samaria).

"The Lord has a mighty and strong one."

*Hinneh chazaq ve-ammitz la-Adonai*—mighty one (Assyria).

"As a storm of hail, a tempest of destruction."

*Ke-zerem barad sa'ar qatev*—destructive storm.

**YHWH as Crown (28:5-6):**
"In that day shall YHWH of hosts be for a crown of glory."

*Ba-yom ha-hu yihyeh YHWH Tzeva'ot la-ateret tzevi*—YHWH = crown.

"For a diadem of beauty, unto the residue of his people."

*Ve-li-tzfirat tif'arah li-she'ar ammo*—beauty for remnant.

"A spirit of justice to him that sits in judgment."

*U-le-ruach mishpat la-yoshev al-ha-mishpat*—justice spirit.

**Drunken Priests/Prophets (28:7-8):**
"The priest and the prophet reel through strong drink."

*Kohen ve-navi shagu ba-shekhar*—leaders drunk.

"They are confused because of wine."

*Niv'u min-ha-yayin*—wine-confused.

"They reel in vision, they totter in judgment."

*Shagu ba-ro'eh faqu peliliyyah*—vision and judgment impaired.

"All tables are full of filthy vomit."

*Ki kol-shulchanot male'u qi tzo'ah*—vomit-covered tables.

**Mocking Response (28:9-10):**
"'Whom shall he teach knowledge?'"

*Et-mi yoreh de'ah*—who can he teach?

"'Precept upon precept, precept upon precept.'"

*Tzav la-tzav tzav la-tzav*—mocking repetition.

"'Line upon line, line upon line.'"

*Qav la-qav qav la-qav*—mocking lines.

"'Here a little, there a little.'"

*Ze'er sham ze'er sham*—little bits.

**Foreign Tongue (28:11-13):**
"With stammering lips and with a strange tongue shall it be spoken."

*Ki be-la'agei safah u-ve-lashon acheret yedabber el-ha-am ha-zeh*—foreign speech. 1 Corinthians 14:21 quotes this.

"'This is the rest, give rest to the weary.'"

*Zot ha-menuchah hanichu le-ayef*—offered rest.

"'This is the refreshing'; yet they would not hear."

*Ve-zot ha-marge'ah ve-lo avu shemo'a*—refused rest.

**The Key Verses (28:15-16):**
"'We have made a covenant with death.'"

*Karatnu berit et-mavet*—death covenant.

"'With Sheol are we at agreement.'"

*Ve-et-she'ol asinu chozeh*—Sheol agreement.

"'We have made lies our refuge.'"

*Ki samnu khazav machsenu*—lies as refuge.

"'In falsehood have we hid ourselves.'"

*U-va-sheqer nistartarnu*—hidden in falsehood.

**The Key Verse (28:16):**
"'Behold, I lay in Zion for a foundation a stone.'"

*Hineni yissad be-Tziyyon aven*—Zion stone.

"'A tried stone.'"

*Even bochan*—tested stone.

"'A precious corner-stone of sure foundation.'"

*Pinnat yiqrat mussad mussad*—precious cornerstone.

"'He that believes shall not make haste.'"

*Ha-ma'amin lo yachish*—believer unhurried. Romans 9:33; 10:11; 1 Peter 2:6 quote this.

**Justice and Righteousness (28:17-19):**
"'I will make justice the line, and righteousness the plummet.'"

*Ve-samti mishpat le-qav u-tzedaqah le-mishqolet*—justice/righteousness as measure.

"'The hail shall sweep away the refuge of lies.'"

*Ve-ya'ah varad machseh kazav*—lies swept away.

"'Your covenant with death shall be annulled.'"

*Ve-kupar beritekhem et-mavet*—death covenant cancelled.

**Strange Work (28:21):**
"YHWH shall rise up as in mount Perazim."

*Ki khe-har Peratzim yaqum YHWH*—Perazim (2 Samuel 5:20).

"He shall be wroth as in the valley of Gibeon."

*Ke-emeq be-Giv'on yirgaz*—Gibeon (Joshua 10:10-11).

"That he may do his work, his strange work."

*La'asot ma'asehu zar ma'asehu*—strange work.

"Bring to pass his act, his strange act."

*Ve-la'avod avodato nokhriyyah avodato*—foreign act.

**Farmer Parable (28:23-29):**
"Does he that plows for sowing plow continually?"

*Ha-kol ha-yom yacharosh ha-choresh*—not always plowing.

"For his God does instruct him aright."

*Ve-yissro le-mishpat Elohav yorennu*—God teaches farmer.

"The black cummin is not threshed with a threshing-sledge."

*Ki lo ba-charutz yudash qetzach*—gentle threshing.

**The Key Verse (28:29):**
"This also comes forth from YHWH of hosts."

*Gam-zot me-im YHWH Tzeva'ot yatza'ah*—from YHWH.

"Wonderful is his counsel, and great his wisdom."

*Hifli etzah higdil tushiyyah*—wonderful counsel, great wisdom.

**Archetypal Layer:** Isaiah 28 contains **the precious cornerstone (28:16)**—quoted in Romans 9:33; 10:11; 1 Peter 2:6—and **the covenant with death (28:15, 18)** that will be annulled.

**Ethical Inversion Applied:**
- "Woe to the crown of pride of the drunkards of Ephraim"—proud drunkards
- "YHWH of hosts be for a crown of glory"—YHWH replaces false crown
- "The priest and the prophet reel through strong drink"—drunken leaders
- "'Precept upon precept, line upon line'"—mocking
- "With stammering lips and with a strange tongue"—1 Corinthians 14:21
- "'This is the rest, give rest to the weary'"—rest offered, refused
- "'We have made a covenant with death'"—false security
- "'We have made lies our refuge'"—lies as refuge
- "'Behold, I lay in Zion for a foundation a stone'"—cornerstone
- "'A tried stone, a precious corner-stone'"—tested, precious
- "'He that believes shall not make haste'"—Romans 9:33
- "'I will make justice the line, and righteousness the plummet'"—justice measure
- "'Your covenant with death shall be annulled'"—death covenant cancelled
- "His strange work... his strange act"—YHWH against his own
- "Wonderful is his counsel, and great his wisdom"—divine wisdom

**Modern Equivalent:** Isaiah 28:16's cornerstone is quoted three times in the NT (Romans 9:33; 10:11; 1 Peter 2:6) for Christ. The "stammering lips" (28:11) is applied to tongues in 1 Corinthians 14:21. The farmer parable (28:23-29) shows God's wisdom in varied methods.

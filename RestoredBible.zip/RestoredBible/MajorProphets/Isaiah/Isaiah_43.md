# Isaiah 43: Fear Not, I Have Redeemed You

*From the Hebrew: וְעַתָּה כֹּה־אָמַר יְהוָה בֹּרַאֲךָ (Ve-Attah Koh-Amar YHWH Bor'akha) — But Now Thus Says YHWH That Created You*

---

## Israel Redeemed (43:1-7)

**43:1** But now thus says YHWH that created you, O Jacob, and he that formed you, O Israel: Fear not, for I have redeemed you, I have called you by your name, you are mine.

**43:2** When you pass through the waters, I will be with you, and through the rivers, they shall not overflow you; when you walk through the fire, you shall not be burned, neither shall the flame kindle upon you.

**43:3** For I am YHWH your God, the Holy One of Israel, your Savior; I have given Egypt as your ransom, Cush and Seba for you.

**43:4** Since you are precious in my sight, and honourable, and I have loved you; therefore will I give men for you, and peoples for your life.

**43:5** Fear not, for I am with you; I will bring your seed from the east, and gather you from the west;

**43:6** I will say to the north: "Give up," and to the south: "Keep not back, bring my sons from far, and my daughters from the end of the earth;

**43:7** "Every one that is called by my name, and whom I have created for my glory, I have formed him, yea, I have made him."

---

## Witnesses to YHWH (43:8-13)

**43:8** The blind people that have eyes, and the deaf that have ears, let them be brought forth.

**43:9** All the nations are gathered together, and the peoples are assembled; who among them can declare this, and announce to us former things? Let them bring their witnesses, that they may be justified; and let them hear, and say: "It is truth."

**43:10** You are my witnesses, says YHWH, and my servant whom I have chosen; that you may know and believe me, and understand that I am he; before me there was no God formed, neither shall any be after me.

**43:11** I, even I, am YHWH; and beside me there is no savior.

**43:12** I have declared, and I have saved, and I have announced, and there was no strange god among you; therefore you are my witnesses, says YHWH, and I am God.

**43:13** Yea, since the day was I am he, and there is none that can deliver out of my hand; I will work, and who can reverse it?

---

## A New Exodus (43:14-21)

**43:14** Thus says YHWH, your Redeemer, the Holy One of Israel: For your sake I have sent to Babylon, and I will bring down all of them as fugitives, even the Chaldeans, in the ships of their shouting.

**43:15** I am YHWH, your Holy One, the Creator of Israel, your King.

**43:16** Thus says YHWH, who makes a way in the sea, and a path in the mighty waters;

**43:17** Who brings forth chariot and horse, army and power—they lie down together, they shall not rise, they are extinct, they are quenched as a wick:

**43:18** Remember not the former things, neither consider the things of old.

**43:19** Behold, I will do a new thing; now shall it spring forth; shall you not know it? I will even make a way in the wilderness, and rivers in the desert.

**43:20** The beasts of the field shall honour me, the jackals and the ostriches; because I give waters in the wilderness, and rivers in the desert, to give drink to my people, my chosen,

**43:21** The people which I formed for myself, that they might tell forth my praise.

---

## Israel's Ingratitude (43:22-28)

**43:22** Yet you have not called upon me, O Jacob, neither have you wearied yourself about me, O Israel.

**43:23** You have not brought me the small cattle of your burnt-offerings; neither have you honoured me with your sacrifices. I have not burdened you with a meal-offering, nor wearied you with frankincense.

**43:24** You have bought me no sweet cane with money, neither have you satisfied me with the fat of your sacrifices; but you have burdened me with your sins, you have wearied me with your iniquities.

**43:25** I, even I, am he that blots out your transgressions for my own sake; and your sins I will not remember.

**43:26** Put me in remembrance, let us plead together; declare, that you may be justified.

**43:27** Your first father sinned, and your intercessors have transgressed against me.

**43:28** Therefore I have profaned the princes of the sanctuary, and I have given Jacob to the curse, and Israel to reviling.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (43:1-2):**
"Thus says YHWH that created you, O Jacob."

*Koh-amar YHWH bor'akha Ya'aqov*—Creator of Jacob.

"He that formed you, O Israel."

*Ve-yotzrekha Yisra'el*—former of Israel.

"Fear not, for I have redeemed you."

*Al-tira ki ge'altikha*—redeemed.

"I have called you by your name."

*Qaratikha vi-shemekha*—called by name.

"You are mine."

*Li-attah*—belonging.

"When you pass through the waters, I will be with you."

*Ki-ta'avor ba-mayim ittekha-ani*—through waters.

"Through the rivers, they shall not overflow you."

*U-va-neharot lo yishtefukha*—rivers won't overflow.

"When you walk through the fire, you shall not be burned."

*Ki-telekh be-mo-esh lo tikkaveh*—through fire.

"Neither shall the flame kindle upon you."

*Ve-lehavah lo tiv'ar-bakh*—flame won't kindle.

**Ransom (43:3-4):**
"I am YHWH your God, the Holy One of Israel, your Savior."

*Ki ani YHWH Elohekha Qedosh Yisra'el moshi'ekha*—Savior.

"I have given Egypt as your ransom."

*Natatti khofrékha Mitzrayim*—Egypt as ransom.

"Cush and Seba for you."

*Kush u-Seva tachtekha*—Cush and Seba.

**The Key Verse (43:4):**
"Since you are precious in my sight."

*Me-asher yaqarta ve-einai*—precious.

"And honourable."

*Nikhbadta*—honoured.

"And I have loved you."

*Va-ani ahavtikha*—loved.

"Therefore will I give men for you."

*Ve-etten adam tachtekha*—men given.

"Peoples for your life."

*U-le'ummim tachat nafshekha*—peoples for life.

**Ingathering (43:5-7):**
"Fear not, for I am with you."

*Al-tira ki ittekha-ani*—fear not.

"I will bring your seed from the east."

*Mi-mizrach avi zar'ekha*—from east.

"Gather you from the west."

*U-mi-ma'arav aqabbetzekka*—from west.

"I will say to the north: 'Give up.'"

*Omar la-tzafon teni*—north gives up.

"To the south: 'Keep not back.'"

*Ve-la-teiman al-tikla'i*—south releases.

"Bring my sons from far, and my daughters from the end of the earth."

*Havi'i vanai me-rachoq u-venotai mi-qetzeh ha-aretz*—sons/daughters gathered.

"Every one that is called by my name."

*Kol ha-niqra vi-shemi*—called by name.

"Whom I have created for my glory."

*Ve-li-khevodi verativo*—created for glory.

**The Key Verses (43:10-12):**
"You are my witnesses, says YHWH."

*Attem edai ne'um-YHWH*—witnesses.

"And my servant whom I have chosen."

*Ve-avdi asher bacharti*—chosen servant.

"That you may know and believe me."

*Lema'an tede'u ve-ta'aminu li*—know and believe.

"And understand that I am he."

*Ve-tavinu ki-ani hu*—I am he.

"Before me there was no God formed."

*Lefanai lo-notzar El*—no prior God.

"Neither shall any be after me."

*Ve-acharai lo yihyeh*—no subsequent God.

**The Key Verse (43:11):**
"I, even I, am YHWH."

*Anokhi anokhi YHWH*—double I.

"Beside me there is no savior."

*Ve-ein mi-bil'adai moshi'a*—only Savior.

"I have declared, and I have saved, and I have announced."

*Anokhi higgadti ve-hosha'ti ve-hishma'ti*—declared, saved, announced.

"You are my witnesses, says YHWH, and I am God."

*Ve-attem edai ne'um-YHWH va-ani-El*—witnesses and God.

**The Key Verse (43:13):**
"Since the day was I am he."

*Gam-mi-yom ani hu*—from the day, I am he.

"There is none that can deliver out of my hand."

*Ve-ein mi-yadi matztzil*—none delivers.

"I will work, and who can reverse it?"

*Ef'al u-mi yeshivenah*—irreversible work.

**New Exodus (43:14-21):**
"Your Redeemer, the Holy One of Israel."

*Go'alkhem Qedosh Yisra'el*—Redeemer.

"For your sake I have sent to Babylon."

*Lema'ankhem shillachti Bavelah*—sent to Babylon.

"I am YHWH, your Holy One, the Creator of Israel, your King."

*Ani YHWH qedoshkhem bore Yisra'el malkkhem*—Holy One, Creator, King.

"Who makes a way in the sea."

*Ha-noten ba-yam derekh*—sea way.

"A path in the mighty waters."

*U-ve-mayim azzim netivah*—mighty waters path (Exodus echo).

"Who brings forth chariot and horse, army and power."

*Ha-motzi rekhev va-sus chayil ve-izuz*—chariot and horse.

"They are extinct, they are quenched as a wick."

*Da'akhu ka-pishtah khavu*—quenched like wick.

**The Key Verses (43:18-19):**
"Remember not the former things."

*Al-tizkeru rishonot*—don't remember former.

"Neither consider the things of old."

*U-qadmoniyyot al-titbonenu*—don't consider old.

"Behold, I will do a new thing."

*Hineni oseh chadashah*—doing new.

"Now shall it spring forth."

*Attah titzmach*—springing forth.

"Shall you not know it?"

*Halo tede'uha*—won't you know?

"I will even make a way in the wilderness."

*Af-asim ba-midbar derekh*—wilderness way.

"Rivers in the desert."

*Bi-yeshimon neharot*—desert rivers.

"The people which I formed for myself."

*Am-zu yatzarti li*—formed people.

"That they might tell forth my praise."

*Tehillati yesapperu*—praise-tellers.

**Ingratitude (43:22-24):**
"Yet you have not called upon me, O Jacob."

*Ve-lo-oti qarata Ya'aqov*—not called.

"Neither have you wearied yourself about me."

*Ki-yaga'ta bi Yisra'el*—not wearied for YHWH.

"I have not burdened you with a meal-offering."

*Lo he'evadttikha be-minchah*—not burdened.

"You have burdened me with your sins."

*Akh he'evadtani be-chatto'tekha*—burdened with sins.

"You have wearied me with your iniquities."

*Hoga'tani ba-avonotekha*—wearied with iniquities.

**The Key Verse (43:25):**
"I, even I, am he that blots out your transgressions for my own sake."

*Anokhi anokhi hu mocheh fesha'ekha lema'ani*—blotting out transgressions.

"Your sins I will not remember."

*Ve-chatto'tekha lo ezkor*—sins not remembered.

**Archetypal Layer:** Isaiah 43 contains **"Fear not, for I have redeemed you" (43:1)**, **"You are my witnesses" (43:10)**, **"I, even I, am YHWH; beside me there is no savior" (43:11)**, and **"I will do a new thing" (43:19)**.

**Ethical Inversion Applied:**
- "Fear not, for I have redeemed you"—redeemed
- "I have called you by your name, you are mine"—named and owned
- "When you pass through the waters, I will be with you"—water protection
- "When you walk through the fire, you shall not be burned"—fire protection
- "I am YHWH your God, the Holy One of Israel, your Savior"—Savior
- "I have given Egypt as your ransom"—ransom paid
- "Since you are precious in my sight, and honourable, and I have loved you"—precious, loved
- "Fear not, for I am with you"—presence
- "Bring my sons from far, and my daughters from the end of the earth"—global gathering
- "Every one that is called by my name... I have created for my glory"—glory purpose
- "You are my witnesses, says YHWH"—witness role
- "Before me there was no God formed, neither shall any be after me"—only God
- "I, even I, am YHWH; beside me there is no savior"—only Savior
- "I will work, and who can reverse it?"—irreversible
- "Who makes a way in the sea"—Exodus echo
- "Remember not the former things"—don't remember
- "Behold, I will do a new thing"—new thing
- "I will even make a way in the wilderness"—new Exodus
- "You have burdened me with your sins"—sin-burden
- "I, even I, am he that blots out your transgressions for my own sake"—grace
- "Your sins I will not remember"—forgiveness

**Modern Equivalent:** Isaiah 43:2's water and fire protection promises comfort in trials. "I, even I, am YHWH; beside me there is no savior" (43:11) is foundational monotheism. "I will do a new thing" (43:19) announces God's fresh work. "I... blot out your transgressions for my own sake" (43:25) is pure grace.

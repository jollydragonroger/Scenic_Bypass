# Isaiah 56: Salvation for All Who Keep Justice

*From the Hebrew: כֹּה אָמַר יְהוָה שִׁמְרוּ מִשְׁפָּט (Koh Amar YHWH Shimru Mishpat) — Thus Says YHWH: Keep Justice*

---

## Foreigners and Eunuchs Welcomed (56:1-8)

**56:1** Thus says YHWH: Keep justice, and do righteousness; for my salvation is near to come, and my righteousness to be revealed.

**56:2** Happy is the man that does this, and the son of man that holds fast by it: that keeps the sabbath from profaning it, and keeps his hand from doing any evil.

**56:3** Neither let the son of the stranger, that has joined himself to YHWH, speak, saying: "YHWH will surely separate me from his people"; neither let the eunuch say: "Behold, I am a dry tree."

**56:4** For thus says YHWH concerning the eunuchs that keep my sabbaths, and choose the things that please me, and hold fast by my covenant:

**56:5** Even unto them will I give in my house and within my walls a monument and a memorial better than sons and daughters; I will give them an everlasting name, that shall not be cut off.

**56:6** Also the foreigners, that join themselves to YHWH, to minister unto him, and to love the name of YHWH, to be his servants, every one that keeps the sabbath from profaning it, and holds fast by my covenant:

**56:7** Even them will I bring to my holy mountain, and make them joyful in my house of prayer; their burnt-offerings and their sacrifices shall be acceptable upon my altar; for my house shall be called a house of prayer for all peoples.

**56:8** Says the Lord YHWH who gathers the dispersed of Israel: Yet will I gather others to him, beside those of him that are gathered.

---

## Faithless Leaders (56:9-12)

**56:9** All you beasts of the field, come to devour, all you beasts in the forest.

**56:10** His watchmen are blind, they are all without knowledge; they are all dumb dogs, they cannot bark; raving, lying down, loving to slumber.

**56:11** Yea, the dogs are greedy, they know not when they have enough; and these are shepherds that cannot understand; they have all turned to their own way, each one to his gain, one and all.

**56:12** "Come," say they, "I will fetch wine, and we will fill ourselves with strong drink; and tomorrow shall be as this day, and much more abundant."

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (56:1-2):**
"Keep justice, and do righteousness."

*Shimru mishpat va-asu tzedaqah*—justice and righteousness.

"For my salvation is near to come."

*Ki-qerovah yeshu'ati lavo*—salvation near.

"My righteousness to be revealed."

*Ve-tzidqati le-higgalot*—righteousness revealed.

"Happy is the man that does this."

*Ashrei enosh ya'aseh-zot*—blessed doer.

"The son of man that holds fast by it."

*U-ven-adam yachaziq bah*—one who holds fast.

"That keeps the sabbath from profaning it."

*Shomer shabbat me-challelo*—sabbath-keeper.

"Keeps his hand from doing any evil."

*Ve-shomer yado me-asot kol-ra*—avoids evil.

**Foreigners and Eunuchs (56:3-5):**
"Neither let the son of the stranger, that has joined himself to YHWH, speak, saying."

*Ve-al-yomar ben-ha-nekhar ha-nilveh el-YHWH lemor*—foreigner's concern.

"'YHWH will surely separate me from his people.'"

*Havdel yavdileni YHWH me-al ammo*—fear of exclusion.

"Neither let the eunuch say: 'Behold, I am a dry tree.'"

*Ve-al-yomar ha-saris hen ani etz yavesh*—eunuch's concern.

"Concerning the eunuchs that keep my sabbaths."

*La-sarisim asher yishmeru et-shabbtotai*—sabbath-keeping eunuchs.

"Choose the things that please me."

*U-vacharu ba-asher chafatzti*—choosing what pleases.

"Hold fast by my covenant."

*U-machaziqqim bi-veriti*—covenant-holders.

**The Key Verse (56:5):**
"Unto them will I give in my house and within my walls a monument and a memorial."

*Ve-natatti lahem be-veiti u-ve-chomotai yad va-shem*—monument (*yad va-shem* = "hand and name").

"Better than sons and daughters."

*Tov mi-banim u-mi-banot*—better than children.

"An everlasting name, that shall not be cut off."

*Shem olam etten lo asher lo yikkaret*—eternal name.

**The Key Verses (56:6-7):**
"The foreigners, that join themselves to YHWH."

*U-venei ha-nekhar ha-nilvim al-YHWH*—foreigners joined.

"To minister unto him."

*Le-shareto*—to serve.

"To love the name of YHWH."

*U-le-ahavah et-shem YHWH*—love YHWH's name.

"To be his servants."

*Lihyot lo la-avadim*—to be servants.

"Every one that keeps the sabbath from profaning it."

*Kol-shomer shabbat me-challelo*—sabbath-keepers.

"Holds fast by my covenant."

*U-machaziqqim bi-veriti*—covenant-holders.

"Even them will I bring to my holy mountain."

*Va-havi'otim el-har qodshi*—brought to holy mountain.

"Make them joyful in my house of prayer."

*Ve-simachtim be-veit tefillati*—joyful in prayer house.

"Their burnt-offerings and their sacrifices shall be acceptable upon my altar."

*Oloteihem ve-zivcheihem le-ratzon al-mizbechi*—acceptable offerings.

**The Key Verse (56:7):**
"For my house shall be called a house of prayer for all peoples."

*Ki veiti beit-tefillah yiqqare le-khol-ha-ammim*—prayer house for all. Jesus quotes this in Matthew 21:13; Mark 11:17; Luke 19:46.

**Gathering (56:8):**
"Says the Lord YHWH who gathers the dispersed of Israel."

*Ne'um Adonai YHWH meqabbetz nidchei Yisra'el*—gathers Israel's dispersed.

"Yet will I gather others to him."

*Od aqabbetz alav le-niqbatzav*—more gathered. Jesus alludes to this in John 10:16.

**Blind Watchmen (56:9-12):**
"All you beasts of the field, come to devour."

*Kol chayyeto sadai etayu*—beasts invited.

"All you beasts in the forest."

*Kol-chayyeto ba-ya'ar*—forest beasts.

"His watchmen are blind."

*Tzofav ivrim*—blind watchmen.

"They are all without knowledge."

*Kullam lo yada'u*—no knowledge.

"They are all dumb dogs, they cannot bark."

*Kullam kelavim illemim lo yukhelu linbo'ach*—mute dogs.

"Raving, lying down, loving to slumber."

*Hozim shokevim ohavei lanum*—dreaming, lying, slumbering.

"The dogs are greedy, they know not when they have enough."

*Ve-ha-kelavim azzei-nefesh lo yade'u sov'ah*—greedy dogs.

"These are shepherds that cannot understand."

*Ve-hem ro'im lo yade'u havin*—uncomprehending shepherds.

"They have all turned to their own way."

*Kullam le-darkkam panu*—own way.

"Each one to his gain."

*Ish le-vitza'o mi-qatzehu*—own gain.

"'Come... I will fetch wine.'"

*Etayu eqqachah yayin*—wine-fetching.

"'We will fill ourselves with strong drink.'"

*Ve-nisbe'ah shekhar*—filled with drink.

"'Tomorrow shall be as this day.'"

*Ve-hayah kha-zeh yom machar*—tomorrow same.

"'And much more abundant.'"

*Gadol yeter me'od*—even more.

**Archetypal Layer:** Isaiah 56 begins **Third Isaiah (chapters 56-66)** with inclusion of **foreigners and eunuchs (56:3-7)**, **"my house shall be called a house of prayer for all peoples" (56:7)**—Matthew 21:13, and **condemnation of blind watchmen (56:10-12)**.

**Ethical Inversion Applied:**
- "Keep justice, and do righteousness"—ethical demand
- "My salvation is near to come"—salvation near
- "Happy is the man that does this"—beatitude
- "That keeps the sabbath from profaning it"—sabbath
- "'YHWH will surely separate me from his people'"—foreigner's fear
- "'Behold, I am a dry tree'"—eunuch's fear
- "Unto them will I give in my house... a monument and a memorial"—yad va-shem
- "Better than sons and daughters"—better than children
- "An everlasting name, that shall not be cut off"—eternal name
- "The foreigners, that join themselves to YHWH"—foreigners included
- "To love the name of YHWH, to be his servants"—love and service
- "Even them will I bring to my holy mountain"—included
- "Make them joyful in my house of prayer"—joy
- "For my house shall be called a house of prayer for all peoples"—Matthew 21:13
- "Yet will I gather others to him"—John 10:16
- "His watchmen are blind"—blind leaders
- "They are all dumb dogs, they cannot bark"—mute watchmen
- "These are shepherds that cannot understand"—ignorant shepherds
- "They have all turned to their own way"—self-serving
- "'Tomorrow shall be as this day'"—false security

**Modern Equivalent:** Isaiah 56 opens Third Isaiah with radical inclusion. Foreigners and eunuchs—previously excluded (Deuteronomy 23:1-3)—are welcomed if they keep covenant. "My house shall be called a house of prayer for all peoples" (56:7) is quoted by Jesus when cleansing the temple. The Ethiopian eunuch's conversion (Acts 8) fulfills 56:3-5. *Yad Vashem*, Israel's Holocaust memorial, takes its name from 56:5.

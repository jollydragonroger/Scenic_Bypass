# Isaiah 23: The Oracle Against Tyre

*From the Hebrew: מַשָּׂא צֹר (Massa Tzor) — The Burden of Tyre*

---

## Tyre's Fall (23:1-14)

**23:1** The burden of Tyre.
Wail, you ships of Tarshish,
for it is laid waste, so that there is no house, no entering in;
from the land of Kittim it is revealed to them.

**23:2** Be still, you inhabitants of the coast-land,
you whom the merchants of Sidon, that pass over the sea, have replenished.

**23:3** And on great waters the seed of Shihor,
the harvest of the Nile, was her revenue;
and she was the mart of nations.

**23:4** Be ashamed, O Sidon; for the sea has spoken,
the stronghold of the sea, saying:
"I have not travailed, nor brought forth,
neither have I reared young men, nor brought up virgins."

**23:5** When the report comes to Egypt,
they shall be sorely pained at the report of Tyre.

**23:6** Pass over to Tarshish; wail, you inhabitants of the coast-land.

**23:7** Is this your joyous city, whose feet in antiquity, in ancient days,
carried her afar off to sojourn?

**23:8** Who has devised this against Tyre, the crowning city,
whose merchants are princes,
whose traffickers are the honorable of the earth?

**23:9** YHWH of hosts has devised it,
to pollute the pride of all glory,
to bring into contempt all the honorable of the earth.

**23:10** Overflow your land as the Nile, O daughter of Tarshish;
there is no girdle any more.

**23:11** He has stretched out his hand over the sea,
he has shaken the kingdoms;
YHWH has given commandment concerning Canaan,
to destroy the strongholds thereof.

**23:12** And he said: "You shall no more rejoice, O oppressed virgin daughter of Sidon;
arise, pass over to Kittim; even there shall you have no rest."

**23:13** Behold, the land of the Chaldeans—this is the people that was not,
Assyria founded it for shipmen—
they set up their towers, they overthrew the palaces thereof;
it is made a ruin.

**23:14** Wail, you ships of Tarshish,
for your stronghold is laid waste.

---

## Tyre's Restoration (23:15-18)

**23:15** And it shall come to pass in that day, that Tyre shall be forgotten seventy years, according to the days of one king; after the end of seventy years it shall be unto Tyre as in the song of the harlot:

**23:16** Take a harp, go about the city, you harlot long forgotten;
make sweet melody, sing many songs,
that you may be remembered.

**23:17** And it shall come to pass after the end of seventy years, that YHWH will remember Tyre, and she shall return to her hire, and shall have commerce with all the kingdoms of the world upon the face of the earth.

**23:18** And her gain and her hire shall be holy to YHWH;
it shall not be treasured nor laid up;
for her gain shall be for them that dwell before YHWH,
to eat their fill, and for stately clothing.

---

## Synthesis Notes

**Key Restorations:**

**Title (23:1):**
"The burden of Tyre."

*Massa Tzor*—oracle against Phoenician city-state.

Tyre was the great commercial center of the ancient Mediterranean.

**Ships of Tarshish (23:1):**
"Wail, you ships of Tarshish."

*Heililu oniyyot Tarshish*—Tarshish ships.

"For it is laid waste, so that there is no house, no entering in."

*Ki-shuddad mi-bayit mi-bo*—devastated.

"From the land of Kittim it is revealed to them."

*Me-eretz Kittim niglah lamo*—news from Cyprus.

**Commercial Glory (23:2-3):**
"The merchants of Sidon, that pass over the sea, have replenished."

*Socher Tzidon over yam mille'ukh*—Sidonian merchants.

"On great waters the seed of Shihor."

*U-ve-mayim rabbim zera Shichor*—Nile grain.

"The harvest of the Nile, was her revenue."

*Qetzir Ye'or tevu'atah*—Nile harvest.

"She was the mart of nations."

*Va-tehi sachar goyim*—nations' marketplace.

**Sidon's Shame (23:4):**
"Be ashamed, O Sidon; for the sea has spoken."

*Boshi Tzidon ki-amar yam*—sea speaks.

"'I have not travailed, nor brought forth.'"

*Lo-chalti ve-lo yaladti*—no children.

"'Neither have I reared young men, nor brought up virgins.'"

*Ve-lo gidalti bachurim romamti betulot*—no raising youth.

**The Key Verse (23:8-9):**
"Who has devised this against Tyre, the crowning city."

*Mi ya'atz zot al-Tzor ha-ma'atirah*—who planned this?

"Whose merchants are princes."

*Asher sochreyha sarim*—merchant-princes.

"Whose traffickers are the honorable of the earth?"

*Kina'anekha nikhbadei-aretz*—honored traders.

"YHWH of hosts has devised it."

*YHWH Tzeva'ot ye'atzah*—YHWH planned.

"To pollute the pride of all glory."

*Le-challel ge'on kol-tzevi*—pollute pride.

"To bring into contempt all the honorable of the earth."

*Le-haqel kol-nikhbadei-aretz*—bring contempt.

**YHWH's Power (23:11):**
"He has stretched out his hand over the sea."

*Yado natah al-ha-yam*—hand over sea.

"He has shaken the kingdoms."

*Hirgiz mamlakhot*—shaken kingdoms.

"YHWH has given commandment concerning Canaan."

*YHWH tzivvah el-Kena'an*—commanded Canaan.

"To destroy the strongholds thereof."

*Lashmid ma'uzanekha*—destroy strongholds.

**Seventy Years (23:15-17):**
"Tyre shall be forgotten seventy years."

*Ve-nishkachat Tzor shiv'im shanah*—seventy years forgotten.

"According to the days of one king."

*Ki-mei melekh echad*—one king's lifespan.

"After the end of seventy years it shall be unto Tyre as in the song of the harlot."

*Mi-qetz shiv'im shanah yihyeh le-Tzor ke-shirat ha-zonah*—harlot's song.

"Take a harp, go about the city, you harlot long forgotten."

*Qechi khinnor sobbi ir zonah nishkachah*—harlot with harp.

"Make sweet melody, sing many songs, that you may be remembered."

*Heitivi naggen harbi shir lema'an tizzakheri*—seeking remembrance.

"YHWH will remember Tyre."

*U-faqad YHWH et-Tzor*—YHWH remembers.

"She shall return to her hire."

*Ve-shavah le-etnannah*—return to commerce.

"Have commerce with all the kingdoms of the world."

*Ve-zantah et-kol-mamlakhot ha-aretz*—commerce with all.

**The Key Verse (23:18):**
"Her gain and her hire shall be holy to YHWH."

*Ve-hayah sachrah ve-etnanah qodesh la-YHWH*—commerce holy.

"It shall not be treasured nor laid up."

*Lo ye'atzer ve-lo yechasher*—not hoarded.

"For her gain shall be for them that dwell before YHWH."

*Ki la-yoshevim lifnei YHWH yihyeh sachrah*—for YHWH's servants.

"To eat their fill, and for stately clothing."

*Le-ekhol le-savah u-li-mekhsseh atiq*—food and clothing.

**Archetypal Layer:** Isaiah 23 concludes the Oracles Against the Nations (chapters 13-23). Tyre's commercial pride is judged, but remarkably, **her future commerce will be "holy to YHWH" (23:18)**—wealth dedicated to God's people.

**Ethical Inversion Applied:**
- "The burden of Tyre"—commercial center judged
- "Wail, you ships of Tarshish"—trading ships mourn
- "She was the mart of nations"—commercial hub
- "Be ashamed, O Sidon"—sister city shamed
- "'I have not travailed, nor brought forth'"—barren sea
- "Who has devised this against Tyre?"—who planned?
- "YHWH of hosts has devised it"—YHWH planned
- "To pollute the pride of all glory"—pride polluted
- "He has stretched out his hand over the sea"—YHWH's hand
- "Tyre shall be forgotten seventy years"—seventy years
- "It shall be unto Tyre as in the song of the harlot"—harlot metaphor
- "YHWH will remember Tyre"—restoration
- "Her gain and her hire shall be holy to YHWH"—commerce sanctified
- "Her gain shall be for them that dwell before YHWH"—wealth redirected

**Modern Equivalent:** Isaiah 23's transformation of Tyre's commerce into "holy to YHWH" (23:18) envisions wealth redeemed—commercial activity serving God's purposes. This anticipates Revelation's vision of nations bringing their glory into the New Jerusalem.

---

## Section Summary: Isaiah 13-23 (Oracles Against the Nations)

Chapters 13-23 form Isaiah's second major section:

**Structure:**
- **13-14**: Babylon (and Assyria, Philistia)
- **15-16**: Moab
- **17**: Damascus (and Israel)
- **18**: Cush
- **19-20**: Egypt
- **21**: Babylon, Dumah, Arabia
- **22**: Jerusalem ("Valley of Vision")
- **23**: Tyre

**Major Themes:**
- **Divine sovereignty** over all nations
- **Pride judged**—Babylon (14:12-15), Moab (16:6), Tyre (23:9)
- **Nations turning to YHWH**—Egypt (19:19-25), Cush (18:7), Tyre (23:18)
- **Prophetic compassion**—Moab (15:5; 16:9-11)
- **Assyria as instrument** but also judged
- **Key quotations**—"Fallen, fallen is Babylon" (21:9); "Let us eat and drink" (22:13); "Key of David" (22:22)

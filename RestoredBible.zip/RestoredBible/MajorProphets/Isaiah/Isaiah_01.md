# Isaiah 1: The Indictment of Judah

*From the Hebrew: חֲזוֹן יְשַׁעְיָהוּ (Chazon Yeshayahu) — The Vision of Isaiah*

---

## Title (1:1)

**1:1** The vision of Isaiah the son of Amoz, which he saw concerning Judah and Jerusalem, in the days of Uzziah, Jotham, Ahaz, and Hezekiah, kings of Judah.

---

## The Rebellious Nation (1:2-9)

**1:2** Hear, O heavens, and give ear, O earth,
for YHWH has spoken:
"Children I have reared and brought up,
and they have rebelled against me.

**1:3** "The ox knows its owner,
and the donkey its master's crib;
but Israel does not know,
my people does not consider."

**1:4** Ah, sinful nation, a people laden with iniquity,
a seed of evil-doers, children that deal corruptly!
They have forsaken YHWH,
they have despised the Holy One of Israel,
they are turned away backward.

**1:5** On what part will you yet be stricken, that you revolt more and more?
The whole head is sick, and the whole heart faint.

**1:6** From the sole of the foot even unto the head there is no soundness in it;
but wounds, and bruises, and festering sores:
they have not been pressed, neither bound up, neither mollified with oil.

**1:7** Your country is desolate; your cities are burned with fire;
your land, strangers devour it in your presence,
and it is desolate, as overthrown by strangers.

**1:8** And the daughter of Zion is left as a booth in a vineyard,
as a lodge in a garden of cucumbers,
as a besieged city.

**1:9** Except YHWH of hosts had left unto us a very small remnant,
we should have been as Sodom,
we should have been like unto Gomorrah.

---

## Meaningless Worship (1:10-17)

**1:10** Hear the word of YHWH, you rulers of Sodom;
give ear unto the teaching of our God, you people of Gomorrah.

**1:11** "To what purpose is the multitude of your sacrifices unto me?"
says YHWH;
"I am full of the burnt-offerings of rams,
and the fat of fed beasts;
and I delight not in the blood of bullocks, or of lambs, or of he-goats.

**1:12** "When you come to appear before me,
who has required this at your hand, to trample my courts?

**1:13** "Bring no more vain oblations;
it is an offering of abomination unto me;
new moon and sabbath, the calling of convocations—
I cannot endure iniquity along with the solemn assembly.

**1:14** "Your new moons and your appointed seasons my soul hates;
they are a trouble unto me;
I am weary to bear them.

**1:15** "And when you spread forth your hands, I will hide my eyes from you;
yea, when you make many prayers, I will not hear;
your hands are full of blood.

**1:16** "Wash you, make you clean,
put away the evil of your doings from before my eyes,
cease to do evil;

**1:17** "Learn to do well; seek justice, relieve the oppressed,
judge the fatherless, plead for the widow."

---

## The Offer of Cleansing (1:18-20)

**1:18** "Come now, and let us reason together,"
says YHWH;
"though your sins be as scarlet, they shall be as white as snow;
though they be red like crimson, they shall be as wool.

**1:19** "If you be willing and obedient,
you shall eat the good of the land;

**1:20** "But if you refuse and rebel,
you shall be devoured with the sword";
for the mouth of YHWH has spoken.

---

## The Corrupt City (1:21-31)

**1:21** How is the faithful city become a harlot!
She that was full of justice, righteousness lodged in her,
but now murderers.

**1:22** Your silver is become dross,
your wine mixed with water.

**1:23** Your princes are rebellious, and companions of thieves;
every one loves bribes, and follows after rewards;
they judge not the fatherless,
neither does the cause of the widow come unto them.

**1:24** Therefore says the Lord, YHWH of hosts, the Mighty One of Israel:
"Ah, I will ease me of my adversaries,
and avenge me of my enemies;

**1:25** "And I will turn my hand upon you,
and purge away your dross as with lye,
and will take away all your alloy;

**1:26** "And I will restore your judges as at the first,
and your counsellors as at the beginning;
afterward you shall be called The city of righteousness, a faithful city."

**1:27** Zion shall be redeemed with justice,
and they that return of her with righteousness.

**1:28** But the destruction of the transgressors and the sinners shall be together,
and they that forsake YHWH shall be consumed.

**1:29** For they shall be ashamed of the oaks which you have desired,
and you shall be confounded for the gardens that you have chosen.

**1:30** For you shall be as an oak whose leaf fades,
and as a garden that has no water.

**1:31** And the strong shall be as tow,
and his work as a spark;
and they shall both burn together,
and none shall quench them.

---

## Synthesis Notes

**Key Restorations:**

**Title (1:1):**
"The vision of Isaiah the son of Amoz."

*Chazon Yeshayahu ben-Amotz*—Isaiah = YHWH saves.

"Concerning Judah and Jerusalem."

*Al-Yehudah vi-Yerushalayim*—southern focus.

"In the days of Uzziah, Jotham, Ahaz, and Hezekiah."

Four kings = approximately 740-686 BCE.

**Cosmic Courtroom (1:2-4):**
"Hear, O heavens, and give ear, O earth."

*Shim'u shamayim ve-ha'azini eretz*—heaven/earth as witnesses.

"Children I have reared and brought up."

*Banim giddalti ve-romamti*—parental language.

"They have rebelled against me."

*Ve-hem pash'u vi*—rebellion.

"The ox knows its owner."

*Yada shor qonehu*—ox knows owner.

"Israel does not know."

*Yisra'el lo yada*—Israel doesn't know.

**The Key Verse (1:4):**
"The Holy One of Israel."

*Qedosh Yisra'el*—Isaiah's distinctive title for YHWH (26 times).

**Disease Imagery (1:5-6):**
"The whole head is sick, and the whole heart faint."

*Kol-rosh la-choli ve-khol-levav davvai*—comprehensive sickness.

"From the sole of the foot even unto the head there is no soundness."

*Mi-kaf-regel ve-ad-rosh ein-bo metom*—total infection.

**The Remnant (1:9):**
"Except YHWH of hosts had left unto us a very small remnant."

*Lulei YHWH Tzeva'ot hotir lanu sarid kim'at*—remnant theology.

"We should have been as Sodom."

*Ki-Sedom hayinu*—Sodom comparison.

**The Key Verses (1:11-17):**
"To what purpose is the multitude of your sacrifices unto me?"

*Lammah-li rov-zivchekhem*—sacrifice questioned.

"I am full of the burnt-offerings of rams."

*Sava'ti olot eilim*—satiated.

"I cannot endure iniquity along with the solemn assembly."

*Lo-ukhal aven va-atzarah*—can't combine sin and worship.

"Your hands are full of blood."

*Yedeikhem damim male'u*—blood-filled hands.

"Wash you, make you clean."

*Rachatzu hizzakku*—cleansing command.

"Learn to do well; seek justice."

*Limdu hetev dirshu mishpat*—ethical mandate.

"Relieve the oppressed, judge the fatherless, plead for the widow."

*Ashru chamotz shiftu yatom rivu almanah*—social justice triad.

**The Key Verse (1:18):**
"Come now, and let us reason together."

*Lekhu-na ve-nivvakhechah*—invitation to reason.

"Though your sins be as scarlet, they shall be as white as snow."

*Im-yihyu chata'eikhem ka-shanim ka-sheleg yalvinu*—scarlet to snow.

"Though they be red like crimson, they shall be as wool."

*Im-ya'dimu kha-tola ka-tzemer yihyu*—crimson to wool.

**Harlot City (1:21-26):**
"How is the faithful city become a harlot!"

*Eikhah haytah le-zonah qiryah ne'emanah*—faithful to harlot.

"She that was full of justice."

*Male'ati mishpat*—once just.

"Righteousness lodged in her."

*Tzedeq yalin bah*—righteousness resided.

"But now murderers."

*Ve-attah meratzchim*—now murderers.

"Your silver is become dross."

*Kaspekh hayah le-sigim*—silver to dross.

"Your wine mixed with water."

*Sov'ekh mahul ba-mayim*—watered wine.

"I will restore your judges as at the first."

*Ve-ashivah shofetayikh ke-va-rishonah*—restored judges.

"Afterward you shall be called The city of righteousness."

*Acharei-khen yiqqare lakh ir ha-tzedeq*—righteous city.

"Zion shall be redeemed with justice."

*Tziyyon be-mishpat tippaddeh*—justice-redemption.

**Archetypal Layer:** Isaiah 1 is the **prologue/summary** of Isaiah's message: rebellion despite YHWH's care, worthless worship while practicing injustice, the offer of cleansing, and Zion's future redemption through justice.

**Ethical Inversion Applied:**
- "Children I have reared and brought up, and they have rebelled"—parental metaphor
- "The ox knows its owner... Israel does not know"—animals > Israel
- "The Holy One of Israel"—Isaiah's distinctive title
- "From the sole of the foot... no soundness"—total sickness
- "Except YHWH of hosts had left unto us a very small remnant"—remnant preserved
- "To what purpose is the multitude of your sacrifices?"—sacrifice questioned
- "I cannot endure iniquity along with the solemn assembly"—ethics and worship
- "Your hands are full of blood"—blood-guilt
- "Wash you, make you clean"—cleansing command
- "Learn to do well; seek justice"—ethical mandate
- "Relieve the oppressed, judge the fatherless, plead for the widow"—social triad
- "Though your sins be as scarlet, they shall be as white as snow"—cleansing offer
- "How is the faithful city become a harlot"—city as prostitute
- "I will restore your judges as at the first"—restoration promise
- "Zion shall be redeemed with justice"—justice-redemption

**Modern Equivalent:** Isaiah 1's critique of worship without justice (1:11-17) is foundational for prophetic ethics. The "scarlet to snow" offer (1:18) shows transformation is possible. Social justice (orphan, widow, oppressed) is inseparable from true worship.

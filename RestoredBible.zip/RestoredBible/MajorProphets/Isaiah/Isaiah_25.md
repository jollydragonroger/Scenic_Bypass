# Isaiah 25: The Feast on the Mountain

*From the Hebrew: יְהוָה אֱלֹהַי אַתָּה (YHWH Elohai Attah) — YHWH, You Are My God*

---

## Praise for Deliverance (25:1-5)

**25:1** O YHWH, you are my God,
I will exalt you, I will praise your name,
for you have done wonderful things;
counsels of old, in faithfulness and truth.

**25:2** For you have made of a city a heap,
of a fortified city a ruin;
a castle of strangers to be no city,
it shall never be built.

**25:3** Therefore shall a strong people glorify you,
a city of terrible nations shall fear you.

**25:4** For you have been a stronghold to the poor,
a stronghold to the needy in his distress,
a refuge from the storm, a shadow from the heat;
for the blast of the terrible ones is as a storm against the wall.

**25:5** As the heat in a dry place,
you bring down the noise of strangers;
as the heat by the shadow of a cloud,
the song of the terrible ones is brought low.

---

## The Feast of YHWH (25:6-8)

**25:6** And in this mountain will YHWH of hosts make unto all peoples
a feast of fat things, a feast of wines on the lees,
of fat things full of marrow, of wines on the lees well refined.

**25:7** And he will destroy in this mountain
the face of the covering that is cast over all peoples,
and the veil that is spread over all nations.

**25:8** He will swallow up death forever;
and the Lord YHWH will wipe away tears from off all faces;
and the reproach of his people will he take away from off all the earth;
for YHWH has spoken it.

---

## Waiting for Salvation (25:9-12)

**25:9** And it shall be said in that day:
"Lo, this is our God,
for whom we waited, that he might save us;
this is YHWH, for whom we waited,
we will be glad and rejoice in his salvation."

**25:10** For in this mountain will the hand of YHWH rest;
and Moab shall be trodden down in his place,
as straw is trodden down in the dunghill.

**25:11** And when he shall spread forth his hands in the midst thereof,
as he that swims spreads forth his hands to swim,
his pride shall be brought down together with the cunning of his hands.

**25:12** And the fortress of the high fort of your walls
he has brought down, laid low,
brought to the ground, even to the dust.

---

## Synthesis Notes

**Key Restorations:**

**Praise (25:1-5):**
"O YHWH, you are my God."

*YHWH Elohai attah*—personal confession.

"I will exalt you, I will praise your name."

*Aromimekha odeh shimekha*—exaltation and praise.

"For you have done wonderful things."

*Ki asita pele*—wonderful deeds.

"Counsels of old, in faithfulness and truth."

*Etzot me-rachoq emunah omen*—ancient counsels, faithful and true.

"You have made of a city a heap."

*Ki samta me-ir la-gal*—city to heap.

"Of a fortified city a ruin."

*Qiryah betzurah le-mappelah*—fortress ruined.

"A strong people glorify you."

*Al-ken yekhabdukha am-az*—strong peoples glorify.

"A city of terrible nations shall fear you."

*Qiryat goyim aritzim yira'ukha*—terrible nations fear.

"You have been a stronghold to the poor."

*Ki-hayita ma'oz la-dal*—stronghold for poor.

"A stronghold to the needy in his distress."

*Ma'oz la-evyon ba-tzar-lo*—needy's stronghold.

"A refuge from the storm."

*Machseh mi-zerem*—storm refuge.

"A shadow from the heat."

*Tzel me-chorev*—heat shade.

**The Key Verses (25:6-8):**
"In this mountain will YHWH of hosts make unto all peoples a feast."

*Ve-asah YHWH Tzeva'ot le-khol-ha-ammim ba-har ha-zeh mishteh*—feast for all peoples.

"A feast of fat things."

*Mishteh shemanim*—rich food.

"A feast of wines on the lees."

*Mishteh shemarim*—aged wines.

"Of fat things full of marrow."

*Shemanim memuchayim*—marrow-filled.

"Of wines on the lees well refined."

*Shemarim mezuqqaqim*—refined wines.

**The Key Verse (25:7):**
"He will destroy in this mountain the face of the covering."

*U-villa ba-har ha-zeh penei-ha-lot*—covering destroyed.

"That is cast over all peoples."

*Ha-lot al-kol-ha-ammim*—covering all peoples.

"The veil that is spread over all nations."

*Ve-ha-massekha ha-nesukha al-kol-ha-goyim*—veil on all nations.

**The Key Verse (25:8):**
"He will swallow up death forever."

*Billa ha-mavet la-netzach*—death swallowed. 1 Corinthians 15:54 quotes this.

"The Lord YHWH will wipe away tears from off all faces."

*U-machah Adonai YHWH dim'ah me-al kol-panim*—tears wiped. Revelation 7:17; 21:4 echoes this.

"The reproach of his people will he take away from off all the earth."

*Ve-cherpat ammo yasir me-al kol-ha-aretz*—reproach removed.

"For YHWH has spoken it."

*Ki YHWH dibber*—YHWH has spoken.

**The Key Verse (25:9):**
"'Lo, this is our God, for whom we waited, that he might save us.'"

*Hinneh Eloheinu zeh qivvinu lo ve-yoshi'enu*—waited for salvation.

"'This is YHWH, for whom we waited.'"

*Zeh YHWH qivvinu lo*—waited for YHWH.

"'We will be glad and rejoice in his salvation.'"

*Nagilah ve-nismechah bi-yeshu'ato*—rejoice in salvation.

**Moab's Fall (25:10-12):**
"In this mountain will the hand of YHWH rest."

*Ki-tanuach yad-YHWH ba-har ha-zeh*—YHWH's hand rests.

"Moab shall be trodden down in his place."

*Ve-nidash Mo'av tachtav*—Moab trampled.

"As straw is trodden down in the dunghill."

*Ke-hiddush mathben be-mei madmenah*—straw in manure.

"His pride shall be brought down."

*Ve-hishpil ga'avato*—pride lowered.

"The fortress of the high fort of your walls he has brought down."

*U-mivtzar misgav chomotayikh heshach*—fortress brought down.

**Archetypal Layer:** Isaiah 25 contains **the eschatological feast (25:6)**, **death swallowed (25:8)**—quoted in 1 Corinthians 15:54, and **tears wiped away (25:8)**—echoed in Revelation 7:17; 21:4.

**Ethical Inversion Applied:**
- "O YHWH, you are my God"—personal confession
- "You have done wonderful things"—wonderful deeds
- "Counsels of old, in faithfulness and truth"—ancient faithful plans
- "You have been a stronghold to the poor"—poor protected
- "A stronghold to the needy in his distress"—needy helped
- "A refuge from the storm, a shadow from the heat"—protection imagery
- "In this mountain will YHWH of hosts make unto all peoples a feast"—universal feast
- "A feast of fat things, a feast of wines on the lees"—rich food and wine
- "He will destroy... the covering that is cast over all peoples"—veil removed
- "The veil that is spread over all nations"—universal unveiling
- "He will swallow up death forever"—1 Corinthians 15:54
- "The Lord YHWH will wipe away tears from off all faces"—Revelation 7:17; 21:4
- "The reproach of his people will he take away"—reproach removed
- "'Lo, this is our God, for whom we waited'"—waiting rewarded
- "'We will be glad and rejoice in his salvation'"—salvation joy

**Modern Equivalent:** Isaiah 25's feast (25:6), death swallowed (25:8), and tears wiped (25:8) are foundational to NT eschatology. Paul quotes 25:8 in 1 Corinthians 15:54. Revelation 7:17 and 21:4 echo the tears wiped imagery. The veil removed (25:7) suggests universal revelation.

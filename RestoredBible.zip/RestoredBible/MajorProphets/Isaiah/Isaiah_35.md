# Isaiah 35: The Highway of Holiness

*From the Hebrew: יְשֻׂשׂוּם מִדְבָּר וְצִיָּה (Yesusum Midbar Ve-Tziyyah) — The Wilderness and the Dry Land Shall Be Glad*

---

## The Blooming Wilderness (35:1-2)

**35:1** The wilderness and the dry land shall be glad;
and the desert shall rejoice, and blossom as the rose.

**35:2** It shall blossom abundantly, and rejoice, even with joy and singing;
the glory of Lebanon shall be given unto it,
the excellency of Carmel and Sharon;
they shall see the glory of YHWH, the excellency of our God.

---

## Encouragement to the Weak (35:3-4)

**35:3** Strengthen the weak hands, and make firm the tottering knees.

**35:4** Say to them that are of a fearful heart:
"Be strong, fear not;
behold, your God will come with vengeance,
with the recompense of God he will come and save you."

---

## Healing for the Afflicted (35:5-7)

**35:5** Then the eyes of the blind shall be opened,
and the ears of the deaf shall be unstopped.

**35:6** Then shall the lame man leap as a hart,
and the tongue of the dumb shall sing;
for in the wilderness shall waters break out,
and streams in the desert.

**35:7** And the parched land shall become a pool,
and the thirsty ground springs of water;
in the habitation of jackals herds shall lie down,
it shall be an enclosure for reeds and rushes.

---

## The Highway of Holiness (35:8-10)

**35:8** And a highway shall be there, and a way,
and it shall be called The way of holiness;
the unclean shall not pass over it; but it shall be for those;
the wayfaring men, yea fools, shall not err therein.

**35:9** No lion shall be there, nor shall any ravenous beast go up thereon,
they shall not be found there;
but the redeemed shall walk there;

**35:10** And the ransomed of YHWH shall return,
and come with singing unto Zion,
and everlasting joy shall be upon their heads;
they shall obtain gladness and joy,
and sorrow and sighing shall flee away.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (35:1-2):**
"The wilderness and the dry land shall be glad."

*Yesusum midbar ve-tziyyah*—wilderness glad.

"The desert shall rejoice, and blossom as the rose."

*Ve-tagel aravah ve-tifrach ka-chavatzelet*—desert blooms (chavatzelet = crocus/rose).

"It shall blossom abundantly."

*Paroach tifrach*—abundant blossoming.

"Rejoice, even with joy and singing."

*Ve-tagel af gilat va-rannen*—joyful singing.

"The glory of Lebanon shall be given unto it."

*Kevod ha-Levanon nittan lah*—Lebanon's glory.

"The excellency of Carmel and Sharon."

*Hadar ha-Karmel ve-ha-Sharon*—Carmel/Sharon beauty.

"They shall see the glory of YHWH."

*Hemmah yir'u kevod-YHWH*—see YHWH's glory.

"The excellency of our God."

*Hadar Eloheinu*—God's excellency.

**Encouragement (35:3-4):**
"Strengthen the weak hands."

*Chazzqu yadayim rafot*—strengthen hands.

"Make firm the tottering knees."

*U-virka'yim koshelot ammetzu*—firm knees.

"Say to them that are of a fearful heart."

*Imru le-nimharei-lev*—fearful hearts.

"'Be strong, fear not.'"

*Chizqu al-tira'u*—be strong.

"'Behold, your God will come with vengeance.'"

*Hinneh Eloheikhem naqam yavo*—God comes with vengeance.

"'With the recompense of God he will come and save you.'"

*Gemul Elohim hu yavo ve-yoshia'khem*—God saves.

**The Key Verses (35:5-6):**
"The eyes of the blind shall be opened."

*Az tippaqachnah einei ivrim*—blind see.

"The ears of the deaf shall be unstopped."

*Ve-oznei chereshim tippetachnah*—deaf hear.

"The lame man leap as a hart."

*Az yedalleg ka-ayyal pisse'ach*—lame leap.

"The tongue of the dumb shall sing."

*Ve-taron leshon illem*—mute sing.

"In the wilderness shall waters break out."

*Ki-niv'qe'u va-midbar mayim*—wilderness waters.

"Streams in the desert."

*U-nechalim ba-aravah*—desert streams.

**Transformation (35:7):**
"The parched land shall become a pool."

*Ve-hayah ha-sharav la-agam*—parched to pool.

"The thirsty ground springs of water."

*Ve-tzimmaon le-mabbu'ei mayim*—thirsty to springs.

"In the habitation of jackals herds shall lie down."

*Bi-neveh tannim rivtzah*—jackals' place becomes pasture.

"It shall be an enclosure for reeds and rushes."

*Chatzir le-qaneh va-gome*—reeds and rushes.

**The Key Verses (35:8-10):**
"A highway shall be there, and a way."

*Ve-hayah-sham maslul va-derekh*—highway.

"It shall be called The way of holiness."

*Ve-derekh ha-qodesh yiqqare lah*—holiness way.

"The unclean shall not pass over it."

*Lo-ya'avrenu tame*—unclean excluded.

"But it shall be for those."

*Ve-hu lahem*—for the redeemed.

"The wayfaring men, yea fools, shall not err therein."

*Holekh derekh ve-evilim lo yit'u*—even fools won't stray.

"No lion shall be there."

*Lo-yihyeh sham aryeh*—no lion.

"Nor shall any ravenous beast go up thereon."

*U-feritz chayyot bal-ya'alenah*—no predator.

"They shall not be found there."

*Lo timmatzena sham*—not found.

"The redeemed shall walk there."

*Ve-halekhu ge'ulim*—redeemed walk.

**The Key Verse (35:10):**
"The ransomed of YHWH shall return."

*U-feduyei YHWH yeshuvun*—ransomed return.

"Come with singing unto Zion."

*U-va'u Tziyyon be-rinnah*—singing to Zion.

"Everlasting joy shall be upon their heads."

*Ve-simchat olam al-rosham*—eternal joy.

"They shall obtain gladness and joy."

*Sason ve-simchah yassiggu*—obtain gladness.

"Sorrow and sighing shall flee away."

*Ve-nasu yagon va-anachah*—sorrow flees.

This verse is repeated in Isaiah 51:11.

**Archetypal Layer:** Isaiah 35 is **the counterpart to chapter 34**—from judgment to restoration. The messianic signs (35:5-6) are cited by Jesus in Matthew 11:5 and Luke 7:22. The "highway of holiness" (35:8) is the return route.

**Ethical Inversion Applied:**
- "The wilderness and the dry land shall be glad"—creation rejoices
- "The desert shall rejoice, and blossom as the rose"—desert blooms
- "The glory of Lebanon shall be given unto it"—Lebanon's glory transferred
- "They shall see the glory of YHWH"—divine glory seen
- "Strengthen the weak hands"—encouragement
- "Make firm the tottering knees"—support
- "'Be strong, fear not'"—no fear
- "'Your God will come with vengeance'"—God comes
- "The eyes of the blind shall be opened"—Matthew 11:5
- "The ears of the deaf shall be unstopped"—deaf hear
- "The lame man leap as a hart"—lame leap
- "The tongue of the dumb shall sing"—mute sing
- "In the wilderness shall waters break out"—wilderness watered
- "A highway shall be there"—highway
- "It shall be called The way of holiness"—holiness way
- "The redeemed shall walk there"—redeemed walk
- "The ransomed of YHWH shall return"—ransomed return
- "Come with singing unto Zion"—joyful return
- "Everlasting joy shall be upon their heads"—eternal joy
- "Sorrow and sighing shall flee away"—sorrow ends

**Modern Equivalent:** Isaiah 35's messianic signs (35:5-6) are cited by Jesus when John's disciples ask if he is the Messiah (Matthew 11:5; Luke 7:22). The highway of holiness (35:8) represents the way of salvation. "Sorrow and sighing shall flee away" (35:10) anticipates Revelation 21:4.

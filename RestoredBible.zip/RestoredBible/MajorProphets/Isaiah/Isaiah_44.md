# Isaiah 44: The Folly of Idolatry and Cyrus Named

*From the Hebrew: וְעַתָּה שְׁמַע יַעֲקֹב עַבְדִּי (Ve-Attah Shema Ya'aqov Avdi) — Yet Now Hear, O Jacob My Servant*

---

## Israel Blessed (44:1-5)

**44:1** Yet now hear, O Jacob my servant, and Israel, whom I have chosen.

**44:2** Thus says YHWH that made you, and formed you from the womb, who will help you: Fear not, O Jacob my servant, and you Jeshurun, whom I have chosen.

**44:3** For I will pour water upon the thirsty land, and streams upon the dry ground; I will pour my spirit upon your seed, and my blessing upon your offspring;

**44:4** And they shall spring up among the grass, as willows by the watercourses.

**44:5** One shall say: "I am YHWH's"; and another shall call himself by the name of Jacob; and another shall subscribe with his hand unto YHWH, and surname himself by the name of Israel.

---

## YHWH Alone Is God (44:6-8)

**44:6** Thus says YHWH, the King of Israel, and his Redeemer, YHWH of hosts: I am the first, and I am the last, and beside me there is no God.

**44:7** And who, as I, can proclaim—let him declare it, and set it in order for me—since I appointed the ancient people? And the things that are coming, and that shall come to pass, let them declare.

**44:8** Fear not, neither be afraid; have I not announced unto you of old, and declared it? And you are my witnesses. Is there a God beside me? Yea, there is no Rock; I know not any.

---

## The Folly of Idolatry (44:9-20)

**44:9** They that fashion a graven image are all of them vanity, and their delectable things shall not profit; and their own witnesses see not, nor know; that they may be ashamed.

**44:10** Who has fashioned a god, or molten an image that is profitable for nothing?

**44:11** Behold, all the fellows thereof shall be ashamed; and the craftsmen are of men; let them all be gathered together, let them stand up; they shall fear, they shall be ashamed together.

**44:12** The smith makes an axe, and works in the coals, and fashions it with hammers, and works it with his strong arm; yea, he is hungry, and his strength fails; he drinks no water, and is faint.

**44:13** The carpenter stretches out a line; he marks it out with a pencil; he shapes it with planes, and he marks it out with the compasses, and shapes it after the figure of a man, according to the beauty of a man, to dwell in a house.

**44:14** He hews him down cedars, and takes the holm-tree and the oak, and strengthens for himself one among the trees of the forest; he plants a fir-tree, and the rain does nourish it.

**44:15** Then a man uses it for fuel; and he takes thereof, and warms himself; yea, he kindles it, and bakes bread; yea, he makes a god, and worships it; he makes it a graven image, and falls down thereto.

**44:16** He burns the half thereof in the fire; with the half thereof he eats flesh; he roasts roast, and is satisfied; yea, he warms himself, and says: "Aha, I am warm, I have seen the fire";

**44:17** And the residue thereof he makes a god, even his graven image; he falls down unto it, and worships, and prays unto it, and says: "Deliver me, for you are my god."

**44:18** They know not, neither do they understand; for their eyes are besmeared, that they cannot see, and their hearts, that they cannot understand.

**44:19** And none considers in his heart, neither is there knowledge nor understanding to say: "I have burned the half of it in the fire; yea, also I have baked bread upon the coals thereof; I have roasted flesh and eaten it; and shall I make the residue thereof an abomination? Shall I fall down to the stock of a tree?"

**44:20** He feeds on ashes; a deceived heart has turned him aside, that he cannot deliver his soul, nor say: "Is there not a lie in my right hand?"

---

## Israel Redeemed and Cyrus Named (44:21-28)

**44:21** Remember these things, O Jacob, and Israel, for you are my servant; I have formed you, you are my own servant; O Israel, you shall not be forgotten of me.

**44:22** I have blotted out, as a thick cloud, your transgressions, and, as a cloud, your sins; return unto me, for I have redeemed you.

**44:23** Sing, O heavens, for YHWH has done it; shout, you lowest parts of the earth; break forth into singing, you mountains, O forest, and every tree therein; for YHWH has redeemed Jacob, and does glorify himself in Israel.

**44:24** Thus says YHWH, your Redeemer, and he that formed you from the womb: I am YHWH, that makes all things; that stretched forth the heavens alone; that spread abroad the earth by myself;

**44:25** That frustrates the tokens of the impostors, and makes diviners mad; that turns wise men backward, and makes their knowledge foolish;

**44:26** That confirms the word of his servant, and performs the counsel of his messengers; that says of Jerusalem: "She shall be inhabited"; and of the cities of Judah: "They shall be built, and I will raise up the waste places thereof";

**44:27** That says to the deep: "Be dry, and I will dry up your rivers";

**44:28** That says of Cyrus: "He is my shepherd, and shall perform all my pleasure"; even saying of Jerusalem: "She shall be built"; and to the temple: "Your foundation shall be laid."

---

## Synthesis Notes

**Key Restorations:**

**Israel Addressed (44:1-2):**
"Yet now hear, O Jacob my servant."

*Ve-attah shema Ya'aqov avdi*—servant Jacob.

"Israel, whom I have chosen."

*Ve-Yisra'el bacharti vo*—chosen Israel.

"YHWH that made you, and formed you from the womb."

*YHWH osekha ve-yotzrekha mi-beten*—womb-formed.

"Fear not, O Jacob my servant."

*Al-tira avdi Ya'aqov*—fear not.

"You Jeshurun, whom I have chosen."

*Vi-Yeshurun bacharti vo*—Jeshurun = Israel (poetic name, "upright one").

**The Key Verse (44:3):**
"I will pour water upon the thirsty land."

*Ki-etzoq mayim al-tzame*—water on thirsty.

"Streams upon the dry ground."

*U-nozellim al-yabbashah*—streams on dry.

"I will pour my spirit upon your seed."

*Etzoq ruchi al-zar'ekha*—Spirit on descendants.

"My blessing upon your offspring."

*U-virkhati al-tze'etza'ekha*—blessing on offspring.

**Joining YHWH (44:5):**
"One shall say: 'I am YHWH's.'"

*Zeh yomar la-YHWH ani*—belonging to YHWH.

"Another shall call himself by the name of Jacob."

*Ve-zeh yiqra ve-shem-Ya'aqov*—named by Jacob.

"Another shall subscribe with his hand unto YHWH."

*Ve-zeh yikhtov yado la-YHWH*—hand-writing to YHWH.

"Surname himself by the name of Israel."

*U-ve-shem Yisra'el yekhaneh*—surnamed Israel.

**The Key Verse (44:6):**
"Thus says YHWH, the King of Israel, and his Redeemer, YHWH of hosts."

*Koh-amar YHWH melekh-Yisra'el ve-go'alo YHWH Tzeva'ot*—King and Redeemer.

"I am the first, and I am the last."

*Ani rishon va-ani acharon*—first and last. Revelation 1:17; 22:13 quotes this.

"Beside me there is no God."

*U-mi-bal'adai ein Elohim*—no other God.

**The Key Verse (44:8):**
"Fear not, neither be afraid."

*Al-tifchadu ve-al-tirhu*—don't fear.

"Have I not announced unto you of old, and declared it?"

*Halo me-az hishma'tikha ve-higgadti*—announced beforehand.

"You are my witnesses."

*Ve-attem edai*—witnesses.

"Is there a God beside me?"

*Ha-yesh eloah mi-bal'adai*—is there another?

"Yea, there is no Rock; I know not any."

*Ve-ein tzur bal-yadati*—no Rock unknown.

**Idol Satire (44:9-20):**
"They that fashion a graven image are all of them vanity."

*Yotzrei fesel kullam tohu*—idol-makers = vanity.

"Who has fashioned a god... that is profitable for nothing?"

*Mi-yatzar el u-fesel nasakh le-vilti ho'il*—useless god.

"The smith makes an axe, and works in the coals."

*Charash barzel ma'atzad u-fa'al ba-pecham*—smith works.

"He is hungry, and his strength fails."

*Gam-ra'ev ve-ein ko'ach*—hungry, weak.

"The carpenter stretches out a line."

*Charash etzim natah qav*—carpenter measures.

"He shapes it after the figure of a man."

*Ya'asehu ke-tavnit ish*—man-shaped.

"According to the beauty of a man, to dwell in a house."

*Ke-tif'eret adam le-shevet bayit*—beautiful, housed.

**The Key Verses (44:15-17):**
"He takes thereof, and warms himself."

*Va-yiqqach mehem va-yacham*—fuel for warmth.

"Yea, he kindles it, and bakes bread."

*Af-yassiq ve-afah lachem*—bakes bread.

"Yea, he makes a god, and worships it."

*Af-yif'al-el va-yishtachu*—makes god, worships.

"He makes it a graven image, and falls down thereto."

*Asahu fesel va-yissgod-lamo*—falls before idol.

"He burns the half thereof in the fire."

*Chetzyo saraf be-mo-esh*—half burned.

"With the half thereof he eats flesh."

*Al-chetzyo basar yokhal*—half for food.

"The residue thereof he makes a god."

*U-she'erito le-el asah*—residue becomes god.

"'Deliver me, for you are my god.'"

*Hatzileni ki eli attah*—asking wood for salvation.

**The Key Verses (44:18-20):**
"They know not, neither do they understand."

*Lo yade'u ve-lo yavinu*—no knowledge.

"Their eyes are besmeared, that they cannot see."

*Ki tach me-re'ot eineihem*—blinded eyes.

"Their hearts, that they cannot understand."

*Me-haskil libbotam*—blocked hearts.

"None considers in his heart."

*Ve-lo-yashiv el-libbo*—no reflection.

"'Shall I make the residue thereof an abomination?'"

*Ve-yitro le-to'evah e'eseh*—residue = abomination?

"'Shall I fall down to the stock of a tree?'"

*Le-vul-etz essgod*—worship tree stock?

"He feeds on ashes."

*Ro'eh efer*—feeding on ashes.

"A deceived heart has turned him aside."

*Lev hutal hittahu*—deceived heart.

"He cannot deliver his soul."

*Ve-lo-yatztzil et-nafsho*—can't save self.

"'Is there not a lie in my right hand?'"

*Ha-lo sheqer bi-yemini*—lie in hand.

**Redemption (44:21-23):**
"Remember these things, O Jacob."

*Zekhor-elleh Ya'aqov*—remember.

"I have formed you, you are my own servant."

*Yetzartikha eved-li attah*—formed as servant.

"O Israel, you shall not be forgotten of me."

*Yisra'el lo tinnasheni*—not forgotten.

**The Key Verse (44:22):**
"I have blotted out, as a thick cloud, your transgressions."

*Machiti kha-av pesha'ekha*—transgressions blotted.

"As a cloud, your sins."

*Ukhe-anan chatto'tekha*—sins like cloud.

"Return unto me, for I have redeemed you."

*Shuvah elai ki ge'altikha*—return, redeemed.

**The Key Verse (44:23):**
"Sing, O heavens, for YHWH has done it."

*Ronnu shamayim ki-asah YHWH*—heavens sing.

"Shout, you lowest parts of the earth."

*Hari'u tachtiyyot aretz*—earth shouts.

"Break forth into singing, you mountains."

*Pitzchu harim rinnah*—mountains sing.

"For YHWH has redeemed Jacob."

*Ki-ga'al YHWH Ya'aqov*—Jacob redeemed.

**Cyrus Named (44:24-28):**
"I am YHWH, that makes all things."

*Anokhi YHWH oseh kol*—makes all.

"That stretched forth the heavens alone."

*Noteh shamayim levaddi*—alone stretched heavens.

"That spread abroad the earth by myself."

*Roqa ha-aretz me-itti*—spread earth alone.

"That frustrates the tokens of the impostors."

*Mefer otot baddim*—frustrates false signs.

"Makes diviners mad."

*Ve-qosemim yeholel*—diviners maddened.

"That turns wise men backward."

*Meshiv chakhamim achor*—wise turned back.

"Makes their knowledge foolish."

*Ve-da'tam yesakkel*—knowledge fooled.

"That confirms the word of his servant."

*Meqim devar avdo*—servant's word confirmed.

"That says of Jerusalem: 'She shall be inhabited.'"

*Ha-omer li-Yerushalayim tushav*—Jerusalem inhabited.

**The Key Verse (44:28):**
"That says of Cyrus: 'He is my shepherd.'"

*Ha-omer le-Khoresh ro'i*—Cyrus = my shepherd.

"Shall perform all my pleasure."

*Ve-khol-cheftzi yashlim*—performs YHWH's pleasure.

"Even saying of Jerusalem: 'She shall be built.'"

*Ve-lemor li-Yerushalayim tibbanneh*—Jerusalem built.

"To the temple: 'Your foundation shall be laid.'"

*Ve-heikhal tivvased*—temple founded.

**Archetypal Layer:** Isaiah 44 contains **"I am the first, and I am the last" (44:6)**—Revelation 1:17, **the idol satire (44:9-20)**, **"I have blotted out... your transgressions" (44:22)**, and **Cyrus named as YHWH's shepherd (44:28)**.

**Ethical Inversion Applied:**
- "Yet now hear, O Jacob my servant"—servant addressed
- "You Jeshurun, whom I have chosen"—Jeshurun
- "I will pour my spirit upon your seed"—Spirit poured
- "One shall say: 'I am YHWH's'"—belonging
- "I am the first, and I am the last"—Revelation 1:17
- "Beside me there is no God"—monotheism
- "You are my witnesses"—witness role
- "Is there a God beside me? Yea, there is no Rock"—no other Rock
- "They that fashion a graven image are all of them vanity"—idol satire
- "He burns the half thereof in the fire... the residue thereof he makes a god"—absurdity
- "'Deliver me, for you are my god'"—asking wood for help
- "A deceived heart has turned him aside"—deception
- "'Is there not a lie in my right hand?'"—unasked question
- "I have blotted out, as a thick cloud, your transgressions"—forgiveness
- "Return unto me, for I have redeemed you"—redemption basis
- "Sing, O heavens... shout... break forth into singing"—cosmic praise
- "I am YHWH, that makes all things"—Creator
- "That says of Cyrus: 'He is my shepherd'"—Cyrus named

**Modern Equivalent:** Isaiah 44:6's "I am the first, and I am the last" is applied to Christ in Revelation 1:17; 22:13. The idol satire (44:9-20) is the OT's most detailed mockery of idolatry. Cyrus named by name (44:28) 150 years before his birth is a major prophecy.

# Isaiah 22: The Oracle Concerning the Valley of Vision

*From the Hebrew: מַשָּׂא גֵּיא חִזָּיוֹן (Massa Gei Chizzayon) — The Burden of the Valley of Vision*

---

## Jerusalem's False Celebration (22:1-14)

**22:1** The burden of the Valley of Vision.
What ails you now, that you are wholly gone up to the housetops,

**22:2** You that are full of uproar, a tumultuous city, a joyous town?
Your slain are not slain with the sword, nor dead in battle.

**22:3** All your rulers fled together, without the bow they were bound;
all that were found of you were bound together, they fled afar off.

**22:4** Therefore said I: "Look away from me, I will weep bitterly;
strain not to comfort me, for the destruction of the daughter of my people."

**22:5** For it is a day of trouble, and of trampling, and of perplexity,
from the Lord, YHWH of hosts, in the Valley of Vision;
a breaking down of walls, and a crying to the mountain.

**22:6** And Elam bore the quiver, with troops of men, even horsemen;
and Kir uncovered the shield.

**22:7** And it came to pass, that your choicest valleys were full of chariots,
and the horsemen set themselves in array at the gate.

**22:8** And the covering of Judah was laid bare,
and you did look in that day to the armor in the house of the forest.

**22:9** And you saw the breaches of the city of David, that they were many;
and you gathered together the waters of the lower pool.

**22:10** And you numbered the houses of Jerusalem,
and you broke down the houses to fortify the wall;

**22:11** You made also a reservoir between the two walls for the water of the old pool;
but you looked not unto him that had done this,
neither had you respect unto him that fashioned it long ago.

**22:12** And in that day did the Lord, YHWH of hosts, call to weeping,
and to lamentation, and to baldness, and to girding with sackcloth;

**22:13** And behold joy and gladness, slaying oxen and killing sheep,
eating flesh and drinking wine—
"Let us eat and drink, for tomorrow we shall die."

**22:14** And it was revealed in my ears by YHWH of hosts:
Surely this iniquity shall not be expiated by you till you die,
says the Lord, YHWH of hosts.

---

## Shebna Replaced by Eliakim (22:15-25)

**22:15** Thus says the Lord, YHWH of hosts:
Go, get yourself unto this steward, even unto Shebna, who is over the house:

**22:16** "What have you here, and whom have you here,
that you have hewn out here a tomb for yourself,
you that hew out your tomb on high,
and grave a habitation for yourself in the rock?

**22:17** "Behold, YHWH will hurl you away violently, as a man hurls;
yea, he will wind you round and round.

**22:18** "He will violently roll you like a ball into a large country;
there shall you die, and there shall be the chariots of your glory,
you shame of your lord's house.

**22:19** "And I will thrust you from your post,
and from your station shall you be pulled down."

**22:20** And it shall come to pass in that day,
that I will call my servant Eliakim the son of Hilkiah;

**22:21** And I will clothe him with your robe, and bind him with your girdle,
and I will commit your government into his hand;
and he shall be a father to the inhabitants of Jerusalem,
and to the house of Judah.

**22:22** And the key of the house of David will I lay upon his shoulder;
and he shall open, and none shall shut;
and he shall shut, and none shall open.

**22:23** And I will fasten him as a peg in a sure place;
and he shall be for a throne of glory to his father's house.

**22:24** And they shall hang upon him all the glory of his father's house,
the offspring and the issue, every small vessel,
from the cups to all the jars.

**22:25** In that day, says YHWH of hosts,
shall the peg that was fastened in a sure place be removed,
and be cut down, and fall;
and the burden that was upon it shall be cut off;
for YHWH has spoken it.

---

## Synthesis Notes

**Key Restorations:**

**Title (22:1):**
"The burden of the Valley of Vision."

*Massa gei chizzayon*—Jerusalem (site of prophetic visions).

**False Celebration (22:1-4):**
"What ails you now, that you are wholly gone up to the housetops."

*Mah-llakh efo ki-alit kullakh la-gaggot*—rooftop celebration.

"A tumultuous city, a joyous town."

*Ir homiyyah qiryah allizah*—noisy, joyful.

"Your slain are not slain with the sword."

*Chalalayikh lo chalelei-cherev*—not sword-slain.

"Nor dead in battle."

*Ve-lo metei milchamah*—not battle-dead.

"'Look away from me, I will weep bitterly.'"

*Al-tifnu le-nachameni al-shod bat-ammi*—bitter weeping.

**Siege Preparations (22:5-11):**
"A day of trouble, and of trampling, and of perplexity."

*Yom mehumah u-mevusah u-mevukhah*—triple trouble.

"A breaking down of walls."

*Meqarqar qir*—wall breaking.

"Elam bore the quiver... Kir uncovered the shield."

*Elam nasa ashpah... ve-Qir erah magen*—foreign armies.

"The covering of Judah was laid bare."

*Va-yegal et-masakh Yehudah*—Judah exposed.

"You did look in that day to the armor in the house of the forest."

*Va-tabbetu ba-yom ha-hu el-nesheq beit ha-ya'ar*—armory consulted.

"You saw the breaches of the city of David."

*Ve-et-biq'ei ir-David re'item ki-rabbu*—many breaches.

"You gathered together the waters of the lower pool."

*Va-tiqbetzu et-mei ha-berekhah ha-tachtonah*—water gathered.

**The Key Verse (22:11):**
"But you looked not unto him that had done this."

*Ve-el-osah lo hibbattem*—didn't look to God.

"Neither had you respect unto him that fashioned it long ago."

*Ve-yotzrah me-rachoq lo re'item*—didn't see the Fashioner.

**Called to Mourn (22:12-14):**
"The Lord... call to weeping, and to lamentation, and to baldness."

*Va-yiqra Adonai YHWH Tzeva'ot ba-yom ha-hu li-vekhi u-le-misped u-le-qorchah*—called to mourn.

"And to girding with sackcloth."

*Ve-la-chagor saq*—sackcloth.

**The Key Verse (22:13):**
"And behold joy and gladness, slaying oxen and killing sheep."

*Ve-hinneh sason ve-simchah harog baqar ve-shachat tzon*—instead: feasting.

"Eating flesh and drinking wine."

*Akhol basar ve-shatot yayin*—eating and drinking.

"'Let us eat and drink, for tomorrow we shall die.'"

*Akhol ve-shato ki machar namut*—fatalistic hedonism. 1 Corinthians 15:32 quotes this.

**The Key Verse (22:14):**
"This iniquity shall not be expiated by you till you die."

*Im-yekhupper ha-avon ha-zeh lakhem ad-temutun*—unforgiven until death.

**Shebna Demoted (22:15-19):**
"This steward, even unto Shebna, who is over the house."

*Ha-sokhen ha-zeh al-Shevna asher al-ha-bayit*—Shebna, palace steward.

"'What have you here... that you have hewn out here a tomb for yourself.'"

*Mah-llekha foh u-mi lekha foh ki-chatsavta lekha foh qever*—self-made tomb.

"'YHWH will hurl you away violently.'"

*YHWH metaltelekha taltelah gaver*—hurled away.

"'He will violently roll you like a ball into a large country.'"

*Tzanof yitznofkha tzenefah ke-kaddur el-eretz rachavat yadayim*—rolled like ball.

"'There shall you die.'"

*Shammah tamut*—die in exile.

"'I will thrust you from your post.'"

*Va-hadaftikha mi-matzavekha*—thrust from post.

**Eliakim Elevated (22:20-24):**
"I will call my servant Eliakim the son of Hilkiah."

*Ve-qarati le-avdi le-Elyaqim ben-Chilqiyahu*—servant called.

"I will clothe him with your robe, and bind him with your girdle."

*Ve-hilbashtiv kuttonetekha ve-avnetekha achazqennu*—Shebna's clothes.

"I will commit your government into his hand."

*U-memshalttekha etten be-yado*—government given.

"He shall be a father to the inhabitants of Jerusalem."

*Ve-hayah le-av le-yoshev Yerushalayim*—father to Jerusalem.

**The Key Verse (22:22):**
"The key of the house of David will I lay upon his shoulder."

*Ve-natatti mafteach beit-David al-shikhmo*—Davidic key.

"He shall open, and none shall shut."

*U-fatach ve-ein soger*—opening authority.

"And he shall shut, and none shall open."

*Ve-sagar ve-ein pote'ach*—closing authority.

This is quoted in Revelation 3:7 concerning Christ.

**Peg Imagery (22:23-25):**
"I will fasten him as a peg in a sure place."

*U-teqa'tiv yated bi-maqom ne'eman*—secure peg.

"He shall be for a throne of glory to his father's house."

*Ve-hayah le-khisse khavod le-veit aviv*—glory throne.

"They shall hang upon him all the glory of his father's house."

*Ve-talu alav kol kevod beit-aviv*—glory hung.

"The peg that was fastened in a sure place be removed."

*Ba-yom ha-hu... tamush ha-yated ha-tequ'ah be-maqom ne'eman*—peg removed.

**Archetypal Layer:** Isaiah 22 contains **"let us eat and drink, for tomorrow we die" (22:13)**—quoted in 1 Corinthians 15:32—and **the key of David (22:22)**—quoted in Revelation 3:7.

**Ethical Inversion Applied:**
- "The burden of the Valley of Vision"—Jerusalem
- "What ails you now, that you are wholly gone up to the housetops"—false celebration
- "Your slain are not slain with the sword"—different death
- "Look away from me, I will weep bitterly"—prophetic grief
- "A day of trouble, and of trampling, and of perplexity"—triple trouble
- "You looked not unto him that had done this"—didn't look to God
- "The Lord... call to weeping"—called to mourn
- "'Let us eat and drink, for tomorrow we shall die'"—1 Corinthians 15:32
- "This iniquity shall not be expiated by you till you die"—unforgivable
- "YHWH will hurl you away violently"—Shebna expelled
- "I will call my servant Eliakim"—Eliakim elevated
- "The key of the house of David will I lay upon his shoulder"—Revelation 3:7
- "He shall open, and none shall shut"—absolute authority
- "I will fasten him as a peg in a sure place"—secure position

**Modern Equivalent:** Isaiah 22:13's fatalistic hedonism is quoted by Paul (1 Corinthians 15:32). The "key of David" (22:22) is applied to Christ in Revelation 3:7. The failure to look to God amid crisis (22:11) remains a warning.

# Isaiah 48: Refined in the Furnace of Affliction

*From the Hebrew: שִׁמְעוּ־זֹאת בֵּית יַעֲקֹב (Shim'u-Zot Beit Ya'aqov) — Hear This, O House of Jacob*

---

## Israel's Stubbornness (48:1-11)

**48:1** Hear this, O house of Jacob, who are called by the name of Israel, and are come forth out of the waters of Judah; who swear by the name of YHWH, and make mention of the God of Israel, but not in truth, nor in righteousness.

**48:2** For they call themselves of the holy city, and stay themselves upon the God of Israel; YHWH of hosts is his name.

**48:3** I have declared the former things from of old; yea, they went forth out of my mouth, and I announced them; suddenly I did them, and they came to pass.

**48:4** Because I knew that you are obstinate, and your neck is an iron sinew, and your brow brass;

**48:5** Therefore I have declared it to you from of old; before it came to pass I announced it to you; lest you should say: "My idol has done them, and my graven image, and my molten image, has commanded them."

**48:6** You have heard, see all this; and will you not declare it? I have announced to you new things from this time, even hidden things, which you have not known.

**48:7** They are created now, and not from of old, and before this day you heard them not; lest you should say: "Behold, I knew them."

**48:8** Yea, you heard not; yea, you knew not; yea, from of old your ear was not opened; for I knew that you would deal very treacherously, and were called a transgressor from the womb.

**48:9** For my name's sake will I defer my anger, and for my praise will I refrain for you, that I cut you not off.

**48:10** Behold, I have refined you, but not as silver; I have tried you in the furnace of affliction.

**48:11** For my own sake, for my own sake, will I do it; for how should it be profaned? And my glory will I not give to another.

---

## YHWH's Call and Purpose (48:12-16)

**48:12** Hearken unto me, O Jacob, and Israel my called: I am he; I am the first, I also am the last.

**48:13** My hand also has laid the foundation of the earth, and my right hand has spread out the heavens; when I call unto them, they stand up together.

**48:14** Assemble yourselves, all of you, and hear; who among them has declared these things? He whom YHWH loves shall perform his pleasure on Babylon, and his arm shall be on the Chaldeans.

**48:15** I, even I, have spoken, yea, I have called him; I have brought him, and he shall make his way prosperous.

**48:16** Come near unto me, hear this: From the beginning I have not spoken in secret; from the time that it was, there am I; and now the Lord YHWH has sent me, and his spirit.

---

## The Way of Peace (48:17-22)

**48:17** Thus says YHWH, your Redeemer, the Holy One of Israel: I am YHWH your God, who teaches you for your profit, who leads you by the way that you should go.

**48:18** Oh that you had hearkened to my commandments! Then would your peace have been as a river, and your righteousness as the waves of the sea;

**48:19** Your seed also would have been as the sand, and the offspring of your body like the grains thereof; his name would not be cut off nor destroyed from before me.

**48:20** Go forth from Babylon, flee from the Chaldeans; with a voice of singing declare, tell this, utter it even to the end of the earth; say: "YHWH has redeemed his servant Jacob."

**48:21** And they thirsted not when he led them through the deserts; he caused the waters to flow out of the rock for them; he cleaved the rock also, and the waters gushed out.

**48:22** There is no peace, says YHWH, unto the wicked.

---

## Synthesis Notes

**Key Restorations:**

**Israel's Stubbornness (48:1-2):**
"Hear this, O house of Jacob."

*Shim'u-zot beit Ya'aqov*—Jacob addressed.

"Who are called by the name of Israel."

*Ha-niqre'im be-shem Yisra'el*—called Israel.

"Come forth out of the waters of Judah."

*U-mi-mei Yehudah yatza'u*—from Judah's waters.

"Who swear by the name of YHWH."

*Ha-nishba'im be-shem YHWH*—swearing by YHWH.

"Make mention of the God of Israel."

*U-ve-Elohei Yisra'el yazkiru*—mentioning God.

"But not in truth, nor in righteousness."

*Lo be-emet ve-lo bi-tzedaqah*—without truth/righteousness.

"They call themselves of the holy city."

*Ki me-ir ha-qodesh niqra'u*—holy city claim.

"Stay themselves upon the God of Israel."

*Ve-al-Elohei Yisra'el nismakhu*—leaning on God.

**Prophecy Announced (48:3-5):**
"I have declared the former things from of old."

*Ha-rishonot me-az higgadti*—former things declared.

"They went forth out of my mouth, and I announced them."

*U-mi-pi yatze'u va-ashmi'em*—mouth-spoken.

"Suddenly I did them, and they came to pass."

*Pitom asiti va-tavona*—sudden fulfillment.

**The Key Verse (48:4):**
"Because I knew that you are obstinate."

*Mi-da'ti ki qasheh attah*—obstinate known.

"Your neck is an iron sinew."

*Ve-gid barzel orpekha*—iron sinew neck.

"Your brow brass."

*U-mitzchakha nechushab*—brass forehead.

"Therefore I have declared it to you from of old."

*Va-aggid lekha me-az*—declared beforehand.

"Before it came to pass I announced it to you."

*Be-terem tavo hishma'tikha*—announced before.

"'Lest you should say: "My idol has done them."'"

*Pen-tomar atzbi asam*—prevent idol credit.

**New Things (48:6-8):**
"I have announced to you new things from this time."

*Hishma'tikha chadashot me-attah*—new things announced.

"Even hidden things, which you have not known."

*U-netzurot ve-lo yeda'tam*—hidden, unknown.

"They are created now, and not from of old."

*Attah nivra'u ve-lo me-az*—newly created.

"Before this day you heard them not."

*Ve-lifnei yom ve-lo shema'tam*—not heard before.

"From of old your ear was not opened."

*Gam me-az lo-niftechah oznekha*—ear not opened.

"I knew that you would deal very treacherously."

*Ki yadati bagod tivgod*—treachery known.

"Were called a transgressor from the womb."

*U-foshe'a mi-beten qora lakh*—womb-transgressor.

**The Key Verses (48:9-11):**
"For my name's sake will I defer my anger."

*Lema'an shemi a'arik appi*—anger deferred for name.

"For my praise will I refrain for you."

*Ve-tehillati echetam lakh*—refrained for praise.

"That I cut you not off."

*Le-vilti hakhritek*—not cut off.

**The Key Verse (48:10):**
"I have refined you, but not as silver."

*Hinneh tzerattikha ve-lo va-khasef*—refined, not as silver.

"I have tried you in the furnace of affliction."

*Bechartikha be-khur oni*—furnace of affliction.

**The Key Verse (48:11):**
"For my own sake, for my own sake, will I do it."

*Lema'ani lema'ani e'eseh*—double "for my sake."

"For how should it be profaned?"

*Ki eikh yechal*—how be profaned?

"My glory will I not give to another."

*U-khevodi le-acher lo-etten*—glory not given to another.

**First and Last (48:12-16):**
"Hearken unto me, O Jacob, and Israel my called."

*Shema elai Ya'aqov ve-Yisra'el meqora'i*—called Israel.

**The Key Verse (48:12):**
"I am he; I am the first, I also am the last."

*Ani-hu ani rishon af ani acharon*—first and last.

"My hand also has laid the foundation of the earth."

*Af-yadi yasdah eretz*—founded earth.

"My right hand has spread out the heavens."

*Vi-yemini tippechah shamayim*—spread heavens.

"When I call unto them, they stand up together."

*Qore ani aleihem ya'amdu yachdav*—stand when called.

"He whom YHWH loves shall perform his pleasure on Babylon."

*YHWH ahevo ya'aseh cheftzo be-Bavel*—Cyrus performs YHWH's will.

**The Key Verse (48:16):**
"From the beginning I have not spoken in secret."

*Me-rosh lo va-seter dibbarti*—not in secret.

"From the time that it was, there am I."

*Me-et heyotah sham ani*—present from beginning.

"And now the Lord YHWH has sent me, and his spirit."

*Ve-attah Adonai YHWH shelachani ve-rucho*—sent with Spirit.

**Translation Note:**
48:16b is remarkable—the speaker shifts to being sent by YHWH with his Spirit. Some see this as the Servant speaking; others see a Trinitarian hint.

**Peace Like a River (48:17-22):**
"I am YHWH your God, who teaches you for your profit."

*Ani YHWH Elohekha melammedkha le-ho'il*—profitable teaching.

"Who leads you by the way that you should go."

*Madrikhekha be-derekh telekh*—guided way.

**The Key Verses (48:18-19):**
"Oh that you had hearkened to my commandments!"

*Lu hiqshavta le-mitzvotai*—if only listened!

"Then would your peace have been as a river."

*Va-yehi kha-nahar shelomekha*—peace like river.

"Your righteousness as the waves of the sea."

*Ve-tzidqatekha ke-gallei ha-yam*—righteousness like waves.

"Your seed also would have been as the sand."

*Va-yehi kha-chol zar'ekha*—seed like sand.

"The offspring of your body like the grains thereof."

*Ve-tze'etza'ei me'ekha ki-me'otav*—offspring like grains.

"His name would not be cut off."

*Lo-yikkaret ve-lo-yishmmed shemo*—name not cut off.

**The Key Verse (48:20):**
"Go forth from Babylon, flee from the Chaldeans."

*Tze'u mi-Bavel birchu mi-Kasdim*—leave Babylon.

"With a voice of singing declare."

*Be-qol rinnah haggidu*—singing declaration.

"'YHWH has redeemed his servant Jacob.'"

*Ga'al YHWH avdo Ya'aqov*—Jacob redeemed.

**Exodus Imagery (48:21):**
"They thirsted not when he led them through the deserts."

*Ve-lo tzame'u ba-choravot holikham*—no thirst.

"He caused the waters to flow out of the rock for them."

*Mayim mi-tzur hizzil lamo*—water from rock.

"He cleaved the rock also, and the waters gushed out."

*Va-yivqa-tzur va-yazuvu mayim*—rock cleaved, water gushed.

**The Key Verse (48:22):**
"There is no peace, says YHWH, unto the wicked."

*Ein shalom amar YHWH la-resha'im*—no peace for wicked.

This verse ends the first section of Second Isaiah (chapters 40-48). It's repeated at 57:21.

**Archetypal Layer:** Isaiah 48 concludes the first section of Second Isaiah with **"I am the first, I also am the last" (48:12)**, **the furnace of affliction (48:10)**, **"peace as a river" (48:18)**, and **"Go forth from Babylon" (48:20)**.

**Ethical Inversion Applied:**
- "Who swear by the name of YHWH... but not in truth"—false swearing
- "They call themselves of the holy city"—holy city claim
- "I have declared the former things from of old"—prophecy
- "Because I knew that you are obstinate"—stubbornness known
- "Your neck is an iron sinew, and your brow brass"—stiff neck
- "Lest you should say: 'My idol has done them'"—prevent idol credit
- "I have announced to you new things"—new things
- "I knew that you would deal very treacherously"—treachery anticipated
- "For my name's sake will I defer my anger"—name-sake action
- "I have refined you... in the furnace of affliction"—refining purpose
- "For my own sake, for my own sake, will I do it"—double emphasis
- "I am he; I am the first, I also am the last"—first and last
- "The Lord YHWH has sent me, and his spirit"—sent with Spirit
- "Oh that you had hearkened to my commandments!"—conditional blessing
- "Then would your peace have been as a river"—river peace
- "Your righteousness as the waves of the sea"—sea-wave righteousness
- "Go forth from Babylon, flee from the Chaldeans"—Babylon exodus
- "'YHWH has redeemed his servant Jacob'"—redemption announcement
- "He caused the waters to flow out of the rock"—new Exodus
- "There is no peace, says YHWH, unto the wicked"—section conclusion

**Modern Equivalent:** Isaiah 48:12's "I am the first, I also am the last" echoes throughout Revelation. The "furnace of affliction" (48:10) describes purifying trials. "Peace as a river" (48:18) is a beloved conditional promise. "There is no peace... unto the wicked" (48:22) ends section one of Second Isaiah.

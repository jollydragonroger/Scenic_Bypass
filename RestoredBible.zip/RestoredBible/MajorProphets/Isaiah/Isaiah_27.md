# Isaiah 27: Leviathan Slain and Israel Restored

*From the Hebrew: בַּיּוֹם הַהוּא יִפְקֹד יְהוָה (Ba-Yom Ha-Hu Yifqod YHWH) — In That Day YHWH Will Punish*

---

## The Slaying of Leviathan (27:1)

**27:1** In that day YHWH with his hard and great and strong sword
will punish leviathan the fleeing serpent,
and leviathan the crooked serpent;
and he will slay the dragon that is in the sea.

---

## The Pleasant Vineyard (27:2-6)

**27:2** In that day sing unto her: "A vineyard of foaming wine!

**27:3** "I YHWH do guard it, I water it every moment;
lest any hurt it, I guard it night and day.

**27:4** "Fury is not in me;
would that the briers and thorns were against me in battle!
I would march upon them, I would burn them together.

**27:5** "Or else let him take hold of my stronghold,
let him make peace with me;
yea, let him make peace with me."

**27:6** In days to come shall Jacob take root,
Israel shall blossom and bud;
and the face of the world shall be filled with fruit.

---

## Israel's Chastisement (27:7-11)

**27:7** Has he smitten him as he smote those that smote him?
Or is he slain according to the slaughter of them that were slain by him?

**27:8** In measure, when you send her away, you contend with her;
he has removed her with his rough blast in the day of the east wind.

**27:9** Therefore by this shall the iniquity of Jacob be expiated,
and this is all the fruit of taking away his sin:
when he makes all the stones of the altar as chalkstones that are beaten in pieces,
so that the Asherim and the sun-images shall rise no more.

**27:10** For the fortified city is solitary, a habitation abandoned and forsaken, like the wilderness;
there shall the calf feed, and there shall he lie down, and consume the branches thereof.

**27:11** When the boughs thereof are withered, they shall be broken off;
the women shall come, and set them on fire;
for it is a people of no understanding;
therefore he that made them will not have compassion upon them,
and he that formed them will show them no favor.

---

## The Great Ingathering (27:12-13)

**27:12** And it shall come to pass in that day,
that YHWH will beat off his fruit from the channel of the River unto the brook of Egypt,
and you shall be gathered one by one, O children of Israel.

**27:13** And it shall come to pass in that day,
that a great horn shall be blown;
and they shall come that were lost in the land of Assyria,
and they that were dispersed in the land of Egypt;
and they shall worship YHWH in the holy mountain at Jerusalem.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verse (27:1):**
"In that day YHWH with his hard and great and strong sword will punish leviathan."

*Ba-yom ha-hu yifqod YHWH be-charbo ha-qashah ve-ha-gedolah ve-ha-chazaqah al livyatan*—Leviathan punished.

"Leviathan the fleeing serpent."

*Livyatan nachash bariach*—fleeing serpent.

"Leviathan the crooked serpent."

*Ve-al livyatan nachash aqallaton*—twisting serpent.

"He will slay the dragon that is in the sea."

*Ve-harag et-ha-tannin asher ba-yam*—sea dragon slain.

**Translation Note:**
Leviathan represents primordial chaos and cosmic evil. This echoes Ancient Near Eastern combat myths (Baal vs. Yam, Marduk vs. Tiamat) but transforms them—YHWH defeats chaos definitively.

**The Pleasant Vineyard (27:2-6):**
"In that day sing unto her: 'A vineyard of foaming wine!'"

*Ba-yom ha-hu kerem chemer annu-lah*—pleasant vineyard.

"I YHWH do guard it."

*Ani YHWH notzrah*—YHWH guards.

"I water it every moment."

*Li-rega'im ashqennah*—constant watering.

"Lest any hurt it, I guard it night and day."

*Pen yifqod alekha laylah va-yom etztzrennah*—night/day guarding.

"Fury is not in me."

*Chemah ein li*—no fury.

"Would that the briers and thorns were against me in battle!"

*Mi-yitteneni shamir shayit ba-milchamah*—desires to fight thorns.

"I would burn them together."

*Atzi'enah yachad*—burn together.

"Or else let him take hold of my stronghold."

*O yachazek be-ma'uzzi*—take hold of refuge.

"Let him make peace with me."

*Ya'aseh shalom li*—make peace.

**The Key Verse (27:5):**
"Let him make peace with me; yea, let him make peace with me."

*Ya'aseh shalom li shalom ya'aseh-li*—peace twice offered.

**The Key Verse (27:6):**
"In days to come shall Jacob take root."

*Ha-ba'im yashresh Ya'aqov*—Jacob rooted.

"Israel shall blossom and bud."

*Yatzitz u-farach Yisra'el*—Israel blooms.

"The face of the world shall be filled with fruit."

*U-male'u fenei-tevel tenuvah*—world filled with fruit.

**Contrast with Isaiah 5:**
Chapter 5 has the vineyard producing wild grapes and being destroyed. Chapter 27 has YHWH tenderly guarding and watering—restoration.

**Chastisement (27:7-11):**
"Has he smitten him as he smote those that smote him?"

*Ha-ke-makkat makkehu hikkahu*—different treatment.

"In measure, when you send her away, you contend with her."

*Be-sa'se'ah be-shallechah terivennah*—measured discipline.

"He has removed her with his rough blast in the day of the east wind."

*Hagah be-rucho ha-qashah be-yom qadim*—east wind removal.

**The Key Verse (27:9):**
"By this shall the iniquity of Jacob be expiated."

*Lakhen be-zot yekhupper avon-Ya'aqov*—iniquity expiated.

"When he makes all the stones of the altar as chalkstones."

*Be-sumo kol-avnei mizbe'ach ke-avnei-gir*—altar stones crushed.

"The Asherim and the sun-images shall rise no more."

*Lo-yaqumu asherim ve-chammanim*—idols ended.

**Fortified City (27:10-11):**
"The fortified city is solitary."

*Ki ir betzurah badad*—lonely fortified city.

"A habitation abandoned and forsaken."

*Naveh meshullach ve-ne'ezav*—abandoned.

"For it is a people of no understanding."

*Ki lo am-binot hu*—no understanding.

"He that made them will not have compassion upon them."

*Al-ken lo-yerachamennu osehu*—no compassion.

"He that formed them will show them no favor."

*Ve-yotzro lo yechunnenu*—no favor.

**The Key Verses (27:12-13):**
"YHWH will beat off his fruit from the channel of the River unto the brook of Egypt."

*Yachbot YHWH mi-shibbolet ha-nahar ad-nachal Mitzrayim*—threshing from Euphrates to Egypt.

"You shall be gathered one by one, O children of Israel."

*Ve-attem teluqqetu le-achad echad benei Yisra'el*—one-by-one gathering.

**The Key Verse (27:13):**
"A great horn shall be blown."

*Yittaqa be-shofar gadol*—great shofar.

"They shall come that were lost in the land of Assyria."

*U-va'u ha-ovedim be-eretz Ashshur*—Assyrian exiles return.

"They that were dispersed in the land of Egypt."

*Ve-ha-nidachim be-eretz Mitzrayim*—Egyptian exiles return.

"They shall worship YHWH in the holy mountain at Jerusalem."

*Ve-hishtachavu la-YHWH be-har ha-qodesh bi-Yerushalayim*—Jerusalem worship.

**Archetypal Layer:** Isaiah 27 concludes the "Isaiah Apocalypse" (chapters 24-27) with **Leviathan slain (27:1)**, **the restored vineyard (27:2-6)**, and **the great shofar ingathering (27:12-13)**.

**Ethical Inversion Applied:**
- "YHWH... will punish leviathan the fleeing serpent"—chaos defeated
- "He will slay the dragon that is in the sea"—sea dragon killed
- "'A vineyard of foaming wine'"—pleasant vineyard (contrast chapter 5)
- "I YHWH do guard it, I water it every moment"—constant care
- "Fury is not in me"—no anger
- "'Let him make peace with me'"—peace offered
- "In days to come shall Jacob take root"—future rooting
- "Israel shall blossom and bud"—blooming
- "The face of the world shall be filled with fruit"—world-fruit
- "In measure, when you send her away, you contend with her"—measured discipline
- "By this shall the iniquity of Jacob be expiated"—expiation
- "The Asherim and the sun-images shall rise no more"—idols ended
- "YHWH will beat off his fruit... you shall be gathered one by one"—careful gathering
- "A great horn shall be blown"—great shofar
- "They shall come that were lost... they that were dispersed"—exile return
- "They shall worship YHWH in the holy mountain at Jerusalem"—Jerusalem worship

**Modern Equivalent:** Isaiah 27:1's Leviathan-slaying is cosmic eschatology—YHWH defeats chaos. The great shofar (27:13) anticipates the "last trumpet" (1 Corinthians 15:52; 1 Thessalonians 4:16). The one-by-one gathering (27:12) shows individual care in redemption.

---

## Section Summary: Isaiah 24-27 (The Isaiah Apocalypse)

Chapters 24-27 form Isaiah's apocalyptic section:

**Structure:**
- **Chapter 24**: Universal judgment, cosmic upheaval, YHWH reigns
- **Chapter 25**: Feast on the mountain, death swallowed, tears wiped
- **Chapter 26**: Song of trust, perfect peace, resurrection promise
- **Chapter 27**: Leviathan slain, vineyard restored, great ingathering

**Major Themes:**
- **Cosmic scope**—not just nations but the whole earth
- **Death defeated** (25:8)—1 Corinthians 15:54
- **Resurrection promised** (26:19)—bodies arise
- **Chaos conquered** (27:1)—Leviathan slain
- **Universal feast** (25:6)—all peoples invited
- **Perfect peace** (26:3)—for the trusting mind
- **Great shofar** (27:13)—final ingathering

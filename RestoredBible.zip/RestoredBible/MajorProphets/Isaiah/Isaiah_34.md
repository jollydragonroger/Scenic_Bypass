# Isaiah 34: The Day of YHWH's Vengeance

*From the Hebrew: קִרְבוּ גוֹיִם לִשְׁמֹעַ (Qirvu Goyim Lishmo'a) — Come Near, You Nations, to Hear*

---

## Universal Judgment (34:1-4)

**34:1** Come near, you nations, to hear,
and attend, you peoples;
let the earth hear, and the fullness thereof,
the world, and all things that come forth of it.

**34:2** For YHWH has indignation against all the nations,
and fury against all their host;
he has utterly destroyed them, he has delivered them to the slaughter.

**34:3** Their slain also shall be cast out,
and the stench of their carcasses shall come up,
and the mountains shall be melted with their blood.

**34:4** And all the host of heaven shall moulder away,
and the heavens shall be rolled together as a scroll;
and all their host shall fade away,
as the leaf fades from off the vine,
and as a fading leaf from the fig-tree.

---

## Judgment on Edom (34:5-17)

**34:5** For my sword has drunk its fill in heaven;
behold, it shall come down upon Edom,
and upon the people of my ban, to judgment.

**34:6** The sword of YHWH is filled with blood,
it is made fat with fatness,
with the blood of lambs and goats,
with the fat of the kidneys of rams;
for YHWH has a sacrifice in Bozrah,
and a great slaughter in the land of Edom.

**34:7** And the wild-oxen shall come down with them,
and the bullocks with the bulls;
and their land shall be drunken with blood,
and their dust made fat with fatness.

**34:8** For it is the day of YHWH's vengeance,
the year of recompense for the controversy of Zion.

**34:9** And the streams thereof shall be turned into pitch,
and the dust thereof into brimstone,
and the land thereof shall become burning pitch.

**34:10** It shall not be quenched night nor day,
the smoke thereof shall go up forever;
from generation to generation it shall lie waste;
none shall pass through it forever and ever.

**34:11** But the pelican and the porcupine shall possess it,
and the owl and the raven shall dwell therein;
and he shall stretch over it the line of confusion,
and the plummet of emptiness.

**34:12** As for her nobles, none shall be there to be called to the kingdom;
and all her princes shall be nothing.

**34:13** And thorns shall come up in her palaces,
nettles and thistles in the fortresses thereof;
and it shall be a habitation of jackals,
a court for ostriches.

**34:14** And the wild-cats shall meet with the jackals,
and the satyr shall cry to his fellow;
yea, the night-monster shall repose there,
and shall find her a place of rest.

**34:15** There shall the arrowsnake make her nest, and lay, and hatch, and brood under her shadow;
yea, there shall the kites be gathered, every one with her mate.

**34:16** Seek out of the book of YHWH, and read;
no one of these shall be missing,
none shall want her mate;
for my mouth, it has commanded,
and his spirit, it has gathered them.

**34:17** And he has cast the lot for them,
and his hand has divided it unto them by line;
they shall possess it forever,
from generation to generation shall they dwell therein.

---

## Synthesis Notes

**Key Restorations:**

**Universal Summons (34:1):**
"Come near, you nations, to hear."

*Qirvu goyim lishmo'a*—nations summoned.

"Attend, you peoples."

*U-le'ummim haqshivu*—peoples attend.

"Let the earth hear, and the fullness thereof."

*Tishma ha-aretz u-melo'ah*—earth hears.

"The world, and all things that come forth of it."

*Tevel ve-khol-tze'etza'ekha*—whole world.

**Universal Judgment (34:2-4):**
"YHWH has indignation against all the nations."

*Ki qetzef la-YHWH al-kol-ha-goyim*—universal wrath.

"Fury against all their host."

*Ve-chemah al-kol-tzeva'am*—fury on hosts.

"He has utterly destroyed them, he has delivered them to the slaughter."

*Hechrimam netanam la-tavach*—devoted to destruction.

"Their slain also shall be cast out."

*Ve-chaleleihem yushallakhu*—bodies cast.

"The stench of their carcasses shall come up."

*U-fighreihem ya'aleh va'asham*—stench rises.

"The mountains shall be melted with their blood."

*Ve-namassu harim mi-damam*—blood-melted mountains.

**The Key Verse (34:4):**
"All the host of heaven shall moulder away."

*Ve-namaqqqu kol-tzeva ha-shamayim*—heavens dissolve.

"The heavens shall be rolled together as a scroll."

*Ve-nagollu kha-sefer ha-shamayim*—heavens rolled like scroll. Revelation 6:14 echoes this.

"All their host shall fade away."

*Ve-khol-tzeva'am yibbol*—host fades.

"As the leaf fades from off the vine."

*Ki-nevol aleh mi-gafen*—vine-leaf fading.

"As a fading leaf from the fig-tree."

*U-khe-novelet mi-te'enah*—fig-leaf fading.

**Edom's Judgment (34:5-8):**
"My sword has drunk its fill in heaven."

*Ki-rivvetah va-shamayim charbi*—sword drunk in heaven.

"It shall come down upon Edom."

*Hinneh al-Edom tered*—descends on Edom.

"Upon the people of my ban, to judgment."

*Ve-al-am chermi le-mishpat*—banned people.

"The sword of YHWH is filled with blood."

*Cherev la-YHWH male'ah dam*—bloody sword.

"YHWH has a sacrifice in Bozrah."

*Ki zevach la-YHWH be-Votzrah*—Bozrah sacrifice.

"A great slaughter in the land of Edom."

*Ve-tevach gadol be-eretz Edom*—Edom slaughter.

**The Key Verse (34:8):**
"It is the day of YHWH's vengeance."

*Ki yom naqam la-YHWH*—vengeance day.

"The year of recompense for the controversy of Zion."

*Shenat shillumim le-riv Tziyyon*—Zion's cause.

**Permanent Desolation (34:9-15):**
"The streams thereof shall be turned into pitch."

*Ve-nehepkhu nechalekha le-zefet*—streams to pitch.

"The dust thereof into brimstone."

*Va-afarah le-gofrit*—dust to brimstone.

"The land thereof shall become burning pitch."

*Ve-haytah artzah li-zefet bo'eret*—burning pitch.

**The Key Verse (34:10):**
"It shall not be quenched night nor day."

*Laylah va-yomam lo tikhbeh*—unquenched fire.

"The smoke thereof shall go up forever."

*Le-olam ya'aleh ashanah*—eternal smoke. Revelation 14:11; 19:3 echo this.

"From generation to generation it shall lie waste."

*Mi-dor le-dor techerav*—perpetual waste.

"None shall pass through it forever and ever."

*Le-netzach netzachim ein over bah*—forever empty.

"The pelican and the porcupine shall possess it."

*Ve-yereshuha qa'at ve-qippod*—animals possess.

"He shall stretch over it the line of confusion."

*Ve-natah alekha qav-tohu*—confusion line.

"The plummet of emptiness."

*Ve-avnei-vohu*—emptiness stones (Genesis 1:2 vocabulary).

"The wild-cats shall meet with the jackals."

*U-faggshu tziyyim et-iyyim*—wild animals meet.

"The satyr shall cry to his fellow."

*Ve-sa'ir al-re'ehu yiqra*—satyrs call.

"The night-monster shall repose there."

*Akh-sham hirgi'ah Lilit*—Lilith rests (night creature).

**The Key Verses (34:16-17):**
"Seek out of the book of YHWH, and read."

*Dirshu me-al sefer-YHWH u-qera'u*—seek and read YHWH's book.

"No one of these shall be missing."

*Achat me-hennah lo ne'derah*—none missing.

"None shall want her mate."

*Ishshshah re'utah lo faqadu*—all paired.

"For my mouth, it has commanded."

*Ki-fi hu tzivvah*—YHWH's mouth commands.

"His spirit, it has gathered them."

*Ve-rucho hi qibbetzam*—Spirit gathers.

"He has cast the lot for them."

*Ve-hu hippil lahen goral*—lot cast.

"His hand has divided it unto them by line."

*Ve-yado chilleqatah lahem ba-qav*—divided by line.

"They shall possess it forever."

*Ad-olam yirashuha*—forever possessed.

**Archetypal Layer:** Isaiah 34 describes **the Day of YHWH's vengeance**, with **heavens rolled like a scroll (34:4)**—Revelation 6:14—and **eternal smoke (34:10)**—Revelation 14:11; 19:3. Edom represents all enemies.

**Ethical Inversion Applied:**
- "Come near, you nations, to hear"—universal summons
- "YHWH has indignation against all the nations"—universal wrath
- "He has utterly destroyed them"—devoted to destruction
- "All the host of heaven shall moulder away"—cosmic dissolution
- "The heavens shall be rolled together as a scroll"—Revelation 6:14
- "My sword has drunk its fill in heaven"—heavenly sword
- "It shall come down upon Edom"—Edom judgment
- "YHWH has a sacrifice in Bozrah"—sacrifice imagery
- "It is the day of YHWH's vengeance"—vengeance day
- "The year of recompense for the controversy of Zion"—Zion vindicated
- "The streams thereof shall be turned into pitch"—Sodom-like
- "It shall not be quenched night nor day"—unquenched
- "The smoke thereof shall go up forever"—Revelation 14:11
- "He shall stretch over it the line of confusion"—tohu va-vohu
- "Seek out of the book of YHWH, and read"—YHWH's book
- "My mouth, it has commanded, and his spirit, it has gathered them"—Word and Spirit

**Modern Equivalent:** Isaiah 34's imagery of heavens rolled like a scroll (34:4) and eternal smoke (34:10) directly influences Revelation. The "book of YHWH" (34:16) implies written prophecy. Edom symbolizes all enemies of God's people.

# Isaiah 36: Sennacherib's Invasion

*From the Hebrew: וַיְהִי בְּאַרְבַּע עֶשְׂרֵה שָׁנָה (Va-Yehi Be-Arba Esreh Shanah) — And It Came to Pass in the Fourteenth Year*

---

## Assyria Invades Judah (36:1-3)

**36:1** Now it came to pass in the fourteenth year of king Hezekiah, that Sennacherib king of Assyria came up against all the fortified cities of Judah, and took them.

**36:2** And the king of Assyria sent Rabshakeh from Lachish to Jerusalem unto king Hezekiah with a great army. And he stood by the conduit of the upper pool in the highway of the fuller's field.

**36:3** Then came forth unto him Eliakim the son of Hilkiah, who was over the household, and Shebna the scribe, and Joah the son of Asaph the recorder.

---

## Rabshakeh's First Speech (36:4-10)

**36:4** And Rabshakeh said unto them: "Say now to Hezekiah: Thus says the great king, the king of Assyria: What confidence is this wherein you trust?

**36:5** "I say that your counsel and strength for the war are but vain words; now on whom do you trust, that you have rebelled against me?

**36:6** "Behold, you trust upon the staff of this bruised reed, even upon Egypt, whereon if a man lean, it will go into his hand, and pierce it; so is Pharaoh king of Egypt to all that trust on him.

**36:7** "But if you say unto me: 'We trust in YHWH our God'; is not that he, whose high places and whose altars Hezekiah has taken away, and has said to Judah and to Jerusalem: 'You shall worship before this altar'?

**36:8** "Now therefore, I pray you, make a wager with my master the king of Assyria: I will give you two thousand horses, if you be able on your part to set riders upon them.

**36:9** "How then can you turn away the face of one captain, even of the least of my master's servants, and put your trust on Egypt for chariots and for horsemen?

**36:10** "And am I now come up without YHWH against this land to destroy it? YHWH said unto me: 'Go up against this land, and destroy it.'"

---

## Request for Aramaic (36:11-12)

**36:11** Then said Eliakim and Shebna and Joah unto Rabshakeh: "Speak, I pray you, unto your servants in the Aramaic language, for we understand it; and speak not to us in the Jews' language, in the ears of the people that are on the wall."

**36:12** But Rabshakeh said: "Has my master sent me to your master, and to you, to speak these words? Has he not sent me to the men that sit upon the wall, to eat their own dung, and to drink their own water with you?"

---

## Rabshakeh's Second Speech (36:13-20)

**36:13** Then Rabshakeh stood, and cried with a loud voice in the Jews' language, and said: "Hear the words of the great king, the king of Assyria.

**36:14** "Thus says the king: 'Let not Hezekiah deceive you, for he will not be able to deliver you.

**36:15** "'Neither let Hezekiah make you trust in YHWH, saying: YHWH will surely deliver us; this city shall not be given into the hand of the king of Assyria.'

**36:16** "Hearken not to Hezekiah; for thus says the king of Assyria: 'Make your peace with me, and come out to me; and eat every one of his vine, and every one of his fig-tree, and drink every one the waters of his own cistern;

**36:17** "'Until I come and take you away to a land like your own land, a land of grain and wine, a land of bread and vineyards.'

**36:18** "'Beware lest Hezekiah persuade you, saying: YHWH will deliver us. Has any of the gods of the nations delivered his land out of the hand of the king of Assyria?

**36:19** "'Where are the gods of Hamath and Arpad? Where are the gods of Sepharvaim? And have they delivered Samaria out of my hand?

**36:20** "'Who are they among all the gods of these countries, that have delivered their country out of my hand, that YHWH should deliver Jerusalem out of my hand?'"

---

## The People's Silence (36:21-22)

**36:21** But they held their peace, and answered him not a word; for the king's commandment was, saying: "Answer him not."

**36:22** Then came Eliakim the son of Hilkiah, that was over the household, and Shebna the scribe, and Joah the son of Asaph the recorder, to Hezekiah with their clothes rent, and told him the words of Rabshakeh.

---

## Synthesis Notes

**Key Restorations:**

**Historical Setting (36:1):**
"In the fourteenth year of king Hezekiah."

*Be-arba esreh shanah la-melekh Chizkiyyahu*—701 BCE.

"Sennacherib king of Assyria came up against all the fortified cities of Judah."

*Alah Sancheriv melekh-Ashshur al kol-arei Yehudah ha-betzurot*—Assyrian invasion.

"And took them."

*Va-yitposem*—cities captured.

**Rabshakeh's Mission (36:2-3):**
"The king of Assyria sent Rabshakeh from Lachish."

*Va-yishlach melekh-Ashshur et-Rav-Shaqeh mi-Lakhish*—Rabshakeh = chief cupbearer/officer.

"To Jerusalem unto king Hezekiah with a great army."

*Yerushalayimah el-ha-melekh Chizkiyyahu be-cheil kaved*—large force.

"He stood by the conduit of the upper pool in the highway of the fuller's field."

*Va-ya'amod bi-te'alat ha-berekhah ha-elyonah bi-mesillat sedeh khoves*—same location as Isaiah 7:3.

"Eliakim the son of Hilkiah, who was over the household."

*Elyaqim ben-Chilqiyyahu asher al-ha-bayit*—Eliakim fulfilled Isaiah 22:20-22.

**Rabshakeh's First Speech (36:4-10):**
"'What confidence is this wherein you trust?'"

*Mah ha-bittachon ha-zeh asher batachta*—mocking trust.

"'Your counsel and strength for the war are but vain words.'"

*Akh devar-sefatayim etzah u-gevurah la-milchamah*—empty talk.

"'You trust upon the staff of this bruised reed, even upon Egypt.'"

*Hinneh batachta al-mish'enet ha-qaneh ha-ratzutz ha-zeh al-Mitzrayim*—Egypt = bruised reed.

"'Whereon if a man lean, it will go into his hand, and pierce it.'"

*Asher yissamekh ish alav u-va be-khapo u-neqavah*—pierces hand.

"'But if you say unto me: "We trust in YHWH our God."'"

*Ve-khi-tomar elai el-YHWH Eloheinu batachnu*—Hezekiah's trust.

"'Is not that he, whose high places and whose altars Hezekiah has taken away?'"

*Halo-hu asher hesir Chizkiyyahu et-bamotav ve-et-mizbechotav*—misunderstanding Hezekiah's reforms.

"'I will give you two thousand horses, if you be able on your part to set riders upon them.'"

*Ettenah-lekha alpayyim susim im-tukhal latet lekha rokhevim aleihem*—mocking weakness.

"'YHWH said unto me: "Go up against this land."'"

*YHWH amar elai aleh el-ha-aretz ha-zot*—claiming YHWH's authority.

**Language Request (36:11-12):**
"'Speak... in the Aramaic language.'"

*Dabber-na el-avadekha Aramit*—diplomatic language.

"'Speak not to us in the Jews' language.'"

*Ve-al-tedabber elenu Yehudit*—not in Hebrew.

"'In the ears of the people that are on the wall.'"

*Be-oznei ha-am asher al-ha-chomah*—people listening.

"'Has my master sent me... to the men that sit upon the wall?'"

*Ha-el adonekha ve-elekha shelachani adoni... ha-lo al-ha-anashim ha-yoshevim al-ha-chomah*—intended audience.

"'To eat their own dung, and to drink their own water with you?'"

*Le-ekhol et-chari'eihem ve-lishtot et-sheineihem immakhem*—siege conditions.

**Rabshakeh's Second Speech (36:13-20):**
"'Let not Hezekiah deceive you.'"

*Al-yashshia etkhem Chizkiyyahu*—Hezekiah can't save.

"'Neither let Hezekiah make you trust in YHWH.'"

*Ve-al-yavte'ach etkhem Chizkiyyahu el-YHWH*—don't trust YHWH.

"''YHWH will surely deliver us.'"

*Hatzzel yatzilenu YHWH*—mocking trust.

"''Make your peace with me, and come out to me.'"

*Asu-itti verakhah u-tze'u elai*—surrender offer.

"''Eat every one of his vine, and every one of his fig-tree.'"

*Ve-ikhlu ish-gafno ve-ish te'enato*—peace imagery.

"''Has any of the gods of the nations delivered his land?'"

*Ha-hittzilu elohei ha-goyim ish et-artzo*—comparing YHWH to other gods.

"''Where are the gods of Hamath and Arpad?'"

*Ayyeh elohei Chamat ve-Arpad*—conquered cities.

"''Have they delivered Samaria out of my hand?'"

*Ve-hitzzilu et-Shomeron mi-yaddi*—Samaria fell.

"''That YHWH should deliver Jerusalem out of my hand?'"

*Ki-yatztzil YHWH et-Yerushalayim mi-yaddi*—blasphemous challenge.

**Silence (36:21-22):**
"They held their peace, and answered him not a word."

*Va-yacharishu ve-lo-anu oto davar*—commanded silence.

"The king's commandment was, saying: 'Answer him not.'"

*Ki-mitzvat ha-melekh hi lemor lo ta'anuhu*—Hezekiah's order.

"They... came to Hezekiah with their clothes rent."

*Va-yavo'u el-Chizkiyyahu qeru'ei begadim*—distress shown.

**Archetypal Layer:** Isaiah 36 begins the **historical narrative section (chapters 36-39)**, paralleling 2 Kings 18-20. Rabshakeh's speeches challenge trust in YHWH and blasphemously equate him with other gods.

**Ethical Inversion Applied:**
- "Sennacherib king of Assyria came up against all the fortified cities of Judah"—invasion
- "The king of Assyria sent Rabshakeh"—Assyrian official
- "He stood by the conduit of the upper pool"—same as Isaiah 7:3
- "'What confidence is this wherein you trust?'"—mocking trust
- "'You trust upon the staff of this bruised reed, even upon Egypt'"—Egypt unreliable
- "'Is not that he, whose high places... Hezekiah has taken away?'"—misunderstanding reforms
- "'I will give you two thousand horses'"—mocking weakness
- "'YHWH said unto me: "Go up against this land"'"—false claim
- "'Speak... in the Aramaic language'"—language request
- "'To eat their own dung'"—siege horrors
- "'Let not Hezekiah deceive you'"—propaganda
- "'Has any of the gods of the nations delivered?'"—blasphemy
- "'Where are the gods of Hamath and Arpad?'"—conquered gods
- "'That YHWH should deliver Jerusalem?'"—ultimate challenge
- "They held their peace, and answered him not a word"—obedient silence

**Modern Equivalent:** Isaiah 36 records Sennacherib's 701 BCE invasion, confirmed by Assyrian records (Sennacherib's Prism). Rabshakeh's rhetoric is sophisticated propaganda, challenging faith in YHWH by comparing him to defeated gods.

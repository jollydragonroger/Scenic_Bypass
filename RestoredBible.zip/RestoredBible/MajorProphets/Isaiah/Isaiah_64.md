# Isaiah 64: Oh That You Would Rend the Heavens

*From the Hebrew: לוּא־קָרַעְתָּ שָׁמַיִם יָרַדְתָּ (Lu-Qarata Shamayim Yaradta) — Oh That You Would Rend the Heavens and Come Down*

---

## Prayer for Divine Intervention (64:1-7)

**64:1** Oh that you would rend the heavens, that you would come down, that the mountains might quake at your presence,

**64:2** As when fire kindles the brushwood, and the fire causes the waters to boil; to make your name known to your adversaries, that the nations might tremble at your presence!

**64:3** When you did tremendous things which we looked not for, you came down, the mountains quaked at your presence.

**64:4** For from of old men have not heard, nor perceived by the ear, neither has the eye seen a God beside you, who works for him that waits for him.

**64:5** You meet him that rejoices and works righteousness, those that remember you in your ways; behold, you were wroth, and we sinned; upon them have we been a long time; and shall we be saved?

**64:6** And we are all become as one that is unclean, and all our righteousnesses are as a polluted garment; and we all do fade as a leaf, and our iniquities, like the wind, take us away.

**64:7** And there is none that calls upon your name, that stirs up himself to take hold of you; for you have hid your face from us, and have consumed us by means of our iniquities.

---

## The Potter and the Clay (64:8-12)

**64:8** But now, O YHWH, you are our Father; we are the clay, and you our potter, and we all are the work of your hand.

**64:9** Be not wroth very sore, O YHWH, neither remember iniquity forever; behold, look, we beseech you, we are all your people.

**64:10** Your holy cities are become a wilderness, Zion is become a wilderness, Jerusalem a desolation.

**64:11** Our holy and our beautiful house, where our fathers praised you, is burned with fire; and all our pleasant things are laid waste.

**64:12** Will you refrain yourself for these things, O YHWH? Will you hold your peace, and afflict us very sore?

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (64:1-3):**
"Oh that you would rend the heavens, that you would come down."

*Lu-qarata shamayim yaradta*—rend heavens, come down.

"That the mountains might quake at your presence."

*Mippanekha harim nazollu*—mountains quake.

"As when fire kindles the brushwood."

*Ki-qedoch esh hamasim*—fire kindling.

"The fire causes the waters to boil."

*Esh mayim tiv'eh*—water boiling.

"To make your name known to your adversaries."

*Le-hodia shimekha le-tzarekha*—name known to adversaries.

"That the nations might tremble at your presence."

*Mippanekha goyim yirgazu*—nations tremble.

"When you did tremendous things which we looked not for."

*Ba-asotekha nora'ot lo neqavveh*—unexpected tremendous things.

"You came down, the mountains quaked at your presence."

*Yaradta mippanekha harim nazollu*—Sinai echo.

**The Key Verse (64:4):**
"From of old men have not heard, nor perceived by the ear."

*U-me-olam lo-sham'u lo he'ezinu*—never heard.

"Neither has the eye seen."

*Ayin lo-ra'atah*—never seen.

"A God beside you."

*Elohim zulatekha*—no God besides.

"Who works for him that waits for him."

*Ya'aseh li-mchakkeh-lo*—works for waiters. 1 Corinthians 2:9 alludes to this.

**Sinfulness Confessed (64:5-7):**
"You meet him that rejoices and works righteousness."

*Pagata et-sas ve-oseh tzedeq*—meeting joyful righteous.

"Those that remember you in your ways."

*Bi-drakhekha yizkerukha*—remembering your ways.

"Behold, you were wroth, and we sinned."

*Hen-attah qatzafta va-necheta*—angry, we sinned.

"Upon them have we been a long time."

*Bahem olam*—long time.

"Shall we be saved?"

*Ve-nivvashe'a*—shall we be saved?

**The Key Verse (64:6):**
"We are all become as one that is unclean."

*Va-nehi kha-tame kullanu*—all unclean.

"All our righteousnesses are as a polluted garment."

*U-khe-beged iddim kol-tzidqoteinu*—righteousnesses = filthy rags.

"We all do fade as a leaf."

*Va-navel ke-aleh kullanu*—fading like leaf.

"Our iniquities, like the wind, take us away."

*Va-avoneinu ka-ruach tissa'unu*—iniquities like wind.

**The Key Verse (64:7):**
"There is none that calls upon your name."

*Ve-ein-qore ve-shimekha*—none calls.

"That stirs up himself to take hold of you."

*Mit'orer lehachaziq bakh*—none stirs to hold.

"You have hid your face from us."

*Ki-histarta fanekha mimmenu*—face hidden.

"Have consumed us by means of our iniquities."

*Va-temugenu be-yad-avoneinu*—consumed by iniquities.

**The Key Verses (64:8-9):**
"But now, O YHWH, you are our Father."

*Ve-attah YHWH avinu*—you are Father.

"We are the clay, and you our potter."

*Anachnu ha-chomer ve-attah yotzrenu*—clay and potter.

"We all are the work of your hand."

*U-ma'aseh yadekha kullanu*—hand's work.

"Be not wroth very sore, O YHWH."

*Al-tiqtzof YHWH ad-me'od*—don't be very angry.

"Neither remember iniquity forever."

*Ve-al-la-ad tizkor avon*—don't remember forever.

"Behold, look, we beseech you, we are all your people."

*Hen-habbet-na ammekha kullanu*—we're your people.

**Temple Destruction (64:10-12):**
"Your holy cities are become a wilderness."

*Arei qodshekha hayu midbar*—holy cities = wilderness.

"Zion is become a wilderness."

*Tziyyon midbar hayetah*—Zion = wilderness.

"Jerusalem a desolation."

*Yerushalayim shemamah*—Jerusalem = desolation.

**The Key Verse (64:11):**
"Our holy and our beautiful house."

*Beit qodshenu ve-tif'artenu*—holy, beautiful house.

"Where our fathers praised you."

*Asher hillelukha avoteinu*—fathers praised.

"Is burned with fire."

*Hayah li-serefat-esh*—burned.

"All our pleasant things are laid waste."

*Ve-khol-machamaddenu hayah le-chorvah*—pleasant things wasted.

**The Key Verse (64:12):**
"Will you refrain yourself for these things, O YHWH?"

*Ha-al-elleh tit'appaq YHWH*—will you refrain?

"Will you hold your peace?"

*Techesheh*—hold peace?

"Afflict us very sore?"

*U-te'annenu ad-me'od*—afflict very sore?

**Archetypal Layer:** Isaiah 64 continues the prayer of 63:15-19 with **"Oh that you would rend the heavens" (64:1)**, **"neither has the eye seen a God beside you" (64:4)**—1 Corinthians 2:9, **"all our righteousnesses are as a polluted garment" (64:6)**, and **"we are the clay, and you our potter" (64:8)**.

**Ethical Inversion Applied:**
- "Oh that you would rend the heavens, that you would come down"—longing for theophany
- "That the mountains might quake at your presence"—quaking mountains
- "As when fire kindles the brushwood"—fire imagery
- "To make your name known to your adversaries"—name known
- "That the nations might tremble at your presence"—nations tremble
- "When you did tremendous things which we looked not for"—unexpected acts
- "From of old men have not heard, nor perceived by the ear"—1 Corinthians 2:9
- "Neither has the eye seen a God beside you"—unseen God
- "Who works for him that waits for him"—works for waiters
- "You meet him that rejoices and works righteousness"—meeting righteous
- "Behold, you were wroth, and we sinned"—anger, sin
- "We are all become as one that is unclean"—all unclean
- "All our righteousnesses are as a polluted garment"—filthy rags
- "We all do fade as a leaf"—fading leaf
- "Our iniquities, like the wind, take us away"—wind-blown
- "There is none that calls upon your name"—none calls
- "You have hid your face from us"—hidden face
- "But now, O YHWH, you are our Father"—Father
- "We are the clay, and you our potter"—clay/potter
- "We all are the work of your hand"—hand's work
- "Be not wroth very sore, O YHWH"—don't be very angry
- "Neither remember iniquity forever"—don't remember
- "We are all your people"—your people
- "Your holy cities are become a wilderness"—wilderness
- "Our holy and our beautiful house... is burned with fire"—temple burned
- "Will you refrain yourself for these things?"—will you refrain?

**Modern Equivalent:** Isaiah 64:4's "neither has the eye seen a God beside you, who works for him that waits for him" is adapted in 1 Corinthians 2:9. "All our righteousnesses are as a polluted garment" (64:6) is foundational for understanding human inability. The clay/potter imagery (64:8) echoes Romans 9:20-21.

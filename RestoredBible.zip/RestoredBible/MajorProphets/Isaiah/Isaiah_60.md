# Isaiah 60: Arise, Shine, for Your Light Has Come

*From the Hebrew: קוּמִי אוֹרִי כִּי בָא אוֹרֵךְ (Qumi Ori Ki Va Orekh) — Arise, Shine, for Your Light Has Come*

---

## Zion's Light (60:1-3)

**60:1** Arise, shine, for your light has come, and the glory of YHWH is risen upon you.

**60:2** For, behold, darkness shall cover the earth, and gross darkness the peoples; but upon you YHWH will arise, and his glory shall be seen upon you.

**60:3** And nations shall walk at your light, and kings at the brightness of your rising.

---

## The Nations Bring Their Wealth (60:4-9)

**60:4** Lift up your eyes round about, and see: They all are gathered together, and come to you; your sons come from far, and your daughters are borne on the side.

**60:5** Then you shall see and be radiant, and your heart shall throb and be enlarged; because the abundance of the sea shall be turned unto you, the wealth of the nations shall come unto you.

**60:6** The multitude of camels shall cover you, the young camels of Midian and Ephah, all coming from Sheba; they shall bring gold and frankincense, and shall proclaim the praises of YHWH.

**60:7** All the flocks of Kedar shall be gathered together unto you, the rams of Nebaioth shall minister unto you; they shall come up with acceptance on my altar, and I will glorify my glorious house.

**60:8** Who are these that fly as a cloud, and as the doves to their windows?

**60:9** Surely the isles shall wait for me, and the ships of Tarshish first, to bring your sons from far, their silver and their gold with them, for the name of YHWH your God, and for the Holy One of Israel, because he has glorified you.

---

## Foreigners Rebuild Zion (60:10-14)

**60:10** And foreigners shall build up your walls, and their kings shall minister unto you; for in my wrath I smote you, but in my favour have I had compassion on you.

**60:11** Your gates also shall be open continually, day and night, they shall not be shut; that men may bring unto you the wealth of the nations, and their kings led in procession.

**60:12** For that nation and kingdom that will not serve you shall perish; yea, those nations shall be utterly wasted.

**60:13** The glory of Lebanon shall come unto you, the cypress, the plane-tree, and the larch together; to beautify the place of my sanctuary, and I will make the place of my feet glorious.

**60:14** And the sons of them that afflicted you shall come bending unto you, and all they that despised you shall bow down at the soles of your feet; and they shall call you the city of YHWH, the Zion of the Holy One of Israel.

---

## Everlasting Light (60:15-22)

**60:15** Whereas you have been forsaken and hated, so that no man passed through you, I will make you an eternal excellency, a joy of many generations.

**60:16** You shall also suck the milk of the nations, and shall suck the breast of kings; and you shall know that I YHWH am your Savior, and your Redeemer, the Mighty One of Jacob.

**60:17** For brass I will bring gold, and for iron I will bring silver, and for wood brass, and for stones iron; I will also make your officers peace, and righteousness your exactors.

**60:18** Violence shall no more be heard in your land, desolation nor destruction within your borders; but you shall call your walls Salvation, and your gates Praise.

**60:19** The sun shall be no more your light by day, neither for brightness shall the moon give light unto you; but YHWH shall be unto you an everlasting light, and your God your glory.

**60:20** Your sun shall no more go down, neither shall your moon withdraw itself; for YHWH shall be your everlasting light, and the days of your mourning shall be ended.

**60:21** Your people also shall be all righteous, they shall inherit the land forever; the branch of my planting, the work of my hands, that I may be glorified.

**60:22** The smallest shall become a thousand, and the least a mighty nation; I YHWH will hasten it in its time.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (60:1-3):**
"Arise, shine, for your light has come."

*Qumi ori ki va orekh*—arise and shine.

"The glory of YHWH is risen upon you."

*U-khevod YHWH alayikh zarach*—YHWH's glory rises.

"Darkness shall cover the earth."

*Ki-hinneh ha-choshekh yekhasseh-eretz*—darkness covers earth.

"Gross darkness the peoples."

*Va-arafel le'ummim*—thick darkness on peoples.

"Upon you YHWH will arise."

*Ve-alayikh yizrach YHWH*—YHWH rises on you.

"His glory shall be seen upon you."

*U-khevodo alayikh yera'eh*—glory seen.

"Nations shall walk at your light."

*Ve-halekhu goyim le-orekh*—nations walk by light.

"Kings at the brightness of your rising."

*U-melakhim le-nogah zarchekh*—kings by brightness.

**Nations Bring Wealth (60:4-9):**
"Lift up your eyes round about, and see."

*Se'i-saviv einayikh u-re'i*—look around.

"They all are gathered together, and come to you."

*Kullam niqbetzu va'u-lakh*—all gathered.

"Your sons come from far."

*Banayikh me-rachoq yavo'u*—sons from far.

"Your daughters are borne on the side."

*U-venotayikh al-tzad te'amannah*—daughters carried.

"Your heart shall throb and be enlarged."

*U-fachad ve-rachav levavekh*—heart expands.

"The abundance of the sea shall be turned unto you."

*Ki-yehafekhk alayikh hamon yam*—sea's abundance.

"The wealth of the nations shall come unto you."

*Cheil goyim yavo'u lakh*—nations' wealth.

**The Key Verse (60:6):**
"The multitude of camels shall cover you."

*Shifekat gemalim tekhasekh*—camel caravans.

"The young camels of Midian and Ephah."

*Bikrei Midyan ve-Efah*—Midian/Ephah camels.

"All coming from Sheba."

*Kullam mi-Sheva yavo'u*—from Sheba.

"They shall bring gold and frankincense."

*Zahav u-levonah yissa'u*—gold and frankincense. Matthew 2:11 echoes this.

"Shall proclaim the praises of YHWH."

*U-tehillot YHWH yevasseru*—proclaim praises.

"Who are these that fly as a cloud?"

*Mi-elleh ka-av te'ufenah*—flying like cloud.

"As the doves to their windows?"

*Ve-kha-yonim el-arubboteihem*—doves to windows.

"The ships of Tarshish first."

*Oniyyot Tarshish ba-rishonah*—Tarshish ships first.

"To bring your sons from far."

*Le-havi vanayikh me-rachoq*—bring sons.

"Their silver and their gold with them."

*Kaspam u-zehabam ittam*—silver and gold.

**Foreigners Serve (60:10-14):**
"Foreigners shall build up your walls."

*U-vanu venei-nekhar chomotayikh*—foreigners build walls.

"Their kings shall minister unto you."

*U-malkheihem yesharetu-kha*—kings serve.

"In my wrath I smote you."

*Ki ve-qitzpi hikkittikh*—struck in wrath.

"In my favour have I had compassion on you."

*U-vi-retzoni richamttikh*—compassion in favor.

**The Key Verse (60:11):**
"Your gates also shall be open continually."

*U-fittchu she'arayikh tamid*—gates always open. Revelation 21:25 echoes this.

"Day and night, they shall not be shut."

*Yomam va-laylah lo yissageru*—never shut.

"That men may bring unto you the wealth of the nations."

*Le-havi elayikh cheil goyim*—nations' wealth brought.

"Their kings led in procession."

*U-malkheihem nehugim*—kings led.

"The glory of Lebanon shall come unto you."

*Kevod ha-Levanon elayikh yavo*—Lebanon's glory.

"To beautify the place of my sanctuary."

*Le-fa'er meqom miqdashi*—beautify sanctuary.

"I will make the place of my feet glorious."

*U-meqom raglai akhabbed*—feet-place glorified.

"They shall call you the city of YHWH."

*Ve-qare'u lakh ir YHWH*—city of YHWH.

"The Zion of the Holy One of Israel."

*Tziyyon Qedosh Yisra'el*—Zion of Holy One.

**Everlasting Light (60:15-22):**
"Whereas you have been forsaken and hated."

*Tachat heyotek azuvah u-senu'ah*—formerly forsaken.

"I will make you an eternal excellency."

*Ve-samtikh li-ge'on olam*—eternal excellency.

"A joy of many generations."

*Mesos dor va-dor*—joy of generations.

"You shall know that I YHWH am your Savior."

*Ve-yadat ki ani YHWH moshi'ekh*—know YHWH as Savior.

"Your Redeemer, the Mighty One of Jacob."

*Ve-go'alekh avir Ya'aqov*—Redeemer, Mighty One.

"For brass I will bring gold."

*Tachat ha-nechoshet avi zahav*—gold for brass.

"For iron I will bring silver."

*Ve-tachat ha-barzel avi kesef*—silver for iron.

"I will also make your officers peace."

*Ve-samti fequddatek shalom*—officers = peace.

"Righteousness your exactors."

*Ve-nogsayikh tzedaqah*—exactors = righteousness.

**The Key Verse (60:18):**
"Violence shall no more be heard in your land."

*Lo-yishama od chamas be-artzekh*—no violence.

"Desolation nor destruction within your borders."

*Shod va-shever bi-gevuleyikh*—no destruction.

"You shall call your walls Salvation."

*Ve-qarait yeshu'ah chomotayikh*—walls = Salvation.

"Your gates Praise."

*U-she'arayikh tehillah*—gates = Praise.

**The Key Verses (60:19-20):**
"The sun shall be no more your light by day."

*Lo-yihyeh-lakh od ha-shemesh le-or yomam*—no sun needed. Revelation 21:23; 22:5 echoes this.

"Neither for brightness shall the moon give light unto you."

*U-le-nogah ha-yareach lo-ya'ir lakh*—no moon needed.

"YHWH shall be unto you an everlasting light."

*Ve-hayah-lakh YHWH le-or olam*—YHWH = eternal light.

"Your God your glory."

*Ve-Elohayikh le-tif'artek*—God = glory.

"Your sun shall no more go down."

*Lo-yavo od shimshekh*—sun won't set.

"Your moon withdraw itself."

*Vi-yerechekh lo ye'asef*—moon won't wane.

"YHWH shall be your everlasting light."

*Ki YHWH yihyeh-lakh le-or olam*—YHWH = everlasting light.

"The days of your mourning shall be ended."

*Ve-shalemu yemei evlek*—mourning ended.

**The Key Verses (60:21-22):**
"Your people also shall be all righteous."

*Ve-ammekh kullam tzaddiqim*—all righteous.

"They shall inherit the land forever."

*Le-olam yirshu aretz*—eternal land.

"The branch of my planting."

*Netzer matta'ai*—my planting.

"The work of my hands, that I may be glorified."

*Ma'aseh yadai le-hitpa'er*—for my glory.

"The smallest shall become a thousand."

*Ha-qaton yihyeh le-elef*—small to thousand.

"The least a mighty nation."

*Ve-ha-tza'ir le-goy atzum*—least to mighty.

"I YHWH will hasten it in its time."

*Ani YHWH be-ittah achishenah*—hastened in time.

**Archetypal Layer:** Isaiah 60 is one of the most quoted chapters in Revelation. **"Arise, shine" (60:1)**, **"gold and frankincense" (60:6)**—Matthew 2:11, **"your gates... shall be open continually" (60:11)**—Revelation 21:25, **"the sun shall be no more your light" (60:19)**—Revelation 21:23; 22:5.

**Ethical Inversion Applied:**
- "Arise, shine, for your light has come"—light has come
- "The glory of YHWH is risen upon you"—glory rises
- "Darkness shall cover the earth"—earth's darkness
- "Upon you YHWH will arise"—YHWH rises on Zion
- "Nations shall walk at your light"—nations come
- "Kings at the brightness of your rising"—kings come
- "They all are gathered together, and come to you"—gathering
- "The abundance of the sea shall be turned unto you"—sea's abundance
- "The wealth of the nations shall come unto you"—nations' wealth
- "They shall bring gold and frankincense"—Matthew 2:11
- "Shall proclaim the praises of YHWH"—praises
- "Foreigners shall build up your walls"—foreigners serve
- "Their kings shall minister unto you"—kings serve
- "Your gates also shall be open continually"—Revelation 21:25
- "The glory of Lebanon shall come unto you"—Lebanon's glory
- "They shall call you the city of YHWH"—city of YHWH
- "I will make you an eternal excellency"—eternal excellency
- "For brass I will bring gold"—upgrade
- "Violence shall no more be heard in your land"—no violence
- "You shall call your walls Salvation, and your gates Praise"—walls/gates named
- "The sun shall be no more your light by day"—Revelation 21:23
- "YHWH shall be unto you an everlasting light"—YHWH = light
- "The days of your mourning shall be ended"—mourning ended
- "Your people also shall be all righteous"—all righteous
- "The smallest shall become a thousand"—small to great
- "I YHWH will hasten it in its time"—hastened

**Modern Equivalent:** Isaiah 60 heavily influences Revelation 21-22's New Jerusalem. The Magi's gifts (Matthew 2:11) echo 60:6. Gates always open (60:11) appears in Revelation 21:25. No sun/moon needed (60:19-20) appears in Revelation 21:23 and 22:5. This is one of Scripture's most beautiful visions of future glory.

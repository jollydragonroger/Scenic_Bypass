# Isaiah 6: The Call of Isaiah

*From the Hebrew: בִּשְׁנַת־מוֹת הַמֶּלֶךְ עֻזִּיָּהוּ (Bi-Shenat-Mot Ha-Melekh Uzziyahu) — In the Year That King Uzziah Died*

---

## The Vision of YHWH (6:1-4)

**6:1** In the year that king Uzziah died I saw the Lord sitting upon a throne high and lifted up, and his train filled the temple.

**6:2** Above him stood the seraphim; each one had six wings: with two he covered his face, and with two he covered his feet, and with two he did fly.

**6:3** And one called unto another, and said:
"Holy, holy, holy, is YHWH of hosts;
the whole earth is full of his glory."

**6:4** And the posts of the door were moved at the voice of him that called, and the house was filled with smoke.

---

## Isaiah's Cleansing (6:5-7)

**6:5** Then said I: "Woe is me! For I am undone;
because I am a man of unclean lips, and I dwell in the midst of a people of unclean lips;
for my eyes have seen the King, YHWH of hosts."

**6:6** Then flew one of the seraphim unto me, having a live coal in his hand, which he had taken with the tongs from off the altar;

**6:7** And he touched my mouth with it, and said:
"Lo, this has touched your lips;
and your iniquity is taken away, and your sin expiated."

---

## The Commission (6:8-13)

**6:8** And I heard the voice of the Lord, saying:
"Whom shall I send, and who will go for us?"
Then I said: "Here am I; send me."

**6:9** And he said: "Go, and tell this people:
Hear indeed, but understand not;
and see indeed, but perceive not.

**6:10** "Make the heart of this people fat,
and make their ears heavy, and shut their eyes;
lest they, seeing with their eyes, and hearing with their ears,
and understanding with their heart,
return, and be healed."

**6:11** Then said I: "Lord, how long?"
And he answered:
"Until cities be waste without inhabitant,
and houses without man,
and the land become utterly waste,

**6:12** "And YHWH have removed men far away,
and the forsaken places be many in the midst of the land.

**6:13** "And if there be yet a tenth in it,
it shall again be eaten up;
as a terebinth, and as an oak, whose stock remains, when they are felled;
the holy seed is the stock thereof."

---

## Synthesis Notes

**Key Restorations:**

**The Key Verse (6:1):**
"In the year that king Uzziah died."

*Bi-shenat-mot ha-melekh Uzziyahu*—approximately 740 BCE.

"I saw the Lord sitting upon a throne high and lifted up."

*Va-er'eh et-Adonai yoshev al-kisse ram ve-nissa*—enthroned Lord.

"His train filled the temple."

*Ve-shulav mele'im et-ha-heikhal*—robe fills temple.

**Seraphim (6:2-3):**
"Above him stood the seraphim."

*Serafim omedim mimma'al lo*—seraphim standing.

"Each one had six wings."

*Shesh kenafayim shesh kenafayim le-echad*—six wings each.

"With two he covered his face."

*Bi-shetayim yekhasseh fanav*—face covered (can't look at God).

"With two he covered his feet."

*U-vi-shetayim yekhasseh raglav*—feet covered (modesty/reverence).

"With two he did fly."

*U-vi-shetayim ye'ofef*—flying.

**The Key Verse (6:3):**
"Holy, holy, holy, is YHWH of hosts."

*Qadosh qadosh qadosh YHWH Tzeva'ot*—triple holy (Trisagion).

"The whole earth is full of his glory."

*Melo khol-ha-aretz kevodo*—glory fills earth.

**Theophany Effects (6:4):**
"The posts of the door were moved."

*Va-yanu'u ammot ha-sippim*—doorposts shake.

"The house was filled with smoke."

*Ve-ha-bayit yimmale ashan*—smoke fills.

**The Key Verse (6:5):**
"Woe is me! For I am undone."

*Oy-li ki-nidmeiti*—undone/ruined.

"I am a man of unclean lips."

*Ki ish teme-sefatayim anokhi*—unclean lips.

"I dwell in the midst of a people of unclean lips."

*U-ve-tokh am teme-sefatayim anokhi yoshev*—unclean people.

"My eyes have seen the King, YHWH of hosts."

*Ki et-ha-Melekh YHWH Tzeva'ot ra'u einai*—seen the King.

**Cleansing (6:6-7):**
"Then flew one of the seraphim unto me."

*Va-ya'of elai echad min-ha-serafim*—seraph flies.

"Having a live coal in his hand."

*U-ve-yado ritzpah*—live coal.

"Which he had taken with the tongs from off the altar."

*Be-melqachayim laqach me-al ha-mizbe'ach*—altar coal.

"He touched my mouth with it."

*Va-yagga al-pi*—mouth touched.

"Your iniquity is taken away."

*Ve-sar avonekha*—iniquity removed.

"Your sin expiated."

*Ve-chatta'tekha tekhupper*—sin atoned.

**The Key Verse (6:8):**
"Whom shall I send, and who will go for us?"

*Et-mi eshlach u-mi yelekh-lanu*—divine council question.

"Here am I; send me."

*Hinneni shelacheni*—Isaiah's response.

**The Key Verses (6:9-10):**
"Go, and tell this people."

*Lekh ve-amarta la-am ha-zeh*—go and tell.

"Hear indeed, but understand not."

*Shim'u shamo'a ve-al-tavinu*—hear without understanding.

"See indeed, but perceive not."

*U-re'u ra'o ve-al-teda'u*—see without perceiving.

"Make the heart of this people fat."

*Hashmen lev-ha-am ha-zeh*—fatten hearts.

"Make their ears heavy."

*Ve-oznav hakhbed*—heavy ears.

"Shut their eyes."

*Ve-einav hasha*—blinded eyes.

"Lest they... return, and be healed."

*Pen... va-shav ve-rafa lo*—prevent healing.

**Duration (6:11-12):**
"Lord, how long?"

*Ad-matai Adonai*—how long?

"Until cities be waste without inhabitant."

*Ad asher-im sha'u arim me-ein yoshev*—cities emptied.

**The Key Verse (6:13):**
"If there be yet a tenth in it, it shall again be eaten up."

*Ve-od bah asiriyyah ve-shavah ve-haytah le-va'er*—tenth consumed.

"As a terebinth, and as an oak, whose stock remains when they are felled."

*Ka-elah ve-kha-allon asher be-shallechet matzevet bam*—stump remains.

"The holy seed is the stock thereof."

*Zera qodesh matzevtah*—holy seed = stump.

**Archetypal Layer:** Isaiah 6 is **Isaiah's throne-room vision and call**. The Trisagion (6:3), cleansing by fire (6:6-7), "Here am I; send me" (6:8), and the hardening commission (6:9-10) quoted in all four Gospels and Acts.

**Ethical Inversion Applied:**
- "In the year that king Uzziah died"—human king dies, divine King appears
- "I saw the Lord sitting upon a throne high and lifted up"—exalted throne
- "His train filled the temple"—overwhelming presence
- "Each one had six wings"—covering, flying
- "Holy, holy, holy, is YHWH of hosts"—triple holiness
- "The whole earth is full of his glory"—glory fills
- "Woe is me! For I am undone"—shattering encounter
- "I am a man of unclean lips"—unclean confession
- "My eyes have seen the King"—seen YHWH
- "A live coal... from off the altar"—altar fire
- "Your iniquity is taken away, and your sin expiated"—cleansing
- "Whom shall I send?"—divine question
- "Here am I; send me"—response
- "Hear indeed, but understand not"—hardening
- "Make the heart of this people fat"—judicial hardening
- "The holy seed is the stock thereof"—remnant preserved

**Modern Equivalent:** Isaiah 6 is the classic call narrative. The Trisagion (6:3) is foundational liturgy. The hardening commission (6:9-10) is quoted more in the NT than almost any OT passage. "Here am I; send me" (6:8) models prophetic availability.

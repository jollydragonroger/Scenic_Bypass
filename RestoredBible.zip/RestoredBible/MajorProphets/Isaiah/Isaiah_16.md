# Isaiah 16: Moab's Plea and Pride

*From the Hebrew: שִׁלְחוּ־כַר מֹשֵׁל אֶרֶץ (Shilchu-Khar Moshel Eretz) — Send the Lamb to the Ruler of the Land*

---

## Moab Seeks Refuge (16:1-5)

**16:1** Send the lambs for the ruler of the land
from Sela through the wilderness
unto the mount of the daughter of Zion.

**16:2** And it shall come to pass, that as wandering birds,
as a scattered nest,
so shall the daughters of Moab be at the fords of Arnon.

**16:3** "Give counsel, execute justice;
make your shadow as the night in the midst of the noonday;
hide the outcasts; betray not the fugitive.

**16:4** "Let my outcasts dwell with you; as for Moab,
be a covert to him from the face of the destroyer."
For the extortion is at an end, destruction ceases,
they that trampled are consumed out of the land.

**16:5** And a throne shall be established through mercy,
and there shall sit thereon in truth, in the tent of David,
one that judges, and seeks justice, and is swift to do righteousness.

---

## Moab's Pride and Lament (16:6-12)

**16:6** We have heard of the pride of Moab, that he is very proud;
his haughtiness, and his pride, and his arrogance,
and the ill-foundation of his boasts.

**16:7** Therefore shall Moab wail for Moab, every one shall wail;
for the raisin-cakes of Kir-hareseth shall you mourn,
utterly stricken.

**16:8** For the fields of Heshbon languish,
and the vine of Sibmah,
whose choice plants did overcome the lords of nations;
they reached even unto Jazer, they wandered into the wilderness;
her branches were spread abroad, they passed over the sea.

**16:9** Therefore I will weep with the weeping of Jazer for the vine of Sibmah;
I will water you with my tears, O Heshbon, and Elealeh;
for upon your summer fruits and upon your harvest the battle-shout is fallen.

**16:10** And gladness and joy are taken away out of the fruitful field;
and in the vineyards there shall be no singing, neither joyful noise;
no treader treads out wine in the presses;
I have made the vintage shout to cease.

**16:11** Wherefore my heart sounds like a harp for Moab,
and my inward parts for Kir-heres.

**16:12** And it shall come to pass, when Moab presents himself,
when he wearies himself upon the high place,
and comes to his sanctuary to pray, that he shall not prevail.

---

## The Timeframe of Judgment (16:13-14)

**16:13** This is the word that YHWH spoke concerning Moab in time past.

**16:14** But now YHWH has spoken, saying: "Within three years, as the years of a hireling, and the glory of Moab shall be brought into contempt, with all his great multitude; and the remnant shall be very small and feeble."

---

## Synthesis Notes

**Key Restorations:**

**Seeking Refuge (16:1-4):**
"Send the lambs for the ruler of the land."

*Shilchu-khar moshel-eretz*—tribute lambs.

"From Sela through the wilderness."

*Mi-Sela midbarah*—from Petra (Sela).

"Unto the mount of the daughter of Zion."

*El-har bat-Tziyyon*—to Zion.

"As wandering birds, as a scattered nest."

*Ve-hayah khe-of noded qen meshullach*—scattered birds.

"The daughters of Moab be at the fords of Arnon."

*Tihyeynah benot Mo'av ma'berot le-Arnon*—at river crossings.

"'Give counsel, execute justice.'"

*Havi'u etzah asu pelilah*—counsel and justice.

"'Make your shadow as the night in the midst of the noonday.'"

*Shiti kha-laylah tzillekh be-tokh tzohorayim*—complete shade.

"'Hide the outcasts; betray not the fugitive.'"

*Sattri nidachim noded al-tegalli*—protect refugees.

"'Let my outcasts dwell with you.'"

*Yaguru vakh niddachay*—shelter outcasts.

"'Be a covert to him from the face of the destroyer.'"

*Mo'av hevi-seter lamo mippenei shodded*—hide from destroyer.

**The Key Verse (16:5):**
"A throne shall be established through mercy."

*Ve-hukhan be-chesed kisse*—mercy-established throne.

"There shall sit thereon in truth, in the tent of David."

*Ve-yashav alav be-emet be-ohel David*—Davidic throne.

"One that judges, and seeks justice."

*Shofet ve-doresh mishpat*—seeking justice.

"Swift to do righteousness."

*U-mehir tzedeq*—quick righteousness.

**Pride (16:6):**
"We have heard of the pride of Moab, that he is very proud."

*Shama'nu ge'on-Mo'av ge'eh me'od*—very proud.

"His haughtiness, and his pride, and his arrogance."

*Ge'ono u-ge'ono ve-evrato*—triple pride.

"The ill-foundation of his boasts."

*Lo-khen baddav*—empty boasts.

**Lamentation (16:7-11):**
"Therefore shall Moab wail for Moab."

*Lakhen yeyalel Mo'av le-Mo'av*—mutual wailing.

"For the raisin-cakes of Kir-hareseth shall you mourn."

*La-ashishei Qir-Chareseth tehegu*—raisin-cakes lost.

"The fields of Heshbon languish."

*Ki sadmot Cheshbon umlal*—fields languish.

"The vine of Sibmah."

*Gefen Sivmah*—famous vineyard.

"Whose choice plants did overcome the lords of nations."

*Ba'alei goyim haleumu serugekha*—far-reaching vines.

"They reached even unto Jazer."

*Ad-Ya'zer naga'u*—extended reach.

"They passed over the sea."

*Averu yam*—crossed sea (Dead Sea).

**The Key Verse (16:9):**
"I will weep with the weeping of Jazer for the vine of Sibmah."

*Al-ken evkeh bi-vekhi Ya'zer gefen Sivmah*—prophet weeps.

"I will water you with my tears."

*Ariyyekh dim'ati*—tears water.

"Upon your summer fruits and upon your harvest the battle-shout is fallen."

*Al-qeytzekh ve-al-qetzirkha heidad nafal*—harvest destroyed.

"Gladness and joy are taken away out of the fruitful field."

*Ve-ne'esfah simchah va-gil min-ha-karmel*—joy removed.

"In the vineyards there shall be no singing."

*U-va-keramim lo-yerunnan lo-yero'a*—no vineyard singing.

"No treader treads out wine in the presses."

*Yayin ba-yeqavim lo-yidrokh ha-dorekh*—no wine-treading.

"I have made the vintage shout to cease."

*Heidad hishbatti*—vintage shout ended.

**The Key Verse (16:11):**
"My heart sounds like a harp for Moab."

*Al-ken me'ai le-Mo'av ka-kinnor yehemu*—heart like harp.

"My inward parts for Kir-heres."

*Ve-qirbi le-Qir-Chares*—inner mourning.

**Useless Worship (16:12):**
"When Moab presents himself... upon the high place."

*Ve-hayah ki-nir'ah ki-nil'ah Mo'av al-ha-bamah*—high place worship.

"Comes to his sanctuary to pray."

*U-va el-miqdashiv le-hitpallel*—temple prayer.

"He shall not prevail."

*Ve-lo yukhal*—prayer fails.

**Timeframe (16:13-14):**
"Within three years, as the years of a hireling."

*Be-shalosh shanim ki-shenei sakhir*—exact timeframe.

"The glory of Moab shall be brought into contempt."

*Ve-niqlah kevod Mo'av*—glory contemned.

"The remnant shall be very small and feeble."

*U-she'ar me'at miz'ar lo khabbir*—small remnant.

**Archetypal Layer:** Isaiah 16 continues the Moab oracle with **Moab seeking refuge in Zion (16:1-5)**, **prophetic sympathy (16:9-11)**, and **the messianic throne promise (16:5)**.

**Ethical Inversion Applied:**
- "Send the lambs for the ruler of the land"—tribute
- "As wandering birds, as a scattered nest"—refugees
- "'Give counsel, execute justice'"—Moab's plea
- "'Hide the outcasts; betray not the fugitive'"—refugee protection
- "A throne shall be established through mercy"—messianic throne
- "One that judges, and seeks justice"—just king
- "We have heard of the pride of Moab"—pride heard
- "His haughtiness, and his pride, and his arrogance"—triple pride
- "I will weep with the weeping of Jazer"—prophetic tears
- "I will water you with my tears"—grief
- "My heart sounds like a harp for Moab"—heart mourns
- "When Moab... comes to his sanctuary to pray"—useless prayer
- "He shall not prevail"—prayer fails
- "Within three years"—judgment timeline
- "The remnant shall be very small"—small remnant

**Modern Equivalent:** Isaiah 16:5's Davidic throne "established through mercy" is messianic. The prophet's grief for an enemy nation (16:9-11) models compassion. Moab's pride prevents help; his worship fails because of arrogance.

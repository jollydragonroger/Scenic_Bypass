# Isaiah 33: Woe to the Destroyer and the Exalted YHWH

*From the Hebrew: הוֹי שׁוֹדֵד וְאַתָּה לֹא שָׁדוּד (Hoy Shoded Ve-Attah Lo Shadud) — Woe to You That Spoil, and You Were Not Spoiled*

---

## Woe to the Destroyer (33:1-6)

**33:1** Woe to you that spoil, and you were not spoiled;
and deal treacherously, and they dealt not treacherously with you!
When you have ceased to spoil, you shall be spoiled;
when you have made an end of dealing treacherously, they shall deal treacherously with you.

**33:2** O YHWH, be gracious unto us;
we have waited for you;
be their arm every morning,
our salvation also in the time of trouble.

**33:3** At the noise of the tumult the peoples are fled;
at the lifting up of yourself the nations are scattered.

**33:4** And your spoil is gathered as the caterpillar gathers;
as locusts leap do they leap upon it.

**33:5** YHWH is exalted, for he dwells on high;
he has filled Zion with justice and righteousness.

**33:6** And there shall be faith in your times,
strength of salvation, wisdom, and knowledge;
the fear of YHWH is his treasure.

---

## The Devastated Land and YHWH's Action (33:7-16)

**33:7** Behold, their valiant ones cry without;
the ambassadors of peace weep bitterly.

**33:8** The highways lie waste, the wayfaring man ceases;
the covenant is broken, the cities are despised,
he regards no man.

**33:9** The land mourns and languishes;
Lebanon is ashamed, it withers away;
Sharon is like a wilderness;
and Bashan and Carmel shake off their leaves.

**33:10** Now will I arise, says YHWH;
now will I be exalted;
now will I lift up myself.

**33:11** You conceive chaff, you bring forth stubble;
your breath is a fire that shall devour you.

**33:12** And the peoples shall be as the burnings of lime;
as thorns cut down, that are burned in the fire.

**33:13** Hear, you that are far off, what I have done;
and, you that are near, acknowledge my might.

**33:14** The sinners in Zion are afraid;
trembling has seized the ungodly:
"Who among us shall dwell with the devouring fire?
Who among us shall dwell with everlasting burnings?"

**33:15** He that walks righteously, and speaks uprightly;
he that despises the gain of oppressions,
that shakes his hands from holding of bribes,
that stops his ears from hearing of blood,
and shuts his eyes from looking upon evil;

**33:16** He shall dwell on high; his place of defence shall be the munitions of rocks;
his bread shall be given him; his waters shall be sure.

---

## The King in His Beauty (33:17-24)

**33:17** Your eyes shall see the king in his beauty;
they shall behold a land stretching afar.

**33:18** Your heart shall muse on the terror:
"Where is he that counted, where is he that weighed?
Where is he that counted the towers?"

**33:19** You shall not see the fierce people,
a people of a deep speech that you cannot perceive,
of a stammering tongue that you cannot understand.

**33:20** Look upon Zion, the city of our solemn gatherings;
your eyes shall see Jerusalem a peaceful habitation,
a tent that shall not be removed,
the stakes whereof shall never be plucked up,
neither shall any of the cords thereof be broken.

**33:21** But there YHWH will be with us in majesty,
a place of broad rivers and streams,
wherein shall go no galley with oars,
neither shall gallant ship pass thereby.

**33:22** For YHWH is our judge, YHWH is our lawgiver,
YHWH is our king; he will save us.

**33:23** Your tacklings are loosed; they do not hold the stand of their mast,
they do not spread the sail;
then is the prey of a great spoil divided;
the lame take the prey.

**33:24** And the inhabitant shall not say: "I am sick";
the people that dwell therein shall be forgiven their iniquity.

---

## Synthesis Notes

**Key Restorations:**

**Destroyer Destroyed (33:1):**
"Woe to you that spoil, and you were not spoiled."

*Hoy shoded ve-attah lo shadud*—unspoiled spoiler.

"Deal treacherously, and they dealt not treacherously with you."

*U-voged ve-lo-vagdu vo*—betrayed betrayer.

"When you have ceased to spoil, you shall be spoiled."

*Ke-hatimekha shadod tusshad*—lex talionis.

**Prayer (33:2):**
"O YHWH, be gracious unto us."

*YHWH chonnenu*—grace plea.

"We have waited for you."

*Lekha qivvinu*—waiting.

"Be their arm every morning."

*Heyeh zero'am li-beqarim*—daily strength.

"Our salvation also in the time of trouble."

*Af-yeshu'atenu be-et tzarah*—trouble-salvation.

**YHWH Exalted (33:5-6):**
"YHWH is exalted, for he dwells on high."

*Nisgav YHWH ki shokhen marom*—exalted high-dweller.

"He has filled Zion with justice and righteousness."

*Mille Tziyyon mishpat u-tzedaqah*—Zion filled with justice.

**The Key Verse (33:6):**
"There shall be faith in your times."

*Ve-hayah emunat ittekha*—faith in your times.

"Strength of salvation, wisdom, and knowledge."

*Chosen yeshu'ot chokhmah va-da'at*—salvation, wisdom, knowledge.

"The fear of YHWH is his treasure."

*Yir'at YHWH hi otzaro*—YHWH-fear = treasure.

**Devastation (33:7-9):**
"Their valiant ones cry without."

*Hen er'ellam tza'aqu chutzah*—valiant ones cry.

"The ambassadors of peace weep bitterly."

*Mal'akhei shalom mar yivkayun*—peace ambassadors weep.

"The highways lie waste."

*Nashamu mesillot*—empty highways.

"The covenant is broken."

*Hefer berit*—broken covenant.

"Lebanon is ashamed, it withers away."

*Chofer Levanon qamel*—Lebanon withers.

**YHWH Rises (33:10-13):**
"Now will I arise, says YHWH."

*Attah aqum yomar YHWH*—YHWH arises.

"Now will I be exalted."

*Attah eromam*—exalted.

"Now will I lift up myself."

*Attah innase*—lifted.

"You conceive chaff, you bring forth stubble."

*Taharu chashash teledu qash*—empty births.

"Your breath is a fire that shall devour you."

*Ruchakhem esh tokhelkhem*—own breath consumes.

"Hear, you that are far off, what I have done."

*Shim'u rechoqim asher asiti*—far ones hear.

"You that are near, acknowledge my might."

*U-de'u qerovim gevurati*—near ones know might.

**The Key Verses (33:14-16):**
"The sinners in Zion are afraid."

*Pachadu be-Tziyyon chatta'im*—sinners afraid.

"'Who among us shall dwell with the devouring fire?'"

*Mi yagur lanu esh okhelah*—devouring fire.

"'Who among us shall dwell with everlasting burnings?'"

*Mi yagur lanu moqdei olam*—eternal burnings.

"He that walks righteously, and speaks uprightly."

*Holekh tzedaqot ve-dover meisharim*—righteous walk/speech.

"He that despises the gain of oppressions."

*Mo'es be-vetza ma'ashshaqqot*—despises oppressive gain.

"That shakes his hands from holding of bribes."

*No'er kappav mi-temokh ba-shochad*—refuses bribes.

"That stops his ears from hearing of blood."

*Otem ozno mi-shemo'a damim*—ears closed to bloodshed.

"That shuts his eyes from looking upon evil."

*Ve-otzem einav me-re'ot be-ra*—eyes shut to evil.

"He shall dwell on high."

*Hu meromim yishkon*—dwell high.

"His bread shall be given him; his waters shall be sure."

*Lachmo nittan meimav ne'emanim*—provision sure.

**The King in Beauty (33:17-22):**
"Your eyes shall see the king in his beauty."

*Melekh be-yofyo techezeynah einekha*—king's beauty seen.

"They shall behold a land stretching afar."

*Tir'eynah eretz marchqqim*—far land.

"'Where is he that counted?... Where is he that counted the towers?'"

*Ayyeh sofer ayyeh shoqel ayyeh sofer et-ha-migdalim*—oppressors gone.

"Look upon Zion, the city of our solemn gatherings."

*Chazeh Tziyyon qiryat mo'adenu*—festival city.

"Your eyes shall see Jerusalem a peaceful habitation."

*Einekha tir'eynah Yerushalayim naveh sha'anan*—peaceful Jerusalem.

"A tent that shall not be removed."

*Ohel bal-yitzan*—unmoved tent.

**The Key Verse (33:22):**
"YHWH is our judge."

*Ki YHWH shoftenu*—YHWH judges.

"YHWH is our lawgiver."

*YHWH mechoqeqenu*—YHWH gives law.

"YHWH is our king."

*YHWH malkenu*—YHWH rules.

"He will save us."

*Hu yoshi'enu*—YHWH saves.

**Healing (33:24):**
"The inhabitant shall not say: 'I am sick.'"

*U-val-yomar shakhen chaliti*—no sickness.

"The people that dwell therein shall be forgiven their iniquity."

*Ha-am ha-yoshev bah nesu avon*—iniquity forgiven.

**Archetypal Layer:** Isaiah 33 contains **"the fear of YHWH is his treasure" (33:6)**, **the entrance requirements for God's presence (33:14-16)**, and **the threefold office: "YHWH is our judge, YHWH is our lawgiver, YHWH is our king" (33:22)**.

**Ethical Inversion Applied:**
- "Woe to you that spoil, and you were not spoiled"—spoiler spoiled
- "We have waited for you"—waiting
- "YHWH is exalted, for he dwells on high"—exalted
- "He has filled Zion with justice and righteousness"—Zion just
- "The fear of YHWH is his treasure"—YHWH-fear = treasure
- "Their valiant ones cry without"—valiant weep
- "The covenant is broken"—broken covenant
- "Now will I arise, says YHWH"—YHWH rises
- "'Who among us shall dwell with the devouring fire?'"—fire question
- "He that walks righteously, and speaks uprightly"—entrance requirements
- "He that despises the gain of oppressions"—rejects oppression
- "That shakes his hands from holding of bribes"—no bribes
- "Your eyes shall see the king in his beauty"—king's beauty
- "YHWH is our judge, YHWH is our lawgiver, YHWH is our king"—threefold office
- "He will save us"—salvation
- "The inhabitant shall not say: 'I am sick'"—no sickness
- "The people... shall be forgiven their iniquity"—forgiveness

**Modern Equivalent:** Isaiah 33:22's threefold office (judge, lawgiver, king) describes YHWH's comprehensive authority. The entrance requirements (33:14-16) parallel Psalm 15 and 24. "The fear of YHWH is his treasure" (33:6) defines true wealth.

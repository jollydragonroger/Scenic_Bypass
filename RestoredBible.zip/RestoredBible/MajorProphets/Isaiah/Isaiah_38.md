# Isaiah 38: Hezekiah's Illness and Recovery

*From the Hebrew: בַּיָּמִים הָהֵם חָלָה חִזְקִיָּהוּ (Ba-Yamim Ha-Hem Chalah Chizkiyyahu) — In Those Days Was Hezekiah Sick*

---

## Hezekiah's Illness and Prayer (38:1-8)

**38:1** In those days was Hezekiah sick unto death. And Isaiah the prophet the son of Amoz came to him, and said unto him: "Thus says YHWH: Set your house in order; for you shall die, and not live."

**38:2** Then Hezekiah turned his face to the wall, and prayed unto YHWH,

**38:3** And said: "Remember now, O YHWH, I beseech you, how I have walked before you in truth and with a whole heart, and have done that which is good in your sight." And Hezekiah wept sore.

**38:4** Then came the word of YHWH to Isaiah, saying:

**38:5** "Go, and say to Hezekiah: Thus says YHWH, the God of David your father: I have heard your prayer, I have seen your tears; behold, I will add unto your days fifteen years.

**38:6** "And I will deliver you and this city out of the hand of the king of Assyria; and I will defend this city.

**38:7** "And this shall be the sign unto you from YHWH, that YHWH will do this thing that he has spoken:

**38:8** "Behold, I will cause the shadow on the steps, which is gone down on the dial of Ahaz with the sun, to return backward ten steps." So the sun returned ten steps on the dial whereon it was gone down.

---

## Hezekiah's Psalm (38:9-20)

**38:9** The writing of Hezekiah king of Judah, when he had been sick, and was recovered of his sickness.

**38:10** I said: In the noontide of my days I shall go, even to the gates of Sheol; I am deprived of the residue of my years.

**38:11** I said: I shall not see YAH, even YAH in the land of the living; I shall behold man no more with the inhabitants of the world.

**38:12** My habitation is plucked up and carried away from me as a shepherd's tent; I have rolled up like a weaver my life; he will cut me off from the loom; from day even to night will you make an end of me.

**38:13** I waited patiently till morning; as a lion, so he breaks all my bones; from day even to night will you make an end of me.

**38:14** Like a swallow or a crane, so do I chatter; I moan as a dove; my eyes fail with looking upward; O Lord, I am oppressed, be my surety.

**38:15** What shall I say? He has both spoken unto me, and himself has done it; I shall go softly all my years because of the bitterness of my soul.

**38:16** O Lord, by these things men live, and altogether therein is the life of my spirit; wherefore recover me, and make me to live.

**38:17** Behold, for my peace I had great bitterness; but you have in love to my soul delivered it from the pit of corruption; for you have cast all my sins behind your back.

**38:18** For Sheol cannot thank you, death cannot praise you; they that go down into the pit cannot hope for your truth.

**38:19** The living, the living, he shall praise you, as I do this day; the father to the children shall make known your truth.

**38:20** YHWH is ready to save me; therefore we will sing my songs to the stringed instruments all the days of our life in the house of YHWH.

---

## The Fig Poultice (38:21-22)

**38:21** Now Isaiah had said: "Let them take a cake of figs, and lay it for a plaster upon the boil, and he shall recover."

**38:22** Hezekiah also had said: "What is the sign that I shall go up to the house of YHWH?"

---

## Synthesis Notes

**Key Restorations:**

**Illness Announcement (38:1):**
"In those days was Hezekiah sick unto death."

*Ba-yamim ha-hem chalah Chizkiyyahu la-mut*—mortal illness.

"Set your house in order."

*Tzav le-veitekha*—arrange affairs.

"For you shall die, and not live."

*Ki met attah ve-lo tichyeh*—death sentence.

**Hezekiah's Prayer (38:2-3):**
"Hezekiah turned his face to the wall."

*Va-yassev Chizkiyyahu panav el-ha-qir*—turned to wall.

"Prayed unto YHWH."

*Va-yitpallel el-YHWH*—prayer.

"Remember now, O YHWH... how I have walked before you in truth."

*Anna YHWH zekhar-na et asher hithalakhti lefanekha be-emet*—truthful walk.

"With a whole heart."

*U-ve-lev shalem*—whole heart.

"Have done that which is good in your sight."

*Ve-ha-tov be-einekha asiti*—good done.

"Hezekiah wept sore."

*Va-yevk Chizkiyyahu bekhi gadol*—great weeping.

**YHWH's Response (38:5-8):**
"I have heard your prayer, I have seen your tears."

*Shama'ti et-tefillatekha ra'iti et-dim'atekha*—prayer heard, tears seen.

"I will add unto your days fifteen years."

*Hineni yosif al-yamekha chameish esreh shanah*—fifteen years added.

"I will deliver you and this city out of the hand of the king of Assyria."

*U-mi-kaf melekh-Ashshur atzilekha ve-et ha-ir ha-zot*—Assyria deliverance.

"I will cause the shadow on the steps... to return backward ten steps."

*Hineni meshiv et-tzel ha-ma'alot asher yardah be-ma'alot Achaz ba-shemesh achoranit eser ma'alot*—sundial sign.

"The sun returned ten steps on the dial."

*Va-tashov ha-shemesh eser ma'alot ba-ma'alot asher yaradah*—sun returned.

**Hezekiah's Psalm (38:9-20):**
"The writing of Hezekiah king of Judah."

*Mikhtav le-Chizkiyyahu melekh-Yehudah*—Hezekiah's composition.

**The Key Verses (38:10-12):**
"In the noontide of my days I shall go, even to the gates of Sheol."

*Bi-demi yamai elekh be-sha'arei she'ol*—midlife death.

"I am deprived of the residue of my years."

*Puqqadti yeter shenotai*—years cut short.

"I shall not see YAH, even YAH in the land of the living."

*Lo-er'eh Yah Yah be-eretz ha-chayyim*—no more seeing YAH.

"My habitation is plucked up and carried away from me."

*Dori nissa ve-niglah minni*—tent removed.

"As a shepherd's tent."

*Ke-ohel ro'i*—shepherd's tent.

"I have rolled up like a weaver my life."

*Qippidti kha-oreg chayyai*—rolled up like fabric.

"He will cut me off from the loom."

*Mi-dallah yevatzze'eni*—cut from loom.

**The Key Verses (38:14-17):**
"Like a swallow or a crane, so do I chatter."

*Ka-sus agur ken atzaftzef*—bird sounds.

"I moan as a dove."

*Ehgeh ka-yonah*—dove moaning.

"My eyes fail with looking upward."

*Dallu einai la-marom*—eyes failing.

"O Lord, I am oppressed, be my surety."

*Adonai ashqah-li arveni*—asking surety.

"He has both spoken unto me, and himself has done it."

*Mah-adabber ve-amar-li ve-hu asah*—God spoke and did.

"I shall go softly all my years because of the bitterness of my soul."

*Eddaddeh khol-shenotai al-mar nafshi*—walking softly in bitterness.

"You have in love to my soul delivered it from the pit of corruption."

*Ve-attah chashaqta nafshi mi-shachat beli*—saved from pit.

"You have cast all my sins behind your back."

*Ki hishlakhta acharei gavekha kol-chata'ai*—sins behind God's back.

**The Key Verses (38:18-19):**
"Sheol cannot thank you, death cannot praise you."

*Ki lo she'ol todekka mavet yehalelekka*—Sheol silent.

"They that go down into the pit cannot hope for your truth."

*Lo-yesabberu yordei-vor el-amittekha*—pit-dwellers hopeless.

"The living, the living, he shall praise you, as I do this day."

*Chai chai hu yodekka kamoni ha-yom*—living praise.

"The father to the children shall make known your truth."

*Av le-vanim yodi'a el-amittekha*—generational teaching.

**The Key Verse (38:20):**
"YHWH is ready to save me."

*YHWH le-hoshi'eni*—YHWH saves.

"We will sing my songs to the stringed instruments all the days of our life in the house of YHWH."

*U-neginotai nenaggen kol-yemei chayyeinu al-beit YHWH*—lifelong temple praise.

**Fig Remedy (38:21-22):**
"Let them take a cake of figs, and lay it for a plaster upon the boil."

*Yis'u develat te'enim vi-yimrechu al-ha-shecchin*—fig poultice.

"He shall recover."

*Ve-yechi*—he will live.

"What is the sign that I shall go up to the house of YHWH?"

*Mah ot ki e'eleh beit YHWH*—sign for temple return.

**Archetypal Layer:** Isaiah 38 shows **Hezekiah's prayer changing the divine verdict**, **the sundial sign**, and **Hezekiah's thanksgiving psalm** emphasizing that the living praise God.

**Ethical Inversion Applied:**
- "In those days was Hezekiah sick unto death"—mortal illness
- "'Set your house in order; for you shall die'"—death sentence
- "Hezekiah turned his face to the wall, and prayed"—wall-prayer
- "'Remember now, O YHWH... how I have walked before you in truth'"—appeal to faithfulness
- "Hezekiah wept sore"—great weeping
- "'I have heard your prayer, I have seen your tears'"—prayer answered
- "'I will add unto your days fifteen years'"—fifteen years added
- "'I will cause the shadow... to return backward ten steps'"—sundial miracle
- "In the noontide of my days I shall go"—midlife death feared
- "I shall not see YAH, even YAH in the land of the living"—YAH seen in life
- "My habitation is plucked up... as a shepherd's tent"—tent metaphor
- "He will cut me off from the loom"—weaver metaphor
- "You have in love to my soul delivered it from the pit"—saved from pit
- "You have cast all my sins behind your back"—sins removed
- "Sheol cannot thank you, death cannot praise you"—dead silent
- "The living, the living, he shall praise you"—living praise
- "YHWH is ready to save me"—YHWH saves
- "Let them take a cake of figs"—natural remedy with divine healing

**Modern Equivalent:** Isaiah 38 shows prayer affecting outcomes—Hezekiah's fifteen additional years. The sundial miracle (38:8) demonstrates divine control over creation. Hezekiah's psalm emphasizes that the living praise God—incentive for healing. The fig poultice (38:21) shows natural means combined with divine healing.

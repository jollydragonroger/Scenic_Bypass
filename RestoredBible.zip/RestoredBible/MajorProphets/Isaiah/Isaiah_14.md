# Isaiah 14: The Fall of the King of Babylon

*From the Hebrew: כִּי יְרַחֵם יְהוָה אֶת־יַעֲקֹב (Ki Yerachem YHWH Et-Ya'aqov) — For YHWH Will Have Compassion on Jacob*

---

## Israel's Restoration (14:1-2)

**14:1** For YHWH will have compassion on Jacob, and will yet choose Israel, and set them in their own land; and the stranger shall join himself with them, and they shall cleave to the house of Jacob.

**14:2** And the peoples shall take them, and bring them to their place; and the house of Israel shall possess them in the land of YHWH for servants and for handmaids; and they shall take them captive, whose captives they were; and they shall rule over their oppressors.

---

## The Taunt Against the King of Babylon (14:3-23)

**14:3** And it shall come to pass in the day that YHWH shall give you rest from your sorrow, and from your trouble, and from the hard service wherein you were made to serve,

**14:4** That you shall take up this parable against the king of Babylon, and say:
How has the oppressor ceased! The golden city ceased!

**14:5** YHWH has broken the staff of the wicked, the sceptre of the rulers,

**14:6** That smote the peoples in wrath with an unceasing stroke, that ruled the nations in anger, with a persecution that none restrained.

**14:7** The whole earth is at rest, and is quiet; they break forth into singing.

**14:8** Yea, the cypresses rejoice at you, and the cedars of Lebanon: "Since you are laid down, no feller is come up against us."

**14:9** Sheol from beneath is moved for you to meet you at your coming; it stirs up the shades for you, even all the chief ones of the earth; it has raised up from their thrones all the kings of the nations.

**14:10** All they do answer and say unto you: "Are you also become weak as we? Are you become like unto us?

**14:11** "Your pomp is brought down to Sheol, and the noise of your psalteries; the maggot is spread under you, and the worms cover you."

**14:12** How are you fallen from heaven, O day-star, son of the dawn! How are you cut down to the ground, that did cast lots over the nations!

**14:13** And you said in your heart: "I will ascend into heaven, above the stars of God will I exalt my throne; and I will sit upon the mount of assembly, in the uttermost parts of the north;

**14:14** "I will ascend above the heights of the clouds; I will be like the Most High."

**14:15** Yet you shall be brought down to Sheol, to the uttermost parts of the pit.

**14:16** They that see you shall narrowly look upon you, they shall consider you: "Is this the man that made the earth to tremble, that did shake kingdoms;

**14:17** "That made the world as a wilderness, and destroyed the cities thereof; that let not loose his prisoners to their home?"

**14:18** All the kings of the nations, all of them, sleep in glory, every one in his own house.

**14:19** But you are cast forth away from your grave like an abhorred offshoot, clothed with the slain, that are thrust through with the sword, that go down to the stones of the pit; as a carcass trodden under foot.

**14:20** You shall not be joined with them in burial, because you have destroyed your land, you have slain your people; the seed of evil-doers shall not be named forever.

**14:21** Prepare slaughter for his children for the iniquity of their fathers; that they rise not up, and possess the earth, and fill the face of the world with cities.

**14:22** And I will rise up against them, says YHWH of hosts, and cut off from Babylon name and remnant, and offspring and posterity, says YHWH.

**14:23** I will also make it a possession for the bittern, and pools of water; and I will sweep it with the besom of destruction, says YHWH of hosts.

---

## Oracle Against Assyria (14:24-27)

**14:24** YHWH of hosts has sworn, saying: Surely as I have thought, so shall it come to pass; and as I have purposed, so shall it stand:

**14:25** That I will break Assyria in my land, and upon my mountains tread him under foot; then shall his yoke depart from off them, and his burden depart from off their shoulder.

**14:26** This is the purpose that is purposed upon the whole earth; and this is the hand that is stretched out upon all the nations.

**14:27** For YHWH of hosts has purposed, and who shall annul it? And his hand is stretched out, and who shall turn it back?

---

## Oracle Against Philistia (14:28-32)

**14:28** In the year that king Ahaz died was this burden.

**14:29** Rejoice not, O Philistia, all of you, because the rod that smote you is broken; for out of the serpent's root shall come forth a basilisk, and his fruit shall be a flying serpent.

**14:30** And the first-born of the poor shall feed, and the needy shall lie down in safety; and I will kill your root with famine, and your remnant shall be slain.

**14:31** Wail, O gate; cry, O city; you are melted away, O Philistia, all of you; for there comes a smoke out of the north, and there is no straggler in his ranks.

**14:32** What then shall one answer the messengers of the nation? That YHWH has founded Zion, and in her shall the afflicted of his people take refuge.

---

## Synthesis Notes

**Key Restorations:**

**Israel Restored (14:1-2):**
"YHWH will have compassion on Jacob."

*Ki yerachem YHWH et-Ya'aqov*—compassion.

"Will yet choose Israel."

*U-vachar od be-Yisra'el*—renewed election.

"The stranger shall join himself with them."

*Ve-nilvah ha-ger aleihem*—strangers join.

**Taunt Song (14:3-11):**
"You shall take up this parable against the king of Babylon."

*Ve-nasa'ta ha-mashal ha-zeh al-melekh Bavel*—taunt song.

"How has the oppressor ceased!"

*Eikh shavat noges*—oppressor ended.

"The golden city ceased!"

*Shavtah madhevah*—golden city ended.

"YHWH has broken the staff of the wicked."

*Shavar YHWH matteh resha'im*—staff broken.

"The whole earth is at rest."

*Nachah shaqtah kol-ha-aretz*—earth rests.

"They break forth into singing."

*Patzechu rinnah*—singing breaks out.

"The cypresses rejoice at you, and the cedars of Lebanon."

*Gam-beroshim samechu lekha arzei Levanon*—trees rejoice.

**Sheol Scene (14:9-11):**
"Sheol from beneath is moved for you."

*She'ol mittachat ragezah lekha*—Sheol stirred.

"It stirs up the shades for you."

*Orer lekha refa'im*—shades awakened.

"All the chief ones of the earth."

*Kol-atudei aretz*—earth's leaders.

"It has raised up from their thrones all the kings of the nations."

*Heqim mi-khis'otam kol malkhei goyim*—kings rise.

"'Are you also become weak as we?'"

*Gam-attah chulleita khamonu*—weak like us.

"Your pomp is brought down to Sheol."

*Hurad she'ol ge'onekha*—pomp to Sheol.

"The maggot is spread under you."

*Tachtekha yutzza rimmah*—maggots.

**The Key Verses (14:12-15):**
"How are you fallen from heaven, O day-star, son of the dawn!"

*Eikh nafalta mi-shamayim Heilel ben-Shachar*—Heilel (day-star/Lucifer) fallen.

"How are you cut down to the ground."

*Nigda'ta la-aretz*—cut down.

"That did cast lots over the nations!"

*Cholesh al-goyim*—dominated nations.

**The Five "I Wills" (14:13-14):**
1. "I will ascend into heaven" — *E'eleh ha-shamayim*
2. "Above the stars of God will I exalt my throne" — *Mi-ma'al le-khokhevei-El arim kis'i*
3. "I will sit upon the mount of assembly" — *Ve-eshev be-har-mo'ed*
4. "I will ascend above the heights of the clouds" — *E'eleh al-bamotei av*
5. "I will be like the Most High" — *Eddammeh le-Elyon*

**The Key Verse (14:15):**
"Yet you shall be brought down to Sheol."

*Akh el-she'ol turad*—brought to Sheol.

"To the uttermost parts of the pit."

*El-yarketei-vor*—pit's depths.

**Disgraceful Death (14:16-21):**
"'Is this the man that made the earth to tremble?'"

*Ha-zeh ha-ish margiz ha-aretz*—this the trembler?

"You are cast forth away from your grave."

*Ve-attah hoshlakhta mi-qivrekha*—cast from grave.

"Like an abhorred offshoot."

*Ke-netzer nit'av*—abhorred branch.

"You shall not be joined with them in burial."

*Lo-techad ittam bi-qevurah*—no burial.

**Divine Sovereignty (14:24-27):**
"Surely as I have thought, so shall it come to pass."

*Im-lo ka-asher dimmiti ken haytah*—thought = reality.

"As I have purposed, so shall it stand."

*Ve-kha-asher ya'atzti hi taqum*—purpose stands.

**The Key Verse (14:27):**
"YHWH of hosts has purposed, and who shall annul it?"

*Ki YHWH Tzeva'ot ya'atz u-mi yafer*—who annuls?

"His hand is stretched out, and who shall turn it back?"

*Ve-yado ha-netuyah u-mi yeshivenah*—who turns back?

**Zion's Refuge (14:32):**
"YHWH has founded Zion."

*Ki-YHWH yissad Tziyyon*—Zion founded.

"In her shall the afflicted of his people take refuge."

*U-vah yechesu aniyyei ammo*—afflicted refuge.

**Archetypal Layer:** Isaiah 14 contains **the famous "Lucifer" passage (14:12-15)**—originally about Babylon's king but applied to Satan's fall. The five "I wills" show pride's trajectory. Divine sovereignty is absolute (14:27).

**Ethical Inversion Applied:**
- "YHWH will have compassion on Jacob"—compassion
- "The stranger shall join himself with them"—Gentile inclusion
- "How has the oppressor ceased!"—oppressor ends
- "The whole earth is at rest"—cosmic peace
- "Sheol from beneath is moved for you"—Sheol welcomes
- "'Are you also become weak as we?'"—equalizing death
- "How are you fallen from heaven, O day-star"—Heilel/Lucifer
- "'I will ascend into heaven'"—first "I will"
- "'I will be like the Most High'"—fifth "I will"
- "Yet you shall be brought down to Sheol"—descent
- "'Is this the man that made the earth to tremble?'"—deflated
- "YHWH of hosts has purposed, and who shall annul it?"—sovereignty
- "YHWH has founded Zion"—Zion secure

**Modern Equivalent:** Isaiah 14:12-15's "Lucifer" (Latin translation of *Heilel*) has been applied to Satan's fall (Luke 10:18). The five "I wills" exemplify pride. Divine sovereignty (14:27) is foundational theology.

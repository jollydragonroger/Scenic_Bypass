# Isaiah 41: YHWH's Challenge to the Nations

*From the Hebrew: הַחֲרִישׁוּ אֵלַי אִיִּים (Hacharishu Elai Iyyim) — Keep Silence Before Me, O Islands*

---

## The Summons to the Nations (41:1-7)

**41:1** Keep silence before me, O islands, and let the peoples renew their strength; let them come near, then let them speak; let us come near together to judgment.

**41:2** Who has raised up one from the east, whom he calls in righteousness to his foot? He gives nations before him, and makes him rule over kings; his sword makes them as dust, his bow as driven stubble.

**41:3** He pursues them, and passes on safely; the way with his feet he does not tread.

**41:4** Who has wrought and done it? He that called the generations from the beginning. I, YHWH, am the first, and with the last I am he.

**41:5** The isles saw, and feared; the ends of the earth trembled; they drew near, and came.

**41:6** They helped every one his neighbor; and every one said to his brother: "Be of good courage."

**41:7** So the carpenter encouraged the goldsmith, and he that smooths with the hammer him that smites the anvil, saying of the soldering: "It is good"; and he fastened it with nails, that it should not be moved.

---

## Israel, YHWH's Servant (41:8-20)

**41:8** But you, Israel, my servant, Jacob whom I have chosen, the seed of Abraham my friend;

**41:9** You whom I have taken hold of from the ends of the earth, and called from the corners thereof, and said unto you: "You are my servant, I have chosen you and not cast you away";

**41:10** Fear not, for I am with you; be not dismayed, for I am your God; I will strengthen you, yea, I will help you; yea, I will uphold you with my victorious right hand.

**41:11** Behold, all they that are incensed against you shall be ashamed and confounded; they that strive with you shall be as nothing, and shall perish.

**41:12** You shall seek them, and shall not find them, even them that contend with you; they that war against you shall be as nothing, and as a thing of nought.

**41:13** For I YHWH your God hold your right hand, who says unto you: "Fear not, I help you."

**41:14** Fear not, you worm Jacob, and you men of Israel; I help you, says YHWH, and your Redeemer is the Holy One of Israel.

**41:15** Behold, I make you a new sharp threshing-sledge having teeth; you shall thresh the mountains, and beat them small, and shall make the hills as chaff.

**41:16** You shall fan them, and the wind shall carry them away, and the whirlwind shall scatter them; and you shall rejoice in YHWH, you shall glory in the Holy One of Israel.

**41:17** The poor and needy seek water, and there is none, and their tongue fails for thirst; I YHWH will answer them, I the God of Israel will not forsake them.

**41:18** I will open rivers on the bare heights, and fountains in the midst of the valleys; I will make the wilderness a pool of water, and the dry land springs of water.

**41:19** I will plant in the wilderness the cedar, the acacia-tree, and the myrtle, and the oil-tree; I will set in the desert the cypress, the plane-tree, and the larch together;

**41:20** That they may see, and know, and consider, and understand together, that the hand of YHWH has done this, and the Holy One of Israel has created it.

---

## The Challenge to the Idols (41:21-29)

**41:21** Produce your cause, says YHWH; bring forth your strong reasons, says the King of Jacob.

**41:22** Let them bring them forth, and declare unto us what shall happen; the former things, what are they? Declare, that we may consider, and know the end of them; or announce to us things to come.

**41:23** Declare the things that are to come hereafter, that we may know that you are gods; yea, do good, or do evil, that we may be dismayed, and behold it together.

**41:24** Behold, you are nothing, and your work is of nought; an abomination is he that chooses you.

**41:25** I have raised up one from the north, and he is come; from the rising of the sun one that calls upon my name; and he shall come upon rulers as upon mortar, and as the potter treads clay.

**41:26** Who has declared from the beginning, that we may know? And beforetime, that we may say: "He is right"? Yea, there is none that declares, yea, there is none that announces, yea, there is none that hears your utterances.

**41:27** A harbinger unto Zion will I give: "Behold, behold them," and to Jerusalem a messenger of good tidings.

**41:28** And I look, but there is no man; even among them, but there is no counsellor, that, when I ask of them, can give an answer.

**41:29** Behold, all of them, their works are vanity and nought; their molten images are wind and confusion.

---

## Synthesis Notes

**Key Restorations:**

**Courtroom Summons (41:1):**
"Keep silence before me, O islands."

*Hacharishu elai iyyim*—silence commanded.

"Let the peoples renew their strength."

*U-le'ummim yachalifu kho'ach*—strength for trial.

"Let us come near together to judgment."

*Yachdav la-mishpat niqravah*—courtroom scene.

**Cyrus Introduced (41:2-4):**
"Who has raised up one from the east."

*Mi he'ir mi-mizrach*—one from east (Cyrus).

"Whom he calls in righteousness to his foot."

*Tzedeq yiqra'ehu le-raglo*—called righteously.

"He gives nations before him."

*Yitten lefanav goyim*—nations given.

"Makes him rule over kings."

*U-melakhim yard*—rules kings.

"His sword makes them as dust."

*Yitten ke-afar charbo*—sword makes dust.

**The Key Verse (41:4):**
"Who has wrought and done it?"

*Mi-fa'al ve-asah*—who did this?

"He that called the generations from the beginning."

*Qore ha-dorot me-rosh*—calling generations.

"I, YHWH, am the first, and with the last I am he."

*Ani YHWH rishon ve-et-acharonim ani-hu*—first and last. Revelation 1:17; 22:13 echoes this.

**Idol-Making (41:5-7):**
"The isles saw, and feared."

*Ra'u iyyim ve-yira'u*—islands fear.

"They helped every one his neighbor."

*Ya'azru ish et-re'ehu*—mutual help.

"The carpenter encouraged the goldsmith."

*Va-yechazzeq charash et-tzroref*—craftsmen collaborate.

"He fastened it with nails, that it should not be moved."

*Va-yechazqehu be-masmerim lo yimmot*—nailed idol.

**The Key Verses (41:8-10):**
"But you, Israel, my servant."

*Ve-attah Yisra'el avdi*—Israel = servant.

"Jacob whom I have chosen."

*Ya'aqov asher bechartikha*—chosen Jacob.

"The seed of Abraham my friend."

*Zera Avraham ohavi*—Abraham's seed, my friend. James 2:23 cites this.

"You whom I have taken hold of from the ends of the earth."

*Asher hechezaqtikha mi-qetzot ha-aretz*—taken from earth's ends.

"'You are my servant, I have chosen you and not cast you away.'"

*Avdi-attah bechartikha ve-lo me'astikha*—chosen, not rejected.

**The Key Verse (41:10):**
"Fear not, for I am with you."

*Al-tira ki immekha-ani*—fear not, I'm with you.

"Be not dismayed, for I am your God."

*Al-tishta ki-ani Elohekha*—don't be dismayed.

"I will strengthen you."

*Immatzttikha*—strengthened.

"Yea, I will help you."

*Af-azartikha*—helped.

"Yea, I will uphold you with my victorious right hand."

*Af-temakhtikha bi-yemin tzidqi*—upheld by righteous right hand.

**Fear Not (41:13-14):**
"I YHWH your God hold your right hand."

*Ki ani YHWH Elohekha machaziq yeminekha*—holding hand.

"'Fear not, I help you.'"

*Al-tira ani azartikha*—help promised.

"Fear not, you worm Jacob."

*Al-tir'i tola'at Ya'aqov*—worm Jacob.

"Your Redeemer is the Holy One of Israel."

*Ve-go'alekh Qedosh Yisra'el*—Redeemer = Holy One.

**Transformation (41:15-20):**
"I make you a new sharp threshing-sledge having teeth."

*Hinneh samttikha le-morag charutz chadash ba'al pifiyyot*—threshing sledge.

"You shall thresh the mountains."

*Tadush harim*—thresh mountains.

"The poor and needy seek water."

*Ha-aniyyim ve-ha-evyonim mevaqeshim mayim*—seeking water.

"I YHWH will answer them."

*Ani YHWH e'enem*—YHWH answers.

"I will open rivers on the bare heights."

*Eftach al-shefayim neharot*—rivers on heights.

"I will make the wilderness a pool of water."

*Asim midbar la-agam-mayim*—wilderness to pool.

"I will plant in the wilderness the cedar."

*Etten ba-midbar erez*—cedar planted.

"That they may see, and know, and consider, and understand."

*Lema'an yir'u ve-yede'u ve-yasimu ve-yaskilu yachdav*—see, know, consider, understand.

"The hand of YHWH has done this."

*Ki yad-YHWH asetah zot*—YHWH's hand.

**Idol Challenge (41:21-29):**
"Produce your cause, says YHWH."

*Qarevu rivekhem yomar YHWH*—present case.

"Bring forth your strong reasons, says the King of Jacob."

*Haggishu atzumotekhem yomar melekh Ya'aqov*—King of Jacob.

"Declare unto us what shall happen."

*Yaggidu ha-otiyyot mah-hennah*—declare future.

"Declare the things that are to come hereafter."

*Haggidu ha-otiyyot le-achor*—things to come.

"That we may know that you are gods."

*Ve-nede'ah ki elohim attem*—prove divinity.

**The Key Verse (41:24):**
"Behold, you are nothing, and your work is of nought."

*Hen-attem me-ayin u-fo'alkhem me-afa*—idols = nothing.

"An abomination is he that chooses you."

*To'evah yivchar bakhem*—choosing idols = abomination.

**Cyrus Again (41:25-27):**
"I have raised up one from the north."

*Ha'iroti mi-tzafon va-yat*—from north.

"From the rising of the sun one that calls upon my name."

*Mi-mizrach-shemesh yiqra vi-shemi*—calls YHWH's name.

"He shall come upon rulers as upon mortar."

*Ve-yavo seganim kemo-chomer*—tramples rulers.

"A harbinger unto Zion will I give."

*Rishon le-Tziyyon hinneh hinnam*—herald to Zion.

"To Jerusalem a messenger of good tidings."

*U-li-Yerushalayim mevasser etten*—good news messenger.

**The Key Verse (41:29):**
"Behold, all of them, their works are vanity and nought."

*Hen kullam aven efes ma'aseihem*—all vanity.

"Their molten images are wind and confusion."

*Ruach va-tohu niskeyhem*—wind and chaos.

**Archetypal Layer:** Isaiah 41 introduces **the Servant theme (41:8-10)**, **"Fear not" repeated (41:10, 13, 14)**, **YHWH as first and last (41:4)**, and **Cyrus as YHWH's instrument (41:2, 25)**.

**Ethical Inversion Applied:**
- "Keep silence before me, O islands"—courtroom summons
- "Who has raised up one from the east"—Cyrus introduced
- "I, YHWH, am the first, and with the last I am he"—Revelation 1:17
- "You, Israel, my servant, Jacob whom I have chosen"—servant Israel
- "The seed of Abraham my friend"—James 2:23
- "'You are my servant, I have chosen you'"—election
- "Fear not, for I am with you"—presence promise
- "I will strengthen you, yea, I will help you"—help promised
- "I will uphold you with my victorious right hand"—upheld
- "I YHWH your God hold your right hand"—hand-holding
- "'Fear not, I help you'"—repeated
- "Fear not, you worm Jacob"—worm to threshing sledge
- "Your Redeemer is the Holy One of Israel"—Redeemer
- "I make you a new sharp threshing-sledge"—empowered
- "The poor and needy seek water"—provision
- "I will open rivers on the bare heights"—transformation
- "That they may see, and know"—recognition
- "Produce your cause, says YHWH"—idol trial
- "Declare the things that are to come... that we may know that you are gods"—prediction test
- "Behold, you are nothing"—idols = nothing
- "I have raised up one from the north"—Cyrus again
- "Their molten images are wind and confusion"—idols = chaos

**Modern Equivalent:** Isaiah 41:4's "I, YHWH, am the first, and with the last I am he" is echoed in Revelation 1:17; 22:13. The "fear not" promises (41:10, 13, 14) are among Scripture's most beloved. Abraham called "my friend" (41:8) is cited in James 2:23.

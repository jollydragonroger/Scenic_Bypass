# Isaiah 24: The Devastation of the Earth

*From the Hebrew: הִנֵּה יְהוָה בּוֹקֵק הָאָרֶץ (Hinneh YHWH Boqeq Ha-Aretz) — Behold, YHWH Makes the Earth Empty*

---

## Universal Judgment (24:1-13)

**24:1** Behold, YHWH makes the earth empty, and makes it waste,
and turns it upside down, and scatters abroad the inhabitants thereof.

**24:2** And it shall be, as with the people, so with the priest;
as with the servant, so with his master;
as with the maid, so with her mistress;
as with the buyer, so with the seller;
as with the lender, so with the borrower;
as with the creditor, so with the debtor.

**24:3** The earth shall be utterly emptied, and clean despoiled;
for YHWH has spoken this word.

**24:4** The earth faints and fades away,
the world languishes and fades away,
the lofty people of the earth do languish.

**24:5** The earth also is polluted under the inhabitants thereof;
because they have transgressed the laws, violated the statute,
broken the everlasting covenant.

**24:6** Therefore has a curse devoured the earth,
and they that dwell therein are found guilty;
therefore the inhabitants of the earth waste away,
and few men left.

**24:7** The new wine mourns, the vine languishes,
all the merry-hearted do sigh.

**24:8** The mirth of tabrets ceases,
the noise of them that rejoice ends,
the joy of the harp ceases.

**24:9** They drink not wine with a song;
strong drink is bitter to them that drink it.

**24:10** Broken down is the city of wasteness;
every house is shut up, that none may come in.

**24:11** There is a crying in the streets because of the wine;
all joy is darkened, the mirth of the land is gone.

**24:12** In the city is left desolation,
and the gate is smitten unto ruin.

**24:13** For thus shall it be in the midst of the earth, among the peoples,
as at the beating of an olive-tree,
as at the gleanings when the vintage is done.

---

## Songs from the Ends of the Earth (24:14-16)

**24:14** These shall lift up their voice, they shall sing;
for the majesty of YHWH they cry aloud from the sea.

**24:15** Wherefore glorify YHWH in the regions of light,
even the name of YHWH, the God of Israel, in the isles of the sea.

**24:16** From the uttermost part of the earth have we heard songs:
"Glory to the righteous."
But I said: I pine away, I pine away, woe is me!
The treacherous deal treacherously;
yea, the treacherous deal very treacherously.

---

## Terror and Judgment (24:17-23)

**24:17** Terror, and the pit, and the trap, are upon you, O inhabitant of the earth.

**24:18** And it shall come to pass, that he who flees from the noise of the terror shall fall into the pit;
and he that comes up out of the midst of the pit shall be taken in the trap;
for the windows on high are opened,
and the foundations of the earth do shake.

**24:19** The earth is broken, broken down,
the earth is crumbled in pieces,
the earth trembles and totters.

**24:20** The earth reels to and fro like a drunken man,
and sways to and fro as a lodge;
and the transgression thereof is heavy upon it,
and it shall fall, and not rise again.

**24:21** And it shall come to pass in that day,
that YHWH will punish the host of the high heaven on high,
and the kings of the earth upon the earth.

**24:22** And they shall be gathered together, as prisoners are gathered in the dungeon,
and shall be shut up in the prison,
and after many days shall they be punished.

**24:23** Then the moon shall be confounded, and the sun ashamed;
for YHWH of hosts will reign in mount Zion, and in Jerusalem,
and before his elders shall be glory.

---

## Synthesis Notes

**Key Restorations:**

**Universal Judgment (24:1-3):**
"YHWH makes the earth empty, and makes it waste."

*YHWH boqeq ha-aretz u-volelah*—emptying and wasting.

"Turns it upside down."

*Ve-ivvah fanekha*—face twisted.

"Scatters abroad the inhabitants thereof."

*Ve-hefitz yoshevekha*—inhabitants scattered.

**The Key Verse (24:2):**
"As with the people, so with the priest."

*Ve-hayah kha-am ka-kohen*—all equal in judgment.

"As with the servant, so with his master."

*Ka-eved ka-adonav*—no class distinction.

"As with the buyer, so with the seller."

*Ka-qoneh ka-mokhér*—economic equality.

"As with the lender, so with the borrower."

*Ka-malveh ka-loveh*—financial equality.

**The Key Verse (24:5):**
"The earth also is polluted under the inhabitants thereof."

*Ve-ha-aretz chanefah tachat yoshevekha*—earth polluted.

"They have transgressed the laws."

*Ki averu torot*—laws transgressed.

"Violated the statute."

*Chalefu choq*—statute violated.

"Broken the everlasting covenant."

*Heferu berit olam*—eternal covenant broken.

**The Key Verse (24:6):**
"A curse devoured the earth."

*Al-ken alah akhelah eretz*—curse devours.

"The inhabitants of the earth waste away."

*Va-yecheru yoshevei eretz*—inhabitants burn.

"Few men left."

*Ve-nish'ar enosh miz'ar*—few remain.

**Joy Ended (24:7-12):**
"The new wine mourns, the vine languishes."

*Aval tirosh umlalah gafen*—wine mourns.

"All the merry-hearted do sigh."

*Ne'enechu kol-simchei-lev*—merry sigh.

"The mirth of tabrets ceases."

*Shavat mesos tuppim*—tambourine mirth ends.

"The joy of the harp ceases."

*Shavat mesos kinnor*—harp joy ends.

"They drink not wine with a song."

*Ba-shir lo-yishtu yayin*—no singing with wine.

"Broken down is the city of wasteness."

*Nishberah qiryat-tohu*—chaos city broken.

"In the city is left desolation."

*Nish'ar ba-ir shammah*—desolation remains.

**Remnant (24:13-16):**
"As at the beating of an olive-tree."

*Ke-noqef zayit*—olive gleanings.

"As at the gleanings when the vintage is done."

*Ke-olelot im-kalah batzir*—vintage gleanings.

"These shall lift up their voice, they shall sing."

*Hemmah yis'u qolam yarónnu*—remnant sings.

"For the majesty of YHWH they cry aloud from the sea."

*Bi-ge'on YHWH tzahalu mi-yam*—sea-praise.

"'Glory to the righteous.'"

*Tzevi la-tzaddiq*—glory to righteous.

"But I said: I pine away, I pine away, woe is me!"

*Va-omar razi-li razi-li oy li*—prophet's distress.

**Terror Trio (24:17-18):**
"Terror, and the pit, and the trap."

*Pachad va-fachat va-pach*—alliterative terror (pachad/pachat/pach).

"He who flees from the noise of the terror shall fall into the pit."

*Ve-hayah ha-nas mi-qol ha-pachad yippol el-ha-pachat*—no escape.

"He that comes up out of the midst of the pit shall be taken in the trap."

*Ve-ha-oleh mi-tokh ha-pachat yillakhed ba-pach*—caught anyway.

"The windows on high are opened."

*Ki-arubbbot mi-marom niftachu*—heavenly windows (Genesis 7:11 echo).

"The foundations of the earth do shake."

*U-mosedeyi eretz yir'ashu*—foundations shake.

**The Key Verses (24:19-20):**
"The earth is broken, broken down."

*Ro'ah hitro'a'ah ha-aretz*—broken.

"The earth is crumbled in pieces."

*Por hitporrah eretz*—crumbled.

"The earth trembles and totters."

*Mot hitmottetah eretz*—tottering.

"The earth reels to and fro like a drunken man."

*Nu'a tanu'a eretz ka-shikkkor*—drunken reeling.

"Sways to and fro as a lodge."

*Ve-hitnod'dah ka-melunah*—swaying like hut.

**Cosmic Judgment (24:21-23):**
"YHWH will punish the host of the high heaven on high."

*Yifqod YHWH al-tzeva ha-marom ba-marom*—heavenly host punished.

"The kings of the earth upon the earth."

*Ve-al-malkhei ha-adamah al-ha-adamah*—earthly kings punished.

"They shall be gathered together, as prisoners are gathered in the dungeon."

*Ve-usfu asefah assir al-bor*—imprisoned.

"After many days shall they be punished."

*U-me-rov yamim yippaqedu*—later punishment.

**The Key Verse (24:23):**
"The moon shall be confounded, and the sun ashamed."

*Ve-chaferah ha-levanah u-voshah ha-chammah*—moon/sun shamed.

"YHWH of hosts will reign in mount Zion, and in Jerusalem."

*Ki-malakh YHWH Tzeva'ot be-har Tziyyon u-vi-Yerushalayim*—YHWH reigns.

"Before his elders shall be glory."

*Ve-neged zeqenav kavod*—glory before elders.

**Archetypal Layer:** Isaiah 24 begins the **"Isaiah Apocalypse" (chapters 24-27)**—cosmic eschatology. The earth judged, covenant broken (24:5), heavenly hosts punished (24:21), YHWH reigns in Zion (24:23).

**Ethical Inversion Applied:**
- "YHWH makes the earth empty, and makes it waste"—de-creation
- "As with the people, so with the priest"—universal judgment
- "The earth also is polluted under the inhabitants thereof"—polluted earth
- "They have transgressed the laws, violated the statute, broken the everlasting covenant"—covenant broken
- "A curse devoured the earth"—curse
- "Few men left"—remnant
- "The mirth of tabrets ceases"—joy ended
- "Broken down is the city of wasteness"—chaos city
- "Terror, and the pit, and the trap"—alliterative terror
- "The windows on high are opened"—Genesis flood echo
- "The earth reels to and fro like a drunken man"—drunken earth
- "YHWH will punish the host of the high heaven on high"—heavenly punishment
- "The kings of the earth upon the earth"—earthly kings
- "The moon shall be confounded, and the sun ashamed"—cosmic shame
- "YHWH of hosts will reign in mount Zion"—YHWH reigns

**Modern Equivalent:** Isaiah 24 introduces apocalyptic eschatology. The "everlasting covenant" broken (24:5) may refer to the Noahic covenant. Cosmic judgment (24:21-23) includes heavenly beings. YHWH's reign in Zion (24:23) anticipates Revelation's vision.

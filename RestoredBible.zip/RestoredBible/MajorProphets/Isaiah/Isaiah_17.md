# Isaiah 17: The Oracle Against Damascus

*From the Hebrew: מַשָּׂא דַּמֶּשֶׂק (Massa Dammeseq) — The Burden of Damascus*

---

## Damascus and Israel's Fall (17:1-6)

**17:1** The burden of Damascus.
Behold, Damascus is taken away from being a city,
and it shall be a ruinous heap.

**17:2** The cities of Aroer are forsaken;
they shall be for flocks, which shall lie down,
and none shall make them afraid.

**17:3** The fortress also shall cease from Ephraim,
and the kingdom from Damascus;
and the remnant of Aram shall be as the glory of the children of Israel,
says YHWH of hosts.

**17:4** And it shall come to pass in that day,
that the glory of Jacob shall be made thin,
and the fatness of his flesh shall wax lean.

**17:5** And it shall be as when the harvestman gathers the standing grain,
and his arm reaps the ears;
yea, it shall be as when one gleans ears in the valley of Rephaim.

**17:6** Yet there shall be left therein gleanings,
as at the beating of an olive-tree,
two or three berries in the top of the uppermost bough,
four or five in the branches of the fruitful tree,
says YHWH, the God of Israel.

---

## Turning to the Maker (17:7-8)

**17:7** In that day shall a man look unto his Maker,
and his eyes shall have regard to the Holy One of Israel.

**17:8** And he shall not look to the altars, the work of his hands,
neither shall he have regard to that which his fingers have made,
either the Asherim, or the sun-images.

---

## Forgotten God (17:9-11)

**17:9** In that day shall his strong cities be as the forsaken places,
which were forsaken from before the children of Israel, after the manner of woods and lofty forests;
and it shall be a desolation.

**17:10** For you have forgotten the God of your salvation,
and have not been mindful of the Rock of your stronghold;
therefore you plant plants of pleasantness,
and set it with strange slips.

**17:11** In the day of your planting you hedge it in,
and in the morning you make your seed to blossom;
but the harvest flees away in the day of grief and of desperate pain.

---

## The Raging Nations (17:12-14)

**17:12** Ah, the uproar of many peoples,
that roar like the roaring of the seas;
and the rushing of nations, that rush like the rushing of mighty waters!

**17:13** The nations shall rush like the rushing of many waters;
but he shall rebuke them, and they shall flee far off,
and shall be chased as the chaff of the mountains before the wind,
and like the whirling dust before the storm.

**17:14** At eventide behold terror;
and before the morning they are not.
This is the portion of them that spoil us,
and the lot of them that rob us.

---

## Synthesis Notes

**Key Restorations:**

**Title (17:1):**
"The burden of Damascus."

*Massa Dammeseq*—oracle against Syria's capital.

Damascus and Israel (Ephraim) were allied against Judah (Syro-Ephraimite crisis, 735 BCE).

**Damascus Destroyed (17:1-3):**
"Damascus is taken away from being a city."

*Hinneh Dammeseq musar me-ir*—ceases as city.

"It shall be a ruinous heap."

*Ve-haytah me'i mappalah*—ruinous heap.

"The cities of Aroer are forsaken."

*Azuvot arei Aro'er*—abandoned cities.

"They shall be for flocks."

*La-adarim tihyeynah*—flocks graze.

"None shall make them afraid."

*Ve-ein machrid*—no one frightens.

"The fortress also shall cease from Ephraim."

*Ve-nishbat mivtzar me-Efrayim*—Ephraim's fortress gone.

"The kingdom from Damascus."

*U-mamlakhah mi-Dammeseq*—Damascus loses kingdom.

"The remnant of Aram shall be as the glory of the children of Israel."

*U-she'ar Aram ki-khevod benei-Yisra'el yihyu*—same fate.

**Jacob's Decline (17:4-6):**
"The glory of Jacob shall be made thin."

*Yiddal kevod Ya'aqov*—glory thins.

"The fatness of his flesh shall wax lean."

*U-mishman besaro yerazeh*—flesh leans.

"As when the harvestman gathers the standing grain."

*Ve-hayah ka-asof qatzir qamah*—harvest gathering.

"As when one gleans ears in the valley of Rephaim."

*Ve-khimlalel shivbolim be-emeq Refa'im*—gleaning.

"Yet there shall be left therein gleanings."

*Ve-nish'ar-bo olelot*—gleanings remain.

"As at the beating of an olive-tree."

*Ke-noqef zayit*—olive beating.

"Two or three berries in the top of the uppermost bough."

*Shenayim sheloshah gargerim be-rosh amir*—few berries.

"Four or five in the branches."

*Arba'ah chamishah bi-se'ifekha*—sparse fruit.

**The Key Verses (17:7-8):**
"In that day shall a man look unto his Maker."

*Ba-yom ha-hu yish'eh ha-adam al-osehu*—look to Maker.

"His eyes shall have regard to the Holy One of Israel."

*Ve-einav el-Qedosh Yisra'el tir'eynah*—regard Holy One.

"He shall not look to the altars, the work of his hands."

*Ve-lo yish'eh el-ha-mizbechot ma'aseh yadav*—not to altars.

"Neither shall he have regard to that which his fingers have made."

*Va-asher asu etzbe'otav lo yir'eh*—not to idols.

"Either the Asherim, or the sun-images."

*Ve-ha-asherim ve-ha-chammanim*—Asherah poles and incense altars.

**Forgotten God (17:9-11):**
"His strong cities be as the forsaken places."

*Ba-yom ha-hu yihyu arei ma'uzzo ka-azuvat ha-choresh*—abandoned cities.

**The Key Verse (17:10):**
"You have forgotten the God of your salvation."

*Ki shachacht Elohei yish'ekh*—forgotten salvation-God.

"Have not been mindful of the Rock of your stronghold."

*Ve-tzur ma'uzekh lo zakhart*—Rock forgotten.

"Therefore you plant plants of pleasantness."

*Al-ken titta'i nit'ei na'amanim*—pleasant gardens.

"Set it with strange slips."

*U-zemorat zar tizra'ennu*—foreign vines (fertility cult).

"The harvest flees away in the day of grief."

*Nad qatzir be-yom nachalah*—harvest flees.

"Of desperate pain."

*U-khe'ev anush*—desperate pain.

**Nations Rebuked (17:12-14):**
"The uproar of many peoples."

*Hoy hamon ammim rabbim*—many peoples roar.

"That roar like the roaring of the seas."

*Ka-hamon yamim yehemayun*—sea-roaring.

"The rushing of nations."

*U-she'on le'ummim*—nation-rushing.

"He shall rebuke them."

*Ve-ga'ar bo*—YHWH rebukes.

"They shall flee far off."

*Ve-nas mi-merchaq*—flee far.

"Chased as the chaff of the mountains before the wind."

*Ve-ruddaf ke-motz harim lifnei-ruach*—chaff chased.

"Like the whirling dust before the storm."

*U-khe-galgal lifnei sufah*—whirling dust.

**The Key Verse (17:14):**
"At eventide behold terror."

*Le-et erev ve-hinneh valladhah*—evening terror.

"Before the morning they are not."

*Be-terem boqer einennu*—gone by morning.

"This is the portion of them that spoil us."

*Zeh cheleq shoseinu*—spoilers' portion.

"The lot of them that rob us."

*Ve-goral le-vozzeinu*—robbers' lot.

**Archetypal Layer:** Isaiah 17 prophesies **Damascus and Ephraim's joint fall**, includes **a remnant turning to the Maker (17:7-8)**, and describes **sudden destruction of enemies (17:14)**.

**Ethical Inversion Applied:**
- "Damascus is taken away from being a city"—city destroyed
- "It shall be a ruinous heap"—ruins
- "The fortress also shall cease from Ephraim"—Ephraim falls too
- "The remnant of Aram shall be as the glory of the children of Israel"—same fate
- "The glory of Jacob shall be made thin"—glory diminished
- "Yet there shall be left therein gleanings"—remnant preserved
- "Two or three berries in the top"—small remnant
- "In that day shall a man look unto his Maker"—turning to God
- "His eyes shall have regard to the Holy One of Israel"—proper regard
- "He shall not look to the altars, the work of his hands"—abandoning idols
- "You have forgotten the God of your salvation"—forgotten God
- "Have not been mindful of the Rock of your stronghold"—Rock forgotten
- "The harvest flees away in the day of grief"—failed harvest
- "He shall rebuke them, and they shall flee"—YHWH rebukes nations
- "At eventide behold terror; before the morning they are not"—overnight destruction

**Modern Equivalent:** Isaiah 17's "forgotten the God of your salvation" (17:10) and "Rock of your stronghold" (17:10) show forgetting YHWH as the core problem. The overnight destruction (17:14) shows divine protection—enemies vanish.

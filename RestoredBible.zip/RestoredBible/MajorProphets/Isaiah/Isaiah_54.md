# Isaiah 54: The Barren Woman Sings

*From the Hebrew: רָנִּי עֲקָרָה לֹא יָלָדָה (Ronni Aqarah Lo Yaladah) — Sing, O Barren, You That Did Not Bear*

---

## Zion's Children Multiply (54:1-3)

**54:1** Sing, O barren, you that did not bear, break forth into singing, and cry aloud, you that did not travail; for more are the children of the desolate than the children of the married wife, says YHWH.

**54:2** Enlarge the place of your tent, and let them stretch forth the curtains of your habitations, spare not; lengthen your cords, and strengthen your stakes.

**54:3** For you shall spread abroad on the right hand and on the left; and your seed shall possess the nations, and make the desolate cities to be inhabited.

---

## YHWH as Husband (54:4-10)

**54:4** Fear not, for you shall not be ashamed; neither be confounded, for you shall not be put to shame; for you shall forget the shame of your youth, and the reproach of your widowhood shall you remember no more.

**54:5** For your Maker is your husband, YHWH of hosts is his name; and the Holy One of Israel is your Redeemer, the God of the whole earth shall he be called.

**54:6** For YHWH has called you as a wife forsaken and grieved in spirit, even a wife of youth, when she is cast off, says your God.

**54:7** For a small moment have I forsaken you; but with great compassions will I gather you.

**54:8** In a little wrath I hid my face from you for a moment; but with everlasting kindness will I have compassion on you, says YHWH your Redeemer.

**54:9** For this is as the waters of Noah unto me; for as I have sworn that the waters of Noah should no more go over the earth, so have I sworn that I would not be wroth with you, nor rebuke you.

**54:10** For the mountains may depart, and the hills be removed; but my kindness shall not depart from you, neither shall my covenant of peace be removed, says YHWH that has compassion on you.

---

## The New Jerusalem (54:11-17)

**54:11** O afflicted, tossed with tempest, and not comforted, behold, I will set your stones in fair colours, and lay your foundations with sapphires.

**54:12** And I will make your pinnacles of rubies, and your gates of carbuncles, and all your border of precious stones.

**54:13** And all your children shall be taught of YHWH; and great shall be the peace of your children.

**54:14** In righteousness shall you be established; you shall be far from oppression, for you shall not fear; and from terror, for it shall not come near you.

**54:15** Behold, they may gather together, but not by me; whosoever shall gather together against you shall fall because of you.

**54:16** Behold, I have created the smith that blows the fire of coals, and brings forth a weapon for his work; and I have created the waster to destroy.

**54:17** No weapon that is formed against you shall prosper; and every tongue that shall rise against you in judgment you shall condemn. This is the heritage of the servants of YHWH, and their righteousness which is of me, says YHWH.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verse (54:1):**
"Sing, O barren, you that did not bear."

*Ronni aqarah lo yaladah*—barren sings. Galatians 4:27 quotes this.

"Break forth into singing, and cry aloud."

*Pitzchi rinnah ve-tzahali*—joyful singing.

"You that did not travail."

*Lo-chalah*—didn't labor.

"More are the children of the desolate than the children of the married wife."

*Ki-rabbim benei-shomemah mi-benei be'ulah*—desolate's children exceed married's.

**Expansion (54:2-3):**
"Enlarge the place of your tent."

*Harchivi meqom ohalek*—enlarge tent.

"Let them stretch forth the curtains of your habitations."

*Vi-yeri'ot mishkenotayikh yattu*—stretch curtains.

"Spare not."

*Al-tachsokhi*—don't hold back.

"Lengthen your cords, and strengthen your stakes."

*Ha'ariki meytarayikh vi-yetedotayikh chazzeqi*—longer cords, stronger stakes.

"You shall spread abroad on the right hand and on the left."

*Ki-yamin u-smo'l tifrotzi*—spread right and left.

"Your seed shall possess the nations."

*Ve-zar'ekh goyim yirash*—nations possessed.

**Fear Not (54:4-6):**
"Fear not, for you shall not be ashamed."

*Al-tir'i ki-lo tevoshi*—no shame.

"You shall forget the shame of your youth."

*Ki voshet alumayikh tishkachi*—youth shame forgotten.

"The reproach of your widowhood shall you remember no more."

*Ve-cherpat almenutayikh lo tizkeri-od*—widowhood reproach forgotten.

**The Key Verse (54:5):**
"For your Maker is your husband."

*Ki vo'alayikh osayikh*—Maker = husband.

"YHWH of hosts is his name."

*YHWH Tzeva'ot shemo*—name.

"The Holy One of Israel is your Redeemer."

*Ve-go'alekh Qedosh Yisra'el*—Redeemer.

"The God of the whole earth shall he be called."

*Elohei khol-ha-aretz yiqqare*—God of all earth.

**Momentary Forsaking (54:7-8):**
"For a small moment have I forsaken you."

*Be-rega qaton azavttikh*—small moment.

"With great compassions will I gather you."

*U-ve-rachamim gedolim aqabbtzekh*—great compassions gather.

"In a little wrath I hid my face from you for a moment."

*Be-shetzef qetzef histarti fanai rega mimmekh*—momentary hiding.

"With everlasting kindness will I have compassion on you."

*U-ve-chesed olam richamttikh*—everlasting kindness.

**The Key Verses (54:9-10):**
"This is as the waters of Noah unto me."

*Ki-mei Noach zot li*—Noah's waters comparison.

"As I have sworn that the waters of Noah should no more go over the earth."

*Ka-asher nishba'ti me-avor mei-Noach od al-ha-aretz*—Noah oath.

"So have I sworn that I would not be wroth with you."

*Ken nishba'ti mi-qetzof alayikh*—sworn not to be angry.

"The mountains may depart, and the hills be removed."

*Ki he-harim yamushu ve-ha-geva'ot temutena*—mountains depart.

"My kindness shall not depart from you."

*Ve-chasdi me-ittek lo-yamush*—kindness won't depart.

"Neither shall my covenant of peace be removed."

*U-verit shelomi lo tamut*—peace covenant remains.

**Jeweled City (54:11-12):**
"O afflicted, tossed with tempest, and not comforted."

*Aniyyah so'arah lo nuchamah*—storm-tossed, uncomforted.

"I will set your stones in fair colours."

*Hinneh anokhi marbitz ba-pukh avanayikh*—stones in antimony.

"Lay your foundations with sapphires."

*Vi-ysadttikh ba-sappirim*—sapphire foundations.

"I will make your pinnacles of rubies."

*Ve-samti kadkod shimshottayikh*—ruby pinnacles.

"Your gates of carbuncles."

*U-she'arayikh le-avnei eqdach*—carbuncle gates.

"All your border of precious stones."

*Ve-khol-gevulek le-avnei-chefetz*—precious stone borders.

Revelation 21:18-21 echoes this jeweled city imagery.

**The Key Verse (54:13):**
"All your children shall be taught of YHWH."

*Ve-khol-banayikh limmudei YHWH*—YHWH-taught children. John 6:45 quotes this.

"Great shall be the peace of your children."

*Ve-rav shalom banayikh*—great peace.

**Security (54:14-17):**
"In righteousness shall you be established."

*Bi-tzedaqah tikkonani*—established in righteousness.

"You shall be far from oppression."

*Rachaki me-osheq*—far from oppression.

"For you shall not fear."

*Ki-lo tira'i*—no fear.

"From terror, for it shall not come near you."

*U-mi-mechittah ki lo-tiqrav elayikh*—terror won't approach.

"Whosoever shall gather together against you shall fall because of you."

*Mi-gor yagur efes me-otti al-yippol alayikh*—attackers fall.

"I have created the smith that blows the fire of coals."

*Hinneh anokhi barati charash nofe'ach be-esh pecham*—smith created.

"I have created the waster to destroy."

*Ve-anokhi barati mashchit le-chabbel*—destroyer created.

**The Key Verse (54:17):**
"No weapon that is formed against you shall prosper."

*Kol-keli yutzar alayikh lo yitzlach*—no weapon prospers.

"Every tongue that shall rise against you in judgment you shall condemn."

*Ve-khol-lashon taqum-ittek le-mishpat tarshi'i*—tongues condemned.

"This is the heritage of the servants of YHWH."

*Zot nachalat avdei YHWH*—servants' heritage.

"Their righteousness which is of me, says YHWH."

*Ve-tzidqatam me-itti ne'um-YHWH*—righteousness from YHWH.

**Archetypal Layer:** Isaiah 54 contains **"Sing, O barren" (54:1)**—Galatians 4:27, **"your Maker is your husband" (54:5)**, **the jeweled city (54:11-12)**—Revelation 21, **"all your children shall be taught of YHWH" (54:13)**—John 6:45, and **"no weapon formed against you shall prosper" (54:17)**.

**Ethical Inversion Applied:**
- "Sing, O barren, you that did not bear"—Galatians 4:27
- "More are the children of the desolate than the children of the married wife"—reversal
- "Enlarge the place of your tent"—expansion
- "Lengthen your cords, and strengthen your stakes"—growth
- "Your seed shall possess the nations"—nations possessed
- "Fear not, for you shall not be ashamed"—no shame
- "Your Maker is your husband"—divine marriage
- "YHWH of hosts is his name"—name
- "The God of the whole earth shall he be called"—universal God
- "For a small moment have I forsaken you"—momentary
- "With great compassions will I gather you"—great compassion
- "With everlasting kindness will I have compassion on you"—everlasting kindness
- "This is as the waters of Noah unto me"—Noah oath parallel
- "The mountains may depart... my kindness shall not depart"—unchanging kindness
- "Neither shall my covenant of peace be removed"—peace covenant
- "I will set your stones in fair colours"—Revelation 21
- "Lay your foundations with sapphires"—jeweled city
- "All your children shall be taught of YHWH"—John 6:45
- "Great shall be the peace of your children"—peace
- "In righteousness shall you be established"—righteousness establishment
- "No weapon that is formed against you shall prosper"—protection
- "Every tongue that shall rise against you in judgment you shall condemn"—vindication
- "This is the heritage of the servants of YHWH"—servants' heritage

**Modern Equivalent:** Isaiah 54:1's "Sing, O barren" is quoted in Galatians 4:27 for the new covenant. The jeweled city (54:11-12) influences Revelation 21. "All your children shall be taught of YHWH" (54:13) is quoted by Jesus in John 6:45. "No weapon formed against you shall prosper" (54:17) is one of Scripture's most beloved protection promises.

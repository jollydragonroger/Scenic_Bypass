# Isaiah 11: The Branch from Jesse and the Peaceable Kingdom

*From the Hebrew: וְיָצָא חֹטֶר מִגֵּזַע יִשָׁי (Ve-Yatza Choter Mi-Geza Yishai) — And There Shall Come Forth a Shoot out of the Stock of Jesse*

---

## The Branch and His Spirit (11:1-5)

**11:1** And there shall come forth a shoot out of the stock of Jesse,
and a branch out of his roots shall bear fruit.

**11:2** And the spirit of YHWH shall rest upon him,
the spirit of wisdom and understanding,
the spirit of counsel and might,
the spirit of knowledge and of the fear of YHWH.

**11:3** And his delight shall be in the fear of YHWH;
and he shall not judge after the sight of his eyes,
neither decide after the hearing of his ears;

**11:4** But with righteousness shall he judge the poor,
and decide with equity for the meek of the land;
and he shall smite the land with the rod of his mouth,
and with the breath of his lips shall he slay the wicked.

**11:5** And righteousness shall be the girdle of his loins,
and faithfulness the girdle of his reins.

---

## The Peaceable Kingdom (11:6-9)

**11:6** And the wolf shall dwell with the lamb,
and the leopard shall lie down with the kid;
and the calf and the young lion and the fatling together;
and a little child shall lead them.

**11:7** And the cow and the bear shall feed;
their young ones shall lie down together;
and the lion shall eat straw like the ox.

**11:8** And the sucking child shall play on the hole of the asp,
and the weaned child shall put his hand on the basilisk's den.

**11:9** They shall not hurt nor destroy in all my holy mountain;
for the earth shall be full of the knowledge of YHWH,
as the waters cover the sea.

---

## The Root of Jesse and the Ingathering (11:10-16)

**11:10** And it shall come to pass in that day, that the root of Jesse, that stands for an ensign of the peoples, unto him shall the nations seek; and his resting-place shall be glorious.

**11:11** And it shall come to pass in that day, that the Lord will set his hand again the second time to recover the remnant of his people, that shall remain from Assyria, and from Egypt, and from Pathros, and from Cush, and from Elam, and from Shinar, and from Hamath, and from the islands of the sea.

**11:12** And he will set up an ensign for the nations, and will assemble the dispersed of Israel, and gather together the scattered of Judah from the four corners of the earth.

**11:13** The envy also of Ephraim shall depart, and they that harass Judah shall be cut off; Ephraim shall not envy Judah, and Judah shall not harass Ephraim.

**11:14** And they shall fly down upon the shoulder of the Philistines on the west; together shall they spoil the children of the east; they shall put forth their hand upon Edom and Moab; and the children of Ammon shall obey them.

**11:15** And YHWH will utterly destroy the tongue of the Egyptian sea; and with his scorching wind will he shake his hand over the River, and will smite it into seven streams, and cause men to march over dry-shod.

**11:16** And there shall be a highway for the remnant of his people, that shall remain from Assyria, like as there was for Israel in the day that he came up out of the land of Egypt.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verse (11:1):**
"There shall come forth a shoot out of the stock of Jesse."

*Ve-yatza choter mi-geza Yishai*—shoot from stump.

"A branch out of his roots shall bear fruit."

*Ve-netzer mi-shorashav yifreh*—root-branch bears fruit.

**Translation Note:**
*Choter* = shoot/twig; *Netzer* = branch/sprout (some connect to "Nazarene" in Matthew 2:23). Jesse (not David) emphasizes humble origins—the dynasty cut down to a stump.

**The Key Verse (11:2):**
"The spirit of YHWH shall rest upon him."

*Ve-nachah alav ruach YHWH*—Spirit rests.

**The Sevenfold Spirit:**
1. Spirit of YHWH — *Ruach YHWH*
2. Spirit of wisdom — *Ruach chokhmah*
3. Spirit of understanding — *U-vinah*
4. Spirit of counsel — *Ruach etzah*
5. Spirit of might — *U-gevurah*
6. Spirit of knowledge — *Ruach da'at*
7. Spirit of the fear of YHWH — *Ve-yir'at YHWH*

**Righteous Rule (11:3-5):**
"His delight shall be in the fear of YHWH."

*Va-haricho be-yir'at YHWH*—delighting in fear.

"He shall not judge after the sight of his eyes."

*Ve-lo-le-mar'eh einav yishpot*—not by appearance.

"Neither decide after the hearing of his ears."

*Ve-lo-le-mishma oznav yokhi'ach*—not by hearsay.

"With righteousness shall he judge the poor."

*Ve-shafat be-tzedeq dallim*—righteous judgment.

"Decide with equity for the meek of the land."

*Ve-hokhiach be-mishor le-anvei-aretz*—equity for meek.

"He shall smite the land with the rod of his mouth."

*Ve-hikkah-eretz be-shevet piv*—mouth-rod strikes.

"With the breath of his lips shall he slay the wicked."

*U-ve-ruach sefatav yamit rasha*—breath slays wicked.

"Righteousness shall be the girdle of his loins."

*Ve-hayah tzedeq ezor motnav*—righteousness belt.

"Faithfulness the girdle of his reins."

*Ve-ha-emunah ezor chalatzav*—faithfulness belt.

**The Peaceable Kingdom (11:6-9):**
"The wolf shall dwell with the lamb."

*Ve-gar ze'ev im-keves*—wolf with lamb.

"The leopard shall lie down with the kid."

*Ve-namer im-gedi yirbatz*—leopard with kid.

"The calf and the young lion and the fatling together."

*Ve-egel u-khefir u-meri yachdav*—calf, lion, fatling.

"A little child shall lead them."

*Ve-na'ar qaton noheg bam*—child leads.

"The cow and the bear shall feed."

*U-farah va-dov tir'eynah*—cow and bear.

"The lion shall eat straw like the ox."

*Ve-aryeh ka-baqar yokhal teven*—lion eats straw.

"The sucking child shall play on the hole of the asp."

*Ve-shia'sha'a yoneq al-chur paten*—infant at asp's hole.

"The weaned child shall put his hand on the basilisk's den."

*Ve-al me'urat tzif'oni gamul yado hadah*—child at viper's den.

**The Key Verse (11:9):**
"They shall not hurt nor destroy in all my holy mountain."

*Lo-yare'u ve-lo-yashchitu be-khol-har qodshi*—no harm on holy mountain.

"For the earth shall be full of the knowledge of YHWH."

*Ki-male'ah ha-aretz de'ah et-YHWH*—earth full of knowledge.

"As the waters cover the sea."

*Ka-mayim la-yam mekhassim*—waters cover sea.

**Root of Jesse (11:10):**
"The root of Jesse, that stands for an ensign of the peoples."

*Shoresh Yishai asher omed le-nes ammim*—root = ensign.

"Unto him shall the nations seek."

*Elav goyim yidroshu*—nations seek. Romans 15:12 quotes this.

"His resting-place shall be glorious."

*Ve-haytah menuchato kavod*—glorious rest.

**Second Exodus (11:11-16):**
"The Lord will set his hand again the second time to recover the remnant."

*Yosif Adonai shenit yado liqnot et-she'ar ammo*—second recovery.

"From Assyria, and from Egypt, and from Pathros..."

Listing diaspora locations.

"He will set up an ensign for the nations."

*Ve-nasa nes la-goyim*—ensign raised.

"Assemble the dispersed of Israel."

*Ve-asaf nidchei Yisra'el*—Israel gathered.

"Gather together the scattered of Judah from the four corners of the earth."

*U-nefutzot Yehudah yeqabbetz me-arba kanfot ha-aretz*—four corners.

"There shall be a highway for the remnant."

*Ve-haytah mesillah li-she'ar ammo*—highway for remnant.

"Like as there was for Israel in the day that he came up out of the land of Egypt."

*Ka-asher haytah le-Yisra'el be-yom aloto me-eretz Mitzrayim*—new Exodus.

**Archetypal Layer:** Isaiah 11 contains **the Branch from Jesse (11:1)**, **the sevenfold Spirit (11:2)**, **the Peaceable Kingdom (11:6-9)**, and **the second Exodus ingathering (11:11-16)**.

**Ethical Inversion Applied:**
- "A shoot out of the stock of Jesse"—stump sprouts
- "A branch out of his roots shall bear fruit"—root-branch
- "The spirit of YHWH shall rest upon him"—Spirit-anointed
- "Spirit of wisdom and understanding"—wisdom pair
- "Spirit of counsel and might"—action pair
- "Spirit of knowledge and of the fear of YHWH"—knowledge pair
- "He shall not judge after the sight of his eyes"—beyond appearance
- "With righteousness shall he judge the poor"—just for poor
- "With the breath of his lips shall he slay the wicked"—word-power
- "The wolf shall dwell with the lamb"—predator/prey reconciled
- "A little child shall lead them"—child leadership
- "The lion shall eat straw like the ox"—carnivore becomes herbivore
- "They shall not hurt nor destroy in all my holy mountain"—no harm
- "The earth shall be full of the knowledge of YHWH"—universal knowledge
- "The root of Jesse, that stands for an ensign"—ensign for nations
- "Unto him shall the nations seek"—Romans 15:12
- "The Lord will set his hand again the second time"—second Exodus
- "A highway for the remnant"—new Exodus highway

**Modern Equivalent:** Isaiah 11's Branch/shoot (11:1) and sevenfold Spirit (11:2) are foundational messianic texts. The Peaceable Kingdom (11:6-9) envisions cosmic reconciliation—creation healed. Romans 15:12 quotes the root of Jesse (11:10) for Gentile inclusion.

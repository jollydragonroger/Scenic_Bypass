# Isaiah 49: The Servant as a Light to the Nations

*From the Hebrew: שִׁמְעוּ אִיִּים אֵלַי (Shim'u Iyyim Elai) — Listen, O Isles, unto Me*

---

## The Second Servant Song (49:1-7)

**49:1** Listen, O isles, unto me, and attend, you peoples, from far: YHWH has called me from the womb; from the bowels of my mother has he made mention of my name.

**49:2** And he has made my mouth like a sharp sword, in the shadow of his hand has he hid me; and he has made me a polished shaft, in his quiver has he kept me close.

**49:3** And he said unto me: "You are my servant, Israel, in whom I will be glorified."

**49:4** But I said: "I have laboured in vain, I have spent my strength for nought and vanity; yet surely my right is with YHWH, and my recompense with my God."

**49:5** And now says YHWH that formed me from the womb to be his servant, to bring Jacob back to him, and that Israel be gathered unto him—for I am honourable in the eyes of YHWH, and my God is become my strength—

**49:6** Yea, he says: "It is too light a thing that you should be my servant to raise up the tribes of Jacob, and to restore the preserved of Israel; I will also give you for a light of the nations, that my salvation may be unto the end of the earth."

**49:7** Thus says YHWH, the Redeemer of Israel, his Holy One, to him who is despised of men, to him who is abhorred of the nation, to a servant of rulers: "Kings shall see and arise, princes, and they shall prostrate themselves; because of YHWH that is faithful, even the Holy One of Israel, who has chosen you."

---

## Restoration of Zion (49:8-13)

**49:8** Thus says YHWH: In an acceptable time have I answered you, and in a day of salvation have I helped you; and I will preserve you, and give you for a covenant of the people, to raise up the land, to cause to inherit the desolate heritages;

**49:9** Saying to the prisoners: "Go forth"; to them that are in darkness: "Show yourselves." They shall feed in the ways, and in all high hills shall be their pasture.

**49:10** They shall not hunger nor thirst, neither shall the heat nor sun smite them; for he that has compassion on them will lead them, even by the springs of water will he guide them.

**49:11** And I will make all my mountains a way, and my highways shall be raised on high.

**49:12** Behold, these shall come from far; and, lo, these from the north and from the west; and these from the land of Sinim.

**49:13** Sing, O heavens, and be joyful, O earth, and break forth into singing, O mountains; for YHWH has comforted his people, and has compassion upon his afflicted.

---

## Zion Remembered (49:14-21)

**49:14** But Zion said: "YHWH has forsaken me, and the Lord has forgotten me."

**49:15** Can a woman forget her sucking child, that she should not have compassion on the son of her womb? Yea, these may forget, yet will I not forget you.

**49:16** Behold, I have graven you upon the palms of my hands; your walls are continually before me.

**49:17** Your children make haste; your destroyers and they that made you waste shall go forth from you.

**49:18** Lift up your eyes round about, and behold: All these gather themselves together, and come to you. As I live, says YHWH, you shall surely clothe yourself with them all, as with an ornament, and gird yourself with them, like a bride.

**49:19** For as for your waste and your desolate places and your land that has been destroyed—surely now shall you be too strait for the inhabitants, and they that swallowed you up shall be far away.

**49:20** The children of your bereavement shall yet say in your ears: "The place is too strait for me; give place to me that I may dwell."

**49:21** Then shall you say in your heart: "Who has begotten me these, seeing I have been bereaved of my children, and am solitary, an exile, and wandering to and fro? And who has brought up these? Behold, I was left alone; these, where were they?"

---

## Nations Bring Israel Home (49:22-26)

**49:22** Thus says the Lord YHWH: Behold, I will lift up my hand to the nations, and set up my standard to the peoples, and they shall bring your sons in their bosom, and your daughters shall be carried upon their shoulders.

**49:23** And kings shall be your foster-fathers, and their queens your nursing mothers; they shall bow down to you with their face to the earth, and lick the dust of your feet; and you shall know that I am YHWH, for they shall not be ashamed that wait for me.

**49:24** Shall the prey be taken from the mighty, or the captives of the victorious be delivered?

**49:25** But thus says YHWH: Even the captives of the mighty shall be taken away, and the prey of the terrible shall be delivered; for I will contend with him that contends with you, and I will save your children.

**49:26** And I will feed them that oppress you with their own flesh; and they shall be drunken with their own blood, as with sweet wine; and all flesh shall know that I YHWH am your Savior, and your Redeemer, the Mighty One of Jacob.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (49:1-3) — Second Servant Song:**
"Listen, O isles, unto me."

*Shim'u iyyim elai*—islands listen.

"Attend, you peoples, from far."

*Ve-haqshivu le'ummim me-rachoq*—distant peoples.

"YHWH has called me from the womb."

*YHWH mi-beten qera'ani*—womb-called.

"From the bowels of my mother has he made mention of my name."

*Mi-me'ei immi hizkir shemi*—named from womb.

"He has made my mouth like a sharp sword."

*Va-yasem pi ke-cherev chaddah*—sword-mouth.

"In the shadow of his hand has he hid me."

*Be-tzel yado hechbi'ani*—hidden in hand-shadow.

"He has made me a polished shaft."

*Va-yesimeni le-chetz barur*—polished arrow.

"In his quiver has he kept me close."

*Be-ashpato histirani*—hidden in quiver.

"'You are my servant, Israel, in whom I will be glorified.'"

*Avdi-attah Yisra'el asher-bekha etpa'ar*—Servant = Israel, glorified.

**Servant's Discouragement (49:4-5):**
"'I have laboured in vain.'"

*Le-riq yaga'ti*—vain labor.

"'I have spent my strength for nought and vanity.'"

*Le-tohu va-hevel kochi killeti*—strength spent for nothing.

"'Yet surely my right is with YHWH.'"

*Akhen mishpati et-YHWH*—justice with YHWH.

"'My recompense with my God.'"

*U-fe'ullati et-Elohai*—recompense with God.

"YHWH that formed me from the womb to be his servant."

*YHWH yotzri mi-beten le-eved lo*—womb-formed servant.

"To bring Jacob back to him."

*Le-shobev Ya'aqov elav*—bringing Jacob back.

"That Israel be gathered unto him."

*Ve-Yisra'el lo ye'asef*—Israel gathered.

**The Key Verse (49:6):**
"'It is too light a thing that you should be my servant to raise up the tribes of Jacob.'"

*Naqel mi-heyotekha li eved la-haqim et-shivtei Ya'aqov*—too small a task.

"'To restore the preserved of Israel.'"

*Ve-netzirei Yisra'el le-hashiv*—restore preserved.

"'I will also give you for a light of the nations.'"

*U-netatikha le-or goyim*—light of nations. Acts 13:47 quotes this.

"'That my salvation may be unto the end of the earth.'"

*Lihyot yeshu'ati ad-qetzeh ha-aretz*—salvation to earth's end.

**The Key Verse (49:7):**
"To him who is despised of men."

*Li-vezoh-nefesh*—despised of soul.

"To him who is abhorred of the nation."

*Li-meta'ev goy*—abhorred by nation.

"To a servant of rulers."

*Le-eved moshelim*—servant of rulers.

"'Kings shall see and arise.'"

*Melakhim yir'u va-qamu*—kings rise.

"'Princes, and they shall prostrate themselves.'"

*Sarim ve-yishtachawu*—princes prostrate.

"'Because of YHWH that is faithful.'"

*Lema'an YHWH asher ne'eman*—faithful YHWH.

"'The Holy One of Israel, who has chosen you.'"

*Qedosh Yisra'el va-yivcharekka*—Holy One chooses.

**The Key Verse (49:8):**
"In an acceptable time have I answered you."

*Be-et ratzon anitikha*—acceptable time. 2 Corinthians 6:2 quotes this.

"In a day of salvation have I helped you."

*U-ve-yom yeshu'ah azartikha*—salvation day.

"I will... give you for a covenant of the people."

*Ve-ettzorkha ve-ettenekha li-verit am*—covenant of people.

**Liberation (49:9-12):**
"'Go forth'... 'Show yourselves.'"

*Tze'u... higgalu*—prisoners freed.

"They shall not hunger nor thirst."

*Lo yir'avu ve-lo yitzma'u*—no hunger/thirst. Revelation 7:16 echoes this.

"Neither shall the heat nor sun smite them."

*Ve-lo-yakkkem sharav va-shemesh*—no heat/sun strike.

"He that has compassion on them will lead them."

*Ki-merachamam yenahagem*—compassion leads.

"By the springs of water will he guide them."

*Ve-al-mabbu'ei mayim yenahelem*—spring guidance.

"These from the land of Sinim."

*Ve-elleh me-eretz Sinim*—from Sinim (possibly China).

**The Key Verse (49:13):**
"Sing, O heavens, and be joyful, O earth."

*Ronnu shamayim ve-gili aretz*—cosmic joy.

"For YHWH has comforted his people."

*Ki-nicham YHWH ammo*—YHWH comforts.

"Has compassion upon his afflicted."

*Va-aniyyav yerachem*—compassion on afflicted.

**Zion's Complaint (49:14-16):**
"'YHWH has forsaken me, and the Lord has forgotten me.'"

*Azavani YHWH va-Adonai shekechani*—forsaken, forgotten.

**The Key Verse (49:15):**
"Can a woman forget her sucking child?"

*Ha-tishkach ishshash olalah*—woman forget nursing child?

"That she should not have compassion on the son of her womb?"

*Me-rachem ben-bitnah*—no womb-compassion?

"Yea, these may forget."

*Gam-elleh tishkachnah*—even these may forget.

"Yet will I not forget you."

*Ve-anokhi lo eshkachekh*—I won't forget.

**The Key Verse (49:16):**
"Behold, I have graven you upon the palms of my hands."

*Hen al-kappayim chaqqotikh*—engraved on palms.

"Your walls are continually before me."

*Chomotayikh negdi tamid*—walls always before.

**Children Return (49:17-21):**
"Your children make haste."

*Miharu banayikh*—children hurry.

"You shall surely clothe yourself with them all, as with an ornament."

*Ki khullam ka-adi tilbashi*—ornament-children.

"Gird yourself with them, like a bride."

*U-teqashsherim ka-kallah*—bride-girding.

"'The place is too strait for me.'"

*Tzar-li ha-maqom*—too crowded!

"'Who has begotten me these?'"

*Mi yalad-li et-elleh*—who bore these?

**Nations Serve (49:22-26):**
"I will lift up my hand to the nations."

*Essa el-goyim yadi*—hand to nations.

"Set up my standard to the peoples."

*Ve-el-ammim arim nissi*—standard raised.

"They shall bring your sons in their bosom."

*Ve-hevi'u vanayikh be-chotzen*—sons in bosom.

"Your daughters shall be carried upon their shoulders."

*U-venotayikh al-katef tinnasena*—daughters on shoulders.

"Kings shall be your foster-fathers."

*Ve-hayu melakhim omneykha*—king foster-fathers.

"Their queens your nursing mothers."

*Ve-saroteihem meiniqotayikh*—queen nurses.

"I will contend with him that contends with you."

*Ve-et-yeriveykh anokhi ariv*—contend for you.

"I will save your children."

*Ve-et-banayikh anokhi oshi'a*—save children.

**The Key Verse (49:26):**
"All flesh shall know that I YHWH am your Savior."

*Ve-yade'u khol-basar ki ani YHWH moshi'ekh*—all flesh knows.

"Your Redeemer, the Mighty One of Jacob."

*Ve-go'alekh avir Ya'aqov*—Redeemer, Mighty One.

**Archetypal Layer:** Isaiah 49 contains **the Second Servant Song (49:1-7)**, **"a light of the nations" (49:6)**—Acts 13:47, **"I have graven you upon the palms of my hands" (49:16)**, and **Zion's population explosion (49:19-21)**.

**Ethical Inversion Applied:**
- "YHWH has called me from the womb"—womb-called
- "He has made my mouth like a sharp sword"—sword-mouth
- "'You are my servant, Israel'"—Servant Israel
- "'I have laboured in vain'"—perceived failure
- "'Yet surely my right is with YHWH'"—trust despite failure
- "'It is too light a thing... to raise up the tribes of Jacob'"—mission expanded
- "'I will also give you for a light of the nations'"—Acts 13:47
- "'That my salvation may be unto the end of the earth'"—worldwide
- "To him who is despised of men"—despised Servant
- "'Kings shall see and arise'"—kings rise
- "In an acceptable time have I answered you"—2 Corinthians 6:2
- "'Go forth'... 'Show yourselves'"—prisoners freed
- "They shall not hunger nor thirst"—Revelation 7:16
- "YHWH has comforted his people"—comfort
- "'YHWH has forsaken me... forgotten me'"—Zion's complaint
- "Can a woman forget her sucking child?"—mother analogy
- "Yet will I not forget you"—unforgetting
- "I have graven you upon the palms of my hands"—palm-engraved
- "Your walls are continually before me"—walls remembered
- "'The place is too strait for me'"—population boom
- "Kings shall be your foster-fathers"—royal servants
- "I will contend with him that contends with you"—YHWH fights
- "All flesh shall know that I YHWH am your Savior"—universal knowledge

**Modern Equivalent:** Isaiah 49:6's "light of the nations... salvation to the end of the earth" is quoted in Acts 13:47 for Paul's Gentile mission. The "graven on my palms" (49:16) is a beloved comfort text. The Servant's discouragement (49:4) and vindication (49:7) pattern Christ's suffering and exaltation.

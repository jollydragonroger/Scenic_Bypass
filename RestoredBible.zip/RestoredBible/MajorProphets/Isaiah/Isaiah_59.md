# Isaiah 59: Sin Separates, the Redeemer Comes

*From the Hebrew: הֵן לֹא־קָצְרָה יַד־יְהוָה (Hen Lo-Qatzrah Yad-YHWH) — Behold, YHWH's Hand Is Not Shortened*

---

## Sin Separates (59:1-8)

**59:1** Behold, YHWH's hand is not shortened, that it cannot save, neither his ear heavy, that it cannot hear;

**59:2** But your iniquities have separated between you and your God, and your sins have hid his face from you, that he will not hear.

**59:3** For your hands are defiled with blood, and your fingers with iniquity; your lips have spoken lies, your tongue mutters wickedness.

**59:4** None calls in righteousness, and none pleads in truth; they trust in vanity, and speak lies; they conceive mischief, and bring forth iniquity.

**59:5** They hatch adders' eggs, and weave the spider's web; he that eats of their eggs dies, and that which is crushed breaks out into a viper.

**59:6** Their webs shall not become garments, neither shall they cover themselves with their works; their works are works of iniquity, and the act of violence is in their hands.

**59:7** Their feet run to evil, and they make haste to shed innocent blood; their thoughts are thoughts of iniquity, desolation and destruction are in their paths.

**59:8** The way of peace they know not, and there is no justice in their goings; they have made them crooked paths; whosoever goes therein does not know peace.

---

## Confession of Sin (59:9-15a)

**59:9** Therefore is justice far from us, neither does righteousness overtake us; we look for light, but behold darkness, for brightness, but we walk in gloom.

**59:10** We grope for the wall like the blind, yea, as they that have no eyes do we grope; we stumble at noonday as in the twilight; we are in dark places like the dead.

**59:11** We roar all like bears, and mourn sore like doves; we look for justice, but there is none; for salvation, but it is far off from us.

**59:12** For our transgressions are multiplied before you, and our sins testify against us; for our transgressions are with us, and as for our iniquities, we know them:

**59:13** Transgressing and denying YHWH, and turning away from following our God, speaking oppression and revolt, conceiving and uttering from the heart words of falsehood.

**59:14** And justice is turned away backward, and righteousness stands afar off; for truth is fallen in the street, and uprightness cannot enter.

**59:15a** And truth is lacking, and he that departs from evil makes himself a prey.

---

## YHWH Intervenes (59:15b-21)

**59:15b** And YHWH saw it, and it displeased him that there was no justice.

**59:16** And he saw that there was no man, and was astonished that there was no intercessor; therefore his own arm brought salvation unto him; and his righteousness, it sustained him.

**59:17** And he put on righteousness as a coat of mail, and a helmet of salvation upon his head; and he put on garments of vengeance for clothing, and was clad with zeal as a cloak.

**59:18** According to their deeds, accordingly he will repay: fury to his adversaries, recompense to his enemies; to the islands he will repay recompense.

**59:19** So shall they fear the name of YHWH from the west, and his glory from the rising of the sun; for he will come as a rushing stream, which the breath of YHWH drives.

**59:20** And a Redeemer will come to Zion, and unto them that turn from transgression in Jacob, says YHWH.

**59:21** And as for me, this is my covenant with them, says YHWH: My spirit that is upon you, and my words which I have put in your mouth, shall not depart out of your mouth, nor out of the mouth of your seed, nor out of the mouth of your seed's seed, says YHWH, from henceforth and forever.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (59:1-2):**
"YHWH's hand is not shortened, that it cannot save."

*Hen lo-qatzrah yad-YHWH me-hoshi'a*—hand not short.

"Neither his ear heavy, that it cannot hear."

*Ve-lo-khavedah ozno mi-shemo'a*—ear not heavy.

"But your iniquities have separated between you and your God."

*Ki im-avonotekhem hayu mavdilim beineikhem le-vein Eloheikhem*—iniquities separate.

"Your sins have hid his face from you."

*Ve-chatto'tekhem histiru fanim mikkem*—sins hide face.

"That he will not hear."

*Mi-shemo'a*—won't hear.

**Catalog of Sins (59:3-8):**
"Your hands are defiled with blood."

*Ki kappekhem nego'alu va-dam*—bloody hands.

"Your fingers with iniquity."

*Ve-etzbe'oteikhem ba-avon*—iniquitous fingers.

"Your lips have spoken lies."

*Siftoteikhem dibberu-shaqer*—lying lips.

"Your tongue mutters wickedness."

*Leshonkhem avlah tehgeh*—wicked tongue.

"None calls in righteousness."

*Ein-qore ve-tzedeq*—no righteous calling.

"None pleads in truth."

*Ve-ein nishpat be-emunah*—no true pleading.

"They trust in vanity, and speak lies."

*Bato'ach al-tohu ve-dabber-shav*—trusting emptiness.

"They conceive mischief, and bring forth iniquity."

*Haro amal ve-holid aven*—conceiving mischief.

"They hatch adders' eggs."

*Beitzei tzif'oni biqque'u*—viper eggs.

"Weave the spider's web."

*Ve-qurei akavish ye'erogu*—spider webs.

"Their webs shall not become garments."

*Qureihem lo-yihyu le-veged*—useless webs.

"Their works are works of iniquity."

*Ma'aseihem ma'asei-aven*—iniquitous works.

"The act of violence is in their hands."

*U-fo'al chamas be-khappeihem*—violent hands.

**The Key Verses (59:7-8):**
"Their feet run to evil."

*Ragleihem la-ra yarutzu*—feet run to evil. Romans 3:15 quotes this.

"They make haste to shed innocent blood."

*Vi-maharu lishpokh dam naqi*—shedding innocent blood.

"Their thoughts are thoughts of iniquity."

*Machshevoteihem machshevot aven*—iniquitous thoughts.

"Desolation and destruction are in their paths."

*Shod va-shever bi-mesillotam*—destruction in paths.

"The way of peace they know not."

*Derekh shalom lo yada'u*—no peace known. Romans 3:17 quotes this.

"There is no justice in their goings."

*Ve-ein mishpat be-ma'gelotam*—no justice.

"They have made them crooked paths."

*Netivoteihem iqqeshu lahem*—crooked paths.

"Whosoever goes therein does not know peace."

*Kol dorekh bah lo yada shalom*—no peace for travelers.

**Confession (59:9-15a):**
"Therefore is justice far from us."

*Al-ken rachaq mishpat mimmenu*—justice far.

"Neither does righteousness overtake us."

*Ve-lo tassigenu tzedaqah*—righteousness doesn't reach.

"We look for light, but behold darkness."

*Neqavveh la-or ve-hinneh-choshekh*—expecting light, getting darkness.

"We grope for the wall like the blind."

*Negashshash ka-ivrim qir*—groping like blind.

"We stumble at noonday as in the twilight."

*Kashalnnu va-tzohorayim ka-neshef*—stumbling at noon.

"We roar all like bears."

*Nehemeh kha-dubbim kullanu*—bear roaring.

"Mourn sore like doves."

*Ve-kha-yonim hago nehgeh*—dove mourning.

"We look for justice, but there is none."

*Neqavveh la-mishpat va-ayin*—no justice.

"For salvation, but it is far off from us."

*Li-yeshu'ah rachaqah mimmenu*—salvation far.

"Our transgressions are multiplied before you."

*Ki-rabbu fesh'enu negdekha*—many transgressions.

"Our sins testify against us."

*Ve-chatto'teinu aneta vanu*—sins testify.

**The Key Verse (59:14):**
"Justice is turned away backward."

*Ve-hussag achor mishpat*—justice turned back.

"Righteousness stands afar off."

*U-tzedaqah me-rachoq ta'amod*—righteousness distant.

"Truth is fallen in the street."

*Ki-khashla ba-rechov emet*—truth fallen.

"Uprightness cannot enter."

*U-nekhochah lo-tukhal lavo*—uprightness can't enter.

"Truth is lacking."

*Va-tehi ha-emet ne'deret*—truth lacking.

"He that departs from evil makes himself a prey."

*Ve-sar me-ra mishtollel*—avoiding evil makes one prey.

**YHWH Intervenes (59:15b-19):**
"YHWH saw it, and it displeased him that there was no justice."

*Va-yar YHWH va-yera be-einav ki-ein mishpat*—displeased by no justice.

**The Key Verse (59:16):**
"He saw that there was no man."

*Va-yar ki-ein ish*—no man.

"Was astonished that there was no intercessor."

*Va-yishtomem ki ein mafgi'a*—no intercessor.

"Therefore his own arm brought salvation unto him."

*Va-tosha lo zero'o*—own arm saves.

"His righteousness, it sustained him."

*Ve-tzidqato hi semakhathu*—righteousness sustains.

**The Key Verse (59:17):**
"He put on righteousness as a coat of mail."

*Va-yilbash tzedaqah ka-shiryan*—righteousness armor. Ephesians 6:14 echoes this.

"A helmet of salvation upon his head."

*Ve-kova yeshu'ah be-rosho*—salvation helmet. Ephesians 6:17 echoes this.

"He put on garments of vengeance for clothing."

*Va-yilbash bigdei naqam tilboshet*—vengeance garments.

"Was clad with zeal as a cloak."

*Va-ya'at ka-me'il qin'ah*—zeal cloak.

"According to their deeds, accordingly he will repay."

*Ke-al gemulot ke-al yeshallem*—repayment.

**The Key Verses (59:19-21):**
"They fear the name of YHWH from the west."

*Ve-yir'u mi-ma'arav et-shem YHWH*—west fears.

"His glory from the rising of the sun."

*U-mi-mizrach-shemesh et-kevodo*—east sees glory.

"He will come as a rushing stream."

*Ki-yavo kha-nahar tzar*—rushing stream.

"Which the breath of YHWH drives."

*Ruach YHWH nosesah vo*—YHWH's breath drives.

**The Key Verse (59:20):**
"A Redeemer will come to Zion."

*U-va le-Tziyyon go'el*—Redeemer to Zion. Romans 11:26 quotes this.

"Unto them that turn from transgression in Jacob."

*U-le-shavei fesha be-Ya'aqov*—to those turning from transgression.

**The Key Verse (59:21):**
"This is my covenant with them, says YHWH."

*Ve-ani zot beriti otam amar YHWH*—covenant.

"My spirit that is upon you."

*Ruchi asher alekha*—Spirit upon.

"My words which I have put in your mouth."

*U-devarai asher-samti be-fikha*—words in mouth.

"Shall not depart out of your mouth."

*Lo-yamushu mi-pikha*—not depart from mouth.

"Nor out of the mouth of your seed."

*U-mi-pi zar'akha*—nor from seed's mouth.

"Nor out of the mouth of your seed's seed."

*U-mi-pi zera zar'akha*—nor from seed's seed.

"From henceforth and forever."

*Me-attah ve-ad-olam*—forever.

**Archetypal Layer:** Isaiah 59 contains **"your iniquities have separated between you and your God" (59:2)**, **"their feet run to evil" (59:7)**—Romans 3:15, **the divine warrior arming himself (59:17)**—Ephesians 6:14-17, and **"a Redeemer will come to Zion" (59:20)**—Romans 11:26.

**Ethical Inversion Applied:**
- "YHWH's hand is not shortened, that it cannot save"—hand not short
- "Neither his ear heavy, that it cannot hear"—ear not heavy
- "Your iniquities have separated between you and your God"—separation
- "Your sins have hid his face from you"—hidden face
- "Your hands are defiled with blood"—bloody hands
- "Their feet run to evil"—Romans 3:15
- "They make haste to shed innocent blood"—shedding blood
- "The way of peace they know not"—Romans 3:17
- "There is no justice in their goings"—no justice
- "Therefore is justice far from us"—justice far
- "We grope for the wall like the blind"—blind groping
- "We roar all like bears"—bear roaring
- "Our transgressions are multiplied before you"—many transgressions
- "Justice is turned away backward"—justice backward
- "Truth is fallen in the street"—truth fallen
- "He that departs from evil makes himself a prey"—avoiding evil dangerous
- "He saw that there was no man... no intercessor"—no intercessor
- "His own arm brought salvation unto him"—own arm saves
- "He put on righteousness as a coat of mail"—Ephesians 6:14
- "A helmet of salvation upon his head"—Ephesians 6:17
- "He put on garments of vengeance"—vengeance
- "A Redeemer will come to Zion"—Romans 11:26
- "My spirit that is upon you... shall not depart"—Spirit covenant

**Modern Equivalent:** Isaiah 59's catalog of sins (59:3-8) is quoted in Romans 3:15-17 to prove universal sinfulness. The divine warrior imagery (59:17) underlies Ephesians 6:14-17. "A Redeemer will come to Zion" (59:20) is quoted in Romans 11:26 for Israel's salvation.

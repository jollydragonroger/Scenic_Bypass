# Isaiah 52: Awake, O Zion, and the Suffering Servant Introduced

*From the Hebrew: עוּרִי עוּרִי לִבְשִׁי עֻזֵּךְ צִיּוֹן (Uri Uri Livshi Uzzekh Tziyyon) — Awake, Awake, Put On Your Strength, O Zion*

---

## Zion Arises (52:1-6)

**52:1** Awake, awake, put on your strength, O Zion; put on your beautiful garments, O Jerusalem, the holy city; for henceforth there shall no more come into you the uncircumcised and the unclean.

**52:2** Shake yourself from the dust, arise, and sit down, O Jerusalem; loose yourself from the bands of your neck, O captive daughter of Zion.

**52:3** For thus says YHWH: You were sold for nought; and you shall be redeemed without money.

**52:4** For thus says the Lord YHWH: My people went down at the first into Egypt to sojourn there; and Assyria has oppressed them without cause.

**52:5** Now therefore, what do I here, says YHWH, seeing that my people is taken away for nought? They that rule over them do howl, says YHWH, and my name continually all the day is blasphemed.

**52:6** Therefore my people shall know my name; therefore they shall know in that day that I, even he that spoke, behold, here I am.

---

## How Beautiful on the Mountains (52:7-10)

**52:7** How beautiful upon the mountains are the feet of him that brings good tidings, that publishes peace, that brings good tidings of good, that publishes salvation; that says unto Zion: "Your God reigns!"

**52:8** The voice of your watchmen! They lift up the voice, together do they sing; for they shall see, eye to eye, YHWH returning to Zion.

**52:9** Break forth into joy, sing together, you waste places of Jerusalem; for YHWH has comforted his people, he has redeemed Jerusalem.

**52:10** YHWH has made bare his holy arm in the eyes of all the nations; and all the ends of the earth shall see the salvation of our God.

---

## Depart from Babylon (52:11-12)

**52:11** Depart, depart, go out from there, touch no unclean thing; go out of the midst of her; be clean, you that bear the vessels of YHWH.

**52:12** For you shall not go out in haste, neither shall you go by flight; for YHWH will go before you, and the God of Israel will be your rearguard.

---

## The Suffering Servant Introduced (52:13-15)

**52:13** Behold, my servant shall prosper, he shall be exalted and lifted up, and shall be very high.

**52:14** According as many were astonished at you—so marred was his visage unlike that of a man, and his form unlike that of the sons of men—

**52:15** So shall he startle many nations; kings shall shut their mouths at him; for that which had not been told them shall they see, and that which they had not heard shall they perceive.

---

## Synthesis Notes

**Key Restorations:**

**Zion Awakens (52:1-2):**
"Awake, awake, put on your strength, O Zion."

*Uri uri livshi uzzekh Tziyyon*—Zion awakens.

"Put on your beautiful garments, O Jerusalem."

*Livshi bigdei tif'artek Yerushalayim*—beautiful garments.

"The holy city."

*Ir ha-qodesh*—holy city.

"For henceforth there shall no more come into you the uncircumcised and the unclean."

*Ki lo yosif yavo-vakh od arel ve-tame*—no more uncircumcised/unclean.

"Shake yourself from the dust, arise."

*Hitna'ari me-afar qumi*—shake off dust.

"Sit down, O Jerusalem."

*Shevi Yerushalayim*—sit enthroned.

"Loose yourself from the bands of your neck, O captive daughter of Zion."

*Hitpatechi moserot tzavvarekh sheviyyah bat-Tziyyon*—neck bands loosed.

**Redemption Without Money (52:3-6):**
"You were sold for nought."

*Chinnam nimkartem*—sold for nothing.

"You shall be redeemed without money."

*Ve-lo ve-khesef tigga'elu*—redeemed without money.

"My people went down at the first into Egypt."

*Mitzrayim yarad-ammi va-rishonah*—Egypt first.

"Assyria has oppressed them without cause."

*Ve-Ashshur be-efes ashaqo*—Assyria oppressed.

"My people is taken away for nought."

*Chinnam luqqach ammi*—taken for nothing.

"They that rule over them do howl."

*Moshelav yeheililu*—rulers howl.

"My name continually all the day is blasphemed."

*Ve-tamid kol-ha-yom shemi mino'atz*—name blasphemed. Romans 2:24 cites this.

**The Key Verse (52:6):**
"My people shall know my name."

*Lakhen yeda ammi shemi*—name known.

"They shall know in that day that I, even he that spoke, behold, here I am."

*Lakhen ba-yom ha-hu ki-ani-hu ha-medabber hinnenni*—"I am he... here I am."

**The Key Verse (52:7):**
"How beautiful upon the mountains are the feet of him that brings good tidings."

*Mah-na'vu al-he-harim raglei mevasser*—beautiful feet. Romans 10:15 quotes this.

"That publishes peace."

*Mashmi'a shalom*—peace-publisher.

"That brings good tidings of good."

*Mevasser tov*—good news.

"That publishes salvation."

*Mashmi'a yeshu'ah*—salvation-publisher.

"That says unto Zion: 'Your God reigns!'"

*Omer le-Tziyyon malakh Elohayikh*—"Your God reigns!"

**Watchmen See (52:8-10):**
"The voice of your watchmen!"

*Qol tzofayikh*—watchmen's voice.

"They lift up the voice, together do they sing."

*Nas'u qol yachdav yerannennu*—singing together.

"For they shall see, eye to eye."

*Ki ayin be-ayin yir'u*—eye to eye.

"YHWH returning to Zion."

*Be-shuv YHWH Tziyyon*—YHWH returns.

"Break forth into joy, sing together, you waste places of Jerusalem."

*Pitzchu rannennu yachdav chorvot Yerushalayim*—ruins sing.

"YHWH has comforted his people."

*Ki-nicham YHWH ammo*—comfort.

"He has redeemed Jerusalem."

*Ga'al Yerushalayim*—Jerusalem redeemed.

**The Key Verse (52:10):**
"YHWH has made bare his holy arm."

*Chasaf YHWH et-zero'a qodsho*—holy arm bared.

"In the eyes of all the nations."

*Le-einei kol-ha-goyim*—nations see.

"All the ends of the earth shall see the salvation of our God."

*Ve-ra'u kol-afsei-aretz et yeshu'at Eloheinu*—earth's ends see salvation. Luke 3:6 echoes this.

**Depart from Babylon (52:11-12):**
"Depart, depart, go out from there."

*Suru suru tze'u mi-sham*—depart.

"Touch no unclean thing."

*Tame al-tigga'u*—no unclean touch. 2 Corinthians 6:17 quotes this.

"Go out of the midst of her."

*Tze'u mi-tokhah*—exit.

"Be clean, you that bear the vessels of YHWH."

*Hibbaru nos'ei kelei YHWH*—clean vessel-bearers.

"You shall not go out in haste."

*Ki lo ve-chippazon tetze'u*—not in haste.

"Neither shall you go by flight."

*U-vi-menusah lo telekhu*—not fleeing.

"YHWH will go before you."

*Ki-holekh lifneikhem YHWH*—YHWH leads.

"The God of Israel will be your rearguard."

*U-me'assefkhem Elohei Yisra'el*—God as rearguard.

**The Key Verses (52:13-15) — Fourth Servant Song Begins:**
"Behold, my servant shall prosper."

*Hinneh yaskil avdi*—servant prospers/succeeds.

"He shall be exalted and lifted up, and shall be very high."

*Yarum ve-nissa ve-gavah me'od*—exalted, lifted, very high.

"Many were astonished at you."

*Ka-asher shamemu alekha rabbim*—many astonished.

**The Key Verse (52:14):**
"So marred was his visage unlike that of a man."

*Ken-mishchat me-ish mar'ehu*—disfigured beyond man.

"His form unlike that of the sons of men."

*Ve-to'aro mi-benei adam*—form beyond human.

**The Key Verse (52:15):**
"So shall he startle many nations."

*Ken yazzeh goyim rabbim*—startles/sprinkles nations.

"Kings shall shut their mouths at him."

*Alav yiqpetzu melakhim pihem*—kings speechless.

"That which had not been told them shall they see."

*Ki asher lo-suppar lahem ra'u*—see untold things. Romans 15:21 quotes this.

"That which they had not heard shall they perceive."

*Va-asher lo-shame'u hitvonanu*—perceive unheard things.

**Archetypal Layer:** Isaiah 52 contains **"How beautiful... the feet of him that brings good tidings" (52:7)**—Romans 10:15, **"touch no unclean thing" (52:11)**—2 Corinthians 6:17, and **introduces the Fourth Servant Song (52:13-53:12)**.

**Ethical Inversion Applied:**
- "Awake, awake, put on your strength, O Zion"—Zion awakens
- "Put on your beautiful garments"—beauty restored
- "For henceforth there shall no more come into you the uncircumcised"—purity
- "Shake yourself from the dust, arise"—dust shaken
- "Loose yourself from the bands of your neck"—captivity ended
- "You were sold for nought; you shall be redeemed without money"—free redemption
- "My name continually all the day is blasphemed"—Romans 2:24
- "My people shall know my name"—name known
- "How beautiful upon the mountains are the feet of him that brings good tidings"—Romans 10:15
- "That publishes peace... salvation"—gospel content
- "'Your God reigns!'"—divine reign
- "They shall see, eye to eye, YHWH returning to Zion"—YHWH returns
- "YHWH has made bare his holy arm"—arm revealed
- "All the ends of the earth shall see the salvation of our God"—universal salvation
- "Depart, depart, go out from there"—Babylon exit
- "Touch no unclean thing"—2 Corinthians 6:17
- "YHWH will go before you, and the God of Israel will be your rearguard"—protection
- "Behold, my servant shall prosper"—servant success
- "He shall be exalted and lifted up, and shall be very high"—triple exaltation
- "So marred was his visage unlike that of a man"—disfigured
- "So shall he startle many nations"—nations startled
- "Kings shall shut their mouths at him"—kings silent
- "That which had not been told them shall they see"—Romans 15:21

**Modern Equivalent:** Isaiah 52:7's "beautiful feet" gospel herald is quoted in Romans 10:15. "Touch no unclean thing" (52:11) is quoted in 2 Corinthians 6:17. The Fourth Servant Song begins at 52:13, with the Servant's exaltation (52:13), disfigurement (52:14), and impact on nations (52:15) setting up Isaiah 53.

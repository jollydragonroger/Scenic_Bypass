# Isaiah 3: Judgment on Jerusalem's Leadership

*From the Hebrew: כִּי הִנֵּה הָאָדוֹן יְהוָה צְבָאוֹת (Ki Hinneh Ha-Adon YHWH Tzeva'ot) — For Behold, the Lord YHWH of Hosts*

---

## The Removal of Leadership (3:1-7)

**3:1** For, behold, the Lord, YHWH of hosts,
does take away from Jerusalem and from Judah
stay and staff,
every stay of bread, and every stay of water;

**3:2** The mighty man, and the man of war;
the judge, and the prophet, and the diviner, and the elder;

**3:3** The captain of fifty, and the man of rank, and the counsellor,
and the cunning charmer, and the skillful enchanter.

**3:4** And I will give children to be their princes,
and babes shall rule over them.

**3:5** And the people shall oppress one another,
every man his fellow, and every man his neighbor;
the child shall behave insolently against the aged,
and the base against the honorable.

**3:6** When a man shall take hold of his brother in the house of his father, saying:
"You have a mantle, be our ruler,
and let this ruin be under your hand";

**3:7** In that day shall he swear, saying:
"I will not be a healer;
for in my house is neither bread nor clothing;
you shall not make me ruler of the people."

---

## Indictment of Jerusalem (3:8-15)

**3:8** For Jerusalem is ruined, and Judah is fallen;
because their tongue and their doings are against YHWH,
to provoke the eyes of his glory.

**3:9** The show of their countenance does witness against them;
and they declare their sin as Sodom, they hide it not.
Woe unto their soul!
For they have wrought evil unto themselves.

**3:10** Say of the righteous, that it shall be well with him;
for they shall eat the fruit of their doings.

**3:11** Woe unto the wicked! It shall be ill with him;
for the work of his hands shall be done to him.

**3:12** As for my people, children are their oppressors,
and women rule over them.
O my people, they that lead you cause you to err,
and destroy the way of your paths.

**3:13** YHWH stands up to plead,
and stands to judge the peoples.

**3:14** YHWH will enter into judgment
with the elders of his people, and the princes thereof:
"It is you that have eaten up the vineyard;
the spoil of the poor is in your houses;

**3:15** "What mean you that you crush my people,
and grind the face of the poor?"
says the Lord, YHWH of hosts.

---

## Judgment on the Daughters of Zion (3:16-26)

**3:16** Moreover YHWH said:
Because the daughters of Zion are haughty,
and walk with stretched-forth necks and wanton eyes,
walking and mincing as they go,
and making a tinkling with their feet;

**3:17** Therefore the Lord will smite with a scab
the crown of the head of the daughters of Zion,
and YHWH will lay bare their secret parts.

**3:18** In that day the Lord will take away
the bravery of their anklets, and the fillets, and the crescents;

**3:19** The pendants, and the bracelets, and the veils;

**3:20** The headtires, and the armlets, and the sashes,
and the corselets, and the amulets;

**3:21** The rings, and the nose-jewels;

**3:22** The aprons, and the mantelets,
and the cloaks, and the girdles;

**3:23** And the gauze robes, and the fine linen,
and the turbans, and the mantles.

**3:24** And it shall come to pass,
that instead of sweet spices there shall be rottenness;
and instead of a girdle, a rope;
and instead of curled hair, baldness;
and instead of a stomacher, a girding of sackcloth;
branding instead of beauty.

**3:25** Your men shall fall by the sword,
and your mighty in the war.

**3:26** And her gates shall lament and mourn;
and utterly bereft she shall sit upon the ground.

---

## Synthesis Notes

**Key Restorations:**

**Removal of Support (3:1-3):**
"The Lord, YHWH of hosts, does take away from Jerusalem and from Judah stay and staff."

*Ha-Adon YHWH Tzeva'ot mesir mi-Yerushalayim u-mi-Yehudah mash'en u-mash'enah*—support removed.

"Every stay of bread, and every stay of water."

*Kol mish'an-lechem ve-khol mish'an-mayim*—food/water removed.

"The mighty man, and the man of war."

*Gibbor ve-ish milchamah*—warriors removed.

"The judge, and the prophet, and the diviner, and the elder."

*Shofet ve-navi ve-qosem ve-zaqen*—leaders removed.

**Child Rulers (3:4-5):**
"I will give children to be their princes."

*Ve-natatti ne'arim sareyhem*—child princes.

"Babes shall rule over them."

*Ve-ta'alulim yimshelu-vam*—babes ruling.

"The people shall oppress one another."

*Ve-niggs ha-am ish be-ish*—mutual oppression.

"The child shall behave insolently against the aged."

*Yirhavu ha-na'ar ba-zaqen*—youth vs. aged.

"The base against the honorable."

*Ve-ha-niqleh ba-nikhbad*—base vs. honorable.

**Leadership Vacuum (3:6-7):**
"'You have a mantle, be our ruler.'"

*Simlah lekha qatzin tihyeh-lanu*—desperate leadership.

"'Let this ruin be under your hand.'"

*Ve-ha-makhshelah ha-zot tachat yadekha*—ruin-management.

"'I will not be a healer.'"

*Lo-ehyeh chovesh*—refusal to lead.

**The Key Verse (3:10-11):**
"Say of the righteous, that it shall be well with him."

*Imru tzaddiq ki-tov*—good for righteous.

"For they shall eat the fruit of their doings."

*Ki-feri ma'aleleihem yokhelu*—eat fruit.

"Woe unto the wicked! It shall be ill with him."

*Oy la-rasha ra*—woe to wicked.

"The work of his hands shall be done to him."

*Ki-gemul yadav ye'aseh lo*—hands' work returned.

**Exploitation Indictment (3:14-15):**
"YHWH will enter into judgment with the elders."

*YHWH be-mishpat yavo im-ziqnei ammo*—elders judged.

"'It is you that have eaten up the vineyard.'"

*Ve-attem bi'artem ha-kerem*—vineyard devoured.

"'The spoil of the poor is in your houses.'"

*Gezellat he-ani be-vatteykem*—poor's spoil in houses.

**The Key Verse (3:15):**
"'What mean you that you crush my people.'"

*Mallakhem tedakke'u ammi*—crushing people.

"'And grind the face of the poor?'"

*U-fenei aniyyim titchanu*—grinding poor's face.

**Daughters of Zion (3:16-24):**
"The daughters of Zion are haughty."

*Ki gavhu benot-Tziyyon*—haughty daughters.

"Walk with stretched-forth necks."

*Va-telakhnah netuyot garon*—stretched necks.

"Wanton eyes."

*U-mesaqrot einayim*—flirtatious eyes.

"Walking and mincing as they go."

*Halokh ve-tafof telakhnah*—mincing walk.

"Making a tinkling with their feet."

*U-ve-ragleihem te'akkasnah*—tinkling anklets.

**Luxury to Poverty (3:24):**
"Instead of sweet spices there shall be rottenness."

*Ve-hayah tachat bosem maq yihyeh*—spices to rot.

"Instead of a girdle, a rope."

*Ve-tachat chagor niqpah*—belt to rope.

"Instead of curled hair, baldness."

*Ve-tachat ma'aseh miqsheh qorchah*—hair to baldness.

"Instead of a stomacher, a girding of sackcloth."

*Ve-tachat petiqil machgoret saq*—fine cloth to sackcloth.

"Branding instead of beauty."

*Ki tachat yofi*—beauty to branding.

**Archetypal Layer:** Isaiah 3 describes **leadership collapse**, **exploitation of the poor (3:14-15)**, and **judgment on luxury (3:16-24)**. Social order reverses; luxury becomes poverty.

**Ethical Inversion Applied:**
- "Does take away from Jerusalem and from Judah stay and staff"—support removed
- "The mighty man, and the man of war"—warriors gone
- "I will give children to be their princes"—immature leadership
- "The people shall oppress one another"—mutual oppression
- "'You have a mantle, be our ruler'"—desperate leadership
- "Say of the righteous, that it shall be well with him"—righteous prosper
- "Woe unto the wicked! It shall be ill with him"—wicked suffer
- "'It is you that have eaten up the vineyard'"—leaders exploit
- "'The spoil of the poor is in your houses'"—poor's goods stolen
- "'What mean you that you crush my people'"—crushing people
- "'And grind the face of the poor'"—grinding poor
- "The daughters of Zion are haughty"—luxury pride
- "Instead of sweet spices there shall be rottenness"—luxury reversed
- "Branding instead of beauty"—beauty reversed

**Modern Equivalent:** Isaiah 3's critique of leadership exploitation (3:14-15) and luxury amid poverty (3:16-24) remains relevant. "Grinding the face of the poor" describes economic oppression. Luxury removed reverses social position.

# Isaiah 7: The Sign of Immanuel

*From the Hebrew: וַיְהִי בִּימֵי אָחָז (Va-Yehi Bi-Mei Achaz) — And It Came to Pass in the Days of Ahaz*

---

## The Syro-Ephraimite Crisis (7:1-9)

**7:1** And it came to pass in the days of Ahaz the son of Jotham, the son of Uzziah, king of Judah, that Rezin the king of Aram, and Pekah the son of Remaliah, king of Israel, went up to Jerusalem to war against it; but could not prevail against it.

**7:2** And it was told the house of David, saying: "Aram is confederate with Ephraim." And his heart was moved, and the heart of his people, as the trees of the forest are moved with the wind.

**7:3** Then said YHWH unto Isaiah: "Go forth now to meet Ahaz, you, and Shear-jashub your son, at the end of the conduit of the upper pool, in the highway of the fuller's field;

**7:4** "And say unto him: Keep calm, and be quiet; fear not, neither let your heart be faint, because of these two tails of smoking firebrands, for the fierce anger of Rezin and Aram, and of the son of Remaliah.

**7:5** "Because Aram has counseled evil against you, Ephraim also, and the son of Remaliah, saying:

**7:6** "'Let us go up against Judah, and vex it, and let us make a breach therein for us, and set up a king in the midst of it, even the son of Tabeel';

**7:7** "Thus says the Lord YHWH: It shall not stand, neither shall it come to pass.

**7:8** "For the head of Aram is Damascus, and the head of Damascus is Rezin; and within threescore and five years shall Ephraim be broken, that it be not a people;

**7:9** "And the head of Ephraim is Samaria, and the head of Samaria is Remaliah's son. If you will not have faith, surely you shall not be established."

---

## The Sign of Immanuel (7:10-17)

**7:10** And YHWH spoke again unto Ahaz, saying:

**7:11** "Ask a sign of YHWH your God: ask it either in the depth, or in the height above."

**7:12** But Ahaz said: "I will not ask, neither will I put YHWH to the test."

**7:13** And he said: "Hear now, O house of David: Is it a small thing for you to weary men, that you will weary my God also?

**7:14** "Therefore the Lord himself shall give you a sign: behold, the young woman shall conceive, and bear a son, and shall call his name Immanuel.

**7:15** "Butter and honey shall he eat, when he knows to refuse the evil, and choose the good.

**7:16** "For before the child shall know to refuse the evil, and choose the good, the land whose two kings you dread shall be forsaken.

**7:17** "YHWH shall bring upon you, and upon your people, and upon your father's house, days that have not come, from the day that Ephraim departed from Judah; even the king of Assyria."

---

## The Assyrian Devastation (7:18-25)

**7:18** And it shall come to pass in that day, that YHWH shall hiss for the fly that is in the uttermost part of the rivers of Egypt, and for the bee that is in the land of Assyria.

**7:19** And they shall come, and shall rest all of them in the desolate valleys, and in the holes of the rocks, and upon all thorns, and upon all pastures.

**7:20** In that day shall the Lord shave with a razor that is hired in the parts beyond the River, even with the king of Assyria, the head and the hair of the feet; and it shall also consume the beard.

**7:21** And it shall come to pass in that day, that a man shall nourish a young cow, and two sheep;

**7:22** And it shall come to pass, for the abundance of milk that they shall give, that he shall eat butter; for butter and honey shall every one eat that is left in the midst of the land.

**7:23** And it shall come to pass in that day, that every place, where there were a thousand vines at a thousand silverlings, shall be for briers and thorns.

**7:24** With arrows and with bow shall one come thither; because all the land shall be briers and thorns.

**7:25** And all the hills that were digged with the mattock, you shall not come thither for fear of briers and thorns; but it shall be for the sending forth of oxen, and for the treading of sheep.

---

## Synthesis Notes

**Key Restorations:**

**Historical Setting (7:1-2):**
"In the days of Ahaz."

*Bi-mei Achaz*—approximately 735-732 BCE.

"Rezin the king of Aram, and Pekah... king of Israel."

*Retzin melekh-Aram u-Feqach... melekh-Yisra'el*—Syro-Ephraimite coalition.

"Went up to Jerusalem to war against it."

*La-milchamah alekha*—attacking Jerusalem.

"His heart was moved... as the trees of the forest are moved with the wind."

*Va-yanu levavo u-levav ammo ka-nu'a atzei-ya'ar mippenei-ruach*—terrified.

**Isaiah's Message (7:3-9):**
"Go forth now to meet Ahaz."

*Tze-na liqrat Achaz*—meet Ahaz.

"You, and Shear-jashub your son."

*Attah u-She'ar Yashub benekha*—"a remnant shall return."

"At the end of the conduit of the upper pool."

*El-qetzeh te'alat ha-berekhah ha-elyonah*—upper pool.

"Keep calm, and be quiet."

*Hishamer ve-hashqet*—calm down.

"Fear not, neither let your heart be faint."

*Al-tira ve-levavkha al-yerakh*—don't fear.

"These two tails of smoking firebrands."

*Shenei zanvot ha-udim ha-ashenim ha-elleh*—smoldering stumps.

**The Key Verse (7:9):**
"If you will not have faith, surely you shall not be established."

*Im lo ta'aminu ki lo te'amenu*—believe/be established wordplay.

**The Key Verse (7:14):**
"Therefore the Lord himself shall give you a sign."

*Lakhen yitten Adonai hu lakhem ot*—divine sign.

"Behold, the young woman shall conceive."

*Hinneh ha-almah harah*—the almah pregnant.

"And bear a son."

*Ve-yoledet ben*—bearing son.

"And shall call his name Immanuel."

*Ve-qara't shemo Immanu-El*—Immanuel = God with us.

**Translation Note:**
*Almah* (עַלְמָה) means "young woman of marriageable age." The LXX translated it *parthenos* (virgin), which Matthew 1:23 follows. The Hebrew word for virgin is *betulah*. The sign works historically (Isaiah's wife or young woman in Ahaz's court) and typologically (Mary/Jesus).

**Timing Sign (7:15-16):**
"Butter and honey shall he eat."

*Chem'ah u-devash yokhal*—simple diet (land devastated).

"When he knows to refuse the evil, and choose the good."

*Le-da'to ma'os ba-ra u-vachor ba-tov*—age of moral discernment.

"Before the child shall know to refuse the evil."

*Be-terem yeda ha-na'ar ma'os ba-ra u-vachor ba-tov*—before moral age.

"The land whose two kings you dread shall be forsaken."

*Te'azev ha-adamah asher attah qatz mippenei shenei melakhekha*—enemies gone.

**Assyria Warned (7:17-25):**
"YHWH shall bring upon you... the king of Assyria."

*Yavi YHWH alekha... et melekh Ashshur*—Assyria coming.

"YHWH shall hiss for the fly that is in... Egypt, and for the bee that is in... Assyria."

*Yishraq YHWH la-zevuv... Mitzrayim ve-la-devorah... Ashshur*—summoning powers.

"The Lord shave with a razor that is hired... the king of Assyria."

*Yegalleach Adonai be-ta'ar ha-sekhirah... be-melekh Ashshur*—Assyria as razor.

"The head and the hair of the feet."

*Et-ha-rosh u-se'ar ha-raglayim*—complete shaving (total humiliation).

**Archetypal Layer:** Isaiah 7 contains **the Immanuel prophecy (7:14)**—foundational for Christian messianic interpretation. The historical context is the Syro-Ephraimite crisis (735 BCE). The sign works on multiple levels.

**Ethical Inversion Applied:**
- "His heart was moved... as the trees of the forest"—fear
- "Shear-jashub"—"a remnant shall return" (sign-name)
- "These two tails of smoking firebrands"—enemies as stumps
- "If you will not have faith, surely you shall not be established"—faith wordplay
- "The Lord himself shall give you a sign"—divine sign
- "The young woman shall conceive"—almah
- "Shall call his name Immanuel"—God with us
- "Butter and honey shall he eat"—simple/survival diet
- "Before the child shall know to refuse the evil"—timing marker
- "The land whose two kings you dread shall be forsaken"—enemies removed
- "YHWH shall bring... the king of Assyria"—Assyria as judgment
- "YHWH shall hiss for the fly"—summoning Egypt
- "The Lord shave with a razor"—Assyria as razor

**Modern Equivalent:** Isaiah 7:14's "Immanuel" is quoted in Matthew 1:23 for Jesus' birth. The historical fulfillment (Ahaz's crisis resolved) and typological fulfillment (virgin birth) operate together. "If you will not believe, you will not be established" (7:9) connects faith and stability.

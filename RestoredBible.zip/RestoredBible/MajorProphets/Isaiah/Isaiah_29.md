# Isaiah 29: Woe to Ariel and the Sealed Book

*From the Hebrew: הוֹי אֲרִיאֵל אֲרִיאֵל (Hoy Ari'el Ari'el) — Woe to Ariel, Ariel*

---

## Woe to Ariel (29:1-8)

**29:1** Woe to Ariel, to Ariel, the city where David encamped!
Add year to year, let the feasts come round;

**29:2** Then will I distress Ariel,
and there shall be mourning and moaning;
and she shall be unto me as a hearth of God.

**29:3** And I will encamp against you round about,
and will lay siege against you with a mound,
and I will raise siege works against you.

**29:4** And brought low you shall speak out of the ground,
and your speech shall come low out of the dust;
and your voice shall be as of a ghost out of the ground,
and your speech shall chirp out of the dust.

**29:5** But the multitude of your foes shall be like small dust,
and the multitude of the terrible ones as chaff that passes away;
yea, it shall be at an instant suddenly.

**29:6** From YHWH of hosts shall punishment come
with thunder, and with earthquake, and great noise,
with whirlwind and tempest, and the flame of a devouring fire.

**29:7** And the multitude of all the nations that war against Ariel,
even all that war against her and her stronghold, and that distress her,
shall be as a dream, a vision of the night.

**29:8** And it shall be as when a hungry man dreams, and, behold, he eats,
but he awakes, and his soul is empty;
or as when a thirsty man dreams, and, behold, he drinks,
but he awakes, and, behold, he is faint, and his soul has appetite—
so shall the multitude of all the nations be, that fight against mount Zion.

---

## Blindness and the Sealed Book (29:9-14)

**29:9** Stupefy yourselves, and be stupid;
blind yourselves, and be blind;
be drunk, but not with wine;
stagger, but not with strong drink.

**29:10** For YHWH has poured out upon you the spirit of deep sleep,
and has closed your eyes; the prophets,
and your heads, the seers, has he covered.

**29:11** And the vision of all this is become unto you as the words of a book that is sealed, which men deliver to one that is learned, saying: "Read this, I pray you"; and he says: "I cannot, for it is sealed";

**29:12** And the book is delivered to him that is not learned, saying: "Read this, I pray you"; and he says: "I am not learned."

**29:13** And the Lord said:
Forasmuch as this people draw near,
and with their mouth and with their lips do honor me,
but have removed their heart far from me,
and their fear of me is a commandment of men learned by rote;

**29:14** Therefore, behold, I will again do a marvelous work among this people,
even a marvelous work and a wonder;
and the wisdom of their wise men shall perish,
and the prudence of their prudent men shall be hid.

---

## Woe to Those Who Hide (29:15-16)

**29:15** Woe unto them that seek deep to hide their counsel from YHWH,
and their works are in the dark, and they say:
"Who sees us? And who knows us?"

**29:16** O your perversity! Shall the potter be esteemed as clay;
that the thing made should say of him that made it: "He made me not";
or the thing framed say of him that framed it: "He has no understanding"?

---

## Future Transformation (29:17-24)

**29:17** Is it not yet a very little while,
and Lebanon shall be turned into a fruitful field,
and the fruitful field shall be esteemed as a forest?

**29:18** And in that day shall the deaf hear the words of a book,
and the eyes of the blind shall see out of obscurity and out of darkness.

**29:19** The humble also shall increase their joy in YHWH,
and the neediest among men shall exult in the Holy One of Israel.

**29:20** For the terrible one is brought to nought, and the scorner ceases,
and all they that watch for iniquity are cut off;

**29:21** That make a man an offender by a word,
and lay a snare for him that reproves in the gate,
and turn aside the just with a thing of nought.

**29:22** Therefore thus says YHWH, who redeemed Abraham, concerning the house of Jacob:
Jacob shall not now be ashamed,
neither shall his face now wax pale.

**29:23** For when he sees his children, the work of my hands, in the midst of him,
they shall sanctify my name;
yea, they shall sanctify the Holy One of Jacob,
and shall stand in awe of the God of Israel.

**29:24** They also that err in spirit shall come to understanding,
and they that murmur shall learn doctrine.

---

## Synthesis Notes

**Key Restorations:**

**Ariel (29:1-4):**
"Woe to Ariel, to Ariel, the city where David encamped!"

*Hoy Ari'el Ari'el qiryat chanah David*—Ariel = lion of God / altar hearth = Jerusalem.

"Add year to year, let the feasts come round."

*Sefu shanah al-shanah chaggim yinqofu*—cycle continues.

"Then will I distress Ariel."

*Va-hatziqoti le-Ari'el*—distress.

"She shall be unto me as a hearth of God."

*Ve-haytah li ka-ari'el*—altar hearth (sacrifice site).

"I will encamp against you round about."

*Ve-chaniti alayikh kaddur*—YHWH besieges.

"Brought low you shall speak out of the ground."

*Ve-shafalti me-eretz tedabberi*—speaking from dust.

"Your voice shall be as of a ghost out of the ground."

*Ve-hayah ke-ov me-eretz qolekh*—ghost-voice.

**Sudden Deliverance (29:5-8):**
"The multitude of your foes shall be like small dust."

*Ve-hayah ke-avaq daq hamon zarayikh*—foes as dust.

"It shall be at an instant suddenly."

*Ve-hayah le-feta pitom*—sudden.

"From YHWH of hosts shall punishment come."

*Me-im YHWH Tzeva'ot tippaqed*—YHWH punishes.

"With thunder, and with earthquake, and great noise."

*Be-ra'am u-ve-ra'ash ve-qol gadol*—theophany.

"The multitude of all the nations that war against Ariel... shall be as a dream."

*Ve-hayah ka-chalom chazon laylah hamon kol-ha-goyim ha-tzove'im al-Ari'el*—enemies vanish like dream.

**Blindness (29:9-12):**
"Stupefy yourselves, and be stupid."

*Hitmahmehu u-temahu*—self-stupefying.

"Blind yourselves, and be blind."

*Hisha'u va-sha'u*—self-blinding.

"Be drunk, but not with wine."

*Shakeru ve-lo yayin*—spiritual drunkenness.

"YHWH has poured out upon you the spirit of deep sleep."

*Ki-nasakh aleikem YHWH ruach tardemah*—deep sleep spirit.

"Has closed your eyes; the prophets."

*Va-ye'attzem et-eineikhem et-ha-nevi'im*—prophets blinded.

"Your heads, the seers, has he covered."

*Ve-et-rasheikhem ha-chozim kissah*—seers covered.

"The vision of all this is become unto you as the words of a book that is sealed."

*Va-tehi lakhem chazut ha-kol ke-divrei ha-sefer he-chatum*—sealed book.

"'Read this, I pray you'; and he says: 'I cannot, for it is sealed.'"

*Qera-na zeh ve-amar lo ukhal ki chatum hu*—can't read—sealed.

"'Read this, I pray you'; and he says: 'I am not learned.'"

*Qera-na zeh ve-amar lo yadati sefer*—can't read—unlearned.

**The Key Verse (29:13):**
"This people draw near, and with their mouth and with their lips do honor me."

*Ha-am ha-zeh bi-fiv u-vi-sefatav kibbeduni*—lip service.

"But have removed their heart far from me."

*Ve-libbo richoq mimmeni*—distant heart.

"Their fear of me is a commandment of men learned by rote."

*Va-tehi yir'atam oti mitzvat anashim melummadah*—rote religion. Jesus quotes this in Matthew 15:8-9; Mark 7:6-7.

**The Key Verse (29:14):**
"I will again do a marvelous work among this people."

*Hineni yosif le-hafli et-ha-am-ha-zeh hafle va-fele*—marvelous work.

"The wisdom of their wise men shall perish."

*Ve-avdah chokhmat chakhamav*—wisdom perishes. 1 Corinthians 1:19 quotes this.

"The prudence of their prudent men shall be hid."

*U-vinat nevonavav tisstatter*—prudence hidden.

**Potter and Clay (29:15-16):**
"Woe unto them that seek deep to hide their counsel from YHWH."

*Hoy ha-ma'amiqim me-YHWH lastir etzah*—hiding from YHWH.

"'Who sees us? And who knows us?'"

*Mi ro'enu u-mi yode'enu*—denying divine sight.

**The Key Verse (29:16):**
"Shall the potter be esteemed as clay."

*Im-ke-chomer ha-yotzer yechashev*—potter/clay reversed.

"The thing made should say of him that made it: 'He made me not.'"

*Ki-yomar ma'aseh le-osehu lo asani*—denying maker.

"The thing framed say of him that framed it: 'He has no understanding.'"

*Ve-yetzer amar le-yotzro lo hevin*—accusing creator.

**Future Transformation (29:17-24):**
"Lebanon shall be turned into a fruitful field."

*Ve-shav Levanon la-karmel*—Lebanon to garden.

**The Key Verse (29:18):**
"In that day shall the deaf hear the words of a book."

*Ve-sham'u va-yom ha-hu ha-chershim divrei-sefer*—deaf hear book.

"The eyes of the blind shall see out of obscurity and out of darkness."

*U-me-ofel u-me-choshekh einei ivrim tir'eynah*—blind see.

"The humble also shall increase their joy in YHWH."

*Ve-yasfu anavim ba-YHWH simchah*—humble rejoice.

"The neediest among men shall exult in the Holy One of Israel."

*Ve-evyonei adam bi-Qedosh Yisra'el yagilu*—needy exult.

"They also that err in spirit shall come to understanding."

*Ve-yad'u to'ei-ruach binah*—erring understand.

"They that murmur shall learn doctrine."

*Ve-rogenim yilmedu-leqach*—murmurers learn.

**Archetypal Layer:** Isaiah 29 contains **the lip-service critique (29:13)**—quoted by Jesus—and **the wisdom perishes (29:14)**—quoted by Paul in 1 Corinthians 1:19. The potter/clay imagery (29:16) recurs in Romans 9:20.

**Ethical Inversion Applied:**
- "Woe to Ariel... the city where David encamped"—Jerusalem warned
- "I will encamp against you round about"—YHWH besieges
- "Your voice shall be as of a ghost out of the ground"—humbled speech
- "The multitude of your foes shall be like small dust"—enemies vanish
- "It shall be at an instant suddenly"—sudden deliverance
- "YHWH has poured out upon you the spirit of deep sleep"—spiritual blindness
- "The vision... as the words of a book that is sealed"—sealed book
- "This people... with their mouth and with their lips do honor me"—Matthew 15:8-9
- "Their heart far from me"—distant heart
- "Their fear of me is a commandment of men learned by rote"—rote religion
- "I will again do a marvelous work"—marvelous work
- "The wisdom of their wise men shall perish"—1 Corinthians 1:19
- "Shall the potter be esteemed as clay"—Romans 9:20
- "The deaf hear... the blind shall see"—messianic signs
- "The humble also shall increase their joy"—humble rejoice
- "They also that err in spirit shall come to understanding"—transformation

**Modern Equivalent:** Isaiah 29:13's lip-service critique is quoted by Jesus (Matthew 15:8-9; Mark 7:6-7). The perishing wisdom (29:14) is quoted by Paul (1 Corinthians 1:19). The potter/clay (29:16) underlies Romans 9:20. The deaf hearing and blind seeing (29:18) anticipates Jesus' messianic signs.

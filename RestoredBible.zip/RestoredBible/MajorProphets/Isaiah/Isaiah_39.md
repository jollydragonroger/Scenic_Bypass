# Isaiah 39: The Babylonian Envoys

*From the Hebrew: בָּעֵת הַהִיא שָׁלַח מְרֹדַךְ בַּלְאֲדָן (Ba-Et Ha-Hi Shalach Merodakh Bal'adan) — At That Time Merodach-baladan... Sent*

---

## Babylon's Embassy (39:1-2)

**39:1** At that time Merodach-baladan the son of Baladan, king of Babylon, sent letters and a present to Hezekiah; for he heard that he had been sick, and was recovered.

**39:2** And Hezekiah was glad of them, and showed them his treasure-house, the silver, and the gold, and the spices, and the precious oil, and all the house of his armour, and all that was found in his treasures; there was nothing in his house, nor in all his dominion, that Hezekiah showed them not.

---

## Isaiah's Inquiry (39:3-4)

**39:3** Then came Isaiah the prophet unto king Hezekiah, and said unto him: "What said these men? And from whence came they unto you?" And Hezekiah said: "They are come from a far country unto me, even from Babylon."

**39:4** Then said he: "What have they seen in your house?" And Hezekiah answered: "All that is in my house have they seen; there is nothing among my treasures that I have not shown them."

---

## The Prophecy of Exile (39:5-8)

**39:5** Then said Isaiah to Hezekiah: "Hear the word of YHWH of hosts:

**39:6** "Behold, the days come, that all that is in your house, and that which your fathers have laid up in store until this day, shall be carried to Babylon; nothing shall be left, says YHWH.

**39:7** "And of your sons that shall issue from you, whom you shall beget, shall they take away; and they shall be officers in the palace of the king of Babylon."

**39:8** Then said Hezekiah unto Isaiah: "Good is the word of YHWH which you have spoken." He said moreover: "For there shall be peace and truth in my days."

---

## Synthesis Notes

**Key Restorations:**

**Babylonian Embassy (39:1):**
"At that time Merodach-baladan the son of Baladan, king of Babylon."

*Ba-et ha-hi shalach Merodakh Bal'adan ben-Bal'adan melekh-Bavel*—Merodach-baladan II (reigned 721-710, 703-702 BCE).

"Sent letters and a present to Hezekiah."

*Sefarim u-minchah el-Chizkiyyahu*—letters and gift.

"For he heard that he had been sick, and was recovered."

*Va-yishma ki chalah va-yechezaq*—heard of illness/recovery.

**Historical Note:**
Merodach-baladan was a Chaldean king who rebelled against Assyria. His embassy to Hezekiah was likely a diplomatic mission seeking anti-Assyrian allies. This visit probably occurred before Sennacherib's invasion (701 BCE).

**Hezekiah's Display (39:2):**
"Hezekiah was glad of them."

*Va-yismach aleihem Chizkiyyahu*—glad reception.

"Showed them his treasure-house."

*Va-yar'em et-beit nekhoto*—treasury shown.

"The silver, and the gold, and the spices, and the precious oil."

*Et-ha-kesef ve-et-ha-zahav ve-et-ha-besamim ve-et ha-shemen ha-tov*—valuables.

"All the house of his armour."

*Ve-et kol-beit kelav*—armory.

"All that was found in his treasures."

*Ve-et kol-asher nimtza be-otzrotav*—all treasures.

"There was nothing in his house, nor in all his dominion, that Hezekiah showed them not."

*Lo-hayah davar asher lo-her'am Chizkiyyahu be-veito u-ve-khol-memshallto*—complete disclosure.

**Isaiah's Questions (39:3-4):**
"What said these men?"

*Mah amru ha-anashim ha-elleh*—what did they say?

"From whence came they unto you?"

*U-me-ayin yavo'u elekha*—where from?

"They are come from a far country unto me, even from Babylon."

*Me-eretz rechoquah ba'u elai mi-Bavel*—far country, Babylon.

"What have they seen in your house?"

*Mah ra'u be-veitekha*—what did they see?

"All that is in my house have they seen."

*Kol asher be-veiti ra'u*—saw everything.

"There is nothing among my treasures that I have not shown them."

*Lo-hayah davar asher lo-hir'itim be-otzrotai*—showed all.

**The Key Verses (39:5-7):**
"Hear the word of YHWH of hosts."

*Shema devar-YHWH Tzeva'ot*—hear YHWH's word.

"Behold, the days come, that all that is in your house... shall be carried to Babylon."

*Hinneh yamim ba'im ve-nissa kol-asher be-veitekha... Bavelah*—carried to Babylon.

"That which your fathers have laid up in store until this day."

*Va-asher otzru avotekha ad-ha-yom ha-zeh*—ancestral treasures.

"Nothing shall be left, says YHWH."

*Lo-yivvater davar amar YHWH*—nothing left.

"Of your sons that shall issue from you, whom you shall beget."

*U-mi-banekha asher yetze'u mimmekha asher tolid*—your descendants.

"Shall they take away."

*Yiqqachu*—taken.

"They shall be officers in the palace of the king of Babylon."

*Ve-hayu sarisim be-heikhal melekh Bavel*—officials in Babylon's palace.

**The Key Verse (39:8):**
"Good is the word of YHWH which you have spoken."

*Tov devar-YHWH asher dibbarta*—good word.

"For there shall be peace and truth in my days."

*Ki yihyeh shalom ve-emet be-yamai*—peace in my days.

**Interpretation of Hezekiah's Response:**
Hezekiah's response is ambiguous. It could be:
1. Acceptance of divine judgment as just
2. Relief that the disaster won't occur in his lifetime
3. A combination—accepting judgment while grateful for personal reprieve

The response has been criticized as self-centered, but may reflect submission to God's word.

**Archetypal Layer:** Isaiah 39 concludes the historical section (chapters 36-39) and **bridges to Second Isaiah (chapters 40-55)** by introducing Babylon as the future threat. This sets up the exile-and-return theme of chapters 40-66.

**Ethical Inversion Applied:**
- "Merodach-baladan... king of Babylon, sent letters and a present"—diplomatic mission
- "He heard that he had been sick, and was recovered"—recovery news
- "Hezekiah was glad of them"—glad reception (problematic)
- "Showed them his treasure-house"—complete disclosure (unwise)
- "There was nothing... that Hezekiah showed them not"—showed everything
- "'What said these men? And from whence came they?'"—Isaiah's probing questions
- "'They are come from a far country... from Babylon'"—Babylon mentioned
- "'What have they seen in your house?'"—key question
- "'All that is in my house have they seen'"—full disclosure admitted
- "'Behold, the days come, that all... shall be carried to Babylon'"—exile prophecy
- "'Nothing shall be left'"—complete removal
- "'Of your sons... shall they take away'"—descendants exiled
- "'They shall be officers in the palace of the king of Babylon'"—Daniel fulfillment
- "'Good is the word of YHWH'"—acceptance
- "'There shall be peace and truth in my days'"—personal reprieve

**Modern Equivalent:** Isaiah 39 prophesies the Babylonian exile (fulfilled 586 BCE). The mention of Hezekiah's sons becoming "officers in the palace of the king of Babylon" (39:7) is fulfilled in Daniel and his companions. This chapter bridges First Isaiah (1-39) and Second Isaiah (40-55).

---

## Section Summary: Isaiah 36-39 (Historical Narrative)

Chapters 36-39 parallel 2 Kings 18-20:

**Structure:**
- **36-37**: Sennacherib's invasion and miraculous deliverance
- **38**: Hezekiah's illness, prayer, recovery, and psalm
- **39**: Babylonian embassy and exile prophecy

**Major Themes:**
- **Trust in YHWH** vs. trust in Egypt/Assyria
- **Prayer changes outcomes** (37:14-20; 38:2-3)
- **Divine deliverance** (37:36—angel slays 185,000)
- **The living praise God** (38:19)
- **Babylon as future threat** (39:6-7)—transitional

**Historical Confirmation:**
- Sennacherib's Prism confirms invasion but omits capturing Jerusalem
- Sennacherib's assassination by his sons confirmed by Assyrian records
- Merodach-baladan's reign confirmed archaeologically

# Isaiah 30: Woe to the Rebellious Children

*From the Hebrew: הוֹי בָּנִים סוֹרְרִים (Hoy Banim Sorerim) — Woe to the Rebellious Children*

---

## The Folly of Trusting Egypt (30:1-7)

**30:1** Woe to the rebellious children, says YHWH,
that take counsel, but not of me;
and that form projects, but not of my spirit,
that they may add sin to sin;

**30:2** That walk to go down into Egypt,
and have not asked at my mouth;
to take refuge in the stronghold of Pharaoh,
and to take shelter in the shadow of Egypt!

**30:3** Therefore shall the stronghold of Pharaoh turn to your shame,
and the shelter in the shadow of Egypt to your confusion.

**30:4** For his princes are at Zoan,
and his ambassadors are come to Hanes.

**30:5** They shall all be ashamed of a people that cannot profit them,
that are not a help nor profit,
but a shame, and also a reproach.

**30:6** The burden of the beasts of the South.
Through the land of trouble and anguish,
from whence come the lioness and the lion,
the viper and flying serpent,
they carry their riches upon the shoulders of young donkeys,
and their treasures upon the humps of camels,
to a people that shall not profit them.

**30:7** For Egypt helps in vain, and to no purpose;
therefore have I called her:
"Rahab that sits still."

---

## A Rebellious People (30:8-17)

**30:8** Now go, write it before them on a tablet,
and inscribe it in a book,
that it may be for the time to come forever and ever.

**30:9** For it is a rebellious people, lying children,
children that refuse to hear the teaching of YHWH;

**30:10** That say to the seers: "See not";
and to the prophets: "Prophesy not unto us right things,
speak unto us smooth things, prophesy delusions;

**30:11** "Get out of the way, turn aside out of the path,
cause the Holy One of Israel to cease from before us."

**30:12** Wherefore thus says the Holy One of Israel:
Because you despise this word,
and trust in oppression and perverseness, and stay thereon;

**30:13** Therefore this iniquity shall be to you
as a breach ready to fall, swelling out in a high wall,
whose breaking comes suddenly at an instant.

**30:14** And its breaking is as the breaking of a potter's vessel
that is broken in pieces without sparing;
so that there shall not be found among the pieces thereof
a shard to take fire from the hearth,
or to take water out of the cistern.

**30:15** For thus said the Lord YHWH, the Holy One of Israel:
In sitting still and rest shall you be saved,
in quietness and in confidence shall be your strength;
and you would not.

**30:16** But you said: "No, for we will flee upon horses";
therefore shall you flee;
and: "We will ride upon the swift";
therefore shall they that pursue you be swift.

**30:17** One thousand shall flee at the rebuke of one,
at the rebuke of five shall you flee;
till you be left as a beacon upon the top of a mountain,
and as an ensign on a hill.

---

## Grace for Those Who Wait (30:18-26)

**30:18** And therefore will YHWH wait, that he may be gracious unto you,
and therefore will he be exalted, that he may have compassion upon you;
for YHWH is a God of justice;
happy are all they that wait for him.

**30:19** For, O people that dwells in Zion at Jerusalem,
you shall weep no more;
he will surely be gracious unto you at the voice of your cry;
when he shall hear, he will answer you.

**30:20** And though the Lord give you sparing bread and scant water,
yet shall your Teacher not be hidden any more,
but your eyes shall see your Teacher;

**30:21** And your ears shall hear a word behind you, saying:
"This is the way, walk in it,"
when you turn to the right hand, and when you turn to the left.

**30:22** And you shall defile your graven images overlaid with silver,
and your molten images covered with gold;
you shall cast them away as an unclean thing;
you shall say unto it: "Get out."

**30:23** And he will give the rain for your seed, wherewith you sow the ground,
and bread of the increase of the ground, and it shall be fat and plenteous;
in that day shall your cattle feed in large pastures.

**30:24** The oxen likewise and the young donkeys that till the ground
shall eat savory provender,
which has been winnowed with the shovel and with the fan.

**30:25** And there shall be upon every lofty mountain, and upon every high hill,
streams and watercourses,
in the day of the great slaughter, when the towers fall.

**30:26** Moreover the light of the moon shall be as the light of the sun,
and the light of the sun shall be sevenfold, as the light of seven days,
in the day that YHWH binds up the breach of his people,
and heals the stroke of their wound.

---

## YHWH's Judgment on Assyria (30:27-33)

**30:27** Behold, the name of YHWH comes from far,
burning with his anger, and in thick rising smoke;
his lips are full of indignation,
and his tongue is as a devouring fire;

**30:28** And his breath is as an overflowing stream,
that reaches even unto the neck,
to sift the nations with the sieve of destruction;
and a bridle that causes to err shall be in the jaws of the peoples.

**30:29** You shall have a song as in the night when a feast is hallowed;
and gladness of heart, as when one goes with the pipe
to come unto the mountain of YHWH, to the Rock of Israel.

**30:30** And YHWH will cause his glorious voice to be heard,
and will show the lighting down of his arm,
with furious anger, and the flame of a devouring fire,
with a blast, and tempest, and hailstones.

**30:31** For through the voice of YHWH shall Assyria be dismayed,
the rod that smote them.

**30:32** And in every place where the appointed staff shall pass,
which YHWH shall lay upon him,
it shall be with tabrets and harps;
and in battles of wielding will he fight with them.

**30:33** For a hearth is ordered of old;
yea, for the king it is prepared,
deep and large;
the pile thereof is fire and much wood;
the breath of YHWH, like a stream of brimstone, kindles it.

---

## Synthesis Notes

**Key Restorations:**

**Egypt Alliance Condemned (30:1-7):**
"Woe to the rebellious children."

*Hoy banim sorerim*—rebellious children.

"That take counsel, but not of me."

*La'asot etzah ve-lo minni*—counsel without YHWH.

"That form projects, but not of my spirit."

*Ve-linssokh massekha ve-lo ruchi*—plans without Spirit.

"That they may add sin to sin."

*Lema'an sefot chata'at al-chata'at*—sin on sin.

"To take refuge in the stronghold of Pharaoh."

*La'oz be-ma'oz Par'oh*—Pharaoh's refuge.

"To take shelter in the shadow of Egypt."

*Ve-lachsot be-tzel Mitzrayim*—Egypt's shadow.

"Egypt helps in vain, and to no purpose."

*U-Mitzrayim hevel va-riq ya'azoru*—vain help.

"'Rahab that sits still.'"

*Rahav hem shavet*—idle Rahab (chaos monster name for Egypt).

**Written Testimony (30:8-11):**
"Now go, write it before them on a tablet."

*Attah bo ketov-ah al-lu'ach ittam*—tablet writing.

"Inscribe it in a book."

*Ve-al-sefer chuqqah*—book inscription.

"For the time to come forever and ever."

*Le-yom acharon la'ad ad-olam*—future testimony.

"It is a rebellious people, lying children."

*Ki am meri hu banim kechashim*—rebels and liars.

"Children that refuse to hear the teaching of YHWH."

*Banim lo-avu shemo'a torat YHWH*—refuse Torah.

**The Key Verse (30:10):**
"'See not'... 'Prophesy not unto us right things.'"

*Lo tirchu... al-tinave'u lanu nekochot*—don't see or speak truth.

"'Speak unto us smooth things, prophesy delusions.'"

*Dabberu-lanu chalaqot chazu mahatallot*—smooth things and delusions.

"'Cause the Holy One of Israel to cease from before us.'"

*Hashbitu mi-panenu et-Qedosh Yisra'el*—remove Holy One.

**Wall Breaking (30:12-14):**
"This iniquity shall be to you as a breach ready to fall."

*Yihyeh lakhem he-avon ha-zeh ke-feretz nofel*—breach in wall.

"Swelling out in a high wall."

*Niveh be-chomah nisgavah*—bulging high wall.

"Whose breaking comes suddenly at an instant."

*Asher-pitom le-feta yavo shivrah*—sudden collapse.

"As the breaking of a potter's vessel."

*Ki-shever nevel yotzrim*—potter's vessel shattered.

**The Key Verse (30:15):**
"In sitting still and rest shall you be saved."

*Be-shuvah va-nachat tivvashe'un*—stillness saves.

"In quietness and in confidence shall be your strength."

*Be-hashqet u-ve-vitchah tihyeh gevuratkhem*—quiet confidence = strength.

"And you would not."

*Ve-lo avitem*—refused.

**Flight Reversed (30:16-17):**
"'We will flee upon horses'; therefore shall you flee."

*Al-sus nanus al-ken tenusun*—flee because fleeing.

"'We will ride upon the swift'; therefore shall they that pursue you be swift."

*Ve-al-qal nirkav al-ken yiqallu rodefekhem*—pursuers faster.

"One thousand shall flee at the rebuke of one."

*Elef echad mippenei ga'arat echad*—one routs thousand.

**The Key Verses (30:18-21):**
"YHWH wait, that he may be gracious unto you."

*Lakhen yechakkeh YHWH lachonankhem*—YHWH waits to be gracious.

"Happy are all they that wait for him."

*Ashrei kol-chokei lo*—blessed waiters.

"You shall weep no more."

*Bakho lo-tivkeh*—no more weeping.

"He will surely be gracious unto you at the voice of your cry."

*Chanon yachonekha le-qol za'aqekha*—gracious at cry.

"Your Teacher not be hidden any more."

*Ve-lo-yikkanef od morekha*—Teacher visible.

"Your eyes shall see your Teacher."

*Ve-hayu einekha ro'ot et-morekha*—see the Teacher.

**The Key Verse (30:21):**
"Your ears shall hear a word behind you."

*Ve-oznekha tishma'nah davar me-acharekha*—voice behind.

"'This is the way, walk in it.'"

*Zeh ha-derekh lekhu vo*—the way.

"When you turn to the right hand, and when you turn to the left."

*Ki ta'aminu ve-khi tasmilu*—right or left guidance.

**Abundant Blessing (30:23-26):**
"He will give the rain for your seed."

*Ve-natan matar zar'akha*—rain given.

"The light of the moon shall be as the light of the sun."

*Ve-hayah or-ha-levanah ke-or ha-chammah*—moon bright as sun.

"The light of the sun shall be sevenfold."

*Ve-or ha-chammah yihyeh shiv'atayim*—sun sevenfold.

"In the day that YHWH binds up the breach of his people."

*Be-yom chabosh YHWH et-shever ammo*—YHWH heals breach.

**YHWH Against Assyria (30:27-33):**
"The name of YHWH comes from far, burning with his anger."

*Hinneh shem-YHWH ba mi-merchaq bo'er appo*—YHWH comes burning.

"His tongue is as a devouring fire."

*U-leshono ke-esh okhelet*—fire-tongue.

"Through the voice of YHWH shall Assyria be dismayed."

*Ki-mi-qol YHWH yechat Ashshur*—Assyria dismayed.

"A hearth is ordered of old."

*Ki-arukh me-etmol tofteh*—Topheth prepared.

"The breath of YHWH, like a stream of brimstone, kindles it."

*Nishmat YHWH ke-nachal gofrit bo'arah bah*—YHWH's breath kindles.

**Archetypal Layer:** Isaiah 30 contains **"in quietness and confidence shall be your strength" (30:15)**, **"this is the way, walk in it" (30:21)**, and **YHWH waiting to be gracious (30:18)**.

**Ethical Inversion Applied:**
- "Woe to the rebellious children"—rebellion
- "That take counsel, but not of me"—wrong counsel
- "To take refuge in the stronghold of Pharaoh"—Egypt alliance
- "'Rahab that sits still'"—Egypt = idle chaos
- "Write it before them on a tablet"—permanent record
- "'Speak unto us smooth things, prophesy delusions'"—wanting lies
- "'Cause the Holy One of Israel to cease from before us'"—reject Holy One
- "This iniquity shall be to you as a breach ready to fall"—sudden collapse
- "In sitting still and rest shall you be saved"—stillness saves
- "In quietness and in confidence shall be your strength"—quiet strength
- "And you would not"—refusal
- "YHWH wait, that he may be gracious unto you"—waiting grace
- "Happy are all they that wait for him"—blessed waiting
- "Your eyes shall see your Teacher"—visible Teacher
- "'This is the way, walk in it'"—the way
- "The light of the sun shall be sevenfold"—enhanced light
- "In the day that YHWH binds up the breach of his people"—healing

**Modern Equivalent:** Isaiah 30:15's "in quietness and in confidence shall be your strength" is a classic trust text. The "Teacher" visible (30:20) and "this is the way" (30:21) anticipate Jesus as the Way. YHWH waiting to be gracious (30:18) shows divine patience.

# Isaiah 47: The Fall of Babylon

*From the Hebrew: רְדִי וּשְׁבִי עַל־עָפָר (Redi U-Shevi Al-Afar) — Come Down and Sit in the Dust*

---

## Babylon Humiliated (47:1-7)

**47:1** Come down, and sit in the dust, O virgin daughter of Babylon; sit on the ground without a throne, O daughter of the Chaldeans; for you shall no more be called tender and delicate.

**47:2** Take the millstones, and grind meal; remove your veil, strip off the train, uncover the leg, pass through the rivers.

**47:3** Your nakedness shall be uncovered, yea, your shame shall be seen; I will take vengeance, and will let no man intercede.

**47:4** Our Redeemer, YHWH of hosts is his name, the Holy One of Israel.

**47:5** Sit silent, and get into darkness, O daughter of the Chaldeans; for you shall no more be called the mistress of kingdoms.

**47:6** I was wroth with my people, I profaned my inheritance, and gave them into your hand; you showed them no mercy; upon the aged you made your yoke exceeding heavy.

**47:7** And you said: "I shall be a mistress forever"; so that you did not lay these things to your heart, neither did remember the end thereof.

---

## Babylon's Pride and Fall (47:8-15)

**47:8** Now therefore hear this, you that are given to pleasures, that sit securely, that say in your heart: "I am, and there is none else beside me; I shall not sit as a widow, neither shall I know the loss of children";

**47:9** But these two things shall come to you in a moment in one day, the loss of children, and widowhood; in their full measure shall they come upon you, for the multitude of your sorceries, and the great abundance of your enchantments.

**47:10** And you have trusted in your wickedness, you have said: "None sees me"; your wisdom and your knowledge, it has perverted you; and you have said in your heart: "I am, and there is none else beside me."

**47:11** Therefore shall evil come upon you; you shall not know how to charm it away; and calamity shall fall upon you; you shall not be able to put it away; and ruin shall come upon you suddenly, before you know.

**47:12** Stand now with your enchantments, and with the multitude of your sorceries, wherein you have laboured from your youth; if so be you shall be able to profit, if so be you may prevail.

**47:13** You are wearied in the multitude of your counsels; let now the astrologers, the stargazers, the monthly prognosticators, stand up, and save you from the things that shall come upon you.

**47:14** Behold, they shall be as stubble; the fire shall burn them; they shall not deliver themselves from the power of the flame; it shall not be a coal to warm at, nor a fire to sit before.

**47:15** Thus shall they be unto you with whom you have laboured; they that have trafficked with you from your youth shall wander every one to his quarter; there shall be none to save you.

---

## Synthesis Notes

**Key Restorations:**

**Babylon Humiliated (47:1-3):**
"Come down, and sit in the dust, O virgin daughter of Babylon."

*Redi u-shevi al-afar betulat bat-Bavel*—virgin Babylon in dust.

"Sit on the ground without a throne."

*Shevi la-aretz ein-kisse bat-Kasdim*—throneless.

"You shall no more be called tender and delicate."

*Ki lo tosifi yiqre'u-lakh rakkah va-anugah*—no longer pampered.

"Take the millstones, and grind meal."

*Qechi rechayim ve-tachani qamach*—slave work.

"Remove your veil."

*Galli tzammatek*—veil removed.

"Strip off the train, uncover the leg."

*Chasfi-shovel galli-shoq*—stripped.

"Pass through the rivers."

*Iveri neharot*—crossing rivers (exile).

"Your nakedness shall be uncovered."

*Tiggal ervatekh*—nakedness exposed.

"Yea, your shame shall be seen."

*Gam tere'eh cherppatekh*—shame seen.

"I will take vengeance, and will let no man intercede."

*Naqam eqqach ve-lo efga adam*—vengeance without intercession.

**The Key Verse (47:4):**
"Our Redeemer, YHWH of hosts is his name."

*Go'alenu YHWH Tzeva'ot shemo*—Redeemer identified.

"The Holy One of Israel."

*Qedosh Yisra'el*—Holy One.

**Mistress No More (47:5-7):**
"Sit silent, and get into darkness."

*Shevi dumam u-vo'i va-choshekh*—silent darkness.

"You shall no more be called the mistress of kingdoms."

*Ki lo tosifi yiqre'u-lakh geveret mamlakhot*—no longer mistress.

"I was wroth with my people."

*Qatzafti al-ammi*—angry with people.

"I profaned my inheritance."

*Chillalti nachalati*—profaned inheritance.

"Gave them into your hand."

*Va-ettenem be-yadekh*—given to Babylon.

"You showed them no mercy."

*Lo-samtt lahem rachamim*—no mercy shown.

"Upon the aged you made your yoke exceeding heavy."

*Al-zaqen hikhbadtt ullekh me'od*—heavy yoke on aged.

**The Key Verse (47:7):**
"'I shall be a mistress forever.'"

*Le-olam ehyeh geverett*—eternal mistress claim.

"You did not lay these things to your heart."

*Lo-samtt elleh al-libbek*—didn't consider.

"Neither did remember the end thereof."

*Lo zakhart acharitta*—didn't remember end.

**Pride Exposed (47:8-11):**
"You that are given to pleasures."

*Adinah*—pleasure-seeking.

"That sit securely."

*Ha-yoshevet la-vetach*—secure sitting.

**The Key Verse (47:8):**
"'I am, and there is none else beside me.'"

*Ani ve-afsi od*—"I am, and none beside" (parodying YHWH's claim).

"'I shall not sit as a widow.'"

*Lo eshev almanah*—never widowed.

"'Neither shall I know the loss of children.'"

*Ve-lo eda shekol*—no child loss.

**The Key Verse (47:9):**
"These two things shall come to you in a moment in one day."

*Ve-tavona lakh shetei-elleh rega be-yom echad*—sudden loss.

"The loss of children, and widowhood."

*Shekol ve-almon*—childlessness and widowhood.

"In their full measure shall they come upon you."

*Ke-tummam ba'u alayikh*—full measure.

"For the multitude of your sorceries."

*Be-rov keshafayikh*—many sorceries.

"The great abundance of your enchantments."

*Be-atzumat chabarayikh me'od*—many enchantments.

**The Key Verse (47:10):**
"You have trusted in your wickedness."

*Va-tivtechi be-ra'atek*—trusting evil.

"You have said: 'None sees me.'"

*Amart ein ro'ani*—claiming invisibility.

"Your wisdom and your knowledge, it has perverted you."

*Chokhmtek ve-da'attek hi shovattek*—wisdom perverts.

"'I am, and there is none else beside me.'"

*Ani ve-afsi od*—repeated divine parody.

**Sudden Destruction (47:11):**
"Evil come upon you; you shall not know how to charm it away."

*U-va'ah alayikh ra'ah lo tede'i shachrah*—uncharmable evil.

"Calamity shall fall upon you; you shall not be able to put it away."

*Ve-tippol alayikh hovah lo tukheli kaprerah*—unstoppable calamity.

"Ruin shall come upon you suddenly, before you know."

*Ve-tavo alayikh pitom sho'ah lo teda'i*—sudden ruin.

**Astrologers Useless (47:12-15):**
"Stand now with your enchantments."

*Imdi-na ba-chabarayikh*—stand with enchantments.

"With the multitude of your sorceries."

*U-ve-rov keshafayikh*—many sorceries.

"Wherein you have laboured from your youth."

*Asher yagaat me-ne'urayikh*—lifelong labor.

"If so be you shall be able to profit."

*Ulai tukheli ho'il*—maybe profit?

"If so be you may prevail."

*Ulai ta'arotzi*—maybe prevail?

**The Key Verse (47:13):**
"Let now the astrologers, the stargazers, the monthly prognosticators, stand up."

*Ya'amdu-na ve-yoshi'ukh hoverei shamayim ha-chozim ba-kokhavim modi'im le-chadashim*—astrologers summoned.

"And save you from the things that shall come upon you."

*Me-asher yavo'u alayikh*—save from coming things.

**The Key Verse (47:14):**
"Behold, they shall be as stubble."

*Hinneh hayu khe-qash*—stubble.

"The fire shall burn them."

*Esh serafatam*—fire burns.

"They shall not deliver themselves from the power of the flame."

*Lo-yatzilu et-nafsham mi-yad lehavah*—can't self-deliver.

"It shall not be a coal to warm at."

*Ein-gachelet le-chamam*—no warming coal.

"Nor a fire to sit before."

*Ur la-shevet negdo*—no fire to sit by.

**Complete Abandonment (47:15):**
"They that have trafficked with you from your youth shall wander every one to his quarter."

*Socharyikh mi-ne'urayikh ish le-evro ta'u*—traders scatter.

"There shall be none to save you."

*Ein moshi'ekh*—no savior.

**Archetypal Layer:** Isaiah 47 is a **taunt song over Babylon**. Babylon claims YHWH's title ("I am, and there is none else"—47:8, 10), trusts sorcery, but faces sudden ruin.

**Ethical Inversion Applied:**
- "Come down, and sit in the dust"—humiliation
- "Sit on the ground without a throne"—throneless
- "You shall no more be called tender and delicate"—no longer pampered
- "Take the millstones, and grind meal"—slave labor
- "Your nakedness shall be uncovered"—shame exposed
- "I will take vengeance"—YHWH's vengeance
- "Our Redeemer, YHWH of hosts is his name"—Redeemer
- "You shall no more be called the mistress of kingdoms"—no longer mistress
- "I was wroth with my people"—divine anger
- "You showed them no mercy"—Babylon's cruelty
- "'I shall be a mistress forever'"—Babylon's pride
- "'I am, and there is none else beside me'"—divine parody
- "'I shall not sit as a widow'"—false security
- "These two things shall come to you in a moment in one day"—sudden loss
- "For the multitude of your sorceries"—sorcery judged
- "Your wisdom and your knowledge, it has perverted you"—wisdom perverts
- "Ruin shall come upon you suddenly"—sudden ruin
- "Let now the astrologers... stand up, and save you"—astrologers summoned
- "Behold, they shall be as stubble"—astrologers burn
- "There shall be none to save you"—no savior

**Modern Equivalent:** Isaiah 47's taunt of Babylon influences Revelation 17-18. Babylon's claim "I am, and there is none else" (47:8, 10) parodies YHWH's exclusive claim—the height of arrogance. The failure of astrology and sorcery (47:12-14) mocks Babylonian religion.

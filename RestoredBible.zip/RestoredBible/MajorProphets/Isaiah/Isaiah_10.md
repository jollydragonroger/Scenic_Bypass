# Isaiah 10: Assyria the Rod and the Remnant

*From the Hebrew: הוֹי הַחֹקְקִים חִקְקֵי־אָוֶן (Hoy Ha-Choqeqim Chiqqei-Aven) — Woe unto Them That Decree Unrighteous Decrees*

---

## Woe to Unjust Lawmakers (10:1-4)

**10:1** Woe unto them that decree unrighteous decrees,
and to the writers that write perverseness;

**10:2** To turn aside the needy from judgment,
and to take away the right of the poor of my people,
that widows may be their spoil,
and that they may make the fatherless their prey!

**10:3** And what will you do in the day of visitation,
and in the desolation which shall come from far?
To whom will you flee for help?
And where will you leave your glory?

**10:4** They can do nothing except crouch under the captives,
and fall under the slain.
For all this his anger is not turned away,
but his hand is stretched out still.

---

## Assyria: The Rod of YHWH's Anger (10:5-19)

**10:5** O Assyrian, the rod of my anger,
in whose hand as a staff is my indignation!

**10:6** I send him against a profane nation,
and against the people of my wrath do I give him a charge,
to take the spoil, and to take the prey,
and to tread them down like the mire of the streets.

**10:7** However he means not so, neither does his heart think so;
but it is in his heart to destroy,
and to cut off nations not a few.

**10:8** For he says: "Are not my princes all of them kings?

**10:9** "Is not Calno as Carchemish? Is not Hamath as Arpad? Is not Samaria as Damascus?

**10:10** "As my hand has reached the kingdoms of the idols,
whose graven images did exceed them of Jerusalem and of Samaria;

**10:11** "Shall I not, as I have done unto Samaria and her idols,
so do to Jerusalem and her idols?"

**10:12** Wherefore it shall come to pass, that when the Lord has performed his whole work upon mount Zion and on Jerusalem, I will punish the fruit of the arrogant heart of the king of Assyria, and the glory of his haughty looks.

**10:13** For he has said: "By the strength of my hand I have done it,
and by my wisdom, for I am prudent;
in that I have removed the bounds of the peoples,
and have robbed their treasures,
and have brought down as a mighty one them that sit on thrones;

**10:14** "And my hand has found as a nest the riches of the peoples;
and as one gathers eggs that are forsaken,
have I gathered all the earth;
and there was none that moved the wing, or that opened the mouth, or chirped."

**10:15** Shall the axe boast itself against him that hews therewith?
Shall the saw magnify itself against him that wields it?
As if a rod should wield them that lift it up,
or as if a staff should lift up him that is not wood.

**10:16** Therefore shall the Lord, YHWH of hosts,
send among his fat ones leanness;
and under his glory there shall be kindled a burning like the burning of fire.

**10:17** And the light of Israel shall be for a fire,
and his Holy One for a flame;
and it shall burn and devour his thorns and his briers in one day.

**10:18** And the glory of his forest and of his fruitful field, he will consume both soul and body; and it shall be as when a sick man wastes away.

**10:19** And the remnant of the trees of his forest shall be few, that a child may write them.

---

## The Remnant of Israel (10:20-34)

**10:20** And it shall come to pass in that day, that the remnant of Israel, and they that are escaped of the house of Jacob, shall no more again stay upon him that smote them; but shall stay upon YHWH, the Holy One of Israel, in truth.

**10:21** A remnant shall return, even the remnant of Jacob, unto God the Mighty.

**10:22** For though your people, O Israel, be as the sand of the sea, only a remnant of them shall return; an extermination is determined, overflowing with righteousness.

**10:23** For an extermination wholly determined shall the Lord, YHWH of hosts, make in the midst of all the earth.

**10:24** Therefore thus says the Lord, YHWH of hosts: "O my people that dwells in Zion, be not afraid of Assyria, though he smite you with the rod, and lift up his staff against you, after the manner of Egypt.

**10:25** "For yet a very little while, and the indignation shall be accomplished, and my anger shall be to their destruction."

**10:26** And YHWH of hosts shall stir up against him a scourge, as in the slaughter of Midian at the rock of Oreb; and his rod shall be over the sea, and he shall lift it up after the manner of Egypt.

**10:27** And it shall come to pass in that day, that his burden shall depart from off your shoulder, and his yoke from off your neck, and the yoke shall be destroyed because of fatness.

**10:28** He is come to Aiath, he is passed through Migron; at Michmash he lays up his baggage;

**10:29** They are gone over the pass; they have taken up their lodging at Geba; Ramah trembles; Gibeah of Saul is fled.

**10:30** Cry aloud with your voice, O daughter of Gallim! Hearken, O Laish! O poor Anathoth!

**10:31** Madmenah is in mad flight; the inhabitants of Gebim flee to cover.

**10:32** This very day shall he halt at Nob, shaking his hand at the mount of the daughter of Zion, the hill of Jerusalem.

**10:33** Behold, the Lord, YHWH of hosts, shall lop the boughs with terror; and the high ones of stature shall be hewn down, and the lofty shall be brought low.

**10:34** And he shall cut down the thickets of the forest with iron, and Lebanon shall fall by a mighty one.

---

## Synthesis Notes

**Key Restorations:**

**Seventh Woe (10:1-4):**
"Woe unto them that decree unrighteous decrees."

*Hoy ha-choqeqim chiqqei-aven*—unjust legislation.

"To the writers that write perverseness."

*U-mekhattvim amal kittavu*—perverse writing.

"To turn aside the needy from judgment."

*Le-hattot mi-din dallim*—denying justice.

"To take away the right of the poor of my people."

*Ve-ligzol mishpat aniyyei ammi*—robbing poor.

"That widows may be their spoil."

*Lihyot almanot shelalam*—widows as spoil.

"That they may make the fatherless their prey."

*Ve-yetomim yavozzu*—orphans as prey.

"His hand is stretched out still."

*Ve-od yado netuyah*—refrain conclusion.

**Assyria as Instrument (10:5-11):**
"O Assyrian, the rod of my anger."

*Hoy Ashshur shevet appi*—Assyria = anger rod.

"In whose hand as a staff is my indignation."

*U-matteh hu ve-yadam za'ami*—indignation staff.

"I send him against a profane nation."

*Be-goy chanef ashallechenu*—sent against profane.

"To take the spoil, and to take the prey."

*Lishlol shalal ve-lavoz baz*—plunder mission.

"However he means not so."

*Ve-hu lo-khen yedammeh*—Assyria's intent differs.

"It is in his heart to destroy."

*Ki le-hashmid bi-lvavo*—destruction in heart.

"To cut off nations not a few."

*Ve-le-hakhrit goyim lo me'at*—many nations.

**Assyrian Arrogance (10:8-14):**
"'Are not my princes all of them kings?'"

*Halo sarai yachdav melakhim*—boasting.

"'By the strength of my hand I have done it.'"

*Be-kho'ach yadi asiti*—hand strength.

"'By my wisdom, for I am prudent.'"

*U-ve-chokhmati ki nevunoti*—wisdom claim.

"'My hand has found as a nest the riches of the peoples.'"

*Va-timtza kha-qen yadi le-cheil ha-ammim*—nest metaphor.

"'As one gathers eggs that are forsaken.'"

*Ve-khe'esof beitzim azuvot*—egg gathering.

"'There was none that moved the wing, or that opened the mouth.'"

*Ve-lo hayah noded kanaf u-fotze peh u-metzaftzef*—no resistance.

**The Key Verse (10:15):**
"Shall the axe boast itself against him that hews therewith?"

*Ha-yitpa'er ha-garzen al ha-chotev bo*—axe boasting.

"Shall the saw magnify itself against him that wields it?"

*Im-yitgaddel ha-massor al meniffo*—saw magnifying.

"As if a rod should wield them that lift it up."

*Ke-hanif shevet et-merimav*—rod wielding lifter.

"As if a staff should lift up him that is not wood."

*Ke-harim matteh lo-etz*—staff lifting non-wood.

**Assyria's Judgment (10:16-19):**
"The light of Israel shall be for a fire."

*Ve-hayah or-Yisra'el le-esh*—Israel's light = fire.

"His Holy One for a flame."

*U-qedosho le-lehavah*—Holy One = flame.

"It shall burn and devour his thorns and his briers in one day."

*Ve-va'arah ve-akhelah shito u-shemiro be-yom echad*—one-day destruction.

"The remnant of the trees of his forest shall be few."

*U-she'ar etz ya'aro mispar yihyu*—few trees remain.

"That a child may write them."

*Ve-na'ar yikhtevem*—child can count.

**The Key Verses (10:20-22):**
"The remnant of Israel... shall stay upon YHWH."

*She'ar Yisra'el... ve-nish'anu al-YHWH*—true reliance.

"The Holy One of Israel, in truth."

*Qedosh Yisra'el be-emet*—truthful reliance.

"A remnant shall return."

*She'ar yashuv*—Shear-jashub fulfilled.

"The remnant of Jacob, unto God the Mighty."

*She'ar Ya'aqov el El Gibbor*—return to Mighty God.

"Though your people, O Israel, be as the sand of the sea."

*Ki im-yihyeh ammekha Yisra'el ke-chol ha-yam*—many people.

"Only a remnant of them shall return."

*She'ar yashuv bo*—remnant returns. Romans 9:27 quotes this.

**Assyrian March (10:28-32):**
Listing cities as Assyria approaches Jerusalem—Aiath, Migron, Michmash, Geba, Ramah, Gibeah, Gallim, Laish, Anathoth, Madmenah, Gebim, Nob.

"This very day shall he halt at Nob."

*Od ha-yom be-Nov la'amod*—halts at Nob.

"Shaking his hand at the mount of the daughter of Zion."

*Yenofef yado har bat-Tziyyon*—threatening Jerusalem.

**YHWH's Counter (10:33-34):**
"The Lord, YHWH of hosts, shall lop the boughs with terror."

*Ha-Adon YHWH Tzeva'ot mesa'ef pu'rah be-ma'aratzah*—YHWH lops.

"The high ones of stature shall be hewn down."

*Ve-ramei ha-qomah gedui'im*—tall cut down.

"Lebanon shall fall by a mighty one."

*Ve-ha-Levanon be-addir yippol*—Lebanon falls.

**Archetypal Layer:** Isaiah 10 shows **Assyria as YHWH's instrument (10:5-6)** who overreaches (10:7-14), is judged for arrogance (10:15-19), while **the remnant returns (10:20-22)**.

**Ethical Inversion Applied:**
- "Woe unto them that decree unrighteous decrees"—unjust laws
- "To turn aside the needy from judgment"—denied justice
- "O Assyrian, the rod of my anger"—Assyria as tool
- "I send him against a profane nation"—divine deployment
- "However he means not so"—Assyria's different intent
- "It is in his heart to destroy"—destruction intent
- "'By the strength of my hand I have done it'"—self-credit
- "Shall the axe boast itself against him that hews therewith?"—tool/wielder
- "The light of Israel shall be for a fire"—Israel consumes Assyria
- "The remnant of Israel... shall stay upon YHWH"—true reliance
- "A remnant shall return"—Shear-jashub
- "Though your people... be as the sand of the sea, only a remnant shall return"—Romans 9:27

**Modern Equivalent:** Isaiah 10's theology of nations as divine instruments (10:5-15) is foundational for understanding sovereignty. Assyria doesn't know it serves YHWH. The axe/wielder metaphor (10:15) shows tools can't claim credit. The remnant theology (10:20-22) is quoted in Romans 9:27.

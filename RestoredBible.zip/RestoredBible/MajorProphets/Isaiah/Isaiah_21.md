# Isaiah 21: The Fall of Babylon and Oracles Against Arabia

*From the Hebrew: מַשָּׂא מִדְבַּר־יָם (Massa Midbar-Yam) — The Burden of the Wilderness of the Sea*

---

## The Fall of Babylon (21:1-10)

**21:1** The burden of the wilderness of the sea.
As whirlwinds in the South sweeping on,
it comes from the wilderness, from a terrible land.

**21:2** A grievous vision is declared unto me:
"The treacherous dealer deals treacherously,
and the spoiler spoils.
Go up, O Elam; besiege, O Media;
all the sighing thereof have I made to cease."

**21:3** Therefore are my loins filled with convulsion;
pangs have taken hold upon me, as the pangs of a woman in travail;
I am bent at the hearing of it;
I am affrighted at the seeing of it.

**21:4** My heart staggers, terror has overwhelmed me;
the twilight that I longed for has been turned for me into trembling.

**21:5** They prepare the table, they set the watch, they eat, they drink—
"Arise, you princes, anoint the shield."

**21:6** For thus has the Lord said unto me:
"Go, set a watchman; let him declare what he sees."

**21:7** And when he sees a troop, horsemen in pairs,
a troop of donkeys, a troop of camels,
he shall hearken diligently with much heed.

**21:8** And he cried as a lion: "Upon the watch-tower, O Lord, I stand continually in the daytime,
and I am set in my ward all the nights."

**21:9** And, behold, there comes a troop of men, horsemen in pairs.
And he spoke and said: "Fallen, fallen is Babylon;
and all the graven images of her gods are broken unto the ground."

**21:10** O you my threshing, and the son of my floor,
that which I have heard from YHWH of hosts, the God of Israel,
have I declared unto you.

---

## Oracle Against Dumah (21:11-12)

**21:11** The burden of Dumah.
One calls unto me out of Seir:
"Watchman, what of the night? Watchman, what of the night?"

**21:12** The watchman said:
"The morning comes, and also the night;
if you will inquire, inquire; come again."

---

## Oracle Against Arabia (21:13-17)

**21:13** The burden upon Arabia.
In the thickets in Arabia shall you lodge,
O caravans of Dedanites.

**21:14** Unto him that is thirsty bring water!
The inhabitants of the land of Tema meet the fugitive with his bread.

**21:15** For they fled away from the swords,
from the drawn sword, and from the bent bow,
and from the grievousness of war.

**21:16** For thus has the Lord said unto me: "Within a year, according to the years of a hireling, and all the glory of Kedar shall fail;

**21:17** "And the residue of the number of the archers, the mighty men of the children of Kedar, shall be diminished; for YHWH, the God of Israel, has spoken it."

---

## Synthesis Notes

**Key Restorations:**

**Title (21:1):**
"The burden of the wilderness of the sea."

*Massa midbar-yam*—Babylon (between Tigris and Euphrates).

"As whirlwinds in the South sweeping on."

*Ke-sufot ba-negev lachalof*—desert storm.

"It comes from the wilderness, from a terrible land."

*Mi-midbar ba me-eretz nora'ah*—terrible land.

**Vision's Impact (21:2-4):**
"A grievous vision is declared unto me."

*Chazut qashah huggad li*—harsh vision.

"The treacherous dealer deals treacherously."

*Ha-boged boged*—treachery.

"The spoiler spoils."

*Ve-ha-shoded shoded*—spoiling.

"Go up, O Elam; besiege, O Media."

*Ali Elam tzuri Maday*—Elam and Media attack (Persia).

"My loins filled with convulsion."

*Al-ken male'u motnai chalchalah*—convulsing loins.

"Pangs have taken hold upon me, as the pangs of a woman in travail."

*Tzirim achazuni ke-tzirei yoledah*—labor pangs.

"My heart staggers, terror has overwhelmed me."

*Na'avah levavi palatzut bi'atatni*—staggering heart.

"The twilight that I longed for has been turned for me into trembling."

*Et neshef chishqi sam li le-charadah*—twilight to trembling.

**Babylon's Feast (21:5):**
"They prepare the table, they set the watch, they eat, they drink."

*Arokh ha-shulchan tzafoh ha-tzafit akhol shato*—banquet (Daniel 5).

"'Arise, you princes, anoint the shield.'"

*Qumu ha-sarim mishchu magen*—sudden alarm.

**The Watchman (21:6-9):**
"Go, set a watchman; let him declare what he sees."

*Lekh ha'amed ha-metzappeh asher yir'eh yaggid*—set watchman.

"When he sees a troop, horsemen in pairs."

*Ve-ra'ah rekhev tzemed parashim*—paired horsemen.

"A troop of donkeys, a troop of camels."

*Rekhev chamor rekhev gamal*—donkey and camel trains.

"He shall hearken diligently with much heed."

*Ve-hiqshiv qeshev rav-qashev*—careful attention.

"He cried as a lion."

*Va-yiqra aryeh*—lion cry.

"'Upon the watch-tower, O Lord, I stand continually in the daytime.'"

*Al-mitzpeh Adonai anokhi omed tamid yomam*—constant watch.

**The Key Verse (21:9):**
"'Fallen, fallen is Babylon.'"

*Nafelah nafelah Bavel*—Babylon fallen (Revelation 14:8; 18:2).

"'All the graven images of her gods are broken unto the ground.'"

*Ve-khol-pesilei elohekha shibbar la-aretz*—idols smashed.

**Israel Addressed (21:10):**
"O you my threshing, and the son of my floor."

*Medushati u-ven-gorni*—threshed ones.

"That which I have heard from YHWH of hosts... have I declared unto you."

*Asher shama'ti me-et YHWH Tzeva'ot... higgadti lakhem*—declared.

**Dumah (21:11-12):**
"The burden of Dumah."

*Massa Dumah*—Dumah (silence/Edom).

"One calls unto me out of Seir."

*Elai qore mi-Se'ir*—calling from Seir.

"'Watchman, what of the night?'"

*Shomer mah-mi-llaylah*—night inquiry.

**The Key Verse (21:12):**
"'The morning comes, and also the night.'"

*Atah voqer ve-gam-laylah*—morning and night.

"'If you will inquire, inquire; come again.'"

*Im-tivayun ba'ayu shuvu etayu*—come back.

**Arabia (21:13-17):**
"The burden upon Arabia."

*Massa ba-Arav*—Arabia oracle.

"In the thickets in Arabia shall you lodge."

*Ba-ya'ar ba-Arav talinu*—lodge in thickets.

"O caravans of Dedanites."

*Orechot Dedanim*—Dedan caravans.

"Unto him that is thirsty bring water!"

*Liqrat tzame hetayu mayim*—water for thirsty.

"The inhabitants of the land of Tema meet the fugitive with his bread."

*Yoshevei eretz Tema be-lachmo qidemu noded*—Tema's bread.

"For they fled away from the swords."

*Ki-mippenei charavot nadedu*—fled from swords.

"Within a year... all the glory of Kedar shall fail."

*Be-od shanah ki-shenei sakhir ve-khalah kol-kevod Qedar*—Kedar's glory ends.

"The mighty men of the children of Kedar, shall be diminished."

*U-she'ar mispar qeshet gibborei venei-Qedar yim'atu*—archers diminished.

**Archetypal Layer:** Isaiah 21 contains **"Fallen, fallen is Babylon" (21:9)**—quoted in Revelation. The enigmatic Dumah oracle (21:11-12) and the Arabia oracle complete the section.

**Ethical Inversion Applied:**
- "The burden of the wilderness of the sea"—Babylon
- "Go up, O Elam; besiege, O Media"—Persian attack
- "My loins filled with convulsion"—prophet's agony
- "They prepare the table, they set the watch, they eat, they drink"—Belshazzar's feast
- "'Arise, you princes, anoint the shield'"—sudden alarm
- "Go, set a watchman; let him declare what he sees"—watchman appointed
- "'Upon the watch-tower... I stand continually'"—constant watch
- "'Fallen, fallen is Babylon'"—Revelation 14:8; 18:2
- "'All the graven images of her gods are broken'"—idols destroyed
- "'Watchman, what of the night?'"—night inquiry
- "'The morning comes, and also the night'"—ambiguous answer
- "'If you will inquire, inquire; come again'"—ongoing inquiry
- "Unto him that is thirsty bring water!"—hospitality
- "Within a year... all the glory of Kedar shall fail"—Kedar's end

**Modern Equivalent:** Isaiah 21:9's "Fallen, fallen is Babylon" is quoted verbatim in Revelation 14:8 and 18:2. The watchman imagery (21:6-8) provides a prophetic model. The enigmatic Dumah oracle's "morning and night" suggests ongoing tension.

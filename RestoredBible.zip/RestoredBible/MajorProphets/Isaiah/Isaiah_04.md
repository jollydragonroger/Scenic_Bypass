# Isaiah 4: The Branch of YHWH

*From the Hebrew: בַּיּוֹם הַהוּא יִהְיֶה צֶמַח יְהוָה (Ba-Yom Ha-Hu Yihyeh Tzemach YHWH) — In That Day Shall the Branch of YHWH Be*

---

## The Scarcity of Men (4:1)

**4:1** And seven women shall take hold of one man in that day, saying:
"We will eat our own bread, and wear our own apparel;
only let us be called by your name; take away our reproach."

---

## The Branch of YHWH (4:2-6)

**4:2** In that day shall the branch of YHWH be beautiful and glorious,
and the fruit of the land shall be the pride and glory
of them that are escaped of Israel.

**4:3** And it shall come to pass, that he that is left in Zion,
and he that remains in Jerusalem,
shall be called holy,
every one that is written unto life in Jerusalem;

**4:4** When the Lord shall have washed away the filth of the daughters of Zion,
and shall have purged the blood of Jerusalem from the midst thereof,
by the spirit of judgment, and by the spirit of burning.

**4:5** And YHWH will create over every dwelling-place of mount Zion,
and over her assemblies,
a cloud and smoke by day,
and the shining of a flaming fire by night;
for over all the glory shall be a canopy.

**4:6** And there shall be a pavilion for a shadow in the day-time from the heat,
and for a refuge and for a covert from storm and from rain.

---

## Synthesis Notes

**Key Restorations:**

**Scarcity of Men (4:1):**
"Seven women shall take hold of one man."

*Ve-hecheziku sheva nashim be-ish echad*—seven to one ratio.

"'We will eat our own bread, and wear our own apparel.'"

*Lachmenu nokhal u-simllatenu nilbash*—self-provision.

"'Only let us be called by your name.'"

*Raq yiqqare shimkha aleinu*—name only.

"'Take away our reproach.'"

*Esof cherppatenu*—remove reproach (of childlessness).

**The Key Verse (4:2):**
"In that day shall the branch of YHWH be beautiful and glorious."

*Ba-yom ha-hu yihyeh tzemach YHWH li-tzevi u-le-khavod*—Branch of YHWH.

"The fruit of the land shall be the pride and glory."

*U-feri ha-aretz le-ga'on u-le-tif'eret*—land's fruit glorified.

"Of them that are escaped of Israel."

*Li-feleitat Yisra'el*—remnant survivors.

**The Key Verse (4:3):**
"He that is left in Zion, and he that remains in Jerusalem."

*Ha-nish'ar be-Tziyyon ve-ha-notar bi-Yerushalayim*—remnant.

"Shall be called holy."

*Qadosh ye'ammer lo*—called holy.

"Every one that is written unto life in Jerusalem."

*Kol-ha-katuv la-chayyim bi-Yerushalayim*—book of life.

**Purging (4:4):**
"When the Lord shall have washed away the filth of the daughters of Zion."

*Im rachatz Adonai et tzo'at benot-Tziyyon*—filth washed.

"Shall have purged the blood of Jerusalem."

*Ve-et-demei Yerushalayim yaddiach mi-qirbah*—blood purged.

"By the spirit of judgment."

*Be-ruach mishpat*—judgment spirit.

"By the spirit of burning."

*U-ve-ruach ba'er*—burning spirit.

**Divine Canopy (4:5-6):**
"YHWH will create over every dwelling-place of mount Zion."

*U-vara YHWH al kol-mekhon har-Tziyyon*—YHWH creates.

"A cloud and smoke by day."

*Anan yomam ve-ashan*—daytime cloud (Exodus echo).

"The shining of a flaming fire by night."

*Ve-nogah esh lehavah laylah*—nighttime fire.

"For over all the glory shall be a canopy."

*Ki al-kol-kavod chuppah*—glory canopy.

"A pavilion for a shadow in the day-time from the heat."

*Ve-sukkah tihyeh le-tzel-yomam me-chorev*—shade from heat.

"A refuge and for a covert from storm and from rain."

*U-le-machseh u-le-mistor mi-zerem u-mi-matar*—storm refuge.

**Archetypal Layer:** Isaiah 4 introduces **the Branch of YHWH (Tzemach YHWH)**—a messianic title. The remnant is purified by judgment and burning, then protected by divine canopy (Exodus pillar imagery).

**Ethical Inversion Applied:**
- "Seven women shall take hold of one man"—war's aftermath
- "'Take away our reproach'"—childlessness reproach
- "The branch of YHWH be beautiful and glorious"—messianic branch
- "The fruit of the land shall be the pride and glory"—agricultural blessing
- "Them that are escaped of Israel"—remnant
- "He that is left in Zion... shall be called holy"—holy survivors
- "Every one that is written unto life in Jerusalem"—book of life
- "Washed away the filth of the daughters of Zion"—cleansing
- "Purged the blood of Jerusalem"—blood removed
- "By the spirit of judgment"—judgment spirit
- "By the spirit of burning"—purifying fire
- "A cloud and smoke by day"—Exodus pillar
- "The shining of a flaming fire by night"—night fire
- "Over all the glory shall be a canopy"—glory-canopy
- "A pavilion for a shadow in the day-time"—shade
- "A refuge and for a covert from storm"—storm shelter

**Modern Equivalent:** Isaiah 4's "Branch of YHWH" (*Tzemach YHWH*) is the first of several messianic titles in Isaiah. The book of life (4:3), judgment/burning purification (4:4), and glory-canopy (4:5) show salvation through purification.

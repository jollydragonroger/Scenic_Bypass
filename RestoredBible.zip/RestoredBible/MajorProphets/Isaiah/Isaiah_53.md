# Isaiah 53: The Suffering Servant

*From the Hebrew: מִי הֶאֱמִין לִשְׁמֻעָתֵנוּ (Mi He'emin Li-Shemu'atenu) — Who Has Believed Our Report?*

---

## The Despised Servant (53:1-3)

**53:1** Who would have believed our report? And to whom has the arm of YHWH been revealed?

**53:2** For he grew up before him as a tender plant, and as a root out of a dry ground; he had no form nor comeliness, that we should look upon him, nor beauty that we should delight in him.

**53:3** He was despised, and forsaken of men, a man of pains, and acquainted with disease, and as one from whom men hide their face; he was despised, and we esteemed him not.

---

## The Servant Bears Our Sins (53:4-6)

**53:4** Surely our diseases he did bear, and our pains he carried; whereas we did esteem him stricken, smitten of God, and afflicted.

**53:5** But he was wounded because of our transgressions, he was crushed because of our iniquities; the chastisement of our peace was upon him, and with his stripes we were healed.

**53:6** All we like sheep did go astray, we turned every one to his own way; and YHWH has laid on him the iniquity of us all.

---

## The Silent Lamb (53:7-9)

**53:7** He was oppressed, though he humbled himself and opened not his mouth; as a lamb that is led to the slaughter, and as a sheep that before her shearers is dumb; yea, he opened not his mouth.

**53:8** By oppression and judgment he was taken away, and with his generation who did reason? For he was cut off out of the land of the living; for the transgression of my people to whom the stroke was due.

**53:9** And they made his grave with the wicked, and with the rich his tomb; although he had done no violence, neither was any deceit in his mouth.

---

## The Servant's Vindication (53:10-12)

**53:10** Yet it pleased YHWH to crush him by disease; if his soul would offer itself in restitution, he would see his seed, he would prolong his days, and the pleasure of YHWH would prosper in his hand.

**53:11** Of the travail of his soul he shall see, and shall be satisfied; by his knowledge shall my righteous servant justify the many, and their iniquities he shall bear.

**53:12** Therefore will I divide him a portion among the great, and he shall divide the spoil with the mighty; because he bared his soul unto death, and was numbered with the transgressors; yet he bore the sin of many, and made intercession for the transgressors.

---

## Synthesis Notes

**Key Restorations:**

**The Key Verse (53:1):**
"Who would have believed our report?"

*Mi he'emin li-shemu'atenu*—who believed? John 12:38; Romans 10:16 quote this.

"To whom has the arm of YHWH been revealed?"

*Ve-zero'a YHWH al-mi nigllatah*—arm revealed to whom?

**The Key Verses (53:2-3):**
"He grew up before him as a tender plant."

*Va-ya'al ka-yoneq lefanav*—tender shoot.

"As a root out of a dry ground."

*Ve-kha-shoresh me-eretz tziyyah*—root from dry ground.

"He had no form nor comeliness."

*Lo-to'ar lo ve-lo hadar*—no form or majesty.

"That we should look upon him."

*Ve-nir'ehu*—we see him.

"Nor beauty that we should delight in him."

*Ve-lo-mar'eh ve-nechmedehu*—no beauty to desire.

"He was despised, and forsaken of men."

*Nivzeh va-chadal ishim*—despised, rejected.

"A man of pains, and acquainted with disease."

*Ish makh'ovot vi-yadu'a choli*—man of sorrows, familiar with suffering.

"As one from whom men hide their face."

*U-khe-master panim mimmenu*—face hidden from.

"He was despised, and we esteemed him not."

*Nivzeh ve-lo chashavnuhu*—despised, not esteemed.

**The Key Verses (53:4-6):**
"Surely our diseases he did bear."

*Akhen cholayenu hu nasa*—bore our diseases. Matthew 8:17 quotes this.

"Our pains he carried."

*U-makh'ovenu sevalanu*—carried our pains.

"We did esteem him stricken, smitten of God, and afflicted."

*Va-anachnu chashavnuhu nagua mukkeh Elohim u-me'unneh*—we thought God struck him.

**The Key Verse (53:5):**
"He was wounded because of our transgressions."

*Ve-hu mecholal mi-pesha'enu*—pierced for transgressions.

"He was crushed because of our iniquities."

*Medukka me-avonotenu*—crushed for iniquities.

"The chastisement of our peace was upon him."

*Musar shelomenu alav*—punishment brought us peace.

"With his stripes we were healed."

*U-va-chaburato nirpa-lanu*—by his wounds healed. 1 Peter 2:24 quotes this.

**The Key Verse (53:6):**
"All we like sheep did go astray."

*Kullanu ka-tzon ta'inu*—all strayed like sheep. 1 Peter 2:25 echoes this.

"We turned every one to his own way."

*Ish le-darko paninu*—each to own way.

"YHWH has laid on him the iniquity of us all."

*Va-YHWH hifgi'a bo et avon kullanu*—YHWH laid all iniquity on him.

**The Key Verses (53:7-9):**
"He was oppressed, though he humbled himself."

*Niggas ve-hu na'aneh*—oppressed, afflicted.

"Opened not his mouth."

*Ve-lo yiftach-piv*—silent.

"As a lamb that is led to the slaughter."

*Ka-seh la-tevach yuval*—lamb to slaughter. Acts 8:32 quotes this.

"As a sheep that before her shearers is dumb."

*U-khe-rachel lifnei gozezkha ne'elamah*—silent sheep.

"He opened not his mouth."

*Ve-lo yiftach piv*—repeated silence.

**The Key Verse (53:8):**
"By oppression and judgment he was taken away."

*Me-otzer u-mi-mishpat luqqach*—taken by oppression/judgment.

"With his generation who did reason?"

*Ve-et-doro mi yesocheach*—who considered?

"He was cut off out of the land of the living."

*Ki nigzar me-eretz chayyim*—cut off from living.

"For the transgression of my people to whom the stroke was due."

*Mi-pesha ammi nega lamo*—struck for my people's transgression.

**The Key Verse (53:9):**
"They made his grave with the wicked."

*Va-yitten et-resha'im qivro*—grave with wicked.

"With the rich his tomb."

*Ve-et-ashir be-motav*—tomb with rich.

"Although he had done no violence."

*Al lo-chamas asah*—no violence done.

"Neither was any deceit in his mouth."

*Ve-lo mirmah be-fiv*—no deceit. 1 Peter 2:22 quotes this.

**The Key Verses (53:10-12):**
"Yet it pleased YHWH to crush him by disease."

*Va-YHWH chafetz dakke'o hecheli*—YHWH pleased to crush.

"If his soul would offer itself in restitution."

*Im-tasim asham nafsho*—soul as guilt offering.

"He would see his seed."

*Yir'eh zera*—see offspring.

"He would prolong his days."

*Ya'arikh yamim*—prolong days.

"The pleasure of YHWH would prosper in his hand."

*Ve-chefetz YHWH be-yado yitzlach*—YHWH's will prospers.

**The Key Verse (53:11):**
"Of the travail of his soul he shall see."

*Me-amal nafsho yir'eh*—see soul's labor.

"Shall be satisfied."

*Yisba*—satisfied.

"By his knowledge shall my righteous servant justify the many."

*Be-da'to yatzdiq tzaddiq avdi la-rabbim*—righteous servant justifies many.

"Their iniquities he shall bear."

*Va-avonotam hu yisbol*—bears iniquities.

**The Key Verse (53:12):**
"Therefore will I divide him a portion among the great."

*Lakhen achalleq-lo va-rabbim*—portion among great.

"He shall divide the spoil with the mighty."

*Ve-et-atzumim yechalleq shalal*—divides spoil.

"Because he bared his soul unto death."

*Tachat asher he'erah la-mavet nafsho*—poured out unto death.

"Was numbered with the transgressors."

*Ve-et-posh'im nimnah*—numbered with transgressors. Luke 22:37 quotes this.

"He bore the sin of many."

*Ve-hu chet-rabbim nasa*—bore many's sin.

"Made intercession for the transgressors."

*Ve-la-posh'im yafgi'a*—interceded for transgressors.

**Archetypal Layer:** Isaiah 53 is **the Fourth Servant Song (52:13-53:12)**—the most detailed OT prophecy of substitutionary suffering. It is quoted extensively in the NT: Matthew 8:17 (53:4); John 12:38 (53:1); Acts 8:32-33 (53:7-8); Romans 10:16 (53:1); 1 Peter 2:22-25 (53:5-6, 9).

**Ethical Inversion Applied:**
- "Who would have believed our report?"—John 12:38; Romans 10:16
- "To whom has the arm of YHWH been revealed?"—arm revealed
- "He grew up before him as a tender plant"—humble origins
- "As a root out of a dry ground"—unexpected source
- "He had no form nor comeliness"—no beauty
- "He was despised, and forsaken of men"—rejected
- "A man of pains, and acquainted with disease"—man of sorrows
- "Surely our diseases he did bear"—Matthew 8:17
- "Our pains he carried"—vicarious suffering
- "We did esteem him stricken, smitten of God"—misunderstood
- "He was wounded because of our transgressions"—pierced for us
- "He was crushed because of our iniquities"—crushed for us
- "The chastisement of our peace was upon him"—punishment for peace
- "With his stripes we were healed"—1 Peter 2:24
- "All we like sheep did go astray"—1 Peter 2:25
- "YHWH has laid on him the iniquity of us all"—sin-bearing
- "As a lamb that is led to the slaughter"—Acts 8:32
- "He opened not his mouth"—silent suffering
- "He was cut off out of the land of the living"—death
- "They made his grave with the wicked, and with the rich his tomb"—burial
- "He had done no violence, neither was any deceit"—1 Peter 2:22
- "Yet it pleased YHWH to crush him"—divine purpose
- "If his soul would offer itself in restitution"—guilt offering
- "He would see his seed, he would prolong his days"—resurrection implied
- "By his knowledge shall my righteous servant justify the many"—justification
- "He bore the sin of many"—sin-bearing
- "Made intercession for the transgressors"—intercession

**Modern Equivalent:** Isaiah 53 is the OT's clearest prophecy of substitutionary atonement. The Ethiopian eunuch in Acts 8 was reading this when Philip explained it as Jesus. Every major theme—rejection, vicarious suffering, silence, death with wicked/rich, resurrection, justification—finds fulfillment in Christ's passion.

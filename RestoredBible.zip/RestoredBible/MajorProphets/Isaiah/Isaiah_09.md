# Isaiah 9: The Light in Darkness and the Child Born

*From the Hebrew: הָעָם הַהֹלְכִים בַּחֹשֶׁךְ (Ha-Am Ha-Holekhim Ba-Choshekh) — The People That Walk in Darkness*

---

## The Light Dawns (9:1-7)

**9:1** For is there no gloom for her that was in anguish? In the former time he brought into contempt the land of Zebulun and the land of Naphtali, but in the latter time he has made it glorious, by the way of the sea, beyond the Jordan, Galilee of the nations.

**9:2** The people that walked in darkness have seen a great light; they that dwelt in the land of the shadow of death, upon them has the light shined.

**9:3** You have multiplied the nation, you have increased their joy; they joy before you according to the joy in harvest, as men rejoice when they divide the spoil.

**9:4** For the yoke of his burden, and the staff of his shoulder, the rod of his oppressor, you have broken as in the day of Midian.

**9:5** For every boot stamped with fierceness, and every cloak rolled in blood, shall be for burning, for fuel of fire.

**9:6** For unto us a child is born, unto us a son is given; and the government shall be upon his shoulder; and his name shall be called Wonderful Counsellor, Mighty God, Everlasting Father, Prince of Peace.

**9:7** For the increase of his government and of peace there shall be no end, upon the throne of David, and upon his kingdom, to establish it, and to uphold it through justice and through righteousness from henceforth even forever. The zeal of YHWH of hosts shall perform this.

---

## The Outstretched Hand (9:8-21)

**9:8** The Lord has sent a word into Jacob, and it has lighted upon Israel.

**9:9** And all the people shall know, even Ephraim and the inhabitant of Samaria, that say in pride and in arrogance of heart:

**9:10** "The bricks are fallen, but we will build with hewn stones; the sycamores are cut down, but cedars will we put in their place."

**9:11** Therefore YHWH does set up on high the adversaries of Rezin against him, and stir up his enemies;

**9:12** The Arameans on the east, and the Philistines on the west; and they devour Israel with open mouth. For all this his anger is not turned away, but his hand is stretched out still.

**9:13** Yet the people have not turned unto him that smote them, neither have they sought YHWH of hosts.

**9:14** Therefore YHWH does cut off from Israel head and tail, palm-branch and rush, in one day.

**9:15** The elder and the man of rank, he is the head; and the prophet that teaches lies, he is the tail.

**9:16** For they that lead this people cause them to err; and they that are led of them are destroyed.

**9:17** Therefore the Lord shall have no joy in their young men, neither shall he have compassion on their fatherless and widows; for every one is profane and an evil-doer, and every mouth speaks wantonness. For all this his anger is not turned away, but his hand is stretched out still.

**9:18** For wickedness burns as the fire; it devours the briers and thorns; yea, it kindles in the thickets of the forest, and they roll upward in thick clouds of smoke.

**9:19** Through the wrath of YHWH of hosts is the land burnt up; the people also are as the fuel of fire; no man spares his brother.

**9:20** And one snatches on the right hand, and is hungry; and he eats on the left hand, and is not satisfied; they eat every man the flesh of his own arm:

**9:21** Manasseh, Ephraim; and Ephraim, Manasseh; and they together are against Judah. For all this his anger is not turned away, but his hand is stretched out still.

---

## Synthesis Notes

**Key Restorations:**

**Galilee's Glory (9:1):**
"In the former time he brought into contempt the land of Zebulun and the land of Naphtali."

*Ka-et ha-rishon heqal artzah Zevulun ve-artzah Naftali*—formerly despised.

"In the latter time he has made it glorious."

*Ve-ha-acharon hikhbid*—later glorified.

"By the way of the sea, beyond the Jordan, Galilee of the nations."

*Derekh ha-yam ever ha-Yarden Gelil ha-goyim*—Galilee of Gentiles. Matthew 4:15-16 quotes this.

**The Key Verse (9:2):**
"The people that walked in darkness have seen a great light."

*Ha-am ha-holekhim ba-choshekh ra'u or gadol*—great light.

"They that dwelt in the land of the shadow of death."

*Yoshevei be-eretz tzalmavet*—shadow of death.

"Upon them has the light shined."

*Or nagah aleihem*—light shined.

**Liberation (9:3-5):**
"You have multiplied the nation, you have increased their joy."

*Hirbita ha-goy higdalta ha-simchah*—joy increased.

"They joy before you according to the joy in harvest."

*Samechu lefanekha ke-simchat ba-qatzir*—harvest joy.

"The yoke of his burden... you have broken as in the day of Midian."

*Ki et-ol subblo... hachattota ke-yom Midyan*—Midian liberation (Judges 7).

"Every boot stamped with fierceness."

*Ki khol-se'on so'en be-ra'ash*—warrior's boot.

"Every cloak rolled in blood."

*Ve-simlah megolalah ve-damim*—bloody garments.

"Shall be for burning, for fuel of fire."

*Ve-haytah li-serefah ma'akholet esh*—burned.

**The Key Verses (9:6-7):**
"For unto us a child is born."

*Ki-yeled yullad-lanu*—child born.

"Unto us a son is given."

*Ben nittan-lanu*—son given.

"The government shall be upon his shoulder."

*Va-tehi ha-misrah al-shikhmo*—governmental authority.

"His name shall be called."

*Va-yiqra shemo*—named.

**The Fourfold Name:**
1. "Wonderful Counsellor" — *Pele Yo'etz* — miracle of counsel
2. "Mighty God" — *El Gibbor* — divine warrior
3. "Everlasting Father" — *Avi-Ad* — father forever
4. "Prince of Peace" — *Sar-Shalom* — peace ruler

**The Key Verse (9:7):**
"For the increase of his government and of peace there shall be no end."

*Le-marbeh ha-misrah u-le-shalom ein-qetz*—endless increase.

"Upon the throne of David."

*Al-kisse David*—Davidic throne.

"To establish it, and to uphold it through justice and through righteousness."

*Le-hakhin otah u-le-sa'adah be-mishpat u-vi-tzedaqah*—justice and righteousness.

"From henceforth even forever."

*Me-attah ve-ad-olam*—forever.

"The zeal of YHWH of hosts shall perform this."

*Qin'at YHWH Tzeva'ot ta'aseh zot*—YHWH's zeal.

**Refrain (9:12, 17, 21):**
"For all this his anger is not turned away, but his hand is stretched out still."

*Be-khol-zot lo-shav appo ve-od yado netuyah*—refrain (4x in 9:12, 17, 21; 10:4).

**Judgment on Israel (9:8-21):**
"'The bricks are fallen, but we will build with hewn stones.'"

*Levenim nafalu ve-gazit nivneh*—arrogant rebuilding.

"'The sycamores are cut down, but cedars will we put in their place.'"

*Shiqmim guddau ve-arazim nachalif*—upgrading materials.

"YHWH does cut off from Israel head and tail."

*Va-yakhret YHWH mi-Yisra'el rosh ve-zanav*—head and tail cut.

"The elder and the man of rank, he is the head."

*Zaqen u-nesu-fanim hu ha-rosh*—elder = head.

"The prophet that teaches lies, he is the tail."

*Ve-navi moreh-sheqer hu ha-zanav*—false prophet = tail.

"Wickedness burns as the fire."

*Ki-va'arah kha-esh rish'ah*—wickedness as fire.

"The people also are as the fuel of fire."

*Va-yehi ha-am ke-ma'akholet esh*—people as fuel.

"They eat every man the flesh of his own arm."

*Ish besar-zero'o yokhelu*—self-consumption.

"Manasseh, Ephraim; and Ephraim, Manasseh."

*Menassheh et-Efrayim ve-Efrayim et-Menassheh*—tribal conflict.

**Archetypal Layer:** Isaiah 9 contains **the great messianic prophecy (9:2-7)** with the fourfold throne name. Matthew 4:15-16 applies the light to Jesus' Galilean ministry.

**Ethical Inversion Applied:**
- "In the latter time he has made it glorious"—Galilee glorified
- "The people that walked in darkness have seen a great light"—darkness to light
- "They that dwelt in the land of the shadow of death"—shadow of death
- "The yoke of his burden... you have broken"—liberation
- "Every boot stamped with fierceness... shall be for burning"—war ended
- "Unto us a child is born, unto us a son is given"—messianic birth
- "The government shall be upon his shoulder"—governmental authority
- "Wonderful Counsellor"—miraculous counsel
- "Mighty God"—divine warrior
- "Everlasting Father"—eternal father
- "Prince of Peace"—peace ruler
- "Upon the throne of David"—Davidic promise
- "Through justice and through righteousness"—just reign
- "The zeal of YHWH of hosts shall perform this"—divine accomplishment
- "His hand is stretched out still"—ongoing judgment
- "The bricks are fallen, but we will build with hewn stones"—arrogance

**Modern Equivalent:** Isaiah 9:6-7 is the primary messianic birth prophecy. The fourfold name (*Pele Yo'etz, El Gibbor, Avi-Ad, Sar-Shalom*) combines divine and royal titles. Handel's "Messiah" famously sets this text. The light in Galilee (9:1-2) is applied to Jesus in Matthew 4:15-16.

# Isaiah 2: The Mountain of YHWH and the Day of YHWH

*From the Hebrew: הַדָּבָר אֲשֶׁר חָזָה יְשַׁעְיָהוּ (Ha-Davar Asher Chazah Yeshayahu) — The Word That Isaiah Saw*

---

## The Exalted Mountain (2:1-5)

**2:1** The word that Isaiah the son of Amoz saw concerning Judah and Jerusalem.

**2:2** And it shall come to pass in the end of days,
that the mountain of YHWH's house shall be established
at the top of the mountains,
and shall be exalted above the hills;
and all nations shall flow unto it.

**2:3** And many peoples shall go and say:
"Come, let us go up to the mountain of YHWH,
to the house of the God of Jacob;
and he will teach us of his ways,
and we will walk in his paths."
For out of Zion shall go forth the teaching,
and the word of YHWH from Jerusalem.

**2:4** And he shall judge between the nations,
and shall decide for many peoples;
and they shall beat their swords into plowshares,
and their spears into pruning-hooks;
nation shall not lift up sword against nation,
neither shall they learn war any more.

**2:5** O house of Jacob, come, and let us walk in the light of YHWH.

---

## The Day of YHWH Against Pride (2:6-22)

**2:6** For you have forsaken your people, the house of Jacob;
for they are full of customs from the east,
and are soothsayers like the Philistines,
and they strike hands with the children of strangers.

**2:7** Their land also is full of silver and gold,
neither is there any end of their treasures;
their land also is full of horses,
neither is there any end of their chariots.

**2:8** Their land also is full of idols;
they worship the work of their own hands,
that which their own fingers have made.

**2:9** And man is bowed down, and man is humbled—
therefore forgive them not.

**2:10** Enter into the rock, and hide in the dust,
from before the terror of YHWH, and from the glory of his majesty.

**2:11** The lofty looks of man shall be brought low,
and the haughtiness of men shall be bowed down,
and YHWH alone shall be exalted in that day.

**2:12** For YHWH of hosts has a day
upon all that is proud and lofty,
and upon all that is lifted up, and it shall be brought low;

**2:13** And upon all the cedars of Lebanon, that are high and lifted up,
and upon all the oaks of Bashan;

**2:14** And upon all the high mountains,
and upon all the hills that are lifted up;

**2:15** And upon every lofty tower,
and upon every fortified wall;

**2:16** And upon all the ships of Tarshish,
and upon all pleasant imagery.

**2:17** And the loftiness of man shall be bowed down,
and the haughtiness of men shall be brought low;
and YHWH alone shall be exalted in that day.

**2:18** And the idols shall utterly pass away.

**2:19** And men shall go into the caves of the rocks,
and into the holes of the earth,
from before the terror of YHWH, and from the glory of his majesty,
when he arises to shake mightily the earth.

**2:20** In that day a man shall cast away his idols of silver, and his idols of gold,
which they made for themselves to worship,
to the moles and to the bats;

**2:21** To go into the clefts of the rocks,
and into the crevices of the crags,
from before the terror of YHWH, and from the glory of his majesty,
when he arises to shake mightily the earth.

**2:22** Cease from man, whose breath is in his nostrils;
for how little is he to be accounted!

---

## Synthesis Notes

**Key Restorations:**

**The Key Verses (2:2-4):**
"In the end of days."

*Be-acharit ha-yamim*—latter days.

"The mountain of YHWH's house shall be established at the top of the mountains."

*Yihyeh nakkon har beit-YHWH be-rosh he-harim*—exalted mountain.

"Shall be exalted above the hills."

*Ve-nissa mi-geva'ot*—lifted above.

"All nations shall flow unto it."

*Ve-naharu elav kol-ha-goyim*—nations flowing.

"Many peoples shall go and say."

*Ve-halekhu ammim rabbim ve-amru*—peoples speak.

"'Come, let us go up to the mountain of YHWH.'"

*Lekhu ve-na'aleh el-har-YHWH*—pilgrimage invitation.

"'He will teach us of his ways.'"

*Ve-yorenu mi-derakhav*—divine teaching.

"'We will walk in his paths.'"

*Ve-nelkhah be-orchotav*—walking paths.

**The Key Verse (2:3):**
"For out of Zion shall go forth the teaching."

*Ki mi-Tziyyon tetze torah*—Torah from Zion.

"And the word of YHWH from Jerusalem."

*U-devar-YHWH mi-Yerushalayim*—YHWH's word.

**The Key Verse (2:4):**
"He shall judge between the nations."

*Ve-shafat bein ha-goyim*—divine arbitration.

"Shall decide for many peoples."

*Ve-hokhiach le-ammim rabbim*—dispute resolution.

"They shall beat their swords into plowshares."

*Ve-khittetu charvotam le-ittim*—swords to plowshares.

"Their spears into pruning-hooks."

*Va-chanitoteyhem le-mazmerot*—spears to pruning-hooks.

"Nation shall not lift up sword against nation."

*Lo-yissa goy el-goy cherev*—no more war.

"Neither shall they learn war any more."

*Ve-lo-yilmedu od milchamah*—war unlearned.

**The Key Verse (2:5):**
"O house of Jacob, come, and let us walk in the light of YHWH."

*Beit Ya'aqov lekhu ve-nelkhah be-or YHWH*—walk in light.

**Judgment on Pride (2:6-22):**
"They are full of customs from the east."

*Ki male'u mi-qedem*—eastern practices.

"Soothsayers like the Philistines."

*Ve-onenim ka-Pelishtiim*—divination.

"Their land also is full of silver and gold."

*Va-timmale artzo kesef ve-zahav*—wealth.

"Their land also is full of horses."

*Va-timmale artzo susim*—horses (military).

"Their land also is full of idols."

*Va-timmale artzo elilim*—idols.

"They worship the work of their own hands."

*Yishtachavu le-ma'aseh yadav*—self-made worship.

**The Key Verse (2:11, 17):**
"The lofty looks of man shall be brought low."

*Einei gavhut adam shafal*—pride humbled.

"The haughtiness of men shall be bowed down."

*Ve-shach rum anashim*—haughtiness bowed.

"YHWH alone shall be exalted in that day."

*Ve-nisgav YHWH levaddo ba-yom ha-hu*—YHWH alone exalted.

**The Day of YHWH (2:12):**
"YHWH of hosts has a day."

*Ki yom la-YHWH Tzeva'ot*—YHWH's day.

"Upon all that is proud and lofty."

*Al kol-ge'eh va-ram*—against pride.

"Upon all the cedars of Lebanon."

*Ve-al kol-arzei ha-Levanon*—Lebanon's cedars.

"Upon all the high mountains."

*Ve-al kol-he-harim ha-ramim*—high mountains.

"Upon every lofty tower."

*Ve-al kol-migdal gavo'ah*—lofty towers.

"Upon all the ships of Tarshish."

*Ve-al kol-oniyyot Tarshish*—trading ships.

**Terror of YHWH (2:19-21):**
"Men shall go into the caves of the rocks."

*U-va'u bi-me'arot tzurim*—hiding in caves.

"From before the terror of YHWH."

*Mi-penei pachad YHWH*—YHWH's terror.

"From the glory of his majesty."

*U-me-hadar ge'ono*—majestic glory.

"When he arises to shake mightily the earth."

*Be-qumo la'arotz ha-aretz*—earth-shaking.

"A man shall cast away his idols of silver."

*Yashlikhu ha-adam et elilei khaspo*—idols discarded.

"To the moles and to the bats."

*La-chafor perot ve-la-atalefim*—moles and bats.

**The Key Verse (2:22):**
"Cease from man, whose breath is in his nostrils."

*Chidlu lakhem min-ha-adam asher neshamah be-appo*—stop trusting man.

"For how little is he to be accounted!"

*Ki va-meh nechshav hu*—man's insignificance.

**Archetypal Layer:** Isaiah 2 contains **the vision of universal peace (2:2-4)** and **the Day of YHWH against pride (2:12-22)**. Swords to plowshares; YHWH alone exalted.

**Ethical Inversion Applied:**
- "The mountain of YHWH's house shall be established at the top"—exalted mountain
- "All nations shall flow unto it"—universal pilgrimage
- "He will teach us of his ways"—divine instruction
- "Out of Zion shall go forth the teaching"—Torah from Zion
- "They shall beat their swords into plowshares"—weapons transformed
- "Nation shall not lift up sword against nation"—peace
- "Neither shall they learn war any more"—war unlearned
- "Let us walk in the light of YHWH"—light-walking
- "Their land also is full of idols"—idol-full
- "They worship the work of their own hands"—self-worship
- "The lofty looks of man shall be brought low"—pride humbled
- "YHWH alone shall be exalted in that day"—YHWH alone
- "YHWH of hosts has a day upon all that is proud"—Day of YHWH
- "Men shall go into the caves of the rocks"—hiding from YHWH
- "A man shall cast away his idols"—idols discarded
- "Cease from man, whose breath is in his nostrils"—stop trusting man

**Modern Equivalent:** Isaiah 2:2-4's vision of universal peace (swords to plowshares) is inscribed at the UN. The Day of YHWH against human pride (2:12-22) shows all human achievement relativized before YHWH. "Cease from man" (2:22) counsels against misplaced trust.

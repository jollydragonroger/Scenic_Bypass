# Isaiah 46: The Fall of Babylon's Gods

*From the Hebrew: כָּרַע בֵּל קֹרֵס נְבוֹ (Kara Bel Qores Nevo) — Bel Bows Down, Nebo Stoops*

---

## Babylon's Idols Carried Away (46:1-2)

**46:1** Bel bows down, Nebo stoops; their idols are upon the beasts, and upon the cattle; the things that you carried are made a load, a burden to the weary beast.

**46:2** They stoop, they bow down together, they could not deliver the burden; and themselves are gone into captivity.

---

## YHWH Carries Israel (46:3-7)

**46:3** Hearken unto me, O house of Jacob, and all the remnant of the house of Israel, that have been borne by me from birth, that have been carried from the womb:

**46:4** Even to old age I am the same, and even to hoar hairs will I carry you; I have made, and I will bear; yea, I will carry, and will deliver.

**46:5** To whom will you liken me, and make me equal, and compare me, that we may be like?

**46:6** They lavish gold out of the bag, and weigh silver in the balance; they hire a goldsmith, and he makes it a god; they fall down, yea, they worship.

**46:7** They bear it upon the shoulder, they carry it, and set it in its place, and it stands; from its place it does not remove; yea, one cries unto it, yet it cannot answer, nor save him out of his trouble.

---

## Remember This (46:8-13)

**46:8** Remember this, and stand fast; bring it to mind, O you transgressors.

**46:9** Remember the former things of old; for I am God, and there is none else; I am God, and there is none like me;

**46:10** Declaring the end from the beginning, and from ancient times things that are not yet done; saying: "My counsel shall stand, and all my pleasure will I do";

**46:11** Calling a bird of prey from the east, the man of my counsel from a far country; yea, I have spoken, I will also bring it to pass; I have purposed, I will also do it.

**46:12** Hearken unto me, you stout-hearted, that are far from righteousness:

**46:13** I bring near my righteousness, it shall not be far off, and my salvation shall not tarry; and I will place salvation in Zion for Israel my glory.

---

## Synthesis Notes

**Key Restorations:**

**Babylon's Gods Fall (46:1-2):**
"Bel bows down, Nebo stoops."

*Kara Bel qores Nevo*—Bel (Marduk) and Nebo (god of wisdom) collapse.

"Their idols are upon the beasts, and upon the cattle."

*Hayu atzabbeihem la-chayyah ve-la-behemah*—idols loaded on animals.

"The things that you carried are made a load."

*Nesu'oteikhem amussot massa*—carried things become burden.

"A burden to the weary beast."

*La-ayefah*—burden to tired animals.

"They stoop, they bow down together."

*Qoresu kar'u yachdav*—stooping, bowing.

"They could not deliver the burden."

*Lo yakhlu mallet massa*—can't deliver burden.

"Themselves are gone into captivity."

*Ve-nafsham ba-shevi halakhah*—idols into exile.

**Contrast: YHWH Carries (46:3-4):**
"Hearken unto me, O house of Jacob."

*Shim'u elai beit-Ya'aqov*—Jacob addressed.

"All the remnant of the house of Israel."

*Ve-khol-she'erit beit Yisra'el*—remnant.

"That have been borne by me from birth."

*Ha-amusim minni-beten*—borne from womb.

"That have been carried from the womb."

*Ha-nesu'im minni-racham*—carried from womb.

**The Key Verse (46:4):**
"Even to old age I am the same."

*Ve-ad-ziqnah ani hu*—same to old age.

"Even to hoar hairs will I carry you."

*Ve-ad-seivah ani esbol*—carry to gray hair.

"I have made, and I will bear."

*Ani asiti va-ani essa*—made and will bear.

"Yea, I will carry, and will deliver."

*Va-ani esbol va-amallet*—carry and deliver.

**The Contrast:**
Babylon's gods must be carried by weary beasts; YHWH carries Israel from birth to old age.

**Idol-Making (46:5-7):**
"To whom will you liken me, and make me equal?"

*Le-mi tedammeyuni ve-tashvu*—compare to whom?

"Compare me, that we may be like?"

*Ve-tamshiluni ve-nidmeh*—who is like?

"They lavish gold out of the bag."

*Ha-zalim zahav mi-kis*—gold poured.

"Weigh silver in the balance."

*Ve-khesef ba-qaneh yishqolu*—silver weighed.

"They hire a goldsmith, and he makes it a god."

*Yiskeru tzroef ve-ya'asehu el*—goldsmith makes god.

"They fall down, yea, they worship."

*Yisseggdu af-yishtachawu*—fall and worship.

"They bear it upon the shoulder, they carry it."

*Yissa'uhu al-katef yisbeluhu*—carried on shoulder.

"Set it in its place, and it stands."

*Ve-yannichuhu tachtav ve-ya'amod*—set in place.

"From its place it does not remove."

*Mi-meqomo lo yamish*—can't move.

"One cries unto it, yet it cannot answer."

*Af-yitz'aq elav ve-lo ya'aneh*—no answer.

"Nor save him out of his trouble."

*Mi-tzarato lo yoshi'ennu*—can't save.

**Remember (46:8-11):**
"Remember this, and stand fast."

*Zikhru-zot ve-hit'oshashu*—remember and be firm.

"Bring it to mind, O you transgressors."

*Hashivu posh'im al-lev*—transgressors remember.

**The Key Verses (46:9-10):**
"Remember the former things of old."

*Zikhru rishonot me-olam*—remember former things.

"For I am God, and there is none else."

*Ki anokhi El ve-ein od*—I am God, no other.

"I am God, and there is none like me."

*Elohim ve-efes kamoni*—none like me.

"Declaring the end from the beginning."

*Maggid me-reshit acharit*—end from beginning.

"From ancient times things that are not yet done."

*U-mi-qedem asher lo-na'asu*—ancient, undone things.

"'My counsel shall stand.'"

*Atzati taqum*—counsel stands.

"'All my pleasure will I do.'"

*Ve-khol-cheftzi e'eseh*—pleasure done.

**The Key Verse (46:11):**
"Calling a bird of prey from the east."

*Qore mi-mizrach ayit*—bird of prey from east (Cyrus).

"The man of my counsel from a far country."

*Me-eretz merchaq ish atzati*—counsel-man from far.

"I have spoken, I will also bring it to pass."

*Af-dibbarti af-avi'ennah*—spoken, will bring.

"I have purposed, I will also do it."

*Yatzarti af-e'esennah*—purposed, will do.

**Salvation Near (46:12-13):**
"Hearken unto me, you stout-hearted."

*Shim'u elai abbirei lev*—stubborn hearts.

"That are far from righteousness."

*Ha-rechoqim mi-tzedaqah*—far from righteousness.

**The Key Verse (46:13):**
"I bring near my righteousness, it shall not be far off."

*Qeravti tzidqati lo tirchaq*—righteousness near.

"My salvation shall not tarry."

*U-teshu'ati lo te'achar*—salvation won't delay.

"I will place salvation in Zion for Israel my glory."

*Ve-natatti be-Tziyyon teshu'ah le-Yisra'el tif'arti*—Zion salvation.

**Archetypal Layer:** Isaiah 46 contrasts **idols that must be carried (46:1-2, 6-7)** with **YHWH who carries Israel (46:3-4)**. YHWH declares **the end from the beginning (46:10)**.

**Ethical Inversion Applied:**
- "Bel bows down, Nebo stoops"—Babylon's gods collapse
- "Their idols are upon the beasts"—idols burden animals
- "They could not deliver the burden"—idols can't deliver
- "Themselves are gone into captivity"—idols exiled
- "That have been borne by me from birth"—YHWH carries Israel
- "That have been carried from the womb"—womb-carried
- "Even to old age I am the same"—unchanging
- "Even to hoar hairs will I carry you"—lifelong carrying
- "I have made, and I will bear"—made and bears
- "To whom will you liken me?"—incomparable
- "They bear it upon the shoulder, they carry it"—idol carried
- "Set it in its place, and it stands"—immobile
- "From its place it does not remove"—can't move
- "One cries unto it, yet it cannot answer"—no answer
- "Nor save him out of his trouble"—can't save
- "Remember the former things of old"—remember
- "For I am God, and there is none else"—only God
- "Declaring the end from the beginning"—knows end from beginning
- "'My counsel shall stand'"—counsel stands
- "Calling a bird of prey from the east"—Cyrus = bird of prey
- "I have spoken, I will also bring it to pass"—word accomplishes
- "I bring near my righteousness"—righteousness near
- "My salvation shall not tarry"—salvation soon
- "I will place salvation in Zion"—Zion salvation

**Modern Equivalent:** Isaiah 46's contrast between carried idols (46:1-2, 6-7) and the carrying God (46:3-4) is powerful: false gods burden their worshippers; the true God carries his people. "Declaring the end from the beginning" (46:10) is foundational for understanding prophecy.

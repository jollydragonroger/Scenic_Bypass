# Jeremiah 50: Oracle Against Babylon (Part 1)

*From the Hebrew: הַדָּבָר אֲשֶׁר דִּבֶּר יְהוָה אֶל־בָּבֶל (Ha-Davar Asher Dibber YHWH El-Bavel) — The Word That YHWH Spoke Concerning Babylon*

---

## Babylon's Fall Announced (50:1-10)

**50:1** The word that YHWH spoke concerning Babylon, concerning the land of the Chaldeans, by Jeremiah the prophet.

**50:2** "Declare among the nations and announce, and set up a standard; announce, and conceal not; say: 'Babylon is taken, Bel is put to shame, Merodach is dismayed; her images are put to shame, her idols are dismayed.'

**50:3** "For out of the north there comes up a nation against her, which shall make her land desolate, and none shall dwell therein; they are fled, they are gone, both man and beast.

**50:4** "In those days, and in that time," says YHWH, "the children of Israel shall come, they and the children of Judah together; they shall go on their way weeping, and shall seek YHWH their God.

**50:5** "They shall inquire concerning Zion with their faces toward it, saying: 'Come, and let us join ourselves to YHWH in an everlasting covenant that shall not be forgotten.'

**50:6** "My people have been lost sheep; their shepherds have caused them to go astray, they have turned them away on the mountains; they have gone from mountain to hill, they have forgotten their resting-place.

**50:7** "All that found them have devoured them; and their adversaries said: 'We are not guilty,' because they have sinned against YHWH, the habitation of righteousness, even YHWH, the hope of their fathers.

**50:8** "Flee out of the midst of Babylon, and go forth out of the land of the Chaldeans, and be as the he-goats before the flocks.

**50:9** "For, lo, I will stir up and cause to come up against Babylon an assembly of great nations from the north country; and they shall set themselves in array against her, from there she shall be taken; their arrows shall be as of a mighty man that makes childless; none shall return in vain.

**50:10** "And Chaldea shall be a spoil; all that spoil her shall be satisfied," says YHWH.

---

## Babylon's Punishment (50:11-20)

**50:11** "Because you are glad, because you rejoice, O you that plunder my heritage, because you gambol as a heifer at grass, and neigh as strong horses;

**50:12** "Your mother shall be greatly ashamed, she that bore you shall be confounded; behold, the hindermost of the nations shall be a wilderness, a dry land, and a desert.

**50:13** "Because of the wrath of YHWH it shall not be inhabited, but it shall be wholly desolate; every one that goes by Babylon shall be astonished, and hiss at all her plagues.

**50:14** "Set yourselves in array against Babylon round about, all you that bend the bow, shoot at her, spare no arrows; for she has sinned against YHWH.

**50:15** "Shout against her round about, she has submitted herself; her buttresses are fallen, her walls are thrown down; for it is the vengeance of YHWH, take vengeance upon her; as she has done, do unto her.

**50:16** "Cut off the sower from Babylon, and him that handles the sickle in the time of harvest; for fear of the oppressing sword they shall turn every one to his people, and they shall flee every one to his own land.

**50:17** "Israel is a scattered sheep, the lions have driven him away; first the king of Assyria has devoured him, and last this Nebuchadrezzar king of Babylon has broken his bones.

**50:18** "Therefore thus says YHWH of hosts, the God of Israel: Behold, I will punish the king of Babylon and his land, as I have punished the king of Assyria.

**50:19** "And I will bring Israel back to his pasture, and he shall feed on Carmel and Bashan, and his soul shall be satisfied upon the hills of Ephraim and in Gilead.

**50:20** "In those days, and in that time," says YHWH, "the iniquity of Israel shall be sought for, and there shall be none; and the sins of Judah, and they shall not be found; for I will pardon them whom I leave as a remnant."

---

## The Attack on Babylon (50:21-34)

**50:21** "Go up against the land of Merathaim, even against it, and against the inhabitants of Pekod; slay and utterly destroy after them," says YHWH, "and do according to all that I have commanded you.

**50:22** "Hark! Battle is in the land, and great destruction.

**50:23** "How is the hammer of the whole earth cut asunder and broken! How is Babylon become a desolation among the nations!

**50:24** "I have laid a snare for you, and you are also taken, O Babylon, and you were not aware; you are found, and also caught, because you have striven against YHWH.

**50:25** "YHWH has opened his armoury, and has brought forth the weapons of his indignation; for the Lord YHWH of hosts has a work to do in the land of the Chaldeans.

**50:26** "Come against her from every quarter, open her granaries, cast her up as heaps, and destroy her utterly; let nothing of her be left.

**50:27** "Slay all her bullocks, let them go down to the slaughter; woe unto them! For their day is come, the time of their visitation.

**50:28** "Hark! They flee and escape out of the land of Babylon, to declare in Zion the vengeance of YHWH our God, the vengeance of his temple.

**50:29** "Call together the archers against Babylon, all them that bend the bow; encamp against her round about, let none thereof escape; recompense her according to her work, according to all that she has done, do unto her; for she has been arrogant against YHWH, against the Holy One of Israel.

**50:30** "Therefore shall her young men fall in her broad places, and all her men of war shall be brought to silence in that day," says YHWH.

**50:31** "Behold, I am against you, O arrogant one," says the Lord YHWH of hosts; "for your day is come, the time that I will visit you.

**50:32** "And the arrogant one shall stumble and fall, and none shall raise him up; and I will kindle a fire in his cities, and it shall devour all that are round about him."

**50:33** Thus says YHWH of hosts: "The children of Israel and the children of Judah are oppressed together; and all that took them captives hold them fast; they refuse to let them go.

**50:34** "Their Redeemer is strong, YHWH of hosts is his name; he will thoroughly plead their cause, that he may give rest to the earth, and disquiet the inhabitants of Babylon."

---

## Sword Against Babylon (50:35-46)

**50:35** "A sword is upon the Chaldeans," says YHWH, "and upon the inhabitants of Babylon, and upon her princes, and upon her wise men.

**50:36** "A sword is upon the boasters, and they shall become fools; a sword is upon her mighty men, and they shall be dismayed.

**50:37** "A sword is upon their horses, and upon their chariots, and upon all the mingled people that are in the midst of her, and they shall become as women; a sword is upon her treasures, and they shall be robbed.

**50:38** "A drought is upon her waters, and they shall be dried up; for it is a land of graven images, and they are mad upon idols.

**50:39** "Therefore the wild cats with the jackals shall dwell there, and the ostriches shall dwell therein; and it shall be no more inhabited forever, neither shall it be dwelt in from generation to generation.

**50:40** "As when God overthrew Sodom and Gomorrah and the neighbour cities thereof," says YHWH; "so shall no man dwell there, neither shall any son of man sojourn therein.

**50:41** "Behold, a people comes from the north, and a great nation, and many kings shall be stirred up from the uttermost parts of the earth.

**50:42** "They lay hold on bow and spear, they are cruel, and have no compassion; their voice is like the roaring sea, and they ride upon horses; every one set in array, as a man to the battle, against you, O daughter of Babylon.

**50:43** "The king of Babylon has heard the report of them, and his hands wax feeble; anguish has taken hold of him, and pangs as of a woman in travail.

**50:44** "Behold, he shall come up like a lion from the thicket of the Jordan against the strong habitation; for I will suddenly make them run away from her; and who so is chosen, him will I appoint over her; for who is like me? And who will appoint me a time? And who is that shepherd that will stand before me?

**50:45** "Therefore hear the counsel of YHWH, that he has taken against Babylon; and his purposes, that he has purposed against the land of the Chaldeans: Surely the least of the flock shall drag them away; surely he shall make their habitation desolate over them.

**50:46** "At the noise of the taking of Babylon the earth quakes, and the cry is heard among the nations."

---

## Synthesis Notes

**Key Restorations:**

**Babylon Falls (50:1-3):**
"The word that YHWH spoke concerning Babylon."

*Ha-davar asher dibber YHWH el-Bavel*—concerning Babylon.

"'Declare among the nations and announce.'"

*Haggidu va-goyim ve-hashmi'u*—declare.

"'Set up a standard.'"

*Ve-se'u-nes*—raise standard.

"'Babylon is taken.'"

*Nilkedah Bavel*—taken.

"'Bel is put to shame.'"

*Hovish Bel*—Bel shamed.

"'Merodach is dismayed.'"

*Chatat Merodakh*—Marduk dismayed.

**Bel and Marduk:**
Chief gods of Babylon—captured along with the city.

"'Her images are put to shame.'"

*Hovishu atzabbehha*—images shamed.

"'Her idols are dismayed.'"

*Chattu gillulekha*—idols dismayed.

"'Out of the north there comes up a nation against her.'"

*Ki me-tzafon alah alekha goy*—north nation.

**North Invader:**
Persia (and Medes) came from the north.

**Israel's Return (50:4-7):**
**The Key Verses (50:4-5):**
"'In those days, and in that time.'"

*Ba-yamim ha-hemmah u-va-et ha-hi*—those days.

"'The children of Israel shall come, they and the children of Judah together.'"

*Yavo'u venei-Yisra'el hemmah u-venei-Yehudah yachdav*—Israel and Judah.

"'They shall go on their way weeping.'"

*Halokh u-vakho yelekhu*—weeping journey.

"'Shall seek YHWH their God.'"

*Ve-et-YHWH Eloheihem yevaqeshu*—seek YHWH.

"'They shall inquire concerning Zion with their faces toward it.'"

*Tziyyon yish'alu derekh hennah peneihem*—faces toward Zion.

"''Come, and let us join ourselves to YHWH in an everlasting covenant.''"

*Bo'u ve-nilvvu el-YHWH berit olam*—everlasting covenant.

**The Key Verses (50:6-7):**
"'My people have been lost sheep.'"

*Tzon ovedot hayah ammi*—lost sheep.

"'Their shepherds have caused them to go astray.'"

*Ro'eihem hit'um*—shepherds led astray.

"'They have turned them away on the mountains.'"

*Harim shovavum*—on mountains.

"'They have forgotten their resting-place.'"

*Shakechu rivtzam*—forgot rest.

"'All that found them have devoured them.'"

*Kol-motzve'ihem akhalum*—devoured.

"'Their adversaries said: We are not guilty.'"

*Ve-tzareihem amru lo ne'sham*—not guilty.

"'Because they have sinned against YHWH.'"

*Tachat asher chat'u la-YHWH*—because sinned.

"'The habitation of righteousness, even YHWH.'"

*Neveh-tzedeq YHWH*—habitation of righteousness.

"'The hope of their fathers.'"

*Miqveh avoteihem*—fathers' hope.

**Flee Babylon (50:8-10):**
"'Flee out of the midst of Babylon.'"

*Neddu mi-tokh Bavel*—flee.

"'Go forth out of the land of the Chaldeans.'"

*U-me-eretz Kasdim tze'u*—leave.

"'Be as the he-goats before the flocks.'"

*Vi-heyu ke-attudim lifnei tzon*—lead flocks.

"'I will stir up and cause to come up against Babylon an assembly of great nations.'"

*Hineni me'ir u-ma'aleh al-Bavel qahal goyim gedolim*—assembly.

"'From the north country.'"

*Me-eretz tzafon*—from north.

"'She shall be taken.'"

*Mi-sham tillakhed*—taken.

"'Their arrows shall be as of a mighty man that makes childless.'"

*Chitztzav ke-gibbor maskil*—skilled archer.

"'None shall return in vain.'"

*Lo yashuv reqam*—none miss.

**Babylon's Punishment (50:11-20):**
"'Because you are glad, because you rejoice, O you that plunder my heritage.'"

*Ki tismuchi ki ta'alzi shossei nachalati*—glad plunderers.

"'Because you gambol as a heifer at grass.'"

*Ki tafushi ke-egelah dashshah*—gamboling heifer.

"'Neigh as strong horses.'"

*Va-titzhalu ke-abbirim*—neighing.

"'Your mother shall be greatly ashamed.'"

*Boshah immekhem me'od*—mother shamed.

"'The hindermost of the nations shall be a wilderness.'"

*Hinneh acharit goyim midbar*—last of nations.

"'A dry land, and a desert.'"

*Tziyyah va-aravah*—dry, desert.

**The Key Verse (50:15):**
"'It is the vengeance of YHWH.'"

*Ki-niqmat YHWH hi*—YHWH's vengeance.

"'Take vengeance upon her.'"

*Hinaqqemu vah*—take vengeance.

"'As she has done, do unto her.'"

*Ka-asher asetah asu-lah*—measure for measure.

**The Key Verses (50:17-18):**
"'Israel is a scattered sheep.'"

*Seh pezurah Yisra'el*—scattered sheep.

"'The lions have driven him away.'"

*Arayot hiddichuhuu*—lions drove.

"'First the king of Assyria has devoured him.'"

*Ha-rishon akhal melekh Ashshur*—Assyria first.

"'Last this Nebuchadrezzar king of Babylon has broken his bones.'"

*Ve-ha-acharon ha-zeh itzzemo Nevukhadre'zzar melekh Bavel*—Babylon last.

"'I will punish the king of Babylon and his land.'"

*Hineni poqed el-melekh Bavel ve-el-artzo*—punish.

"'As I have punished the king of Assyria.'"

*Ka-asher paqadti el-melekh Ashshur*—like Assyria.

**The Key Verses (50:19-20):**
"'I will bring Israel back to his pasture.'"

*Ve-shavti et-Yisra'el el-navehu*—bring back.

"'He shall feed on Carmel and Bashan.'"

*Ve-ra'ah be-Karmel u-va-Bashan*—graze.

"'His soul shall be satisfied upon the hills of Ephraim and in Gilead.'"

*U-ve-har Efrayim u-va-Gil'ad tisba nafsho*—satisfied.

**The Key Verse (50:20):**
"'The iniquity of Israel shall be sought for, and there shall be none.'"

*Yevuqqash et-avon Yisra'el ve-einennu*—no iniquity.

"'The sins of Judah, and they shall not be found.'"

*Ve-et-chatto't Yehudah ve-lo timmatzena*—not found.

"'For I will pardon them whom I leave as a remnant.'"

*Ki eslach la-asher asha'ir*—pardon remnant.

**Attack on Babylon (50:21-34):**
"'Go up against the land of Merathaim.'"

*Aleh al-ha-aretz Meratayim*—Merathaim.

"'Against the inhabitants of Pekod.'"

*Ve-al-yoshevei Peqod*—Pekod.

**Wordplays:**
*Merathaim* = "double rebellion"; *Pekod* = "punishment" (also actual places).

**The Key Verse (50:23):**
"'How is the hammer of the whole earth cut asunder and broken!'"

*Eikh nigda va-yishshaver pattish kol-ha-aretz*—hammer broken.

"'How is Babylon become a desolation among the nations!'"

*Eikh hayetah le-shammah Bavel ba-goyim*—desolation.

**The Key Verse (50:25):**
"'YHWH has opened his armoury.'"

*Patach YHWH et-otzaro*—opened armory.

"'Has brought forth the weapons of his indignation.'"

*Va-yotze et-kelei za'amo*—wrath weapons.

**The Key Verse (50:29):**
"'She has been arrogant against YHWH.'"

*Ki el-YHWH zadah*—arrogant against YHWH.

"'Against the Holy One of Israel.'"

*El-Qedosh Yisra'el*—Holy One.

**The Key Verse (50:34):**
"'Their Redeemer is strong.'"

*Go'alam chazaq*—strong Redeemer.

"'YHWH of hosts is his name.'"

*YHWH Tzeva'ot shemo*—YHWH of hosts.

"'He will thoroughly plead their cause.'"

*Riv yariv et-rivam*—plead cause.

"'That he may give rest to the earth.'"

*Lema'an hirgi'a et-ha-aretz*—give earth rest.

"'Disquiet the inhabitants of Babylon.'"

*Ve-hirgiz le-yoshevei Bavel*—disquiet Babylon.

**Sword Upon Babylon (50:35-46):**
**The Key Verses (50:35-38):**
"'A sword is upon the Chaldeans.'"

*Cherev al-Kasdim*—sword on Chaldeans.

"'Upon the inhabitants of Babylon.'"

*Ve-al-yoshevei Bavel*—on Babylon.

"'Upon her princes, and upon her wise men.'"

*Ve-al-sareyha ve-al-chakhamekha*—princes, wise.

"'A sword is upon the boasters.'"

*Cherev el-ha-baddim*—on boasters.

"'A sword is upon her mighty men.'"

*Cherev el-gibborekha*—on mighty.

"'A sword is upon their horses, and upon their chariots.'"

*Cherev el-susav ve-el-rikhbo*—horses, chariots.

"'A drought is upon her waters.'"

*Chorev el-meimekha*—drought on waters.

**Wordplay:**
*Cherev* (sword) / *chorev* (drought).

"'They shall be dried up.'"

*Ve-yaveshu*—dried.

"'It is a land of graven images.'"

*Ki eretz pesilim hi*—idol land.

"'They are mad upon idols.'"

*U-va-emim yitholalu*—mad on idols.

**The Key Verses (50:39-40):**
"'The wild cats with the jackals shall dwell there.'"

*Lakhen yeshvu tziyyim et-iyyim*—wild animals.

"'The ostriches shall dwell therein.'"

*Ve-yashvu vah benot ya'anah*—ostriches.

"'It shall be no more inhabited forever.'"

*Ve-lo-teshev od la-netzach*—never inhabited.

"'As when God overthrew Sodom and Gomorrah.'"

*Ke-mahpekhat Elohim et-Sedom ve-et-Amorah*—like Sodom.

**The Key Verses (50:44-46):**
"'He shall come up like a lion from the thicket of the Jordan.'"

*Hinneh ke-aryeh ya'aleh mi-ge'on ha-Yarden*—lion. (Repeats 49:19)

"'For who is like me? And who will appoint me a time?'"

*Ki mi khamoni u-mi yo'ideni*—who like me?

"'At the noise of the taking of Babylon the earth quakes.'"

*Mi-qol nitpesah Bavel nir'ashah ha-aretz*—earth quakes.

"'The cry is heard among the nations.'"

*U-ze'aqah ba-goyim nishma*—cry heard.

**Archetypal Layer:** Jeremiah 50 begins the **massive oracle against Babylon (50-51)**, containing **"Babylon is taken, Bel is put to shame" (50:2)**, **"My people have been lost sheep" (50:6)**, **"Israel is a scattered sheep... first Assyria... last Babylon" (50:17)**, and **"Their Redeemer is strong, YHWH of hosts is his name" (50:34)**.

**Ethical Inversion Applied:**
- "The word that YHWH spoke concerning Babylon"—Babylon oracle
- "'Babylon is taken, Bel is put to shame'"—taken, gods shamed
- "'Merodach is dismayed'"—Marduk dismayed
- "'Out of the north there comes up a nation against her'"—north invader
- "'The children of Israel shall come, they and the children of Judah together'"—united return
- "'They shall go on their way weeping, and shall seek YHWH'"—weeping seekers
- "'Come, and let us join ourselves to YHWH in an everlasting covenant'"—everlasting covenant
- "'My people have been lost sheep'"—lost sheep
- "'Their shepherds have caused them to go astray'"—bad shepherds
- "'They have forgotten their resting-place'"—forgot rest
- "'All that found them have devoured them'"—devoured
- "'Their adversaries said: We are not guilty'"—false innocence
- "'Flee out of the midst of Babylon'"—flee
- "'I will stir up... an assembly of great nations from the north'"—north assembly
- "'Because you are glad... O you that plunder my heritage'"—glad plunderers
- "'It is the vengeance of YHWH, take vengeance upon her'"—vengeance
- "'As she has done, do unto her'"—measure for measure
- "'Israel is a scattered sheep, the lions have driven him away'"—scattered
- "'First the king of Assyria... last this Nebuchadrezzar'"—two devourers
- "'I will punish the king of Babylon... as I have punished... Assyria'"—like Assyria
- "'I will bring Israel back to his pasture'"—bring back
- "'The iniquity of Israel shall be sought for, and there shall be none'"—no iniquity
- "'I will pardon them whom I leave as a remnant'"—pardon remnant
- "'How is the hammer of the whole earth cut asunder!'"—hammer broken
- "'YHWH has opened his armoury'"—YHWH's armory
- "'She has been arrogant against YHWH, against the Holy One of Israel'"—arrogance
- "'Their Redeemer is strong, YHWH of hosts is his name'"—strong Redeemer
- "'A sword is upon the Chaldeans'"—sword
- "'A drought is upon her waters'"—drought
- "'It is a land of graven images'"—idols
- "'As when God overthrew Sodom and Gomorrah'"—like Sodom
- "'At the noise of the taking of Babylon the earth quakes'"—earth quakes

**Modern Equivalent:** Jeremiah 50 begins the longest oracle against a foreign nation. Babylon, YHWH's instrument of judgment, now becomes the object of judgment. "Their Redeemer is strong" (50:34) assures Israel of deliverance. The Medes and Persians fulfilled this prophecy in 539 BCE.

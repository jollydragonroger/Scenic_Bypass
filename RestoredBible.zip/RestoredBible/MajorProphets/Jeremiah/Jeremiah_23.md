# Jeremiah 23: The Righteous Branch and False Prophets

*From the Hebrew: הוֹי רֹעִים (Hoy Ro'im) — Woe to the Shepherds*

---

## Woe to the Shepherds (23:1-4)

**23:1** "Woe unto the shepherds that destroy and scatter the sheep of my pasture!" says YHWH.

**23:2** Therefore thus says YHWH, the God of Israel, against the shepherds that feed my people: "You have scattered my flock, and driven them away, and have not taken care of them; behold, I will visit upon you the evil of your doings," says YHWH.

**23:3** "And I will gather the remnant of my flock out of all the countries whither I have driven them, and will bring them back to their folds; and they shall be fruitful and multiply.

**23:4** "And I will set up shepherds over them, who shall feed them; and they shall fear no more, nor be dismayed, neither shall any be lacking," says YHWH.

---

## The Righteous Branch (23:5-8)

**23:5** "Behold, the days come," says YHWH, "that I will raise unto David a righteous Branch, and he shall reign as king and prosper, and shall execute justice and righteousness in the land.

**23:6** "In his days Judah shall be saved, and Israel shall dwell safely; and this is his name whereby he shall be called: YHWH Tzidqenu—YHWH is our righteousness."

**23:7** "Therefore, behold, the days come," says YHWH, "that they shall no more say: 'As YHWH lives, that brought up the children of Israel out of the land of Egypt';

**23:8** "But: 'As YHWH lives, that brought up and that led the seed of the house of Israel out of the north country, and from all the countries whither I had driven them'; and they shall dwell in their own land."

---

## Against the False Prophets (23:9-22)

**23:9** Concerning the prophets. My heart within me is broken, all my bones shake; I am like a drunken man, and like a man whom wine has overcome; because of YHWH, and because of his holy words.

**23:10** For the land is full of adulterers; for because of the curse the land mourns, the pastures of the wilderness are dried up; and their course is evil, and their might is not right.

**23:11** "For both prophet and priest are profane; yea, in my house have I found their wickedness," says YHWH.

**23:12** "Wherefore their way shall be unto them as slippery places in the darkness, they shall be thrust, and fall therein; for I will bring evil upon them, even the year of their visitation," says YHWH.

**23:13** "And I have seen unseemliness in the prophets of Samaria: they prophesied by Baal, and caused my people Israel to err.

**23:14** "But in the prophets of Jerusalem I have seen a horrible thing: they commit adultery, and walk in lies, and they strengthen the hands of evil-doers, that none does return from his wickedness; they are all of them become unto me as Sodom, and the inhabitants thereof as Gomorrah."

**23:15** Therefore thus says YHWH of hosts concerning the prophets: "Behold, I will feed them with wormwood, and make them drink the water of gall; for from the prophets of Jerusalem is ungodliness gone forth into all the land."

**23:16** Thus says YHWH of hosts: "Hearken not unto the words of the prophets that prophesy unto you, they lead you unto vanity; they speak a vision of their own heart, and not out of the mouth of YHWH.

**23:17** "They say continually unto them that despise me: 'YHWH has said: You shall have peace'; and unto every one that walks in the stubbornness of his own heart they say: 'No evil shall come upon you.'"

**23:18** "For who has stood in the council of YHWH, that he should perceive and hear his word? Who has attended to his word, and heard it?

**23:19** "Behold, a storm of YHWH is gone forth in fury, a whirling storm; it shall whirl upon the head of the wicked.

**23:20** "The anger of YHWH shall not return, until he have executed, and till he have performed the purposes of his heart; in the end of days you shall consider it perfectly.

**23:21** "I sent not these prophets, yet they ran; I spoke not unto them, yet they prophesied.

**23:22** "But if they had stood in my council, then had they caused my people to hear my words, and had turned them from their evil way, and from the evil of their doings."

---

## YHWH's Omnipresence (23:23-32)

**23:23** "Am I a God near at hand," says YHWH, "and not a God afar off?

**23:24** "Can any hide himself in secret places that I shall not see him?" says YHWH. "Do not I fill heaven and earth?" says YHWH.

**23:25** "I have heard what the prophets have said, that prophesy lies in my name, saying: 'I have dreamed, I have dreamed.'

**23:26** "How long shall this be? Is it in the heart of the prophets that prophesy lies, and the prophets of the deceit of their own heart?

**23:27** "That think to cause my people to forget my name by their dreams which they tell every man to his neighbour, as their fathers forgot my name for Baal.

**23:28** "The prophet that has a dream, let him tell a dream; and he that has my word, let him speak my word faithfully. What is the straw to the wheat?" says YHWH.

**23:29** "Is not my word like as fire?" says YHWH; "and like a hammer that breaks the rock in pieces?

**23:30** "Therefore, behold, I am against the prophets," says YHWH, "that steal my words every one from his neighbour.

**23:31** "Behold, I am against the prophets," says YHWH, "that use their tongues, and say: 'He says.'

**23:32** "Behold, I am against them that prophesy lying dreams," says YHWH, "and do tell them, and cause my people to err by their lies, and by their wantonness; yet I sent them not, nor commanded them; neither do they profit this people at all," says YHWH.

---

## The Burden of YHWH (23:33-40)

**23:33** "And when this people, or the prophet, or a priest, shall ask you, saying: 'What is the burden of YHWH?' then shall you say unto them: 'What burden! I will cast you off,' says YHWH.

**23:34** "And as for the prophet, and the priest, and the people, that shall say: 'The burden of YHWH,' I will even punish that man and his house.

**23:35** "Thus shall you say every one to his neighbour, and every one to his brother: 'What has YHWH answered?' and: 'What has YHWH spoken?'

**23:36** "And the burden of YHWH shall you mention no more; for every man's own word shall be his burden; for you have perverted the words of the living God, of YHWH of hosts our God.

**23:37** "Thus shall you say to the prophet: 'What has YHWH answered you?' and: 'What has YHWH spoken?'

**23:38** "But if you say: 'The burden of YHWH'; therefore thus says YHWH: Because you say this word: 'The burden of YHWH,' and I have sent unto you, saying: 'You shall not say: The burden of YHWH';

**23:39** "Therefore, behold, I will utterly tear you out, and I will cast you off, and the city that I gave unto you and to your fathers, away from my presence;

**23:40** "And I will bring an everlasting reproach upon you, and a perpetual shame, which shall not be forgotten."

---

## Synthesis Notes

**Key Restorations:**

**Woe to Shepherds (23:1-4):**
**The Key Verse (23:1):**
"Woe unto the shepherds that destroy and scatter the sheep of my pasture!"

*Hoy ro'im me'abbedim u-mefitzim et-tzon mar'iti*—woe to scattering shepherds.

"You have scattered my flock, and driven them away."

*Attem hafitzotem et-tzoni va-taddichum*—scattered, driven.

"Have not taken care of them."

*Ve-lo faqadtem otam*—not cared for.

"I will visit upon you the evil of your doings."

*Hineni poqed aleikhem et-ro'a ma'aleleikem*—punish evil doings.

**The Key Verses (23:3-4):**
"I will gather the remnant of my flock."

*Va-ani aqabbetz et-she'erit tzoni*—gather remnant.

"Out of all the countries whither I have driven them."

*Mi-kol ha-aratzot asher hiddachti otam sham*—from all countries.

"Bring them back to their folds."

*Va-hashivoti ethen al-nevehen*—return to folds.

"They shall be fruitful and multiply."

*U-faru ve-ravu*—fruitful, multiply.

"I will set up shepherds over them, who shall feed them."

*Va-haqimoti aleihem ro'im ve-ra'um*—set up shepherds.

"They shall fear no more, nor be dismayed."

*Ve-lo-yir'u od ve-lo-yechatu*—no fear.

"Neither shall any be lacking."

*Ve-lo yippaqedu*—none lacking.

**Righteous Branch (23:5-8):**
**The Key Verses (23:5-6):**
"The days come, that I will raise unto David a righteous Branch."

*Hineh yamim ba'im... va-haqimoti le-David Tzemach tzaddiq*—righteous Branch.

"He shall reign as king and prosper."

*U-malakh melekh ve-hiskil*—reign, prosper.

"Shall execute justice and righteousness in the land."

*Ve-asah mishpat u-tzedaqah ba-aretz*—justice and righteousness.

**The Key Verse (23:6):**
"In his days Judah shall be saved."

*Be-yamav tivvasha Yehudah*—Judah saved.

"Israel shall dwell safely."

*Ve-Yisra'el yishkon la-vetach*—Israel safe.

"This is his name whereby he shall be called."

*Ve-zeh-shemo asher-yiqre'o*—his name.

"YHWH Tzidqenu—YHWH is our righteousness."

*YHWH Tzidqenu*—YHWH our Righteousness.

**Messianic Title:**
*Tzemach* (Branch) is a messianic title (Isaiah 4:2; 11:1; Zechariah 3:8; 6:12). "YHWH our Righteousness" becomes the king's name.

**New Exodus (23:7-8):**
"They shall no more say: 'As YHWH lives, that brought up... out of... Egypt.'"

*Lo-yomru od chai-YHWH asher he'elah et-benei Yisra'el me-eretz Mitzrayim*—no more Egypt oath.

"But: 'As YHWH lives, that brought up... out of the north country.'"

*Ki im-chai-YHWH asher he'elah... me-eretz tzafon*—north exodus. (Repeats 16:14-15)

**Against False Prophets (23:9-22):**
"My heart within me is broken."

*Nishbar libbi be-qirbi*—heart broken.

"All my bones shake."

*Raffu kol-atzmotai*—bones shake.

"I am like a drunken man."

*Hayiti ke-ish shikkor*—like drunk.

"Because of YHWH, and because of his holy words."

*Mippenei YHWH u-mippenei divrei qodsho*—because of holy words.

"The land is full of adulterers."

*Ki mena'afim male'ah ha-aretz*—full of adulterers.

"Both prophet and priest are profane."

*Ki gam-navi gam-kohen chanfu*—profane.

"In my house have I found their wickedness."

*Gam be-veiti matzati ra'atam*—wickedness in temple.

**The Key Verses (23:13-14):**
"I have seen unseemliness in the prophets of Samaria."

*U-vi-nevi'ei Shomeron ra'iti tiflah*—Samaria prophets.

"They prophesied by Baal."

*Hinabbu va-Ba'al*—Baal prophets.

"Caused my people Israel to err."

*Va-yat'u et-ammi et-Yisra'el*—caused error.

"In the prophets of Jerusalem I have seen a horrible thing."

*U-vi-nevi'ei Yerushalayim ra'iti sha'arurah*—horrible thing.

"They commit adultery, and walk in lies."

*Na'of ve-halokh ba-sheqer*—adultery and lies.

"They strengthen the hands of evil-doers."

*Ve-chizzequ yedei mere'im*—strengthen evildoers.

"None does return from his wickedness."

*Le-vilti-shuv ish me-ra'ato*—none returns.

"They are all of them become unto me as Sodom."

*Hayu-li khullam ke-Sedom*—like Sodom.

"The inhabitants thereof as Gomorrah."

*Ve-yoshvekha ka-Amorah*—like Gomorrah.

**The Key Verses (23:16-17):**
"Hearken not unto the words of the prophets that prophesy unto you."

*Al-tishme'u el-divrei ha-nevi'im ha-nibbe'im lakhem*—don't listen.

"They lead you unto vanity."

*Mavhilim hem etkhem*—lead to vanity.

"They speak a vision of their own heart."

*Chazon libbam yedabberu*—own heart vision.

"Not out of the mouth of YHWH."

*Lo mi-pi YHWH*—not from YHWH.

"'YHWH has said: You shall have peace.'"

*Dibber YHWH shalom yihyeh lakhem*—peace prophecy.

"'No evil shall come upon you.'"

*Lo-tavo aleikhem ra'ah*—no evil.

**The Key Verse (23:18):**
"Who has stood in the council of YHWH?"

*Ki mi amad be-sod YHWH*—who stood in council?

"That he should perceive and hear his word?"

*Ve-yar ve-yishma et-devaro*—perceive and hear?

"Who has attended to his word, and heard it?"

*Mi-hiqshiv devaro va-yishma*—who attended?

**Divine Council:**
True prophets have stood in YHWH's heavenly council (cf. 1 Kings 22:19-23; Isaiah 6).

**The Key Verses (23:21-22):**
"I sent not these prophets, yet they ran."

*Lo-shalachti et-ha-nevi'im ve-hem ratzu*—not sent, they ran.

"I spoke not unto them, yet they prophesied."

*Lo-dibbarti aleihem ve-hem nibba'u*—not spoke, they prophesied.

"If they had stood in my council."

*Ve-im-amdu be-sodi*—if stood in council.

"They had caused my people to hear my words."

*Ve-yashmi'u devarai et-ammi*—would cause hearing.

"Had turned them from their evil way."

*Ve-yeshivum mi-darkam ha-ra'ah*—would turn them.

**YHWH's Omnipresence (23:23-32):**
**The Key Verses (23:23-24):**
"Am I a God near at hand... and not a God afar off?"

*Ha-Elohei mi-qarov ani... ve-lo Elohei me-rachoq*—near and far.

"Can any hide himself in secret places that I shall not see him?"

*Im-yissater ish be-mistarim va-ani lo-er'ennu*—can't hide.

"Do not I fill heaven and earth?"

*Halo et-ha-shamayim ve-et-ha-aretz ani male*—fill heaven and earth.

"'I have dreamed, I have dreamed.'"

*Chalamti chalamti*—dream claims.

"Think to cause my people to forget my name by their dreams."

*Ha-choshevim le-hashki'ach et-ammi shemi ba-chalomotam*—forget name.

"As their fathers forgot my name for Baal."

*Ka-asher shakhechu avotam et-shemi la-Ba'al*—forgot for Baal.

**The Key Verses (23:28-29):**
"The prophet that has a dream, let him tell a dream."

*Ha-navi asher-itto chalom yesapper chalom*—tell dream.

"He that has my word, let him speak my word faithfully."

*Va-asher devari itto yedabber devari emet*—speak word faithfully.

"What is the straw to the wheat?"

*Mah-la-teven et-ha-bar*—straw vs. wheat.

**The Key Verse (23:29):**
"Is not my word like as fire?"

*Ha-lo khoh devari ka-esh*—word like fire.

"Like a hammer that breaks the rock in pieces?"

*U-khe-pattish yefotetz sela*—hammer breaking rock.

**YHWH's Word:**
Fire and hammer—powerful, not comfortable.

**The Key Verses (23:30-32):**
"I am against the prophets that steal my words."

*Hineni al-ha-nevi'im gonesvei devarai*—stealing words.

"That use their tongues, and say: 'He says.'"

*Ha-loqechim leshonam va-yin'amu ne'um*—using tongues.

"That prophesy lying dreams."

*Nevi'ei chalomot sheqer*—lying dreams.

"Cause my people to err by their lies."

*Va-yat'u et-ammi be-shiqreihem*—cause error.

"I sent them not, nor commanded them."

*Va-anokhi lo-shelachtim ve-lo tzivvitim*—not sent.

"Neither do they profit this people at all."

*Ve-ho'el lo-yo'ilu la-am ha-zeh*—no profit.

**Burden Wordplay (23:33-40):**
"'What is the burden of YHWH?'"

*Mah-massa YHWH*—what burden?

"'What burden! I will cast you off.'"

*Et-mah-massa ve-natashti etkhem*—wordplay on *massa* (burden/oracle).

**Wordplay:**
*Massa* means both "oracle/burden" and "something carried." YHWH turns their question into judgment—they are the burden he will cast off.

**Archetypal Layer:** Jeremiah 23 contains **woe to shepherds (23:1-4)**, **"I will raise unto David a righteous Branch... YHWH Tzidqenu" (23:5-6)**, **"Who has stood in the council of YHWH?" (23:18)**, and **"Is not my word like as fire... like a hammer?" (23:29)**.

**Ethical Inversion Applied:**
- "Woe unto the shepherds that destroy and scatter"—woe to shepherds
- "You have scattered my flock, and driven them away"—scattered
- "I will gather the remnant of my flock"—gather remnant
- "I will set up shepherds over them, who shall feed them"—new shepherds
- "I will raise unto David a righteous Branch"—messianic Branch
- "He shall reign as king and prosper"—reign, prosper
- "Shall execute justice and righteousness"—justice
- "Judah shall be saved, and Israel shall dwell safely"—saved, safe
- "YHWH Tzidqenu—YHWH is our righteousness"—name
- "They shall no more say... out of... Egypt"—new exodus
- "Both prophet and priest are profane"—profane
- "In my house have I found their wickedness"—temple wickedness
- "In the prophets of Jerusalem I have seen a horrible thing"—horrible
- "They commit adultery, and walk in lies"—adultery, lies
- "They strengthen the hands of evil-doers"—strengthen evil
- "They are all of them become unto me as Sodom"—like Sodom
- "They speak a vision of their own heart"—own heart
- "'YHWH has said: You shall have peace'"—false peace
- "Who has stood in the council of YHWH?"—council question
- "I sent not these prophets, yet they ran"—unsent
- "If they had stood in my council"—condition
- "Am I a God near at hand... and not a God afar off?"—near and far
- "Can any hide himself in secret places?"—can't hide
- "Do not I fill heaven and earth?"—omnipresent
- "What is the straw to the wheat?"—straw vs. wheat
- "Is not my word like as fire?"—fire word
- "Like a hammer that breaks the rock in pieces?"—hammer word
- "I am against the prophets that steal my words"—against stealers
- "'What is the burden of YHWH?' 'What burden! I will cast you off'"—wordplay

**Modern Equivalent:** Jeremiah 23's "righteous Branch" (23:5-6) with the name "YHWH our Righteousness" is a key messianic prophecy. "Who has stood in the council of YHWH?" (23:18) distinguishes true from false prophets. "Is not my word like as fire... like a hammer?" (23:29) shows the power of authentic divine word.

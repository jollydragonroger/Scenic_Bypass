# Jeremiah 10: The Folly of Idols and the True God

*From the Hebrew: שִׁמְעוּ אֶת־הַדָּבָר (Shim'u Et-Ha-Davar) — Hear the Word*

---

## The Vanity of Idols (10:1-10)

**10:1** Hear the word which YHWH speaks unto you, O house of Israel.

**10:2** Thus says YHWH: "Learn not the way of the nations, and be not dismayed at the signs of heaven; for the nations are dismayed at them.

**10:3** "For the customs of the peoples are vanity; for it is but a tree which one cuts out of the forest, the work of the hands of the workman with the axe.

**10:4** "They deck it with silver and with gold, they fasten it with nails and with hammers, that it move not.

**10:5** "They are like a pillar in a garden of cucumbers, and speak not; they must needs be borne, because they cannot go. Be not afraid of them, for they cannot do evil, neither is it in them to do good."

**10:6** There is none like you, O YHWH; you are great, and your name is great in might.

**10:7** Who would not fear you, O King of the nations? For it befits you; forasmuch as among all the wise men of the nations, and in all their royalty, there is none like you.

**10:8** But they are altogether brutish and foolish: the teaching of idols! It is but a stock.

**10:9** Silver beaten into plates is brought from Tarshish, and gold from Uphaz, the work of the craftsman and of the hands of the goldsmith; blue and purple is their clothing; they are all the work of skilful men.

**10:10** But YHWH is the true God, he is the living God, and the everlasting King; at his wrath the earth trembles, and the nations cannot abide his indignation.

---

## The Creator God (10:11-16)

**10:11** Thus shall you say unto them: "The gods that have not made the heavens and the earth, these shall perish from the earth, and from under the heavens."

**10:12** He that has made the earth by his power, that has established the world by his wisdom, and has stretched out the heavens by his understanding;

**10:13** At the sound of his giving a multitude of waters in the heavens, when he causes the vapours to ascend from the ends of the earth; he makes lightnings for the rain, and brings forth the wind out of his treasuries.

**10:14** Every man is become brutish, without knowledge, every goldsmith is put to shame by the graven image, for his molten image is falsehood, and there is no breath in them.

**10:15** They are vanity, a work of delusion; in the time of their visitation they shall perish.

**10:16** Not like these is the portion of Jacob; for he is the former of all things, and Israel is the tribe of his inheritance; YHWH of hosts is his name.

---

## The Coming Exile (10:17-22)

**10:17** Gather up your wares from the ground, O you that abide in the siege.

**10:18** For thus says YHWH: "Behold, I will sling out the inhabitants of the land at this time, and will distress them, that they may feel it."

**10:19** Woe is me for my hurt! My wound is grievous; but I said: "This is but a sickness, and I must bear it."

**10:20** My tent is spoiled, and all my cords are broken; my children are gone forth of me, and they are not; there is none to stretch forth my tent any more, and to set up my curtains.

**10:21** For the shepherds are become brutish, and have not inquired of YHWH; therefore they have not prospered, and all their flock is scattered.

**10:22** Hark! A report, behold, it comes, and a great commotion out of the north country, to make the cities of Judah desolate, a dwelling-place of jackals.

---

## Jeremiah's Prayer (10:23-25)

**10:23** O YHWH, I know that man's way is not his own; it is not in man to direct his steps as he walks.

**10:24** O YHWH, correct me, but in measure; not in your anger, lest you diminish me.

**10:25** Pour out your fury upon the nations that know you not, and upon the families that call not on your name; for they have devoured Jacob, yea, they have devoured him and consumed him, and have laid waste his habitation.

---

## Synthesis Notes

**Key Restorations:**

**Warning Against Idols (10:1-5):**
"Learn not the way of the nations."

*El-derekh ha-goyim al-tilmadu*—don't learn nations' way.

"Be not dismayed at the signs of heaven."

*U-me-otot ha-shamayim al-techatu*—don't fear sky signs.

"The nations are dismayed at them."

*Ki-yechatu ha-goyim me-hemmah*—nations fear them.

"The customs of the peoples are vanity."

*Ki chuqqot ha-ammim hevel hu*—customs = vanity.

"It is but a tree which one cuts out of the forest."

*Ki-etz mi-ya'ar kerato*—cut tree.

"The work of the hands of the workman with the axe."

*Ma'aseh yedei-charash be-ma'atzad*—craftsman's work.

"They deck it with silver and with gold."

*Be-khesef u-ve-zahav yeya'fehu*—decorated.

"They fasten it with nails and with hammers, that it move not."

*Be-masmerot u-ve-maqqavot yechazzeqem ve-lo yafiq*—nailed down.

**The Key Verse (10:5):**
"They are like a pillar in a garden of cucumbers."

*Ke-tomer miqshah hemmah*—cucumber-field scarecrow.

"And speak not."

*Ve-lo yedabberu*—can't speak.

"They must needs be borne, because they cannot go."

*Naso yinnase'u ki lo yitz'adu*—must be carried.

"Be not afraid of them, for they cannot do evil."

*Al-tir'u mehem ki-lo yare'u*—can't do evil.

"Neither is it in them to do good."

*Ve-gam-heitiv ein otam*—can't do good.

**YHWH's Uniqueness (10:6-10):**
**The Key Verse (10:6):**
"There is none like you, O YHWH."

*Me-ein kamokha YHWH*—none like YHWH.

"You are great."

*Gadol attah*—you are great.

"Your name is great in might."

*Ve-gadol shimkha bi-gevurah*—great name.

**The Key Verse (10:7):**
"Who would not fear you, O King of the nations?"

*Mi lo yira'akha melekh ha-goyim*—who wouldn't fear?

"For it befits you."

*Ki lekha ya'atah*—it befits you.

"Among all the wise men of the nations, and in all their royalty, there is none like you."

*Ki ve-khol chakhmei ha-goyim u-ve-khol-malkutam me-ein kamokha*—none like among nations.

"The teaching of idols! It is but a stock."

*Musar havalim etz hu*—idol teaching = wood.

"Silver beaten into plates is brought from Tarshish."

*Kesef meruqqa mi-Tarshish yuva*—Tarshish silver.

"Gold from Uphaz."

*Ve-zahav me-Ufaz*—Uphaz gold.

"The work of the craftsman."

*Ma'aseh charash*—craftsman work.

"Blue and purple is their clothing."

*Tekhelet ve-argaman levusham*—blue and purple.

"They are all the work of skilful men."

*Ma'aseh chakhamim kullam*—skillful work.

**The Key Verse (10:10):**
"YHWH is the true God."

*Va-YHWH Elohim emet*—YHWH = true God.

"He is the living God."

*Hu Elohim chayyim*—living God.

"The everlasting King."

*U-Melekh olam*—everlasting King.

"At his wrath the earth trembles."

*Mi-qitzfo tir'ash ha-aretz*—earth trembles.

"The nations cannot abide his indignation."

*Ve-lo-yakhilu goyim za'mo*—nations can't endure.

**Creator God (10:11-16):**
**The Key Verse (10:11):**
"The gods that have not made the heavens and the earth, these shall perish."

*Elahayya di-shemayya ve-arqa la avadu ye'vadu me-ar'a u-min-techot shemayya elleh*—gods perish.

**Note:** 10:11 is in Aramaic, not Hebrew—perhaps a statement for exiles to make to their captors.

**The Key Verse (10:12):**
"He that has made the earth by his power."

*Oseh eretz be-khocho*—made earth by power.

"Has established the world by his wisdom."

*Mekhin tevel be-chokhmato*—established by wisdom.

"Has stretched out the heavens by his understanding."

*U-vi-tevunato natah shamayim*—stretched heavens.

"At the sound of his giving a multitude of waters in the heavens."

*Le-qol titto hamon mayim ba-shamayim*—water sound.

"He causes the vapours to ascend from the ends of the earth."

*Va-ya'aleh nesi'im mi-qetzeh ha-aretz*—vapours ascend.

"He makes lightnings for the rain."

*Beraqim la-matar asah*—lightning for rain.

"Brings forth the wind out of his treasuries."

*Va-yotze ruach me-otzrotav*—wind from treasuries.

"Every man is become brutish."

*Niv'ar kol-adam*—all brutish.

"Without knowledge."

*Mi-da'at*—without knowledge.

"Every goldsmith is put to shame by the graven image."

*Hovish kol-tzoref mi-pasel*—goldsmith shamed.

"His molten image is falsehood."

*Ki sheqer niseko*—falsehood.

"There is no breath in them."

*Ve-lo-ruach bam*—no breath.

"They are vanity."

*Hevel hemmah*—vanity.

"A work of delusion."

*Ma'aseh ta'tu'im*—delusion work.

"In the time of their visitation they shall perish."

*Be-et pequddatam yovedu*—perish at visitation.

**The Key Verse (10:16):**
"Not like these is the portion of Jacob."

*Lo-kha-elleh cheleq Ya'aqov*—Jacob's portion different.

"He is the former of all things."

*Ki-yotzer ha-kol hu*—former of all.

"Israel is the tribe of his inheritance."

*Ve-Yisra'el shevet nachalato*—Israel = inheritance.

"YHWH of hosts is his name."

*YHWH Tzeva'ot shemo*—YHWH of hosts.

**Coming Exile (10:17-22):**
"Gather up your wares from the ground."

*Isfi me-eretz kin'atek*—gather belongings.

"O you that abide in the siege."

*Yoshevet ba-matzor*—besieged one.

"I will sling out the inhabitants of the land."

*Hineni qola et-yoshevei ha-aretz*—sling out.

"Will distress them, that they may feel it."

*Ve-hatzaroti lahem lema'an yimtza'u*—distress to feel.

"Woe is me for my hurt!"

*Oy li al-shivri*—woe for hurt.

"My wound is grievous."

*Nachelah makkati*—grievous wound.

"'This is but a sickness, and I must bear it.'"

*Akh zeh choli ve-essa'ennu*—sickness to bear.

"My tent is spoiled."

*Oholi shuddad*—tent spoiled.

"All my cords are broken."

*Ve-khol-meytarai nittaqu*—cords broken.

"My children are gone forth of me."

*Banai yetza'uni ve-einam*—children gone.

"There is none to stretch forth my tent any more."

*Ein noteh-od oholi*—none stretches tent.

"To set up my curtains."

*U-meqim yeri'otai*—none sets curtains.

"The shepherds are become brutish."

*Ki niv'aru ha-ro'im*—brutish shepherds.

"Have not inquired of YHWH."

*Ve-et-YHWH lo darashuu*—didn't seek YHWH.

"Therefore they have not prospered."

*Al-ken lo hiskkilu*—not prospered.

"All their flock is scattered."

*Ve-khol-mar'itam nafotzu*—flock scattered.

"A report... a great commotion out of the north country."

*Qol shemu'ah hinneh va'ah ve-ra'ash gadol me-eretz tzafon*—northern commotion.

"To make the cities of Judah desolate."

*Lasum et-arei Yehudah shemamah*—Judah desolate.

"A dwelling-place of jackals."

*Me'on tannim*—jackal dwelling.

**Jeremiah's Prayer (10:23-25):**
**The Key Verse (10:23):**
"O YHWH, I know that man's way is not his own."

*Yada'ti YHWH ki lo la-adam darko*—man's way not his own.

"It is not in man to direct his steps as he walks."

*Lo le-ish holekh le-hakhin et-tza'ado*—can't direct steps.

**The Key Verse (10:24):**
"O YHWH, correct me, but in measure."

*Yassreni YHWH akh be-mishpat*—correct in measure.

"Not in your anger."

*Al be-appekha*—not in anger.

"Lest you diminish me."

*Pen-tam'iteni*—lest diminish.

"Pour out your fury upon the nations that know you not."

*Shefokh chamatekha al-ha-goyim asher lo-yeda'ukha*—fury on unknowing nations.

"Upon the families that call not on your name."

*Ve-al mishpachot asher be-shimkha lo qara'u*—on non-callers.

"They have devoured Jacob."

*Ki-akhlu et-Ya'aqov*—devoured Jacob.

"Yea, they have devoured him and consumed him."

*Va-yakheluhu va-yekhulluhu*—consumed.

"Have laid waste his habitation."

*Ve-et-navehu heshammuu*—wasted habitation.

**Archetypal Layer:** Jeremiah 10 contains **the idol satire (10:3-5)**, **"YHWH is the true God, he is the living God, and the everlasting King" (10:10)**, **"He that has made the earth by his power" (10:12)**, and **"I know that man's way is not his own; it is not in man to direct his steps" (10:23)**.

**Ethical Inversion Applied:**
- "Learn not the way of the nations"—don't learn nations' ways
- "Be not dismayed at the signs of heaven"—no astrology fear
- "The customs of the peoples are vanity"—customs = vanity
- "It is but a tree which one cuts out of the forest"—cut tree
- "They deck it with silver and with gold"—decorated
- "They fasten it with nails and with hammers, that it move not"—nailed down
- "They are like a pillar in a garden of cucumbers, and speak not"—scarecrow
- "They must needs be borne, because they cannot go"—must be carried
- "Be not afraid of them, for they cannot do evil"—can't do evil
- "Neither is it in them to do good"—can't do good
- "There is none like you, O YHWH"—YHWH unique
- "Who would not fear you, O King of the nations?"—fear YHWH
- "YHWH is the true God, he is the living God, and the everlasting King"—true, living, everlasting
- "He that has made the earth by his power"—creator
- "Has established the world by his wisdom"—establisher
- "Has stretched out the heavens by his understanding"—stretcher
- "He makes lightnings for the rain, and brings forth the wind"—weather controller
- "Every man is become brutish, without knowledge"—brutish
- "His molten image is falsehood, and there is no breath in them"—no breath
- "Not like these is the portion of Jacob"—Jacob's portion different
- "He is the former of all things"—former of all
- "I will sling out the inhabitants of the land"—exile
- "The shepherds are become brutish, and have not inquired of YHWH"—brutish shepherds
- "I know that man's way is not his own"—man can't direct
- "It is not in man to direct his steps as he walks"—can't direct steps
- "Correct me, but in measure; not in your anger"—measured correction
- "Pour out your fury upon the nations that know you not"—fury on nations

**Modern Equivalent:** Jeremiah 10's idol satire parallels Isaiah 44:9-20. "I know that man's way is not his own" (10:23) is foundational for understanding human dependence on God. The Aramaic verse (10:11) is unique in Jeremiah.

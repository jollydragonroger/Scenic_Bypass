# Jeremiah 14: The Great Drought

*From the Hebrew: אֲשֶׁר הָיָה דְבַר־יְהוָה אֶל־יִרְמְיָהוּ עַל־דִּבְרֵי הַבַּצָּרוֹת (Asher Hayah Devar-YHWH El-Yirmeyahu Al-Divrei Ha-Batztzarot) — The Word of YHWH That Came to Jeremiah Concerning the Drought*

---

## The Drought Described (14:1-6)

**14:1** The word of YHWH that came to Jeremiah concerning the drought.

**14:2** "Judah mourns, and the gates thereof languish, they sit in black upon the ground; and the cry of Jerusalem is gone up.

**14:3** "And their nobles send their little ones for water: they come to the cisterns, and find no water; they return with their vessels empty; they are ashamed and confounded, and cover their heads.

**14:4** "Because of the ground which is cracked, for there has been no rain in the land, the plowmen are ashamed, they cover their heads.

**14:5** "Yea, the hind also in the field calves, and forsakes her young, because there is no grass.

**14:6** "And the wild asses stand on the high hills, they gasp for air like jackals; their eyes fail, because there is no herbage."

---

## The People's Confession and Plea (14:7-9)

**14:7** Though our iniquities testify against us, O YHWH, work for your name's sake; for our backslidings are many, we have sinned against you.

**14:8** O you hope of Israel, the savior thereof in time of trouble, why should you be as a stranger in the land, and as a wayfaring man that turns aside to tarry for a night?

**14:9** Why should you be as a man astonished, as a mighty man that cannot save? Yet you, O YHWH, are in the midst of us, and your name is called upon us; leave us not.

---

## YHWH's Rejection (14:10-12)

**14:10** Thus says YHWH unto this people: "Even so have they loved to wander, they have not refrained their feet; therefore YHWH does not accept them, now will he remember their iniquity, and punish their sins."

**14:11** And YHWH said unto me: "Pray not for this people for their good.

**14:12** "When they fast, I will not hear their cry; and when they offer burnt-offering and meal-offering, I will not accept them; but I will consume them by the sword, and by the famine, and by the pestilence."

---

## The False Prophets (14:13-16)

**14:13** Then said I: "Ah, Lord YHWH! Behold, the prophets say unto them: 'You shall not see the sword, neither shall you have famine; but I will give you assured peace in this place.'"

**14:14** Then YHWH said unto me: "The prophets prophesy lies in my name; I sent them not, neither have I commanded them, neither spoke I unto them; they prophesy unto you a lying vision, and divination, and a thing of nought, and the deceit of their own heart.

**14:15** "Therefore thus says YHWH concerning the prophets that prophesy in my name, and I sent them not, yet they say: 'Sword and famine shall not be in this land': by sword and famine shall those prophets be consumed.

**14:16** "And the people to whom they prophesy shall be cast out in the streets of Jerusalem because of the famine and the sword; and they shall have none to bury them, them, their wives, nor their sons, nor their daughters; for I will pour their wickedness upon them."

---

## Jeremiah's Lament (14:17-22)

**14:17** And you shall say this word unto them: "Let my eyes run down with tears night and day, and let them not cease; for the virgin daughter of my people is broken with a great breach, with a very grievous wound.

**14:18** "If I go forth into the field, then behold the slain with the sword! And if I enter into the city, then behold them that are sick with famine! For both the prophet and the priest go about in the land, and have no knowledge."

**14:19** Have you utterly rejected Judah? Has your soul loathed Zion? Why have you smitten us, and there is no healing for us? We looked for peace, but no good came; and for a time of healing, and behold terror!

**14:20** We acknowledge, O YHWH, our wickedness, and the iniquity of our fathers; for we have sinned against you.

**14:21** Do not abhor us, for your name's sake; do not dishonour the throne of your glory; remember, break not your covenant with us.

**14:22** Are there any among the vanities of the nations that can cause rain? Or can the heavens give showers? Are not you he, O YHWH our God, and do we not wait for you? For you have made all these things.

---

## Synthesis Notes

**Key Restorations:**

**Drought Description (14:1-6):**
"The word of YHWH... concerning the drought."

*Al-divrei ha-batztzarot*—concerning drought.

"Judah mourns."

*Avelah Yehudah*—Judah mourns.

"The gates thereof languish."

*U-she'arekha umelaluu*—gates languish.

"They sit in black upon the ground."

*Qaderu la-aretz*—sit in black/mourning.

"The cry of Jerusalem is gone up."

*Ve-tzavchat Yerushalayim alatah*—Jerusalem's cry rises.

"Their nobles send their little ones for water."

*Ve-addireichem shalchu tze'ireihem la-mayim*—nobles send young for water.

"They come to the cisterns, and find no water."

*Ba'u al-gevi'im lo matze'u mayim*—no water in cisterns.

"They return with their vessels empty."

*Shavu kheleihem reqam*—empty vessels.

"They are ashamed and confounded, and cover their heads."

*Boshu ve-hokhlemuu ve-chafu rosham*—ashamed, heads covered.

"The ground... is cracked."

*Ha-adamah chattah*—cracked ground.

"There has been no rain in the land."

*Ki lo-hayah geshem ba-aretz*—no rain.

"The plowmen are ashamed."

*Boshu ikkkarim*—farmers ashamed.

"The hind also in the field calves, and forsakes her young."

*Ki gam-ayyelet ba-sadeh yaladah ve-azov*—hind abandons fawn.

"Because there is no grass."

*Ki lo-hayah deshe*—no grass.

"The wild asses stand on the high hills."

*U-fera'im amdu al-shefayim*—wild donkeys on hills.

"They gasp for air like jackals."

*Sha'afu ruach ke-tannim*—gasp like jackals.

"Their eyes fail, because there is no herbage."

*Kalu eineihem ki-ein esev*—eyes fail, no herbage.

**People's Confession (14:7-9):**
"Though our iniquities testify against us."

*Im-avonoteinu anu vanu*—iniquities testify.

"Work for your name's sake."

*Aseh lema'an-shimkha*—act for name's sake.

"Our backslidings are many."

*Ki-rabbu meshuvotenu*—many backslidings.

"We have sinned against you."

*Lakh chatanu*—sinned against you.

**The Key Verse (14:8):**
"O you hope of Israel."

*Miqweh Yisra'el*—hope of Israel.

"The savior thereof in time of trouble."

*Moshi'o be-et tzarah*—savior in trouble.

"Why should you be as a stranger in the land?"

*Lammah tihyeh ke-ger ba-aretz*—why like stranger?

"As a wayfaring man that turns aside to tarry for a night?"

*Ve-khe-ore'ach natah lalun*—overnight guest.

**The Key Verse (14:9):**
"Why should you be as a man astonished?"

*Lammah tihyeh ke-ish nidham*—why astonished?

"As a mighty man that cannot save?"

*Ke-gibbor lo-yukhal le-hoshi'a*—can't save?

"You, O YHWH, are in the midst of us."

*Ve-attah ve-qirbenu YHWH*—YHWH in midst.

"Your name is called upon us."

*Ve-shimkha aleinu niqra*—name upon us.

"Leave us not."

*Al-tannichenu*—don't leave.

**YHWH's Rejection (14:10-12):**
"Even so have they loved to wander."

*Ken ahevu lanu'a*—loved wandering.

"They have not refrained their feet."

*Ragleihem lo chasakhuu*—didn't refrain feet.

"YHWH does not accept them."

*Va-YHWH lo ratzam*—not accepted.

"Now will he remember their iniquity."

*Attah yizkor avonam*—remember iniquity.

"Punish their sins."

*Ve-yifqod chattotam*—punish sins.

**The Key Verses (14:11-12):**
"Pray not for this people for their good."

*Al-titpallel be'ad-ha-am ha-zeh le-tovah*—don't pray. (Third time: 7:16; 11:14)

"When they fast, I will not hear their cry."

*Ki yatzumu einenni shome'a el-rinnatam*—won't hear fast.

"When they offer burnt-offering and meal-offering, I will not accept them."

*Ve-khi ya'alu olah u-minchah einenni rotzam*—won't accept offerings.

"I will consume them by the sword, and by the famine, and by the pestilence."

*Ki ba-cherev u-va-ra'av u-va-dever anokhi mekhallem*—sword, famine, pestilence.

**False Prophets (14:13-16):**
"The prophets say unto them: 'You shall not see the sword.'"

*Ha-nevi'im omerim lahem lo tir'u cherev*—no sword.

"'Neither shall you have famine.'"

*Ve-ra'av lo-yihyeh lakhem*—no famine.

"'I will give you assured peace in this place.'"

*Ki-shalom emet etten lakhem ba-maqom ha-zeh*—assured peace.

**The Key Verse (14:14):**
"The prophets prophesy lies in my name."

*Sheqer ha-nevi'im nivve'im bi-shemi*—lies in my name.

"I sent them not."

*Lo shelachtim*—not sent.

"Neither have I commanded them."

*Ve-lo tzivvitim*—not commanded.

"Neither spoke I unto them."

*Ve-lo dibbartii aleihem*—didn't speak.

"They prophesy unto you a lying vision."

*Chazon sheqer*—lying vision.

"Divination."

*Ve-qesem*—divination.

"A thing of nought."

*Ve-elil*—worthlessness.

"The deceit of their own heart."

*U-tarmit libbam*—heart deceit.

"By sword and famine shall those prophets be consumed."

*Ba-cherev u-va-ra'av yittammu ha-nevi'im ha-hemmah*—prophets consumed.

"The people to whom they prophesy shall be cast out."

*Ve-ha-am asher-hemmah nivve'im lahem yihyu mushlakhim*—people cast out.

"They shall have none to bury them."

*Ve-ein meqabber lahem*—none to bury.

"I will pour their wickedness upon them."

*Ve-shafakhtti aleihem et-ra'atam*—pour wickedness.

**Jeremiah's Lament (14:17-22):**
"Let my eyes run down with tears night and day."

*Teradnah einai dim'ah laylah ve-yomam*—tears day and night.

"Let them not cease."

*Ve-al-tidmena*—don't cease.

"The virgin daughter of my people is broken."

*Ki shever gadol nishberah betulat bat-ammi*—virgin broken.

"With a great breach, with a very grievous wound."

*Makkah nachelah me'od*—grievous wound.

"If I go forth into the field, then behold the slain with the sword!"

*Im yatzati ha-sadeh ve-hinneh challei-cherev*—sword slain.

"If I enter into the city, then behold them that are sick with famine!"

*Ve-im ba'ti ha-ir ve-hinneh tachalue'ei ra'av*—famine sick.

"Both the prophet and the priest go about in the land."

*Ki-gam-navi gam-kohen sacharu el-eretz*—prophet and priest wander.

"Have no knowledge."

*Ve-lo yada'u*—no knowledge.

**The Key Verse (14:19):**
"Have you utterly rejected Judah?"

*Ha-ma'os ma'asta et-Yehudah*—rejected Judah?

"Has your soul loathed Zion?"

*Im-be-Tziyyon ga'alah nafshekha*—loathed Zion?

"Why have you smitten us, and there is no healing for us?"

*Maddua hikkitanu ve-ein lanu marp'e*—smitten, no healing.

"We looked for peace, but no good came."

*Qavvoh le-shalom ve-ein tov*—expected peace.

"For a time of healing, and behold terror!"

*U-le-et marp'e ve-hinneh be'atah*—expected healing, got terror.

**The Key Verse (14:20):**
"We acknowledge, O YHWH, our wickedness."

*Yada'nu YHWH rish'enu*—acknowledge wickedness.

"The iniquity of our fathers."

*Avon avotenu*—fathers' iniquity.

"We have sinned against you."

*Ki chatanu lakh*—sinned against you.

**The Key Verse (14:21):**
"Do not abhor us, for your name's sake."

*Al-tina'atz lema'an-shimkha*—don't abhor.

"Do not dishonour the throne of your glory."

*Al-tenavvel kisse khevodekha*—don't dishonor throne.

"Remember, break not your covenant with us."

*Zekhor al-tafer berittkha ittanu*—don't break covenant.

**The Key Verse (14:22):**
"Are there any among the vanities of the nations that can cause rain?"

*Ha-yesh be-havlei ha-goyim magshimim*—can vanities rain?

"Can the heavens give showers?"

*Ve-im-ha-shamayim yittenu revivim*—can heavens shower?

"Are not you he, O YHWH our God?"

*Halo-attah hu YHWH Eloheinu*—you are he.

"Do we not wait for you?"

*U-neqavveh lakh*—we wait for you.

"You have made all these things."

*Ki-attah asita et-kol-elleh*—you made all.

**Archetypal Layer:** Jeremiah 14 contains **drought as divine judgment (14:1-6)**, **"O you hope of Israel, the savior thereof in time of trouble" (14:8)**, **"Pray not for this people" (14:11)**—third occurrence, and **condemnation of false prophets (14:13-16)**.

**Ethical Inversion Applied:**
- "The word of YHWH... concerning the drought"—drought oracle
- "Judah mourns, and the gates thereof languish"—mourning
- "They come to the cisterns, and find no water"—no water
- "The ground... is cracked, for there has been no rain"—cracked, no rain
- "The hind... calves, and forsakes her young"—animal suffering
- "The wild asses stand on the high hills, they gasp for air"—gasping
- "Though our iniquities testify against us"—confession
- "Work for your name's sake"—appeal to name
- "O you hope of Israel, the savior thereof in time of trouble"—hope/savior
- "Why should you be as a stranger in the land?"—YHWH as stranger
- "As a mighty man that cannot save?"—can't save
- "You, O YHWH, are in the midst of us"—YHWH present
- "Leave us not"—don't leave
- "They loved to wander, they have not refrained their feet"—loved wandering
- "YHWH does not accept them"—not accepted
- "Pray not for this people for their good"—don't pray
- "When they fast, I will not hear their cry"—won't hear fast
- "I will consume them by the sword, and by the famine, and by the pestilence"—sword, famine, pestilence
- "The prophets prophesy lies in my name"—lies in YHWH's name
- "I sent them not, neither have I commanded them"—not sent
- "They prophesy unto you a lying vision, and divination"—lying vision
- "By sword and famine shall those prophets be consumed"—prophets consumed
- "Let my eyes run down with tears night and day"—tears
- "Have you utterly rejected Judah?"—rejected?
- "We acknowledge, O YHWH, our wickedness"—acknowledge wickedness
- "Do not abhor us, for your name's sake"—don't abhor
- "Remember, break not your covenant with us"—don't break covenant
- "Are there any among the vanities of the nations that can cause rain?"—only YHWH rains

**Modern Equivalent:** Jeremiah 14 shows drought as covenant curse (Deuteronomy 28:23-24). The confession (14:7-9, 19-22) models repentance but is rejected because behavior hasn't changed. The false prophets' message of "assured peace" (14:13) contrasts with Jeremiah's "sword, famine, pestilence" (14:12).

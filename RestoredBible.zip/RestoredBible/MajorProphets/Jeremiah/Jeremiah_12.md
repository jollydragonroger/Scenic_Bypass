# Jeremiah 12: Why Do the Wicked Prosper?

*From the Hebrew: צַדִּיק אַתָּה יְהוָה (Tzaddiq Attah YHWH) — Righteous Are You, O YHWH*

---

## Jeremiah's Complaint (12:1-4)

**12:1** Righteous are you, O YHWH, when I contend with you; yet will I reason with you: Wherefore does the way of the wicked prosper? Wherefore are all they secure that deal very treacherously?

**12:2** You have planted them, yea, they have taken root; they grow, yea, they bring forth fruit; you are near in their mouth, and far from their reins.

**12:3** But you, O YHWH, know me, you see me, and try my heart toward you; pull them out like sheep for the slaughter, and prepare them for the day of slaughter.

**12:4** How long shall the land mourn, and the herbs of the whole field wither? For the wickedness of them that dwell therein, the beasts are consumed, and the birds; because they said: "He shall not see our latter end."

---

## YHWH's Answer (12:5-13)

**12:5** "If you have run with the footmen, and they have wearied you, then how can you contend with horses? And though in a land of peace you are secure, yet how will you do in the thicket of the Jordan?

**12:6** "For even your brethren, and the house of your father, even they have dealt treacherously with you, even they have cried aloud after you; believe them not, though they speak fair words unto you."

**12:7** "I have forsaken my house, I have cast off my heritage; I have given the dearly beloved of my soul into the hand of her enemies.

**12:8** "My heritage is become unto me as a lion in the forest; she has uttered her voice against me; therefore have I hated her.

**12:9** "Is my heritage unto me as a speckled bird of prey? Are the birds of prey against her round about? Come, assemble all the beasts of the field, bring them to devour.

**12:10** "Many shepherds have destroyed my vineyard, they have trodden my portion under foot, they have made my pleasant portion a desolate wilderness.

**12:11** "They have made it desolate, it mourns unto me, being desolate; the whole land is made desolate, because no man lays it to heart.

**12:12** "Upon all the high hills in the wilderness spoilers are come; for the sword of YHWH devours from the one end of the land even to the other end of the land; no flesh has peace.

**12:13** "They have sown wheat, and have reaped thorns; they have tired themselves to no profit; and you shall be ashamed of your increase, because of the fierce anger of YHWH."

---

## Promise to the Nations (12:14-17)

**12:14** Thus says YHWH: "As for all my evil neighbours, that touch the inheritance which I have caused my people Israel to inherit, behold, I will pluck them up from off their land, and will pluck up the house of Judah from among them.

**12:15** "And it shall come to pass, after I have plucked them up, I will again have compassion on them; and I will bring them back, every man to his heritage, and every man to his land.

**12:16** "And it shall come to pass, if they will diligently learn the ways of my people, to swear by my name: 'As YHWH lives,' even as they taught my people to swear by Baal, then shall they be built up in the midst of my people.

**12:17** "But if they will not hearken, then will I pluck up that nation, plucking up and destroying it," says YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Jeremiah's Complaint (12:1-4):**
**The Key Verse (12:1):**
"Righteous are you, O YHWH, when I contend with you."

*Tzaddiq attah YHWH ki ariv elekha*—YHWH is righteous.

"Yet will I reason with you."

*Akh mishpattim adabber otakh*—yet I'll reason.

"Wherefore does the way of the wicked prosper?"

*Maddua derekh resha'im tzalekhah*—why wicked prosper?

"Wherefore are all they secure that deal very treacherously?"

*Shallu kol-bogedei vaged*—treacherous secure?

**The Key Verse (12:2):**
"You have planted them, yea, they have taken root."

*Neta'tam gam-shoreshu*—planted, rooted.

"They grow, yea, they bring forth fruit."

*Yelkhu gam-asu feri*—grow, fruit.

"You are near in their mouth."

*Qarov attah be-fihem*—near in mouth.

"Far from their reins."

*Ve-rachoq mi-khilyoteihem*—far from kidneys (= heart).

**The Key Verse (12:3):**
"You, O YHWH, know me, you see me."

*Ve-attah YHWH yeda'tani tir'eni*—you know me.

"Try my heart toward you."

*U-vachanta libbi ittakh*—test my heart.

"Pull them out like sheep for the slaughter."

*Hattiqem ke-tzon li-tivchah*—sheep for slaughter.

"Prepare them for the day of slaughter."

*Ve-haqdishem le-yom haregah*—prepare for slaughter day.

"How long shall the land mourn?"

*Ad-matai te'eval ha-aretz*—land mourning.

"The herbs of the whole field wither."

*Ve-esev kol-ha-sadeh yivash*—herbs wither.

"For the wickedness of them that dwell therein."

*Me-ra'at yoshevei-vah*—because of wickedness.

"The beasts are consumed, and the birds."

*Saftah vehemot va-of*—beasts and birds consumed.

"'He shall not see our latter end.'"

*Lo yir'eh et-acharitenu*—"He won't see our end."

**YHWH's Answer (12:5-13):**
**The Key Verse (12:5):**
"If you have run with the footmen, and they have wearied you."

*Ki et-raglim ratzta va-yall'ukha*—footmen wearied you.

"Then how can you contend with horses?"

*Ve-eikh tetachare et-ha-susim*—how contend with horses?

"Though in a land of peace you are secure."

*U-ve-eretz shalom attah bote'ach*—secure in peace land.

"How will you do in the thicket of the Jordan?"

*Ve-eikh ta'aseh bi-ge'on ha-Yarden*—Jordan thicket.

**YHWH's Challenge:**
If current trials weary Jeremiah, worse is coming. "Running with horses" and "Jordan thicket" represent greater challenges ahead.

**The Key Verse (12:6):**
"Even your brethren, and the house of your father, even they have dealt treacherously with you."

*Ki gam-achekha u-veit-avikha gam-hemmah bagdu vakh*—family treachery.

"Even they have cried aloud after you."

*Gam-hemmah qare'u acharekha male*—cried after you.

"Believe them not, though they speak fair words unto you."

*Al-ta'amen bam ki-yedabberu elekha tovot*—don't believe fair words.

**The Key Verses (12:7-9):**
"I have forsaken my house."

*Azavti et-beiti*—house forsaken.

"I have cast off my heritage."

*Natashti et-nachalati*—heritage cast off.

"I have given the dearly beloved of my soul into the hand of her enemies."

*Natatti et-yedidut nafshi be-khaf oyevekha*—beloved given to enemies.

"My heritage is become unto me as a lion in the forest."

*Hayetah-li nachalati ke-aryeh ba-ya'ar*—heritage = lion.

"She has uttered her voice against me."

*Natnah alai be-qolah*—raised voice against me.

"Therefore have I hated her."

*Al-ken senetikha*—therefore hated.

"Is my heritage unto me as a speckled bird of prey?"

*Ha-ayit tzavu'a nachalati li*—speckled bird.

"Are the birds of prey against her round about?"

*Ha-ayit saviv alekha*—birds of prey around.

"Come, assemble all the beasts of the field."

*Lekhu isfu kol-chayyat ha-sadeh*—beasts assemble.

"Bring them to devour."

*Hetayu le-okhlah*—bring to devour.

**Vineyard Destruction (12:10-13):**
"Many shepherds have destroyed my vineyard."

*Ro'im rabbim shichatu karmi*—shepherds destroyed vineyard.

"They have trodden my portion under foot."

*Bossu et-chelqati*—trodden portion.

"They have made my pleasant portion a desolate wilderness."

*Natnu et-chelqat chemdati le-midbar shemamah*—pleasant portion = wilderness.

"They have made it desolate, it mourns unto me."

*Samah li-shemamah avelah alai shemamah*—desolate, mourning.

"The whole land is made desolate."

*Nashamah kol-ha-aretz*—whole land desolate.

"Because no man lays it to heart."

*Ki ein ish sam al-lev*—no one considers.

"Upon all the high hills in the wilderness spoilers are come."

*Al-kol-shefayim ba-midbar ba'u shodedim*—spoilers on hills.

"The sword of YHWH devours."

*Ki cherev la-YHWH okhelah*—YHWH's sword devours.

"From the one end of the land even to the other end."

*Mi-qetzeh-eretz ve-ad-qetzeh ha-aretz*—end to end.

"No flesh has peace."

*Ein shalom le-khol-basar*—no peace for flesh.

**The Key Verse (12:13):**
"They have sown wheat, and have reaped thorns."

*Zare'u chittim ve-qotzim qatzaru*—sown wheat, reaped thorns.

"They have tired themselves to no profit."

*Nechlu lo yo'ilu*—tired, no profit.

"You shall be ashamed of your increase."

*U-voshu mi-tevu'oteikhem*—ashamed of increase.

"Because of the fierce anger of YHWH."

*Me-charon af YHWH*—YHWH's fierce anger.

**Promise to Nations (12:14-17):**
"As for all my evil neighbours, that touch the inheritance."

*Kol-shekheinai ha-ra'im ha-noge'im ba-nachalah*—evil neighbors.

"I will pluck them up from off their land."

*Hineni notesham me-al admatam*—pluck up nations.

"Will pluck up the house of Judah from among them."

*Ve-et-beit Yehudah etosh mi-tokham*—pluck Judah from among.

**The Key Verse (12:15):**
"After I have plucked them up, I will again have compassion on them."

*Ve-hayah acharei noshti otam ashuv ve-richamtim*—compassion after plucking.

"I will bring them back, every man to his heritage."

*Va-hashivotim ish le-nachalato*—return to heritage.

"Every man to his land."

*Ve-ish le-artzo*—return to land.

**The Key Verse (12:16):**
"If they will diligently learn the ways of my people."

*Ve-hayah im-lammod yilmedu et-darkhei ammi*—learn my people's ways.

"To swear by my name: 'As YHWH lives.'"

*Le-hisshave'a vi-shemi chai-YHWH*—swear by YHWH.

"Even as they taught my people to swear by Baal."

*Ka-asher limmedu et-ammi le-hisshave'a va-Ba'al*—as taught Baal-swearing.

"Then shall they be built up in the midst of my people."

*Ve-nivnu be-tokh ammi*—built among my people.

"But if they will not hearken."

*Ve-im lo yishma'u*—if not hear.

"Then will I pluck up that nation, plucking up and destroying it."

*Ve-natashti et-ha-goy ha-hu natosh ve-abbed*—pluck and destroy.

**Archetypal Layer:** Jeremiah 12 contains the second "confession" of Jeremiah (12:1-4), **"Wherefore does the way of the wicked prosper?" (12:1)**, **"If you have run with the footmen, and they have wearied you, then how can you contend with horses?" (12:5)**, and **YHWH's lament over his own heritage (12:7-13)**.

**Ethical Inversion Applied:**
- "Righteous are you, O YHWH, when I contend with you"—YHWH righteous
- "Wherefore does the way of the wicked prosper?"—prosperity question
- "You have planted them, yea, they have taken root"—planted, rooted
- "You are near in their mouth, and far from their reins"—lip service
- "You, O YHWH, know me, you see me"—YHWH knows Jeremiah
- "Pull them out like sheep for the slaughter"—slaughter request
- "How long shall the land mourn?"—land mourning
- "'He shall not see our latter end'"—denial of judgment
- "If you have run with the footmen... how can you contend with horses?"—greater challenge
- "In a land of peace you are secure... how will you do in the thicket of the Jordan?"—greater hardship
- "Even your brethren... have dealt treacherously with you"—family treachery
- "Believe them not, though they speak fair words"—don't trust fair words
- "I have forsaken my house"—house forsaken
- "I have given the dearly beloved of my soul into the hand of her enemies"—beloved to enemies
- "My heritage is become unto me as a lion in the forest"—heritage hostile
- "Therefore have I hated her"—hated heritage
- "Many shepherds have destroyed my vineyard"—vineyard destroyed
- "They have sown wheat, and have reaped thorns"—sown wheat, reaped thorns
- "After I have plucked them up, I will again have compassion"—post-judgment compassion
- "If they will diligently learn the ways of my people"—nations can learn
- "Then shall they be built up in the midst of my people"—nations built up

**Modern Equivalent:** Jeremiah 12:1's "Wherefore does the way of the wicked prosper?" parallels Job's and the Psalms' laments (Psalm 73). YHWH's answer (12:5) challenges Jeremiah to prepare for worse. The promise to nations (12:14-17) shows even enemy nations can be restored if they learn YHWH's ways.

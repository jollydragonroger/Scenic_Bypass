# Jeremiah 40: Gedaliah Appointed Governor

*From the Hebrew: הַדָּבָר אֲשֶׁר הָיָה אֶל־יִרְמְיָהוּ (Ha-Davar Asher Hayah El-Yirmeyahu) — The Word That Came to Jeremiah*

---

## Jeremiah Freed at Ramah (40:1-6)

**40:1** The word which came to Jeremiah from YHWH, after that Nebuzaradan the captain of the guard had let him go from Ramah, when he had taken him being bound in chains among all the captives of Jerusalem and Judah, that were carried away captive unto Babylon.

**40:2** And the captain of the guard took Jeremiah, and said unto him: "YHWH your God pronounced this evil upon this place;

**40:3** "And YHWH has brought it, and done according as he spoke; because you have sinned against YHWH, and have not hearkened to his voice, therefore this thing is come upon you.

**40:4** "And now, behold, I loose you this day from the chains which are upon your hand. If it seem good unto you to come with me into Babylon, come, and I will look well unto you; but if it seem ill unto you to come with me into Babylon, forbear; behold, all the land is before you; whither it seems good and right unto you to go, there go."

**40:5** Now while he was not yet gone back—"Go back then to Gedaliah the son of Ahikam, the son of Shaphan, whom the king of Babylon has made governor over the cities of Judah, and dwell with him among the people; or go wheresoever it seems right unto you to go." So the captain of the guard gave him an allowance and a present, and let him go.

**40:6** Then went Jeremiah unto Gedaliah the son of Ahikam to Mizpah, and dwelt with him among the people that were left in the land.

---

## Gedaliah's Governance (40:7-12)

**40:7** Now when all the captains of the forces that were in the fields, they and their men, heard that the king of Babylon had made Gedaliah the son of Ahikam governor in the land, and had committed unto him men, and women, and children, and of the poorest of the land, of them that were not carried away captive to Babylon;

**40:8** Then they came to Gedaliah to Mizpah, even Ishmael the son of Nethaniah, and Johanan and Jonathan the sons of Kareah, and Seraiah the son of Tanhumeth, and the sons of Ephai the Netophathite, and Jezaniah the son of the Maacathite, they and their men.

**40:9** And Gedaliah the son of Ahikam the son of Shaphan swore unto them and to their men, saying: "Fear not to serve the Chaldeans; dwell in the land, and serve the king of Babylon, and it shall be well with you.

**40:10** "As for me, behold, I will dwell at Mizpah, to stand before the Chaldeans that may come unto us; but as for you, gather wine and summer fruits and oil, and put them in your vessels, and dwell in your cities that you have taken."

**40:11** Likewise when all the Jews that were in Moab, and among the children of Ammon, and in Edom, and that were in all the countries, heard that the king of Babylon had left a remnant of Judah, and that he had set over them Gedaliah the son of Ahikam, the son of Shaphan;

**40:12** Then all the Jews returned out of all places whither they were driven, and came to the land of Judah, to Gedaliah, unto Mizpah, and gathered wine and summer fruits in great abundance.

---

## Warning About Ishmael (40:13-16)

**40:13** Moreover Johanan the son of Kareah, and all the captains of the forces that were in the fields, came to Gedaliah to Mizpah,

**40:14** And said unto him: "Do you know at all that Baalis the king of the children of Ammon has sent Ishmael the son of Nethaniah to take your life?" But Gedaliah the son of Ahikam believed them not.

**40:15** Then Johanan the son of Kareah spoke to Gedaliah in Mizpah secretly, saying: "Let me go, I pray you, and I will slay Ishmael the son of Nethaniah, and no man shall know it; wherefore should he take your life, that all the Jews that are gathered unto you should be scattered, and the remnant of Judah perish?"

**40:16** But Gedaliah the son of Ahikam said unto Johanan the son of Kareah: "You shall not do this thing; for you speak falsely of Ishmael."

---

## Synthesis Notes

**Key Restorations:**

**Jeremiah at Ramah (40:1-5):**
"After that Nebuzaradan the captain of the guard had let him go from Ramah."

*Achar shallach oto Nevuzar'adan rav-tabbachim min-ha-Ramah*—freed at Ramah.

"When he had taken him being bound in chains."

*Be-qachto oto ve-hu asur ba-azziqim*—bound in chains.

"Among all the captives of Jerusalem and Judah."

*Be-tokh kol-galut Yerushalayim vi-Yhudah*—among captives.

"That were carried away captive unto Babylon."

*Ha-muglaim Bavelah*—being exiled.

**Ramah:**
Ramah was a staging point for deportees heading to Babylon—same location as Rachel's weeping (31:15).

**The Key Verses (40:2-3):**
"'YHWH your God pronounced this evil upon this place.'"

*YHWH Elohekha dibber et-ha-ra'ah ha-zot el-ha-maqom ha-zeh*—YHWH pronounced.

"'YHWH has brought it, and done according as he spoke.'"

*Va-yave va-ya'as YHWH ka-asher dibber*—YHWH did it.

"'Because you have sinned against YHWH.'"

*Ki-chata'tem la-YHWH*—you sinned.

"'Have not hearkened to his voice.'"

*Ve-lo-shema'tem be-qolo*—didn't hear.

"'Therefore this thing is come upon you.'"

*Va-yehi lakhem ha-davar ha-zeh*—this happened.

**Pagan Recognition:**
A Babylonian officer acknowledges YHWH's sovereignty and Judah's sin.

**The Key Verses (40:4-5):**
"'I loose you this day from the chains which are upon your hand.'"

*Ve-attah hinneh pittachti otakh ha-yom min-ha-azziqim asher al-yadekha*—freed.

"'If it seem good unto you to come with me into Babylon, come.'"

*Im-tov be-einekha lavo itti Bavel bo*—come to Babylon.

"'I will look well unto you.'"

*Ve-asim et-eini alekha*—I'll watch over you.

"'If it seem ill unto you to come with me into Babylon, forbear.'"

*Ve-im-ra be-einekha lavo itti Bavel chadal*—or don't.

"'Behold, all the land is before you.'"

*Re'eh kol-ha-aretz lefanekha*—all land before you.

"'Whither it seems good and right unto you to go, there go.'"

*El-tov ve-el-ha-yashar be-einekha lalekhet sham lekh*—go where you wish.

"'Go back then to Gedaliah the son of Ahikam.'"

*Shuv el-Gedalyahu ben-Achiqam*—go to Gedaliah.

"'Whom the king of Babylon has made governor over the cities of Judah.'"

*Asher hifqid melekh-Bavel be-arei Yehudah*—Babylon's governor.

"'Dwell with him among the people.'"

*U-shev itto be-tokh ha-am*—dwell with him.

"The captain of the guard gave him an allowance and a present."

*Va-yitten-lo rav-tabbachim aruchah u-mas'et*—provisions and gift.

"Let him go."

*Va-yeshallechehu*—released.

**Jeremiah's Choice (40:6):**
"Then went Jeremiah unto Gedaliah the son of Ahikam to Mizpah."

*Va-yavo Yirmeyahu el-Gedalyahu ben-Achiqam ha-Mitzpah*—to Mizpah.

"Dwelt with him among the people that were left in the land."

*Va-yeshev itto be-tokh ha-am ha-nish'arim ba-aretz*—stayed with people.

**Mizpah:**
Became the administrative center after Jerusalem's destruction—about 8 miles north of Jerusalem.

**Gedaliah's Governance (40:7-12):**
"All the captains of the forces that were in the fields."

*Kol-sarei ha-chayalim asher ba-sadeh*—field commanders.

"They and their men."

*Hemmah ve-ansheihem*—and men.

"Heard that the king of Babylon had made Gedaliah... governor in the land."

*Ki-hifqid melekh-Bavel et-Gedalyahu ben-Achiqam ba-aretz*—Gedaliah governor.

"Had committed unto him men, and women, and children."

*Ve-khi hifqid itto anashim ve-nashim ve-taf*—entrusted people.

"The poorest of the land."

*U-mi-dallat ha-aretz*—poorest.

"Of them that were not carried away captive to Babylon."

*Asher lo-hoglu Bavelah*—not exiled.

"They came to Gedaliah to Mizpah."

*Va-yavo'u el-Gedalyahu ha-Mitzpah*—came to Mizpah.

"Ishmael the son of Nethaniah."

*Ve-Yishma'el ben-Netanyahu*—Ishmael.

"Johanan and Jonathan the sons of Kareah."

*Ve-Yochanan ve-Yonatan benei Qareach*—Johanan, Jonathan.

"Seraiah the son of Tanhumeth."

*Ve-Serayah ben-Tanchumet*—Seraiah.

"The sons of Ephai the Netophathite."

*U-venei Eifai ha-Netofati*—Ephai's sons.

"Jezaniah the son of the Maacathite."

*Vi-Yzanyahu ben-ha-Ma'akhati*—Jezaniah.

**The Key Verses (40:9-10):**
"'Fear not to serve the Chaldeans.'"

*Al-tir'u me-avod et-ha-Kasdim*—don't fear serving.

"'Dwell in the land, and serve the king of Babylon.'"

*Shevu va-aretz ve-ivdu et-melekh Bavel*—dwell, serve.

"'It shall be well with you.'"

*Ve-yitav lakhem*—well with you.

"'As for me, behold, I will dwell at Mizpah.'"

*Va-ani hineni yoshev ba-Mitzpah*—I'll stay at Mizpah.

"'To stand before the Chaldeans that may come unto us.'"

*La'amod lifnei ha-Kasdim asher yavo'u eleinu*—represent to Babylon.

"'Gather wine and summer fruits and oil.'"

*Ve-attem isfu yayin ve-qayitz ve-shemen*—gather harvest.

"'Put them in your vessels.'"

*Ve-simu bi-kheleikhem*—in vessels.

"'Dwell in your cities that you have taken.'"

*U-shevu be-areikhem asher tefastem*—dwell in cities.

**Return of Refugees (40:11-12):**
"All the Jews that were in Moab."

*Kol-ha-Yehudim asher be-Mo'av*—in Moab.

"Among the children of Ammon, and in Edom."

*U-vi-venei Ammon u-ve-Edom*—Ammon, Edom.

"In all the countries."

*Va-asher be-khol ha-aratzot*—all countries.

"Heard that the king of Babylon had left a remnant of Judah."

*Ki-natan melekh-Bavel she'erit li-Yhudah*—remnant left.

"He had set over them Gedaliah."

*Ve-khi hifqid aleihem et-Gedalyahu*—Gedaliah over them.

"Then all the Jews returned out of all places."

*Va-yashuvu khol-ha-Yehudim mi-kol-ha-meqomot*—Jews returned.

"Came to the land of Judah, to Gedaliah, unto Mizpah."

*Va-yavo'u eretz Yehudah el-Gedalyahu ha-Mitzpah*—to Mizpah.

"Gathered wine and summer fruits in great abundance."

*Va-ya'asfu yayin ve-qayitz harbeh me'od*—abundant harvest.

**Warning About Ishmael (40:13-16):**
"Johanan the son of Kareah."

*Yochanan ben-Qareach*—Johanan.

"All the captains of the forces that were in the fields."

*Ve-khol-sarei ha-chayalim asher ba-sadeh*—field captains.

"Came to Gedaliah to Mizpah."

*Ba'u el-Gedalyahu ha-Mitzpah*—came.

**The Key Verse (40:14):**
"'Do you know at all that Baalis the king of the children of Ammon has sent Ishmael?'"

*Ha-yado'a teda ki Ba'alis melekh benei-Ammon shalach et-Yishma'el ben-Netanyahu*—Ammonite plot.

"'To take your life?'"

*Le-hakkotekha nafesh*—to kill you.

"But Gedaliah the son of Ahikam believed them not."

*Ve-lo-he'emin lahem Gedalyahu ben-Achiqam*—didn't believe.

**Ammonite Plot:**
Baalis, king of Ammon, sponsored Ishmael's assassination plot.

**The Key Verse (40:15):**
"'Let me go, I pray you, and I will slay Ishmael.'"

*Elkah-na ve-akkeh et-Yishma'el ben-Netanyahu*—let me kill Ishmael.

"'No man shall know it.'"

*Ve-ish lo yeda*—no one will know.

"'Wherefore should he take your life?'"

*Lammah yakkekka nafesh*—why should he kill you?

"'That all the Jews that are gathered unto you should be scattered.'"

*Ve-nafutzu kol-Yehudah ha-niqbatzim elekha*—Jews scattered.

"'The remnant of Judah perish?'"

*Ve-avedah she'erit Yehudah*—remnant perish.

**The Key Verse (40:16):**
"'You shall not do this thing.'"

*Al-ta'aseh et-ha-davar ha-zeh*—don't do this.

"'You speak falsely of Ishmael.'"

*Ki-sheqer attah dover el-Yishma'el*—speaking falsely.

**Tragic Trust:**
Gedaliah's trust in Ishmael would prove fatal.

**Archetypal Layer:** Jeremiah 40 contains **Nebuzaradan's recognition of YHWH's judgment (40:2-3)**, **Jeremiah's choice to stay with Gedaliah (40:6)**, **Gedaliah's hopeful governance (40:9-10)**, and **the warning about Ishmael that Gedaliah ignored (40:14-16)**.

**Ethical Inversion Applied:**
- "Nebuzaradan the captain of the guard had let him go from Ramah"—freed at Ramah
- "He had taken him being bound in chains among all the captives"—initially chained
- "'YHWH your God pronounced this evil upon this place'"—pagan recognizes YHWH
- "'YHWH has brought it, and done according as he spoke'"—YHWH did it
- "'Because you have sinned against YHWH'"—sin acknowledged
- "'Have not hearkened to his voice'"—didn't hear
- "'I loose you this day from the chains'"—freed
- "'If it seem good unto you to come with me into Babylon, come'"—Babylon option
- "'If it seem ill unto you... forbear'"—stay option
- "'All the land is before you'"—freedom
- "'Go back then to Gedaliah'"—suggested
- "'Whom the king of Babylon has made governor'"—Gedaliah governor
- "The captain of the guard gave him an allowance and a present"—provisions
- "Then went Jeremiah unto Gedaliah... to Mizpah"—chose Mizpah
- "Dwelt with him among the people that were left"—stayed
- "All the captains of the forces... heard that the king of Babylon had made Gedaliah... governor"—heard
- "They came to Gedaliah to Mizpah"—came
- "Ishmael the son of Nethaniah"—Ishmael
- "Johanan and Jonathan the sons of Kareah"—Johanan
- "'Fear not to serve the Chaldeans'"—don't fear
- "'Dwell in the land, and serve the king of Babylon'"—submit
- "'It shall be well with you'"—well
- "'Gather wine and summer fruits and oil'"—harvest
- "All the Jews that were in Moab... Ammon... Edom"—refugees
- "Heard that the king of Babylon had left a remnant"—heard
- "All the Jews returned... came to the land of Judah"—returned
- "Gathered wine and summer fruits in great abundance"—abundant
- "'Do you know at all that Baalis the king of... Ammon has sent Ishmael?'"—warning
- "'To take your life?'"—assassination plot
- "Gedaliah... believed them not"—didn't believe
- "'Let me go... and I will slay Ishmael'"—offer to kill
- "'No man shall know it'"—secret
- "'Wherefore should he take your life?'"—reason
- "'The remnant of Judah perish?'"—consequence
- "'You shall not do this thing'"—refused
- "'You speak falsely of Ishmael'"—dismissed warning

**Modern Equivalent:** Jeremiah 40 shows the fragile hope after Jerusalem's fall. Gedaliah's governance represented stability—refugees returned, harvests gathered. But his fatal trust in Ishmael would destroy this hope. Nebuzaradan's theological insight (40:2-3) is remarkable.

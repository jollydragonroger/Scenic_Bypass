# Jeremiah 52: Historical Appendix — The Fall of Jerusalem

*From the Hebrew: בֶּן־עֶשְׂרִים וְאַחַת שָׁנָה צִדְקִיָּהוּ בְמָלְכוֹ (Ben-Esrim Ve-Achat Shanah Tzidqiyyahu Be-Molkho) — Zedekiah Was Twenty-One Years Old When He Began to Reign*

---

## Zedekiah's Reign and Rebellion (52:1-3)

**52:1** Zedekiah was twenty and one years old when he began to reign; and he reigned eleven years in Jerusalem; and his mother's name was Hamutal the daughter of Jeremiah of Libnah.

**52:2** And he did that which was evil in the sight of YHWH, according to all that Jehoiakim had done.

**52:3** For through the anger of YHWH did it come to pass in Jerusalem and Judah, until he had cast them out from his presence. And Zedekiah rebelled against the king of Babylon.

---

## The Siege and Fall of Jerusalem (52:4-11)

**52:4** And it came to pass in the ninth year of his reign, in the tenth month, in the tenth day of the month, that Nebuchadrezzar king of Babylon came, he and all his army, against Jerusalem, and encamped against it; and they built forts against it round about.

**52:5** So the city was besieged unto the eleventh year of king Zedekiah.

**52:6** In the fourth month, in the ninth day of the month, the famine was sore in the city, so that there was no bread for the people of the land.

**52:7** Then a breach was made in the city, and all the men of war fled, and went forth out of the city by night by the way of the gate between the two walls, which was by the king's garden—now the Chaldeans were against the city round about—and they went by the way of the Arabah.

**52:8** But the army of the Chaldeans pursued after the king, and overtook Zedekiah in the plains of Jericho; and all his army was scattered from him.

**52:9** Then they took the king, and carried him up unto the king of Babylon to Riblah in the land of Hamath; and he gave judgment upon him.

**52:10** And the king of Babylon slew the sons of Zedekiah before his eyes; he slew also all the princes of Judah in Riblah.

**52:11** And he put out the eyes of Zedekiah; and the king of Babylon bound him in fetters, and carried him to Babylon, and put him in prison till the day of his death.

---

## The Destruction of the Temple and City (52:12-23)

**52:12** Now in the fifth month, in the tenth day of the month, which was the nineteenth year of king Nebuchadrezzar, king of Babylon, came Nebuzaradan the captain of the guard, who stood before the king of Babylon, into Jerusalem;

**52:13** And he burned the house of YHWH, and the king's house; and all the houses of Jerusalem, even every great man's house, burned he with fire.

**52:14** And all the army of the Chaldeans, that were with the captain of the guard, broke down all the walls of Jerusalem round about.

**52:15** Then Nebuzaradan the captain of the guard carried away captive of the poorest of the people, and the residue of the people that remained in the city, and those that fell away, that fell to the king of Babylon, and the residue of the multitude.

**52:16** But Nebuzaradan the captain of the guard left of the poorest of the land to be vinedressers and husbandmen.

**52:17** And the pillars of brass that were in the house of YHWH, and the bases and the brazen sea that were in the house of YHWH, did the Chaldeans break in pieces, and carried all the brass of them to Babylon.

**52:18** The pots also, and the shovels, and the snuffers, and the basins, and the pans, and all the vessels of brass wherewith they ministered, took they away.

**52:19** And the cups, and the fire-pans, and the basins, and the pots, and the candlesticks, and the pans, and the bowls—that which was of gold, in gold, and that which was of silver, in silver—the captain of the guard took away.

**52:20** The two pillars, the one sea, and the twelve brazen bulls that were under the bases, which king Solomon had made for the house of YHWH—the brass of all these vessels was without weight.

**52:21** And as for the pillars, the height of the one pillar was eighteen cubits; and a line of twelve cubits did compass it; and the thickness thereof was four fingers; it was hollow.

**52:22** And a capital of brass was upon it; and the height of the one capital was five cubits, with network and pomegranates upon the capital round about, all of brass; and the second pillar also had like unto these, and pomegranates.

**52:23** And there were ninety and six pomegranates on the outside; all the pomegranates were a hundred upon the network round about.

---

## The Captives and Executions (52:24-30)

**52:24** And the captain of the guard took Seraiah the chief priest, and Zephaniah the second priest, and the three keepers of the door;

**52:25** And out of the city he took an officer that was set over the men of war; and seven men of them that saw the king's face, that were found in the city; and the scribe of the captain of the host, who mustered the people of the land; and threescore men of the people of the land, that were found in the midst of the city.

**52:26** And Nebuzaradan the captain of the guard took them, and brought them to the king of Babylon to Riblah.

**52:27** And the king of Babylon smote them, and put them to death at Riblah in the land of Hamath. So Judah was carried away captive out of his land.

**52:28** This is the people whom Nebuchadrezzar carried away captive: in the seventh year three thousand Jews and three and twenty;

**52:29** In the eighteenth year of Nebuchadrezzar, from Jerusalem, eight hundred thirty and two persons;

**52:30** In the three and twentieth year of Nebuchadrezzar Nebuzaradan the captain of the guard carried away captive of the Jews seven hundred forty and five persons; all the persons were four thousand and six hundred.

---

## Jehoiachin Released (52:31-34)

**52:31** And it came to pass in the seven and thirtieth year of the captivity of Jehoiachin king of Judah, in the twelfth month, in the five and twentieth day of the month, that Evil-merodach king of Babylon, in the first year of his reign, lifted up the head of Jehoiachin king of Judah, and brought him forth out of prison.

**52:32** And he spoke kindly to him, and set his throne above the throne of the kings that were with him in Babylon.

**52:33** And he changed his prison garments, and did eat bread before him continually all the days of his life.

**52:34** And for his allowance, there was a continual allowance given him of the king of Babylon, every day a portion, until the day of his death, all the days of his life.

---

## Synthesis Notes

**Key Restorations:**

**Zedekiah's Reign (52:1-3):**
"Zedekiah was twenty and one years old when he began to reign."

*Ben-esrim ve-achat shanah Tzidqiyyahu be-molkho*—21 years old.

"He reigned eleven years in Jerusalem."

*Ve-achat esreh shanah malakh bi-Yrushalayim*—11 years (597-586 BCE).

"His mother's name was Hamutal the daughter of Jeremiah of Libnah."

*Ve-shem immo Chamutal bat-Yirmeyahu mi-Livnah*—Hamutal.

**Same Mother as Jehoahaz:**
Zedekiah and Jehoahaz had the same mother (2 Kings 23:31; 24:18).

"He did that which was evil in the sight of YHWH."

*Va-ya'as ha-ra be-einei YHWH*—evil.

"According to all that Jehoiakim had done."

*Ke-khol asher-asah Yehoyaqim*—like Jehoiakim.

"Through the anger of YHWH did it come to pass in Jerusalem and Judah."

*Ki al-af YHWH hayetah bi-Yerushalayim u-vi-Yhudah*—YHWH's anger.

"Until he had cast them out from his presence."

*Ad-hishlikh otam me-al panav*—cast out.

"Zedekiah rebelled against the king of Babylon."

*Va-yimrod Tzidqiyyahu be-melekh Bavel*—rebelled.

**Siege Timeline (52:4-7):**
"In the ninth year of his reign, in the tenth month, in the tenth day."

*Ba-shanah ha-teshi'it le-molkho ba-chodesh ha-asiri ba-asor la-chodesh*—10 Tevet, 588 BCE.

"Nebuchadrezzar king of Babylon came... against Jerusalem."

*Ba Nevukhadre'zzar melekh-Bavel... al-Yerushalayim*—siege begins.

"They built forts against it round about."

*Va-yivnu alekha dayeq saviv*—siege works.

"The city was besieged unto the eleventh year of king Zedekiah."

*Va-tavo ha-ir ba-matzor ad ashtei esreh shanah la-melekh Tzidqiyyahu*—18-month siege.

"In the fourth month, in the ninth day of the month."

*Ba-chodesh ha-revi'i be-tish'ah la-chodesh*—9 Tammuz, 586 BCE.

"The famine was sore in the city."

*Va-yechezaq ha-ra'av ba-ir*—severe famine.

"There was no bread for the people of the land."

*Ve-lo-hayah lechem le-am ha-aretz*—no bread.

"A breach was made in the city."

*Va-tibbaqqa ha-ir*—wall breached.

"All the men of war fled."

*Ve-khol anshei ha-milchamah yivrechu*—fled.

"By the way of the gate between the two walls."

*Derekh sha'ar bein ha-chomotayim*—between walls.

"Which was by the king's garden."

*Asher al-gan ha-melekh*—king's garden.

"They went by the way of the Arabah."

*Va-yelkhu derekh ha-Aravah*—toward Jordan.

**Zedekiah Captured (52:8-11):**
"The army of the Chaldeans pursued after the king."

*Va-yirdefu cheil-Kasdim acharei ha-melekh*—pursued.

"Overtook Zedekiah in the plains of Jericho."

*Va-yassiguu et-Tzidqiyyahu be-arvot Yericho*—caught at Jericho.

"All his army was scattered from him."

*Ve-khol-cheilo nafutzu me-alav*—army scattered.

"They took the king... unto the king of Babylon to Riblah."

*Va-yiqqechu et-ha-melekh... el-melekh Bavel Rivlatah*—to Riblah.

"He gave judgment upon him."

*Va-yedabber itto mishpatim*—judged.

**The Key Verse (52:10):**
"The king of Babylon slew the sons of Zedekiah before his eyes."

*Va-yishchat melekh-Bavel et-benei Tzidqiyyahu le-einav*—sons killed.

"He slew also all the princes of Judah in Riblah."

*Ve-gam et-kol-sarei Yehudah shachat be-Rivlah*—princes killed.

**The Key Verse (52:11):**
"He put out the eyes of Zedekiah."

*Ve-et-einei Tzidqiyyahu ivver*—blinded.

"The king of Babylon bound him in fetters."

*Va-ya'asrehu ba-nechushtayim*—bronze chains.

"Carried him to Babylon."

*Va-yevi'ehu melekh-Bavel Bavelah*—to Babylon.

"Put him in prison till the day of his death."

*Va-yittenehu ve-veit ha-pequddot ad-yom moto*—prison until death.

**Temple Destruction (52:12-16):**
"In the fifth month, in the tenth day of the month."

*U-va-chodesh ha-chamishi be-asor la-chodesh*—10 Av.

"The nineteenth year of king Nebuchadrezzar."

*Hi shenat tesha-esreh shanah la-melekh Nevukhadre'zzar*—586 BCE.

"Nebuzaradan the captain of the guard."

*Ba Nevuzar'adan rav-tabbachim*—Nebuzaradan.

"Who stood before the king of Babylon."

*Omed lifnei melekh-Bavel*—served Babylon's king.

"He burned the house of YHWH."

*Va-yisrof et-beit YHWH*—burned temple.

"The king's house."

*Ve-et-beit ha-melekh*—palace.

"All the houses of Jerusalem."

*Ve-et-kol-battei Yerushalayim*—all houses.

"Every great man's house, burned he with fire."

*Ve-et-kol-beit gadol saraf ba-esh*—great houses burned.

"All the army of the Chaldeans... broke down all the walls of Jerusalem."

*Ve-et-kol-chomot Yerushalayim saviv natutzu kol-cheil Kasdim*—walls broken.

**Temple Vessels (52:17-23):**
"The pillars of brass that were in the house of YHWH."

*Ve-et-ammudei ha-nechoshet asher le-veit YHWH*—bronze pillars.

"The bases and the brazen sea."

*Ve-et-ha-mekhanot ve-et-yam ha-nechoshet*—bases, bronze sea.

"Did the Chaldeans break in pieces."

*Shiberu Kasdim*—broke.

"Carried all the brass of them to Babylon."

*Va-yis'u et-kol-nechushtam Bavel*—to Babylon.

"The pots... shovels... snuffers... basins... pans."

*Ve-et-ha-sirot ve-et-ha-ya'im ve-et-ha-mezammerot ve-et-ha-mizraqot ve-et-ha-kappot*—vessels.

"That which was of gold, in gold, and that which was of silver, in silver."

*Asher zahav zahav va-asher kesef kesef*—gold/silver.

"The two pillars, the one sea, and the twelve brazen bulls."

*Ha-ammudim shenayim ha-yam echad ve-ha-baqar shnem-asar nechoshet*—pillars, sea, bulls.

"Which king Solomon had made for the house of YHWH."

*Asher-asah ha-melekh Shelomoh le-veit YHWH*—Solomon made.

"The brass of all these vessels was without weight."

*Lo-hayah mishqal le-nechushtam kol-ha-kelim ha-elleh*—immeasurable.

"The height of the one pillar was eighteen cubits."

*Shemoneh esreh ammah qomat ha-ammud ha-echad*—18 cubits.

"A capital of brass was upon it."

*Ve-khoteret alav nechoshet*—capital.

"The height of the one capital was five cubits."

*Ve-qomat ha-khoteret chamesh ammot*—5 cubits.

"With network and pomegranates upon the capital."

*U-sevakhah ve-rimmonim al-ha-khoteret saviv*—network, pomegranates.

"Ninety and six pomegranates on the outside."

*Va-yihyu ha-rimmonim tish'im ve-shishah ruchah*—96 pomegranates.

"All the pomegranates were a hundred upon the network."

*Kol-ha-rimmonim me'ah al-ha-sevakhah saviv*—100 total.

**Executions (52:24-27):**
"The captain of the guard took Seraiah the chief priest."

*Va-yiqqach rav-tabbachim et-Serayah kohen ha-rosh*—chief priest taken.

"Zephaniah the second priest."

*Ve-et-Tzefanyahu kohen ha-mishneh*—second priest.

"The three keepers of the door."

*Ve-et-sheloshet shomerei ha-saf*—doorkeepers.

"An officer that was set over the men of war."

*Saris echad asher-hayah paqid al-anshei ha-milchamah*—military officer.

"Seven men of them that saw the king's face."

*Ve-shiv'ah anashim me-ro'ei fenei ha-melekh*—royal advisors.

"The scribe of the captain of the host."

*Ve-et sofer sar ha-tzava*—military scribe.

"Threescore men of the people of the land."

*Ve-shishshim ish me-am ha-aretz*—60 citizens.

"The king of Babylon smote them, and put them to death at Riblah."

*Va-yakkeh otam melekh-Bavel va-yemitem be-Rivlah*—executed.

"Judah was carried away captive out of his land."

*Va-yiggel Yehudah me-al admato*—exiled.

**Deportation Numbers (52:28-30):**
"In the seventh year three thousand Jews and three and twenty."

*Ba-shanah ha-shevi'it Yehudim sheloshet alafim ve-esrim u-sheloshah*—3,023 in 597 BCE.

"In the eighteenth year... eight hundred thirty and two persons."

*Bi-shnat shemoneh esreh li-Nevukhadre'zzar... nefesh shemoneh me'ot sheloshim u-shenayim*—832 in 586 BCE.

"In the three and twentieth year... seven hundred forty and five persons."

*Bi-shnat shalosh ve-esrim li-Nevukhadre'zzar... Yehudim sheva me'ot arba'im ve-chamishah*—745 in 582 BCE.

"All the persons were four thousand and six hundred."

*Kol-nefesh arba'at alafim ve-shesh me'ot*—4,600 total.

**Different Numbers:**
These numbers are smaller than 2 Kings 24-25, possibly counting only adult males.

**Jehoiachin Released (52:31-34):**
**The Key Verse (52:31):**
"In the seven and thirtieth year of the captivity of Jehoiachin king of Judah."

*Va-yehi bi-sheloshim va-sheva shanah le-galut Yehoyakhin melekh-Yehudah*—37th year of captivity.

"In the twelfth month, in the five and twentieth day."

*Ba-chodesh ha-shenim-asar be-esrim ve-chamishah la-chodesh*—25 Adar.

"Evil-merodach king of Babylon."

*Nasa Evil-Merodakh melekh Bavel*—Evil-merodach.

**Evil-merodach:**
Amel-Marduk, Nebuchadnezzar's son, reigned 562-560 BCE.

"In the first year of his reign."

*Bi-shnat molkho*—first year.

"Lifted up the head of Jehoiachin king of Judah."

*Et-rosh Yehoyakhin melekh-Yehudah*—lifted up.

"Brought him forth out of prison."

*Va-yotze oto mi-beit ha-keli*—released.

**The Key Verses (52:32-34):**
"He spoke kindly to him."

*Va-yedabber itto tovot*—spoke kindly.

"Set his throne above the throne of the kings that were with him in Babylon."

*Va-yitten et-kis'o mi-ma'al le-kise ha-melakhim asher itto be-Bavel*—throne above.

"He changed his prison garments."

*Ve-shinnah et-bigdei khil'o*—changed clothes.

"Did eat bread before him continually all the days of his life."

*Ve-akhal lechem lefanav tamid kol-yemei chayyav*—ate before him.

"For his allowance, there was a continual allowance given him of the king of Babylon."

*Ve-aruchato aruchat tamid nittenah-lo me-et melekh-Bavel*—daily allowance.

"Every day a portion, until the day of his death."

*Devar-yom be-yomo ad-yom moto*—until death.

"All the days of his life."

*Kol yemei chayyav*—all his life.

**Hope Amid Exile:**
The book ends with Jehoiachin's release—a sign of hope for the Davidic line.

**Archetypal Layer:** Jeremiah 52 is **an historical appendix** (nearly identical to 2 Kings 24:18-25:30), containing **the siege and fall of Jerusalem (52:4-11)**, **the destruction of the temple (52:12-14)**, **deportation numbers (52:28-30)**, and **Jehoiachin's release as a hopeful ending (52:31-34)**.

**Ethical Inversion Applied:**
- "Zedekiah was twenty and one years old"—21 years
- "He reigned eleven years in Jerusalem"—11 years
- "He did that which was evil in the sight of YHWH"—evil
- "Through the anger of YHWH did it come to pass"—YHWH's anger
- "Zedekiah rebelled against the king of Babylon"—rebelled
- "In the ninth year... in the tenth month, in the tenth day"—10 Tevet
- "Nebuchadrezzar king of Babylon came... against Jerusalem"—siege
- "The city was besieged unto the eleventh year"—18 months
- "In the fourth month, in the ninth day"—9 Tammuz
- "The famine was sore in the city"—famine
- "There was no bread for the people"—no bread
- "A breach was made in the city"—breached
- "All the men of war fled"—fled
- "By the way of the gate between the two walls"—escape route
- "They went by the way of the Arabah"—toward Jordan
- "Overtook Zedekiah in the plains of Jericho"—caught
- "All his army was scattered from him"—scattered
- "They took the king... to Riblah"—to Riblah
- "He gave judgment upon him"—judged
- "The king of Babylon slew the sons of Zedekiah before his eyes"—sons killed
- "He slew also all the princes of Judah"—princes killed
- "He put out the eyes of Zedekiah"—blinded
- "Bound him in fetters... carried him to Babylon"—to Babylon
- "Put him in prison till the day of his death"—prison
- "In the fifth month, in the tenth day"—10 Av
- "He burned the house of YHWH"—temple burned
- "The king's house"—palace burned
- "All the houses of Jerusalem"—all burned
- "Broke down all the walls of Jerusalem"—walls broken
- "The pillars of brass... the bases and the brazen sea"—temple vessels
- "Did the Chaldeans break in pieces"—broke
- "Carried all the brass of them to Babylon"—to Babylon
- "The captain of the guard took Seraiah the chief priest"—chief priest
- "The king of Babylon smote them, and put them to death"—executed
- "Judah was carried away captive out of his land"—exiled
- "In the seventh year three thousand Jews"—3,023 (597 BCE)
- "In the eighteenth year... eight hundred thirty and two"—832 (586 BCE)
- "In the three and twentieth year... seven hundred forty and five"—745 (582 BCE)
- "All the persons were four thousand and six hundred"—4,600 total
- "In the seven and thirtieth year of the captivity of Jehoiachin"—37th year
- "Evil-merodach king of Babylon, in the first year of his reign"—562 BCE
- "Lifted up the head of Jehoiachin king of Judah"—released
- "Brought him forth out of prison"—freed
- "He spoke kindly to him"—kindly
- "Set his throne above the throne of the kings"—honored
- "He changed his prison garments"—new clothes
- "Did eat bread before him continually"—daily food
- "A continual allowance given him... until the day of his death"—provision

**Modern Equivalent:** Jeremiah 52 closes the book with historical summary (parallel to 2 Kings 24-25). The ending with Jehoiachin's release (562 BCE) provides hope—the Davidic line survives. This editorial addition updates readers after Jeremiah's death.

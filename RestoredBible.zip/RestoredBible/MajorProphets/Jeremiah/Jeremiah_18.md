# Jeremiah 18: The Potter's House

*From the Hebrew: הַדָּבָר אֲשֶׁר הָיָה אֶל־יִרְמְיָהוּ (Ha-Davar Asher Hayah El-Yirmeyahu) — The Word That Came to Jeremiah*

---

## The Potter and the Clay (18:1-12)

**18:1** The word which came to Jeremiah from YHWH, saying:

**18:2** "Arise, and go down to the potter's house, and there I will cause you to hear my words."

**18:3** Then I went down to the potter's house, and, behold, he was at his work on the wheels.

**18:4** And whensoever the vessel that he made of the clay was marred in the hand of the potter, he made it again another vessel, as seemed good to the potter to make it.

**18:5** Then the word of YHWH came to me, saying:

**18:6** "O house of Israel, cannot I do with you as this potter?" says YHWH. "Behold, as the clay in the potter's hand, so are you in my hand, O house of Israel.

**18:7** "At one instant I may speak concerning a nation, and concerning a kingdom, to pluck up and to break down and to destroy it;

**18:8** "But if that nation turn from their evil, because of which I have spoken against it, I repent of the evil that I thought to do unto it.

**18:9** "And at one instant I may speak concerning a nation, and concerning a kingdom, to build and to plant it;

**18:10** "But if it do evil in my sight, that it hearken not to my voice, then I repent of the good, wherewith I said I would benefit it.

**18:11** "Now therefore do you speak to the men of Judah, and to the inhabitants of Jerusalem, saying: Thus says YHWH: Behold, I frame evil against you, and devise a device against you; return now every one from his evil way, and amend your ways and your doings."

**18:12** But they say: "There is no hope; for we will walk after our own devices, and we will do every one after the stubbornness of his evil heart."

---

## Israel's Unnatural Forsaking (18:13-17)

**18:13** Therefore thus says YHWH: "Ask now among the nations, who has heard such things; the virgin of Israel has done a very horrible thing.

**18:14** "Does the snow of Lebanon fail from the rock of the field? Or are the strange cold flowing waters plucked up?

**18:15** "For my people have forgotten me, they offer unto vanity; and they have been made to stumble in their ways, in the ancient paths, to walk in bypaths, in a way not cast up;

**18:16** "To make their land an astonishment, and a perpetual hissing; every one that passes thereby shall be astonished, and shake his head.

**18:17** "I will scatter them as with an east wind before the enemy; I will show them the back, and not the face, in the day of their calamity."

---

## Plot Against Jeremiah (18:18-23)

**18:18** Then said they: "Come, and let us devise devices against Jeremiah; for instruction shall not perish from the priest, nor counsel from the wise, nor the word from the prophet. Come, and let us smite him with the tongue, and let us not give heed to any of his words."

**18:19** Give heed to me, O YHWH, and hearken to the voice of them that contend with me.

**18:20** Shall evil be recompensed for good? For they have digged a pit for my soul. Remember how I stood before you to speak good for them, to turn away your wrath from them.

**18:21** Therefore deliver up their children to the famine, and hurl them to the power of the sword; and let their wives be bereaved of their children, and widows; and let their men be slain of death, and their young men smitten of the sword in battle.

**18:22** Let a cry be heard from their houses, when you shall bring a troop suddenly upon them; for they have digged a pit to take me, and hid snares for my feet.

**18:23** Yet, O YHWH, you know all their counsel against me to slay me; forgive not their iniquity, neither blot out their sin from your sight; but let them be made to stumble before you; deal you with them in the time of your anger.

---

## Synthesis Notes

**Key Restorations:**

**Potter's House (18:1-6):**
"Arise, and go down to the potter's house."

*Qum ve-yaradta beit ha-yotzer*—go to potter's house.

"There I will cause you to hear my words."

*Ve-shammah ashmi'akha et-devarai*—hear words there.

"I went down to the potter's house."

*Va-ered beit ha-yotzer*—went down.

"He was at his work on the wheels."

*Ve-hinnehu oseh melakah al-ha-ovnayim*—working at wheels.

**The Key Verse (18:4):**
"The vessel that he made of the clay was marred in the hand of the potter."

*Ve-nishchat ha-keli asher hu oseh ba-chomer be-yad ha-yotzer*—vessel marred.

"He made it again another vessel."

*Ve-shav va-ya'asehu keli acher*—made another vessel.

"As seemed good to the potter to make it."

*Ka-asher yashar be-einei ha-yotzer la'asot*—as seemed good.

**The Key Verse (18:6):**
"O house of Israel, cannot I do with you as this potter?"

*Ha-kha-yotzer ha-zeh lo-ukhal la'asot lakhem beit Yisra'el*—can't I do like potter?

"As the clay in the potter's hand, so are you in my hand."

*Hinneh kha-chomer be-yad ha-yotzer ken-attem be-yadi*—clay in hand.

**Divine Sovereignty:**
YHWH can remake Israel as potter remakes clay. This is quoted in Romans 9:20-21.

**Conditional Prophecy (18:7-10):**
**The Key Verses (18:7-8):**
"At one instant I may speak concerning a nation."

*Rega adabber al-goy ve-al-mamlakah*—speak concerning nation.

"To pluck up and to break down and to destroy it."

*Lintosh ve-lintotz u-le-ha'avid*—uproot, tear down, destroy.

"But if that nation turn from their evil."

*Ve-shav ha-goy ha-hu me-ra'ato*—if nation turns.

"I repent of the evil that I thought to do unto it."

*Ve-nichamti al-ha-ra'ah asher chashavti la'asot lo*—repent of evil.

**The Key Verses (18:9-10):**
"At one instant I may speak concerning a nation."

*Ve-rega adabber al-goy ve-al-mamlakah*—speak concerning nation.

"To build and to plant it."

*Livnot ve-linto'a*—build and plant.

"But if it do evil in my sight."

*Ve-asah ha-ra be-einai*—if does evil.

"That it hearken not to my voice."

*Le-vilti shemo'a be-qoli*—not hear voice.

"Then I repent of the good."

*Ve-nichamti al-ha-tovah*—repent of good.

"Wherewith I said I would benefit it."

*Asher amarti le-heitiv oto*—benefit withdrawn.

**Conditional Prophecy:**
Prophetic threats and promises are often conditional on response.

**Warning (18:11-12):**
"I frame evil against you."

*Hineni yotzer aleikhem ra'ah*—framing evil.

"Devise a device against you."

*Ve-choshev aleikhem machashavah*—devising plan.

"Return now every one from his evil way."

*Shuvu-na ish mi-darkko ha-ra'ah*—return from evil.

"Amend your ways and your doings."

*Ve-heitivu darkheikhem u-ma'aleleikhem*—amend ways.

**The Key Verse (18:12):**
"'There is no hope.'"

*No'ash*—no hope.

"'We will walk after our own devices.'"

*Ki-acharei machshevoteinu nelekh*—follow our devices.

"'We will do every one after the stubbornness of his evil heart.'"

*Ve-ish sherirut libbo-ha-ra na'aseh*—stubborn evil heart.

**Unnatural Forsaking (18:13-17):**
"Ask now among the nations, who has heard such things."

*She'alu-na va-goyim mi shama ke-elleh*—ask nations.

"The virgin of Israel has done a very horrible thing."

*Sha'arurah me'od asetah vetulat Yisra'el*—horrible thing.

**The Key Verse (18:14):**
"Does the snow of Lebanon fail from the rock of the field?"

*Ha-ya'azov mi-tzur sadai sheleg Levanon*—Lebanon snow fail?

"Are the strange cold flowing waters plucked up?"

*Im-yinnatesu mayim zarim qarim nozelim*—cold waters plucked?

**Nature's Constancy:**
Snow and springs don't abandon their nature—but Israel has.

**The Key Verse (18:15):**
"My people have forgotten me."

*Ki shekechani ammi*—forgot me.

"They offer unto vanity."

*La-shav yeqatteru*—offer to vanity.

"They have been made to stumble in their ways."

*Va-yakhshilum bi-darkheihem*—made to stumble.

"In the ancient paths."

*Sheveilei olam*—ancient paths.

"To walk in bypaths, in a way not cast up."

*Lalekhet netivot derekh lo selulah*—bypaths.

"I will scatter them as with an east wind."

*Ke-ruach-qadim afitzem*—east wind scatters.

"I will show them the back, and not the face."

*Oref ve-lo-fanim er'em*—back, not face.

"In the day of their calamity."

*Be-yom eidam*—calamity day.

**Plot Against Jeremiah (18:18-23):**
"'Let us devise devices against Jeremiah.'"

*Lekhu ve-nachshevah al-Yirmeyahu machashavot*—plot against Jeremiah.

"'Instruction shall not perish from the priest.'"

*Ki lo-toved torah mi-kohen*—Torah won't perish.

"'Nor counsel from the wise.'"

*Ve-etzah me-chakham*—counsel won't perish.

"'Nor the word from the prophet.'"

*Ve-davar mi-navi*—word won't perish.

"'Let us smite him with the tongue.'"

*Lekhu ve-nakkehhu va-lashon*—smite with tongue.

"'Let us not give heed to any of his words.'"

*Ve-al-naqshivah el-kol-devarav*—ignore his words.

**Jeremiah's Response (18:19-23):**
"Give heed to me, O YHWH."

*Haqshivah YHWH elai*—heed me.

"Hearken to the voice of them that contend with me."

*U-shema le-qol yerivai*—hear contenders.

**The Key Verse (18:20):**
"Shall evil be recompensed for good?"

*Ha-yeshullam tachat-tovah ra'ah*—evil for good?

"They have digged a pit for my soul."

*Ki-kharu shuchah le-nafshi*—pit for soul.

"Remember how I stood before you to speak good for them."

*Zekhor amdi lefanekha le-dabber aleihem tovah*—spoke good for them.

"To turn away your wrath from them."

*Le-hashiv et-chamatekha mehem*—turn wrath.

"Deliver up their children to the famine."

*Lakhen ten et-beneihem la-ra'av*—children to famine.

"Hurl them to the power of the sword."

*Ve-haggerem al-yedei-cherev*—to sword.

"Let their wives be bereaved of their children, and widows."

*Ve-tihenah neseihem shakkulot ve-almanot*—bereaved wives.

"Let their men be slain of death."

*Ve-ansheihem yihyu harugei mavet*—men slain.

"Their young men smitten of the sword in battle."

*Bachureihem mukkei-cherev ba-milchamah*—young men in battle.

"Let a cry be heard from their houses."

*Tisshama ze'aqah mi-batteihem*—cry from houses.

"When you shall bring a troop suddenly upon them."

*Ki-tavi aleihem gedud pit'om*—sudden troop.

"They have digged a pit to take me."

*Ki-kharu shuchah le-lokhdenni*—pit to take.

"Hid snares for my feet."

*U-fachim tamnu le-raglai*—snares hidden.

**The Key Verse (18:23):**
"You know all their counsel against me to slay me."

*Ve-attah YHWH yada'ta et-kol-atzatam alai la-mavet*—you know plot.

"Forgive not their iniquity."

*Al-tekhapper al-avonam*—don't forgive.

"Neither blot out their sin from your sight."

*Ve-chatta'tam mi-lefanekha al-timchi*—don't blot out.

"Let them be made to stumble before you."

*Ve-yihyu mukhashalim lefanekha*—let them stumble.

"Deal you with them in the time of your anger."

*Be-et appekha aseh vahem*—deal in anger.

**Imprecatory Prayer:**
Jeremiah prays for judgment on those who plot against him—similar to imprecatory psalms.

**Archetypal Layer:** Jeremiah 18 contains **the potter and clay (18:1-6)**—Romans 9:20-21, **conditional prophecy (18:7-10)**, **"'There is no hope... we will walk after our own devices'" (18:12)**, and **the fourth of Jeremiah's "confessions" (18:18-23)**.

**Ethical Inversion Applied:**
- "Arise, and go down to the potter's house"—potter visit
- "He was at his work on the wheels"—potter working
- "The vessel... was marred in the hand of the potter"—marred vessel
- "He made it again another vessel"—remade vessel
- "Cannot I do with you as this potter?"—divine sovereignty
- "As the clay in the potter's hand, so are you in my hand"—Romans 9:20-21
- "At one instant I may speak concerning a nation... to pluck up"—judgment conditional
- "But if that nation turn from their evil, I repent"—repentance changes outcome
- "At one instant I may speak... to build and to plant"—blessing conditional
- "But if it do evil in my sight... I repent of the good"—blessing revoked
- "I frame evil against you, and devise a device against you"—framing evil
- "Return now every one from his evil way"—call to return
- "'There is no hope'"—hopeless refusal
- "'We will walk after our own devices'"—stubborn devices
- "Ask now among the nations, who has heard such things"—unparalleled
- "Does the snow of Lebanon fail?"—nature constant
- "My people have forgotten me"—YHWH forgotten
- "They have been made to stumble in their ways, in the ancient paths"—ancient paths forsaken
- "I will scatter them as with an east wind"—east wind
- "I will show them the back, and not the face"—back shown
- "'Let us devise devices against Jeremiah'"—plot against
- "'Let us smite him with the tongue'"—tongue attack
- "Shall evil be recompensed for good?"—evil for good
- "They have digged a pit for my soul"—pit for Jeremiah
- "Remember how I stood before you to speak good for them"—Jeremiah interceded
- "Forgive not their iniquity"—imprecation
- "Deal you with them in the time of your anger"—anger request

**Modern Equivalent:** Jeremiah 18's potter and clay is quoted in Romans 9:20-21 for divine sovereignty. The conditional nature of prophecy (18:7-10) shows that prophetic threats can be averted by repentance. Israel's response ("There is no hope... we will walk after our own devices") shows hardened rejection.

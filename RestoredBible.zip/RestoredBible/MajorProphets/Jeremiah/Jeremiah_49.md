# Jeremiah 49: Oracles Against Ammon, Edom, Damascus, Kedar, Hazor, and Elam

*From the Hebrew: לִבְנֵי עַמּוֹן (Li-Vnei Ammon) — Concerning the Children of Ammon*

---

## Oracle Against Ammon (49:1-6)

**49:1** Of the children of Ammon. Thus says YHWH: "Has Israel no sons? Has he no heir? Why then does Malcam possess Gad, and his people dwell in the cities thereof?

**49:2** "Therefore, behold, the days come," says YHWH, "that I will cause an alarm of war to be heard against Rabbah of the children of Ammon; and it shall become a desolate mound, and her daughters shall be burned with fire; then shall Israel possess them that did possess him," says YHWH.

**49:3** "Wail, O Heshbon, for Ai is laid waste; cry, you daughters of Rabbah, gird you with sackcloth; lament, and run to and fro among the fences; for Malcam shall go into captivity, his priests and his princes together.

**49:4** "Wherefore do you glory in the valleys, your flowing valley, O backsliding daughter? That trusted in her treasures: 'Who shall come unto me?'

**49:5** "Behold, I will bring a terror upon you," says the Lord YHWH of hosts, "from all that are round about you; and you shall be driven out every man right forth, and there shall be none to gather up him that wanders.

**49:6** "But afterward I will bring back the captivity of the children of Ammon," says YHWH.

---

## Oracle Against Edom (49:7-22)

**49:7** Of Edom. Thus says YHWH of hosts: "Is wisdom no more in Teman? Is counsel perished from the prudent? Is their wisdom vanished?

**49:8** "Flee, turn back, dwell deep, O inhabitants of Dedan; for I will bring the calamity of Esau upon him, the time that I will visit him.

**49:9** "If grape-gatherers came to you, would they not leave some gleaning grapes? If thieves by night, would they not destroy only till they had enough?

**49:10** "But I have made Esau bare, I have uncovered his secret places, and he shall not be able to hide himself; his seed is spoiled, and his brethren, and his neighbours, and he is not.

**49:11** "Leave your fatherless children, I will preserve them alive; and let your widows trust in me."

**49:12** For thus says YHWH: "Behold, they to whom it pertained not to drink of the cup shall assuredly drink; and are you he that shall altogether go unpunished? You shall not go unpunished, but you shall surely drink.

**49:13** "For I have sworn by myself," says YHWH, "that Bozrah shall become an astonishment, a reproach, a waste, and a curse; and all the cities thereof shall be perpetual wastes."

**49:14** I have heard a message from YHWH, and an ambassador is sent among the nations: "Gather yourselves together, and come against her, and rise up to the battle."

**49:15** "For, behold, I make you small among the nations, and despised among men.

**49:16** "Your terribleness has deceived you, and the pride of your heart, O you that dwell in the clefts of the rock, that hold the height of the hill; though you should make your nest as high as the eagle, I will bring you down from there," says YHWH.

**49:17** "And Edom shall become an astonishment; every one that passes by it shall be astonished, and shall hiss at all the plagues thereof.

**49:18** "As in the overthrow of Sodom and Gomorrah and the neighbour cities thereof," says YHWH, "no man shall dwell there, neither shall any son of man sojourn therein.

**49:19** "Behold, he shall come up like a lion from the thicket of the Jordan against the strong habitation; for I will suddenly make him run away from her; and who so is chosen, him will I appoint over her; for who is like me? And who will appoint me a time? And who is that shepherd that will stand before me?"

**49:20** Therefore hear the counsel of YHWH, that he has taken against Edom; and his purposes, that he has purposed against the inhabitants of Teman: "Surely the least of the flock shall drag them away; surely he shall make their habitation desolate over them.

**49:21** "The earth quakes at the noise of their fall; there is a cry, the noise whereof is heard in the Red Sea.

**49:22** "Behold, he shall come up and fly as the vulture, and spread out his wings against Bozrah; and the heart of the mighty men of Edom at that day shall be as the heart of a woman in her pangs."

---

## Oracle Against Damascus (49:23-27)

**49:23** Of Damascus. "Hamath is ashamed, and Arpad; for they have heard evil tidings, they are melted away; there is trouble in the sea; it cannot be quiet.

**49:24** "Damascus is waxed feeble, she turns herself to flee, and trembling has seized on her; anguish and pangs have taken hold of her, as of a woman in travail.

**49:25** "'How is the city of praise not forsaken, the city of my joy?'

**49:26** "Therefore her young men shall fall in her broad places, and all the men of war shall be brought to silence in that day," says YHWH of hosts.

**49:27** "And I will kindle a fire in the wall of Damascus, and it shall devour the palaces of Ben-hadad."

---

## Oracle Against Kedar and Hazor (49:28-33)

**49:28** Of Kedar, and of the kingdoms of Hazor, which Nebuchadrezzar king of Babylon smote. Thus says YHWH: "Arise, go up unto Kedar, and spoil the children of the east.

**49:29** "Their tents and their flocks shall they take; they shall carry away for themselves their curtains, and all their vessels, and their camels; and they shall proclaim against them: 'Terror on every side.'

**49:30** "Flee, wander far off, dwell deep, O inhabitants of Hazor," says YHWH; "for Nebuchadrezzar king of Babylon has taken counsel against you, and has conceived a purpose against you.

**49:31** "Arise, get you up against a nation that is at ease, that dwells without care," says YHWH; "that has neither gates nor bars, that dwells alone.

**49:32** "And their camels shall be a booty, and the multitude of their cattle a spoil; and I will scatter unto all winds them that have the corners of their hair polled; and I will bring their calamity from every side of them," says YHWH.

**49:33** "And Hazor shall be a dwelling-place of jackals, a desolation forever; no man shall dwell there, neither shall any son of man sojourn therein."

---

## Oracle Against Elam (49:34-39)

**49:34** The word of YHWH that came to Jeremiah the prophet concerning Elam, in the beginning of the reign of Zedekiah king of Judah, saying:

**49:35** Thus says YHWH of hosts: "Behold, I will break the bow of Elam, the chief of their might.

**49:36** "And I will bring upon Elam the four winds from the four quarters of heaven, and will scatter them toward all those winds; and there shall be no nation whither the dispersed of Elam shall not come.

**49:37** "And I will cause Elam to be dismayed before their enemies, and before them that seek their life; and I will bring evil upon them, even my fierce anger," says YHWH; "and I will send the sword after them, till I have consumed them;

**49:38** "And I will set my throne in Elam, and will destroy from there king and princes," says YHWH.

**49:39** "But it shall come to pass in the end of days, that I will bring back the captivity of Elam," says YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Ammon (49:1-6):**
"'Has Israel no sons? Has he no heir?'"

*Ha-vanim ein le-Yisra'el im-yoresh ein lo*—no heirs?

"'Why then does Malcam possess Gad?'"

*Maddua yarash Malkam et-Gad*—Milcom/Malcam possesses.

**Malcam/Milcom:**
The national god of Ammon (1 Kings 11:5, 33). Ammon had occupied Israelite territory after 722 BCE.

"'I will cause an alarm of war to be heard against Rabbah.'"

*Ve-hishma'ti el-Rabbat benei-Ammon teru'at milchamah*—war against Rabbah.

"'It shall become a desolate mound.'"

*Ve-hayetah le-tel shemamah*—desolate mound.

"'Then shall Israel possess them that did possess him.'"

*Ve-yarash Yisra'el et-yoreshav*—Israel repossesses.

"'Malcam shall go into captivity.'"

*Ki Malkam ba-golah yelekh*—Milcom exiled.

**The Key Verse (49:6):**
"'Afterward I will bring back the captivity of the children of Ammon.'"

*Ve-acharei-khen ashiv et-shevut benei-Ammon*—Ammon restored.

**Edom (49:7-22):**
"'Is wisdom no more in Teman?'"

*Ha-ein od chokhmah be-Teiman*—no wisdom?

**Teman:**
Famous for wisdom—Eliphaz was from Teman (Job 2:11).

"'Is counsel perished from the prudent?'"

*Avdah etzah mi-banim*—counsel perished.

"'Flee, turn back, dwell deep, O inhabitants of Dedan.'"

*Nusu hafnu he'emiqu la-shevet yoshevei Dedan*—flee, dwell deep.

"'I will bring the calamity of Esau upon him.'"

*Ki eid Esav heveti alav*—Esau's calamity.

**The Key Verses (49:9-10):**
"'If grape-gatherers came to you, would they not leave some gleaning grapes?'"

*Im-botzrim ba'u lakh halo yash'iru olelot*—gleanings left.

"'If thieves by night, would they not destroy only till they had enough?'"

*Im-gannavim ba-laylah hishhitu dayyam*—thieves take enough.

"'But I have made Esau bare.'"

*Ki-ani chasafti et-Esav*—stripped bare.

"'I have uncovered his secret places.'"

*Gilleiti et-mistarav*—uncovered.

"'He shall not be able to hide himself.'"

*Ve-nechba lo yukhal*—can't hide.

**The Key Verse (49:11):**
"'Leave your fatherless children, I will preserve them alive.'"

*Azvah yetomekha ani achayeh*—orphans preserved.

"'Let your widows trust in me.'"

*Ve-almnotekha alai tivtachu*—widows trust.

**Remarkable:**
YHWH promises to care for Edom's orphans and widows.

**The Key Verse (49:12):**
"'They to whom it pertained not to drink of the cup shall assuredly drink.'"

*Hinneh asher-ein mishpatam lishtot ha-kos shato yishtu*—if others drink.

"'Are you he that shall altogether go unpunished?'"

*Ve-attah hu naqqeh tinnaqeh*—escape?

"'You shall surely drink.'"

*Ki shato tishteh*—surely drink.

**The Key Verse (49:16):**
"'Your terribleness has deceived you.'"

*Tiflatztekha hisshi otakh*—terror deceived you.

"'The pride of your heart.'"

*Zedon libbkha*—heart pride.

"'O you that dwell in the clefts of the rock.'"

*Shokhen be-chagvei ha-sela*—rock clefts.

"'That hold the height of the hill.'"

*Tofesi merom giv'ah*—hill heights.

"'Though you should make your nest as high as the eagle.'"

*Ki-tagbiha ka-nesher qinnekha*—eagle's nest.

"'I will bring you down from there.'"

*Mi-sham oridekha*—bring down.

**Petra:**
Edom's capital Petra ("rock") was carved into cliffs.

**The Key Verses (49:19-20):**
"'He shall come up like a lion from the thicket of the Jordan.'"

*Hinneh ke-aryeh ya'aleh mi-ge'on ha-Yarden*—lion from Jordan.

"'For I will suddenly make him run away from her.'"

*Ki-arga aritzennu me-alekha*—suddenly run.

"'Who is like me?'"

*Ki mi khamoni*—who like me?

"'Who will appoint me a time?'"

*U-mi yo'ideni*—appoint time?

"'Who is that shepherd that will stand before me?'"

*U-mi-zeh ro'eh asher ya'amod lefanai*—what shepherd stands?

**Damascus (49:23-27):**
"'Hamath is ashamed, and Arpad.'"

*Boshah Chamat ve-Arpad*—Hamath, Arpad shamed.

"'They have heard evil tidings.'"

*Ki-shemu'ah ra'ah sham'u*—evil tidings.

"'They are melted away.'"

*Namogu*—melted.

"'Damascus is waxed feeble.'"

*Raftah Dammeseq*—feeble.

"'She turns herself to flee.'"

*Hifnah lanus*—turns to flee.

"'Trembling has seized on her.'"

*Ve-retet hecheziqah*—trembling.

"''How is the city of praise not forsaken?''"

*Eikh lo-uzvah ir tehillah*—praise city.

"''The city of my joy?''"

*Qiryat mesos*—joy city.

"'I will kindle a fire in the wall of Damascus.'"

*Ve-hitztzatti esh be-chomat Dammeseq*—fire in wall.

"'It shall devour the palaces of Ben-hadad.'"

*Ve-akhelah armenot Ben-Hadad*—Ben-hadad's palaces.

**Kedar and Hazor (49:28-33):**
"'Arise, go up unto Kedar, and spoil the children of the east.'"

*Qumu alu el-Qedar ve-shaddu et-benei-qedem*—attack Kedar.

"'Their tents and their flocks shall they take.'"

*Aholeihem ve-tzonam yiqqachu*—take tents, flocks.

"'Their curtains, and all their vessels, and their camels.'"

*Yeri'oteihem ve-khol-keleihem u-gemaleihem*—curtains, vessels, camels.

"'They shall proclaim against them: Terror on every side.'"

*Ve-qare'u aleihem magor mi-ssaviv*—terror everywhere.

"'Flee, wander far off, dwell deep, O inhabitants of Hazor.'"

*Nusu neddu me'od he'miqu la-shevet yoshevei Chatzor*—flee, dwell deep.

"'Nebuchadrezzar king of Babylon has taken counsel against you.'"

*Ki-ya'atz aleikhem Nevukhadre'zzar melekh-Bavel etzah*—Babylon counsels.

"'A nation that is at ease, that dwells without care.'"

*Goy shaley yoshev la-vetach*—at ease.

"'That has neither gates nor bars.'"

*Lo-delatayim ve-lo-veriach lo*—no gates.

"'That dwells alone.'"

*Badad yishkonu*—dwells alone.

"'Their camels shall be a booty.'"

*Ve-hayu gemaleihem la-vaz*—camels as booty.

"'Them that have the corners of their hair polled.'"

*Qetzutzei fe'ah*—trimmed corners.

"'Hazor shall be a dwelling-place of jackals.'"

*Ve-hayetah Chatzor li-me'on tannim*—jackals' dwelling.

**Elam (49:34-39):**
"In the beginning of the reign of Zedekiah."

*Be-reshit mamlekhet Tzidqiyyahu*—Zedekiah's beginning.

"'I will break the bow of Elam.'"

*Hineni shover et-qeshet Eilam*—break bow.

**Elam:**
Famous for archers—breaking the bow = breaking military power.

"'The chief of their might.'"

*Reshit gevuratam*—chief strength.

"'I will bring upon Elam the four winds.'"

*Ve-heveti el-Eilam arba ruchot*—four winds.

"'From the four quarters of heaven.'"

*Me-arba qetzot ha-shamayim*—four quarters.

"'Will scatter them toward all those winds.'"

*Ve-zeritim le-khol ha-ruchot ha-elleh*—scatter.

"'I will set my throne in Elam.'"

*Ve-samti kis'i be-Eilam*—throne in Elam.

"'Will destroy from there king and princes.'"

*Ve-ha'avadti mi-sham melekh ve-sarim*—destroy king.

**The Key Verse (49:39):**
"'In the end of days, I will bring back the captivity of Elam.'"

*Ve-hayah be-acharit ha-yamim ashiv et-shevut Eilam*—Elam restored.

**Archetypal Layer:** Jeremiah 49 contains oracles against **Ammon (49:1-6)**, **Edom (49:7-22)**—the longest, with parallels to Obadiah, **Damascus (49:23-27)**, **Kedar and Hazor (49:28-33)**, and **Elam (49:34-39)**.

**Ethical Inversion Applied:**
- "'Has Israel no sons? Has he no heir?'"—rhetorical
- "'Why then does Malcam possess Gad?'"—Ammon occupied
- "'I will cause an alarm of war to be heard against Rabbah'"—war
- "'Malcam shall go into captivity'"—god exiled
- "'Afterward I will bring back the captivity of... Ammon'"—restoration
- "'Is wisdom no more in Teman?'"—wisdom question
- "'I will bring the calamity of Esau upon him'"—Esau's calamity
- "'If grape-gatherers came to you, would they not leave some gleaning?'"—worse than gleaners
- "'I have made Esau bare, I have uncovered his secret places'"—stripped
- "'Leave your fatherless children, I will preserve them alive'"—YHWH preserves
- "'They to whom it pertained not to drink of the cup shall assuredly drink'"—all drink
- "'Your terribleness has deceived you, and the pride of your heart'"—deceived by pride
- "'O you that dwell in the clefts of the rock'"—Petra
- "'Though you should make your nest as high as the eagle'"—eagle nest
- "'I will bring you down from there'"—brought down
- "'He shall come up like a lion from the thicket of the Jordan'"—lion
- "'Who is like me? And who will appoint me a time?'"—YHWH's challenge
- "'Hamath is ashamed, and Arpad'"—shamed
- "'Damascus is waxed feeble'"—feeble
- "'How is the city of praise not forsaken?'"—forsaken
- "'I will kindle a fire in the wall of Damascus'"—fire
- "'Arise, go up unto Kedar, and spoil the children of the east'"—attack
- "'Terror on every side'"—*magor missaviv*
- "'A nation that is at ease, that dwells without care'"—at ease
- "'That has neither gates nor bars'"—defenseless
- "'I will break the bow of Elam, the chief of their might'"—bow broken
- "'I will bring upon Elam the four winds'"—scattered
- "'I will set my throne in Elam'"—YHWH's throne
- "'In the end of days, I will bring back the captivity of Elam'"—restoration

**Modern Equivalent:** Jeremiah 49 gathers oracles against smaller nations. Edom's oracle (49:7-22) parallels Obadiah. The promise to care for Edom's orphans (49:11) shows compassion. Ammon, Elam receive restoration promises (49:6, 39).

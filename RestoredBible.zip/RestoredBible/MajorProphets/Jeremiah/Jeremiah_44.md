# Jeremiah 44: The Queen of Heaven Controversy

*From the Hebrew: הַדָּבָר אֲשֶׁר הָיָה אֶל־יִרְמְיָהוּ (Ha-Davar Asher Hayah El-Yirmeyahu) — The Word That Came to Jeremiah*

---

## Jeremiah's Warning in Egypt (44:1-14)

**44:1** The word that came to Jeremiah concerning all the Jews that dwelt in the land of Egypt, that dwelt at Migdol, and at Tahpanhes, and at Noph, and in the country of Pathros, saying:

**44:2** "Thus says YHWH of hosts, the God of Israel: You have seen all the evil that I have brought upon Jerusalem, and upon all the cities of Judah; and, behold, this day they are a desolation, and no man dwells therein;

**44:3** "Because of their wickedness which they have committed to provoke me, in that they went to offer, and to serve other gods, whom they knew not, neither they, nor you, nor your fathers.

**44:4** "Howbeit I sent unto you all my servants the prophets, sending them betimes and often, saying: 'Oh, do not this abominable thing that I hate.'

**44:5** "But they hearkened not, nor inclined their ear to turn from their wickedness, to burn no incense unto other gods.

**44:6** "Wherefore my fury and my anger was poured forth, and was kindled in the cities of Judah and in the streets of Jerusalem; and they are wasted and desolate, as at this day.

**44:7** "Therefore now thus says YHWH, the God of hosts, the God of Israel: Wherefore do you commit this great evil against your own souls, to cut off from you man and woman, infant and suckling, out of the midst of Judah, to leave you none remaining;

**44:8** "In that you provoke me with the works of your hands, offering unto other gods in the land of Egypt, whither you are gone to sojourn; that you may be cut off, and that you may be a curse and a reproach among all the nations of the earth?

**44:9** "Have you forgotten the wickedness of your fathers, and the wickedness of the kings of Judah, and the wickedness of their wives, and your own wickedness, and the wickedness of your wives, which they committed in the land of Judah, and in the streets of Jerusalem?

**44:10** "They are not humbled even unto this day, neither have they feared, nor walked in my law, nor in my statutes, that I set before you and before your fathers.

**44:11** "Therefore thus says YHWH of hosts, the God of Israel: Behold, I will set my face against you for evil, even to cut off all Judah.

**44:12** "And I will take the remnant of Judah, that have set their faces to go into the land of Egypt to sojourn there, and they shall all be consumed; in the land of Egypt shall they fall; they shall be consumed by the sword and by the famine; they shall die, from the least even unto the greatest, by the sword and by the famine; and they shall be an execration, and an astonishment, and a curse, and a reproach.

**44:13** "For I will punish them that dwell in the land of Egypt, as I have punished Jerusalem, by the sword, by the famine, and by the pestilence;

**44:14** "So that none of the remnant of Judah, that are gone into the land of Egypt to sojourn there, shall escape or remain, that they should return into the land of Judah, to which they have a desire to return to dwell there; for none shall return save such as shall escape."

---

## The People's Defiant Response (44:15-19)

**44:15** Then all the men who knew that their wives offered unto other gods, and all the women that stood by, a great assembly, even all the people that dwelt in the land of Egypt, in Pathros, answered Jeremiah, saying:

**44:16** "As for the word that you have spoken unto us in the name of YHWH, we will not hearken unto you.

**44:17** "But we will certainly perform every word that is gone forth out of our mouth, to offer unto the queen of heaven, and to pour out drink-offerings unto her, as we have done, we and our fathers, our kings and our princes, in the cities of Judah, and in the streets of Jerusalem; for then had we plenty of bread, and were well, and saw no evil.

**44:18** "But since we left off to offer to the queen of heaven, and to pour out drink-offerings unto her, we have wanted all things, and have been consumed by the sword and by the famine.

**44:19** "And when we offered to the queen of heaven, and poured out drink-offerings unto her, did we make her cakes to worship her, and pour out drink-offerings unto her, without our husbands?"

---

## Jeremiah's Reply (44:20-30)

**44:20** Then Jeremiah said unto all the people, to the men, and to the women, even to all the people that had given him that answer, saying:

**44:21** "The offering that you offered in the cities of Judah, and in the streets of Jerusalem, you and your fathers, your kings and your princes, and the people of the land, did not YHWH remember them, and came it not into his mind?

**44:22** "So that YHWH could no longer bear, because of the evil of your doings, and because of the abominations which you have committed; therefore is your land become a desolation, and an astonishment, and a curse, without an inhabitant, as at this day.

**44:23** "Because you have offered, and because you have sinned against YHWH, and have not hearkened to the voice of YHWH, nor walked in his law, nor in his statutes, nor in his testimonies; therefore this evil is happened unto you, as at this day."

**44:24** Moreover Jeremiah said unto all the people, and to all the women: "Hear the word of YHWH, all Judah that are in the land of Egypt:

**44:25** "Thus says YHWH of hosts, the God of Israel, saying: You and your wives have both spoken with your mouths, and with your hands have fulfilled it, saying: 'We will surely perform our vows that we have vowed, to offer to the queen of heaven, and to pour out drink-offerings unto her'; you will surely establish your vows, and surely perform your vows.

**44:26** "Therefore hear the word of YHWH, all Judah that dwell in the land of Egypt: Behold, I have sworn by my great name, says YHWH, that my name shall no more be named in the mouth of any man of Judah in all the land of Egypt, saying: 'As the Lord YHWH lives.'

**44:27** "Behold, I watch over them for evil, and not for good; and all the men of Judah that are in the land of Egypt shall be consumed by the sword and by the famine, until there be an end of them.

**44:28** "And they that escape the sword shall return out of the land of Egypt into the land of Judah, few in number; and all the remnant of Judah, that are gone into the land of Egypt to sojourn there, shall know whose word shall stand, mine, or theirs.

**44:29** "And this shall be the sign unto you," says YHWH, "that I will punish you in this place, that you may know that my words shall surely stand against you for evil:

**44:30** "Thus says YHWH: Behold, I will give Pharaoh Hophra king of Egypt into the hand of his enemies, and into the hand of them that seek his life; as I gave Zedekiah king of Judah into the hand of Nebuchadrezzar king of Babylon, his enemy, and that sought his life."

---

## Synthesis Notes

**Key Restorations:**

**Setting (44:1):**
"All the Jews that dwelt in the land of Egypt."

*El-kol-ha-Yehudim ha-yoshevim be-eretz Mitzrayim*—all Egyptian Jews.

"That dwelt at Migdol, and at Tahpanhes, and at Noph."

*Ha-yoshevim be-Migdol u-ve-Tachpancheis u-ve-Nof*—locations.

"In the country of Pathros."

*U-ve-eretz Patros*—Upper Egypt.

**Jewish Diaspora:**
Jews had scattered throughout Egypt—Delta and Upper Egypt.

**Warning (44:2-10):**
"'You have seen all the evil that I have brought upon Jerusalem.'"

*Re'item et kol-ha-ra'ah asher-heveti al-Yerushalayim*—seen evil.

"'Upon all the cities of Judah.'"

*Ve-al kol-arei Yehudah*—all Judah.

"'This day they are a desolation, and no man dwells therein.'"

*Ve-hinnam chorvah ha-yom ha-zeh ve-ein bahem yoshev*—desolation.

"'Because of their wickedness which they have committed.'"

*Mippenei ra'atam asher asu*—because of wickedness.

"'To provoke me, in that they went to offer, and to serve other gods.'"

*Le-hakh'iseni lalekhet le-qatter la'avod le-lohim acherim*—provoke with other gods.

"'Whom they knew not, neither they, nor you, nor your fathers.'"

*Asher lo yeda'um hemmah attem va-avoteikhem*—unknown gods.

"'I sent unto you all my servants the prophets.'"

*Va-eshlach aleikhem et-kol-avadai ha-nevi'im*—sent prophets.

"'Sending them betimes and often.'"

*Hashkem ve-shalo'ach*—persistently.

"'Oh, do not this abominable thing that I hate.'"

*Al-na ta'asu et-devar ha-to'evah ha-zot asher saneti*—don't do this.

"'They hearkened not, nor inclined their ear.'"

*Ve-lo sham'u ve-lo hittu et-oznam*—didn't hear.

"'To turn from their wickedness.'"

*Lashuv me-ra'atam*—turn from evil.

"'To burn no incense unto other gods.'"

*Le-vilti qatter le-lohim acherim*—stop burning incense.

"'My fury and my anger was poured forth.'"

*Va-tittakh chamati ve-appi*—fury poured.

"'They are wasted and desolate, as at this day.'"

*Va-tihyenah le-chorvah li-shemamah ke-ha-yom ha-zeh*—desolate.

**The Key Verses (44:7-8):**
"'Wherefore do you commit this great evil against your own souls?'"

*Lammah attem osim ra'ah gedolah el-nafshotekhem*—why great evil?

"'To cut off from you man and woman, infant and suckling.'"

*Le-hakhrit lakhem ish ve-ishah olel ve-yoneq*—cut off all.

"'To leave you none remaining.'"

*Le-vilti hoter lakhem she'erit*—no remnant.

"'You provoke me with the works of your hands.'"

*Le-hakh'is oti be-ma'asei yedeikhem*—provoke with works.

"'Offering unto other gods in the land of Egypt.'"

*Le-qatter le-lohim acherim be-eretz Mitzrayim*—incense in Egypt.

"'That you may be cut off.'"

*Lema'an hakhrit lakhem*—cut off.

"'That you may be a curse and a reproach among all the nations.'"

*Ve-li-heyot lakhem li-qelalah u-le-cherpah be-khol goyei ha-aretz*—curse.

"'Have you forgotten the wickedness of your fathers?'"

*Ha-shekachtem et-ra'ot avoteikhem*—forgotten?

"'The wickedness of the kings of Judah.'"

*Ve-et ra'ot malkhei Yehudah*—kings' evil.

"'The wickedness of their wives.'"

*Ve-et ra'ot nashav*—wives' evil.

"'Your own wickedness, and the wickedness of your wives.'"

*Ve-et ra'oteikhem ve-et ra'ot nesheikhem*—your evil.

"'They are not humbled even unto this day.'"

*Lo dukke'u ad ha-yom ha-zeh*—not humbled.

"'Neither have they feared, nor walked in my law.'"

*Ve-lo yare'u ve-lo halkhu be-torati u-ve-chuqqotai*—didn't fear or walk.

**Judgment (44:11-14):**
"'I will set my face against you for evil.'"

*Hineni sam panai bakhem le-ra'ah*—face against you.

"'Even to cut off all Judah.'"

*Ve-le-hakhrit et-kol-Yehudah*—cut off all.

"'The remnant of Judah, that have set their faces to go into... Egypt.'"

*Ve-laqachti et-she'erit Yehudah asher-samu peneihem lavo eretz-Mitzrayim*—remnant.

"'They shall all be consumed.'"

*Ve-tammu khulam*—consumed.

"'In the land of Egypt shall they fall.'"

*Be-eretz Mitzrayim yippolu*—fall in Egypt.

"'By the sword and by the famine.'"

*Ba-cherev ba-ra'av*—sword and famine.

"'They shall be an execration, and an astonishment, and a curse, and a reproach.'"

*Ve-hayu la-alah le-shammah ve-li-qelalah u-le-cherpah*—curse.

"'I will punish them that dwell in... Egypt, as I have punished Jerusalem.'"

*U-faqadti al-ha-yoshevim be-eretz Mitzrayim ka-asher paqadti al-Yerushalayim*—punish like Jerusalem.

"'None of the remnant of Judah... shall escape or remain.'"

*Ve-lo yihyeh palit ve-sarid li-she'erit Yehudah*—no escape.

"'That they should return into the land of Judah.'"

*La-shuv eretz Yehudah*—return.

"'To which they have a desire to return.'"

*Asher-hemmah menass'im et-nafsham lashuv*—desire to return.

"'None shall return save such as shall escape.'"

*Ki-lo yashuvu ki im-peletim*—only escapees.

**Defiant Response (44:15-19):**
"All the men who knew that their wives offered unto other gods."

*Kol-ha-anashim ha-yod'im ki-meqatterot neshehem le-lohim acherim*—knew wives offered.

"All the women that stood by, a great assembly."

*Ve-khol-ha-nashim ha-omedot qahal gadol*—great assembly.

"All the people that dwelt in... Egypt, in Pathros."

*Ve-khol-ha-am ha-yoshevim be-eretz Mitzrayim be-Patros*—Pathros.

**The Key Verse (44:16):**
"'As for the word that you have spoken unto us in the name of YHWH.'"

*Ha-davar asher dibbarta eleinu be-shem YHWH*—your word.

"'We will not hearken unto you.'"

*Einennu shom'im elekha*—won't hear.

**The Key Verses (44:17-18):**
"'We will certainly perform every word that is gone forth out of our mouth.'"

*Ki aso na'aseh et-kol-ha-davar asher-yatza mi-pinu*—will perform.

"'To offer unto the queen of heaven.'"

*Le-qatter li-melekhet ha-shamayim*—queen of heaven.

"'To pour out drink-offerings unto her.'"

*Ve-hassekh lah nesakhim*—drink offerings.

"'As we have done, we and our fathers, our kings and our princes.'"

*Ka-asher asinu anachnu va-avoteinu malkheinu ve-sareinu*—as before.

"'In the cities of Judah, and in the streets of Jerusalem.'"

*Be-arei Yehudah u-ve-chutzot Yerushalayim*—Judah/Jerusalem.

"'For then had we plenty of bread, and were well.'"

*Va-nisba lechem va-nihyeh tovim*—plenty and well.

"'Saw no evil.'"

*Ve-ra'ah lo ra'inu*—no evil.

"'But since we left off to offer to the queen of heaven.'"

*U-min-az chadlnu le-qatter li-melekhet ha-shamayim*—since stopped.

"'We have wanted all things.'"

*Chasarnu khol*—lacked everything.

"'Been consumed by the sword and by the famine.'"

*U-va-cherev u-va-ra'av tammnu*—consumed.

**Queen of Heaven:**
Ishtar/Astarte worship. The women blamed Josiah's reforms for their troubles.

**The Key Verse (44:19):**
"'When we offered to the queen of heaven... did we make her cakes to worship her... without our husbands?'"

*Ve-khi-anachnu meqatterot li-melekhet ha-shamayim... ha-mi-balladei anashenu asinu lah kawwanim le-ha'atzivah*—with husbands' approval.

**Jeremiah's Reply (44:20-30):**
"'The offering that you offered in the cities of Judah... did not YHWH remember them?'"

*Ha-lo et-ha-qitter asher qittartem... YHWH zakar otam*—YHWH remembered.

"'Came it not into his mind?'"

*Va-ta'aleh al-libbo*—came to mind.

"'YHWH could no longer bear.'"

*Ve-lo-yakhal YHWH od la-set*—couldn't bear.

"'Because of the evil of your doings.'"

*Mippenei ro'a ma'aleleikem*—evil doings.

"'Therefore is your land become a desolation.'"

*Va-tehi artzekhem le-chorvah*—desolation.

"'Because you have offered, and because you have sinned against YHWH.'"

*Mippenei asher qittartem va-asher chata'tem la-YHWH*—because offered/sinned.

"'Have not hearkened to the voice of YHWH.'"

*Ve-lo shema'tem be-qol YHWH*—didn't hear.

"'Nor walked in his law.'"

*U-ve-torato u-ve-chuqqotav u-ve-edotav lo halakhtem*—didn't walk.

"'Therefore this evil is happened unto you.'"

*Al-ken qare'ah etkhem ha-ra'ah ha-zot*—evil happened.

**The Key Verses (44:25-28):**
"'You and your wives have both spoken with your mouths.'"

*Attem ve-nesheikhem va-tedabbernah be-fikhem*—spoken.

"'With your hands have fulfilled it.'"

*U-vi-ydeikhem mille'ten*—fulfilled.

"''We will surely perform our vows... to offer to the queen of heaven.''"

*Aso na'aseh et-nedarenu asher nadarnu le-qatter li-melekhet ha-shamayim*—vows.

"'I have sworn by my great name,' says YHWH."

*Nishba'ti vi-shemi ha-gadol amar YHWH*—YHWH swears.

"'My name shall no more be named in the mouth of any man of Judah.'"

*Im-yihyeh shemi od niqra be-fi kol-ish Yehudah*—name not used.

"'In all the land of Egypt.'"

*Be-khol-eretz Mitzrayim*—all Egypt.

"'I watch over them for evil, and not for good.'"

*Hineni shoqed aleihem le-ra'ah ve-lo le-tovah*—watch for evil.

"'They that escape the sword shall return... few in number.'"

*U-feletei cherev yashuvu min-eretz Mitzrayim eretz Yehudah metei mispar*—few return.

"'All the remnant of Judah... shall know whose word shall stand, mine, or theirs.'"

*Ve-yad'u kol-she'erit Yehudah... devar-mi yaqum mimmeni u-mehem*—whose word stands.

**Sign of Pharaoh Hophra (44:29-30):**
"'This shall be the sign unto you.'"

*Ve-zot-lakhem ha-ot*—sign.

"'That I will punish you in this place.'"

*Ki-poqed ani aleikhem ba-maqom ha-zeh*—punish here.

"'That you may know that my words shall surely stand against you.'"

*Lema'an ted'u ki qom yaqumu devarai aleikhem le-ra'ah*—words stand.

"'I will give Pharaoh Hophra king of Egypt into the hand of his enemies.'"

*Hineni noten et-Par'oh Chofra melekh Mitzrayim be-yad oyvav*—Hophra given.

"'Into the hand of them that seek his life.'"

*U-ve-yad mevaqqeshei nafsho*—seekers of life.

"'As I gave Zedekiah king of Judah into the hand of Nebuchadrezzar.'"

*Ka-asher natatti et-Tzidqiyyahu melekh-Yehudah be-yad Nevukhadre'zzar*—like Zedekiah.

**Pharaoh Hophra:**
Hophra (Apries) was assassinated in 570 BCE by Amasis—fulfilling this prophecy.

**Archetypal Layer:** Jeremiah 44 contains **the women's defiant worship of the Queen of Heaven (44:17-19)**, **their claim that troubles began when they stopped (44:18)**, **"We will not hearken unto you" (44:16)**, and **the sign of Pharaoh Hophra's death (44:30)**.

**Ethical Inversion Applied:**
- "All the Jews that dwelt in the land of Egypt"—Egyptian diaspora
- "At Migdol, and at Tahpanhes, and at Noph, and in... Pathros"—locations
- "'You have seen all the evil that I have brought upon Jerusalem'"—seen evil
- "'They are a desolation, and no man dwells therein'"—desolation
- "'Because of their wickedness... to provoke me... serve other gods'"—cause
- "'I sent unto you all my servants the prophets'"—sent prophets
- "'Oh, do not this abominable thing that I hate'"—plea
- "'They hearkened not, nor inclined their ear'"—didn't hear
- "'My fury and my anger was poured forth'"—poured out
- "'Wherefore do you commit this great evil against your own souls?'"—self-harm
- "'You provoke me with the works of your hands'"—provoke
- "'Have you forgotten the wickedness of your fathers?'"—forgotten
- "'They are not humbled even unto this day'"—not humbled
- "'I will set my face against you for evil'"—face against
- "'They shall all be consumed'"—consumed
- "'They shall be an execration, and an astonishment, and a curse'"—curse
- "'None of the remnant... shall escape or remain'"—none escape
- "'We will not hearken unto you'"—defiance
- "'We will certainly perform every word... to offer unto the queen of heaven'"—vow to queen
- "'As we have done, we and our fathers, our kings'"—tradition
- "'For then had we plenty of bread, and were well'"—prosperity claim
- "'Since we left off to offer to the queen of heaven'"—blamed reforms
- "'We have wanted all things, and have been consumed'"—blamed stop
- "'Did we... without our husbands?'"—husbands knew
- "'The offering that you offered... did not YHWH remember?'"—YHWH remembered
- "'YHWH could no longer bear'"—couldn't bear
- "'You and your wives have both spoken with your mouths'"—spoken
- "'We will surely perform our vows to... the queen of heaven'"—vow
- "'I have sworn by my great name'"—YHWH swears
- "'My name shall no more be named in the mouth of any man of Judah'"—name withdrawn
- "'I watch over them for evil, and not for good'"—watch for evil
- "'All the remnant... shall know whose word shall stand, mine, or theirs'"—test
- "'I will give Pharaoh Hophra king of Egypt into the hand of his enemies'"—Hophra falls
- "'As I gave Zedekiah king of Judah into the hand of Nebuchadrezzar'"—like Zedekiah

**Modern Equivalent:** Jeremiah 44 shows the final confrontation. The women's defense of Queen of Heaven worship reveals syncretism justified by prosperity theology. Blaming Josiah's reforms for troubles inverts cause and effect. Hophra's assassination (570 BCE) fulfilled the sign.

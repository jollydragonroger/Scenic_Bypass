# Jeremiah 48: Oracle Against Moab

*From the Hebrew: לְמוֹאָב (Le-Mo'av) — Concerning Moab*

---

## Moab's Destruction (48:1-10)

**48:1** Of Moab. Thus says YHWH of hosts, the God of Israel: "Woe unto Nebo! For it is laid waste; Kiriathaim is put to shame, it is taken; Misgab is put to shame and dismayed.

**48:2** "The praise of Moab is no more; in Heshbon they have devised evil against her: 'Come, and let us cut her off from being a nation.' You also, O Madmen, shall be brought to silence; the sword shall pursue you.

**48:3** "Hark! A cry from Horonaim, spoiling and great destruction!

**48:4** "Moab is destroyed; her little ones have caused a cry to be heard.

**48:5** "For by the ascent of Luhith with continual weeping shall they go up; for in the going down of Horonaim they have heard the distress of the cry of destruction.

**48:6** "Flee, save your lives, and be like a tamarisk in the wilderness.

**48:7** "For, because you have trusted in your works and in your treasures, you also shall be taken; and Chemosh shall go forth into captivity, his priests and his princes together.

**48:8** "And the spoiler shall come upon every city, and no city shall escape; the valley also shall perish, and the plain shall be destroyed; as YHWH has spoken.

**48:9** "Give wings unto Moab, for she must fly and get away; and her cities shall become a desolation, without any to dwell therein.

**48:10** "Cursed be he that does the work of YHWH with a slack hand, and cursed be he that keeps back his sword from blood."

---

## Moab's Complacency (48:11-17)

**48:11** "Moab has been at ease from his youth, and he has settled on his lees, and has not been emptied from vessel to vessel, neither has he gone into captivity; therefore his taste remains in him, and his scent is not changed.

**48:12** "Therefore, behold, the days come," says YHWH, "that I will send unto him them that tilt up, and they shall tilt him up; and they shall empty his vessels, and break their bottles in pieces.

**48:13** "And Moab shall be ashamed of Chemosh, as the house of Israel was ashamed of Beth-el their confidence.

**48:14** "How say you: 'We are mighty men, and valiant men for the war'?

**48:15** "Moab is laid waste, and they are gone up into her cities, and his chosen young men are gone down to the slaughter," says the King, whose name is YHWH of hosts.

**48:16** "The calamity of Moab is near to come, and his affliction hastens fast.

**48:17** "Bemoan him, all you that are round about him, and all you that know his name; say: 'How is the strong staff broken, the beautiful rod!'

---

## The Cup of Judgment (48:18-28)

**48:18** "O you daughter that dwells in Dibon, come down from your glory, and sit in thirst; for the spoiler of Moab is come up against you, he has destroyed your strongholds.

**48:19** "O inhabitant of Aroer, stand by the way, and watch; ask him that flees, and her that escapes; say: 'What has been done?'

**48:20** "Moab is put to shame, for it is dismayed; wail and cry; tell in Arnon, that Moab is laid waste.

**48:21** "And judgment is come upon the country of the plain: upon Holon, and upon Jahzah, and upon Mephaath;

**48:22** "And upon Dibon, and upon Nebo, and upon Beth-diblathaim;

**48:23** "And upon Kiriathaim, and upon Beth-gamul, and upon Beth-meon;

**48:24** "And upon Kerioth, and upon Bozrah, and upon all the cities of the land of Moab, far and near.

**48:25** "The horn of Moab is cut off, and his arm is broken," says YHWH.

**48:26** "Make him drunken, for he magnified himself against YHWH; and Moab shall wallow in his vomit, and he also shall be in derision.

**48:27** "For was not Israel a derision unto you? Was he found among thieves? For as often as you spoke of him, you did shake your head.

**48:28** "O you that dwell in Moab, leave the cities, and dwell in the rock; and be like the dove that makes her nest in the sides of the pit's mouth.

---

## Moab's Pride (48:29-39)

**48:29** "We have heard of the pride of Moab; he is very proud; his loftiness, and his pride, and his haughtiness, and the arrogancy of his heart.

**48:30** "I know his arrogancy," says YHWH, "that it is ill-founded; his boastings have wrought nothing right.

**48:31** "Therefore will I wail for Moab; yea, I will cry out for all Moab; for the men of Kir-heres shall they mourn.

**48:32** "With more than the weeping of Jazer will I weep for you, O vine of Sibmah; your branches passed over the sea, they reached even to the sea of Jazer; upon your summer fruits and upon your vintage the spoiler is fallen.

**48:33** "And gladness and joy is taken away from the fruitful field, and from the land of Moab; and I have caused wine to cease from the winepresses; none shall tread with shouting; the shouting shall be no shouting.

**48:34** "From the cry of Heshbon even unto Elealeh, even unto Jahaz have they uttered their voice, from Zoar even unto Horonaim, a heifer of three years old; for the waters of Nimrim also shall become desolate.

**48:35** "Moreover I will cause to cease in Moab," says YHWH, "him that offers in the high place, and him that offers to his gods.

**48:36** "Therefore my heart moans for Moab like pipes, and my heart moans like pipes for the men of Kir-heres; therefore the abundance that he has gotten is perished.

**48:37** "For every head is bald, and every beard clipped; upon all the hands are cuttings, and upon the loins sackcloth.

**48:38** "On all the housetops of Moab and in the broad places thereof there is lamentation every where; for I have broken Moab like a vessel wherein is no pleasure," says YHWH.

**48:39** "How is it broken down! How do they wail! How has Moab turned the back with shame! So shall Moab become a derision and a dismay to all that are round about him."

---

## The Coming Destroyer (48:40-47)

**48:40** For thus says YHWH: "Behold, he shall fly as a vulture, and shall spread out his wings against Moab.

**48:41** "Kerioth is taken, and the strongholds are seized, and the heart of the mighty men of Moab at that day shall be as the heart of a woman in her pangs.

**48:42** "And Moab shall be destroyed from being a people, because he has magnified himself against YHWH.

**48:43** "Terror, and the pit, and the trap, are upon you, O inhabitant of Moab," says YHWH.

**48:44** "He that flees from the terror shall fall into the pit; and he that gets up out of the pit shall be taken in the trap; for I will bring upon her, even upon Moab, the year of their visitation," says YHWH.

**48:45** "In the shadow of Heshbon the fugitives stand without strength; for a fire is gone forth out of Heshbon, and a flame from the midst of Sihon, and it devours the corner of Moab, and the crown of the head of the tumultuous ones.

**48:46** "Woe unto you, O Moab! The people of Chemosh is undone; for your sons are taken away captive, and your daughters into captivity.

**48:47** "Yet will I turn the captivity of Moab in the end of days," says YHWH. Thus far is the judgment of Moab.

---

## Synthesis Notes

**Key Restorations:**

**Destruction Begins (48:1-10):**
"'Woe unto Nebo! For it is laid waste.'"

*Hoy el-Nevo ki shuddadah*—Nebo destroyed.

"'Kiriathaim is put to shame, it is taken.'"

*Hovishah Qiryatayim nilekedah*—Kiriathaim taken.

"'The praise of Moab is no more.'"

*Ein od tehillat Mo'av*—no more praise.

"'In Heshbon they have devised evil against her.'"

*Be-Cheshbon chashvu alekha ra'ah*—evil devised.

"'Come, and let us cut her off from being a nation.'"

*Lekhu ve-nakhritenah mi-goy*—cut off.

"'Hark! A cry from Horonaim.'"

*Qol tze'aqah me-Choronayim*—cry from Horonaim.

"'Spoiling and great destruction!'"

*Shod va-shever gadol*—destruction.

**The Key Verse (48:7):**
"'Because you have trusted in your works and in your treasures.'"

*Ki ya'an bitchekh be-ma'asayikh u-ve-otzrotayikh*—trusted works/treasures.

"'You also shall be taken.'"

*Gam-at tillakedi*—taken.

"'Chemosh shall go forth into captivity.'"

*Ve-yatza Khemosh ba-golah*—Chemosh exiled.

"'His priests and his princes together.'"

*Kohanav ve-sarav yachdav*—priests and princes.

**Chemosh:**
The national god of Moab (Numbers 21:29; 1 Kings 11:7).

**The Key Verse (48:10):**
"'Cursed be he that does the work of YHWH with a slack hand.'"

*Arur oseh melekhet YHWH remiyyah*—cursed slackness.

"'Cursed be he that keeps back his sword from blood.'"

*Ve-arur mone'a charbo mi-dam*—cursed withholding.

**Wine Imagery (48:11-13):**
**The Key Verse (48:11):**
"'Moab has been at ease from his youth.'"

*Sha'anan Mo'av mi-ne'urav*—at ease.

"'He has settled on his lees.'"

*Ve-shoqet hu el-shemarav*—settled on lees.

"'Has not been emptied from vessel to vessel.'"

*Ve-lo-huraq mi-keli el-keli*—not poured out.

"'Neither has he gone into captivity.'"

*U-va-golah lo halakh*—no exile.

"'Therefore his taste remains in him.'"

*Al-ken amad ta'amo vo*—taste remains.

"'His scent is not changed.'"

*Ve-reicho lo namar*—scent unchanged.

**Wine Lees:**
Wine left on its sediment develops flavor but becomes harsh. Moab's undisturbed life made it complacent.

"'I will send unto him them that tilt up.'"

*Ve-shilachti lo tzo'im ve-tze'uhu*—send pourers.

"'They shall tilt him up... empty his vessels... break their bottles.'"

*Ve-khelav yariqqu ve-nivleihem yenappetzu*—pour, break.

**The Key Verse (48:13):**
"'Moab shall be ashamed of Chemosh.'"

*Ve-vosh Mo'av mi-Khemosh*—ashamed of Chemosh.

"'As the house of Israel was ashamed of Beth-el their confidence.'"

*Ka-asher boshu beit-Yisra'el mi-Beit-El mivtacham*—like Israel's shame at Bethel.

**Pride and Fall (48:29-39):**
**The Key Verses (48:29-30):**
"'We have heard of the pride of Moab.'"

*Shama'nu ge'on-Mo'av*—heard of pride.

"'He is very proud.'"

*Ge'eh me'od*—very proud.

"'His loftiness, and his pride, and his haughtiness.'"

*Govho u-ge'ono u-ga'avato*—loftiness, pride.

"'The arrogancy of his heart.'"

*Ve-rum libbo*—heart arrogance.

"'I know his arrogancy,' says YHWH."

*Ani yada'ti... evrato*—YHWH knows.

"'That it is ill-founded.'"

*Ve-lo-khen*—unfounded.

"'His boastings have wrought nothing right.'"

*Baddav lo-khen asu*—empty boasts.

**The Key Verses (48:31-32):**
"'I will wail for Moab; yea, I will cry out for all Moab.'"

*Al-ken al-Mo'av ayeilil u-le-Mo'av kullo ezaq*—YHWH wails.

"'For the men of Kir-heres shall they mourn.'"

*Le-anshei Qir-Cheres yehegu*—mourn Kir-heres.

"'With more than the weeping of Jazer will I weep for you.'"

*Mi-bekhi Ya'zer evkeh-lakh*—weep more than Jazer.

"'O vine of Sibmah.'"

*Ha-gefen Sivmah*—Sibmah vine.

"'Your branches passed over the sea.'"

*Netishayikh avru yam*—far-reaching.

"'Upon your summer fruits and upon your vintage the spoiler is fallen.'"

*Al-qeytzekh ve-al-betzirakh shoded nafal*—spoiler on harvest.

**The Key Verse (48:36):**
"'My heart moans for Moab like pipes.'"

*Al-ken libbi le-Mo'av ka-chalilim yehemeh*—YHWH's heart moans.

"'My heart moans like pipes for the men of Kir-heres.'"

*Ve-libbi le-anshei Qir-Cheres ka-chalilim yehemeh*—moans.

**YHWH's Grief:**
Remarkably, YHWH mourns for Moab's destruction.

**The Key Verses (48:37-38):**
"'Every head is bald, and every beard clipped.'"

*Ki khol-rosh qorchah ve-khol-zaqan geru'ah*—baldness.

"'Upon all the hands are cuttings.'"

*Al-kol-yadayim gedudot*—self-cutting.

"'Upon the loins sackcloth.'"

*Ve-al-motnayim saq*—sackcloth.

"'On all the housetops of Moab... there is lamentation.'"

*Al-kol-gaggot Mo'av... kullo mispeid*—rooftop mourning.

"'I have broken Moab like a vessel wherein is no pleasure.'"

*Ki-shavarti et-Mo'av ki-kheli ein-chefetz bo*—broken vessel.

**Coming Destroyer (48:40-47):**
**The Key Verse (48:40):**
"'Behold, he shall fly as a vulture.'"

*Hinneh ka-nesher yida'eh*—vulture flight.

"'Shall spread out his wings against Moab.'"

*U-faras kenafav el-Mo'av*—wings spread.

**The Key Verses (48:43-44):**
"'Terror, and the pit, and the trap, are upon you.'"

*Pachad va-fachat va-fach alekha*—terror, pit, trap.

"'He that flees from the terror shall fall into the pit.'"

*Ha-nas mippenei ha-pachad yippol el-ha-pachat*—flee to fall.

"'He that gets up out of the pit shall be taken in the trap.'"

*Ve-ha-oleh min-ha-pachat yillakhed ba-fach*—out to trap.

**Isaiah 24:17-18:**
Nearly identical language—inescapable judgment.

**The Key Verse (48:46):**
"'Woe unto you, O Moab!'"

*Oy-lakh Mo'av*—woe Moab.

"'The people of Chemosh is undone.'"

*Avad am-Khemosh*—Chemosh's people undone.

"'Your sons are taken away captive.'"

*Ki luqqechu vanekha ba-shevi*—sons captive.

"'Your daughters into captivity.'"

*U-venotekha ba-shivyah*—daughters captive.

**The Key Verse (48:47):**
"'Yet will I turn the captivity of Moab in the end of days,' says YHWH."

*Ve-shavti shevut-Mo'av be-acharit ha-yamim*—restore Moab.

"Thus far is the judgment of Moab."

*Ad-hennah mishpat Mo'av*—end of Moab oracle.

**Future Restoration:**
Like Egypt (46:26), Moab receives a promise of restoration.

**Archetypal Layer:** Jeremiah 48 is the **longest oracle against a foreign nation**, containing extensive parallels to Isaiah 15-16, **the wine imagery of complacency (48:11)**, **YHWH mourning for Moab (48:31, 36)**, and **"Yet will I turn the captivity of Moab in the end of days" (48:47)**.

**Ethical Inversion Applied:**
- "'Woe unto Nebo! For it is laid waste'"—Nebo destroyed
- "'Kiriathaim is put to shame, it is taken'"—taken
- "'Come, and let us cut her off from being a nation'"—cut off
- "'Because you have trusted in your works and in your treasures'"—false trust
- "'Chemosh shall go forth into captivity'"—god exiled
- "'Cursed be he that does the work of YHWH with a slack hand'"—no slackness
- "'Cursed be he that keeps back his sword from blood'"—no withholding
- "'Moab has been at ease from his youth'"—complacent
- "'He has settled on his lees'"—wine imagery
- "'Has not been emptied from vessel to vessel'"—undisturbed
- "'Neither has he gone into captivity'"—no exile
- "'His taste remains in him, and his scent is not changed'"—unchanged
- "'I will send unto him them that tilt up'"—pourers sent
- "'Moab shall be ashamed of Chemosh'"—ashamed of god
- "'We have heard of the pride of Moab'"—pride
- "'He is very proud; his loftiness, and his pride'"—proud
- "'I know his arrogancy,' says YHWH"—YHWH knows
- "'His boastings have wrought nothing right'"—empty boasts
- "'I will wail for Moab'"—YHWH wails
- "'My heart moans for Moab like pipes'"—YHWH mourns
- "'Every head is bald, and every beard clipped'"—mourning
- "'I have broken Moab like a vessel'"—broken
- "'Behold, he shall fly as a vulture'"—destroyer
- "'Terror, and the pit, and the trap, are upon you'"—inescapable
- "'He that flees from the terror shall fall into the pit'"—flee to fall
- "'Woe unto you, O Moab! The people of Chemosh is undone'"—undone
- "'Yet will I turn the captivity of Moab in the end of days'"—restoration

**Modern Equivalent:** Jeremiah 48 draws heavily on Isaiah 15-16. The wine imagery (48:11) explains complacency—never disturbed, never refined. YHWH's mourning for Moab (48:31, 36) shows divine grief even in judgment. The final promise of restoration (48:47) extends hope.

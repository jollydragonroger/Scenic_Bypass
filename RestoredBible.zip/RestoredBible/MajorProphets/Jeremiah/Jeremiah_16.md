# Jeremiah 16: No Marriage, No Mourning, No Feasting

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came to Me*

---

## Jeremiah Forbidden to Marry (16:1-9)

**16:1** The word of YHWH came also unto me, saying:

**16:2** "You shall not take a wife, neither shall you have sons or daughters in this place.

**16:3** "For thus says YHWH concerning the sons and concerning the daughters that are born in this place, and concerning their mothers that bore them, and concerning their fathers that begot them in this land:

**16:4** "They shall die of grievous deaths; they shall not be lamented, neither shall they be buried; they shall be as dung upon the face of the ground; and they shall be consumed by the sword, and by famine; and their carcasses shall be food for the fowls of heaven, and for the beasts of the earth."

**16:5** For thus says YHWH: "Enter not into the house of mourning, neither go to lament, neither bemoan them; for I have taken away my peace from this people," says YHWH, "even lovingkindness and compassions.

**16:6** "Both the great and the small shall die in this land; they shall not be buried, neither shall men lament for them, nor cut themselves, nor make themselves bald for them;

**16:7** "Neither shall men break bread for them in mourning, to comfort them for the dead; neither shall men give them the cup of consolation to drink for their father or for their mother.

**16:8** "And you shall not go into the house of feasting to sit with them, to eat and to drink."

**16:9** For thus says YHWH of hosts, the God of Israel: "Behold, I will cause to cease out of this place, before your eyes and in your days, the voice of mirth and the voice of gladness, the voice of the bridegroom and the voice of the bride."

---

## Why This Judgment? (16:10-13)

**16:10** And it shall come to pass, when you shall tell this people all these words, and they shall say unto you: "Wherefore has YHWH pronounced all this great evil against us? Or what is our iniquity? Or what is our sin that we have committed against YHWH our God?"

**16:11** Then shall you say unto them: "Because your fathers have forsaken me," says YHWH, "and have walked after other gods, and have served them, and have worshipped them, and have forsaken me, and have not kept my law;

**16:12** "And you have done worse than your fathers; for, behold, you walk every one after the stubbornness of his evil heart, so as not to hearken unto me;

**16:13** "Therefore will I cast you forth out of this land into the land that you have not known, neither you nor your fathers; and there shall you serve other gods day and night; for I will show you no favour."

---

## A New Exodus (16:14-18)

**16:14** "Therefore, behold, the days come," says YHWH, "that it shall no more be said: 'As YHWH lives, that brought up the children of Israel out of the land of Egypt';

**16:15** "But: 'As YHWH lives, that brought up the children of Israel from the land of the north, and from all the countries whither he had driven them'; and I will bring them back into their land that I gave unto their fathers.

**16:16** "Behold, I will send for many fishers," says YHWH, "and they shall fish them; and afterward I will send for many hunters, and they shall hunt them from every mountain, and from every hill, and out of the clefts of the rocks.

**16:17** "For my eyes are upon all their ways; they are not hid from my face, neither is their iniquity concealed from my eyes.

**16:18** "And first I will recompense their iniquity and their sin double; because they have profaned my land with the carcasses of their detestable things, and have filled my inheritance with their abominations."

---

## The Nations Will Come (16:19-21)

**16:19** O YHWH, my strength, and my stronghold, and my refuge in the day of affliction, unto you shall the nations come from the ends of the earth, and shall say: "Our fathers have inherited nought but lies, vanity and things wherein there is no profit.

**16:20** "Shall a man make unto himself gods, and they are no gods?"

**16:21** "Therefore, behold, I will cause them to know, this once will I cause them to know my hand and my might; and they shall know that my name is YHWH."

---

## Synthesis Notes

**Key Restorations:**

**No Marriage (16:1-4):**
"You shall not take a wife."

*Lo-tiqqach lekha ishah*—don't marry.

"Neither shall you have sons or daughters in this place."

*Ve-lo-yihyu lekha banim u-vanot ba-maqom ha-zeh*—no children.

**Sign-Act:**
Jeremiah's celibacy is a sign-act prophesying the end of normal family life due to coming judgment.

"They shall die of grievous deaths."

*Motei tachalue'im yamutu*—grievous deaths.

"They shall not be lamented, neither shall they be buried."

*Lo yissafedu ve-lo yiqqaveru*—not lamented/buried.

"They shall be as dung upon the face of the ground."

*Li-domen al-penei ha-adamah yihyu*—dung on ground.

"Consumed by the sword, and by famine."

*U-va-cherev u-va-ra'av yikhlu*—sword and famine.

"Their carcasses shall be food for the fowls of heaven."

*Ve-hayetah nivlatam le-ma'akhal le-of ha-shamayim*—carrion.

**No Mourning (16:5-7):**
"Enter not into the house of mourning."

*Al-tavo beit-marzeach*—no mourning house.

"Neither go to lament, neither bemoan them."

*Ve-al-telekh lispod ve-al-tanod lahem*—no lamenting.

"I have taken away my peace from this people."

*Ki-asafti et-shelomi me-et ha-am ha-zeh*—peace withdrawn.

**The Key Verse (16:5):**
"Even lovingkindness and compassions."

*Et-ha-chesed ve-et-ha-rachamim*—lovingkindness and compassion withdrawn.

"Both the great and the small shall die in this land."

*U-metu gedolim u-qetannim ba-aretz ha-zot*—all die.

"They shall not be buried."

*Lo yiqqaveru*—not buried.

"Neither shall men lament for them."

*Ve-lo-yispedu lahem*—not lamented.

"Nor cut themselves."

*Ve-lo yitgodedu*—no cutting (pagan mourning).

"Nor make themselves bald for them."

*Ve-lo yiqqarechu lahem*—no balding.

"Neither shall men break bread for them in mourning."

*Ve-lo-yiferesu lahem al-evel*—no mourning bread.

"Neither shall men give them the cup of consolation."

*Ve-lo-yashqu otam kos tanchumim*—no consolation cup.

**No Feasting (16:8-9):**
"You shall not go into the house of feasting."

*U-veit mishteh lo-tavo*—no feasting house.

"To sit with them, to eat and to drink."

*Lashevet ittam le-ekhol ve-lishtot*—no eating/drinking.

**The Key Verse (16:9):**
"I will cause to cease out of this place."

*Hineni mashbit min-ha-maqom ha-zeh*—cause to cease.

"Before your eyes and in your days."

*Le-eineikhem u-vi-yemeikhem*—in your time.

"The voice of mirth and the voice of gladness."

*Qol sason ve-qol simchah*—joy sounds.

"The voice of the bridegroom and the voice of the bride."

*Qol chatan ve-qol kallah*—wedding sounds. (Repeats 7:34)

**Why Judgment? (16:10-13):**
"'Wherefore has YHWH pronounced all this great evil against us?'"

*Al-mah dibber YHWH aleinu et kol-ha-ra'ah ha-gedolah ha-zot*—why evil?

"'What is our iniquity?'"

*U-meh avonenu*—what iniquity?

"'What is our sin?'"

*U-meh chatta'tenu*—what sin?

"'Because your fathers have forsaken me.'"

*Al asher-azvu avoteikhem oti*—fathers forsook.

"'Walked after other gods.'"

*Va-yelkhu acharei elohim acherim*—other gods.

"'Served them, and worshipped them.'"

*Va-ya'avdum va-yishtachavu lahem*—served/worshipped.

"'Forsaken me, and have not kept my law.'"

*Ve-oti azavu ve-et-torati lo shamaru*—forsook, didn't keep law.

**The Key Verse (16:12):**
"You have done worse than your fathers."

*Ve-attem hare'otem la'asot me-avoteikhem*—worse than fathers.

"You walk every one after the stubbornness of his evil heart."

*Ve-hinnekhem holekhim ish acharei sherirut libbo ha-ra*—evil heart stubbornness.

"So as not to hearken unto me."

*Le-vilti shemo'a elai*—not hearken.

"I cast you forth out of this land."

*Ve-hetaltii etkhem me-al ha-aretz ha-zot*—cast out.

"Into the land that you have not known."

*Al-ha-aretz asher lo-yeda'tem*—unknown land.

"There shall you serve other gods day and night."

*Va-avadtem-sham et-elohim acherim yomam va-laylah*—serve foreign gods.

"I will show you no favour."

*Asher lo-etten lakhem channinah*—no favor.

**New Exodus (16:14-18):**
**The Key Verses (16:14-15):**
"The days come, that it shall no more be said: 'As YHWH lives, that brought up the children of Israel out of the land of Egypt.'"

*Lo-ye'amer od chai-YHWH asher he'elah et-benei Yisra'el me-eretz Mitzrayim*—no more Egypt exodus.

"But: 'As YHWH lives, that brought up the children of Israel from the land of the north.'"

*Ki im-chai-YHWH asher he'elah et-benei Yisra'el me-eretz tzafon*—north exodus.

"From all the countries whither he had driven them."

*U-mi-kol ha-aratzot asher hiddichim shammah*—all countries.

"I will bring them back into their land."

*Va-hashivotim al-admatam*—bring back.

"That I gave unto their fathers."

*Asher natatti la-avotam*—fathers' land.

**New Exodus:**
The return from Babylon will eclipse the Exodus from Egypt as the defining redemption event.

**The Key Verse (16:16):**
"I will send for many fishers."

*Hineni shole'ach le-dayya'agim rabbim*—fishers sent.

"They shall fish them."

*Ve-dayya'agum*—fish them.

"I will send for many hunters."

*Ve-acharei-khen eshlach le-tzayyaddim rabbim*—hunters sent.

"They shall hunt them from every mountain."

*Ve-tzaduum me-al kol-har*—hunt from mountains.

"From every hill."

*U-me-al kol-giv'ah*—from hills.

"Out of the clefts of the rocks."

*U-mi-neqiqei ha-sela'im*—from rock clefts.

"My eyes are upon all their ways."

*Ki einai al-kol-darkhehem*—eyes on ways.

"They are not hid from my face."

*Lo nisteru mi-lefanai*—not hidden.

"Neither is their iniquity concealed from my eyes."

*Ve-lo-nitzpenah avonam mi-neged einai*—iniquity not concealed.

"First I will recompense their iniquity and their sin double."

*Ve-shillamti rishonah mishneh avonam ve-chattataim*—double recompense.

"They have profaned my land with the carcasses of their detestable things."

*Al challelam et-artzi be-nivlat shiqqutzehem*—profaned land.

"Have filled my inheritance with their abominations."

*U-ve-to'avoteihem mil'u et-nachalati*—filled with abominations.

**Nations Come (16:19-21):**
**The Key Verse (16:19):**
"O YHWH, my strength, and my stronghold, and my refuge in the day of affliction."

*YHWH uzzi u-ma'uzzi u-menusi be-yom tzarah*—strength, refuge.

"Unto you shall the nations come from the ends of the earth."

*Elekha goyim yavo'u me-afsei-aretz*—nations come.

"'Our fathers have inherited nought but lies.'"

*Akh-sheqer nachalu avoteinu*—fathers inherited lies.

"'Vanity and things wherein there is no profit.'"

*Hevel ve-ein-bam mo'il*—vanity, no profit.

**The Key Verse (16:20):**
"'Shall a man make unto himself gods, and they are no gods?'"

*Ha-ya'aseh-lo adam elohim ve-hemmah lo elohim*—making non-gods.

**The Key Verse (16:21):**
"I will cause them to know, this once."

*Lakhen hineni modi'am ba-pa'am ha-zot*—this once.

"I will cause them to know my hand and my might."

*Odi'em et-yadi ve-et-gevurati*—hand and might.

"They shall know that my name is YHWH."

*Ve-yade'u ki-shemi YHWH*—know my name.

**Archetypal Layer:** Jeremiah 16 contains **Jeremiah forbidden to marry (16:1-4)**, **the new exodus surpassing Egypt (16:14-15)**, **fishers and hunters (16:16)**, and **"unto you shall the nations come" (16:19)**.

**Ethical Inversion Applied:**
- "You shall not take a wife"—no marriage
- "Neither shall you have sons or daughters"—no children
- "They shall die of grievous deaths"—grievous deaths
- "They shall not be lamented, neither shall they be buried"—no burial
- "Enter not into the house of mourning"—no mourning
- "I have taken away my peace from this people"—peace withdrawn
- "Even lovingkindness and compassions"—kindness withdrawn
- "Neither shall men break bread for them in mourning"—no mourning bread
- "Neither shall men give them the cup of consolation"—no consolation
- "You shall not go into the house of feasting"—no feasting
- "I will cause to cease... the voice of mirth"—joy ceases
- "The voice of the bridegroom and the voice of the bride"—wedding sounds cease
- "'Wherefore has YHWH pronounced all this great evil?'"—asking why
- "'Because your fathers have forsaken me'"—fathers forsook
- "You have done worse than your fathers"—worse than fathers
- "You walk every one after the stubbornness of his evil heart"—evil heart
- "I cast you forth out of this land"—exile
- "There shall you serve other gods day and night"—fitting punishment
- "It shall no more be said: 'As YHWH lives, that brought up... out of... Egypt'"—new exodus
- "But: 'As YHWH lives, that brought up... from the land of the north'"—new exodus oath
- "I will send for many fishers... many hunters"—fishers and hunters
- "My eyes are upon all their ways"—eyes on ways
- "First I will recompense their iniquity and their sin double"—double recompense
- "O YHWH, my strength, and my stronghold"—strength/stronghold
- "Unto you shall the nations come from the ends of the earth"—nations come
- "'Our fathers have inherited nought but lies'"—inherited lies
- "'Shall a man make unto himself gods, and they are no gods?'"—false gods
- "They shall know that my name is YHWH"—name known

**Modern Equivalent:** Jeremiah 16's new exodus (16:14-15) shows restoration will surpass the original Exodus. The "fishers and hunters" (16:16) may be either judgment (hunting sinners) or restoration (gathering exiles). The nations' confession (16:19) anticipates Gentile conversion.

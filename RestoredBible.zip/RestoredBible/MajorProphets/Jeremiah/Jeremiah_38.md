# Jeremiah 38: The Cistern and the Secret Meeting

*From the Hebrew: וַיִּשְׁמַע שְׁפַטְיָה (Va-Yishma Shefatyah) — And Shephatiah Heard*

---

## Jeremiah Cast into the Cistern (38:1-6)

**38:1** And Shephatiah the son of Mattan, and Gedaliah the son of Pashhur, and Jucal the son of Shelemiah, and Pashhur the son of Malchiah, heard the words that Jeremiah spoke unto all the people, saying:

**38:2** "Thus says YHWH: He that remains in this city shall die by the sword, by the famine, and by the pestilence; but he that goes forth to the Chaldeans shall live, and his life shall be unto him for a prey, and he shall live.

**38:3** "Thus says YHWH: This city shall surely be given into the hand of the army of the king of Babylon, and he shall take it."

**38:4** Then said the princes unto the king: "Let this man, we pray you, be put to death; forasmuch as he weakens the hands of the men of war that remain in this city, and the hands of all the people, in speaking such words unto them; for this man seeks not the welfare of this people, but the hurt."

**38:5** And Zedekiah the king said: "Behold, he is in your hand; for the king is not he that can do any thing against you."

**38:6** Then took they Jeremiah, and cast him into the pit of Malchiah the king's son, that was in the court of the guard; and they let down Jeremiah with cords. And in the pit there was no water, but mire; and Jeremiah sank in the mire.

---

## Ebed-melech Rescues Jeremiah (38:7-13)

**38:7** Now when Ebed-melech the Cushite, an officer in the king's house, heard that they had put Jeremiah into the pit—the king then sitting in the gate of Benjamin—

**38:8** Ebed-melech went forth out of the king's house, and spoke to the king, saying:

**38:9** "My lord the king, these men have done evil in all that they have done to Jeremiah the prophet, whom they have cast into the pit; and he is like to die in the place where he is, because of the famine; for there is no more bread in the city."

**38:10** Then the king commanded Ebed-melech the Cushite, saying: "Take from here thirty men with you, and take up Jeremiah the prophet out of the pit, before he die."

**38:11** So Ebed-melech took the men with him, and went into the house of the king under the treasury, and took from there worn clouts and worn rags, and let them down by cords into the pit to Jeremiah.

**38:12** And Ebed-melech the Cushite said unto Jeremiah: "Put now these worn clouts and rags under your armholes under the cords." And Jeremiah did so.

**38:13** So they drew up Jeremiah with the cords, and took him up out of the pit; and Jeremiah remained in the court of the guard.

---

## Zedekiah's Final Inquiry (38:14-28)

**38:14** Then Zedekiah the king sent, and took Jeremiah the prophet unto him into the third entry that is in the house of YHWH; and the king said unto Jeremiah: "I will ask you a thing; hide nothing from me."

**38:15** Then Jeremiah said unto Zedekiah: "If I declare it unto you, will you not surely put me to death? And if I give you counsel, you will not hearken unto me."

**38:16** So Zedekiah the king swore secretly unto Jeremiah, saying: "As YHWH lives, that made us this soul, I will not put you to death, neither will I give you into the hand of these men that seek your life."

**38:17** Then said Jeremiah unto Zedekiah: "Thus says YHWH, the God of hosts, the God of Israel: If you will go forth unto the king of Babylon's princes, then your soul shall live, and this city shall not be burned with fire; and you shall live, and your house.

**38:18** "But if you will not go forth to the king of Babylon's princes, then shall this city be given into the hand of the Chaldeans, and they shall burn it with fire, and you shall not escape out of their hand."

**38:19** And Zedekiah the king said unto Jeremiah: "I am afraid of the Jews that are fallen away to the Chaldeans, lest they deliver me into their hand, and they mock me."

**38:20** But Jeremiah said: "They shall not deliver you. Hearken, I beseech you, to the voice of YHWH, in that which I speak unto you; so it shall be well with you, and your soul shall live.

**38:21** "But if you refuse to go forth, this is the word that YHWH has shown me:

**38:22** "Behold, all the women that are left in the king of Judah's house shall be brought forth to the king of Babylon's princes, and those women shall say: 'Your familiar friends have set you on, and have prevailed over you; your feet are sunk in the mire, they have turned away back.'

**38:23** "And they shall bring out all your wives and your children to the Chaldeans; and you shall not escape out of their hand, but shall be taken by the hand of the king of Babylon; and you shall cause this city to be burned with fire."

**38:24** Then said Zedekiah unto Jeremiah: "Let no man know of these words, and you shall not die.

**38:25** "But if the princes hear that I have talked with you, and they come unto you, and say unto you: 'Declare unto us now what you have said unto the king; hide it not from us, and we will not put you to death; also what the king said unto you';

**38:26** "Then you shall say unto them: 'I presented my supplication before the king, that he would not cause me to return to Jonathan's house, to die there.'"

**38:27** Then came all the princes unto Jeremiah, and asked him; and he told them according to all these words that the king had commanded. So they left off speaking with him; for the matter was not reported.

**38:28** And Jeremiah abode in the court of the guard until the day that Jerusalem was taken.

---

## Synthesis Notes

**Key Restorations:**

**Opposition to Jeremiah (38:1-4):**
"Shephatiah the son of Mattan."

*Shefatyah ben-Mattan*—Shephatiah.

"Gedaliah the son of Pashhur."

*U-Gedalyahu ben-Pashhur*—Gedaliah.

"Jucal the son of Shelemiah."

*Ve-Yukhal ben-Shelemyahu*—Jucal (= Jehucal of 37:3).

"Pashhur the son of Malchiah."

*U-Fashhur ben-Malkiyyahu*—Pashhur.

"Heard the words that Jeremiah spoke unto all the people."

*Shom'im et-ha-devarim asher Yirmeyahu medabber el-kol-ha-am*—heard Jeremiah.

**The Key Verses (38:2-3):**
"'He that remains in this city shall die by the sword, by the famine, and by the pestilence.'"

*Ha-yoshev ba-ir ha-zot yamut ba-cherev ba-ra'av u-va-daver*—stay = die.

"'He that goes forth to the Chaldeans shall live.'"

*Ve-ha-yotze el-ha-Kasdim yichyeh*—surrender = live.

"'His life shall be unto him for a prey.'"

*Ve-hayetah-lo nafsho le-shalal*—life as plunder.

"'This city shall surely be given into the hand of the army of the king of Babylon.'"

*Hinnaton tinnaten ha-ir ha-zot be-yad cheil melekh Bavel*—city given.

"'He shall take it.'"

*U-lekhadah*—take it.

**The Key Verse (38:4):**
"'Let this man, we pray you, be put to death.'"

*Yumat-na ha-ish ha-zeh*—death sentence.

"'He weakens the hands of the men of war.'"

*Ki-hu merappeh et-yedei anshei ha-milchamah*—weakening hands.

"'The hands of all the people.'"

*Ve-et yedei kol-ha-am*—all people.

"'In speaking such words unto them.'"

*Le-dabber aleihem ka-devarim ha-elleh*—speaking such words.

"'This man seeks not the welfare of this people, but the hurt.'"

*Ki ein ha-ish ha-zeh doresh le-shalom la-am ha-zeh ki im-le-ra'ah*—seeks hurt.

**Treason Charge:**
Jeremiah's surrender message was seen as weakening morale—treason during siege.

**The Key Verse (38:5):**
"Zedekiah the king said: 'Behold, he is in your hand.'"

*Va-yomer ha-melekh Tzidqiyyahu hinneh-hu be-yedkhem*—in your hands.

"'The king is not he that can do any thing against you.'"

*Ki-ein ha-melekh yukhal etkhem davar*—king powerless.

**Weak King:**
Zedekiah admits his powerlessness before his officials.

**The Key Verse (38:6):**
"They cast him into the pit of Malchiah the king's son."

*Va-yashlikhu oto el-bor Malkiyyahu ven-ha-melekh*—into pit.

"That was in the court of the guard."

*Asher ba-chatzer ha-mattarah*—guard court.

"They let down Jeremiah with cords."

*Va-yeshallchu et-Yirmeyahu ba-chavalim*—lowered with ropes.

"In the pit there was no water, but mire."

*U-va-bor ein mayim ki im-tit*—no water, just mud.

"Jeremiah sank in the mire."

*Va-yitba Yirmeyahu ba-tit*—sank in mud.

**Ebed-melech's Rescue (38:7-13):**
**The Key Verse (38:7):**
"Ebed-melech the Cushite, an officer in the king's house."

*Eved-Melekh ha-Kushi ish saris be-veit ha-melekh*—Cushite official.

"Heard that they had put Jeremiah into the pit."

*Ki-natenu et-Yirmeyahu el-ha-bor*—heard.

"The king then sitting in the gate of Benjamin."

*Ve-ha-melekh yoshev be-sha'ar Binyamin*—king at gate.

**Ebed-melech:**
His name means "servant of the king." A Cushite (Ethiopian/Nubian) court official.

**The Key Verse (38:9):**
"'My lord the king, these men have done evil.'"

*Adoni ha-melekh here'u ha-anashim ha-elleh*—done evil.

"'In all that they have done to Jeremiah the prophet.'"

*Et asher-asu le-Yirmeyahu ha-navi*—to Jeremiah.

"'Whom they have cast into the pit.'"

*Et asher-hishlikhu el-ha-bor*—into pit.

"'He is like to die in the place where he is, because of the famine.'"

*Va-yamut tachtav mippenei ha-ra'av*—will die of hunger.

"'For there is no more bread in the city.'"

*Ki ein ha-lechem od ba-ir*—no bread left.

**The Key Verse (38:10):**
"'Take from here thirty men with you.'"

*Qach be-yadekha mi-zeh sheloshim anashim*—take 30 men.

"'Take up Jeremiah the prophet out of the pit, before he die.'"

*Ve-ha'alita et-Yirmeyahu ha-navi min-ha-bor be-terem yamut*—rescue before death.

**The Key Verses (38:11-12):**
"Went into the house of the king under the treasury."

*Va-yavo veit ha-melekh el-tachat ha-otzar*—under treasury.

"Took from there worn clouts and worn rags."

*Va-yiqqach mi-sham beloei secharbot u-veloei malachim*—rags.

"Let them down by cords into the pit."

*Va-yeshallchem el-Yirmeyahu el-ha-bor ba-chavalim*—lowered rags.

"'Put now these worn clouts and rags under your armholes under the cords.'"

*Sim-na beloei ha-secharbot ve-ha-malachim tachat atzzilot yadekha mi-tachat la-chavalim*—pad armpits.

"Jeremiah did so."

*Va-ya'as Yirmeyahu ken*—Jeremiah obeyed.

**Compassionate Detail:**
Ebed-melech's care—rags to protect Jeremiah's armpits from rope burns.

**The Key Verse (38:13):**
"They drew up Jeremiah with the cords."

*Va-yimshekhu et-Yirmeyahu ba-chavalim*—pulled up.

"Took him up out of the pit."

*Va-ya'alu oto min-ha-bor*—out of pit.

"Jeremiah remained in the court of the guard."

*Va-yeshev Yirmeyahu ba-chatzer ha-mattarah*—stayed in guard court.

**Zedekiah's Final Inquiry (38:14-23):**
"Zedekiah the king sent, and took Jeremiah the prophet unto him."

*Va-yishlach ha-melekh Tzidqiyyahu va-yiqqach et-Yirmeyahu ha-navi elav*—king fetched.

"Into the third entry that is in the house of YHWH."

*El-mavo ha-shelishi asher be-veit YHWH*—third entry (secret location).

"'I will ask you a thing; hide nothing from me.'"

*Davar ani sho'el otakh al-tekhached mimmeni davar*—hide nothing.

**The Key Verse (38:15):**
"'If I declare it unto you, will you not surely put me to death?'"

*Ki aggid lekha halo temitenni*—will you kill me?

"'If I give you counsel, you will not hearken unto me.'"

*Ve-khi i'atzekha lo tishma elai*—won't listen.

**The Key Verse (38:16):**
"Zedekiah the king swore secretly unto Jeremiah."

*Va-yishava ha-melekh Tzidqiyyahu el-Yirmeyahu ba-seter*—secret oath.

"'As YHWH lives, that made us this soul.'"

*Chai-YHWH asher-asah lanu et-ha-nefesh ha-zot*—by YHWH who made soul.

"'I will not put you to death.'"

*Im-amitekha*—won't kill.

"'Neither will I give you into the hand of these men that seek your life.'"

*Ve-im-ettenkha be-yad ha-anashim ha-elleh asher-mevaqqeshim et-nafshekha*—won't give to enemies.

**The Key Verses (38:17-18):**
"'If you will go forth unto the king of Babylon's princes.'"

*Im-yatzo tetze el-sarei melekh Bavel*—if surrender.

"'Then your soul shall live.'"

*Ve-chayetah nafshekha*—you'll live.

"'This city shall not be burned with fire.'"

*Ve-ha-ir ha-zot lo tissaref ba-esh*—city not burned.

"'You shall live, and your house.'"

*Ve-chayita attah u-veitekha*—you and house live.

"'But if you will not go forth... this city be given into the hand of the Chaldeans.'"

*Ve-im-lo tetze... ve-nittenah ha-ir ha-zot be-yad ha-Kasdim*—if not = city falls.

"'They shall burn it with fire.'"

*U-serafuha va-esh*—burned.

"'You shall not escape out of their hand.'"

*Ve-attah lo-timmalet mi-yadam*—won't escape.

**The Key Verse (38:19):**
"'I am afraid of the Jews that are fallen away to the Chaldeans.'"

*Ani doge et-ha-Yehudim asher naflu el-ha-Kasdim*—afraid of defectors.

"'Lest they deliver me into their hand, and they mock me.'"

*Pen-yittenu oti be-yadam ve-hit'allelu vi*—fear of mockery.

**Zedekiah's Fear:**
He fears the Jewish defectors more than Babylon.

**The Key Verses (38:20-23):**
"'They shall not deliver you.'"

*Lo yittenu*—won't deliver.

"'Hearken, I beseech you, to the voice of YHWH.'"

*Shema-na be-qol YHWH*—hear YHWH.

"'In that which I speak unto you.'"

*La-asher ani dover elekha*—what I speak.

"'So it shall be well with you, and your soul shall live.'"

*Ve-yitav lekha ve-tichi nafshekha*—well, live.

"'But if you refuse to go forth.'"

*Ve-im-ma'en attah latze't*—if refuse.

"'This is the word that YHWH has shown me.'"

*Zeh ha-davar asher hir'ani YHWH*—YHWH's word.

"'All the women that are left in the king of Judah's house shall be brought forth.'"

*Hinneh kol-ha-nashim asher nish'aru be-veit melekh-Yehudah mutz'ot*—women brought out.

"'To the king of Babylon's princes.'"

*El-sarei melekh Bavel*—to Babylon's princes.

"'Those women shall say: Your familiar friends have set you on.'"

*Ve-hennah omerot hissitukha ve-yakhlu lekha anshei shelomekha*—friends incited.

"'Your feet are sunk in the mire.'"

*Hotba'u va-botz raglekha*—feet in mire.

"'They have turned away back.'"

*Nasogu achor*—turned back.

**The Key Verse (38:23):**
"'They shall bring out all your wives and your children to the Chaldeans.'"

*Ve-et-kol-nashekha ve-et-banekha motzi'im el-ha-Kasdim*—family captured.

"'You shall not escape out of their hand.'"

*Ve-attah lo-timmalet mi-yadam*—won't escape.

"'Shall be taken by the hand of the king of Babylon.'"

*Ki ve-yad melekh-Bavel tittafes*—taken.

"'You shall cause this city to be burned with fire.'"

*Ve-et-ha-ir ha-zot tisrof ba-esh*—you cause burning.

**Secrecy Agreement (38:24-28):**
"'Let no man know of these words, and you shall not die.'"

*Ish al-yeda ba-devarim ha-elleh ve-lo tamut*—keep secret.

"'If the princes hear that I have talked with you.'"

*Ve-khi-yishme'u ha-sarim ki-dibbarti ittakh*—if princes hear.

"'Declare unto us now what you have said unto the king.'"

*Haggidah-na lanu mah-dibbarta el-ha-melekh*—tell us.

"'I presented my supplication before the king.'"

*Mappil ani techinati lifnei ha-melekh*—cover story.

"'That he would not cause me to return to Jonathan's house, to die there.'"

*Le-vilti hashiveni beit Yehonatan lamut sham*—Jonathan's house.

**The Key Verse (38:27):**
"He told them according to all these words that the king had commanded."

*Va-yagged lahem ke-khol ha-devarim ha-elleh asher tzivvah ha-melekh*—told cover story.

"They left off speaking with him."

*Va-yacharishu mimmenu*—they stopped asking.

"The matter was not reported."

*Ki lo-nishma ha-davar*—not reported.

**The Key Verse (38:28):**
"Jeremiah abode in the court of the guard until the day that Jerusalem was taken."

*Va-yeshev Yirmeyahu ba-chatzer ha-mattarah ad-yom asher-nilekedah Yerushalayim*—until fall.

**Archetypal Layer:** Jeremiah 38 contains **"He weakens the hands of the men of war" (38:4)**—treason charge, **Jeremiah cast into the muddy cistern (38:6)**, **Ebed-melech's compassionate rescue (38:7-13)**, and **Zedekiah's final inquiry with unchanged advice (38:17-18)**.

**Ethical Inversion Applied:**
- "Shephatiah... Gedaliah... Jucal... Pashhur heard the words"—opponents
- "'He that remains in this city shall die'"—stay = die
- "'He that goes forth to the Chaldeans shall live'"—surrender = live
- "'This city shall surely be given'"—city falls
- "'Let this man... be put to death'"—death sentence
- "'He weakens the hands of the men of war'"—weakening charge
- "'This man seeks not the welfare of this people, but the hurt'"—accused
- "'Behold, he is in your hand'"—Zedekiah abdicates
- "'The king is not he that can do any thing against you'"—powerless king
- "They cast him into the pit of Malchiah"—into cistern
- "In the pit there was no water, but mire"—muddy pit
- "Jeremiah sank in the mire"—sinking
- "Ebed-melech the Cushite, an officer"—rescuer
- "'These men have done evil in all that they have done to Jeremiah'"—evil deed
- "'He is like to die... because of the famine'"—dying
- "'Take from here thirty men'"—rescue order
- "Took from there worn clouts and worn rags"—rags
- "'Put now these worn clouts and rags under your armholes'"—compassion
- "They drew up Jeremiah with the cords"—rescued
- "Zedekiah the king... took Jeremiah... into the third entry"—secret meeting
- "'I will ask you a thing; hide nothing from me'"—inquiry
- "'If I declare it unto you, will you not surely put me to death?'"—fear
- "'As YHWH lives... I will not put you to death'"—oath
- "'If you will go forth unto the king of Babylon's princes, then your soul shall live'"—surrender = live
- "'This city shall not be burned with fire'"—conditional
- "'But if you will not go forth... this city be given... they shall burn it'"—not surrender = burn
- "'I am afraid of the Jews that are fallen away to the Chaldeans'"—Zedekiah's fear
- "'Hearken, I beseech you, to the voice of YHWH'"—final plea
- "'All the women... shall say: Your familiar friends have set you on'"—taunt
- "'Your feet are sunk in the mire'"—symbolic
- "'You shall cause this city to be burned with fire'"—king responsible
- "'Let no man know of these words'"—secrecy
- "He told them according to all these words that the king had commanded"—cover story
- "Jeremiah abode in the court of the guard until... Jerusalem was taken"—until fall

**Modern Equivalent:** Jeremiah 38 shows the prophet at his most vulnerable—sinking in mud. Ebed-melech (a foreign official) shows more compassion than Jewish leaders. Zedekiah's secret inquiry and inability to act shows tragic weakness. The cistern foreshadows Israel's cistern imagery (2:13).

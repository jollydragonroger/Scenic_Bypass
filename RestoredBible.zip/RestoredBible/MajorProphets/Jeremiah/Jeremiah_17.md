# Jeremiah 17: The Heart Is Deceitful

*From the Hebrew: חַטַּאת יְהוּדָה (Chattat Yehudah) — The Sin of Judah*

---

## Judah's Sin Engraved (17:1-4)

**17:1** "The sin of Judah is written with a pen of iron, and with the point of a diamond; it is graven upon the tablet of their heart, and upon the horns of your altars.

**17:2** "Like the symbols of their sons are their altars, and their Asherim are by the leafy trees, upon the high hills.

**17:3** "O you that sit upon the mountain, in the field: I will give your substance and all your treasures for a spoil, and your high places, because of sin, throughout all your borders.

**17:4** "And you, even of yourself, shall discontinue from your heritage that I gave you; and I will cause you to serve your enemies in the land which you know not; for you have kindled a fire in my nostrils, which shall burn forever."

---

## Trust in Man vs. Trust in YHWH (17:5-11)

**17:5** Thus says YHWH: "Cursed is the man that trusts in man, and makes flesh his arm, and whose heart departs from YHWH.

**17:6** "For he shall be like a tamarisk in the desert, and shall not see when good comes; but shall inhabit the parched places in the wilderness, a salt land and not inhabited.

**17:7** "Blessed is the man that trusts in YHWH, and whose trust YHWH is.

**17:8** "For he shall be as a tree planted by the waters, and that spreads out its roots by the river, and shall not see when heat comes, but its foliage shall be luxuriant; and shall not be anxious in the year of drought, neither shall cease from yielding fruit.

**17:9** "The heart is deceitful above all things, and it is desperately sick—who can know it?

**17:10** "I YHWH search the heart, I try the reins, even to give every man according to his ways, according to the fruit of his doings."

**17:11** As the partridge that broods over young which she has not brought forth, so is he that gets riches, and not by right; in the midst of his days he shall leave them, and at his end he shall be a fool.

---

## The Throne of Glory (17:12-13)

**17:12** A glorious throne, set on high from the beginning, is the place of our sanctuary.

**17:13** O YHWH, the hope of Israel, all that forsake you shall be ashamed; they that depart from me shall be written in the earth, because they have forsaken YHWH, the fountain of living waters.

---

## Jeremiah's Prayer (17:14-18)

**17:14** Heal me, O YHWH, and I shall be healed; save me, and I shall be saved; for you are my praise.

**17:15** Behold, they say unto me: "Where is the word of YHWH? Let it come now."

**17:16** As for me, I have not hastened from being a shepherd after you; neither have I desired the woeful day; you know; that which came out of my lips was manifest before you.

**17:17** Be not a terror unto me; you are my refuge in the day of evil.

**17:18** Let them be ashamed that persecute me, but let not me be ashamed; let them be dismayed, but let not me be dismayed; bring upon them the day of evil, and destroy them with double destruction.

---

## The Sabbath (17:19-27)

**17:19** Thus said YHWH unto me: "Go, and stand in the gate of the children of the people, whereby the kings of Judah come in, and by which they go out, and in all the gates of Jerusalem;

**17:20** "And say unto them: Hear the word of YHWH, you kings of Judah, and all Judah, and all the inhabitants of Jerusalem, that enter in by these gates:

**17:21** "Thus says YHWH: Take heed for the sake of your souls, and bear no burden on the sabbath day, nor bring it in by the gates of Jerusalem;

**17:22** "Neither carry forth a burden out of your houses on the sabbath day, neither do any work; but hallow the sabbath day, as I commanded your fathers.

**17:23** "But they hearkened not, neither inclined their ear, but made their neck stiff, that they might not hear, nor receive instruction.

**17:24** "And it shall come to pass, if you diligently hearken unto me," says YHWH, "to bring in no burden through the gates of this city on the sabbath day, but to hallow the sabbath day, to do no work therein;

**17:25** "Then shall there enter in by the gates of this city kings and princes sitting upon the throne of David, riding in chariots and on horses, they, and their princes, the men of Judah, and the inhabitants of Jerusalem; and this city shall be inhabited forever.

**17:26** "And they shall come from the cities of Judah, and from the places round about Jerusalem, and from the land of Benjamin, and from the Lowland, and from the mountains, and from the South, bringing burnt-offerings, and sacrifices, and meal-offerings, and frankincense, and bringing sacrifices of thanksgiving, unto the house of YHWH.

**17:27** "But if you will not hearken unto me to hallow the sabbath day, and not to bear a burden and enter in at the gates of Jerusalem on the sabbath day; then will I kindle a fire in the gates thereof, and it shall devour the palaces of Jerusalem, and it shall not be quenched."

---

## Synthesis Notes

**Key Restorations:**

**Engraved Sin (17:1-4):**
**The Key Verse (17:1):**
"The sin of Judah is written with a pen of iron."

*Chattat Yehudah ketuvah be-et barzel*—iron-pen sin.

"With the point of a diamond."

*Be-tzipporen shamir*—diamond point.

"It is graven upon the tablet of their heart."

*Charushahh al-lu'ach libbam*—heart-engraved.

"Upon the horns of your altars."

*U-le-qarnot mizbechoteikhem*—altar horns.

**Indelible Sin:**
Sin is so ingrained it's engraved with iron and diamond on both heart and altar.

"Like the symbols of their sons are their altars."

*Kizkor beneihem mizbechotam*—children remember altars.

"Their Asherim are by the leafy trees."

*Va-ashereihem al-etz ra'anan*—Asherah poles.

"Upon the high hills."

*Al geva'ot ha-gevohot*—high hills.

"I will give your substance and all your treasures for a spoil."

*Chelekha kol-otzrotekha la-baz etten*—treasures spoiled.

"You, even of yourself, shall discontinue from your heritage."

*Ve-shamattah ve-vakh mi-nachalatekha*—discontinue from heritage.

"I will cause you to serve your enemies in the land which you know not."

*Ve-ha'avadtikha et-oyvekha ba-aretz asher lo-yada'ta*—serve enemies.

"You have kindled a fire in my nostrils."

*Ki-esh qedachtem be-appi*—kindled fire.

"Which shall burn forever."

*Ad-olam tuqad*—burn forever.

**Two Trees (17:5-8):**
**The Key Verses (17:5-6):**
"Cursed is the man that trusts in man."

*Arur ha-gever asher yivtach ba-adam*—cursed man-truster.

"Makes flesh his arm."

*Ve-sam basar zero'o*—flesh as arm.

"Whose heart departs from YHWH."

*U-min-YHWH yasur libbo*—heart departs.

"He shall be like a tamarisk in the desert."

*Ve-hayah ke-ar'ar ba-aravah*—desert shrub.

"Shall not see when good comes."

*Ve-lo yir'eh ki-yavo tov*—won't see good.

"Shall inhabit the parched places in the wilderness."

*Ve-shakhan charerim ba-midbar*—parched places.

"A salt land and not inhabited."

*Eretz melechah ve-lo teshev*—salt, uninhabited.

**The Key Verses (17:7-8):**
"Blessed is the man that trusts in YHWH."

*Barukh ha-gever asher yivtach ba-YHWH*—blessed YHWH-truster.

"Whose trust YHWH is."

*Ve-hayah YHWH mivtacho*—YHWH = trust.

"He shall be as a tree planted by the waters."

*Ve-hayah ke-etz shatul al-mayim*—tree by waters. (Cf. Psalm 1:3)

"Spreads out its roots by the river."

*Ve-al-yuval yeshalach shorashav*—roots by river.

"Shall not see when heat comes."

*Ve-lo yir'eh ki-yavo chom*—won't see heat.

"Its foliage shall be luxuriant."

*Ve-hayah alehu ra'anan*—luxuriant leaves.

"Shall not be anxious in the year of drought."

*U-vi-shenat batzzoret lo yid'ag*—no drought anxiety.

"Neither shall cease from yielding fruit."

*Ve-lo yamish me-asot peri*—keeps bearing fruit.

**Parallel to Psalm 1:**
This blessed-cursed contrast parallels Psalm 1:1-6.

**The Key Verses (17:9-10):**
**The Key Verse (17:9):**
"The heart is deceitful above all things."

*Aqov ha-lev mi-kol*—heart deceitful above all.

"It is desperately sick."

*Ve-anush hu*—desperately sick.

"Who can know it?"

*Mi yeda'ennu*—who knows?

**The Key Verse (17:10):**
"I YHWH search the heart."

*Ani YHWH choqer lev*—YHWH searches heart.

"I try the reins."

*Bochen kelayot*—tests kidneys (= motives).

"To give every man according to his ways."

*Ve-latet le-ish ki-drakkhav*—according to ways.

"According to the fruit of his doings."

*Ki-feri ma'alalav*—fruit of doings.

**Ill-Gotten Riches (17:11):**
"The partridge that broods over young which she has not brought forth."

*Qore dagar ve-lo yalad*—partridge hatching others' eggs.

"He that gets riches, and not by right."

*Oseh osher ve-lo ve-mishpat*—riches without right.

"In the midst of his days he shall leave them."

*Ba-chatzi yamav ya'azvenu*—leaves riches mid-life.

"At his end he shall be a fool."

*U-ve-acharito yihyeh naval*—fool at end.

**Throne and Hope (17:12-13):**
"A glorious throne, set on high from the beginning."

*Kisse khavod marom me-rishon*—glorious throne.

"Is the place of our sanctuary."

*Meqom miqdashenu*—sanctuary place.

**The Key Verse (17:13):**
"O YHWH, the hope of Israel."

*Miqweh Yisra'el YHWH*—hope of Israel.

"All that forsake you shall be ashamed."

*Kol-ozvekha yevoshu*—forsakers shamed.

"They that depart from me shall be written in the earth."

*Yesuray ba-aretz yikkatev*—written in earth (= forgotten).

"Because they have forsaken YHWH, the fountain of living waters."

*Ki azvu meqor mayim-chayyim et-YHWH*—fountain of living waters. (Repeats 2:13)

**Jeremiah's Prayer (17:14-18):**
**The Key Verse (17:14):**
"Heal me, O YHWH, and I shall be healed."

*Refa'eni YHWH ve-erafe*—heal me.

"Save me, and I shall be saved."

*Hoshi'eni ve-ivvashe'ah*—save me.

"For you are my praise."

*Ki tehillati attah*—you = praise.

"'Where is the word of YHWH? Let it come now.'"

*Ayyeh devar-YHWH yavo na*—mocking challenge.

"I have not hastened from being a shepherd after you."

*Va-ani lo-atztti me-ro'eh acharekha*—didn't hasten from shepherd role.

"Neither have I desired the woeful day."

*Ve-yom anush lo hit'avveiti*—didn't desire woeful day.

"You know."

*Attah yada'ta*—you know.

"That which came out of my lips was manifest before you."

*Motza sefatai nokhach panekha hayah*—lips manifest before you.

"Be not a terror unto me."

*Al-tehi-li li-mechittah*—don't be terror.

"You are my refuge in the day of evil."

*Machaseh attah li be-yom ra'ah*—refuge in evil day.

"Let them be ashamed that persecute me."

*Yevoshu rodfai*—persecutors shamed.

"Let not me be ashamed."

*Ve-al-evoshahh ani*—not me shamed.

"Bring upon them the day of evil."

*Havi aleihem yom ra'ah*—bring evil day.

"Destroy them with double destruction."

*U-mishneh shivaron shavveram*—double destruction.

**Sabbath (17:19-27):**
"Stand in the gate of the children of the people."

*Amod be-sha'ar benei-ha-am*—people's gate.

"Bear no burden on the sabbath day."

*Ve-al-tis'u massa be-yom ha-shabbat*—no sabbath burden.

"Nor bring it in by the gates of Jerusalem."

*Ve-havito be-sha'arei Yerushalayim*—not through gates.

"Neither carry forth a burden out of your houses."

*Ve-lo-totzi'u massa mi-batteikem*—not from houses.

"Neither do any work."

*Ve-khol-melakah lo ta'asu*—no work.

"Hallow the sabbath day."

*Ve-qiddashtem et-yom ha-shabbat*—hallow sabbath.

"As I commanded your fathers."

*Ka-asher tzivviti et-avoteikhem*—commanded fathers.

"They hearkened not, neither inclined their ear."

*Ve-lo sham'u ve-lo hittu et-oznam*—didn't hear.

"Made their neck stiff."

*Va-yaqshu et-orpam*—stiff neck.

**Conditional Promise (17:24-27):**
"If you diligently hearken unto me."

*Im-shamo'a tishme'un elai*—if diligently hear.

"To bring in no burden through the gates... on the sabbath."

*Le-vilti havi massa be-sha'arei ha-ir ha-zot be-yom ha-shabbat*—no sabbath burden.

"Then shall there enter in by the gates... kings and princes sitting upon the throne of David."

*U-va'u be-sha'arei ha-ir ha-zot melakhim ve-sarim yoshevim al-kisse David*—Davidic kings enter.

"Riding in chariots and on horses."

*Rokhevim ba-rekhev u-va-susim*—chariots and horses.

"This city shall be inhabited forever."

*Ve-yashovah ha-ir ha-zot le-olam*—forever inhabited.

"But if you will not hearken unto me to hallow the sabbath day."

*Ve-im-lo tishme'u elai le-qaddesh et-yom ha-shabbat*—if not hallow.

"I will kindle a fire in the gates."

*Ve-hitztzatti esh be-she'arekha*—fire kindled.

"It shall devour the palaces of Jerusalem."

*Ve-akhelah armenot Yerushalayim*—palaces devoured.

"It shall not be quenched."

*Ve-lo tikhbeh*—not quenched.

**Archetypal Layer:** Jeremiah 17 contains **"The heart is deceitful above all things, and it is desperately sick—who can know it?" (17:9)**, **"I YHWH search the heart" (17:10)**, **the two trees (17:5-8)**—paralleling Psalm 1, and **"the fountain of living waters" (17:13)**.

**Ethical Inversion Applied:**
- "The sin of Judah is written with a pen of iron"—iron-pen sin
- "With the point of a diamond"—diamond-engraved
- "It is graven upon the tablet of their heart"—heart-engraved
- "You have kindled a fire in my nostrils"—fire kindled
- "Cursed is the man that trusts in man"—cursed man-truster
- "Makes flesh his arm"—flesh as strength
- "He shall be like a tamarisk in the desert"—desert shrub
- "Shall not see when good comes"—misses good
- "Blessed is the man that trusts in YHWH"—blessed YHWH-truster
- "He shall be as a tree planted by the waters"—Psalm 1 parallel
- "Shall not be anxious in the year of drought"—no drought anxiety
- "Neither shall cease from yielding fruit"—perpetual fruit
- "The heart is deceitful above all things"—deceitful heart
- "It is desperately sick"—sick heart
- "Who can know it?"—unknowable
- "I YHWH search the heart"—YHWH searches
- "I try the reins"—tests motives
- "To give every man according to his ways"—according to ways
- "He that gets riches, and not by right"—unjust riches
- "At his end he shall be a fool"—fool at end
- "A glorious throne, set on high from the beginning"—glorious throne
- "O YHWH, the hope of Israel"—hope of Israel
- "They have forsaken YHWH, the fountain of living waters"—fountain forsaken
- "Heal me, O YHWH, and I shall be healed"—healing prayer
- "'Where is the word of YHWH? Let it come now'"—mocking
- "Be not a terror unto me; you are my refuge"—refuge
- "Bear no burden on the sabbath day"—sabbath
- "If you diligently hearken... kings... shall enter"—conditional promise
- "But if you will not hearken... I will kindle a fire"—conditional threat

**Modern Equivalent:** Jeremiah 17:9-10's "The heart is deceitful above all things" is foundational for understanding human nature's corruption and need for divine searching. The two trees (17:5-8) parallel Psalm 1 and show the contrast between trusting man versus trusting YHWH.

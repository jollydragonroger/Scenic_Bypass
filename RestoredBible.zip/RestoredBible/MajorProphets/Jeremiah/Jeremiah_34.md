# Jeremiah 34: The Broken Covenant of Liberty

*From the Hebrew: הַדָּבָר אֲשֶׁר הָיָה אֶל־יִרְמְיָהוּ (Ha-Davar Asher Hayah El-Yirmeyahu) — The Word That Came to Jeremiah*

---

## Message to Zedekiah (34:1-7)

**34:1** The word which came unto Jeremiah from YHWH, when Nebuchadnezzar king of Babylon, and all his army, and all the kingdoms of the earth that were under his dominion, and all the peoples, fought against Jerusalem, and against all the cities thereof, saying:

**34:2** "Thus says YHWH, the God of Israel: Go, and speak to Zedekiah king of Judah, and tell him: Thus says YHWH: Behold, I will give this city into the hand of the king of Babylon, and he shall burn it with fire;

**34:3** "And you shall not escape out of his hand, but shall surely be taken, and delivered into his hand; and your eyes shall behold the eyes of the king of Babylon, and he shall speak with you mouth to mouth, and you shall go to Babylon.

**34:4** "Yet hear the word of YHWH, O Zedekiah king of Judah: Thus says YHWH concerning you: You shall not die by the sword;

**34:5** "You shall die in peace; and with the burnings of your fathers, the former kings that were before you, so shall they make a burning for you; and they shall lament you: 'Ah lord!' For I have spoken the word," says YHWH.

**34:6** Then Jeremiah the prophet spoke all these words unto Zedekiah king of Judah in Jerusalem,

**34:7** When the king of Babylon's army fought against Jerusalem, and against all the cities of Judah that were left, against Lachish and against Azekah; for these alone remained of the cities of Judah as fortified cities.

---

## The Broken Covenant of Liberty (34:8-22)

**34:8** The word that came unto Jeremiah from YHWH, after that the king Zedekiah had made a covenant with all the people that were at Jerusalem, to proclaim liberty unto them;

**34:9** That every man should let his man-servant, and every man his maid-servant, being a Hebrew man or a Hebrew woman, go free; that none should make bondmen of them, even of a Jew his brother;

**34:10** And all the princes and all the people hearkened, that had entered into the covenant to let every one his man-servant, and every one his maid-servant, go free, and not to make bondmen of them any more; they hearkened, and let them go;

**34:11** But afterwards they turned, and caused the servants and the handmaids, whom they had let go free, to return, and brought them into subjection for servants and for handmaids.

**34:12** Therefore the word of YHWH came to Jeremiah from YHWH, saying:

**34:13** "Thus says YHWH, the God of Israel: I made a covenant with your fathers in the day that I brought them forth out of the land of Egypt, out of the house of bondage, saying:

**34:14** "'At the end of seven years you shall let go every man his brother that is a Hebrew, that has been sold unto you, and has served you six years, you shall let him go free from you'; but your fathers hearkened not unto me, neither inclined their ear.

**34:15** "And you were now turned, and had done that which is right in my eyes, in proclaiming liberty every man to his neighbour; and you had made a covenant before me in the house whereon my name is called;

**34:16** "But you turned and profaned my name, and caused every man his servant, and every man his handmaid, whom you had let go free at their pleasure, to return; and you brought them into subjection, to be unto you for servants and for handmaids."

**34:17** Therefore thus says YHWH: "You have not hearkened unto me, to proclaim liberty, every man to his brother, and every man to his neighbour; behold, I proclaim for you a liberty," says YHWH, "unto the sword, unto the pestilence, and unto the famine; and I will make you a horror unto all the kingdoms of the earth.

**34:18** "And I will give the men that have transgressed my covenant, that have not performed the words of the covenant which they made before me, when they cut the calf in twain and passed between the parts thereof;

**34:19** "The princes of Judah, and the princes of Jerusalem, the officers, and the priests, and all the people of the land, that passed between the parts of the calf;

**34:20** "I will even give them into the hand of their enemies, and into the hand of them that seek their life; and their dead bodies shall be for food unto the fowls of the heaven, and to the beasts of the earth.

**34:21** "And Zedekiah king of Judah and his princes will I give into the hand of their enemies, and into the hand of them that seek their life, and into the hand of the king of Babylon's army, that are gone up from you.

**34:22** "Behold, I will command," says YHWH, "and cause them to return to this city; and they shall fight against it, and take it, and burn it with fire; and I will make the cities of Judah a desolation, without inhabitant."

---

## Synthesis Notes

**Key Restorations:**

**Message to Zedekiah (34:1-7):**
"When Nebuchadnezzar king of Babylon... fought against Jerusalem."

*U-Nevukhadnetztzar melekh-Bavel... nilchamim al-Yerushalayim*—siege.

"All his army, and all the kingdoms of the earth that were under his dominion."

*Ve-khol-cheilo ve-khol-mamlekh ha-aretz memshelet yado ve-khol-ha-ammim*—coalition.

"'I will give this city into the hand of the king of Babylon.'"

*Hineni noten et-ha-ir ha-zot be-yad melekh-Bavel*—give city.

"'He shall burn it with fire.'"

*U-serafah va-esh*—burn.

"'You shall not escape out of his hand.'"

*Ve-attah lo timmalet mi-yado*—won't escape.

"'Shall surely be taken, and delivered into his hand.'"

*Ki tafos tittafes u-ve-yado tinnaten*—caught, delivered.

"'Your eyes shall behold the eyes of the king of Babylon.'"

*Ve-einekha et-einei melekh-Bavel tir'enah*—eyes meet.

"'He shall speak with you mouth to mouth.'"

*U-fiv im-pikha yedabber*—mouth to mouth.

"'You shall go to Babylon.'"

*U-Vavel tavo*—go to Babylon.

**Conditional Promise (34:4-5):**
"'Yet hear the word of YHWH.'"

*Akh shema devar-YHWH*—but hear.

"'You shall not die by the sword.'"

*Lo tamut ba-cherev*—not by sword.

"'You shall die in peace.'"

*Be-shalom tamut*—die in peace.

"'With the burnings of your fathers, the former kings.'"

*Ve-khi-misrefot avotekha ha-melakhim ha-rishonim*—royal burnings.

"'So shall they make a burning for you.'"

*Ken yisrefu-lakh*—burn for you.

"'They shall lament you: "Ah lord!"'"

*Ve-hoy adon yispedu-lakh*—mourning lament.

**Note:**
This conditional promise apparently wasn't fulfilled—Zedekiah's eyes were blinded and he died in Babylonian prison (52:11).

**Last Fortified Cities (34:7):**
"Against Lachish and against Azekah."

*El-Lakhish ve-el-Azekah*—Lachish, Azekah.

"These alone remained of the cities of Judah as fortified cities."

*Ki hennah nish'aru be-arei Yehudah arei mivtzar*—last fortresses.

**Lachish Letters:**
The Lachish letters (ancient ostraca) mention watching for Azekah's fire signals—when they stopped, Azekah had fallen.

**Covenant of Liberty (34:8-11):**
"King Zedekiah had made a covenant with all the people."

*Acharei kharot ha-melekh Tzidqiyyahu berit et-kol-ha-am*—covenant made.

"To proclaim liberty unto them."

*Liqro lahem deror*—proclaim liberty.

"Every man should let his man-servant... go free."

*Le-shallech ish et-avdo ve-ish et-shiphchato... chofshim*—free slaves.

"Being a Hebrew man or a Hebrew woman."

*Ha-ivri ve-ha-ivriyyah*—Hebrew slaves.

"That none should make bondmen of them."

*Le-vilti avod-bam*—no bondage.

"Even of a Jew his brother."

*Be-Yhudi achihu ish*—Jewish brother.

"All the princes and all the people hearkened."

*Va-yishme'u khol-ha-sarim ve-khol-ha-am*—obeyed.

"They hearkened, and let them go."

*Va-yishme'u va-yeshallchu*—released.

**The Key Verse (34:11):**
"But afterwards they turned."

*Va-yashuvu acharei-khen*—but returned.

"Caused the servants and the handmaids... to return."

*Va-yashivu et-ha-avadim ve-et-ha-shefachot*—re-enslaved.

"Brought them into subjection for servants."

*Va-yikhbeshum la-avadim ve-li-shefachot*—subjugated.

**YHWH's Response (34:12-17):**
"I made a covenant with your fathers."

*Anokhi karati berit et-avoteikhem*—Exodus covenant.

"In the day that I brought them forth out of the land of Egypt."

*Be-yom hotzi'i otam me-eretz Mitzrayim*—Exodus.

"Out of the house of bondage."

*Mi-beit avadim*—house of bondage.

**The Key Verse (34:14):**
"'At the end of seven years you shall let go every man his brother.'"

*Mi-qetz sheva shanim teshallchu ish et-achiv ha-ivri*—seven-year release.

"'That has been sold unto you, and has served you six years.'"

*Asher-yimmakker lekha va-avadekha shesh shanim*—six years service.

"'You shall let him go free from you.'"

*Ve-shillachto chofshi me-immakh*—release.

**Deuteronomy 15:12:**
This references Deuteronomy 15:12's sabbatical slave release law.

"Your fathers hearkened not unto me."

*Ve-lo-sham'u avoteikhem elai*—fathers didn't obey.

"You were now turned, and had done that which is right in my eyes."

*Va-tashuvu attem ha-yom va-ta'asu et-ha-yashar be-einai*—did right.

"In proclaiming liberty every man to his neighbour."

*Liqro deror ish le-re'ehu*—proclaimed liberty.

"You had made a covenant before me in the house whereon my name is called."

*Va-tikhretu berit lefanai ba-bayit asher-niqra shemi alav*—temple covenant.

**The Key Verse (34:16):**
"But you turned and profaned my name."

*Va-tashuvu va-techalelu et-shemi*—profaned name.

"Caused every man his servant... to return."

*Va-tashivu ish et-avdo ve-ish et-shiphchato*—re-enslaved.

"You brought them into subjection."

*Va-tikhbeshu otam*—subjugated.

**The Key Verse (34:17):**
"'You have not hearkened unto me, to proclaim liberty.'"

*Lo-shema'tem elai liqro deror*—didn't proclaim liberty.

"'Behold, I proclaim for you a liberty,' says YHWH."

*Hineni qore lakhem deror... la-cherev la-dever ve-la-ra'av*—liberty to sword/plague/famine.

"'Unto the sword, unto the pestilence, and unto the famine.'"

*La-cherev la-dever ve-la-ra'av*—sword, plague, famine.

"'I will make you a horror unto all the kingdoms of the earth.'"

*U-netattim li-za'avah le-khol mamlekh ha-aretz*—horror.

**Ironic "Liberty":**
Since they wouldn't give liberty to slaves, YHWH gives them "liberty"—to be destroyed.

**Covenant Ritual (34:18-20):**
**The Key Verses (34:18-19):**
"The men that have transgressed my covenant."

*Ha-anashim ha-overim et-beriti*—covenant transgressors.

"That have not performed the words of the covenant."

*Asher lo-heqimu et-divrei ha-berit*—didn't perform.

"Which they made before me."

*Asher kartu lefanai*—made before me.

"When they cut the calf in twain and passed between the parts thereof."

*Ha-egel asher kartu li-shnayim va-ya'avru bein betarav*—cut calf, passed between.

**Ancient Covenant Ritual:**
Genesis 15:9-17 describes this ritual—cutting animals and passing between means "may I become like this if I break covenant."

"The princes of Judah, and the princes of Jerusalem."

*Sarei Yehudah ve-sarei Yerushalayim*—Judah/Jerusalem princes.

"The officers, and the priests."

*Ha-sarisim ve-ha-kohanim*—officers, priests.

"All the people of the land, that passed between the parts of the calf."

*Ve-khol am ha-aretz ha-overim bein bitrei ha-egel*—all passed.

"I will even give them into the hand of their enemies."

*Ve-natatti otam be-yad oyveihem*—to enemies.

"Their dead bodies shall be for food unto the fowls of the heaven."

*Ve-hayetah nivlatam le-ma'akhal le-of ha-shamayim*—carrion.

"Zedekiah king of Judah and his princes will I give into the hand of their enemies."

*Ve-et-Tzidqiyyahu melekh-Yehudah ve-et-sarav etten be-yad oyveihem*—Zedekiah given.

**The Key Verse (34:22):**
"'I will command, and cause them to return to this city.'"

*Hineni metzavveh... va-hashivotim el-ha-ir ha-zot*—return Babylonians.

"'They shall fight against it, and take it, and burn it with fire.'"

*Ve-nilchamu alekha u-lekaduha u-serafuha va-esh*—take and burn.

"'I will make the cities of Judah a desolation, without inhabitant.'"

*Ve-et-arei Yehudah etten shemamah me-ein yoshev*—desolation.

**Historical Note:**
The Babylonians temporarily withdrew during Egyptian intervention (37:5), giving hope. But they returned.

**Archetypal Layer:** Jeremiah 34 contains **the last fortified cities—Lachish and Azekah (34:7)**, **the broken covenant of liberty (34:8-16)**, **"I proclaim for you a liberty... unto the sword" (34:17)**—ironic judgment, and **the covenant ritual of passing between animal parts (34:18-19)**.

**Ethical Inversion Applied:**
- "Nebuchadnezzar king of Babylon... fought against Jerusalem"—siege
- "I will give this city into the hand of the king of Babylon"—give city
- "He shall burn it with fire"—burn
- "You shall not escape out of his hand"—won't escape
- "Your eyes shall behold the eyes of the king of Babylon"—eyes meet
- "You shall not die by the sword"—conditional promise
- "You shall die in peace"—peace death (unfulfilled)
- "Against Lachish and against Azekah"—last fortresses
- "These alone remained... as fortified cities"—last standing
- "King Zedekiah had made a covenant... to proclaim liberty"—liberty covenant
- "Every man should let his man-servant... go free"—release slaves
- "All the princes and all the people hearkened"—obeyed
- "They hearkened, and let them go"—released
- "But afterwards they turned"—reversed
- "Caused the servants and the handmaids... to return"—re-enslaved
- "Brought them into subjection for servants"—subjugated
- "I made a covenant with your fathers"—Exodus covenant
- "'At the end of seven years you shall let go every man his brother'"—Deuteronomy 15
- "You were now turned, and had done that which is right in my eyes"—did right
- "But you turned and profaned my name"—profaned
- "Caused every man his servant... to return"—re-enslaved
- "'You have not hearkened unto me, to proclaim liberty'"—didn't proclaim
- "'I proclaim for you a liberty... unto the sword'"—ironic liberty
- "When they cut the calf in twain and passed between the parts"—covenant ritual
- "I will even give them into the hand of their enemies"—to enemies
- "Their dead bodies shall be for food unto the fowls"—carrion
- "'I will command, and cause them to return to this city'"—Babylonians return
- "'They shall fight against it, and take it, and burn it'"—take and burn

**Modern Equivalent:** Jeremiah 34 shows covenant breaking with social consequences. The "liberty" irony (34:17) is powerful—since they wouldn't give liberty to slaves, they receive "liberty" to destruction. The calf-cutting ritual (34:18-19) illuminates Genesis 15:9-17's covenant.

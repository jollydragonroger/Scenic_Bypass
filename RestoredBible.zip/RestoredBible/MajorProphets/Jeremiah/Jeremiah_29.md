# Jeremiah 29: Letter to the Exiles

*From the Hebrew: וְאֵלֶּה דִּבְרֵי הַסֵּפֶר (Ve-Elleh Divrei Ha-Sefer) — And These Are the Words of the Letter*

---

## The Letter to Babylon (29:1-9)

**29:1** Now these are the words of the letter that Jeremiah the prophet sent from Jerusalem unto the residue of the elders of the captivity, and to the priests, and to the prophets, and to all the people, whom Nebuchadnezzar had carried away captive from Jerusalem to Babylon,

**29:2** After that Jeconiah the king, and the queen-mother, and the officers, and the princes of Judah and Jerusalem, and the craftsmen, and the smiths, were departed from Jerusalem,

**29:3** By the hand of Elasah the son of Shaphan, and Gemariah the son of Hilkiah, whom Zedekiah king of Judah sent unto Babylon to Nebuchadnezzar king of Babylon, saying:

**29:4** Thus says YHWH of hosts, the God of Israel, unto all the captivity, whom I have caused to be carried away captive from Jerusalem unto Babylon:

**29:5** "Build houses, and dwell in them; and plant gardens, and eat the fruit of them;

**29:6** "Take wives, and beget sons and daughters; and take wives for your sons, and give your daughters to husbands, that they may bear sons and daughters; and multiply there, and be not diminished.

**29:7** "And seek the peace of the city whither I have caused you to be carried away captive, and pray unto YHWH for it; for in the peace thereof shall you have peace."

**29:8** For thus says YHWH of hosts, the God of Israel: "Let not your prophets that are in the midst of you, and your diviners, deceive you, neither hearken to your dreams which you cause to be dreamed.

**29:9** "For they prophesy falsely unto you in my name; I have not sent them," says YHWH.

---

## After Seventy Years (29:10-14)

**29:10** For thus says YHWH: "After seventy years are accomplished for Babylon, I will remember you, and perform my good word toward you, in causing you to return to this place.

**29:11** "For I know the thoughts that I think toward you," says YHWH, "thoughts of peace, and not of evil, to give you a future and a hope.

**29:12** "And you shall call upon me, and you shall go and pray unto me, and I will hearken unto you.

**29:13** "And you shall seek me, and find me, when you shall search for me with all your heart.

**29:14** "And I will be found of you," says YHWH, "and I will turn your captivity, and gather you from all the nations, and from all the places whither I have driven you," says YHWH; "and I will bring you back unto the place whence I caused you to be carried away captive."

---

## Against Those Who Remain (29:15-19)

**29:15** "Because you have said: 'YHWH has raised us up prophets in Babylon';

**29:16** "Thus says YHWH concerning the king that sits upon the throne of David, and concerning all the people that dwell in this city, your brethren that are not gone forth with you into captivity;

**29:17** "Thus says YHWH of hosts: Behold, I will send upon them the sword, the famine, and the pestilence, and will make them like vile figs, that cannot be eaten, they are so bad.

**29:18** "And I will pursue after them with the sword, with the famine, and with the pestilence, and will make them a horror unto all the kingdoms of the earth, a curse, and an astonishment, and a hissing, and a reproach, among all the nations whither I have driven them;

**29:19** "Because they have not hearkened to my words," says YHWH, "wherewith I sent unto them my servants the prophets, sending them betimes and often; but you would not hear," says YHWH.

---

## Against False Prophets in Babylon (29:20-32)

**29:20** "Hear therefore the word of YHWH, all you of the captivity, whom I have sent away from Jerusalem to Babylon:

**29:21** "Thus says YHWH of hosts, the God of Israel, concerning Ahab the son of Kolaiah, and concerning Zedekiah the son of Maaseiah, who prophesy a lie unto you in my name: Behold, I will deliver them into the hand of Nebuchadrezzar king of Babylon; and he shall slay them before your eyes;

**29:22** "And of them shall be taken up a curse by all the captives of Judah that are in Babylon, saying: 'YHWH make you like Zedekiah and like Ahab, whom the king of Babylon roasted in the fire';

**29:23** "Because they have wrought vile deeds in Israel, and have committed adultery with their neighbours' wives, and have spoken words in my name falsely, which I commanded them not; but I am he that knows, and am witness," says YHWH.

**29:24** And concerning Shemaiah the Nehelamite you shall speak, saying:

**29:25** Thus says YHWH of hosts, the God of Israel: "Because you have sent letters in your own name unto all the people that are at Jerusalem, and to Zephaniah the son of Maaseiah the priest, and to all the priests, saying:

**29:26** "'YHWH has made you priest in the stead of Jehoiada the priest, to be officers in the house of YHWH, over every man that is mad, and makes himself a prophet, that you should put him in the stocks and in shackles.

**29:27** "'Now therefore, why have you not rebuked Jeremiah of Anathoth, who makes himself a prophet to you,

**29:28** "'Forasmuch as he has sent unto us in Babylon, saying: The captivity is long; build houses, and dwell in them; and plant gardens, and eat the fruit of them?'"

**29:29** And Zephaniah the priest read this letter in the ears of Jeremiah the prophet.

**29:30** Then came the word of YHWH unto Jeremiah, saying:

**29:31** "Send to all them of the captivity, saying: Thus says YHWH concerning Shemaiah the Nehelamite: Because that Shemaiah has prophesied unto you, and I sent him not, and he has caused you to trust in a lie;

**29:32** "Therefore thus says YHWH: Behold, I will punish Shemaiah the Nehelamite, and his seed; he shall not have a man to dwell among this people, neither shall he behold the good that I will do unto my people," says YHWH; "because he has spoken rebellion against YHWH."

---

## Synthesis Notes

**Key Restorations:**

**Letter Introduction (29:1-3):**
"The words of the letter that Jeremiah the prophet sent from Jerusalem."

*Divrei ha-sefer asher shalach Yirmeyahu ha-navi mi-Yerushalayim*—letter from Jerusalem.

"Unto the residue of the elders of the captivity."

*El-yeter ziqnei ha-golah*—remaining elders.

"To the priests, and to the prophets, and to all the people."

*Ve-el-ha-kohanim ve-el-ha-nevi'im ve-el-kol-ha-am*—all groups.

"Whom Nebuchadnezzar had carried away captive."

*Asher heglah Nevukhadnetztzar*—Nebuchadnezzar exiled.

"After that Jeconiah the king, and the queen-mother."

*Acharei tzeit Yekhonyah ha-melekh ve-ha-gevirah*—after 597 BCE.

"By the hand of Elasah the son of Shaphan."

*Be-yad El'asah ben-Shafan*—via Elasah.

"Gemariah the son of Hilkiah."

*Ve-Gemaryah ben-Chilqiyyah*—and Gemariah.

"Whom Zedekiah king of Judah sent unto Babylon."

*Asher shalach Tzidqiyyahu melekh-Yehudah... Bavelah*—Zedekiah's embassy.

**The Key Verses (29:4-7):**
**The Key Verse (29:5):**
"Build houses, and dwell in them."

*Benu vatim ve-shevu*—build and dwell.

"Plant gardens, and eat the fruit of them."

*Ve-nit'u gannot ve-ikhlu et-piryan*—plant and eat.

**The Key Verse (29:6):**
"Take wives, and beget sons and daughters."

*U-qechu nashim ve-holidu banim u-vanot*—marry and have children.

"Take wives for your sons, and give your daughters to husbands."

*U-qechu li-veneikhem nashim ve-et-benotekhem tenu la-anashim*—arrange marriages.

"That they may bear sons and daughters."

*Ve-tiledna banim u-vanot*—grandchildren.

"Multiply there, and be not diminished."

*U-revu sham ve-al-tim'atu*—multiply, don't diminish.

**Settle In:**
Not temporary—plan for long-term residence in Babylon.

**The Key Verse (29:7):**
"Seek the peace of the city whither I have caused you to be carried away captive."

*Ve-dirshu et-shalom ha-ir asher higleiti etkhem shammah*—seek city's peace.

"Pray unto YHWH for it."

*Ve-hitpallelu va'adah el-YHWH*—pray for it.

"For in the peace thereof shall you have peace."

*Ki vi-shlomah yihyeh lakhem shalom*—its peace = your peace.

**Revolutionary Theology:**
Pray for Babylon's welfare—the enemy's peace is your peace.

**False Prophets (29:8-9):**
"Let not your prophets that are in the midst of you... deceive you."

*Al-yashshiyu lakhem nevi'eikhem asher be-qirbkhem*—don't be deceived.

"Neither hearken to your dreams which you cause to be dreamed."

*Ve-al-tishme'u el-chalomotekhem asher attem machalimim*—don't hear dreams.

"They prophesy falsely unto you in my name."

*Ki sheqer hem nivve'im lakhem bi-shemi*—false prophecy.

"I have not sent them."

*Lo shelachtim*—not sent.

**Seventy Years (29:10-14):**
**The Key Verse (29:10):**
"After seventy years are accomplished for Babylon."

*Ki le-fi melo't le-Bavel shiv'im shanah*—70 years for Babylon.

"I will remember you."

*Efqod etkhem*—remember/visit.

"Perform my good word toward you."

*Va-haqimoti aleikhem et-devari ha-tov*—perform good word.

"In causing you to return to this place."

*Le-hashiv etkhem el-ha-maqom ha-zeh*—return here.

**The Key Verse (29:11):**
"I know the thoughts that I think toward you."

*Ki anokhi yada'ti et-ha-machashavot asher anokhi choshev aleikhem*—I know my thoughts.

"Thoughts of peace, and not of evil."

*Machshevot shalom ve-lo le-ra'ah*—peace thoughts, not evil.

"To give you a future and a hope."

*Latet lakhem acharit ve-tiqvah*—future and hope.

**Future and Hope:**
*Acharit* (end/future) and *tiqvah* (hope)—one of Scripture's most quoted verses.

**The Key Verses (29:12-14):**
"You shall call upon me."

*U-qe'ratem oti*—call upon me.

"You shall go and pray unto me."

*Va-halakhtem ve-hitpalleltem elai*—pray to me.

"I will hearken unto you."

*Ve-shama'ti aleikhem*—I will hear.

**The Key Verse (29:13):**
"You shall seek me, and find me."

*U-viqqashtem oti u-metzatem*—seek and find.

"When you shall search for me with all your heart."

*Ki tidreshunni be-khol-levavkhem*—whole heart seeking.

**The Key Verse (29:14):**
"I will be found of you."

*Ve-nimtzeiti lakhem*—I will be found.

"I will turn your captivity."

*Ve-shavti et-shevutkhem*—turn captivity.

"Gather you from all the nations."

*Ve-qibbatzti etkhem mi-kol-ha-goyim*—gather from nations.

"Bring you back unto the place whence I caused you to be carried away."

*Va-hashivoti etkhem el-ha-maqom asher-higleiti etkhem mi-sham*—bring back.

**Against Those Remaining (29:15-19):**
"'YHWH has raised us up prophets in Babylon.'"

*Heqim lanu YHWH nevi'im Bavelah*—claim.

"Concerning the king that sits upon the throne of David."

*El-ha-melekh ha-yoshev el-kisse David*—Zedekiah.

"Concerning all the people that dwell in this city."

*Ve-el-kol-ha-am ha-yoshev ba-ir ha-zot*—Jerusalem dwellers.

"I will send upon them the sword, the famine, and the pestilence."

*Hineni meshalleach bam et-ha-cherev et-ha-ra'av ve-et-ha-daver*—sword, famine, pestilence.

"Will make them like vile figs, that cannot be eaten."

*Ve-natatti otam ka-te'enim ha-sho'arim asher lo-te'akhalnahh me-ro'a*—vile figs. (Cf. 24:8)

"I will pursue after them."

*U-redafti achareihem*—pursue.

"Make them a horror... a curse, and an astonishment."

*U-netattim li-za'avah... li-qelalah u-le-shammah*—horror, curse.

"Because they have not hearkened to my words."

*Ya'an asher-lo sham'u el-devarai*—didn't hear.

**False Prophets in Babylon (29:20-23):**
"Ahab the son of Kolaiah, and... Zedekiah the son of Maaseiah."

*Achav ben-Qolayah ve-el Tzidqiyyahu ben-Ma'aseyah*—two false prophets.

"Who prophesy a lie unto you in my name."

*Ha-nivve'im lakhem bi-shemi shaqer*—false prophecy.

"I will deliver them into the hand of Nebuchadrezzar."

*Hineni notem otam be-yad Nevukhadre'zzar*—to Nebuchadnezzar.

"He shall slay them before your eyes."

*Ve-hikkam le-eineikhem*—kill before you.

"'YHWH make you like Zedekiah and like Ahab.'"

*Yesimkha YHWH ke-Tzidqiyyahu ve-khe-Achav*—curse formula.

"Whom the king of Babylon roasted in the fire."

*Asher-qalam melekh-Bavel ba-esh*—roasted.

"They have wrought vile deeds in Israel."

*Ya'an asher asu nevalah be-Yisra'el*—vile deeds.

"Committed adultery with their neighbours' wives."

*Va-yena'afu et-neshei re'eihem*—adultery.

"Spoken words in my name falsely."

*Va-yedabberu davar bi-shemi sheqer*—false words.

"I am he that knows, and am witness."

*Ve-anokhi yode'a ve-ed*—I know and witness.

**Shemaiah (29:24-32):**
"Shemaiah the Nehelamite."

*Shema'yah ha-Nechelami*—Shemaiah.

"You have sent letters in your own name."

*Ya'an asher shalachta sefarim be-shimkha*—sent letters.

"'YHWH has made you priest in the stead of Jehoiada.'"

*YHWH netankha kohen tachat Yehoyada ha-kohen*—replacing Jehoiada.

"'To be officers in the house of YHWH.'"

*Li-heyot peqidim beit YHWH*—temple officers.

"'Over every man that is mad, and makes himself a prophet.'"

*Le-khol-ish meshugga u-mitnabba*—over "mad" prophets.

"'That you should put him in the stocks.'"

*Ve-natattah oto el-ha-mahpakhet*—in stocks.

"'Why have you not rebuked Jeremiah of Anathoth?'"

*Ve-attah lammah lo ga'arta be-Yirmeyahu ha-Anatoti*—why not rebuke?

"'Who makes himself a prophet to you.'"

*Ha-mitnabba lakhem*—making himself prophet.

"Zephaniah the priest read this letter in the ears of Jeremiah."

*Va-yiqra Tzefanyah ha-kohen et-ha-sefer ha-zeh be-oznei Yirmeyahu ha-navi*—read to Jeremiah.

"Because that Shemaiah has prophesied unto you, and I sent him not."

*Ya'an asher niba lakhem Shema'yah va-ani lo shelachtiv*—not sent.

"He has caused you to trust in a lie."

*Va-yavtach etkhem al-shaqer*—trust lies.

"I will punish Shemaiah the Nehelamite, and his seed."

*Poqed ani al-Shema'yah ha-Nechelami ve-al-zar'o*—punish him and seed.

"He shall not have a man to dwell among this people."

*Lo-yihyeh lo ish yoshev be-tokh ha-am ha-zeh*—no descendants.

"Neither shall he behold the good that I will do."

*Ve-lo-yir'eh ba-tov asher-ani oseh le-ammi*—won't see good.

"Because he has spoken rebellion against YHWH."

*Ki-sarah dibber al-YHWH*—spoken rebellion.

**Archetypal Layer:** Jeremiah 29 contains **"Seek the peace of the city... pray unto YHWH for it" (29:7)**, **"I know the thoughts that I think toward you... thoughts of peace... to give you a future and a hope" (29:11)**, **"You shall seek me, and find me, when you shall search for me with all your heart" (29:13)**, and **judgment on false prophets in Babylon (29:20-32)**.

**Ethical Inversion Applied:**
- "The words of the letter that Jeremiah the prophet sent"—letter
- "Unto the residue of the elders of the captivity"—to exiles
- "Build houses, and dwell in them"—settle
- "Plant gardens, and eat the fruit of them"—cultivate
- "Take wives, and beget sons and daughters"—marry
- "Multiply there, and be not diminished"—grow
- "Seek the peace of the city whither I have caused you to be carried away captive"—seek city peace
- "Pray unto YHWH for it"—pray for Babylon
- "In the peace thereof shall you have peace"—shared peace
- "Let not your prophets... deceive you"—don't be deceived
- "They prophesy falsely unto you in my name"—false prophecy
- "After seventy years are accomplished for Babylon"—70 years
- "I will remember you"—remember
- "Perform my good word toward you"—good word
- "I know the thoughts that I think toward you"—YHWH's thoughts
- "Thoughts of peace, and not of evil"—peace thoughts
- "To give you a future and a hope"—future and hope
- "You shall call upon me... and I will hearken"—call and answer
- "You shall seek me, and find me"—seek and find
- "When you shall search for me with all your heart"—whole heart
- "I will be found of you"—found
- "I will turn your captivity, and gather you"—restore
- "I will send upon them the sword, the famine, and the pestilence"—judgment on Jerusalem
- "Will make them like vile figs"—vile figs
- "Ahab the son of Kolaiah... Zedekiah the son of Maaseiah"—false prophets
- "Whom the king of Babylon roasted in the fire"—executed
- "They have wrought vile deeds in Israel"—vile deeds
- "Committed adultery with their neighbours' wives"—adultery
- "I am he that knows, and am witness"—YHWH witnesses
- "Shemaiah the Nehelamite"—opponent
- "'Why have you not rebuked Jeremiah?'"—Shemaiah's complaint
- "He shall not have a man to dwell among this people"—no descendants
- "Because he has spoken rebellion against YHWH"—rebellion

**Modern Equivalent:** Jeremiah 29:11 ("I know the plans I have for you... plans to prosper you and not to harm you, plans to give you hope and a future") is one of Scripture's most quoted verses—in context, it's addressed to exiles facing 70 years in Babylon. "Seek the peace of the city" (29:7) established the theology of living faithfully in exile.

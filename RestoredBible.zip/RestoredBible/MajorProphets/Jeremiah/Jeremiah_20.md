# Jeremiah 20: Pashhur and Jeremiah's Deepest Lament

*From the Hebrew: וַיִּשְׁמַע פַּשְׁחוּר (Va-Yishma Pashhur) — And Pashhur Heard*

---

## Pashhur's Persecution (20:1-6)

**20:1** Now Pashhur the son of Immer the priest, who was chief officer in the house of YHWH, heard Jeremiah prophesying these things.

**20:2** Then Pashhur smote Jeremiah the prophet, and put him in the stocks that were in the upper gate of Benjamin, which was in the house of YHWH.

**20:3** And it came to pass on the morrow, that Pashhur brought forth Jeremiah out of the stocks. Then said Jeremiah unto him: "YHWH has not called your name Pashhur, but Magor-missabib.

**20:4** "For thus says YHWH: Behold, I will make you a terror to yourself, and to all your friends; and they shall fall by the sword of their enemies, and your eyes shall behold it; and I will give all Judah into the hand of the king of Babylon, and he shall carry them captive to Babylon, and shall slay them with the sword.

**20:5** "Moreover I will give all the wealth of this city, and all the gains thereof, and all the precious things thereof, yea, all the treasures of the kings of Judah will I give into the hand of their enemies, who shall spoil them, and take them, and carry them to Babylon.

**20:6** "And you, Pashhur, and all that dwell in your house shall go into captivity; and you shall come to Babylon, and there you shall die, and there shall you be buried, you, and all your friends, to whom you have prophesied falsely."

---

## Jeremiah's Deepest Lament (20:7-18)

**20:7** O YHWH, you have enticed me, and I was enticed; you have overcome me, and have prevailed; I am become a laughing-stock all the day, every one mocks me.

**20:8** For as often as I speak, I cry out, I cry: "Violence and spoil!" Because the word of YHWH is made a reproach unto me, and a derision, all the day.

**20:9** And if I say: "I will not make mention of him, nor speak any more in his name," then there is in my heart as it were a burning fire shut up in my bones, and I am weary with forbearing, and I cannot contain.

**20:10** For I have heard the whispering of many: "Terror on every side! Denounce, and we will denounce him!" All my familiar friends watch for my halting: "Peradventure he will be enticed, and we shall prevail against him, and we shall take our revenge on him."

**20:11** But YHWH is with me as a mighty warrior; therefore my persecutors shall stumble, and they shall not prevail; they shall be greatly ashamed, because they have not prospered, even with an everlasting confusion which shall never be forgotten.

**20:12** But, O YHWH of hosts, that tries the righteous, that sees the reins and the heart, let me see your vengeance on them; for unto you have I revealed my cause.

**20:13** Sing unto YHWH, praise YHWH; for he has delivered the soul of the needy from the hand of evil-doers.

**20:14** Cursed be the day wherein I was born; the day wherein my mother bore me, let it not be blessed.

**20:15** Cursed be the man who brought tidings to my father, saying: "A man-child is born unto you," making him very glad.

**20:16** And let that man be as the cities which YHWH overthrew, and repented not; and let him hear a cry in the morning, and an alarm at noontide;

**20:17** Because he slew me not from the womb; and so my mother would have been my grave, and her womb always great.

**20:18** Wherefore came I forth out of the womb to see labour and sorrow, that my days should be consumed in shame?

---

## Synthesis Notes

**Key Restorations:**

**Pashhur's Attack (20:1-2):**
"Pashhur the son of Immer the priest."

*Pashhur ben-Immer ha-kohen*—Pashhur son of Immer.

"Who was chief officer in the house of YHWH."

*Ve-hu faqid nagid be-veit YHWH*—chief officer.

"Heard Jeremiah prophesying these things."

*Va-yishma... et-Yirmeyahu nibe et-ha-devarim ha-elleh*—heard prophecy.

"Pashhur smote Jeremiah the prophet."

*Va-yakkeh Pashhur et-Yirmeyahu ha-navi*—struck Jeremiah.

"Put him in the stocks."

*Va-yitten oto al-ha-mahpakhet*—in stocks.

"In the upper gate of Benjamin."

*Asher be-sha'ar Binyamin ha-elyon*—Benjamin Gate.

"Which was in the house of YHWH."

*Asher be-veit YHWH*—in temple.

**Pashhur Renamed (20:3-6):**
"Pashhur brought forth Jeremiah out of the stocks."

*Va-yotze Pashhur et-Yirmeyahu min-ha-mahpakhet*—released.

**The Key Verse (20:3):**
"YHWH has not called your name Pashhur."

*Lo Pashhur qara YHWH shemekha*—not Pashhur.

"But Magor-missabib."

*Ki im-Magor Missaviv*—Terror-on-Every-Side.

**Name Change:**
*Pashhur* (possibly "prosperity around") becomes *Magor-missabib* ("terror on every side")—a prophetic name change.

"I will make you a terror to yourself, and to all your friends."

*Hineni notenekha le-magor lekha u-le-khol-ohavekha*—terror to self and friends.

"They shall fall by the sword of their enemies."

*Ve-naflu be-cherev oyveihem*—fall by sword.

"Your eyes shall behold it."

*Ve-einekha ro'ot*—eyes see.

"I will give all Judah into the hand of the king of Babylon."

*Ve-et-kol-Yehudah etten be-yad melekh-Bavel*—Judah to Babylon.

"He shall carry them captive to Babylon."

*Ve-heglam Bavelah*—exiled.

"Shall slay them with the sword."

*Ve-hikkam ba-cherev*—slain.

"All the wealth of this city."

*Ve-et-kol-chosen ha-ir ha-zot*—city wealth.

"All the treasures of the kings of Judah."

*Ve-et kol-otzrot malkhei Yehudah*—royal treasures.

"Will I give into the hand of their enemies."

*Etten be-yad oyveihem*—to enemies.

"Who shall spoil them, and take them, and carry them to Babylon."

*U-vazazum u-leqachum ve-hevi'um Bavelah*—spoil, take, carry.

"You, Pashhur... shall go into captivity."

*Ve-attah Pashhur... ba-shevi telekh*—Pashhur captive.

"You shall come to Babylon, and there you shall die."

*U-Vavel tavo ve-sham tamut*—die in Babylon.

"There shall you be buried."

*Ve-sham tiqqaver*—buried there.

"You, and all your friends, to whom you have prophesied falsely."

*Attah ve-khol-ohavekha asher-nibbeita lahem ba-shaqer*—false prophecy.

**Jeremiah's Lament (20:7-13):**
**The Key Verse (20:7):**
"O YHWH, you have enticed me, and I was enticed."

*Pittitani YHWH va-eppat*—you enticed, I was enticed.

"You have overcome me, and have prevailed."

*Chazaqtani va-tukhal*—overpowered, prevailed.

"I am become a laughing-stock all the day."

*Hayiti li-sechoq kol-ha-yom*—laughingstock.

"Every one mocks me."

*Kullo lo'eg li*—all mock.

**The Key Verse (20:8):**
"As often as I speak, I cry out."

*Ki-middei adabber ez'aq*—when I speak, I cry.

"I cry: 'Violence and spoil!'"

*Chamas va-shod eqra*—violence and spoil.

"The word of YHWH is made a reproach unto me."

*Ki-hayah devar-YHWH li le-cherpah*—word = reproach.

"And a derision, all the day."

*U-le-qeles kol-ha-yom*—derision.

**The Key Verse (20:9):**
"If I say: 'I will not make mention of him.'"

*Ve-amarti lo-ezkerennu*—not mention.

"'Nor speak any more in his name.'"

*Ve-lo-adabber od bi-shemo*—not speak.

"Then there is in my heart as it were a burning fire."

*Ve-hayah ve-libbi ke-esh bo'eret*—burning fire.

"Shut up in my bones."

*Atzur be-atzmotai*—shut in bones.

"I am weary with forbearing."

*Ve-nil'eiti kalkel*—weary forbearing.

"I cannot contain."

*Ve-lo ukhal*—cannot contain.

**Fire in Bones:**
The compulsion to prophesy—even when Jeremiah wants to stop, he cannot.

**The Key Verse (20:10):**
"I have heard the whispering of many."

*Ki shama'ti dibbat rabbim*—many whisper.

"'Terror on every side!'"

*Magor missaviv*—terror around.

"'Denounce, and we will denounce him!'"

*Haggidu ve-naggidennu*—denounce him.

"All my familiar friends watch for my halting."

*Kol enosh shelomi shomerim tzal'i*—friends watch for fall.

"'Peradventure he will be enticed.'"

*Ulai yefutteh*—maybe enticed.

"'We shall prevail against him.'"

*Ve-nukhlah lo*—prevail against.

"'We shall take our revenge on him.'"

*Ve-niqqechah niqmatenu mimmenu*—revenge.

**The Key Verse (20:11):**
"But YHWH is with me as a mighty warrior."

*Va-YHWH otti ke-gibbor aritz*—mighty warrior with me.

"Therefore my persecutors shall stumble."

*Al-ken rodfai yikkashelu*—persecutors stumble.

"They shall not prevail."

*Ve-lo yukhalu*—won't prevail.

"They shall be greatly ashamed."

*Boshu me'od*—greatly shamed.

"Because they have not prospered."

*Ki lo hiskkilu*—didn't prosper.

"Even with an everlasting confusion which shall never be forgotten."

*Kelimmat olam lo tishshakach*—never forgotten shame.

**The Key Verse (20:12):**
"O YHWH of hosts, that tries the righteous."

*Va-YHWH Tzeva'ot bochen tzaddiq*—tries righteous.

"That sees the reins and the heart."

*Ro'eh kelayot va-lev*—sees kidneys and heart.

"Let me see your vengeance on them."

*Er'eh niqmatekha mehem*—see vengeance.

"For unto you have I revealed my cause."

*Ki elekha gilliti et-rivi*—revealed cause. (Repeats 11:20)

**The Key Verse (20:13):**
"Sing unto YHWH, praise YHWH."

*Shiru la-YHWH hallelu et-YHWH*—sing, praise.

"For he has delivered the soul of the needy from the hand of evil-doers."

*Ki hitztzil et-nefesh evyon mi-yad mere'im*—delivered needy.

**Birth Curse (20:14-18):**
**The Key Verse (20:14):**
"Cursed be the day wherein I was born."

*Arur ha-yom asher yulladti vo*—cursed birth day.

"The day wherein my mother bore me, let it not be blessed."

*Yom asher-yeladatni immi al-yehi varukh*—not blessed.

**The Key Verse (20:15):**
"Cursed be the man who brought tidings to my father."

*Arur ha-ish asher bissar et-avi*—cursed messenger.

"'A man-child is born unto you.'"

*Yullad-lekha ben zakhar*—son born.

"Making him very glad."

*Samme'ach simmechuhu*—making glad.

"Let that man be as the cities which YHWH overthrew."

*Ve-hayah ha-ish ha-hu ke-arim asher-hafakh YHWH*—like Sodom/Gomorrah.

"And repented not."

*Ve-lo nicham*—no relenting.

"Let him hear a cry in the morning."

*Ve-shama ze'aqah ba-boqer*—morning cry.

"An alarm at noontide."

*U-teru'ah be-et tzohorayim*—noon alarm.

**The Key Verses (20:17-18):**
"Because he slew me not from the womb."

*Asher lo-metani me-rachem*—didn't kill in womb.

"So my mother would have been my grave."

*Va-tehi-li immi qivri*—mother = grave.

"Her womb always great."

*Ve-rachmah harat olam*—eternally pregnant.

"Wherefore came I forth out of the womb?"

*Lammah zeh me-rechem yatzati*—why born?

"To see labour and sorrow."

*Lir'ot amal ve-yagon*—see toil, sorrow.

"That my days should be consumed in shame."

*Va-yikhlu ve-voshet yamai*—days in shame.

**Parallel to Job:**
This birth-curse parallels Job 3:1-26—wishing never to have been born.

**Archetypal Layer:** Jeremiah 20 contains **Pashhur renamed Magor-missabib (20:3)**, **"there is in my heart as it were a burning fire shut up in my bones" (20:9)**, **"YHWH is with me as a mighty warrior" (20:11)**, and **the most extreme of Jeremiah's "confessions" (20:7-18)**—cursing his birth.

**Ethical Inversion Applied:**
- "Pashhur... smote Jeremiah the prophet"—struck prophet
- "Put him in the stocks"—stocks
- "YHWH has not called your name Pashhur, but Magor-missabib"—Terror-on-Every-Side
- "I will make you a terror to yourself"—self-terror
- "I will give all Judah into the hand of the king of Babylon"—Babylon
- "You, Pashhur... shall go into captivity"—captive
- "There you shall die, and there shall you be buried"—die in Babylon
- "You have prophesied falsely"—false prophecy
- "O YHWH, you have enticed me, and I was enticed"—enticed
- "You have overcome me, and have prevailed"—overpowered
- "I am become a laughing-stock all the day"—laughingstock
- "As often as I speak, I cry out"—cry out
- "I cry: 'Violence and spoil!'"—violence message
- "The word of YHWH is made a reproach unto me"—word = reproach
- "'I will not make mention of him, nor speak any more in his name'"—desire to quit
- "Then there is in my heart as it were a burning fire"—fire in heart
- "Shut up in my bones"—can't contain
- "I am weary with forbearing, and I cannot contain"—can't stop
- "'Terror on every side! Denounce, and we will denounce him!'"—enemy whispers
- "All my familiar friends watch for my halting"—friends betray
- "YHWH is with me as a mighty warrior"—warrior YHWH
- "My persecutors shall stumble, and they shall not prevail"—persecutors fail
- "Sing unto YHWH, praise YHWH"—sudden praise
- "Cursed be the day wherein I was born"—cursed birthday
- "Cursed be the man who brought tidings to my father"—cursed messenger
- "Because he slew me not from the womb"—wishing death in womb
- "Wherefore came I forth out of the womb to see labour and sorrow?"—why born?
- "That my days should be consumed in shame"—shame days

**Modern Equivalent:** Jeremiah 20 shows the prophet's psychological extremity. "Fire shut up in my bones" (20:9) shows the compulsion to prophesy. The swing from praise (20:13) to birth-curse (20:14-18) shows emotional range. This is the sixth and final "confession" of Jeremiah.

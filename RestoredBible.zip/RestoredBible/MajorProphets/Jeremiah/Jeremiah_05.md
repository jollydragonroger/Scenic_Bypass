# Jeremiah 5: Not One Righteous

*From the Hebrew: שׁוֹטְטוּ בְּחוּצוֹת יְרוּשָׁלִַם (Shotetu Be-Chutzot Yerushalayim) — Run To and Fro Through the Streets of Jerusalem*

---

## The Search for One Righteous (5:1-9)

**5:1** "Run to and fro through the streets of Jerusalem, and see now, and know, and seek in the broad places thereof, if you can find a man, if there be any that does justly, that seeks truth; and I will pardon her.

**5:2** "And though they say: 'As YHWH lives,' surely they swear falsely."

**5:3** O YHWH, are not your eyes upon truth? You have stricken them, but they were not affected; you have consumed them, but they have refused to receive correction; they have made their faces harder than a rock; they have refused to return.

**5:4** And I said: "Surely these are poor, they are foolish, for they know not the way of YHWH, nor the ordinance of their God.

**5:5** "I will get me unto the great men, and will speak unto them; for they know the way of YHWH, and the ordinance of their God." But these had altogether broken the yoke, and burst the bands.

**5:6** Wherefore a lion out of the forest shall slay them, a wolf of the deserts shall spoil them, a leopard shall watch over their cities, every one that goes out there shall be torn in pieces; because their transgressions are many, their backslidings are increased.

**5:7** "How can I pardon you? Your children have forsaken me, and sworn by no-gods; and when I had fed them to the full, they committed adultery, and assembled themselves in troops at the harlots' houses.

**5:8** "They are become as well-fed horses, lusty stallions; every one neighs after his neighbor's wife.

**5:9** "Shall I not punish for these things?" says YHWH; "and shall not my soul be avenged on such a nation as this?"

---

## Judgment Decreed (5:10-19)

**5:10** "Go up upon her walls, and destroy, but make not a full end; take away her shoots; for they are not YHWH's.

**5:11** "For the house of Israel and the house of Judah have dealt very treacherously against me," says YHWH.

**5:12** "They have belied YHWH, and said: 'It is not he, neither shall evil come upon us; neither shall we see sword nor famine;

**5:13** "'And the prophets shall become wind, and the word is not in them; thus be it done unto them.'"

**5:14** Wherefore thus says YHWH, the God of hosts: "Because you speak this word, behold, I will make my words in your mouth fire, and this people wood, and it shall devour them.

**5:15** "Lo, I will bring a nation upon you from far, O house of Israel," says YHWH; "it is an enduring nation, it is an ancient nation, a nation whose language you know not, neither understand what they say.

**5:16** "Their quiver is an open sepulchre, they are all mighty men.

**5:17** "And they shall eat up your harvest, and your bread, they shall eat up your sons and your daughters, they shall eat up your flocks and your herds, they shall eat up your vines and your fig-trees; they shall batter your fortified cities, wherein you trust, with the sword."

**5:18** "But even in those days," says YHWH, "I will not make a full end with you.

**5:19** "And it shall come to pass, when you shall say: 'Wherefore has YHWH our God done all these things unto us?' then shall you say unto them: 'Like as you have forsaken me, and served strange gods in your land, so shall you serve strangers in a land that is not yours.'"

---

## A Foolish and Senseless People (5:20-31)

**5:20** "Declare this in the house of Jacob, and publish it in Judah, saying:

**5:21** "'Hear now this, O foolish people, and without heart, that have eyes, and see not, that have ears, and hear not:

**5:22** "'Fear you not me?' says YHWH; 'Will you not tremble at my presence? Who have placed the sand for the bound of the sea, an everlasting ordinance, which it cannot pass; and though the waves thereof toss themselves, yet can they not prevail; though they roar, yet can they not pass over it.

**5:23** "'But this people has a revolting and a rebellious heart; they are revolted, and gone.

**5:24** "'Neither say they in their heart: Let us now fear YHWH our God, that gives the rain, the former rain and the latter rain, in its season; that keeps for us the appointed weeks of the harvest.

**5:25** "'Your iniquities have turned away these things, and your sins have withheld good from you.

**5:26** "'For among my people are found wicked men; they pry, as fowlers lie in wait; they set a trap, they catch men.

**5:27** "'As a cage is full of birds, so are their houses full of deceit; therefore they are become great, and grown rich;

**5:28** "'They are grown fat, they are sleek; yea, they overpass in deeds of wickedness; they plead not the cause, the cause of the fatherless, that they might make it prosper; and the right of the needy do they not judge.

**5:29** "'Shall I not punish for these things?' says YHWH; 'shall not my soul be avenged on such a nation as this?'

**5:30** "'An appalling and horrible thing is come to pass in the land;

**5:31** "'The prophets prophesy falsely, and the priests bear rule at their hands; and my people love to have it so; and what will you do in the end thereof?'"

---

## Synthesis Notes

**Key Restorations:**

**The Key Verse (5:1):**
"Run to and fro through the streets of Jerusalem."

*Shotetu be-chutzot Yerushalayim*—search the streets.

"See now, and know, and seek in the broad places thereof."

*U-re'u-na u-de'u u-vaqshu vi-rechovotekha*—search squares.

"If you can find a man."

*Im-timtze'u ish*—find one man.

"If there be any that does justly."

*Im-yesh oseh mishpat*—does justice.

"That seeks truth."

*Mevaqesh emunah*—seeks truth.

"And I will pardon her."

*Ve-eslach lah*—pardon for one.

**Abraham's Negotiation Echo:**
Like Genesis 18:23-32 (Abraham bargaining for Sodom), YHWH seeks even one righteous person.

**False Oaths (5:2-3):**
"Though they say: 'As YHWH lives,' surely they swear falsely."

*Ve-im chai-YHWH yomeru lakhen la-sheqer yishshave'u*—false oaths.

"You have stricken them, but they were not affected."

*Hikkita otam ve-lo-chalu*—struck, not affected.

"You have consumed them, but they have refused to receive correction."

*Killitam me'anu qachat musar*—refused correction.

"They have made their faces harder than a rock."

*Chizzequ feneihem mi-sela*—rock-hard faces.

"They have refused to return."

*Me'anu lashuv*—refused return.

**Poor and Great (5:4-5):**
"Surely these are poor, they are foolish."

*Akh-dallim hem no'alu*—poor and foolish.

"They know not the way of YHWH."

*Ki lo yade'u derekh YHWH*—don't know YHWH's way.

"Nor the ordinance of their God."

*Mishpat Eloheihem*—don't know ordinance.

"I will get me unto the great men."

*Elekhah-li el-ha-gedolim*—go to great ones.

"For they know the way of YHWH."

*Ki hemmah yade'u derekh YHWH*—they know.

"But these had altogether broken the yoke."

*Akh hemmah yachdav shaveru ol*—yoke broken.

"Burst the bands."

*Nittequ mosrot*—bands burst.

**Wild Beasts (5:6):**
"A lion out of the forest shall slay them."

*Al-ken hikkam aryeh mi-ya'ar*—forest lion.

"A wolf of the deserts shall spoil them."

*Ze'ev aravot yeshodddem*—desert wolf.

"A leopard shall watch over their cities."

*Namer shoqed al-areihem*—watching leopard.

"Every one that goes out there shall be torn in pieces."

*Kol-ha-yotze mehenah yittaref*—torn in pieces.

"Their transgressions are many."

*Ki rabbu fish'eihem*—many transgressions.

"Their backslidings are increased."

*Atzmu meshuvoteihem*—increased backslidings.

**The Key Verses (5:7-9):**
"How can I pardon you?"

*Ei la-zot eslach-lakh*—how pardon?

"Your children have forsaken me."

*Banayikh azavuni*—children forsook.

"Sworn by no-gods."

*Va-yishshave'u be-lo elohim*—sworn by non-gods.

"When I had fed them to the full, they committed adultery."

*Va-asbi'a otam va-yina'afu*—fed, they adultered.

"Assembled themselves in troops at the harlots' houses."

*U-veit zonah yitgodadu*—harlot house troops.

"They are become as well-fed horses, lusty stallions."

*Susim mezunanim mashkim hayu*—fed stallions.

"Every one neighs after his neighbor's wife."

*Ish el-eshet re'ehu yitzhalu*—neighing for neighbor's wife.

**The Key Verse (5:9):**
"Shall I not punish for these things?"

*Ha-al-elleh lo-efqod*—shall I not punish?

"Shall not my soul be avenged on such a nation as this?"

*Ve-im be-goy asher-ka-zeh lo titnaqem nafshi*—avenged on such nation? (Repeated in 5:29)

**Denial (5:12-13):**
"They have belied YHWH."

*Kichashu va-YHWH*—denied YHWH.

"'It is not he.'"

*Ve-amru lo hu*—"Not he."

"'Neither shall evil come upon us.'"

*Ve-lo-tavo aleinu ra'ah*—no evil.

"'Neither shall we see sword nor famine.'"

*Ve-cherev ve-ra'av lo nir'eh*—no sword/famine.

"'The prophets shall become wind.'"

*Ve-ha-nevi'im yihyu le-ruach*—prophets = wind.

"'The word is not in them.'"

*Ve-ha-dibber ein bahem*—no word in them.

**Fire Words (5:14):**
"I will make my words in your mouth fire."

*Hineni noten devarai be-fikha le-esh*—word = fire.

"This people wood."

*Ve-ha-am ha-zeh etzim*—people = wood.

"It shall devour them."

*Va-akhalatam*—fire devours.

**Ancient Nation (5:15-17):**
"I will bring a nation upon you from far."

*Hineni mevi aleikhem goy me-merchaq*—nation from far.

"It is an enduring nation."

*Goy eitan hu*—enduring nation.

"It is an ancient nation."

*Goy me-olam hu*—ancient nation.

"A nation whose language you know not."

*Goy lo-teda leshono*—unknown language.

"Their quiver is an open sepulchre."

*Ashpato ke-qever patu'ach*—quiver = open grave.

"They are all mighty men."

*Kullam gibborim*—all mighty.

"They shall eat up your harvest, and your bread."

*Ve-akhal qetzirekha ve-lachmekha*—eat harvest.

"They shall eat up your sons and your daughters."

*Yokhlu banekha u-venotekha*—eat children.

"They shall eat up your flocks and your herds."

*Yokhal tzonekha u-veqarekha*—eat flocks.

"They shall eat up your vines and your fig-trees."

*Yokhal gafnekha u-te'enatekha*—eat vines/figs.

"They shall batter your fortified cities, wherein you trust."

*Yarosh arei mivtzarekha asher attah bote'ach bahenah ba-cherev*—batter cities.

**The Key Verse (5:18):**
"I will not make a full end with you."

*Lo-e'eseh ittkhem kalah*—not full end.

**Exile Explanation (5:19):**
"'Like as you have forsaken me, and served strange gods in your land.'"

*Ka-asher azavtem oti va-ta'avdu et-elohei nekhar be-artzekhem*—forsook, served foreign.

"'So shall you serve strangers in a land that is not yours.'"

*Ken ta'avdu zarim be-eretz lo lakhem*—serve strangers abroad.

**Foolish People (5:20-25):**
"O foolish people, and without heart."

*Am sakal ve-ein lev*—foolish, heartless.

"That have eyes, and see not."

*Einayim lahem ve-lo yir'u*—eyes, no sight.

"That have ears, and hear not."

*Oznayim lahem ve-lo yishma'u*—ears, no hearing.

**The Key Verse (5:22):**
"'Fear you not me?'"

*Ha-oti lo-tira'u*—don't you fear me?

"'Will you not tremble at my presence?'"

*Im mippanai lo tachilu*—won't you tremble?

"'Who have placed the sand for the bound of the sea.'"

*Asher-samti chol gevul la-yam*—sand bounds sea.

"'An everlasting ordinance, which it cannot pass.'"

*Choq-olam ve-lo ya'avrennu*—everlasting bound.

"'Though the waves thereof toss themselves, yet can they not prevail.'"

*Va-yitga'ashu ve-lo yukhalu*—can't prevail.

"This people has a revolting and a rebellious heart."

*Ve-la-am ha-zeh hayah lev sorer u-moreh*—rebellious heart.

"They are revolted, and gone."

*Saru va-yelekhu*—revolted and gone.

"Your iniquities have turned away these things."

*Avonotekhem hittu-elleh*—iniquities turned away blessings.

"Your sins have withheld good from you."

*Ve-chatto'tekhem mane'u ha-tov mikkem*—sins withheld good.

**Wicked Prosperity (5:26-31):**
"Among my people are found wicked men."

*Ki-nimtze'u ve-ammi resha'im*—wicked found.

"They pry, as fowlers lie in wait."

*Yashur ke-shakh yaqushim*—fowler-lurking.

"They set a trap, they catch men."

*Hitzzivu mashchit anashim yilkodu*—trap men.

"As a cage is full of birds."

*Ki-kheluv male of*—bird-filled cage.

"So are their houses full of deceit."

*Ken batteihem mele'im mirmah*—deceit-filled houses.

"Therefore they are become great, and grown rich."

*Al-ken gadelu va-ya'ashiru*—great and rich.

"They are grown fat, they are sleek."

*Shamenu ashtu*—fat and sleek.

"They overpass in deeds of wickedness."

*Gam averu divrei-ra*—exceed in wickedness.

"They plead not the cause, the cause of the fatherless."

*Din lo-danu din yatom*—no orphan justice.

"That they might make it prosper."

*Va-yatzlichu*—no prosperity.

"The right of the needy do they not judge."

*U-mishpat evyonim lo shafatu*—no needy judgment.

**The Key Verses (5:30-31):**
"An appalling and horrible thing is come to pass in the land."

*Shammah u-sha'arurah nihyetah ba-aretz*—appalling thing.

"The prophets prophesy falsely."

*Ha-nevi'im nibe'u va-sheqer*—false prophets.

"The priests bear rule at their hands."

*Ve-ha-kohanim yirdu al-yedeihem*—priests rule by them.

"My people love to have it so."

*Ve-ammi ahevu khen*—people love it.

"What will you do in the end thereof?"

*U-mah-ta'asu le-acharitah*—what at the end?

**Archetypal Layer:** Jeremiah 5 contains **the search for one righteous (5:1)**, **"Shall I not punish for these things?" (5:9, 29)**, **"I will not make a full end" (5:18)**, and **"The prophets prophesy falsely... my people love to have it so" (5:31)**.

**Ethical Inversion Applied:**
- "If you can find a man... that does justly, that seeks truth"—one righteous
- "I will pardon her"—pardon for one
- "They say: 'As YHWH lives,' surely they swear falsely"—false oaths
- "They have made their faces harder than a rock"—rock-hard
- "These had altogether broken the yoke"—yoke broken
- "A lion... a wolf... a leopard"—wild beasts
- "Their transgressions are many"—many sins
- "How can I pardon you?"—how pardon?
- "When I had fed them to the full, they committed adultery"—fed, adultered
- "Every one neighs after his neighbor's wife"—neighing lust
- "Shall I not punish for these things?"—must punish
- "They have belied YHWH, and said: 'It is not he'"—denial
- "'Neither shall evil come upon us'"—false security
- "I will make my words in your mouth fire"—fire words
- "This people wood"—wood people
- "I will bring a nation upon you from far"—distant nation
- "A nation whose language you know not"—unknown language
- "I will not make a full end with you"—not full end
- "'Like as you have forsaken me... so shall you serve strangers'"—fitting punishment
- "O foolish people, and without heart"—heartless fools
- "That have eyes, and see not, that have ears, and hear not"—blind/deaf
- "'Who have placed the sand for the bound of the sea'"—sea bounded
- "Your iniquities have turned away these things"—iniquities divert
- "Your sins have withheld good from you"—sins withhold
- "Among my people are found wicked men"—wicked among people
- "They plead not the cause... of the fatherless"—no orphan justice
- "The prophets prophesy falsely"—false prophets
- "The priests bear rule at their hands"—corrupt priests
- "My people love to have it so"—people love corruption
- "What will you do in the end thereof?"—end question

**Modern Equivalent:** Jeremiah 5:1's search for one righteous echoes Abraham's bargaining for Sodom. "Eyes and see not, ears and hear not" (5:21) is quoted by Jesus (Mark 8:18). The false prophets/corrupt priests/willing people triad (5:31) describes systemic corruption.

# Jeremiah 19: The Broken Flask

*From the Hebrew: כֹּה אָמַר יְהוָה (Koh Amar YHWH) — Thus Says YHWH*

---

## The Potter's Flask (19:1-9)

**19:1** Thus says YHWH: "Go, and get a potter's earthen flask, and take of the elders of the people, and of the elders of the priests;

**19:2** "And go forth unto the valley of the son of Hinnom, which is by the entry of the gate Harsith, and proclaim there the words that I shall tell you;

**19:3** "And say: Hear the word of YHWH, O kings of Judah, and inhabitants of Jerusalem; thus says YHWH of hosts, the God of Israel: Behold, I will bring evil upon this place, which whosoever hears, his ears shall tingle.

**19:4** "Because they have forsaken me, and have estranged this place, and have offered in it unto other gods, whom neither they nor their fathers have known, nor the kings of Judah; and have filled this place with the blood of innocents;

**19:5** "And have built the high places of Baal, to burn their sons in the fire for burnt-offerings unto Baal; which I commanded not, nor spoke it, neither came it into my mind.

**19:6** "Therefore, behold, the days come," says YHWH, "that this place shall no more be called Topheth, nor the valley of the son of Hinnom, but the valley of slaughter.

**19:7** "And I will make void the counsel of Judah and Jerusalem in this place; and I will cause them to fall by the sword before their enemies, and by the hand of them that seek their life; and their carcasses will I give to be food for the fowls of the heaven, and for the beasts of the earth.

**19:8** "And I will make this city an astonishment, and a hissing; every one that passes thereby shall be astonished and hiss because of all its plagues.

**19:9** "And I will cause them to eat the flesh of their sons and the flesh of their daughters, and they shall eat every one the flesh of his friend, in the siege and in the straitness, wherewith their enemies, and they that seek their life, shall straiten them."

---

## Breaking the Flask (19:10-13)

**19:10** "Then shall you break the flask in the sight of the men that go with you,

**19:11** "And shall say unto them: Thus says YHWH of hosts: Even so will I break this people and this city, as one breaks a potter's vessel, that cannot be made whole again; and they shall bury in Topheth, for want of room to bury.

**19:12** "Thus will I do unto this place," says YHWH, "and to the inhabitants thereof, even making this city as Topheth;

**19:13** "And the houses of Jerusalem, and the houses of the kings of Judah, which are defiled, shall be as the place of Topheth, even all the houses upon whose roofs they have offered unto all the host of heaven, and have poured out drink-offerings unto other gods."

---

## Jeremiah in the Temple Court (19:14-15)

**19:14** Then came Jeremiah from Topheth, whither YHWH had sent him to prophesy; and he stood in the court of YHWH's house, and said to all the people:

**19:15** "Thus says YHWH of hosts, the God of Israel: Behold, I will bring upon this city and upon all its towns all the evil that I have pronounced against it; because they have made their neck stiff, that they might not hear my words."

---

## Synthesis Notes

**Key Restorations:**

**Flask Sign-Act (19:1-2):**
"Go, and get a potter's earthen flask."

*Halokh ve-qanita baqbuq yotzer cheres*—get clay flask.

"Take of the elders of the people, and of the elders of the priests."

*U-mi-ziqnei ha-am u-mi-ziqnei ha-kohanim*—bring elders.

"Go forth unto the valley of the son of Hinnom."

*Ve-yatzata el-gei ven-Hinnom*—Hinnom Valley.

"By the entry of the gate Harsith."

*Asher petach sha'ar ha-charsit*—Potsherd Gate.

"Proclaim there the words that I shall tell you."

*Ve-qarata sham et-ha-devarim asher-adabber elekha*—proclaim words.

**Judgment Pronounced (19:3-5):**
"Behold, I will bring evil upon this place."

*Hineni mevi ra'ah al-ha-maqom ha-zeh*—evil on place.

"Whosoever hears, his ears shall tingle."

*Asher kol-shom'o titzzelna oznav*—ears tingle. (Also 1 Samuel 3:11; 2 Kings 21:12)

"They have forsaken me."

*Asher azavuni*—forsook me.

"Have estranged this place."

*Va-yenakkeru et-ha-maqom ha-zeh*—estranged place.

"Offered in it unto other gods."

*Va-yeqatteru-vo le-lohim acherim*—offered to other gods.

"Whom neither they nor their fathers have known."

*Asher lo-yeda'um hemmah va-avoteihem*—unknown gods.

"Have filled this place with the blood of innocents."

*U-mal'u et-ha-maqom ha-zeh dam neqi'im*—innocent blood.

**The Key Verse (19:5):**
"Have built the high places of Baal."

*U-vanu et-bamot ha-Ba'al*—Baal high places.

"To burn their sons in the fire for burnt-offerings unto Baal."

*Lisrof et-beneihem ba-esh olot la-Ba'al*—burn sons to Baal.

"Which I commanded not."

*Asher lo-tzivviti*—not commanded.

"Nor spoke it."

*Ve-lo dibbarti*—didn't speak.

"Neither came it into my mind."

*Ve-lo aletah al-libbi*—never in mind. (Repeats 7:31)

**Valley Renamed (19:6-9):**
"This place shall no more be called Topheth."

*Ve-lo-yiqqare la-maqom ha-zeh od ha-Tofet*—not Topheth.

"Nor the valley of the son of Hinnom."

*Ve-gei ven-Hinnom*—not Hinnom.

"But the valley of slaughter."

*Ki im-gei ha-haregah*—slaughter valley. (Repeats 7:32)

"I will make void the counsel of Judah and Jerusalem."

*U-vaqotti et-atzat Yehudah vi-Yerushalayim*—void counsel.

**Wordplay:**
*Baqbuq* (flask) relates to *baqaq* (make void)—the flask symbolizes YHWH emptying Judah's plans.

"I will cause them to fall by the sword."

*Ve-hippaltim ba-cherev*—fall by sword.

"Their carcasses will I give to be food for the fowls."

*Ve-natatti et-nivlatam le-ma'akhal le-of ha-shamayim*—carrion for birds.

"I will make this city an astonishment."

*Ve-samti et-ha-ir ha-zot le-shammah*—astonishment.

"A hissing."

*Ve-li-shreqah*—hissing.

"Every one that passes thereby shall be astonished and hiss."

*Kol-over alekha yisshom ve-yishroq*—passersby hiss.

"Because of all its plagues."

*Al-kol-makkotekha*—all plagues.

**The Key Verse (19:9):**
"I will cause them to eat the flesh of their sons and the flesh of their daughters."

*Ve-ha'akaltim et-besar beneihem ve-et besar benoteihem*—eat sons/daughters.

"They shall eat every one the flesh of his friend."

*Ve-ish besar re'ehu yokhelu*—eat friends.

"In the siege and in the straitness."

*Ba-matzor u-va-matzoq*—siege straits.

"Wherewith their enemies... shall straiten them."

*Asher yatziqu lahem oyveihem*—enemies straiten.

**Siege Cannibalism:**
This curse fulfills Deuteronomy 28:53-57 and occurred during Babylon's siege (Lamentations 2:20; 4:10).

**Breaking the Flask (19:10-13):**
**The Key Verse (19:10):**
"Then shall you break the flask."

*Ve-shibarta ha-baqbuq*—break flask.

"In the sight of the men that go with you."

*Le-einei ha-anashim ha-holekhim otakh*—before witnesses.

**The Key Verse (19:11):**
"Even so will I break this people and this city."

*Ka-khah eshbor et-ha-am ha-zeh ve-et-ha-ir ha-zot*—break people/city.

"As one breaks a potter's vessel."

*Ka-asher yishbor et-keli ha-yotzer*—break potter's vessel.

"That cannot be made whole again."

*Asher lo-yukhal le-herappe od*—can't be mended.

**Contrast with Chapter 18:**
In chapter 18, the clay on the wheel could be reshaped. Here, the fired flask cannot be mended—judgment is now irreversible.

"They shall bury in Topheth, for want of room to bury."

*U-ve-Tofet yiqberu me-ein maqom liqbor*—bury for lack of room.

"Making this city as Topheth."

*Ve-latet et-ha-ir ha-zot ke-Tofet*—city = Topheth.

"The houses of Jerusalem... which are defiled."

*U-vayu battei Yerushalayim... ha-tema'im*—defiled houses.

"All the houses upon whose roofs they have offered unto all the host of heaven."

*Le-khol ha-battim asher qitteru al-gaggoteihem le-khol tzeva ha-shamayim*—rooftop offerings.

"Poured out drink-offerings unto other gods."

*Ve-hassekh nesakhim le-lohim acherim*—drink offerings.

**Temple Court (19:14-15):**
"Then came Jeremiah from Topheth."

*Va-yavo Yirmeyahu mi-ha-Tofet*—came from Topheth.

"Whither YHWH had sent him to prophesy."

*Asher shelakho YHWH sham le-hinnave*—sent to prophesy.

"He stood in the court of YHWH's house."

*Va-ya'amod ba-chatzer beit-YHWH*—temple court.

"I will bring upon this city and upon all its towns all the evil."

*Hineni mevi el-ha-ir ha-zot ve-al-kol-arekha et-kol-ha-ra'ah*—evil on city.

"That I have pronounced against it."

*Asher dibbarti alekha*—pronounced.

**The Key Verse (19:15):**
"Because they have made their neck stiff."

*Ki hiqshu et-orpam*—stiff neck.

"That they might not hear my words."

*Le-vilti shemo'a et-devarai*—not hear words.

**Archetypal Layer:** Jeremiah 19 contains **the broken flask sign-act (19:1-11)**—contrasting with the reshaped clay of chapter 18, **the valley of slaughter (19:6)**, **child sacrifice condemnation (19:5)**, and **siege cannibalism (19:9)**.

**Ethical Inversion Applied:**
- "Go, and get a potter's earthen flask"—get flask
- "Take of the elders of the people, and of the elders of the priests"—bring witnesses
- "Go forth unto the valley of the son of Hinnom"—Hinnom Valley
- "Behold, I will bring evil upon this place"—evil coming
- "Whosoever hears, his ears shall tingle"—ears tingle
- "They have forsaken me"—forsaken
- "Have filled this place with the blood of innocents"—innocent blood
- "Have built the high places of Baal, to burn their sons"—child sacrifice
- "Which I commanded not, nor spoke it, neither came it into my mind"—never commanded
- "This place shall no more be called Topheth... but the valley of slaughter"—renamed
- "I will make void the counsel of Judah"—counsel voided
- "Their carcasses will I give to be food for the fowls"—carrion
- "I will make this city an astonishment, and a hissing"—astonishment
- "I will cause them to eat the flesh of their sons"—cannibalism
- "In the siege and in the straitness"—siege horrors
- "Then shall you break the flask"—flask broken
- "Even so will I break this people and this city"—people/city broken
- "As one breaks a potter's vessel, that cannot be made whole again"—irreversible
- "They shall bury in Topheth, for want of room to bury"—no burial room
- "All the houses upon whose roofs they have offered unto all the host of heaven"—rooftop worship
- "Because they have made their neck stiff"—stiff neck
- "That they might not hear my words"—didn't hear

**Modern Equivalent:** Jeremiah 19's broken flask contrasts with chapter 18's reshaped clay. Unfired clay can be remolded; a fired, hardened flask cannot be mended. Israel has moved from reformable to irreparably broken. The siege cannibalism (19:9) fulfilled Deuteronomy 28:53-57.

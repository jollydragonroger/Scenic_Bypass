# Jeremiah 3: Faithless Israel, Faithless Judah

*From the Hebrew: לֵאמֹר הֵן יְשַׁלַּח אִישׁ אֶת־אִשְׁתּוֹ (Lemor Hen Yeshallach Ish Et-Ishto) — Saying, If a Man Put Away His Wife*

---

## The Unfaithful Wife (3:1-5)

**3:1** "If a man put away his wife, and she go from him, and become another man's, may he return unto her again? Will not that land be greatly polluted? But you have played the harlot with many lovers; and would you yet return to me?" says YHWH.

**3:2** "Lift up your eyes unto the high hills, and see: Where have you not been lain with? By the ways have you sat for them, as an Arabian in the wilderness; and you have polluted the land with your harlotries and with your wickedness.

**3:3** "Therefore the showers have been withheld, and there has been no latter rain; yet you had a harlot's forehead, you refused to be ashamed.

**3:4** "Did you not just now cry unto me: 'My father, you are the friend of my youth.

**3:5** "'Will he bear grudge forever? Will he keep it to the end?' Behold, you have spoken, but you have done evil things, and have had your way."

---

## Faithless Israel and Treacherous Judah (3:6-11)

**3:6** And YHWH said unto me in the days of Josiah the king: "Have you seen that which backsliding Israel has done? She is gone up upon every high mountain and under every leafy tree, and there has played the harlot.

**3:7** "And I said after she had done all these things: She will return unto me; but she returned not. And her treacherous sister Judah saw it.

**3:8** "And I saw, when, for this very cause that backsliding Israel had committed adultery, I had put her away and given her a bill of divorcement, yet treacherous Judah her sister feared not; but she also went and played the harlot.

**3:9** "And it came to pass through the lightness of her harlotry, that the land was polluted, and she committed adultery with stones and with stocks.

**3:10** "And yet for all this her treacherous sister Judah has not returned unto me with her whole heart, but feignedly," says YHWH.

**3:11** And YHWH said unto me: "Backsliding Israel has proved herself more righteous than treacherous Judah."

---

## A Call to Return (3:12-18)

**3:12** "Go, and proclaim these words toward the north, and say: Return, backsliding Israel, says YHWH; I will not cause my anger to fall upon you; for I am merciful, says YHWH, I will not bear grudge forever.

**3:13** "Only acknowledge your iniquity, that you have transgressed against YHWH your God, and have scattered your ways to the strangers under every leafy tree, and you have not hearkened to my voice," says YHWH.

**3:14** "Return, O backsliding children," says YHWH; "for I am become your husband; and I will take you one of a city, and two of a family, and I will bring you to Zion.

**3:15** "And I will give you shepherds according to my heart, who shall feed you with knowledge and understanding.

**3:16** "And it shall come to pass, when you are multiplied and increased in the land, in those days," says YHWH, "they shall say no more: The ark of the covenant of YHWH; neither shall it come to mind; neither shall they remember it; neither shall they miss it; neither shall it be made any more.

**3:17** "At that time they shall call Jerusalem the throne of YHWH; and all the nations shall be gathered unto it, to the name of YHWH, to Jerusalem; neither shall they walk any more after the stubbornness of their evil heart.

**3:18** "In those days the house of Judah shall walk with the house of Israel, and they shall come together out of the land of the north to the land that I have given for an inheritance unto your fathers."

---

## Israel's Confession (3:19-25)

**3:19** "But I said: How would I put you among the sons, and give you a pleasant land, the goodliest heritage of the nations! And I said: You shall call me, My father; and shall not turn away from following me.

**3:20** "Surely as a wife treacherously departs from her husband, so have you dealt treacherously with me, O house of Israel," says YHWH.

**3:21** A voice is heard upon the high hills, the suppliant weeping of the children of Israel; for they have perverted their way, they have forgotten YHWH their God.

**3:22** "Return, you backsliding children, I will heal your backslidings." "Here we are, we are come unto you; for you are YHWH our God.

**3:23** "Truly vain is the help that is looked for from the hills, the uproar on the mountains; truly in YHWH our God is the salvation of Israel.

**3:24** "But the shameful thing has devoured the labour of our fathers from our youth; their flocks and their herds, their sons and their daughters.

**3:25** "Let us lie down in our shame, and let our confusion cover us; for we have sinned against YHWH our God, we and our fathers, from our youth even unto this day; and we have not hearkened to the voice of YHWH our God."

---

## Synthesis Notes

**Key Restorations:**

**Divorce Imagery (3:1):**
"If a man put away his wife."

*Hen yeshallach ish et-ishto*—divorce scenario.

"She go from him, and become another man's."

*Ve-halakhah me-itto ve-hayetah le-ish-acher*—remarriage.

"May he return unto her again?"

*Ha-yashuv elekha od*—can he return? (Deuteronomy 24:1-4 says no)

"Will not that land be greatly polluted?"

*Ha-lo chanof techenaf ha-aretz ha-hi*—land polluted.

"You have played the harlot with many lovers."

*Ve-att zanit re'im rabbim*—many lovers.

"Would you yet return to me?"

*Ve-shov elai*—yet return?

**Harlotry Described (3:2-5):**
"Lift up your eyes unto the high hills."

*Se'i einayikh al-shefayim u-re'i*—look at high places.

"Where have you not been lain with?"

*Eifo lo shuggalt*—where not defiled?

"By the ways have you sat for them."

*Al-derakhim yashavt lahem*—roadside waiting.

"As an Arabian in the wilderness."

*Ka-aravi ba-midbar*—like desert Arab.

"You have polluted the land with your harlotries."

*Va-tachanifi eretz bi-znutayikh*—land polluted.

"The showers have been withheld."

*Va-yimman'u revivim*—rain withheld.

"There has been no latter rain."

*U-malqosh lo hayah*—no spring rain.

"Yet you had a harlot's forehead."

*U-metzach ishah zonah hayah lakh*—harlot's forehead.

"You refused to be ashamed."

*Me'ant hikkaklem*—refused shame.

**Two Sisters (3:6-11):**
"In the days of Josiah the king."

*Bi-yemei Yoshiyyahu ha-melekh*—Josiah's time.

"Backsliding Israel."

*Meshuvah Yisra'el*—faithless Israel.

"She is gone up upon every high mountain."

*Halekhah hi al-kol-har gavoah*—high mountains.

"Under every leafy tree."

*Ve-el-tachat kol-etz ra'anan*—green trees.

"There has played the harlot."

*Va-tizni sham*—harlotry there.

"She will return unto me."

*Tashuv elai*—expected return.

"But she returned not."

*Ve-lo shavah*—didn't return.

"Her treacherous sister Judah saw it."

*Va-tere bogodah achutah Yehudah*—Judah saw.

**The Key Verse (3:8):**
"For this very cause that backsliding Israel had committed adultery."

*Al-odot asher na'afah meshuvah Yisra'el*—adultery cause.

"I had put her away."

*Shillachttikha*—put away.

"Given her a bill of divorcement."

*Va-etten et-sefer kerittutekha elekha*—divorce certificate (722 BCE exile).

"Yet treacherous Judah her sister feared not."

*Ve-lo yar'ah bogodah achutah Yehudah*—Judah didn't fear.

"She also went and played the harlot."

*Va-telekh va-tizni gam-hi*—also harloted.

"Through the lightness of her harlotry."

*Mi-qol zanutah*—lightness of harlotry.

"She committed adultery with stones and with stocks."

*Va-tina'af et-ha-even ve-et-ha-etz*—stone and wood adultery.

**The Key Verse (3:10):**
"Judah has not returned unto me with her whole heart."

*Lo-shavah elai bogodah Yehudah be-khol-libbah*—not whole-hearted.

"But feignedly."

*Ki im-be-sheqer*—feignedly.

**The Key Verse (3:11):**
"Backsliding Israel has proved herself more righteous than treacherous Judah."

*Tziddekah nafshah meshuvah Yisra'el mi-bogodah Yehudah*—Israel more righteous.

**Call to Return (3:12-18):**
"Go, and proclaim these words toward the north."

*Halokh ve-qarata et-ha-devarim ha-elleh tzafonah*—proclaim north (to exiled Israel).

**The Key Verse (3:12):**
"Return, backsliding Israel."

*Shuvah meshuvah Yisra'el*—return, faithless.

"I will not cause my anger to fall upon you."

*Lo-appil panai bakhem*—won't frown.

"For I am merciful."

*Ki-chasid ani*—I am merciful.

"I will not bear grudge forever."

*Lo ettor le-olam*—won't grudge forever.

**The Key Verse (3:13):**
"Only acknowledge your iniquity."

*Akh de'i avonek*—just acknowledge.

"That you have transgressed against YHWH your God."

*Ki va-YHWH Elohayikh pasha'at*—transgressed.

"Have scattered your ways to the strangers."

*Va-tefazzeri et-derakhayikh la-zarim*—scattered ways.

"You have not hearkened to my voice."

*U-ve-qoli lo shama'at*—didn't listen.

**The Key Verse (3:14):**
"Return, O backsliding children."

*Shuvu vanim shovavim*—return, wayward children.

"For I am become your husband."

*Ki anokhi ba'alti vakhem*—I am husband.

"I will take you one of a city, and two of a family."

*Ve-laqachti etkhem echad me-ir u-shenayim mi-mishpachah*—one from city, two from family.

"I will bring you to Zion."

*Ve-heveti etkhem Tziyyon*—bring to Zion.

**The Key Verse (3:15):**
"I will give you shepherds according to my heart."

*Ve-natatti lakhem ro'im ke-libbi*—heart-shepherds.

"Who shall feed you with knowledge and understanding."

*Ve-ra'u etkhem de'ah ve-haskil*—feed with knowledge.

**The Key Verse (3:16):**
"They shall say no more: The ark of the covenant of YHWH."

*Lo-yomru od aron-berit-YHWH*—no more ark mention.

"Neither shall it come to mind."

*Ve-lo ya'aleh al-lev*—not on mind.

"Neither shall they remember it."

*Ve-lo yizkeru-vo*—not remembered.

"Neither shall they miss it."

*Ve-lo yifqodu*—not missed.

"Neither shall it be made any more."

*Ve-lo ye'aseh od*—not made again.

**The Key Verse (3:17):**
"At that time they shall call Jerusalem the throne of YHWH."

*Ba-et ha-hi yiqre'u li-Yerushalayim kisse YHWH*—Jerusalem = YHWH's throne.

"All the nations shall be gathered unto it."

*Ve-niqwwu elekha kol-ha-goyim*—nations gathered.

**Confession (3:21-25):**
"A voice is heard upon the high hills."

*Qol al-shefayim nishma*—voice heard.

"The suppliant weeping of the children of Israel."

*Bekhi tachanunei benei Yisra'el*—Israel's weeping.

"They have perverted their way."

*Ki he'evvu et-darkkam*—perverted way.

"They have forgotten YHWH their God."

*Shakechu et-YHWH Eloheihem*—forgot YHWH.

**The Key Verse (3:22):**
"Return, you backsliding children, I will heal your backslidings."

*Shuvu banim shovavim erpa meshuvotekhem*—return, I'll heal.

"'Here we are, we are come unto you.'"

*Hinnenu atanu lakh*—here we come.

"'For you are YHWH our God.'"

*Ki attah YHWH Eloheinu*—you are our God.

"Truly in YHWH our God is the salvation of Israel."

*Akhen ba-YHWH Eloheinu teshu'at Yisra'el*—salvation in YHWH.

"Let us lie down in our shame."

*Nishkevah ve-voshttenu*—lie in shame.

"Let our confusion cover us."

*U-tekhasenu kelimmatenu*—confusion covers.

"We have sinned against YHWH our God."

*Ki la-YHWH Eloheinu chatanu*—sinned against YHWH.

**Archetypal Layer:** Jeremiah 3 uses **divorce imagery (3:1, 8)**, compares **faithless Israel with treacherous Judah (3:6-11)**, and offers **"Return, backsliding children, I will heal your backslidings" (3:22)**.

**Ethical Inversion Applied:**
- "If a man put away his wife... may he return unto her again?"—divorce law
- "You have played the harlot with many lovers"—spiritual adultery
- "Would you yet return to me?"—grace question
- "You had a harlot's forehead, you refused to be ashamed"—shamelessness
- "Backsliding Israel"—faithless Israel
- "Her treacherous sister Judah"—treacherous Judah
- "I had put her away and given her a bill of divorcement"—722 BCE
- "Treacherous Judah her sister feared not"—Judah didn't learn
- "Judah has not returned unto me with her whole heart, but feignedly"—fake repentance
- "Backsliding Israel has proved herself more righteous than treacherous Judah"—Israel better
- "Return, backsliding Israel... for I am merciful"—mercy offered
- "Only acknowledge your iniquity"—acknowledgment required
- "I am become your husband"—husband role
- "I will give you shepherds according to my heart"—good shepherds
- "They shall say no more: The ark of the covenant"—ark obsolete
- "They shall call Jerusalem the throne of YHWH"—Jerusalem = throne
- "All the nations shall be gathered unto it"—nations gather
- "Return, you backsliding children, I will heal your backslidings"—healing offered
- "'Here we are, we are come unto you'"—confession
- "Truly in YHWH our God is the salvation of Israel"—salvation in YHWH
- "We have sinned against YHWH our God"—sin confession

**Modern Equivalent:** Jeremiah 3 uses marriage imagery to describe Israel's unfaithfulness, similar to Hosea. The remarkable statement that the ark will be forgotten (3:16) anticipates a more spiritual worship. "Shepherds according to my heart" (3:15) contrasts with Judah's faithless leaders.

# Jeremiah 22: Oracles Against Judah's Kings

*From the Hebrew: כֹּה אָמַר יְהוָה (Koh Amar YHWH) — Thus Says YHWH*

---

## Message to the Royal House (22:1-9)

**22:1** Thus says YHWH: "Go down to the house of the king of Judah, and speak there this word,

**22:2** "And say: Hear the word of YHWH, O king of Judah, that sits upon the throne of David, you, and your servants, and your people that enter in by these gates.

**22:3** "Thus says YHWH: Execute justice and righteousness, and deliver the spoiled out of the hand of the oppressor; and do no wrong, do no violence, to the stranger, the fatherless, nor the widow, neither shed innocent blood in this place.

**22:4** "For if you do this thing indeed, then shall there enter in by the gates of this house kings sitting upon the throne of David, riding in chariots and on horses, he, and his servants, and his people.

**22:5** "But if you will not hear these words, I swear by myself," says YHWH, "that this house shall become a desolation."

**22:6** For thus says YHWH concerning the house of the king of Judah: "You are Gilead unto me, and the head of Lebanon; yet surely I will make you a wilderness, and cities which are not inhabited.

**22:7** "And I will prepare destroyers against you, every one with his weapons; and they shall cut down your choice cedars, and cast them into the fire.

**22:8** "And many nations shall pass by this city, and they shall say every man to his neighbour: 'Wherefore has YHWH done thus unto this great city?'

**22:9** "Then they shall answer: 'Because they forsook the covenant of YHWH their God, and worshipped other gods, and served them.'"

---

## Concerning Shallum (Jehoahaz) (22:10-12)

**22:10** Weep not for the dead, neither bemoan him; but weep sore for him that goes away, for he shall return no more, nor see his native country.

**22:11** For thus says YHWH touching Shallum the son of Josiah, king of Judah, who reigned instead of Josiah his father, and who went forth out of this place: "He shall not return there any more;

**22:12** "But in the place whither they have led him captive, there shall he die, and he shall see this land no more."

---

## Concerning Jehoiakim (22:13-19)

**22:13** Woe unto him that builds his house by unrighteousness, and his chambers by injustice; that uses his neighbour's service without wages, and gives him not his hire;

**22:14** That says: "I will build me a wide house and spacious chambers," and cuts him out windows; and it is ceiled with cedar, and painted with vermilion.

**22:15** Shall you reign, because you strive to excel in cedar? Did not your father eat and drink, and do justice and righteousness? Then it was well with him.

**22:16** He judged the cause of the poor and needy; then it was well. Is not this to know me? says YHWH.

**22:17** But your eyes and your heart are not but for your covetousness, and for shedding innocent blood, and for oppression, and for violence, to do it.

**22:18** Therefore thus says YHWH concerning Jehoiakim the son of Josiah, king of Judah: "They shall not lament for him: 'Ah my brother!' or: 'Ah sister!' They shall not lament for him: 'Ah lord!' or: 'Ah his glory!'

**22:19** "He shall be buried with the burial of an ass, drawn and cast forth beyond the gates of Jerusalem."

---

## Concerning Jerusalem (22:20-23)

**22:20** Go up to Lebanon, and cry, and lift up your voice in Bashan; and cry from Abarim, for all your lovers are destroyed.

**22:21** I spoke unto you in your prosperity; but you said: "I will not hear." This has been your manner from your youth, that you hearkened not to my voice.

**22:22** The wind shall feed upon all your shepherds, and your lovers shall go into captivity; surely then shall you be ashamed and confounded for all your wickedness.

**22:23** O inhabitant of Lebanon, that makes your nest in the cedars, how gracious shall you be when pangs come upon you, the pain as of a woman in travail!

---

## Concerning Coniah (Jehoiachin) (22:24-30)

**22:24** "As I live," says YHWH, "though Coniah the son of Jehoiakim king of Judah were the signet upon my right hand, yet would I pluck you thence;

**22:25** "And I will give you into the hand of them that seek your life, and into the hand of them of whom you are afraid, even into the hand of Nebuchadrezzar king of Babylon, and into the hand of the Chaldeans.

**22:26** "And I will cast you out, and your mother that bore you, into another country, where you were not born; and there shall you die.

**22:27** "But to the land whereunto they long to return, there shall they not return."

**22:28** Is this man Coniah a despised broken image? Is he a vessel wherein is no pleasure? Wherefore are they cast out, he and his seed, and are cast into a land which they know not?

**22:29** O land, land, land, hear the word of YHWH.

**22:30** Thus says YHWH: "Write this man childless, a man that shall not prosper in his days; for no man of his seed shall prosper, sitting upon the throne of David, and ruling any more in Judah."

---

## Synthesis Notes

**Key Restorations:**

**Royal House Message (22:1-5):**
"Go down to the house of the king of Judah."

*Red beit melekh-Yehudah*—go to palace.

"O king of Judah, that sits upon the throne of David."

*Melekh Yehudah ha-yoshev al-kisse David*—Davidic throne.

**The Key Verse (22:3):**
"Execute justice and righteousness."

*Asu mishpat u-tzedaqah*—do justice and righteousness.

"Deliver the spoiled out of the hand of the oppressor."

*Ve-hatztzilu gazul mi-yad osheq*—deliver oppressed.

"Do no wrong, do no violence."

*Ve-al-ta'asu ve-al-tachmosu*—no wrong/violence.

"To the stranger, the fatherless, nor the widow."

*Le-ger yatom ve-almanah*—stranger, orphan, widow.

"Neither shed innocent blood."

*Ve-dam naqi al-tishpekhu*—no innocent blood.

**Conditional Promise (22:4-5):**
"If you do this thing indeed."

*Ki im-aso ta'asu et-ha-davar ha-zeh*—if do this.

"Then shall there enter in by the gates... kings sitting upon the throne of David."

*U-va'u be-sha'arei ha-bayit ha-zeh melakhim yoshevim le-David al-kis'o*—kings enter.

"If you will not hear these words."

*Ve-im lo tishme'u et-ha-devarim ha-elleh*—if not hear.

"I swear by myself."

*Bi nishba'atti*—YHWH swears by himself.

"This house shall become a desolation."

*Ki le-chorvah yihyeh ha-bayit ha-zeh*—palace = desolation.

**Gilead/Lebanon (22:6-9):**
"You are Gilead unto me, and the head of Lebanon."

*Gil'ad attah li rosh ha-Levanon*—precious like Gilead/Lebanon.

"I will make you a wilderness."

*Im-lo ashitkha midbar*—wilderness.

"I will prepare destroyers against you."

*Ve-qiddashti alekha mashchitim*—destroyers prepared.

"They shall cut down your choice cedars."

*Ve-karetuu mivchar arazekha*—cedars cut.

"'Wherefore has YHWH done thus unto this great city?'"

*Al-meh asah YHWH ka-khah la-ir ha-gedolah ha-zot*—why this?

"'Because they forsook the covenant of YHWH their God.'"

*Al asher azvu et-berit YHWH Eloheihem*—forsook covenant.

**Shallum/Jehoahaz (22:10-12):**
"Weep not for the dead."

*Al-tivku le-met*—don't weep for dead (Josiah).

"But weep sore for him that goes away."

*Bakho vakhu la-holekh*—weep for exile (Jehoahaz).

"He shall return no more."

*Ki lo yashuv od*—no return.

"Nor see his native country."

*Ve-lo yir'eh et-eretz moladto*—won't see homeland.

"Shallum the son of Josiah."

*Shallum ben-Yoshiyyahu*—Shallum = Jehoahaz (throne name).

"He shall not return there any more."

*Lo-yashuv sham od*—no return.

"In the place whither they have led him captive, there shall he die."

*Ki bi-meqom asher-higlu oto sham yamut*—die in exile (Egypt).

**Jehoiakim (22:13-19):**
**The Key Verse (22:13):**
"Woe unto him that builds his house by unrighteousness."

*Hoy boneh veito be-lo-tzedeq*—woe to unrighteous builder.

"And his chambers by injustice."

*Va-aliyyotav be-lo mishpat*—chambers by injustice.

"That uses his neighbour's service without wages."

*Be-re'ehu ya'avod chinnam*—unpaid labor.

"Gives him not his hire."

*U-fo'alo lo yitten-lo*—no wages.

**The Key Verse (22:14):**
"'I will build me a wide house and spacious chambers.'"

*Evneh-li bayit middot va-aliyyot meruvvachim*—big house.

"Cuts him out windows."

*Ve-qara lo challonai*—windows cut.

"It is ceiled with cedar."

*Ve-safun ba-araz*—cedar ceiling.

"Painted with vermilion."

*U-mash'uach ba-shashar*—vermilion paint.

**The Key Verses (22:15-16):**
"Shall you reign, because you strive to excel in cedar?"

*Ha-timlokh ki attah metachare va-araz*—reign by cedar?

"Did not your father eat and drink, and do justice and righteousness?"

*Avikha halo akhal ve-shatah ve-asah mishpat u-tzedaqah*—Josiah did justice.

"Then it was well with him."

*Az tov lo*—well with him.

**The Key Verse (22:16):**
"He judged the cause of the poor and needy."

*Dan din-ani ve-evyon*—judged poor/needy.

"Then it was well."

*Az tov*—well.

"Is not this to know me?"

*Halo-hi ha-da'at oti*—this is knowing me.

**Knowing YHWH:**
Knowing God = doing justice for the poor.

**The Key Verse (22:17):**
"Your eyes and your heart are not but for your covetousness."

*Ki ein einekha ve-libbkha ki im-al-bitz'ekha*—only covetousness.

"For shedding innocent blood."

*Ve-al dam ha-naqi lishpokh*—shedding blood.

"For oppression, and for violence."

*Ve-al-ha-osheq ve-al-ha-merutzah*—oppression/violence.

**The Key Verses (22:18-19):**
"They shall not lament for him: 'Ah my brother!' or: 'Ah sister!'"

*Lo-yispedu lo hoy achi ve-hoy achot*—no mourning.

"'Ah lord!' or: 'Ah his glory!'"

*Hoy adon ve-hoy hodoh*—no lament.

"He shall be buried with the burial of an ass."

*Qevurat chamor yiqqaver*—donkey burial.

"Drawn and cast forth beyond the gates of Jerusalem."

*Sachov ve-hashlekh me-hal'ah le-sha'arei Yerushalayim*—dragged out.

**Jerusalem (22:20-23):**
"Go up to Lebanon, and cry."

*Ali ha-Levanon u-tza'aqi*—cry on Lebanon.

"Lift up your voice in Bashan."

*U-va-Bashan teni qolekh*—cry in Bashan.

"Cry from Abarim."

*Ve-tza'aqi me-Avarim*—cry from Abarim.

"All your lovers are destroyed."

*Ki nishberu kol-me'ahavayikh*—lovers destroyed.

"I spoke unto you in your prosperity."

*Dibbarti elayikh be-shalwotayikh*—spoke in prosperity.

"You said: 'I will not hear.'"

*Amert lo eshma*—refused.

"This has been your manner from your youth."

*Zeh darkkekh mi-ne'urayikh*—your way from youth.

"You hearkened not to my voice."

*Ki lo-shama'at be-qoli*—didn't hear.

"The wind shall feed upon all your shepherds."

*Kol-ro'ayikh tir'eh ruach*—wind feeds shepherds.

"Your lovers shall go into captivity."

*U-me'ahavayikh ba-shevi yelekhu*—lovers captive.

"O inhabitant of Lebanon, that makes your nest in the cedars."

*Yoshavti ba-Levanon mequnnenet ba-arazim*—nested in cedars.

"How gracious shall you be when pangs come upon you."

*Mah-nechantt be-vo-lakh chavalim*—how will you groan.

**Coniah/Jehoiachin (22:24-30):**
**The Key Verse (22:24):**
"Though Coniah the son of Jehoiakim... were the signet upon my right hand."

*Im-yihyeh Konyahu ben-Yehoyaqim... chotam al-yad yemini*—even signet ring.

"Yet would I pluck you thence."

*Ki mi-sham etteqqenka*—pluck off.

"I will give you into the hand of Nebuchadrezzar."

*U-netattikha be-yad Nevukhadre'zzar*—to Nebuchadnezzar.

"I will cast you out, and your mother that bore you."

*Ve-hettaltikha ve-et-immekha asher yeladtekka*—you and mother cast out.

"Into another country, where you were not born."

*Al-ha-aretz acheret asher lo-yulladtem sham*—foreign land.

"There shall you die."

*Ve-sham tamutu*—die there.

"The land whereunto they long to return, there shall they not return."

*Ve-el-ha-aretz asher-hem menas'im et-nafsham lashuv sham lo yashuvu*—no return.

**The Key Verse (22:28):**
"Is this man Coniah a despised broken image?"

*Ha-etzev nivzeh naphatz ha-ish ha-zeh Konyahu*—despised image.

"Is he a vessel wherein is no pleasure?"

*Im-keli ein chefetz bo*—undesirable vessel.

"Wherefore are they cast out, he and his seed?"

*Maddua hushlekhu hu ve-zar'o*—why cast out?

"Cast into a land which they know not."

*Ve-hushlekhu al-ha-aretz asher lo-yade'u*—unknown land.

**The Key Verse (22:29):**
"O land, land, land, hear the word of YHWH."

*Eretz eretz eretz shim'i devar-YHWH*—triple "land."

**The Key Verse (22:30):**
"Write this man childless."

*Kitvu et-ha-ish ha-zeh ariri*—write childless.

"A man that shall not prosper in his days."

*Gever lo-yitzlach be-yamav*—won't prosper.

"No man of his seed shall prosper, sitting upon the throne of David."

*Ki lo yitzlach mi-zar'o ish yoshev al-kisse David*—no descendant on throne.

"Ruling any more in Judah."

*U-moshel od bi-Yhudah*—no more rule.

**Childless Curse:**
Jehoiachin had sons (1 Chronicles 3:17-18), but none ruled on the throne—"childless" means dynastically childless.

**Archetypal Layer:** Jeremiah 22 contains oracles against four kings: **Shallum/Jehoahaz (22:10-12)**, **Jehoiakim (22:13-19)**—woe for injustice and cedar palaces, **Jerusalem personified (22:20-23)**, and **Coniah/Jehoiachin (22:24-30)**—written childless.

**Ethical Inversion Applied:**
- "Execute justice and righteousness"—royal duty
- "Deliver the spoiled out of the hand of the oppressor"—deliver oppressed
- "Do no wrong... to the stranger, the fatherless, nor the widow"—protect vulnerable
- "Neither shed innocent blood"—no murder
- "If you do this thing indeed... kings sitting upon the throne of David"—conditional
- "If you will not hear... this house shall become a desolation"—desolation
- "Weep not for the dead... weep sore for him that goes away"—Jehoahaz
- "He shall return no more, nor see his native country"—no return
- "Woe unto him that builds his house by unrighteousness"—woe Jehoiakim
- "That uses his neighbour's service without wages"—slave labor
- "'I will build me a wide house'"—palace building
- "Did not your father... do justice and righteousness?"—Josiah contrast
- "He judged the cause of the poor and needy... Is not this to know me?"—knowing God = justice
- "Your eyes and your heart are not but for your covetousness"—Jehoiakim's greed
- "He shall be buried with the burial of an ass"—donkey burial
- "I spoke unto you in your prosperity... 'I will not hear'"—refused in prosperity
- "Though Coniah... were the signet upon my right hand"—even signet
- "Yet would I pluck you thence"—plucked
- "O land, land, land, hear the word of YHWH"—triple land
- "Write this man childless"—dynastically childless
- "No man of his seed shall prosper, sitting upon the throne of David"—no throne

**Modern Equivalent:** Jeremiah 22:16's "He judged the cause of the poor and needy... Is not this to know me?" equates knowing God with doing justice. Jehoiachin's "childless" curse (22:30) was overcome through Jesus's virgin birth—Matthew traces Jesus through Jehoiachin (Matthew 1:12), but Luke traces through Nathan (Luke 3:31).

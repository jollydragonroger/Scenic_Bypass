# Jeremiah 11: The Broken Covenant

*From the Hebrew: הַדָּבָר אֲשֶׁר הָיָה אֶל־יִרְמְיָהוּ (Ha-Davar Asher Hayah El-Yirmeyahu) — The Word That Came to Jeremiah*

---

## The Covenant Broken (11:1-8)

**11:1** The word that came to Jeremiah from YHWH, saying:

**11:2** "Hear the words of this covenant, and speak unto the men of Judah, and to the inhabitants of Jerusalem;

**11:3** "And say unto them: Thus says YHWH, the God of Israel: Cursed be the man that hears not the words of this covenant,

**11:4** "Which I commanded your fathers in the day that I brought them forth out of the land of Egypt, out of the iron furnace, saying: Hearken to my voice, and do them, according to all which I command you; so shall you be my people, and I will be your God;

**11:5** "That I may establish the oath which I swore unto your fathers, to give them a land flowing with milk and honey, as at this day." Then answered I, and said: "Amen, O YHWH."

**11:6** And YHWH said unto me: "Proclaim all these words in the cities of Judah, and in the streets of Jerusalem, saying: Hear the words of this covenant, and do them.

**11:7** "For I earnestly forewarned your fathers in the day that I brought them up out of the land of Egypt, even unto this day, warning betimes and often, saying: Hearken to my voice.

**11:8** "Yet they hearkened not, nor inclined their ear, but walked every one in the stubbornness of their evil heart; therefore I brought upon them all the words of this covenant, which I commanded them to do, but they did them not."

---

## The Conspiracy (11:9-17)

**11:9** And YHWH said unto me: "A conspiracy is found among the men of Judah, and among the inhabitants of Jerusalem.

**11:10** "They are turned back to the iniquities of their forefathers, who refused to hear my words; and they are gone after other gods to serve them; the house of Israel and the house of Judah have broken my covenant which I made with their fathers."

**11:11** Therefore thus says YHWH: "Behold, I will bring evil upon them, which they shall not be able to escape; and though they shall cry unto me, I will not hearken unto them.

**11:12** "Then shall the cities of Judah and the inhabitants of Jerusalem go and cry unto the gods unto whom they offer; but they shall not save them at all in the time of their trouble.

**11:13** "For according to the number of your cities are your gods, O Judah; and according to the number of the streets of Jerusalem have you set up altars to the shameful thing, altars to offer unto Baal."

**11:14** "Therefore pray not for this people, neither lift up cry nor prayer for them; for I will not hear them in the time that they cry unto me for their trouble."

**11:15** "What has my beloved to do in my house, seeing she has wrought lewdness with many, and the holy flesh is passed from you? When you do evil, then you rejoice."

**11:16** "YHWH called your name a leafy olive-tree, fair with goodly fruit"; with the noise of a great tumult he has kindled fire upon it, and the branches of it are broken.

**11:17** For YHWH of hosts, that planted you, has pronounced evil against you, because of the evil of the house of Israel and of the house of Judah, which they have wrought for themselves in provoking me by offering unto Baal.

---

## The Plot Against Jeremiah (11:18-23)

**11:18** And YHWH gave me knowledge of it, and I knew it; then you showed me their doings.

**11:19** But I was like a docile lamb that is led to the slaughter; and I knew not that they had devised devices against me: "Let us destroy the tree with the fruit thereof, and let us cut him off from the land of the living, that his name may be no more remembered."

**11:20** But, O YHWH of hosts, that judges righteously, that tries the reins and the heart, let me see your vengeance on them; for unto you have I revealed my cause.

**11:21** Therefore thus says YHWH concerning the men of Anathoth, that seek your life, saying: "You shall not prophesy in the name of YHWH, that you die not by our hand";

**11:22** Therefore thus says YHWH of hosts: "Behold, I will punish them; the young men shall die by the sword, their sons and their daughters shall die by famine;

**11:23** "And there shall be no remnant unto them; for I will bring evil upon the men of Anathoth, even the year of their visitation."

---

## Synthesis Notes

**Key Restorations:**

**Covenant Words (11:1-5):**
"Hear the words of this covenant."

*Shim'u et-divrei ha-berit ha-zot*—hear covenant words.

"Cursed be the man that hears not the words of this covenant."

*Arur ha-ish asher lo yishma et-divrei ha-berit ha-zot*—cursed non-hearer.

"Which I commanded your fathers in the day that I brought them forth out of the land of Egypt."

*Asher tzivviti et-avoteikhem be-yom hotzi'i otam me-eretz Mitzrayim*—Exodus covenant.

"Out of the iron furnace."

*Mi-kur ha-barzel*—iron furnace (Egypt).

"Hearken to my voice, and do them."

*Shim'u ve-qoli va-asitem otam*—hear and do.

"So shall you be my people, and I will be your God."

*Vi-heyitem li le-am va-anokhi ehyeh lakhem le-lohim*—covenant formula.

"To give them a land flowing with milk and honey."

*Latet lahem eretz zavat chalav u-devash*—milk and honey land.

"Then answered I, and said: 'Amen, O YHWH.'"

*Va-a'an va-omar amen YHWH*—Jeremiah's amen.

**Proclamation Command (11:6-8):**
"Proclaim all these words in the cities of Judah."

*Qera et-kol-ha-devarim ha-elleh be-arei Yehudah*—proclaim in cities.

"In the streets of Jerusalem."

*U-ve-chutzot Yerushalayim*—in Jerusalem streets.

"I earnestly forewarned your fathers."

*Ha'ed ha'idoti ba-avoteikhem*—earnest warning.

"Warning betimes and often."

*Hashkem ve-ha'ed*—rising early, warning.

"Yet they hearkened not, nor inclined their ear."

*Ve-lo sham'u ve-lo hittu et-oznam*—didn't hear.

"Walked every one in the stubbornness of their evil heart."

*Va-yelkhu ish be-sherirut libbam ha-ra*—evil heart stubbornness.

"I brought upon them all the words of this covenant."

*Va-avi aleihem et-kol-divrei ha-berit ha-zot*—covenant words brought.

**Conspiracy (11:9-13):**
**The Key Verse (11:9):**
"A conspiracy is found among the men of Judah."

*Qesher nimtza be-ish Yehudah*—conspiracy found.

**The Key Verse (11:10):**
"They are turned back to the iniquities of their forefathers."

*Shavu al-avonot avotam ha-rishonim*—returned to ancestors' sins.

"Who refused to hear my words."

*Asher me'anu lishmoa et-devarai*—refused to hear.

"They are gone after other gods to serve them."

*Va-yelkhu acharei elohim acherim le-ovdam*—followed other gods.

"The house of Israel and the house of Judah have broken my covenant."

*Heferu beit-Yisra'el u-veit Yehudah et-beriti*—broken covenant.

"I will bring evil upon them, which they shall not be able to escape."

*Hineni mevi aleihem ra'ah asher lo-yukhelu latzeit mimmennah*—inescapable evil.

"Though they shall cry unto me, I will not hearken unto them."

*Ve-za'aqu elai ve-lo eshma aleihem*—won't hear their cry.

"The cities of Judah and the inhabitants of Jerusalem go and cry unto the gods."

*Ve-halekhu arei Yehudah ve-yoshevei Yerushalayim ve-za'aqu el-ha-elohim*—cry to gods.

"They shall not save them at all."

*Ve-lo yoshiu lahem*—gods won't save.

"According to the number of your cities are your gods, O Judah."

*Ki mispar arekha hayu elohekha Yehudah*—gods = cities. (Repeats 2:28)

"According to the number of the streets of Jerusalem have you set up altars."

*U-mispar chutzot Yerushalayim samtem mizbechot*—street altars.

"Altars to the shameful thing, altars to offer unto Baal."

*La-boshet mizbechot leqatter la-Ba'al*—Baal altars.

**No Intercession (11:14-17):**
**The Key Verse (11:14):**
"Pray not for this people."

*Ve-attah al-titpallel be'ad ha-am ha-zeh*—don't pray. (Repeats 7:16)

"Neither lift up cry nor prayer for them."

*Ve-al-tissa va'adam rinnah u-tefillah*—no cry or prayer.

"I will not hear them in the time that they cry unto me."

*Ki einenni shome'a be-et qor'am elai*—won't hear their cry.

"What has my beloved to do in my house?"

*Meh li-yedidi be-veiti*—what's beloved doing in house?

"Seeing she has wrought lewdness with many."

*Asotah ha-mezimmah ha-rabbim*—lewdness with many.

"The holy flesh is passed from you."

*U-vesar-qodesh ya'avru me-alayikh*—holy flesh gone.

**The Key Verse (11:16):**
"YHWH called your name a leafy olive-tree."

*Zayit ra'anan yefeh feri-to'ar qara YHWH shemekh*—leafy olive.

"Fair with goodly fruit."

*Yefeh feri-to'ar*—fair fruit.

"With the noise of a great tumult he has kindled fire upon it."

*Le-qol hamon gadol hitztzit esh alekha*—fire kindled.

"The branches of it are broken."

*Ve-ra'u daliyyotav*—branches broken.

"YHWH of hosts, that planted you, has pronounced evil against you."

*Va-YHWH Tzeva'ot ha-note'a otakh dibber alayikh ra'ah*—planter pronounced evil.

**Plot Against Jeremiah (11:18-23):**
"YHWH gave me knowledge of it."

*Va-YHWH hodi'ani va-eda*—YHWH informed.

"Then you showed me their doings."

*Az hir'itani ma'aleleihem*—showed doings.

**The Key Verse (11:19):**
"I was like a docile lamb that is led to the slaughter."

*Va-ani ke-kheves aluf yuval li-tevo'ach*—lamb to slaughter.

"I knew not that they had devised devices against me."

*Ve-lo-yada'ti ki-alai chashvu machashavot*—didn't know their plots.

"'Let us destroy the tree with the fruit thereof.'"

*Nashchitah etz be-lachmo*—destroy tree with fruit.

"'Let us cut him off from the land of the living.'"

*Ve-nikhretennu me-eretz chayyim*—cut from living.

"'That his name may be no more remembered.'"

*Ve-shemo lo-yizzakher od*—name forgotten.

**The Key Verse (11:20):**
"O YHWH of hosts, that judges righteously."

*Va-YHWH Tzeva'ot shofet tzedeq*—righteous judge.

"That tries the reins and the heart."

*Bochen kelayot va-lev*—tests kidneys and heart.

"Let me see your vengeance on them."

*Er'eh niqmatekha mehem*—see vengeance.

"For unto you have I revealed my cause."

*Ki elekha gilliti et-rivi*—revealed cause.

**Anathoth Judgment (11:21-23):**
"The men of Anathoth, that seek your life."

*Al-anshei Anatot ha-mevaqqeshim et-nafshekha*—life-seekers.

"'You shall not prophesy in the name of YHWH.'"

*Lo tinnave be-shem YHWH*—don't prophesy.

"'That you die not by our hand.'"

*Ve-lo tamut be-yadenu*—or die.

"The young men shall die by the sword."

*Ha-bachurim yamutu ba-cherev*—sword death.

"Their sons and their daughters shall die by famine."

*Beneihem u-venoteihem yamutu ba-ra'av*—famine death.

"There shall be no remnant unto them."

*U-she'erit lo tihyeh lahem*—no remnant.

"I will bring evil upon the men of Anathoth."

*Ki-avi ra'ah el-anshei Anatot*—evil on Anathoth.

"Even the year of their visitation."

*Shenat pequddatam*—visitation year.

**Archetypal Layer:** Jeremiah 11 contains **the broken covenant (11:10)**, **"Pray not for this people" (11:14)**, **"I was like a docile lamb that is led to the slaughter" (11:19)**, and **the first of Jeremiah's "confessions" (11:18-23)**.

**Ethical Inversion Applied:**
- "Hear the words of this covenant"—covenant words
- "Cursed be the man that hears not"—curse for non-hearing
- "Out of the iron furnace"—Egypt = iron furnace
- "Hearken to my voice, and do them"—hear and do
- "So shall you be my people, and I will be your God"—covenant formula
- "A land flowing with milk and honey"—promised land
- "'Amen, O YHWH'"—Jeremiah's amen
- "I earnestly forewarned your fathers"—earnest warning
- "Yet they hearkened not, nor inclined their ear"—didn't hear
- "Walked every one in the stubbornness of their evil heart"—stubborn
- "A conspiracy is found among the men of Judah"—conspiracy
- "They are turned back to the iniquities of their forefathers"—returned to sin
- "The house of Israel and the house of Judah have broken my covenant"—broken covenant
- "I will bring evil upon them, which they shall not be able to escape"—inescapable
- "Though they shall cry unto me, I will not hearken"—won't hear
- "According to the number of your cities are your gods"—many gods
- "Pray not for this people"—no intercession
- "YHWH called your name a leafy olive-tree"—olive tree
- "He has kindled fire upon it"—fire on olive
- "The branches of it are broken"—branches broken
- "YHWH of hosts, that planted you, has pronounced evil"—planter pronounces evil
- "I was like a docile lamb that is led to the slaughter"—lamb to slaughter
- "I knew not that they had devised devices against me"—unknown plots
- "'Let us destroy the tree with the fruit thereof'"—destroy tree
- "O YHWH of hosts, that judges righteously"—righteous judge
- "That tries the reins and the heart"—tests heart
- "Let me see your vengeance on them"—vengeance request
- "The men of Anathoth, that seek your life"—hometown enemies
- "'You shall not prophesy... that you die not by our hand'"—death threat
- "There shall be no remnant unto them"—no remnant

**Modern Equivalent:** Jeremiah 11 introduces the first of Jeremiah's "confessions" (11:18-23; cf. 12:1-6; 15:10-21; 17:14-18; 18:18-23; 20:7-18). "I was like a docile lamb that is led to the slaughter" (11:19) parallels Isaiah 53:7. The plot from Anathoth (his hometown) shows Jeremiah's rejection by his own people.

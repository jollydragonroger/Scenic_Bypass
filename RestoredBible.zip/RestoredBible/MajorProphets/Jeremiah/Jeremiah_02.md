# Jeremiah 2: Israel's Unfaithfulness

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came to Me*

---

## Israel's Early Devotion (2:1-3)

**2:1** And the word of YHWH came to me, saying:

**2:2** "Go, and cry in the ears of Jerusalem, saying: Thus says YHWH: I remember for you the devotion of your youth, the love of your espousals; how you went after me in the wilderness, in a land that was not sown.

**2:3** "Israel was holiness unto YHWH, the first-fruits of his increase; all that devour him shall be held guilty, evil shall come upon them," says YHWH.

---

## Israel's Forsaking of YHWH (2:4-13)

**2:4** Hear the word of YHWH, O house of Jacob, and all the families of the house of Israel.

**2:5** Thus says YHWH: What unrighteousness have your fathers found in me, that they are gone far from me, and have walked after vanity, and are become vain?

**2:6** Neither said they: "Where is YHWH that brought us up out of the land of Egypt; that led us through the wilderness, through a land of deserts and of pits, through a land of drought and of the shadow of death, through a land that no man passed through, and where no man dwelt?"

**2:7** And I brought you into a land of fruitful fields, to eat the fruit thereof and the good thereof; but when you entered, you defiled my land, and made my heritage an abomination.

**2:8** The priests said not: "Where is YHWH?" And they that handle the law knew me not, and the shepherds transgressed against me; the prophets also prophesied by Baal, and walked after things that do not profit.

**2:9** Wherefore I will yet contend with you, says YHWH, and with your children's children will I contend.

**2:10** For pass over to the isles of the Kittites, and see, and send unto Kedar, and consider diligently; and see if there has been such a thing.

**2:11** Has a nation changed its gods, which yet are no gods? But my people has changed its glory for that which does not profit.

**2:12** Be astonished, O heavens, at this, and be horribly afraid, be utterly desolate, says YHWH.

**2:13** For my people have committed two evils: they have forsaken me, the fountain of living waters, and hewed them out cisterns, broken cisterns, that can hold no water.

---

## The Consequences of Forsaking YHWH (2:14-19)

**2:14** Is Israel a servant? Is he a home-born slave? Why is he become a prey?

**2:15** The young lions have roared upon him, and let out their voice; and they have made his land waste, his cities are laid desolate, without inhabitant.

**2:16** The children also of Noph and Tahpanhes feed upon the crown of your head.

**2:17** Is it not this that causes it unto you, that you have forsaken YHWH your God, when he led you by the way?

**2:18** And now what have you to do in the way to Egypt, to drink the waters of Shihor? Or what have you to do in the way to Assyria, to drink the waters of the River?

**2:19** Your own wickedness shall correct you, and your backslidings shall reprove you; know therefore and see that it is an evil and a bitter thing, that you have forsaken YHWH your God, and that my fear is not in you, says the Lord, YHWH of hosts.

---

## Israel's Infidelity (2:20-28)

**2:20** For of old time I have broken your yoke, and burst your bands, and you said: "I will not transgress"; yet upon every high hill and under every leafy tree you did recline, playing the harlot.

**2:21** Yet I had planted you a noble vine, wholly a right seed; how then are you turned into the degenerate plant of a strange vine unto me?

**2:22** For though you wash yourself with nitre, and take much soap, yet your iniquity is marked before me, says the Lord YHWH.

**2:23** How can you say: "I am not defiled, I have not gone after the Baalim"? See your way in the valley, know what you have done; you are a swift young camel traversing her ways;

**2:24** A wild ass used to the wilderness, that snuffs up the wind in her desire; her lust, who can hinder it? All they that seek her will not weary themselves; in her month they shall find her.

**2:25** Withhold your foot from being unshod, and your throat from thirst; but you said: "There is no hope; no, for I have loved strangers, and after them will I go."

**2:26** As the thief is ashamed when he is found, so is the house of Israel ashamed; they, their kings, their princes, and their priests, and their prophets;

**2:27** Who say to a stock: "You are my father," and to a stone: "You have brought me forth"; for they have turned their back unto me, and not their face; but in the time of their trouble they will say: "Arise, and save us."

**2:28** But where are your gods that you have made? Let them arise, if they can save you in the time of your trouble; for according to the number of your cities are your gods, O Judah.

---

## YHWH's Case Against Israel (2:29-37)

**2:29** Wherefore will you contend with me? You all have transgressed against me, says YHWH.

**2:30** In vain have I smitten your children, they received no correction; your own sword has devoured your prophets, like a destroying lion.

**2:31** O generation, see the word of YHWH: Have I been a wilderness unto Israel? A land of thick darkness? Wherefore say my people: "We roam at large; we will come no more unto you"?

**2:32** Can a maid forget her ornaments, or a bride her attire? Yet my people have forgotten me days without number.

**2:33** How well you direct your way to seek love! Therefore even the wicked women have you taught your ways.

**2:34** Also in your skirts is found the blood of the souls of the innocent poor; you did not find them breaking in; yet for all these things

**2:35** You say: "I am innocent; surely his anger is turned away from me." Behold, I will enter into judgment with you, because you say: "I have not sinned."

**2:36** How greatly you cheapen yourself to change your way! You shall be ashamed of Egypt also, as you were ashamed of Assyria.

**2:37** From him also shall you go forth, with your hands upon your head; for YHWH has rejected those in whom you trust, and you shall not prosper in them.

---

## Synthesis Notes

**Key Restorations:**

**Early Devotion (2:2-3):**
"I remember for you the devotion of your youth."

*Zakharti lakh chesed ne'urayikh*—remembered youth devotion.

"The love of your espousals."

*Ahavat kelulotayikh*—bridal love.

"How you went after me in the wilderness."

*Lekhtekh acharai ba-midbar*—following in wilderness.

"Israel was holiness unto YHWH."

*Qodesh Yisra'el la-YHWH*—Israel = holy.

"The first-fruits of his increase."

*Reshit tevu'ato*—firstfruits.

**Accusation (2:5-8):**
"What unrighteousness have your fathers found in me?"

*Mah-matz'u avotekhem bi avel*—what wrong?

"That they are gone far from me."

*Ki rachagu me-alai*—gone far.

"Walked after vanity, and are become vain."

*Va-yelkhu acharei ha-hevel va-yehbalu*—followed vanity, became vain.

"Neither said they: 'Where is YHWH?'"

*Ve-lo amru ayyeh YHWH*—didn't ask for YHWH.

"That brought us up out of the land of Egypt."

*Ha-ma'aleh otanu me-eretz Mitzrayim*—Exodus.

"That led us through the wilderness."

*Ha-molikhi otanu ba-midbar*—wilderness leading.

"A land of deserts and of pits."

*Be-eretz aravah ve-shuchah*—desert land.

"A land of drought and of the shadow of death."

*Be-eretz tziyyah ve-tzalmavet*—death-shadow land.

"I brought you into a land of fruitful fields."

*Va-avi etkhem el-eretz ha-karmel*—fruitful land.

"You defiled my land."

*Va-tetame'u et-artzi*—land defiled.

"Made my heritage an abomination."

*Ve-nachalati samttem le-to'evah*—heritage = abomination.

"The priests said not: 'Where is YHWH?'"

*Ha-kohanim lo amru ayyeh YHWH*—priests didn't ask.

"They that handle the law knew me not."

*Ve-tofsei ha-torah lo yeda'uni*—Torah-handlers ignorant.

"The shepherds transgressed against me."

*Ve-ha-ro'im pash'u vi*—shepherds transgressed.

"The prophets also prophesied by Baal."

*Ve-ha-nevi'im nibbu va-Ba'al*—Baal prophets.

**The Key Verses (2:11-13):**
"Has a nation changed its gods, which yet are no gods?"

*Ha-hemir goy elohim ve-hemmah lo elohim*—nations don't change gods.

"But my people has changed its glory for that which does not profit."

*Ve-ammi hemir kevodo be-lo yo'il*—glory changed.

"Be astonished, O heavens, at this."

*Shommu shamayim al-zot*—heavens astonished.

"Be horribly afraid, be utterly desolate."

*Ve-sa'aru charavu me'od*—terrified, desolate.

**The Key Verse (2:13):**
"My people have committed two evils."

*Shetayim ra'ot asah ammi*—two evils.

"They have forsaken me, the fountain of living waters."

*Oti azavu meqor mayim chayyim*—forsaken living fountain.

"Hewed them out cisterns, broken cisterns, that can hold no water."

*Lachtzov lahem borot borot nishbarim asher lo-yakhilu ha-mayim*—broken cisterns.

**Consequences (2:14-19):**
"Is Israel a servant? Is he a home-born slave?"

*Ha-eved Yisra'el im-yelid bayit hu*—slave?

"Why is he become a prey?"

*Maddua hayah la-baz*—why prey?

"The young lions have roared upon him."

*Alav sha'agu kefirim*—lions roar.

"His cities are laid desolate."

*Arav nitztu mi-bli yoshev*—desolate cities.

"Is it not this that causes it unto you, that you have forsaken YHWH?"

*Halo-zot ta'aseh-lakh azvekh et-YHWH Elohayikh*—forsaking caused this.

"What have you to do in the way to Egypt?"

*Mah-lakh le-derekh Mitzrayim*—why go to Egypt?

"To drink the waters of Shihor?"

*Lishtot mei Shichor*—Nile waters.

"What have you to do in the way to Assyria?"

*U-mah-lakh le-derekh Ashshur*—why go to Assyria?

"To drink the waters of the River?"

*Lishtot mei Nahar*—Euphrates waters.

"Your own wickedness shall correct you."

*Teyasserekh ra'atek*—wickedness corrects.

**Infidelity (2:20-28):**
"Of old time I have broken your yoke."

*Ki me-olam shavarti ullekh*—yoke broken.

"I will not transgress."

*Lo e'evod*—won't transgress.

"Upon every high hill and under every leafy tree you did recline, playing the harlot."

*Ki al-kol-giv'ah gevohah ve-tachat kol-etz ra'anan at tzo'ah zonah*—harlotry.

**The Key Verse (2:21):**
"I had planted you a noble vine."

*Ve-anokhi netatikh soreq*—noble vine planted.

"Wholly a right seed."

*Kullo zera emet*—true seed.

"How then are you turned into the degenerate plant of a strange vine?"

*Ve-eikh nehpakht li surrei ha-gefen nokhriyyah*—wild vine.

"Though you wash yourself with nitre."

*Ki im-tekhabesi ba-neter*—washing with lye.

"Take much soap."

*Ve-tarbei-lakh borit*—much soap.

"Yet your iniquity is marked before me."

*Nikhtam avonekh lefanai*—iniquity stained.

"You are a swift young camel traversing her ways."

*Bikrah qallah mesareket derakhekha*—young camel.

"A wild ass used to the wilderness."

*Pereh limmud midbar*—wild donkey.

"Who say to a stock: 'You are my father.'"

*Omerim la-etz avi attah*—wood = father.

"To a stone: 'You have brought me forth.'"

*Ve-la-even att yelidtani*—stone = mother.

"They have turned their back unto me, and not their face."

*Ki-fanu elai oref ve-lo fanim*—backs, not faces.

"In the time of their trouble they will say: 'Arise, and save us.'"

*U-ve-et ra'atam yomeru qumah ve-hoshi'enu*—crisis prayer.

"Where are your gods that you have made?"

*Ve-ayyeh elohekha asher asita lakh*—where are gods?

"According to the number of your cities are your gods."

*Ki mispar arekha hayu elohekha*—gods = cities.

**YHWH's Case (2:29-37):**
"You all have transgressed against me."

*Kullakhem pesha'tem bi*—all transgressed.

"In vain have I smitten your children."

*La-shav hikkeiti et-beneikhem*—vain discipline.

"They received no correction."

*Musar lo laqachu*—no correction received.

"Your own sword has devoured your prophets."

*Akhlah charevkhem nevi'eikhem*—sword ate prophets.

"Have I been a wilderness unto Israel?"

*Ha-midbar hayiti le-Yisra'el*—was I wilderness?

"A land of thick darkness?"

*Im eretz ma'pelyah*—dark land?

"Can a maid forget her ornaments?"

*Ha-tishkach betulah edyah*—maid forget ornaments?

"Or a bride her attire?"

*Kallah qishurrekha*—bride forget attire?

"Yet my people have forgotten me days without number."

*Ve-ammi shekechuni yamim ein mispar*—forgotten countless days.

"In your skirts is found the blood of the souls of the innocent poor."

*Gam bi-khnafayikh nimtze'u dam nafshot evyonim neqi'im*—innocent blood.

"You say: 'I am innocent.'"

*Ki tomeri niqqeiti*—claiming innocence.

"I will enter into judgment with you, because you say: 'I have not sinned.'"

*Hineni nishpat otak al-omrek lo chatati*—judgment for denial.

"How greatly you cheapen yourself to change your way!"

*Mah-tezelzi me'od leshannot et-darkekh*—cheapening self.

**Archetypal Layer:** Jeremiah 2 presents Israel as an unfaithful bride, containing **"the devotion of your youth" (2:2)**, **"two evils: they have forsaken me, the fountain of living waters, and hewed them out cisterns, broken cisterns" (2:13)**, and **"I had planted you a noble vine" (2:21)**.

**Ethical Inversion Applied:**
- "I remember for you the devotion of your youth"—early devotion
- "The love of your espousals"—bridal love
- "Israel was holiness unto YHWH"—holy Israel
- "What unrighteousness have your fathers found in me?"—YHWH blameless
- "Walked after vanity, and are become vain"—became like idols
- "Neither said they: 'Where is YHWH?'"—didn't ask
- "I brought you into a land of fruitful fields"—provision
- "You defiled my land"—defilement
- "The priests said not: 'Where is YHWH?'"—priestly failure
- "Has a nation changed its gods?"—nations more faithful
- "My people has changed its glory"—glory exchanged
- "They have forsaken me, the fountain of living waters"—living water forsaken
- "Hewed them out cisterns, broken cisterns"—broken cisterns
- "Is Israel a servant?"—slave question
- "What have you to do in the way to Egypt?"—Egypt alliance
- "Your own wickedness shall correct you"—self-correction
- "I had planted you a noble vine"—noble vine
- "How then are you turned into the degenerate plant?"—degenerate
- "Your iniquity is marked before me"—stained iniquity
- "Who say to a stock: 'You are my father'"—wood worship
- "According to the number of your cities are your gods"—many gods
- "Can a maid forget her ornaments?"—Israel forgot
- "Yet my people have forgotten me days without number"—countless forgetting
- "I am innocent... I have not sinned"—false innocence

**Modern Equivalent:** Jeremiah 2:13's "fountain of living waters" vs. "broken cisterns" is one of Scripture's most powerful metaphors for forsaking God. The bridal imagery (2:2) and vine imagery (2:21) parallel Hosea and Isaiah 5.

# Jeremiah 30: The Book of Consolation Begins

*From the Hebrew: הַדָּבָר אֲשֶׁר הָיָה אֶל־יִרְמְיָהוּ (Ha-Davar Asher Hayah El-Yirmeyahu) — The Word That Came to Jeremiah*

---

## Introduction to the Book of Consolation (30:1-3)

**30:1** The word that came to Jeremiah from YHWH, saying:

**30:2** "Thus says YHWH, the God of Israel: Write in a book all the words that I have spoken unto you.

**30:3** "For, lo, the days come," says YHWH, "that I will turn the captivity of my people Israel and Judah," says YHWH; "and I will cause them to return to the land that I gave to their fathers, and they shall possess it."

---

## The Time of Jacob's Trouble (30:4-11)

**30:4** And these are the words that YHWH spoke concerning Israel and concerning Judah.

**30:5** For thus says YHWH: "We have heard a voice of trembling, of fear, and not of peace.

**30:6** "Ask now, and see whether a man does travail with child? Wherefore do I see every man with his hands on his loins, as a woman in travail, and all faces are turned into paleness?

**30:7** "Alas! For that day is great, so that none is like it; it is even the time of Jacob's trouble, but he shall be saved out of it.

**30:8** "And it shall come to pass in that day," says YHWH of hosts, "that I will break his yoke from off your neck, and will burst your bands; and strangers shall no more make him their bondman;

**30:9** "But they shall serve YHWH their God, and David their king, whom I will raise up unto them.

**30:10** "Therefore fear not, O Jacob my servant," says YHWH; "neither be dismayed, O Israel; for, lo, I will save you from afar, and your seed from the land of their captivity; and Jacob shall return, and shall be quiet and at ease, and none shall make him afraid.

**30:11** "For I am with you," says YHWH, "to save you; for I will make a full end of all the nations whither I have scattered you, but I will not make a full end of you; but I will correct you in measure, and will not utterly destroy you."

---

## Incurable Wound, Yet Healing (30:12-17)

**30:12** For thus says YHWH: "Your hurt is incurable, and your wound is grievous.

**30:13** "There is none to plead your cause, that you may be bound up; you have no healing medicines.

**30:14** "All your lovers have forgotten you, they seek you not; for I have wounded you with the wound of an enemy, with the chastisement of a cruel one; for the greatness of your iniquity, because your sins were increased.

**30:15** "Why do you cry for your hurt? Your pain is incurable; for the greatness of your iniquity, because your sins were increased, I have done these things unto you.

**30:16** "Therefore all they that devour you shall be devoured, and all your adversaries, every one of them, shall go into captivity; and they that spoil you shall be a spoil, and all that prey upon you will I give for a prey.

**30:17** "For I will restore health unto you, and I will heal you of your wounds," says YHWH; "because they have called you an outcast: 'It is Zion, whom no man seeks after.'"

---

## The Restored City (30:18-22)

**30:18** Thus says YHWH: "Behold, I will turn the captivity of Jacob's tents, and have compassion on his dwelling-places; and the city shall be built upon its own mound, and the palace shall be inhabited upon its own place.

**30:19** "And out of them shall proceed thanksgiving and the voice of them that make merry; and I will multiply them, and they shall not be few; I will also glorify them, and they shall not be small.

**30:20** "Their children also shall be as aforetime, and their congregation shall be established before me, and I will punish all that oppress them.

**30:21** "And their prince shall be of themselves, and their ruler shall proceed from the midst of them; and I will cause him to draw near, and he shall approach unto me; for who is he that has pledged his heart to approach unto me?" says YHWH.

**30:22** "And you shall be my people, and I will be your God."

---

## The Storm of YHWH (30:23-24)

**30:23** Behold, a storm of YHWH is gone forth in fury, a sweeping storm; it shall whirl upon the head of the wicked.

**30:24** The fierce anger of YHWH shall not return, until he have executed, and till he have performed the intents of his heart; in the end of days you shall consider it.

---

## Synthesis Notes

**Key Restorations:**

**Book of Consolation Introduction (30:1-3):**
"Write in a book all the words that I have spoken unto you."

*Ketov-lekha et kol-ha-devarim asher-dibbarti elekha el-sefer*—write in book.

**Book of Consolation:**
Chapters 30-33 form the "Book of Consolation"—Jeremiah's collection of hope oracles.

**The Key Verse (30:3):**
"The days come, that I will turn the captivity of my people Israel and Judah."

*Ki-hinneh yamim ba'im... ve-shavti et-shevut ammi Yisra'el vi-Yhudah*—turn captivity.

"I will cause them to return to the land that I gave to their fathers."

*Va-hashivotim el-ha-aretz asher-natatti la-avotam*—return to land.

"They shall possess it."

*Vi-yreshuha*—possess it.

**Jacob's Trouble (30:5-11):**
"We have heard a voice of trembling, of fear, and not of peace."

*Ki-qol charadah shama'nu pachad ve-ein shalom*—trembling, fear.

"Ask now, and see whether a man does travail with child?"

*Sha'alu-na u-re'u im-yoled zakhar*—do men give birth?

"Wherefore do I see every man with his hands on his loins?"

*Maddua ra'iti khol-gever yadav al-chalatzav*—hands on loins.

"As a woman in travail."

*Ka-yoledah*—like birthing woman.

"All faces are turned into paleness."

*Ve-nehepkhu khol-panim le-yerakkon*—faces pale.

**The Key Verse (30:7):**
"Alas! For that day is great."

*Hoy ki gadol ha-yom ha-hu*—great day.

"So that none is like it."

*Me-ein kamohu*—none like it.

"It is even the time of Jacob's trouble."

*Ve-et-tzarah hi le-Ya'aqov*—Jacob's trouble.

"But he shall be saved out of it."

*U-mimmennah yivvashe'a*—saved from it.

**The Key Verses (30:8-9):**
"I will break his yoke from off your neck."

*Eshbor ullo me-al tzavva'rekha*—yoke broken.

"Will burst your bands."

*U-moseroteikha anatteiqi*—bands burst.

"Strangers shall no more make him their bondman."

*Ve-lo-ya'avdu-vo od zarim*—no more foreign service.

**The Key Verse (30:9):**
"They shall serve YHWH their God."

*Ve-avedu et YHWH Eloheihem*—serve YHWH.

"And David their king, whom I will raise up unto them."

*Ve-et David malkam asher aqim lahem*—David raised up.

**Davidic King:**
A future Davidic king—messianic expectation.

**The Key Verse (30:10):**
"Fear not, O Jacob my servant."

*Ve-attah al-tira avdi Ya'aqov*—don't fear.

"Neither be dismayed, O Israel."

*Ve-al-techat Yisra'el*—don't be dismayed.

"I will save you from afar."

*Ki hineni moshi'akha me-rachoq*—save from afar.

"Your seed from the land of their captivity."

*Ve-et-zar'akha me-eretz shivyam*—seed from captivity.

"Jacob shall return, and shall be quiet and at ease."

*Ve-shav Ya'aqov ve-shaqat ve-sha'anan*—quiet and ease.

"None shall make him afraid."

*Ve-ein macharid*—none terrifies.

**The Key Verse (30:11):**
"I am with you, to save you."

*Ki-ittekha ani... le-hoshi'ekha*—with you to save.

"I will make a full end of all the nations whither I have scattered you."

*Ki e'eseh khalah be-khol-ha-goyim asher hafitzotsikha sham*—full end of nations.

"But I will not make a full end of you."

*Ve-otakh lo-e'eseh khalah*—not full end of you.

"I will correct you in measure."

*Ve-yissartikha la-mishpat*—correct in measure.

"Will not utterly destroy you."

*Ve-naqqeh lo anaqekka*—not utterly destroy.

**Incurable Yet Healed (30:12-17):**
"Your hurt is incurable."

*Ki khoh amar YHWH anush le-shivrekh*—incurable hurt.

"Your wound is grievous."

*Nachelah makkatek*—grievous wound.

"There is none to plead your cause."

*Ein-dan dinekh*—no advocate.

"You have no healing medicines."

*Refu'ot te'alah ein lakh*—no medicines.

"All your lovers have forgotten you."

*Kol-me'ahavayikh shekechukh*—lovers forgot.

"They seek you not."

*Otakh lo yidroshu*—don't seek.

"I have wounded you with the wound of an enemy."

*Makkat oyev hikkitikh*—enemy wound.

"With the chastisement of a cruel one."

*Musar akhzari*—cruel chastisement.

"For the greatness of your iniquity."

*Al rov avonek*—great iniquity.

"Because your sins were increased."

*Atzemu chattotayikh*—many sins.

"Why do you cry for your hurt?"

*Mah-tiz'aq al-shivrekh*—why cry?

"Your pain is incurable."

*Anush makh'ovekh*—incurable pain.

**The Key Verses (30:16-17):**
"All they that devour you shall be devoured."

*Lakhen kol-okhlayikh ye'akhelu*—devourers devoured.

"All your adversaries, every one of them, shall go into captivity."

*Ve-khol-tzarayikh kullam ba-shevi yelekhu*—adversaries captive.

"They that spoil you shall be a spoil."

*Ve-hayu shosayikh li-messissah*—spoilers spoiled.

"All that prey upon you will I give for a prey."

*Ve-khol-bozazayikh etten la-baz*—preyers preyed upon.

**The Key Verse (30:17):**
"I will restore health unto you."

*Ki a'aleh arukha lakh*—restore health.

"I will heal you of your wounds."

*U-mi-makkotayikh erpa'ek*—heal wounds.

"Because they have called you an outcast."

*Ki niddachah qare'u lakh*—called outcast.

"'It is Zion, whom no man seeks after.'"

*Tziyyon hi doresh ein lah*—no one seeks Zion.

**Restored City (30:18-22):**
"I will turn the captivity of Jacob's tents."

*Hineni-shav shevut ohalei-Ya'aqov*—turn tent captivity.

"Have compassion on his dwelling-places."

*U-mishkenotav arachem*—compassion on dwellings.

"The city shall be built upon its own mound."

*Ve-nivnetah ir al-tillah*—city on mound.

"The palace shall be inhabited upon its own place."

*Ve-armon al-mishpato yeshev*—palace inhabited.

"Out of them shall proceed thanksgiving."

*Ve-yatza mehem todah*—thanksgiving proceeds.

"The voice of them that make merry."

*Ve-qol mesacheqim*—merry voices.

"I will multiply them, and they shall not be few."

*Ve-hirbeitim ve-lo yim'atu*—multiply, not few.

"I will also glorify them, and they shall not be small."

*Ve-hikhbadtim ve-lo yitze'aru*—glorify, not small.

"Their children also shall be as aforetime."

*Ve-hayu vanav ke-qedem*—children as before.

"Their congregation shall be established before me."

*Va-adato lefanai tikkon*—congregation established.

**The Key Verse (30:21):**
"Their prince shall be of themselves."

*Ve-hayah adiro mimmenu*—prince from themselves.

"Their ruler shall proceed from the midst of them."

*U-moshelo mi-qirbo yetze*—ruler from midst.

"I will cause him to draw near, and he shall approach unto me."

*Ve-hiqravtiv ve-niggash elai*—draw near, approach.

"For who is he that has pledged his heart to approach unto me?"

*Ki mi hu-zeh arav et-libbo lageshet elai*—who pledges heart?

**Priestly King:**
The future ruler will have priestly access to YHWH.

**The Key Verse (30:22):**
"You shall be my people, and I will be your God."

*Vi-heyitem li le-am va-anokhi ehyeh lakhem le-lohim*—covenant formula.

**Storm (30:23-24):**
"A storm of YHWH is gone forth in fury."

*Hinneh sa'arat YHWH chemah yatze'ah*—fury storm.

"A sweeping storm."

*Sa'ar mitgorer*—sweeping storm.

"It shall whirl upon the head of the wicked."

*Al rosh resha'im yachul*—whirls on wicked.

"The fierce anger of YHWH shall not return."

*Lo yashuv charon af-YHWH*—won't return.

"Until he have executed... the intents of his heart."

*Ad-asoto ve-ad-haqimo mezimmot libbo*—until executed.

"In the end of days you shall consider it."

*Be-acharit ha-yamim titbonenu vah*—end of days.

**Archetypal Layer:** Jeremiah 30 begins the **"Book of Consolation" (30-33)**, containing **"the time of Jacob's trouble, but he shall be saved out of it" (30:7)**, **"David their king, whom I will raise up" (30:9)**, **"I will restore health unto you, and I will heal you of your wounds" (30:17)**, and **"You shall be my people, and I will be your God" (30:22)**.

**Ethical Inversion Applied:**
- "Write in a book all the words that I have spoken unto you"—write book
- "I will turn the captivity of my people Israel and Judah"—turn captivity
- "I will cause them to return to the land"—return to land
- "We have heard a voice of trembling, of fear"—trembling heard
- "All faces are turned into paleness"—pale faces
- "That day is great, so that none is like it"—unique day
- "It is even the time of Jacob's trouble"—Jacob's trouble
- "But he shall be saved out of it"—saved from trouble
- "I will break his yoke from off your neck"—yoke broken
- "They shall serve YHWH their God"—serve YHWH
- "And David their king, whom I will raise up"—Davidic king
- "Fear not, O Jacob my servant"—don't fear
- "I will save you from afar"—save from afar
- "Jacob shall return, and shall be quiet and at ease"—quiet and ease
- "None shall make him afraid"—none terrifies
- "I am with you, to save you"—with you
- "I will make a full end of all the nations... but I will not make a full end of you"—preserved
- "I will correct you in measure"—measured correction
- "Your hurt is incurable, and your wound is grievous"—incurable
- "All your lovers have forgotten you"—forgotten
- "I have wounded you with the wound of an enemy"—YHWH wounded
- "All they that devour you shall be devoured"—devourers devoured
- "I will restore health unto you, and I will heal you"—healing
- "Because they have called you an outcast"—called outcast
- "The city shall be built upon its own mound"—rebuilt
- "Out of them shall proceed thanksgiving"—thanksgiving
- "Their prince shall be of themselves"—native prince
- "I will cause him to draw near, and he shall approach unto me"—priestly access
- "You shall be my people, and I will be your God"—covenant formula
- "In the end of days you shall consider it"—end of days

**Modern Equivalent:** Jeremiah 30 begins the "Book of Consolation" (30-33). "The time of Jacob's trouble" (30:7) is referenced in eschatology. "David their king" (30:9) is a messianic promise. The covenant formula (30:22) is foundational.

# Jeremiah 25: The Seventy Years and the Cup of Wrath

*From the Hebrew: הַדָּבָר אֲשֶׁר הָיָה עַל־יִרְמְיָהוּ (Ha-Davar Asher Hayah Al-Yirmeyahu) — The Word That Came to Jeremiah*

---

## Twenty-Three Years of Prophecy (25:1-7)

**25:1** The word that came to Jeremiah concerning all the people of Judah, in the fourth year of Jehoiakim the son of Josiah, king of Judah, that was the first year of Nebuchadrezzar king of Babylon;

**25:2** Which Jeremiah the prophet spoke unto all the people of Judah, and to all the inhabitants of Jerusalem, saying:

**25:3** "From the thirteenth year of Josiah the son of Amon, king of Judah, even unto this day, these three and twenty years, the word of YHWH has come unto me, and I have spoken unto you, speaking betimes and often; but you have not hearkened.

**25:4** "And YHWH has sent unto you all his servants the prophets, sending them betimes and often—but you have not hearkened, nor inclined your ear to hear—

**25:5** "Saying: 'Return now every one from his evil way, and from the evil of your doings, and dwell in the land that YHWH has given unto you and to your fathers, from of old and even for evermore;

**25:6** "'And go not after other gods to serve them, and to worship them, and provoke me not with the work of your hands, and I will do you no hurt.'

**25:7** "Yet you have not hearkened unto me," says YHWH; "that you might provoke me with the work of your hands to your own hurt."

---

## Seventy Years of Babylonian Rule (25:8-14)

**25:8** Therefore thus says YHWH of hosts: "Because you have not heard my words,

**25:9** "Behold, I will send and take all the families of the north," says YHWH, "and I will send unto Nebuchadrezzar the king of Babylon, my servant, and will bring them against this land, and against the inhabitants thereof, and against all these nations round about; and I will utterly destroy them, and make them an astonishment, and a hissing, and perpetual desolations.

**25:10** "Moreover I will cause to cease from them the voice of mirth and the voice of gladness, the voice of the bridegroom and the voice of the bride, the sound of the millstones, and the light of the lamp.

**25:11** "And this whole land shall be a desolation, and an astonishment; and these nations shall serve the king of Babylon seventy years.

**25:12** "And it shall come to pass, when seventy years are accomplished, that I will punish the king of Babylon, and that nation," says YHWH, "for their iniquity, and the land of the Chaldeans; and I will make it perpetual desolations.

**25:13** "And I will bring upon that land all my words which I have pronounced against it, even all that is written in this book, which Jeremiah has prophesied against all the nations.

**25:14** "For many nations and great kings shall make bondmen of them also; and I will recompense them according to their deeds, and according to the work of their hands."

---

## The Cup of YHWH's Fury (25:15-29)

**25:15** For thus says YHWH, the God of Israel, unto me: "Take this cup of the wine of fury at my hand, and cause all the nations, to whom I send you, to drink it.

**25:16** "And they shall drink, and reel to and fro, and be like madmen, because of the sword that I will send among them."

**25:17** Then I took the cup at YHWH's hand, and made all the nations to drink, unto whom YHWH had sent me:

**25:18** Jerusalem, and the cities of Judah, and the kings thereof, and the princes thereof, to make them a desolation, an astonishment, a hissing, and a curse; as it is this day;

**25:19** Pharaoh king of Egypt, and his servants, and his princes, and all his people;

**25:20** And all the mingled people, and all the kings of the land of Uz, and all the kings of the land of the Philistines, and Ashkelon, and Gaza, and Ekron, and the remnant of Ashdod;

**25:21** Edom, and Moab, and the children of Ammon;

**25:22** And all the kings of Tyre, and all the kings of Zidon, and the kings of the isle which is beyond the sea;

**25:23** Dedan, and Tema, and Buz, and all that have the corners of their hair polled;

**25:24** And all the kings of Arabia, and all the kings of the mingled people that dwell in the wilderness;

**25:25** And all the kings of Zimri, and all the kings of Elam, and all the kings of the Medes;

**25:26** And all the kings of the north, far and near, one with another; and all the kingdoms of the world, which are upon the face of the earth; and the king of Sheshach shall drink after them.

**25:27** "And you shall say unto them: Thus says YHWH of hosts, the God of Israel: Drink, and be drunken, and spew, and fall, and rise no more, because of the sword which I will send among you.

**25:28** "And it shall be, if they refuse to take the cup at your hand to drink, then shall you say unto them: Thus says YHWH of hosts: You shall surely drink.

**25:29** "For, lo, I begin to bring evil on the city whereupon my name is called, and should you be utterly unpunished? You shall not be unpunished; for I will call for a sword upon all the inhabitants of the earth," says YHWH of hosts.

---

## YHWH's Judgment on the Earth (25:30-38)

**25:30** "Therefore prophesy against them all these words, and say unto them: YHWH shall roar from on high, and utter his voice from his holy habitation; he shall mightily roar because of his fold; he shall give a shout, as they that tread the grapes, against all the inhabitants of the earth.

**25:31** "A noise is come even to the end of the earth; for YHWH has a controversy with the nations, he does enter into judgment with all flesh; as for the wicked, he has given them to the sword," says YHWH.

**25:32** Thus says YHWH of hosts: "Behold, evil shall go forth from nation to nation, and a great storm shall be raised up from the uttermost parts of the earth."

**25:33** And the slain of YHWH shall be at that day from one end of the earth even unto the other end of the earth; they shall not be lamented, neither gathered, nor buried; they shall be dung upon the face of the ground.

**25:34** Wail, you shepherds, and cry; and wallow yourselves in the dust, you leaders of the flock; for the days of your slaughter are fully come, and I will break you in pieces, and you shall fall like a precious vessel.

**25:35** And the shepherds shall have no way to flee, nor the leaders of the flock to escape.

**25:36** Hark! The cry of the shepherds, and the wailing of the leaders of the flock! For YHWH lays waste their pasture.

**25:37** And the peaceable folds are brought to silence because of the fierce anger of YHWH.

**25:38** He has forsaken his covert, as the lion; for their land is become a waste because of the fierceness of the oppressing sword, and because of his fierce anger.

---

## Synthesis Notes

**Key Restorations:**

**Twenty-Three Years (25:1-7):**
"In the fourth year of Jehoiakim."

*Bi-shanah ha-revi'it li-Yehoyaqim*—605/604 BCE.

"That was the first year of Nebuchadrezzar king of Babylon."

*Hi ha-shanah ha-rishonit le-Nevukhadre'zzar melekh Bavel*—Nebuchadnezzar's first year.

"From the thirteenth year of Josiah."

*Min-shelosh esreh shanah le-Yoshiyyahu*—627 BCE.

"Even unto this day, these three and twenty years."

*Ve-ad ha-yom ha-zeh zeh shalosh ve-esrim shanah*—23 years.

"The word of YHWH has come unto me."

*Hayah devar-YHWH elai*—word came.

"I have spoken unto you, speaking betimes and often."

*Va-adabber aleikhem hashkem ve-dabber*—speaking persistently.

"You have not hearkened."

*Ve-lo shema'tem*—didn't listen.

"YHWH has sent unto you all his servants the prophets."

*Va-yishlach YHWH aleikhem et-kol-avadav ha-nevi'im*—sent prophets.

"Sending them betimes and often."

*Hashkem ve-shalo'ach*—rising early, sending.

"You have not hearkened, nor inclined your ear."

*Ve-lo shema'tem ve-lo hittitem et-oznekhem*—didn't hear/incline.

"'Return now every one from his evil way.'"

*Shuvu-na ish mi-darkko ha-ra'ah*—return from evil.

"'Go not after other gods.'"

*Ve-al-telkhu acharei elohim acherim*—no other gods.

"Yet you have not hearkened unto me."

*Ve-lo-shema'tem elai*—didn't listen.

**Seventy Years (25:8-14):**
"Because you have not heard my words."

*Ya'an asher lo-shema'tem et-devarai*—didn't hear.

**The Key Verse (25:9):**
"I will send and take all the families of the north."

*Hineni sholeach ve-laqachti et-kol-mishpechot tzafon*—north families.

"I will send unto Nebuchadrezzar the king of Babylon, my servant."

*Ve-el-Nevukhadre'zzar melekh-Bavel avdi*—Nebuchadnezzar = YHWH's servant.

**YHWH's Servant:**
Nebuchadnezzar called YHWH's *eved* (servant)—instrument of divine judgment.

"I will bring them against this land."

*Va-havi'otim al-ha-aretz ha-zot*—against this land.

"I will utterly destroy them."

*Ve-hacharamtim*—utterly destroy.

"Make them an astonishment, and a hissing, and perpetual desolations."

*Ve-samtim le-shammah ve-li-shreqah ve-le-chorvot olam*—desolation.

**The Key Verse (25:10):**
"I will cause to cease from them the voice of mirth and the voice of gladness."

*Ve-ha'avadti mehem qol sason ve-qol simchah*—cease joy.

"The voice of the bridegroom and the voice of the bride."

*Qol chatan ve-qol kallah*—cease wedding. (Repeats 7:34; 16:9)

"The sound of the millstones."

*Qol rechayyim*—cease grinding.

"The light of the lamp."

*Ve-or ner*—cease lamp.

**The Key Verse (25:11):**
"This whole land shall be a desolation."

*Ve-hayetah kol-ha-aretz ha-zot le-chorvah*—desolation.

"These nations shall serve the king of Babylon seventy years."

*Ve-avdu ha-goyim ha-elleh et-melekh Bavel shiv'im shanah*—70 years.

**Seventy Years:**
From 605/586 BCE to 539/516 BCE. Daniel 9:2 and 2 Chronicles 36:21 reference this prophecy.

**The Key Verse (25:12):**
"When seventy years are accomplished."

*Vi-hayah ki-melo't shiv'im shanah*—after 70 years.

"I will punish the king of Babylon, and that nation."

*Efqod al-melekh Bavel ve-al-ha-goy ha-hu*—punish Babylon.

"I will make it perpetual desolations."

*Ve-samtiv le-shammot olam*—perpetual desolation.

**Cup of Fury (25:15-29):**
**The Key Verse (25:15):**
"Take this cup of the wine of fury at my hand."

*Qach et-kos ha-yayin ha-chemah ha-zot mi-yadi*—cup of fury.

"Cause all the nations, to whom I send you, to drink it."

*Ve-hishqita oto et-kol-ha-goyim asher anokhi sholeach otakh aleihem*—nations drink.

"They shall drink, and reel to and fro, and be like madmen."

*Ve-shatuu ve-hitgo'ashu ve-hitholalu*—drink, reel, mad.

"Because of the sword that I will send among them."

*Mippenei ha-cherev asher anokhi sholeach beinotam*—sword sent.

**Nations Listed (25:18-26):**
- Jerusalem and Judah (25:18)
- Egypt (25:19)
- Philistines (25:20)
- Edom, Moab, Ammon (25:21)
- Tyre, Sidon (25:22)
- Arabian tribes (25:23-24)
- Zimri, Elam, Medes (25:25)
- All northern kings (25:26)
- Sheshach = Babylon (25:26)

**Sheshach:**
*Sheshach* is an *atbash* cipher for Babel (Babylon)—letters reversed.

**The Key Verse (25:27):**
"Drink, and be drunken, and spew, and fall, and rise no more."

*Shetu ve-shikheru ve-qu u-niflu ve-lo taqumu*—drink, drunk, spew, fall.

"Because of the sword which I will send among you."

*Mippenei ha-cherev asher anokhi sholeach beineikem*—sword.

**The Key Verse (25:29):**
"I begin to bring evil on the city whereupon my name is called."

*Ki hinneh va-ir asher-niqra shemi alekha anokhi matchil le-hara*—evil begins at Jerusalem.

"Should you be utterly unpunished?"

*Ve-attem hinnaqeh tinnaquu*—can you escape?

"You shall not be unpunished."

*Lo tinnaquu*—not unpunished.

"I will call for a sword upon all the inhabitants of the earth."

*Ki cherev ani qore al-kol-yoshevei ha-aretz*—sword on all.

**Universal Judgment (25:30-38):**
"YHWH shall roar from on high."

*YHWH mi-marom yish'ag*—roar from high.

"Utter his voice from his holy habitation."

*U-mi-me'on qodsho yitten qolo*—voice from habitation.

"He shall mightily roar because of his fold."

*Sha'og yish'ag al-navehu*—roar for fold.

"Give a shout, as they that tread the grapes."

*Hedad ke-dorekhim ya'aneh*—grape-treading shout.

"Against all the inhabitants of the earth."

*El kol-yoshevei ha-aretz*—all inhabitants.

**The Key Verse (25:31):**
"A noise is come even to the end of the earth."

*Ba sha'on ad-qetzeh ha-aretz*—noise to earth's end.

"YHWH has a controversy with the nations."

*Ki riv la-YHWH ba-goyim*—controversy with nations.

"He does enter into judgment with all flesh."

*Nishpat hu le-khol-basar*—judging all flesh.

"The wicked, he has given them to the sword."

*Ha-resha'im netanam la-cherev*—wicked to sword.

"Evil shall go forth from nation to nation."

*Hinneh ra'ah yotzet mi-goy el-goy*—evil spreads.

"A great storm shall be raised up from the uttermost parts of the earth."

*U-se'arah gedolah te'or mi-yarketei-aretz*—great storm.

"The slain of YHWH shall be at that day from one end of the earth even unto the other."

*Ve-hayu challalei YHWH ba-yom ha-hu mi-qetzeh ha-aretz ve-ad-qetzeh ha-aretz*—slain everywhere.

"They shall not be lamented, neither gathered, nor buried."

*Lo yissafedu ve-lo ye'asefu ve-lo yiqqaveru*—no burial.

"They shall be dung upon the face of the ground."

*Domen al-penei ha-adamah yihyu*—dung.

**The Key Verses (25:34-38):**
"Wail, you shepherds, and cry."

*Heililu ha-ro'im ve-za'aqu*—wail, shepherds.

"Wallow yourselves in the dust, you leaders of the flock."

*Ve-hitpaleshu addirei ha-tzon*—wallow.

"The days of your slaughter are fully come."

*Ki-male'u yemeikhem li-tevo'ach*—slaughter days.

"I will break you in pieces, and you shall fall like a precious vessel."

*U-tefotzoteikhem u-nefaltem ki-kheli chemdah*—fall like vessel.

"The shepherds shall have no way to flee."

*Ve-avad manos min-ha-ro'im*—no flight.

"Nor the leaders of the flock to escape."

*U-feletah me-addirei ha-tzon*—no escape.

"YHWH lays waste their pasture."

*Ki-shoded YHWH et-mar'itam*—pasture wasted.

"The peaceable folds are brought to silence."

*Ve-nadmu ne'ot ha-shalom*—silent folds.

"Because of the fierce anger of YHWH."

*Mippenei charon af-YHWH*—fierce anger.

"He has forsaken his covert, as the lion."

*Azav ke-kefir sukko*—forsaken like lion.

"Their land is become a waste."

*Ki-hayetah artzam le-shammah*—land waste.

"Because of the fierceness of the oppressing sword."

*Mippenei charon ha-yonah*—oppressing fierceness.

"Because of his fierce anger."

*U-mippenei charon appo*—fierce anger.

**Archetypal Layer:** Jeremiah 25 contains **23 years of Jeremiah's ministry (25:3)**, **Nebuchadnezzar as "my servant" (25:9)**, **the 70 years prophecy (25:11-12)**, **the cup of wrath passed to nations (25:15-29)**, and **universal judgment (25:30-38)**.

**Ethical Inversion Applied:**
- "In the fourth year of Jehoiakim... the first year of Nebuchadrezzar"—605 BCE
- "These three and twenty years, the word of YHWH has come unto me"—23 years
- "I have spoken unto you... but you have not hearkened"—unheard
- "YHWH has sent unto you all his servants the prophets"—prophets sent
- "'Return now every one from his evil way'"—return call
- "Yet you have not hearkened unto me"—didn't listen
- "I will send unto Nebuchadrezzar... my servant"—Babylon = servant
- "I will utterly destroy them"—destroy
- "I will cause to cease... the voice of mirth"—joy ceases
- "The voice of the bridegroom and the voice of the bride"—weddings cease
- "These nations shall serve the king of Babylon seventy years"—70 years
- "When seventy years are accomplished, that I will punish the king of Babylon"—Babylon punished
- "Take this cup of the wine of fury"—fury cup
- "Cause all the nations... to drink it"—nations drink
- "They shall drink, and reel to and fro, and be like madmen"—drunken nations
- "The king of Sheshach shall drink after them"—Babylon last
- "Drink, and be drunken, and spew, and fall, and rise no more"—fall
- "I begin to bring evil on the city whereupon my name is called"—Jerusalem first
- "Should you be utterly unpunished? You shall not be unpunished"—all punished
- "YHWH shall roar from on high"—YHWH roars
- "YHWH has a controversy with the nations"—controversy
- "He does enter into judgment with all flesh"—all flesh judged
- "The slain of YHWH shall be at that day from one end of the earth even unto the other"—universal
- "Wail, you shepherds"—shepherds wail
- "The days of your slaughter are fully come"—slaughter days
- "YHWH lays waste their pasture"—pasture wasted

**Modern Equivalent:** Jeremiah 25's 70-year prophecy (25:11-12) was fulfilled in Babylon's fall to Persia (539 BCE) and the temple's rebuilding (516 BCE). Daniel 9:2 cites this prophecy. The cup of wrath (25:15-29) becomes a major biblical image (Revelation 14:10; 16:19).

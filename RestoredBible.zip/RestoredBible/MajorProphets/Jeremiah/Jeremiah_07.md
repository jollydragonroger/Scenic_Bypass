# Jeremiah 7: The Temple Sermon

*From the Hebrew: הַדָּבָר אֲשֶׁר הָיָה אֶל־יִרְמְיָהוּ (Ha-Davar Asher Hayah El-Yirmeyahu) — The Word That Came to Jeremiah*

---

## The Temple Sermon (7:1-15)

**7:1** The word that came to Jeremiah from YHWH, saying:

**7:2** "Stand in the gate of YHWH's house, and proclaim there this word, and say: Hear the word of YHWH, all you of Judah, that enter in at these gates to worship YHWH.

**7:3** "Thus says YHWH of hosts, the God of Israel: Amend your ways and your doings, and I will cause you to dwell in this place.

**7:4** "Trust not in lying words, saying: 'The temple of YHWH, the temple of YHWH, the temple of YHWH, are these.'

**7:5** "For if you thoroughly amend your ways and your doings; if you thoroughly execute justice between a man and his neighbour;

**7:6** "If you oppress not the stranger, the fatherless, and the widow, and shed not innocent blood in this place, neither walk after other gods to your hurt;

**7:7** "Then will I cause you to dwell in this place, in the land that I gave to your fathers, from of old even for evermore.

**7:8** "Behold, you trust in lying words, that cannot profit.

**7:9** "Will you steal, murder, and commit adultery, and swear falsely, and offer unto Baal, and walk after other gods whom you have not known,

**7:10** "And come and stand before me in this house, whereupon my name is called, and say: 'We are delivered,' that you may do all these abominations?

**7:11** "Is this house, whereupon my name is called, become a den of robbers in your eyes? Behold, I, even I, have seen it," says YHWH.

**7:12** "But go now unto my place which was in Shiloh, where I caused my name to dwell at the first, and see what I did to it for the wickedness of my people Israel.

**7:13** "And now, because you have done all these works," says YHWH, "and I spoke unto you, rising up early and speaking, but you heard not; and I called you, but you answered not;

**7:14** "Therefore will I do unto the house, whereupon my name is called, wherein you trust, and unto the place which I gave to you and to your fathers, as I have done to Shiloh.

**7:15** "And I will cast you out of my sight, as I have cast out all your brethren, even the whole seed of Ephraim."

---

## Do Not Pray for This People (7:16-20)

**7:16** "Therefore pray not for this people, neither lift up cry nor prayer for them, neither make intercession to me; for I will not hear you.

**7:17** "See you not what they do in the cities of Judah and in the streets of Jerusalem?

**7:18** "The children gather wood, and the fathers kindle the fire, and the women knead the dough, to make cakes to the queen of heaven, and to pour out drink-offerings unto other gods, that they may provoke me.

**7:19** "Do they provoke me?" says YHWH; "do they not provoke themselves, to the confusion of their own faces?"

**7:20** Therefore thus says the Lord YHWH: "Behold, my anger and my fury shall be poured out upon this place, upon man, and upon beast, and upon the trees of the field, and upon the fruit of the ground; and it shall burn, and shall not be quenched."

---

## Obedience Better Than Sacrifice (7:21-28)

**7:21** Thus says YHWH of hosts, the God of Israel: "Add your burnt-offerings unto your sacrifices, and eat flesh.

**7:22** "For I spoke not unto your fathers, nor commanded them in the day that I brought them out of the land of Egypt, concerning burnt-offerings or sacrifices;

**7:23** "But this thing I commanded them, saying: Hearken unto my voice, and I will be your God, and you shall be my people; and walk in all the way that I command you, that it may be well with you.

**7:24** "But they hearkened not, nor inclined their ear, but walked in their own counsels, even in the stubbornness of their evil heart, and went backward, and not forward.

**7:25** "Since the day that your fathers came forth out of the land of Egypt unto this day, I have sent unto you all my servants the prophets, daily rising up early and sending them;

**7:26** "Yet they hearkened not unto me, nor inclined their ear, but made their neck stiff; they did worse than their fathers.

**7:27** "And you shall speak all these words unto them, but they will not hearken to you; you shall also call unto them, but they will not answer you.

**7:28** "And you shall say unto them: This is the nation that has not hearkened to the voice of YHWH their God, nor received correction; truth is perished, and is cut off from their mouth."

---

## Topheth and the Valley of Slaughter (7:29-34)

**7:29** Cut off your hair, and cast it away, and take up a lamentation on the high hills; for YHWH has rejected and forsaken the generation of his wrath.

**7:30** "For the children of Judah have done that which is evil in my sight," says YHWH; "they have set their detestable things in the house whereupon my name is called, to defile it.

**7:31** "And they have built the high places of Topheth, which is in the valley of the son of Hinnom, to burn their sons and their daughters in the fire; which I commanded not, neither came it into my mind.

**7:32** "Therefore, behold, the days come," says YHWH, "that it shall no more be called Topheth, nor the valley of the son of Hinnom, but the valley of slaughter; for they shall bury in Topheth, for lack of room.

**7:33** "And the carcasses of this people shall be food for the fowls of the heaven, and for the beasts of the earth; and none shall frighten them away.

**7:34** "Then will I cause to cease from the cities of Judah, and from the streets of Jerusalem, the voice of mirth and the voice of gladness, the voice of the bridegroom and the voice of the bride; for the land shall be desolate."

---

## Synthesis Notes

**Key Restorations:**

**Temple Gate Sermon (7:1-4):**
"Stand in the gate of YHWH's house."

*Amod be-sha'ar beit-YHWH*—temple gate.

"Proclaim there this word."

*Ve-qarata sham et-ha-davar ha-zeh*—proclaim word.

"Amend your ways and your doings."

*Heitivu darkheikhem u-ma'aleleikhem*—amend ways.

"I will cause you to dwell in this place."

*Va-ashkenak ba-maqom ha-zeh*—dwell in place.

**The Key Verse (7:4):**
"Trust not in lying words."

*Al-tivtechu lakhem el-divrei ha-sheqer*—no lying trust.

"Saying: 'The temple of YHWH, the temple of YHWH, the temple of YHWH, are these.'"

*Lemor heikhal YHWH heikhal YHWH heikhal YHWH hemmah*—triple temple chant.

**False Security:**
The threefold repetition "temple of YHWH" mocks the people's false confidence that YHWH's temple presence guaranteed protection regardless of behavior.

**Conditions for Dwelling (7:5-7):**
"If you thoroughly amend your ways."

*Ki im-heitiv teitivu et-darkheikhem*—truly amend.

"If you thoroughly execute justice."

*Im-aso ta'asu mishpat*—truly do justice.

"Between a man and his neighbour."

*Bein ish u-vein re'ehu*—between people.

"If you oppress not the stranger, the fatherless, and the widow."

*Ger yatom ve-almanah lo ta'ashoquu*—don't oppress vulnerable.

"Shed not innocent blood in this place."

*Ve-dam naqi al-tishpekhu ba-maqom ha-zeh*—no innocent blood.

"Neither walk after other gods to your hurt."

*Ve-acharei elohim acherim lo telekhu le-ra lakhem*—no other gods.

"Then will I cause you to dwell in this place."

*Ve-shikhanti etkhem ba-maqom ha-zeh*—dwell in place.

**The Key Verses (7:9-11):**
"Will you steal, murder, and commit adultery."

*Ha-ganov ratzocah ve-na'of*—steal, murder, adultery.

"Swear falsely."

*Ve-hishave'a la-sheqer*—false oaths.

"Offer unto Baal."

*Ve-qatter la-Ba'al*—Baal offerings.

"Walk after other gods whom you have not known."

*Ve-halokh acharei elohim acherim asher lo-yeda'tem*—unknown gods.

"Come and stand before me in this house."

*U-vatem va-amadtem lefanai ba-bayit ha-zeh*—stand in temple.

"'We are delivered.'"

*Nitztzalnu*—"we are saved."

"That you may do all these abominations?"

*Lema'an asot et kol-ha-to'evot ha-elleh*—do abominations.

**The Key Verse (7:11):**
"Is this house... become a den of robbers in your eyes?"

*Ha-me'arat paritzim hayah ha-bayit ha-zeh... be-eineikhem*—robber den. Jesus quotes this in Matthew 21:13; Mark 11:17; Luke 19:46.

"Behold, I, even I, have seen it."

*Gam anokhi hinneh ra'iti*—I've seen.

**Shiloh Warning (7:12-15):**
"Go now unto my place which was in Shiloh."

*Ki lekhu-na el-meqomi asher be-Shilo*—go to Shiloh.

"Where I caused my name to dwell at the first."

*Asher shikkanti shemi sham ba-rishonah*—name dwelt first.

"See what I did to it for the wickedness of my people Israel."

*U-re'u et asher-asiti lo mippenei ra'at ammi Yisra'el*—see what I did.

**Historical Reference:**
Shiloh was destroyed around 1050 BCE (see Psalm 78:60; 1 Samuel 4), proving YHWH would abandon even his dwelling place.

"I will do unto the house... as I have done to Shiloh."

*Ve-asiti la-bayit... ka-asher asiti le-Shilo*—same fate.

"I will cast you out of my sight."

*Ve-hishlakhti etkhem me-al panai*—cast out.

"As I have cast out all your brethren, even the whole seed of Ephraim."

*Ka-asher hishlakhti et-kol-acheikhem et kol-zera Efrayim*—like Ephraim (722 BCE).

**No Intercession (7:16-20):**
**The Key Verse (7:16):**
"Pray not for this people."

*Ve-attah al-titpallel be'ad ha-am ha-zeh*—don't pray.

"Neither lift up cry nor prayer for them."

*Ve-al-tissa va'adam rinnah u-tefillah*—no cry or prayer.

"Neither make intercession to me."

*Ve-al-tifga-vi*—don't intercede.

"For I will not hear you."

*Ki-einenni shome'a otakh*—I won't hear.

**Queen of Heaven (7:18):**
"The children gather wood."

*Ha-banim melaqtim etzim*—children gather.

"The fathers kindle the fire."

*Ve-ha-avot mav'irim et-ha-esh*—fathers kindle.

"The women knead the dough."

*Ve-ha-nashim lashot batzek*—women knead.

"To make cakes to the queen of heaven."

*La'asot kavvanim li-melekhet ha-shamayim*—cakes for queen of heaven.

**Queen of Heaven:**
Probably Ishtar/Astarte, Mesopotamian goddess. Family involvement shows pervasive idolatry.

**Obedience Over Sacrifice (7:21-26):**
"Add your burnt-offerings unto your sacrifices, and eat flesh."

*Oloteikhem sefu al-zivchekhem ve-ikhlu vasar*—eat it all (sarcasm).

**The Key Verses (7:22-23):**
"I spoke not unto your fathers... concerning burnt-offerings or sacrifices."

*Ki lo-dibbarti et-avoteikhem... al-divrei olah va-zavach*—not about sacrifice.

"But this thing I commanded them, saying: Hearken unto my voice."

*Ki im-et-ha-davar ha-zeh tzivviti otam lemor shim'u ve-qoli*—obey my voice.

"I will be your God, and you shall be my people."

*Ve-hayiti lakhem le-lohim ve-attem tihyu-li le-am*—covenant formula.

"Walk in all the way that I command you."

*Ve-halakhtem be-khol-ha-derekh asher atzavveh etkhem*—walk commanded way.

"That it may be well with you."

*Lema'an yitav lakhem*—for your good.

"They hearkened not, nor inclined their ear."

*Ve-lo sham'u ve-lo hittu et-oznam*—didn't hear.

"Walked in their own counsels."

*Va-yelkhu be-mo'atzot*—own counsels.

"In the stubbornness of their evil heart."

*Be-sherirut libbam ha-ra*—evil heart stubbornness.

"Went backward, and not forward."

*Va-yihyu le-achor ve-lo le-fanim*—backward, not forward.

**The Key Verse (7:28):**
"This is the nation that has not hearkened to the voice of YHWH."

*Zeh ha-goy asher lo-sham'u be-qol YHWH Elohav*—not hearkened.

"Nor received correction."

*Ve-lo laqechu musar*—no correction.

"Truth is perished."

*Avdah ha-emunah*—truth perished.

"Is cut off from their mouth."

*Ve-nikhretah mi-pihem*—cut from mouth.

**Topheth (7:29-34):**
"Cut off your hair, and cast it away."

*Gozzi nizrekh ve-hashllikhi*—cut hair.

"Take up a lamentation on the high hills."

*Ve-si'i al-shefayim qinah*—hillside lamentation.

"YHWH has rejected and forsaken the generation of his wrath."

*Ki ma'as YHWH va-yittosh et-dor evrato*—wrath generation.

**The Key Verse (7:31):**
"They have built the high places of Topheth."

*U-vanu bamot ha-Tofett*—Topheth high places.

"Which is in the valley of the son of Hinnom."

*Asher be-gei ven-Hinnom*—Hinnom Valley (Gehenna).

"To burn their sons and their daughters in the fire."

*Lisrof et-beneihem ve-et-benoteihem ba-esh*—child sacrifice.

"Which I commanded not."

*Asher lo tzivviti*—not commanded.

"Neither came it into my mind."

*Ve-lo aletah al-libbi*—never in my mind.

**The Key Verse (7:32):**
"It shall no more be called Topheth."

*Ve-lo-yiqqare od ha-Tofett*—not called Topheth.

"Nor the valley of the son of Hinnom."

*Ve-gei ven-Hinnom*—not Hinnom.

"But the valley of slaughter."

*Ki im-gei ha-haregah*—valley of slaughter.

"They shall bury in Topheth, for lack of room."

*Ve-qavru ve-Tofett me-ein maqom*—bury for lack of room.

**The Key Verse (7:34):**
"I will cause to cease... the voice of mirth and the voice of gladness."

*Ve-hishbatti... qol sason ve-qol simchah*—cease joy.

"The voice of the bridegroom and the voice of the bride."

*Qol chatan ve-qol kallah*—cease wedding sounds.

"The land shall be desolate."

*Ki le-chorvah tihyeh ha-aretz*—desolate land.

**Archetypal Layer:** Jeremiah 7 is the **Temple Sermon**, containing **"'The temple of YHWH, the temple of YHWH, the temple of YHWH'" (7:4)**, **"Is this house... become a den of robbers?" (7:11)**—Matthew 21:13, **the Shiloh warning (7:12-14)**, and **Topheth/Gehenna (7:31-32)**.

**Ethical Inversion Applied:**
- "Stand in the gate of YHWH's house"—temple gate
- "Amend your ways and your doings"—amendment required
- "'The temple of YHWH, the temple of YHWH, the temple of YHWH'"—false security
- "If you thoroughly amend your ways"—conditional dwelling
- "If you oppress not the stranger, the fatherless, and the widow"—social justice
- "Will you steal, murder, and commit adultery... and come and stand before me"—hypocritical worship
- "'We are delivered'"—false security
- "Is this house... become a den of robbers?"—Matthew 21:13
- "Go now unto my place which was in Shiloh"—Shiloh warning
- "See what I did to it"—Shiloh destroyed
- "I will do unto the house... as I have done to Shiloh"—temple warning
- "I will cast you out of my sight"—exile
- "Pray not for this people"—no intercession
- "The women knead the dough, to make cakes to the queen of heaven"—family idolatry
- "I spoke not unto your fathers... concerning burnt-offerings"—obedience priority
- "Hearken unto my voice"—obedience
- "They hearkened not... walked in... the stubbornness of their evil heart"—disobedience
- "Went backward, and not forward"—regression
- "Truth is perished"—truth gone
- "They have built the high places of Topheth"—Gehenna
- "To burn their sons and their daughters in the fire"—child sacrifice
- "Which I commanded not, neither came it into my mind"—not commanded
- "The valley of slaughter"—slaughter valley
- "I will cause to cease... the voice of mirth"—joy ends

**Modern Equivalent:** Jeremiah 7 is quoted by Jesus when cleansing the temple (Matthew 21:13; Mark 11:17; Luke 19:46). The Shiloh warning (7:12-14) shows that no shrine is guaranteed protection. The Valley of Hinnom (7:31-32) became "Gehenna," Jesus's word for hell.

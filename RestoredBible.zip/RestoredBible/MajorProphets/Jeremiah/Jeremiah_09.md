# Jeremiah 9: Oh That I Had a Lodging Place

*From the Hebrew: מִי־יִתְּנֵנִי בַמִּדְבָּר (Mi-Yitteneni Va-Midbar) — Oh That I Were in the Wilderness*

---

## Jeremiah's Lament (9:1-6)

**9:1** Oh that my head were waters, and my eyes a fountain of tears, that I might weep day and night for the slain of the daughter of my people!

**9:2** Oh that I had in the wilderness a lodging-place of wayfaring men, that I might leave my people, and go from them! For they are all adulterers, an assembly of treacherous men.

**9:3** "And they bend their tongue, their bow of falsehood; and they are grown mighty in the land, but not for truth; for they proceed from evil to evil, and me they know not," says YHWH.

**9:4** "Take heed every one of his neighbour, and trust not in any brother; for every brother acts craftily, and every neighbour goes about with slanders.

**9:5** "And they deceive every one his neighbour, and speak not the truth; they have taught their tongue to speak lies, they weary themselves to commit iniquity.

**9:6** "Your habitation is in the midst of deceit; through deceit they refuse to know me," says YHWH.

---

## Judgment Announced (9:7-11)

**9:7** Therefore thus says YHWH of hosts: "Behold, I will smelt them, and try them; for how else should I do, because of the daughter of my people?

**9:8** "Their tongue is a sharpened arrow, it speaks deceit; one speaks peaceably to his neighbour with his mouth, but in his heart he lays wait for him.

**9:9** "Shall I not punish them for these things?" says YHWH; "shall not my soul be avenged on such a nation as this?"

**9:10** For the mountains will I take up a weeping and wailing, and for the pastures of the wilderness a lamentation, because they are burned up, so that none passes through, and they hear not the voice of the cattle; both the fowl of the heavens and the beast are fled, and gone.

**9:11** "And I will make Jerusalem heaps, a dwelling-place of jackals; and I will make the cities of Judah a desolation, without inhabitant."

---

## Why the Land Perishes (9:12-16)

**9:12** Who is the wise man, that may understand this? And who is he to whom the mouth of YHWH has spoken, that he may declare it? Why is the land perished and laid waste like a wilderness, so that none passes through?

**9:13** And YHWH says: "Because they have forsaken my law which I set before them, and have not hearkened to my voice, neither walked therein;

**9:14** "But have walked after the stubbornness of their own heart, and after the Baalim, which their fathers taught them."

**9:15** Therefore thus says YHWH of hosts, the God of Israel: "Behold, I will feed them, even this people, with wormwood, and give them water of gall to drink.

**9:16** "I will scatter them also among the nations, whom neither they nor their fathers have known; and I will send the sword after them, till I have consumed them."

---

## Call for Mourning (9:17-22)

**9:17** Thus says YHWH of hosts: "Consider, and call for the mourning women, that they may come; and send for the wise women, that they may come;

**9:18** "And let them make haste, and take up a wailing for us, that our eyes may run down with tears, and our eyelids gush out with waters.

**9:19** "For a voice of wailing is heard out of Zion: 'How are we undone! We are greatly confounded, because we have forsaken the land, because our dwellings have cast us out.'"

**9:20** "Yet hear the word of YHWH, O women, and let your ear receive the word of his mouth, and teach your daughters wailing, and every one her neighbour lamentation.

**9:21** "For death is come up into our windows, it is entered into our palaces, to cut off the children from the street, and the young men from the broad places."

**9:22** Speak: "Thus says YHWH: The carcasses of men shall fall as dung upon the open field, and as the handful after the harvestman; and none shall gather them."

---

## True Glory (9:23-26)

**9:23** Thus says YHWH: "Let not the wise man glory in his wisdom, neither let the mighty man glory in his might, let not the rich man glory in his riches;

**9:24** "But let him that glories glory in this, that he understands, and knows me, that I am YHWH who exercises lovingkindness, justice, and righteousness, in the earth; for in these things I delight," says YHWH.

**9:25** "Behold, the days come," says YHWH, "that I will punish all them that are circumcised in their uncircumcision:

**9:26** "Egypt, and Judah, and Edom, and the children of Ammon, and Moab, and all that have the corners of their hair polled, that dwell in the wilderness; for all the nations are uncircumcised, but all the house of Israel are uncircumcised in the heart."

---

## Synthesis Notes

**Key Restorations:**

**Jeremiah's Lament (9:1-2):**
**The Key Verse (9:1):**
"Oh that my head were waters."

*Mi-yitten roshi mayim*—head = waters.

"My eyes a fountain of tears."

*Ve-eini meqor dim'ah*—eyes = tear fountain.

"That I might weep day and night."

*Ve-evkeh yomam va-laylah*—weep day/night.

"For the slain of the daughter of my people."

*Et challei bat-ammi*—for slain.

**The Key Verse (9:2):**
"Oh that I had in the wilderness a lodging-place of wayfaring men."

*Mi-yitteneni va-midbar melon orchim*—wilderness lodging.

"That I might leave my people, and go from them."

*Ve-e'ezvah et-ammi ve-elekhah me-ittam*—leave people.

"They are all adulterers."

*Ki khullam mena'afim*—all adulterers.

"An assembly of treacherous men."

*Atzeret bogedim*—treacherous assembly.

**Society of Lies (9:3-6):**
"They bend their tongue, their bow of falsehood."

*Va-yadrekhu et-leshonam qashtam sheqer*—tongue = bow of lies.

"They are grown mighty in the land, but not for truth."

*Ve-lo le-emunah gavru ba-aretz*—mighty, but not for truth.

"They proceed from evil to evil."

*Ki me-ra'ah el-ra'ah yatza'u*—evil to evil.

"Me they know not."

*Ve-oti lo-yada'u*—don't know me.

"Take heed every one of his neighbour."

*Ish me-re'ehu hishameru*—beware of neighbor.

"Trust not in any brother."

*Ve-al-kol-ach al-tivtachu*—don't trust brothers.

"Every brother acts craftily."

*Ki khol-ach aqov ya'qov*—brother deceives (Jacob wordplay).

"Every neighbour goes about with slanders."

*Ve-khol-re'a rakhil yahalokh*—neighbor slanders.

"They deceive every one his neighbour."

*Ve-ish be-re'ehu yehatelu*—deceive neighbor.

"Speak not the truth."

*Ve-emet lo yedabberu*—no truth.

"They have taught their tongue to speak lies."

*Limmedu leshonam dabber-sheqer*—taught tongue lies.

"They weary themselves to commit iniquity."

*Ha'aveh nil'u*—wearied by iniquity.

"Your habitation is in the midst of deceit."

*Shivtekha be-tokh mirmah*—dwelling in deceit.

"Through deceit they refuse to know me."

*Be-mirmah me'anu da'at-oti*—refuse to know through deceit.

**Judgment (9:7-11):**
"I will smelt them, and try them."

*Hineni tzorfam u-vachantim*—smelt and try.

"For how else should I do, because of the daughter of my people?"

*Ki-eikh e'eseh mippenei bat-ammi*—what else to do?

"Their tongue is a sharpened arrow."

*Chetz shachut leshonam*—sharpened arrow tongue.

"It speaks deceit."

*Mirmah dibber*—speaks deceit.

"One speaks peaceably to his neighbour with his mouth."

*Be-fiv shalom et-re'ehu yedabber*—mouth speaks peace.

"In his heart he lays wait for him."

*U-ve-qirbo yasim orbo*—heart sets ambush.

**The Key Verse (9:9):**
"Shall I not punish them for these things?"

*Ha-al-elleh lo-efqod-bam*—must punish. (Repeats 5:9, 29)

"Shall not my soul be avenged on such a nation as this?"

*Im be-goy asher-ka-zeh lo titnaqem nafshi*—avenged on such nation.

"I will make Jerusalem heaps."

*Ve-natatti et-Yerushalayim le-gallim*—Jerusalem = heaps.

"A dwelling-place of jackals."

*Me'on tannim*—jackal dwelling.

"The cities of Judah a desolation, without inhabitant."

*Ve-et-arei Yehudah etten shemamah mi-bli yoshev*—Judah desolate.

**Why Land Perishes (9:12-16):**
"Who is the wise man, that may understand this?"

*Mi-ha-ish he-chakham ve-yaven et-zot*—who understands?

"Why is the land perished?"

*Al-mah avdah ha-aretz*—why perished?

"Laid waste like a wilderness."

*Nitzzetah kha-midbar*—wilderness waste.

"None passes through."

*Mi-beli over*—none passes.

"Because they have forsaken my law."

*Al-azvam et-torati*—forsook Torah.

"Have not hearkened to my voice."

*Ve-lo-sham'u ve-qoli*—didn't hear voice.

"Neither walked therein."

*Ve-lo-halekhu vah*—didn't walk in it.

"Walked after the stubbornness of their own heart."

*Va-yelkhu acharei sherirut libbam*—heart stubbornness.

"After the Baalim, which their fathers taught them."

*Ve-acharei ha-Be'alim asher limmedum avotam*—Baal-following.

"I will feed them, even this people, with wormwood."

*Hineni ma'akhilam et-ha-am ha-zeh la'anah*—wormwood food.

"Give them water of gall to drink."

*Ve-hishqitim mei-rosh*—gall water.

"I will scatter them also among the nations."

*Va-hafitzotzim ba-goyim*—scatter among nations.

"Whom neither they nor their fathers have known."

*Asher lo yade'u hemmah va-avotam*—unknown nations.

"I will send the sword after them, till I have consumed them."

*Ve-shillachti achareihem et-ha-cherev ad kalloti otam*—sword follows.

**Mourning Women (9:17-22):**
"Call for the mourning women."

*Qir'u la-meqonenot*—call mourners.

"Send for the wise women."

*Ve-el-ha-chakhamot shilchu*—send for wise women.

"Let them make haste."

*Ve-temahernah*—hurry.

"Take up a wailing for us."

*Ve-tissenah aleinu nehi*—wail for us.

"Our eyes may run down with tears."

*Ve-tirednah eineinu dim'ah*—eyes run tears.

"Our eyelids gush out with waters."

*Ve-af'appeinu yizzelu-mayim*—eyelids gush.

"'How are we undone!'"

*Eikh shuddadnu*—how undone!

"'We are greatly confounded.'"

*Boshnu me'od*—greatly confounded.

"'Because we have forsaken the land.'"

*Ki-azavnu aretz*—forsook land.

"'Our dwellings have cast us out.'"

*Ki hishllikhu mishkenoteinu*—dwellings cast out.

"Death is come up into our windows."

*Ki-alah mavet be-challoneinu*—death in windows.

"Entered into our palaces."

*Ba be-armenotinu*—death in palaces.

"To cut off the children from the street."

*Le-hakhrit olal mi-chutz*—cut off children.

"The young men from the broad places."

*Bachurim me-rechovot*—cut off young men.

"The carcasses of men shall fall as dung upon the open field."

*Ve-naflah nivlat ha-adam ke-domen al-penei ha-sadeh*—dung-corpses.

"As the handful after the harvestman."

*U-khe-amir me-acharei ha-qotzer*—harvestman's handful.

"None shall gather them."

*Ve-ein me'assef*—none gathers.

**True Glory (9:23-26):**
**The Key Verses (9:23-24):**
"Let not the wise man glory in his wisdom."

*Al-yithalel chakham be-chokhmato*—no wisdom glory.

"Neither let the mighty man glory in his might."

*Ve-al-yithalel ha-gibbor bi-gevurato*—no might glory.

"Let not the rich man glory in his riches."

*Al-yithalel ashir be-oshro*—no riches glory.

**The Key Verse (9:24):**
"But let him that glories glory in this."

*Ki im-be-zot yithalel ha-mithalel*—glory in this.

"That he understands, and knows me."

*Haskel ve-yado'a oti*—understands and knows me.

"That I am YHWH who exercises lovingkindness, justice, and righteousness, in the earth."

*Ki ani YHWH oseh chesed mishpat u-tzedaqah ba-aretz*—lovingkindness, justice, righteousness.

"For in these things I delight."

*Ki ve-elleh chafatzti*—I delight in these. 1 Corinthians 1:31; 2 Corinthians 10:17 quote this.

**Circumcised Uncircumcision (9:25-26):**
"I will punish all them that are circumcised in their uncircumcision."

*U-faqadti al-kol-mul be-orlah*—circumcised but uncircumcised.

"Egypt, and Judah, and Edom, and the children of Ammon, and Moab."

*Al-Mitzrayim ve-al-Yehudah ve-al-Edom ve-al-benei Ammon ve-al-Mo'av*—nations listed.

"All that have the corners of their hair polled."

*Ve-al kol-qetzutzei fe'ah*—clipped corners.

"All the nations are uncircumcised."

*Ki khol-ha-goyim arelim*—nations uncircumcised.

"All the house of Israel are uncircumcised in the heart."

*Ve-khol-beit Yisra'el arlei-lev*—Israel uncircumcised in heart.

**Archetypal Layer:** Jeremiah 9 contains **"Oh that my head were waters, and my eyes a fountain of tears" (9:1)**, **"Let not the wise man glory in his wisdom... but let him that glories glory in this, that he understands, and knows me" (9:23-24)**—1 Corinthians 1:31, and **"all the house of Israel are uncircumcised in the heart" (9:26)**.

**Ethical Inversion Applied:**
- "Oh that my head were waters, and my eyes a fountain of tears"—weeping prophet
- "Oh that I had in the wilderness a lodging-place"—escape desire
- "They are all adulterers, an assembly of treacherous men"—all treacherous
- "They bend their tongue, their bow of falsehood"—lying bow
- "They proceed from evil to evil"—evil to evil
- "Me they know not"—don't know YHWH
- "Take heed every one of his neighbour, and trust not in any brother"—trust no one
- "Every brother acts craftily"—Jacob wordplay
- "They have taught their tongue to speak lies"—learned lying
- "Your habitation is in the midst of deceit"—deceit dwelling
- "Their tongue is a sharpened arrow, it speaks deceit"—arrow tongue
- "One speaks peaceably... in his heart he lays wait"—ambush heart
- "Shall I not punish them for these things?"—must punish
- "I will make Jerusalem heaps, a dwelling-place of jackals"—jackal dwelling
- "Who is the wise man, that may understand this?"—who understands?
- "Because they have forsaken my law"—Torah forsaken
- "Walked after the stubbornness of their own heart"—heart stubbornness
- "I will feed them... with wormwood"—wormwood food
- "I will scatter them also among the nations"—exile
- "Call for the mourning women"—professional mourners
- "Death is come up into our windows"—death enters
- "The carcasses of men shall fall as dung"—dung-corpses
- "Let not the wise man glory in his wisdom"—no self-glory
- "Let him that glories glory in this, that he understands, and knows me"—1 Corinthians 1:31
- "I am YHWH who exercises lovingkindness, justice, and righteousness"—divine character
- "For in these things I delight"—divine delight
- "All the house of Israel are uncircumcised in the heart"—heart uncircumcision

**Modern Equivalent:** Jeremiah 9:1's "fountain of tears" established Jeremiah as "the weeping prophet." 9:23-24 is quoted in 1 Corinthians 1:31 and 2 Corinthians 10:17—"Let him who boasts boast in the Lord." "Uncircumcised in the heart" (9:26) anticipates Romans 2:28-29.

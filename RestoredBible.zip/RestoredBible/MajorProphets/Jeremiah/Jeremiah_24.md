# Jeremiah 24: The Two Baskets of Figs

*From the Hebrew: הִרְאַנִי יְהוָה (Hir'ani YHWH) — YHWH Showed Me*

---

## The Vision of the Figs (24:1-3)

**24:1** YHWH showed me, and, behold, two baskets of figs set before the temple of YHWH; after that Nebuchadrezzar king of Babylon had carried away captive Jeconiah the son of Jehoiakim, king of Judah, and the princes of Judah, with the craftsmen and smiths, from Jerusalem, and had brought them to Babylon.

**24:2** One basket had very good figs, like the figs that are first-ripe; and the other basket had very bad figs, which could not be eaten, they were so bad.

**24:3** Then said YHWH unto me: "What do you see, Jeremiah?" And I said: "Figs; the good figs, very good; and the bad, very bad, that cannot be eaten, they are so bad."

---

## The Good Figs: The Exiles (24:4-7)

**24:4** And the word of YHWH came unto me, saying:

**24:5** "Thus says YHWH, the God of Israel: Like these good figs, so will I regard the captives of Judah, whom I have sent out of this place into the land of the Chaldeans, for good.

**24:6** "And I will set my eyes upon them for good, and I will bring them back to this land; and I will build them, and not pull them down; and I will plant them, and not pluck them up.

**24:7** "And I will give them a heart to know me, that I am YHWH; and they shall be my people, and I will be their God; for they shall return unto me with their whole heart."

---

## The Bad Figs: Those Who Remain (24:8-10)

**24:8** "And as the bad figs, which cannot be eaten, they are so bad; surely thus says YHWH: So will I make Zedekiah the king of Judah, and his princes, and the residue of Jerusalem, that remain in this land, and them that dwell in the land of Egypt;

**24:9** "I will even make them a horror among all the kingdoms of the earth for evil; a reproach and a proverb, a taunt and a curse, in all places whither I shall drive them.

**24:10** "And I will send the sword, the famine, and the pestilence, among them, till they be consumed from off the land that I gave unto them and to their fathers."

---

## Synthesis Notes

**Key Restorations:**

**Historical Setting (24:1):**
"After that Nebuchadrezzar king of Babylon had carried away captive Jeconiah."

*Acharei haglot Nevukhadre'zzar melekh-Bavel et-Yekhonyahu ben-Yehoyaqim melekh-Yehudah*—after 597 BCE deportation.

"The princes of Judah."

*Ve-et-sarei Yehudah*—princes exiled.

"With the craftsmen and smiths."

*Ve-et-ha-charash ve-et-ha-masger*—craftsmen/smiths.

"From Jerusalem."

*Mi-Yerushalayim*—from Jerusalem.

"Had brought them to Babylon."

*Va-yevi'em Bavelah*—to Babylon.

**Historical Context:**
This is after the 597 BCE deportation but before 586 BCE. Jeconiah/Jehoiachin and the elite were taken; Zedekiah was left as puppet king.

**Two Baskets (24:2-3):**
"Two baskets of figs set before the temple of YHWH."

*Shenei dudda'ei te'enim mu'adim lifnei heikhal YHWH*—two fig baskets.

"One basket had very good figs."

*Ha-dud echad te'enim tovot me'od*—very good figs.

"Like the figs that are first-ripe."

*Ki-te'enei ha-bikkurot*—firstfruits figs.

"The other basket had very bad figs."

*Ve-ha-dud echad te'enim ra'ot me'od*—very bad figs.

"Which could not be eaten, they were so bad."

*Asher lo-te'akhalnahh me-ro'a*—inedible.

"'What do you see, Jeremiah?'"

*Mah-attah ro'eh Yirmeyahu*—what see?

"'Figs; the good figs, very good.'"

*Te'enim ha-te'enim ha-tovot tovot me'od*—good figs.

"'The bad, very bad, that cannot be eaten.'"

*Ve-ha-ra'ot ra'ot me'od asher lo-te'akhalnahh me-ro'a*—bad figs.

**Good Figs = Exiles (24:5-7):**
**The Key Verse (24:5):**
"Like these good figs, so will I regard the captives of Judah."

*Ka-te'enim ha-tovot ha-elleh ken-akkir et-galut Yehudah*—regard captives like good figs.

"Whom I have sent out of this place into the land of the Chaldeans."

*Asher shillachti min-ha-maqom ha-zeh eretz Kasdim*—sent to Chaldea.

"For good."

*Le-tovah*—for good.

**Reversal:**
Those in exile (seemingly judged) are actually the "good figs"—the future hope.

**The Key Verse (24:6):**
"I will set my eyes upon them for good."

*Ve-samti eini aleihem le-tovah*—eyes for good.

"I will bring them back to this land."

*Va-hashivotim al-ha-aretz ha-zot*—bring back.

"I will build them, and not pull them down."

*U-venitim ve-lo eheros*—build, not pull down.

"I will plant them, and not pluck them up."

*U-neta'tim ve-lo ettosh*—plant, not pluck.

**Six Verbs Reversed:**
The six verbs of Jeremiah's commission (1:10) now reversed—building and planting, not destroying.

**The Key Verse (24:7):**
"I will give them a heart to know me."

*Ve-natatti lahem lev lada'at oti*—heart to know.

"That I am YHWH."

*Ki ani YHWH*—I am YHWH.

"They shall be my people, and I will be their God."

*Ve-hayu-li le-am va-anokhi ehyeh lahem le-lohim*—covenant formula.

"They shall return unto me with their whole heart."

*Ki-yashuvu elai be-khol-libbam*—whole-heart return.

**New Covenant Anticipation:**
"A heart to know me" anticipates the new covenant (31:31-34).

**Bad Figs = Remnant (24:8-10):**
**The Key Verse (24:8):**
"As the bad figs, which cannot be eaten."

*Ve-kha-te'enim ha-ra'ot asher lo-te'akhalnahh me-ro'a*—bad figs.

"So will I make Zedekiah the king of Judah."

*Ken-etten et-Tzidqiyyahu melekh-Yehudah*—Zedekiah like bad.

"His princes."

*Ve-et-sarav*—his princes.

"The residue of Jerusalem, that remain in this land."

*Ve-et she'erit Yerushalayim ha-nish'arim ba-aretz ha-zot*—Jerusalem remnant.

"Them that dwell in the land of Egypt."

*Ve-et-ha-yoshevim be-eretz Mitzrayim*—Egypt dwellers.

**Bad Figs:**
Those who remained (seemingly blessed) and those who fled to Egypt are actually the "bad figs."

**The Key Verse (24:9):**
"I will make them a horror among all the kingdoms of the earth."

*U-netattim li-za'avah le-ra'ah le-khol mamlekhot ha-aretz*—horror to kingdoms.

"A reproach and a proverb."

*Le-cherpah u-le-mashal*—reproach, proverb.

"A taunt and a curse."

*Li-shninah ve-li-qelalah*—taunt, curse.

"In all places whither I shall drive them."

*Be-khol-ha-meqomot asher addichim sham*—all places driven.

**The Key Verse (24:10):**
"I will send the sword, the famine, and the pestilence, among them."

*Ve-shillachti vam et-ha-cherev et-ha-ra'av ve-et-ha-daver*—sword, famine, pestilence.

"Till they be consumed from off the land."

*Ad-tummam me-al ha-adamah*—consumed.

"That I gave unto them and to their fathers."

*Asher-natatti lahem ve-la-avotam*—land given.

**Archetypal Layer:** Jeremiah 24 contains **the two baskets of figs (24:1-3)**, **exiles as good figs (24:5-7)**, **"I will give them a heart to know me" (24:7)**—anticipating the new covenant, and **those remaining as bad figs (24:8-10)**.

**Ethical Inversion Applied:**
- "YHWH showed me... two baskets of figs"—vision
- "Set before the temple of YHWH"—temple setting
- "After that Nebuchadrezzar... had carried away captive Jeconiah"—597 BCE
- "One basket had very good figs"—good figs
- "Like the figs that are first-ripe"—firstfruits quality
- "The other basket had very bad figs"—bad figs
- "Which could not be eaten, they were so bad"—inedible
- "Like these good figs, so will I regard the captives of Judah"—exiles = good
- "Whom I have sent out of this place... for good"—sent for good
- "I will set my eyes upon them for good"—eyes for good
- "I will bring them back to this land"—return promise
- "I will build them, and not pull them down"—build
- "I will plant them, and not pluck them up"—plant
- "I will give them a heart to know me"—new heart
- "That I am YHWH"—know YHWH
- "They shall be my people, and I will be their God"—covenant formula
- "They shall return unto me with their whole heart"—whole heart
- "As the bad figs... so will I make Zedekiah"—Zedekiah = bad
- "The residue of Jerusalem, that remain in this land"—remnant = bad
- "Them that dwell in the land of Egypt"—Egypt dwellers = bad
- "I will make them a horror among all the kingdoms"—horror
- "A reproach and a proverb, a taunt and a curse"—cursed
- "I will send the sword, the famine, and the pestilence"—judgment
- "Till they be consumed from off the land"—consumed

**Modern Equivalent:** Jeremiah 24 reverses expectations: those in exile are "good," those remaining are "bad." This counters the natural assumption that those left behind were blessed. "I will give them a heart to know me" (24:7) anticipates the new covenant's heart transformation (31:33; Ezekiel 36:26).

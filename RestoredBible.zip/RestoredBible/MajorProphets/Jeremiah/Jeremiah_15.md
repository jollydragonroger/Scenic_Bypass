# Jeremiah 15: Four Kinds of Destroyers

*From the Hebrew: וַיֹּאמֶר יְהוָה אֵלַי (Va-Yomer YHWH Elai) — And YHWH Said to Me*

---

## No Intercession Will Avail (15:1-9)

**15:1** Then said YHWH unto me: "Though Moses and Samuel stood before me, yet my mind could not be toward this people; cast them out of my sight, and let them go forth.

**15:2** "And it shall come to pass, when they say unto you: 'Whither shall we go forth?' then you shall tell them: Thus says YHWH: Such as are for death, to death; and such as are for the sword, to the sword; and such as are for the famine, to the famine; and such as are for captivity, to captivity.

**15:3** "And I will appoint over them four kinds," says YHWH: "the sword to slay, and the dogs to drag, and the fowls of the heaven, and the beasts of the earth, to devour and to destroy.

**15:4** "And I will cause them to be a horror to all the kingdoms of the earth, because of Manasseh the son of Hezekiah king of Judah, for that which he did in Jerusalem.

**15:5** "For who shall have pity upon you, O Jerusalem? Or who shall bemoan you? Or who shall turn aside to ask of your welfare?

**15:6** "You have forsaken me," says YHWH, "you are gone backward; therefore do I stretch out my hand against you, and destroy you; I am weary with repenting.

**15:7** "And I fan them with a fan in the gates of the land; I bereave them of children, I destroy my people, since they return not from their ways.

**15:8** "Their widows are increased to me above the sand of the seas; I bring upon them, against the mother of the young men, a spoiler at noonday; I cause anguish and terrors to fall upon her suddenly.

**15:9** "She that has borne seven languishes; she has given up her spirit; her sun is gone down while it was yet day; she is ashamed and confounded; and the residue of them will I deliver to the sword before their enemies," says YHWH.

---

## Jeremiah's Complaint (15:10-14)

**15:10** Woe is me, my mother, that you have borne me a man of strife and a man of contention to the whole earth! I have not lent, neither have men lent to me; yet every one of them curses me.

**15:11** YHWH said: "Verily I will strengthen you for good; verily I will cause the enemy to make supplication unto you in the time of evil and in the time of affliction.

**15:12** "Can iron break iron from the north, and brass?

**15:13** "Your substance and your treasures will I give for a spoil without price, and that for all your sins, even in all your borders.

**15:14** "And I will make you to pass with your enemies into a land which you know not; for a fire is kindled in my anger, which shall burn upon you."

---

## Jeremiah's Confession (15:15-21)

**15:15** O YHWH, you know; remember me, and think of me, and avenge me of my persecutors; take me not away because of your long-suffering; know that for your sake I have suffered reproach.

**15:16** Your words were found, and I did eat them; and your words were unto me a joy and the rejoicing of my heart; for your name was called on me, O YHWH, God of hosts.

**15:17** I sat not in the assembly of them that make merry, nor rejoiced; I sat alone because of your hand; for you have filled me with indignation.

**15:18** Why is my pain perpetual, and my wound incurable, so that it refuses to be healed? Will you indeed be unto me as a deceitful brook, as waters that fail?

**15:19** Therefore thus says YHWH: "If you return, then will I bring you back, that you may stand before me; and if you take forth the precious from the vile, you shall be as my mouth; they shall return unto you, but you shall not return unto them.

**15:20** "And I will make you unto this people a fortified brazen wall; and they shall fight against you, but they shall not prevail against you; for I am with you to save you and to deliver you," says YHWH.

**15:21** "And I will deliver you out of the hand of the wicked, and I will redeem you out of the hand of the terrible."

---

## Synthesis Notes

**Key Restorations:**

**No Intercession (15:1-4):**
**The Key Verse (15:1):**
"Though Moses and Samuel stood before me."

*Im-ya'amod Mosheh u-Shemu'el lefanai*—Moses and Samuel intercede.

"Yet my mind could not be toward this people."

*Ein nafshi el-ha-am ha-zeh*—mind not toward people.

"Cast them out of my sight."

*Shallach me-al-panai*—cast out.

"Let them go forth."

*Ve-yetze'u*—go forth.

**Moses/Samuel Reference:**
Moses (Exodus 32:11-14; Numbers 14:13-20) and Samuel (1 Samuel 7:9; 12:23) were famous intercessors—yet even their prayers wouldn't avail now.

**The Key Verse (15:2):**
"'Whither shall we go forth?'"

*Anah netze*—where go?

"Such as are for death, to death."

*Asher la-mavet la-mavet*—death for death.

"Such as are for the sword, to the sword."

*Va-asher la-cherev la-cherev*—sword for sword.

"Such as are for the famine, to the famine."

*Va-asher la-ra'av la-ra'av*—famine for famine.

"Such as are for captivity, to captivity."

*Va-asher la-shevi la-shevi*—captivity for captivity.

**The Key Verse (15:3):**
"I will appoint over them four kinds."

*U-faqadti aleihem arba mishpachot*—four kinds.

"The sword to slay."

*Et-ha-cherev la-harog*—sword to kill.

"The dogs to drag."

*Ve-et-ha-kelavim lishhov*—dogs to drag.

"The fowls of the heaven, and the beasts of the earth, to devour and to destroy."

*Ve-et-of ha-shamayim ve-et-behemmat ha-aretz le-ekhol u-le-hashchit*—birds and beasts.

**The Key Verse (15:4):**
"I will cause them to be a horror to all the kingdoms of the earth."

*U-netattim li-za'avah le-khol mamlekhot ha-aretz*—horror to kingdoms.

"Because of Manasseh the son of Hezekiah king of Judah."

*Bigelal Menasheh ven-Chizqiyyahu melekh Yehudah*—Manasseh's fault.

"For that which he did in Jerusalem."

*Al asher asah bi-Yerushalayim*—what he did. (See 2 Kings 21:1-18; 24:3-4)

**Judgment Described (15:5-9):**
"Who shall have pity upon you, O Jerusalem?"

*Mi yachmal alayikh Yerushalayim*—who'll pity?

"Who shall bemoan you?"

*U-mi yanud lakh*—who'll mourn?

"Who shall turn aside to ask of your welfare?"

*U-mi yasur lish'ol le-shalom lakh*—who'll inquire?

"You have forsaken me."

*Att natashtt oti*—you forsook me.

"You are gone backward."

*Achor telekhi*—gone backward.

"I stretch out my hand against you, and destroy you."

*Va-et yaddi alayikh va-ashchitekh*—hand against.

**The Key Verse (15:6):**
"I am weary with repenting."

*Nil'eiti hinnachem*—weary of relenting.

"I fan them with a fan in the gates of the land."

*Va-ezrem be-mizreh be-sha'arei ha-aretz*—fan them.

"I bereave them of children."

*Shikkaltti ibadti et-ammi*—bereave of children.

"I destroy my people, since they return not from their ways."

*Mi-darkhehem lo shavu*—didn't return.

"Their widows are increased to me above the sand of the seas."

*Atzmu-li almenotav me-chol yammim*—widows exceed sand.

"I bring upon them, against the mother of the young men, a spoiler at noonday."

*Hevetti lahem al-em bachur shoded ba-tzohorayim*—noonday spoiler.

"She that has borne seven languishes."

*Umlalah yoledet ha-shiv'ah*—mother of seven languishes.

"She has given up her spirit."

*Nafchah nafshah*—breathed out.

"Her sun is gone down while it was yet day."

*Ba shemshah be-od yomam*—sun set at day.

"She is ashamed and confounded."

*Boshahh ve-chafrah*—ashamed.

**Jeremiah's Complaint (15:10-14):**
**The Key Verse (15:10):**
"Woe is me, my mother, that you have borne me."

*Oy-li immi ki yelidttini*—woe for birth.

"A man of strife and a man of contention to the whole earth."

*Ish riv ve-ish madon le-khol-ha-aretz*—strife and contention man.

"I have not lent, neither have men lent to me."

*Lo nashiti ve-lo nashu-vi*—no lending.

"Yet every one of them curses me."

*Kullo meqallelni*—all curse me.

"Verily I will strengthen you for good."

*Im-lo sharittikha le-tov*—strengthen for good.

"I will cause the enemy to make supplication unto you."

*Im-lo hifga'ti vakh... et-ha-oyev*—enemy supplicates.

"Your substance and your treasures will I give for a spoil."

*Chelekhkha ve-otzrotekha la-baz etten*—treasures spoiled.

"For all your sins, even in all your borders."

*Be-khol-chattotekha u-ve-khol-gevulekha*—all sins.

"A fire is kindled in my anger."

*Ki-esh qaddechah be-appi*—fire kindled.

**Jeremiah's Confession (15:15-18):**
"O YHWH, you know."

*Attah yada'ta YHWH*—you know.

"Remember me, and think of me."

*Zokhreni u-foqdeni*—remember, visit.

"Avenge me of my persecutors."

*Ve-hinnaqem li me-rodfai*—avenge.

"Take me not away because of your long-suffering."

*Al-le-erekh appekha tiqqacheni*—don't take me.

"For your sake I have suffered reproach."

*Da ki-aley seti cherpah*—suffered reproach.

**The Key Verse (15:16):**
"Your words were found, and I did eat them."

*Nimtze'u devarekha va-okhlem*—found words, ate them.

"Your words were unto me a joy and the rejoicing of my heart."

*Va-yehi devarekha li le-sason u-le-simchat levavi*—words = joy.

"For your name was called on me."

*Ki-niqra shimkha alai*—name called on me.

"O YHWH, God of hosts."

*YHWH Elohei Tzeva'ot*—YHWH of hosts.

**The Key Verse (15:17):**
"I sat not in the assembly of them that make merry."

*Lo-yashavti ve-sod-mesacheqim*—didn't sit with merry.

"Nor rejoiced."

*Va-e'loz*—didn't rejoice.

"I sat alone because of your hand."

*Mippenei yadekha vadad yashavti*—sat alone.

"You have filled me with indignation."

*Ki-za'am mille'tani*—filled with indignation.

**The Key Verse (15:18):**
"Why is my pain perpetual?"

*Lammah hayah khevi netzach*—perpetual pain.

"My wound incurable."

*U-makkati anusah*—incurable wound.

"So that it refuses to be healed?"

*Me'anah here'afeh*—refuses healing.

"Will you indeed be unto me as a deceitful brook?"

*Hayo tihyeh li ke-mo akhzav*—deceitful brook?

"As waters that fail?"

*Mayim lo ne'emanu*—failing waters.

**YHWH's Response (15:19-21):**
**The Key Verse (15:19):**
"If you return, then will I bring you back."

*Im-tashuv va-ashivekha*—if return, bring back.

"That you may stand before me."

*Lefanai ta'amod*—stand before me.

"If you take forth the precious from the vile."

*Ve-im-totzi yaqar mi-zolel*—precious from vile.

"You shall be as my mouth."

*Ke-fi tihyeh*—be my mouth.

"They shall return unto you."

*Yashuvu hemmah elekha*—they return to you.

"But you shall not return unto them."

*Ve-attah lo-tashuv aleihem*—you don't return to them.

**The Key Verses (15:20-21):**
"I will make you unto this people a fortified brazen wall."

*U-netattikha la-am ha-zeh le-chomat nechoshet betzurah*—bronze wall.

"They shall fight against you."

*Ve-nilchamu elekha*—they fight.

"But they shall not prevail against you."

*Ve-lo-yukhlu lakh*—won't prevail.

"For I am with you to save you and to deliver you."

*Ki-ittekha ani le-hoshi'akha u-le-hatztzilekha*—with you to save.

"I will deliver you out of the hand of the wicked."

*Ve-hitztzaltikha mi-yad ra'im*—deliver from wicked.

"I will redeem you out of the hand of the terrible."

*U-feditikha mi-kaf aritzim*—redeem from terrible.

**Archetypal Layer:** Jeremiah 15 contains **"Though Moses and Samuel stood before me" (15:1)**, **four kinds of destroyers (15:3)**, **"Your words were found, and I did eat them" (15:16)**, and **"If you take forth the precious from the vile, you shall be as my mouth" (15:19)**.

**Ethical Inversion Applied:**
- "Though Moses and Samuel stood before me"—even great intercessors can't help
- "My mind could not be toward this people"—mind turned
- "Cast them out of my sight"—cast out
- "Such as are for death, to death; and such as are for the sword, to the sword"—fated destructions
- "I will appoint over them four kinds"—four destroyers
- "Because of Manasseh... for that which he did in Jerusalem"—Manasseh's sins
- "Who shall have pity upon you, O Jerusalem?"—no pity
- "You have forsaken me... you are gone backward"—forsaken, backward
- "I am weary with repenting"—weary of relenting
- "Their widows are increased to me above the sand of the seas"—many widows
- "Her sun is gone down while it was yet day"—premature darkness
- "Woe is me, my mother, that you have borne me"—birth lament
- "A man of strife and a man of contention"—Jeremiah's role
- "Yet every one of them curses me"—universally cursed
- "Your words were found, and I did eat them"—ate words
- "Your words were unto me a joy and the rejoicing of my heart"—joy from words
- "I sat alone because of your hand"—sat alone
- "You have filled me with indignation"—filled with indignation
- "Why is my pain perpetual, and my wound incurable?"—perpetual pain
- "Will you indeed be unto me as a deceitful brook?"—deceitful brook
- "If you return, then will I bring you back"—conditional restoration
- "If you take forth the precious from the vile, you shall be as my mouth"—precious from vile
- "They shall return unto you, but you shall not return unto them"—stand firm
- "I will make you unto this people a fortified brazen wall"—bronze wall
- "I am with you to save you and to deliver you"—with you

**Modern Equivalent:** Jeremiah 15:16's "Your words were found, and I did eat them" parallels Ezekiel 3:1-3 and Revelation 10:9-10. The "precious from the vile" (15:19) describes prophetic discernment. YHWH's challenge to Jeremiah shows that even prophets need course correction.

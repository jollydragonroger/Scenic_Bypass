# Jeremiah 33: The Branch of Righteousness

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֶל־יִרְמְיָהוּ (Va-Yehi Devar-YHWH El-Yirmeyahu) — And the Word of YHWH Came to Jeremiah*

---

## Call to Me and I Will Answer (33:1-9)

**33:1** Moreover the word of YHWH came unto Jeremiah the second time, while he was yet shut up in the court of the guard, saying:

**33:2** "Thus says YHWH the maker thereof, YHWH that formed it to establish it, YHWH is his name:

**33:3** "'Call unto me, and I will answer you, and will tell you great things, and hidden, which you know not.'

**33:4** "For thus says YHWH, the God of Israel, concerning the houses of this city, and concerning the houses of the kings of Judah, which are broken down for the mounds and for the ramparts;

**33:5** "They that come to fight with the Chaldeans, even to fill them with the dead bodies of men, whom I have slain in my anger and in my fury, and for all whose wickedness I have hid my face from this city:

**33:6** "Behold, I will bring it healing and cure, and I will cure them; and I will reveal unto them an abundance of peace and truth.

**33:7** "And I will cause the captivity of Judah and the captivity of Israel to return, and will build them, as at the first.

**33:8** "And I will cleanse them from all their iniquity, whereby they have sinned against me; and I will pardon all their iniquities, whereby they have sinned against me, and whereby they have transgressed against me.

**33:9** "And this city shall be to me for a name of joy, for a praise and for a glory, before all the nations of the earth, which shall hear all the good that I do unto them, and shall fear and tremble for all the good and for all the peace that I procure unto it."

---

## Restoration of Joy (33:10-13)

**33:10** Thus says YHWH: "Yet again there shall be heard in this place, whereof you say: 'It is waste, without man and without beast', even in the cities of Judah, and in the streets of Jerusalem, that are desolate, without man and without inhabitant and without beast,

**33:11** "The voice of joy and the voice of gladness, the voice of the bridegroom and the voice of the bride, the voice of them that say: 'Give thanks to YHWH of hosts, for YHWH is good, for his mercy endures forever', even of them that bring offerings of thanksgiving into the house of YHWH. For I will cause the captivity of the land to return as at the first," says YHWH.

**33:12** Thus says YHWH of hosts: "Yet again shall there be in this place, which is waste, without man and without beast, and in all the cities thereof, a habitation of shepherds causing their flocks to lie down.

**33:13** "In the cities of the hill-country, in the cities of the Lowland, and in the cities of the South, and in the land of Benjamin, and in the places about Jerusalem, and in the cities of Judah, shall the flocks again pass under the hands of him that counts them," says YHWH.

---

## The Righteous Branch (33:14-18)

**33:14** "Behold, the days come," says YHWH, "that I will perform that good word which I have spoken concerning the house of Israel and concerning the house of Judah.

**33:15** "In those days, and at that time, will I cause a Branch of righteousness to grow up unto David; and he shall execute justice and righteousness in the land.

**33:16** "In those days shall Judah be saved, and Jerusalem shall dwell safely; and this is the name whereby she shall be called: YHWH Tzidqenu—YHWH is our righteousness."

**33:17** For thus says YHWH: "David shall never want a man to sit upon the throne of the house of Israel;

**33:18** "Neither shall the priests the Levites want a man before me to offer burnt-offerings, and to burn meal-offerings, and to do sacrifice continually."

---

## The Covenant with David and Levi (33:19-26)

**33:19** And the word of YHWH came unto Jeremiah, saying:

**33:20** "Thus says YHWH: If you can break my covenant with the day, and my covenant with the night, so that there should not be day and night in their season;

**33:21** "Then may also my covenant be broken with David my servant, that he should not have a son to reign upon his throne; and with the Levites the priests, my ministers.

**33:22** "As the host of heaven cannot be numbered, neither the sand of the sea measured; so will I multiply the seed of David my servant, and the Levites that minister unto me."

**33:23** And the word of YHWH came to Jeremiah, saying:

**33:24** "Consider not what this people have spoken, saying: 'The two families which YHWH did choose, he has cast them off'? And they contemn my people, that they should be no more a nation before them.

**33:25** "Thus says YHWH: If my covenant be not with day and night, if I have not appointed the ordinances of heaven and earth;

**33:26** "Then will I also cast away the seed of Jacob, and of David my servant, so that I will not take of his seed to be rulers over the seed of Abraham, Isaac, and Jacob; for I will cause their captivity to return, and will have compassion on them."

---

## Synthesis Notes

**Key Restorations:**

**Setting (33:1):**
"The word of YHWH came unto Jeremiah the second time."

*Va-yehi devar-YHWH el-Yirmeyahu shenit*—second time.

"While he was yet shut up in the court of the guard."

*Ve-hu odenu atzur ba-chatzer ha-mattarah*—still imprisoned.

**Call and Answer (33:2-3):**
"YHWH the maker thereof."

*YHWH osah*—maker.

"YHWH that formed it to establish it."

*YHWH yotzerah la-hakhinah*—former, establisher.

"YHWH is his name."

*YHWH shemo*—his name.

**The Key Verse (33:3):**
"'Call unto me, and I will answer you.'"

*Qera elai ve-e'enekka*—call, I'll answer.

"'Will tell you great things, and hidden, which you know not.'"

*Ve-aggidah lekha gedolot u-vetzurot lo yeda'tam*—great hidden things.

**Healing Promise (33:4-9):**
"Concerning the houses of this city... which are broken down for the mounds."

*Al-battei ha-ir ha-zot ve-al-battei malkhei Yehudah ha-nittutzzim el-ha-solelot*—broken for siege.

"And for the ramparts."

*Ve-el-ha-charev*—for ramparts.

"They that come to fight with the Chaldeans."

*Ba'im le-hillachem et-ha-Kasdim*—fighting Chaldeans.

"Even to fill them with the dead bodies of men."

*U-le-mal'am et-pigrei ha-adam*—fill with corpses.

"Whom I have slain in my anger."

*Asher hikkeitim be-appi*—slain in anger.

"I have hid my face from this city."

*Histarti fanai me-ha-ir ha-zot*—hid face.

**The Key Verse (33:6):**
"I will bring it healing and cure."

*Hineni ma'aleh lah arukha u-marpe*—healing and cure.

"I will cure them."

*U-refa'tim*—cure them.

"I will reveal unto them an abundance of peace and truth."

*Ve-gileiti lahem ateret shalom ve-emet*—abundance peace/truth.

**The Key Verses (33:7-8):**
"I will cause the captivity of Judah and the captivity of Israel to return."

*Va-hashivoti et-shevut Yehudah ve-et shevut Yisra'el*—return captivity.

"Will build them, as at the first."

*U-venitim ka-ba-rishonah*—build as before.

"I will cleanse them from all their iniquity."

*Ve-tiharti otam mi-kol-avonam*—cleanse.

"Whereby they have sinned against me."

*Asher chat'u-li*—sinned.

"I will pardon all their iniquities."

*Ve-salachti le-khol-avonotam*—pardon.

"Whereby they have sinned against me, and whereby they have transgressed against me."

*Asher chat'u-li va-asher pash'u vi*—sinned, transgressed.

**The Key Verse (33:9):**
"This city shall be to me for a name of joy."

*Ve-hayetah li le-shem sason*—name of joy.

"For a praise and for a glory."

*Li-tehillah u-le-tif'eret*—praise and glory.

"Before all the nations of the earth."

*Le-khol goyei ha-aretz*—all nations.

"Which shall hear all the good that I do unto them."

*Asher yishme'u et-kol-ha-tovah asher anokhi oseh otam*—hear good.

"Shall fear and tremble."

*Ve-pachedu ve-ragzu*—fear and tremble.

"For all the good and for all the peace."

*Al kol-ha-tovah ve-al kol-ha-shalom*—good and peace.

**Joy Restored (33:10-13):**
"'It is waste, without man and without beast.'"

*Charev hu me-ein adam u-me-ein behemah*—waste claim.

"In the cities of Judah, and in the streets of Jerusalem."

*Be-arei Yehudah u-ve-chutzot Yerushalayim*—Judah/Jerusalem.

"That are desolate."

*Ha-neshammot*—desolate.

**The Key Verse (33:11):**
"The voice of joy and the voice of gladness."

*Qol sason ve-qol simchah*—joy sounds.

"The voice of the bridegroom and the voice of the bride."

*Qol chatan ve-qol kallah*—wedding sounds.

"The voice of them that say: 'Give thanks to YHWH of hosts.'"

*Qol omerim hodu et-YHWH Tzeva'ot*—thanksgiving.

"'For YHWH is good.'"

*Ki-tov YHWH*—YHWH is good.

"'For his mercy endures forever.'"

*Ki le-olam chasdo*—mercy forever. (Psalm 136 refrain)

"Them that bring offerings of thanksgiving into the house of YHWH."

*Mevi'im todah beit YHWH*—thank offerings.

"I will cause the captivity of the land to return as at the first."

*Ki-ashiv et-shevut ha-aretz ka-va-rishonah*—restore as before.

"Yet again shall there be... a habitation of shepherds."

*Od yihyeh... neveh ro'im*—shepherds' habitation.

"Causing their flocks to lie down."

*Marbitzim tzon*—flocks lie down.

"The flocks again pass under the hands of him that counts them."

*Ta'avornah ha-tzon al-yedei moneh*—counted flocks.

**The Branch (33:14-18):**
**The Key Verse (33:14):**
"I will perform that good word which I have spoken."

*Va-haqimoti et-ha-davar ha-tov asher dibbarti*—perform good word.

"Concerning the house of Israel and concerning the house of Judah."

*El-beit Yisra'el ve-al-beit Yehudah*—Israel and Judah.

**The Key Verse (33:15):**
"In those days, and at that time."

*Ba-yamim ha-hem u-va-et ha-hi*—those days, that time.

"I cause a Branch of righteousness to grow up unto David."

*Atzmiacḥ le-David tzemach tzedaqah*—righteous Branch.

"He shall execute justice and righteousness in the land."

*Ve-asah mishpat u-tzedaqah ba-aretz*—justice and righteousness.

**The Key Verse (33:16):**
"In those days shall Judah be saved."

*Ba-yamim ha-hem tivvasha Yehudah*—Judah saved.

"Jerusalem shall dwell safely."

*Vi-Yerushalayim tishkon la-vetach*—Jerusalem safe.

"This is the name whereby she shall be called."

*Ve-zeh asher-yiqra-lah*—name called.

"YHWH Tzidqenu—YHWH is our righteousness."

*YHWH Tzidqenu*—YHWH our Righteousness.

**Comparison with 23:5-6:**
In 23:5-6, the Branch is named "YHWH our Righteousness." Here (33:16), Jerusalem receives this name.

**The Key Verses (33:17-18):**
"David shall never want a man to sit upon the throne of the house of Israel."

*Lo-yikkareit le-David ish yoshev al-kisse beit-Yisra'el*—perpetual Davidic throne.

"Neither shall the priests the Levites want a man before me."

*Ve-la-kohanim ha-Leviyyim lo-yikkareit ish mi-lefanai*—perpetual Levitical priesthood.

"To offer burnt-offerings, and to burn meal-offerings, and to do sacrifice continually."

*Ma'aleh olah u-maqtir minchah ve-oseh zevach kol-ha-yamim*—continual sacrifice.

**Covenant with Day and Night (33:19-26):**
**The Key Verses (33:20-21):**
"If you can break my covenant with the day."

*Im-taferu et-beriti ha-yom*—break day covenant.

"And my covenant with the night."

*Ve-et-beriti ha-laylah*—night covenant.

"So that there should not be day and night in their season."

*Le-vilti heyot-yomam va-laylah be-ittam*—no day/night.

"Then may also my covenant be broken with David my servant."

*Gam-beriti tufar et-David avdi*—David covenant broken.

"That he should not have a son to reign upon his throne."

*Mi-heyot-lo ven molekh al-kis'o*—no son on throne.

"And with the Levites the priests, my ministers."

*Ve-et-ha-Leviyyim ha-kohanim mesharetai*—Levites.

**The Key Verse (33:22):**
"As the host of heaven cannot be numbered."

*Ka-asher lo-yissafer tzeva ha-shamayim*—countless stars.

"Neither the sand of the sea measured."

*Ve-lo yimmad chol ha-yam*—unmeasured sand.

"So will I multiply the seed of David my servant."

*Ken arbeh et-zera David avdi*—multiply David's seed.

"And the Levites that minister unto me."

*Ve-et-ha-Leviyyim mesharetei oti*—Levites.

**People's Doubt (33:24-26):**
"'The two families which YHWH did choose, he has cast them off.'"

*Shetei ha-mishpachot asher bachar YHWH bahem va-yim'asem*—cast off claim.

"They contemn my people."

*Va-yin'atzu et-ammi*—despise people.

"That they should be no more a nation before them."

*Mi-heyot-od goy lifneihem*—no more nation.

**The Key Verses (33:25-26):**
"If my covenant be not with day and night."

*Im-lo beriti yomam va-laylah*—day/night covenant.

"If I have not appointed the ordinances of heaven and earth."

*Chuqqot shamayim va-aretz lo-samti*—ordinances.

"Then will I also cast away the seed of Jacob, and of David my servant."

*Gam-zera Ya'aqov ve-David avdi em'as*—cast away.

"So that I will not take of his seed to be rulers."

*Mi-qachat mi-zar'o moshelim*—no rulers from seed.

"Over the seed of Abraham, Isaac, and Jacob."

*El-zera Avraham Yitzchaq ve-Ya'aqov*—patriarchs.

"For I will cause their captivity to return."

*Ki-ashiv et-shevutam*—return captivity.

"Will have compassion on them."

*Ve-richamtim*—compassion.

**Archetypal Layer:** Jeremiah 33 concludes the Book of Consolation with **"Call unto me, and I will answer you" (33:3)**, **"The voice of joy... the voice of the bridegroom and the voice of the bride" (33:11)**, **"I cause a Branch of righteousness to grow up unto David" (33:15)**, and **the covenant with day and night (33:20-21)**.

**Ethical Inversion Applied:**
- "While he was yet shut up in the court of the guard"—still imprisoned
- "YHWH the maker thereof, YHWH that formed it"—creator
- "'Call unto me, and I will answer you'"—call and answer
- "'Will tell you great things, and hidden'"—hidden things
- "The houses of this city... which are broken down for the mounds"—siege destruction
- "I have hid my face from this city"—hid face
- "I will bring it healing and cure"—healing
- "I will reveal unto them an abundance of peace and truth"—peace and truth
- "I will cause the captivity of Judah and... Israel to return"—return
- "Will build them, as at the first"—rebuild
- "I will cleanse them from all their iniquity"—cleanse
- "I will pardon all their iniquities"—pardon
- "This city shall be to me for a name of joy"—joy name
- "For a praise and for a glory"—praise and glory
- "They shall fear and tremble for all the good"—fear for good
- "'It is waste, without man and without beast'"—waste claim
- "The voice of joy and the voice of gladness"—joy restored
- "The voice of the bridegroom and the voice of the bride"—weddings restored
- "'Give thanks to YHWH of hosts, for YHWH is good'"—thanksgiving
- "'For his mercy endures forever'"—Psalm 136 refrain
- "A habitation of shepherds causing their flocks to lie down"—peaceful flocks
- "I will perform that good word which I have spoken"—perform
- "I cause a Branch of righteousness to grow up unto David"—Branch
- "He shall execute justice and righteousness"—justice
- "Judah be saved, and Jerusalem shall dwell safely"—saved, safe
- "YHWH Tzidqenu—YHWH is our righteousness"—Jerusalem's name
- "David shall never want a man to sit upon the throne"—perpetual throne
- "Neither shall the priests the Levites want a man"—perpetual priesthood
- "If you can break my covenant with the day, and... the night"—unbreakable
- "Then may also my covenant be broken with David"—conditional impossibility
- "As the host of heaven cannot be numbered"—countless
- "So will I multiply the seed of David"—multiply David
- "'The two families which YHWH did choose, he has cast them off'"—false claim
- "If my covenant be not with day and night"—cosmic covenant
- "Then will I also cast away the seed of Jacob"—impossible
- "I will cause their captivity to return, and will have compassion"—return, compassion

**Modern Equivalent:** Jeremiah 33 concludes the Book of Consolation (30-33). "Call unto me, and I will answer you" (33:3) is often quoted. The Branch (33:15) and "YHWH our Righteousness" (33:16) repeat the messianic theme from 23:5-6. The day/night covenant (33:20-21) guarantees Davidic and Levitical permanence.

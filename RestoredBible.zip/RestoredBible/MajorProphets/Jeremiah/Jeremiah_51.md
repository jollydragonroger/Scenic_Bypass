# Jeremiah 51: Oracle Against Babylon (Part 2)

*From the Hebrew: כֹּה אָמַר יְהוָה (Koh Amar YHWH) — Thus Says YHWH*

---

## YHWH Stirs Up Destroyers (51:1-10)

**51:1** Thus says YHWH: "Behold, I will raise up against Babylon, and against them that dwell in Leb-kamai, a destroying wind.

**51:2** "And I will send unto Babylon strangers, that shall fan her; and they shall empty her land; for in the day of trouble they shall be against her round about.

**51:3** "Let the archer bend his bow against her, and let him lift himself up against her in his coat of mail; and spare not her young men; destroy utterly all her host.

**51:4** "And they shall fall down slain in the land of the Chaldeans, and thrust through in her streets.

**51:5** "For Israel is not forsaken, nor Judah, of his God, of YHWH of hosts; though their land was filled with guilt against the Holy One of Israel.

**51:6** "Flee out of the midst of Babylon, and save every man his life; be not cut off in her iniquity; for it is the time of YHWH's vengeance; he will render unto her a recompense.

**51:7** "Babylon has been a golden cup in YHWH's hand, that made all the earth drunken; the nations have drunk of her wine; therefore the nations are mad.

**51:8** "Babylon is suddenly fallen and destroyed; wail for her; take balm for her pain, if so be she may be healed.

**51:9** "'We would have healed Babylon, but she is not healed; forsake her, and let us go every one into his own country; for her judgment reaches unto heaven, and is lifted up even to the skies.'

**51:10** "YHWH has brought forth our righteousness; come, and let us declare in Zion the work of YHWH our God."

---

## The Lord of All the Earth (51:11-19)

**51:11** "Make bright the arrows, fill the quivers; YHWH has stirred up the spirit of the kings of the Medes; for his purpose is against Babylon, to destroy it; for it is the vengeance of YHWH, the vengeance of his temple.

**51:12** "Set up a standard against the walls of Babylon, make the watch strong, set the watchmen, prepare the ambushes; for YHWH has both devised and done that which he spoke concerning the inhabitants of Babylon.

**51:13** "O you that dwell upon many waters, abundant in treasures, your end is come, the measure of your covetousness.

**51:14** "YHWH of hosts has sworn by himself: Surely I will fill you with men, as with the cankerworm; and they shall lift up a shout against you.

**51:15** "He that made the earth by his power, that established the world by his wisdom, and by his understanding stretched out the heavens:

**51:16** "When he utters his voice, there is a tumult of waters in the heavens, and he causes the vapors to ascend from the ends of the earth; he makes lightnings for the rain, and brings forth the wind out of his treasuries.

**51:17** "Every man is become brutish, without knowledge; every goldsmith is put to shame by the graven image, for his molten image is falsehood, and there is no breath in them.

**51:18** "They are vanity, a work of delusion; in the time of their visitation they shall perish.

**51:19** "The portion of Jacob is not like these; for he is the former of all things; and Israel is the tribe of his inheritance; YHWH of hosts is his name."

---

## YHWH's War Club (51:20-26)

**51:20** "You are my battle-axe and weapons of war; and with you will I shatter nations; and with you will I destroy kingdoms;

**51:21** "And with you will I shatter the horse and his rider; and with you will I shatter the chariot and him that rides therein;

**51:22** "And with you will I shatter man and woman; and with you will I shatter the old man and the youth; and with you will I shatter the young man and the maid;

**51:23** "And with you will I shatter the shepherd and his flock; and with you will I shatter the husbandman and his yoke of oxen; and with you will I shatter governors and deputies.

**51:24** "And I will render unto Babylon and to all the inhabitants of Chaldea all their evil that they have done in Zion in your sight," says YHWH.

**51:25** "Behold, I am against you, O destroying mountain," says YHWH, "which destroys all the earth; and I will stretch out my hand upon you, and roll you down from the rocks, and will make you a burnt mountain.

**51:26** "And they shall not take of you a stone for a corner, nor a stone for foundations; but you shall be desolate forever," says YHWH.

---

## The Attack Continues (51:27-44)

**51:27** "Set up a standard in the land, blow the horn among the nations, prepare the nations against her, call together against her the kingdoms of Ararat, Minni, and Ashkenaz; appoint a marshal against her; cause the horses to come up as the rough cankerworm.

**51:28** "Prepare against her the nations, the kings of the Medes, the governors thereof, and all the deputies thereof, and all the land of his dominion.

**51:29** "And the land trembles and is in pain; for the purposes of YHWH against Babylon do stand, to make the land of Babylon a desolation, without inhabitant.

**51:30** "The mighty men of Babylon have forborne to fight, they remain in their strongholds; their might has failed, they are become as women; her dwelling-places are set on fire; her bars are broken.

**51:31** "One post runs to meet another, and one messenger to meet another, to tell the king of Babylon that his city is taken on every quarter;

**51:32** "And the fords are seized, and the reeds they have burned with fire, and the men of war are affrighted.

**51:33** "For thus says YHWH of hosts, the God of Israel: The daughter of Babylon is like a threshing-floor at the time when it is trodden; yet a little while, and the time of harvest shall come for her.

**51:34** "'Nebuchadrezzar the king of Babylon has devoured me, he has crushed me, he has set me down as an empty vessel, he has swallowed me up like a dragon, he has filled his maw with my delicacies; he has washed me out.'

**51:35** "'The violence done to me and to my flesh be upon Babylon,' shall the inhabitant of Zion say; and: 'My blood be upon the inhabitants of Chaldea,' shall Jerusalem say.

**51:36** "Therefore thus says YHWH: Behold, I will plead your cause, and take vengeance for you; and I will dry up her sea, and make her fountain dry.

**51:37** "And Babylon shall become heaps, a dwelling-place for jackals, an astonishment, and a hissing, without inhabitant.

**51:38** "They shall roar together like young lions; they shall growl as lions' whelps.

**51:39** "When they are heated, I will make their feast, and I will make them drunken, that they may rejoice, and sleep a perpetual sleep, and not wake," says YHWH.

**51:40** "I will bring them down like lambs to the slaughter, like rams with he-goats.

**51:41** "How is Sheshach taken! And the praise of the whole earth seized! How is Babylon become an astonishment among the nations!

**51:42** "The sea is come up upon Babylon; she is covered with the multitude of the waves thereof.

**51:43** "Her cities are become a desolation, a dry land, and a desert, a land wherein no man dwells, neither does any son of man pass thereby.

**51:44** "And I will punish Bel in Babylon, and I will bring forth out of his mouth that which he has swallowed up; and the nations shall not flow together any more unto him; yea, the wall of Babylon shall fall."

---

## Call to Flee (51:45-53)

**51:45** "My people, go out of the midst of her, and save yourselves every man from the fierce anger of YHWH.

**51:46** "And let not your heart faint, neither fear for the report that shall be heard in the land; for a report shall come one year, and after that in another year a report, and violence in the land, ruler against ruler.

**51:47** "Therefore, behold, the days come, that I will do judgment upon the graven images of Babylon; and her whole land shall be ashamed; and all her slain shall fall in the midst of her.

**51:48** "Then the heaven and the earth, and all that is therein, shall sing for joy over Babylon; for the spoilers shall come unto her from the north," says YHWH.

**51:49** "As Babylon has caused the slain of Israel to fall, so at Babylon shall fall the slain of all the land.

**51:50** "You that have escaped the sword, go, stand not still; remember YHWH from afar, and let Jerusalem come into your mind.

**51:51** "'We are ashamed, because we have heard reproach; confusion has covered our faces; for strangers are come into the sanctuaries of YHWH's house.'

**51:52** "Wherefore, behold, the days come," says YHWH, "that I will do judgment upon her graven images; and through all her land the wounded shall groan.

**51:53** "Though Babylon should mount up to heaven, and though she should fortify the height of her strength, yet from me shall spoilers come unto her," says YHWH.

---

## Babylon's Final Destruction (51:54-58)

**51:54** "Hark! A cry from Babylon, and great destruction from the land of the Chaldeans!

**51:55** "For YHWH spoils Babylon, and destroys out of her the great voice; and their waves roar like many waters, the noise of their voice is uttered;

**51:56** "For the spoiler is come upon her, even upon Babylon, and her mighty men are taken, their bows are shattered; for YHWH is a God of recompenses, he will surely requite.

**51:57** "And I will make drunk her princes and her wise men, her governors and her deputies, and her mighty men; and they shall sleep a perpetual sleep, and not wake," says the King, whose name is YHWH of hosts.

**51:58** Thus says YHWH of hosts: "The broad walls of Babylon shall be utterly overthrown, and her high gates shall be burned with fire; and the peoples shall labor for vanity, and the nations for the fire; and they shall be weary."

---

## Seraiah's Mission (51:59-64)

**51:59** The word which Jeremiah the prophet commanded Seraiah the son of Neriah, the son of Mahseiah, when he went with Zedekiah the king of Judah to Babylon in the fourth year of his reign. Now Seraiah was quartermaster.

**51:60** And Jeremiah wrote in one book all the evil that should come upon Babylon, even all these words that are written concerning Babylon.

**51:61** And Jeremiah said to Seraiah: "When you come to Babylon, then see that you read all these words,

**51:62** "And say: 'O YHWH, you have spoken concerning this place, to cut it off, that none shall dwell therein, neither man nor beast, but that it shall be desolate forever.'

**51:63** "And it shall be, when you have made an end of reading this book, that you shall bind a stone to it, and cast it into the midst of the Euphrates;

**51:64** "And you shall say: 'Thus shall Babylon sink, and shall not rise again because of the evil that I will bring upon her; and they shall be weary.'" Thus far are the words of Jeremiah.

---

## Synthesis Notes

**Key Restorations:**

**Destroyers (51:1-10):**
"'I will raise up against Babylon... a destroying wind.'"

*Hineni me'ir al-Bavel... ruach mashchit*—destroying wind.

"'Against them that dwell in Leb-kamai.'"

*Ve-el-yoshevei Lev-Qamai*—Leb-kamai.

**Leb-kamai:**
Atbash cipher for "Chaldeans" (כשדים becomes לב קמי).

"'I will send unto Babylon strangers, that shall fan her.'"

*Ve-shilachti le-Bavel zarim ve-zeruha*—winnowers.

**The Key Verse (51:5):**
"'Israel is not forsaken, nor Judah, of his God, of YHWH of hosts.'"

*Ki lo-alman Yisra'el vi-Yhudah me-Elohav me-YHWH Tzeva'ot*—not forsaken.

"'Though their land was filled with guilt against the Holy One of Israel.'"

*Ki artzam male'ah asham mi-Qedosh Yisra'el*—despite guilt.

**The Key Verse (51:6):**
"'Flee out of the midst of Babylon.'"

*Nusu mi-tokh Bavel*—flee.

"'Save every man his life.'"

*U-malletu ish nafsho*—save life.

"'It is the time of YHWH's vengeance.'"

*Ki et neqamah hi la-YHWH*—vengeance time.

**The Key Verse (51:7):**
"'Babylon has been a golden cup in YHWH's hand.'"

*Kos-zahav Bavel be-yad YHWH*—golden cup.

"'That made all the earth drunken.'"

*Meshakkeret kol-ha-aretz*—earth drunken.

"'The nations have drunk of her wine.'"

*Mi-yeinah shatu goyim*—nations drank.

"'Therefore the nations are mad.'"

*Al-ken yithollelu goyim*—nations mad.

**The Key Verses (51:8-10):**
"'Babylon is suddenly fallen and destroyed.'"

*Pit'om nafelah Bavel va-tishaver*—suddenly fallen.

"'Wail for her.'"

*Heililu alekha*—wail.

"'Take balm for her pain, if so be she may be healed.'"

*Qechu tzori le-makh'ovah ulai terafei*—balm.

"''We would have healed Babylon, but she is not healed.''"

*Ripinu et-Bavel ve-lo nirpa'tah*—tried to heal.

"'Her judgment reaches unto heaven.'"

*Ki-naga el-ha-shamayim mishpatah*—reaches heaven.

"'YHWH has brought forth our righteousness.'"

*Hotzi YHWH et-tzidqotenu*—brought righteousness.

**The Medes (51:11-14):**
"'YHWH has stirred up the spirit of the kings of the Medes.'"

*He'ir YHWH et-ruach malkhei Madai*—Medes stirred.

"'His purpose is against Babylon, to destroy it.'"

*Ki-al-Bavel mezimmato le-hashchitah*—destroy Babylon.

"'It is the vengeance of YHWH, the vengeance of his temple.'"

*Ki-niqmat YHWH hi niqmat hekhalo*—temple vengeance.

**The Key Verse (51:13):**
"'O you that dwell upon many waters, abundant in treasures.'"

*Shokhanet al-mayim rabbim rabbat otzarot*—many waters.

"'Your end is come.'"

*Ba qitztzekh*—end come.

"'The measure of your covetousness.'"

*Ammat bitz'ekh*—measure of greed.

**Creator Hymn (51:15-19):**
**The Key Verses (51:15-16):**
"'He that made the earth by his power.'"

*Oseh eretz be-khocho*—made earth.

"'That established the world by his wisdom.'"

*Mekhin tevel be-chokhmato*—established world.

"'By his understanding stretched out the heavens.'"

*U-vi-tvunato natah shamayim*—stretched heavens.

(Repeats 10:12-16)

**The Key Verse (51:19):**
"'The portion of Jacob is not like these.'"

*Lo khe-elleh cheleq Ya'aqov*—not like these.

"'He is the former of all things.'"

*Ki-yotzer ha-kol hu*—former of all.

"'Israel is the tribe of his inheritance.'"

*Ve-shevet nachalato*—inheritance tribe.

"'YHWH of hosts is his name.'"

*YHWH Tzeva'ot shemo*—YHWH's name.

**War Club (51:20-26):**
**The Key Verses (51:20-23):**
"'You are my battle-axe and weapons of war.'"

*Mappetz attah li kelei milchamah*—battle-axe.

"'With you will I shatter nations.'"

*Ve-nipatztti bekha goyim*—shatter nations.

"'With you will I destroy kingdoms.'"

*Ve-hishshatti bekha mamlakhot*—destroy kingdoms.

"'With you will I shatter the horse and his rider.'"

*Ve-nipatztti bekha sus ve-rokhvo*—shatter horse.

"'With you will I shatter the chariot.'"

*Ve-nipatztti bekha rekhev ve-rokhvo*—shatter chariot.

"'With you will I shatter man and woman.'"

*Ve-nipatztti bekha ish ve-ishah*—shatter all.

**Addressed to:**
Either Babylon (past use) or the Medes (future use) as YHWH's instrument.

**The Key Verses (51:25-26):**
"'I am against you, O destroying mountain.'"

*Hineni elekha har ha-mashchit*—destroying mountain.

"'Which destroys all the earth.'"

*Ha-mashchit et-kol-ha-aretz*—destroys earth.

"'I will... roll you down from the rocks.'"

*Ve-gilgaltikha min-ha-sela'im*—roll down.

"'Will make you a burnt mountain.'"

*U-netattikha le-har serefah*—burnt mountain.

"'They shall not take of you a stone for a corner, nor a stone for foundations.'"

*Ve-lo-yiqchu mimmekha even le-pinnah ve-even le-mosadot*—no building stone.

"'You shall be desolate forever.'"

*Ki-shimmot olam tihyeh*—forever desolate.

**Coalition (51:27-33):**
"'Call together against her the kingdoms of Ararat, Minni, and Ashkenaz.'"

*Qir'u alekha mamlekh Ararat Minni ve-Ashkenaz*—northern kingdoms.

**Northern Nations:**
Ararat (Urartu), Minni (Manneans), Ashkenaz (Scythians)—all north of Babylon.

"'Prepare against her the nations, the kings of the Medes.'"

*Qaddeshu alekha goyim et-malkhei Madai*—Medes.

"'One post runs to meet another.'"

*Ratz liqrat-ratz yarutz*—messenger to messenger.

"'To tell the king of Babylon that his city is taken on every quarter.'"

*Le-haggid le-melekh Bavel ki-nilkedah iro mi-qatzeh*—city taken.

"'The daughter of Babylon is like a threshing-floor at the time when it is trodden.'"

*Ki koh amar YHWH Tzeva'ot... bat-Bavel ke-goren et hidrikkkah*—threshing floor.

**Zion's Cry (51:34-44):**
**The Key Verses (51:34-35):**
"''Nebuchadrezzar the king of Babylon has devoured me.''"

*Akhalani hamamani Nevukhadre'zzar melekh Bavel*—devoured.

"''He has crushed me.''"

*Hitztzigani*—crushed.

"''He has set me down as an empty vessel.''"

*Hittziggani keli riq*—empty vessel.

"''He has swallowed me up like a dragon.''"

*Bela'ani ke-tannin*—like dragon.

"''He has filled his maw with my delicacies.''"

*Milla kereso me-adanai*—filled belly.

"''The violence done to me and to my flesh be upon Babylon.''"

*Chamasi u-she'eri al-Bavel*—violence on Babylon.

"''My blood be upon the inhabitants of Chaldea.''"

*Ve-dami el-yoshevei Khasdim*—blood on Chaldeans.

**The Key Verse (51:36):**
"'I will plead your cause, and take vengeance for you.'"

*Hineni rav et-rivekh ve-niqamti et-niqmatekh*—plead, avenge.

"'I will dry up her sea, and make her fountain dry.'"

*Ve-hacharavti et-yammah ve-hovalti et-meqorah*—dry up.

**The Key Verses (51:41-44):**
"'How is Sheshach taken!'"

*Eikh nilkedah Sheshakh*—Sheshach taken.

**Sheshach:**
Atbash cipher for Babylon (בבל becomes ששך).

"'The praise of the whole earth seized!'"

*Va-titttafes tehillat kol-ha-aretz*—seized.

"'The sea is come up upon Babylon.'"

*Alah al-Bavel ha-yam*—sea upon Babylon.

"'I will punish Bel in Babylon.'"

*U-faqadti al-Bel be-Bavel*—punish Bel.

"'I will bring forth out of his mouth that which he has swallowed up.'"

*Ve-hotzeti et-bila'o mi-piv*—disgorge.

**Call to Flee (51:45-53):**
"'My people, go out of the midst of her.'"

*Tze'u mi-tokhah ammi*—go out.

"'Save yourselves every man from the fierce anger of YHWH.'"

*U-malletu ish et-nafsho me-charon af-YHWH*—save from anger.

**The Key Verse (51:48):**
"'The heaven and the earth, and all that is therein, shall sing for joy over Babylon.'"

*Ve-rinenu al-Bavel shamayim va-aretz ve-khol asher bahem*—heaven/earth sing.

**The Key Verse (51:50):**
"'You that have escaped the sword, go, stand not still.'"

*Peletim me-cherev lekhu al-ta'amodu*—go, don't stop.

"'Remember YHWH from afar, and let Jerusalem come into your mind.'"

*Zikhru me-rachoq et-YHWH vi-Yerushalayim ta'aleh al-levavkhem*—remember.

**The Key Verse (51:53):**
"'Though Babylon should mount up to heaven.'"

*Ki-ta'aleh Bavel ha-shamayim*—mount to heaven.

"'Though she should fortify the height of her strength.'"

*Ve-khi vatzzer merom uzzah*—fortify.

"'Yet from me shall spoilers come unto her.'"

*Me-itti yavo'u lah shodedim*—spoilers come.

**Final Destruction (51:54-58):**
"'YHWH is a God of recompenses, he will surely requite.'"

*Ki El gemulot YHWH shalleim yeshallem*—God of recompense.

"'I will make drunk her princes... they shall sleep a perpetual sleep.'"

*Ve-hishkarti sareyha... ve-yashenu shenat-olam*—perpetual sleep.

**The Key Verse (51:58):**
"'The broad walls of Babylon shall be utterly overthrown.'"

*Chomat Bavel ha-rechavah ar'er tit'ar'ar*—walls overthrown.

"'Her high gates shall be burned with fire.'"

*U-she'areyha ha-gevohim ba-esh yitzzattu*—gates burned.

"'The peoples shall labor for vanity, and the nations for the fire.'"

*Ve-yag'u ammim be-dei-riq u-le'ummim be-dei-esh ve-ya'efu*—labor in vain.

**Seraiah's Mission (51:59-64):**
"Seraiah the son of Neriah, the son of Mahseiah."

*Serayah ben-Neriyyah ben-Machseyah*—Seraiah.

**Baruch's Brother:**
Seraiah was Baruch's brother (32:12).

"When he went with Zedekiah the king of Judah to Babylon in the fourth year."

*Be-lekhto et-Tzidqiyyahu melekh-Yehudah Bavel bi-shnat ha-revi'it le-molkho*—4th year.

"Seraiah was quartermaster."

*Ve-Serayah sar menuchah*—quartermaster.

"Jeremiah wrote in one book all the evil that should come upon Babylon."

*Va-yikhtov Yirmeyahu et kol-ha-ra'ah asher-tavo el-Bavel*—wrote evil.

**The Key Verses (51:61-64):**
"'When you come to Babylon, then see that you read all these words.'"

*Ve-hayah ke-vo'akha Bavel ve-ra'ita ve-qarata et kol-ha-devarim ha-elleh*—read.

"''O YHWH, you have spoken concerning this place, to cut it off.''"

*YHWH attah dibbarta el-ha-maqom ha-zeh le-hakhrito*—cut off.

"'You shall bind a stone to it, and cast it into the midst of the Euphrates.'"

*Ve-qasharta alav even ve-hishlakhto el-tokh Perat*—sink in Euphrates.

"''Thus shall Babylon sink, and shall not rise again.''"

*Kakhah tishqa Bavel ve-lo-taqum*—sink, not rise.

"Thus far are the words of Jeremiah."

*Ad-hennah divrei Yirmeyahu*—Jeremiah's words end.

**Archetypal Layer:** Jeremiah 51 concludes the **Babylon oracle** with **"Babylon has been a golden cup in YHWH's hand" (51:7)**, **the Creator hymn (51:15-19)**, **"You are my battle-axe" (51:20)**, **Zion's cry against Babylon (51:34-35)**, and **Seraiah's symbolic sinking of the scroll (51:59-64)**.

**Ethical Inversion Applied:**
- "'I will raise up against Babylon... a destroying wind'"—destroying wind
- "'Against them that dwell in Leb-kamai'"—Atbash for Chaldeans
- "'Israel is not forsaken, nor Judah, of his God'"—not forsaken
- "'Flee out of the midst of Babylon'"—flee
- "'It is the time of YHWH's vengeance'"—vengeance time
- "'Babylon has been a golden cup in YHWH's hand'"—golden cup
- "'That made all the earth drunken'"—nations drunk
- "'Babylon is suddenly fallen and destroyed'"—suddenly fallen
- "''We would have healed Babylon, but she is not healed''"—incurable
- "'YHWH has brought forth our righteousness'"—vindication
- "'YHWH has stirred up the spirit of the kings of the Medes'"—Medes stirred
- "'It is the vengeance of YHWH, the vengeance of his temple'"—temple vengeance
- "'O you that dwell upon many waters, abundant in treasures'"—many waters
- "'Your end is come'"—end come
- "'He that made the earth by his power'"—Creator
- "'The portion of Jacob is not like these'"—Jacob's portion
- "'You are my battle-axe and weapons of war'"—battle-axe
- "'With you will I shatter nations... kingdoms'"—shatter
- "'I am against you, O destroying mountain'"—destroying mountain
- "'You shall be desolate forever'"—forever desolate
- "'The kingdoms of Ararat, Minni, and Ashkenaz'"—northern coalition
- "'The kings of the Medes'"—Medes
- "'One post runs to meet another'"—messengers
- "''Nebuchadrezzar... has devoured me, he has crushed me''"—Zion's cry
- "''The violence done to me... be upon Babylon''"—justice
- "'I will plead your cause, and take vengeance for you'"—plead, avenge
- "'How is Sheshach taken!'"—Atbash for Babylon
- "'I will punish Bel in Babylon'"—punish Bel
- "'My people, go out of the midst of her'"—go out
- "'The heaven and the earth... shall sing for joy over Babylon'"—heaven/earth sing
- "'Remember YHWH from afar, and let Jerusalem come into your mind'"—remember
- "'Though Babylon should mount up to heaven'"—even if
- "'Yet from me shall spoilers come unto her'"—spoilers come
- "'YHWH is a God of recompenses'"—recompense
- "'The broad walls of Babylon shall be utterly overthrown'"—walls fall
- "Seraiah the son of Neriah"—Baruch's brother
- "'When you come to Babylon... read all these words'"—read
- "'You shall bind a stone to it, and cast it into... the Euphrates'"—sink
- "''Thus shall Babylon sink, and shall not rise again''"—sink, not rise
- "Thus far are the words of Jeremiah"—Jeremiah ends

**Modern Equivalent:** Jeremiah 51 concludes the Babylon oracle. The symbolic act of sinking the scroll (51:63-64) visualized Babylon's fate. "Thus far are the words of Jeremiah" (51:64) marks the end of Jeremiah's words—chapter 52 is an historical appendix.

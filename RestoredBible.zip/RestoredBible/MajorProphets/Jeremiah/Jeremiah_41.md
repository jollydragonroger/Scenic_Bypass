# Jeremiah 41: The Assassination of Gedaliah

*From the Hebrew: וַיְהִי בַּחֹדֶשׁ הַשְּׁבִיעִי (Va-Yehi Ba-Chodesh Ha-Shevi'i) — And It Came to Pass in the Seventh Month*

---

## Gedaliah Assassinated (41:1-3)

**41:1** Now it came to pass in the seventh month, that Ishmael the son of Nethaniah, the son of Elishama, of the seed royal, came, and ten men with him, unto Gedaliah the son of Ahikam to Mizpah; and there they did eat bread together in Mizpah.

**41:2** Then arose Ishmael the son of Nethaniah, and the ten men that were with him, and smote Gedaliah the son of Ahikam the son of Shaphan with the sword, and slew him, whom the king of Babylon had made governor over the land.

**41:3** Ishmael also slew all the Jews that were with him, even with Gedaliah, at Mizpah, and the Chaldeans that were found there, the men of war.

---

## The Pilgrims Massacred (41:4-9)

**41:4** And it came to pass the second day after he had slain Gedaliah, and no man knew it,

**41:5** That there came men from Shechem, from Shiloh, and from Samaria, eighty men, having their beards shaven and their clothes rent, and having cut themselves, with meal-offerings and frankincense in their hand, to bring them to the house of YHWH.

**41:6** And Ishmael the son of Nethaniah went forth from Mizpah to meet them, weeping all along as he went; and it came to pass, as he met them, he said unto them: "Come to Gedaliah the son of Ahikam."

**41:7** And it was so, when they came into the midst of the city, that Ishmael the son of Nethaniah slew them, and cast them into the midst of the pit, he, and the men that were with him.

**41:8** But ten men were found among them that said unto Ishmael: "Slay us not; for we have stores hidden in the field, of wheat, and of barley, and of oil, and of honey." So he forbare, and slew them not among their brethren.

**41:9** Now the pit wherein Ishmael cast all the dead bodies of the men whom he had slain by the side of Gedaliah—the same was it which Asa the king had made for fear of Baasha king of Israel—Ishmael the son of Nethaniah filled it with them that were slain.

---

## The Captives Taken (41:10-15)

**41:10** Then Ishmael carried away captive all the residue of the people that were in Mizpah, even the king's daughters, and all the people that remained in Mizpah, whom Nebuzaradan the captain of the guard had committed to Gedaliah the son of Ahikam; Ishmael the son of Nethaniah carried them away captive, and departed to go over to the children of Ammon.

**41:11** But when Johanan the son of Kareah, and all the captains of the forces that were with him, heard of all the evil that Ishmael the son of Nethaniah had done,

**41:12** Then they took all the men, and went to fight with Ishmael the son of Nethaniah, and found him by the great waters that are in Gibeon.

**41:13** Now it came to pass, that when all the people that were with Ishmael saw Johanan the son of Kareah, and all the captains of the forces that were with him, then they were glad.

**41:14** So all the people that Ishmael had carried away captive from Mizpah cast about and returned, and went unto Johanan the son of Kareah.

**41:15** But Ishmael the son of Nethaniah escaped from Johanan with eight men, and went to the children of Ammon.

---

## Johanan Gathers the Remnant (41:16-18)

**41:16** Then took Johanan the son of Kareah, and all the captains of the forces that were with him, all the remnant of the people whom he had recovered from Ishmael the son of Nethaniah, from Mizpah, after that he had slain Gedaliah the son of Ahikam, the mighty men of war, and the women, and the children, and the officers, whom he had brought back from Gibeon;

**41:17** And they departed, and dwelt in Geruth Chimham, which is by Beth-lehem, to go to enter into Egypt,

**41:18** Because of the Chaldeans; for they were afraid of them, because Ishmael the son of Nethaniah had slain Gedaliah the son of Ahikam, whom the king of Babylon made governor in the land.

---

## Synthesis Notes

**Key Restorations:**

**Assassination (41:1-3):**
"In the seventh month."

*Ba-chodesh ha-shevi'i*—Tishri (September/October 586 BCE).

"Ishmael the son of Nethaniah, the son of Elishama."

*Yishma'el ben-Netanyahu ben-Elishama*—Ishmael.

"Of the seed royal."

*Mi-zera ha-melukhah*—royal family.

**Royal Motivation:**
Ishmael was of Davidic descent—may have resented Gedaliah's non-royal appointment.

"Came, and ten men with him, unto Gedaliah... to Mizpah."

*Ba hu va-asarah anashim itto el-Gedalyahu... ha-Mitzpah*—came.

"There they did eat bread together in Mizpah."

*Va-yokhlu sham lechem yachdav ba-Mitzpah*—ate together.

**Hospitality Violation:**
Eating together established a covenant of peace—Ishmael violated sacred hospitality.

**The Key Verse (41:2):**
"Then arose Ishmael... and smote Gedaliah... with the sword."

*Va-yaqam Yishma'el ben-Netanyahu... va-yakku et-Gedalyahu... ba-cherev*—killed.

"Slew him, whom the king of Babylon had made governor over the land."

*Va-yamet oto asher-hifqid melekh-Bavel ba-aretz*—governor killed.

**The Key Verse (41:3):**
"Ishmael also slew all the Jews that were with him."

*Ve-et kol-ha-Yehudim asher-hayu itto et-Gedalyahu ba-Mitzpah*—killed Jews.

"And the Chaldeans that were found there, the men of war."

*Ve-et-ha-Kasdim asher nimtze'u sham et-anshei ha-milchamah*—killed Babylonian soldiers.

**Pilgrim Massacre (41:4-9):**
"The second day after he had slain Gedaliah."

*Va-yehi ba-yom ha-sheni le-hamit et-Gedalyahu*—second day.

"No man knew it."

*Ve-ish lo yada*—secret.

"There came men from Shechem, from Shiloh, and from Samaria."

*Va-yavo'u anashim mi-Shekhem mi-Shilo u-mi-Shomeron*—northern pilgrims.

"Eighty men."

*Shemonim ish*—80 men.

"Having their beards shaven and their clothes rent."

*Megullchei zaqan u-qeru'ei begadim*—mourning signs.

"Having cut themselves."

*U-mitgodedim*—self-laceration.

"With meal-offerings and frankincense in their hand."

*U-minchah u-levonah be-yadam*—offerings.

"To bring them to the house of YHWH."

*Le-havi beit YHWH*—to temple (now destroyed).

**Northern Pilgrims:**
Even from the former northern kingdom, pilgrims came to the destroyed temple site to mourn.

**The Key Verses (41:6-7):**
"Ishmael... went forth from Mizpah to meet them."

*Va-yetze Yishma'el ben-Netanyahu liqratam min-ha-Mitzpah*—went out.

"Weeping all along as he went."

*Halokh u-vokheh*—feigning tears.

"'Come to Gedaliah the son of Ahikam.'"

*Bo'u el-Gedalyahu ben-Achiqam*—invitation.

"When they came into the midst of the city."

*Va-yehi ke-vo'am el-tokh ha-ir*—when inside.

"Ishmael... slew them, and cast them into the midst of the pit."

*Va-yishchatem Yishma'el... el-tokh ha-bor*—slew, threw into pit.

"He, and the men that were with him."

*Hu ve-ha-anashim asher-itto*—he and men.

**The Key Verse (41:8):**
"'Slay us not; for we have stores hidden in the field.'"

*Al-temitenu ki-yesh-lanu matmonim ba-sadeh*—hidden stores.

"'Of wheat, and of barley, and of oil, and of honey.'"

*Chittim u-se'orim ve-shemen u-devash*—supplies.

"So he forbare, and slew them not among their brethren."

*Va-yechdal ve-lo hemitam be-tokh acheihem*—spared 10.

**The Key Verse (41:9):**
"The pit wherein Ishmael cast all the dead bodies."

*Ve-ha-bor asher-hishlikh sham Yishma'el et kol-pigrei ha-anashim*—pit.

"By the side of Gedaliah."

*Be-yad Gedalyahu*—beside Gedaliah.

"The same was it which Asa the king had made for fear of Baasha king of Israel."

*Hu asher asah ha-melekh Asa mippenei Ba'sha melekh-Yisra'el*—Asa's cistern (1 Kings 15:22).

"Ishmael... filled it with them that were slain."

*Oto mille Yishma'el... challalim*—filled with corpses.

**Captives Taken (41:10-15):**
"Ishmael carried away captive all the residue of the people."

*Va-yishbe Yishma'el et-kol-she'erit ha-am*—captives taken.

"Even the king's daughters."

*Et-benot ha-melekh*—king's daughters.

"All the people that remained in Mizpah."

*Ve-et-kol-ha-am ha-nish'arim ba-Mitzpah*—all remaining.

"Whom Nebuzaradan the captain of the guard had committed to Gedaliah."

*Asher hifqid Nevuzar'adan rav-tabbachim et-Gedalyahu*—Nebuzaradan's trust.

"Departed to go over to the children of Ammon."

*Va-yelekh la'avor el-benei Ammon*—to Ammon.

**Johanan's Pursuit (41:11-15):**
"Johanan the son of Kareah, and all the captains of the forces... heard of all the evil."

*Va-yishma Yochanan ben-Qareach ve-khol-sarei ha-chayalim... et kol-ha-ra'ah*—heard.

"They took all the men."

*Va-yiqchu et-kol-ha-anashim*—gathered men.

"Went to fight with Ishmael."

*Va-yelkhu le-hillachem im-Yishma'el*—went to fight.

"Found him by the great waters that are in Gibeon."

*Va-yimtze'u oto el-mayim rabbim asher be-Giv'on*—at Gibeon waters.

"When all the people that were with Ishmael saw Johanan."

*Va-yehi ka-asher ra'u khol-ha-am asher et-Yishma'el et-Yochanan*—saw Johanan.

"Then they were glad."

*Va-yismachu*—glad.

"All the people that Ishmael had carried away captive from Mizpah cast about and returned."

*Va-yasobbu kol-ha-am asher shavah Yishma'el mi-Mitzpah va-yashuvu*—returned.

"Went unto Johanan the son of Kareah."

*Va-yelkhu el-Yochanan ben-Qareach*—to Johanan.

"Ishmael the son of Nethaniah escaped from Johanan with eight men."

*Ve-Yishma'el ben-Netanyahu nimlet mippenei Yochanan bi-shemonah anashim*—escaped with 8.

"Went to the children of Ammon."

*Va-yelekh el-benei Ammon*—to Ammon.

**Remnant Heads South (41:16-18):**
"Johanan... and all the captains of the forces... all the remnant of the people."

*Va-yiqqach Yochanan... ve-khol-sarei ha-chayalim... et kol-she'erit ha-am*—took remnant.

"Whom he had recovered from Ishmael."

*Asher heshiv me-et Yishma'el*—recovered.

"After that he had slain Gedaliah."

*Acharei hikkah et-Gedalyahu*—after assassination.

"The mighty men of war, and the women, and the children, and the officers."

*Et-gevurei ha-milchamah ve-nashim ve-taf ve-sarisim*—all groups.

"Whom he had brought back from Gibeon."

*Asher heshiv mi-Giv'on*—from Gibeon.

**The Key Verses (41:17-18):**
"They departed, and dwelt in Geruth Chimham."

*Va-yelkhu va-yeshvu be-Gerut Kimham*—Geruth Chimham.

"Which is by Beth-lehem."

*Asher-etzel Beit-Lachem*—near Bethlehem.

"To go to enter into Egypt."

*Lalekhet lavo Mitzraymah*—heading to Egypt.

"Because of the Chaldeans."

*Mippenei ha-Kasdim*—fear of Chaldeans.

"For they were afraid of them."

*Ki yare'u mippeneihem*—afraid.

"Because Ishmael... had slain Gedaliah."

*Ki-hikkah Yishma'el... et-Gedalyahu*—assassination consequences.

"Whom the king of Babylon made governor in the land."

*Asher-hifqid melekh-Bavel ba-aretz*—Babylon's governor killed.

**Fear of Babylonian Reprisal:**
They feared Babylon would blame them for Gedaliah's murder.

**Archetypal Layer:** Jeremiah 41 contains **the assassination of Gedaliah at a shared meal (41:1-2)**, **the massacre of 80 pilgrims (41:4-9)**, **Johanan's rescue of the captives (41:11-14)**, and **the remnant heading toward Egypt in fear (41:17-18)**.

**Ethical Inversion Applied:**
- "In the seventh month"—Tishri 586 BCE
- "Ishmael the son of Nethaniah, the son of Elishama"—Ishmael
- "Of the seed royal"—royal blood
- "Ten men with him"—ten conspirators
- "There they did eat bread together in Mizpah"—hospitality violated
- "Then arose Ishmael... and smote Gedaliah... with the sword"—assassination
- "Slew him, whom the king of Babylon had made governor"—governor killed
- "Ishmael also slew all the Jews that were with him"—killed Jews
- "And the Chaldeans that were found there"—killed Babylonians
- "The second day after he had slain Gedaliah"—second day
- "No man knew it"—secret
- "There came men from Shechem, from Shiloh, and from Samaria"—northern pilgrims
- "Eighty men"—80 men
- "Having their beards shaven and their clothes rent"—mourning
- "With meal-offerings and frankincense... to bring them to the house of YHWH"—temple offerings
- "Ishmael... went forth from Mizpah to meet them"—went out
- "Weeping all along as he went"—feigned tears
- "'Come to Gedaliah the son of Ahikam'"—false invitation
- "When they came into the midst of the city"—inside
- "Ishmael... slew them, and cast them into the midst of the pit"—massacred
- "'Slay us not; for we have stores hidden'"—bargain
- "So he forbare, and slew them not among their brethren"—spared 10
- "The pit... which Asa the king had made"—Asa's cistern
- "Ishmael... filled it with them that were slain"—filled with dead
- "Ishmael carried away captive all the residue of the people"—captives
- "Even the king's daughters"—royal daughters
- "Departed to go over to the children of Ammon"—to Ammon
- "Johanan the son of Kareah... heard of all the evil"—heard
- "Went to fight with Ishmael"—pursued
- "Found him by the great waters that are in Gibeon"—at Gibeon
- "All the people that were with Ishmael saw Johanan... they were glad"—glad
- "All the people that Ishmael had carried away captive... returned"—returned
- "Ishmael... escaped from Johanan with eight men"—escaped
- "Went to the children of Ammon"—to Ammon
- "They departed, and dwelt in Geruth Chimham"—south of Mizpah
- "Which is by Beth-lehem"—near Bethlehem
- "To go to enter into Egypt"—heading to Egypt
- "Because of the Chaldeans; for they were afraid"—fear of Babylon

**Modern Equivalent:** Jeremiah 41 records the tragic end of Judean self-governance. Gedaliah's assassination is still commemorated in the Jewish calendar (Fast of Gedaliah). The hospitality violation and pilgrim massacre show Ishmael's depravity. The remnant's fear of Babylon sets up the Egypt descent.

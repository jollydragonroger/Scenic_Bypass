# Jeremiah 37: Jeremiah Imprisoned

*From the Hebrew: וַיִּמְלֹךְ מֶלֶךְ צִדְקִיָּהוּ (Va-Yimlokh Melekh Tzidqiyyahu) — And King Zedekiah Reigned*

---

## Zedekiah's Inquiry (37:1-10)

**37:1** And Zedekiah the son of Josiah reigned as king, instead of Coniah the son of Jehoiakim, whom Nebuchadrezzar king of Babylon made king in the land of Judah.

**37:2** But neither he, nor his servants, nor the people of the land, did hearken unto the words of YHWH, which he spoke by the prophet Jeremiah.

**37:3** And Zedekiah the king sent Jehucal the son of Shelemiah, and Zephaniah the son of Maaseiah the priest, to the prophet Jeremiah, saying: "Pray now unto YHWH our God for us."

**37:4** Now Jeremiah came in and went out among the people; for they had not put him into prison.

**37:5** And Pharaoh's army was come forth out of Egypt; and when the Chaldeans that were besieging Jerusalem heard tidings of them, they withdrew from Jerusalem.

**37:6** Then came the word of YHWH unto the prophet Jeremiah, saying:

**37:7** "Thus says YHWH, the God of Israel: Thus shall you say to the king of Judah, that sent you unto me to inquire of me: Behold, Pharaoh's army, which is come forth to help you, shall return to Egypt into their own land.

**37:8** "And the Chaldeans shall return, and fight against this city; and they shall take it, and burn it with fire.

**37:9** "Thus says YHWH: Deceive not yourselves, saying: 'The Chaldeans will surely depart from us'; for they will not depart.

**37:10** "For though you had smitten the whole army of the Chaldeans that fight against you, and there remained but wounded men among them, yet would they rise up every man in his tent, and burn this city with fire."

---

## Jeremiah Arrested (37:11-16)

**37:11** And it came to pass, when the army of the Chaldeans was withdrawn from Jerusalem for fear of Pharaoh's army,

**37:12** That Jeremiah went forth out of Jerusalem to go into the land of Benjamin, to receive his portion there, in the midst of the people.

**37:13** And when he was in the gate of Benjamin, a captain of the ward was there, whose name was Irijah, the son of Shelemiah, the son of Hananiah; and he laid hold on Jeremiah the prophet, saying: "You are falling away to the Chaldeans."

**37:14** Then said Jeremiah: "It is false; I fall not away to the Chaldeans"; but he hearkened not to him; so Irijah laid hold on Jeremiah, and brought him to the princes.

**37:15** And the princes were wroth with Jeremiah, and smote him, and put him in prison in the house of Jonathan the scribe; for they had made that the prison.

**37:16** When Jeremiah was come into the dungeon-house, and into the cells, and Jeremiah had remained there many days;

---

## Zedekiah's Secret Inquiry (37:17-21)

**37:17** Then Zedekiah the king sent, and fetched him; and the king asked him secretly in his house, and said: "Is there any word from YHWH?" And Jeremiah said: "There is." He said also: "You shall be delivered into the hand of the king of Babylon."

**37:18** Moreover Jeremiah said unto king Zedekiah: "Wherein have I sinned against you, or against your servants, or against this people, that you have put me in prison?

**37:19** "Where now are your prophets that prophesied unto you, saying: 'The king of Babylon shall not come against you, nor against this land'?

**37:20** "And now hear, I pray you, O my lord the king; let my supplication, I pray you, be accepted before you; that you cause me not to return to the house of Jonathan the scribe, lest I die there."

**37:21** Then Zedekiah the king commanded, and they committed Jeremiah into the court of the guard, and they gave him daily a loaf of bread out of the bakers' street, until all the bread in the city was spent. So Jeremiah remained in the court of the guard.

---

## Synthesis Notes

**Key Restorations:**

**Historical Setting (37:1-2):**
"Zedekiah the son of Josiah reigned as king."

*Va-yimlokh melekh Tzidqiyyahu ben-Yoshiyyahu*—Zedekiah reigned.

"Instead of Coniah the son of Jehoiakim."

*Tachat Konyahu ben-Yehoyaqim*—replacing Jeconiah.

"Whom Nebuchadrezzar king of Babylon made king in the land of Judah."

*Asher himlikh Nevukhadre'zzar melekh-Bavel be-eretz Yehudah*—Babylon's puppet.

**The Key Verse (37:2):**
"Neither he, nor his servants, nor the people of the land, did hearken."

*Ve-lo shama hu va-avadav ve-am ha-aretz*—didn't hear.

"Unto the words of YHWH, which he spoke by the prophet Jeremiah."

*El-divrei YHWH asher dibber be-yad Yirmeyahu ha-navi*—Jeremiah's words.

**Zedekiah's Inquiry (37:3-5):**
"Zedekiah the king sent Jehucal the son of Shelemiah."

*Va-yishlach ha-melekh Tzidqiyyahu et-Yekhukhal ben-Shelemyahu*—sent envoy.

"Zephaniah the son of Maaseiah the priest."

*Ve-et-Tzefanyahu ben-Ma'aseyah ha-kohen*—and priest.

"'Pray now unto YHWH our God for us.'"

*Hitpallel-na va'adenu el-YHWH Eloheinu*—pray for us.

"Jeremiah came in and went out among the people."

*Ve-Yirmeyahu ba va-yotze be-tokh ha-am*—free movement.

"They had not put him into prison."

*Ve-lo natenu oto beit ha-keli*—not yet imprisoned.

**Egyptian Intervention (37:5):**
"Pharaoh's army was come forth out of Egypt."

*Ve-cheil Par'oh yatza mi-Mitzrayim*—Egyptian army came.

"The Chaldeans that were besieging Jerusalem heard tidings of them."

*Va-yishme'u ha-Kasdim ha-tzarim al-Yerushalayim et-shim'am*—Chaldeans heard.

"They withdrew from Jerusalem."

*Va-ye'alu me-al Yerushalayim*—withdrew.

**Historical Note:**
Pharaoh Hophra (Apries) briefly intervened, causing Babylon to withdraw temporarily (588 BCE).

**YHWH's Response (37:6-10):**
"'Pharaoh's army, which is come forth to help you, shall return to Egypt.'"

*Cheil Par'oh ha-yotze lakhem le-ezrah shav le-artzo Mitzrayim*—Egypt returns.

"'The Chaldeans shall return, and fight against this city.'"

*Ve-shavu ha-Kasdim ve-nilchamu al-ha-ir ha-zot*—Chaldeans return.

"'They shall take it, and burn it with fire.'"

*U-lekhaduha u-serafuha va-esh*—take and burn.

**The Key Verse (37:9):**
"'Deceive not yourselves.'"

*Al-tashshi'u nafshotekhem*—don't deceive yourselves.

"'Saying: The Chaldeans will surely depart from us.'"

*Lemor halokh yelkhu me-aleinu ha-Kasdim*—Chaldeans leaving.

"'For they will not depart.'"

*Ki lo yelkhu*—won't leave.

**The Key Verse (37:10):**
"'Though you had smitten the whole army of the Chaldeans.'"

*Ki im-hikkitem kol-cheil Kasdim*—even if you struck all.

"'There remained but wounded men among them.'"

*Ve-nish'aru vahem anashim medaqqarim*—only wounded left.

"'Yet would they rise up every man in his tent.'"

*Ish be-ohalo yaqumu*—they'd rise.

"'And burn this city with fire.'"

*Ve-sarfu et-ha-ir ha-zot ba-esh*—burn city.

**Inevitable Judgment:**
Even if only wounded soldiers remained, they would still accomplish YHWH's purpose.

**Jeremiah Arrested (37:11-16):**
"When the army of the Chaldeans was withdrawn."

*Va-yehi be-he'alot cheil Kasdim*—when Chaldeans withdrew.

"For fear of Pharaoh's army."

*Mippenei cheil Par'oh*—because of Egypt.

"Jeremiah went forth out of Jerusalem."

*Va-yetze Yirmeyahu mi-Yerushalayim*—left Jerusalem.

"To go into the land of Benjamin."

*Lalekhet eretz Binyamin*—to Benjamin.

"To receive his portion there."

*Lachaliq mi-sham be-tokh ha-am*—receive portion.

**Property Matter:**
Likely related to his Anathoth field purchase (32:6-15).

"A captain of the ward was there, whose name was Irijah."

*Ve-sham ba'al peqiddut u-shemo Yir'iyyah*—Irijah captain.

"The son of Shelemiah, the son of Hananiah."

*Ben-Shelemyahu ben-Chananyah*—grandson of Hananiah.

**Possible Connection:**
Possibly descended from the false prophet Hananiah (chapter 28).

"He laid hold on Jeremiah the prophet."

*Va-yitpos et-Yirmeyahu ha-navi*—seized Jeremiah.

**The Key Verse (37:13):**
"'You are falling away to the Chaldeans.'"

*El-ha-Kasdim attah nofel*—you're defecting.

**The Key Verse (37:14):**
"'It is false; I fall not away to the Chaldeans.'"

*Sheqer eini nofel al-ha-Kasdim*—false, not defecting.

"He hearkened not to him."

*Ve-lo shama elav*—didn't listen.

"Irijah laid hold on Jeremiah, and brought him to the princes."

*Va-yitpos Yir'iyyah be-Yirmeyahu va-yevi'ehu el-ha-sarim*—brought to princes.

"The princes were wroth with Jeremiah, and smote him."

*Va-yiqtzefu ha-sarim al-Yirmeyahu va-hikku oto*—angry, beat him.

"Put him in prison in the house of Jonathan the scribe."

*Va-yittenu oto beit ha-asur beit Yehonatan ha-sofer*—Jonathan's prison.

"They had made that the prison."

*Ki oto asu le-veit ha-keli*—made into prison.

"Jeremiah was come into the dungeon-house, and into the cells."

*Ki-va Yirmeyahu el-beit ha-bor ve-el-ha-chaniyyot*—dungeon, cells.

"Jeremiah had remained there many days."

*Va-yeshev sham Yirmeyahu yamim rabbim*—many days.

**Zedekiah's Secret Inquiry (37:17-21):**
"Zedekiah the king sent, and fetched him."

*Va-yishlach ha-melekh Tzidqiyyahu va-yiqqachehu*—king fetched him.

"The king asked him secretly in his house."

*Va-yish'alehu ha-melekh be-veito ba-seter*—asked secretly.

**The Key Verse (37:17):**
"'Is there any word from YHWH?'"

*Ha-yesh davar me-et YHWH*—any word?

"Jeremiah said: 'There is.'"

*Va-yomer Yirmeyahu yesh*—there is.

"'You shall be delivered into the hand of the king of Babylon.'"

*Be-yad melekh-Bavel tinnaten*—to Babylon's hand.

**Unchanged Message:**
Despite imprisonment, Jeremiah's message doesn't change.

**Jeremiah's Defense (37:18-20):**
"'Wherein have I sinned against you?'"

*Meh chatati lakh*—what sin?

"'Or against your servants, or against this people?'"

*U-la-avadekha u-la-am ha-zeh*—against whom?

"'That you have put me in prison?'"

*Ki netattum oti el-beit ha-keli*—why imprisoned?

**The Key Verse (37:19):**
"'Where now are your prophets that prophesied unto you?'"

*Ve-ayyeh nevi'eikhem asher-nibbe'u lakhem*—where are prophets?

"'Saying: The king of Babylon shall not come against you?'"

*Lemor lo-yavo melekh-Bavel aleikhem*—Babylon won't come.

"'Nor against this land?'"

*Ve-al-ha-aretz ha-zot*—nor against land.

**Vindication:**
Jeremiah's prophecy of Babylon's coming was correct; the false prophets were wrong.

**The Key Verse (37:20):**
"'Let my supplication, I pray you, be accepted before you.'"

*Tipol-na techinati lefanekha*—accept plea.

"'Cause me not to return to the house of Jonathan the scribe.'"

*Ve-al-teshiveni beit Yehonatan ha-sofer*—don't send back.

"'Lest I die there.'"

*Ve-lo amut sham*—lest I die.

**The Key Verse (37:21):**
"Zedekiah the king commanded."

*Va-yetzav ha-melekh Tzidqiyyahu*—king commanded.

"They committed Jeremiah into the court of the guard."

*Va-yafqidu et-Yirmeyahu ba-chatzer ha-mattarah*—court of guard.

"They gave him daily a loaf of bread out of the bakers' street."

*Ve-naton lo kikkar-lechem le-yom me-chutz ha-ofim*—daily bread.

"Until all the bread in the city was spent."

*Ad-tom kol-ha-lechem min-ha-ir*—until bread gone.

"Jeremiah remained in the court of the guard."

*Va-yeshev Yirmeyahu ba-chatzer ha-mattarah*—stayed in guard court.

**Improved Conditions:**
Better than the dungeon—open courtyard, daily bread.

**Archetypal Layer:** Jeremiah 37 contains **Egyptian intervention and Babylonian withdrawal (37:5)**, **"Deceive not yourselves, saying: 'The Chaldeans will surely depart'" (37:9)**, **Jeremiah arrested as alleged defector (37:13-14)**, and **Zedekiah's secret inquiry with unchanged answer (37:17)**.

**Ethical Inversion Applied:**
- "Zedekiah the son of Josiah reigned as king"—Zedekiah's reign
- "Instead of Coniah the son of Jehoiakim"—replaced Jeconiah
- "Whom Nebuchadrezzar king of Babylon made king"—Babylon's puppet
- "Neither he, nor his servants... did hearken"—didn't hear
- "Unto the words of YHWH, which he spoke by... Jeremiah"—ignored
- "'Pray now unto YHWH our God for us'"—request prayer
- "Jeremiah came in and went out among the people"—free
- "They had not put him into prison"—not yet
- "Pharaoh's army was come forth out of Egypt"—Egyptian army
- "The Chaldeans... withdrew from Jerusalem"—withdrew
- "'Pharaoh's army... shall return to Egypt'"—Egypt returns
- "'The Chaldeans shall return, and fight against this city'"—Chaldeans return
- "'They shall take it, and burn it with fire'"—take and burn
- "'Deceive not yourselves'"—don't deceive
- "'The Chaldeans will surely depart from us'"—false hope
- "'For they will not depart'"—won't leave
- "'Though you had smitten the whole army'"—even if struck all
- "'Yet would they rise up... and burn this city'"—inevitable
- "Jeremiah went forth out of Jerusalem"—left city
- "To go into the land of Benjamin"—Benjamin
- "To receive his portion there"—property
- "A captain of the ward... Irijah"—Irijah
- "'You are falling away to the Chaldeans'"—defection charge
- "'It is false; I fall not away to the Chaldeans'"—denial
- "He hearkened not to him"—didn't listen
- "The princes were wroth with Jeremiah, and smote him"—beat him
- "Put him in prison"—imprisoned
- "Jeremiah was come into the dungeon-house, and into the cells"—dungeon
- "Jeremiah had remained there many days"—long imprisonment
- "The king asked him secretly in his house"—secret inquiry
- "'Is there any word from YHWH?'"—king's question
- "'There is'"—there is
- "'You shall be delivered into the hand of the king of Babylon'"—same message
- "'Wherein have I sinned against you?'"—Jeremiah's defense
- "'Where now are your prophets that prophesied unto you?'"—vindication
- "'Cause me not to return to the house of Jonathan'"—plea
- "'Lest I die there'"—death fear
- "They committed Jeremiah into the court of the guard"—better conditions
- "They gave him daily a loaf of bread"—daily bread
- "Until all the bread in the city was spent"—until gone

**Modern Equivalent:** Jeremiah 37 shows the prophet caught between opposing forces. The false hope of Egyptian intervention was exposed. Jeremiah's arrest as an alleged defector shows how his pro-surrender message was misinterpreted. Zedekiah's secret inquiry reveals his fear and weakness.

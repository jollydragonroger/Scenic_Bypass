# Jeremiah 36: The Burned Scroll

*From the Hebrew: וַיְהִי בַּשָּׁנָה הָרְבִיעִית (Va-Yehi Ba-Shanah Ha-Revi'it) — And It Came to Pass in the Fourth Year*

---

## The First Scroll (36:1-8)

**36:1** And it came to pass in the fourth year of Jehoiakim the son of Josiah, king of Judah, that this word came unto Jeremiah from YHWH, saying:

**36:2** "Take a scroll of a book, and write therein all the words that I have spoken unto you against Israel, and against Judah, and against all the nations, from the day I spoke unto you, from the days of Josiah, even unto this day.

**36:3** "It may be that the house of Judah will hear all the evil which I purpose to do unto them; that they may return every man from his evil way, and I may forgive their iniquity and their sin."

**36:4** Then Jeremiah called Baruch the son of Neriah; and Baruch wrote from the mouth of Jeremiah all the words of YHWH, which he had spoken unto him, upon a scroll of a book.

**36:5** And Jeremiah commanded Baruch, saying: "I am detained, I cannot go into the house of YHWH;

**36:6** "Therefore go, and read in the scroll, which you have written from my mouth, the words of YHWH in the ears of the people in YHWH's house upon a fast-day; and also you shall read them in the ears of all Judah that come out of their cities.

**36:7** "It may be they will present their supplication before YHWH, and will return every one from his evil way; for great is the anger and the fury that YHWH has pronounced against this people."

**36:8** And Baruch the son of Neriah did according to all that Jeremiah the prophet commanded him, reading in the book the words of YHWH in YHWH's house.

---

## The Scroll Read to the Officials (36:9-19)

**36:9** Now it came to pass in the fifth year of Jehoiakim the son of Josiah, king of Judah, in the ninth month, that they proclaimed a fast before YHWH, all the people in Jerusalem, and all the people that came from the cities of Judah unto Jerusalem.

**36:10** Then Baruch read in the book the words of Jeremiah in the house of YHWH, in the chamber of Gemariah the son of Shaphan the scribe, in the upper court, at the entry of the new gate of YHWH's house, in the ears of all the people.

**36:11** And when Micaiah the son of Gemariah, the son of Shaphan, had heard out of the book all the words of YHWH,

**36:12** He went down into the king's house, into the scribe's chamber; and, lo, all the princes sat there, even Elishama the scribe, and Delaiah the son of Shemaiah, and Elnathan the son of Achbor, and Gemariah the son of Shaphan, and Zedekiah the son of Hananiah, and all the princes.

**36:13** And Micaiah declared unto them all the words that he had heard, when Baruch read the book in the ears of the people.

**36:14** Therefore all the princes sent Jehudi the son of Nethaniah, the son of Shelemiah, the son of Cushi, unto Baruch, saying: "Take in your hand the scroll wherein you have read in the ears of the people, and come." So Baruch the son of Neriah took the scroll in his hand, and came unto them.

**36:15** And they said unto him: "Sit down now, and read it in our ears." So Baruch read it in their ears.

**36:16** Now it came to pass, when they had heard all the words, they turned in fear one to another, and said unto Baruch: "We will surely tell the king of all these words."

**36:17** And they asked Baruch, saying: "Tell us now: How did you write all these words at his mouth?"

**36:18** Then Baruch answered them: "He pronounced all these words unto me with his mouth, and I wrote them with ink in the book."

**36:19** Then said the princes unto Baruch: "Go, hide, you and Jeremiah; and let no man know where you are."

---

## The King Burns the Scroll (36:20-26)

**36:20** And they went in to the king into the court; but they had deposited the scroll in the chamber of Elishama the scribe; and they told all the words in the ears of the king.

**36:21** So the king sent Jehudi to fetch the scroll; and he took it out of the chamber of Elishama the scribe. And Jehudi read it in the ears of the king, and in the ears of all the princes that stood beside the king.

**36:22** Now the king was sitting in the winter-house in the ninth month; and the brazier was burning before him.

**36:23** And it came to pass, when Jehudi had read three or four columns, that he cut it with the penknife, and cast it into the fire that was in the brazier, until all the scroll was consumed in the fire that was in the brazier.

**36:24** Yet they were not afraid, nor rent their garments, neither the king, nor any of his servants that heard all these words.

**36:25** Moreover Elnathan and Delaiah and Gemariah had entreated the king not to burn the scroll; but he would not hear them.

**36:26** And the king commanded Jerahmeel the king's son, and Seraiah the son of Azriel, and Shelemiah the son of Abdeel, to take Baruch the scribe and Jeremiah the prophet; but YHWH hid them.

---

## The Second Scroll (36:27-32)

**36:27** Then the word of YHWH came to Jeremiah, after that the king had burned the scroll, and the words which Baruch wrote at the mouth of Jeremiah, saying:

**36:28** "Take again another scroll, and write in it all the former words that were in the first scroll, which Jehoiakim the king of Judah has burned.

**36:29** "And concerning Jehoiakim king of Judah you shall say: Thus says YHWH: You have burned this scroll, saying: 'Why have you written therein, saying: The king of Babylon shall certainly come and destroy this land, and shall cause to cease from there man and beast?'

**36:30** "Therefore thus says YHWH concerning Jehoiakim king of Judah: He shall have none to sit upon the throne of David; and his dead body shall be cast out in the day to the heat, and in the night to the frost.

**36:31** "And I will punish him and his seed and his servants for their iniquity; and I will bring upon them, and upon the inhabitants of Jerusalem, and upon the men of Judah, all the evil that I have pronounced against them, but they hearkened not."

**36:32** Then took Jeremiah another scroll, and gave it to Baruch the scribe, the son of Neriah, who wrote therein from the mouth of Jeremiah all the words of the book which Jehoiakim king of Judah had burned in the fire; and there were added besides unto them many like words.

---

## Synthesis Notes

**Key Restorations:**

**First Scroll (36:1-4):**
"In the fourth year of Jehoiakim."

*Ba-shanah ha-revi'it li-Yehoyaqim ben-Yoshiyyahu melekh Yehudah*—605/604 BCE.

**The Key Verse (36:2):**
"'Take a scroll of a book.'"

*Qach-lekha megillat-sefer*—take scroll.

"'Write therein all the words that I have spoken unto you.'"

*Ve-khatavta alekha et kol-ha-devarim asher-dibbarti elekha*—write all words.

"'Against Israel, and against Judah, and against all the nations.'"

*Al-Yisra'el ve-al-Yehudah ve-al-kol-ha-goyim*—against all.

"'From the day I spoke unto you, from the days of Josiah.'"

*Mi-yom dibbarti elekha mi-yemei Yoshiyyahu*—from Josiah's days.

"'Even unto this day.'"

*Ve-ad ha-yom ha-zeh*—until now.

**23 Years of Prophecy:**
This represents 23 years of oracles (627-605 BCE).

**The Key Verse (36:3):**
"'It may be that the house of Judah will hear all the evil.'"

*Ulai yishme'u beit Yehudah et kol-ha-ra'ah*—perhaps hear.

"'That they may return every man from his evil way.'"

*Lema'an yashuvu ish mi-darkko ha-ra'ah*—return from evil.

"'I may forgive their iniquity and their sin.'"

*Ve-salachti la-avonam u-le-chatta'tam*—forgive.

**Baruch's Role (36:4-8):**
"Jeremiah called Baruch the son of Neriah."

*Va-yiqra Yirmeyahu et-Barukh ben-Neriyyah*—called Baruch.

"Baruch wrote from the mouth of Jeremiah all the words of YHWH."

*Va-yikhtov Barukh mi-pi Yirmeyahu et kol-divrei YHWH*—wrote from mouth.

"Upon a scroll of a book."

*Al-megillat-sefer*—on scroll.

"'I am detained, I cannot go into the house of YHWH.'"

*Ani atzur lo ukhal lavo beit YHWH*—detained.

**Detained:**
Either under house arrest or ritually barred from the temple.

"'Read in the scroll... the words of YHWH in the ears of the people... upon a fast-day.'"

*Ve-qarata ba-megillah... divrei YHWH be-oznei ha-am... be-yom tzom*—read on fast day.

"'It may be they will present their supplication before YHWH.'"

*Ulai-tipol tehinnatam lifnei YHWH*—perhaps supplicate.

"'Return every one from his evil way.'"

*Ve-yashuvu ish mi-darkko ha-ra'ah*—return.

"'Great is the anger and the fury.'"

*Ki-gadol ha-af ve-ha-chemah*—great anger.

**Public Reading (36:9-10):**
"In the fifth year of Jehoiakim... in the ninth month."

*Ba-shanah ha-chamishit li-Yehoyaqim... ba-chodesh ha-teshi'i*—December 604 BCE.

"They proclaimed a fast before YHWH."

*Qare'u tzom lifnei YHWH*—fast proclaimed.

"Baruch read in the book the words of Jeremiah in the house of YHWH."

*Va-yiqra Varukh ba-sefer et-divrei Yirmeyahu be-veit YHWH*—Baruch read.

"In the chamber of Gemariah the son of Shaphan the scribe."

*Be-lishkat Gemaryahu ben-Shafan ha-sofer*—Gemariah's chamber.

"In the upper court, at the entry of the new gate."

*Ba-chatzer ha-elyonah petach sha'ar beit-YHWH he-chadash*—new gate.

**Report to Officials (36:11-19):**
"Micaiah the son of Gemariah, the son of Shaphan."

*Mikhayehu ben-Gemaryahu ben-Shafan*—Micaiah heard.

"He went down into the king's house, into the scribe's chamber."

*Va-yered beit-ha-melekh al-lishkat ha-sofer*—to palace.

"All the princes sat there."

*Ve-hinneh-sham kol-ha-sarim yoshevim*—princes sitting.

"Elishama the scribe."

*Elishama ha-sofer*—Elishama.

"Micaiah declared unto them all the words."

*Va-yagged lahem Mikhayehu et kol-ha-devarim*—reported.

"All the princes sent Jehudi... unto Baruch."

*Va-yishlechu khol-ha-sarim el-Barukh et-Yehudi*—sent for Baruch.

"'Take in your hand the scroll... and come.'"

*Qach be-yadekha ha-megillah... u-vo*—bring scroll.

"'Sit down now, and read it in our ears.'"

*Shev na u-qera'eha be-ozneinu*—read to us.

"So Baruch read it in their ears."

*Va-yiqra Barukh be-ozneihem*—Baruch read.

**The Key Verse (36:16):**
"When they had heard all the words, they turned in fear one to another."

*Va-yehi ki-shom'am et-kol-ha-devarim pachaduu ish el-re'ehu*—feared.

"'We will surely tell the king of all these words.'"

*Hagged naggid la-melekh et kol-ha-devarim ha-elleh*—must tell king.

**The Key Verse (36:17-18):**
"'How did you write all these words at his mouth?'"

*Hagged-na lanu eikh katavta et-kol-ha-devarim ha-elleh mi-piv*—how written?

"'He pronounced all these words unto me with his mouth.'"

*Mi-piv yiqra elai et kol-ha-devarim ha-elleh*—dictated.

"'I wrote them with ink in the book.'"

*Va-ani kotev al-ha-sefer ba-dyo*—wrote with ink.

**The Key Verse (36:19):**
"'Go, hide, you and Jeremiah; and let no man know where you are.'"

*Lekhu hissateru attah ve-Yirmeyahu ve-ish al-yeda et-meqomkhem*—hide.

**King Burns Scroll (36:20-26):**
"They had deposited the scroll in the chamber of Elishama."

*Ve-et-ha-megillah hifqidu be-lishkat Elishama ha-sofer*—stored scroll.

"They told all the words in the ears of the king."

*Va-yaggidu be-oznei ha-melekh et kol-ha-devarim*—told king.

"The king sent Jehudi to fetch the scroll."

*Va-yishlach ha-melekh et-Yehudi laqachat et-ha-megillah*—sent for scroll.

"Jehudi read it in the ears of the king."

*Va-yiqra'eha Yehudi be-oznei ha-melekh*—Jehudi read.

"All the princes that stood beside the king."

*U-ve-oznei khol-ha-sarim ha-omedim al-ha-melekh*—princes present.

**The Key Verse (36:22):**
"The king was sitting in the winter-house in the ninth month."

*Ve-ha-melekh yoshev beit ha-choref ba-chodesh ha-teshi'i*—winter house.

"The brazier was burning before him."

*Ve-et-ha-ach lefanav meva'aret*—brazier burning.

**The Key Verse (36:23):**
"When Jehudi had read three or four columns."

*Va-yehi ki-qero Yehudi shalosh dela'tot ve-arba*—3-4 columns.

"He cut it with the penknife."

*Yiqra'eha be-ta'ar ha-sofer*—cut with knife.

"Cast it into the fire that was in the brazier."

*Ve-hashlekh el-ha-esh asher el-ha-ach*—into fire.

"Until all the scroll was consumed in the fire."

*Ad-tom kol-ha-megillah al-ha-esh asher al-ha-ach*—all consumed.

**The Key Verse (36:24):**
"They were not afraid."

*Ve-lo pachaduu*—not afraid.

"Nor rent their garments."

*Ve-lo qare'u et-bigdeihem*—didn't tear garments.

"Neither the king, nor any of his servants."

*Ha-melekh ve-khol-avadav*—king and servants.

**Contrast with Josiah:**
When Josiah heard the law book, he tore his garments (2 Kings 22:11). Jehoiakim showed contempt.

**The Key Verses (36:25-26):**
"Elnathan and Delaiah and Gemariah had entreated the king not to burn the scroll."

*Ve-gam Elnatan u-Delayahu ve-Gemaryahu hipgi'u va-melekh le-vilti serof et-ha-megillah*—entreated.

"He would not hear them."

*Ve-lo shama aleihem*—wouldn't hear.

"The king commanded... to take Baruch the scribe and Jeremiah the prophet."

*Va-yetzav ha-melekh... litpos et-Barukh ha-sofer ve-et Yirmeyahu ha-navi*—arrest order.

"YHWH hid them."

*Va-YHWH hissitiram*—YHWH hid.

**Second Scroll (36:27-32):**
**The Key Verse (36:28):**
"'Take again another scroll.'"

*Shuv qach-lekha megillah acheret*—another scroll.

"'Write in it all the former words that were in the first scroll.'"

*U-khetov alekha et kol-ha-devarim ha-rishonim asher hayu al-ha-megillah ha-rishonah*—write again.

"'Which Jehoiakim the king of Judah has burned.'"

*Asher saraf Yehoyaqim melekh-Yehudah*—which Jehoiakim burned.

**The Key Verse (36:29):**
"'You have burned this scroll, saying: Why have you written therein?'"

*Attah sarafta et-ha-megillah ha-zot lemor maddua katavta alekha*—king's objection.

"'The king of Babylon shall certainly come and destroy this land.'"

*Bo yavo melekh Bavel ve-hishchit et-ha-aretz ha-zot*—Babylon prophecy.

**Judgment on Jehoiakim (36:30-31):**
**The Key Verse (36:30):**
"'He shall have none to sit upon the throne of David.'"

*Lo-yihyeh-lo yoshev al-kisse David*—no successor.

"'His dead body shall be cast out in the day to the heat.'"

*Ve-nivlato tihyeh mushlekhot la-chorev ba-yom*—exposed to heat.

"'And in the night to the frost.'"

*Ve-la-qerach ba-laylah*—exposed to frost.

**Jehoiachin's Brief Reign:**
Jehoiachin reigned only 3 months (2 Kings 24:8)—effectively, Jehoiakim had no lasting successor.

"'I will punish him and his seed and his servants for their iniquity.'"

*U-faqadti alav ve-al-zar'o ve-al-avadav et-avonam*—punish him.

"'I will bring upon them... all the evil.'"

*Ve-heveti aleihem... et kol-ha-ra'ah*—bring evil.

"'They hearkened not.'"

*Ve-lo sham'u*—didn't hear.

**The Key Verse (36:32):**
"Jeremiah... gave it to Baruch the scribe."

*U-Yirmeyahu laqach megillah acheret va-yittenah el-Barukh ben-Neriyyah ha-sofer*—gave to Baruch.

"Who wrote therein from the mouth of Jeremiah all the words of the book."

*Va-yikhtov alekha mi-pi Yirmeyahu et kol-divrei ha-sefer*—wrote from mouth.

"Which Jehoiakim king of Judah had burned in the fire."

*Asher saraf Yehoyaqim melekh-Yehudah ba-esh*—burned by king.

"There were added besides unto them many like words."

*Ve-od nosaf aleihem devarim rabbim ka-hemmah*—many added.

**Archetypal Layer:** Jeremiah 36 contains **the dictation of the first scroll to Baruch (36:4)**, **the king burning the scroll column by column (36:23)**, **the contrast with Josiah's response (36:24)**, and **the second scroll with "many like words" added (36:32)**.

**Ethical Inversion Applied:**
- "In the fourth year of Jehoiakim"—605/604 BCE
- "'Take a scroll of a book'"—take scroll
- "'Write therein all the words that I have spoken unto you'"—write all
- "'Against Israel, and against Judah, and against all the nations'"—against all
- "'From the days of Josiah, even unto this day'"—23 years
- "'It may be that the house of Judah will hear'"—hope
- "'That they may return every man from his evil way'"—return
- "'I may forgive their iniquity and their sin'"—forgive
- "Jeremiah called Baruch the son of Neriah"—called Baruch
- "Baruch wrote from the mouth of Jeremiah all the words"—dictation
- "'I am detained, I cannot go into the house of YHWH'"—detained
- "'Read in the scroll... the words of YHWH... upon a fast-day'"—fast day reading
- "In the fifth year of Jehoiakim... in the ninth month"—Dec 604
- "They proclaimed a fast before YHWH"—fast
- "Baruch read in the book the words of Jeremiah in the house of YHWH"—temple reading
- "Micaiah... had heard... all the words of YHWH"—Micaiah heard
- "All the princes sat there"—princes sitting
- "'Sit down now, and read it in our ears'"—officials hear
- "When they had heard all the words, they turned in fear"—feared
- "'We will surely tell the king'"—must tell
- "'How did you write all these words at his mouth?'"—inquiry
- "'He pronounced all these words unto me with his mouth'"—dictated
- "'I wrote them with ink in the book'"—wrote
- "'Go, hide, you and Jeremiah'"—hide
- "The king sent Jehudi to fetch the scroll"—fetched
- "Jehudi read it in the ears of the king"—read to king
- "The king was sitting in the winter-house"—winter house
- "The brazier was burning before him"—brazier
- "When Jehudi had read three or four columns"—partial reading
- "He cut it with the penknife"—cut
- "Cast it into the fire"—burned
- "Until all the scroll was consumed"—consumed
- "They were not afraid, nor rent their garments"—no fear
- "Elnathan and Delaiah and Gemariah had entreated the king not to burn"—entreated
- "He would not hear them"—wouldn't hear
- "The king commanded... to take Baruch... and Jeremiah"—arrest order
- "YHWH hid them"—YHWH hid
- "'Take again another scroll'"—second scroll
- "'Write in it all the former words'"—rewrite
- "'You have burned this scroll'"—king's act
- "'He shall have none to sit upon the throne of David'"—no successor
- "'His dead body shall be cast out'"—exposed
- "There were added besides unto them many like words"—more added

**Modern Equivalent:** Jeremiah 36 shows how Scripture survived opposition. The king destroyed the scroll, but it was rewritten with additions. The contrast with Josiah's reaction (tearing garments) shows Jehoiakim's contempt. This chapter illuminates prophetic book formation.

# Jeremiah 45: The Word to Baruch

*From the Hebrew: הַדָּבָר אֲשֶׁר דִּבֶּר יִרְמְיָהוּ הַנָּבִיא (Ha-Davar Asher Dibber Yirmeyahu Ha-Navi) — The Word That Jeremiah the Prophet Spoke*

---

## Baruch's Lament (45:1-3)

**45:1** The word that Jeremiah the prophet spoke unto Baruch the son of Neriah, when he wrote these words in a book at the mouth of Jeremiah, in the fourth year of Jehoiakim the son of Josiah, king of Judah, saying:

**45:2** "Thus says YHWH, the God of Israel, concerning you, O Baruch:

**45:3** "You did say: 'Woe is me now! For YHWH has added sorrow to my pain; I am weary with my groaning, and I find no rest.'"

---

## YHWH's Answer to Baruch (45:4-5)

**45:4** "Thus shall you say unto him: Thus says YHWH: Behold, that which I have built will I break down, and that which I have planted I will pluck up; and this in the whole land.

**45:5** "And do you seek great things for yourself? Seek them not; for, behold, I will bring evil upon all flesh," says YHWH; "but your life will I give unto you for a prey in all places whither you go."

---

## Synthesis Notes

**Key Restorations:**

**Setting (45:1):**
"The word that Jeremiah the prophet spoke unto Baruch the son of Neriah."

*Ha-davar asher dibber Yirmeyahu ha-navi el-Barukh ben-Neriyyah*—to Baruch.

"When he wrote these words in a book at the mouth of Jeremiah."

*Be-khotvo et-ha-devarim ha-elleh al-sefer mi-pi Yirmeyahu*—writing from Jeremiah's dictation.

"In the fourth year of Jehoiakim."

*Ba-shanah ha-revi'it li-Yehoyaqim ben-Yoshiyyahu melekh Yehudah*—605/604 BCE.

**Historical Context:**
This oracle dates to the same time as chapter 36—when Baruch wrote the first scroll. Though placed here, it belongs chronologically earlier.

**Baruch's Lament (45:2-3):**
"'Thus says YHWH, the God of Israel, concerning you, O Baruch.'"

*Koh-amar YHWH Elohei Yisra'el alekha Barukh*—concerning Baruch.

**The Key Verse (45:3):**
"'You did say: Woe is me now!'"

*Amarta oy-na li*—woe to me.

"'For YHWH has added sorrow to my pain.'"

*Ki-yasaf YHWH yagon al-makh'ovi*—added sorrow.

"'I am weary with my groaning.'"

*Yagati be-anachati*—weary with groaning.

"'I find no rest.'"

*U-menuchah lo matzati*—no rest.

**Baruch's Burden:**
As Jeremiah's scribe, Baruch shared his master's suffering and rejection.

**YHWH's Answer (45:4-5):**
**The Key Verse (45:4):**
"'Behold, that which I have built will I break down.'"

*Hinneh asher-baniti ani hores*—break what I built.

"'That which I have planted I will pluck up.'"

*Ve-et asher-nata'ti ani notesh*—pluck what I planted.

"'And this in the whole land.'"

*Ve-et-kol-ha-aretz hi*—whole land.

**Reversal:**
YHWH's commission language (1:10) reversed—now destruction rather than building.

**The Key Verse (45:5):**
"'Do you seek great things for yourself?'"

*Ve-attah tevaqesh-lekha gedolot*—seek great things?

"'Seek them not.'"

*Al-tevaqesh*—don't seek.

"'For, behold, I will bring evil upon all flesh,' says YHWH."

*Ki hineni mevi ra'ah al-kol-basar*—evil on all flesh.

"'But your life will I give unto you for a prey.'"

*Ve-natatti lekha et-nafshekha le-shalal*—life as prey.

"'In all places whither you go.'"

*Al-kol-ha-meqomot asher telekh-sham*—wherever you go.

**Life as Prey:**
The same promise given to Ebed-melech (39:18). In universal judgment, survival is the "great thing."

**Archetypal Layer:** Jeremiah 45 is **the only chapter devoted to Baruch**, containing **his lament of exhaustion (45:3)**, **YHWH's rebuke about seeking great things (45:5)**, and **the promise of life as prey—survival in judgment**.

**Ethical Inversion Applied:**
- "The word that Jeremiah the prophet spoke unto Baruch"—to Baruch
- "When he wrote these words in a book at the mouth of Jeremiah"—dictation
- "In the fourth year of Jehoiakim"—605/604 BCE
- "'Thus says YHWH, the God of Israel, concerning you, O Baruch'"—about Baruch
- "'You did say: Woe is me now!'"—Baruch's lament
- "'YHWH has added sorrow to my pain'"—added sorrow
- "'I am weary with my groaning'"—weary
- "'I find no rest'"—no rest
- "'That which I have built will I break down'"—break down
- "'That which I have planted I will pluck up'"—pluck up
- "'This in the whole land'"—whole land
- "'Do you seek great things for yourself?'"—seeking great things
- "'Seek them not'"—don't seek
- "'I will bring evil upon all flesh'"—evil on all
- "'Your life will I give unto you for a prey'"—life as prey
- "'In all places whither you go'"—wherever

**Modern Equivalent:** Jeremiah 45 is a personal word to Baruch—the only chapter focused on him. His lament echoes Jeremiah's confessions. The rebuke "Do you seek great things for yourself?" challenges ambition in times of judgment. "Life as prey" means survival is enough when everything collapses.

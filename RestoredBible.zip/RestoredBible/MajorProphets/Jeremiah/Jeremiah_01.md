# Jeremiah 1: The Call of Jeremiah

*From the Hebrew: דִּבְרֵי יִרְמְיָהוּ (Divrei Yirmeyahu) — The Words of Jeremiah*

---

## Introduction (1:1-3)

**1:1** The words of Jeremiah the son of Hilkiah, of the priests that were in Anathoth in the land of Benjamin;

**1:2** To whom the word of YHWH came in the days of Josiah the son of Amon, king of Judah, in the thirteenth year of his reign.

**1:3** It came also in the days of Jehoiakim the son of Josiah, king of Judah, unto the end of the eleventh year of Zedekiah the son of Josiah, king of Judah, unto the carrying away of Jerusalem captive in the fifth month.

---

## Jeremiah's Call (1:4-10)

**1:4** And the word of YHWH came unto me, saying:

**1:5** "Before I formed you in the belly I knew you, and before you came forth out of the womb I sanctified you; I have appointed you a prophet unto the nations."

**1:6** Then said I: "Ah, Lord YHWH! Behold, I cannot speak; for I am a child."

**1:7** But YHWH said unto me: "Say not: I am a child; for to whomsoever I shall send you you shall go, and whatsoever I shall command you you shall speak.

**1:8** "Be not afraid of them; for I am with you to deliver you," says YHWH.

**1:9** Then YHWH put forth his hand, and touched my mouth; and YHWH said unto me: "Behold, I have put my words in your mouth.

**1:10** "See, I have this day set you over the nations and over the kingdoms, to pluck up and to break down, and to destroy and to overthrow; to build and to plant."

---

## Two Visions (1:11-16)

**1:11** Moreover the word of YHWH came unto me, saying: "Jeremiah, what do you see?" And I said: "I see a rod of an almond-tree."

**1:12** Then said YHWH unto me: "You have well seen; for I watch over my word to perform it."

**1:13** And the word of YHWH came unto me the second time, saying: "What do you see?" And I said: "I see a seething pot; and its face is from the north."

**1:14** Then YHWH said unto me: "Out of the north evil shall break forth upon all the inhabitants of the land.

**1:15** "For, lo, I will call all the families of the kingdoms of the north," says YHWH; "and they shall come, and they shall set every one his throne at the entrance of the gates of Jerusalem, and against all its walls round about, and against all the cities of Judah.

**1:16** "And I will utter my judgments against them touching all their wickedness; in that they have forsaken me, and have offered unto other gods, and worshipped the work of their own hands."

---

## Encouragement to Jeremiah (1:17-19)

**1:17** "You therefore gird up your loins, and arise, and speak unto them all that I command you; be not dismayed at them, lest I dismay you before them.

**1:18** "For, behold, I have made you this day a fortified city, and an iron pillar, and brazen walls, against the whole land, against the kings of Judah, against the princes thereof, against the priests thereof, and against the people of the land.

**1:19** "And they shall fight against you; but they shall not prevail against you; for I am with you," says YHWH, "to deliver you."

---

## Synthesis Notes

**Key Restorations:**

**Historical Setting (1:1-3):**
"The words of Jeremiah the son of Hilkiah."

*Divrei Yirmeyahu ben-Chilqiyyahu*—Jeremiah's words.

"Of the priests that were in Anathoth."

*Min-ha-kohanim asher ba-Anatot*—priestly lineage.

"In the land of Benjamin."

*Be-eretz Binyamin*—Benjamin's territory.

"In the days of Josiah... in the thirteenth year of his reign."

*Bi-yemei Yoshiyyahu... bi-shnat shelosh-esreh le-molkho*—627 BCE.

"Unto the carrying away of Jerusalem captive."

*Ad-gelot Yerushalayim*—586 BCE.

**Jeremiah's Ministry Span:**
- From 627 BCE (Josiah's 13th year) to 586 BCE (Jerusalem's fall)
- Through reigns of Josiah, Jehoahaz, Jehoiakim, Jehoiachin, Zedekiah
- 40+ years of prophetic ministry

**The Key Verse (1:5):**
"Before I formed you in the belly I knew you."

*Be-terem etzorkha va-beten yeda'tikha*—pre-birth knowledge.

"Before you came forth out of the womb I sanctified you."

*U-ve-terem tetze me-rechem hiqdashttikha*—womb-sanctified.

"I have appointed you a prophet unto the nations."

*Navi la-goyim netattikha*—prophet to nations.

**Jeremiah's Objection (1:6):**
"Ah, Lord YHWH!"

*Ahahh Adonai YHWH*—exclamation.

"Behold, I cannot speak."

*Hinneh lo-yadati dabber*—can't speak.

"For I am a child."

*Ki-na'ar anokhi*—I'm young.

**YHWH's Response (1:7-10):**
"Say not: I am a child."

*Al-tomar na'ar anokhi*—don't say young.

"To whomsoever I shall send you you shall go."

*Ki al-kol-asher eshlachakha telekh*—go where sent.

"Whatsoever I shall command you you shall speak."

*Ve-et kol-asher atzavvekha tedabber*—speak what commanded.

"Be not afraid of them."

*Al-tira mippeneihem*—don't fear.

"For I am with you to deliver you."

*Ki-ittekha ani le-hatztzilekha*—with you to deliver.

**The Key Verse (1:9):**
"YHWH put forth his hand, and touched my mouth."

*Va-yishlach YHWH et-yado va-yigga al-pi*—mouth touched.

"I have put my words in your mouth."

*Hinneh natatti devarai be-fikha*—words given.

**The Key Verse (1:10):**
"I have this day set you over the nations and over the kingdoms."

*Re'eh hifqadttikha ha-yom ha-zeh al-ha-goyim ve-al-ha-mamlakhot*—set over nations.

"To pluck up and to break down."

*Lintosh ve-lintotz*—uproot and tear down.

"To destroy and to overthrow."

*U-le-ha'avid ve-la-haros*—destroy and overthrow.

"To build and to plant."

*Livnot ve-lintoa*—build and plant.

**Six Verbs of Ministry:**
Four destructive, two constructive—Jeremiah's message is predominantly judgment, but ends in hope.

**Almond Vision (1:11-12):**
"I see a rod of an almond-tree."

*Maqqel shaqed ani ro'eh*—almond rod (*shaqed*).

"I watch over my word to perform it."

*Shoqed ani al-devari la'asoto*—watching (*shoqed*) over word.

**Wordplay:**
*Shaqed* (almond) sounds like *shoqed* (watching)—YHWH is alert, awake to perform his word.

**Boiling Pot Vision (1:13-16):**
"I see a seething pot."

*Sir nafuach ani ro'eh*—boiling pot.

"Its face is from the north."

*U-fanav mippenei tzafonah*—tilted from north.

"Out of the north evil shall break forth."

*Mi-tzafon tippattach ha-ra'ah*—evil from north.

"I will call all the families of the kingdoms of the north."

*Ki hineni qore le-khol-mishpechot mamlakhot tzafonah*—northern kingdoms called.

**Historical Reference:**
Babylon, though east of Judah, invaded from the north via the Fertile Crescent.

**Fortified Prophet (1:17-19):**
"Gird up your loins, and arise, and speak."

*Ve-attah te'ezzor motnekha ve-qamta ve-dibbarta*—prepare and speak.

"Be not dismayed at them, lest I dismay you before them."

*Al-techat mippeneihem pen-achittkha lifneihem*—don't be dismayed.

**The Key Verse (1:18):**
"I have made you this day a fortified city."

*Hinneh netattikha ha-yom le-ir mivtzar*—fortified city.

"An iron pillar."

*U-le-ammud barzel*—iron pillar.

"Brazen walls."

*Ve-le-chomot nechoshet*—bronze walls.

"Against the whole land."

*Al-kol-ha-aretz*—against all.

"They shall fight against you; but they shall not prevail against you."

*Ve-nilchamu elekha ve-lo-yukhlu lakh*—fight but not prevail.

"For I am with you... to deliver you."

*Ki-ittekha-ani... le-hatztzilekha*—with you to deliver.

**Archetypal Layer:** Jeremiah 1 establishes the **pre-birth call (1:5)**, **mouth touched with words (1:9)**, **six-verb commission (1:10)**, **almond/watching wordplay (1:11-12)**, and **fortified prophet (1:18)**.

**Ethical Inversion Applied:**
- "The words of Jeremiah"—prophet's words
- "Of the priests that were in Anathoth"—priestly origin
- "Before I formed you in the belly I knew you"—pre-existence knowing
- "Before you came forth out of the womb I sanctified you"—womb-sanctified
- "I have appointed you a prophet unto the nations"—nations prophet
- "'Ah, Lord YHWH! Behold, I cannot speak; for I am a child'"—humble objection
- "'Say not: I am a child'"—objection overruled
- "'To whomsoever I shall send you you shall go'"—obedience required
- "'Be not afraid of them; for I am with you to deliver you'"—presence promise
- "YHWH put forth his hand, and touched my mouth"—mouth touched
- "'I have put my words in your mouth'"—words given
- "'To pluck up and to break down, and to destroy and to overthrow'"—destruction
- "'To build and to plant'"—construction
- "'I see a rod of an almond-tree'"—almond vision
- "'I watch over my word to perform it'"—watching wordplay
- "'I see a seething pot'"—boiling pot
- "'Out of the north evil shall break forth'"—northern threat
- "'I have made you this day a fortified city, and an iron pillar'"—fortified
- "'They shall fight against you; but they shall not prevail'"—opposition promised
- "'For I am with you... to deliver you'"—deliverance promised

**Modern Equivalent:** Jeremiah 1:5's pre-birth calling ("Before I formed you in the belly I knew you") is foundational for understanding divine foreknowledge and purpose. The six verbs of 1:10 summarize Jeremiah's entire ministry. The almond/watching wordplay (1:11-12) shows God's alertness to fulfill his word.

# Jeremiah 43: Flight to Egypt

*From the Hebrew: וַיְהִי כְּכַלּוֹת יִרְמְיָהוּ (Va-Yehi Ke-Khallot Yirmeyahu) — And It Came to Pass When Jeremiah Had Finished*

---

## The Rejection of YHWH's Word (43:1-7)

**43:1** And it came to pass, that when Jeremiah had made an end of speaking unto all the people all the words of YHWH their God, wherewith YHWH their God had sent him to them, even all these words,

**43:2** Then spoke Azariah the son of Hoshaiah, and Johanan the son of Kareah, and all the proud men, saying unto Jeremiah: "You speak falsely; YHWH our God has not sent you to say: 'You shall not go into Egypt to sojourn there';

**43:3** "But Baruch the son of Neriah sets you on against us, to deliver us into the hand of the Chaldeans, that they may put us to death, and carry us away captives to Babylon."

**43:4** So Johanan the son of Kareah, and all the captains of the forces, and all the people, hearkened not to the voice of YHWH, to dwell in the land of Judah.

**43:5** But Johanan the son of Kareah, and all the captains of the forces, took all the remnant of Judah, that were returned from all the nations whither they had been driven, to sojourn in the land of Judah:

**43:6** The men, and the women, and the children, and the king's daughters, and every person that Nebuzaradan the captain of the guard had left with Gedaliah the son of Ahikam, the son of Shaphan, and Jeremiah the prophet, and Baruch the son of Neriah;

**43:7** And they came into the land of Egypt; for they hearkened not to the voice of YHWH; and they came even to Tahpanhes.

---

## The Sign at Tahpanhes (43:8-13)

**43:8** Then came the word of YHWH unto Jeremiah in Tahpanhes, saying:

**43:9** "Take great stones in your hand, and hide them in the mortar in the framework, which is at the entry of Pharaoh's house in Tahpanhes, in the sight of the men of Judah;

**43:10** "And say unto them: Thus says YHWH of hosts, the God of Israel: Behold, I will send and take Nebuchadrezzar the king of Babylon, my servant, and will set his throne upon these stones that I have hid; and he shall spread his royal pavilion over them.

**43:11** "And he shall come, and shall smite the land of Egypt: such as are for death shall be given to death, and such as are for captivity to captivity, and such as are for the sword to the sword.

**43:12** "And I will kindle a fire in the houses of the gods of Egypt; and he shall burn them, and carry them away captives; and he shall wrap himself with the land of Egypt, as a shepherd wraps himself in his garment; and he shall go forth from there in peace.

**43:13** "He shall also break the pillars of Beth-shemesh, that is in the land of Egypt; and the houses of the gods of Egypt shall he burn with fire."

---

## Synthesis Notes

**Key Restorations:**

**Rejection of YHWH's Word (43:1-4):**
"When Jeremiah had made an end of speaking unto all the people."

*Va-yehi ke-khallot Yirmeyahu le-dabber el-kol-ha-am*—finished speaking.

"All the words of YHWH their God."

*Et-kol-divrei YHWH Eloheihem*—all YHWH's words.

"Wherewith YHWH their God had sent him to them."

*Asher shelakho YHWH Eloheihem aleihem*—sent by YHWH.

"Even all these words."

*Et kol-ha-devarim ha-elleh*—all these words.

**The Key Verse (43:2):**
"Then spoke Azariah the son of Hoshaiah."

*Va-yomer Azaryah ben-Hosha'yah*—Azariah spoke.

"Johanan the son of Kareah."

*Ve-Yochanan ben-Qareach*—Johanan.

"All the proud men."

*Ve-khol-ha-anashim ha-zedim*—proud/arrogant men.

"'You speak falsely.'"

*Sheqer attah medabber*—you lie.

"'YHWH our God has not sent you.'"

*Lo shelachakha YHWH Eloheinu*—not sent.

"'To say: You shall not go into Egypt to sojourn there.'"

*Lemor lo tavo'u Mitzrayim lagur sham*—not to go to Egypt.

**Accusation Against Baruch (43:3):**
**The Key Verse (43:3):**
"'Baruch the son of Neriah sets you on against us.'"

*Ki Barukh ben-Neriyyah massit otakh banu*—Baruch incites.

"'To deliver us into the hand of the Chaldeans.'"

*Lema'an tet otanu be-yad ha-Kasdim*—deliver to Chaldeans.

"'That they may put us to death.'"

*Le-hamit otanu*—to kill us.

"'Carry us away captives to Babylon.'"

*U-le-haglot otanu Bavel*—exile to Babylon.

**Blame Baruch:**
Rather than accept YHWH's word, they blame the scribe Baruch for manipulating Jeremiah.

**The Key Verse (43:4):**
"Johanan the son of Kareah, and all the captains of the forces, and all the people."

*Ve-lo-shama Yochanan ben-Qareach ve-khol-sarei ha-chayalim ve-khol-ha-am*—all.

"Hearkened not to the voice of YHWH."

*Be-qol YHWH*—YHWH's voice.

"To dwell in the land of Judah."

*La-shevet be-eretz Yehudah*—to stay.

**Flight to Egypt (43:5-7):**
"Johanan... and all the captains of the forces, took all the remnant of Judah."

*Va-yiqqach Yochanan... ve-khol-sarei ha-chayalim et-kol-she'erit Yehudah*—took remnant.

"That were returned from all the nations whither they had been driven."

*Asher-shavu mi-kol-ha-goyim asher niddchu sham*—returned refugees.

"To sojourn in the land of Judah."

*Lagur be-eretz Yehudah*—had sojourned.

"The men, and the women, and the children, and the king's daughters."

*Et-ha-gevarim ve-et-ha-nashim ve-et-ha-taf ve-et-benot ha-melekh*—all groups.

"Every person that Nebuzaradan the captain of the guard had left with Gedaliah."

*Ve-et kol-ha-nefesh asher hinnich Nevuzar'adan rav-tabbachim et-Gedalyahu*—Nebuzaradan's trust.

"Jeremiah the prophet, and Baruch the son of Neriah."

*Ve-et Yirmeyahu ha-navi ve-et Barukh ben-Neriyyah*—forced to go.

**The Key Verse (43:7):**
"They came into the land of Egypt."

*Va-yavo'u eretz Mitzrayim*—came to Egypt.

"For they hearkened not to the voice of YHWH."

*Ki lo sham'u be-qol YHWH*—didn't hear.

"They came even to Tahpanhes."

*Va-yavo'u ad-Tachpancheis*—to Tahpanhes.

**Tahpanhes:**
A fortress city in the eastern Nile Delta (modern Tell Defenneh).

**Sign at Tahpanhes (43:8-13):**
"The word of YHWH came unto Jeremiah in Tahpanhes."

*Va-yehi devar-YHWH el-Yirmeyahu be-Tachpancheis*—word came.

**The Key Verse (43:9):**
"'Take great stones in your hand.'"

*Qach be-yadekha avanim gedolot*—take large stones.

"'Hide them in the mortar in the framework.'"

*U-temantam ba-melet ba-malben*—hide in mortar.

"'Which is at the entry of Pharaoh's house in Tahpanhes.'"

*Asher be-petach beit-Par'oh be-Tachpancheis*—at Pharaoh's palace.

"'In the sight of the men of Judah.'"

*Le-einei anashim Yehudim*—before Jews.

**The Key Verse (43:10):**
"'Thus says YHWH of hosts, the God of Israel.'"

*Koh-amar YHWH Tzeva'ot Elohei Yisra'el*—YHWH says.

"'Behold, I will send and take Nebuchadrezzar the king of Babylon, my servant.'"

*Hineni sholeach ve-laqachti et-Nevukhadre'zzar melekh-Bavel avdi*—send Nebuchadnezzar.

"'Will set his throne upon these stones that I have hid.'"

*Ve-samti kis'o mi-ma'al la-avanim ha-elleh asher tamanti*—throne on stones.

"'He shall spread his royal pavilion over them.'"

*Ve-natah et-shafriro aleihem*—royal canopy.

**Nebuchadnezzar in Egypt:**
Historical records confirm Nebuchadnezzar invaded Egypt in 568/567 BCE.

**The Key Verse (43:11):**
"'He shall come, and shall smite the land of Egypt.'"

*U-va ve-hikkah et-eretz Mitzrayim*—smite Egypt.

"'Such as are for death shall be given to death.'"

*Asher la-mavet la-mavet*—death for death.

"'Such as are for captivity to captivity.'"

*Va-asher la-shevi la-shevi*—captivity for captivity.

"'Such as are for the sword to the sword.'"

*Va-asher la-cherev la-cherev*—sword for sword.

**The Key Verse (43:12):**
"'I will kindle a fire in the houses of the gods of Egypt.'"

*Ve-hitztzatti esh be-vattei elohei Mitzrayim*—fire in temples.

"'He shall burn them, and carry them away captives.'"

*U-serafam ve-shavam*—burn and captive.

"'He shall wrap himself with the land of Egypt.'"

*Ve-atah et-eretz Mitzrayim*—wrap Egypt.

"'As a shepherd wraps himself in his garment.'"

*Ka-asher ya'ateh ha-ro'eh et-bigdo*—like shepherd's cloak.

"'He shall go forth from there in peace.'"

*Ve-yatza mi-sham be-shalom*—leave in peace.

**The Key Verse (43:13):**
"'He shall also break the pillars of Beth-shemesh.'"

*Ve-shibbar et-matztzevot Beit-Shemesh*—break obelisks.

"'That is in the land of Egypt.'"

*Asher be-eretz Mitzrayim*—in Egypt.

"'The houses of the gods of Egypt shall he burn with fire.'"

*Ve-et-battei elohei Mitzrayim yisrof ba-esh*—burn temples.

**Beth-shemesh:**
"House of the Sun" = Heliopolis (On), the sun-god temple with famous obelisks.

**Archetypal Layer:** Jeremiah 43 contains **the accusation that Baruch manipulated Jeremiah (43:3)**, **the forced journey to Egypt against YHWH's command (43:4-7)**, and **the sign of the stones predicting Nebuchadnezzar's invasion of Egypt (43:9-13)**.

**Ethical Inversion Applied:**
- "When Jeremiah had made an end of speaking... all the words of YHWH"—finished
- "Azariah... and Johanan... and all the proud men"—accusers
- "'You speak falsely'"—called liar
- "'YHWH our God has not sent you'"—denied commission
- "'Baruch the son of Neriah sets you on against us'"—blamed Baruch
- "'To deliver us into the hand of the Chaldeans'"—accused
- "'That they may put us to death'"—accused
- "Johanan... and all the captains... and all the people, hearkened not"—didn't hear
- "To dwell in the land of Judah"—refused
- "Johanan... took all the remnant of Judah"—took remnant
- "The men, and the women, and the children, and the king's daughters"—all groups
- "Jeremiah the prophet, and Baruch the son of Neriah"—forced along
- "They came into the land of Egypt"—came to Egypt
- "For they hearkened not to the voice of YHWH"—didn't hear
- "They came even to Tahpanhes"—Tahpanhes
- "'Take great stones in your hand'"—sign-act
- "'Hide them in the mortar in the framework'"—hide stones
- "'At the entry of Pharaoh's house in Tahpanhes'"—palace entry
- "'In the sight of the men of Judah'"—before Jews
- "'I will send and take Nebuchadrezzar the king of Babylon, my servant'"—send Babylon
- "'Will set his throne upon these stones'"—throne on stones
- "'He shall spread his royal pavilion over them'"—royal canopy
- "'He shall come, and shall smite the land of Egypt'"—smite Egypt
- "'Such as are for death... for captivity... for the sword'"—fate categories
- "'I will kindle a fire in the houses of the gods of Egypt'"—temple fire
- "'He shall burn them, and carry them away captives'"—burn, captive
- "'He shall wrap himself with the land of Egypt'"—wrap like garment
- "'As a shepherd wraps himself in his garment'"—shepherd image
- "'He shall go forth from there in peace'"—Babylon victorious
- "'He shall also break the pillars of Beth-shemesh'"—obelisks broken
- "'The houses of the gods of Egypt shall he burn with fire'"—temples burned

**Modern Equivalent:** Jeremiah 43 shows the tragic disobedience. Despite swearing to obey (42:5-6), they accused Jeremiah of lying and blamed Baruch. Jeremiah and Baruch were forced to Egypt. The buried stones (43:9) mark the site of Babylon's future conquest—judgment follows even to Egypt.

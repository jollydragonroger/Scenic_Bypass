# Jeremiah 6: The Siege of Jerusalem

*From the Hebrew: הֵעִזוּ בְּנֵי בִנְיָמִן (He'izu Benei Vinyamin) — Flee for Safety, O Children of Benjamin*

---

## Warning of Invasion (6:1-8)

**6:1** "Flee for safety, O children of Benjamin, out of the midst of Jerusalem, and blow the horn in Tekoa, and set up a signal on Beth-cherem; for evil looks forth from the north, and great destruction.

**6:2** "The comely and delicate one, the daughter of Zion, will I cut off.

**6:3** "Shepherds with their flocks come unto her; they pitch their tents against her round about; they feed, every one in his place."

**6:4** "Prepare war against her; arise, and let us go up at noon." "Woe unto us! For the day declines, for the shadows of the evening are stretched out."

**6:5** "Arise, and let us go up by night, and let us destroy her palaces."

**6:6** For thus has YHWH of hosts said: "Hew down her trees, and cast up a mound against Jerusalem; this is the city to be punished; she is full of oppression in her midst.

**6:7** "As a cistern wells with her waters, so she wells with her wickedness; violence and spoil is heard in her; before me continually is sickness and wounds.

**6:8** "Be corrected, O Jerusalem, lest my soul be alienated from you, lest I make you desolate, a land not inhabited."

---

## Total Corruption (6:9-15)

**6:9** Thus says YHWH of hosts: "They shall thoroughly glean as a vine the remnant of Israel; turn again your hand as a grape-gatherer over the shoots."

**6:10** To whom shall I speak and give warning, that they may hear? Behold, their ear is uncircumcised, and they cannot attend; behold, the word of YHWH is become unto them a reproach, they have no delight in it.

**6:11** Therefore I am full of the fury of YHWH, I am weary with holding in: "Pour it out upon the babes in the street, and upon the assembly of young men together; for even the husband with the wife shall be taken, the aged with him that is full of days.

**6:12** "And their houses shall be turned unto others, their fields and their wives together; for I will stretch out my hand upon the inhabitants of the land," says YHWH.

**6:13** "For from the least of them even unto the greatest of them, every one is greedy for gain; and from the prophet even unto the priest, every one deals falsely.

**6:14** "They have healed also the hurt of my people lightly, saying: 'Peace, peace,' when there is no peace.

**6:15** "They were put to shame because they had committed abomination; yet they were not at all ashamed, neither could they blush; therefore they shall fall among them that fall; at the time that I punish them they shall stumble," says YHWH.

---

## Rejection of the Ancient Paths (6:16-21)

**6:16** Thus says YHWH: "Stand in the ways and see, and ask for the ancient paths, where is the good way, and walk therein, and you shall find rest for your souls." But they said: "We will not walk therein."

**6:17** "And I set watchmen over you: 'Attend to the sound of the horn.' But they said: 'We will not attend.'"

**6:18** Therefore hear, you nations, and know, O congregation, what is against them.

**6:19** Hear, O earth: Behold, I will bring evil upon this people, even the fruit of their thoughts, because they have not attended unto my words, and as for my teaching, they have rejected it.

**6:20** To what purpose comes there to me frankincense from Sheba, and the sweet cane from a far country? Your burnt-offerings are not acceptable, nor your sacrifices pleasing unto me.

**6:21** Therefore thus says YHWH: "Behold, I will lay stumbling-blocks before this people, and the fathers and the sons together shall stumble against them, the neighbour and his friend, and they shall perish."

---

## The Enemy from the North (6:22-26)

**6:22** Thus says YHWH: "Behold, a people comes from the north country, and a great nation shall be roused from the uttermost parts of the earth.

**6:23** "They lay hold on bow and spear, they are cruel, and have no compassion; their voice roars like the sea, and they ride upon horses; everyone set in array, as a man to battle, against you, O daughter of Zion."

**6:24** "We have heard the fame thereof, our hands wax feeble, anguish has taken hold of us, and pain, as of a woman in travail."

**6:25** Go not forth into the field, nor walk by the way; for there is the sword of the enemy, and terror on every side.

**6:26** O daughter of my people, gird yourself with sackcloth, and wallow yourself in ashes; make mourning, as for an only son, most bitter lamentation; for the spoiler shall suddenly come upon us.

---

## The Assayer of the People (6:27-30)

**6:27** "I have made you a tower and a fortress among my people, that you may know and try their way."

**6:28** They are all grievous revolters, going about with slanders; they are brass and iron; they all deal corruptly.

**6:29** The bellows blow fiercely, the lead is consumed of the fire; in vain does the founder refine, for the wicked are not separated.

**6:30** Refuse silver shall men call them, because YHWH has rejected them.

---

## Synthesis Notes

**Key Restorations:**

**Invasion Warning (6:1-5):**
"Flee for safety, O children of Benjamin."

*He'izu benei Vinyamin mi-qerev Yerushalayim*—Benjamin flees.

"Blow the horn in Tekoa."

*U-vi-Teqoa tiq'u shofar*—Tekoa horn.

"Set up a signal on Beth-cherem."

*Ve-al Beit ha-Kerem se'u mas'et*—Beth-cherem signal.

"Evil looks forth from the north."

*Ki ra'ah nishqafah mi-tzafon*—north evil.

"Great destruction."

*Ve-shever gadol*—great destruction.

"The comely and delicate one, the daughter of Zion, will I cut off."

*Ha-navah ve-ha-me'unnagah damiti bat-Tziyyon*—daughter Zion cut off.

"Shepherds with their flocks come unto her."

*Elekha yavo'u ro'im ve-edreihem*—shepherd-armies.

"They pitch their tents against her round about."

*Taq'u alekha ohalim saviv*—tents pitched.

"'Prepare war against her.'"

*Qaddeshu alekha milchamah*—war prepared.

"'Woe unto us! For the day declines.'"

*Oy lanu ki-fanah ha-yom*—woe, day declines.

**The Key Verses (6:6-8):**
"Hew down her trees, and cast up a mound against Jerusalem."

*Kirttu etzah ve-shifkhu al-Yerushalayim solelah*—siege mound.

"This is the city to be punished."

*Hi ha-ir hofdad*—city to be punished.

"She is full of oppression in her midst."

*Kullakh osheq be-qirbah*—full of oppression.

"As a cistern wells with her waters, so she wells with her wickedness."

*Ke-haqer bor meimekha ken heqerah ra'atah*—wickedness wells up.

"Violence and spoil is heard in her."

*Chamas va-shod yishama vah*—violence heard.

"Before me continually is sickness and wounds."

*Al-panai tamid choli u-makkah*—sickness/wounds.

**The Key Verse (6:8):**
"Be corrected, O Jerusalem."

*Hivvaseri Yerushalayim*—be corrected.

"Lest my soul be alienated from you."

*Pen-tiqa nafshi mimmekk*—soul alienated.

"Lest I make you desolate, a land not inhabited."

*Pen-asimekk shemamah eretz lo noshavah*—uninhabited desolation.

**Total Corruption (6:9-15):**
"They shall thoroughly glean as a vine the remnant of Israel."

*Olel ye'olelu ki-gefen she'erit Yisra'el*—thorough gleaning.

**The Key Verse (6:10):**
"To whom shall I speak and give warning, that they may hear?"

*Al-mi adabbera ve-a'idah ve-yishma'u*—who will hear?

"Their ear is uncircumcised."

*Hinneh arelah oznam*—uncircumcised ear.

"They cannot attend."

*Ve-lo yukhelu le-haqshiv*—can't attend.

"The word of YHWH is become unto them a reproach."

*Hinneh devar-YHWH hayah lahem le-cherpah*—word = reproach.

"They have no delight in it."

*Lo yachpetzu-vo*—no delight.

"I am full of the fury of YHWH."

*Ve-et chamat YHWH maleiti*—full of YHWH's fury.

"I am weary with holding in."

*Nil'eiti hakil*—weary holding.

**The Key Verses (6:13-14):**
"From the least of them even unto the greatest of them, every one is greedy for gain."

*Ki mi-qetannam ve-ad-gedolam kullo botzea batza*—all greedy.

"From the prophet even unto the priest, every one deals falsely."

*U-mi-navi ve-ad-kohen kullo oseh shaqer*—all deal falsely.

**The Key Verse (6:14):**
"They have healed also the hurt of my people lightly."

*Va-yerape'u et-shever ammi al-neqallah*—lightly healed.

"Saying: 'Peace, peace,' when there is no peace."

*Lemor shalom shalom ve-ein shalom*—false peace.

**The Key Verse (6:15):**
"They were put to shame because they had committed abomination."

*Hovishu ki to'evah asu*—shamed by abomination.

"Yet they were not at all ashamed."

*Gam-bosh lo-yevoshu*—not ashamed.

"Neither could they blush."

*Ve-hakhlim lo yada'u*—can't blush.

**Ancient Paths (6:16-21):**
**The Key Verse (6:16):**
"Stand in the ways and see."

*Imdu al-derakhim u-re'u*—stand at crossroads.

"Ask for the ancient paths."

*Ve-sha'alu li-netivot olam*—ask for ancient paths.

"Where is the good way."

*Ei-zeh derekh ha-tov*—where is good way.

"Walk therein."

*U-lekhu-vah*—walk in it.

"You shall find rest for your souls."

*U-mitze'u margo'a le-nafshekhem*—find soul rest.

"But they said: 'We will not walk therein.'"

*Va-yomru lo nelekh*—we won't walk.

**The Key Verse (6:17):**
"I set watchmen over you."

*Va-haqimoti aleikhem tzofim*—watchmen set.

"'Attend to the sound of the horn.'"

*Haqshivu le-qol shofar*—attend to horn.

"But they said: 'We will not attend.'"

*Va-yomru lo naqshiv*—we won't attend.

"I will bring evil upon this people, even the fruit of their thoughts."

*Hineni mevi el-ha-am ha-zeh ra'ah peri machshevotam*—fruit of thoughts.

"They have not attended unto my words."

*Ki al-devarai lo-hiqshivu*—didn't attend.

"My teaching, they have rejected it."

*Ve-torati va-yim'asu-vah*—teaching rejected.

**Ritual Rejected (6:20):**
"To what purpose comes there to me frankincense from Sheba?"

*Lammah-zeh li levonah mi-Sheva tavo*—why frankincense?

"The sweet cane from a far country?"

*Ve-qaneh ha-tov me-eretz merchaq*—sweet cane.

"Your burnt-offerings are not acceptable."

*Oloteikhem lo le-ratzon*—offerings unacceptable.

"Nor your sacrifices pleasing unto me."

*Ve-zivchekhem lo-arevu li*—sacrifices not pleasing.

**Enemy Description (6:22-26):**
"A people comes from the north country."

*Am ba me-eretz tzafon*—north country.

"A great nation shall be roused from the uttermost parts of the earth."

*Ve-goy gadol ye'or mi-yarketei-aretz*—great nation roused.

"They lay hold on bow and spear."

*Qeshet ve-khidon yachaziquu*—bow and spear.

"They are cruel, and have no compassion."

*Akhzari hu ve-lo yerachamuu*—cruel, no compassion.

"Their voice roars like the sea."

*Qolam ka-yam yehemeh*—sea-roar voice.

"They ride upon horses."

*Ve-al-susim yirkavu*—horseback.

"Everyone set in array, as a man to battle."

*Arukh ke-ish la-milchamah*—battle-ready.

"Against you, O daughter of Zion."

*Alayikh bat-Tziyyon*—against Zion.

"'We have heard the fame thereof, our hands wax feeble.'"

*Shama'nu shim'o raffu yadeinu*—fame heard, hands feeble.

"'Anguish has taken hold of us, and pain, as of a woman in travail.'"

*Tzarah hecheziqatnu chil ka-yoledah*—travail anguish.

"Go not forth into the field."

*Al-tetze'i ha-sadeh*—don't go to field.

"There is the sword of the enemy, and terror on every side."

*Ki cherev le-oyev magor mi-saviv*—sword, terror around.

**The Key Verse (6:26):**
"O daughter of my people, gird yourself with sackcloth."

*Bat-ammi chigri-saq*—sackcloth.

"Wallow yourself in ashes."

*Ve-hitpallshi va-efer*—roll in ashes.

"Make mourning, as for an only son."

*Evel yachid asi lakh*—only son mourning.

"Most bitter lamentation."

*Misped tamrurim*—bitter lamentation.

"The spoiler shall suddenly come upon us."

*Ki pitom yavo ha-shoded aleinu*—sudden spoiler.

**Assayer (6:27-30):**
"I have made you a tower and a fortress among my people."

*Bachan netattikha be-ammi mivtzar*—tower among people.

"That you may know and try their way."

*Ve-teda u-vachanta et-darkkam*—know and try.

"They are all grievous revolters."

*Kullam sarei sorerim*—all rebellious.

"Going about with slanders."

*Holekhei rakhil*—slanderers.

"They are brass and iron."

*Nechoshet u-varzel*—brass and iron.

"They all deal corruptly."

*Kullam mashchitim*—all corrupt.

**The Key Verses (6:29-30):**
"The bellows blow fiercely."

*Nachar mappu'ach*—bellows blow.

"The lead is consumed of the fire."

*Me-esh tam ofarett*—lead consumed.

"In vain does the founder refine."

*La-shav tzaraf tzarof*—vain refining.

"For the wicked are not separated."

*Ve-ra'im lo nittaqu*—wicked not separated.

"Refuse silver shall men call them."

*Kesef nim'as qare'u lahem*—refuse silver.

"Because YHWH has rejected them."

*Ki-ma'as YHWH bahem*—YHWH rejected.

**Archetypal Layer:** Jeremiah 6 contains **"'Peace, peace,' when there is no peace" (6:14)**, **"Ask for the ancient paths... you shall find rest for your souls" (6:16)**, and **"Refuse silver shall men call them, because YHWH has rejected them" (6:30)**.

**Ethical Inversion Applied:**
- "Flee for safety, O children of Benjamin"—flee command
- "Evil looks forth from the north"—north evil
- "She is full of oppression in her midst"—oppression
- "Violence and spoil is heard in her"—violence heard
- "Be corrected, O Jerusalem"—correction plea
- "Lest my soul be alienated from you"—alienation warning
- "Their ear is uncircumcised"—uncircumcised ear
- "The word of YHWH is become unto them a reproach"—word = reproach
- "From the least... even unto the greatest... every one is greedy for gain"—universal greed
- "From the prophet even unto the priest, every one deals falsely"—universal falsehood
- "'Peace, peace,' when there is no peace"—false peace
- "They were not at all ashamed, neither could they blush"—shameless
- "Stand in the ways and see, and ask for the ancient paths"—ancient paths
- "Where is the good way, and walk therein"—good way
- "You shall find rest for your souls"—soul rest
- "'We will not walk therein'"—refusal
- "I set watchmen over you"—watchmen
- "'We will not attend'"—refused attention
- "To what purpose comes there to me frankincense from Sheba?"—ritual rejected
- "Your burnt-offerings are not acceptable"—unacceptable offerings
- "They are cruel, and have no compassion"—cruel enemy
- "Terror on every side"—terror around
- "The spoiler shall suddenly come upon us"—sudden spoiler
- "I have made you a tower and a fortress"—Jeremiah as assayer
- "In vain does the founder refine"—vain refining
- "Refuse silver shall men call them"—rejected as refuse

**Modern Equivalent:** Jeremiah 6:14's "'Peace, peace,' when there is no peace" is repeated in 8:11 and Ezekiel 13:10. "Ask for the ancient paths... you shall find rest for your souls" (6:16) is one of Jeremiah's most quoted verses. The refining imagery (6:27-30) shows judgment failing to purify.

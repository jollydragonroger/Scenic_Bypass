# Jeremiah 39: The Fall of Jerusalem

*From the Hebrew: בַּשָּׁנָה הַתְּשִׁעִית (Ba-Shanah Ha-Teshi'it) — In the Ninth Year*

---

## Jerusalem Falls (39:1-10)

**39:1** In the ninth year of Zedekiah king of Judah, in the tenth month, came Nebuchadrezzar king of Babylon and all his army against Jerusalem, and besieged it;

**39:2** In the eleventh year of Zedekiah, in the fourth month, the ninth day of the month, a breach was made in the city—

**39:3** That all the princes of the king of Babylon came in, and sat in the middle gate, even Nergal-sarezer, Samgar-nebo, Sarsechim Rab-saris, Nergal-sarezer Rab-mag, with all the rest of the princes of the king of Babylon.

**39:4** And it came to pass, that when Zedekiah the king of Judah and all the men of war saw them, they fled, and went forth out of the city by night, by the way of the king's garden, by the gate between the two walls; and he went out the way of the Arabah.

**39:5** But the army of the Chaldeans pursued after them, and overtook Zedekiah in the plains of Jericho; and when they had taken him, they brought him up to Nebuchadnezzar king of Babylon to Riblah in the land of Hamath, and he gave judgment upon him.

**39:6** Then the king of Babylon slew the sons of Zedekiah in Riblah before his eyes; also the king of Babylon slew all the nobles of Judah.

**39:7** Moreover he put out Zedekiah's eyes, and bound him in fetters, to carry him to Babylon.

**39:8** And the Chaldeans burned the king's house, and the houses of the people, with fire, and broke down the walls of Jerusalem.

**39:9** Then Nebuzaradan the captain of the guard carried away captive into Babylon the remnant of the people that remained in the city, the deserters also, that fell away to him, with the rest of the people that remained.

**39:10** But Nebuzaradan the captain of the guard left of the poor of the people, that had nothing, in the land of Judah, and gave them vineyards and fields in that day.

---

## Jeremiah Released (39:11-14)

**39:11** Now Nebuchadrezzar king of Babylon gave charge concerning Jeremiah to Nebuzaradan the captain of the guard, saying:

**39:12** "Take him, and look well to him, and do him no harm; but do unto him even as he shall say unto you."

**39:13** So Nebuzaradan the captain of the guard sent, and Nebushasban Rab-saris, and Nergal-sarezer Rab-mag, and all the chief officers of the king of Babylon;

**39:14** They sent, and took Jeremiah out of the court of the guard, and committed him unto Gedaliah the son of Ahikam, the son of Shaphan, that he should carry him home; so he dwelt among the people.

---

## Promise to Ebed-melech (39:15-18)

**39:15** Now the word of YHWH came unto Jeremiah, while he was shut up in the court of the guard, saying:

**39:16** "Go, and speak to Ebed-melech the Cushite, saying: Thus says YHWH of hosts, the God of Israel: Behold, I will bring my words upon this city for evil, and not for good; and they shall be accomplished before you in that day.

**39:17** "But I will deliver you in that day," says YHWH; "and you shall not be given into the hand of the men of whom you are afraid.

**39:18** "For I will surely deliver you, and you shall not fall by the sword, but your life shall be for a prey unto you; because you have put your trust in me," says YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Siege Timeline (39:1-2):**
"In the ninth year of Zedekiah... in the tenth month."

*Ba-shanah ha-teshi'it li-Tzidqiyyahu melekh-Yehudah ba-chodesh ha-asiri*—January 588 BCE.

"Came Nebuchadrezzar king of Babylon and all his army against Jerusalem."

*Ba Nevukhadre'zzar melekh-Bavel ve-khol-cheilo el-Yerushalayim*—siege begins.

"And besieged it."

*Va-yatzuru alekha*—besieged.

"In the eleventh year of Zedekiah, in the fourth month, the ninth day."

*Be-ashtei-esreh shanah li-Tzidqiyyahu ba-chodesh ha-revi'i be-tish'ah la-chodesh*—July 586 BCE.

"A breach was made in the city."

*Huvqe'ah ha-ir*—wall breached.

**18-Month Siege:**
From January 588 to July 586 BCE—18 months of siege.

**Babylonian Officials (39:3):**
"All the princes of the king of Babylon came in."

*Va-yavo'u kol-sarei melekh-Bavel*—princes entered.

"Sat in the middle gate."

*Va-yeshvu be-sha'ar ha-tavekh*—middle gate.

"Nergal-sarezer, Samgar-nebo, Sarsechim Rab-saris, Nergal-sarezer Rab-mag."

*Nergal Sar'etzer Samgar-Nevu Sarsekhim Rav-Saris Nergal Sar'etzer Rav-Mag*—officials.

**Babylonian Titles:**
*Rab-saris* = chief eunuch; *Rab-mag* = chief mage/official.

**Zedekiah's Flight (39:4-5):**
"When Zedekiah the king of Judah and all the men of war saw them."

*Va-yehi ka-asher ra'am Tzidqiyyahu melekh-Yehudah ve-khol anshei ha-milchamah*—when saw.

"They fled, and went forth out of the city by night."

*Va-yivrechu va-yetz'u laylah min-ha-ir*—fled by night.

"By the way of the king's garden."

*Derekh gan ha-melekh*—king's garden.

"By the gate between the two walls."

*Be-sha'ar bein ha-chomotayim*—between walls.

"He went out the way of the Arabah."

*Va-yetze derekh ha-Aravah*—toward Jordan Valley.

"The army of the Chaldeans pursued after them."

*Va-yirdefu cheil-Kasdim achareihem*—pursued.

"Overtook Zedekiah in the plains of Jericho."

*Va-yasssigu et-Tzidqiyyahu be-arvot Yericho*—caught at Jericho.

"Brought him up to Nebuchadnezzar king of Babylon to Riblah."

*Va-ya'alu oto el-Nevukhadnetztzar melekh-Bavel Rivlatah*—to Riblah.

"In the land of Hamath."

*Be-eretz Chamat*—Hamath (Syria).

"He gave judgment upon him."

*Va-yedabber itto mishpattim*—judged.

**Zedekiah's Fate (39:6-7):**
"The king of Babylon slew the sons of Zedekiah in Riblah before his eyes."

*Va-yishchat melekh-Bavel et-benei Tzidqiyyahu be-Rivlah le-einav*—sons killed.

"Also the king of Babylon slew all the nobles of Judah."

*Ve-et kol-chorei Yehudah shachat melekh-Bavel*—nobles killed.

**The Key Verse (39:7):**
"Moreover he put out Zedekiah's eyes."

*Ve-et-einei Tzidqiyyahu ivver*—blinded.

"Bound him in fetters."

*Va-ya'asrehu ba-nechushtayim*—bronze fetters.

"To carry him to Babylon."

*Le-havi oto Bavelah*—to Babylon.

**Fulfilled Prophecy:**
- Jeremiah said: "Your eyes shall behold the king of Babylon's eyes" (34:3)—fulfilled at Riblah.
- Ezekiel said: "I will bring him to Babylon... yet shall he not see it" (Ezekiel 12:13)—blinded, didn't see Babylon.

**Jerusalem Destroyed (39:8-10):**
"The Chaldeans burned the king's house, and the houses of the people."

*Ve-et-beit ha-melekh ve-et-beit ha-am sarefu ha-Kasdim ba-esh*—burned.

"Broke down the walls of Jerusalem."

*Ve-et-chomot Yerushalayim natzu*—walls broken.

"Nebuzaradan the captain of the guard."

*Nevuzar'adan rav-tabbachim*—Nebuzaradan.

"Carried away captive into Babylon the remnant of the people."

*Hegelah Bavel et-yeter ha-am*—exiled remnant.

"The deserters also, that fell away to him."

*Ve-et-ha-nofelim asher naflu alav*—deserters too.

"The rest of the people that remained."

*Ve-et yeter ha-am ha-nish'arim*—rest.

**The Key Verse (39:10):**
"Nebuzaradan the captain of the guard left of the poor of the people."

*U-min-ha-am ha-dallim asher ein-lahem me'umah hish'ir Nevuzar'adan rav-tabbachim*—left poor.

"That had nothing, in the land of Judah."

*Be-eretz Yehudah*—in Judah.

"Gave them vineyards and fields in that day."

*Va-yitten lahem keramim ve-yegevim ba-yom ha-hu*—gave land.

**Land Redistribution:**
The landless poor received property—a reversal.

**Jeremiah Released (39:11-14):**
"Nebuchadrezzar king of Babylon gave charge concerning Jeremiah."

*Va-yetzav Nevukhadre'zzar melekh-Bavel al-Yirmeyahu*—charge concerning Jeremiah.

"To Nebuzaradan the captain of the guard."

*Be-yad Nevuzar'adan rav-tabbachim*—to Nebuzaradan.

**The Key Verse (39:12):**
"'Take him, and look well to him.'"

*Qachenu ve-einekha sim alav*—take, watch.

"'Do him no harm.'"

*Ve-al-ta'as lo me'umah ra*—no harm.

"'Do unto him even as he shall say unto you.'"

*Ki im-ka-asher yedabber elekha ken aseh immo*—as he says.

**Nebuchadnezzar's Protection:**
The Babylonian king protected Jeremiah—likely knew of his pro-surrender prophecies.

"Nebuzaradan the captain of the guard sent."

*Va-yishlach Nevuzar'adan rav-tabbachim*—sent officials.

"Nebushasban Rab-saris, and Nergal-sarezer Rab-mag."

*Ve-Nevushazban Rav-Saris ve-Nergal Sar'etzer Rav-Mag*—officials.

"All the chief officers of the king of Babylon."

*Ve-khol ravvei melekh Bavel*—all chiefs.

"They sent, and took Jeremiah out of the court of the guard."

*Va-yishlchu va-yiqqu et-Yirmeyahu me-chatzer ha-mattarah*—took from court.

"Committed him unto Gedaliah the son of Ahikam."

*Va-yittenu oto el-Gedalyahu ben-Achiqam*—to Gedaliah.

"The son of Shaphan."

*Ben-Shafan*—Shaphan's grandson.

"That he should carry him home."

*Le-hotzi'o el-ha-bayit*—bring home.

"So he dwelt among the people."

*Va-yeshev be-tokh ha-am*—dwelt among people.

**Ahikam's Son:**
Gedaliah was son of Ahikam who saved Jeremiah (26:24). The Shaphan family consistently supported Jeremiah.

**Promise to Ebed-melech (39:15-18):**
"The word of YHWH came unto Jeremiah, while he was shut up in the court of the guard."

*Va-yehi devar-YHWH el-Yirmeyahu bi-heyoto atzur ba-chatzer ha-mattarah*—while imprisoned.

"'Go, and speak to Ebed-melech the Cushite.'"

*Halokh ve-amarta le-Eved-Melekh ha-Kushi*—speak to Ebed-melech.

"'Behold, I will bring my words upon this city for evil, and not for good.'"

*Hineni mevi et-devarai el-ha-ir ha-zot le-ra'ah ve-lo le-tovah*—evil on city.

"'They shall be accomplished before you in that day.'"

*Ve-hayu lefanekha ba-yom ha-hu*—before you that day.

**The Key Verses (39:17-18):**
"'But I will deliver you in that day,' says YHWH."

*Ve-hitztzaltikha va-yom ha-hu*—deliver you.

"'You shall not be given into the hand of the men of whom you are afraid.'"

*Ve-lo tinnaten be-yad ha-anashim asher-attah yagor mippeneihem*—not to feared men.

**The Key Verse (39:18):**
"'For I will surely deliver you.'"

*Ki mallet amalletekha*—surely deliver.

"'You shall not fall by the sword.'"

*U-va-cherev lo tippol*—not by sword.

"'Your life shall be for a prey unto you.'"

*Ve-hayetah lekha nafshekha le-shalal*—life as plunder.

"'Because you have put your trust in me,' says YHWH."

*Ki-vatachta vi*—because you trusted.

**Reward for Trust:**
Ebed-melech's rescue of Jeremiah (38:7-13) is rewarded with personal deliverance.

**Archetypal Layer:** Jeremiah 39 contains **the fall of Jerusalem (39:2)**, **Zedekiah's sons slain and his eyes put out (39:6-7)**, **Jeremiah released and protected by Babylon (39:11-14)**, and **Ebed-melech's reward for trusting YHWH (39:18)**.

**Ethical Inversion Applied:**
- "In the ninth year of Zedekiah... in the tenth month"—January 588
- "Came Nebuchadrezzar king of Babylon and all his army"—siege begins
- "In the eleventh year of Zedekiah, in the fourth month"—July 586
- "A breach was made in the city"—wall breached
- "All the princes of the king of Babylon came in"—entered
- "Sat in the middle gate"—occupied
- "When Zedekiah the king of Judah and all the men of war saw them"—saw
- "They fled, and went forth out of the city by night"—fled
- "By the way of the king's garden"—escape route
- "He went out the way of the Arabah"—toward Jordan
- "The army of the Chaldeans pursued after them"—pursued
- "Overtook Zedekiah in the plains of Jericho"—caught
- "Brought him up to Nebuchadnezzar... to Riblah"—to king
- "He gave judgment upon him"—judged
- "The king of Babylon slew the sons of Zedekiah... before his eyes"—sons killed
- "Slew all the nobles of Judah"—nobles killed
- "He put out Zedekiah's eyes"—blinded
- "Bound him in fetters, to carry him to Babylon"—to Babylon
- "The Chaldeans burned the king's house, and the houses of the people"—burned
- "Broke down the walls of Jerusalem"—walls broken
- "Nebuzaradan... carried away captive... the remnant"—exiled
- "Left of the poor of the people, that had nothing"—poor left
- "Gave them vineyards and fields"—land given
- "Nebuchadrezzar king of Babylon gave charge concerning Jeremiah"—protected
- "'Take him, and look well to him, and do him no harm'"—care for
- "'Do unto him even as he shall say unto you'"—honor
- "They... took Jeremiah out of the court of the guard"—freed
- "Committed him unto Gedaliah the son of Ahikam"—to Gedaliah
- "He dwelt among the people"—free
- "'Go, and speak to Ebed-melech the Cushite'"—Ebed-melech message
- "'I will bring my words upon this city for evil'"—evil coming
- "'But I will deliver you in that day'"—deliver
- "'You shall not be given into the hand of the men of whom you are afraid'"—protected
- "'Your life shall be for a prey unto you'"—life as plunder
- "'Because you have put your trust in me'"—trust rewarded

**Modern Equivalent:** Jeremiah 39 records the fulfillment of Jeremiah's prophecies. The detailed chronology (39:1-2) matches 2 Kings 25 and Jeremiah 52. Ebed-melech's reward (39:17-18) shows individual faith matters amid national judgment.

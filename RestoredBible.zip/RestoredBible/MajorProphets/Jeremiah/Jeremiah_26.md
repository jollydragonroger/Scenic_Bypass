# Jeremiah 26: The Temple Sermon and Jeremiah's Trial

*From the Hebrew: בְּרֵאשִׁית מַמְלֶכֶת יְהוֹיָקִים (Be-Reshit Mamlekhet Yehoyaqim) — In the Beginning of the Reign of Jehoiakim*

---

## The Temple Sermon (26:1-6)

**26:1** In the beginning of the reign of Jehoiakim the son of Josiah, king of Judah, came this word from YHWH, saying:

**26:2** "Thus says YHWH: Stand in the court of YHWH's house, and speak unto all the cities of Judah, which come to worship in YHWH's house, all the words that I command you to speak unto them; diminish not a word.

**26:3** "Peradventure they will hearken, and turn every man from his evil way; that I may repent of the evil, which I purpose to do unto them because of the evil of their doings.

**26:4** "And you shall say unto them: Thus says YHWH: If you will not hearken to me, to walk in my law, which I have set before you,

**26:5** "To hearken to the words of my servants the prophets, whom I send unto you, even sending them betimes and often, but you have not hearkened;

**26:6** "Then will I make this house like Shiloh, and will make this city a curse to all the nations of the earth."

---

## The Arrest (26:7-11)

**26:7** And the priests and the prophets and all the people heard Jeremiah speaking these words in the house of YHWH.

**26:8** And it came to pass, when Jeremiah had made an end of speaking all that YHWH had commanded him to speak unto all the people, that the priests and the prophets and all the people laid hold on him, saying: "You shall surely die.

**26:9** "Why have you prophesied in the name of YHWH, saying: 'This house shall be like Shiloh, and this city shall be desolate, without an inhabitant'?" And all the people were gathered against Jeremiah in the house of YHWH.

**26:10** When the princes of Judah heard these things, they came up from the king's house unto the house of YHWH; and they sat in the entry of the new gate of YHWH's house.

**26:11** Then spoke the priests and the prophets unto the princes and to all the people, saying: "This man is worthy of death; for he has prophesied against this city, as you have heard with your ears."

---

## Jeremiah's Defense (26:12-15)

**26:12** Then spoke Jeremiah unto all the princes and to all the people, saying: "YHWH sent me to prophesy against this house and against this city all the words that you have heard.

**26:13** "Therefore now amend your ways and your doings, and hearken to the voice of YHWH your God; and YHWH will repent of the evil that he has pronounced against you.

**26:14** "But as for me, behold, I am in your hand; do with me as is good and right in your eyes.

**26:15** "Only know for certain that, if you put me to death, you will bring innocent blood upon yourselves, and upon this city, and upon the inhabitants thereof; for of a truth YHWH has sent me unto you to speak all these words in your ears."

---

## The Verdict (26:16-19)

**26:16** Then said the princes and all the people unto the priests and to the prophets: "This man is not worthy of death; for he has spoken to us in the name of YHWH our God."

**26:17** Then rose up certain of the elders of the land, and spoke to all the assembly of the people, saying:

**26:18** "Micah the Morashtite prophesied in the days of Hezekiah king of Judah; and he spoke to all the people of Judah, saying: 'Thus says YHWH of hosts: Zion shall be plowed as a field, and Jerusalem shall become heaps, and the mountain of the house as the high places of a forest.'

**26:19** "Did Hezekiah king of Judah and all Judah put him to death? Did he not fear YHWH, and entreat the favour of YHWH, and YHWH repented of the evil which he had pronounced against them? Thus might we procure great evil against our own souls."

---

## The Fate of Uriah (26:20-24)

**26:20** And there was also a man that prophesied in the name of YHWH, Uriah the son of Shemaiah of Kiriath-jearim; and he prophesied against this city and against this land according to all the words of Jeremiah;

**26:21** And when Jehoiakim the king, with all his mighty men, and all the princes, heard his words, the king sought to put him to death; but when Uriah heard it, he was afraid, and fled, and went into Egypt;

**26:22** And Jehoiakim the king sent men into Egypt, Elnathan the son of Achbor, and certain men with him, into Egypt;

**26:23** And they fetched forth Uriah out of Egypt, and brought him unto Jehoiakim the king; who slew him with the sword, and cast his dead body into the graves of the common people.

**26:24** Nevertheless the hand of Ahikam the son of Shaphan was with Jeremiah, that they should not give him into the hand of the people to put him to death.

---

## Synthesis Notes

**Key Restorations:**

**Temple Sermon Setting (26:1-6):**
"In the beginning of the reign of Jehoiakim."

*Be-reshit mamlekhet Yehoyaqim ben-Yoshiyyahu melekh Yehudah*—608/607 BCE.

"Stand in the court of YHWH's house."

*Amod ba-chatzer beit-YHWH*—temple court.

"Speak unto all the cities of Judah."

*Ve-dibbarta el-kol-arei Yehudah*—speak to all.

"Diminish not a word."

*Al-tigra davar*—don't diminish.

**The Key Verse (26:3):**
"Peradventure they will hearken."

*Ulai yishme'u*—perhaps hear.

"Turn every man from his evil way."

*Ve-yashuvu ish mi-darkko ha-ra'ah*—turn from evil.

"That I may repent of the evil, which I purpose to do unto them."

*Ve-nichamti el-ha-ra'ah asher anokhi choshev la'asot lahem*—I may repent.

**Conditional Prophecy:**
Same principle as 18:7-10—judgment can be averted by repentance.

"If you will not hearken to me."

*Im-lo tishme'u elai*—if not hear.

"To walk in my law."

*Lalekhet be-torati*—walk in law.

"To hearken to the words of my servants the prophets."

*Lishmoa al-divrei avadai ha-nevi'im*—hear prophets.

**The Key Verse (26:6):**
"I will make this house like Shiloh."

*Ve-natatti et-ha-bayit ha-zeh ke-Shiloh*—like Shiloh. (Cf. 7:12-14)

"I will make this city a curse to all the nations of the earth."

*Ve-et-ha-ir ha-zot etten li-qelalah le-khol goyei ha-aretz*—curse city.

**Arrest (26:7-11):**
"The priests and the prophets and all the people heard Jeremiah."

*Va-yishme'u ha-kohanim ve-ha-nevi'im ve-khol-ha-am*—all heard.

"They laid hold on him."

*Va-yitpesu oto*—seized.

"'You shall surely die.'"

*Mot tamut*—death sentence.

"'Why have you prophesied... saying: This house shall be like Shiloh?'"

*Maddua nibbeta ve-shem-YHWH lemor ka-Shiloh yihyeh ha-bayit ha-zeh*—why prophesy Shiloh?

"'This city shall be desolate, without an inhabitant.'"

*Ve-ha-ir ha-zot techerav me-ein yoshev*—desolate city.

"All the people were gathered against Jeremiah."

*Va-yiqqahel kol-ha-am el-Yirmeyahu*—gathered against.

"The princes of Judah heard these things."

*Va-yishme'u sarei Yehudah*—princes heard.

"They came up from the king's house."

*Va-ya'alu mi-beit ha-melekh*—came from palace.

"They sat in the entry of the new gate of YHWH's house."

*Va-yeshvu be-petach sha'ar-YHWH he-chadash*—new gate.

"'This man is worthy of death.'"

*Mishpat-mavet la-ish ha-zeh*—death sentence.

"'He has prophesied against this city.'"

*Ki niba el-ha-ir ha-zot*—prophesied against.

**Jeremiah's Defense (26:12-15):**
**The Key Verse (26:12):**
"YHWH sent me to prophesy against this house and against this city."

*YHWH shelachani le-hinnave el-ha-bayit ha-zeh ve-el-ha-ir ha-zot*—YHWH sent.

"All the words that you have heard."

*Et kol-ha-devarim asher shema'tem*—words heard.

**The Key Verse (26:13):**
"Amend your ways and your doings."

*Ve-attah heitivu darkheikhem u-ma'aleleikem*—amend ways.

"Hearken to the voice of YHWH your God."

*Ve-shim'u be-qol YHWH Eloheikhem*—hear YHWH.

"YHWH will repent of the evil that he has pronounced against you."

*Ve-yinnachem YHWH el-ha-ra'ah asher dibber aleikhem*—YHWH will repent.

**The Key Verses (26:14-15):**
"Behold, I am in your hand."

*Va-ani hineni be-yedkhem*—in your hand.

"Do with me as is good and right in your eyes."

*Asu li ka-tov ve-kha-yashar be-eineikhem*—do as you see fit.

"Only know for certain."

*Akh yado'a ted'u*—know certainly.

"If you put me to death."

*Ki im-memittim attem oti*—if kill me.

"You will bring innocent blood upon yourselves."

*Ki dam naqi attem nottenim aleikhem*—innocent blood.

"Upon this city, and upon the inhabitants thereof."

*Ve-el-ha-ir ha-zot ve-el-yoshvekha*—on city.

"Of a truth YHWH has sent me unto you."

*Ki be-emet shelachani YHWH aleikhem*—truly sent.

**Verdict (26:16-19):**
"This man is not worthy of death."

*Ein la-ish ha-zeh mishpat-mavet*—not worthy of death.

"He has spoken to us in the name of YHWH our God."

*Ki be-shem YHWH Eloheinu dibber eleinu*—spoke in YHWH's name.

**Micah Precedent (26:18-19):**
"Micah the Morashtite prophesied in the days of Hezekiah."

*Mikhah ha-Morashtti hayah nibe bi-yemei Chizqiyyahu melekh Yehudah*—Micah prophesied.

"'Thus says YHWH of hosts: Zion shall be plowed as a field.'"

*Koh-amar YHWH Tzeva'ot Tziyyon sadeh techaresh*—Zion plowed.

"'Jerusalem shall become heaps.'"

*Vi-Yerushalayim iyyim tihyeh*—Jerusalem heaps.

"'The mountain of the house as the high places of a forest.'"

*Ve-har ha-bayit le-vamot ya'ar*—temple mount = forest heights.

**Micah 3:12:**
The elders quote Micah 3:12 as precedent—Micah prophesied Jerusalem's destruction, Hezekiah repented, and the city was spared.

"Did Hezekiah king of Judah... put him to death?"

*Ha-hemit hemituhu Chizqiyyahu melekh-Yehudah ve-khol-Yehudah*—did Hezekiah kill?

"Did he not fear YHWH, and entreat the favour of YHWH?"

*Halo yare et-YHWH va-yechal et-penei YHWH*—feared and entreated.

"YHWH repented of the evil which he had pronounced against them."

*Va-yinnachem YHWH el-ha-ra'ah asher-dibber aleihem*—YHWH repented.

"Thus might we procure great evil against our own souls."

*Va-anachnu osim ra'ah gedolah al-nafshoteinu*—we'd do evil.

**Uriah's Fate (26:20-24):**
"Uriah the son of Shemaiah of Kiriath-jearim."

*Uriyyahu ben-Shema'yahu mi-Qiryat-Ye'arim*—Uriah.

"He prophesied against this city and against this land."

*Va-yinnave al-ha-ir ha-zot ve-al-ha-aretz ha-zot*—prophesied against.

"According to all the words of Jeremiah."

*Ke-khol divrei Yirmeyahu*—like Jeremiah.

"The king sought to put him to death."

*Va-yevaqesh ha-melekh hamito*—king sought death.

"Uriah heard it, he was afraid, and fled, and went into Egypt."

*Va-yishma Uriyyahu va-yira va-yivreach va-yavo Mitzrayim*—fled to Egypt.

"Jehoiakim... sent men into Egypt."

*Va-yishlach ha-melekh Yehoyaqim anashim Mitzrayim*—sent to Egypt.

"Elnathan the son of Achbor."

*Et-Elnatan ben-Akhbor*—Elnathan.

"They fetched forth Uriah out of Egypt."

*Va-yotzi'u et-Uriyyahu mi-Mitzrayim*—brought from Egypt.

"Brought him unto Jehoiakim the king."

*Va-yevi'uhu el-ha-melekh Yehoyaqim*—to king.

"Who slew him with the sword."

*Va-yakkehuu ba-cherev*—killed by sword.

"Cast his dead body into the graves of the common people."

*Va-yashlekh et-nivlato el-qivrei benei ha-am*—common graves.

**Contrast:**
Uriah fled and was killed; Jeremiah stood his ground and was saved.

**The Key Verse (26:24):**
"The hand of Ahikam the son of Shaphan was with Jeremiah."

*Akh yad Achiqam ben-Shafan hayetah et-Yirmeyahu*—Ahikam protected.

"That they should not give him into the hand of the people to put him to death."

*Le-vilti tet-oto be-yad-ha-am la-hamito*—not given to people.

**Ahikam:**
Son of Shaphan (Josiah's secretary, 2 Kings 22:12). This family consistently supported Jeremiah.

**Archetypal Layer:** Jeremiah 26 narrates the **temple sermon's consequences (cf. chapter 7)**, **Jeremiah's trial before princes**, **the Micah precedent (26:18-19)**, and **Uriah's contrasting fate (26:20-23)**.

**Ethical Inversion Applied:**
- "Stand in the court of YHWH's house"—temple location
- "Speak... all the words that I command you"—full message
- "Diminish not a word"—don't reduce
- "Peradventure they will hearken, and turn every man from his evil way"—hope
- "That I may repent of the evil"—YHWH may repent
- "I will make this house like Shiloh"—Shiloh threat
- "I will make this city a curse to all the nations"—curse
- "The priests and the prophets and all the people... laid hold on him"—arrested
- "'You shall surely die'"—death threat
- "'Why have you prophesied... This house shall be like Shiloh?'"—charge
- "The princes of Judah heard these things"—princes intervene
- "'This man is worthy of death'"—priests/prophets
- "YHWH sent me to prophesy"—divine commission
- "Amend your ways and your doings"—call to amend
- "YHWH will repent of the evil"—conditional
- "I am in your hand; do with me as is good and right"—submission
- "If you put me to death, you will bring innocent blood"—warning
- "Of a truth YHWH has sent me"—certainty
- "'This man is not worthy of death'"—princes' verdict
- "Micah the Morashtite prophesied... 'Zion shall be plowed'"—Micah precedent
- "Did Hezekiah... put him to death?"—precedent question
- "YHWH repented of the evil"—Hezekiah's example
- "Uriah the son of Shemaiah... prophesied against this city"—parallel prophet
- "The king sought to put him to death"—Jehoiakim's intent
- "He was afraid, and fled, and went into Egypt"—Uriah fled
- "They fetched forth Uriah out of Egypt"—extradited
- "Slew him with the sword, and cast his dead body"—Uriah killed
- "The hand of Ahikam the son of Shaphan was with Jeremiah"—Jeremiah protected

**Modern Equivalent:** Jeremiah 26 shows the political dynamics of prophecy. The elders' use of Micah's precedent (26:18-19) demonstrates early "canon consciousness." The contrast between Uriah (who fled and died) and Jeremiah (who stayed and lived) illustrates faithful witness.

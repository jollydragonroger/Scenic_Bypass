# Jeremiah 8: The Harvest Is Past

*From the Hebrew: בָּעֵת הַהִיא (Ba-Et Ha-Hi) — At That Time*

---

## Desecration of the Graves (8:1-3)

**8:1** "At that time," says YHWH, "they shall bring out the bones of the kings of Judah, and the bones of his princes, and the bones of the priests, and the bones of the prophets, and the bones of the inhabitants of Jerusalem, out of their graves;

**8:2** "And they shall spread them before the sun, and the moon, and all the host of heaven, whom they have loved, and whom they have served, and after whom they have walked, and whom they have sought, and whom they have worshipped; they shall not be gathered, nor be buried, they shall be for dung upon the face of the earth.

**8:3** "And death shall be chosen rather than life by all the residue that remain of this evil family, that remain in all the places whither I have driven them," says YHWH of hosts.

---

## Perpetual Backsliding (8:4-12)

**8:4** Moreover you shall say unto them: "Thus says YHWH: Do men fall, and not rise up again? Does one turn away, and not return?

**8:5** "Why then is this people of Jerusalem slid back by a perpetual backsliding? They hold fast deceit, they refuse to return.

**8:6** "I attended and listened, but they spoke not aright; no man repents him of his wickedness, saying: 'What have I done?' Every one turns away in his course, as a horse that rushes headlong in the battle.

**8:7** "Yea, the stork in the heaven knows her appointed times; and the turtle-dove and the swallow and the crane observe the time of their coming; but my people know not the ordinance of YHWH.

**8:8** "How do you say: 'We are wise, and the law of YHWH is with us'? Lo, certainly in vain has wrought the vain pen of the scribes.

**8:9** "The wise men are put to shame, they are dismayed and taken; lo, they have rejected the word of YHWH; and what wisdom is in them?

**8:10** "Therefore will I give their wives unto others, and their fields to them that shall possess them; for from the least even unto the greatest every one is greedy for gain, from the prophet even unto the priest every one deals falsely.

**8:11** "And they have healed the hurt of the daughter of my people lightly, saying: 'Peace, peace,' when there is no peace.

**8:12** "They shall be put to shame because they have committed abomination; yet they are not at all ashamed, neither know they how to blush; therefore shall they fall among them that fall, in the time of their visitation they shall stumble," says YHWH.

---

## The Harvest Is Past (8:13-17)

**8:13** "I will utterly consume them," says YHWH; "there are no grapes on the vine, nor figs on the fig-tree, and the leaf is faded; and I gave them that which they transgress."

**8:14** "Why do we sit still? Assemble yourselves, and let us enter into the fortified cities, and let us be cut off there; for YHWH our God has cut us off, and given us water of gall to drink, because we have sinned against YHWH.

**8:15** "We looked for peace, but no good came; and for a time of healing, and behold terror!"

**8:16** The snorting of his horses is heard from Dan; at the sound of the neighing of his strong ones the whole land trembles; for they are come, and have devoured the land and all that is in it, the city and those that dwell therein.

**8:17** "For, behold, I will send serpents, basilisks, among you, which will not be charmed; and they shall bite you," says YHWH.

---

## Jeremiah's Grief (8:18-22)

**8:18** Though I would take comfort against sorrow, my heart is faint within me.

**8:19** Behold the voice of the cry of the daughter of my people from a land far off: "Is not YHWH in Zion? Is not her King in her?" "Why have they provoked me with their graven images, and with strange vanities?"

**8:20** "The harvest is past, the summer is ended, and we are not saved."

**8:21** For the hurt of the daughter of my people am I seized with anguish; I am black, appalment has taken hold on me.

**8:22** Is there no balm in Gilead? Is there no physician there? Why then is not the health of the daughter of my people recovered?

---

## Synthesis Notes

**Key Restorations:**

**Desecration (8:1-3):**
"They shall bring out the bones of the kings of Judah."

*Ve-hotzi'u et-atzmot malkhei-Yehudah*—bones brought out.

"The bones of his princes... the priests... the prophets... the inhabitants of Jerusalem."

*Ve-et-atzmot sarav ve-et-atzmot ha-kohanim ve-et-atzmot ha-nevi'im ve-et-atzmot yoshevei Yerushalayim*—all bones.

"Out of their graves."

*Mi-qivreihem*—from graves.

"They shall spread them before the sun, and the moon, and all the host of heaven."

*U-shetachum la-shemesh ve-la-yareach u-le-khol tzeva ha-shamayim*—spread before heavenly bodies.

"Whom they have loved... served... walked... sought... worshipped."

*Asher ahevum va-asher avadum va-asher halekhu achareihem va-asher derashum va-asher hishtachavu lahem*—five verbs of idolatry.

"They shall not be gathered, nor be buried."

*Lo ye'asfu ve-lo yiqqaveru*—no burial.

"They shall be for dung upon the face of the earth."

*Le-domen al-penei ha-adamah yihyu*—dung.

"Death shall be chosen rather than life."

*Ve-nivchar mavet me-chayyim*—death preferred.

**Perpetual Backsliding (8:4-7):**
"Do men fall, and not rise up again?"

*Ha-yippelu ve-lo yaqumu*—fall, not rise?

"Does one turn away, and not return?"

*Im-yashuv ve-lo yashuv*—turn, not return?

"Why then is this people of Jerusalem slid back by a perpetual backsliding?"

*Maddua shoveah ha-am ha-zeh Yerushalayim meshuvah nitzachat*—perpetual backsliding.

"They hold fast deceit."

*Hecheziquu ba-tarmit*—hold deceit.

"They refuse to return."

*Me'anu lashuv*—refuse return.

"I attended and listened."

*Hiqshavti va-eshma*—listened.

"They spoke not aright."

*Lo-khen yedabberu*—spoke wrongly.

"No man repents him of his wickedness."

*Ein ish nicham al-ra'ato*—no repentance.

"'What have I done?'"

*Meh asiti*—self-examination absent.

"Every one turns away in his course."

*Kullo shav be-merutzatam*—all turn away.

"As a horse that rushes headlong in the battle."

*Ke-sus shotef ba-milchamah*—headlong horse.

**The Key Verse (8:7):**
"The stork in the heaven knows her appointed times."

*Gam-chasidah va-shamayim yade'ah mo'adekha*—stork knows seasons.

"The turtle-dove and the swallow and the crane observe the time of their coming."

*Ve-tor ve-sus ve-agur shameru et-et bo'anah*—birds observe times.

"But my people know not the ordinance of YHWH."

*Ve-ammi lo yade'u et mishpat YHWH*—people don't know YHWH's ordinance.

**Birds more faithful than Israel.**

**False Wisdom (8:8-12):**
**The Key Verse (8:8):**
"'We are wise, and the law of YHWH is with us'?"

*Chakhamim anachnu ve-torat YHWH ittanu*—claiming wisdom.

"In vain has wrought the vain pen of the scribes."

*Akhen hinneh la-sheqer asah et-shaqer soferim*—scribes' vain pen.

"The wise men are put to shame."

*Hovishu chakhamim*—wise shamed.

"They have rejected the word of YHWH."

*Hinneh vi-devar-YHWH ma'asu*—word rejected.

"What wisdom is in them?"

*Ve-chokhmat-meh lahem*—what wisdom?

"From the least even unto the greatest every one is greedy for gain."

*Ki mi-qetannam ve-ad-gedolam kullo botzea batza*—all greedy. (Repeats 6:13)

"From the prophet even unto the priest every one deals falsely."

*U-mi-navi ve-ad-kohen kullo oseh shaqer*—all deal falsely. (Repeats 6:13)

**The Key Verse (8:11):**
"'Peace, peace,' when there is no peace."

*Shalom shalom ve-ein shalom*—false peace. (Repeats 6:14)

"They are not at all ashamed, neither know they how to blush."

*Gam-bosh lo-yevoshu ve-hikaklem lo yada'u*—can't blush. (Repeats 6:15)

**Harvest Past (8:13-17):**
"I will utterly consume them."

*Asof asifem*—utterly consume.

"There are no grapes on the vine."

*Ein anavim ba-gefen*—no grapes.

"Nor figs on the fig-tree."

*Ve-ein te'enim ba-te'enah*—no figs.

"The leaf is faded."

*Ve-he-aleh navel*—faded leaf.

"'Why do we sit still?'"

*Al-mah anachnu yoshevim*—why sit?

"'Let us enter into the fortified cities.'"

*Ve-navo'ah el-arei ha-mivtzar*—flee to cities.

"'Let us be cut off there.'"

*Ve-niddammah sham*—perish there.

"'YHWH our God has cut us off.'"

*Ki YHWH Eloheinu hadimmmanu*—God cut off.

"'Given us water of gall to drink.'"

*Va-yashqenu mei-rosh*—gall water.

"'Because we have sinned against YHWH.'"

*Ki chatanu la-YHWH*—sin confession.

"'We looked for peace, but no good came.'"

*Qavvoh le-shalom ve-ein tov*—expected peace.

"'For a time of healing, and behold terror!'"

*Le-et marp'e ve-hinneh ve'atah*—expected healing, got terror.

"The snorting of his horses is heard from Dan."

*Mi-Dan nishma nacharat susav*—Dan hears snorting.

"The whole land trembles."

*Ra'ashah kol-ha-aretz*—land trembles.

"I will send serpents, basilisks, among you."

*Hineni meshalleach bakhem nechashim tzif'onim*—serpents sent.

"Which will not be charmed."

*Asher ein-lahem lachash*—uncharmable.

**Jeremiah's Grief (8:18-22):**
"Though I would take comfort against sorrow."

*Mivligi alai yagon*—comfort against sorrow.

"My heart is faint within me."

*Alai libbi davvai*—faint heart.

"'Is not YHWH in Zion? Is not her King in her?'"

*Ha-YHWH ein be-Tziyyon im-malkah ein bah*—YHWH in Zion?

"'Why have they provoked me with their graven images?'"

*Maddua hikh'isuni vi-fesileihem*—provoked by images.

**The Key Verse (8:20):**
"'The harvest is past, the summer is ended.'"

*Avar qatzir kalah qayitz*—harvest past, summer ended.

"'And we are not saved.'"

*Va-anachnu lo nosha'nu*—not saved.

**The Key Verses (8:21-22):**
"For the hurt of the daughter of my people am I seized with anguish."

*Al-shever bat-ammi hoshbarti*—anguish seized.

"I am black."

*Qadarti*—blackened.

"Appalment has taken hold on me."

*Shammah hecheziqatni*—appalment holds.

**The Key Verse (8:22):**
"Is there no balm in Gilead?"

*Ha-tzori ein be-Gil'ad*—no balm in Gilead?

"Is there no physician there?"

*Im-rofe ein sham*—no physician?

"Why then is not the health of the daughter of my people recovered?"

*Maddua lo aletah arukhat bat-ammi*—why no healing?

**Archetypal Layer:** Jeremiah 8 contains **"the stork in the heaven knows her appointed times... but my people know not" (8:7)**, **"'Peace, peace,' when there is no peace" (8:11)**, **"'The harvest is past, the summer is ended, and we are not saved'" (8:20)**, and **"Is there no balm in Gilead?" (8:22)**.

**Ethical Inversion Applied:**
- "They shall bring out the bones of the kings"—desecration
- "Spread them before the sun, and the moon"—before idols they worshipped
- "They shall be for dung upon the face of the earth"—dung
- "Death shall be chosen rather than life"—death preferred
- "Do men fall, and not rise up again?"—fall/rise question
- "Why then is this people of Jerusalem slid back by a perpetual backsliding?"—perpetual
- "They hold fast deceit, they refuse to return"—deceit held
- "No man repents him of his wickedness"—no repentance
- "'What have I done?'"—no self-examination
- "The stork in the heaven knows her appointed times"—birds know
- "My people know not the ordinance of YHWH"—people don't know
- "'We are wise, and the law of YHWH is with us'"—false wisdom claim
- "In vain has wrought the vain pen of the scribes"—scribes' vain work
- "They have rejected the word of YHWH"—word rejected
- "What wisdom is in them?"—no wisdom
- "'Peace, peace,' when there is no peace"—false peace
- "They are not at all ashamed, neither know they how to blush"—shameless
- "There are no grapes on the vine, nor figs on the fig-tree"—fruitless
- "'We looked for peace, but no good came'"—disappointed expectation
- "The snorting of his horses is heard from Dan"—invasion heard
- "I will send serpents, basilisks"—judgment serpents
- "'Is not YHWH in Zion?'"—questioning YHWH's presence
- "'The harvest is past, the summer is ended, and we are not saved'"—missed opportunity
- "For the hurt of the daughter of my people am I seized with anguish"—Jeremiah's grief
- "Is there no balm in Gilead?"—healing question
- "Is there no physician there?"—physician question
- "Why then is not the health of the daughter of my people recovered?"—unanswered healing

**Modern Equivalent:** Jeremiah 8:7's comparison of birds knowing their seasons while people don't know YHWH's ordinance is profound. "The harvest is past, the summer is ended, and we are not saved" (8:20) is one of Scripture's most poignant laments. "Is there no balm in Gilead?" (8:22) became a famous spiritual song.

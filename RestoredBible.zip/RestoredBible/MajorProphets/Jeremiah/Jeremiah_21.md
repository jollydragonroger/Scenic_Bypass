# Jeremiah 21: Zedekiah's Inquiry and YHWH's Answer

*From the Hebrew: הַדָּבָר אֲשֶׁר הָיָה אֶל־יִרְמְיָהוּ (Ha-Davar Asher Hayah El-Yirmeyahu) — The Word That Came to Jeremiah*

---

## Zedekiah's Inquiry (21:1-2)

**21:1** The word which came unto Jeremiah from YHWH, when king Zedekiah sent unto him Pashhur the son of Malchiah, and Zephaniah the son of Maaseiah the priest, saying:

**21:2** "Inquire, I pray you, of YHWH for us; for Nebuchadrezzar king of Babylon makes war against us; peradventure YHWH will deal with us according to all his wondrous works, that he may go up from us."

---

## YHWH's Answer (21:3-10)

**21:3** Then said Jeremiah unto them: "Thus shall you say to Zedekiah:

**21:4** "Thus says YHWH, the God of Israel: Behold, I will turn back the weapons of war that are in your hands, wherewith you fight against the king of Babylon, and against the Chaldeans, that besiege you without the walls, and I will gather them into the midst of this city.

**21:5** "And I myself will fight against you with an outstretched hand and with a strong arm, even in anger, and in fury, and in great wrath.

**21:6** "And I will smite the inhabitants of this city, both man and beast; they shall die of a great pestilence.

**21:7** "And afterward," says YHWH, "I will deliver Zedekiah king of Judah, and his servants, and the people, even such as are left in this city from the pestilence, from the sword, and from the famine, into the hand of Nebuchadrezzar king of Babylon, and into the hand of their enemies, and into the hand of those that seek their life; and he shall smite them with the edge of the sword; he shall not spare them, neither have pity, nor have compassion."

**21:8** "And unto this people you shall say: Thus says YHWH: Behold, I set before you the way of life and the way of death.

**21:9** "He that abides in this city shall die by the sword, and by the famine, and by the pestilence; but he that goes out, and falls away to the Chaldeans that besiege you, he shall live, and his life shall be unto him for a prey.

**21:10** "For I have set my face against this city for evil, and not for good," says YHWH; "it shall be given into the hand of the king of Babylon, and he shall burn it with fire."

---

## Message to the House of David (21:11-14)

**21:11** And touching the house of the king of Judah, hear the word of YHWH:

**21:12** O house of David, thus says YHWH: "Execute justice in the morning, and deliver the spoiled out of the hand of the oppressor, lest my fury go forth like fire, and burn that none can quench it, because of the evil of your doings.

**21:13** "Behold, I am against you, O inhabitant of the valley, and rock of the plain," says YHWH; "you that say: 'Who shall come down against us? Or who shall enter into our habitations?'

**21:14** "And I will punish you according to the fruit of your doings," says YHWH; "and I will kindle a fire in her forest, and it shall devour all that is round about her."

---

## Synthesis Notes

**Key Restorations:**

**Zedekiah's Embassy (21:1-2):**
"When king Zedekiah sent unto him Pashhur the son of Malchiah."

*Bi-shloach elav ha-melekh Tzidqiyyahu et-Pashhur ben-Malkiyyah*—Zedekiah's embassy.

**Note:** This Pashhur is different from Pashhur ben-Immer (20:1).

"And Zephaniah the son of Maaseiah the priest."

*Ve-et Tzefanyah ben-Ma'aseyah ha-kohen*—Zephaniah priest.

"Inquire, I pray you, of YHWH for us."

*Derash-na va'adenu et-YHWH*—inquire of YHWH.

"Nebuchadrezzar king of Babylon makes war against us."

*Ki Nevukhadre'zzar melekh-Bavel nilcham aleinu*—Nebuchadnezzar fights.

"Peradventure YHWH will deal with us according to all his wondrous works."

*Ulai ya'aseh YHWH ittanu ke-khol-nifl'otav*—hoping for miracle.

"That he may go up from us."

*Ve-ya'aleh me-aleinu*—withdraw from us.

**Historical Context:**
This is during Babylon's final siege of Jerusalem (588-586 BCE). Zedekiah hopes for a miracle like Sennacherib's withdrawal (2 Kings 19:35-36).

**YHWH's Answer (21:3-7):**
"I will turn back the weapons of war that are in your hands."

*Hineni messev et-kelei ha-milchamah asher be-yedkhem*—turn back weapons.

"Wherewith you fight against the king of Babylon."

*Asher attem nilchamim bam et-melekh Bavel*—fighting Babylon.

"I will gather them into the midst of this city."

*Ve-asafti otam el-tokh ha-ir ha-zot*—gather into city.

**The Key Verse (21:5):**
"I myself will fight against you."

*Ve-nilchamti ani ittkhem*—I fight against you.

"With an outstretched hand and with a strong arm."

*Be-yad netuyah u-vi-zero'a chazaqah*—outstretched hand, strong arm.

**Exodus Reversal:**
The "outstretched hand" and "strong arm" that delivered Israel from Egypt (Deuteronomy 4:34; 5:15) now fights against them.

"Even in anger, and in fury, and in great wrath."

*U-ve-af u-ve-chemah u-ve-qetzef gadol*—anger, fury, wrath.

"I will smite the inhabitants of this city."

*Ve-hikkeiti et-yoshevei ha-ir ha-zot*—smite inhabitants.

"Both man and beast."

*Ve-et-ha-adam ve-et-ha-behemah*—man and beast.

"They shall die of a great pestilence."

*Be-dever gadol yamutu*—great pestilence.

"I will deliver Zedekiah king of Judah... into the hand of Nebuchadrezzar."

*Ve-etten et-Tzidqiyyahu melekh-Yehudah... be-yad Nevukhadre'zzar*—Zedekiah delivered.

"He shall smite them with the edge of the sword."

*Ve-hikkam le-fi-cherev*—sword edge.

"He shall not spare them, neither have pity, nor have compassion."

*Lo-yachmal aleihem ve-lo yachos ve-lo yerachem*—no mercy.

**Way of Life/Death (21:8-10):**
**The Key Verse (21:8):**
"I set before you the way of life and the way of death."

*Hineni noten lifneikhem et-derekh ha-chayyim ve-et-derekh ha-mavet*—life and death ways.

**Deuteronomy Echo:**
Echoes Deuteronomy 30:15, 19—but here "life" means surrender to Babylon.

**The Key Verse (21:9):**
"He that abides in this city shall die by the sword, and by the famine, and by the pestilence."

*Ha-yoshev ba-ir ha-zot yamut ba-cherev u-va-ra'av u-va-daver*—stay = die.

"He that goes out, and falls away to the Chaldeans that besiege you, he shall live."

*Ve-ha-yotze ve-nafal al-ha-Kasdim ha-tzarim aleikhem yichyeh*—defect = live.

"His life shall be unto him for a prey."

*Ve-hayetah-lo nafsho le-shalal*—life as plunder.

**Controversial Advice:**
Jeremiah counsels surrender/defection—viewed as treason (38:4).

**The Key Verse (21:10):**
"I have set my face against this city for evil, and not for good."

*Ki samti fanai ba-ir ha-zot le-ra'ah ve-lo le-tovah*—face set against.

"It shall be given into the hand of the king of Babylon."

*Be-yad melekh-Bavel tinnaten*—given to Babylon.

"He shall burn it with fire."

*U-serafah va-esh*—burn with fire.

**House of David (21:11-14):**
"Touching the house of the king of Judah."

*U-le-veit melekh Yehudah*—to royal house.

**The Key Verse (21:12):**
"Execute justice in the morning."

*Dinu la-boqer mishpat*—morning justice.

"Deliver the spoiled out of the hand of the oppressor."

*Ve-hatztzilu gazul mi-yad osheq*—deliver oppressed.

"Lest my fury go forth like fire."

*Pen-tetze kha-esh chamati*—fire fury.

"Burn that none can quench it."

*Ve-va'arah ve-ein mekhabeh*—unquenchable.

"Because of the evil of your doings."

*Mippenei ro'a ma'aleleikem*—evil doings.

**The Key Verse (21:13):**
"Behold, I am against you."

*Hineni elayikh*—against you.

"O inhabitant of the valley, and rock of the plain."

*Yoshevet ha-emeq tzur ha-mishor*—valley/rock.

**Jerusalem's Location:**
Jerusalem sits on a plateau surrounded by valleys—they felt secure.

"'Who shall come down against us?'"

*Mi yeched aleinu*—who'll attack?

"'Who shall enter into our habitations?'"

*U-mi yavo bi-me'onotenu*—who'll enter?

**The Key Verse (21:14):**
"I will punish you according to the fruit of your doings."

*U-faqadti aleikhem ki-fri ma'aleleikem*—punish by fruit.

"I will kindle a fire in her forest."

*Ve-hitztzatti esh be-ya'rah*—fire in forest.

"It shall devour all that is round about her."

*Ve-akhelah kol-sevivekha*—devour surroundings.

**Archetypal Layer:** Jeremiah 21 contains **YHWH fighting against Jerusalem with "outstretched hand and strong arm" (21:5)**—reversing Exodus imagery, **"I set before you the way of life and the way of death" (21:8)**, and **counsel to surrender to Babylon (21:9)**.

**Ethical Inversion Applied:**
- "Inquire, I pray you, of YHWH for us"—inquiry
- "Peradventure YHWH will deal with us according to all his wondrous works"—hoping for miracle
- "I will turn back the weapons of war that are in your hands"—weapons turned
- "I will gather them into the midst of this city"—enemies gathered
- "I myself will fight against you"—YHWH fights against
- "With an outstretched hand and with a strong arm"—Exodus reversal
- "Even in anger, and in fury, and in great wrath"—anger, fury, wrath
- "I will smite the inhabitants of this city"—smite inhabitants
- "They shall die of a great pestilence"—pestilence
- "I will deliver Zedekiah... into the hand of Nebuchadrezzar"—Zedekiah delivered
- "He shall not spare them, neither have pity, nor have compassion"—no mercy
- "I set before you the way of life and the way of death"—life/death choice
- "He that abides in this city shall die"—stay = die
- "He that goes out, and falls away to the Chaldeans... shall live"—defect = live
- "His life shall be unto him for a prey"—life as plunder
- "I have set my face against this city for evil"—face set against
- "It shall be given into the hand of the king of Babylon"—given to Babylon
- "He shall burn it with fire"—burned
- "Execute justice in the morning"—morning justice
- "Deliver the spoiled out of the hand of the oppressor"—deliver oppressed
- "Lest my fury go forth like fire"—fire fury
- "'Who shall come down against us?'"—false security
- "I will punish you according to the fruit of your doings"—fruit punishment
- "I will kindle a fire in her forest"—forest fire

**Modern Equivalent:** Jeremiah 21 shows the shocking reversal where YHWH's "outstretched hand" that saved Israel now fights against them. The counsel to surrender (21:9) was viewed as treason but was actually the path of life. This section begins the "Book of Kings" collection (21-24).

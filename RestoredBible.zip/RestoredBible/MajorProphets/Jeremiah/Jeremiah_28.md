# Jeremiah 28: Hananiah the False Prophet

*From the Hebrew: וַיְהִי בַּשָּׁנָה הַהִיא (Va-Yehi Ba-Shanah Ha-Hi) — And It Came to Pass in That Year*

---

## Hananiah's Prophecy (28:1-4)

**28:1** And it came to pass the same year, in the beginning of the reign of Zedekiah king of Judah, in the fourth year, in the fifth month, that Hananiah the son of Azzur the prophet, who was of Gibeon, spoke unto me in the house of YHWH, in the presence of the priests and of all the people, saying:

**28:2** "Thus speaks YHWH of hosts, the God of Israel, saying: 'I have broken the yoke of the king of Babylon.

**28:3** "'Within two full years will I bring back into this place all the vessels of YHWH's house, that Nebuchadnezzar king of Babylon took away from this place, and carried to Babylon;

**28:4** "'And I will bring back to this place Jeconiah the son of Jehoiakim, king of Judah, with all the captives of Judah, that went to Babylon,' says YHWH; 'for I will break the yoke of the king of Babylon.'"

---

## Jeremiah's Response (28:5-9)

**28:5** Then the prophet Jeremiah said unto the prophet Hananiah in the presence of the priests, and in the presence of all the people that stood in the house of YHWH,

**28:6** Even the prophet Jeremiah said: "Amen! YHWH do so! YHWH perform your words which you have prophesied, to bring back the vessels of YHWH's house, and all them of the captivity, from Babylon unto this place.

**28:7** "Nevertheless hear now this word that I speak in your ears, and in the ears of all the people:

**28:8** "The prophets that have been before me and before you of old prophesied against many countries, and against great kingdoms, of war, and of evil, and of pestilence.

**28:9** "The prophet that prophesies of peace, when the word of the prophet shall come to pass, then shall the prophet be known, that YHWH has truly sent him."

---

## Hananiah Breaks the Yoke (28:10-11)

**28:10** Then Hananiah the prophet took the bar from off the prophet Jeremiah's neck, and broke it.

**28:11** And Hananiah spoke in the presence of all the people, saying: "Thus says YHWH: Even so will I break the yoke of Nebuchadnezzar king of Babylon within two full years from off the neck of all the nations." And the prophet Jeremiah went his way.

---

## YHWH's Judgment on Hananiah (28:12-17)

**28:12** Then the word of YHWH came unto Jeremiah, after that Hananiah the prophet had broken the bar from off the neck of the prophet Jeremiah, saying:

**28:13** "Go, and tell Hananiah, saying: Thus says YHWH: You have broken the bars of wood; but you have made in their stead bars of iron.

**28:14** "For thus says YHWH of hosts, the God of Israel: I have put a yoke of iron upon the neck of all these nations, that they may serve Nebuchadnezzar king of Babylon; and they shall serve him; and I have given him the beasts of the field also."

**28:15** Then said the prophet Jeremiah unto Hananiah the prophet: "Hear now, Hananiah; YHWH has not sent you; but you make this people to trust in a lie.

**28:16** "Therefore thus says YHWH: Behold, I will send you away from off the face of the earth; this year you shall die, because you have spoken rebellion against YHWH."

**28:17** So Hananiah the prophet died the same year in the seventh month.

---

## Synthesis Notes

**Key Restorations:**

**Hananiah's False Prophecy (28:1-4):**
"The same year, in the beginning of the reign of Zedekiah."

*Va-yehi ba-shanah ha-hi be-reshit mamlekhet Tzidqiyyahu*—same year.

"In the fourth year, in the fifth month."

*Ba-shanah ha-revi'it ba-chodesh ha-chamishi*—4th year, 5th month (594/593 BCE).

"Hananiah the son of Azzur the prophet."

*Chananyah ben-Azzur ha-navi*—Hananiah.

"Who was of Gibeon."

*Asher mi-Giv'on*—from Gibeon.

"Spoke unto me in the house of YHWH."

*Elai be-veit YHWH*—in temple.

"In the presence of the priests and of all the people."

*Le-einei ha-kohanim ve-khol-ha-am*—before witnesses.

**The Key Verse (28:2):**
"'I have broken the yoke of the king of Babylon.'"

*Shavarti et-ol melekh Bavel*—yoke broken.

"'Within two full years will I bring back into this place all the vessels.'"

*Be-od shnatayim yamim ani meshiv el-ha-maqom ha-zeh et-kol-kelei beit-YHWH*—two years.

"'That Nebuchadnezzar king of Babylon took away.'"

*Asher laqach Nevukhadnetztzar melekh Bavel*—taken.

"'And carried to Babylon.'"

*Va-yevi'em Bavelah*—to Babylon.

**The Key Verse (28:4):**
"'I will bring back to this place Jeconiah.'"

*Va-hashivoti el-ha-maqom ha-zeh et-Yekhonyah*—Jeconiah returned.

"'With all the captives of Judah.'"

*Ve-et-kol-galut Yehudah*—all captives.

"'For I will break the yoke of the king of Babylon.'"

*Ki eshbor et-ol melekh Bavel*—break yoke.

**Hananiah's Message:**
Directly contradicts Jeremiah's message (chapter 27). Promises quick restoration rather than 70 years of servitude.

**Jeremiah's Response (28:5-9):**
"'Amen! YHWH do so!'"

*Amen ken ya'aseh YHWH*—Amen!

"'YHWH perform your words which you have prophesied.'"

*Yaqem YHWH et-devarekha asher nibbeta*—perform words.

"'To bring back the vessels of YHWH's house.'"

*Le-hashiv kelei beit-YHWH*—return vessels.

"'And all them of the captivity, from Babylon unto this place.'"

*Ve-khol-ha-golah mi-Bavel el-ha-maqom ha-zeh*—captives back.

**Jeremiah's Wish:**
Jeremiah genuinely wishes Hananiah were right—but knows he isn't.

**The Key Verses (28:8-9):**
"The prophets that have been before me and before you of old."

*Ha-nevi'im asher hayu lefanai ve-lefanekha min-ha-olam*—ancient prophets.

"Prophesied against many countries, and against great kingdoms."

*Va-yinnav'u el-aratzot rabbut ve-al-mamlakhot gedolot*—prophesied against.

"Of war, and of evil, and of pestilence."

*Le-milchamah u-le-ra'ah u-le-daver*—war, evil, pestilence.

**The Key Verse (28:9):**
"The prophet that prophesies of peace."

*Ha-navi asher yinnave le-shalom*—peace prophet.

"When the word of the prophet shall come to pass."

*Be-vo devar ha-navi*—when fulfilled.

"Then shall the prophet be known, that YHWH has truly sent him."

*Yivvada ha-navi asher-shelakho YHWH be-emet*—known as sent.

**Test of Prophecy:**
Prophets of judgment align with prophetic tradition. Prophets of peace must prove themselves by fulfillment (Deuteronomy 18:21-22).

**Hananiah Breaks Yoke (28:10-11):**
"Hananiah the prophet took the bar from off the prophet Jeremiah's neck."

*Va-yiqqach Chananyah ha-navi et-ha-motah me-al tzavvar Yirmeyahu ha-navi*—took yoke.

"And broke it."

*Va-yishberehu*—broke it.

"'Even so will I break the yoke of Nebuchadnezzar king of Babylon.'"

*Ka-khah eshbor et-ol Nevukhadnetztzar melekh-Bavel*—break Babylon's yoke.

"'Within two full years from off the neck of all the nations.'"

*Be-od shnatayim yamim me-al tzavvar kol-ha-goyim*—two years.

"The prophet Jeremiah went his way."

*Va-yelekh Yirmeyahu ha-navi le-darkko*—Jeremiah left.

**Jeremiah's Silence:**
Jeremiah doesn't immediately respond—he waits for YHWH's word.

**YHWH's Response (28:12-14):**
"The word of YHWH came unto Jeremiah, after that Hananiah the prophet had broken the bar."

*Va-yehi devar-YHWH el-Yirmeyahu acharei shevor Chananyah ha-navi et-ha-motah*—word came after.

**The Key Verse (28:13):**
"'You have broken the bars of wood.'"

*Motot etz shavarta*—broke wood bars.

"'But you have made in their stead bars of iron.'"

*Ve-asit tachteihen motot barzel*—made iron bars.

**Escalation:**
Hananiah's false hope actually worsens the situation—wood becomes iron.

**The Key Verse (28:14):**
"'I have put a yoke of iron upon the neck of all these nations.'"

*Ki ol barzel natatti al-tzavvar kol-ha-goyim ha-elleh*—iron yoke.

"'That they may serve Nebuchadnezzar king of Babylon.'"

*La'avod et-Nevukhadnetztzar melekh Bavel*—serve Nebuchadnezzar.

"'They shall serve him.'"

*Va'avaduhu*—shall serve.

"'I have given him the beasts of the field also.'"

*Ve-gam et-chayyat ha-sadeh natatti lo*—beasts given.

**Hananiah's Death Sentence (28:15-17):**
**The Key Verse (28:15):**
"'Hear now, Hananiah; YHWH has not sent you.'"

*Shema-na Chananyah lo-shelachakha YHWH*—not sent.

"'You make this people to trust in a lie.'"

*Ve-attah hivtachta et-ha-am ha-zeh al-sheqer*—trusting lies.

**The Key Verse (28:16):**
"'Behold, I will send you away from off the face of the earth.'"

*Hineni meshall'chakha me-al penei ha-adamah*—sent from earth.

"'This year you shall die.'"

*Ha-shanah attah met*—die this year.

"'Because you have spoken rebellion against YHWH.'"

*Ki sarah dibbarta el-YHWH*—spoken rebellion.

**The Key Verse (28:17):**
"So Hananiah the prophet died the same year in the seventh month."

*Va-yamat Chananyah ha-navi ba-shanah ha-hi ba-chodesh ha-shevi'i*—died 7th month.

**Fulfillment:**
Hananiah prophesied in the 5th month (28:1), died in the 7th month—within two months.

**Archetypal Layer:** Jeremiah 28 contains **Hananiah's false prophecy of quick restoration (28:2-4)**, **Jeremiah's test for prophets of peace (28:8-9)**, **wood yoke becomes iron yoke (28:13)**, and **Hananiah's death within two months (28:17)**.

**Ethical Inversion Applied:**
- "Hananiah the son of Azzur the prophet, who was of Gibeon"—false prophet
- "Spoke unto me in the house of YHWH"—temple setting
- "In the presence of the priests and of all the people"—public
- "'I have broken the yoke of the king of Babylon'"—false claim
- "'Within two full years will I bring back... all the vessels'"—two years
- "'I will bring back to this place Jeconiah'"—Jeconiah return
- "'For I will break the yoke of the king of Babylon'"—false hope
- "'Amen! YHWH do so!'"—Jeremiah's wish
- "'YHWH perform your words'"—conditional wish
- "The prophets that have been before me and before you of old"—prophetic tradition
- "Prophesied against many countries... of war, and of evil"—judgment tradition
- "The prophet that prophesies of peace"—peace prophet
- "When the word of the prophet shall come to pass"—fulfillment test
- "Then shall the prophet be known, that YHWH has truly sent him"—known by fruit
- "Hananiah the prophet took the bar from off... Jeremiah's neck"—yoke taken
- "And broke it"—yoke broken
- "'Even so will I break the yoke of Nebuchadnezzar'"—symbolic action
- "The prophet Jeremiah went his way"—silent departure
- "'You have broken the bars of wood'"—wood broken
- "'But you have made in their stead bars of iron'"—iron replacement
- "'I have put a yoke of iron upon the neck of all these nations'"—iron yoke
- "'YHWH has not sent you'"—not sent
- "'You make this people to trust in a lie'"—false trust
- "'This year you shall die'"—death sentence
- "'Because you have spoken rebellion against YHWH'"—rebellion
- "Hananiah the prophet died the same year in the seventh month"—fulfilled

**Modern Equivalent:** Jeremiah 28 shows the confrontation between true and false prophecy. Jeremiah's test (28:8-9) establishes that prophets of judgment align with tradition; prophets of peace must prove themselves. Hananiah's death (28:17) vindicated Jeremiah—the false prophet died within months.

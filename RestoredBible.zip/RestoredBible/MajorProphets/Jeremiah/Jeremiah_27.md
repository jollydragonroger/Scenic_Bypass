# Jeremiah 27: The Yoke of Babylon

*From the Hebrew: בְּרֵאשִׁית מַמְלֶכֶת יְהוֹיָקִם (Be-Reshit Mamlekhet Yehoyaqim) — In the Beginning of the Reign of Jehoiakim*

---

## The Yoke Sign-Act (27:1-7)

**27:1** In the beginning of the reign of Jehoiakim the son of Josiah, king of Judah, came this word unto Jeremiah from YHWH, saying:

**27:2** Thus says YHWH to me: "Make yourself bands and bars, and put them upon your neck;

**27:3** "And send them to the king of Edom, and to the king of Moab, and to the king of the children of Ammon, and to the king of Tyre, and to the king of Zidon, by the hand of the messengers that come to Jerusalem unto Zedekiah king of Judah;

**27:4** "And give them a charge unto their masters, saying: Thus says YHWH of hosts, the God of Israel: Thus shall you say unto your masters:

**27:5** "'I have made the earth, the man and the beast that are upon the face of the earth, by my great power and by my outstretched arm; and I give it unto whom it seems right unto me.

**27:6** "'And now have I given all these lands into the hand of Nebuchadnezzar the king of Babylon, my servant; and the beasts of the field also have I given him to serve him.

**27:7** "'And all the nations shall serve him, and his son, and his son's son, until the time of his own land come; and then many nations and great kings shall make him their bondman.'"

---

## Submit or Perish (27:8-11)

**27:8** "And it shall come to pass, that the nation and the kingdom which will not serve the same Nebuchadnezzar king of Babylon, and that will not put their neck under the yoke of the king of Babylon, that nation will I punish," says YHWH, "with the sword, and with the famine, and with the pestilence, until I have consumed them by his hand.

**27:9** "But as for you, hearken not to your prophets, nor to your diviners, nor to your dreams, nor to your soothsayers, nor to your sorcerers, that speak unto you, saying: 'You shall not serve the king of Babylon';

**27:10** "For they prophesy a lie unto you, to remove you far from your land; and that I should drive you out, and you should perish.

**27:11** "But the nation that shall bring their neck under the yoke of the king of Babylon, and serve him, that nation will I let remain in their own land," says YHWH; "and they shall till it, and dwell therein."

---

## Message to Zedekiah (27:12-15)

**27:12** And I spoke to Zedekiah king of Judah according to all these words, saying: "Bring your necks under the yoke of the king of Babylon, and serve him and his people, and live.

**27:13** "Why will you die, you and your people, by the sword, by the famine, and by the pestilence, as YHWH has spoken concerning the nation that will not serve the king of Babylon?

**27:14** "And hearken not unto the words of the prophets that speak unto you, saying: 'You shall not serve the king of Babylon'; for they prophesy a lie unto you.

**27:15** "'For I have not sent them," says YHWH, "and they prophesy falsely in my name; that I might drive you out, and that you might perish, you, and the prophets that prophesy unto you."

---

## Message to the Priests and People (27:16-22)

**27:16** Also I spoke to the priests and to all this people, saying: "Thus says YHWH: Hearken not to the words of your prophets that prophesy unto you, saying: 'Behold, the vessels of YHWH's house shall now shortly be brought back from Babylon'; for they prophesy a lie unto you.

**27:17** "Hearken not unto them; serve the king of Babylon, and live; wherefore should this city become a desolation?

**27:18** "But if they be prophets, and if the word of YHWH be with them, let them now make intercession to YHWH of hosts, that the vessels which are left in the house of YHWH, and in the house of the king of Judah, and at Jerusalem, go not to Babylon.

**27:19** "For thus says YHWH of hosts concerning the pillars, and concerning the sea, and concerning the bases, and concerning the residue of the vessels that remain in this city,

**27:20** "Which Nebuchadnezzar king of Babylon took not, when he carried away captive Jeconiah the son of Jehoiakim, king of Judah, from Jerusalem to Babylon, and all the nobles of Judah and Jerusalem;

**27:21** "Yea, thus says YHWH of hosts, the God of Israel, concerning the vessels that remain in the house of YHWH, and in the house of the king of Judah, and at Jerusalem:

**27:22** "'They shall be carried to Babylon, and there shall they be, until the day that I remember them," says YHWH; "and bring them up, and restore them to this place.'"

---

## Synthesis Notes

**Key Restorations:**

**Yoke Sign-Act (27:1-3):**
"Make yourself bands and bars."

*Aseh-lekha mosrot u-motot*—make yoke straps/bars.

"Put them upon your neck."

*Ve-netattam al-tzavva'rekha*—wear on neck.

"Send them to the king of Edom... Moab... Ammon... Tyre... Zidon."

*Ve-shillachtam el-melekh Edom ve-el-melekh Mo'av ve-el-melekh benei-Ammon ve-el-melekh Tzor ve-el-melekh Tzidon*—send to kings.

"By the hand of the messengers that come to Jerusalem unto Zedekiah."

*Be-yad mal'akhim ha-ba'im Yerushalayim el-Tzidqiyyahu melekh Yehudah*—via messengers.

**Historical Context:**
Around 594/593 BCE, envoys from neighboring nations met in Jerusalem, likely to plot rebellion against Babylon. Jeremiah wore a yoke and sent yoke-messages to the kings.

**Creator's Right (27:4-7):**
**The Key Verse (27:5):**
"I have made the earth, the man and the beast."

*Anokhi asiti et-ha-aretz et-ha-adam ve-et-ha-behemah*—I made earth.

"By my great power and by my outstretched arm."

*Be-khohi ha-gadol u-vi-zero'i ha-netuyah*—great power, outstretched arm.

"I give it unto whom it seems right unto me."

*U-netattikha la-asher yashar be-einai*—give as I choose.

**The Key Verse (27:6):**
"Now have I given all these lands into the hand of Nebuchadnezzar the king of Babylon, my servant."

*Ve-attah anokhi natatti et-kol-ha-aratzot ha-elleh be-yad Nevukhadnetztzar melekh-Bavel avdi*—lands to Nebuchadnezzar.

"The beasts of the field also have I given him to serve him."

*Ve-gam et-chayyat ha-sadeh natatti lo le-ovdo*—beasts given.

**The Key Verse (27:7):**
"All the nations shall serve him, and his son, and his son's son."

*Ve-avedu oto kol-ha-goyim ve-et-beno ve-et-ben-beno*—three generations.

"Until the time of his own land come."

*Ad-bo et-artzo gam-hu*—until his time comes.

"Many nations and great kings shall make him their bondman."

*Ve-avedu-vo gam-hu goyim rabbim u-melakhim gedolim*—Babylon becomes servant.

**Three Generations:**
Nebuchadnezzar, Amel-Marduk (Evil-merodach), Belshazzar—until Babylon's fall in 539 BCE.

**Submit or Perish (27:8-11):**
"The nation and the kingdom which will not serve... Nebuchadnezzar."

*Ve-hayah ha-goy ve-ha-mamlakah asher lo-ya'avdu oto et-Nevukhadnetztzar*—not serve.

"Will not put their neck under the yoke."

*Va-asher lo-yitten et-tzavva'ro be-ol melekh Bavel*—not take yoke.

"That nation will I punish."

*Ba-goy ha-hu efqod*—punish.

"With the sword, and with the famine, and with the pestilence."

*Ba-cherev u-va-ra'av u-va-daver*—sword, famine, pestilence.

"Until I have consumed them by his hand."

*Ad-tummi otam be-yado*—consumed by Babylon.

**The Key Verse (27:9):**
"Hearken not to your prophets, nor to your diviners."

*Ve-attem al-tishme'u el-nevi'eikhem ve-el-qosmeikhem*—don't hear prophets/diviners.

"Nor to your dreams, nor to your soothsayers, nor to your sorcerers."

*Ve-el-chalomotekhem ve-el-oneneikhem ve-el-kashhafeikhem*—dreams/soothsayers/sorcerers.

"'You shall not serve the king of Babylon.'"

*Lo ta'avdu et-melekh Bavel*—false prophecy.

**The Key Verse (27:10):**
"They prophesy a lie unto you."

*Ki sheqer hem nivve'im lakhem*—prophesying lies.

"To remove you far from your land."

*Lema'an harchiq etkhem me-al admatekhem*—remove from land.

"That I should drive you out, and you should perish."

*Ve-hiddachti etkhem va-avadtem*—driven out, perish.

**The Key Verse (27:11):**
"The nation that shall bring their neck under the yoke... I will let remain in their own land."

*Ve-ha-goy asher yavi et-tzavva'ro be-ol melekh Bavel va-avado ve-hinnachttiv al-admato*—submit = remain.

"They shall till it, and dwell therein."

*Ve-avadah ve-yashav bah*—till and dwell.

**Message to Zedekiah (27:12-15):**
"Bring your necks under the yoke of the king of Babylon."

*Havi'u et-tzavva'reikhem be-ol melekh Bavel*—take yoke.

"Serve him and his people, and live."

*Ve-ivdu oto ve-ammo vi-chyu*—serve and live.

"Why will you die, you and your people?"

*Lammah tamutu attah ve-ammekha*—why die?

"By the sword, by the famine, and by the pestilence."

*Ba-cherev ba-ra'av u-va-daver*—sword, famine, pestilence.

"Hearken not unto the words of the prophets."

*Ve-al-tishme'u el-divrei ha-nevi'im*—don't hear prophets.

"'You shall not serve the king of Babylon.'"

*Lo ta'avdu et-melekh Bavel*—false message.

"They prophesy a lie unto you."

*Ki sheqer hem nivve'im lakhem*—prophesying lies.

"I have not sent them."

*Ki lo shelachtim*—not sent.

"They prophesy falsely in my name."

*Ve-hem nivve'im bi-shemi la-sheqer*—falsely in my name.

**Message to Priests and People (27:16-22):**
"'The vessels of YHWH's house shall now shortly be brought back from Babylon.'"

*Hinneh kelei beit-YHWH mushavim me-Bavel attah meherah*—vessels returning.

"They prophesy a lie unto you."

*Ki sheqer hem nivve'im lakhem*—prophesying lies.

"Hearken not unto them; serve the king of Babylon, and live."

*Al-tishme'u aleihem ivdu et-melekh Bavel vi-chyu*—serve and live.

"Wherefore should this city become a desolation?"

*Lammah tihyeh ha-ir ha-zot chorvah*—why desolation?

**The Key Verse (27:18):**
"If they be prophets, and if the word of YHWH be with them."

*Ve-im-nevi'im hem ve-im-yesh devar-YHWH ittam*—if true prophets.

"Let them now make intercession to YHWH of hosts."

*Yifge'u-na va-YHWH Tzeva'ot*—let them intercede.

"That the vessels which are left... go not to Babylon."

*Le-vilti-vo ha-kelim ha-notarim... Bavelah*—intercede for vessels.

**Vessels Already Taken (27:19-21):**
"The pillars, and concerning the sea, and concerning the bases."

*Al-ha-ammudim ve-al-ha-yam ve-al-ha-mekhonot*—temple furnishings.

"The residue of the vessels that remain in this city."

*Ve-al-yeter ha-kelim ha-notarim ba-ir ha-zot*—remaining vessels.

"Which Nebuchadnezzar king of Babylon took not."

*Asher lo-leqacham Nevukhadnetztzar melekh Bavel*—not yet taken.

"When he carried away captive Jeconiah... from Jerusalem to Babylon."

*Be-hagloto et-Yekhonyah... mi-Yerushalayim Bavelah*—597 BCE.

**The Key Verse (27:22):**
"They shall be carried to Babylon."

*Bavelah yuva'u*—carried to Babylon.

"There shall they be, until the day that I remember them."

*Ve-shammah yihyu ad yom poqdi otam*—until visited.

"And bring them up, and restore them to this place."

*Ve-ha'alitim va-hashivotim el-ha-maqom ha-zeh*—restored (Ezra 1:7-11).

**Archetypal Layer:** Jeremiah 27 contains **the yoke sign-act (27:2)**, **Nebuchadnezzar as "my servant" (27:6)**, **the call to submit and live (27:11-12)**, and **the test for true prophets (27:18)**.

**Ethical Inversion Applied:**
- "Make yourself bands and bars, and put them upon your neck"—yoke sign-act
- "Send them to the king of Edom... Moab... Ammon... Tyre... Zidon"—nations addressed
- "I have made the earth, the man and the beast"—creator's right
- "By my great power and by my outstretched arm"—divine power
- "I give it unto whom it seems right unto me"—sovereign giving
- "I given all these lands into the hand of Nebuchadnezzar... my servant"—Babylon = servant
- "The beasts of the field also have I given him"—complete dominion
- "All the nations shall serve him, and his son, and his son's son"—three generations
- "Until the time of his own land come"—Babylon's end
- "The nation and the kingdom which will not serve... will I punish"—submit or perish
- "With the sword, and with the famine, and with the pestilence"—judgment
- "Hearken not to your prophets, nor to your diviners"—don't listen
- "'You shall not serve the king of Babylon'"—false prophecy
- "They prophesy a lie unto you"—lies
- "The nation that shall bring their neck under the yoke... will I let remain"—submit = survive
- "Bring your necks under the yoke of the king of Babylon... and live"—live by submission
- "Why will you die?"—rhetorical
- "I have not sent them"—unsent prophets
- "'The vessels of YHWH's house shall now shortly be brought back'"—false hope
- "If they be prophets... let them now make intercession"—prophet test
- "They shall be carried to Babylon"—vessels taken
- "Until the day that I remember them... and restore them"—future restoration

**Modern Equivalent:** Jeremiah 27 shows prophetic drama—wearing a yoke and sending yoke-messages. The call to submit to Babylon was politically treasonous but spiritually obedient. The vessels were restored under Cyrus (Ezra 1:7-11).

# Jeremiah 32: The Field at Anathoth

*From the Hebrew: הַדָּבָר אֲשֶׁר הָיָה אֶל־יִרְמְיָהוּ (Ha-Davar Asher Hayah El-Yirmeyahu) — The Word That Came to Jeremiah*

---

## The Purchase During the Siege (32:1-15)

**32:1** The word that came to Jeremiah from YHWH in the tenth year of Zedekiah king of Judah, which was the eighteenth year of Nebuchadrezzar.

**32:2** Now at that time the king of Babylon's army was besieging Jerusalem; and Jeremiah the prophet was shut up in the court of the guard, which was in the king of Judah's house.

**32:3** For Zedekiah king of Judah had shut him up, saying: "Wherefore do you prophesy, and say: Thus says YHWH: Behold, I will give this city into the hand of the king of Babylon, and he shall take it;

**32:4** "And Zedekiah king of Judah shall not escape out of the hand of the Chaldeans, but shall surely be delivered into the hand of the king of Babylon, and shall speak with him mouth to mouth, and his eyes shall behold his eyes;

**32:5** "And he shall lead Zedekiah to Babylon, and there shall he be until I remember him," says YHWH; "though you fight with the Chaldeans, you shall not prosper?"

**32:6** And Jeremiah said: "The word of YHWH came unto me, saying:

**32:7** "'Behold, Hanamel the son of Shallum your uncle is coming to you, saying: Buy my field that is in Anathoth; for the right of redemption is yours to buy it.'

**32:8** "So Hanamel my uncle's son came to me in the court of the guard according to the word of YHWH, and said unto me: 'Buy my field, I pray you, that is in Anathoth, which is in the land of Benjamin; for the right of inheritance is yours, and the redemption is yours; buy it for yourself.' Then I knew that this was the word of YHWH.

**32:9** "And I bought the field that was in Anathoth of Hanamel my uncle's son, and weighed him the money, even seventeen shekels of silver.

**32:10** "And I subscribed the deed, and sealed it, and called witnesses, and weighed him the money in the balances.

**32:11** "So I took the deed of the purchase, both that which was sealed, containing the terms and conditions, and that which was open;

**32:12** "And I delivered the deed of the purchase unto Baruch the son of Neriah, the son of Mahseiah, in the presence of Hanamel my uncle's son, and in the presence of the witnesses that subscribed the deed of the purchase, before all the Jews that sat in the court of the guard.

**32:13** "And I charged Baruch before them, saying:

**32:14** "'Thus says YHWH of hosts, the God of Israel: Take these deeds, this deed of the purchase, both that which is sealed, and this deed which is open, and put them in an earthen vessel, that they may continue many days.'

**32:15** "For thus says YHWH of hosts, the God of Israel: 'Houses and fields and vineyards shall yet again be bought in this land.'"

---

## Jeremiah's Prayer (32:16-25)

**32:16** Now after I had delivered the deed of the purchase unto Baruch the son of Neriah, I prayed unto YHWH, saying:

**32:17** "Ah Lord YHWH! Behold, you have made the heaven and the earth by your great power and by your outstretched arm; there is nothing too hard for you;

**32:18** "Who shows lovingkindness unto thousands, and recompenses the iniquity of the fathers into the bosom of their children after them; the great, the mighty God, YHWH of hosts is his name;

**32:19** "Great in counsel, and mighty in work; whose eyes are open upon all the ways of the sons of men, to give every one according to his ways, and according to the fruit of his doings;

**32:20** "Who did set signs and wonders in the land of Egypt, even unto this day, both in Israel and among other men; and made yourself a name, as at this day;

**32:21** "And brought forth your people Israel out of the land of Egypt with signs, and with wonders, and with a strong hand, and with an outstretched arm, and with great terror;

**32:22** "And gave them this land, which you did swear to their fathers to give them, a land flowing with milk and honey;

**32:23** "And they came in, and possessed it; but they hearkened not to your voice, neither walked in your law; they have done nothing of all that you commanded them to do; therefore you have caused all this evil to come upon them;

**32:24** "Behold the mounds, they are come unto the city to take it; and the city is given into the hand of the Chaldeans that fight against it, because of the sword, and of the famine, and of the pestilence; and what you have spoken is come to pass; and, behold, you see it.

**32:25** "Yet you have said unto me, O Lord YHWH: 'Buy the field for money, and call witnesses'; whereas the city is given into the hand of the Chaldeans."

---

## YHWH's Answer (32:26-44)

**32:26** Then came the word of YHWH unto Jeremiah, saying:

**32:27** "Behold, I am YHWH, the God of all flesh; is there any thing too hard for me?

**32:28** "Therefore thus says YHWH: Behold, I will give this city into the hand of the Chaldeans, and into the hand of Nebuchadrezzar king of Babylon, and he shall take it;

**32:29** "And the Chaldeans, that fight against this city, shall come and set this city on fire, and burn it, with the houses, upon whose roofs they have offered unto Baal, and poured out drink-offerings unto other gods, to provoke me.

**32:30** "For the children of Israel and the children of Judah have only done that which was evil in my sight from their youth; for the children of Israel have only provoked me with the work of their hands," says YHWH.

**32:31** "For this city has been to me a provocation of my anger and of my fury from the day that they built it even unto this day, that I should remove it from before my face;

**32:32** "Because of all the evil of the children of Israel and of the children of Judah, which they have done to provoke me, they, their kings, their princes, their priests, and their prophets, and the men of Judah, and the inhabitants of Jerusalem.

**32:33** "And they have turned unto me the back, and not the face; and though I taught them, teaching them betimes and often, yet they have not hearkened to receive instruction.

**32:34** "But they set their detestable things in the house whereon my name is called, to defile it.

**32:35** "And they built the high places of Baal, which are in the valley of the son of Hinnom, to cause their sons and their daughters to pass through the fire unto Molech; which I commanded them not, neither came it into my mind, that they should do this abomination, to cause Judah to sin.

**32:36** "And now therefore thus says YHWH, the God of Israel, concerning this city, whereof you say: 'It is given into the hand of the king of Babylon by the sword, and by the famine, and by the pestilence':

**32:37** "Behold, I will gather them out of all the countries, whither I have driven them in my anger, and in my fury, and in great wrath; and I will bring them back unto this place, and I will cause them to dwell safely;

**32:38** "And they shall be my people, and I will be their God;

**32:39** "And I will give them one heart and one way, that they may fear me forever; for the good of them, and of their children after them;

**32:40** "And I will make an everlasting covenant with them, that I will not turn away from them, to do them good; and I will put my fear in their hearts, that they shall not depart from me.

**32:41** "Yea, I will rejoice over them to do them good, and I will plant them in this land in truth with my whole heart and with my whole soul.

**32:42** "For thus says YHWH: Like as I have brought all this great evil upon this people, so will I bring upon them all the good that I have promised them.

**32:43** "And fields shall be bought in this land, whereof you say: 'It is desolate, without man or beast; it is given into the hand of the Chaldeans.'

**32:44** "Men shall buy fields for money, and subscribe the deeds, and seal them, and call witnesses, in the land of Benjamin, and in the places about Jerusalem, and in the cities of Judah, and in the cities of the hill-country, and in the cities of the Lowland, and in the cities of the South; for I will cause their captivity to return," says YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Historical Setting (32:1-5):**
"In the tenth year of Zedekiah... the eighteenth year of Nebuchadrezzar."

*Ba-shanah ha-asirit le-Tzidqiyyahu... hi shenat shemoneh esreh li-Nevukhadre'zzar*—588/587 BCE.

"The king of Babylon's army was besieging Jerusalem."

*Az cheil melekh-Bavel tzarim al-Yerushalayim*—siege.

"Jeremiah the prophet was shut up in the court of the guard."

*Vi-Yirmeyahu ha-navi hayah kalua ba-chatzer ha-mattarah*—imprisoned.

"Which was in the king of Judah's house."

*Asher beit-melekh Yehudah*—in palace.

"'Wherefore do you prophesy... I will give this city into the hand of the king of Babylon?'"

*Maddua attah niba lemor... hineni noten et-ha-ir ha-zot be-yad melekh-Bavel*—charge.

"'Zedekiah king of Judah shall not escape.'"

*Ve-Tzidqiyyahu melekh-Yehudah lo yimmalet mi-yad ha-Kasdim*—won't escape.

"'Shall speak with him mouth to mouth.'"

*Ve-dibber piv im-piv*—face to face.

"'His eyes shall behold his eyes.'"

*Ve-einav et-einav tir'enah*—eyes see.

**Field Purchase (32:6-15):**
"'Hanamel the son of Shallum your uncle is coming to you.'"

*Hinneh Chanam'el ben-Shallum dodekha ba elekha*—cousin coming.

"'Buy my field that is in Anathoth.'"

*Qeneh-lekha et-saddi asher ba-Anatot*—buy field.

"'For the right of redemption is yours.'"

*Ki lekha mishpat ha-ge'ullah liqnot*—redemption right.

**Leviticus 25:25:**
According to Leviticus 25:25, a kinsman could redeem family land.

"I bought the field... seventeen shekels of silver."

*Va-eqneh et-ha-sadeh... shiv'ah sheqalim ve-asarah ha-kasef*—17 shekels.

"I subscribed the deed, and sealed it, and called witnesses."

*Va-ekhtov ba-sefer va-echtom va-a'ed edim*—legal process.

"I weighed him the money in the balances."

*Va-eshqol ha-kesef be-moznayyim*—weighed silver.

"The deed of the purchase, both that which was sealed... and that which was open."

*Et-sefer ha-miqnah et-he-chatum... ve-et-ha-galui*—sealed and open copy.

"I delivered the deed of the purchase unto Baruch the son of Neriah."

*Va-etten et-ha-sefer ha-miqnah el-Barukh ben-Neriyyah*—to Baruch.

**The Key Verses (32:14-15):**
"'Take these deeds... and put them in an earthen vessel.'"

*Laqo'ach et-ha-sefarim ha-elleh... ve-netattam bi-kheli-chares*—clay jar.

"'That they may continue many days.'"

*Lema'an ya'amdu yamim rabbim*—many days.

"'Houses and fields and vineyards shall yet again be bought in this land.'"

*Od yiqqanu vatim u-sadot u-keramim ba-aretz ha-zot*—future purchases.

**Sign-Act:**
During siege, Jeremiah buys land as sign of future restoration.

**Jeremiah's Prayer (32:16-25):**
**The Key Verse (32:17):**
"Ah Lord YHWH!"

*Ahahh Adonai YHWH*—alas Lord.

"You have made the heaven and the earth by your great power."

*Hinneh attah asita et-ha-shamayim ve-et-ha-aretz be-khochakha ha-gadol*—made heaven/earth.

"By your outstretched arm."

*U-vi-zero'akha ha-netuyah*—outstretched arm.

"There is nothing too hard for you."

*Lo-yippale mimmekha kol-davar*—nothing too hard.

**The Key Verses (32:18-19):**
"Who shows lovingkindness unto thousands."

*Oseh chesed la-alafim*—lovingkindness to thousands.

"Recompenses the iniquity of the fathers into the bosom of their children."

*U-meshalleim avon avot el-cheiq beneihem achareihem*—recompense.

"The great, the mighty God."

*Ha-El ha-gadol ha-gibbor*—great mighty God.

"YHWH of hosts is his name."

*YHWH Tzeva'ot shemo*—YHWH of hosts.

"Great in counsel, and mighty in work."

*Gedol ha-etzah ve-rav ha-aliliyyah*—great counsel, mighty work.

"Whose eyes are open upon all the ways of the sons of men."

*Asher einekha pequchot al-kol-darkhei benei adam*—eyes on all.

"To give every one according to his ways."

*Latet le-ish ki-derakhav*—according to ways.

"According to the fruit of his doings."

*Ve-khi-feri ma'alalav*—fruit of doings.

"Who did set signs and wonders in the land of Egypt."

*Asher-samta otot u-mofetim be-eretz Mitzrayim*—Exodus signs.

"Made yourself a name, as at this day."

*Va-ta'as-lekha shem ke-ha-yom ha-zeh*—made name.

"Brought forth your people Israel out of... Egypt."

*Va-totze et-ammekha Yisra'el me-eretz Mitzrayim*—brought out.

"With signs, and with wonders."

*Be-otot u-ve-mofetim*—signs/wonders.

"With a strong hand, and with an outstretched arm."

*U-ve-yad chazaqah u-vi-zero'a netuyah*—strong hand.

"With great terror."

*U-ve-mora gadol*—great terror.

"Gave them this land... a land flowing with milk and honey."

*Va-titten lahem et-ha-aretz ha-zot... eretz zavat chalav u-devash*—gave land.

"They came in, and possessed it."

*Va-yavo'u va-yirshu otah*—possessed.

"They hearkened not to your voice."

*Ve-lo-sham'u ve-qolekha*—didn't hear.

"Neither walked in your law."

*U-ve-toratekha lo halakhu*—didn't walk in law.

"Therefore you have caused all this evil to come upon them."

*Va-taqre otam et kol-ha-ra'ah ha-zot*—caused evil.

"Behold the mounds, they are come unto the city to take it."

*Hinneh ha-solelot ba'u ha-ir le-lokhddah*—siege mounds.

"The city is given into the hand of the Chaldeans."

*Ve-ha-ir nittenah be-yad ha-Kasdim*—given to Chaldeans.

"Yet you have said unto me... 'Buy the field for money.'"

*Ve-attah amarta elai... qeneh-lekha ha-sadeh ba-kasef*—buy field.

"Whereas the city is given into the hand of the Chaldeans."

*Ve-ha-ir nittenah be-yad ha-Kasdim*—but city falling.

**YHWH's Answer (32:26-44):**
**The Key Verse (32:27):**
"Behold, I am YHWH, the God of all flesh."

*Hinneh ani YHWH Elohei kol-basar*—God of all flesh.

"Is there any thing too hard for me?"

*Ha-mimmeni yippale kol-davar*—anything too hard?

"I will give this city into the hand of the Chaldeans."

*Hineni noten et-ha-ir ha-zot be-yad ha-Kasdim*—give city.

"The Chaldeans... shall come and set this city on fire."

*U-va'u ha-Kasdim... ve-hitztzitu et-ha-ir ha-zot ba-esh*—burn city.

"Upon whose roofs they have offered unto Baal."

*Asher qitteru al-gaggoteihen la-Ba'al*—rooftop Baal worship.

"The children of Israel and the children of Judah have only done... evil."

*Ki hayu benei-Yisra'el u-venei Yehudah akh osim ha-ra*—only evil.

"From their youth."

*Mi-ne'ureihem*—from youth.

"This city has been to me a provocation of my anger."

*Ki al-appi ve-al-chamati hayetah li ha-ir ha-zot*—provocation.

"From the day that they built it."

*Le-min-ha-yom asher banu otah*—since built.

"They have turned unto me the back, and not the face."

*Va-yifnu elai oref ve-lo fanim*—back, not face.

"Though I taught them, teaching them betimes and often."

*Ve-lammed otam hashkem ve-lammed*—taught repeatedly.

"They have not hearkened to receive instruction."

*Ve-lo sham'u laqachat musar*—didn't receive instruction.

"They set their detestable things in the house whereon my name is called."

*Va-yasimu shiqqutzehem ba-bayit asher-niqra shemi alav*—abominations in temple.

"They built the high places of Baal... in the valley of the son of Hinnom."

*Va-yivnu et-bamot ha-Ba'al asher be-gei ven-Hinnom*—Baal high places.

"To cause their sons and their daughters to pass through the fire unto Molech."

*Le-ha'avir et-beneihem ve-et-benoteihem la-Molekh*—child sacrifice.

"Which I commanded them not."

*Asher lo-tzivvitim*—not commanded.

"Neither came it into my mind."

*Ve-lo aletah al-libbi*—never in mind.

**The Key Verses (32:37-41):**
"I will gather them out of all the countries."

*Hineni meqabbetzam mi-kol-ha-aratzot*—gather.

"Whither I have driven them in my anger."

*Asher hiddachtim sham be-appi*—driven in anger.

"I will bring them back unto this place."

*Va-hashivotim el-ha-maqom ha-zeh*—bring back.

"I will cause them to dwell safely."

*Ve-hoshavtim la-vetach*—dwell safely.

**The Key Verse (32:38):**
"They shall be my people, and I will be their God."

*Ve-hayu li le-am va-ani ehyeh lahem le-lohim*—covenant formula.

**The Key Verse (32:39):**
"I will give them one heart and one way."

*Ve-natatti lahem lev echad ve-derekh echad*—one heart, one way.

"That they may fear me forever."

*Le-yir'ah oti kol-ha-yamim*—fear forever.

"For the good of them, and of their children after them."

*Le-tov lahem ve-li-vneihem achareihem*—for their good.

**The Key Verse (32:40):**
"I will make an everlasting covenant with them."

*Ve-kharati lahem berit olam*—everlasting covenant.

"I will not turn away from them, to do them good."

*Asher lo-ashuv me-achareihem le-heitivii otam*—won't turn from good.

"I will put my fear in their hearts."

*Ve-et-yir'ati etten bi-levavam*—fear in hearts.

"That they shall not depart from me."

*Le-vilti sur me-alai*—won't depart.

**The Key Verse (32:41):**
"I will rejoice over them to do them good."

*Ve-sasti aleihem le-heitiv otam*—rejoice over them.

"I will plant them in this land in truth."

*U-neta'tim ba-aretz ha-zot be-emet*—plant in truth.

"With my whole heart and with my whole soul."

*Be-khol-libbi u-ve-khol-nafshi*—whole heart/soul.

**YHWH's Whole Heart:**
Remarkable—YHWH commits "with my whole heart and with my whole soul."

**The Key Verses (32:42-44):**
"Like as I have brought all this great evil... so will I bring upon them all the good."

*Ki kha-asher heveti el-ha-am ha-zeh et kol-ha-ra'ah ha-gedolah ha-zot ken anokhi mevi aleihem et-kol-ha-tovah*—evil to good.

"Fields shall be bought in this land."

*Ve-niqnu sadot ba-aretz ha-zot*—fields bought.

"Whereof you say: 'It is desolate.'"

*Asher attem omerim shemamah hi*—called desolate.

"Men shall buy fields for money, and subscribe the deeds."

*Sadot ba-kesef yiqnu ve-khatov ba-sefer ve-chatom*—normal commerce.

"In the land of Benjamin, and in the places about Jerusalem."

*Be-eretz Binyamin u-vi-svivei Yerushalayim*—Benjamin, Jerusalem.

"In the cities of Judah."

*U-ve-arei Yehudah*—Judah cities.

"In the cities of the hill-country, and in the cities of the Lowland, and in the cities of the South."

*U-ve-arei ha-har u-ve-arei ha-shefelah u-ve-arei ha-negev*—all regions.

"For I will cause their captivity to return."

*Ki-ashiv et-shevutam*—restore captivity.

**Archetypal Layer:** Jeremiah 32 contains **Jeremiah's purchase of the field during siege (32:6-15)**, **"There is nothing too hard for you" (32:17)**, **"Is there any thing too hard for me?" (32:27)**, **"I will give them one heart and one way" (32:39)**, and **everlasting covenant (32:40)**.

**Ethical Inversion Applied:**
- "The tenth year of Zedekiah... the eighteenth year of Nebuchadrezzar"—588/587 BCE
- "The king of Babylon's army was besieging Jerusalem"—siege
- "Jeremiah the prophet was shut up in the court of the guard"—imprisoned
- "'Buy my field that is in Anathoth'"—redemption
- "I bought the field... seventeen shekels of silver"—17 shekels
- "I subscribed the deed, and sealed it, and called witnesses"—legal
- "I delivered the deed of the purchase unto Baruch"—to Baruch
- "'Put them in an earthen vessel, that they may continue many days'"—clay jar
- "'Houses and fields and vineyards shall yet again be bought'"—future purchase
- "You have made the heaven and the earth by your great power"—creator
- "There is nothing too hard for you"—nothing too hard
- "Who shows lovingkindness unto thousands"—lovingkindness
- "Great in counsel, and mighty in work"—counsel and work
- "Who did set signs and wonders in... Egypt"—Exodus
- "They came in, and possessed it; but they hearkened not"—didn't obey
- "Therefore you have caused all this evil to come upon them"—consequence
- "Behold the mounds, they are come unto the city"—siege mounds
- "'Buy the field for money'... whereas the city is given"—paradox
- "Behold, I am YHWH, the God of all flesh"—God of all flesh
- "Is there any thing too hard for me?"—nothing too hard
- "I will give this city into the hand of the Chaldeans"—give city
- "They have only done... evil in my sight from their youth"—evil
- "They have turned unto me the back, and not the face"—back, not face
- "They built the high places of Baal... to cause their sons... to pass through the fire"—child sacrifice
- "I will gather them out of all the countries"—gather
- "I will bring them back unto this place"—bring back
- "They shall be my people, and I will be their God"—covenant formula
- "I will give them one heart and one way"—one heart
- "I will make an everlasting covenant with them"—everlasting
- "I will not turn away from them, to do them good"—won't turn
- "I will put my fear in their hearts"—fear in hearts
- "I will rejoice over them to do them good"—rejoice
- "I will plant them in this land in truth with my whole heart and with my whole soul"—whole heart
- "Like as I have brought all this great evil... so will I bring upon them all the good"—evil to good
- "Fields shall be bought in this land"—commerce restored

**Modern Equivalent:** Jeremiah 32's field purchase during siege is a powerful sign-act of hope. "Nothing too hard" (32:17, 27) echoes Genesis 18:14. "One heart and one way" (32:39) and "everlasting covenant" (32:40) expand the new covenant theme. YHWH's commitment "with my whole heart and with my whole soul" (32:41) is remarkable.

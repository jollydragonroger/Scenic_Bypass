# Jeremiah 31: The New Covenant

*From the Hebrew: בָּעֵת הַהִיא (Ba-Et Ha-Hi) — At That Time*

---

## Israel's Restoration (31:1-6)

**31:1** "At that time," says YHWH, "will I be the God of all the families of Israel, and they shall be my people."

**31:2** Thus says YHWH: "The people that were left of the sword have found grace in the wilderness, even Israel, when I go to cause him to rest."

**31:3** "From afar YHWH appeared unto me." "Yea, I have loved you with an everlasting love; therefore with lovingkindness have I drawn you.

**31:4** "Again will I build you, and you shall be built, O virgin of Israel; again shall you be adorned with your tabrets, and shall go forth in the dances of them that make merry.

**31:5** "Again shall you plant vineyards upon the mountains of Samaria; the planters shall plant, and shall have the use thereof.

**31:6** "For there shall be a day, that the watchmen upon the hills of Ephraim shall cry: 'Arise, and let us go up to Zion, unto YHWH our God.'"

---

## The Great Ingathering (31:7-14)

**31:7** For thus says YHWH: "Sing with gladness for Jacob, and shout at the head of the nations; announce, praise, and say: 'O YHWH, save your people, the remnant of Israel.'

**31:8** "Behold, I will bring them from the north country, and gather them from the uttermost parts of the earth, and with them the blind and the lame, the woman with child and her that travails with child together; a great company shall they return hither.

**31:9** "They shall come with weeping, and with supplications will I lead them; I will cause them to walk by rivers of waters, in a straight way wherein they shall not stumble; for I am a father to Israel, and Ephraim is my first-born."

**31:10** Hear the word of YHWH, O you nations, and declare it in the isles afar off, and say: "He that scattered Israel will gather him, and keep him, as a shepherd does his flock."

**31:11** For YHWH has ransomed Jacob, and redeemed him from the hand of him that was stronger than he.

**31:12** And they shall come and sing in the height of Zion, and shall flow unto the goodness of YHWH, to the corn, and to the wine, and to the oil, and to the young of the flock and of the herd; and their soul shall be as a watered garden, and they shall not sorrow any more at all.

**31:13** Then shall the virgin rejoice in the dance, and the young men and the old together; for I will turn their mourning into joy, and will comfort them, and make them rejoice from their sorrow.

**31:14** And I will satiate the soul of the priests with fatness, and my people shall be satisfied with my goodness," says YHWH.

---

## Rachel Weeping for Her Children (31:15-17)

**31:15** Thus says YHWH: "A voice is heard in Ramah, lamentation, and bitter weeping, Rachel weeping for her children; she refuses to be comforted for her children, because they are not."

**31:16** Thus says YHWH: "Refrain your voice from weeping, and your eyes from tears; for your work shall be rewarded," says YHWH; "and they shall come back from the land of the enemy.

**31:17** "And there is hope for your future," says YHWH; "and your children shall return to their own border."

---

## Ephraim's Repentance (31:18-22)

**31:18** "I have surely heard Ephraim bemoaning himself: 'You have chastised me, and I was chastised, as a calf untrained; turn me, and I shall be turned, for you are YHWH my God.

**31:19** "'For after I was turned, I repented, and after I was made to know, I smote upon my thigh; I was ashamed, yea, even confounded, because I did bear the reproach of my youth.'

**31:20** "Is Ephraim my precious son? Is he a child of delight? For as often as I speak of him, I do earnestly remember him still; therefore my heart yearns for him, I will surely have compassion upon him," says YHWH.

**31:21** "Set up road-marks for yourself, make yourself guide-posts; set your heart toward the highway, even the way by which you went; return, O virgin of Israel, return to these your cities.

**31:22** "How long will you go hither and thither, O you backsliding daughter? For YHWH has created a new thing in the earth: a woman shall encompass a man."

---

## Blessings on Judah and Israel (31:23-26)

**31:23** Thus says YHWH of hosts, the God of Israel: "Yet again shall they use this speech in the land of Judah and in the cities thereof, when I shall turn their captivity: 'YHWH bless you, O habitation of righteousness, O mountain of holiness.'

**31:24** "And Judah and all the cities thereof shall dwell therein together: the husbandmen, and they that go forth with flocks.

**31:25** "For I have satiated the weary soul, and every pining soul have I replenished."

**31:26** Upon this I awaked, and beheld; and my sleep was sweet unto me.

---

## Sowing and Building (31:27-30)

**31:27** "Behold, the days come," says YHWH, "that I will sow the house of Israel and the house of Judah with the seed of man, and with the seed of beast.

**31:28** "And it shall come to pass, that like as I have watched over them to pluck up and to break down, and to overthrow and to destroy, and to afflict; so will I watch over them to build and to plant," says YHWH.

**31:29** "In those days they shall say no more: 'The fathers have eaten sour grapes, and the children's teeth are set on edge.'

**31:30** "But every one shall die for his own iniquity; every man that eats the sour grapes, his teeth shall be set on edge."

---

## The New Covenant (31:31-34)

**31:31** "Behold, the days come," says YHWH, "that I will make a new covenant with the house of Israel, and with the house of Judah;

**31:32** "Not according to the covenant that I made with their fathers in the day that I took them by the hand to bring them out of the land of Egypt; forasmuch as they broke my covenant, although I was a lord over them," says YHWH.

**31:33** "But this is the covenant that I will make with the house of Israel after those days," says YHWH: "I will put my law in their inward parts, and in their heart will I write it; and I will be their God, and they shall be my people;

**31:34** "And they shall teach no more every man his neighbour, and every man his brother, saying: 'Know YHWH'; for they shall all know me, from the least of them unto the greatest of them," says YHWH; "for I will forgive their iniquity, and their sin will I remember no more."

---

## Israel's Permanence (31:35-37)

**31:35** Thus says YHWH, who gives the sun for a light by day, and the ordinances of the moon and of the stars for a light by night, who stirs up the sea, that the waves thereof roar, YHWH of hosts is his name:

**31:36** "If these ordinances depart from before me," says YHWH, "then the seed of Israel also shall cease from being a nation before me forever."

**31:37** Thus says YHWH: "If heaven above can be measured, and the foundations of the earth searched out beneath, then will I also cast off all the seed of Israel for all that they have done," says YHWH.

---

## The Rebuilt City (31:38-40)

**31:38** "Behold, the days come," says YHWH, "that the city shall be built to YHWH from the tower of Hananel unto the gate of the corner.

**31:39** "And the measuring line shall yet go out straight forward unto the hill Gareb, and shall turn about unto Goah.

**31:40** "And the whole valley of the dead bodies, and of the ashes, and all the fields unto the brook Kidron, unto the corner of the horse gate toward the east, shall be holy unto YHWH; it shall not be plucked up, nor thrown down any more forever."

---

## Synthesis Notes

**Key Restorations:**

**Israel's Restoration (31:1-6):**
"At that time, will I be the God of all the families of Israel."

*Ba-et ha-hi... ehyeh le-lohim le-khol mishpechot Yisra'el*—God of all families.

"They shall be my people."

*Ve-hemmah yihyu-li le-am*—my people.

"The people that were left of the sword have found grace in the wilderness."

*Matza chen ba-midbar am seredei cherev*—grace in wilderness.

**The Key Verse (31:3):**
"I have loved you with an everlasting love."

*Ve-ahavat olam ahavtikh*—everlasting love.

"Therefore with lovingkindness have I drawn you."

*Al-ken meshakhtikh chased*—drawn with lovingkindness.

"Again will I build you, and you shall be built, O virgin of Israel."

*Od evnekh ve-nivneit betulat Yisra'el*—rebuilt.

"Again shall you be adorned with your tabrets."

*Od ta'di tuppayikh*—adorned with tambourines.

"Shall go forth in the dances of them that make merry."

*Ve-yatzat bi-mechol mesacheqim*—joyful dances.

"The watchmen upon the hills of Ephraim shall cry: 'Arise, and let us go up to Zion.'"

*Ki yesh-yom qar'u notzrim be-har Efrayim qumu ve-na'aleh Tziyyon el-YHWH Eloheinu*—Ephraim to Zion.

**Great Ingathering (31:7-14):**
"Sing with gladness for Jacob."

*Rannu le-Ya'aqov simchah*—sing for Jacob.

"Shout at the head of the nations."

*Ve-tzahalu be-rosh ha-goyim*—shout among nations.

"'O YHWH, save your people, the remnant of Israel.'"

*Hoshia YHWH et-ammekha et she'erit Yisra'el*—save remnant.

"I will bring them from the north country."

*Hineni mevi otam me-eretz tzafon*—from north.

"Gather them from the uttermost parts of the earth."

*Ve-qibbatztim mi-yarketei-aretz*—uttermost parts.

"With them the blind and the lame."

*Bam ivver u-fisse'ach*—blind and lame.

"The woman with child and her that travails."

*Harah ve-yoledet yachdav*—pregnant and birthing.

"A great company shall they return."

*Qahal gadol yashuvu hennah*—great company.

**The Key Verse (31:9):**
"They shall come with weeping."

*Bi-vekhi yavo'u*—come weeping.

"With supplications will I lead them."

*U-ve-tachanunuim ovilem*—lead with supplications.

"I will cause them to walk by rivers of waters."

*Olikhem el-nachalei mayim*—by waters.

"In a straight way wherein they shall not stumble."

*Be-derekh yashar lo yikkashelu vah*—straight path.

"I am a father to Israel."

*Ki-hayiti le-Yisra'el le-av*—father to Israel.

"Ephraim is my first-born."

*Ve-Efrayim bekhori hu*—Ephraim firstborn.

**The Key Verses (31:10-14):**
"He that scattered Israel will gather him."

*Mezareh Yisra'el yeqabbetzennu*—scatterer gathers.

"Keep him, as a shepherd does his flock."

*U-shemaro ke-ro'eh edro*—keep like shepherd.

"YHWH has ransomed Jacob."

*Ki-fadah YHWH et-Ya'aqov*—ransomed.

"Redeemed him from the hand of him that was stronger than he."

*U-ge'alo mi-yad chazaq mimmenu*—redeemed from stronger.

"They shall come and sing in the height of Zion."

*U-va'u ve-rinnu vi-merom Tziyyon*—sing on Zion.

"Flow unto the goodness of YHWH."

*Ve-naharu el-tuv YHWH*—flow to goodness.

"Their soul shall be as a watered garden."

*Ve-hayetah nafsham ke-gan raveh*—watered garden.

"They shall not sorrow any more at all."

*Ve-lo-yosifu le-da'avah od*—no more sorrow.

"I will turn their mourning into joy."

*Ve-hafakhti evlam le-sason*—mourning to joy.

"Will comfort them."

*Ve-nichamtim*—comfort.

"Make them rejoice from their sorrow."

*Ve-simachtim mi-ygonam*—rejoice from sorrow.

**Rachel Weeping (31:15-17):**
**The Key Verse (31:15):**
"A voice is heard in Ramah."

*Qol be-Ramah nishma*—voice in Ramah.

"Lamentation, and bitter weeping."

*Nehi bekhi tamrurim*—lamentation, bitter weeping.

"Rachel weeping for her children."

*Rachel mevakkah al-banekha*—Rachel weeps.

"She refuses to be comforted for her children."

*Me'anah le-hinnachem al-banekha*—refuses comfort.

"Because they are not."

*Ki einennu*—they are not.

**Matthew 2:18:**
Quoted in Matthew 2:18 regarding the slaughter of the innocents.

**The Key Verses (31:16-17):**
"Refrain your voice from weeping."

*Min'i qolekh mi-bekhi*—stop weeping.

"Your eyes from tears."

*Ve-einayikh mi-dim'ah*—stop tears.

"Your work shall be rewarded."

*Ki yesh sakhar li-fe'ullatekh*—work rewarded.

"They shall come back from the land of the enemy."

*Ve-shavu me-eretz oyev*—return from enemy land.

"There is hope for your future."

*Ve-yesh-tiqvah le-acharitekh*—hope for future.

"Your children shall return to their own border."

*Ve-shavu vanim li-gevulam*—children return.

**Ephraim's Repentance (31:18-22):**
"I have surely heard Ephraim bemoaning himself."

*Shamoa shama'ti Efrayim mitnoded*—heard Ephraim.

"'You have chastised me, and I was chastised.'"

*Yissartani va-ivvaser*—chastised.

"'As a calf untrained.'"

*Ke-egel lo lummad*—untrained calf.

"'Turn me, and I shall be turned.'"

*Hashiveni ve-ashuvah*—turn me, I'll turn.

"'For you are YHWH my God.'"

*Ki attah YHWH Elohai*—you're my God.

"'After I was turned, I repented.'"

*Ki-acharei shuvi nichamti*—after turning, repented.

"'I smote upon my thigh.'"

*Safaqti al-yarekh*—struck thigh (regret).

"'I was ashamed, yea, even confounded.'"

*Boshti ve-gam-niklamti*—ashamed, confounded.

"'Because I did bear the reproach of my youth.'"

*Ki nasati cherpat ne'urai*—youth's reproach.

**The Key Verse (31:20):**
"Is Ephraim my precious son?"

*Ha-ven yaqqir li Efrayim*—precious son?

"Is he a child of delight?"

*Im yeled sha'ashu'im*—delight child?

"For as often as I speak of him, I do earnestly remember him still."

*Ki-middei dabberi bo zakhor ezkerennu od*—remember him.

"My heart yearns for him."

*Al-ken hamu me'ai lo*—heart yearns.

"I will surely have compassion upon him."

*Rachem arachamennu*—surely compassion.

**The Key Verse (31:22):**
"YHWH has created a new thing in the earth."

*Ki-bara YHWH chadashah ba-aretz*—new creation.

"A woman shall encompass a man."

*Neqevah tesovev gaver*—woman encompasses man.

**Mysterious Verse:**
This enigmatic verse has many interpretations—perhaps restored Israel (feminine) will court YHWH (masculine), reversing the usual pattern.

**Blessings (31:23-26):**
"'YHWH bless you, O habitation of righteousness, O mountain of holiness.'"

*Yevarekekha YHWH neveh-tzedeq har ha-qodesh*—blessing formula.

"I have satiated the weary soul."

*Ki hirveti nefesh ayefah*—satiated weary.

"Every pining soul have I replenished."

*Ve-khol-nefesh da'avah mille'ti*—replenished pining.

**Sowing/Building (31:27-30):**
"I will sow the house of Israel and the house of Judah."

*Ve-zara'ti et-beit Yisra'el ve-et-beit Yehudah*—sow Israel/Judah.

"With the seed of man, and with the seed of beast."

*Zera adam ve-zera behemah*—human and animal seed.

"Like as I have watched over them to pluck up... so will I watch over them to build and to plant."

*Ka-asher shaqadti aleihem lintosh... ken eshqod aleihem livnot ve-linto'a*—watch to build.

**The Key Verses (31:29-30):**
"'The fathers have eaten sour grapes, and the children's teeth are set on edge.'"

*Avot akhlu voser ve-shinei vanim tiqhenah*—proverb.

"Every one shall die for his own iniquity."

*Ki im-ish ba-avono yamut*—die for own sin.

**Individual Responsibility:**
Ezekiel 18:2-4 elaborates this principle.

**THE NEW COVENANT (31:31-34):**
**The Key Verse (31:31):**
"Behold, the days come, that I will make a new covenant."

*Hinneh yamim ba'im... ve-kharati et-beit Yisra'el... berit chadashah*—new covenant.

"With the house of Israel, and with the house of Judah."

*Et-beit Yisra'el ve-et-beit Yehudah*—Israel and Judah.

**The Key Verse (31:32):**
"Not according to the covenant that I made with their fathers."

*Lo kha-berit asher karati et-avotam*—not like old covenant.

"In the day that I took them by the hand to bring them out of... Egypt."

*Be-yom hecheziqqi be-yadam le-hotzi'am me-eretz Mitzrayim*—Exodus covenant.

"Forasmuch as they broke my covenant."

*Asher-hemmah heferu et-beriti*—they broke it.

"Although I was a lord over them."

*Ve-anokhi ba'alti vam*—I was husband/lord.

**The Key Verse (31:33):**
"This is the covenant that I will make."

*Ki zot ha-berit asher ekhrot*—this covenant.

"After those days."

*Acharei ha-yamim ha-hem*—after those days.

"I will put my law in their inward parts."

*Natatti et-torati be-qirbam*—law in inward parts.

"In their heart will I write it."

*Ve-al-libbam ekhtevenah*—write on heart.

"I will be their God, and they shall be my people."

*Ve-hayiti lahem le-lohim ve-hemmah yihyu-li le-am*—covenant formula.

**The Key Verse (31:34):**
"They shall teach no more every man his neighbour."

*Ve-lo yelammdu od ish et-re'ehu*—no more teaching.

"And every man his brother, saying: 'Know YHWH.'"

*Ve-ish et-achiv lemor de'u et-YHWH*—know YHWH.

"For they shall all know me."

*Ki-khullam yed'u oti*—all know me.

"From the least of them unto the greatest of them."

*Le-miqtannam ve-ad-gedolam*—least to greatest.

"I will forgive their iniquity."

*Ki eslach la-avonam*—forgive iniquity.

"Their sin will I remember no more."

*U-le-chatta'tam lo ezkor-od*—sin not remembered.

**New Covenant:**
This is the only explicit "new covenant" text in the Hebrew Bible. Hebrews 8:8-12 and 10:16-17 quote it extensively.

**Israel's Permanence (31:35-37):**
"Who gives the sun for a light by day."

*Ha-noten shemesh le-or yomam*—sun for day.

"The ordinances of the moon and of the stars for a light by night."

*Chuqqot yareach ve-khokhavim le-or laylah*—moon and stars.

"Who stirs up the sea, that the waves thereof roar."

*Roga ha-yam va-yehemu gallav*—stirs sea.

"If these ordinances depart from before me."

*Im-yamushu ha-chuqqim ha-elleh mi-lefanai*—if ordinances depart.

"Then the seed of Israel also shall cease from being a nation."

*Gam zera Yisra'el yishbetu mi-heyot goy lefanai*—Israel ceases.

"If heaven above can be measured."

*Im-yimmaddu shamayim mi-le-ma'alah*—measure heaven.

"And the foundations of the earth searched out beneath."

*Ve-yechaqeru mosdei-eretz le-mattah*—search foundations.

"Then will I also cast off all the seed of Israel."

*Gam-ani em'as be-khol-zera Yisra'el*—cast off.

**Eternal Promise:**
Israel's permanence is as certain as cosmic order.

**Rebuilt City (31:38-40):**
"The city shall be built to YHWH."

*Ve-nivnetah ha-ir la-YHWH*—city built.

"From the tower of Hananel unto the gate of the corner."

*Mi-migdal Chanan'el ad-sha'ar ha-pinnah*—Hananel to corner.

"The whole valley of the dead bodies, and of the ashes."

*Ve-khol-ha-emeq ha-pegarim ve-ha-deshen*—corpse valley.

"All the fields unto the brook Kidron."

*Ve-khol-ha-shedemot ad-nachal Qidron*—to Kidron.

"Shall be holy unto YHWH."

*Qodesh la-YHWH*—holy to YHWH.

"It shall not be plucked up, nor thrown down any more forever."

*Lo-yinnates ve-lo-yehares od le-olam*—never destroyed.

**Archetypal Layer:** Jeremiah 31 is the theological climax of the book, containing **"I have loved you with an everlasting love" (31:3)**, **"A voice is heard in Ramah, Rachel weeping for her children" (31:15)**, **THE NEW COVENANT (31:31-34)**—the only explicit new covenant text, and **Israel's permanence like cosmic order (31:35-37)**.

**Ethical Inversion Applied:**
- "I have loved you with an everlasting love"—everlasting love
- "With lovingkindness have I drawn you"—drawn with kindness
- "Again will I build you"—rebuilt
- "The watchmen upon the hills of Ephraim shall cry: 'Let us go up to Zion'"—Ephraim to Zion
- "Sing with gladness for Jacob"—sing
- "'O YHWH, save your people, the remnant of Israel'"—save remnant
- "I will bring them from the north country"—from north
- "With them the blind and the lame"—inclusive
- "They shall come with weeping"—weeping return
- "I am a father to Israel"—father
- "Ephraim is my first-born"—firstborn
- "He that scattered Israel will gather him"—gather
- "YHWH has ransomed Jacob"—ransomed
- "Their soul shall be as a watered garden"—watered garden
- "I will turn their mourning into joy"—mourning to joy
- "A voice is heard in Ramah"—Ramah voice
- "Rachel weeping for her children"—Rachel weeps
- "She refuses to be comforted... because they are not"—refuses comfort
- "Refrain your voice from weeping"—stop weeping
- "There is hope for your future"—hope
- "Your children shall return"—children return
- "'Turn me, and I shall be turned'"—turn me
- "Is Ephraim my precious son?"—precious
- "My heart yearns for him"—heart yearns
- "YHWH has created a new thing in the earth"—new creation
- "I will sow the house of Israel"—sow
- "Like as I have watched over them to pluck up... so will I watch over them to build"—reverse
- "'The fathers have eaten sour grapes'"—individual responsibility
- "I will make a new covenant"—NEW COVENANT
- "Not according to the covenant that I made with their fathers"—different
- "I will put my law in their inward parts"—inward law
- "In their heart will I write it"—heart-written
- "I will be their God, and they shall be my people"—covenant formula
- "They shall teach no more... saying: 'Know YHWH'"—universal knowledge
- "They shall all know me, from the least... unto the greatest"—all know
- "I will forgive their iniquity"—forgive
- "Their sin will I remember no more"—sin forgotten
- "If these ordinances depart... then the seed of Israel also shall cease"—cosmic permanence
- "The city shall be built to YHWH"—rebuilt
- "It shall not be plucked up, nor thrown down any more forever"—permanent

**Modern Equivalent:** Jeremiah 31 is the theological heart of Jeremiah. The New Covenant (31:31-34) is quoted in Hebrews 8:8-12 and 10:16-17 as fulfilled in Christ. Key features: (1) law written on hearts, (2) universal knowledge of God, (3) complete forgiveness. "Rachel weeping" (31:15) is quoted in Matthew 2:18.

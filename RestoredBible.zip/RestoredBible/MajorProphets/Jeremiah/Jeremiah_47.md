# Jeremiah 47: Oracle Against the Philistines

*From the Hebrew: אֲשֶׁר הָיָה דְבַר־יְהוָה אֶל־יִרְמְיָהוּ הַנָּבִיא אֶל־פְּלִשְׁתִּים (Asher Hayah Devar-YHWH El-Yirmeyahu Ha-Navi El-Pelishtim) — The Word of YHWH That Came to Jeremiah the Prophet Concerning the Philistines*

---

## The Flood from the North (47:1-7)

**47:1** The word of YHWH that came to Jeremiah the prophet concerning the Philistines, before that Pharaoh smote Gaza.

**47:2** Thus says YHWH: "Behold, waters rise up out of the north, and shall become an overflowing stream, and shall overflow the land and all that is therein, the city and them that dwell therein; and the men shall cry, and all the inhabitants of the land shall wail.

**47:3** "At the noise of the stamping of the hoofs of his strong ones, at the rushing of his chariots, at the rumbling of his wheels, the fathers look not back to their children for feebleness of hands;

**47:4** "Because of the day that comes to spoil all the Philistines, to cut off from Tyre and Zidon every helper that remains; for YHWH will spoil the Philistines, the remnant of the isle of Caphtor.

**47:5** "Baldness is come upon Gaza; Ashkelon is brought to nought, the remnant of their valley; how long will you cut yourself?

**47:6** "O you sword of YHWH, how long will it be ere you be quiet? Put up yourself into your scabbard, rest, and be still.

**47:7** "How can it be quiet, seeing YHWH has given it a charge? Against Ashkelon, and against the sea-shore, there has he appointed it."

---

## Synthesis Notes

**Key Restorations:**

**Setting (47:1):**
"The word of YHWH that came to Jeremiah the prophet concerning the Philistines."

*Asher hayah devar-YHWH el-Yirmeyahu ha-navi el-Pelishtim*—concerning Philistines.

"Before that Pharaoh smote Gaza."

*Be-terem yakkeh Far'oh et-Azzah*—before Pharaoh struck Gaza.

**Historical Context:**
Either Pharaoh Neco's campaign (609 BCE) or Hophra's campaign (588 BCE).

**Flood from North (47:2-4):**
**The Key Verse (47:2):**
"'Behold, waters rise up out of the north.'"

*Hinneh mayim olim mi-tzafon*—waters from north.

"'Shall become an overflowing stream.'"

*Ve-hayu le-nachal shotef*—overflowing stream.

"'Shall overflow the land and all that is therein.'"

*Ve-yishtefu eretz u-melo'ah*—flood land.

"'The city and them that dwell therein.'"

*Ir ve-yoshevei vah*—city and inhabitants.

"'The men shall cry.'"

*Ve-za'aqu ha-adam*—men cry.

"'All the inhabitants of the land shall wail.'"

*Ve-heililu kol yoshev ha-aretz*—wail.

**The Key Verse (47:3):**
"'At the noise of the stamping of the hoofs of his strong ones.'"

*Mi-qol sha'atat parsot abbirav*—hoofbeats.

"'At the rushing of his chariots.'"

*Me-ra'ash le-rikhbo*—chariot noise.

"'At the rumbling of his wheels.'"

*Hamon galgilav*—wheel rumble.

"'The fathers look not back to their children.'"

*Lo-hifnu avot el-banim*—fathers don't look back.

"'For feebleness of hands.'"

*Me-rifyon yadayim*—weak hands.

**The Key Verse (47:4):**
"'Because of the day that comes to spoil all the Philistines.'"

*Al-ha-yom ha-ba lishdod et-kol-Pelishtim*—day to spoil.

"'To cut off from Tyre and Zidon every helper that remains.'"

*Le-hakhrit le-Tzor u-le-Tzidon kol sarid ozer*—cut off helpers.

"'For YHWH will spoil the Philistines.'"

*Ki-shoded YHWH et-Pelishtim*—YHWH spoils.

"'The remnant of the isle of Caphtor.'"

*She'erit i Kaftor*—Caphtor remnant.

**Caphtor:**
Crete—the Philistines' origin (Amos 9:7; Deuteronomy 2:23).

**Mourning and Sword (47:5-7):**
**The Key Verse (47:5):**
"'Baldness is come upon Gaza.'"

*Ba'ah qorchah el-Azzah*—baldness (mourning).

"'Ashkelon is brought to nought.'"

*Nidmetah Ashqelon*—silenced.

"'The remnant of their valley.'"

*She'erit imqam*—valley remnant.

"'How long will you cut yourself?'"

*Ad-matai titgodadi*—self-laceration (mourning).

**The Key Verses (47:6-7):**
"'O you sword of YHWH, how long will it be ere you be quiet?'"

*Hoy cherev la-YHWH ad-anah lo tishqoti*—sword, how long?

"'Put up yourself into your scabbard.'"

*He'asfi el-ta'arekh*—into scabbard.

"'Rest, and be still.'"

*Heragi ve-dommi*—rest, be still.

"'How can it be quiet, seeing YHWH has given it a charge?'"

*Eikh tishqoti va-YHWH tzivvah lah*—can't rest.

"'Against Ashkelon, and against the sea-shore.'"

*El-Ashqelon ve-el-chof ha-yam*—against coast.

"'There has he appointed it.'"

*Sham ye'adah*—appointed there.

**YHWH's Sword:**
The sword cannot rest—it has YHWH's commission.

**Archetypal Layer:** Jeremiah 47 contains **the oracle against Philistia**, **"Waters rise up out of the north" (47:2)**—Babylon as flood, **Philistines as "remnant of Caphtor" (47:4)**, and **"O you sword of YHWH, how long?" (47:6-7)**—the sword cannot rest.

**Ethical Inversion Applied:**
- "The word of YHWH... concerning the Philistines"—Philistine oracle
- "Before that Pharaoh smote Gaza"—before Egyptian strike
- "'Behold, waters rise up out of the north'"—northern flood
- "'Shall become an overflowing stream'"—overflowing
- "'Shall overflow the land and all that is therein'"—flood land
- "'The city and them that dwell therein'"—city flooded
- "'The men shall cry, and all the inhabitants... shall wail'"—crying
- "'At the noise of the stamping of the hoofs'"—hoofbeats
- "'At the rushing of his chariots'"—chariots
- "'At the rumbling of his wheels'"—wheels
- "'The fathers look not back to their children'"—fathers flee
- "'For feebleness of hands'"—weak
- "'The day that comes to spoil all the Philistines'"—day of spoiling
- "'To cut off from Tyre and Zidon every helper'"—cut helpers
- "'YHWH will spoil the Philistines'"—YHWH spoils
- "'The remnant of the isle of Caphtor'"—Cretan origin
- "'Baldness is come upon Gaza'"—mourning
- "'Ashkelon is brought to nought'"—silenced
- "'How long will you cut yourself?'"—self-laceration
- "'O you sword of YHWH, how long will it be ere you be quiet?'"—sword addressed
- "'Put up yourself into your scabbard'"—plea
- "'Rest, and be still'"—plea
- "'How can it be quiet, seeing YHWH has given it a charge?'"—can't rest
- "'Against Ashkelon, and against the sea-shore'"—commission
- "'There has he appointed it'"—appointed

**Modern Equivalent:** Jeremiah 47's oracle against Philistia uses flood imagery for Babylon's invasion. The "sword of YHWH" personified (47:6-7) cannot rest because it has a divine commission. The Philistines' Cretan origin (Caphtor) is noted.

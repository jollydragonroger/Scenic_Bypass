# Jeremiah 46: Oracle Against Egypt

*From the Hebrew: אֲשֶׁר הָיָה דְבַר־יְהוָה אֶל־יִרְמְיָהוּ הַנָּבִיא עַל־הַגּוֹיִם (Asher Hayah Devar-YHWH El-Yirmeyahu Ha-Navi Al-Ha-Goyim) — The Word of YHWH That Came to Jeremiah the Prophet Concerning the Nations*

---

## Introduction to Oracles Against Nations (46:1)

**46:1** The word of YHWH which came to Jeremiah the prophet concerning the nations.

---

## Oracle Against Egypt at Carchemish (46:2-12)

**46:2** Of Egypt: concerning the army of Pharaoh-neco king of Egypt, which was by the river Euphrates in Carchemish, which Nebuchadrezzar king of Babylon smote in the fourth year of Jehoiakim the son of Josiah, king of Judah.

**46:3** "Prepare the buckler and shield, and draw near to battle.

**46:4** "Harness the horses, and mount, you horsemen, and stand forth with your helmets; furbish the spears, put on the coats of mail.

**46:5** "Wherefore do I see them dismayed and turned backward? And their mighty ones are beaten down, and fled apace, and look not back; terror is on every side," says YHWH.

**46:6** "Let not the swift flee away, nor the mighty man escape; in the north by the river Euphrates have they stumbled and fallen.

**46:7** "Who is this that rises up like the Nile, whose waters toss themselves like the rivers?

**46:8** "Egypt rises up like the Nile, and his waters toss themselves like the rivers; and he says: 'I will rise up, I will cover the earth; I will destroy the city and the inhabitants thereof.'

**46:9** "Come up, you horses; and rush madly, you chariots; and let the mighty men come forth: Cush and Put, that handle the shield, and the Ludim, that handle and bend the bow.

**46:10** "For that day is a day of the Lord YHWH of hosts, a day of vengeance, that he may avenge him of his adversaries; and the sword shall devour and be satiate, and shall be made drunk with their blood; for the Lord YHWH of hosts has a sacrifice in the north country by the river Euphrates.

**46:11** "Go up into Gilead, and take balm, O virgin daughter of Egypt; in vain do you use many medicines; there is no healing for you.

**46:12** "The nations have heard of your shame, and the earth is full of your cry; for the mighty man has stumbled against the mighty, they are fallen both of them together."

---

## Oracle Against Egypt's Land (46:13-26)

**46:13** The word that YHWH spoke to Jeremiah the prophet, how that Nebuchadrezzar king of Babylon should come and smite the land of Egypt.

**46:14** "Declare in Egypt, and announce in Migdol, and announce in Noph and in Tahpanhes; say: 'Stand forth, and prepare; for the sword has devoured round about you.'

**46:15** "Why is your strong one swept away? He stood not, because YHWH did thrust him down.

**46:16** "He made many to stumble; yea, they fell one upon another, and they said: 'Arise, and let us return to our own people, and to the land of our nativity, from the oppressing sword.'

**46:17** "They cried there: 'Pharaoh king of Egypt is but a noise; he has let the appointed time pass by.'

**46:18** "As I live," says the King, whose name is YHWH of hosts, "surely like Tabor among the mountains, and like Carmel by the sea, so shall he come.

**46:19** "O you daughter that dwells in Egypt, furnish yourself to go into captivity; for Noph shall become a desolation, and shall be burnt up, without inhabitant.

**46:20** "Egypt is a very fair heifer; but the gadfly out of the north is come, it is come.

**46:21** "Also her hired men in the midst of her are like calves of the stall; for they also are turned back, they are fled away together, they did not stand; for the day of their calamity is come upon them, the time of their visitation.

**46:22** "The sound thereof shall go like the serpent; for they shall march with an army, and come against her with axes, as hewers of wood.

**46:23** "They shall cut down her forest," says YHWH, "though it cannot be searched; because they are more than the locusts, and are innumerable.

**46:24** "The daughter of Egypt shall be put to shame; she shall be delivered into the hand of the people of the north."

**46:25** YHWH of hosts, the God of Israel, says: "Behold, I will punish Amon of No, and Pharaoh, and Egypt, with her gods, and her kings; even Pharaoh, and them that trust in him;

**46:26** "And I will deliver them into the hand of those that seek their lives, and into the hand of Nebuchadrezzar king of Babylon, and into the hand of his servants; and afterwards it shall be inhabited, as in the days of old," says YHWH.

---

## Comfort for Jacob (46:27-28)

**46:27** "But fear not, O Jacob my servant, neither be dismayed, O Israel; for, lo, I will save you from afar, and your seed from the land of their captivity; and Jacob shall return, and shall be quiet and at ease, and none shall make him afraid.

**46:28** "Fear not, O Jacob my servant," says YHWH, "for I am with you; for I will make a full end of all the nations whither I have driven you; but I will not make a full end of you, but I will correct you in measure, and will in no wise leave you unpunished."

---

## Synthesis Notes

**Key Restorations:**

**Introduction (46:1):**
"The word of YHWH which came to Jeremiah the prophet concerning the nations."

*Asher hayah devar-YHWH el-Yirmeyahu ha-navi al-ha-goyim*—concerning nations.

**Oracles Against Nations:**
Chapters 46-51 contain oracles against foreign nations, beginning with Egypt.

**Carchemish Oracle (46:2-12):**
"Of Egypt: concerning the army of Pharaoh-neco king of Egypt."

*Le-Mitzrayim al-cheil Par'oh Nekho melekh Mitzrayim*—Pharaoh Neco's army.

"Which was by the river Euphrates in Carchemish."

*Asher-hayah al-nahar-Perat be-Kharkhemish*—at Carchemish.

"Which Nebuchadrezzar king of Babylon smote in the fourth year of Jehoiakim."

*Asher hikkah Nevukhadre'zzar melekh Bavel bi-shnat ha-revi'it li-Yehoyaqim*—605 BCE.

**Battle of Carchemish:**
The decisive battle (605 BCE) where Babylon defeated Egypt and became the dominant Near Eastern power.

**The Key Verses (46:3-4):**
"'Prepare the buckler and shield, and draw near to battle.'"

*Irkhu magen ve-tzinnah u-geshu la-milchamah*—battle preparation.

"'Harness the horses, and mount, you horsemen.'"

*Isru ha-susim va'alu ha-parashim*—cavalry.

"'Stand forth with your helmets.'"

*Ve-hityatzzevu ba-kova'im*—helmets.

"'Furbish the spears, put on the coats of mail.'"

*Mirqu ha-romachim liveshu ha-siryanot*—spears, armor.

**The Key Verses (46:5-6):**
"'Wherefore do I see them dismayed and turned backward?'"

*Maddua ra'iti hemmah chattim nesogim achor*—dismayed, retreating.

"'Their mighty ones are beaten down, and fled apace.'"

*Ve-gibboreihem yukkatu manos nasu*—beaten, fleeing.

"'Look not back.'"

*Ve-lo-hifnu*—didn't look back.

"'Terror is on every side,' says YHWH."

*Magor missaviv*—terror everywhere.

"'In the north by the river Euphrates have they stumbled and fallen.'"

*Tzafonah el-nahar-Perat kashlu ve-nafalu*—fell at Euphrates.

**The Key Verses (46:7-8):**
"'Who is this that rises up like the Nile?'"

*Mi-zeh ka-Ye'or ya'aleh*—like Nile.

"'Whose waters toss themselves like the rivers?'"

*Ka-neharot yitga'ashu memav*—churning waters.

"'Egypt rises up like the Nile.'"

*Mitzrayim ka-Ye'or ya'aleh*—Egypt rises.

"'I will rise up, I will cover the earth.'"

*E'eleh akhasseh eretz*—cover earth.

"'I will destroy the city and the inhabitants thereof.'"

*Ovidah ir ve-yoshevei vah*—destroy cities.

**The Key Verse (46:9):**
"'Come up, you horses; and rush madly, you chariots.'"

*Alu ha-susim ve-hithollelu ha-rekhev*—horses, chariots.

"'Let the mighty men come forth.'"

*Ve-yetz'u ha-gibborim*—mighty men.

"'Cush and Put, that handle the shield.'"

*Kush u-Fut tofessei magen*—Cushites, Libyans.

"'The Ludim, that handle and bend the bow.'"

*Ve-Ludim tofessei dorekhei qashet*—Lydians.

**Mercenaries:**
Egypt's army included African and Lydian mercenaries.

**The Key Verse (46:10):**
"'That day is a day of the Lord YHWH of hosts.'"

*Ve-ha-yom ha-hu la-Adonai YHWH Tzeva'ot*—day of YHWH.

"'A day of vengeance.'"

*Yom neqamah*—vengeance day.

"'The sword shall devour and be satiate.'"

*Ve-akhelah cherev ve-save'ah*—sword devours.

"'Shall be made drunk with their blood.'"

*Ve-ravvetah mi-dammam*—drunk on blood.

"'The Lord YHWH of hosts has a sacrifice in the north country.'"

*Ki zevach la-Adonai YHWH Tzeva'ot be-eretz tzafon*—sacrifice.

**The Key Verses (46:11-12):**
"'Go up into Gilead, and take balm.'"

*Ali Gil'ad u-qechi tzori*—Gilead's balm.

"'O virgin daughter of Egypt.'"

*Betulat bat-Mitzrayim*—virgin Egypt.

"'In vain do you use many medicines.'"

*La-shav hirbeit refu'ot*—vain medicines.

"'There is no healing for you.'"

*Te'alah ein lakh*—no healing.

"'The nations have heard of your shame.'"

*Sham'u goyim qelonekh*—nations heard shame.

"'The mighty man has stumbled against the mighty.'"

*Ki-gibbor be-gibbor kashal*—mighty stumbled.

"'They are fallen both of them together.'"

*Yachdav naflu sheneihem*—both fell.

**Egypt's Land (46:13-26):**
"Nebuchadrezzar king of Babylon should come and smite the land of Egypt."

*Lavo Nevukhadre'zzar melekh Bavel le-hakkot et-eretz Mitzrayim*—smite Egypt.

"'Declare in Egypt, and announce in Migdol... Noph... Tahpanhes.'"

*Haggidu ve-Mitzrayim ve-hashmi'u ve-Migdol ve-hashmi'u ve-Nof u-ve-Tachpancheis*—announce.

"'The sword has devoured round about you.'"

*Ki akhelah cherev sevivotayikh*—sword devoured.

**The Key Verse (46:15):**
"'Why is your strong one swept away?'"

*Maddua nischaf abbirekha*—swept away.

"'He stood not, because YHWH did thrust him down.'"

*Lo amad ki YHWH hadafo*—YHWH thrust down.

**Apis Bull:**
"Strong one" (*abbir*) may refer to the Apis bull god of Egypt.

**The Key Verse (46:17):**
"'Pharaoh king of Egypt is but a noise.'"

*Qare'u sham Par'oh melekh-Mitzrayim sha'on*—just noise.

"'He has let the appointed time pass by.'"

*He'evir ha-mo'ed*—missed opportunity.

**The Key Verse (46:18):**
"''As I live,' says the King, whose name is YHWH of hosts.'"

*Chai-ani ne'um ha-Melekh YHWH Tzeva'ot shemo*—YHWH swears.

"'Surely like Tabor among the mountains.'"

*Ki khe-Tavor be-harim*—like Tabor.

"'And like Carmel by the sea, so shall he come.'"

*Ve-khe-Karmel ba-yam yavo*—Nebuchadnezzar comes.

**The Key Verses (46:19-21):**
"'Furnish yourself to go into captivity.'"

*Kelei golah asi lakh*—prepare for exile.

"'Noph shall become a desolation.'"

*Ki-Nof le-shammah tihyeh*—Memphis desolate.

"'Egypt is a very fair heifer.'"

*Egelah yefeh-fiyyah Mitzrayim*—fair heifer.

"'But the gadfly out of the north is come.'"

*Qeretz mi-tzafon ba va*—gadfly from north.

"'Her hired men in the midst of her are like calves of the stall.'"

*Gam-sekhireiha ve-qirbah ke-egelei marbeq*—mercenaries like calves.

"'They are turned back, they are fled away together.'"

*Gam-hemmah hifnu nasu yachdav*—fled.

**The Key Verses (46:22-24):**
"'The sound thereof shall go like the serpent.'"

*Qolah ka-nachash yelekh*—serpent sound.

"'They shall march with an army, and come against her with axes.'"

*Ki-ve-chayil yelekhu u-ve-qardomot ba'u lah*—axes.

"'As hewers of wood.'"

*Ke-chotesvei etzim*—woodcutters.

"'They shall cut down her forest.'"

*Kartu ya'arah*—cut forest.

"'Because they are more than the locusts.'"

*Ki lo yechaqer ki rabbu me-arbeh*—more than locusts.

"'The daughter of Egypt shall be put to shame.'"

*Hovishah bat-Mitzrayim*—shamed.

"'She shall be delivered into the hand of the people of the north.'"

*Nittenah be-yad am-tzafon*—to north.

**The Key Verses (46:25-26):**
"'I will punish Amon of No.'"

*Hineni poqed el-Amon mi-No*—punish Amon of Thebes.

"'And Pharaoh, and Egypt, with her gods.'"

*Ve-al-Par'oh ve-al-Mitzrayim ve-al-elohekha*—Pharaoh, gods.

"'I will deliver them into the hand of Nebuchadrezzar king of Babylon.'"

*U-netattim be-yad Nevukhadre'zzar melekh-Bavel*—to Nebuchadnezzar.

"'Afterwards it shall be inhabited, as in the days of old.'"

*Ve-acharei-khen tishkon ki-yemei-qedem*—inhabited again.

**Comfort for Jacob (46:27-28):**
**The Key Verses (46:27-28):**
"'Fear not, O Jacob my servant.'"

*Ve-attah al-tira avdi Ya'aqov*—don't fear.

"'Neither be dismayed, O Israel.'"

*Ve-al-techat Yisra'el*—don't be dismayed.

"'I will save you from afar.'"

*Ki hineni moshi'akha me-rachoq*—save from afar.

"'Your seed from the land of their captivity.'"

*Ve-et-zar'akha me-eretz shivyam*—seed from captivity.

"'Jacob shall return, and shall be quiet and at ease.'"

*Ve-shav Ya'aqov ve-shaqat ve-sha'anan*—quiet, ease.

"'None shall make him afraid.'"

*Ve-ein macharid*—none terrifies.

"'I am with you.'"

*Ki-ittekha ani*—with you.

"'I will make a full end of all the nations.'"

*Ki e'eseh khalah be-khol-ha-goyim*—end nations.

"'But I will not make a full end of you.'"

*Ve-otakh lo-e'eseh khalah*—not end you.

"'I will correct you in measure.'"

*Ve-yissartikha la-mishpat*—correct in measure.

"'Will in no wise leave you unpunished.'"

*Ve-naqqeh lo anaqekka*—not unpunished.

**(Repeats 30:10-11)**

**Archetypal Layer:** Jeremiah 46 begins the **Oracles Against Nations (46-51)** with Egypt, containing **the Battle of Carchemish (46:2-12)**—605 BCE, **"That day is a day of the Lord YHWH of hosts, a day of vengeance" (46:10)**, and **comfort for Jacob amid nations' judgment (46:27-28)**.

**Ethical Inversion Applied:**
- "The word of YHWH... concerning the nations"—nations oracles begin
- "Concerning the army of Pharaoh-neco"—Neco's army
- "By the river Euphrates in Carchemish"—Carchemish
- "Which Nebuchadrezzar king of Babylon smote in the fourth year of Jehoiakim"—605 BCE
- "'Prepare the buckler and shield, and draw near to battle'"—battle prep
- "'Harness the horses, and mount, you horsemen'"—cavalry
- "'Wherefore do I see them dismayed and turned backward?'"—retreating
- "'Terror is on every side'"—*magor missaviv*
- "'In the north by the river Euphrates have they stumbled and fallen'"—fallen
- "'Who is this that rises up like the Nile?'"—Nile image
- "'Egypt rises up like the Nile'"—Egypt rises
- "'I will rise up, I will cover the earth'"—Egypt's boast
- "'Cush and Put... the Ludim'"—mercenaries
- "'That day is a day of the Lord YHWH of hosts, a day of vengeance'"—day of YHWH
- "'The sword shall devour and be satiate'"—sword devours
- "'Go up into Gilead, and take balm'"—no healing
- "'There is no healing for you'"—incurable
- "'The nations have heard of your shame'"—shamed
- "'Why is your strong one swept away? He stood not, because YHWH did thrust him down'"—YHWH thrust
- "'Pharaoh king of Egypt is but a noise'"—just noise
- "'He has let the appointed time pass by'"—missed opportunity
- "'As I live,' says the King, whose name is YHWH of hosts'"—YHWH swears
- "'Like Tabor among the mountains'"—Nebuchadnezzar comes
- "'Furnish yourself to go into captivity'"—exile
- "'Egypt is a very fair heifer; but the gadfly out of the north is come'"—gadfly
- "'Her hired men... are like calves of the stall'"—mercenaries
- "'The sound thereof shall go like the serpent'"—serpent sound
- "'They shall cut down her forest'"—cut forest
- "'They are more than the locusts'"—innumerable
- "'I will punish Amon of No, and Pharaoh, and Egypt, with her gods'"—punish
- "'I will deliver them into the hand of Nebuchadrezzar'"—to Babylon
- "'Afterwards it shall be inhabited, as in the days of old'"—restoration
- "'Fear not, O Jacob my servant'"—don't fear
- "'I will save you from afar'"—save
- "'I will make a full end of all the nations... but I will not make a full end of you'"—preserved

**Modern Equivalent:** Jeremiah 46 begins the Oracles Against Nations. The Battle of Carchemish (605 BCE) was a turning point—Egypt's defeat made Babylon dominant. The contrast between Egypt's judgment and Jacob's preservation (46:27-28) shows YHWH's sovereignty over all nations.

# Jeremiah 35: The Rechabites' Faithfulness

*From the Hebrew: הַדָּבָר אֲשֶׁר הָיָה אֶל־יִרְמְיָהוּ (Ha-Davar Asher Hayah El-Yirmeyahu) — The Word That Came to Jeremiah*

---

## The Rechabites Tested (35:1-11)

**35:1** The word which came unto Jeremiah from YHWH in the days of Jehoiakim the son of Josiah, king of Judah, saying:

**35:2** "Go unto the house of the Rechabites, and speak unto them, and bring them into the house of YHWH, into one of the chambers, and give them wine to drink."

**35:3** Then I took Jaazaniah the son of Jeremiah, the son of Habazziniah, and his brethren, and all his sons, and the whole house of the Rechabites;

**35:4** And I brought them into the house of YHWH, into the chamber of the sons of Hanan the son of Igdaliah, the man of God, which was by the chamber of the princes, which was above the chamber of Maaseiah the son of Shallum, the keeper of the door;

**35:5** And I set before the sons of the house of the Rechabites bowls full of wine, and cups, and I said unto them: "Drink wine."

**35:6** But they said: "We will drink no wine; for Jonadab the son of Rechab our father commanded us, saying: 'You shall drink no wine, neither you, nor your sons, forever;

**35:7** "'Neither shall you build house, nor sow seed, nor plant vineyard, nor have any; but all your days you shall dwell in tents, that you may live many days in the land wherein you sojourn.'

**35:8** "And we have hearkened to the voice of Jonadab the son of Rechab our father in all that he charged us, to drink no wine all our days, we, our wives, our sons, nor our daughters;

**35:9** "Nor to build houses for us to dwell in; neither have we vineyard, nor field, nor seed;

**35:10** "But we have dwelt in tents, and have hearkened, and done according to all that Jonadab our father commanded us.

**35:11** "But it came to pass, when Nebuchadrezzar king of Babylon came up against the land, that we said: 'Come, and let us go to Jerusalem for fear of the army of the Chaldeans, and for fear of the army of the Arameans'; so we dwell at Jerusalem."

---

## Judah's Contrast (35:12-17)

**35:12** Then came the word of YHWH unto Jeremiah, saying:

**35:13** "Thus says YHWH of hosts, the God of Israel: Go, and say to the men of Judah and the inhabitants of Jerusalem: 'Will you not receive instruction to hearken to my words?' says YHWH.

**35:14** "'The words of Jonadab the son of Rechab, that he commanded his sons, not to drink wine, are performed, and unto this day they drink none, for they hearken to their father's commandment; but I have spoken unto you, speaking betimes and often, and you have not hearkened unto me.

**35:15** "'I have sent also unto you all my servants the prophets, sending them betimes and often, saying: Return now every man from his evil way, and amend your doings, and go not after other gods to serve them, and you shall dwell in the land which I have given to you and to your fathers; but you have not inclined your ear, nor hearkened unto me.

**35:16** "'Forasmuch as the sons of Jonadab the son of Rechab have performed the commandment of their father which he commanded them, but this people has not hearkened unto me';

**35:17** "Therefore thus says YHWH, the God of hosts, the God of Israel: Behold, I will bring upon Judah and upon all the inhabitants of Jerusalem all the evil that I have pronounced against them; because I have spoken unto them, but they have not heard; and I have called unto them, but they have not answered."

---

## Blessing on the Rechabites (35:18-19)

**35:18** And unto the house of the Rechabites Jeremiah said: "Thus says YHWH of hosts, the God of Israel: Because you have hearkened to the commandment of Jonadab your father, and kept all his precepts, and done according unto all that he commanded you;

**35:19** "Therefore thus says YHWH of hosts, the God of Israel: Jonadab the son of Rechab shall not want a man to stand before me forever."

---

## Synthesis Notes

**Key Restorations:**

**Setting (35:1):**
"In the days of Jehoiakim the son of Josiah."

*Bi-yemei Yehoyaqim ben-Yoshiyyahu melekh Yehudah*—Jehoiakim's reign (609-598 BCE).

**Command to Test Rechabites (35:2-5):**
"Go unto the house of the Rechabites."

*Halokh el-beit ha-Rekhabim*—go to Rechabites.

"Bring them into the house of YHWH."

*Va-havi'otam beit YHWH*—bring to temple.

"Into one of the chambers."

*El-achat ha-leshakhot*—to a chamber.

"Give them wine to drink."

*Ve-hishqita otam yayin*—give wine.

"Jaazaniah the son of Jeremiah, the son of Habazziniah."

*Ya'azanyahu ben-Yirmeyahu ben-Chavatztzinyah*—Rechabite leader.

"The chamber of the sons of Hanan the son of Igdaliah."

*Lishkat benei Chanan ben-Yigdalyahu*—Hanan's chamber.

"The man of God."

*Ish ha-Elohim*—man of God (prophet).

"By the chamber of the princes."

*Asher etzel lishkat ha-sarim*—near princes' chamber.

"Above the chamber of Maaseiah the son of Shallum."

*Asher mi-ma'al li-lishkat Ma'aseyahu ben-Shallum*—above Maaseiah's.

"The keeper of the door."

*Shomer ha-saf*—doorkeeper.

"I set before the sons of the house of the Rechabites bowls full of wine."

*Va-etten lifnei benei veit-ha-Rekhabim gevi'im mele'im yayin*—wine offered.

"And cups."

*Ve-khosot*—cups.

"'Drink wine.'"

*Shetu-yayin*—drink wine.

**Rechabites' Response (35:6-11):**
**The Key Verses (35:6-7):**
"'We will drink no wine.'"

*Lo nishteh yayin*—no wine.

"'Jonadab the son of Rechab our father commanded us.'"

*Ki Yonadav ben-Rekhav avinu tzivvanu*—Jonadab commanded.

"'You shall drink no wine, neither you, nor your sons, forever.'"

*Lo tishtu-yayin attem u-veneikhem ad-olam*—no wine forever.

"'Neither shall you build house.'"

*Ve-vayit lo tivnu*—no houses.

"'Nor sow seed.'"

*Ve-zera lo tizra'u*—no sowing.

"'Nor plant vineyard, nor have any.'"

*Ve-kherem lo titta'u ve-lo yihyeh lakhem*—no vineyards.

"'All your days you shall dwell in tents.'"

*Ki be-ohalim teshvu kol-yemeikhem*—dwell in tents.

"'That you may live many days in the land wherein you sojourn.'"

*Lema'an tichyu yamim rabbim al-penei ha-adamah asher attem garim sham*—long life.

**Jonadab/Jehonadab:**
2 Kings 10:15-23 introduces Jonadab, who joined Jehu's anti-Baal purge. The Rechabites were Kenites (1 Chronicles 2:55) who maintained a nomadic lifestyle as protest against Canaanite culture.

**The Key Verses (35:8-10):**
"We have hearkened to the voice of Jonadab."

*Va-nishma be-qol Yonadav ben-Rekhav avinu*—obeyed Jonadab.

"In all that he charged us."

*Le-khol asher tzivvanu*—all he commanded.

"To drink no wine all our days."

*Le-vilti shetot-yayin kol-yamenu*—no wine ever.

"We, our wives, our sons, nor our daughters."

*Anachnu nashenu baneinu u-venotenu*—whole family.

"Nor to build houses for us to dwell in."

*Ve-le-vilti benot battim le-shivtenu*—no houses.

"Neither have we vineyard, nor field, nor seed."

*Ve-kherem ve-sadeh ve-zera lo hayah lanu*—no agriculture.

"We have dwelt in tents."

*Va-neshev be-ohalim*—dwelt in tents.

"Have hearkened, and done according to all that Jonadab our father commanded us."

*Va-nishma va-na'as ke-khol asher-tzivvanu Yonadav avinu*—obeyed all.

**The Key Verse (35:11):**
"When Nebuchadrezzar king of Babylon came up against the land."

*Va-yehi ba-alot Nevukhadre'zzar melekh-Bavel el-ha-aretz*—Nebuchadnezzar came.

"We said: 'Come, and let us go to Jerusalem for fear.'"

*Va-nomer lekhu ve-navo Yerushalayim mippenei cheil ha-Kasdim u-mippenei cheil Aram*—fled to Jerusalem.

"So we dwell at Jerusalem."

*Va-neshev bi-Yerushalayim*—in Jerusalem.

**Exception Noted:**
They came to Jerusalem only because of military threat—otherwise they kept to tents.

**Contrast with Judah (35:12-17):**
**The Key Verse (35:13):**
"'Will you not receive instruction to hearken to my words?'"

*Halo tiqqechu musar lishmoa el-devarai*—receive instruction?

**The Key Verse (35:14):**
"'The words of Jonadab the son of Rechab... are performed.'"

*Huqam et-divrei Yonadav ben-Rekhav asher-tzivvah et-banav*—Jonadab's words kept.

"'Unto this day they drink none.'"

*Ve-ad ha-yom ha-zeh lo shatuu*—still obeying.

"'They hearken to their father's commandment.'"

*Ki sham'u et mitzwat avihem*—hearkened.

"'But I have spoken unto you, speaking betimes and often.'"

*Ve-anokhi dibbarti aleikhem hashkem ve-dabber*—spoke repeatedly.

"'You have not hearkened unto me.'"

*Ve-lo shema'tem elai*—didn't hearken.

**The Key Verse (35:15):**
"'I have sent also unto you all my servants the prophets.'"

*Va-eshlach aleikhem et-kol-avadai ha-nevi'im*—sent prophets.

"'Sending them betimes and often.'"

*Hashkem ve-shalo'ach*—rising early, sending.

"'Return now every man from his evil way.'"

*Shuvu-na ish mi-darkko ha-ra'ah*—return from evil.

"'Amend your doings.'"

*Ve-heitivu ma'aleleikem*—amend doings.

"'Go not after other gods to serve them.'"

*Ve-al-telkhu acharei elohim acherim le-ovdam*—no other gods.

"'You shall dwell in the land which I have given to you.'"

*U-shevu al-ha-adamah asher-natatti lakhem*—dwell in land.

"'You have not inclined your ear, nor hearkened unto me.'"

*Ve-lo hittitem et-oznekhem ve-lo shema'tem elai*—didn't incline.

**The Key Verse (35:16):**
"'The sons of Jonadab... have performed the commandment of their father.'"

*Ki heqimu benei Yonadav ben-Rekhav et-mitzwat avihem*—performed.

"'But this people has not hearkened unto me.'"

*Ve-ha-am ha-zeh lo sham'u elai*—didn't hearken.

**Contrast:**
Rechabites obeyed a human ancestor's commands for 250+ years; Judah won't obey YHWH.

**The Key Verse (35:17):**
"'Behold, I will bring upon Judah... all the evil that I have pronounced.'"

*Hineni mevi el-Yehudah ve-el kol-yoshevei Yerushalayim et kol-ha-ra'ah*—evil coming.

"'Because I have spoken unto them, but they have not heard.'"

*Ya'an dibbarti aleihem ve-lo sham'u*—spoke, not heard.

"'I have called unto them, but they have not answered.'"

*Va-eqra lahem ve-lo anu*—called, not answered.

**Blessing on Rechabites (35:18-19):**
"'Because you have hearkened to the commandment of Jonadab your father.'"

*Ya'an asher shema'tem el-mitzwat Yonadav avikhem*—hearkened.

"'Kept all his precepts.'"

*Va-tishmeru et-kol-mitzwotav*—kept precepts.

"'Done according unto all that he commanded you.'"

*Va-ta'asu ke-khol asher tzivvah etkhem*—done all.

**The Key Verse (35:19):**
"'Jonadab the son of Rechab shall not want a man to stand before me forever.'"

*Lo-yikkareit ish le-Yonadav ben-Rekhav omed lefanai kol-ha-yamim*—perpetual standing.

**Perpetual Promise:**
"Stand before me" often means priestly or prophetic service—the Rechabites receive lasting honor.

**Archetypal Layer:** Jeremiah 35 contains **the Rechabites as model of obedience (35:6-10)**, **the contrast with disobedient Judah (35:14-16)**, and **"Jonadab the son of Rechab shall not want a man to stand before me forever" (35:19)**.

**Ethical Inversion Applied:**
- "In the days of Jehoiakim"—Jehoiakim's reign
- "Go unto the house of the Rechabites"—test Rechabites
- "Bring them into the house of YHWH"—temple
- "Give them wine to drink"—offer wine
- "I set before... bowls full of wine"—wine offered
- "'Drink wine'"—command
- "'We will drink no wine'"—refusal
- "'Jonadab the son of Rechab our father commanded us'"—ancestor's command
- "'You shall drink no wine... forever'"—no wine
- "'Neither shall you build house'"—no houses
- "'Nor sow seed, nor plant vineyard'"—no agriculture
- "'All your days you shall dwell in tents'"—tent life
- "'That you may live many days in the land'"—promise
- "We have hearkened to the voice of Jonadab... in all that he charged us"—full obedience
- "We have dwelt in tents"—kept command
- "When Nebuchadrezzar... came up against the land"—only exception
- "'We said: Come, and let us go to Jerusalem'"—fled for safety
- "'Will you not receive instruction to hearken to my words?'"—YHWH's question
- "'The words of Jonadab... are performed'"—human command kept
- "'Unto this day they drink none'"—still obeying
- "'But I have spoken unto you... you have not hearkened'"—YHWH ignored
- "'I have sent also unto you all my servants the prophets'"—prophets sent
- "'Return now every man from his evil way'"—call to return
- "'You have not inclined your ear'"—didn't incline
- "'The sons of Jonadab... have performed the commandment'"—contrast
- "'But this people has not hearkened unto me'"—contrast
- "'I will bring upon Judah... all the evil'"—judgment
- "'Because I have spoken... but they have not heard'"—cause
- "'Because you have hearkened to the commandment of Jonadab'"—reason for blessing
- "'Jonadab the son of Rechab shall not want a man to stand before me forever'"—perpetual honor

**Modern Equivalent:** Jeremiah 35 uses the Rechabites as a shame-inducing contrast. A human ancestor's commands have been obeyed for 250+ years, while YHWH's commands are ignored. The point isn't that Rechabite rules are binding, but that their faithfulness exposes Judah's unfaithfulness.

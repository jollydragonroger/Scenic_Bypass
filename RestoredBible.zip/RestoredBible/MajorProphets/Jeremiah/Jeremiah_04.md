# Jeremiah 4: The Coming Destruction

*From the Hebrew: אִם־תָּשׁוּב יִשְׂרָאֵל (Im-Tashuv Yisra'el) — If You Will Return, O Israel*

---

## Call to Repentance (4:1-4)

**4:1** "If you will return, O Israel," says YHWH, "return unto me; and if you will put away your detestable things out of my sight, and will not waver;

**4:2** "And will swear: 'As YHWH lives,' in truth, in justice, and in righteousness; then shall the nations bless themselves by him, and in him shall they glory."

**4:3** For thus says YHWH to the men of Judah and to Jerusalem: "Break up for you a fallow ground, and sow not among thorns.

**4:4** "Circumcise yourselves to YHWH, and take away the foreskins of your heart, you men of Judah and inhabitants of Jerusalem; lest my fury go forth like fire, and burn that none can quench it, because of the evil of your doings."

---

## The Enemy from the North (4:5-18)

**4:5** Declare in Judah, and publish in Jerusalem, and say: "Blow the horn in the land"; cry aloud and say: "Assemble yourselves, and let us go into the fortified cities."

**4:6** Set up a standard toward Zion; put yourselves under covert, stay not; for I will bring evil from the north, and a great destruction.

**4:7** A lion is gone up from his thicket, and a destroyer of nations is set out, gone forth from his place; to make your land desolate, that your cities be laid waste, without inhabitant.

**4:8** For this gird you with sackcloth, lament and wail; for the fierce anger of YHWH is not turned back from us.

**4:9** And it shall come to pass at that day, says YHWH, that the heart of the king shall fail, and the heart of the princes; and the priests shall be astonished, and the prophets shall wonder.

**4:10** Then said I: "Ah, Lord YHWH! Surely you have greatly deceived this people and Jerusalem, saying: You shall have peace; whereas the sword reaches unto the soul."

**4:11** At that time shall it be said to this people and to Jerusalem: "A hot wind of the high hills in the wilderness toward the daughter of my people, not to fan, nor to cleanse;

**4:12** "A wind too strong for this shall come for me; now will I also utter judgments against them."

**4:13** Behold, he goes up as clouds, and his chariots are as the whirlwind; his horses are swifter than eagles. "Woe unto us! For we are undone."

**4:14** O Jerusalem, wash your heart from wickedness, that you may be saved. How long shall your evil thoughts lodge within you?

**4:15** For a voice declares from Dan, and publishes evil from the hills of Ephraim:

**4:16** "Make mention to the nations: behold, proclaim against Jerusalem: watchers come from a far country, and give out their voice against the cities of Judah."

**4:17** As keepers of a field are they against her round about; because she has been rebellious against me, says YHWH.

**4:18** Your way and your doings have procured these things unto you; this is your wickedness; yea, it is bitter, yea, it reaches unto your heart.

---

## Jeremiah's Anguish (4:19-22)

**4:19** My bowels, my bowels! I writhe in pain! The walls of my heart! My heart moans unto me, I cannot hold my peace; because you have heard, O my soul, the sound of the horn, the alarm of war.

**4:20** Destruction upon destruction is cried; for the whole land is spoiled; suddenly are my tents spoiled, my curtains in a moment.

**4:21** How long shall I see the standard, shall I hear the sound of the horn?

**4:22** "For my people is foolish, they know me not; they are sottish children, and they have no understanding; they are wise to do evil, but to do good they have no knowledge."

---

## Vision of Cosmic Destruction (4:23-28)

**4:23** I beheld the earth, and, lo, it was waste and void; and the heavens, and they had no light.

**4:24** I beheld the mountains, and, lo, they trembled, and all the hills moved lightly.

**4:25** I beheld, and, lo, there was no man, and all the birds of the heavens were fled.

**4:26** I beheld, and, lo, the fruitful field was a wilderness, and all its cities were broken down at the presence of YHWH, and before his fierce anger.

**4:27** For thus says YHWH: "The whole land shall be desolate; yet will I not make a full end.

**4:28** "For this shall the earth mourn, and the heavens above be black; because I have spoken it, I have purposed it, and I have not repented, neither will I turn back from it."

---

## The Abandoned City (4:29-31)

**4:29** For the noise of the horsemen and bowmen the whole city flees; they go into the thickets, and climb up upon the rocks; every city is forsaken, and not a man dwells therein.

**4:30** And you, that are spoiled, what do you? Though you clothe yourself with scarlet, though you deck yourself with ornaments of gold, though you enlarge your eyes with paint, in vain do you make yourself fair; your lovers despise you, they seek your life.

**4:31** For I have heard a voice as of a woman in travail, the anguish as of her that brings forth her first child, the voice of the daughter of Zion, that gasps for breath, that spreads her hands: "Woe is me now! For my soul faints before the murderers."

---

## Synthesis Notes

**Key Restorations:**

**Conditional Return (4:1-2):**
"If you will return, O Israel... return unto me."

*Im-tashuv Yisra'el... elai tashuv*—conditional return.

"Put away your detestable things out of my sight."

*Ve-im-tasir shiqqutzekkha mippanai*—remove detestables.

"Will not waver."

*Ve-lo tanud*—no wavering.

"'As YHWH lives,' in truth, in justice, and in righteousness."

*Chai-YHWH be-emet be-mishpat u-vi-tzedaqah*—true oath.

"Then shall the nations bless themselves by him."

*Ve-hitbareku vo goyim*—nations blessed.

"In him shall they glory."

*U-vo yithalalu*—glory in him.

**The Key Verses (4:3-4):**
"Break up for you a fallow ground."

*Niru lakhem nir*—plow fallow ground.

"Sow not among thorns."

*Ve-al-tizre'u el-qotzim*—don't sow in thorns.

**The Key Verse (4:4):**
"Circumcise yourselves to YHWH."

*Himmolu la-YHWH*—circumcise to YHWH.

"Take away the foreskins of your heart."

*Ve-hasiru orlot levavchem*—heart circumcision.

"You men of Judah and inhabitants of Jerusalem."

*Ish Yehudah ve-yoshevei Yerushalayim*—Judah and Jerusalem.

"Lest my fury go forth like fire."

*Pen-tetze kha-esh chamati*—fire fury.

"Burn that none can quench it."

*Ve-va'arah ve-ein mekhabeh*—unquenchable.

**Invasion Announced (4:5-9):**
"Blow the horn in the land."

*Tiq'u shofar ba-aretz*—blow shofar.

"Assemble yourselves, and let us go into the fortified cities."

*He'asefu ve-navo'ah el-arei ha-mivtzar*—flee to fortified cities.

"Set up a standard toward Zion."

*Se'u-nes Tziyonah*—raise banner.

"I will bring evil from the north."

*Ki ra'ah anokhi mevi mi-tzafon*—evil from north.

"A great destruction."

*Ve-shever gadol*—great destruction.

**The Key Verse (4:7):**
"A lion is gone up from his thicket."

*Alah aryeh mi-subbeko*—lion from thicket (Babylon).

"A destroyer of nations is set out."

*Mashchit goyim nasa*—nation destroyer.

"Gone forth from his place."

*Yatza mi-meqomo*—gone forth.

"To make your land desolate."

*Lasum artzekh le-shammah*—land desolate.

"Your cities be laid waste, without inhabitant."

*Arayikh titzeynah me-ein yoshev*—cities empty.

"The heart of the king shall fail, and the heart of the princes."

*Yovad lev-ha-melekh ve-lev ha-sarim*—hearts fail.

"The priests shall be astonished, and the prophets shall wonder."

*Ve-nashammu ha-kohanim ve-ha-nevi'im yitmahu*—priests/prophets shocked.

**Wind of Judgment (4:11-13):**
"A hot wind of the high hills."

*Ruach tzach shefayim*—scorching wind.

"Not to fan, nor to cleanse."

*Lo lizrot ve-lo le-haver*—not for winnowing.

"A wind too strong for this."

*Ruach male me-elleh*—full wind.

"Now will I also utter judgments against them."

*Gam-ani adabber mishpattim otam*—judgments uttered.

"He goes up as clouds."

*Kha-ananim ya'aleh*—cloud-like.

"His chariots are as the whirlwind."

*Ve-kha-sufah markevotav*—whirlwind chariots.

"His horses are swifter than eagles."

*Qallu mi-nesharim susav*—eagle-swift horses.

"'Woe unto us! For we are undone.'"

*Oy lanu ki shuddadnu*—woe, undone.

**The Key Verse (4:14):**
"O Jerusalem, wash your heart from wickedness."

*Kabbesi me-ra'ah libbek Yerushalayim*—wash heart.

"That you may be saved."

*Lema'an tivvashe'i*—to be saved.

"How long shall your evil thoughts lodge within you?"

*Ad-matai talin be-qirbek machshevot onek*—evil thoughts.

**Jeremiah's Anguish (4:19-22):**
"My bowels, my bowels!"

*Me'ai me'ai*—internal anguish.

"I writhe in pain!"

*Ochilah*—writhing.

"The walls of my heart!"

*Qirot libbi*—heart walls.

"My heart moans unto me."

*Homeh-li libbi*—heart moans.

"I cannot hold my peace."

*Lo acharish*—can't be silent.

"You have heard, O my soul, the sound of the horn."

*Ki qol shofar shama'at nafshi*—horn heard.

"The alarm of war."

*Teru'at milchamah*—war alarm.

"Destruction upon destruction is cried."

*Shever al-shever niqra*—destruction on destruction.

"The whole land is spoiled."

*Ki shuddedah kol-ha-aretz*—whole land spoiled.

"Suddenly are my tents spoiled."

*Pitom shudddu ohalai*—sudden tent destruction.

**The Key Verse (4:22):**
"My people is foolish, they know me not."

*Ki evil ammi oti lo yada'u*—foolish, don't know me.

"They are sottish children."

*Banim sekalim hemmah*—senseless children.

"They have no understanding."

*Ve-lo nevonim hemmah*—no understanding.

"They are wise to do evil."

*Chakhamim hemmah le-hara*—wise for evil.

"But to do good they have no knowledge."

*U-le-heitiv lo yada'u*—don't know good.

**Cosmic Undoing (4:23-28):**
**The Key Verses (4:23-26):**
"I beheld the earth, and, lo, it was waste and void."

*Ra'iti et-ha-aretz ve-hinneh-tohu va-vohu*—waste and void (Genesis 1:2 language).

"And the heavens, and they had no light."

*Ve-el-ha-shamayim ve-ein oram*—no light.

"I beheld the mountains, and, lo, they trembled."

*Ra'iti he-harim ve-hinneh ro'ashim*—mountains tremble.

"All the hills moved lightly."

*Ve-khol-ha-geva'ot hitqalqalu*—hills shake.

"I beheld, and, lo, there was no man."

*Ra'iti ve-hinneh ein ha-adam*—no man.

"All the birds of the heavens were fled."

*Ve-khol-of ha-shamayim nadedu*—birds fled.

"I beheld, and, lo, the fruitful field was a wilderness."

*Ra'iti ve-hinneh ha-karmel ha-midbar*—fruitful = wilderness.

"All its cities were broken down."

*Ve-khol-arav nittzu*—cities broken.

"At the presence of YHWH."

*Mippenei YHWH*—before YHWH.

"Before his fierce anger."

*Mippenei charon appo*—fierce anger.

**The Key Verse (4:27):**
"The whole land shall be desolate."

*Shemamah tihyeh kol-ha-aretz*—whole land desolate.

"Yet will I not make a full end."

*Ve-khalah lo e'eseh*—not full end.

**Abandoned Harlot (4:29-31):**
"Every city is forsaken."

*Azuvah kol-ha-ir*—cities forsaken.

"Not a man dwells therein."

*Ve-ein yoshev bahen ish*—no inhabitant.

"Though you clothe yourself with scarlet."

*Ki-tilbeshi shani*—scarlet clothes.

"Though you deck yourself with ornaments of gold."

*Ki-ta'di adi-zahav*—gold ornaments.

"Though you enlarge your eyes with paint."

*Ki-tiqre'i va-pukh einayikh*—eye paint.

"In vain do you make yourself fair."

*La-shav titgappi*—vain beauty.

"Your lovers despise you, they seek your life."

*Ma'asu-vakh ogavim nafshekh yevaqeshu*—lovers seek your life.

"A voice as of a woman in travail."

*Ki qol ke-cholah shama'ti*—travailing voice.

"The anguish as of her that brings forth her first child."

*Tzarah ke-mavkirah*—firstborn anguish.

"The voice of the daughter of Zion."

*Qol bat-Tziyyon*—Zion's voice.

"'Woe is me now! For my soul faints before the murderers.'"

*Oy-na li ki-ayefah nafshi le-horegim*—fainting before murderers.

**Archetypal Layer:** Jeremiah 4 contains **"Circumcise yourselves to YHWH, and take away the foreskins of your heart" (4:4)**, **cosmic undoing using Genesis 1:2 language (4:23-26)**, and **"yet will I not make a full end" (4:27)**.

**Ethical Inversion Applied:**
- "If you will return, O Israel... return unto me"—conditional return
- "Put away your detestable things"—remove idols
- "Break up for you a fallow ground"—prepare soil
- "Sow not among thorns"—clear thorns
- "Circumcise yourselves to YHWH"—heart circumcision
- "Take away the foreskins of your heart"—inner change
- "Lest my fury go forth like fire"—unquenchable fire
- "A lion is gone up from his thicket"—Babylon = lion
- "A destroyer of nations"—nation destroyer
- "To make your land desolate"—desolation
- "The heart of the king shall fail"—failed leaders
- "His horses are swifter than eagles"—swift invasion
- "'Woe unto us! For we are undone'"—undone
- "O Jerusalem, wash your heart from wickedness"—heart washing
- "My bowels, my bowels! I writhe in pain!"—prophetic anguish
- "My people is foolish, they know me not"—foolish people
- "They are wise to do evil"—evil wisdom
- "But to do good they have no knowledge"—good ignorance
- "I beheld the earth, and, lo, it was waste and void"—Genesis undoing
- "The heavens... had no light"—light removed
- "There was no man"—de-creation
- "All the birds of the heavens were fled"—birds fled
- "The fruitful field was a wilderness"—fruitful to wilderness
- "Yet will I not make a full end"—not total destruction
- "In vain do you make yourself fair"—vain beauty
- "'Woe is me now! For my soul faints before the murderers'"—final cry

**Modern Equivalent:** Jeremiah 4:4's "circumcise... your heart" anticipates the new covenant (31:31-34) and Paul's teaching (Romans 2:28-29). The cosmic undoing (4:23-26) uses Genesis 1:2 language to show judgment reversing creation. The "yet will I not make a full end" (4:27) preserves hope.

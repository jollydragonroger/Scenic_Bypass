# Jeremiah 42: The Remnant Seeks YHWH's Counsel

*From the Hebrew: וַיִּגְּשׁוּ כָּל־שָׂרֵי הַחֲיָלִים (Va-Yiggashu Kol-Sarei Ha-Chayalim) — And All the Captains of the Forces Came Near*

---

## The Request for Guidance (42:1-6)

**42:1** Then all the captains of the forces, and Johanan the son of Kareah, and Jezaniah the son of Hoshaiah, and all the people from the least even unto the greatest, came near,

**42:2** And said unto Jeremiah the prophet: "Let, we pray you, our supplication be accepted before you, and pray for us unto YHWH your God, even for all this remnant; for we are left but a few of many, as your eyes do behold us;

**42:3** "That YHWH your God may tell us the way wherein we should walk, and the thing that we should do."

**42:4** Then Jeremiah the prophet said unto them: "I have heard you; behold, I will pray unto YHWH your God according to your words; and it shall come to pass, that whatsoever thing YHWH shall answer you, I will declare it unto you; I will keep nothing back from you."

**42:5** Then they said to Jeremiah: "YHWH be a true and faithful witness against us, if we do not even according to all the word wherewith YHWH your God shall send you to us.

**42:6** "Whether it be good, or whether it be evil, we will hearken to the voice of YHWH our God, to whom we send you; that it may be well with us, when we hearken to the voice of YHWH our God."

---

## YHWH's Answer: Stay in the Land (42:7-18)

**42:7** And it came to pass after ten days, that the word of YHWH came unto Jeremiah.

**42:8** Then called he Johanan the son of Kareah, and all the captains of the forces that were with him, and all the people from the least even to the greatest,

**42:9** And said unto them: "Thus says YHWH, the God of Israel, unto whom you sent me to present your supplication before him:

**42:10** "'If you will still abide in this land, then will I build you, and not pull you down, and I will plant you, and not pluck you up; for I repent of the evil that I have done unto you.

**42:11** "'Be not afraid of the king of Babylon, of whom you are afraid; be not afraid of him,' says YHWH; 'for I am with you to save you, and to deliver you from his hand.

**42:12** "'And I will grant you compassion, that he may have compassion upon you, and cause you to return to your own land.'

**42:13** "But if you say: 'We will not abide in this land'; so as not to hearken to the voice of YHWH your God;

**42:14** "Saying: 'No; but we will go into the land of Egypt, where we shall see no war, nor hear the sound of the horn, nor have hunger of bread; and there will we abide';

**42:15** "Now therefore hear the word of YHWH, O remnant of Judah: Thus says YHWH of hosts, the God of Israel: If you wholly set your faces to enter into Egypt, and go to sojourn there;

**42:16** "Then it shall come to pass, that the sword, which you fear, shall overtake you there in the land of Egypt, and the famine, whereof you are afraid, shall follow close after you there in Egypt; and there you shall die.

**42:17** "So shall it be with all the men that set their faces to go into Egypt to sojourn there; they shall die by the sword, by the famine, and by the pestilence; and none of them shall remain or escape from the evil that I will bring upon them.

**42:18** "For thus says YHWH of hosts, the God of Israel: As my anger and my fury has been poured forth upon the inhabitants of Jerusalem, so shall my fury be poured forth upon you, when you shall enter into Egypt; and you shall be an execration, and an astonishment, and a curse, and a reproach; and you shall see this place no more."

---

## Warning Against Egypt (42:19-22)

**42:19** YHWH has spoken concerning you, O remnant of Judah: "Go not into Egypt"; know certainly that I have forewarned you this day.

**42:20** For you have dealt deceitfully against your own souls; for you sent me unto YHWH your God, saying: "Pray for us unto YHWH our God; and according unto all that YHWH our God shall say, so declare unto us, and we will do it";

**42:21** And I have this day declared it to you; but you have not hearkened to the voice of YHWH your God, nor to any thing for which he has sent me unto you.

**42:22** Now therefore know certainly that you shall die by the sword, by the famine, and by the pestilence, in the place whither you desire to go to sojourn there.

---

## Synthesis Notes

**Key Restorations:**

**Request for Guidance (42:1-3):**
"All the captains of the forces."

*Kol-sarei ha-chayalim*—all captains.

"Johanan the son of Kareah."

*Ve-Yochanan ben-Qareach*—Johanan.

"Jezaniah the son of Hoshaiah."

*Vi-Yzanyahu ben-Hosha'yah*—Jezaniah.

"All the people from the least even unto the greatest."

*Ve-khol-ha-am mi-qatan ve-ad-gadol*—all people.

"Came near."

*Va-yiggashu*—approached.

**The Key Verse (42:2):**
"'Let, we pray you, our supplication be accepted before you.'"

*Tipol-na tehinnatenu lefanekha*—accept supplication.

"'Pray for us unto YHWH your God.'"

*Ve-hitpallel ba'adenu el-YHWH Elohekha*—pray for us.

"'For all this remnant.'"

*Be'ad kol-ha-she'erit ha-zot*—for remnant.

"'We are left but a few of many.'"

*Ki nish'arnu me'at me-harbeh*—few from many.

"'As your eyes do behold us.'"

*Ka-asher einekha ro'ot otanu*—as you see.

**The Key Verse (42:3):**
"'That YHWH your God may tell us the way wherein we should walk.'"

*Ve-yagged-lanu YHWH Elohekha et-ha-derekh asher nelekh bah*—show us the way.

"'And the thing that we should do.'"

*Ve-et-ha-davar asher na'aseh*—what to do.

**Jeremiah's Response (42:4):**
"'I have heard you.'"

*Shama'ti*—I've heard.

"'Behold, I will pray unto YHWH your God according to your words.'"

*Hineni mitpallel el-YHWH Eloheikhem ki-divreikhem*—will pray.

"'Whatsoever thing YHWH shall answer you, I will declare it unto you.'"

*Ve-hayah kol-ha-davar asher-ya'aneh YHWH etkhem aggid lakhem*—will declare.

"'I will keep nothing back from you.'"

*Lo-emna mi-kkem davar*—nothing withheld.

**The People's Oath (42:5-6):**
**The Key Verse (42:5):**
"'YHWH be a true and faithful witness against us.'"

*Yehi YHWH banu le-ed emet ve-ne'eman*—YHWH witness.

"'If we do not even according to all the word wherewith YHWH your God shall send you to us.'"

*Im-lo ke-khol-ha-davar asher-yishlachakha YHWH Elohekha eleinu ken na'aseh*—we'll do it.

**The Key Verse (42:6):**
"'Whether it be good, or whether it be evil.'"

*Im-tov ve-im-ra*—good or bad.

"'We will hearken to the voice of YHWH our God.'"

*Be-qol YHWH Eloheinu... nishma*—we'll hear.

"'To whom we send you.'"

*Asher anachnu sholechim otakh elav*—whom we send you.

"'That it may be well with us, when we hearken.'"

*Lema'an yitav-lanu ki nishma be-qol YHWH Eloheinu*—well when we obey.

**YHWH's Answer (42:7-12):**
"After ten days, the word of YHWH came unto Jeremiah."

*Va-yehi mi-qetz aseret yamim va-yehi devar-YHWH el-Yirmeyahu*—10 days later.

"'Thus says YHWH, the God of Israel.'"

*Koh-amar YHWH Elohei Yisra'el*—YHWH says.

"'Unto whom you sent me to present your supplication before him.'"

*Asher shelachtem oti elav le-happil tachanunatkhem lefanav*—sent me.

**The Key Verse (42:10):**
"'If you will still abide in this land.'"

*Im-shov teshvu ba-aretz ha-zot*—if stay.

"'Then will I build you, and not pull you down.'"

*U-vaniti etkhem ve-lo eheros*—build, not destroy.

"'I will plant you, and not pluck you up.'"

*Ve-nata'ti etkhem ve-lo ettosh*—plant, not pluck.

"'For I repent of the evil that I have done unto you.'"

*Ki nichamti el-ha-ra'ah asher asiti lakhem*—I repent of evil.

**The Key Verse (42:11):**
"'Be not afraid of the king of Babylon.'"

*Al-tir'u mippenei melekh Bavel*—don't fear Babylon.

"'Of whom you are afraid.'"

*Asher-attem yere'im mippenav*—whom you fear.

"'Be not afraid of him,' says YHWH."

*Al-tir'u mimmenu*—don't fear him.

"'For I am with you to save you.'"

*Ki-ittkhem ani le-hoshi'a etkhem*—I'm with you.

"'To deliver you from his hand.'"

*U-le-hatztzil etkhem mi-yado*—deliver.

**The Key Verse (42:12):**
"'I will grant you compassion.'"

*Ve-etten lakhem rachamim*—grant compassion.

"'That he may have compassion upon you.'"

*Ve-richam etkhem*—he'll show compassion.

"'Cause you to return to your own land.'"

*Ve-heshiv etkhem el-admatekhem*—return to land.

**Warning About Egypt (42:13-18):**
**The Key Verses (42:13-14):**
"'If you say: We will not abide in this land.'"

*Ve-im-omerim attem lo neshev ba-aretz ha-zot*—if refuse.

"'So as not to hearken to the voice of YHWH your God.'"

*Le-vilti shemo'a be-qol YHWH Eloheikhem*—not hear.

"'No; but we will go into the land of Egypt.'"

*Lo ki eretz Mitzrayim navo*—will go Egypt.

"'Where we shall see no war.'"

*Asher lo-nir'eh sham milchamah*—no war.

"'Nor hear the sound of the horn.'"

*Ve-qol shofar lo nishma*—no trumpet.

"'Nor have hunger of bread.'"

*Ve-la-lechem lo nir'av*—no hunger.

"'There will we abide.'"

*Ve-sham neshev*—we'll stay.

**The Key Verses (42:15-17):**
"'Hear the word of YHWH, O remnant of Judah.'"

*Shim'u devar-YHWH she'erit Yehudah*—hear.

"'If you wholly set your faces to enter into Egypt.'"

*Im-attem sam tasimu feneikhem lavo Mitzrayim*—if set faces to Egypt.

"'And go to sojourn there.'"

*U-vatem lagur sham*—sojourn there.

"'The sword, which you fear, shall overtake you there in... Egypt.'"

*Ve-hayetah ha-cherev asher attem yere'im mimmennah sham tassig etkhem be-eretz Mitzrayim*—sword follows.

"'The famine, whereof you are afraid, shall follow close after you there in Egypt.'"

*Ve-ha-ra'av asher-attem do'agim mimmenu sham yidbaq acharekhem Mitzrayim*—famine follows.

"'There you shall die.'"

*Ve-sham tamutu*—die there.

"'All the men that set their faces to go into Egypt.'"

*Ve-yihyu khol-ha-anashim asher-samu et-peneihem lavo Mitzrayim*—all who go.

"'They shall die by the sword, by the famine, and by the pestilence.'"

*Yamutu ba-cherev ba-ra'av u-va-daver*—die by sword, famine, plague.

"'None of them shall remain or escape from the evil.'"

*Ve-lo-yihyeh lahem sarid u-falit mippenei ha-ra'ah*—no survivor.

**The Key Verse (42:18):**
"'As my anger and my fury has been poured forth upon the inhabitants of Jerusalem.'"

*Ka-asher nittkah appi va-chamati al-yoshevei Yerushalayim*—poured on Jerusalem.

"'So shall my fury be poured forth upon you, when you shall enter into Egypt.'"

*Ken tittakh chamati aleikhem be-vo'akhem Mitzrayim*—poured on you in Egypt.

"'You shall be an execration, and an astonishment, and a curse, and a reproach.'"

*Vi-heyitem le-alah u-le-shammah ve-li-qelalah u-le-cherpah*—curse.

"'You shall see this place no more.'"

*Ve-lo-tir'u od et-ha-maqom ha-zeh*—never see again.

**Final Warning (42:19-22):**
**The Key Verse (42:19):**
"'Go not into Egypt.'"

*Al-tavo'u Mitzrayim*—don't go to Egypt.

"'Know certainly that I have forewarned you this day.'"

*Yado'a ted'u ki ha'idoti vakhem ha-yom*—I've warned.

**The Key Verse (42:20):**
"'You have dealt deceitfully against your own souls.'"

*Ki hit'eitem be-nafshotekhem*—deceived yourselves.

"'You sent me unto YHWH your God.'"

*Ki-attem shelachtem oti el-YHWH Eloheikhem*—you sent me.

"'Pray for us unto YHWH our God.'"

*Hitpallel ba'adenu el-YHWH Eloheinu*—pray for us.

"'According unto all that YHWH our God shall say, so declare unto us, and we will do it.'"

*Ve-khe-khol asher-yomar YHWH Eloheinu ken hagged-lanu ve-asinu*—we'll do.

**The Key Verse (42:21):**
"'I have this day declared it to you.'"

*Va-aggid lakhem ha-yom*—declared.

"'You have not hearkened to the voice of YHWH your God.'"

*Ve-lo shema'tem be-qol YHWH Eloheikhem*—didn't hear.

"'Nor to any thing for which he has sent me unto you.'"

*U-le-khol asher-shelachani aleikhem*—didn't obey.

**The Key Verse (42:22):**
"'Know certainly that you shall die by the sword, by the famine, and by the pestilence.'"

*Ve-attah yado'a ted'u ki ba-cherev ba-ra'av u-va-daver tamutu*—will die.

"'In the place whither you desire to go to sojourn there.'"

*Ba-maqom asher chafatztem lavo lagur sham*—where you want to go.

**Archetypal Layer:** Jeremiah 42 contains **the remnant's oath to obey whatever YHWH says (42:5-6)**, **"If you will still abide in this land, then will I build you" (42:10)**, **"Be not afraid of the king of Babylon... I am with you" (42:11)**, and **warning that Egypt will bring the same judgment they fled (42:16-18)**.

**Ethical Inversion Applied:**
- "All the captains of the forces... and all the people"—all came
- "'Let... our supplication be accepted before you'"—supplication
- "'Pray for us unto YHWH your God'"—pray for us
- "'We are left but a few of many'"—few remnant
- "'That YHWH your God may tell us the way wherein we should walk'"—guidance sought
- "'I will pray unto YHWH your God according to your words'"—will pray
- "'Whatsoever thing YHWH shall answer you, I will declare'"—will declare
- "'I will keep nothing back from you'"—nothing hidden
- "'YHWH be a true and faithful witness against us'"—oath
- "'If we do not even according to all the word'"—promise
- "'Whether it be good, or whether it be evil, we will hearken'"—unconditional
- "After ten days, the word of YHWH came unto Jeremiah"—10 days
- "'If you will still abide in this land'"—if stay
- "'Then will I build you, and not pull you down'"—build
- "'I will plant you, and not pluck you up'"—plant
- "'I repent of the evil that I have done unto you'"—YHWH repents
- "'Be not afraid of the king of Babylon'"—don't fear
- "'I am with you to save you'"—with you
- "'To deliver you from his hand'"—deliver
- "'I will grant you compassion'"—compassion
- "'Cause you to return to your own land'"—return
- "'If you say: We will not abide in this land'"—if refuse
- "'We will go into the land of Egypt'"—Egypt choice
- "'Where we shall see no war... nor have hunger of bread'"—false hope
- "'The sword, which you fear, shall overtake you there in... Egypt'"—sword follows
- "'The famine, whereof you are afraid, shall follow close after you'"—famine follows
- "'There you shall die'"—die in Egypt
- "'They shall die by the sword, by the famine, and by the pestilence'"—judgment
- "'None of them shall remain or escape'"—no escape
- "'As my anger... has been poured forth upon... Jerusalem'"—like Jerusalem
- "'So shall my fury be poured forth upon you, when you shall enter into Egypt'"—poured on you
- "'You shall be an execration, and an astonishment, and a curse'"—cursed
- "'You shall see this place no more'"—never return
- "'Go not into Egypt'"—command
- "'You have dealt deceitfully against your own souls'"—self-deception
- "'You have not hearkened to the voice of YHWH'"—didn't hear
- "'Know certainly that you shall die'"—certain death

**Modern Equivalent:** Jeremiah 42 shows the remnant's insincere inquiry. They swore to obey "whether good or evil" (42:6), but had already decided to go to Egypt. YHWH's promise "I am with you" (42:11) echoes the patriarchal promises. Their fear of Babylon would bring the very judgment they fled.

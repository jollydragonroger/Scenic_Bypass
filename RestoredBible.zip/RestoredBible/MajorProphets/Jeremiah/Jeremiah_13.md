# Jeremiah 13: The Linen Girdle and the Wine Jars

*From the Hebrew: כֹּה אָמַר יְהוָה אֵלַי (Koh Amar YHWH Elai) — Thus Said YHWH to Me*

---

## The Linen Girdle (13:1-11)

**13:1** Thus said YHWH unto me: "Go, and get yourself a linen girdle, and put it upon your loins, and put it not in water."

**13:2** So I got a girdle according to the word of YHWH, and put it upon my loins.

**13:3** And the word of YHWH came unto me the second time, saying:

**13:4** "Take the girdle that you have gotten, which is upon your loins, and arise, go to Perath, and hide it there in a cleft of the rock."

**13:5** So I went, and hid it in Perath, as YHWH commanded me.

**13:6** And it came to pass after many days, that YHWH said unto me: "Arise, go to Perath, and take the girdle from there, which I commanded you to hide there."

**13:7** Then I went to Perath, and digged, and took the girdle from the place where I had hid it; and, behold, the girdle was marred, it was profitable for nothing.

**13:8** Then the word of YHWH came unto me, saying:

**13:9** "Thus says YHWH: After this manner will I mar the pride of Judah, and the great pride of Jerusalem.

**13:10** "This evil people, that refuse to hear my words, that walk in the stubbornness of their heart, and are gone after other gods to serve them, and to worship them, shall even be as this girdle, which is profitable for nothing.

**13:11** "For as the girdle cleaves to the loins of a man, so have I caused to cleave unto me the whole house of Israel and the whole house of Judah," says YHWH; "that they might be unto me for a people, and for a name, and for a praise, and for a glory; but they would not hearken."

---

## The Wine Jars (13:12-14)

**13:12** Moreover you shall speak unto them this word: "Thus says YHWH, the God of Israel: Every jar shall be filled with wine." And when they shall say unto you: "Do we not know well that every jar shall be filled with wine?"

**13:13** Then shall you say unto them: "Thus says YHWH: Behold, I will fill all the inhabitants of this land, even the kings that sit upon David's throne, and the priests, and the prophets, and all the inhabitants of Jerusalem, with drunkenness.

**13:14** "And I will dash them one against another, even the fathers and the sons together," says YHWH; "I will not pity, nor spare, nor have compassion, that I should not destroy them."

---

## Warning Against Pride (13:15-17)

**13:15** Hear, and give ear, be not proud; for YHWH has spoken.

**13:16** Give glory to YHWH your God, before it grow dark, and before your feet stumble upon the twilight mountains, and, while you look for light, he turn it into the shadow of death, and make it gross darkness.

**13:17** But if you will not hear it, my soul shall weep in secret for your pride; and my eye shall weep sore, and run down with tears, because YHWH's flock is carried away captive.

---

## Message to the King and Queen Mother (13:18-19)

**13:18** Say unto the king and to the queen mother: "Sit down low; for your headdresses are come down, even the crown of your glory."

**13:19** The cities of the South are shut up, and there is none to open them; Judah is carried away captive all of it; it is wholly carried away captive.

---

## Jerusalem's Shame (13:20-27)

**13:20** Lift up your eyes, and behold them that come from the north; where is the flock that was given you, your beautiful flock?

**13:21** What will you say, when he shall set over you—and you yourself have trained them—to be captains over you? Shall not pangs take hold of you, as of a woman in travail?

**13:22** And if you say in your heart: "Wherefore are these things come upon me?"—for the greatness of your iniquity are your skirts uncovered, and your heels suffer violence.

**13:23** Can the Cushite change his skin, or the leopard his spots? Then may you also do good, that are accustomed to do evil.

**13:24** Therefore will I scatter them, as the stubble that passes away, by the wind of the wilderness.

**13:25** This is your lot, the portion measured unto you from me, says YHWH; because you have forgotten me, and trusted in falsehood.

**13:26** Therefore will I also uncover your skirts upon your face, and your shame shall appear.

**13:27** Your adulteries, and your neighings, the lewdness of your harlotry, on the hills in the field, I have seen your detestable acts. Woe unto you, O Jerusalem! You will not be made clean! When shall it ever be?

---

## Synthesis Notes

**Key Restorations:**

**Linen Girdle Sign-Act (13:1-7):**
"Go, and get yourself a linen girdle."

*Halokh ve-qanita lekha ezor pishtim*—buy linen girdle.

"Put it upon your loins."

*Ve-samto al-motnekha*—wear on loins.

"Put it not in water."

*U-va-mayim lo tevi'ehu*—don't wash it.

"Go to Perath, and hide it there."

*Qum lekh Peratah ve-tomnehu sham*—hide at Perath.

**Note:** Perath could be the Euphrates (symbolizing Babylon) or a local wadi Parah near Anathoth.

"The girdle was marred, it was profitable for nothing."

*Ve-hinneh nishchat ha-ezor lo-yitzlach la-kol*—marred, useless.

**Interpretation (13:9-11):**
"After this manner will I mar the pride of Judah."

*Ka-khah ashchit et-ge'on Yehudah*—mar Judah's pride.

"The great pride of Jerusalem."

*Ve-et-ge'on Yerushalayim ha-rav*—Jerusalem's pride.

"This evil people, that refuse to hear my words."

*Ha-am ha-ra ha-zeh ha-me'anim lishmoa et-devarai*—refuse to hear.

"Walk in the stubbornness of their heart."

*Ha-holekhim bi-sherirut libbam*—stubborn heart.

"Gone after other gods."

*Va-yelkhu acharei elohim acherim*—other gods.

"Shall even be as this girdle, which is profitable for nothing."

*Vi-yhi ka-ezor ha-zeh asher lo-yitzlach la-kol*—useless like girdle.

**The Key Verse (13:11):**
"As the girdle cleaves to the loins of a man."

*Ki ka-asher yidbaq ha-ezor el-motnei-ish*—girdle cleaves.

"So have I caused to cleave unto me the whole house of Israel and the whole house of Judah."

*Ken hidbaqti elai et-kol-beit Yisra'el ve-et-kol-beit Yehudah*—Israel/Judah cleave.

"That they might be unto me for a people."

*Li-heyot li le-am*—be my people.

"For a name, and for a praise, and for a glory."

*U-le-shem u-li-tehillah u-le-tif'aret*—name, praise, glory.

"But they would not hearken."

*Ve-lo shame'u*—didn't hear.

**Wine Jars (13:12-14):**
"Every jar shall be filled with wine."

*Kol-nevel yimmale yayin*—jars filled.

"'Do we not know well that every jar shall be filled with wine?'"

*Ha-lo yado'a neda ki khol-nevel yimmale yayin*—obvious proverb.

"I will fill all the inhabitants of this land... with drunkenness."

*Hineni memalle et-kol-yoshevei ha-aretz ha-zot... shikkaron*—filled with drunkenness.

"The kings that sit upon David's throne."

*Ve-et-ha-melakhim ha-yoshevim le-David al-kis'o*—kings on David's throne.

"The priests, and the prophets."

*Ve-et-ha-kohanim ve-et-ha-nevi'im*—priests and prophets.

"I will dash them one against another."

*Ve-nippaztim ish el-achiv*—dash together.

"Even the fathers and the sons together."

*Ve-ha-avot ve-ha-banim yachdav*—fathers and sons.

"I will not pity, nor spare, nor have compassion."

*Lo-echmol ve-lo-achus ve-lo arachem*—no pity.

**Warning (13:15-17):**
"Hear, and give ear, be not proud."

*Shim'u ve-ha'azinu al-tigbahu*—don't be proud.

**The Key Verse (13:16):**
"Give glory to YHWH your God."

*Tenu la-YHWH Eloheikhem kavod*—give glory.

"Before it grow dark."

*Be-terem yachshikh*—before dark.

"Before your feet stumble upon the twilight mountains."

*U-ve-terem yitnaggefu raglekhem al-harei-nashef*—before stumbling.

"While you look for light, he turn it into the shadow of death."

*Ve-qivvitem le-or ve-samo le-tzalmavet*—light to death-shadow.

"Make it gross darkness."

*Yasit la-arafel*—gross darkness.

**The Key Verse (13:17):**
"If you will not hear it."

*Ve-im lo tishma'ukha*—if not hear.

"My soul shall weep in secret for your pride."

*Be-mistarim tivkeh nafshi mippenei gevah*—soul weeps secretly.

"My eye shall weep sore, and run down with tears."

*Ve-damoa tidma ve-tered eini dim'ah*—eyes run tears.

"Because YHWH's flock is carried away captive."

*Ki nishbah eder YHWH*—flock captive.

**King and Queen Mother (13:18-19):**
"Say unto the king and to the queen mother."

*Emor la-melekh ve-la-gevirah*—to king and queen mother.

"'Sit down low.'"

*Hashpilu shevu*—sit low.

"'Your headdresses are come down.'"

*Ki yarad mera'ashotekhem*—headdresses down.

"'Even the crown of your glory.'"

*Ateret tif'artkhem*—glory crown.

"The cities of the South are shut up."

*Arei ha-negev suggeruv*—south cities shut.

"There is none to open them."

*Ve-ein pote'ach*—none opens.

"Judah is carried away captive all of it."

*Hogelatah Yehudah kullahh*—Judah captive.

"It is wholly carried away captive."

*Hogelatah shelomim*—wholly captive.

**Jerusalem's Shame (13:20-27):**
"Lift up your eyes, and behold them that come from the north."

*Se'i einayikh u-re'i ha-ba'im mi-tzafon*—see northerners.

"Where is the flock that was given you, your beautiful flock?"

*Ayyeh ha-eder nitan-lakh tzon tif'artek*—where's beautiful flock?

"Shall not pangs take hold of you, as of a woman in travail?"

*Halo chavalim yo'chazukh ke-eshet ledah*—travail pangs.

"'Wherefore are these things come upon me?'"

*Maddua qera'uni elleh*—why these things?

"For the greatness of your iniquity are your skirts uncovered."

*Be-rov avonek nigluu shulayikh*—skirts uncovered.

"Your heels suffer violence."

*Nechmesu aqqevayikh*—heels violated.

**The Key Verse (13:23):**
"Can the Cushite change his skin?"

*Ha-yahafokhk Kushi oro*—can Cushite change skin?

"Or the leopard his spots?"

*Ve-namer chabarburotav*—leopard change spots?

"Then may you also do good, that are accustomed to do evil."

*Gam-attem tukhlu le-heitiv limmudei hare'a*—can evil-learners do good?

**Habituated Sin:**
Sin has become so ingrained that changing is as impossible as changing skin color or spots.

"I scatter them, as the stubble that passes away."

*Va-afitzem ke-qash-over*—scattered stubble.

"By the wind of the wilderness."

*Le-ruach midbar*—wilderness wind.

"This is your lot, the portion measured unto you from me."

*Zeh goralekh menat-middayikh me-itti*—your measured lot.

"Because you have forgotten me."

*Asher shakacht oti*—forgot me.

"Trusted in falsehood."

*Va-tivtechi ba-shaqer*—trusted lies.

"I will uncover your skirts upon your face."

*Ve-gam-ani chasafti shulayikh al-panayikh*—skirts uncovered.

"Your shame shall appear."

*Ve-nir'ah qelonekh*—shame seen.

"Your adulteries, and your neighings."

*Ni'ufayikh u-mitzhalotayikh*—adulteries, neighings.

"The lewdness of your harlotry."

*Zimmmat zenutekh*—harlotry lewdness.

"On the hills in the field."

*Al-geva'ot ba-sadeh*—hills and fields.

"I have seen your detestable acts."

*Ra'iti shiqqutzeikh*—seen detestables.

"Woe unto you, O Jerusalem!"

*Oy lakh Yerushalayim*—woe Jerusalem.

"You will not be made clean!"

*Lo tithhari*—not cleansed.

"When shall it ever be?"

*Acharei matai od*—when ever?

**Archetypal Layer:** Jeremiah 13 contains **the linen girdle sign-act (13:1-11)**, **the wine jars oracle (13:12-14)**, **"Can the Cushite change his skin, or the leopard his spots?" (13:23)**, and **the theme of habituated sin**.

**Ethical Inversion Applied:**
- "Go, and get yourself a linen girdle"—sign-act begins
- "Put it not in water"—don't wash
- "Go to Perath, and hide it there"—bury at Euphrates
- "The girdle was marred, it was profitable for nothing"—useless girdle
- "After this manner will I mar the pride of Judah"—pride marred
- "This evil people, that refuse to hear my words"—refuse to hear
- "As the girdle cleaves to the loins of a man"—intimate clinging
- "So have I caused to cleave unto me... Israel and... Judah"—YHWH's intimacy
- "That they might be unto me for a people, and for a name, and for a praise"—purpose
- "But they would not hearken"—didn't listen
- "Every jar shall be filled with wine"—proverb
- "I will fill all the inhabitants... with drunkenness"—drunkenness judgment
- "I will dash them one against another"—dashing
- "Hear, and give ear, be not proud"—don't be proud
- "Give glory to YHWH your God, before it grow dark"—give glory
- "Before your feet stumble upon the twilight mountains"—twilight stumbling
- "If you will not hear it, my soul shall weep in secret"—Jeremiah weeps
- "Because YHWH's flock is carried away captive"—flock captive
- "Say unto the king and to the queen mother: 'Sit down low'"—royalty humbled
- "Judah is carried away captive all of it"—total captivity
- "Can the Cushite change his skin, or the leopard his spots?"—impossible change
- "Then may you also do good, that are accustomed to do evil"—habituated evil
- "I scatter them, as the stubble"—scattered
- "You have forgotten me, and trusted in falsehood"—forgot YHWH
- "Woe unto you, O Jerusalem! You will not be made clean!"—unclean

**Modern Equivalent:** Jeremiah 13's sign-acts illustrate prophetic drama. "Can the Cushite change his skin, or the leopard his spots?" (13:23) shows sin's enslaving power—it becomes second nature. This supports the need for new covenant heart transformation (31:31-34).

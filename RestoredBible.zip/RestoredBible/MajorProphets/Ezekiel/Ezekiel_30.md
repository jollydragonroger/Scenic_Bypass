# Ezekiel 30: The Day of Egypt

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## The Day of YHWH for Egypt (30:1-9)

**30:1** And the word of YHWH came unto me, saying:

**30:2** "Son of man, prophesy, and say: Thus says the Lord YHWH: Wail: 'Alas for the day!'

**30:3** "For the day is near, even the day of YHWH is near; a day of clouds, it shall be the time of the nations.

**30:4** "And a sword shall come upon Egypt, and anguish shall be in Ethiopia, when the slain shall fall in Egypt; and they shall take away her abundance, and her foundations shall be broken down.

**30:5** "Ethiopia, and Put, and Lud, and all the mingled people, and Cub, and the children of the land that is in league, shall fall with them by the sword.

**30:6** "Thus says YHWH: They also that uphold Egypt shall fall, and the pride of her power shall come down; from Migdol to Syene shall they fall in it by the sword," says the Lord YHWH.

**30:7** "And they shall be desolate in the midst of the countries that are desolate, and her cities shall be in the midst of the cities that are wasted.

**30:8** "And they shall know that I am YHWH, when I have set a fire in Egypt, and all her helpers are destroyed.

**30:9** "In that day shall messengers go forth from before me in ships to make the careless Ethiopians afraid; and there shall be anguish upon them, as in the day of Egypt; for, lo, it comes."

---

## Egypt's Cities Destroyed (30:10-19)

**30:10** Thus says the Lord YHWH: "I will also make the multitude of Egypt to cease, by the hand of Nebuchadrezzar king of Babylon.

**30:11** "He and his people with him, the terrible of the nations, shall be brought in to destroy the land; and they shall draw their swords against Egypt, and fill the land with the slain.

**30:12** "And I will make the rivers dry, and will give over the land into the hand of evil men; and I will make the land desolate, and all that is therein, by the hand of strangers; I YHWH have spoken it.

**30:13** "Thus says the Lord YHWH: I will also destroy the idols, and I will cause the things of nought to cease from Noph; and there shall be no more a prince out of the land of Egypt; and I will put a fear in the land of Egypt.

**30:14** "And I will make Pathros desolate, and will set a fire in Zoan, and will execute judgments upon No.

**30:15** "And I will pour my fury upon Sin, the stronghold of Egypt; and I will cut off the multitude of No.

**30:16** "And I will set a fire in Egypt; Sin shall be in great anguish, and No shall be broken into, and Noph shall have adversaries in the daytime.

**30:17** "The young men of Aven and of Pi-beseth shall fall by the sword; and these cities shall go into captivity.

**30:18** "At Tehaphnehes also the day shall withdraw itself, when I shall break there the yokes of Egypt, and the pride of her power shall cease in her; as for her, a cloud shall cover her, and her daughters shall go into captivity.

**30:19** "Thus will I execute judgments upon Egypt; and they shall know that I am YHWH."

---

## Pharaoh's Arms Broken (30:20-26)

**30:20** And it came to pass in the eleventh year, in the first month, in the seventh day of the month, that the word of YHWH came unto me, saying:

**30:21** "Son of man, I have broken the arm of Pharaoh king of Egypt; and, lo, it has not been bound up to apply healing, to bind it up, that it be strong to hold the sword.

**30:22** "Therefore thus says the Lord YHWH: Behold, I am against Pharaoh king of Egypt, and will break his arms, the strong, and that which was broken; and I will cause the sword to fall out of his hand.

**30:23** "And I will scatter the Egyptians among the nations, and will disperse them through the countries.

**30:24** "And I will strengthen the arms of the king of Babylon, and put my sword in his hand; but I will break the arms of Pharaoh, and he shall groan before him with the groanings of a deadly wounded man.

**30:25** "And I will hold up the arms of the king of Babylon, and the arms of Pharaoh shall fall down; and they shall know that I am YHWH, when I shall put my sword into the hand of the king of Babylon, and he shall stretch it out upon the land of Egypt.

**30:26** "And I will scatter the Egyptians among the nations, and disperse them through the countries; and they shall know that I am YHWH."

---

## Synthesis Notes

**Key Restorations:**

**Day of YHWH for Egypt (30:1-9):**
**The Key Verse (30:2):**
"'Wail: Alas for the day!'"

*Heililu hah la-yom*—wail for day.

**The Key Verse (30:3):**
"'The day is near, even the day of YHWH is near.'"

*Ki-qarov yom ve-qarov yom la-YHWH*—day of YHWH near.

"'A day of clouds.'"

*Yom anan*—cloudy day.

"'It shall be the time of the nations.'"

*Et goyim yihyeh*—time of nations.

**Day of YHWH:**
Applied to Egypt—judgment day language.

**The Key Verses (30:4-6):**
"'A sword shall come upon Egypt.'"

*U-va'ah cherev be-Mitzrayim*—sword comes.

"'Anguish shall be in Ethiopia.'"

*Ve-hayetah chalkhalah ve-Khush*—Ethiopia anguished.

"'When the slain shall fall in Egypt.'"

*Bi-neפol challal be-Mitzrayim*—slain fall.

"'They shall take away her abundance.'"

*Ve-laqechu hamonah*—take abundance.

"'Her foundations shall be broken down.'"

*Ve-nehersu yesodoteyha*—foundations broken.

"'Ethiopia, and Put, and Lud.'"

*Kush u-Put u-Lud*—African allies.

"'All the mingled people.'"

*Ve-khol-ha-erev*—mixed peoples.

"'Cub, and the children of the land that is in league.'"

*Ve-Khuv u-venei eretz ha-berit*—allies.

"'Shall fall with them by the sword.'"

*Ittam ba-cherev yippolu*—fall by sword.

"'They also that uphold Egypt shall fall.'"

*Ve-nafelu somkhei Mitzrayim*—supporters fall.

"'The pride of her power shall come down.'"

*Ve-yarad ge'on uzzah*—pride falls.

"'From Migdol to Syene shall they fall.'"

*Mi-Migdol Seveneh ba-cherev yippelu-vah*—entire Egypt.

**The Key Verses (30:7-9):**
"'They shall be desolate in the midst of the countries that are desolate.'"

*Ve-nashemu be-tokh aratzot neshammot*—desolate among desolate.

"'Her cities shall be in the midst of the cities that are wasted.'"

*Ve-areyha be-tokh arim necheravot tihyenah*—cities wasted.

"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—recognition.

"'When I have set a fire in Egypt.'"

*Be-titti esh be-Mitzrayim*—fire in Egypt.

"'All her helpers are destroyed.'"

*Ve-nishberu kol-ozreyha*—helpers destroyed.

"'In that day shall messengers go forth from before me in ships.'"

*Ba-yom ha-hu yetze'u mal'akhim mi-lefanai ba-tzim*—messengers in ships.

"'To make the careless Ethiopians afraid.'"

*Le-hacharid et-Kush boteach*—terrify Ethiopia.

"'There shall be anguish upon them, as in the day of Egypt.'"

*Ve-hayetah chalkhalah vahem ke-yom Mitzrayim*—anguish.

**Egypt's Cities Destroyed (30:10-19):**
**The Key Verses (30:10-12):**
"'I will also make the multitude of Egypt to cease.'"

*Ve-hishbatti et-hamon Mitzrayim*—cease multitude.

"'By the hand of Nebuchadrezzar king of Babylon.'"

*Be-yad Nevukhadre'tzar melekh-Bavel*—Nebuchadnezzar.

"'He and his people with him, the terrible of the nations.'"

*Hu ve-ammo itto aritzei goyim*—terrible nations.

"'Shall be brought in to destroy the land.'"

*Muva'im le-shachet ha-aretz*—destroy.

"'They shall draw their swords against Egypt.'"

*Ve-heriqu charvotam al-Mitzrayim*—draw swords.

"'Fill the land with the slain.'"

*U-mill'u et-ha-aretz challal*—fill with slain.

"'I will make the rivers dry.'"

*Ve-natatti ye'orim charavah*—rivers dry.

"'Will give over the land into the hand of evil men.'"

*U-makharti et-ha-aretz be-yad ra'im*—to evil men.

"'I will make the land desolate... by the hand of strangers.'"

*Ve-hashimmoti eretz u-melo'ah be-yad zarim*—by strangers.

**The Key Verses (30:13-16):**
"'I will also destroy the idols.'"

*Ve-ha'avadti gillulim*—destroy idols.

"'I will cause the things of nought to cease from Noph.'"

*Ve-hishbatti elilim mi-Nof*—cease from Memphis.

"'There shall be no more a prince out of the land of Egypt.'"

*Ve-nasi me-eretz Mitzrayim lo yihyeh od*—no more prince.

"'I will put a fear in the land of Egypt.'"

*Ve-natatti yir'ah be-eretz Mitzrayim*—fear.

"'I will make Pathros desolate.'"

*Va-hashimmoti et-Patros*—Pathros desolate.

"'Will set a fire in Zoan.'"

*Ve-natatti esh be-Tzo'an*—fire in Zoan.

"'Will execute judgments upon No.'"

*Ve-asiti shefatim be-No*—judgments on Thebes.

"'I will pour my fury upon Sin, the stronghold of Egypt.'"

*Ve-shafakhti chamati al-Sin ma'oz Mitzrayim*—Sin/Pelusium.

"'I will cut off the multitude of No.'"

*Ve-hikhraatti et-hamon No*—cut off Thebes.

"'I will set a fire in Egypt.'"

*Ve-natatti esh be-Mitzrayim*—fire.

"'Sin shall be in great anguish.'"

*Chul tachil Sin*—Sin anguished.

"'No shall be broken into.'"

*Ve-No li-hevvaqe'a*—Thebes broken.

"'Noph shall have adversaries in the daytime.'"

*Ve-Nof tzarei yomam*—Memphis adversaries.

**The Key Verses (30:17-19):**
"'The young men of Aven and of Pi-beseth shall fall by the sword.'"

*Bachurei Aven u-Fi-Veset ba-cherev yippolu*—Heliopolis, Bubastis.

"'These cities shall go into captivity.'"

*Ve-hennah ba-shevi telakhnah*—captivity.

"'At Tehaphnehes also the day shall withdraw itself.'"

*U-vi-Thachpancheיs chasakh ha-yom*—Tahpanhes darkened.

"'When I shall break there the yokes of Egypt.'"

*Be-shivri-sham et-mottot Mitzrayim*—break yokes.

"'The pride of her power shall cease in her.'"

*Ve-nishbat-bah ge'on uzzah*—pride ceases.

"'A cloud shall cover her.'"

*Hi anan yekhasennah*—cloud covers.

"'Her daughters shall go into captivity.'"

*U-venoteyha ba-shevi telakhnah*—daughters captive.

"'Thus will I execute judgments upon Egypt.'"

*Ve-asiti shefatim be-Mitzrayim*—judgments.

**Egyptian Cities:**
Noph (Memphis), No (Thebes), Sin (Pelusium), Pathros (Upper Egypt), Zoan (Tanis), Aven (Heliopolis), Pi-beseth (Bubastis), Tehaphnehes (Tahpanhes).

**Pharaoh's Arms Broken (30:20-26):**
**The Key Verse (30:20):**
"In the eleventh year, in the first month, in the seventh day of the month."

*Ba-shanah ha-ashtei-esreh ba-rishon be-shiv'ah la-chodesh*—April 587 BCE.

**The Key Verse (30:21):**
"'I have broken the arm of Pharaoh king of Egypt.'"

*Et-zero'a Par'oh melekh-Mitzrayim shavarti*—arm broken.

"'It has not been bound up to apply healing.'"

*Ve-hinneh lo-chubbeshah latet refuot*—not bound.

"'To bind it up, that it be strong to hold the sword.'"

*Lasum chittul le-chozקah li-tfos ba-cherev*—can't hold sword.

**Broken Arm:**
Hophra's (Apries') failed attempt to relieve Jerusalem (Jeremiah 37:5-7).

**The Key Verses (30:22-24):**
"'Behold, I am against Pharaoh king of Egypt.'"

*Hineni el-Par'oh melekh-Mitzrayim*—against Pharaoh.

"'Will break his arms, the strong, and that which was broken.'"

*Ve-shavarti et-zero'otav et-ha-chazaqah ve-et-ha-nishberet*—both arms.

"'I will cause the sword to fall out of his hand.'"

*Ve-hipppalti et-ha-cherev mi-yado*—sword falls.

"'I will scatter the Egyptians among the nations.'"

*Va-hafitzoti et-Mitzrayim ba-goyim*—scatter.

"'I will strengthen the arms of the king of Babylon.'"

*Ve-chizzaqti et-zero'ot melekh-Bavel*—strengthen Babylon.

"'Put my sword in his hand.'"

*Ve-natatti et-charbi be-yado*—my sword.

"'I will break the arms of Pharaoh.'"

*Ve-shavarti et-zero'ot Par'oh*—break Pharaoh's.

"'He shall groan before him with the groanings of a deadly wounded man.'"

*Ve-na'aq na'aqot challal lefanav*—groan.

**The Key Verses (30:25-26):**
"'I will hold up the arms of the king of Babylon.'"

*Ve-hichzaqti et-zero'ot melekh-Bavel*—hold up Babylon.

"'The arms of Pharaoh shall fall down.'"

*U-zero'ot Par'oh tipppalנah*—Pharaoh's fall.

"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—recognition.

"'When I shall put my sword into the hand of the king of Babylon.'"

*Be-titti charbi be-yad melekh-Bavel*—my sword in Babylon's hand.

"'He shall stretch it out upon the land of Egypt.'"

*Ve-natah otah al-eretz Mitzrayim*—over Egypt.

"'I will scatter the Egyptians among the nations.'"

*Va-hafitzoti et-Mitzrayim ba-goyim*—scatter.

"'Disperse them through the countries.'"

*Ve-zeriתim ba-aratzot*—disperse.

**Archetypal Layer:** Ezekiel 30 contains **"the day of YHWH is near; a day of clouds" (30:3)**, **catalogue of Egyptian cities to be destroyed (30:13-18)**, **"I have broken the arm of Pharaoh king of Egypt" (30:21)**, and **"I will strengthen the arms of the king of Babylon, and put my sword in his hand" (30:24)**.

**Ethical Inversion Applied:**
- "'Wail: Alas for the day!'"—wail
- "'The day is near, even the day of YHWH is near'"—day of YHWH
- "'A day of clouds'"—cloudy day
- "'It shall be the time of the nations'"—time of nations
- "'A sword shall come upon Egypt'"—sword
- "'Anguish shall be in Ethiopia'"—anguish
- "'They shall take away her abundance'"—take abundance
- "'Her foundations shall be broken down'"—foundations broken
- "'Ethiopia, and Put, and Lud... shall fall'"—allies fall
- "'They also that uphold Egypt shall fall'"—supporters fall
- "'From Migdol to Syene'"—entire Egypt
- "'I have set a fire in Egypt'"—fire
- "'All her helpers are destroyed'"—helpers destroyed
- "'Messengers go forth... to make the careless Ethiopians afraid'"—terrify Ethiopia
- "'I will also make the multitude of Egypt to cease'"—cease
- "'By the hand of Nebuchadrezzar'"—Nebuchadnezzar
- "'The terrible of the nations'"—terrible nations
- "'I will make the rivers dry'"—rivers dry
- "'I will also destroy the idols'"—destroy idols
- "'I will cause the things of nought to cease from Noph'"—Memphis
- "'There shall be no more a prince out of the land of Egypt'"—no prince
- "'I will make Pathros desolate'"—Pathros
- "'Will set a fire in Zoan'"—Zoan
- "'Will execute judgments upon No'"—Thebes
- "'I will pour my fury upon Sin'"—Pelusium
- "'The young men of Aven and of Pi-beseth'"—Heliopolis, Bubastis
- "'At Tehaphnehes also the day shall withdraw'"—Tahpanhes darkened
- "In the eleventh year"—April 587 BCE
- "'I have broken the arm of Pharaoh'"—arm broken
- "'It has not been bound up'"—unhealed
- "'Will break his arms, the strong, and that which was broken'"—both arms
- "'I will cause the sword to fall out of his hand'"—sword falls
- "'I will strengthen the arms of the king of Babylon'"—strengthen Babylon
- "'Put my sword in his hand'"—YHWH's sword
- "'I will break the arms of Pharaoh'"—break Pharaoh
- "'He shall groan... with the groanings of a deadly wounded man'"—groan
- "'The arms of Pharaoh shall fall down'"—arms fall

**Modern Equivalent:** Ezekiel 30 describes Egypt's day of judgment. The catalogue of Egyptian cities (30:13-18) shows comprehensive destruction. "Day of YHWH" language (30:3) applied to Egypt shows YHWH's universal sovereignty. Pharaoh's "broken arm" (30:21) refers to Hophra's failed relief of Jerusalem.

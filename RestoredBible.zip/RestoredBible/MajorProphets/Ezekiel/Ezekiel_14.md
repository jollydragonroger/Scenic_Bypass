# Ezekiel 14: Idolatry and the Intercession of the Righteous

*From the Hebrew: וַיָּבוֹא אֵלַי אֲנָשִׁים (Va-Yavo Elai Anashim) — And There Came Unto Me Certain Men*

---

## Idolatrous Inquirers (14:1-11)

**14:1** Then came certain of the elders of Israel unto me, and sat before me.

**14:2** And the word of YHWH came unto me, saying:

**14:3** "Son of man, these men have set up their idols in their heart, and put the stumbling-block of their iniquity before their face; should I be inquired of at all by them?

**14:4** "Therefore speak unto them, and say unto them: Thus says the Lord YHWH: Every man of the house of Israel that sets up his idols in his heart, and puts the stumbling-block of his iniquity before his face, and comes to the prophet—I YHWH will answer him that comes according to the multitude of his idols;

**14:5** "That I may take the house of Israel in their own heart, because they are all turned away from me through their idols.

**14:6** "Therefore say unto the house of Israel: Thus says the Lord YHWH: Return, and turn yourselves from your idols; and turn away your faces from all your abominations.

**14:7** "For every one of the house of Israel, or of the strangers that sojourn in Israel, that separates himself from me, and sets up his idols in his heart, and puts the stumbling-block of his iniquity before his face, and comes to the prophet to inquire of me concerning him—I YHWH will answer him by myself;

**14:8** "And I will set my face against that man, and will make him a sign and a proverb, and I will cut him off from the midst of my people; and you shall know that I am YHWH.

**14:9** "And when the prophet is deceived and speaks a word, I YHWH have deceived that prophet, and I will stretch out my hand upon him, and will destroy him from the midst of my people Israel.

**14:10** "And they shall bear their iniquity; the iniquity of the prophet shall be even as the iniquity of him that inquires;

**14:11** "That the house of Israel may go no more astray from me, neither defile themselves any more with all their transgressions; but that they may be my people, and I may be their God," says the Lord YHWH.

---

## Noah, Daniel, and Job (14:12-23)

**14:12** And the word of YHWH came unto me, saying:

**14:13** "Son of man, when a land sins against me by trespassing grievously, and I stretch out my hand upon it, and break the staff of the bread thereof, and send famine upon it, and cut off from it man and beast;

**14:14** "Though these three men, Noah, Daniel, and Job, were in it, they should deliver but their own souls by their righteousness," says the Lord YHWH.

**14:15** "If I cause evil beasts to pass through the land, and they bereave it, and it be desolate, so that no man may pass through because of the beasts;

**14:16** "Though these three men were in it, as I live," says the Lord YHWH, "they shall deliver neither sons nor daughters; they only shall be delivered, but the land shall be desolate.

**14:17** "Or if I bring a sword upon that land, and say: 'Let the sword go through the land,' so that I cut off from it man and beast;

**14:18** "Though these three men were in it, as I live," says the Lord YHWH, "they shall deliver neither sons nor daughters, but they only shall be delivered themselves.

**14:19** "Or if I send a pestilence into that land, and pour out my fury upon it in blood, to cut off from it man and beast;

**14:20** "Though Noah, Daniel, and Job, were in it, as I live," says the Lord YHWH, "they shall deliver neither son nor daughter; they shall but deliver their own souls by their righteousness.

**14:21** "For thus says the Lord YHWH: How much more when I send my four sore judgments upon Jerusalem, the sword, and the famine, and the evil beasts, and the pestilence, to cut off from it man and beast!

**14:22** "And, behold, though there be left a remnant therein that shall be brought forth, both sons and daughters; behold, when they come forth unto you, and you see their way and their doings, then you shall be comforted concerning the evil that I have brought upon Jerusalem, even concerning all that I have brought upon it.

**14:23** "And they shall comfort you, when you see their way and their doings; and you shall know that I have not done without cause all that I have done in it," says the Lord YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Idolatrous Inquirers (14:1-11):**
**The Key Verse (14:1):**
"Certain of the elders of Israel... sat before me."

*Va-yavo elai anashim mi-ziqnei Yisra'el va-yeshvu lefanai*—elders came.

**The Key Verse (14:3):**
"'These men have set up their idols in their heart.'"

*Ha-anashim ha-elleh he'elu gilluleihem al-libbam*—idols in heart.

"'Put the stumbling-block of their iniquity before their face.'"

*U-mikhshol avonam natenu nokhach peneihem*—stumbling-block before face.

"'Should I be inquired of at all by them?'"

*Ha-hidarosh iddaresh lahem*—should I answer?

**Heart Idolatry:**
Not just external idols, but internal devotion to false gods.

**The Key Verses (14:4-5):**
"'Every man of the house of Israel that sets up his idols in his heart.'"

*Ish ish mi-beit Yisra'el asher ya'aleh et-gillulav el-libbo*—sets up in heart.

"'Comes to the prophet—I YHWH will answer him... according to the multitude of his idols.'"

*U-va el-ha-navi ani YHWH na'aneiti lo be-rov gillulav*—answer by idols.

"'That I may take the house of Israel in their own heart.'"

*Lema'an tefos et-beit Yisra'el be-libbam*—catch in heart.

"'Because they are all turned away from me through their idols.'"

*Asher nazoru me-alai be-gilluleihem kullam*—turned away.

**The Key Verse (14:6):**
"'Return, and turn yourselves from your idols.'"

*Shuvu ve-hashivu me-al gilluleikhem*—return.

"'Turn away your faces from all your abominations.'"

*U-me-al kol-to'avoteikhem hashivu feneikhem*—turn from abominations.

**The Key Verses (14:7-8):**
"'Every one of the house of Israel, or of the strangers that sojourn in Israel.'"

*Ki ish ish mi-beit Yisra'el u-min-ha-ger asher-yagur be-Yisra'el*—Israel or sojourner.

"'That separates himself from me.'"

*Ve-yinnazzier me-acharai*—separates.

"'Sets up his idols in his heart.'"

*Ve-ya'al gillulav el-libbo*—idols in heart.

"'I YHWH will answer him by myself.'"

*Na'aneiti-lo vi ani YHWH*—answer myself.

"'I will set my face against that man.'"

*Ve-natatti fanai ba-ish ha-hu*—face against.

"'Will make him a sign and a proverb.'"

*Va-hasimotihu le-ot u-li-mshalim*—sign, proverb.

"'I will cut him off from the midst of my people.'"

*Ve-hikhrati oto mi-tokh ammi*—cut off.

**The Key Verses (14:9-11):**
"'When the prophet is deceived and speaks a word, I YHWH have deceived that prophet.'"

*Ve-ha-navi ki-yefutteh ve-dibber davar ani YHWH pittiti et ha-navi ha-hu*—YHWH deceived.

"'I will stretch out my hand upon him.'"

*Ve-natiti et-yadi alav*—hand upon.

"'Will destroy him from the midst of my people Israel.'"

*Ve-hishmattivu mi-tokh ammi Yisra'el*—destroy.

"'They shall bear their iniquity.'"

*Ve-nas'u avonam*—bear iniquity.

"'The iniquity of the prophet shall be even as the iniquity of him that inquires.'"

*Ka-avon ha-doresh ka-avon ha-navi yihyeh*—equal guilt.

"'That the house of Israel may go no more astray from me.'"

*Lema'an lo-yit'u od beit-Yisra'el me-acharai*—no more astray.

"'They may be my people, and I may be their God.'"

*Ve-hayu li le-am va-ani ehyeh lahem l'Elohim*—covenant formula.

**YHWH Deceives:**
When prophets respond to idolaters, YHWH allows deceptive answers as judgment.

**Noah, Daniel, and Job (14:12-23):**
**The Key Verse (14:13):**
"'When a land sins against me by trespassing grievously.'"

*Eretz ki-techeta-li lim'ol ma'al*—land sins.

"'I stretch out my hand upon it.'"

*Ve-natiti yadi alekha*—hand upon.

"'Break the staff of the bread thereof.'"

*Ve-shavarti lah matteh-lachem*—break bread-staff.

"'Send famine upon it.'"

*Ve-shilachti-vah ra'av*—send famine.

"'Cut off from it man and beast.'"

*Ve-hikhraatti mimmennah adam u-vehemah*—cut off.

**The Key Verse (14:14):**
"'Though these three men, Noah, Daniel, and Job, were in it.'"

*Ve-hayu sheloshet ha-anashim ha-elleh be-tokhah Noach Dani'el ve-Iyyov*—three men.

"'They should deliver but their own souls by their righteousness.'"

*Hemmah be-tzidqatam yenatztzelu nafsham*—only themselves.

**Three Righteous:**
Noah (saved from flood), Daniel (Ezekiel's contemporary or ancient Dan'el), Job (saved from affliction)—all proverbially righteous.

**Four Judgments (14:15-21):**
**The Key Verses (14:15-16) — Evil Beasts:**
"'If I cause evil beasts to pass through the land.'"

*Lu-chayyah ra'ah a'avir ba-aretz*—evil beasts.

"'They bereave it, and it be desolate.'"

*Ve-shikkelatah ve-hayetah shemamah*—bereaved, desolate.

"'They shall deliver neither sons nor daughters.'"

*Im-banim ve-im-banot lo yatztzilu*—not deliver children.

"'They only shall be delivered.'"

*Hemmah levaddam yinnatzzelu*—only themselves.

**The Key Verses (14:17-18) — Sword:**
"'Or if I bring a sword upon that land.'"

*O cherev avi al-ha-aretz ha-hi*—bring sword.

"'Let the sword go through the land.'"

*Cherev ta'avor ba-aretz*—sword passes.

"'Cut off from it man and beast.'"

*Ve-hikhraatti mimmennah adam u-vehemah*—cut off.

"'They shall deliver neither sons nor daughters.'"

*Banim u-vanot lo yatztzilu*—not deliver children.

**The Key Verses (14:19-20) — Pestilence:**
"'Or if I send a pestilence into that land.'"

*O dever ashalach el-ha-aretz ha-hi*—send pestilence.

"'Pour out my fury upon it in blood.'"

*Ve-shafakhti chamati alekha be-dam*—fury in blood.

"'Though Noah, Daniel, and Job, were in it.'"

*Noach Dani'el ve-Iyyov be-tokhah*—three.

"'They shall deliver neither son nor daughter.'"

*Im-ben im-bat yatztzilu*—not deliver.

"'They shall but deliver their own souls by their righteousness.'"

*Hemmah be-tzidqatam yatztzilu nafsham*—only themselves.

**The Key Verse (14:21):**
"'How much more when I send my four sore judgments upon Jerusalem.'"

*Af ki arba'at shefatai ha-ra'im... shilachti el-Yerushalayim*—four judgments.

"'The sword, and the famine, and the evil beasts, and the pestilence.'"

*Cherev ve-ra'av ve-chayyah ra'ah va-daver*—sword, famine, beasts, pestilence.

"'To cut off from it man and beast.'"

*Le-hakhrit mimmennah adam u-vehemah*—cut off.

**Four Judgments:**
Sword, famine, wild beasts, pestilence—Leviticus 26 covenant curses.

**The Key Verses (14:22-23):**
"'There be left a remnant therein that shall be brought forth.'"

*Ve-hinneh notrah-bah peletah ha-mutz'im*—remnant.

"'Both sons and daughters.'"

*Banim u-vanot*—sons and daughters.

"'When they come forth unto you, and you see their way and their doings.'"

*Hinneh-hem yotz'im aleikhem u-re'item et-darkam ve-et-alilotam*—see their ways.

"'You shall be comforted concerning the evil that I have brought upon Jerusalem.'"

*Ve-nichamtem al-ha-ra'ah asher-heveti al-Yerushalayim*—comforted.

"'You shall know that I have not done without cause all that I have done in it.'"

*Vi-ydatem ki lo le-chinnam asiti et kol-asher asiti bah*—not without cause.

**Survivors' Testimony:**
The survivors' wickedness will prove Jerusalem's judgment was just.

**Archetypal Layer:** Ezekiel 14 contains **"these men have set up their idols in their heart" (14:3)**, **"I YHWH will answer him... according to the multitude of his idols" (14:4)**, **"I YHWH have deceived that prophet" (14:9)**, **"Though these three men, Noah, Daniel, and Job, were in it, they should deliver but their own souls" (14:14, 20)**, and **"my four sore judgments... sword, famine, evil beasts, pestilence" (14:21)**.

**Ethical Inversion Applied:**
- "Certain of the elders of Israel... sat before me"—elders came
- "'These men have set up their idols in their heart'"—heart idols
- "'Put the stumbling-block of their iniquity before their face'"—stumbling-block
- "'Should I be inquired of at all by them?'"—should I answer?
- "'I YHWH will answer him... according to the multitude of his idols'"—answer by idols
- "'That I may take the house of Israel in their own heart'"—catch in heart
- "'Return, and turn yourselves from your idols'"—call to return
- "'Turn away your faces from all your abominations'"—turn from abominations
- "'I YHWH will answer him by myself'"—YHWH answers
- "'I will set my face against that man'"—face against
- "'Will make him a sign and a proverb'"—sign, proverb
- "'When the prophet is deceived... I YHWH have deceived that prophet'"—YHWH deceives
- "'They shall bear their iniquity'"—bear iniquity
- "'The iniquity of the prophet shall be even as the iniquity of him that inquires'"—equal guilt
- "'They may be my people, and I may be their God'"—covenant formula
- "'When a land sins against me'"—land sins
- "'I stretch out my hand upon it'"—hand upon
- "'Break the staff of the bread thereof, and send famine'"—famine
- "'Though these three men, Noah, Daniel, and Job, were in it'"—three righteous
- "'They should deliver but their own souls by their righteousness'"—only themselves
- "'If I cause evil beasts to pass through'"—evil beasts
- "'They shall deliver neither sons nor daughters'"—not deliver children
- "'Or if I bring a sword upon that land'"—sword
- "'Or if I send a pestilence'"—pestilence
- "'My four sore judgments... sword, famine, evil beasts, pestilence'"—four judgments
- "'There be left a remnant therein'"—remnant
- "'You shall be comforted concerning the evil'"—comforted
- "'You shall know that I have not done without cause'"—not without cause

**Modern Equivalent:** Ezekiel 14 addresses heart idolatry (14:3)—external worship is worthless with internal devotion to idols. Even Noah, Daniel, and Job couldn't save others by their righteousness (14:14)—individual responsibility. The remnant's survival proves God's justice, not mercy (14:22-23).

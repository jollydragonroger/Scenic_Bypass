# Ezekiel 27: The Lament Over Tyre — The Great Ship

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## Tyre the Beautiful Ship (27:1-11)

**27:1** And the word of YHWH came unto me, saying:

**27:2** "And you, son of man, take up a lamentation for Tyre;

**27:3** "And say unto Tyre, that dwells at the entry of the sea, that is the merchant of the peoples unto many isles: Thus says the Lord YHWH: You, O Tyre, have said: 'I am of perfect beauty.'

**27:4** "Your borders are in the heart of the seas; your builders have perfected your beauty.

**27:5** "Of cypress-trees from Senir have they made all your planks; they have taken cedars from Lebanon to make a mast for you.

**27:6** "Of the oaks of Bashan have they made your oars; your deck have they made of ivory inlaid in boxwood, from the isles of Kittim.

**27:7** "Of fine linen with richly woven work from Egypt was your sail, that it might be to you for an ensign; blue and purple from the isles of Elishah was your awning.

**27:8** "The inhabitants of Sidon and Arvad were your rowers; your wise men, O Tyre, were in you, they were your pilots.

**27:9** "The elders of Gebal and the wise men thereof were in you your caulkers; all the ships of the sea with their mariners were in you to exchange your merchandise.

**27:10** "Persia and Lud and Put were in your army, your men of war; they hanged the shield and helmet in you; they set forth your comeliness.

**27:11** "The men of Arvad and your army were upon your walls round about, and the Gammadim were in your towers; they hanged their shields upon your walls round about; they have perfected your beauty."

---

## Tyre's Trade Partners (27:12-25)

**27:12** "Tarshish was your merchant by reason of the multitude of all kinds of riches; with silver, iron, tin, and lead, they traded for your wares.

**27:13** "Javan, Tubal, and Meshech, they were your traffickers; they traded the persons of men and vessels of brass for your merchandise.

**27:14** "They of the house of Togarmah traded for your wares with horses and horsemen and mules.

**27:15** "The men of Dedan were your traffickers; many isles were the mart of your hand; they brought you in exchange horns of ivory and ebony.

**27:16** "Aram was your merchant by reason of the multitude of your works; they traded for your wares with carbuncles, purple, and richly woven work, and fine linen, and coral, and rubies.

**27:17** "Judah, and the land of Israel, they were your traffickers; they traded for your merchandise wheat of Minnith, and pannag, and honey, and oil, and balm.

**27:18** "Damascus was your merchant by reason of the multitude of your works, by reason of the multitude of all riches, with the wine of Helbon, and white wool.

**27:19** "Vedan and Javan traded with yarn for your wares; bright iron, cassia, and calamus, were among your merchandise.

**27:20** "Dedan was your trafficker in precious cloths for riding.

**27:21** "Arabia, and all the princes of Kedar, they were the merchants of your hand; in lambs, and rams, and goats, in these were they your merchants.

**27:22** "The traffickers of Sheba and Raamah, they were your traffickers; they traded for your wares with chief of all spices, and with all precious stones, and gold.

**27:23** "Haran and Canneh and Eden, the traffickers of Sheba, Asshur, and Chilmad, were your traffickers.

**27:24** "These were your traffickers in choice wares, in wrappings of blue and richly woven work, and in chests of rich apparel, bound with cords and cedar-lined, among your merchandise.

**27:25** "The ships of Tarshish were your caravans for your merchandise; so were you replenished, and made very heavy in the heart of the seas."

---

## The Shipwreck (27:26-36)

**27:26** "Your rowers have brought you into great waters; the east wind has broken you in the heart of the seas.

**27:27** "Your riches, and your wares, your merchandise, your mariners, and your pilots, your caulkers, and the exchangers of your merchandise, and all your men of war, that are in you, with all your company which is in the midst of you, shall fall into the heart of the seas in the day of your ruin.

**27:28** "At the sound of the cry of your pilots the waves shall shake.

**27:29** "And all that handle the oar, the mariners, and all the pilots of the sea, shall come down from their ships, they shall stand upon the land,

**27:30** "And shall cause their voice to be heard over you, and shall cry bitterly, and shall cast up dust upon their heads, they shall wallow themselves in the ashes;

**27:31** "And they shall make themselves utterly bald for you, and gird them with sackcloth, and they shall weep for you in bitterness of soul with bitter lamentation.

**27:32** "And in their wailing they shall take up a lamentation for you, and lament over you: 'Who is there like Tyre, like her that is brought to silence in the midst of the sea?'

**27:33** "'When your wares came forth out of the seas, you filled many peoples; you did enrich the kings of the earth with the multitude of your riches and of your merchandise.'

**27:34** "'Now that you are broken by the seas in the depths of the waters, your merchandise and all your company are fallen in the midst of you.'

**27:35** "All the inhabitants of the isles are appalled at you, and their kings are horribly afraid, they are troubled in their countenance.

**27:36** "The merchants among the peoples hiss at you; you are become a terror, and you shall never be any more."

---

## Synthesis Notes

**Key Restorations:**

**Tyre the Beautiful Ship (27:1-11):**
**The Key Verse (27:2):**
"'Take up a lamentation for Tyre.'"

*Sa alekha qinah al-Tzor*—lament for Tyre.

**The Key Verse (27:3):**
"'Tyre, that dwells at the entry of the sea.'"

*Tzor ha-yoshevet al-mevo'ot yam*—at sea's entry.

"'The merchant of the peoples unto many isles.'"

*Rokhelet ha-ammim el-iyyim rabbim*—merchant to isles.

"'You, O Tyre, have said: I am of perfect beauty.'"

*At amaret ani kelilat yofi*—perfect beauty.

**The Key Verses (27:4-7):**
"'Your borders are in the heart of the seas.'"

*Be-lev yammim gevulayikh*—in sea's heart.

"'Your builders have perfected your beauty.'"

*Bonayikh kalelu yofyekh*—perfected beauty.

"'Of cypress-trees from Senir have they made all your planks.'"

*Beroshim mi-Senir banu lakh et kol-luchtayim*—Senir cypress.

"'They have taken cedars from Lebanon to make a mast for you.'"

*Erez mi-Levanon laqechu la'asot toren alayikh*—Lebanon cedar.

"'Of the oaks of Bashan have they made your oars.'"

*Allonim mi-Bashan asu mishotiykh*—Bashan oaks.

"'Your deck have they made of ivory inlaid in boxwood.'"

*Qarshekh asu-shen bat-ashurim*—ivory deck.

"'From the isles of Kittim.'"

*Me-iyyei Kittim*—Kittim (Cyprus).

"'Of fine linen with richly woven work from Egypt was your sail.'"

*Shesh be-riqmah mi-Mitzrayim hayah mifrasekh*—Egyptian linen sail.

"'Blue and purple from the isles of Elishah was your awning.'"

*Tekhelet ve-argaman me-iyyei Elishah hayah mekhassekh*—Elishah purple.

**Ship Metaphor:**
Tyre as a magnificent merchant vessel.

**The Key Verses (27:8-11):**
"'The inhabitants of Sidon and Arvad were your rowers.'"

*Yoshevei Tzidon ve-Arvad hayu shatim lakh*—Sidon, Arvad rowers.

"'Your wise men, O Tyre, were in you, they were your pilots.'"

*Chakhamayikh Tzor hayu vakh hemmah chovlayikh*—pilots.

"'The elders of Gebal and the wise men thereof were... your caulkers.'"

*Ziqnei Geval va-chakhameyha hayu vakh machaziקei bedקekh*—Gebal caulkers.

"'All the ships of the sea with their mariners were in you to exchange your merchandise.'"

*Kol-oniyyot ha-yam u-mallacheihem hayu vakh la'arov ma'aravekh*—all ships.

"'Persia and Lud and Put were in your army.'"

*Paras ve-Lud u-Put hayu ve-cheilekh*—mercenaries.

"'They hanged the shield and helmet in you.'"

*Magen ve-kova tilu vakh*—displayed arms.

"'The men of Arvad and your army were upon your walls.'"

*Benei Arvad ve-cheilekh al-chomotayikh*—guarded walls.

"'The Gammadim were in your towers.'"

*Ve-Gammadim be-migdalotayikh*—Gammadim.

"'They have perfected your beauty.'"

*Hemmah kalelu yofyekh*—perfected beauty.

**Trade Partners (27:12-25):**
**The Key Verse (27:12):**
"'Tarshish was your merchant.'"

*Tarshish sochartekhk*—Tarshish (Spain?).

"'With silver, iron, tin, and lead, they traded for your wares.'"

*Be-kesef barzel bedil va-oferet natenu izbonaych*—metals.

**The Key Verse (27:13):**
"'Javan, Tubal, and Meshech, they were your traffickers.'"

*Yavan Tuval u-Meshekh hemmah rokheltayikh*—Javan (Greece), Tubal, Meshech.

"'They traded the persons of men and vessels of brass.'"

*Be-nefesh adam u-khlei nechoshet natenu ma'aravekh*—slaves, bronze.

**The Key Verse (27:17):**
"'Judah, and the land of Israel, they were your traffickers.'"

*Yehudah ve-eretz Yisra'el hemmah rokheltayikh*—Judah, Israel.

"'They traded for your merchandise wheat of Minnith, and pannag.'"

*Be-chittei Minnit u-Fanag*—wheat.

"'Honey, and oil, and balm.'"

*U-devash va-shemen va-tzori*—honey, oil, balm.

**The Key Verses (27:21-22):**
"'Arabia, and all the princes of Kedar.'"

*Arav ve-khol-nesi'ei Qedar*—Arabia, Kedar.

"'In lambs, and rams, and goats.'"

*Be-kharim ve-eilim ve-attudim*—livestock.

"'The traffickers of Sheba and Raamah.'"

*Rokheltei Sheva u-Ra'mah*—Sheba, Raamah.

"'With chief of all spices, and with all precious stones, and gold.'"

*Be-rosh kol-bosem u-ve-khol-even yeqarah ve-zahav*—spices, gems, gold.

**The Key Verse (27:25):**
"'The ships of Tarshish were your caravans.'"

*Oniyyot Tarshish sharoteikh ma'aravekh*—Tarshish ships.

"'So were you replenished, and made very heavy in the heart of the seas.'"

*Va-timmale'i va-tikhbedi me'od be-lev yammim*—heavy, full.

**Shipwreck (27:26-36):**
**The Key Verse (27:26):**
"'Your rowers have brought you into great waters.'"

*Be-mayim rabbim hevi'ukh shatayikh*—great waters.

"'The east wind has broken you in the heart of the seas.'"

*Ruach ha-qadim shevarakh be-lev yammim*—east wind broke.

**East Wind = Babylon.**

**The Key Verse (27:27):**
"'Your riches, and your wares, your merchandise.'"

*Honekh ve-izbonaikh ma'aravekh*—riches, wares.

"'Your mariners, and your pilots, your caulkers.'"

*Mallachayikh ve-chovlayikh machaziקei bidqekh*—crew.

"'And the exchangers of your merchandise.'"

*Ve-orvei ma'aravekh*—traders.

"'All your men of war.'"

*Ve-khol-anshei milchamatekh*—warriors.

"'Shall fall into the heart of the seas.'"

*Yippelu be-lev yammim*—fall into sea.

"'In the day of your ruin.'"

*Be-yom mappaltekh*—day of ruin.

**The Key Verses (27:28-31):**
"'At the sound of the cry of your pilots the waves shall shake.'"

*Le-qol za'aqat chovlayikh yir'ashu migrashim*—waves shake.

"'All that handle the oar, the mariners, and all the pilots of the sea, shall come down.'"

*Ve-yaredu me-oniyyoteihem kol-tofsei mashut mallachim kol-chovlei yam*—descend.

"'They shall stand upon the land.'"

*El-ha-aretz ya'amodu*—stand on land.

"'Shall cry bitterly.'"

*Ve-hishmi'u alayikh be-qolam ve-yiz'aqu mar*—cry bitterly.

"'Shall cast up dust upon their heads.'"

*Ve-ya'alu afar al-rasheihem*—dust on heads.

"'They shall wallow themselves in the ashes.'"

*Ba-efer yitpallashu*—wallow in ashes.

"'They shall make themselves utterly bald for you.'"

*Ve-hiqrichu elayikh qorchah*—baldness.

"'Gird them with sackcloth.'"

*Ve-chagru saqqim*—sackcloth.

"'They shall weep for you in bitterness of soul.'"

*Ve-vakhu elayikh be-mar-nefesh*—weep bitterly.

"'With bitter lamentation.'"

*Misped mar*—bitter lament.

**The Key Verses (27:32-36):**
"''Who is there like Tyre, like her that is brought to silence in the midst of the sea?''"

*Mi ke-Tzor ke-dumah be-tokh ha-yam*—who like Tyre?

"''When your wares came forth out of the seas, you filled many peoples.''"

*Be-tset izbonaikh mi-yammim hisba't ammim rabbim*—filled many.

"''You did enrich the kings of the earth.''"

*Be-rov honayikh u-ma'aravekh he'eshart malkhei-aretz*—enriched kings.

"''Now that you are broken by the seas in the depths of the waters.''"

*Et nishberet mi-yammim be-ma'amaqqei-mayim*—broken.

"''Your merchandise and all your company are fallen.''"

*Ma'aravekh ve-khol-qehalekh be-tokhekh nafalu*—fallen.

"'All the inhabitants of the isles are appalled at you.'"

*Kol-yoshevei ha-iyyim shamemu alayikh*—appalled.

"'Their kings are horribly afraid.'"

*U-malkheihem sa'aru sa'ar*—afraid.

"'The merchants among the peoples hiss at you.'"

*Socharim ba-ammim sharqu alayikh*—hiss.

"'You are become a terror.'"

*Ballahot hayit*—terror.

"'You shall never be any more.'"

*Ve-einekh ad-olam*—never more.

**Archetypal Layer:** Ezekiel 27 is a **lament over Tyre as a magnificent ship**, containing **detailed construction from international materials (27:4-7)**, **multinational crew (27:8-11)**, **extensive trade partners spanning the known world (27:12-25)**, **"the east wind has broken you" (27:26)**, and **"Who is there like Tyre?" (27:32)**.

**Ethical Inversion Applied:**
- "'Take up a lamentation for Tyre'"—lament
- "'Tyre, that dwells at the entry of the sea'"—sea's entry
- "'I am of perfect beauty'"—pride
- "'Your borders are in the heart of the seas'"—sea's heart
- "'Of cypress-trees from Senir have they made all your planks'"—Senir cypress
- "'They have taken cedars from Lebanon to make a mast'"—Lebanon cedar
- "'Of the oaks of Bashan have they made your oars'"—Bashan oaks
- "'Your deck have they made of ivory'"—ivory deck
- "'Of fine linen with richly woven work from Egypt was your sail'"—Egyptian linen
- "'Blue and purple from the isles of Elishah'"—Elishah purple
- "'The inhabitants of Sidon and Arvad were your rowers'"—Sidon, Arvad
- "'Your wise men... were your pilots'"—pilots
- "'The elders of Gebal... were your caulkers'"—Gebal caulkers
- "'Persia and Lud and Put were in your army'"—mercenaries
- "'Tarshish was your merchant... with silver, iron, tin, and lead'"—Tarshish metals
- "'Javan, Tubal, and Meshech... traded the persons of men'"—slaves
- "'Judah, and the land of Israel... wheat of Minnith'"—Judah's goods
- "'Arabia... in lambs, and rams'"—Arabian livestock
- "'The traffickers of Sheba... all precious stones, and gold'"—Sheba's luxury
- "'The ships of Tarshish were your caravans'"—Tarshish ships
- "'So were you replenished, and made very heavy'"—laden ship
- "'Your rowers have brought you into great waters'"—great waters
- "'The east wind has broken you'"—east wind = Babylon
- "'Your riches... your mariners... shall fall into the heart of the seas'"—sinking
- "'At the sound of the cry of your pilots the waves shall shake'"—waves shake
- "'All that handle the oar... shall come down from their ships'"—descend
- "'Shall cry bitterly'"—mourn
- "'Cast up dust upon their heads'"—mourning gesture
- "'Who is there like Tyre?'"—rhetorical
- "'You did enrich the kings of the earth'"—enriched
- "'Now that you are broken by the seas'"—broken
- "'All the inhabitants of the isles are appalled'"—appalled
- "'The merchants... hiss at you'"—hiss
- "'You shall never be any more'"—never more

**Modern Equivalent:** Ezekiel 27 is an extraordinary trade document, listing Tyre's partners from Spain (Tarshish) to Arabia, from Greece (Javan) to Persia. The ship metaphor shows pride going before a fall—the laden vessel sinks when the east wind (Babylon) strikes. The list provides invaluable economic data about the ancient world.

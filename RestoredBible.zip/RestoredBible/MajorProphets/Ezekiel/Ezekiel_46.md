# Ezekiel 46: The Prince's Worship and Offerings

*From the Hebrew: כֹּה אָמַר אֲדֹנָי יְהוִה (Koh Amar Adonai YHWH) — Thus Says the Lord YHWH*

---

## The Sabbath and New Moon (46:1-8)

**46:1** Thus says the Lord YHWH: "The gate of the inner court that looks toward the east shall be shut the six working days; but on the sabbath day it shall be opened, and in the day of the new moon it shall be opened.

**46:2** "And the prince shall enter by the way of the porch of the gate without, and shall stand by the post of the gate, and the priests shall prepare his burnt-offering and his peace-offerings, and he shall worship at the threshold of the gate; then he shall go forth; but the gate shall not be shut until the evening.

**46:3** "Likewise the people of the land shall worship at the door of that gate before YHWH on the sabbaths and on the new moons.

**46:4** "And the burnt-offering that the prince shall offer unto YHWH shall be on the sabbath day six lambs without blemish and a ram without blemish;

**46:5** "And the meal-offering shall be an ephah for the ram, and the meal-offering for the lambs as he is able to give, and a hin of oil to an ephah.

**46:6** "And on the day of the new moon it shall be a young bullock without blemish, and six lambs, and a ram; they shall be without blemish;

**46:7** "And he shall prepare a meal-offering, an ephah for the bullock, and an ephah for the ram, and for the lambs according as his means suffice, and a hin of oil to an ephah.

**46:8** "And when the prince shall enter, he shall go in by the way of the porch of the gate, and he shall go forth by the way thereof."

---

## The People's Movement at Festivals (46:9-12)

**46:9** "But when the people of the land shall come before YHWH in the appointed seasons, he that enters by the way of the north gate to worship shall go forth by the way of the south gate; and he that enters by the way of the south gate shall go forth by the way of the north gate; he shall not return by the way of the gate whereby he came in, but shall go forth straight before him.

**46:10** "And the prince, when they go in, shall go in in the midst of them; and when they go forth, they shall go forth together.

**46:11** "And in the feasts and in the appointed seasons the meal-offering shall be an ephah for a bullock, and an ephah for a ram, and for the lambs as he is able to give, and a hin of oil to an ephah.

**46:12** "And when the prince shall prepare a freewill-offering, a burnt-offering or peace-offerings as a freewill-offering unto YHWH, one shall open for him the gate that looks toward the east, and he shall prepare his burnt-offering and his peace-offerings, as he does on the sabbath day; then he shall go forth; and after his going forth one shall shut the gate."

---

## The Daily Offering (46:13-15)

**46:13** "And you shall prepare a lamb of the first year without blemish for a burnt-offering unto YHWH daily; morning by morning shall you prepare it.

**46:14** "And you shall prepare a meal-offering with it morning by morning, the sixth part of an ephah, and the third part of a hin of oil, to moisten the fine flour: a meal-offering unto YHWH continually by a perpetual ordinance.

**46:15** "Thus shall they prepare the lamb, and the meal-offering, and the oil, morning by morning, for a continual burnt-offering."

---

## The Prince's Inheritance (46:16-18)

**46:16** Thus says the Lord YHWH: "If the prince give a gift unto any of his sons, it is his inheritance, it shall belong to his sons; it is their possession by inheritance.

**46:17** "But if he give of his inheritance a gift to one of his servants, it shall be his to the year of liberty; then it shall return to the prince; but his inheritance which he gives to his sons shall be theirs.

**46:18** "Moreover the prince shall not take of the people's inheritance, to thrust them out of their possession; he shall give inheritance to his sons out of his own possession; that my people be not scattered every man from his possession."

---

## The Temple Kitchens (46:19-24)

**46:19** Then he brought me through the entry, which was at the side of the gate, into the holy chambers for the priests, which looked toward the north; and, behold, there was a place on the hinder part westward.

**46:20** And he said unto me: "This is the place where the priests shall boil the guilt-offering and the sin-offering, where they shall bake the meal-offering; that they carry them not forth into the outer court, to sanctify the people."

**46:21** Then he brought me forth into the outer court, and caused me to pass by the four corners of the court; and, behold, in every corner of the court there was a court.

**46:22** In the four corners of the court there were courts inclosed, forty cubits long and thirty broad; these four in the corners were of one measure.

**46:23** And there was a row of masonry round about in them, round about the four, and boiling-places were made under the rows round about.

**46:24** Then said he unto me: "These are the boiling-places, where the ministers of the house shall boil the sacrifice of the people."

---

## Synthesis Notes

**Key Restorations:**

**Sabbath and New Moon (46:1-8):**
**The Key Verse (46:1):**
"'The gate of the inner court that looks toward the east shall be shut the six working days.'"

*Sha'ar he-chatzer ha-penimit ha-poneh qadim yihyeh sagur sheshet yemei ha-ma'aseh*—shut 6 days.

"'On the sabbath day it shall be opened.'"

*U-ve-yom ha-shabbat yippate'ach*—opened Sabbath.

"'In the day of the new moon it shall be opened.'"

*U-ve-yom ha-chodesh yippate'ach*—opened new moon.

**The Key Verse (46:2):**
"'The prince shall enter by the way of the porch of the gate without.'"

*U-va ha-nasi derekh ulam ha-sha'ar mi-chutz*—prince enters.

"'Shall stand by the post of the gate.'"

*Ve-amad al-mezuzat ha-sha'ar*—stand at post.

"'The priests shall prepare his burnt-offering and his peace-offerings.'"

*Ve-asu ha-kohanim et-olato ve-et-shelamav*—priests prepare.

"'He shall worship at the threshold of the gate.'"

*Ve-hishtachavah al-miftan ha-sha'ar*—worship at threshold.

"'Then he shall go forth.'"

*Ve-yatza*—go forth.

"'The gate shall not be shut until the evening.'"

*Ve-ha-sha'ar lo-yissager ad-ha-erev*—open till evening.

**The Key Verses (46:3-5):**
"'Likewise the people of the land shall worship at the door of that gate.'"

*Ve-hishtachavu am-ha-aretz petach ha-sha'ar ha-hu*—people worship.

"'Before YHWH on the sabbaths and on the new moons.'"

*Lifnei YHWH ba-shabbatot u-va-chodashim*—sabbaths, new moons.

"'The burnt-offering... on the sabbath day six lambs without blemish and a ram.'"

*Ve-ha-olah... be-yom ha-shabbat shishah kevasim temimim ve-ayil tamim*—6 lambs, 1 ram.

"'The meal-offering shall be an ephah for the ram.'"

*Ve-ha-minchah eifah la-ayil*—ephah for ram.

"'The meal-offering for the lambs as he is able to give.'"

*Ve-la-kevasim minchah mattat yado*—as able.

"'A hin of oil to an ephah.'"

*Ve-shemen hin la-eifah*—hin of oil.

**The Key Verses (46:6-8):**
"'On the day of the new moon... a young bullock without blemish.'"

*U-ve-yom ha-chodesh par ben-baqar tamim*—bullock.

"'Six lambs, and a ram.'"

*Ve-shishah kevasim ve-ayil*—lambs, ram.

"'When the prince shall enter, he shall go in by the way of the porch.'"

*U-ve-vo ha-nasi derekh ulam ha-sha'ar yavo*—via porch.

"'He shall go forth by the way thereof.'"

*U-ve-darko yetze*—same way out.

**People's Movement (46:9-12):**
**The Key Verse (46:9):**
"'When the people of the land shall come before YHWH in the appointed seasons.'"

*U-ve-vo am-ha-aretz lifnei YHWH ba-mo'adim*—at festivals.

"'He that enters by the way of the north gate... shall go forth by the way of the south gate.'"

*Ha-ba derekh-sha'ar tzafon le-hishtachavot yetze derekh-sha'ar negev*—north to south.

"'He that enters by the way of the south gate shall go forth by the way of the north gate.'"

*Ve-ha-ba derekh-sha'ar negev yetze derekh-sha'ar tzafonah*—south to north.

"'He shall not return by the way of the gate whereby he came in.'"

*Lo yashuv derekh ha-sha'ar asher-ba vo*—no return.

"'Shall go forth straight before him.'"

*Ki nikhcho yetze*—straight through.

**The Key Verses (46:10-12):**
"'The prince, when they go in, shall go in in the midst of them.'"

*Ve-ha-nasi be-tokham be-vo'am yavo*—prince among people.

"'When they go forth, they shall go forth together.'"

*U-ve-tzeitam yetze'u*—go out together.

"'In the feasts and in the appointed seasons the meal-offering shall be an ephah for a bullock.'"

*U-va-chaggim u-va-mo'adim tihyeh ha-minchah eifah la-par*—festival offerings.

"'When the prince shall prepare a freewill-offering.'"

*Ve-khi-ya'aseh ha-nasi nedavah*—freewill offering.

"'A burnt-offering or peace-offerings as a freewill-offering unto YHWH.'"

*Olah o shelamim nedavah la-YHWH*—freewill.

"'One shall open for him the gate that looks toward the east.'"

*U-fatach lo et-ha-sha'ar ha-poneh qadim*—open east gate.

"'He shall prepare his burnt-offering and his peace-offerings, as he does on the sabbath day.'"

*Ve-asah et-olato ve-et-shelamav ka-asher ya'aseh be-yom ha-shabbat*—like Sabbath.

"'After his going forth one shall shut the gate.'"

*Ve-sagar et-ha-sha'ar acharei tzeto*—shut after.

**Daily Offering (46:13-15):**
"'You shall prepare a lamb of the first year without blemish for a burnt-offering unto YHWH daily.'"

*Ve-kheves ben-shanato tamim ta'aseh olah la-YHWH la-yom*—daily lamb.

"'Morning by morning shall you prepare it.'"

*Ba-boqer ba-boqer ta'aseh oto*—every morning.

"'You shall prepare a meal-offering with it morning by morning.'"

*U-minchah ta'aseh alav ba-boqer ba-boqer*—daily meal offering.

"'The sixth part of an ephah.'"

*Shishshit ha-eifah*—1/6 ephah.

"'The third part of a hin of oil.'"

*Ve-shemen shelishit ha-hin*—1/3 hin.

"'To moisten the fine flour.'"

*Laros et-ha-solet*—moisten flour.

"'A meal-offering unto YHWH continually by a perpetual ordinance.'"

*Minchah la-YHWH tamid chuqqat olam*—perpetual ordinance.

"'Thus shall they prepare the lamb, and the meal-offering, and the oil, morning by morning.'"

*Ve-asu et-ha-keves ve-et-ha-minchah ve-et-ha-shemen ba-boqer ba-boqer*—daily.

"'For a continual burnt-offering.'"

*Olat tamid*—continual offering.

**Prince's Inheritance (46:16-18):**
"'If the prince give a gift unto any of his sons, it is his inheritance.'"

*Ki-yitten ha-nasi mattanah le-ish mi-banav nachalato hi*—to sons.

"'It shall belong to his sons; it is their possession by inheritance.'"

*Li-vanav tihyeh achuzzatam hi be-nachalah*—sons' possession.

"'If he give of his inheritance a gift to one of his servants.'"

*Ve-khi-yitten mattanah mi-nachalato le-achad me-avadav*—to servant.

"'It shall be his to the year of liberty.'"

*Ve-hayetah lo ad-shnat ha-deror*—until Jubilee.

"'Then it shall return to the prince.'"

*Ve-shavah la-nasi*—returns.

"'His inheritance which he gives to his sons shall be theirs.'"

*Akh nachalato banav lahem tihyeh*—sons keep.

**The Key Verse (46:18):**
"'The prince shall not take of the people's inheritance.'"

*Ve-lo-yiqqach ha-nasi mi-nachalat ha-am*—not take.

"'To thrust them out of their possession.'"

*Le-honotam me-achuzzatam*—not dispossess.

"'He shall give inheritance to his sons out of his own possession.'"

*Me-achuzzato yanchil et-banav*—from own.

"'That my people be not scattered every man from his possession.'"

*Lema'an asher lo-yafutzu ammi ish me-achuzzato*—not scattered.

**Temple Kitchens (46:19-24):**
"He brought me through the entry... into the holy chambers for the priests."

*Va-yevi'eni... el-lishkhot ha-qodesh el-ha-kohanim*—priests' chambers.

"'This is the place where the priests shall boil the guilt-offering and the sin-offering.'"

*Zeh ha-maqom asher yevasshelu-sham ha-kohanim et-ha-asham ve-et-ha-chattat*—boil offerings.

"'Where they shall bake the meal-offering.'"

*Asher yofu et-ha-minchah*—bake meal offering.

"'That they carry them not forth into the outer court, to sanctify the people.'"

*Le-vilti hotzi el-he-chatzer ha-chitzonah le-qaddesh et-ha-am*—not transfer holiness.

"He brought me forth into the outer court, and caused me to pass by the four corners."

*Va-yotzi'eni el-he-chatzer ha-chitzonah va-ya'avireni el-arba miqtzo'ot he-chatzer*—four corners.

"In every corner of the court there was a court."

*Ve-hinneh chatzer be-miqtzo'a he-chatzer chatzer*—corner courts.

"Courts inclosed, forty cubits long and thirty broad."

*Chatzerot qeturot arba'im orekh u-sheloshim rochav*—40 x 30.

"'These are the boiling-places, where the ministers of the house shall boil the sacrifice of the people.'"

*Elleh beit ha-mevasshelim asher yevasshelu-sham mesharetei ha-bayit et-zevach ha-am*—boiling places.

**Archetypal Layer:** Ezekiel 46 details **temple worship**, containing **inner east gate opened on Sabbaths and new moons (46:1)**, **prince worships at the threshold (46:2)**, **Sabbath offerings: 6 lambs and 1 ram (46:4)**, **new moon offerings: 1 bullock, 6 lambs, 1 ram (46:6)**, **one-way traffic flow at festivals (46:9)**, **prince enters among the people (46:10)**, **daily morning offering: 1 lamb (46:13-15)**, **"the prince shall not take of the people's inheritance" (46:18)**, and **temple kitchens for boiling sacrifices (46:19-24)**.

**Ethical Inversion Applied:**
- "'The gate... shall be shut the six working days'"—shut 6 days
- "'On the sabbath day it shall be opened'"—opened Sabbath
- "'In the day of the new moon it shall be opened'"—opened new moon
- "'The prince shall enter by the way of the porch'"—via porch
- "'Shall stand by the post of the gate'"—at post
- "'The priests shall prepare his burnt-offering'"—priests prepare
- "'He shall worship at the threshold'"—worship at threshold
- "'The gate shall not be shut until the evening'"—open till evening
- "'The people of the land shall worship at the door'"—people worship
- "'On the sabbath day six lambs... and a ram'"—Sabbath offerings
- "'On the day of the new moon... a young bullock'"—new moon offerings
- "'When the prince shall enter, he shall go in by the way of the porch'"—via porch
- "'He that enters by the way of the north gate... shall go forth by the way of the south'"—one-way
- "'He shall not return by the way of the gate whereby he came'"—no return
- "'The prince... shall go in in the midst of them'"—prince among people
- "'When the prince shall prepare a freewill-offering'"—freewill
- "'One shall open for him the gate'"—open gate
- "'After his going forth one shall shut the gate'"—shut after
- "'You shall prepare a lamb... daily'"—daily lamb
- "'Morning by morning'"—every morning
- "'A meal-offering unto YHWH continually'"—continual
- "'If the prince give a gift unto any of his sons'"—to sons
- "'It shall be his to the year of liberty'"—Jubilee
- "'Then it shall return to the prince'"—returns
- "'The prince shall not take of the people's inheritance'"—not take
- "'To thrust them out of their possession'"—not dispossess
- "'He shall give inheritance to his sons out of his own possession'"—from own
- "'That my people be not scattered'"—not scattered
- "'This is the place where the priests shall boil'"—boil offerings
- "'That they carry them not forth... to sanctify the people'"—prevent transfer
- "'These are the boiling-places'"—kitchens

**Modern Equivalent:** Ezekiel 46 details temple worship logistics. The prince, while prominent, is limited—he may not enter the inner court, only worship at the threshold. One-way traffic at festivals prevents crowding. The prince must not confiscate land (46:18)—preventing royal abuses. Temple kitchens prevent accidental holiness transfer to worshippers.

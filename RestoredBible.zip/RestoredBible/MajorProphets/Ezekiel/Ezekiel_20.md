# Ezekiel 20: Israel's History of Rebellion

*From the Hebrew: וַיְהִי בַּשָּׁנָה הַשְּׁבִיעִית (Va-Yehi Ba-Shanah Ha-Shevi'it) — And It Came to Pass in the Seventh Year*

---

## The Elders' Inquiry Refused (20:1-4)

**20:1** And it came to pass in the seventh year, in the fifth month, the tenth day of the month, that certain of the elders of Israel came to inquire of YHWH, and sat before me.

**20:2** And the word of YHWH came unto me, saying:

**20:3** "Son of man, speak unto the elders of Israel, and say unto them: Thus says the Lord YHWH: Are you come to inquire of me? As I live," says the Lord YHWH, "I will not be inquired of by you."

**20:4** "Will you judge them, will you judge them, son of man? Cause them to know the abominations of their fathers."

---

## Rebellion in Egypt (20:5-9)

**20:5** "And say unto them: Thus says the Lord YHWH: In the day when I chose Israel, and lifted up my hand unto the seed of the house of Jacob, and made myself known unto them in the land of Egypt, when I lifted up my hand unto them, saying: I am YHWH your God;

**20:6** "In that day I lifted up my hand unto them, to bring them forth out of the land of Egypt into a land that I had sought out for them, flowing with milk and honey, which is the glory of all lands;

**20:7** "And I said unto them: Cast away every man the detestable things of his eyes, and defile not yourselves with the idols of Egypt; I am YHWH your God.

**20:8** "But they rebelled against me, and would not hearken unto me; they did not every man cast away the detestable things of their eyes, neither did they forsake the idols of Egypt; then I said I would pour out my fury upon them, to spend my anger upon them in the midst of the land of Egypt.

**20:9** "But I wrought for my name's sake, that it should not be profaned in the sight of the nations, among whom they were, in whose sight I made myself known unto them, so as to bring them forth out of the land of Egypt."

---

## Rebellion in the Wilderness — First Generation (20:10-17)

**20:10** "So I caused them to go forth out of the land of Egypt, and brought them into the wilderness.

**20:11** "And I gave them my statutes, and taught them my ordinances, which if a man do, he shall live by them.

**20:12** "Moreover also I gave them my sabbaths, to be a sign between me and them, that they might know that I am YHWH that sanctify them.

**20:13** "But the house of Israel rebelled against me in the wilderness; they walked not in my statutes, and they rejected my ordinances, which if a man do, he shall live by them; and my sabbaths they greatly profaned; then I said I would pour out my fury upon them in the wilderness, to consume them.

**20:14** "But I wrought for my name's sake, that it should not be profaned in the sight of the nations, in whose sight I brought them out.

**20:15** "Yet also I lifted up my hand unto them in the wilderness, that I would not bring them into the land which I had given them, flowing with milk and honey, which is the glory of all lands;

**20:16** "Because they rejected my ordinances, and walked not in my statutes, and profaned my sabbaths—for their heart went after their idols.

**20:17** "Nevertheless my eye spared them from destroying them, neither did I make a full end of them in the wilderness."

---

## Rebellion in the Wilderness — Second Generation (20:18-26)

**20:18** "And I said unto their children in the wilderness: Walk not in the statutes of your fathers, neither observe their ordinances, nor defile yourselves with their idols.

**20:19** "I am YHWH your God; walk in my statutes, and keep my ordinances, and do them;

**20:20** "And hallow my sabbaths, and they shall be a sign between me and you, that you may know that I am YHWH your God.

**20:21** "But the children rebelled against me; they walked not in my statutes, neither kept my ordinances to do them, which if a man do, he shall live by them; they profaned my sabbaths; then I said I would pour out my fury upon them, to spend my anger upon them in the wilderness.

**20:22** "Nevertheless I withdrew my hand, and wrought for my name's sake, that it should not be profaned in the sight of the nations, in whose sight I had brought them forth.

**20:23** "I lifted up my hand unto them also in the wilderness, that I would scatter them among the nations, and disperse them through the countries;

**20:24** "Because they had not executed my ordinances, but had rejected my statutes, and had profaned my sabbaths, and their eyes were after their fathers' idols.

**20:25** "Wherefore I gave them also statutes that were not good, and ordinances whereby they should not live;

**20:26** "And I polluted them in their own gifts, in that they set apart all that opens the womb, that I might make them desolate, to the end that they might know that I am YHWH."

---

## Rebellion in the Land (20:27-32)

**20:27** "Therefore, son of man, speak unto the house of Israel, and say unto them: Thus says the Lord YHWH: Yet in this your fathers have blasphemed me, in that they dealt treacherously with me.

**20:28** "For when I had brought them into the land, which I lifted up my hand to give unto them, then they saw every high hill, and every thick tree, and they offered there their sacrifices, and there they presented the provocation of their offering, there also they made their sweet savor, and there they poured out their drink-offerings.

**20:29** "Then I said unto them: What is the high place whereunto you go? So the name thereof is called Bamah unto this day.

**20:30** "Wherefore say unto the house of Israel: Thus says the Lord YHWH: Do you pollute yourselves after the manner of your fathers? And do you go astray after their detestable things?

**20:31** "And when you offer your gifts, when you make your sons to pass through the fire, you pollute yourselves with all your idols, unto this day; and shall I be inquired of by you, O house of Israel? As I live," says the Lord YHWH, "I will not be inquired of by you.

**20:32** "And that which comes into your mind shall not be at all; in that you say: 'We will be as the nations, as the families of the countries, to serve wood and stone.'"

---

## Future Restoration (20:33-44)

**20:33** "As I live," says the Lord YHWH, "surely with a mighty hand, and with an outstretched arm, and with fury poured out, will I be king over you.

**20:34** "And I will bring you out from the peoples, and will gather you out of the countries wherein you are scattered, with a mighty hand, and with an outstretched arm, and with fury poured out;

**20:35** "And I will bring you into the wilderness of the peoples, and there will I plead with you face to face.

**20:36** "Like as I pleaded with your fathers in the wilderness of the land of Egypt, so will I plead with you," says the Lord YHWH.

**20:37** "And I will cause you to pass under the rod, and I will bring you into the bond of the covenant;

**20:38** "And I will purge out from among you the rebels, and them that transgress against me; I will bring them forth out of the land where they sojourn, but they shall not enter into the land of Israel; and you shall know that I am YHWH.

**20:39** "As for you, O house of Israel," thus says the Lord YHWH: "Go, serve every one his idols, and hereafter also, if you will not hearken unto me; but my holy name shall you no more profane with your gifts, and with your idols.

**20:40** "For in my holy mountain, in the mountain of the height of Israel," says the Lord YHWH, "there shall all the house of Israel, all of them, serve me in the land; there will I accept them, and there will I require your heave-offerings, and the first of your gifts, with all your holy things.

**20:41** "With your sweet savor will I accept you, when I bring you out from the peoples, and gather you out of the countries wherein you have been scattered; and I will be sanctified in you in the sight of the nations.

**20:42** "And you shall know that I am YHWH, when I shall bring you into the land of Israel, into the country which I lifted up my hand to give unto your fathers.

**20:43** "And there shall you remember your ways, and all your doings, wherein you have polluted yourselves; and you shall loathe yourselves in your own sight for all your evils that you have committed.

**20:44** "And you shall know that I am YHWH, when I have wrought with you for my name's sake, not according to your evil ways, nor according to your corrupt doings, O house of Israel," says the Lord YHWH.

---

## Oracle Against the South (20:45-49)

**20:45** And the word of YHWH came unto me, saying:

**20:46** "Son of man, set your face toward the south, and preach toward the south, and prophesy against the forest of the field in the South;

**20:47** "And say to the forest of the South: Hear the word of YHWH: Thus says the Lord YHWH: Behold, I will kindle a fire in you, and it shall devour every green tree in you, and every dry tree; the flaming flame shall not be quenched, and all faces from the south to the north shall be burned thereby.

**20:48** "And all flesh shall see that I YHWH have kindled it; it shall not be quenched."

**20:49** Then said I: "Ah Lord YHWH! They say of me: 'Is he not a maker of parables?'"

---

## Synthesis Notes

**Key Restorations:**

**Elders' Inquiry Refused (20:1-4):**
"In the seventh year, in the fifth month, the tenth day."

*Ba-shanah ha-shevi'it ba-chamishi be-asor la-chodesh*—August 591 BCE.

"'Are you come to inquire of me?'"

*Ha-lidrosh oti attem ba'im*—to inquire?

"''As I live,' says the Lord YHWH, 'I will not be inquired of by you.''"

*Chai-ani ne'um Adonai YHWH im-iddaresh lakhem*—not be inquired.

"'Cause them to know the abominations of their fathers.'"

*To'avot avotam hodi'em*—fathers' abominations.

**Rebellion in Egypt (20:5-9):**
"'In the day when I chose Israel.'"

*Be-yom bachori be-Yisra'el*—chose Israel.

"'Lifted up my hand unto the seed of the house of Jacob.'"

*Va-essa yadi le-zera beit Ya'aqov*—swore.

"'Made myself known unto them in the land of Egypt.'"

*Va-ivvade'a lahem be-eretz Mitzrayim*—made known.

"'I am YHWH your God.'"

*Ani YHWH Eloheikhem*—I am YHWH.

"'Cast away every man the detestable things of his eyes.'"

*Ish shiqqutzzei einav hashlikhu*—cast away idols.

"'Defile not yourselves with the idols of Egypt.'"

*U-ve-gillulei Mitzrayim al-tittamma'u*—don't defile.

"'But they rebelled against me.'"

*Va-yamru-vi*—rebelled.

"'I wrought for my name's sake.'"

*Va-a'as lema'an shemi*—for name's sake.

**First Wilderness Generation (20:10-17):**
"'I gave them my statutes... ordinances, which if a man do, he shall live by them.'"

*Va-etten lahem et-chuqqotai... mishpatai asher ya'aseh otam ha-adam va-chai bahem*—live by them.

"'I gave them my sabbaths, to be a sign between me and them.'"

*Ve-gam et-shabbtotai natatti lahem li-heyot le-ot beini u-veineihem*—sign.

"'They rejected my ordinances... my sabbaths they greatly profaned.'"

*Ve-et-mishpatai ma'asu... ve-et-shabbtotai chillelu me'od*—profaned.

"'I wrought for my name's sake.'"

*Va-a'as lema'an shemi*—for name's sake.

"'My eye spared them from destroying them.'"

*Va-tachas eini aleihem mi-shachatam*—spared.

**Second Wilderness Generation (20:18-26):**
"'Walk not in the statutes of your fathers.'"

*Be-chuqqei avoteikhem al-telekhu*—don't walk.

"'Hallow my sabbaths.'"

*Ve-et-shabbtotai qaddeshu*—hallow sabbaths.

"'But the children rebelled against me.'"

*Va-yamru-vi ha-banim*—children rebelled.

**The Key Verse (20:25):**
"'I gave them also statutes that were not good.'"

*Ve-gam-ani natatti lahem chuqqim lo tovim*—not good statutes.

"'Ordinances whereby they should not live.'"

*U-mishpatim lo yichyu bahem*—wouldn't live by.

**The Key Verse (20:26):**
"'I polluted them in their own gifts, in that they set apart all that opens the womb.'"

*Va-atamme otam be-mattnotam be-ha'avir kol-peter rachem*—child sacrifice.

"'That I might make them desolate.'"

*Lema'an asshimmem*—make desolate.

**Difficult Passage:**
YHWH allowed Israel to follow distorted practices (child sacrifice) as judgment.

**Rebellion in the Land (20:27-32):**
"'They saw every high hill, and every thick tree.'"

*Va-yir'u kol-giv'ah ramah ve-khol-etz avot*—high hills, trees.

"'They offered there their sacrifices.'"

*Va-yizbechu-sham et-zivcheihem*—sacrificed.

"'What is the high place whereunto you go? So the name thereof is called Bamah.'"

*Mah ha-bamah asher-attem ha-ba'im sham va-yiqqare shemah Bamah*—called Bamah.

**Bamah Wordplay:**
"What (*mah*)... go (*ba'im*)" = *Bamah* (high place).

"'When you make your sons to pass through the fire.'"

*Be-ha'avir beneikhem ba-esh*—child sacrifice.

"'We will be as the nations.'"

*Nihyeh ka-goyim*—like nations.

**Future Restoration (20:33-44):**
"'With a mighty hand, and with an outstretched arm, and with fury poured out, will I be king over you.'"

*Be-yad chazaqah u-vi-zero'a netuyah u-ve-chemah shefukhah emlokh aleikhem*—king with fury.

"'I will bring you into the wilderness of the peoples.'"

*Ve-heveti etkhem el-midbar ha-ammim*—wilderness of peoples.

"'There will I plead with you face to face.'"

*Ve-nishpattti ittكhem sham panim el-panim*—face to face.

"'I will cause you to pass under the rod.'"

*Ve-he'avarti etkhem tachat ha-shevet*—under rod.

"'I will bring you into the bond of the covenant.'"

*Va-heveti etkhem be-masoret ha-berit*—covenant bond.

"'I will purge out from among you the rebels.'"

*U-varoti mikkem ha-mordim*—purge rebels.

"'In my holy mountain... there shall all the house of Israel... serve me.'"

*Be-har-qodshi... sham ya'avduni kol-beit Yisra'el kullo*—all serve.

"'You shall loathe yourselves in your own sight for all your evils.'"

*U-neqottem bi-fneikhem be-khol-ra'oteikhem*—loathe selves.

"'I have wrought with you for my name's sake.'"

*Ba-asoti itkhem lema'an shemi*—for name's sake.

**Oracle Against the South (20:45-49):**
"'Set your face toward the south.'"

*Sim panekha derekh teman*—toward south.

"'Prophesy against the forest of the field in the South.'"

*Ve-hinnave el-ya'ar ha-sadeh negev*—forest of south.

"'I will kindle a fire in you.'"

*Hineni matztzit bekh esh*—kindle fire.

"'All faces from the south to the north shall be burned.'"

*Ve-nikvu-vah kol-panim mi-negev tzafona*—all burned.

"'Is he not a maker of parables?'"

*Ha-lo memashel meshalim hu*—parable maker.

**Archetypal Layer:** Ezekiel 20 is a **negative salvation history**, containing **rebellion in Egypt (20:5-9)**, **rebellion in the wilderness first generation (20:10-17)**, **rebellion second generation (20:18-26)**, **"I gave them also statutes that were not good" (20:25)**, **rebellion in the land (20:27-32)**, and **future restoration through judgment (20:33-44)**.

**Ethical Inversion Applied:**
- "In the seventh year, in the fifth month"—August 591 BCE
- "'Are you come to inquire of me?'"—inquiry refused
- "'I will not be inquired of by you'"—refused
- "'Cause them to know the abominations of their fathers'"—know abominations
- "'In the day when I chose Israel'"—election
- "'I lifted up my hand unto them'"—swore
- "'I am YHWH your God'"—self-identification
- "'Cast away every man the detestable things'"—command
- "'But they rebelled against me'"—rebelled in Egypt
- "'I wrought for my name's sake'"—for name
- "'I gave them my statutes... which if a man do, he shall live'"—live by them
- "'I gave them my sabbaths, to be a sign'"—sabbaths as sign
- "'They rejected my ordinances... profaned my sabbaths'"—rejected
- "'I wrought for my name's sake'"—for name (repeated)
- "'My eye spared them'"—spared
- "'Walk not in the statutes of your fathers'"—warning to second generation
- "'But the children rebelled against me'"—children rebelled too
- "'I gave them also statutes that were not good'"—not good statutes
- "'I polluted them in their own gifts'"—allowed child sacrifice
- "'They saw every high hill'"—in land
- "'What is the high place... Bamah'"—wordplay
- "'When you make your sons to pass through the fire'"—child sacrifice
- "'We will be as the nations'"—desire to be like nations
- "'With a mighty hand... will I be king over you'"—YHWH as king
- "'I will bring you into the wilderness of the peoples'"—new wilderness
- "'I will plead with you face to face'"—face to face
- "'I will cause you to pass under the rod'"—under rod
- "'I will bring you into the bond of the covenant'"—covenant bond
- "'I will purge out from among you the rebels'"—purge
- "'In my holy mountain... there shall all... serve me'"—all serve
- "'You shall loathe yourselves'"—loathe selves
- "'I have wrought with you for my name's sake'"—for name
- "'Set your face toward the south'"—toward south
- "'I will kindle a fire'"—fire
- "'Is he not a maker of parables?'"—complaint

**Modern Equivalent:** Ezekiel 20 presents a negative salvation history—Israel rebelled at every stage (Egypt, wilderness gen 1, wilderness gen 2, land). "Statutes not good" (20:25) is difficult—YHWH allowed distorted practices as judgment. The future involves a "new exodus" (20:33-38) with purging. "For my name's sake" (20:9, 14, 22, 44) explains YHWH's persistence.

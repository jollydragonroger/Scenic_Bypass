# Ezekiel 22: The Bloody City

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## Jerusalem's Sins (22:1-16)

**22:1** And the word of YHWH came unto me, saying:

**22:2** "And you, son of man, will you judge, will you judge the bloody city? Then cause her to know all her abominations.

**22:3** "And say: Thus says the Lord YHWH: O city that sheds blood in the midst of her, that her time may come, and that makes idols unto herself to defile her!

**22:4** "You are become guilty in your blood that you have shed, and are defiled in your idols which you have made; and you have caused your days to draw near, and are come even unto your years; therefore have I made you a reproach unto the nations, and a mocking to all the countries.

**22:5** "Those that are near, and those that are far from you, shall mock you, you defiled of name and full of tumult.

**22:6** "Behold, the princes of Israel, every one according to his power, have been in you to shed blood.

**22:7** "In you have they made light of father and mother; in the midst of you have they dealt by oppression with the stranger; in you have they wronged the fatherless and the widow.

**22:8** "You have despised my holy things, and have profaned my sabbaths.

**22:9** "In you have been talebearers to shed blood; and in you they have eaten upon the mountains; in the midst of you they have committed lewdness.

**22:10** "In you have they uncovered their fathers' nakedness; in you have they humbled her that was unclean in her impurity.

**22:11** "And each has committed abomination with his neighbor's wife; and each has lewdly defiled his daughter-in-law; and each in you has humbled his sister, his father's daughter.

**22:12** "In you have they taken bribes to shed blood; you have taken interest and increase, and you have greedily gained of your neighbors by oppression, and have forgotten me," says the Lord YHWH.

**22:13** "Behold, therefore, I have smitten my hand at your dishonest gain which you have made, and at your blood which has been in the midst of you.

**22:14** "Can your heart endure, or can your hands be strong, in the days that I shall deal with you? I YHWH have spoken it, and will do it.

**22:15** "And I will scatter you among the nations, and disperse you through the countries; and I will consume your filthiness out of you.

**22:16** "And you shall be profaned in yourself, in the sight of the nations; and you shall know that I am YHWH."

---

## The Smelting Furnace (22:17-22)

**22:17** And the word of YHWH came unto me, saying:

**22:18** "Son of man, the house of Israel is become dross unto me; all of them are brass and tin and iron and lead, in the midst of the furnace; they are the dross of silver.

**22:19** "Therefore thus says the Lord YHWH: Because you are all become dross, therefore, behold, I will gather you into the midst of Jerusalem.

**22:20** "As they gather silver and brass and iron and lead and tin into the midst of the furnace, to blow the fire upon it, to melt it; so will I gather you in my anger and in my fury, and I will cast you in, and melt you.

**22:21** "Yea, I will gather you, and blow upon you with the fire of my wrath, and you shall be melted in the midst thereof.

**22:22** "As silver is melted in the midst of the furnace, so shall you be melted in the midst thereof; and you shall know that I YHWH have poured out my fury upon you."

---

## Corruption of All Classes (22:23-31)

**22:23** And the word of YHWH came unto me, saying:

**22:24** "Son of man, say unto her: You are a land that is not cleansed, nor rained upon in the day of indignation.

**22:25** "There is a conspiracy of her prophets in the midst thereof, like a roaring lion ravening the prey; they have devoured souls; they take treasure and precious things; they have made her widows many in the midst thereof.

**22:26** "Her priests have done violence to my law, and have profaned my holy things; they have put no difference between the holy and the common, neither have they taught difference between the unclean and the clean, and have hid their eyes from my sabbaths, and I am profaned among them.

**22:27** "Her princes in the midst thereof are like wolves ravening the prey, to shed blood, and to destroy souls, to get dishonest gain.

**22:28** "And her prophets have daubed for them with whited plaster, seeing vanity, and divining lies unto them, saying: Thus says the Lord YHWH, when YHWH has not spoken.

**22:29** "The people of the land have used oppression, and exercised robbery, and have wronged the poor and needy, and have oppressed the stranger unlawfully.

**22:30** "And I sought for a man among them, that should make up the hedge, and stand in the gap before me for the land, that I should not destroy it; but I found none.

**22:31** "Therefore have I poured out my indignation upon them; I have consumed them with the fire of my wrath; their own way have I brought upon their heads," says the Lord YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Jerusalem's Sins (22:1-16):**
"'Will you judge, will you judge the bloody city?'"

*Ha-tishpot ha-tishpot et-ir ha-damim*—judge bloody city.

"'Cause her to know all her abominations.'"

*Ve-hoda'tah et kol-to'avoteyha*—know abominations.

**The Key Verses (22:3-5):**
"'O city that sheds blood in the midst of her.'"

*Ir shofekhet dam be-tokhah*—sheds blood.

"'Makes idols unto herself to defile her.'"

*Ve-asetah gillulim alekha le-tom'ah*—makes idols.

"'You are become guilty in your blood that you have shed.'"

*Be-damekh asher-shafakht ashamti*—guilty.

"'Are defiled in your idols which you have made.'"

*U-ve-gillulayikh asher asit tame'ti*—defiled.

"'I have made you a reproach unto the nations.'"

*Al-ken netattikh cherpah la-goyim*—reproach.

"'A mocking to all the countries.'"

*Ve-qallasah le-khol-ha-aratzot*—mocking.

**The Key Verses (22:6-12) — Catalogue of Sins:**
"'The princes of Israel, every one according to his power, have been in you to shed blood.'"

*Hinneh nesi'ei Yisra'el ish li-zero'o hayu vakh lema'an shefokh-dam*—princes shed blood.

"'In you have they made light of father and mother.'"

*Av va-em heqelu vakh*—dishonored parents.

"'Have dealt by oppression with the stranger.'"

*La-ger asu ve-osheq be-tokhekh*—oppressed stranger.

"'Have wronged the fatherless and the widow.'"

*Yatom ve-almanah honu vakh*—wronged orphan, widow.

"'You have despised my holy things.'"

*Qodashay bazit*—despised holy.

"'Have profaned my sabbaths.'"

*Ve-et-shabbtotai chillalt*—profaned sabbaths.

"'In you have been talebearers to shed blood.'"

*Anshei rakhil hayu vakh lema'an shefokh-dam*—talebearers.

"'In you they have eaten upon the mountains.'"

*Ve-el-he-harim akhlu vakh*—mountain shrines.

"'They have committed lewdness.'"

*Zimmah asu be-tokhekh*—lewdness.

"'In you have they uncovered their fathers' nakedness.'"

*Ervat-av gillah vakh*—incest.

"'Have they humbled her that was unclean in her impurity.'"

*Teme'at ha-niddah innu-vakh*—violated impure.

"'Each has committed abomination with his neighbor's wife.'"

*Ve-ish et-eshet re'ehu asah to'evah*—adultery.

"'Each has lewdly defiled his daughter-in-law.'"

*Ve-ish et-kallato timme be-zimmah*—daughter-in-law.

"'Each... has humbled his sister.'"

*Ve-ish et-achoto vat-aviv innah-vakh*—sister.

"'In you have they taken bribes to shed blood.'"

*Shochad laqchu vakh lema'an shefokh-dam*—bribes.

"'You have taken interest and increase.'"

*Neshekh ve-tarbit laqacht*—usury.

"'Have greedily gained of your neighbors by oppression.'"

*Va-tevatze'i re'ayikh be-osheq*—gained by oppression.

"'Have forgotten me.'"

*Ve-oti shakhacht*—forgotten me.

**The Key Verses (22:13-16):**
"'I have smitten my hand at your dishonest gain.'"

*Ve-hinneh hikkeiti kappi el-bitza'ekh*—smitten hand.

"'At your blood which has been in the midst of you.'"

*Asher asit ve-al-damekh asher hayu be-tokhekh*—at blood.

"'Can your heart endure, or can your hands be strong?'"

*Ha-ya'amod libbekh im-techezaqnah yadayikh*—can endure?

"'In the days that I shall deal with you?'"

*La-yamim asher ani oseh otakh*—days I deal.

"'I will scatter you among the nations.'"

*Va-hafitzzoti otakh ba-goyim*—scatter.

"'I will consume your filthiness out of you.'"

*Va-hatimmoti tum'atekh mimmekh*—consume filth.

**Smelting Furnace (22:17-22):**
"'The house of Israel is become dross unto me.'"

*Hayu-li beit-Yisra'el le-sig*—dross.

"'All of them are brass and tin and iron and lead.'"

*Kullam nechoshet u-vedil u-varzel va-oferet*—base metals.

"'In the midst of the furnace.'"

*Be-tokh kur*—in furnace.

"'They are the dross of silver.'"

*Sigim kesef hayu*—silver's dross.

**The Key Verses (22:19-22):**
"'I will gather you into the midst of Jerusalem.'"

*Hineni qovetz etkhem el-tokh Yerushalayim*—gather.

"'As they gather silver and brass and iron and lead and tin into the midst of the furnace.'"

*Qevutzat kesef u-nechoshet u-varzel va-oferet u-vedil el-tokh kur*—gather metals.

"'To blow the fire upon it, to melt it.'"

*Lafachat alav esh le-hattikh*—melt.

"'So will I gather you in my anger and in my fury.'"

*Ken eqbots be-appi u-va-chamati*—gather in anger.

"'I will cast you in, and melt you.'"

*Ve-hinachti ve-hittakhti etkhem*—melt.

"'As silver is melted in the midst of the furnace.'"

*Ke-hittukh kesef be-tokh kur*—melted.

"'You shall know that I YHWH have poured out my fury upon you.'"

*Vi-ydatem ki-ani YHWH shafakhti chamati aleikhem*—poured fury.

**Corruption of All Classes (22:23-31):**
"'You are a land that is not cleansed.'"

*At eretz lo methoharah hi*—not cleansed.

"'Nor rained upon in the day of indignation.'"

*Lo gushemah be-yom za'am*—no rain.

**The Key Verse (22:25):**
"'There is a conspiracy of her prophets in the midst thereof.'"

*Qesher nevi'eyha be-tokhah*—prophets' conspiracy.

"'Like a roaring lion ravening the prey.'"

*Ke-ari sho'eg toref taref*—roaring lion.

"'They have devoured souls.'"

*Nefesh akhalu*—devoured souls.

"'They take treasure and precious things.'"

*Chosen vi-yqar yiqqachu*—take treasure.

"'They have made her widows many.'"

*Almnoteyha hirbu be-tokhah*—many widows.

**The Key Verse (22:26):**
"'Her priests have done violence to my law.'"

*Kohaneyha chamsu torati*—priests violated Torah.

"'Have profaned my holy things.'"

*Va-yechalelu qodashay*—profaned holy.

"'They have put no difference between the holy and the common.'"

*Bein-qodesh le-chol lo hivdilu*—no distinction.

"'Neither have they taught difference between the unclean and the clean.'"

*U-vein ha-tame la-tahor lo hodiu*—not taught.

"'Have hid their eyes from my sabbaths.'"

*U-me-shabbtotai he'elimu eineihem*—hid eyes.

"'I am profaned among them.'"

*Va-echal be-tokham*—profaned.

**The Key Verse (22:27):**
"'Her princes in the midst thereof are like wolves ravening the prey.'"

*Sareyha be-qirbah ki-ze'evim torfei taref*—princes like wolves.

"'To shed blood, and to destroy souls.'"

*Lishpokh dam le-abbed nefashot*—shed blood.

"'To get dishonest gain.'"

*Lema'an betzo'a batza*—dishonest gain.

**The Key Verse (22:28):**
"'Her prophets have daubed for them with whited plaster.'"

*U-nevi'eyha tachu lahem tafel*—whitewash.

"'Seeing vanity, and divining lies unto them.'"

*Chozim lahem shav ve-qosemim lahem kazav*—vanity, lies.

"'Saying: Thus says the Lord YHWH, when YHWH has not spoken.'"

*Omerim koh amar Adonai YHWH va-YHWH lo dibber*—YHWH didn't speak.

**The Key Verse (22:29):**
"'The people of the land have used oppression, and exercised robbery.'"

*Am ha-aretz ashqu osheq ve-gazlu gazel*—oppression, robbery.

"'Have wronged the poor and needy.'"

*Ve-ani ve-evyon honu*—wronged poor.

"'Have oppressed the stranger unlawfully.'"

*Ve-et-ha-ger ashqu be-lo mishpat*—oppressed stranger.

**The Key Verse (22:30):**
"'I sought for a man among them, that should make up the hedge.'"

*Va-avaqesh me-hem ish goder gader*—sought man.

"'Stand in the gap before me for the land.'"

*Ve-omed ba-peretz lefanai be-ad ha-aretz*—stand in gap.

"'That I should not destroy it.'"

*Le-vilti shachatah*—not destroy.

"'But I found none.'"

*Ve-lo matzati*—found none.

**The Key Verse (22:31):**
"'Therefore have I poured out my indignation upon them.'"

*Va-eshpokh aleihem za'ami*—poured indignation.

"'I have consumed them with the fire of my wrath.'"

*Be-esh evrati killitim*—consumed.

"'Their own way have I brought upon their heads.'"

*Darkam be-rosham natatti*—way on heads.

**Archetypal Layer:** Ezekiel 22 is the **"bloody city" indictment**, containing **catalogue of sins (22:6-12)**, **the smelting furnace metaphor (22:17-22)**, **corruption of prophets (22:25, 28)**, **priests (22:26)**, **princes (22:27)**, **people (22:29)**, and **"I sought for a man... to stand in the gap... but I found none" (22:30)**.

**Ethical Inversion Applied:**
- "'Will you judge, will you judge the bloody city?'"—judge
- "'O city that sheds blood in the midst of her'"—sheds blood
- "'Makes idols unto herself to defile her'"—idols
- "'You are become guilty in your blood'"—guilty
- "'I have made you a reproach unto the nations'"—reproach
- "'The princes of Israel... to shed blood'"—princes shed blood
- "'Have they made light of father and mother'"—dishonored parents
- "'Have dealt by oppression with the stranger'"—oppressed stranger
- "'Have wronged the fatherless and the widow'"—wronged vulnerable
- "'You have despised my holy things'"—despised holy
- "'Have profaned my sabbaths'"—profaned sabbaths
- "'In you have been talebearers to shed blood'"—talebearers
- "'Each has committed abomination with his neighbor's wife'"—adultery
- "'In you have they taken bribes to shed blood'"—bribes
- "'You have taken interest and increase'"—usury
- "'Have forgotten me'"—forgotten
- "'Can your heart endure?'"—can't endure
- "'I will scatter you among the nations'"—scatter
- "'The house of Israel is become dross unto me'"—dross
- "'All of them are brass and tin and iron and lead'"—base metals
- "'I will gather you... and melt you'"—melt
- "'You are a land that is not cleansed'"—not cleansed
- "'There is a conspiracy of her prophets'"—prophets conspire
- "'Like a roaring lion ravening the prey'"—lion
- "'They have devoured souls'"—devoured
- "'Her priests have done violence to my law'"—priests violated
- "'They have put no difference between the holy and the common'"—no distinction
- "'Her princes... are like wolves'"—princes like wolves
- "'Her prophets have daubed for them with whited plaster'"—whitewash
- "'Thus says the Lord YHWH, when YHWH has not spoken'"—false prophecy
- "'The people of the land have used oppression'"—oppression
- "'I sought for a man... to stand in the gap'"—sought
- "'But I found none'"—found none
- "'Therefore have I poured out my indignation'"—poured

**Modern Equivalent:** Ezekiel 22 indicts all social classes. The "bloody city" (22:2) = Jerusalem. The catalogue (22:6-12) covers every Decalogue violation. "I sought for a man... but I found none" (22:30) is one of the Bible's most tragic verses—no intercessor was found.

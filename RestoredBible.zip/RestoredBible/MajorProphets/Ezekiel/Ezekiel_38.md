# Ezekiel 38: The Prophecy Against Gog

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## Gog's Invasion (38:1-9)

**38:1** And the word of YHWH came unto me, saying:

**38:2** "Son of man, set your face toward Gog, of the land of Magog, the chief prince of Meshech and Tubal, and prophesy against him,

**38:3** "And say: Thus says the Lord YHWH: Behold, I am against you, O Gog, chief prince of Meshech and Tubal;

**38:4** "And I will turn you about, and put hooks into your jaws, and I will bring you forth, and all your army, horses and horsemen, all of them clothed in full armor, a great company with buckler and shield, all of them handling swords;

**38:5** "Persia, Ethiopia, and Put with them, all of them with shield and helmet;

**38:6** "Gomer, and all his bands; the house of Togarmah in the uttermost parts of the north, and all his bands; even many peoples with you.

**38:7** "Be prepared, yea, prepare yourself, you, and all your companies that are assembled unto you, and be a guard unto them.

**38:8** "After many days you shall be mustered for service; in the latter years you shall come against the land that is brought back from the sword, that is gathered out of many peoples, against the mountains of Israel, which have been a continual waste; but it is brought forth out of the peoples, and they dwell safely all of them.

**38:9** "And you shall ascend, you shall come like a storm, you shall be like a cloud to cover the land, you, and all your bands, and many peoples with you."

---

## Gog's Evil Plan (38:10-13)

**38:10** Thus says the Lord YHWH: "It shall come to pass in that day, that things shall come into your mind, and you shall devise an evil device;

**38:11** "And you shall say: 'I will go up against the land of unwalled villages; I will come upon them that are at quiet, that dwell safely, all of them dwelling without walls, and having neither bars nor gates';

**38:12** "To take the spoil and to take the prey; to turn your hand against the waste places that are now inhabited, and against the people that are gathered out of the nations, that have gotten cattle and goods, that dwell in the middle of the earth.

**38:13** "Sheba, and Dedan, and the merchants of Tarshish, with all the young lions thereof, shall say unto you: 'Are you come to take the spoil? Have you assembled your company to take the prey? To carry away silver and gold, to take away cattle and goods, to take great spoil?'"

---

## YHWH's Purpose (38:14-17)

**38:14** "Therefore, son of man, prophesy, and say unto Gog: Thus says the Lord YHWH: In that day when my people Israel dwell safely, shall you not know it?

**38:15** "And you shall come from your place out of the uttermost parts of the north, you, and many peoples with you, all of them riding upon horses, a great company and a mighty army;

**38:16** "And you shall come up against my people Israel, as a cloud to cover the land; it shall be in the end of days, and I will bring you against my land, that the nations may know me, when I shall be sanctified through you, O Gog, before their eyes.

**38:17** "Thus says the Lord YHWH: Are you he of whom I spoke in old time by my servants the prophets of Israel, that prophesied in those days for many years, that I would bring you against them?"

---

## YHWH's Judgment on Gog (38:18-23)

**38:18** "And it shall come to pass in that day, when Gog shall come against the land of Israel," says the Lord YHWH, "that my fury shall arise up in my nostrils.

**38:19** "For in my jealousy and in the fire of my wrath have I spoken: Surely in that day there shall be a great shaking in the land of Israel;

**38:20** "So that the fishes of the sea, and the fowls of the heaven, and the beasts of the field, and all creeping things that creep upon the ground, and all the men that are upon the face of the earth, shall shake at my presence, and the mountains shall be thrown down, and the steep places shall fall, and every wall shall fall to the ground.

**38:21** "And I will call for a sword against him throughout all my mountains," says the Lord YHWH; "every man's sword shall be against his brother.

**38:22** "And I will plead against him with pestilence and with blood; and I will rain upon him, and upon his bands, and upon the many peoples that are with him, an overflowing shower, and great hailstones, fire, and brimstone.

**38:23** "Thus will I magnify myself, and sanctify myself, and I will make myself known in the eyes of many nations; and they shall know that I am YHWH."

---

## Synthesis Notes

**Key Restorations:**

**Gog's Invasion (38:1-9):**
**The Key Verse (38:2):**
"'Set your face toward Gog, of the land of Magog.'"

*Sim panekha el-Gog eretz ha-Magog*—toward Gog.

"'The chief prince of Meshech and Tubal.'"

*Nesi rosh Meshekh ve-Tuval*—chief prince.

"'Prophesy against him.'"

*Ve-hinnave alav*—prophesy.

**Gog and Magog:**
Gog is the leader; Magog is the land. These represent a cosmic northern enemy.

**The Key Verses (38:3-4):**
"'I am against you, O Gog.'"

*Hineni elekha Gog*—against Gog.

"'Chief prince of Meshech and Tubal.'"

*Nesi rosh Meshekh ve-Tuval*—chief prince.

"'I will turn you about.'"

*Ve-shov'vatikha*—turn about.

"'Put hooks into your jaws.'"

*Ve-natatti chachim bi-lechayekha*—hooks in jaws.

"'I will bring you forth.'"

*Ve-hotzeti otkha*—bring forth.

"'All your army, horses and horsemen.'"

*Ve-et-kol-cheilekha susim u-farashim*—army.

"'All of them clothed in full armor.'"

*Levushei mikhlol kullam*—full armor.

"'A great company with buckler and shield.'"

*Qahal rav tzinnah u-magen*—great company.

"'All of them handling swords.'"

*Tofsei charavot kullam*—with swords.

**The Key Verses (38:5-6):**
"'Persia, Ethiopia, and Put with them.'"

*Paras Kush u-Put ittam*—allies.

"'All of them with shield and helmet.'"

*Kullam magen ve-khova*—armed.

"'Gomer, and all his bands.'"

*Gomer ve-khol-agappeyha*—Gomer.

"'The house of Togarmah in the uttermost parts of the north.'"

*Beit Togarmah yarketei tzafon*—far north.

"'Even many peoples with you.'"

*Ammim rabbim ittakh*—many peoples.

**The Key Verses (38:7-9):**
"'Be prepared, yea, prepare yourself.'"

*Hikon ve-hakhen lekha*—prepare.

"'All your companies that are assembled unto you.'"

*Attah ve-khol-qehalekha ha-niqhalim alekha*—assembled.

"'Be a guard unto them.'"

*Ve-hayita lahem le-mishmar*—guard.

"'After many days you shall be mustered for service.'"

*Mi-yamim rabbim tippaqed*—mustered.

"'In the latter years you shall come.'"

*Be-acharit ha-shanim tavo*—latter years.

"'Against the land that is brought back from the sword.'"

*El-eretz meshovebet me-cherev*—restored from sword.

"'That is gathered out of many peoples.'"

*Mequbbetzet me-ammim rabbim*—gathered.

"'Against the mountains of Israel.'"

*Al harei Yisra'el*—mountains of Israel.

"'Which have been a continual waste.'"

*Asher hayu le-chorvah tamid*—continual waste.

"'It is brought forth out of the peoples.'"

*Ve-hi me-ammim hotzا'ah*—brought forth.

"'They dwell safely all of them.'"

*Ve-yashvu la-vetach kullam*—dwell safely.

"'You shall ascend, you shall come like a storm.'"

*Ve-alita ka-sho'ah tavo*—like storm.

"'You shall be like a cloud to cover the land.'"

*Ke-anan le-khasot ha-aretz tihyeh*—like cloud.

**Gog's Evil Plan (38:10-13):**
**The Key Verses (38:10-12):**
"'It shall come to pass in that day, that things shall come into your mind.'"

*Ve-hayah ba-yom ha-hu ya'alu devarim al-levavekha*—things come to mind.

"'You shall devise an evil device.'"

*Ve-chashavta machashevet ra'ah*—evil plan.

"''I will go up against the land of unwalled villages.''"

*E'eleh al-eretz perazot*—unwalled villages.

"''I will come upon them that are at quiet, that dwell safely.''"

*Avo ha-shoqetim yoshevei la-vetach*—quiet, safe.

"''All of them dwelling without walls.'"

*Kullam yoshevim be-ein chomah*—no walls.

"''Having neither bars nor gates.''"

*U-veriach u-delatayim ein lahem*—no bars, gates.

"'To take the spoil and to take the prey.'"

*Lishlol shalal ve-lavoz baz*—spoil, prey.

"'To turn your hand against the waste places that are now inhabited.'"

*Le-hashiv yadekha al-choravot noshabor*—against waste places.

"'Against the people that are gathered out of the nations.'"

*Ve-al-am me'uqqaf mi-goyim*—gathered people.

"'That have gotten cattle and goods.'"

*Oseh miqneh ve-qinyan*—cattle, goods.

"'That dwell in the middle of the earth.'"

*Yoshevei al-tabbur ha-aretz*—navel of earth.

**The Key Verse (38:13):**
"'Sheba, and Dedan, and the merchants of Tarshish, with all the young lions thereof.'"

*Sheva u-Dedan ve-socherei Tarshish ve-khol-kefireyha*—traders.

"''Are you come to take the spoil?''"

*Ha-lishlol shalal attah ba*—to spoil?

"''Have you assembled your company to take the prey?''"

*Ha-lavoz baz hiqhalta qehalekha*—to prey?

"''To carry away silver and gold.'"

*Laset kesef ve-zahav*—silver, gold.

"''To take away cattle and goods.'"

*Laqachat miqneh ve-qinyan*—cattle, goods.

"''To take great spoil?''"

*Lishlol shalal gadol*—great spoil.

**YHWH's Purpose (38:14-17):**
**The Key Verses (38:14-16):**
"'In that day when my people Israel dwell safely, shall you not know it?'"

*Ba-yom ha-hu be-shevet ammi Yisra'el la-vetach ha-lo teda*—will you know?

"'You shall come from your place out of the uttermost parts of the north.'"

*U-vata mi-meqomekha mi-yarketei tzafon*—from far north.

"'You, and many peoples with you.'"

*Attah ve-ammim rabbim ittakh*—with many.

"'All of them riding upon horses.'"

*Rokhevei susim kullam*—on horses.

"'A great company and a mighty army.'"

*Qahal gadol ve-chayil rav*—great army.

"'You shall come up against my people Israel.'"

*Ve-alita al-ammi Yisra'el*—against my people.

"'As a cloud to cover the land.'"

*Ka-anan le-khasot ha-aretz*—like cloud.

"'It shall be in the end of days.'"

*Be-acharit ha-yamim tihyeh*—end of days.

"'I will bring you against my land.'"

*Va-havi'otikha al-artzi*—bring against land.

"'That the nations may know me.'"

*Lema'an da'at ha-goyim oti*—nations know.

"'When I shall be sanctified through you, O Gog, before their eyes.'"

*Be-hiqqadshi vekha Gog le-eineihem*—sanctified through Gog.

**The Key Verse (38:17):**
"'Are you he of whom I spoke in old time by my servants the prophets of Israel?'"

*Ha-attah-hu asher-dibbarti be-yamim qadmonim be-yad avadai nevi'ei Yisra'el*—spoke before?

"'That prophesied in those days for many years.'"

*Ha-nibbe'im ba-yamim ha-hem shanim*—prophesied.

"'That I would bring you against them?'"

*Le-havi otkha aleihem*—bring against.

**YHWH's Judgment on Gog (38:18-23):**
**The Key Verses (38:18-20):**
"'When Gog shall come against the land of Israel, my fury shall arise up in my nostrils.'"

*Be-yom bo Gog al-admat Yisra'el... ta'aleh chamati be-appi*—fury rises.

"'In my jealousy and in the fire of my wrath have I spoken.'"

*Be-qin'ati be-esh evrati dibbarti*—jealousy, wrath.

"'Surely in that day there shall be a great shaking in the land of Israel.'"

*Im be-yom ha-hu yihyeh ra'ash gadol al-admat Yisra'el*—great shaking.

"'The fishes of the sea, and the fowls of the heaven.'"

*Ve-ra'ashu mi-panai degei ha-yam ve-of ha-shamayim*—fish, birds.

"'The beasts of the field, and all creeping things.'"

*Ve-chayyat ha-sadeh ve-khol-ha-remes*—beasts, creepers.

"'All the men that are upon the face of the earth.'"

*Ve-khol-ha-adam asher al-penei ha-adamah*—all men.

"'Shall shake at my presence.'"

*Ve-ra'ashu mi-panai*—shake at presence.

"'The mountains shall be thrown down.'"

*Ve-nehersu he-harim*—mountains fall.

"'The steep places shall fall.'"

*Ve-nafelu ha-madregot*—steep places fall.

"'Every wall shall fall to the ground.'"

*Ve-khol-chomah la-aretz tippol*—walls fall.

**The Key Verses (38:21-23):**
"'I will call for a sword against him throughout all my mountains.'"

*Ve-qarati alav le-khol-harai cherev*—call for sword.

"'Every man's sword shall be against his brother.'"

*Cherev ish be-achiv tihyeh*—sword against brother.

"'I will plead against him with pestilence and with blood.'"

*Ve-nishpatti itto be-dever u-ve-dam*—pestilence, blood.

"'I will rain upon him... an overflowing shower.'"

*Ve-geshem shotef*—overflowing rain.

"'Great hailstones.'"

*Ve-avnei elgavish*—hailstones.

"'Fire, and brimstone.'"

*Esh ve-gofrית*—fire, brimstone.

"'Thus will I magnify myself, and sanctify myself.'"

*Ve-hitgaddilti ve-hitqaddishti*—magnify, sanctify.

"'I will make myself known in the eyes of many nations.'"

*Ve-noda'ti le-einei goyim rabbim*—made known.

"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—recognition.

**Archetypal Layer:** Ezekiel 38 introduces the **Gog and Magog prophecy (38-39)**, containing **"Gog, of the land of Magog, the chief prince of Meshech and Tubal" (38:2)**, **"I will put hooks into your jaws, and I will bring you forth" (38:4)**, **coalition from Persia, Ethiopia, Put, Gomer, Togarmah (38:5-6)**, **"in the latter years you shall come" (38:8)**, **"like a cloud to cover the land" (38:9, 16)**, **"it shall be in the end of days" (38:16)**, and **cosmic judgment with earthquake, pestilence, fire, and brimstone (38:19-22)**.

**Ethical Inversion Applied:**
- "'Set your face toward Gog, of the land of Magog'"—toward Gog
- "'The chief prince of Meshech and Tubal'"—chief prince
- "'Prophesy against him'"—prophesy
- "'I am against you, O Gog'"—against Gog
- "'I will turn you about'"—turn
- "'Put hooks into your jaws'"—hooks
- "'I will bring you forth'"—bring forth
- "'All your army, horses and horsemen'"—army
- "'Persia, Ethiopia, and Put with them'"—allies
- "'Gomer, and all his bands'"—Gomer
- "'The house of Togarmah in the uttermost parts of the north'"—far north
- "'Be prepared, yea, prepare yourself'"—prepare
- "'After many days you shall be mustered for service'"—mustered
- "'In the latter years you shall come'"—latter years
- "'Against the land that is brought back from the sword'"—restored land
- "'Against the mountains of Israel'"—mountains
- "'They dwell safely all of them'"—safely
- "'You shall ascend... like a storm'"—like storm
- "'Like a cloud to cover the land'"—like cloud
- "'Things shall come into your mind'"—evil plan
- "''I will go up against the land of unwalled villages''"—unwalled
- "''I will come upon them that are at quiet''"—quiet
- "'To take the spoil and to take the prey'"—spoil
- "'That dwell in the middle of the earth'"—navel of earth
- "'Sheba, and Dedan, and the merchants of Tarshish'"—observers
- "''Are you come to take the spoil?''"—question
- "'When my people Israel dwell safely'"—safely
- "'You shall come from your place out of the uttermost parts of the north'"—far north
- "'A great company and a mighty army'"—great army
- "'It shall be in the end of days'"—end of days
- "'I will bring you against my land'"—YHWH brings
- "'That the nations may know me'"—nations know
- "'When I shall be sanctified through you, O Gog'"—sanctified through
- "'Are you he of whom I spoke in old time?'"—ancient prophecy
- "'My fury shall arise up in my nostrils'"—fury rises
- "'In my jealousy and in the fire of my wrath'"—jealousy, wrath
- "'There shall be a great shaking in the land of Israel'"—earthquake
- "'The fishes... the fowls... the beasts... all the men... shall shake'"—cosmic shaking
- "'The mountains shall be thrown down'"—mountains fall
- "'Every wall shall fall'"—walls fall
- "'I will call for a sword against him'"—call sword
- "'Every man's sword shall be against his brother'"—chaos
- "'I will plead against him with pestilence and with blood'"—pestilence
- "'An overflowing shower, and great hailstones'"—hail
- "'Fire, and brimstone'"—fire, brimstone
- "'Thus will I magnify myself, and sanctify myself'"—magnify, sanctify
- "'They shall know that I am YHWH'"—recognition

**Modern Equivalent:** Ezekiel 38 introduces Gog of Magog—a cosmic northern enemy. YHWH draws Gog against restored Israel to demonstrate his power. The "end of days" (38:16) and cosmic judgment make this eschatological. Revelation 20:8 applies Gog and Magog to the final battle. Chapter 39 continues this prophecy.

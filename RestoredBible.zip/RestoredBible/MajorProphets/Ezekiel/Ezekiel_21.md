# Ezekiel 21: The Sword of YHWH

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## The Sword Drawn (21:1-7)

**21:1** And the word of YHWH came unto me, saying:

**21:2** "Son of man, set your face toward Jerusalem, and preach toward the sanctuaries, and prophesy against the land of Israel;

**21:3** "And say to the land of Israel: Thus says YHWH: Behold, I am against you, and will draw forth my sword out of its sheath, and will cut off from you the righteous and the wicked.

**21:4** "Seeing then that I will cut off from you the righteous and the wicked, therefore shall my sword go forth out of its sheath against all flesh from the south to the north;

**21:5** "And all flesh shall know that I YHWH have drawn forth my sword out of its sheath; it shall not return any more.

**21:6** "Sigh therefore, son of man; with the breaking of your loins and with bitterness shall you sigh before their eyes.

**21:7** "And it shall be, when they say unto you: 'Wherefore do you sigh?' that you shall say: 'Because of the tidings, for it comes; and every heart shall melt, and all hands shall be slack, and every spirit shall be faint, and all knees shall drip with water; behold, it comes, and it shall be done,'" says the Lord YHWH.

---

## The Song of the Sword (21:8-17)

**21:8** And the word of YHWH came unto me, saying:

**21:9** "Son of man, prophesy, and say: Thus says YHWH: Say: A sword, a sword, it is sharpened, and also polished;

**21:10** "It is sharpened that it may make a slaughter; it is polished that it may glitter—or shall we make mirth?—the rod of my son, it despises every tree.

**21:11** "And it is given to be polished, that it may be handled; the sword, it is sharpened, yea, it is polished, to give it into the hand of the slayer.

**21:12** "Cry and wail, son of man; for it is upon my people, it is upon all the princes of Israel; they are delivered over to the sword with my people; smite therefore upon your thigh.

**21:13** "For there is a trial; and what if the rod that despises shall be no more?" says the Lord YHWH.

**21:14** "You therefore, son of man, prophesy, and smite your hands together; and let the sword be doubled the third time, the sword of those to be slain; it is the sword of the great one that is to be slain, which encompasses them.

**21:15** "I have set the point of the sword against all their gates, that their heart may melt, and their stumblings be multiplied; ah! It is made glittering, it is wrapped up for slaughter.

**21:16** "Go one way or other, either on the right hand, or on the left, whithersoever your face is set.

**21:17** "I will also smite my hands together, and I will satisfy my fury; I YHWH have spoken it."

---

## The King of Babylon at the Crossroads (21:18-27)

**21:18** The word of YHWH came unto me again, saying:

**21:19** "You also, son of man, appoint two ways, that the sword of the king of Babylon may come; they twain shall come forth out of one land; and mark a signpost, mark it at the head of the way to the city.

**21:20** "You shall appoint a way for the sword to come against Rabbah of the children of Ammon, and against Judah in Jerusalem the fortified.

**21:21** "For the king of Babylon stood at the parting of the way, at the head of the two ways, to use divination; he shook the arrows to and fro, he inquired of the teraphim, he looked in the liver.

**21:22** "In his right hand was the divination for Jerusalem, to set battering rams, to open the mouth for the slaughter, to lift up the voice with shouting, to set battering rams against the gates, to cast up mounds, to build forts.

**21:23** "And it shall be unto them as a false divination in their sight, who have sworn oaths unto them; but he brings iniquity to remembrance, that they may be taken.

**21:24** "Therefore thus says the Lord YHWH: Because you have made your iniquity to be remembered, in that your transgressions are uncovered, so that in all your doings your sins do appear; because you have come to remembrance, you shall be taken with the hand.

**21:25** "And you, O wicked one, that are to be slain, the prince of Israel, whose day is come, in the time of the iniquity of the end;

**21:26** "Thus says the Lord YHWH: The mitre shall be removed, and the crown taken off; this shall be no more the same; that which is low shall be exalted, and that which is high abased.

**21:27** "Overthrown, overthrown, overthrown, will I make it; this also shall be no more, until he come whose right it is, and I will give it him."

---

## Against the Ammonites (21:28-32)

**21:28** "And you, son of man, prophesy, and say: Thus says the Lord YHWH concerning the children of Ammon, and concerning their reproach; and say: A sword, a sword is drawn, for the slaughter it is polished, to cause it to devour, that it may glitter;

**21:29** "While they see for you vanity, while they divine lies unto you, to lay you upon the necks of the wicked that are to be slain, whose day is come in the time of the iniquity of the end.

**21:30** "Cause it to return into its sheath! In the place where you were created, in the land of your origin, will I judge you.

**21:31** "And I will pour out my indignation upon you; I will blow upon you with the fire of my wrath; and I will deliver you into the hand of brutish men, skilled to destroy.

**21:32** "You shall be for fuel to the fire; your blood shall be in the midst of the land; you shall be no more remembered; for I YHWH have spoken it."

---

## Synthesis Notes

**Key Restorations:**

**Sword Drawn (21:1-7):**
"'Set your face toward Jerusalem.'"

*Sim panekha el-Yerushalayim*—toward Jerusalem.

"'Preach toward the sanctuaries.'"

*Ve-hattef el-miqdashim*—toward sanctuaries.

"'Behold, I am against you.'"

*Hineni elayikh*—against you.

"'Will draw forth my sword out of its sheath.'"

*Ve-hotzeti charbi mi-ta'arah*—draw sword.

"'Will cut off from you the righteous and the wicked.'"

*Ve-hikhraatti mimmekh tzaddiq ve-rasha*—cut off both.

**The Key Verse (21:5):**
"'I YHWH have drawn forth my sword out of its sheath.'"

*Ani YHWH hotzeti charbi mi-ta'arah*—YHWH drew.

"'It shall not return any more.'"

*Lo tashuv od*—won't return.

"'Sigh therefore, son of man.'"

*Ve-attah ben-adam he'anech*—sigh.

"'With the breaking of your loins.'"

*Be-shivron motnayim*—broken loins.

"'With bitterness shall you sigh.'"

*U-vi-merimut te'anech*—bitter sighing.

**Song of the Sword (21:8-17):**
**The Key Verses (21:9-10):**
"'A sword, a sword, it is sharpened, and also polished.'"

*Cherev cherev huchadah ve-gam merutah*—sword sharpened, polished.

"'It is sharpened that it may make a slaughter.'"

*Lema'an tevo'ach tevach huchadah*—for slaughter.

"'It is polished that it may glitter.'"

*Lema'an-yehi-lah baraq merutah*—to glitter.

"'The rod of my son, it despises every tree.'"

*Shevet beni mo'eset kol-etz*—despises wood.

**The Key Verses (21:11-12):**
"'It is given to be polished, that it may be handled.'"

*Va-yitten otah le-morat la-tefos be-khaf*—to be handled.

"'The sword, it is sharpened, yea, it is polished, to give it into the hand of the slayer.'"

*Hi huchadah cherev ve-hi moratah latet otah be-yad horeg*—for slayer.

"'Cry and wail, son of man.'"

*Ze'aq ve-heilel ben-adam*—cry, wail.

"'It is upon my people.'"

*Ki-hi hayetah ve-ammi*—upon my people.

"'Upon all the princes of Israel.'"

*Hi ve-khol-nesi'ei Yisra'el*—upon princes.

"'Smite therefore upon your thigh.'"

*Lakhen sefоq el-yarekh*—smite thigh.

**The Key Verses (21:14-17):**
"'Let the sword be doubled the third time.'"

*Ve-tikkafal cherev shelishit*—doubled, tripled.

"'The sword of those to be slain.'"

*Cherev challalim hi*—sword of slain.

"'The sword of the great one that is to be slain.'"

*Cherev challal ha-gadol*—great one slain.

"'I have set the point of the sword against all their gates.'"

*Natatti avchit cherev be-khol-sha'areihem*—at gates.

"'That their heart may melt.'"

*Lema'an yamog lev*—heart melt.

"'I will also smite my hands together.'"

*Ve-gam-ani akkeh khaрpi el-kappi*—smite hands.

"'I will satisfy my fury.'"

*Va-hanichoti chamati*—satisfy fury.

**King of Babylon at Crossroads (21:18-27):**
"'Appoint two ways, that the sword of the king of Babylon may come.'"

*Sim-lekha shenei derakhim lavo cherev melekh-Bavel*—two ways.

"'Mark a signpost, mark it at the head of the way to the city.'"

*Ve-yad bereh be-rosh derekh-ir bereh*—signpost.

"'A way for the sword to come against Rabbah of the children of Ammon.'"

*Derekh lavo cherev et-Rabbat benei-Ammon*—Rabbah.

"'Against Judah in Jerusalem the fortified.'"

*Ve-et-Yehudah bi-Yrushalayim betzurah*—fortified Jerusalem.

**The Key Verse (21:21):**
"'The king of Babylon stood at the parting of the way.'"

*Ki amad melekh-Bavel el-em ha-derekh*—at crossroads.

"'At the head of the two ways, to use divination.'"

*Be-rosh shenei ha-derakhim liqsom qesem*—divination.

"'He shook the arrows to and fro.'"

*Qilqal ba-chitztzim*—shook arrows.

"'He inquired of the teraphim.'"

*Sha'al ba-terafim*—teraphim.

"'He looked in the liver.'"

*Ra'ah ba-kaved*—hepatoscopy.

**Divination Methods:**
Belomancy (arrows), teraphim (household gods), hepatoscopy (liver reading).

**The Key Verse (21:22):**
"'In his right hand was the divination for Jerusalem.'"

*Be-yemino hayah ha-qesem Yerushalayim*—Jerusalem chosen.

"'To set battering rams.'"

*Lasum karim*—battering rams.

"'To open the mouth for the slaughter.'"

*Liftoch peh be-retzach*—for slaughter.

**The Key Verses (21:25-27):**
"'You, O wicked one, that are to be slain, the prince of Israel.'"

*Ve-attah challal rasha nesi Yisra'el*—wicked prince.

"'Whose day is come, in the time of the iniquity of the end.'"

*Asher-ba yomo be-et avon qetz*—day come.

**The Key Verse (21:26):**
"'The mitre shall be removed, and the crown taken off.'"

*Hasir ha-mitznefet ve-harim ha-atarah*—mitre and crown removed.

"'This shall be no more the same.'"

*Zot lo zot*—no more same.

"'That which is low shall be exalted, and that which is high abased.'"

*Ha-shefalah hagbiah ve-ha-gavoha hashpil*—low exalted, high abased.

**The Key Verse (21:27):**
"'Overthrown, overthrown, overthrown, will I make it.'"

*Avvah avvah avvah asimennah*—three-fold overthrow.

"'This also shall be no more.'"

*Gam-zot lo hayatah*—no more.

"'Until he come whose right it is.'"

*Ad-bo asher-lo ha-mishpat*—whose right.

"'I will give it him.'"

*U-netattiv*—give to him.

**Messianic:**
"Whose right it is" echoes Genesis 49:10 (Shiloh)—the true ruler to come.

**Against Ammonites (21:28-32):**
"'Concerning the children of Ammon, and concerning their reproach.'"

*El-benei Ammon ve-el-cherpatam*—Ammon's reproach.

"'A sword, a sword is drawn, for the slaughter it is polished.'"

*Cherev cherev petuchah la-tevach merutah*—drawn sword.

"'In the place where you were created, in the land of your origin, will I judge you.'"

*Be-meqom asher nivreta be-eretz mekhurotayikh eshpot otakh*—judged in origin.

"'You shall be for fuel to the fire.'"

*La-esh tihyi le-okhlah*—fuel for fire.

"'You shall be no more remembered.'"

*Lo tizzakheri*—not remembered.

**Archetypal Layer:** Ezekiel 21 contains **YHWH's drawn sword (21:3-5)**, **the Song of the Sword "sharpened and polished" (21:9-17)**, **Nebuchadnezzar's divination at the crossroads choosing Jerusalem (21:21-22)**, **"The mitre shall be removed, and the crown taken off" (21:26)**, **"Overthrown, overthrown, overthrown" (21:27)**, and **"until he come whose right it is" (21:27)**.

**Ethical Inversion Applied:**
- "'Set your face toward Jerusalem'"—toward Jerusalem
- "'Preach toward the sanctuaries'"—toward sanctuaries
- "'I am against you'"—against
- "'Will draw forth my sword out of its sheath'"—draw sword
- "'Will cut off from you the righteous and the wicked'"—cut off both
- "'It shall not return any more'"—won't return
- "'Sigh therefore, son of man'"—sigh
- "'Every heart shall melt, and all hands shall be slack'"—melt, slack
- "'A sword, a sword, it is sharpened, and also polished'"—sword song
- "'It is sharpened that it may make a slaughter'"—for slaughter
- "'It is polished that it may glitter'"—to glitter
- "'Cry and wail, son of man'"—cry, wail
- "'It is upon my people'"—upon people
- "'Smite therefore upon your thigh'"—smite thigh
- "'Let the sword be doubled the third time'"—doubled, tripled
- "'I have set the point of the sword against all their gates'"—at gates
- "'I will also smite my hands together'"—smite hands
- "'I will satisfy my fury'"—satisfy fury
- "'Appoint two ways'"—two ways
- "'Mark a signpost'"—signpost
- "'The king of Babylon stood at the parting of the way'"—crossroads
- "'To use divination'"—divination
- "'He shook the arrows'"—belomancy
- "'He inquired of the teraphim'"—teraphim
- "'He looked in the liver'"—hepatoscopy
- "'In his right hand was the divination for Jerusalem'"—Jerusalem chosen
- "'To set battering rams'"—siege
- "'You, O wicked one... the prince of Israel'"—wicked prince
- "'Whose day is come'"—day come
- "'The mitre shall be removed, and the crown taken off'"—removed
- "'That which is low shall be exalted, and that which is high abased'"—reversal
- "'Overthrown, overthrown, overthrown'"—three-fold
- "'Until he come whose right it is'"—messianic
- "'I will give it him'"—give
- "'A sword... for the slaughter'"—against Ammon
- "'You shall be for fuel to the fire'"—fuel
- "'You shall be no more remembered'"—not remembered

**Modern Equivalent:** Ezekiel 21 dramatizes YHWH's sword. Nebuchadnezzar's divination at the crossroads (21:21) shows YHWH using pagan means to direct history. "Until he come whose right it is" (21:27) is messianic—true rulership awaits. The three-fold "overthrown" emphasizes totality.

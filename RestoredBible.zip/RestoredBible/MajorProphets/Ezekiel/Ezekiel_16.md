# Ezekiel 16: Jerusalem the Unfaithful Bride

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## Jerusalem's Origins (16:1-14)

**16:1** Again the word of YHWH came unto me, saying:

**16:2** "Son of man, cause Jerusalem to know her abominations,

**16:3** "And say: Thus says the Lord YHWH unto Jerusalem: Your origin and your nativity is of the land of the Canaanite; the Amorite was your father, and your mother was a Hittite.

**16:4** "And as for your nativity, in the day you were born your navel was not cut, neither were you washed in water for cleansing; you were not salted at all, nor swaddled at all.

**16:5** "No eye pitied you, to do any of these unto you, to have compassion upon you; but you were cast out in the open field in the loathing of your person, in the day that you were born.

**16:6** "And when I passed by you, and saw you wallowing in your blood, I said unto you: In your blood, live; yea, I said unto you: In your blood, live.

**16:7** "I cause you to increase, even as the growth of the field. And you did increase and grow up, and you came to excellent beauty: your breasts were fashioned, and your hair was grown; yet you were naked and bare.

**16:8** "Now when I passed by you, and looked upon you, and, behold, your time was the time of love, I spread my skirt over you, and covered your nakedness; yea, I swore unto you, and entered into a covenant with you," says the Lord YHWH, "and you became mine.

**16:9** "Then washed I you with water; yea, I cleansed away your blood from you, and I anointed you with oil.

**16:10** "I clothed you also with richly woven work, and shod you with sealskin, and I wound fine linen about your head, and covered you with silk.

**16:11** "I decked you also with ornaments, and I put bracelets upon your hands, and a chain on your neck.

**16:12** "And I put a ring upon your nose, and earrings in your ears, and a beautiful crown upon your head.

**16:13** "Thus were you decked with gold and silver; and your raiment was of fine linen, and silk, and richly woven work; you did eat fine flour, and honey, and oil; and you were exceeding beautiful, and you did prosper into a kingdom.

**16:14** "And your renown went forth among the nations for your beauty; for it was perfect, through my splendor which I had put upon you," says the Lord YHWH.

---

## Jerusalem's Unfaithfulness (16:15-34)

**16:15** "But you did trust in your beauty, and played the harlot because of your renown, and did pour out your harlotries on every one that passed by; his it was.

**16:16** "And you did take of your garments, and did make for you high places decked with divers colors, and did play the harlot upon them; the like things shall not come, neither shall it be so.

**16:17** "You did also take your fair jewels of my gold and of my silver, which I had given you, and made for yourself images of men, and did play the harlot with them;

**16:18** "And you did take your richly woven garments, and did cover them, and did set my oil and my incense before them.

**16:19** "My bread also which I gave you, fine flour, and oil, and honey, wherewith I fed you, you did even set it before them for a sweet savor; and thus it was," says the Lord YHWH.

**16:20** "Moreover you have taken your sons and your daughters, whom you have borne unto me, and these have you sacrificed unto them to be devoured. Were your harlotries a small matter,

**16:21** "That you have slain my children, and delivered them up, in setting them apart unto them?

**16:22** "And in all your abominations and your harlotries you have not remembered the days of your youth, when you were naked and bare, and were wallowing in your blood.

**16:23** "And it came to pass after all your wickedness—woe, woe unto you! says the Lord YHWH—

**16:24** "That you have built unto yourself an eminent place, and have made yourself a lofty place in every street.

**16:25** "You have built your lofty place at every head of the way, and have made your beauty an abomination, and have opened your feet to every one that passed by, and multiplied your harlotry.

**16:26** "You have also played the harlot with the Egyptians, your neighbors, great of flesh; and have multiplied your harlotry, to provoke me.

**16:27** "Behold, therefore I have stretched out my hand over you, and have diminished your allowance, and delivered you unto the will of them that hate you, the daughters of the Philistines, that are ashamed of your lewd way.

**16:28** "You have played the harlot also with the Assyrians, without having enough; yea, you have played the harlot with them, and yet you were not satisfied.

**16:29** "You have moreover multiplied your harlotry with the land of traffic, even with Chaldea; and yet you were not satisfied herewith.

**16:30** "How weak is your heart," says the Lord YHWH, "seeing you do all these things, the work of a wanton harlot;

**16:31** "In that you build your eminent place in the head of every way, and make your lofty place in every street; and have not been as a harlot, in that you scorn hire.

**16:32** "You wife that commits adultery, that takes strangers instead of her husband!

**16:33** "To all harlots gifts are given; but you have given your gifts to all your lovers, and have bribed them to come unto you from every side in your harlotries.

**16:34** "And the contrary is in you from other women in your harlotries, in that none follows you to play the harlot; and whereas you give hire, and no hire is given unto you, therefore you are contrary."

---

## Jerusalem's Judgment (16:35-43)

**16:35** Wherefore, O harlot, hear the word of YHWH:

**16:36** Thus says the Lord YHWH: "Because your filthiness was poured out, and your nakedness uncovered through your harlotries with your lovers; and because of all the idols of your abominations, and for the blood of your children, that you did give unto them;

**16:37** "Therefore, behold, I will gather all your lovers, unto whom you have been pleasant, and all them that you have loved, with all them that you have hated; I will even gather them against you on every side, and will uncover your nakedness unto them, that they may see all your nakedness.

**16:38** "And I will judge you, as women that break wedlock and shed blood are judged; and I will bring upon you the blood of fury and jealousy.

**16:39** "I will also give you into their hand, and they shall throw down your eminent place, and break down your lofty places; and they shall strip you of your clothes, and take your fair jewels; and they shall leave you naked and bare.

**16:40** "They shall also bring up an assembly against you, and they shall stone you with stones, and thrust you through with their swords.

**16:41** "And they shall burn your houses with fire, and execute judgments upon you in the sight of many women; and I will cause you to cease from playing the harlot, and you shall also give no hire any more.

**16:42** "So will I satisfy my fury upon you, and my jealousy shall depart from you, and I will be quiet, and will be no more angry.

**16:43** "Because you have not remembered the days of your youth, but have raged against me in all these things; therefore, behold, I also will bring your way upon your head," says the Lord YHWH; "and you shall not commit this lewdness above all your abominations."

---

## Worse Than Sodom and Samaria (16:44-52)

**16:44** "Behold, every one that uses proverbs shall use this proverb against you, saying: 'As the mother, so her daughter.'

**16:45** "You are your mother's daughter, that loathes her husband and her children; and you are the sister of your sisters, who loathed their husbands and their children; your mother was a Hittite, and your father an Amorite.

**16:46** "And your elder sister is Samaria, that dwells at your left hand, she and her daughters; and your younger sister, that dwells at your right hand, is Sodom and her daughters.

**16:47** "Yet have you not walked in their ways, nor done after their abominations; but in a very little while you did more corruptly than they in all your ways.

**16:48** "As I live," says the Lord YHWH, "Sodom your sister has not done, she nor her daughters, as you have done, you and your daughters.

**16:49** "Behold, this was the iniquity of your sister Sodom: pride, fulness of bread, and careless ease was in her and in her daughters; neither did she strengthen the hand of the poor and needy.

**16:50** "And they were haughty, and committed abomination before me; therefore I removed them when I saw it.

**16:51** "Neither has Samaria committed even half of your sins; but you have multiplied your abominations more than they, and have justified your sisters by all your abominations which you have done.

**16:52** "You also, bear your own shame, in that you have given judgment for your sisters; through your sins that you have committed more abominable than they, they are more righteous than you; yea, be also confounded, and bear your shame, in that you have justified your sisters."

---

## Restoration of All (16:53-63)

**16:53** "And I will turn their captivity, the captivity of Sodom and her daughters, and the captivity of Samaria and her daughters, and the captivity of your captives in the midst of them;

**16:54** "That you may bear your own shame, and may be confounded in all that you have done, in that you are a comfort unto them.

**16:55** "And your sisters, Sodom and her daughters, shall return to their former estate, and Samaria and her daughters shall return to their former estate, and you and your daughters shall return to your former estate.

**16:56** "For your sister Sodom was not mentioned by your mouth in the day of your pride;

**16:57** "Before your wickedness was uncovered, as at the time of the reproach of the daughters of Aram, and of all that are round about her, the daughters of the Philistines, that have you in disdain on every side.

**16:58** "You have borne your lewdness and your abominations," says YHWH.

**16:59** "For thus says the Lord YHWH: I will even deal with you as you have done, who have despised the oath in breaking the covenant.

**16:60** "Nevertheless I will remember my covenant with you in the days of your youth, and I will establish unto you an everlasting covenant.

**16:61** "Then shall you remember your ways, and be ashamed, when you shall receive your sisters, your elder sisters and your younger; and I will give them unto you for daughters, but not by your covenant.

**16:62** "And I will establish my covenant with you; and you shall know that I am YHWH;

**16:63** "That you may remember, and be confounded, and never open your mouth any more, because of your shame; when I have forgiven you all that you have done," says the Lord YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Jerusalem's Origins (16:1-14):**
"'Your origin and your nativity is of the land of the Canaanite.'"

*Mekhorotayikh u-moladotayikh me-eretz ha-Kena'ani*—Canaanite origin.

"'The Amorite was your father, and your mother was a Hittite.'"

*Avikh ha-Emori ve-immekh Chittit*—Amorite/Hittite.

"'You were cast out in the open field.'"

*Va-tushlikhi el-penei ha-sadeh*—abandoned.

**The Key Verse (16:6):**
"'I passed by you, and saw you wallowing in your blood.'"

*Va-e'evor alayikh va-er'ekh mitboseset be-damayikh*—in blood.

"'I said unto you: In your blood, live.'"

*Va-omar lakh be-damayikh chayi*—live.

**The Key Verse (16:8):**
"'Your time was the time of love.'"

*Et dodim*—time of love.

"'I spread my skirt over you, and covered your nakedness.'"

*Va-efros kenafi alayikh va-akhasseh ervatekh*—marriage.

"'I swore unto you, and entered into a covenant with you.'"

*Va-eshava lakh va-avo vi-verit otakh*—covenant.

"'You became mine.'"

*Va-tihyi li*—became mine.

**The Key Verses (16:9-14):**
"'I clothed you... decked you... put bracelets... a crown.'"

*Va-albishshekh... va-e'edekh... va-ettnah... ateret*—adorned.

"'You were exceeding beautiful.'"

*Va-tippi le-me'od me'od*—exceedingly beautiful.

"'You did prosper into a kingdom.'"

*Va-titzzelechi li-melukhah*—became kingdom.

"'Your renown went forth among the nations for your beauty.'"

*Va-yetze lakh shem ba-goyim be-yofyekh*—renowned.

"'It was perfect, through my splendor which I had put upon you.'"

*Ki kalil hu be-hadari asher-samti alayikh*—my splendor.

**Unfaithfulness (16:15-34):**
"'You did trust in your beauty, and played the harlot.'"

*Va-tivtechi ve-yofyekh va-tizni al-shemekh*—trusted beauty.

"'Did pour out your harlotries on every one that passed by.'"

*Va-tishpekhi et-taznuwtayikh al-kol-over*—harlotries.

"'Made for yourself images of men, and did play the harlot with them.'"

*Va-ta'asi lakh tzalmei zakhar va-tizni vam*—male images.

**The Key Verses (16:20-21):**
"'You have taken your sons and your daughters... and these have you sacrificed unto them.'"

*Va-tiqqechi et-banayikh ve-et-benotayikh... va-tizbechiم lahem*—child sacrifice.

"'You have slain my children.'"

*Va-tishchati et-banai*—slain my children.

**The Key Verse (16:32):**
"'You wife that commits adultery, that takes strangers instead of her husband!'"

*Ha-ishah ha-mena'afet tachat ishah tiqqach et-zarim*—adulteress.

**The Key Verse (16:34):**
"'You give hire, and no hire is given unto you.'"

*U-ve-tittkekh etnan ve-etnan lo nittan-lakh*—pays lovers.

**Judgment (16:35-43):**
"'I will gather all your lovers... against you.'"

*Hineni meqabbetz et-kol-me'ahavayikh... alayikh mi-saviv*—gather lovers.

"'Will uncover your nakedness unto them.'"

*Ve-gilleti ervatekh aleihem*—uncover.

"'I will judge you, as women that break wedlock and shed blood are judged.'"

*U-shefattkikh mishpetei no'afot ve-shofkhot dam*—judged.

"'They shall stone you with stones.'"

*Ve-ragemu otakh even*—stoned.

"'Thrust you through with their swords.'"

*U-vittequ otakh be-charvotam*—thrust through.

**Worse Than Sodom (16:44-52):**
"'As the mother, so her daughter.'"

*Ke-immah bittah*—like mother.

"'Your elder sister is Samaria... your younger sister... is Sodom.'"

*Achotkekh ha-gedolah Shomeron... va-achotkekh ha-qetannah... Sedom*—sisters.

**The Key Verse (16:49):**
"'This was the iniquity of your sister Sodom.'"

*Hinneh zeh hayah avon Sedom achotkekh*—Sodom's sin.

"'Pride, fulness of bread, and careless ease.'"

*Ga'on sive'at-lechem ve-shalvat hashqet*—pride, plenty, ease.

"'Neither did she strengthen the hand of the poor and needy.'"

*Ve-yad-ani ve-evyon lo hecheziqah*—didn't help poor.

**The Key Verse (16:51):**
"'You have multiplied your abominations more than they.'"

*Va-tarbi et-to'avotayikh me-hennah*—more abominations.

"'Have justified your sisters.'"

*Va-ttzaddeqi et-achotayikh*—justified sisters.

**Restoration (16:53-63):**
"'I will turn their captivity.'"

*Ve-shavti et-shevutan*—restore.

**The Key Verse (16:60):**
"'I will remember my covenant with you in the days of your youth.'"

*Ve-zakharti ani et-beriti otakh bi-ymei ne'urayikh*—remember covenant.

"'I will establish unto you an everlasting covenant.'"

*Va-haqimoti lakh berit olam*—everlasting covenant.

**The Key Verse (16:63):**
"'That you may remember, and be confounded.'"

*Lema'an tizkeri u-vosht*—remember, be ashamed.

"'Never open your mouth any more, because of your shame.'"

*Ve-lo yihyeh-lakh od pitchon-peh mippenei kelimmatekh*—silent shame.

"'When I have forgiven you all that you have done.'"

*Be-khapperi-lakh le-khol-asher asit*—forgiven.

**Archetypal Layer:** Ezekiel 16 is the **extended allegory of Jerusalem as unfaithful wife**, containing **"In your blood, live" (16:6)**, **"I spread my skirt over you" (16:8)**, **child sacrifice (16:20-21)**, **"Sodom your sister has not done... as you have done" (16:48)**, **Sodom's sin was "pride, fulness of bread... neither did she strengthen the hand of the poor" (16:49)**, and **"I will establish unto you an everlasting covenant" (16:60)**.

**Ethical Inversion Applied:**
- "'Your origin... is of the land of the Canaanite'"—Canaanite origin
- "'The Amorite was your father... mother was a Hittite'"—mixed heritage
- "'You were cast out in the open field'"—abandoned infant
- "'I passed by you, and saw you wallowing in your blood'"—found
- "'I said unto you: In your blood, live'"—gave life
- "'Your time was the time of love'"—time of love
- "'I spread my skirt over you'"—marriage proposal
- "'I swore unto you, and entered into a covenant'"—covenant
- "'You became mine'"—became mine
- "'I clothed you... decked you... a crown'"—adorned
- "'You were exceeding beautiful'"—beautiful
- "'Your renown went forth among the nations'"—renowned
- "'It was perfect, through my splendor'"—my splendor
- "'You did trust in your beauty, and played the harlot'"—trusted beauty
- "'Made for yourself images of men'"—idols
- "'You have taken your sons... sacrificed unto them'"—child sacrifice
- "'You have slain my children'"—slain children
- "'You wife that commits adultery'"—adulteress
- "'You give hire, and no hire is given unto you'"—pays lovers
- "'I will gather all your lovers... against you'"—lovers judge
- "'Will uncover your nakedness unto them'"—exposed
- "'They shall stone you with stones'"—stoning
- "'As the mother, so her daughter'"—proverb
- "'Your elder sister is Samaria... younger sister... is Sodom'"—sisters
- "'This was the iniquity of your sister Sodom'"—Sodom's sin
- "'Pride, fulness of bread, and careless ease'"—pride, plenty
- "'Neither did she strengthen the hand of the poor'"—didn't help poor
- "'You have multiplied your abominations more than they'"—worse
- "'Have justified your sisters'"—made them look righteous
- "'I will remember my covenant with you'"—remember
- "'I will establish unto you an everlasting covenant'"—eternal covenant
- "'When I have forgiven you all that you have done'"—forgiveness

**Modern Equivalent:** Ezekiel 16 is the longest chapter, depicting Jerusalem as foundling-turned-bride-turned-harlot. Verse 49's definition of Sodom's sin (pride, plenty, not helping poor) challenges popular assumptions. The chapter ends with grace—an everlasting covenant despite unfaithfulness.

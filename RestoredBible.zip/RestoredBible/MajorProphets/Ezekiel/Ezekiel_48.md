# Ezekiel 48: The Division of the Land and the City — YHWH Is There

*From the Hebrew: וְאֵלֶּה שְׁמוֹת הַשְּׁבָטִים (Ve-Elleh Shemot Ha-Shevatim) — And These Are the Names of the Tribes*

---

## The Northern Tribes (48:1-7)

**48:1** Now these are the names of the tribes: from the north end, beside the way of Hethlon to the entrance of Hamath, Hazar-enan at the border of Damascus, northward beside Hamath; and they shall have their sides east and west: Dan, one portion.

**48:2** And by the border of Dan, from the east side unto the west side: Asher, one portion.

**48:3** And by the border of Asher, from the east side even unto the west side: Naphtali, one portion.

**48:4** And by the border of Naphtali, from the east side unto the west side: Manasseh, one portion.

**48:5** And by the border of Manasseh, from the east side unto the west side: Ephraim, one portion.

**48:6** And by the border of Ephraim, from the east side even unto the west side: Reuben, one portion.

**48:7** And by the border of Reuben, from the east side unto the west side: Judah, one portion.

---

## The Holy Portion (48:8-22)

**48:8** And by the border of Judah, from the east side unto the west side, shall be the offering which you shall set apart, five and twenty thousand reeds in breadth, and in length as one of the portions, from the east side unto the west side; and the sanctuary shall be in the midst of it.

**48:9** The offering that you shall set apart unto YHWH shall be five and twenty thousand reeds in length, and ten thousand in breadth.

**48:10** And for these, even for the priests, shall be the holy offering: toward the north five and twenty thousand in length, and toward the west ten thousand in breadth, and toward the east ten thousand in breadth, and toward the south five and twenty thousand in length; and the sanctuary of YHWH shall be in the midst thereof.

**48:11** It shall be for the priests that are sanctified of the sons of Zadok, that have kept my charge; that went not astray when the children of Israel went astray, as the Levites went astray.

**48:12** And it shall be unto them a portion set apart out of the offering of the land, a thing most holy, by the border of the Levites.

**48:13** And answerable unto the border of the priests, the Levites shall have five and twenty thousand in length, and ten thousand in breadth; all the length shall be five and twenty thousand, and the breadth ten thousand.

**48:14** And they shall not sell of it, neither exchange, nor may the first portion of the land be alienated; for it is holy unto YHWH.

**48:15** And the five thousand that are left in the breadth, in front of the five and twenty thousand, shall be for common use, for the city, for dwelling and for open land; and the city shall be in the midst thereof.

**48:16** And these shall be the measures thereof: the north side four thousand and five hundred, and the south side four thousand and five hundred, and on the east side four thousand and five hundred, and the west side four thousand and five hundred.

**48:17** And the city shall have open land: toward the north two hundred and fifty, and toward the south two hundred and fifty, and toward the east two hundred and fifty, and toward the west two hundred and fifty.

**48:18** And the residue in the length, answerable unto the holy offering, shall be ten thousand eastward, and ten thousand westward; and it shall be answerable unto the holy offering; and the increase thereof shall be for food unto them that serve the city.

**48:19** And they that serve the city, out of all the tribes of Israel, shall till it.

**48:20** All the offering shall be five and twenty thousand by five and twenty thousand; you shall set apart the holy offering foursquare, with the possession of the city.

**48:21** And the residue shall be for the prince, on the one side and on the other of the holy offering and of the possession of the city, in front of the five and twenty thousand of the offering toward the east border, and westward in front of the five and twenty thousand toward the west border, answerable unto the portions, it shall be for the prince; and the holy offering and the sanctuary of the house shall be in the midst thereof.

**48:22** And from the possession of the Levites, and from the possession of the city, being in the midst of that which is the prince's, between the border of Judah and the border of Benjamin, it shall be for the prince.

---

## The Southern Tribes (48:23-29)

**48:23** And as for the rest of the tribes: from the east side unto the west side: Benjamin, one portion.

**48:24** And by the border of Benjamin, from the east side unto the west side: Simeon, one portion.

**48:25** And by the border of Simeon, from the east side unto the west side: Issachar, one portion.

**48:26** And by the border of Issachar, from the east side unto the west side: Zebulun, one portion.

**48:27** And by the border of Zebulun, from the east side unto the west side: Gad, one portion.

**48:28** And by the border of Gad, at the south side southward, the border shall be even from Tamar unto the waters of Meribath-kadesh, to the Brook of Egypt, unto the Great Sea.

**48:29** This is the land which you shall divide by lot unto the tribes of Israel for inheritance, and these are their several portions, says the Lord YHWH.

---

## The Gates of the City (48:30-35)

**48:30** And these are the goings out of the city: on the north side four thousand and five hundred by measure;

**48:31** And the gates of the city shall be after the names of the tribes of Israel; three gates northward: the gate of Reuben, one; the gate of Judah, one; the gate of Levi, one.

**48:32** And at the east side four thousand and five hundred; and three gates: even the gate of Joseph, one; the gate of Benjamin, one; the gate of Dan, one.

**48:33** And at the south side four thousand and five hundred by measure; and three gates: the gate of Simeon, one; the gate of Issachar, one; the gate of Zebulun, one.

**48:34** At the west side four thousand and five hundred, with their three gates: the gate of Gad, one; the gate of Asher, one; the gate of Naphtali, one.

**48:35** It shall be eighteen thousand round about. And the name of the city from that day shall be: YHWH Is There.

---

## Synthesis Notes

**Key Restorations:**

**Northern Tribes (48:1-7):**
**The Key Verse (48:1):**
"These are the names of the tribes."

*Ve-elleh shemot ha-shevatim*—names of tribes.

"From the north end, beside the way of Hethlon to the entrance of Hamath."

*Mi-qetzeh tzafonah el-yad derekh Chetlon levo Chamat*—north border.

"Hazar-enan at the border of Damascus, northward beside Hamath."

*Chattzar Enan gevul Dammeseq tzafonah el-yad Chamat*—Hazar-enan.

"They shall have their sides east and west."

*Ve-hayu-lo fe'at-qadim ha-yam*—east to west.

"Dan, one portion."

*Dan echad*—Dan.

**Northern Seven Tribes:**
1. Dan (48:1)
2. Asher (48:2)
3. Naphtali (48:3)
4. Manasseh (48:4)
5. Ephraim (48:5)
6. Reuben (48:6)
7. Judah (48:7)

**Holy Portion (48:8-22):**
**The Key Verse (48:8):**
"By the border of Judah... shall be the offering which you shall set apart."

*Ve-al gevul Yehudah... tihyeh ha-terumah asher tarimu*—holy offering.

"Five and twenty thousand reeds in breadth."

*Chamishah ve-esrim elef rochav*—25,000 breadth.

"In length as one of the portions, from the east side unto the west side."

*Ve-orekh ke-achad ha-chalaqim mi-pe'at qadim ad-pe'at-yamah*—like tribal portion.

"The sanctuary shall be in the midst of it."

*Ve-hayah ha-miqdash be-tokho*—sanctuary in midst.

**The Key Verses (48:9-12):**
"The offering... shall be five and twenty thousand reeds in length, and ten thousand in breadth."

*Ha-terumah... orekh chamishah ve-esrim elef ve-rochav aseret alafim*—25,000 x 10,000.

"For the priests, shall be the holy offering."

*U-le-elleh tihyeh terumat-qodesh la-kohanim*—for priests.

"The sanctuary of YHWH shall be in the midst thereof."

*U-miqdash YHWH be-tokho*—sanctuary in midst.

"For the priests that are sanctified of the sons of Zadok."

*La-kohanim ha-mequddashim mi-benei Tzadoq*—Zadokite priests.

"That have kept my charge."

*Asher shameru mishmarti*—kept charge.

"That went not astray when the children of Israel went astray."

*Asher lo-ta'u bi-te'ot benei Yisra'el*—didn't stray.

"As the Levites went astray."

*Ka-asher ta'u ha-Leviyyim*—Levites strayed.

"It shall be unto them a portion set apart out of the offering of the land."

*Ve-hayetah lahem terumah mi-terumat ha-aretz*—set apart.

"A thing most holy, by the border of the Levites."

*Qodesh qodashim el-gevul ha-Leviyyim*—most holy.

**The Key Verses (48:13-14):**
"The Levites shall have five and twenty thousand in length, and ten thousand in breadth."

*Ve-ha-Leviyyim le'ummat gevul ha-kohanim chamishah ve-esrim elef orekh ve-rochav aseret alafim*—25,000 x 10,000.

"They shall not sell of it, neither exchange."

*Ve-lo-yimkeru mimmennnu ve-lo yamir*—not sell, exchange.

"Nor may the first portion of the land be alienated."

*Ve-lo ya'avor reshit ha-aretz*—not alienate.

"For it is holy unto YHWH."

*Ki-qodesh la-YHWH*—holy.

**The Key Verses (48:15-20):**
"The five thousand that are left in the breadth... shall be for common use."

*Ve-chamishshet alafim ha-notar ba-rochav... chol hu*—common use.

"For the city, for dwelling and for open land."

*La-ir le-moshav u-le-migrash*—city, dwelling.

"The city shall be in the midst thereof."

*Ve-ha-ir be-tokho*—city in midst.

"These shall be the measures thereof: the north side four thousand and five hundred."

*Ve-elleh middoteyha pe'at tzafon chamesh me'ot ve-arba'at alafim*—4,500 each side.

"The city shall have open land: toward the north two hundred and fifty."

*U-migrash la-ir tzafon chamishshim u-matayim*—250 buffer.

"They that serve the city, out of all the tribes of Israel, shall till it."

*Ve-ha-oved ha-ir ya'avduhu mi-kol shivtei Yisra'el*—all tribes serve.

"All the offering shall be five and twenty thousand by five and twenty thousand."

*Kol-ha-terumah chamishah ve-esrim elef ba-chamishah ve-esrim elef*—25,000 x 25,000.

"You shall set apart the holy offering foursquare."

*Revi'it tarimu et-terumat ha-qodesh*—foursquare.

"With the possession of the city."

*El-achuzzat ha-ir*—with city.

**The Key Verses (48:21-22):**
"The residue shall be for the prince."

*Ve-ha-notar la-nasi*—for prince.

"On the one side and on the other of the holy offering and of the possession of the city."

*Mi-zeh u-mi-zeh li-terumat ha-qodesh ve-la-achuzzat ha-ir*—flanking.

"The holy offering and the sanctuary of the house shall be in the midst thereof."

*U-terumat ha-qodesh u-miqdash ha-bayit be-tokho*—in midst.

"From the possession of the Levites, and from the possession of the city... between the border of Judah and the border of Benjamin, it shall be for the prince."

*U-me-achuzzat ha-Leviyyim u-me-achuzzat ha-ir be-tokh asher la-nasi yihyeh bein gevul Yehudah u-vein gevul Binyamin la-nasi yihyeh*—between Judah and Benjamin.

**Southern Tribes (48:23-29):**
**Southern Five Tribes:**
1. Benjamin (48:23)
2. Simeon (48:24)
3. Issachar (48:25)
4. Zebulun (48:26)
5. Gad (48:27)

**The Key Verse (48:28):**
"By the border of Gad, at the south side southward."

*Ve-al gevul Gad el-pe'at negev teimanah*—south border.

"The border shall be even from Tamar unto the waters of Meribath-kadesh."

*Ve-hayah gevul mi-Tamar mei Merivat Qadesh*—Tamar to Meribah.

"To the Brook of Egypt, unto the Great Sea."

*Nachlah el-ha-yam ha-gadol*—to Mediterranean.

**The Key Verse (48:29):**
"This is the land which you shall divide by lot unto the tribes of Israel for inheritance."

*Zot ha-aretz asher tappilu nachalah le-shivtei Yisra'el*—divide by lot.

"These are their several portions."

*Ve-elleh machlequotam*—portions.

**Gates of the City (48:30-35):**
**The Key Verses (48:30-34):**
"These are the goings out of the city: on the north side four thousand and five hundred."

*Ve-elleh totza'ot ha-ir mi-pe'at tzafon chamishshah ve-arba'at alafim middah*—north 4,500.

"The gates of the city shall be after the names of the tribes of Israel."

*Ve-sha'arei ha-ir al-shemot shivtei Yisra'el*—tribal names.

"Three gates northward: the gate of Reuben, one; the gate of Judah, one; the gate of Levi, one."

*She'arim shalosh tzafonah sha'ar Re'uven echad sha'ar Yehudah echad sha'ar Levi echad*—Reuben, Judah, Levi.

"At the east side four thousand and five hundred; and three gates: even the gate of Joseph, one; the gate of Benjamin, one; the gate of Dan, one."

*U-fe'at qadimah... sha'ar Yosef echad sha'ar Binyamin echad sha'ar Dan echad*—Joseph, Benjamin, Dan.

"At the south side four thousand and five hundred... three gates: the gate of Simeon, one; the gate of Issachar, one; the gate of Zebulun, one."

*U-fe'at negbah... sha'ar Shim'on echad sha'ar Yissakhar echad sha'ar Zevulun echad*—Simeon, Issachar, Zebulun.

"At the west side four thousand and five hundred, with their three gates: the gate of Gad, one; the gate of Asher, one; the gate of Naphtali, one."

*U-fe'at-yamah... sha'ar Gad echad sha'ar Asher echad sha'ar Naftali echad*—Gad, Asher, Naphtali.

**12 Gates:**
- North: Reuben, Judah, Levi
- East: Joseph, Benjamin, Dan
- South: Simeon, Issachar, Zebulun
- West: Gad, Asher, Naphtali

**The Key Verse (48:35):**
"It shall be eighteen thousand round about."

*Saviv shemonah asar elef*—18,000 circumference.

"And the name of the city from that day shall be: **YHWH Is There**."

*Ve-shem-ha-ir mi-yom YHWH Shammah*—YHWH Shammah.

**YHWH Shammah:**
The climactic final words of Ezekiel—"YHWH Is There."

**Archetypal Layer:** Ezekiel 48 concludes the temple vision, containing **7 northern tribes (48:1-7)**, **the holy portion with priests' and Levites' land (48:8-14)**, **the city portion (48:15-20)**, **the prince's land (48:21-22)**, **5 southern tribes (48:23-29)**, **12 gates named for the 12 tribes (48:30-34)**, and **the book's climactic conclusion: "The name of the city from that day shall be: YHWH Shammah (YHWH Is There)" (48:35)**.

**Ethical Inversion Applied:**
- "These are the names of the tribes"—tribal allocation
- "Dan, one portion"—Dan
- "Asher, one portion"—Asher
- "Naphtali, one portion"—Naphtali
- "Manasseh, one portion"—Manasseh
- "Ephraim, one portion"—Ephraim
- "Reuben, one portion"—Reuben
- "Judah, one portion"—Judah
- "By the border of Judah... shall be the offering"—holy offering
- "The sanctuary shall be in the midst of it"—sanctuary in center
- "For the priests that are sanctified of the sons of Zadok"—Zadokites
- "That have kept my charge"—kept charge
- "That went not astray... as the Levites went astray"—faithful
- "A thing most holy"—most holy
- "The Levites shall have five and twenty thousand in length"—Levites' portion
- "They shall not sell of it, neither exchange"—inalienable
- "For it is holy unto YHWH"—holy
- "The five thousand... shall be for common use"—common
- "For the city, for dwelling"—city
- "They that serve the city, out of all the tribes of Israel"—all serve
- "All the offering shall be five and twenty thousand by five and twenty thousand"—25,000 x 25,000
- "The residue shall be for the prince"—prince's land
- "The holy offering and the sanctuary... in the midst"—centered
- "Between the border of Judah and the border of Benjamin"—between
- "Benjamin, one portion"—Benjamin
- "Simeon, one portion"—Simeon
- "Issachar, one portion"—Issachar
- "Zebulun, one portion"—Zebulun
- "Gad, one portion"—Gad
- "This is the land which you shall divide by lot"—divide
- "The gates of the city shall be after the names of the tribes"—tribal gates
- "The gate of Reuben, one; the gate of Judah, one; the gate of Levi, one"—north gates
- "The gate of Joseph, one; the gate of Benjamin, one; the gate of Dan, one"—east gates
- "The gate of Simeon, one; the gate of Issachar, one; the gate of Zebulun, one"—south gates
- "The gate of Gad, one; the gate of Asher, one; the gate of Naphtali, one"—west gates
- "It shall be eighteen thousand round about"—18,000 circumference
- "**The name of the city from that day shall be: YHWH Shammah**"—YHWH Is There

**Modern Equivalent:** Ezekiel 48 concludes with land division and the city's 12 gates (echoed in Revelation 21:12). The tribes are reorganized: 7 north of the holy portion, 5 south. The arrangement is idealized, not historical. The book ends with "YHWH Shammah"—"YHWH Is There"—reversing the glory's departure (chapters 10-11) and fulfilling the promise of permanent divine presence.

# Ezekiel 9: The Slaughter in the Temple

*From the Hebrew: וַיִּקְרָא בְאָזְנַי קוֹל גָּדוֹל (Va-Yiqra Ve-Oznai Qol Gadol) — And He Cried in My Ears with a Loud Voice*

---

## The Six Executioners (9:1-2)

**9:1** Then he cried in my ears with a loud voice, saying: "Cause them that have charge over the city to draw near, every man with his destroying weapon in his hand."

**9:2** And, behold, six men came from the way of the upper gate, which lies toward the north, every man with his weapon of slaughter in his hand; and one man in the midst of them clothed in linen, with a writer's inkhorn at his side; and they went in, and stood beside the brazen altar.

---

## The Glory Departs (9:3-4)

**9:3** And the glory of the God of Israel was gone up from the cherub, whereupon it was, to the threshold of the house; and he called to the man clothed in linen, who had the writer's inkhorn at his side.

**9:4** And YHWH said unto him: "Go through the midst of the city, through the midst of Jerusalem, and set a mark upon the foreheads of the men that sigh and that cry for all the abominations that are done in the midst thereof."

---

## The Slaughter Begins (9:5-7)

**9:5** And to the others he said in my hearing: "Go through the city after him, and smite; let not your eye spare, neither have pity;

**9:6** "Slay utterly the old man, the young man and the maiden, and little children and women; but come not near any man upon whom is the mark; and begin at my sanctuary." Then they began at the elders that were before the house.

**9:7** And he said unto them: "Defile the house, and fill the courts with the slain; go forth." And they went forth, and smote in the city.

---

## Ezekiel's Intercession (9:8-11)

**9:8** And it came to pass, while they were smiting, and I was left, that I fell upon my face, and cried, and said: "Ah Lord YHWH! Will you destroy all the residue of Israel in your pouring out of your fury upon Jerusalem?"

**9:9** Then said he unto me: "The iniquity of the house of Israel and Judah is exceeding great, and the land is full of blood, and the city full of wresting of judgment; for they say: 'YHWH has forsaken the land, and YHWH sees not.'

**9:10** "And as for me also, my eye shall not spare, neither will I have pity, but I will bring their way upon their head."

**9:11** And, behold, the man clothed in linen, who had the inkhorn at his side, reported, saying: "I have done according to all that you have commanded me."

---

## Synthesis Notes

**Key Restorations:**

**Six Executioners (9:1-2):**
**The Key Verse (9:1):**
"He cried in my ears with a loud voice."

*Va-yiqra ve-oznai qol gadol*—loud voice.

"'Cause them that have charge over the city to draw near.'"

*Qarevu pequddot ha-ir*—city executioners.

"'Every man with his destroying weapon in his hand.'"

*Ve-ish keli mashcheto be-yado*—destroying weapons.

**The Key Verse (9:2):**
"Six men came from the way of the upper gate."

*Ve-hinneh shishah anashim ba'im mi-derekh-sha'ar ha-elyon*—6 men.

"Which lies toward the north."

*Asher mofneh tzafonah*—from north.

"Every man with his weapon of slaughter in his hand."

*Ve-ish keli mappatzto be-yado*—slaughter weapons.

"One man in the midst of them clothed in linen."

*Ve-ish-echad be-tokham lavush baddim*—linen-clothed man.

"With a writer's inkhorn at his side."

*Ve-qeset ha-sofer be-motnav*—inkhorn.

"They went in, and stood beside the brazen altar."

*Va-yavo'u va-ya'amdu etzel mizbach ha-nechoshet*—at bronze altar.

**Seven Figures:**
Six executioners plus one scribe—seven heavenly beings.

**Glory Departs (9:3-4):**
**The Key Verse (9:3):**
"The glory of the God of Israel was gone up from the cherub."

*U-khevod Elohei Yisra'el na'alah me-al ha-keruv*—glory rose.

"Whereupon it was."

*Asher hayah alav*—where it had been.

"To the threshold of the house."

*El miftan ha-bayit*—to threshold.

"He called to the man clothed in linen."

*Va-yiqra el-ha-ish ha-lavush ha-baddim*—called linen man.

**Glory Movement:**
First stage of YHWH's departure—from cherubim to threshold.

**The Key Verse (9:4):**
"'Go through the midst of the city, through the midst of Jerusalem.'"

*Avor be-tokh ha-ir be-tokh Yerushalayim*—through city.

"'Set a mark upon the foreheads.'"

*Ve-hitvita tav al-mitzchot*—mark foreheads.

"'Of the men that sigh and that cry.'"

*Ha-anashim ha-ne'enachim ve-ha-ne'enaqim*—those who sigh and cry.

"'For all the abominations that are done in the midst thereof.'"

*Al kol-ha-to'avot ha-na'asot be-tokhah*—for abominations.

**The Mark (Tav):**
The letter *tav* (ת)—last letter of Hebrew alphabet. In ancient script, it was shaped like an X or +. Those marked are protected.

**Slaughter (9:5-7):**
**The Key Verse (9:5):**
"'Go through the city after him, and smite.'"

*Ivru va-ir acharav ve-hakku*—follow and smite.

"'Let not your eye spare, neither have pity.'"

*Al-tachos einekhem ve-al-tachomolu*—no sparing.

**The Key Verse (9:6):**
"'Slay utterly the old man, the young man and the maiden.'"

*Zaqen bachur u-vetulah*—all ages.

"'And little children and women.'"

*Ve-taf ve-nashim taharegu le-mashchit*—children, women.

"'But come not near any man upon whom is the mark.'"

*Ve-al-kol-ish asher-alav ha-tav al-tiggashu*—don't touch marked.

"'Begin at my sanctuary.'"

*U-mi-miqdashi tachelu*—begin at sanctuary.

"They began at the elders that were before the house."

*Va-yachelu ba-anashim ha-zeqenim asher lifnei ha-bayit*—began with elders.

**Judgment Begins at Sanctuary:**
1 Peter 4:17 echoes this—judgment begins at God's house.

**The Key Verse (9:7):**
"'Defile the house.'"

*Tamme'u et-ha-bayit*—defile house.

"'Fill the courts with the slain.'"

*U-malle'u et-ha-chatzerot challalim*—fill with slain.

"'Go forth.'"

*Tze'u*—go forth.

"They went forth, and smote in the city."

*Va-yatze'u ve-hikku va-ir*—smote in city.

**Ezekiel's Intercession (9:8-11):**
**The Key Verse (9:8):**
"While they were smiting, and I was left."

*Va-yehi ke-hakkotam ve-nish'arti ani*—I was left.

"I fell upon my face, and cried."

*Va-eppelah al-panai va-ezaq*—fell, cried.

"'Ah Lord YHWH!'"

*Ahahh Adonai YHWH*—Ah Lord!

"'Will you destroy all the residue of Israel?'"

*Ha-mashchit attah et kol-she'erit Yisra'el*—destroy remnant?

"'In your pouring out of your fury upon Jerusalem?'"

*Be-shofkekha et-chamatekha al-Yerushalayim*—pouring fury.

**The Key Verse (9:9):**
"'The iniquity of the house of Israel and Judah is exceeding great.'"

*Avon beit-Yisra'el vi-Yhudah gadol bi-me'od me'od*—exceeding great.

"'The land is full of blood.'"

*Va-timmale ha-aretz damim*—full of blood.

"'The city full of wresting of judgment.'"

*Ve-ha-ir male'ah muteh*—twisted justice.

"'For they say: YHWH has forsaken the land.'"

*Ki amru azav YHWH et-ha-aretz*—YHWH forsook.

"'YHWH sees not.'"

*Ve-ein YHWH ro'eh*—YHWH doesn't see.

**Same Claim:**
Repeats 8:12—they believed YHWH had abandoned them.

**The Key Verse (9:10):**
"'My eye shall not spare, neither will I have pity.'"

*Ve-gam-ani lo-tachos eini ve-lo echmol*—no sparing.

"'I will bring their way upon their head.'"

*Darkam be-rosham natatti*—way on head.

**The Key Verse (9:11):**
"The man clothed in linen... reported."

*Ve-hinneh ha-ish levush ha-baddim... meshiv davar*—reported.

"'I have done according to all that you have commanded me.'"

*Asiti ke-khol asher tzivvitani*—done as commanded.

**Archetypal Layer:** Ezekiel 9 contains **six executioners with destroying weapons (9:1-2)**, **one man in linen with an inkhorn (9:2)**, **"set a mark (*tav*) upon the foreheads of the men that sigh and that cry" (9:4)**, **"begin at my sanctuary" (9:6)**, and **Ezekiel's intercession "Will you destroy all the residue of Israel?" (9:8)**.

**Ethical Inversion Applied:**
- "He cried in my ears with a loud voice"—loud voice
- "'Cause them that have charge over the city to draw near'"—executioners
- "'Every man with his destroying weapon'"—destroying weapons
- "Six men came from the way of the upper gate"—6 from north
- "Every man with his weapon of slaughter"—slaughter weapons
- "One man in the midst of them clothed in linen"—linen-clothed
- "With a writer's inkhorn at his side"—inkhorn
- "They... stood beside the brazen altar"—at altar
- "The glory of the God of Israel was gone up from the cherub"—glory rises
- "To the threshold of the house"—to threshold
- "He called to the man clothed in linen"—called
- "'Go through the midst of the city'"—through city
- "'Set a mark upon the foreheads'"—mark foreheads
- "'Of the men that sigh and that cry'"—mourners
- "'For all the abominations that are done'"—for abominations
- "'Go through the city after him, and smite'"—smite
- "'Let not your eye spare, neither have pity'"—no sparing
- "'Slay utterly the old man, the young man and the maiden'"—all ages
- "'Little children and women'"—children, women
- "'Come not near any man upon whom is the mark'"—marked protected
- "'Begin at my sanctuary'"—begin at sanctuary
- "They began at the elders that were before the house"—began with elders
- "'Defile the house'"—defile
- "'Fill the courts with the slain'"—fill with slain
- "I fell upon my face, and cried"—intercession
- "'Will you destroy all the residue of Israel?'"—destroy remnant?
- "'The iniquity of the house of Israel and Judah is exceeding great'"—great iniquity
- "'The land is full of blood'"—blood-filled
- "'The city full of wresting of judgment'"—twisted justice
- "'YHWH has forsaken the land... YHWH sees not'"—false claim
- "'My eye shall not spare'"—no sparing
- "'I have done according to all that you have commanded me'"—done

**Modern Equivalent:** Ezekiel 9 shows divine judgment on Jerusalem. The protective mark (*tav*) on mourners' foreheads anticipates Revelation 7:3; 9:4. "Begin at my sanctuary" (9:6) shows judgment starts where sin is worst. Ezekiel's intercession (9:8) shows prophetic compassion but receives no reprieve.

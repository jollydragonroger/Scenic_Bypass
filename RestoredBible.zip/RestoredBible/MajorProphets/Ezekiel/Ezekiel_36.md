# Ezekiel 36: Restoration of the Mountains of Israel and New Heart

*From the Hebrew: וְאַתָּה בֶן־אָדָם הִנָּבֵא (Ve-Attah Ven-Adam Hinnave) — And You, Son of Man, Prophesy*

---

## Restoration of the Land (36:1-15)

**36:1** "And you, son of man, prophesy unto the mountains of Israel, and say: You mountains of Israel, hear the word of YHWH.

**36:2** "Thus says the Lord YHWH: Because the enemy has said against you: 'Aha!' and: 'The ancient high places are ours in possession';

**36:3** "Therefore prophesy, and say: Thus says the Lord YHWH: Because, even because they have made you desolate, and swallowed you up on every side, that you might be a possession unto the residue of the nations, and you are taken up in the lips of talkers, and the evil report of the people;

**36:4** "Therefore, you mountains of Israel, hear the word of the Lord YHWH: Thus says the Lord YHWH to the mountains and to the hills, to the watercourses and to the valleys, to the desolate wastes and to the cities that are forsaken, which are become a prey and derision to the residue of the nations that are round about;

**36:5** "Therefore thus says the Lord YHWH: Surely in the fire of my jealousy have I spoken against the residue of the nations, and against all Edom, that have appointed my land unto themselves for a possession with the joy of all their heart, with disdain of soul, to cast it out for a prey.

**36:6** "Therefore prophesy concerning the land of Israel, and say unto the mountains and to the hills, to the watercourses and to the valleys: Thus says the Lord YHWH: Behold, I have spoken in my jealousy and in my fury, because you have borne the shame of the nations;

**36:7** "Therefore thus says the Lord YHWH: I have lifted up my hand: Surely the nations that are round about you, they shall bear their shame.

**36:8** "But you, O mountains of Israel, you shall shoot forth your branches, and yield your fruit to my people Israel; for they are at hand to come.

**36:9** "For, behold, I am for you, and I will turn unto you, and you shall be tilled and sown;

**36:10** "And I will multiply men upon you, all the house of Israel, even all of it; and the cities shall be inhabited, and the waste places shall be built;

**36:11** "And I will multiply upon you man and beast, and they shall increase and be fruitful; and I will cause you to be inhabited after your former estate, and will do better unto you than at your beginnings; and you shall know that I am YHWH.

**36:12** "Yea, I will cause men to walk upon you, even my people Israel, and they shall possess you, and you shall be their inheritance; and you shall no more henceforth bereave them of children.

**36:13** "Thus says the Lord YHWH: Because they say unto you: 'You are a devourer of men, and have been a bereaver of your nation';

**36:14** "Therefore you shall devour men no more, neither bereave your nation any more," says the Lord YHWH.

**36:15** "Neither will I suffer the shame of the nations any more to be heard against you, neither shall you bear the reproach of the peoples any more, neither shall you cause your nation to stumble any more," says the Lord YHWH.

---

## For YHWH's Name's Sake (36:16-23)

**36:16** Moreover the word of YHWH came unto me, saying:

**36:17** "Son of man, when the house of Israel dwelt in their own land, they defiled it by their way and by their doings; their way before me was as the uncleanness of a woman in her impurity.

**36:18** "Wherefore I poured out my fury upon them for the blood which they had poured out upon the land, and because they had defiled it with their idols;

**36:19** "And I scattered them among the nations, and they were dispersed through the countries; according to their way and according to their doings I judged them.

**36:20** "And when they came unto the nations, whither they went, they profaned my holy name; in that men said of them: 'These are the people of YHWH, and are gone forth out of his land.'

**36:21** "But I had pity for my holy name, which the house of Israel had profaned among the nations, whither they went.

**36:22** "Therefore say unto the house of Israel: Thus says the Lord YHWH: I do not this for your sake, O house of Israel, but for my holy name, which you have profaned among the nations, whither you went.

**36:23** "And I will sanctify my great name, which has been profaned among the nations, which you have profaned in the midst of them; and the nations shall know that I am YHWH," says the Lord YHWH, "when I shall be sanctified in you before their eyes."

---

## Cleansing and New Heart (36:24-32)

**36:24** "For I will take you from among the nations, and gather you out of all the countries, and will bring you into your own land.

**36:25** "And I will sprinkle clean water upon you, and you shall be clean; from all your uncleannesses, and from all your idols, will I cleanse you.

**36:26** "A new heart also will I give you, and a new spirit will I put within you; and I will take away the stony heart out of your flesh, and I will give you a heart of flesh.

**36:27** "And I will put my spirit within you, and cause you to walk in my statutes, and you shall keep my ordinances, and do them.

**36:28** "And you shall dwell in the land that I gave to your fathers; and you shall be my people, and I will be your God.

**36:29** "And I will save you from all your uncleannesses; and I will call for the grain, and will increase it, and lay no famine upon you.

**36:30** "And I will multiply the fruit of the tree, and the increase of the field, that you may receive no more the reproach of famine among the nations.

**36:31** "Then shall you remember your evil ways, and your doings that were not good; and you shall loathe yourselves in your own sight for your iniquities and for your abominations.

**36:32** "Not for your sake do I this," says the Lord YHWH, "be it known unto you; be ashamed and confounded for your ways, O house of Israel."

---

## Like the Garden of Eden (36:33-38)

**36:33** Thus says the Lord YHWH: "In the day that I cleanse you from all your iniquities, I will cause the cities to be inhabited, and the waste places shall be built.

**36:34** "And the land that was desolate shall be tilled, whereas it was a desolation in the sight of all that passed by.

**36:35** "And they shall say: 'This land that was desolate is become like the garden of Eden; and the waste and desolate and ruined cities are fortified and inhabited.'

**36:36** "Then the nations that are left round about you shall know that I YHWH have built the ruined places, and planted that which was desolate; I YHWH have spoken it, and I will do it.

**36:37** "Thus says the Lord YHWH: I will yet for this be inquired of by the house of Israel, to do it for them; I will increase them with men like a flock.

**36:38** "As the flock for sacrifice, as the flock of Jerusalem in her appointed seasons, so shall the waste cities be filled with flocks of men; and they shall know that I am YHWH."

---

## Synthesis Notes

**Key Restorations:**

**Restoration of the Land (36:1-15):**
**The Key Verse (36:1):**
"'Prophesy unto the mountains of Israel.'"

*Hinnave el-harei Yisra'el*—to mountains.

"'You mountains of Israel, hear the word of YHWH.'"

*Harei Yisra'el shim'u devar-YHWH*—hear.

**The Key Verses (36:2-5):**
"'Because the enemy has said against you: Aha!'"

*Ya'an amar ha-oyev aleikhem he'ach*—Aha.

"'The ancient high places are ours in possession.'"

*U-vamot olam le-morashah hayetah lanu*—high places ours.

"'They have made you desolate, and swallowed you up on every side.'"

*Ya'an be-ya'an shammot ve-sha'of etkhem mi-saviv*—swallowed.

"'That you might be a possession unto the residue of the nations.'"

*Li-heyotkhem morashah li-sh'erit ha-goyim*—possession.

"'You are taken up in the lips of talkers, and the evil report of the people.'"

*Va-te'alu al-sefat lashon ve-dibbat am*—gossip.

"'Surely in the fire of my jealousy have I spoken against the residue of the nations.'"

*Im-lo be-esh qin'ati dibbarti al-she'erit ha-goyim*—fire of jealousy.

"'And against all Edom.'"

*Ve-al-Edom kullah*—against Edom.

"'That have appointed my land unto themselves for a possession.'"

*Asher natenu et-artzi lahem le-morashah*—took my land.

"'With the joy of all their heart, with disdain of soul.'"

*Be-simchat kol-levav bi-sh'at nefesh*—joy, disdain.

**The Key Verses (36:6-11):**
"'I have spoken in my jealousy and in my fury.'"

*Be-qin'ati u-va-chamati dibbarti*—jealousy, fury.

"'Because you have borne the shame of the nations.'"

*Ya'an kelimmat goyim nesa'tem*—bore shame.

"'The nations that are round about you, they shall bear their shame.'"

*Ha-goyim asher mi-sevivoteikhem hemmah kelimmatam yis'u*—they bear shame.

"'You, O mountains of Israel, you shall shoot forth your branches.'"

*Ve-attem harei Yisra'el anfekhem tittenu*—branches.

"'Yield your fruit to my people Israel.'"

*U-feryekhem tis'u le-ammi Yisra'el*—fruit.

"'For they are at hand to come.'"

*Ki qervu lavo*—near to come.

"'Behold, I am for you.'"

*Ki-hineni aleikhem*—I am for you.

"'I will turn unto you.'"

*U-faniti aleikhem*—turn to you.

"'You shall be tilled and sown.'"

*Ve-ne'evadtem ve-nizra'tem*—tilled, sown.

"'I will multiply men upon you, all the house of Israel, even all of it.'"

*Ve-hirbeti aleikhem adam kol-beit Yisra'el kullo*—multiply.

"'The cities shall be inhabited.'"

*Ve-noshavu he-arim*—inhabited.

"'The waste places shall be built.'"

*Ve-ha-choravot tibbanenah*—built.

"'I will multiply upon you man and beast.'"

*Ve-hirbeti aleikhem adam u-vehemah*—multiply.

"'They shall increase and be fruitful.'"

*Ve-ravu u-faru*—fruitful.

"'I will cause you to be inhabited after your former estate.'"

*Ve-hoshavti etkhem ke-qadmoteikhem*—former estate.

"'Will do better unto you than at your beginnings.'"

*Ve-hetivoti mi-rishoneikhem*—better than before.

**The Key Verses (36:12-15):**
"'I will cause men to walk upon you, even my people Israel.'"

*Ve-holakhti aleikhem adam et-ammi Yisra'el*—people walk.

"'They shall possess you, and you shall be their inheritance.'"

*Vi-reshukha ve-hayit lahem le-nachalah*—possession.

"'You shall no more henceforth bereave them of children.'"

*Ve-lo-tosif od le-shakkelem*—no more bereave.

"''You are a devourer of men, and have been a bereaver of your nation.''"

*Okhelet adam at u-meshakkelet goyekh hayit*—devourer.

"'You shall devour men no more.'"

*Lo-tokheli adam od*—no more devour.

"'Neither bereave your nation any more.'"

*Ve-goyekh lo tesakkeli od*—no more bereave.

"'Neither will I suffer the shame of the nations any more to be heard against you.'"

*Ve-kelimmat goyim lo-tishme'i od*—no more shame.

**For YHWH's Name's Sake (36:16-23):**
**The Key Verses (36:17-19):**
"'When the house of Israel dwelt in their own land, they defiled it.'"

*Beit-Yisra'el yoshevim al-admatam va-yetamme'u otah*—defiled land.

"'Their way before me was as the uncleanness of a woman in her impurity.'"

*Ke-tum'at ha-niddah hayetah darkam lefanai*—like impurity.

"'I poured out my fury upon them for the blood which they had poured out upon the land.'"

*Va-eshpokh chamati aleihem al-ha-dam asher-shafekhu al-ha-aretz*—blood.

"'Because they had defiled it with their idols.'"

*U-ve-gilluleihem timme'uha*—idols.

"'I scattered them among the nations.'"

*Va-afitz otam ba-goyim*—scattered.

"'They were dispersed through the countries.'"

*Va-yizzaru ba-aratzot*—dispersed.

"'According to their way and according to their doings I judged them.'"

*Ke-darkam u-khe-alilotam shefatttim*—judged.

**The Key Verses (36:20-21):**
"'When they came unto the nations... they profaned my holy name.'"

*Va-yavo'u el-ha-goyim... va-yechallelu et-shem qodshi*—profaned name.

"'In that men said of them: These are the people of YHWH.'"

*Be-emor lahem am-YHWH elleh*—people of YHWH.

"'And are gone forth out of his land.'"

*U-me-artzo yatza'u*—left his land.

"'I had pity for my holy name.'"

*Va-achmol al-shem qodshi*—pity for name.

"'Which the house of Israel had profaned among the nations.'"

*Asher chillelu beit Yisra'el ba-goyim*—profaned.

**The Key Verses (36:22-23):**
"'I do not this for your sake, O house of Israel.'"

*Lo lema'ankhem ani oseh beit Yisra'el*—not for you.

"'But for my holy name.'"

*Ki im-le-shem qodshi*—for my name.

"'Which you have profaned among the nations.'"

*Asher chilaltem ba-goyim*—profaned.

"'I will sanctify my great name.'"

*Ve-qiddashti et-shemi ha-gadol*—sanctify name.

"'Which has been profaned among the nations.'"

*Ha-mechoллal ba-goyim*—profaned.

"'The nations shall know that I am YHWH.'"

*Ve-yad'u ha-goyim ki-ani YHWH*—nations know.

"'When I shall be sanctified in you before their eyes.'"

*Be-hiqqadshi vakhem le-eineihem*—sanctified in you.

**Cleansing and New Heart (36:24-32):**
**The Key Verse (36:24):**
"'I will take you from among the nations.'"

*Ve-laqachti etkhem min-ha-goyim*—take from nations.

"'Gather you out of all the countries.'"

*Ve-qibbaתzti etkhem mi-kol-ha-aratzot*—gather.

"'Will bring you into your own land.'"

*Ve-heveti etkhem el-admatekhem*—to your land.

**The Key Verse (36:25):**
"'I will sprinkle clean water upon you, and you shall be clean.'"

*Ve-zaraqti aleikhem mayim tehorim u-tehartem*—clean water.

"'From all your uncleannesses, and from all your idols, will I cleanse you.'"

*Mi-kol tum'oteikhem u-mi-kol gilluleikem ataher etkhem*—cleanse.

**The Key Verse (36:26):**
"'A new heart also will I give you.'"

*Ve-natatti lakhem lev chadash*—new heart.

"'A new spirit will I put within you.'"

*Ve-ruach chadashah etten be-qirbekhem*—new spirit.

"'I will take away the stony heart out of your flesh.'"

*Va-hasiroti et-lev ha-even mi-besarkhem*—remove stone heart.

"'I will give you a heart of flesh.'"

*Ve-natatti lakhem lev basar*—heart of flesh.

**The Key Verse (36:27):**
"'I will put my spirit within you.'"

*Ve-et-ruchi etten be-qirbekhem*—my spirit within.

"'Cause you to walk in my statutes.'"

*Ve-asiti et asher be-chuqqai telekhu*—walk in statutes.

"'You shall keep my ordinances, and do them.'"

*U-mishpatai tishmeru va-asitem*—keep, do.

**The Key Verse (36:28):**
"'You shall dwell in the land that I gave to your fathers.'"

*Vi-yshavtem ba-aretz asher natatti la-avoteikhem*—dwell in land.

"'You shall be my people, and I will be your God.'"

*Vi-heyitem li le-am va-ani ehyeh lakhem le-Elohim*—covenant formula.

**The Key Verses (36:29-32):**
"'I will save you from all your uncleannesses.'"

*Ve-hosha'ti etkhem mi-kol tum'oteikhem*—save.

"'I will call for the grain, and will increase it.'"

*Ve-qarati el-ha-dagan ve-hirbeiti oto*—increase grain.

"'Lay no famine upon you.'"

*Ve-lo-etten aleikhem ra'av*—no famine.

"'I will multiply the fruit of the tree, and the increase of the field.'"

*Ve-hirbeti et-peri ha-etz u-tenuʾat ha-sadeh*—multiply.

"'You shall remember your evil ways... and you shall loathe yourselves.'"

*U-zekhartem et-darkheikem ha-ra'im... u-neqottem bi-fneikhem*—loathe selves.

"'Not for your sake do I this.'"

*Lo lema'ankhem ani oseh*—not for you.

"'Be ashamed and confounded for your ways.'"

*Boshu ve-hikkalemu mi-darkheikem*—be ashamed.

**Like Garden of Eden (36:33-38):**
"'In the day that I cleanse you from all your iniquities.'"

*Be-yom tahareי etkhem mi-kol avonoteikhem*—cleanse.

"'I will cause the cities to be inhabited.'"

*Ve-hoshavti et-he-arim*—inhabited.

"'The waste places shall be built.'"

*Ve-nivnu ha-choravot*—built.

"'The land that was desolate shall be tilled.'"

*Ve-ha-aretz ha-neshammah te'aved*—tilled.

**The Key Verse (36:35):**
"''This land that was desolate is become like the garden of Eden.''"

*Ha-aretz ha-lazu ha-neshammah hayetah ke-gan-Eden*—like Eden.

"'The waste and desolate and ruined cities are fortified and inhabited.'"

*Ve-he-arim he-charevot ve-ha-neshammot ve-ha-neherasot betzurot yashavu*—fortified.

**The Key Verses (36:36-38):**
"'The nations that are left round about you shall know that I YHWH have built the ruined places.'"

*Ve-yad'u ha-goyim asher yishshaʾeru sevivoteikhem ki ani YHWH baniti ha-neherasot*—YHWH built.

"'Planted that which was desolate.'"

*Natati ha-neshammah*—planted.

"'I YHWH have spoken it, and I will do it.'"

*Ani YHWH dibbarti ve-asiti*—spoken, done.

"'I will yet for this be inquired of by the house of Israel.'"

*Od zot iddaresh le-veit Yisra'el*—inquired of.

"'I will increase them with men like a flock.'"

*La'asot lahem arbeh otam ka-tzon adam*—like flock.

"'As the flock for sacrifice, as the flock of Jerusalem in her appointed seasons.'"

*Ke-tzon qodashim ke-tzon Yerushalayim be-mo'adeyha*—Jerusalem's flock.

"'So shall the waste cities be filled with flocks of men.'"

*Ken tihyenah he-arim ha-chorevot mele'ot tzon adam*—filled.

**Archetypal Layer:** Ezekiel 36 is a **foundational restoration chapter**, containing **restoration of the land (36:1-15)**, **"I do not this for your sake... but for my holy name" (36:22)**, **"I will sprinkle clean water upon you" (36:25)**, **"A new heart also will I give you, and a new spirit will I put within you" (36:26)**, **"I will take away the stony heart... give you a heart of flesh" (36:26)**, **"I will put my spirit within you" (36:27)**, and **"This land that was desolate is become like the garden of Eden" (36:35)**.

**Ethical Inversion Applied:**
- "'Prophesy unto the mountains of Israel'"—to mountains
- "'Because the enemy has said... Aha!'"—Aha
- "'The ancient high places are ours in possession'"—enemy claim
- "'You have borne the shame of the nations'"—bore shame
- "'The nations... shall bear their shame'"—reversal
- "'You, O mountains of Israel, you shall shoot forth your branches'"—branches
- "'I am for you'"—for you
- "'I will multiply men upon you'"—multiply
- "'The cities shall be inhabited'"—inhabited
- "'Will do better unto you than at your beginnings'"—better
- "'You shall no more henceforth bereave them of children'"—no more bereave
- "'They defiled it by their way and by their doings'"—defiled
- "'I poured out my fury upon them'"—fury
- "'I scattered them among the nations'"—scattered
- "'They profaned my holy name'"—profaned name
- "'These are the people of YHWH, and are gone forth out of his land'"—shame
- "'I had pity for my holy name'"—pity for name
- "'I do not this for your sake... but for my holy name'"—for name
- "'I will sanctify my great name'"—sanctify
- "'The nations shall know that I am YHWH'"—nations know
- "'I will take you from among the nations'"—take
- "'Gather you out of all the countries'"—gather
- "'Bring you into your own land'"—to land
- "'I will sprinkle clean water upon you'"—clean water
- "'You shall be clean'"—clean
- "'From all your uncleannesses... will I cleanse you'"—cleanse
- "'A new heart also will I give you'"—new heart
- "'A new spirit will I put within you'"—new spirit
- "'I will take away the stony heart'"—remove stone
- "'I will give you a heart of flesh'"—heart of flesh
- "'I will put my spirit within you'"—spirit within
- "'Cause you to walk in my statutes'"—walk in statutes
- "'You shall dwell in the land'"—dwell
- "'You shall be my people, and I will be your God'"—covenant
- "'I will save you from all your uncleannesses'"—save
- "'I will call for the grain, and will increase it'"—increase
- "'Lay no famine upon you'"—no famine
- "'You shall remember your evil ways... loathe yourselves'"—loathe
- "'Not for your sake do I this'"—not for you
- "'Be ashamed and confounded'"—ashamed
- "'This land that was desolate is become like the garden of Eden'"—Eden
- "'The waste and desolate and ruined cities are fortified'"—fortified
- "'I YHWH have spoken it, and I will do it'"—spoken, done
- "'I will increase them with men like a flock'"—like flock

**Modern Equivalent:** Ezekiel 36 is theologically crucial. "For my holy name's sake" (36:22) grounds restoration in YHWH's character, not Israel's merit. The "new heart/new spirit" (36:26-27) promises internal transformation—foundational for New Testament theology. "Like the garden of Eden" (36:35) envisions paradise restored.

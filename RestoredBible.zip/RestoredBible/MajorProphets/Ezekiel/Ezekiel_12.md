# Ezekiel 12: The Sign of the Exile

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## The Sign of Baggage (12:1-16)

**12:1** The word of YHWH also came unto me, saying:

**12:2** "Son of man, you dwell in the midst of the rebellious house, that have eyes to see, and see not, that have ears to hear, and hear not; for they are a rebellious house.

**12:3** "Therefore, son of man, prepare for yourself stuff for exile, and remove by day in their sight; and you shall remove from your place to another place in their sight; perhaps they will perceive, for they are a rebellious house.

**12:4** "And you shall bring forth your stuff by day in their sight, as stuff for exile; and you yourself shall go forth in the evening in their sight, as when men go forth into exile.

**12:5** "Dig through the wall in their sight, and carry out thereby.

**12:6** "In their sight shall you bear it upon your shoulder, and carry it forth in the dark; you shall cover your face, that you see not the ground; for I have set you for a sign unto the house of Israel."

**12:7** And I did so as I was commanded; I brought forth my stuff by day, as stuff for exile, and in the evening I digged through the wall with my hand; I carried it forth in the dark, and bore it upon my shoulder in their sight.

**12:8** And in the morning came the word of YHWH unto me, saying:

**12:9** "Son of man, has not the house of Israel, the rebellious house, said unto you: What are you doing?

**12:10** "Say unto them: Thus says the Lord YHWH: This burden concerns the prince in Jerusalem, and all the house of Israel among whom they are.

**12:11** "Say: I am your sign; as I have done, so shall it be done unto them; they shall go into exile, into captivity.

**12:12** "And the prince that is among them shall bear upon his shoulder in the dark, and shall go forth; they shall dig through the wall to carry out thereby; he shall cover his face, that he see not the ground with his eyes.

**12:13** "My net also will I spread upon him, and he shall be taken in my snare; and I will bring him to Babylon to the land of the Chaldeans; yet shall he not see it, though he shall die there.

**12:14** "And I will scatter toward every wind all that are round about him to help him, and all his troops; and I will draw out the sword after them.

**12:15** "And they shall know that I am YHWH, when I shall disperse them among the nations, and scatter them through the countries.

**12:16** "But I will leave a few men of them from the sword, from the famine, and from the pestilence; that they may declare all their abominations among the nations whither they come; and they shall know that I am YHWH."

---

## The Sign of Trembling (12:17-20)

**12:17** Moreover the word of YHWH came to me, saying:

**12:18** "Son of man, eat your bread with quaking, and drink your water with trembling and with anxiety;

**12:19** "And say unto the people of the land: Thus says the Lord YHWH concerning the inhabitants of Jerusalem in the land of Israel: They shall eat their bread with anxiety, and drink their water with appalment, that her land may be desolate from all that is therein, because of the violence of all them that dwell therein.

**12:20** "And the cities that are inhabited shall be laid waste, and the land shall be a desolation; and you shall know that I am YHWH."

---

## The Proverb Refuted (12:21-28)

**12:21** And the word of YHWH came unto me, saying:

**12:22** "Son of man, what is that proverb that you have in the land of Israel, saying: 'The days are prolonged, and every vision fails'?

**12:23** "Tell them therefore: Thus says the Lord YHWH: I will make this proverb to cease, and they shall no more use it as a proverb in Israel; but say unto them: The days are at hand, and the word of every vision.

**12:24** "For there shall be no more any vain vision nor smooth divination within the house of Israel.

**12:25** "For I YHWH will speak, what word soever it be that I shall speak, and it shall be performed; it shall be no more deferred; for in your days, O rebellious house, will I speak the word, and will perform it," says the Lord YHWH.

**12:26** Again the word of YHWH came to me, saying:

**12:27** "Son of man, behold, they of the house of Israel say: 'The vision that he sees is for many days to come, and he prophesies of times that are far off.'

**12:28** "Therefore say unto them: Thus says the Lord YHWH: There shall none of my words be deferred any more, but the word which I shall speak shall be performed," says the Lord YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Sign of Baggage (12:1-16):**
**The Key Verse (12:2):**
"'You dwell in the midst of the rebellious house.'"

*Be-tokh beit-ha-meri attah yoshev*—among rebellious.

"'That have eyes to see, and see not.'"

*Asher einayim lahem lir'ot ve-lo ra'u*—eyes but don't see.

"'That have ears to hear, and hear not.'"

*Oznayim lahem lishmo'a ve-lo sham'u*—ears but don't hear.

"'For they are a rebellious house.'"

*Ki veit meri hem*—rebellious house.

**The Key Verses (12:3-6):**
"'Prepare for yourself stuff for exile.'"

*Aseh lekha kelei golah*—exile baggage.

"'Remove by day in their sight.'"

*Ve-geleh yomam le-eineihem*—go by day.

"'You shall remove from your place to another place in their sight.'"

*Ve-galita mi-meqomekha el-maqom acher le-eineihem*—move.

"'Perhaps they will perceive.'"

*Ulai yir'u*—maybe see.

"'You shall bring forth your stuff by day in their sight, as stuff for exile.'"

*Ve-hotzeta kelekha ki-kheli golah yomam le-eineihem*—exile stuff.

"'You yourself shall go forth in the evening in their sight.'"

*Ve-attah tetze ba-erev le-eineihem*—go at evening.

"'As when men go forth into exile.'"

*Ke-motza'ei golah*—like exiles.

"'Dig through the wall in their sight.'"

*Ba-qir chator le-eineihem*—dig through wall.

"'Carry out thereby.'"

*Ve-hotzeta vo*—carry out.

"'You shall bear it upon your shoulder.'"

*Al-katef tissa*—on shoulder.

"'Carry it forth in the dark.'"

*Ba-alatah totzi*—in dark.

"'You shall cover your face, that you see not the ground.'"

*Panekha tekhasseh ve-lo tir'eh et-ha-aretz*—cover face.

"'I have set you for a sign unto the house of Israel.'"

*Ki-mofet netattikha le-veit Yisra'el*—sign.

**The Key Verse (12:7):**
"I did so as I was commanded."

*Va-a'as ken ka-asher tzuvveiti*—obeyed.

"I brought forth my stuff by day, as stuff for exile."

*Kelai hotzeti ki-kheli golah yomam*—brought stuff.

"In the evening I digged through the wall with my hand."

*U-va-erev charti-li va-qir be-yad*—dug through.

"I carried it forth in the dark, and bore it upon my shoulder."

*Ba-alatah hotzeti al-katef nasati le-eineihem*—carried out.

**The Key Verses (12:10-12):**
"'This burden concerns the prince in Jerusalem.'"

*Ha-nasi ha-massa ha-zeh bi-Yrushalayim*—concerns prince.

"'All the house of Israel among whom they are.'"

*Ve-khol-beit Yisra'el asher-hemmah be-tokham*—all Israel.

"'I am your sign.'"

*Ani moftekhem*—I am sign.

"'As I have done, so shall it be done unto them.'"

*Ka-asher asiti ken ye'aseh lahem*—as I did.

"'They shall go into exile, into captivity.'"

*Ba-golah ba-shevi yelekhu*—exile.

"'The prince that is among them shall bear upon his shoulder in the dark.'"

*Ve-ha-nasi asher-be-tokham al-katef yissa ba-alatah ve-yetze*—prince carries.

"'They shall dig through the wall to carry out thereby.'"

*Ba-qir yachteru le-hotzi vo*—dig wall.

"'He shall cover his face, that he see not the ground with his eyes.'"

*Panav yekhasseh ya'an asher lo-yir'eh le-ayin hu et-ha-aretz*—cover face.

**Zedekiah:**
This prophecy describes Zedekiah's escape attempt (2 Kings 25:4-7).

**The Key Verse (12:13):**
"'My net also will I spread upon him.'"

*U-farashti et-rishti alav*—spread net.

"'He shall be taken in my snare.'"

*Ve-nitpas bi-metzudati*—caught.

"'I will bring him to Babylon.'"

*Ve-heveti oto Bavelah*—to Babylon.

"'Yet shall he not see it, though he shall die there.'"

*Ve-otah lo-yir'eh ve-sham yamut*—not see, die there.

**Blinding:**
Zedekiah was blinded before being taken to Babylon—he arrived but never "saw" it.

**The Key Verses (12:14-16):**
"'I will scatter toward every wind all that are round about him.'"

*Ve-khol asher sevivotav ezro ve-khol agappav le-khol-ruach ezreh*—scatter.

"'I will draw out the sword after them.'"

*Ve-cherev ariq achareihem*—sword follows.

"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—recognition.

"'I will leave a few men of them from the sword, from the famine, and from the pestilence.'"

*Ve-hotarti me-hem anshei mispar me-cherev me-ra'av u-mi-daver*—few left.

"'That they may declare all their abominations among the nations.'"

*Lema'an yesapperu et-kol-to'avoteihem ba-goyim*—declare.

**Sign of Trembling (12:17-20):**
"'Eat your bread with quaking.'"

*Lachmekha be-ra'ash tokhel*—eat with quaking.

"'Drink your water with trembling and with anxiety.'"

*U-meimekha be-rogzah u-vi-de'agah tishteh*—drink with trembling.

"'They shall eat their bread with anxiety.'"

*Lachmam bi-de'agah yokhelu*—anxiety.

"'Drink their water with appalment.'"

*U-meimeihem be-shimmamon yishtu*—appalment.

"'That her land may be desolate from all that is therein.'"

*Lema'an tishsam artzah mi-melo'ah*—desolate.

"'Because of the violence of all them that dwell therein.'"

*Me-chamas kol-ha-yoshevim bah*—because of violence.

"'The cities that are inhabited shall be laid waste.'"

*Ve-he-arim ha-noshabot techeravnah*—cities waste.

"'The land shall be a desolation.'"

*Ve-ha-aretz shemamah tihyeh*—desolation.

**Proverb Refuted (12:21-28):**
**The Key Verse (12:22):**
"'What is that proverb that you have in the land of Israel?'"

*Mah ha-mashal ha-zeh lakhem al-admat Yisra'el*—proverb.

"''The days are prolonged, and every vision fails.''"

*Ya'arikhu ha-yamim ve-avad kol-chazon*—days prolonged, vision fails.

**Skeptical Proverb:**
The people dismissed prophecies as never happening.

**The Key Verses (12:23-25):**
"'I will make this proverb to cease.'"

*Hashbatti et-ha-mashal ha-zeh*—cease proverb.

"'They shall no more use it as a proverb in Israel.'"

*Ve-lo-yimshelu oto od be-Yisra'el*—no more use.

"'The days are at hand.'"

*Qarevu ha-yamim*—days at hand.

"'The word of every vision.'"

*U-devar kol-chazon*—every vision.

"'There shall be no more any vain vision nor smooth divination.'"

*Ki lo yihyeh od kol-chazon shav u-miqsam chalaق be-tokh beit Yisra'el*—no vain vision.

"'I YHWH will speak, what word soever it be that I shall speak, and it shall be performed.'"

*Ki ani YHWH adabber et asher adabber davar ve-ye'aseh*—will perform.

"'It shall be no more deferred.'"

*Lo timmashekh od*—not deferred.

"'In your days, O rebellious house, will I speak the word, and will perform it.'"

*Ki vi-yemeikhem beit ha-meri adabber davar va-asitihuu*—in your days.

**The Key Verses (12:27-28):**
"''The vision that he sees is for many days to come.''"

*Le-yamim rabbim hu chozeh*—for many days.

"''He prophesies of times that are far off.''"

*U-le-ittim rechoqot hu niba*—far off.

"'There shall none of my words be deferred any more.'"

*Lo-timmashekh od kol-devarai*—not deferred.

"'The word which I shall speak shall be performed.'"

*Asher adabber davar ve-ye'aseh*—will be performed.

**Archetypal Layer:** Ezekiel 12 contains **the sign-act of exile baggage (12:3-7)**, **"The prince... shall bear upon his shoulder... he shall cover his face... yet shall he not see it" (12:12-13)**—predicting Zedekiah's blinding, **"I am your sign" (12:11)**, and **"The days are at hand, and the word of every vision" (12:23)**.

**Ethical Inversion Applied:**
- "'You dwell in the midst of the rebellious house'"—among rebellious
- "'Eyes to see, and see not... ears to hear, and hear not'"—blind/deaf
- "'Prepare for yourself stuff for exile'"—exile baggage
- "'Remove by day in their sight'"—visible sign
- "'Perhaps they will perceive'"—maybe see
- "'Dig through the wall in their sight'"—dig wall
- "'Bear it upon your shoulder'"—on shoulder
- "'Carry it forth in the dark'"—in dark
- "'Cover your face, that you see not the ground'"—cover face
- "'I have set you for a sign'"—sign
- "I did so as I was commanded"—obedience
- "'This burden concerns the prince in Jerusalem'"—concerns prince
- "'I am your sign'"—I am sign
- "'As I have done, so shall it be done unto them'"—pattern
- "'The prince... shall bear upon his shoulder in the dark'"—prince's escape
- "'He shall cover his face, that he see not the ground'"—covered face
- "'My net also will I spread upon him'"—net
- "'He shall be taken in my snare'"—caught
- "'I will bring him to Babylon'"—to Babylon
- "'Yet shall he not see it, though he shall die there'"—blind, die there
- "'I will scatter toward every wind'"—scatter
- "'I will leave a few men of them'"—few left
- "'That they may declare all their abominations'"—declare
- "'Eat your bread with quaking'"—quaking
- "'Drink your water with trembling'"—trembling
- "'The cities... shall be laid waste'"—waste
- "''The days are prolonged, and every vision fails''"—skeptical proverb
- "'I will make this proverb to cease'"—cease proverb
- "'The days are at hand'"—days near
- "'There shall be no more any vain vision'"—no vain vision
- "'I YHWH will speak... and it shall be performed'"—will perform
- "'It shall be no more deferred'"—not deferred
- "''He prophesies of times that are far off''"—another proverb
- "'The word which I shall speak shall be performed'"—will perform

**Modern Equivalent:** Ezekiel 12's sign-act predicts Zedekiah's failed escape. The detail "he shall not see it, though he shall die there" (12:13) was fulfilled when Nebuchadnezzar blinded him before transport. The refuted proverbs (12:22, 27) address prophetic fatigue—people dismissed warnings as never-happening.

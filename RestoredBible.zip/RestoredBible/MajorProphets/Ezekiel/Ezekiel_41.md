# Ezekiel 41: The Temple Interior

*From the Hebrew: וַיְבִיאֵנִי אֶל־הַהֵיכָל (Va-Yevi'eni El-Ha-Heikhal) — And He Brought Me to the Temple*

---

## The Temple Proper (41:1-4)

**41:1** And he brought me to the temple, and measured the posts, six cubits broad on the one side, and six cubits broad on the other side, which was the breadth of the tent.

**41:2** And the breadth of the entrance was ten cubits; and the sides of the entrance were five cubits on the one side, and five cubits on the other side; and he measured the length thereof, forty cubits, and the breadth, twenty cubits.

**41:3** Then went he inward, and measured each post of the entrance, two cubits; and the entrance, six cubits; and the breadth of the entrance, seven cubits.

**41:4** And he measured the length thereof, twenty cubits, and the breadth, twenty cubits, before the temple; and he said unto me: "This is the most holy place."

---

## The Side Chambers (41:5-11)

**41:5** Then he measured the wall of the house, six cubits; and the breadth of every side-chamber, four cubits, round about the house on every side.

**41:6** And the side-chambers were in three stories, one over another, and thirty in each story; and there were cornices in the wall which belonged to the house for the side-chambers round about, that they might have hold therein, and not have hold in the wall of the house.

**41:7** And the side-chambers were broader as they wound about higher and higher; for the winding about of the house went higher and higher round about the house; therefore the breadth of the house continued upward; and so one went up from the lowest story to the highest by the middle story.

**41:8** I saw also that the house had a raised basement round about; the foundations of the side-chambers were a full reed of six cubits to the joining.

**41:9** The thickness of the outer wall of the side-chambers was five cubits; and so also the part that was left free along the structure of side-chambers that belonged to the house.

**41:10** And between the chambers was a breadth of twenty cubits round about the house on every side.

**41:11** And the doors of the side-chambers were toward the part that was left free, one door toward the north, and another door toward the south; and the breadth of the part that was left free was five cubits round about.

---

## The Building to the West (41:12)

**41:12** And the building that was before the separate place at the side toward the west was seventy cubits broad; and the wall of the building was five cubits thick round about, and the length thereof ninety cubits.

---

## Overall Measurements (41:13-15a)

**41:13** So he measured the house, a hundred cubits long; and the separate place, and the building, with the walls thereof, a hundred cubits long;

**41:14** Also the breadth of the face of the house and of the separate place toward the east, a hundred cubits.

**41:15a** And he measured the length of the building before the separate place which was at the back thereof, and the galleries thereof on the one side and on the other side, a hundred cubits.

---

## The Interior Decoration (41:15b-26)

**41:15b** Now the temple, and the inner place, and the outer porch;

**41:16** The thresholds, and the narrow windows, and the galleries that were round about their three stories, over against the threshold, were ceiled with wood round about, and from the ground up to the windows; and the windows were covered;

**41:17** To the space above the entrance, even unto the inner house, and without, and on all the wall round about within and without, by measure.

**41:18** And it was made with cherubim and palm-trees; and a palm-tree was between cherub and cherub, and every cherub had two faces;

**41:19** So that there was the face of a man toward the palm-tree on the one side, and the face of a young lion toward the palm-tree on the other side; it was made through all the house round about.

**41:20** From the ground unto above the entrance were cherubim and palm-trees made; and so on the wall of the temple.

**41:21** As for the temple, the doorposts were squared; and as for the face of the sanctuary, the appearance thereof was as the appearance of the temple.

**41:22** The altar, three cubits high, and the length thereof two cubits, was of wood, and so the corners thereof; and the length thereof, and the walls thereof, were also of wood; and he said unto me: "This is the table that is before YHWH."

**41:23** And the temple and the sanctuary had two doors.

**41:24** And the doors had two leaves apiece, two turning leaves; two leaves for the one door, and two leaves for the other.

**41:25** And there were made on them, on the doors of the temple, cherubim and palm-trees, like as were made upon the walls; and there were thick beams of wood upon the face of the porch without.

**41:26** And there were narrow windows and palm-trees on the one side and on the other side, on the sides of the porch; and upon the side-chambers of the house, and the thick beams.

---

## Synthesis Notes

**Key Restorations:**

**Temple Proper (41:1-4):**
**The Key Verses (41:1-2):**
"He brought me to the temple."

*Va-yevi'eni el-ha-heikhal*—to temple.

"Measured the posts, six cubits broad on the one side."

*Va-yamad et-ha-eilim shesh-ammot rochav mi-poh*—six cubits.

"The breadth of the entrance was ten cubits."

*Ve-rochav ha-petach eser ammot*—ten cubits.

"The sides of the entrance were five cubits on the one side, and five cubits on the other."

*Ve-kitefot ha-petach chamesh ammot mi-poh ve-chamesh ammot mi-poh*—sides.

"He measured the length thereof, forty cubits, and the breadth, twenty cubits."

*Va-yamad et-orko arba'im ammah ve-rochav esrim ammah*—40 x 20 cubits.

**Heikhal:**
The main hall of the temple.

**The Key Verses (41:3-4):**
"Then went he inward."

*Va-yavo penimah*—went inward.

"Measured each post of the entrance, two cubits."

*Va-yamad eil-ha-petach shתayim ammot*—two cubits.

"The entrance, six cubits."

*Ve-ha-petach shesh ammot*—six cubits.

"The breadth of the entrance, seven cubits."

*Ve-rochav ha-petach sheva ammot*—seven cubits.

"He measured the length thereof, twenty cubits, and the breadth, twenty cubits."

*Va-yamad et-orko esrim ammah ve-rochav esrim ammah*—20 x 20 cubits.

"'This is the most holy place.'"

*Zeh Qodesh ha-Qodashim*—Holy of Holies.

**Qodesh ha-Qodashim:**
The Most Holy Place—a perfect 20-cubit cube.

**Side Chambers (41:5-11):**
"He measured the wall of the house, six cubits."

*Va-yamad et-qir ha-bayit shesh ammot*—six cubit wall.

"The breadth of every side-chamber, four cubits."

*Ve-rochav ha-tzela arba ammot*—four cubits.

"Round about the house on every side."

*Saviv saviv la-bayit saviv*—round about.

"The side-chambers were in three stories."

*Ve-ha-tzela'ot tzela el-tzela shalosh u-sheloshim pe'amim*—three stories.

"Thirty in each story."

*Sheloshim*—30 per story.

"The side-chambers were broader as they wound about higher and higher."

*Ve-rachavah ve-nasevah lema'elah lema'elah la-tzela'ot*—broader higher.

"One went up from the lowest story to the highest by the middle story."

*U-min-ha-tachtonah al-ha-elyonah ba-tikhonah*—via middle.

**Building to the West (41:12):**
"The building that was before the separate place at the side toward the west."

*Ve-ha-binyan asher el-penei ha-gizrah petach derekh ha-yam*—western building.

"Seventy cubits broad."

*Rochav shiv'im ammah*—70 cubits.

"The wall of the building was five cubits thick."

*Ve-qir ha-binyan chamesh ammot rochav*—5 cubit wall.

"The length thereof ninety cubits."

*Ve-orko tish'im ammah*—90 cubits.

**Overall Measurements (41:13-15a):**
"He measured the house, a hundred cubits long."

*Va-yamad et-ha-bayit orekh me'ah ammah*—100 cubits.

"The separate place, and the building, with the walls thereof, a hundred cubits long."

*Ve-ha-gizrah ve-ha-binyan ve-qiroteyha orekh me'ah ammah*—100 cubits.

"The breadth of the face of the house and of the separate place toward the east, a hundred cubits."

*Ve-rochav penei ha-bayit ve-ha-gizrah ha-qadim me'ah ammah*—100 cubits.

**Interior Decoration (41:15b-26):**
"The temple, and the inner place, and the outer porch."

*Ve-ha-heikhal ve-ha-penim u-lamim ha-chutzah*—temple parts.

"The thresholds, and the narrow windows."

*Ha-sippim ve-ha-challonot ha-atumot*—thresholds, windows.

"Ceiled with wood round about."

*Sefunim etz saviv saviv*—wood ceiling.

**The Key Verses (41:18-19):**
"It was made with cherubim and palm-trees."

*Asui keruvim ve-timotot*—cherubim, palms.

"A palm-tree was between cherub and cherub."

*Ve-timorah bein-keruv li-khruv*—palm between.

"Every cherub had two faces."

*U-shenayim panim la-keruv*—two faces.

"The face of a man toward the palm-tree on the one side."

*U-fenei adam el-ha-timorah mi-poh*—human face.

"The face of a young lion toward the palm-tree on the other side."

*U-fenei-kefir el-ha-timorah mi-poh*—lion face.

"It was made through all the house round about."

*Asui el-kol-ha-bayit saviv saviv*—all around.

**Two-Faced Cherubim:**
Unlike the four-faced cherubim of chapters 1 and 10.

**The Key Verse (41:22):**
"The altar, three cubits high, and the length thereof two cubits, was of wood."

*Ha-mizbeach etz shalosh ammot govoho ve-orko shתayim ammot*—wood altar.

"'This is the table that is before YHWH.'"

*Zeh ha-shulchan asher lifnei YHWH*—table before YHWH.

**Wooden Altar/Table:**
Incense altar, called "table before YHWH."

**The Key Verses (41:23-26):**
"The temple and the sanctuary had two doors."

*U-shtayim delatot la-heikhal ve-la-qodesh*—two doors.

"The doors had two leaves apiece."

*U-shtayim delatot la-delatot*—two leaves.

"There were made on them... cherubim and palm-trees."

*Ve-asui aleihen... keruvim ve-timorot*—cherubim, palms.

"There were narrow windows and palm-trees."

*Ve-challonot atumot ve-timorot*—windows, palms.

**Archetypal Layer:** Ezekiel 41 describes the **temple interior**, containing **the main hall (heikhal) 40 x 20 cubits (41:2)**, **the Most Holy Place (Qodesh ha-Qodashim) 20 x 20 cubits (41:4)**, **three stories of side chambers, 30 per story (41:6)**, **cherubim with two faces (human and lion) alternating with palm trees (41:18-19)**, and **"This is the table that is before YHWH" (41:22)**.

**Ethical Inversion Applied:**
- "He brought me to the temple"—to temple
- "Measured the posts, six cubits broad"—measurements
- "The breadth of the entrance was ten cubits"—entrance
- "He measured the length thereof, forty cubits, and the breadth, twenty cubits"—40 x 20
- "Then went he inward"—inward
- "He measured the length thereof, twenty cubits, and the breadth, twenty cubits"—20 x 20
- "'This is the most holy place'"—Holy of Holies
- "He measured the wall of the house, six cubits"—wall
- "The breadth of every side-chamber, four cubits"—side chambers
- "The side-chambers were in three stories"—three stories
- "Thirty in each story"—30 each
- "The side-chambers were broader as they wound about higher"—broader higher
- "The building... at the side toward the west was seventy cubits broad"—western building
- "The wall of the building was five cubits thick"—wall
- "The length thereof ninety cubits"—90 cubits
- "He measured the house, a hundred cubits long"—100 cubits
- "The breadth... a hundred cubits"—100 cubits
- "Ceiled with wood round about"—wood ceiling
- "It was made with cherubim and palm-trees"—decoration
- "A palm-tree was between cherub and cherub"—alternating
- "Every cherub had two faces"—two faces
- "The face of a man toward the palm-tree on the one side"—human face
- "The face of a young lion toward the palm-tree on the other side"—lion face
- "It was made through all the house round about"—throughout
- "The altar, three cubits high"—altar
- "'This is the table that is before YHWH'"—table
- "The temple and the sanctuary had two doors"—doors
- "The doors had two leaves apiece"—leaves
- "Cherubim and palm-trees"—decoration on doors

**Modern Equivalent:** Ezekiel 41 describes the temple's interior structure. The Holy of Holies is a perfect 20-cubit cube. The cherubim on walls have only two faces (human and lion), unlike the four-faced cherubim of chapter 1. The "table before YHWH" (41:22) is the incense altar. Palm trees symbolize paradise.

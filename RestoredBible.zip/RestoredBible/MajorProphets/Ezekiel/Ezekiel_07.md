# Ezekiel 7: The End Has Come

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## The End Announced (7:1-9)

**7:1** Moreover the word of YHWH came unto me, saying:

**7:2** "And you, son of man, thus says the Lord YHWH concerning the land of Israel: An end! The end is come upon the four corners of the land.

**7:3** "Now is the end upon you, and I will send my anger upon you, and will judge you according to your ways; and I will bring upon you all your abominations.

**7:4** "And my eye shall not spare you, neither will I have pity; but I will bring your ways upon you, and your abominations shall be in the midst of you; and you shall know that I am YHWH.

**7:5** "Thus says the Lord YHWH: An evil, a singular evil; behold, it comes.

**7:6** "An end is come, the end is come; it watches for you; behold, it comes.

**7:7** "The turn is come unto you, O inhabitant of the land; the time is come, the day is near; there is tumult, and not joyful shouting, upon the mountains.

**7:8** "Now will I shortly pour out my fury upon you, and spend my anger upon you, and will judge you according to your ways; and I will bring upon you all your abominations.

**7:9** "And my eye shall not spare, neither will I have pity; I will bring upon you according to your ways, and your abominations shall be in the midst of you; and you shall know that I YHWH do smite."

---

## The Day of Wrath (7:10-27)

**7:10** "Behold the day; behold, it comes; the turn is gone forth; the rod has blossomed, arrogance has budded.

**7:11** "Violence is risen up into a rod of wickedness; none of them shall remain, nor of their multitude, nor of their wealth; neither shall there be eminency among them.

**7:12** "The time is come, the day draws near; let not the buyer rejoice, nor the seller mourn; for wrath is upon all the multitude thereof.

**7:13** "For the seller shall not return to that which is sold, although they be yet alive; for the vision is touching the whole multitude thereof, which shall not return; neither shall any strengthen himself whose life is in his iniquity.

**7:14** "They have blown the horn, and have made all ready; but none goes to the battle; for my wrath is upon all the multitude thereof.

**7:15** "The sword is without, and the pestilence and the famine within; he that is in the field shall die with the sword; and he that is in the city, famine and pestilence shall devour him.

**7:16** "But they that escape of them shall escape, and shall be on the mountains like doves of the valleys, all of them moaning, every one in his iniquity.

**7:17** "All hands shall be slack, and all knees shall drip with water.

**7:18** "They shall also gird themselves with sackcloth, and horror shall cover them; and shame shall be upon all faces, and baldness upon all their heads.

**7:19** "They shall cast their silver in the streets, and their gold shall be as an unclean thing; their silver and their gold shall not be able to deliver them in the day of the wrath of YHWH; they shall not satisfy their souls, neither fill their bowels; because it has been the stumbling-block of their iniquity.

**7:20** "And as for the beauty of his ornament, He set it in majesty; but they made the images of their abominations and their detestable things therein; therefore have I set it unto them as an unclean thing.

**7:21** "And I will give it into the hands of the strangers for a prey, and to the wicked of the earth for a spoil; and they shall profane it.

**7:22** "I will also turn my face from them, and they shall profane my secret place; and robbers shall enter into it, and profane it.

**7:23** "Make the chain; for the land is full of bloody crimes, and the city is full of violence.

**7:24** "Wherefore I will bring the worst of the nations, and they shall possess their houses; I will also make the pride of the strong to cease; and their holy places shall be profaned.

**7:25** "Horror comes; and they shall seek peace, and there shall be none.

**7:26** "Calamity shall come upon calamity, and rumor shall be upon rumor; and they shall seek a vision of the prophet, and instruction shall perish from the priest, and counsel from the elders.

**7:27** "The king shall mourn, and the prince shall be clothed with appalment, and the hands of the people of the land shall be enfeebled; I will do unto them after their way, and according to their deserts will I judge them; and they shall know that I am YHWH."

---

## Synthesis Notes

**Key Restorations:**

**End Announced (7:1-9):**
**The Key Verse (7:2):**
"'An end! The end is come upon the four corners of the land.'"

*Qetz ba ha-qetz al-arba kanfot ha-aretz*—end comes.

**The Key Verse (7:3):**
"'Now is the end upon you.'"

*Attah ha-qetz alayikh*—end now.

"'I will send my anger upon you.'"

*Ve-shilachti appi vakh*—send anger.

"'Will judge you according to your ways.'"

*U-shefatikh ki-derakhayikh*—judge by ways.

"'I will bring upon you all your abominations.'"

*Ve-natatti alayikh et kol-to'avotayikh*—bring abominations.

**The Key Verse (7:4):**
"'My eye shall not spare you, neither will I have pity.'"

*Ve-lo-tachos eini alayikh ve-lo echmol*—no sparing.

"'Your abominations shall be in the midst of you.'"

*Ve-to'avotayikh be-tokekh tihyenah*—abominations present.

"'You shall know that I am YHWH.'"

*Vi-ydatem ki-ani YHWH*—recognition.

**The Key Verses (7:5-6):**
"'An evil, a singular evil; behold, it comes.'"

*Ra'ah achat ra'ah hinneh va'ah*—singular evil.

"'An end is come, the end is come.'"

*Qetz ba ba ha-qetz*—end comes.

"'It watches for you.'"

*Heqitz elayikh*—watches.

"'Behold, it comes.'"

*Hinneh va'ah*—it comes.

**The Key Verse (7:7):**
"'The turn is come unto you, O inhabitant of the land.'"

*Ba'ah ha-tzefira elayikh yoshev ha-aretz*—turn/doom comes.

"'The time is come, the day is near.'"

*Ba ha-et qarov ha-yom*—time/day near.

"'There is tumult, and not joyful shouting, upon the mountains.'"

*Mehumah ve-lo hed harim*—tumult, not joy.

**The Key Verses (7:8-9):**
"'Now will I shortly pour out my fury upon you.'"

*Attah mi-qarov eshpokh chamati alayikh*—pour fury.

"'Spend my anger upon you.'"

*Ve-khilleti appi vakh*—spend anger.

"'You shall know that I YHWH do smite.'"

*Vi-ydatem ki-ani YHWH makkeh*—YHWH smites.

**Day of Wrath (7:10-27):**
**The Key Verse (7:10):**
"'Behold the day; behold, it comes.'"

*Hinneh ha-yom hinneh va'ah*—day comes.

"'The turn is gone forth.'"

*Yatze'ah ha-tzefira*—doom gone forth.

"'The rod has blossomed.'"

*Tzatz ha-matteh*—rod blossoms.

"'Arrogance has budded.'"

*Parach ha-zadon*—arrogance buds.

**The Key Verse (7:11):**
"'Violence is risen up into a rod of wickedness.'"

*Ha-chamas qam le-matteh-resha*—violence as rod.

"'None of them shall remain.'"

*Lo-mehem ve-lo me-hamonam*—none remain.

"'Neither shall there be eminency among them.'"

*Ve-lo-noha vahem*—no eminence.

**The Key Verses (7:12-13):**
"'The time is come, the day draws near.'"

*Ba ha-et higgi'a ha-yom*—time, day near.

"'Let not the buyer rejoice, nor the seller mourn.'"

*Ha-qoneh al-yismach ve-ha-mokher al-yit'abbal*—no rejoicing/mourning.

"'For wrath is upon all the multitude thereof.'"

*Ki charon el-kol hamonah*—wrath on all.

"'The seller shall not return to that which is sold.'"

*Ki ha-mokher el-ha-mimkar lo yashuv*—no return.

"'Although they be yet alive.'"

*Ve-od ba-chayyim chayyatam*—while alive.

"'The vision is touching the whole multitude thereof.'"

*Ki-chazon el-kol hamonah*—vision touches all.

"'Which shall not return.'"

*Lo yashuv*—won't return.

**The Key Verse (7:14):**
"'They have blown the horn, and have made all ready.'"

*Taq'u va-taqqo'a ve-hakhin ha-kol*—horn blown.

"'But none goes to the battle.'"

*Ve-ein holekh la-milchamah*—none goes.

"'For my wrath is upon all the multitude thereof.'"

*Ki charoni el-kol hamonah*—wrath on all.

**The Key Verse (7:15):**
"'The sword is without, and the pestilence and the famine within.'"

*Ha-cherev ba-chutz ve-ha-dever ve-ha-ra'av mi-bayit*—sword outside, plague/famine inside.

"'He that is in the field shall die with the sword.'"

*Asher ba-sadeh ba-cherev yamut*—field = sword.

"'He that is in the city, famine and pestilence shall devour him.'"

*Va-asher ba-ir ra'av va-dever yokhelennu*—city = famine/plague.

**The Key Verse (7:16):**
"'They that escape of them shall escape.'"

*U-faltu peliteihem*—escapees.

"'Shall be on the mountains like doves of the valleys.'"

*Ve-hayu el-he-harim ke-yonei ha-ge'ayot*—like doves.

"'All of them moaning.'"

*Kullam homot*—moaning.

"'Every one in his iniquity.'"

*Ish ba-avono*—each in sin.

**The Key Verses (7:17-18):**
"'All hands shall be slack.'"

*Kol-ha-yadayim tirfenah*—slack hands.

"'All knees shall drip with water.'"

*Ve-khol-birkayyim telakhnah mayim*—weak knees.

"'They shall... gird themselves with sackcloth.'"

*Ve-chagru saqqim*—sackcloth.

"'Horror shall cover them.'"

*Ve-khissetah otam pallatzut*—horror.

"'Shame shall be upon all faces.'"

*Ve-el-kol-panim bushah*—shame.

"'Baldness upon all their heads.'"

*U-ve-khol-rasheihem qorchah*—baldness.

**The Key Verse (7:19):**
"'They shall cast their silver in the streets.'"

*Kaspam ba-chutzot yashlikhu*—cast silver.

"'Their gold shall be as an unclean thing.'"

*U-zehavam le-niddah yihyeh*—gold unclean.

"'Their silver and their gold shall not be able to deliver them in the day of the wrath of YHWH.'"

*Kaspam u-zehavam lo-yukhal le-hatztzilam be-yom evrat YHWH*—can't deliver.

"'They shall not satisfy their souls.'"

*Nafsham lo yesabeu*—not satisfied.

"'Neither fill their bowels.'"

*U-me'eihem lo yemalle'u*—not filled.

"'It has been the stumbling-block of their iniquity.'"

*Ki-mikhshol avonam hayah*—stumbling-block.

**The Key Verses (7:20-22):**
"'The beauty of his ornament, He set it in majesty.'"

*Ve-tzevi adyo le-ga'on samo*—ornament in majesty.

"'They made the images of their abominations... therein.'"

*Ve-tzalmei to'avoteihem shiqqutzehem asu vo*—images made.

"'Therefore have I set it unto them as an unclean thing.'"

*Al-ken netattiv lahem le-niddah*—made unclean.

"'I will give it into the hands of the strangers for a prey.'"

*U-netattiv be-yad ha-zarim le-vaz*—to strangers.

"'To the wicked of the earth for a spoil.'"

*U-le-rish'ei ha-aretz le-shalal*—to wicked.

"'They shall profane it.'"

*Ve-chilleluhu*—profane.

"'I will also turn my face from them.'"

*Va-hasiboti fanai me-hem*—turn face.

"'They shall profane my secret place.'"

*Ve-chillelu et-tzefuni*—profane secret place.

"'Robbers shall enter into it, and profane it.'"

*U-va'u-vah paritzim ve-chilleluha*—robbers enter.

**The Key Verses (7:23-24):**
"'Make the chain.'"

*Aseh ha-rattoq*—make chain.

"'The land is full of bloody crimes.'"

*Ki ha-aretz male'ah mishpat damim*—bloody crimes.

"'The city is full of violence.'"

*Ve-ha-ir male'ah chamas*—violence.

"'I will bring the worst of the nations.'"

*Ve-heveti ra'ei goyim*—worst nations.

"'They shall possess their houses.'"

*Ve-yareshu et-batteihem*—possess houses.

"'I will also make the pride of the strong to cease.'"

*Ve-hishbatti ge'on azzim*—pride cease.

"'Their holy places shall be profaned.'"

*Ve-nichallu miqdesheihem*—profaned.

**The Key Verses (7:25-27):**
"'Horror comes; and they shall seek peace, and there shall be none.'"

*Qefadah va'ah u-viqshu shalom ve-ayin*—horror, no peace.

"'Calamity shall come upon calamity.'"

*Hovah al-hovah tavo*—calamity upon calamity.

"'Rumor shall be upon rumor.'"

*U-shemu'ah el-shemu'ah tihyeh*—rumor upon rumor.

"'They shall seek a vision of the prophet.'"

*U-viqshu chazon mi-navi*—seek vision.

"'Instruction shall perish from the priest.'"

*Ve-torah tovad mi-kohen*—Torah perishes.

"'Counsel from the elders.'"

*Ve-etzah mi-zeqenim*—counsel gone.

"'The king shall mourn.'"

*Melekh yit'abbal*—king mourns.

"'The prince shall be clothed with appalment.'"

*Ve-nasi yilbash shemamah*—prince appalled.

"'The hands of the people of the land shall be enfeebled.'"

*Vi-ydei am-ha-aretz tibbahalnu*—hands enfeebled.

"'I will do unto them after their way.'"

*Mi-darkam e'eseh otam*—do by their way.

"'According to their deserts will I judge them.'"

*U-ve-mishpateihem eshpetем*—judge by deserts.

"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—recognition.

**Archetypal Layer:** Ezekiel 7 is an **"end" oracle**, containing **"An end! The end is come" (7:2, 6)**, **"The rod has blossomed, arrogance has budded" (7:10)**, **"Their silver and their gold shall not be able to deliver them" (7:19)**, **"Calamity shall come upon calamity" (7:26)**, and **"They shall seek a vision of the prophet, and instruction shall perish from the priest" (7:26)**.

**Ethical Inversion Applied:**
- "'An end! The end is come'"—end
- "'Upon the four corners of the land'"—all land
- "'Now is the end upon you'"—end now
- "'I will send my anger upon you'"—anger
- "'My eye shall not spare you, neither will I have pity'"—no sparing
- "'You shall know that I am YHWH'"—recognition
- "'An evil, a singular evil; behold, it comes'"—singular evil
- "'An end is come, the end is come; it watches for you'"—watching end
- "'The turn is come unto you'"—doom
- "'The time is come, the day is near'"—time/day near
- "'There is tumult, and not joyful shouting'"—tumult
- "'You shall know that I YHWH do smite'"—YHWH smites
- "'The rod has blossomed, arrogance has budded'"—rod/arrogance
- "'Violence is risen up into a rod of wickedness'"—violence as rod
- "'None of them shall remain'"—none remain
- "'Let not the buyer rejoice, nor the seller mourn'"—no transactions matter
- "'The seller shall not return to that which is sold'"—Jubilee void
- "'They have blown the horn... but none goes to the battle'"—no defense
- "'The sword is without, and the pestilence and the famine within'"—surrounded
- "'They that escape... shall be on the mountains like doves'"—mourning doves
- "'All hands shall be slack, and all knees shall drip with water'"—weakness
- "'They shall cast their silver in the streets'"—worthless silver
- "'Their gold shall be as an unclean thing'"—worthless gold
- "'Silver and... gold shall not be able to deliver them'"—can't deliver
- "'It has been the stumbling-block of their iniquity'"—stumbling-block
- "'They made the images of their abominations'"—abominations
- "'I will give it into the hands of the strangers'"—to strangers
- "'I will also turn my face from them'"—face turned
- "'Make the chain'"—chains
- "'The land is full of bloody crimes'"—bloody
- "'The city is full of violence'"—violence
- "'I will bring the worst of the nations'"—worst nations
- "'Horror comes; and they shall seek peace, and there shall be none'"—no peace
- "'Calamity shall come upon calamity'"—calamity
- "'Rumor shall be upon rumor'"—rumors
- "'They shall seek a vision of the prophet'"—seek vision
- "'Instruction shall perish from the priest'"—Torah perishes
- "'Counsel from the elders'"—counsel gone
- "'The king shall mourn'"—king mourns
- "'They shall know that I am YHWH'"—recognition

**Modern Equivalent:** Ezekiel 7 announces the end. "An end" (*qetz*) repeats urgently. The collapse of normal life—buying/selling meaningless, gold worthless, no vision from prophets—portrays total breakdown. This "Day of YHWH" theology intensifies Israel's own tradition against them.

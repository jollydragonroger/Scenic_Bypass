# Ezekiel 8: The Temple Vision — Abominations in Jerusalem

*From the Hebrew: וַיְהִי בַּשָּׁנָה הַשִּׁשִּׁית (Va-Yehi Ba-Shanah Ha-Shishshit) — And It Came to Pass in the Sixth Year*

---

## The Vision Begins (8:1-4)

**8:1** And it came to pass in the sixth year, in the sixth month, in the fifth day of the month, as I sat in my house, and the elders of Judah sat before me, that the hand of the Lord YHWH fell there upon me.

**8:2** Then I beheld, and lo a likeness as the appearance of fire; from the appearance of his loins and downward, fire; and from his loins and upward, as the appearance of brightness, as the color of electrum.

**8:3** And the form of a hand was put forth, and I was taken by a lock of my head; and the spirit lifted me up between the earth and the heaven, and brought me in the visions of God to Jerusalem, to the door of the gate of the inner court that looks toward the north; where was the seat of the image of jealousy, which provokes to jealousy.

**8:4** And, behold, the glory of the God of Israel was there, according to the vision that I saw in the plain.

---

## The Image of Jealousy (8:5-6)

**8:5** Then said he unto me: "Son of man, lift up your eyes now the way toward the north." So I lifted up my eyes the way toward the north, and behold northward of the gate of the altar this image of jealousy in the entry.

**8:6** And he said unto me: "Son of man, do you see what they do? Even the great abominations that the house of Israel do commit here, that I should go far off from my sanctuary? But you shall again see yet greater abominations."

---

## The Seventy Elders (8:7-13)

**8:7** And he brought me to the door of the court; and when I looked, behold a hole in the wall.

**8:8** Then said he unto me: "Son of man, dig now in the wall"; and when I had digged in the wall, behold a door.

**8:9** And he said unto me: "Go in, and see the wicked abominations that they do here."

**8:10** So I went in and saw; and behold every form of creeping things, and detestable beasts, and all the idols of the house of Israel, portrayed upon the wall round about.

**8:11** And there stood before them seventy men of the elders of the house of Israel, and in the midst of them stood Jaazaniah the son of Shaphan, every man with his censer in his hand; and a thick cloud of incense went up.

**8:12** Then said he unto me: "Son of man, have you seen what the elders of the house of Israel do in the dark, every man in his chambers of imagery? For they say: 'YHWH sees us not; YHWH has forsaken the land.'"

**8:13** He said also unto me: "You shall again see yet greater abominations which they do."

---

## The Weeping for Tammuz (8:14-15)

**8:14** Then he brought me to the door of the gate of YHWH's house which was toward the north; and, behold, there sat the women weeping for Tammuz.

**8:15** Then said he unto me: "Have you seen this, O son of man? You shall again see yet greater abominations than these."

---

## Sun Worship (8:16-18)

**8:16** And he brought me into the inner court of YHWH's house, and, behold, at the door of the temple of YHWH, between the porch and the altar, were about five and twenty men, with their backs toward the temple of YHWH, and their faces toward the east; and they worshipped the sun toward the east.

**8:17** Then he said unto me: "Have you seen this, O son of man? Is it a light thing to the house of Judah that they commit the abominations which they commit here, that they have filled the land with violence, and have turned again to provoke me? And, lo, they put the branch to their nose.

**8:18** "Therefore will I also deal in fury; my eye shall not spare, neither will I have pity; and though they cry in my ears with a loud voice, yet will I not hear them."

---

## Synthesis Notes

**Key Restorations:**

**Vision Begins (8:1-4):**
"In the sixth year, in the sixth month, in the fifth day."

*Ba-shanah ha-shishshit ba-chodesh ha-shish bi-chamishah la-chodesh*—September 592 BCE.

"I sat in my house, and the elders of Judah sat before me."

*Ani yoshev be-veiti ve-ziqnei Yehudah yoshevim lefanai*—elders present.

"The hand of the Lord YHWH fell there upon me."

*Va-tippol alai sham yad Adonai YHWH*—hand fell.

**The Key Verse (8:2):**
"A likeness as the appearance of fire."

*Demut ke-mar'eh-esh*—fire appearance.

"From the appearance of his loins and downward, fire."

*Mi-mar'eh motnav u-le-mattah esh*—fire below.

"From his loins and upward, as the appearance of brightness."

*U-mi-motnav u-le-ma'elah ke-mar'eh-zohar*—brightness above.

"As the color of electrum."

*Ke-ein ha-chashmal*—electrum.

**The Key Verse (8:3):**
"The form of a hand was put forth."

*Va-yishlach tavnit yad*—hand extended.

"I was taken by a lock of my head."

*Va-yiqqach oti be-tzitzit roshi*—by hair lock.

"The spirit lifted me up between the earth and the heaven."

*Va-tissa oti ruach bein ha-aretz u-vein ha-shamayim*—lifted between.

"Brought me in the visions of God to Jerusalem."

*Va-tave oti Yerushalaimah be-mar'ot Elohim*—to Jerusalem in visions.

"To the door of the gate of the inner court."

*El-petach sha'ar ha-penimit*—inner court gate.

"That looks toward the north."

*Ha-poneh tzafonah*—facing north.

"The seat of the image of jealousy."

*Moshav semel ha-qin'ah*—image of jealousy.

"Which provokes to jealousy."

*Ha-maqneh*—provokes.

**Image of Jealousy:**
Likely an Asherah pole or similar idol in the temple precincts.

**The Key Verse (8:4):**
"The glory of the God of Israel was there."

*Ve-hinneh-sham kevod Elohei Yisra'el*—glory present.

"According to the vision that I saw in the plain."

*Ka-mar'eh asher ra'iti ba-biq'ah*—like Chebar vision.

**Image of Jealousy (8:5-6):**
**The Key Verse (8:5):**
"'Lift up your eyes now the way toward the north.'"

*Sa-na einekha derekh tzafonah*—look north.

"Northward of the gate of the altar this image of jealousy."

*Mi-tzafon le-sha'ar ha-mizbech semel ha-qin'ah ha-zeh*—at altar gate.

**The Key Verse (8:6):**
"'Do you see what they do?'"

*Ha-ro'eh attah mah hemmah osim*—see what they do?

"'The great abominations that the house of Israel do commit here.'"

*To'avot gedolot asher beit-Yisra'el osim poh*—great abominations.

"'That I should go far off from my sanctuary?'"

*Le-rachaqah me-al miqdashi*—far from sanctuary.

"'You shall again see yet greater abominations.'"

*Od tashuv tir'eh to'avot gedolot*—greater abominations.

**Seventy Elders (8:7-13):**
"He brought me to the door of the court."

*Va-yave oti el-petach he-chatzer*—to court door.

"Behold a hole in the wall."

*Ve-hinneh chor-echad ba-qir*—hole in wall.

"'Dig now in the wall.'"

*Chator-na va-qir*—dig.

"Behold a door."

*Ve-hinneh petach echad*—a door.

"'Go in, and see the wicked abominations.'"

*Bo u-re'eh et-ha-to'avot ha-ra'ot*—see abominations.

**The Key Verse (8:10):**
"Every form of creeping things, and detestable beasts."

*Ve-khol-tavnit remes u-vehemah sheqetz*—creeping things, beasts.

"All the idols of the house of Israel."

*Ve-khol-gillulei beit Yisra'el*—all idols.

"Portrayed upon the wall round about."

*Mechuqqeh al-ha-qir saviv saviv*—portrayed on walls.

**Animal Imagery:**
Possibly Egyptian-style theriomorphic worship.

**The Key Verse (8:11):**
"Seventy men of the elders of the house of Israel."

*Ve-shiv'im ish mi-ziqnei beit-Yisra'el*—70 elders.

"In the midst of them stood Jaazaniah the son of Shaphan."

*Ve-Ya'azanyahu ben-Shafan omed be-tokham*—Jaazaniah.

**Jaazaniah:**
Son of Shaphan (Jeremiah's protector's family)—showing corruption reached respected families.

"Every man with his censer in his hand."

*Ish miqtarto be-yado*—censers.

"A thick cloud of incense went up."

*Va-atar anan ha-qetoret oleh*—incense cloud.

**The Key Verse (8:12):**
"'Have you seen what the elders of the house of Israel do in the dark?'"

*Ha-ra'ita... mah ziqnei beit-Yisra'el osim ba-choshekh*—in dark.

"'Every man in his chambers of imagery?'"

*Ish be-chadrei maskito*—imagery chambers.

"'For they say: YHWH sees us not.'"

*Ki omerim ein YHWH ro'eh otanu*—YHWH doesn't see.

"'YHWH has forsaken the land.'"

*Azav YHWH et-ha-aretz*—YHWH forsook.

**Weeping for Tammuz (8:14-15):**
**The Key Verse (8:14):**
"He brought me to the door of the gate of YHWH's house which was toward the north."

*Va-yave oti el-petach sha'ar beit-YHWH asher el-ha-tzafonah*—north gate.

"There sat the women weeping for Tammuz."

*Ve-hinneh-sham ha-nashim yoshevot mevakkot et-ha-Tammuz*—weeping for Tammuz.

**Tammuz:**
Mesopotamian fertility god whose annual death was mourned (equivalent to Adonis).

**Sun Worship (8:16-18):**
**The Key Verse (8:16):**
"He brought me into the inner court of YHWH's house."

*Va-yave oti el-chatzer beit-YHWH ha-penimit*—inner court.

"At the door of the temple of YHWH, between the porch and the altar."

*Ve-hinneh-petach heikhal YHWH bein ha-ulam u-vein ha-mizbech*—between porch and altar.

"About five and twenty men."

*Ke-esrim ve-chamishah ish*—25 men.

"With their backs toward the temple of YHWH."

*Achoreihem el-heikhal YHWH*—backs to temple.

"Their faces toward the east."

*U-feneihem qedmah*—faces east.

"They worshipped the sun toward the east."

*Ve-hemmah mishtachavitim qedmah la-shemesh*—sun worship.

**Sun Worship:**
Maximum insult—backs to YHWH's temple, facing east to worship the sun.

**The Key Verse (8:17):**
"'Is it a light thing to the house of Judah?'"

*Ha-naqel le-veit Yehudah*—light thing?

"'They commit the abominations which they commit here.'"

*Me-asot et-ha-to'avot asher asu poh*—abominations.

"'They have filled the land with violence.'"

*Ki-male'u et-ha-aretz chamas*—filled with violence.

"'Have turned again to provoke me.'"

*Va-yashuvu le-hakh'iseni*—provoke.

"'They put the branch to their nose.'"

*Ve-hinnam sholechim et-ha-zemorah el-appam*—branch to nose.

**Branch to Nose:**
Obscure gesture, possibly part of sun-worship ritual.

**The Key Verse (8:18):**
"'Therefore will I also deal in fury.'"

*Ve-gam-ani e'eseh ve-chemah*—deal in fury.

"'My eye shall not spare, neither will I have pity.'"

*Ve-lo-tachos eini ve-lo echmol*—no sparing.

"'Though they cry in my ears with a loud voice, yet will I not hear them.'"

*Ve-qare'u ve-oznai qol gadol ve-lo eshma otam*—won't hear.

**Archetypal Layer:** Ezekiel 8 begins the **temple vision (8-11)**, containing **the image of jealousy (8:3, 5)**, **seventy elders with censers offering to animal images (8:10-11)**, **"YHWH sees us not; YHWH has forsaken the land" (8:12)**, **women weeping for Tammuz (8:14)**, and **25 men worshipping the sun with backs to the temple (8:16)**.

**Ethical Inversion Applied:**
- "In the sixth year, in the sixth month"—September 592 BCE
- "I sat in my house, and the elders of Judah sat before me"—in exile
- "The hand of the Lord YHWH fell there upon me"—hand fell
- "A likeness as the appearance of fire"—fire form
- "I was taken by a lock of my head"—taken by hair
- "The spirit lifted me up between the earth and the heaven"—lifted
- "Brought me in the visions of God to Jerusalem"—visionary transport
- "The seat of the image of jealousy, which provokes"—image of jealousy
- "The glory of the God of Israel was there"—glory present
- "'Do you see what they do?'"—see
- "'The great abominations that the house of Israel do commit here'"—abominations
- "'That I should go far off from my sanctuary'"—far from sanctuary
- "'You shall again see yet greater abominations'"—greater abominations
- "Behold a hole in the wall"—hole
- "'Dig now in the wall'"—dig
- "'Go in, and see the wicked abominations'"—see
- "Every form of creeping things, and detestable beasts"—creatures
- "All the idols of the house of Israel, portrayed upon the wall"—idols portrayed
- "Seventy men of the elders of the house of Israel"—70 elders
- "Jaazaniah the son of Shaphan"—from good family
- "Every man with his censer in his hand"—censers
- "'They say: YHWH sees us not'"—YHWH doesn't see
- "'YHWH has forsaken the land'"—YHWH forsook
- "The women weeping for Tammuz"—Tammuz cult
- "About five and twenty men"—25 men
- "With their backs toward the temple of YHWH"—backs to temple
- "They worshipped the sun toward the east"—sun worship
- "'They have filled the land with violence'"—violence
- "'They put the branch to their nose'"—ritual gesture
- "'Therefore will I also deal in fury'"—fury
- "'My eye shall not spare'"—no sparing
- "'Though they cry in my ears... I will not hear them'"—won't hear

**Modern Equivalent:** Ezekiel 8 exposes four escalating abominations in the temple: image of jealousy, animal worship by elders, Tammuz weeping, and sun worship. Each is "greater" than the last. The claim "YHWH doesn't see" (8:12) justifies their actions—but YHWH shows Ezekiel everything.

# Ezekiel 33: The Watchman Renewed and Jerusalem's Fall

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## The Watchman's Responsibility (33:1-9)

**33:1** And the word of YHWH came unto me, saying:

**33:2** "Son of man, speak to the children of your people, and say unto them: When I bring the sword upon a land, if the people of the land take a man from among them, and set him for their watchman;

**33:3** "If, when he sees the sword come upon the land, he blow the horn, and warn the people;

**33:4** "Then whosoever hears the sound of the horn, and takes not warning, if the sword come, and take him away, his blood shall be upon his own head.

**33:5** "He heard the sound of the horn, and took not warning; his blood shall be upon him; whereas if he had taken warning he would have delivered his soul.

**33:6** "But if the watchman see the sword come, and blow not the horn, and the people be not warned, and the sword come, and take any person from among them, he is taken away in his iniquity, but his blood will I require at the watchman's hand.

**33:7** "So you, son of man, I have set you a watchman unto the house of Israel; therefore, when you shall hear the word at my mouth, warn them from me.

**33:8** "When I say unto the wicked: O wicked man, you shall surely die, and you do not speak to warn the wicked from his way; that wicked man shall die in his iniquity, but his blood will I require at your hand.

**33:9** "Nevertheless, if you warn the wicked of his way to turn from it, and he turn not from his way; he shall die in his iniquity, but you have delivered your soul."

---

## Individual Responsibility (33:10-20)

**33:10** "Therefore, O you son of man, say unto the house of Israel: Thus you speak, saying: 'Our transgressions and our sins are upon us, and we pine away in them; how then can we live?'

**33:11** "Say unto them: As I live," says the Lord YHWH, "I have no pleasure in the death of the wicked, but that the wicked turn from his way and live; turn, turn from your evil ways; for why will you die, O house of Israel?

**33:12** "And you, son of man, say unto the children of your people: The righteousness of the righteous shall not deliver him in the day of his transgression; and as for the wickedness of the wicked, he shall not stumble thereby in the day that he turns from his wickedness; neither shall he that is righteous be able to live thereby in the day that he sins.

**33:13** "When I say to the righteous, that he shall surely live; if he trust to his righteousness, and commit iniquity, none of his righteous deeds shall be remembered; but for his iniquity that he has committed, therein shall he die.

**33:14** "Again, when I say unto the wicked: You shall surely die; if he turn from his sin, and do that which is lawful and right;

**33:15** "If the wicked restore the pledge, give back that which he had taken by robbery, walk in the statutes of life, committing no iniquity; he shall surely live, he shall not die.

**33:16** "None of his sins that he has committed shall be remembered against him; he has done that which is lawful and right; he shall surely live.

**33:17** "Yet the children of your people say: 'The way of the Lord is not equal'; but as for them, their way is not equal.

**33:18** "When the righteous turns from his righteousness, and commits iniquity, he shall even die thereby.

**33:19** "And when the wicked turns from his wickedness, and does that which is lawful and right, he shall live thereby.

**33:20** "Yet you say: 'The way of the Lord is not equal.' O house of Israel, I will judge you every one after his ways."

---

## News of Jerusalem's Fall (33:21-22)

**33:21** And it came to pass in the twelfth year of our captivity, in the tenth month, in the fifth day of the month, that one that had escaped out of Jerusalem came unto me, saying: "The city is smitten."

**33:22** Now the hand of YHWH had been upon me in the evening, before he that was escaped came; and he had opened my mouth, until he came to me in the morning; and my mouth was opened, and I was no more dumb.

---

## The Survivors' False Confidence (33:23-29)

**33:23** And the word of YHWH came unto me, saying:

**33:24** "Son of man, they that inhabit those waste places in the land of Israel speak, saying: 'Abraham was one, and he inherited the land; but we are many; the land is given us for inheritance.'

**33:25** "Wherefore say unto them: Thus says the Lord YHWH: You eat with the blood, and lift up your eyes unto your idols, and shed blood; and shall you possess the land?

**33:26** "You stand upon your sword, you work abomination, and you defile every one his neighbor's wife; and shall you possess the land?

**33:27** "Say thus unto them: Thus says the Lord YHWH: As I live, surely they that are in the waste places shall fall by the sword, and him that is in the open field will I give to the beasts to be devoured, and they that are in the strongholds and in the caves shall die of the pestilence.

**33:28** "And I will make the land a desolation and an astonishment, and the pride of her power shall cease; and the mountains of Israel shall be desolate, that none shall pass through.

**33:29** "Then shall they know that I am YHWH, when I have made the land a desolation and an astonishment, because of all their abominations which they have committed."

---

## The People's Response (33:30-33)

**33:30** "And as for you, son of man, the children of your people that talk of you by the walls and in the doors of the houses, and speak one to another, every one to his brother, saying: Come, I pray you, and hear what is the word that comes forth from YHWH.

**33:31** "And they come unto you as the people come, and sit before you as my people, and hear your words, but do them not; for with their mouth they show much love, but their heart goes after their covetousness.

**33:32** "And, lo, you are unto them as a love song of one that has a pleasant voice, and can play well on an instrument; for they hear your words, but they do them not.

**33:33** "And when this comes to pass—behold, it comes—then shall they know that a prophet has been among them."

---

## Synthesis Notes

**Key Restorations:**

**Watchman's Responsibility (33:1-9):**
**The Key Verses (33:2-3):**
"'When I bring the sword upon a land.'"

*Eretz ki-avi alekha cherev*—sword on land.

"'If the people of the land take a man from among them, and set him for their watchman.'"

*Ve-laqechu am ha-aretz ish echad mi-qtzeihem ve-natenu oto lahem le-tzofeh*—watchman.

"'If, when he sees the sword come upon the land, he blow the horn, and warn the people.'"

*Ve-ra'ah et-ha-cherev ba'ah al-ha-aretz ve-taqa ba-shofar ve-hizhir et-ha-am*—blow horn, warn.

**The Key Verses (33:4-6):**
"'Whosoever hears the sound of the horn, and takes not warning.'"

*Ve-shama ha-shome'a et-qol ha-shofar ve-lo nizhar*—heard, didn't heed.

"'If the sword come, and take him away, his blood shall be upon his own head.'"

*Va-tavo cherev va-tiqqachehu damo ve-rosho yihyeh*—his own blood.

"'He heard the sound of the horn, and took not warning.'"

*Et-qol ha-shofar shama ve-lo nizhar*—heard, didn't heed.

"'His blood shall be upon him.'"

*Damo bo yihyeh*—his blood.

"'If he had taken warning he would have delivered his soul.'"

*Ve-hu nizhar nafsho millet*—would have saved.

"'But if the watchman see the sword come, and blow not the horn.'"

*Ve-ha-tzofeh ki-yir'eh et-ha-cherev ba'ah ve-lo-taqa ba-shofar*—didn't blow.

"'And the people be not warned.'"

*Ve-ha-am lo-nizhar*—not warned.

"'He is taken away in his iniquity.'"

*Hu ba-avono nillqach*—taken in iniquity.

"'His blood will I require at the watchman's hand.'"

*Ve-damo mi-yad ha-tzofeh eddrosh*—require from watchman.

**The Key Verses (33:7-9):**
"'I have set you a watchman unto the house of Israel.'"

*Tzofeh netattikha le-veit Yisra'el*—watchman.

"'When you shall hear the word at my mouth, warn them from me.'"

*Ve-shamata mi-pi davar ve-hizharta otam mimmeni*—warn from me.

"'When I say unto the wicked: O wicked man, you shall surely die.'"

*Be-omri la-rasha rasha mot tamut*—wicked shall die.

"'And you do not speak to warn the wicked from his way.'"

*Ve-lo dibbarta le-hazhir rasha mi-darko*—didn't warn.

"'That wicked man shall die in his iniquity.'"

*Hu rasha ba-avono yamut*—die in iniquity.

"'His blood will I require at your hand.'"

*Ve-damo mi-yadekha avaqesh*—require from you.

"'If you warn the wicked of his way to turn from it.'"

*Ve-attah ki-hizharta rasha mi-darko lashuv mimmennah*—warned.

"'And he turn not from his way.'"

*Ve-lo-shav mi-darko*—didn't turn.

"'He shall die in his iniquity.'"

*Hu ba-avono yamut*—die in iniquity.

"'You have delivered your soul.'"

*Ve-attah nafshekha hitztzalta*—delivered soul.

**Individual Responsibility (33:10-20):**
**The Key Verse (33:10):**
"''Our transgressions and our sins are upon us, and we pine away in them.''"

*Pesha'einu ve-chattoteinu aleinu u-vahem anachnu nemaqqim*—pine away.

"''How then can we live?''"

*Ve-eikh nichyeh*—how live?

**The Key Verse (33:11):**
"''As I live,' says the Lord YHWH."

*Chai-ani ne'um Adonai YHWH*—as I live.

"'I have no pleasure in the death of the wicked.'"

*Im-echpots be-mot ha-rasha*—no pleasure.

"'But that the wicked turn from his way and live.'"

*Ki im-be-shuv rasha mi-darko ve-chayah*—turn and live.

"'Turn, turn from your evil ways.'"

*Shuvu shuvu mi-darkheikem ha-ra'im*—turn, turn.

"'For why will you die, O house of Israel?'"

*Ve-lammah tamutu beit Yisra'el*—why die?

**The Key Verses (33:12-16):**
"'The righteousness of the righteous shall not deliver him in the day of his transgression.'"

*Tzidqat ha-tzaddiq lo-tatzzilennu be-yom pish'o*—won't deliver.

"'The wickedness of the wicked, he shall not stumble thereby in the day that he turns.'"

*Ve-rish'at ha-rasha lo-yikkashel bah be-yom shuvo me-rish'ato*—won't stumble.

"'If he trust to his righteousness, and commit iniquity.'"

*Be-vitcho al-tzidqato ve-asah avel*—trusts, sins.

"'None of his righteous deeds shall be remembered.'"

*Kol-tzidqotav lo tizzakharnah*—not remembered.

"'For his iniquity that he has committed, therein shall he die.'"

*U-ve-avlo asher-asah bo yamut*—die for iniquity.

"'If he turn from his sin, and do that which is lawful and right.'"

*Im-yashuv me-chattato ve-asah mishpat u-tzdaqah*—turn, do right.

"'If the wicked restore the pledge, give back that which he had taken by robbery.'"

*Chabol yashiv rasha gezelah yeshallem*—restore, return.

"'Walk in the statutes of life, committing no iniquity.'"

*Be-chuqqot ha-chayyim halakh le-vilti asot avel*—walk in life.

"'He shall surely live, he shall not die.'"

*Chayo yichyeh lo yamut*—shall live.

"'None of his sins that he has committed shall be remembered against him.'"

*Kol-chattotav asher chata lo tizzakharnah lo*—not remembered.

"'He has done that which is lawful and right.'"

*Mishpat u-tzdaqah asah*—done right.

**The Key Verses (33:17-20):**
"''The way of the Lord is not equal.''"

*Lo yittakhen derekh Adonai*—not equal.

"'As for them, their way is not equal.'"

*Ve-hemmah darkam lo yittakhen*—their way unequal.

"'When the righteous turns from his righteousness... he shall... die thereby.'"

*Be-shuv-tzaddiq mi-tzidqato... u-met bahem*—die.

"'When the wicked turns from his wickedness... he shall live thereby.'"

*U-ve-shuv rasha me-rish'ato... ve-chayah bahem*—live.

"'I will judge you every one after his ways.'"

*Ish ki-derakhav eshpot etkhem*—judge by ways.

**News of Jerusalem's Fall (33:21-22):**
**The Key Verse (33:21):**
"In the twelfth year of our captivity, in the tenth month, in the fifth day of the month."

*Ba-shtei esreh shanah le-galutenu ba-asiri ba-chamishah la-chodesh*—January 585 BCE.

"One that had escaped out of Jerusalem came unto me."

*Ba-elai ha-palit mi-Yerushalayim*—escapee came.

"'The city is smitten.'"

*Hukketah ha-ir*—city struck.

**The Key Verse (33:22):**
"The hand of YHWH had been upon me in the evening, before he that was escaped came."

*Ve-yad-YHWH hayetah elai ba-erev lifnei-bo ha-palit*—hand upon.

"He had opened my mouth, until he came to me in the morning."

*Va-yiftach et-pi ad-bo elai ba-boqer*—mouth opened.

"My mouth was opened, and I was no more dumb."

*Va-yipppatach pi ve-lo ne'elamti od*—no more dumb.

**Muteness Ends:**
Fulfills 24:27—Ezekiel's muteness ends when Jerusalem falls.

**Survivors' False Confidence (33:23-29):**
**The Key Verse (33:24):**
"'They that inhabit those waste places in the land of Israel speak.'"

*Yoshevei ha-choravot ha-elleh al-admat Yisra'el omerim*—survivors say.

"''Abraham was one, and he inherited the land; but we are many.''"

*Echad hayah Avraham va-yirash et-ha-aretz va-anachnu rabbim*—Abraham was one.

"''The land is given us for inheritance.''"

*Lanu nittenah ha-aretz le-morashah*—given to us.

**The Key Verses (33:25-26):**
"'You eat with the blood.'"

*Al-ha-dam tokhelu*—eat with blood.

"'Lift up your eyes unto your idols.'"

*Ve-einekhem tis'u el-gilluleikem*—eyes to idols.

"'Shed blood.'"

*Ve-dam tishpokhu*—shed blood.

"'Shall you possess the land?'"

*Ve-ha-aretz tirashu*—possess?

"'You stand upon your sword.'"

*Al-charvekhem amadettem*—stand on sword.

"'Work abomination.'"

*Asiten to'evah*—abomination.

"'You defile every one his neighbor's wife.'"

*Ve-ish et-eshet re'ehu tittamma'u*—defile neighbor's wife.

"'Shall you possess the land?'"

*Ve-ha-aretz tirashu*—possess?

**The Key Verses (33:27-29):**
"'They that are in the waste places shall fall by the sword.'"

*Asher ba-choravot ba-cherev yippolu*—fall by sword.

"'Him that is in the open field will I give to the beasts.'"

*Va-asher al-penei ha-sadeh la-chayyah netattiv le-okhloh*—to beasts.

"'They that are in the strongholds and in the caves shall die of the pestilence.'"

*Va-asher ba-metzadot u-va-me'arot ba-dever yamutu*—pestilence.

"'I will make the land a desolation and an astonishment.'"

*Ve-natatti et-ha-aretz shemamah u-meshammah*—desolation.

"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—recognition.

**People's Response (33:30-33):**
**The Key Verses (33:30-32):**
"'The children of your people that talk of you by the walls and in the doors.'"

*Benei ammekha ha-nidbarim bekha etzel ha-qirot u-ve-fitchei ha-battim*—talk about you.

"'Come, I pray you, and hear what is the word.'"

*Bo'u-na u-shim'u mah ha-davar*—come hear.

"'They come unto you as the people come.'"

*Va-yavo'u elekha ki-mevo am*—come.

"'Sit before you as my people.'"

*Va-yeshvu lefanekha ammi*—sit.

"'Hear your words, but do them not.'"

*Ve-shom'im et-devarekha ve-otam einam osim*—hear, don't do.

"'With their mouth they show much love.'"

*Ki agavim be-fihem hemmah osim*—mouth love.

"'Their heart goes after their covetousness.'"

*Acharei bitza'am libbam holekh*—heart to gain.

"'You are unto them as a love song.'"

*Ve-hinnekha lahem ke-shir agavim*—love song.

"'Of one that has a pleasant voice, and can play well on an instrument.'"

*Yefeh qol u-metiv nagen*—pleasant voice.

"'They hear your words, but they do them not.'"

*Ve-shom'im et-devarekha ve-osim einam otam*—hear, don't do.

**The Key Verse (33:33):**
"'When this comes to pass—behold, it comes.'"

*U-ve-vo'ah hinneh va'ah*—it comes.

"'Then shall they know that a prophet has been among them.'"

*Ve-yad'u ki navi hayah be-tokham*—knew prophet was there.

**Archetypal Layer:** Ezekiel 33 marks the **turning point**, containing **the watchman commission renewed (33:1-9)**, **"I have no pleasure in the death of the wicked" (33:11)**, **"Turn, turn from your evil ways" (33:11)**, **news of Jerusalem's fall (33:21)**, **Ezekiel's muteness ends (33:22)**, **survivors' false logic "Abraham was one" (33:24)**, and **the people treat Ezekiel as entertainment (33:32)**.

**Ethical Inversion Applied:**
- "'When I bring the sword upon a land'"—sword on land
- "'Set him for their watchman'"—watchman
- "'He blow the horn, and warn the people'"—blow, warn
- "'Whosoever hears the sound of the horn, and takes not warning'"—didn't heed
- "'His blood shall be upon his own head'"—his blood
- "'If the watchman see the sword come, and blow not the horn'"—didn't blow
- "'His blood will I require at the watchman's hand'"—require from watchman
- "'I have set you a watchman'"—Ezekiel watchman
- "'Warn them from me'"—warn
- "'His blood will I require at your hand'"—require from you
- "'If you warn the wicked... you have delivered your soul'"—delivered
- "''Our transgressions and our sins are upon us''"—despair
- "''How then can we live?''"—how live?
- "'I have no pleasure in the death of the wicked'"—no pleasure
- "'Turn, turn from your evil ways'"—turn, turn
- "'Why will you die, O house of Israel?'"—why die?
- "'The righteousness of the righteous shall not deliver him'"—won't deliver
- "'If he trust to his righteousness, and commit iniquity'"—false trust
- "'If he turn from his sin, and do that which is lawful'"—turn
- "'If the wicked restore the pledge'"—restore
- "'He shall surely live'"—shall live
- "''The way of the Lord is not equal''"—challenged
- "'Their way is not equal'"—their way
- "'I will judge you every one after his ways'"—individual judgment
- "In the twelfth year... one that had escaped... came"—January 585 BCE
- "'The city is smitten'"—city fallen
- "He had opened my mouth"—muteness ends
- "I was no more dumb"—speak again
- "''Abraham was one... we are many''"—false logic
- "'You eat with the blood'"—with blood
- "'Lift up your eyes unto your idols'"—idols
- "'Stand upon your sword'"—violence
- "'Shall you possess the land?'"—no
- "'They that are in the waste places shall fall'"—fall
- "'They come unto you as the people come'"—come
- "'Hear your words, but do them not'"—hear, don't do
- "'You are unto them as a love song'"—entertainment
- "'Of one that has a pleasant voice'"—pleasant voice
- "'They shall know that a prophet has been among them'"—knew prophet

**Modern Equivalent:** Ezekiel 33 pivots the book. The watchman theme (chapter 3) returns. News of Jerusalem's fall (33:21) ends Ezekiel's muteness and vindicated his prophecy. But survivors still sin (33:25-26) and treat Ezekiel as mere entertainment (33:32). Now restoration oracles begin (34-48).

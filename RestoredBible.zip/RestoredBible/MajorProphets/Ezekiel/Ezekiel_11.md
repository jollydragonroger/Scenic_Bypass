# Ezekiel 11: Judgment on the Leaders and the Glory Departs

*From the Hebrew: וַתִּשָּׂא אֹתִי רוּחַ (Va-Tissa Oti Ruach) — And the Spirit Lifted Me Up*

---

## Judgment on the Leaders (11:1-13)

**11:1** Moreover the spirit lifted me up, and brought me unto the east gate of YHWH's house, which looks eastward; and behold, at the door of the gate five and twenty men; and I saw in the midst of them Jaazaniah the son of Azzur, and Pelatiah the son of Benaiah, princes of the people.

**11:2** And he said unto me: "Son of man, these are the men that devise iniquity, and that give wicked counsel in this city;

**11:3** "That say: 'The time is not near to build houses; this city is the caldron, and we are the flesh.'

**11:4** "Therefore prophesy against them, prophesy, O son of man."

**11:5** And the spirit of YHWH fell upon me, and he said unto me: "Speak: Thus says YHWH: Thus have you said, O house of Israel; for I know the things that come into your mind.

**11:6** "You have multiplied your slain in this city, and you have filled the streets thereof with the slain.

**11:7** "Therefore thus says the Lord YHWH: Your slain whom you have laid in the midst of it, they are the flesh, and this city is the caldron; but you shall be brought forth out of the midst of it.

**11:8** "You have feared the sword; and the sword will I bring upon you," says the Lord YHWH.

**11:9** "And I will bring you forth out of the midst thereof, and deliver you into the hands of strangers, and will execute judgments upon you.

**11:10** "You shall fall by the sword; I will judge you in the border of Israel; and you shall know that I am YHWH.

**11:11** "This city shall not be your caldron, neither shall you be the flesh in the midst thereof; I will judge you in the border of Israel;

**11:12** "And you shall know that I am YHWH; for you have not walked in my statutes, neither have you executed my ordinances, but have done after the ordinances of the nations that are round about you."

**11:13** And it came to pass, when I prophesied, that Pelatiah the son of Benaiah died. Then fell I down upon my face, and cried with a loud voice, and said: "Ah Lord YHWH! Will you make a full end of the remnant of Israel?"

---

## Promise to the Exiles (11:14-21)

**11:14** And the word of YHWH came unto me, saying:

**11:15** "Son of man, as for your brethren, even your brethren, the men of your kindred, and all the house of Israel, all of them, concerning whom the inhabitants of Jerusalem have said: 'Get you far from YHWH; unto us is this land given for a possession';

**11:16** "Therefore say: Thus says the Lord YHWH: Although I have removed them far off among the nations, and although I have scattered them among the countries, yet have I been to them as a little sanctuary in the countries where they are come.

**11:17** "Therefore say: Thus says the Lord YHWH: I will even gather you from the peoples, and assemble you out of the countries where you have been scattered, and I will give you the land of Israel.

**11:18** "And they shall come there, and they shall take away all the detestable things thereof and all the abominations thereof from there.

**11:19** "And I will give them one heart, and I will put a new spirit within you; and I will remove the stony heart out of their flesh, and will give them a heart of flesh;

**11:20** "That they may walk in my statutes, and keep my ordinances, and do them; and they shall be my people, and I will be their God.

**11:21** "But as for them whose heart walks after the heart of their detestable things and their abominations, I will bring their way upon their own heads," says the Lord YHWH.

---

## The Glory Departs (11:22-25)

**11:22** Then did the cherubim lift up their wings, and the wheels were beside them; and the glory of the God of Israel was over them above.

**11:23** And the glory of YHWH went up from the midst of the city, and stood upon the mountain which is on the east side of the city.

**11:24** And a spirit lifted me up, and brought me in the vision by the spirit of God into Chaldea, to them of the captivity. So the vision that I had seen went up from me.

**11:25** Then I spoke unto them of the captivity all the things that YHWH had shown me.

---

## Synthesis Notes

**Key Restorations:**

**Judgment on Leaders (11:1-13):**
**The Key Verse (11:1):**
"The spirit lifted me up, and brought me unto the east gate."

*Va-tissa oti ruach va-tave oti el-sha'ar beit-YHWH ha-qadmoni*—east gate.

"Five and twenty men."

*Chamishah ve-esrim ish*—25 men.

"Jaazaniah the son of Azzur."

*Ya'azanyahu ben-Azzur*—Jaazaniah (different from 8:11).

"Pelatiah the son of Benaiah."

*U-Felatyahu ben-Benayahu*—Pelatiah.

"Princes of the people."

*Sarei ha-am*—princes.

**The Key Verses (11:2-3):**
"'These are the men that devise iniquity.'"

*Elleh ha-anashim ha-choshevim aven*—devise iniquity.

"'That give wicked counsel in this city.'"

*Ve-ha-yo'atzim atzat-ra ba-ir ha-zot*—wicked counsel.

"'They say: The time is not near to build houses.'"

*Ha-omerim lo ve-qarov benot battim*—not time to build.

"'This city is the caldron, and we are the flesh.'"

*Hi ha-sir va-anachnu ha-basar*—caldron, flesh.

**Caldron Metaphor:**
The leaders believed Jerusalem protected them like a pot protects meat.

**The Key Verses (11:5-7):**
"'The spirit of YHWH fell upon me.'"

*Va-tippol alai ruach YHWH*—spirit fell.

"'Thus have you said, O house of Israel.'"

*Ken amarttem beit Yisra'el*—thus you said.

"'I know the things that come into your mind.'"

*U-ma'alot ruchakhem ani yeda'tihah*—I know.

"'You have multiplied your slain in this city.'"

*Hirbeittem challeikem ba-ir ha-zot*—multiplied slain.

"'Filled the streets thereof with the slain.'"

*U-mille'tem chutzotekha challal*—filled streets.

"'Your slain whom you have laid in the midst of it, they are the flesh.'"

*Challeikem asher-samtem be-tokhah hemmah ha-basar*—they are flesh.

"'This city is the caldron.'"

*Ve-hi ha-sir*—caldron.

"'But you shall be brought forth out of the midst of it.'"

*Ve-etkhem otzi mi-tokhah*—brought out.

**Reversal:**
The slain victims are the "flesh"; the leaders will be removed and judged outside.

**The Key Verses (11:8-12):**
"'You have feared the sword.'"

*Cherev yeretem*—feared sword.

"'The sword will I bring upon you.'"

*Ve-cherev avi aleikhem*—bring sword.

"'I will bring you forth out of the midst thereof.'"

*Ve-hotzeti etkhem mi-tokhah*—bring out.

"'Deliver you into the hands of strangers.'"

*Ve-natatti etkhem be-yad zarim*—to strangers.

"'Execute judgments upon you.'"

*Ve-asiti vakhem shefatim*—judgments.

"'You shall fall by the sword.'"

*Ba-cherev tippolu*—fall by sword.

"'I will judge you in the border of Israel.'"

*El-gevul Yisra'el eshpot etkhem*—border judgment.

"'You shall know that I am YHWH.'"

*Vi-ydatem ki-ani YHWH*—recognition.

"'This city shall not be your caldron.'"

*Hi lo-tihyeh lakhem le-sir*—not caldron.

"'Neither shall you be the flesh in the midst thereof.'"

*Ve-attem lo-tihyu ve-tokhah le-vasar*—not flesh.

"'You have not walked in my statutes.'"

*Be-chuqqotai lo halakhtem*—not walked.

"'Have done after the ordinances of the nations.'"

*U-khe-mishpetei ha-goyim asher sevivoteikem asitem*—like nations.

**The Key Verse (11:13):**
"When I prophesied, that Pelatiah the son of Benaiah died."

*Va-yehi ke-hinnav'i u-Felatyahu ben-Benayahu met*—Pelatiah died.

"I fell down upon my face, and cried with a loud voice."

*Va-eppol al-panai va-ezaq qol gadol*—fell, cried.

"'Ah Lord YHWH! Will you make a full end of the remnant of Israel?'"

*Ahahh Adonai YHWH khalah attah oseh et she'erit Yisra'el*—full end?

**Prophetic Power:**
Pelatiah's death during the vision confirmed the prophecy's reality.

**Promise to Exiles (11:14-21):**
**The Key Verse (11:15):**
"'Your brethren, even your brethren, the men of your kindred.'"

*Achekha achekha anshei ge'ullatekha*—kinsmen.

"'All the house of Israel, all of them.'"

*Ve-khol-beit Yisra'el kullo*—all Israel.

"'The inhabitants of Jerusalem have said: Get you far from YHWH.'"

*Asher amru lahem yoshevei Yerushalayim rachqu me-al YHWH*—far from YHWH.

"'Unto us is this land given for a possession.'"

*Lanu hi nittenah ha-aretz le-morashah*—land given to us.

**Jerusalem's Arrogance:**
Those in Jerusalem mocked the exiles as abandoned by YHWH.

**The Key Verse (11:16):**
"'Although I have removed them far off among the nations.'"

*Ki hirchaqtim ba-goyim*—removed far.

"'Although I have scattered them among the countries.'"

*Ve-khi hafitzotsim ba-aratzot*—scattered.

"'Yet have I been to them as a little sanctuary.'"

*Va-ehi lahem le-miqdash me'at*—little sanctuary.

"'In the countries where they are come.'"

*Ba-aratzot asher-ba'u sham*—where they went.

**Little Sanctuary:**
YHWH's presence with the exiles despite temple loss.

**The Key Verse (11:17):**
"'I will even gather you from the peoples.'"

*Ve-qibbatzti etkhem min-ha-ammim*—gather.

"'Assemble you out of the countries where you have been scattered.'"

*Ve-asafti etkhem min-ha-aratzot asher nefotzotem bahem*—assemble.

"'I will give you the land of Israel.'"

*Ve-natatti lakhem et-admat Yisra'el*—give land.

**The Key Verses (11:18-19):**
"'They shall come there.'"

*U-va'u shammah*—come.

"'They shall take away all the detestable things.'"

*Ve-hesiru et-kol-shiqqutzeiyha*—remove detestable.

"'All the abominations thereof from there.'"

*Ve-et-kol to'avoteyha mimmennah*—remove abominations.

**The Key Verse (11:19):**
"'I will give them one heart.'"

*Ve-natatti lahem lev echad*—one heart.

"'I will put a new spirit within you.'"

*Ve-ruach chadashah etten be-qirbekhem*—new spirit.

"'I will remove the stony heart out of their flesh.'"

*Va-hasiroti lev ha-even mi-besaram*—remove stony heart.

"'Will give them a heart of flesh.'"

*Ve-natatti lahem lev basar*—heart of flesh.

**New Covenant:**
Anticipates Jeremiah 31:31-34 and Ezekiel 36:26-27.

**The Key Verse (11:20):**
"'That they may walk in my statutes.'"

*Lema'an be-chuqqotai yelekhu*—walk in statutes.

"'Keep my ordinances, and do them.'"

*Ve-et-mishpatai yishmeru ve-asu otam*—keep ordinances.

"'They shall be my people, and I will be their God.'"

*Ve-hayu-li le-am va-ani ehyeh lahem l'Elohim*—covenant formula.

**Glory Departs (11:22-25):**
**The Key Verse (11:22):**
"The cherubim lift up their wings."

*Va-yis'u ha-keruvim et-kanfeihem*—wings lifted.

"The wheels were beside them."

*Ve-ha-ofannim le-ummatam*—wheels beside.

"The glory of the God of Israel was over them above."

*U-khvod Elohei-Yisra'el aleihem mi-lema'elah*—glory above.

**The Key Verse (11:23):**
"The glory of YHWH went up from the midst of the city."

*Va-ya'al kevod-YHWH me-al tokh ha-ir*—glory left city.

"Stood upon the mountain which is on the east side of the city."

*Va-ya'amod al-ha-har asher mi-qedem la-ir*—on east mountain.

**Mount of Olives:**
The glory rests on the Mount of Olives before departing entirely.

**The Key Verses (11:24-25):**
"A spirit lifted me up."

*Ve-ruach nesa'atni*—spirit lifted.

"Brought me in the vision by the spirit of God into Chaldea."

*Va-tevi'eni Kasdimah el-ha-golah ba-mar'eh be-ruach Elohim*—to Chaldea.

"So the vision that I had seen went up from me."

*Va-ya'al me-alai ha-mar'eh asher ra'iti*—vision ended.

"I spoke unto them of the captivity all the things that YHWH had shown me."

*Va-adabber el-ha-golah et kol-divrei YHWH asher her'ani*—told exiles.

**Archetypal Layer:** Ezekiel 11 concludes the temple vision with **judgment on 25 leaders (11:1-12)**, **Pelatiah's death during prophecy (11:13)**, **"I have been to them as a little sanctuary" (11:16)**, **"I will give them one heart, and I will put a new spirit... a heart of flesh" (11:19)**, and **the glory departing to the Mount of Olives (11:23)**.

**Ethical Inversion Applied:**
- "The spirit lifted me up"—lifted
- "Brought me unto the east gate"—east gate
- "Five and twenty men"—25 men
- "Jaazaniah the son of Azzur, and Pelatiah the son of Benaiah"—named leaders
- "'These are the men that devise iniquity'"—devise iniquity
- "'That give wicked counsel in this city'"—wicked counsel
- "'This city is the caldron, and we are the flesh'"—false security
- "'The spirit of YHWH fell upon me'"—spirit fell
- "'I know the things that come into your mind'"—YHWH knows
- "'You have multiplied your slain in this city'"—multiplied slain
- "'Your slain... they are the flesh'"—victims are flesh
- "'You shall be brought forth out of the midst of it'"—brought out
- "'You have feared the sword'"—feared sword
- "'The sword will I bring upon you'"—sword comes
- "'I will judge you in the border of Israel'"—border judgment
- "'This city shall not be your caldron'"—not caldron
- "'You have not walked in my statutes'"—didn't walk
- "Pelatiah the son of Benaiah died"—death during prophecy
- "'Will you make a full end of the remnant of Israel?'"—intercession
- "'The inhabitants of Jerusalem have said: Get you far from YHWH'"—mocking exiles
- "'Unto us is this land given'"—arrogance
- "'I have been to them as a little sanctuary'"—little sanctuary
- "'I will even gather you from the peoples'"—gather
- "'I will give you the land of Israel'"—give land
- "'They shall take away all the detestable things'"—remove
- "'I will give them one heart'"—one heart
- "'I will put a new spirit within you'"—new spirit
- "'I will remove the stony heart'"—remove stone
- "'Will give them a heart of flesh'"—heart of flesh
- "'They may walk in my statutes'"—walk
- "'They shall be my people, and I will be their God'"—covenant
- "The glory of YHWH went up from the midst of the city"—glory left
- "Stood upon the mountain which is on the east side"—Mount of Olives
- "A spirit lifted me up... brought me... into Chaldea"—returned
- "I spoke unto them of the captivity all the things"—reported

**Modern Equivalent:** Ezekiel 11 concludes the temple vision (8-11). The glory's staged departure (cherubim → threshold → east gate → Mount of Olives → away) shows YHWH reluctantly leaving. The "little sanctuary" (11:16) promises presence with exiles. "Heart of flesh" (11:19) anticipates spiritual renewal.

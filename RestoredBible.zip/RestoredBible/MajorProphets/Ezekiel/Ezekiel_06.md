# Ezekiel 6: Prophecy Against the Mountains of Israel

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## Oracle Against the Mountains (6:1-7)

**6:1** And the word of YHWH came unto me, saying:

**6:2** "Son of man, set your face toward the mountains of Israel, and prophesy unto them,

**6:3** "And say: You mountains of Israel, hear the word of the Lord YHWH: Thus says the Lord YHWH to the mountains and to the hills, to the ravines and to the valleys: Behold, I, even I, will bring a sword upon you, and I will destroy your high places.

**6:4** "And your altars shall become desolate, and your sun-images shall be broken; and I will cast down your slain men before your idols.

**6:5** "And I will lay the carcasses of the children of Israel before their idols; and I will scatter your bones round about your altars.

**6:6** "In all your dwelling-places the cities shall be laid waste, and the high places shall be desolate; that your altars may be laid waste and made desolate, and your idols may be broken and cease, and your sun-images may be hewn down, and your works may be abolished.

**6:7** "And the slain shall fall in the midst of you, and you shall know that I am YHWH."

---

## A Remnant Preserved (6:8-10)

**6:8** "Yet will I leave a remnant, in that you shall have some that escape the sword among the nations, when you shall be scattered through the countries.

**6:9** "And they that escape of you shall remember me among the nations whither they shall be carried captive, how that I have been broken with their straying heart, which has departed from me, and with their eyes, which go astray after their idols; and they shall loathe themselves in their own sight for the evils which they have committed in all their abominations.

**6:10** "And they shall know that I am YHWH; I have not said in vain that I would do this evil unto them."

---

## Lamentation Over Israel (6:11-14)

**6:11** Thus says the Lord YHWH: "Smite with your hand, and stamp with your foot, and say: Alas! Because of all the evil abominations of the house of Israel; for they shall fall by the sword, by the famine, and by the pestilence.

**6:12** "He that is far off shall die of the pestilence; and he that is near shall fall by the sword; and he that remains and is besieged shall die by the famine; thus will I spend my fury upon them.

**6:13** "And you shall know that I am YHWH, when their slain men shall be among their idols round about their altars, upon every high hill, in all the tops of the mountains, and under every leafy tree, and under every thick terebinth, the place where they did offer sweet savor to all their idols.

**6:14** "And I will stretch out my hand upon them, and make the land desolate and waste, more than the wilderness of Diblah, throughout all their habitations; and they shall know that I am YHWH."

---

## Synthesis Notes

**Key Restorations:**

**Oracle Against Mountains (6:1-7):**
**The Key Verse (6:2):**
"'Set your face toward the mountains of Israel.'"

*Sim panekha el-harei Yisra'el*—face mountains.

"'Prophesy unto them.'"

*Ve-hinnave aleihem*—prophesy.

**The Key Verse (6:3):**
"'You mountains of Israel, hear the word of the Lord YHWH.'"

*Harei Yisra'el shim'u devar-Adonai YHWH*—hear.

"'To the mountains and to the hills, to the ravines and to the valleys.'"

*Le-harim ve-la-geva'ot la-afiqim ve-la-ge'ayot*—all terrain.

"'I, even I, will bring a sword upon you.'"

*Hineni ani mevi aleikhem cherev*—sword.

"'I will destroy your high places.'"

*Ve-ibbadti et-bamoteikhem*—destroy high places.

**High Places:**
*Bamot*—hilltop shrines for pagan worship.

**The Key Verse (6:4):**
"'Your altars shall become desolate.'"

*Ve-nashammuu mizbechoteikem*—altars desolate.

"'Your sun-images shall be broken.'"

*Ve-nishberu chammaneikem*—sun-images broken.

"'I will cast down your slain men before your idols.'"

*Ve-hipppalti challeikhem lifnei gilluleikhem*—slain before idols.

**Gillulim:**
"Idols"—a derogatory term suggesting "dung pellets."

**The Key Verse (6:5):**
"'I will lay the carcasses of the children of Israel before their idols.'"

*Ve-natatti et-pigrei benei Yisra'el lifnei gilluleihem*—carcasses before idols.

"'I will scatter your bones round about your altars.'"

*Ve-zereiti et-atzmoteikem sevivot mizbechoteikem*—bones scattered.

**The Key Verse (6:6):**
"'The cities shall be laid waste.'"

*Ha-arim techeravnah*—cities waste.

"'The high places shall be desolate.'"

*Ve-ha-bamot tishamnah*—high places desolate.

"'Your altars may be laid waste and made desolate.'"

*Lema'an yecherevu ve-ye'eshemu mizbechoteikem*—altars waste.

"'Your idols may be broken and cease.'"

*Ve-nishberu ve-shavtu gilluleikem*—idols broken.

"'Your sun-images may be hewn down.'"

*Ve-nigde'u chammaneikem*—sun-images hewn.

"'Your works may be abolished.'"

*Ve-nimchu ma'aseikem*—works abolished.

**The Key Verse (6:7):**
"'The slain shall fall in the midst of you.'"

*Ve-nafal challal be-tokhekem*—slain fall.

"'You shall know that I am YHWH.'"

*Vi-ydatem ki-ani YHWH*—know I am YHWH.

**Recognition Formula:**
"You shall know that I am YHWH"—appears over 70 times in Ezekiel.

**Remnant Preserved (6:8-10):**
**The Key Verse (6:8):**
"'Yet will I leave a remnant.'"

*Ve-hotarti*—leave remnant.

"'You shall have some that escape the sword among the nations.'"

*Bi-heyot lakhem pelitei cherev ba-goyim*—escapees.

"'When you shall be scattered through the countries.'"

*Be-hizzaroteikem ba-aratzot*—scattered.

**The Key Verse (6:9):**
"'They that escape of you shall remember me among the nations.'"

*Ve-zakheru feliteikem oti ba-goyim*—remember.

"'How that I have been broken with their straying heart.'"

*Asher nishbarti et-libbam ha-zoneh*—broken by straying heart.

"'Which has departed from me.'"

*Asher-sar me-alai*—departed.

"'With their eyes, which go astray after their idols.'"

*Ve-et-eineihem ha-zonot acharei gilluleihem*—eyes after idols.

"'They shall loathe themselves in their own sight.'"

*Ve-naqotu bi-feneihem*—loathe selves.

"'For the evils which they have committed.'"

*El-ha-ra'ot asher asu*—evils committed.

"'In all their abominations.'"

*Le-khol to'avoteihem*—abominations.

**YHWH Broken:**
Remarkably, YHWH is "broken" by Israel's unfaithfulness.

**The Key Verse (6:10):**
"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—know I am YHWH.

"'I have not said in vain that I would do this evil unto them.'"

*Lo el-chinnam dibbarti la'asot lahem ha-ra'ah ha-zot*—not in vain.

**Lamentation (6:11-14):**
**The Key Verse (6:11):**
"'Smite with your hand, and stamp with your foot.'"

*Hakkeh ve-khappekha u-reqa be-raglekha*—clap, stamp.

"'Say: Alas!'"

*Ve-emor ach*—alas.

"'Because of all the evil abominations of the house of Israel.'"

*El kol-to'avot ra'ot beit Yisra'el*—evil abominations.

"'They shall fall by the sword, by the famine, and by the pestilence.'"

*Asher ba-cherev ba-ra'av u-va-dever yippolu*—sword, famine, pestilence.

**The Key Verse (6:12):**
"'He that is far off shall die of the pestilence.'"

*Ha-rachoq ba-dever yamut*—far = pestilence.

"'He that is near shall fall by the sword.'"

*Ve-ha-qarov ba-cherev yippol*—near = sword.

"'He that remains and is besieged shall die by the famine.'"

*Ve-ha-nish'ar ve-ha-natzur ba-ra'av yamut*—besieged = famine.

"'Thus will I spend my fury upon them.'"

*Ve-khilleti chamati vam*—fury spent.

**The Key Verse (6:13):**
"'You shall know that I am YHWH.'"

*Vi-ydatem ki-ani YHWH*—know I am YHWH.

"'When their slain men shall be among their idols.'"

*Bi-heyot challeihem be-tokh gilluleihem*—slain among idols.

"'Round about their altars.'"

*Sevivot mizbechotam*—around altars.

"'Upon every high hill.'"

*El kol-giv'ah ramah*—high hill.

"'In all the tops of the mountains.'"

*Be-khol rashei he-harim*—mountaintops.

"'Under every leafy tree.'"

*Ve-tachat kol-etz ra'anan*—leafy tree.

"'Under every thick terebinth.'"

*Ve-tachat kol-elah avuttah*—thick terebinth.

"'The place where they did offer sweet savor to all their idols.'"

*Meqom asher natenu sham reach nichoach le-khol gilluleihem*—sweet savor.

**The Key Verse (6:14):**
"'I will stretch out my hand upon them.'"

*Ve-natiti et-yadi aleihem*—hand stretched.

"'Make the land desolate and waste.'"

*Ve-natatti et-ha-aretz shemamah u-meshammah*—desolate.

"'More than the wilderness of Diblah.'"

*Mi-midbar Divlatah*—Diblah wilderness.

"'Throughout all their habitations.'"

*Be-khol moshevoteihem*—all habitations.

"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—know I am YHWH.

**Archetypal Layer:** Ezekiel 6 contains **the oracle against the mountains of Israel (6:2-3)**, **"I will destroy your high places" (6:3)**, **the slain among idols (6:4-5, 13)**, **"I have been broken with their straying heart" (6:9)**, and **the recognition formula "You shall know that I am YHWH" (6:7, 10, 13, 14)**.

**Ethical Inversion Applied:**
- "'Set your face toward the mountains of Israel'"—face mountains
- "'Prophesy unto them'"—prophesy
- "'You mountains of Israel, hear'"—mountains hear
- "'I, even I, will bring a sword upon you'"—sword
- "'I will destroy your high places'"—destroy *bamot*
- "'Your altars shall become desolate'"—altars desolate
- "'Your sun-images shall be broken'"—sun-images broken
- "'I will cast down your slain men before your idols'"—slain before *gillulim*
- "'I will lay the carcasses... before their idols'"—carcasses
- "'I will scatter your bones round about your altars'"—bones scattered
- "'The cities shall be laid waste'"—cities waste
- "'The high places shall be desolate'"—high places desolate
- "'Your idols may be broken and cease'"—idols broken
- "'The slain shall fall in the midst of you'"—slain fall
- "'You shall know that I am YHWH'"—recognition formula
- "'Yet will I leave a remnant'"—remnant
- "'You shall have some that escape the sword'"—escapees
- "'When you shall be scattered through the countries'"—scattered
- "'They that escape... shall remember me'"—remember
- "'I have been broken with their straying heart'"—YHWH broken
- "'They shall loathe themselves'"—self-loathing
- "'I have not said in vain'"—not in vain
- "'Smite with your hand, and stamp with your foot'"—lament gesture
- "'Say: Alas!'"—alas
- "'They shall fall by the sword, by the famine, and by the pestilence'"—triad
- "'He that is far off... near... remains'"—all affected
- "'Their slain men shall be among their idols'"—slain among idols
- "'Upon every high hill... under every leafy tree'"—worship sites
- "'I will stretch out my hand upon them'"—hand stretched
- "'Make the land desolate and waste'"—desolate

**Modern Equivalent:** Ezekiel 6 prophesies against mountain shrines. The slain scattered among idols shows judgment's poetic justice. "I have been broken with their straying heart" (6:9) reveals YHWH's grief. The recognition formula frames judgment as revelation.

# Ezekiel 47: The River of Life and the Land Boundaries

*From the Hebrew: וַיְשִׁבֵנִי אֶל־פֶּתַח הַבַּיִת (Va-Yeshiveni El-Petach Ha-Bayit) — And He Brought Me Back unto the Door of the House*

---

## The River from the Temple (47:1-12)

**47:1** And he brought me back unto the door of the house; and, behold, waters issued out from under the threshold of the house eastward, for the forefront of the house was toward the east; and the waters came down from under, from the right side of the house, on the south of the altar.

**47:2** Then brought he me out by the way of the gate northward, and led me round by the way without unto the outer gate, by the way of the gate that looks toward the east; and, behold, there trickled forth waters on the right side.

**47:3** When the man went forth eastward with the line in his hand, he measured a thousand cubits, and he caused me to pass through the waters, waters that were to the ankles.

**47:4** Again he measured a thousand, and caused me to pass through the waters, waters that were to the knees. Again he measured a thousand, and caused me to pass through waters that were to the loins.

**47:5** Afterward he measured a thousand; and it was a river that I could not pass through; for the waters were risen, waters to swim in, a river that could not be passed through.

**47:6** And he said unto me: "Son of man, have you seen this?" Then he brought me, and caused me to return to the bank of the river.

**47:7** Now when I had been brought back, behold, upon the bank of the river were very many trees on the one side and on the other.

**47:8** Then said he unto me: "These waters issue forth toward the eastern region, and shall go down into the Arabah; and when they shall enter into the sea, into the sea of the putrid waters, the waters shall be healed.

**47:9** "And it shall come to pass, that every living creature wherewith it swarms, whithersoever the rivers shall come, shall live; and there shall be a very great multitude of fish; for these waters are come thither, that all things may be healed and may live whithersoever the river comes.

**47:10** "And it shall come to pass, that fishers shall stand by it from En-gedi even unto En-eglaim; there shall be a place for the spreading of nets; their fish shall be after their kinds, as the fish of the Great Sea, exceeding many.

**47:11** "But the miry places thereof, and the marshes thereof, shall not be healed; they shall be given for salt.

**47:12** "And by the river upon the bank thereof, on this side and on that side, shall grow every tree for food, whose leaf shall not wither, neither shall the fruit thereof fail; it shall bring forth new fruit every month, because the waters thereof issue out of the sanctuary; and the fruit thereof shall be for food, and the leaf thereof for healing."

---

## The Boundaries of the Land (47:13-23)

**47:13** Thus says the Lord YHWH: "This shall be the border, whereby you shall divide the land for inheritance according to the twelve tribes of Israel: Joseph shall have two portions.

**47:14** "And you shall inherit it, one as well as another, concerning which I lifted up my hand to give it unto your fathers; and this land shall fall unto you for inheritance.

**47:15** "And this shall be the border of the land: on the north side, from the Great Sea, by the way of Hethlon, unto the entrance of Zedad;

**47:16** "Hamath, Berothah, Sibraim, which is between the border of Damascus and the border of Hamath; Hazer-hatticon, which is by the border of Hauran.

**47:17** "And the border from the sea shall be Hazar-enon at the border of Damascus, and on the north northward is the border of Hamath. This is the north side.

**47:18** "And the east side, between Hauran and Damascus and Gilead, and the land of Israel, shall be the Jordan; from the north border unto the east sea shall you measure. This is the east side.

**47:19** "And the south side southward shall be from Tamar as far as the waters of Meriboth-kadesh, to the Brook of Egypt, unto the Great Sea. This is the south side southward.

**47:20** "And the west side shall be the Great Sea, from the south border as far as over against the entrance of Hamath. This is the west side.

**47:21** "So shall you divide this land unto you according to the tribes of Israel.

**47:22** "And it shall come to pass, that you shall divide it by lot for an inheritance unto you and to the strangers that sojourn among you, who shall beget children among you; and they shall be unto you as the home-born among the children of Israel; they shall have inheritance with you among the tribes of Israel.

**47:23** "And it shall come to pass, that in what tribe the stranger sojourns, there shall you give him his inheritance," says the Lord YHWH.

---

## Synthesis Notes

**Key Restorations:**

**River from the Temple (47:1-12):**
**The Key Verse (47:1):**
"He brought me back unto the door of the house."

*Va-yeshiveni el-petach ha-bayit*—to door.

"Behold, waters issued out from under the threshold of the house eastward."

*Ve-hinneh-mayim yotz'im mi-tachat miftan ha-bayit qadimah*—waters issued.

"The forefront of the house was toward the east."

*Ki-penei ha-bayit qadim*—east-facing.

"The waters came down from under, from the right side of the house, on the south of the altar."

*Ve-ha-mayim yordim mi-tachat mi-ketef ha-bayit ha-yemanit mi-negev la-mizbeach*—south of altar.

**The Key Verse (47:2):**
"He brought me out by the way of the gate northward."

*Va-yotzi'eni derekh-sha'ar tzafonah*—via north gate.

"Led me round by the way without unto the outer gate."

*Va-yesivbeni derekh chutz el-sha'ar ha-chutz*—round outside.

"By the way of the gate that looks toward the east."

*Derekh ha-poneh qadim*—east gate.

"Behold, there trickled forth waters on the right side."

*Ve-hinneh mayim mefakkikim min-ha-katef ha-yemanit*—waters trickle.

**The Key Verses (47:3-5):**
"The man went forth eastward with the line in his hand."

*Be-tzeit-ha-ish qadim ve-qav be-yado*—man with line.

"He measured a thousand cubits."

*Va-yamad elef ba-ammah*—1,000 cubits.

"He caused me to pass through the waters, waters that were to the ankles."

*Va-ya'avireni va-mayim mei ofsayim*—ankle-deep.

"Again he measured a thousand, and caused me to pass through... waters that were to the knees."

*Va-yamad elef va-ya'avireni va-mayim mayim birkayim*—knee-deep.

"Again he measured a thousand... waters that were to the loins."

*Va-yamad elef va-ya'avireni mei motnayim*—waist-deep.

"Afterward he measured a thousand; and it was a river that I could not pass through."

*Va-yamad elef nachal asher lo-ukhal la'avor*—impassable.

"The waters were risen, waters to swim in, a river that could not be passed through."

*Ki-ga'u ha-mayim mei sachu nachal asher lo ye'aver*—swimming depth.

**The Key Verses (47:6-7):**
"'Son of man, have you seen this?'"

*Ha-ra'ita ven-adam*—have you seen?

"He brought me, and caused me to return to the bank of the river."

*Va-yolikheni va-yeshiveni sefat ha-nachal*—to bank.

"Upon the bank of the river were very many trees on the one side and on the other."

*Ve-hinneh el-sefat ha-nachal etz rav me'od mi-zeh u-mi-zeh*—many trees.

**The Key Verses (47:8-9):**
"'These waters issue forth toward the eastern region.'"

*Ha-mayim ha-elleh yotz'im el-ha-gelilah ha-qadmonah*—to east.

"'Shall go down into the Arabah.'"

*Ve-yardu al-ha-Aravah*—to Arabah.

"'When they shall enter into the sea, into the sea of the putrid waters, the waters shall be healed.'"

*U-va'u ha-yamah el-ha-yamah ha-motza'im ve-nirpe'u ha-mayim*—sea healed.

**Dead Sea:**
"The sea of the putrid waters" = the Dead Sea.

"'Every living creature wherewith it swarms, whithersoever the rivers shall come, shall live.'"

*Ve-hayah kol-nefesh chayyah asher-yishritz el-kol asher-yavo sham nachalayim yichyeh*—all live.

"'There shall be a very great multitude of fish.'"

*Ve-hayah ha-dagah rabbah me'od*—many fish.

"'These waters are come thither, that all things may be healed and may live.'"

*Ki va'u shammah ha-mayim ha-elleh ve-yerape'u va-chay*—healed, live.

"'Whithersoever the river comes.'"

*Kol asher-yavo shammah ha-nachal*—wherever river goes.

**The Key Verses (47:10-12):**
"'Fishers shall stand by it from En-gedi even unto En-eglaim.'"

*Ve-hayah ya'amdu alav dayyagim me-Ein Gedi ve-ad Ein Eglayim*—fishers.

"'There shall be a place for the spreading of nets.'"

*Mishtoach la-charamim yihyeh*—spread nets.

"'Their fish shall be after their kinds, as the fish of the Great Sea, exceeding many.'"

*Le-minah tihyeh degatam ke-degat ha-yam ha-gadol rabbah me'od*—like Mediterranean.

"'The miry places thereof, and the marshes thereof, shall not be healed.'"

*Bitzatzav u-gevva'av ve-lo yerap'u*—not healed.

"'They shall be given for salt.'"

*Le-melach nittanu*—for salt.

"'By the river upon the bank thereof, on this side and on that side, shall grow every tree for food.'"

*Ve-al-ha-nachal ya'aleh al-sefato mi-zeh u-mi-zeh kol-etz ma'akhal*—food trees.

"'Whose leaf shall not wither.'"

*Lo-yibbol alehu*—leaf won't wither.

"'Neither shall the fruit thereof fail.'"

*Ve-lo-yittom piryo*—fruit won't fail.

"'It shall bring forth new fruit every month.'"

*Le-chodashav yevakker*—monthly fruit.

"'Because the waters thereof issue out of the sanctuary.'"

*Ki meimav min-ha-miqdash hemmah yotz'im*—from sanctuary.

"'The fruit thereof shall be for food.'"

*Ve-hayah piryo le-ma'akhal*—fruit for food.

"'The leaf thereof for healing.'"

*Ve-alehu li-terupah*—leaf for healing.

**Boundaries of the Land (47:13-23):**
**The Key Verses (47:13-14):**
"'This shall be the border, whereby you shall divide the land for inheritance.'"

*Zeh ha-gevul asher tithanchalu et-ha-aretz*—border for inheritance.

"'According to the twelve tribes of Israel.'"

*Li-sheneim asar shivtei Yisra'el*—12 tribes.

"'Joseph shall have two portions.'"

*Yosef chavalim*—Joseph double.

"'You shall inherit it, one as well as another.'"

*U-nechaltam otah ish ke-achiv*—equally.

"'Concerning which I lifted up my hand to give it unto your fathers.'"

*Asher nasati et-yadi le-titתah la-avoteikhem*—sworn to fathers.

"'This land shall fall unto you for inheritance.'"

*Ve-nafelah ha-aretz ha-zot lakhem be-nachalah*—your inheritance.

**The Key Verses (47:15-20):**
"'The border of the land: on the north side, from the Great Sea.'"

*Ve-zeh gevul ha-aretz li-fe'at tzafonah min-ha-yam ha-gadol*—north from Mediterranean.

"'By the way of Hethlon, unto the entrance of Zedad.'"

*Derekh Chetlon levo Tzedad*—via Hethlon.

"'Hamath, Berothah, Sibraim.'"

*Chamat Berotah Sivrayim*—northern cities.

"'The border from the sea shall be Hazar-enon at the border of Damascus.'"

*Ve-hayah gevul min-ha-yam Chattzar Einan gevul Dammeseq*—Hazar-enon.

"'On the north northward is the border of Hamath.'"

*Ve-tzafon tzafonah gevul Chamat*—Hamath border.

"'This is the north side.'"

*Ve-et pe'at tzafon*—north side.

"'The east side... shall be the Jordan.'"

*U-pe'at qedim... ha-Yarden*—Jordan east.

"'From the north border unto the east sea.'"

*Mi-gevul tzafon ad-ha-yam ha-qadmoni*—to Dead Sea.

"'This is the east side.'"

*Ve-et pe'at qadimah*—east side.

"'The south side southward shall be from Tamar.'"

*U-fe'at negbah teimanah mi-Tamar*—from Tamar.

"'As far as the waters of Meriboth-kadesh.'"

*Ad-mei Merivat Qadesh*—to Meribah-kadesh.

"'To the Brook of Egypt, unto the Great Sea.'"

*Nachlah el-ha-yam ha-gadol*—Wadi of Egypt to Mediterranean.

"'This is the south side southward.'"

*Ve-et pe'at negbah teimanah*—south side.

"'The west side shall be the Great Sea.'"

*U-fe'at-yam ha-yam ha-gadol*—Mediterranean.

"'From the south border as far as over against the entrance of Hamath.'"

*Mi-gevul ad-nokhach levo Chamat*—to Hamath entrance.

"'This is the west side.'"

*Zot pe'at-yam*—west side.

**The Key Verses (47:21-23):**
"'You shall divide this land unto you according to the tribes of Israel.'"

*Ve-chilaqtem et-ha-aretz ha-zot lakhem le-shivtei Yisra'el*—divide by tribes.

"'You shall divide it by lot for an inheritance unto you and to the strangers that sojourn among you.'"

*Ve-hayah tappilu otah be-nachalah lakhem ve-la-gerim ha-garim be-tokhekem*—also strangers.

"'Who shall beget children among you.'"

*Asher-holidu vanim be-tokhekem*—have children.

"'They shall be unto you as the home-born among the children of Israel.'"

*Ve-hayu lakhem ke-ezrach bi-venei Yisra'el*—like native-born.

"'They shall have inheritance with you among the tribes of Israel.'"

*Ittkhem yippelu be-nachalah be-tokh shivtei Yisra'el*—inherit with you.

"'In what tribe the stranger sojourns, there shall you give him his inheritance.'"

*Ve-hayah ba-shevet asher-gar ha-ger itto sham tittenu nachalato*—inherit where sojourning.

**Archetypal Layer:** Ezekiel 47 contains **the river from the temple (47:1-12)**—one of the most famous images in Ezekiel, **water deepening from ankle to knee to waist to swimming depth (47:3-5)**, **"the waters shall be healed" (47:8)**—the Dead Sea becoming fresh, **"fishers shall stand by it from En-gedi" (47:10)**, **"every tree for food, whose leaf shall not wither... monthly fruit... leaf thereof for healing" (47:12)**, and **land boundaries with provision for aliens to inherit (47:22-23)**.

**Ethical Inversion Applied:**
- "He brought me back unto the door of the house"—to door
- "Waters issued out from under the threshold of the house eastward"—waters from temple
- "From the right side of the house, on the south of the altar"—south of altar
- "There trickled forth waters on the right side"—trickle
- "He measured a thousand cubits"—1,000 cubits
- "Waters that were to the ankles"—ankle-deep
- "Waters that were to the knees"—knee-deep
- "Waters that were to the loins"—waist-deep
- "It was a river that I could not pass through"—impassable
- "Waters to swim in"—swimming depth
- "'Son of man, have you seen this?'"—have you seen?
- "Upon the bank of the river were very many trees"—many trees
- "'These waters issue forth toward the eastern region'"—eastward
- "'Shall go down into the Arabah'"—to Arabah
- "'When they shall enter into the sea... the waters shall be healed'"—sea healed
- "'Every living creature... shall live'"—all live
- "'There shall be a very great multitude of fish'"—many fish
- "'These waters are come thither, that all things may be healed'"—healed
- "'Fishers shall stand by it from En-gedi'"—fishers
- "'There shall be a place for the spreading of nets'"—nets
- "'Their fish shall be... as the fish of the Great Sea'"—like Mediterranean
- "'The miry places thereof... shall not be healed'"—not healed
- "'They shall be given for salt'"—for salt
- "'By the river... shall grow every tree for food'"—food trees
- "'Whose leaf shall not wither'"—won't wither
- "'Neither shall the fruit thereof fail'"—won't fail
- "'It shall bring forth new fruit every month'"—monthly
- "'Because the waters thereof issue out of the sanctuary'"—from sanctuary
- "'The fruit thereof shall be for food'"—for food
- "'The leaf thereof for healing'"—for healing
- "'This shall be the border'"—border
- "'According to the twelve tribes of Israel'"—12 tribes
- "'Joseph shall have two portions'"—Joseph double
- "'You shall inherit it, one as well as another'"—equally
- "'The north side, from the Great Sea'"—Mediterranean
- "'The east side... shall be the Jordan'"—Jordan
- "'The south side... from Tamar'"—Tamar
- "'The west side shall be the Great Sea'"—Mediterranean
- "'You shall divide this land'"—divide
- "'You shall divide it by lot... unto you and to the strangers'"—strangers included
- "'They shall be unto you as the home-born'"—like native
- "'They shall have inheritance with you'"—inherit together
- "'In what tribe the stranger sojourns, there shall you give him his inheritance'"—inherit where living

**Modern Equivalent:** Ezekiel 47 contains the famous river vision—water flowing from the temple, deepening as it goes, healing the Dead Sea and bringing life. This imagery appears in Revelation 22:1-2 (river of life, tree of life with healing leaves). The land boundaries follow Joshua's ideal. Remarkably, resident aliens may inherit land (47:22-23)—a progressive provision.

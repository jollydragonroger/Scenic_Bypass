# Ezekiel 1: The Vision of the Divine Chariot

*From the Hebrew: וַיְהִי בִּשְׁלֹשִׁים שָׁנָה (Va-Yehi Bi-Sheloshim Shanah) — And It Came to Pass in the Thirtieth Year*

---

## The Setting (1:1-3)

**1:1** Now it came to pass in the thirtieth year, in the fourth month, in the fifth day of the month, as I was among the captives by the river Chebar, that the heavens were opened, and I saw visions of God.

**1:2** In the fifth day of the month, which was the fifth year of king Jehoiachin's captivity,

**1:3** The word of YHWH came expressly unto Ezekiel the priest, the son of Buzi, in the land of the Chaldeans by the river Chebar; and the hand of YHWH was there upon him.

---

## The Four Living Creatures (1:4-14)

**1:4** And I looked, and, behold, a stormy wind came out of the north, a great cloud, with a fire flashing up, so that a brightness was round about it; and out of the midst thereof as the color of electrum, out of the midst of the fire.

**1:5** And out of the midst thereof came the likeness of four living creatures. And this was their appearance: they had the likeness of a man.

**1:6** And every one had four faces, and every one of them had four wings.

**1:7** And their feet were straight feet; and the sole of their feet was like the sole of a calf's foot; and they sparkled like the color of burnished brass.

**1:8** And they had the hands of a man under their wings on their four sides; and as for the faces and wings of them four,

**1:9** Their wings were joined one to another; they turned not when they went; they went every one straight forward.

**1:10** As for the likeness of their faces, they had the face of a man; and they four had the face of a lion on the right side; and they four had the face of an ox on the left side; they four had also the face of an eagle.

**1:11** Thus were their faces; and their wings were stretched upward; two wings of every one were joined one to another, and two covered their bodies.

**1:12** And they went every one straight forward; whither the spirit was to go, they went; they turned not when they went.

**1:13** As for the likeness of the living creatures, their appearance was like coals of fire, burning like the appearance of torches; it flashed up and down among the living creatures; and there was brightness to the fire, and out of the fire went forth lightning.

**1:14** And the living creatures ran and returned as the appearance of a flash of lightning.

---

## The Wheels (1:15-21)

**1:15** Now as I beheld the living creatures, behold one wheel upon the earth beside the living creatures, at each of the four faces thereof.

**1:16** The appearance of the wheels and their work was like unto the color of a beryl; and they four had one likeness; and their appearance and their work was as it were a wheel within a wheel.

**1:17** When they went, they went toward their four sides; they turned not when they went.

**1:18** As for their rings, they were high and they were dreadful; and they four had their rings full of eyes round about.

**1:19** And when the living creatures went, the wheels went beside them; and when the living creatures were lifted up from the earth, the wheels were lifted up.

**1:20** Whithersoever the spirit was to go, as the spirit was to go thither, so they went; and the wheels were lifted up beside them; for the spirit of the living creature was in the wheels.

**1:21** When those went, these went; and when those stood, these stood; and when those were lifted up from the earth, the wheels were lifted up beside them; for the spirit of the living creature was in the wheels.

---

## The Firmament and the Throne (1:22-28)

**1:22** And over the heads of the living creatures there was the likeness of a firmament, like the color of the terrible ice, stretched forth over their heads above.

**1:23** And under the firmament were their wings conformable the one to the other; this one of them had two which covered, and that one of them had two which covered, their bodies.

**1:24** And when they went, I heard the noise of their wings like the noise of great waters, like the voice of the Almighty, a noise of tumult like the noise of a host; when they stood, they let down their wings.

**1:25** For there was a voice above the firmament that was over their heads; when they stood, they let down their wings.

**1:26** And above the firmament that was over their heads was the likeness of a throne, as the appearance of a sapphire stone; and upon the likeness of the throne was a likeness as the appearance of a man upon it above.

**1:27** And I saw as the color of electrum, as the appearance of fire round about enclosing it, from the appearance of his loins and upward; and from the appearance of his loins and downward I saw as it were the appearance of fire, and there was brightness round about him.

**1:28** As the appearance of the bow that is in the cloud in the day of rain, so was the appearance of the brightness round about. This was the appearance of the likeness of the glory of YHWH. And when I saw it, I fell upon my face, and I heard a voice of one that spoke.

---

## Synthesis Notes

**Key Restorations:**

**Setting (1:1-3):**
"In the thirtieth year."

*Bi-sheloshim shanah*—30th year (possibly Ezekiel's age or from Josiah's reform).

"In the fourth month, in the fifth day of the month."

*Ba-chodesh ha-revi'i ba-chamishah la-chodesh*—July 593 BCE.

"I was among the captives by the river Chebar."

*Va-ani be-tokh ha-golah al-nehar-Kevar*—among exiles at Chebar.

**River Chebar:**
A canal near Nippur in Babylon.

"The heavens were opened."

*Niftekhu ha-shamayim*—heavens opened.

"I saw visions of God."

*Va-er'eh mar'ot Elohim*—divine visions.

**The Key Verse (1:2):**
"The fifth year of king Jehoiachin's captivity."

*Hi ha-shanah ha-chamishit le-galut ha-melekh Yoyakhin*—593 BCE.

**The Key Verse (1:3):**
"The word of YHWH came expressly unto Ezekiel the priest."

*Hayoh hayah devar-YHWH el-Yechezqel ha-kohen*—expressly.

"The son of Buzi."

*Ben-Buzi*—son of Buzi.

"In the land of the Chaldeans."

*Be-eretz Kasdim*—Babylon.

"The hand of YHWH was there upon him."

*Va-tehi alav sham yad-YHWH*—hand of YHWH.

**Living Creatures (1:4-14):**
**The Key Verse (1:4):**
"A stormy wind came out of the north."

*Ruach se'arah ba'ah min-ha-tzafon*—storm from north.

"A great cloud."

*Anan gadol*—great cloud.

"With a fire flashing up."

*Ve-esh mitlaqqachat*—flashing fire.

"A brightness was round about it."

*Ve-nogah lo saviv*—brightness.

"Out of the midst thereof as the color of electrum."

*U-mi-tokhah ke-ein ha-chashmal*—electrum.

**Chashmal:**
Electrum—a gold-silver alloy, or possibly amber-like radiance.

**The Key Verses (1:5-6):**
"The likeness of four living creatures."

*Demut arba chayyot*—four living creatures.

"They had the likeness of a man."

*Ve-zeh mar'eihen demut adam lahen*—human form.

"Every one had four faces."

*Ve-arba'ah fanim le-echat*—four faces.

"Every one of them had four wings."

*Ve-arba kenafayim le-achat lahen*—four wings.

**The Key Verse (1:10):**
"The face of a man."

*Penei adam*—human face.

"The face of a lion on the right side."

*U-fenei aryeh el-ha-yamin*—lion right.

"The face of an ox on the left side."

*U-fenei-shor me-ha-semol*—ox left.

"The face of an eagle."

*U-fenei-nesher*—eagle.

**Four Faces:**
Human (intelligence), Lion (royalty/strength), Ox (service/power), Eagle (swiftness/transcendence).

**The Key Verse (1:12):**
"Whither the spirit was to go, they went."

*El asher yihyeh-shammah ha-ruach lalekhet yelekhu*—spirit directs.

"They turned not when they went."

*Lo yissabbu be-lekhtam*—straight forward.

**The Key Verse (1:13):**
"Their appearance was like coals of fire."

*U-demut ha-chayyot mar'eihen ke-gachalei-esh bo'arot*—like coals.

"Burning like the appearance of torches."

*Ke-mar'eh ha-lappidim*—like torches.

"Out of the fire went forth lightning."

*U-min-ha-esh yotze'et baraq*—lightning.

**Wheels (1:15-21):**
**The Key Verses (1:15-16):**
"One wheel upon the earth beside the living creatures."

*Ofan echad ba-aretz etzel ha-chayyot*—wheel beside.

"Like unto the color of a beryl."

*Ke-ein tarshish*—beryl color.

"A wheel within a wheel."

*Ofan be-tokh ha-ofan*—wheel within wheel.

**Wheel Within Wheel:**
Multi-directional mobility—the throne-chariot can move any direction without turning.

**The Key Verse (1:18):**
"Their rings full of eyes round about."

*Ve-gabboteihen mele'ot einayim saviv le-arba'tan*—full of eyes.

**Eyes:**
Divine omniscience—seeing everywhere.

**The Key Verse (1:20):**
"The spirit of the living creature was in the wheels."

*Ki ruach ha-chayyah ba-ofannim*—spirit in wheels.

**Firmament and Throne (1:22-28):**
**The Key Verse (1:22):**
"The likeness of a firmament."

*Demut raqia*—firmament.

"Like the color of the terrible ice."

*Ke-ein ha-qerach ha-nora*—awesome ice/crystal.

"Stretched forth over their heads."

*Natui al-rasheihem mi-le-ma'elah*—stretched above.

**The Key Verse (1:24):**
"The noise of their wings like the noise of great waters."

*Qol kanfeihem ke-qol mayim rabbim*—like waters.

"Like the voice of the Almighty."

*Ke-qol Shaddai*—voice of Shaddai.

"A noise of tumult like the noise of a host."

*Qol hamullah ke-qol machaneh*—like army.

**The Key Verse (1:26):**
"Above the firmament... was the likeness of a throne."

*Mi-ma'al la-raqia... demut kisse*—throne above.

"As the appearance of a sapphire stone."

*Ke-mar'eh even-sappir*—sapphire throne.

"Upon the likeness of the throne was a likeness as the appearance of a man."

*Ve-al demut ha-kisse demut ke-mar'eh adam alav mi-le-ma'elah*—human appearance.

**The Key Verse (1:27):**
"I saw as the color of electrum."

*Va-ere ke-ein chashmal*—electrum.

"As the appearance of fire round about enclosing it."

*Ke-mar'eh-esh beit-lah saviv*—fire enclosing.

"From... his loins and upward."

*Mi-mar'eh motnav u-le-ma'elah*—above loins.

"From... his loins and downward."

*U-mi-mar'eh motnav u-le-mattah*—below loins.

"There was brightness round about him."

*Ve-nogah lo saviv*—brightness.

**The Key Verse (1:28):**
"As the appearance of the bow that is in the cloud."

*Ke-mar'eh ha-qeshet asher yihyeh ve-anan*—like rainbow.

"This was the appearance of the likeness of the glory of YHWH."

*Hu mar'eh demut kevod-YHWH*—glory's likeness.

"When I saw it, I fell upon my face."

*Va-er'eh va-eppol al-panai*—fell on face.

"I heard a voice of one that spoke."

*Va-eshma qol medabber*—heard voice.

**Archetypal Layer:** Ezekiel 1 contains the **Merkavah (Divine Chariot) vision**, including **"the heavens were opened, and I saw visions of God" (1:1)**, **four living creatures with four faces (1:10)**, **"a wheel within a wheel" with eyes (1:16, 18)**, **the throne of sapphire (1:26)**, and **"the appearance of the likeness of the glory of YHWH" (1:28)**.

**Ethical Inversion Applied:**
- "In the thirtieth year"—dating
- "I was among the captives by the river Chebar"—exile setting
- "The heavens were opened"—heaven opens
- "I saw visions of God"—divine visions
- "The fifth year of king Jehoiachin's captivity"—593 BCE
- "The word of YHWH came expressly unto Ezekiel the priest"—expressly
- "The hand of YHWH was there upon him"—hand of YHWH
- "A stormy wind came out of the north"—theophanic storm
- "A great cloud, with a fire flashing up"—cloud and fire
- "Out of the midst thereof as the color of electrum"—electrum
- "The likeness of four living creatures"—four creatures
- "They had the likeness of a man"—human form
- "Every one had four faces, and every one... four wings"—four faces/wings
- "The face of a man... lion... ox... eagle"—four faces
- "Whither the spirit was to go, they went"—spirit-directed
- "Their appearance was like coals of fire"—like fire
- "Out of the fire went forth lightning"—lightning
- "One wheel upon the earth beside the living creatures"—wheels
- "A wheel within a wheel"—wheel within wheel
- "Their rings full of eyes round about"—eyes
- "The spirit of the living creature was in the wheels"—spirit in wheels
- "The likeness of a firmament... like... terrible ice"—crystal firmament
- "The noise of their wings like the noise of great waters"—like waters
- "Like the voice of the Almighty"—Shaddai's voice
- "Above the firmament... the likeness of a throne"—throne
- "As the appearance of a sapphire stone"—sapphire
- "Upon the likeness of the throne... a likeness as the appearance of a man"—enthroned figure
- "I saw as the color of electrum, as the appearance of fire"—electrum/fire
- "As the appearance of the bow that is in the cloud"—rainbow
- "This was the appearance of the likeness of the glory of YHWH"—glory
- "I fell upon my face"—prostration
- "I heard a voice of one that spoke"—voice speaks

**Modern Equivalent:** Ezekiel 1's throne-chariot vision (Merkavah) became foundational for Jewish mysticism. The vision shows YHWH's glory present even in exile—portable, not bound to Jerusalem's temple. The careful language ("likeness," "appearance") maintains divine transcendence while affirming presence.

# Ezekiel 17: The Parable of Two Eagles and a Vine

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## The Parable (17:1-10)

**17:1** And the word of YHWH came unto me, saying:

**17:2** "Son of man, put forth a riddle, and speak a parable unto the house of Israel,

**17:3** "And say: Thus says the Lord YHWH: A great eagle with great wings and long pinions, full of feathers, which had divers colors, came unto Lebanon, and took the top of the cedar;

**17:4** "He cropped off the topmost of the young twigs thereof, and carried it into a land of traffic; he set it in a city of merchants.

**17:5** "He took also of the seed of the land, and planted it in a fruitful soil; he placed it beside many waters; he set it as a willow tree.

**17:6** "And it grew, and became a spreading vine of low stature, whose tendrils turned toward him, and the roots thereof were under him; so it became a vine, and brought forth branches, and shot forth sprigs.

**17:7** "There was also another great eagle with great wings and many feathers; and, behold, this vine did bend its roots toward him, and shot forth its branches toward him, from the beds of its plantation, that he might water it.

**17:8** "It was planted in a good soil by many waters, that it might bring forth branches, and that it might bear fruit, that it might be a stately vine.

**17:9** "Say: Thus says the Lord YHWH: Shall it prosper? Shall he not pull up the roots thereof, and cut off the fruit thereof, that it wither, even all the leaves of its sprouting? It shall wither, neither by great power nor by much people can it be raised from its roots.

**17:10** "Yea, behold, being planted, shall it prosper? Shall it not utterly wither, when the east wind touches it? In the beds where it grew it shall wither."

---

## The Interpretation (17:11-21)

**17:11** Moreover the word of YHWH came unto me, saying:

**17:12** "Say now to the rebellious house: Know you not what these things mean? Tell them: Behold, the king of Babylon came to Jerusalem, and took the king thereof, and the princes thereof, and brought them to him to Babylon.

**17:13** "And he took of the seed royal, and made a covenant with him, and brought him under an oath; and the mighty of the land he took away;

**17:14** "That the kingdom might be lowly, that it might not lift itself up, but that by keeping his covenant it might stand.

**17:15** "But he rebelled against him in sending his ambassadors into Egypt, that they might give him horses and much people. Shall he prosper? Shall he escape that does such things? Shall he break the covenant, and escape?

**17:16** "As I live," says the Lord YHWH, "surely in the place where the king dwells that made him king, whose oath he despised, and whose covenant he broke, even with him in the midst of Babylon he shall die.

**17:17** "Neither shall Pharaoh with his mighty army and great company help him in the war, when they cast up mounds and build forts, to cut off many souls.

**17:18** "Seeing he has despised the oath by breaking the covenant, when, lo, he had given his hand, and has done all these things, he shall not escape.

**17:19** "Therefore thus says the Lord YHWH: As I live, surely my oath that he has despised, and my covenant that he has broken, I will even bring it upon his own head.

**17:20** "And I will spread my net upon him, and he shall be taken in my snare, and I will bring him to Babylon, and will plead with him there for his treachery that he has committed against me.

**17:21** "And all his picked men in all his bands shall fall by the sword, and they that remain shall be scattered toward every wind; and you shall know that I YHWH have spoken it."

---

## The Messianic Cedar (17:22-24)

**17:22** Thus says the Lord YHWH: "I will also take of the lofty top of the cedar, and will set it; I will crop off from the topmost of its young twigs a tender one, and I will plant it upon a high mountain and eminent;

**17:23** "In the mountain of the height of Israel will I plant it; and it shall bring forth boughs, and bear fruit, and be a stately cedar; and under it shall dwell all birds of every wing, in the shadow of the branches thereof shall they dwell.

**17:24** "And all the trees of the field shall know that I YHWH have brought down the high tree, have exalted the low tree, have dried up the green tree, and have made the dry tree to flourish; I YHWH have spoken and have done it."

---

## Synthesis Notes

**Key Restorations:**

**Parable (17:1-10):**
**The Key Verse (17:2):**
"'Put forth a riddle, and speak a parable.'"

*Chud chidah u-meshol mashal*—riddle and parable.

**The Key Verses (17:3-4):**
"'A great eagle with great wings and long pinions.'"

*Ha-nesher ha-gadol gedol ha-kenafayim arekh ha-ever*—great eagle.

"'Full of feathers, which had divers colors.'"

*Male ha-notzah asher-lo ha-riqmah*—many colors.

"'Came unto Lebanon, and took the top of the cedar.'"

*Ba el-ha-Levanon va-yiqqach et-tzammeret ha-erez*—took cedar top.

"'He cropped off the topmost of the young twigs.'"

*Et-rosh yeniqotav qataf*—cropped twigs.

"'Carried it into a land of traffic.'"

*Va-yevi'ehu el-eretz kena'an*—land of trade.

"'Set it in a city of merchants.'"

*Be-ir rokhelim samo*—merchant city.

**First Eagle = Nebuchadnezzar:**
Took Jehoiachin to Babylon (597 BCE).

**The Key Verses (17:5-6):**
"'He took also of the seed of the land.'"

*Va-yiqqach mi-zera ha-aretz*—seed of land.

"'Planted it in a fruitful soil.'"

*Va-yittenehu bi-sedeh zera*—fruitful soil.

"'He placed it beside many waters.'"

*Qachu al-mayim rabbim*—many waters.

"'He set it as a willow tree.'"

*Tzaftzafah samo*—willow.

"'It grew, and became a spreading vine of low stature.'"

*Va-yitzmach va-yehi le-gefen sorachat shiflat qomah*—low vine.

"'Whose tendrils turned toward him.'"

*Lifnot daliyyoteyha elav*—toward him.

**Seed of Land = Zedekiah:**
Made vassal king by Nebuchadnezzar.

**The Key Verses (17:7-8):**
"'There was also another great eagle.'"

*Va-yehi nesher echad gadol*—second eagle.

"'This vine did bend its roots toward him.'"

*Ve-hinneh ha-gefen ha-zot kafenah shorasheyha alav*—bent toward.

"'Shot forth its branches toward him.'"

*Ve-daliyyoteyha shillechah-lo*—branches toward.

"'That he might water it.'"

*Le-hashqot otah*—water it.

**Second Eagle = Pharaoh:**
Egypt, to whom Zedekiah turned for help.

**The Key Verses (17:9-10):**
"'Shall it prosper?'"

*Ha-titzlach*—prosper?

"'Shall he not pull up the roots thereof?'"

*Ha-lo et-shorasheyha yenattеq*—pull roots?

"'Cut off the fruit thereof, that it wither?'"

*Ve-et-piryah yiqosef ve-yavesh*—cut fruit?

"'Shall it not utterly wither, when the east wind touches it?'"

*Ha-lo be-ge'at-bah ruach ha-qadim tivash yavosh*—east wind withers.

**East Wind = Babylon:**
Coming from the east to destroy.

**Interpretation (17:11-21):**
**The Key Verses (17:12-14):**
"'The king of Babylon came to Jerusalem.'"

*Ba melekh-Bavel Yerushalayim*—Babylon came.

"'Took the king thereof, and the princes thereof.'"

*Va-yiqqach et-malkah ve-et-sareyha*—took king/princes.

"'Brought them to him to Babylon.'"

*Va-yave otam elav Bavelah*—to Babylon.

"'He took of the seed royal.'"

*Va-yiqqach mi-zera ha-melukhah*—royal seed.

"'Made a covenant with him.'"

*Va-yikhrot itto berit*—made covenant.

"'Brought him under an oath.'"

*Va-yave oto be-alah*—oath.

"'The mighty of the land he took away.'"

*Ve-et-eilei ha-aretz laqach*—took mighty.

"'That the kingdom might be lowly.'"

*Li-heyot mamlakhah shefalah*—lowly kingdom.

"'That it might not lift itself up.'"

*Le-vilti hitnaשse*—not lift up.

"'By keeping his covenant it might stand.'"

*Lishmor et-berito le-omdah*—stand by covenant.

**The Key Verses (17:15-16):**
"'He rebelled against him in sending his ambassadors into Egypt.'"

*Va-yimrod-bo lishloch mal'akhav Mitzrayim*—rebelled, sent to Egypt.

"'That they might give him horses and much people.'"

*La-tet-lo susim ve-am rav*—horses, army.

"'Shall he prosper?'"

*Ha-yitzlach*—prosper?

"'Shall he break the covenant, and escape?'"

*Va-hefer berit ve-nimלat*—break, escape?

"''As I live,' says the Lord YHWH."

*Chai-ani ne'um Adonai YHWH*—as I live.

"'In the midst of Babylon he shall die.'"

*Be-tokh Bavel yamut*—die in Babylon.

**The Key Verses (17:17-18):**
"'Neither shall Pharaoh with his mighty army and great company help him in the war.'"

*Ve-lo ve-chayil gadol u-ve-qahal rav ya'aseh oto Faroh ba-milchamah*—Pharaoh won't help.

"'Seeing he has despised the oath by breaking the covenant.'"

*U-vazah alah le-hafer berit*—despised oath.

"'When, lo, he had given his hand.'"

*Ve-hinneh natan yado*—gave hand.

"'He shall not escape.'"

*Lo yimmalet*—won't escape.

**The Key Verses (17:19-21):**
"'My oath that he has despised, and my covenant that he has broken.'"

*Alati asher bazah u-veriti asher hefar*—my oath, my covenant.

"'I will even bring it upon his own head.'"

*U-netattiv be-rosho*—on his head.

"'I will spread my net upon him.'"

*U-farashti alav et-rishti*—spread net.

"'He shall be taken in my snare.'"

*Ve-nitpas bi-metzudati*—caught.

"'I will bring him to Babylon.'"

*Va-havi'otihu Bavelah*—to Babylon.

"'Will plead with him there for his treachery.'"

*Ve-nishpattti itto sham be-ma'alo asher ma'al-bi*—plead for treachery.

"'All his picked men... shall fall by the sword.'"

*Ve-khol mivrachav be-khol-agappav ba-cherev yippolu*—fall by sword.

"'They that remain shall be scattered toward every wind.'"

*Ve-ha-nish'arim le-khol-ruach yipparesu*—scattered.

**YHWH's Covenant:**
Zedekiah's oath was sworn in YHWH's name, so breaking it was breaking YHWH's covenant.

**Messianic Cedar (17:22-24):**
**The Key Verse (17:22):**
"'I will also take of the lofty top of the cedar.'"

*Ve-laqachti ani mi-tzammeret ha-erez ha-ramah*—take cedar top.

"'I will crop off from the topmost of its young twigs a tender one.'"

*Me-rosh yonqotav rakh eqtof*—tender twig.

"'I will plant it upon a high mountain and eminent.'"

*Ve-shataltי ani al har-gavoha ve-talul*—high mountain.

**The Key Verse (17:23):**
"'In the mountain of the height of Israel will I plant it.'"

*Be-har merom Yisra'el eshttlennu*—height of Israel.

"'It shall bring forth boughs, and bear fruit, and be a stately cedar.'"

*Ve-nasa anaf ve-asah feri ve-hayah le-erez addir*—stately cedar.

"'Under it shall dwell all birds of every wing.'"

*Ve-shakhenu tachtav kol tzippor kol-kanaf*—all birds dwell.

"'In the shadow of the branches thereof shall they dwell.'"

*Be-tzel daliyyotav yishkonu*—in shadow.

**The Key Verse (17:24):**
"'All the trees of the field shall know that I YHWH.'"

*Ve-yad'u kol-atzei ha-sadeh ki ani YHWH*—trees know.

"'Have brought down the high tree.'"

*Hishpalti etz gavoha*—brought down high.

"'Have exalted the low tree.'"

*Higbahti etz shafel*—exalted low.

"'Have dried up the green tree.'"

*Hovashti etz lach*—dried green.

"'Have made the dry tree to flourish.'"

*Ve-hifrachtি etz yavesh*—flourished dry.

"'I YHWH have spoken and have done it.'"

*Ani YHWH dibbarti ve-asiti*—spoken and done.

**Messianic Hope:**
YHWH will plant a new Davidic ruler on Zion's mountain.

**Archetypal Layer:** Ezekiel 17 contains **the parable of two eagles and a vine (17:3-10)**, **the first eagle = Nebuchadnezzar, second eagle = Pharaoh (17:12-17)**, **Zedekiah's broken oath as YHWH's broken covenant (17:19)**, and **the messianic "tender twig" planted on "the mountain of the height of Israel" (17:22-24)**.

**Ethical Inversion Applied:**
- "'Put forth a riddle, and speak a parable'"—riddle
- "'A great eagle with great wings'"—first eagle
- "'Came unto Lebanon, and took the top of the cedar'"—took Jehoiachin
- "'Carried it into a land of traffic'"—to Babylon
- "'He took also of the seed of the land'"—Zedekiah
- "'Planted it in a fruitful soil'"—vassal king
- "'It grew, and became a spreading vine of low stature'"—low kingdom
- "'There was also another great eagle'"—second eagle
- "'This vine did bend its roots toward him'"—turned to Egypt
- "'Shall it prosper?'"—will it prosper?
- "'Shall it not utterly wither, when the east wind touches it?'"—east wind
- "'The king of Babylon came to Jerusalem'"—Babylon came
- "'Took the king thereof'"—took king
- "'Made a covenant with him'"—covenant
- "'Brought him under an oath'"—oath
- "'He rebelled against him in sending his ambassadors into Egypt'"—rebelled
- "'Shall he break the covenant, and escape?'"—can't escape
- "'In the midst of Babylon he shall die'"—die there
- "'Neither shall Pharaoh... help him in the war'"—Pharaoh won't help
- "'My oath that he has despised, and my covenant that he has broken'"—YHWH's oath
- "'I will spread my net upon him'"—net
- "'He shall be taken in my snare'"—caught
- "'Will plead with him there for his treachery'"—treachery
- "'I will also take of the lofty top of the cedar'"—YHWH plants
- "'A tender one'"—tender twig
- "'I will plant it upon a high mountain'"—high mountain
- "'In the mountain of the height of Israel'"—Zion
- "'It shall... be a stately cedar'"—stately cedar
- "'Under it shall dwell all birds'"—all birds
- "'Have brought down the high tree'"—brought down
- "'Have exalted the low tree'"—exalted low
- "'I YHWH have spoken and have done it'"—YHWH does

**Modern Equivalent:** Ezekiel 17 uses allegory for current events. Zedekiah broke his vassal oath, which was sworn in YHWH's name—making it YHWH's covenant (17:19). The messianic ending (17:22-24) promises YHWH will plant a new Davidic ruler when human kings fail.

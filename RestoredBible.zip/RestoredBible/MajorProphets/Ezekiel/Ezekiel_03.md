# Ezekiel 3: The Scroll Eaten and the Watchman

*From the Hebrew: וַיֹּאמֶר אֵלַי בֶּן־אָדָם (Va-Yomer Elai Ben-Adam) — And He Said Unto Me, Son of Man*

---

## Eating the Scroll (3:1-3)

**3:1** And he said unto me: "Son of man, eat that which you find; eat this scroll, and go, speak unto the house of Israel."

**3:2** So I opened my mouth, and he caused me to eat that scroll.

**3:3** And he said unto me: "Son of man, cause your belly to eat, and fill your bowels with this scroll that I give you." Then did I eat it; and it was in my mouth as honey for sweetness.

---

## The Commission Continued (3:4-11)

**3:4** And he said unto me: "Son of man, go, get you unto the house of Israel, and speak with my words unto them.

**3:5** "For you are not sent to a people of a strange speech and of a hard language, but to the house of Israel;

**3:6** "Not to many peoples of a strange speech and of a hard language, whose words you cannot understand. Surely, if I sent you to them, they would hearken unto you.

**3:7** "But the house of Israel will not hearken unto you; for they will not hearken unto me; for all the house of Israel are of a hard forehead and of a stiff heart.

**3:8** "Behold, I have made your face hard against their faces, and your forehead hard against their foreheads.

**3:9** "As an adamant harder than flint have I made your forehead; fear them not, neither be dismayed at their looks, for they are a rebellious house."

**3:10** Moreover he said unto me: "Son of man, all my words that I shall speak unto you receive in your heart, and hear with your ears.

**3:11** "And go, get you to them of the captivity, unto the children of your people, and speak unto them, and tell them: Thus says the Lord YHWH; whether they will hear, or whether they will forbear."

---

## The Spirit Lifts Ezekiel (3:12-15)

**3:12** Then the spirit lifted me up, and I heard behind me the voice of a great rushing: "Blessed be the glory of YHWH from his place";

**3:13** And the sound of the wings of the living creatures as they touched one another, and the sound of the wheels beside them, even the sound of a great rushing.

**3:14** So the spirit lifted me up, and took me away; and I went in bitterness, in the heat of my spirit, and the hand of YHWH was strong upon me.

**3:15** Then I came to them of the captivity at Tel-abib, that dwelt by the river Chebar, and to where they dwelt; and I sat there overwhelmed among them seven days.

---

## The Watchman (3:16-21)

**3:16** And it came to pass at the end of seven days, that the word of YHWH came unto me, saying:

**3:17** "Son of man, I have made you a watchman unto the house of Israel; therefore, when you hear a word from my mouth, warn them from me.

**3:18** "When I say unto the wicked: You shall surely die; and you give him not warning, nor speak to warn the wicked from his wicked way, to save his life; the same wicked man shall die in his iniquity; but his blood will I require at your hand.

**3:19** "Yet if you warn the wicked, and he turn not from his wickedness, nor from his wicked way, he shall die in his iniquity; but you have delivered your soul.

**3:20** "Again, when a righteous man does turn from his righteousness, and commit iniquity, and I lay a stumbling-block before him, he shall die; because you have not given him warning, he shall die in his sin, and his righteous deeds which he has done shall not be remembered; but his blood will I require at your hand.

**3:21** "Nevertheless if you warn the righteous man, that the righteous sin not, and he does not sin, he shall surely live, because he took warning; and you have delivered your soul."

---

## Ezekiel Bound (3:22-27)

**3:22** And the hand of YHWH was there upon me; and he said unto me: "Arise, go forth into the plain, and I will there speak with you."

**3:23** Then I arose, and went forth into the plain; and, behold, the glory of YHWH stood there, as the glory which I saw by the river Chebar; and I fell on my face.

**3:24** Then spirit entered into me, and set me upon my feet; and he spoke with me, and said unto me: "Go, shut yourself within your house.

**3:25** "But you, son of man, behold, bands shall be put upon you, and you shall be bound with them, and you shall not go out among them;

**3:26** "And I will make your tongue cleave to the roof of your mouth, that you shall be dumb, and shall not be to them a reprover; for they are a rebellious house.

**3:27** "But when I speak with you, I will open your mouth, and you shall say unto them: Thus says the Lord YHWH; he that hears, let him hear; and he that forbears, let him forbear; for they are a rebellious house."

---

## Synthesis Notes

**Key Restorations:**

**Eating the Scroll (3:1-3):**
**The Key Verse (3:1):**
"'Eat that which you find; eat this scroll.'"

*Et asher-timtza ekhol ekhol et-ha-megillah ha-zot*—eat scroll.

"'Go, speak unto the house of Israel.'"

*Ve-lekh dabber el-beit Yisra'el*—go speak.

**The Key Verse (3:2):**
"I opened my mouth, and he caused me to eat that scroll."

*Va-eftach et-pi va-ya'akhileni et ha-megillah ha-zot*—ate.

**The Key Verse (3:3):**
"'Cause your belly to eat, and fill your bowels with this scroll.'"

*Bitnekha ta'akhel u-me'ekha temalle et ha-megillah ha-zot*—fill.

"It was in my mouth as honey for sweetness."

*Va-tokheleha va-tehi ve-fi ki-devash le-matoq*—sweet as honey.

**Sweet Despite Content:**
Though containing woes (2:10), the word tastes sweet—receiving divine revelation is privilege.

**Commission Continued (3:4-11):**
"'Go, get you unto the house of Israel.'"

*Lekh bo el-beit Yisra'el*—go to Israel.

"'Speak with my words unto them.'"

*Ve-dibbarta bi-devarai aleihem*—speak my words.

**The Key Verses (3:5-7):**
"'You are not sent to a people of a strange speech and of a hard language.'"

*Ki lo el-am imqei safah u-khivdei lashon attah shalуach*—not foreign.

"'But to the house of Israel.'"

*El-beit Yisra'el*—to Israel.

"'Surely, if I sent you to them, they would hearken unto you.'"

*Im-lo aleihem shelachtikha hemmah yishme'u elekha*—foreigners would hear.

"'But the house of Israel will not hearken unto you.'"

*U-veit Yisra'el lo yovu lishmo'a elekha*—Israel won't hear.

"'For they will not hearken unto me.'"

*Ki einam ovim lishmo'a elai*—won't hear me.

"'All the house of Israel are of a hard forehead and of a stiff heart.'"

*Ki khol-beit Yisra'el chizqei-metzach ve-qeshei-lev hemmah*—hard, stiff.

**The Key Verses (3:8-9):**
"'I have made your face hard against their faces.'"

*Hinneh natatti et-panekha chazaqim le-ummat peneihem*—hard face.

"'Your forehead hard against their foreheads.'"

*Ve-et-mitzchakha chazaq le-ummat mitzcham*—hard forehead.

"'As an adamant harder than flint have I made your forehead.'"

*Ke-shamir chazaq mi-tzor natatti mitzchekha*—adamant.

"'Fear them not, neither be dismayed.'"

*Lo-tira otam ve-lo-techat mippeneihem*—don't fear.

**The Key Verses (3:10-11):**
"'All my words that I shall speak unto you receive in your heart.'"

*Kol-devarai asher adabber elekha qach bi-levavekha*—receive in heart.

"'Hear with your ears.'"

*U-ve-oznekha shema*—hear.

"'Go, get you to them of the captivity.'"

*Ve-lekh bo el-ha-golah*—to exiles.

"'Unto the children of your people.'"

*El-benei ammekha*—your people.

"'Thus says the Lord YHWH; whether they will hear, or whether they will forbear.'"

*Koh amar Adonai YHWH im-yishme'u ve-im-yechdalu*—hear or refuse.

**Spirit Lifts Ezekiel (3:12-15):**
**The Key Verse (3:12):**
"The spirit lifted me up."

*Va-tissa'eni ruach*—spirit lifted.

"I heard behind me the voice of a great rushing."

*Va-eshma acharai qol ra'ash gadol*—great rushing.

"'Blessed be the glory of YHWH from his place.'"

*Barukh kevod-YHWH mi-meqomo*—blessed be glory.

**The Key Verse (3:13):**
"The sound of the wings of the living creatures."

*Ve-qol kanfei ha-chayyot*—wing sound.

"As they touched one another."

*Mashiqot ishah el-achotah*—touching.

"The sound of the wheels beside them."

*Ve-qol ha-ofannim le-ummatam*—wheel sound.

"The sound of a great rushing."

*Ve-qol ra'ash gadol*—great rushing.

**The Key Verses (3:14-15):**
"The spirit lifted me up, and took me away."

*Ve-ruach nesa'atni va-tiqqacheni*—lifted, took.

"I went in bitterness, in the heat of my spirit."

*Va-elekh mar be-chamat ruchi*—bitter, hot.

"The hand of YHWH was strong upon me."

*Ve-yad-YHWH alai chazaqah*—strong hand.

"I came to them of the captivity at Tel-abib."

*Va-avo el-ha-golah Tel Aviv*—Tel-abib.

**Tel-abib:**
"Mound of the Flood"—an exile settlement near Nippur.

"I sat there overwhelmed among them seven days."

*Va-eshev sham shiv'at yamim mashmi*m be-tokham*—overwhelmed.

**Watchman (3:16-21):**
**The Key Verse (3:17):**
"'I have made you a watchman unto the house of Israel.'"

*Tzofeh netattikha le-veit Yisra'el*—watchman.

"'When you hear a word from my mouth, warn them from me.'"

*Ve-shamata mi-pi davar ve-hizhartah otam mimmeni*—warn.

**The Key Verses (3:18-19):**
"'When I say unto the wicked: You shall surely die.'"

*Be-omri la-rasha mot tamut*—wicked dies.

"'You give him not warning.'"

*Ve-lo hizhartו*—not warned.

"'Nor speak to warn the wicked from his wicked way.'"

*Ve-lo dibbarta le-hazhir rasha mi-darko ha-resha'ah*—not spoken.

"'The same wicked man shall die in his iniquity.'"

*Hu rasha ba-avono yamut*—dies in sin.

"'But his blood will I require at your hand.'"

*Ve-damo mi-yadekha avaqesh*—blood required.

"'Yet if you warn the wicked.'"

*Ve-attah ki-hizhartah rasha*—if warn.

"'And he turn not from his wickedness.'"

*Ve-lo-shav me-rish'o*—didn't turn.

"'He shall die in his iniquity.'"

*Hu ba-avono yamut*—dies.

"'But you have delivered your soul.'"

*Ve-attah et-nafshekha hitztzalta*—delivered soul.

**The Key Verses (3:20-21):**
"'When a righteous man does turn from his righteousness.'"

*U-ve-shuv tzaddiq mi-tzidqo*—righteous turns.

"'And commit iniquity.'"

*Ve-asah avel*—commits evil.

"'I lay a stumbling-block before him.'"

*Ve-natatti mikhshol lefanav*—stumbling-block.

"'He shall die.'"

*Hu yamut*—dies.

"'Because you have not given him warning.'"

*Ki lo hizhartו*—not warned.

"'His righteous deeds... shall not be remembered.'"

*Ve-tzidqotav asher-asah lo tizzakharnah*—not remembered.

"'His blood will I require at your hand.'"

*Ve-damo mi-yadekha avaqesh*—blood required.

"'If you warn the righteous man, that the righteous sin not.'"

*Ve-attah ki-hizhartו tzaddiq le-vilti chato tzaddiq*—warn righteous.

"'And he does not sin.'"

*Ve-hu lo-chata*—doesn't sin.

"'He shall surely live, because he took warning.'"

*Chayoh yichyeh ki nizhar*—lives.

"'You have delivered your soul.'"

*Ve-attah et-nafshekha hitztzalta*—delivered.

**Ezekiel Bound (3:22-27):**
"'Arise, go forth into the plain.'"

*Qum tze el-ha-biq'ah*—go to plain.

"'I will there speak with you.'"

*Ve-sham adabber otakh*—speak there.

"The glory of YHWH stood there."

*Ve-hinneh-sham kevod-YHWH omed*—glory stood.

"As the glory which I saw by the river Chebar."

*Ka-kavod asher ra'iti al-nehar Kevar*—like Chebar.

"I fell on my face."

*Va-eppol al-panai*—fell.

"Spirit entered into me, and set me upon my feet."

*Va-tavo vi ruach va-ta'amideni al-raglai*—spirit entered.

**The Key Verses (3:24-27):**
"'Go, shut yourself within your house.'"

*Bo hissager be-tokh beitekha*—shut in.

"'Bands shall be put upon you.'"

*Hinneh natenu alekha avotot*—bands.

"'You shall be bound.'"

*Ve-asarukha vahem*—bound.

"'You shall not go out among them.'"

*Ve-lo tetze be-tokham*—not go out.

"'I will make your tongue cleave to the roof of your mouth.'"

*U-leshonekha adbiq el-chikkekha*—tongue cleaves.

"'You shall be dumb.'"

*Ve-ne'elamta*—dumb.

"'Shall not be to them a reprover.'"

*Ve-lo-tihyeh lahem le-ish mokhiach*—not reprover.

"'When I speak with you, I will open your mouth.'"

*U-ve-dabberi otakh eftach et-pikha*—open mouth.

"'He that hears, let him hear.'"

*Ha-shome'a yishma*—let hear.

"'He that forbears, let him forbear.'"

*Ve-ha-chadel yechdal*—let refuse.

**Bound and Mute:**
Ezekiel's confinement and muteness are sign-acts—broken when YHWH gives words.

**Archetypal Layer:** Ezekiel 3 contains **"it was in my mouth as honey for sweetness" (3:3)**, **"I have made your face hard... as an adamant" (3:8-9)**, **"I have made you a watchman unto the house of Israel" (3:17)**, the **watchman's accountability for warning (3:18-21)**, and **Ezekiel's binding and muteness (3:25-27)**.

**Ethical Inversion Applied:**
- "'Eat this scroll, and go, speak'"—eat and speak
- "He caused me to eat that scroll"—ate
- "It was in my mouth as honey for sweetness"—sweet
- "'You are not sent to a people of a strange speech'"—not foreign
- "'If I sent you to them, they would hearken'"—foreigners would hear
- "'The house of Israel will not hearken'"—Israel won't
- "'All the house of Israel are of a hard forehead'"—hard
- "'I have made your face hard against their faces'"—hardened
- "'As an adamant harder than flint'"—adamant
- "'All my words... receive in your heart'"—receive
- "The spirit lifted me up"—lifted
- "'Blessed be the glory of YHWH from his place'"—blessed
- "I went in bitterness, in the heat of my spirit"—bitter
- "The hand of YHWH was strong upon me"—strong hand
- "I came to... Tel-abib"—Tel-abib
- "I sat there overwhelmed among them seven days"—overwhelmed
- "'I have made you a watchman'"—watchman
- "'When you hear a word from my mouth, warn them'"—warn
- "'When I say unto the wicked: You shall surely die'"—wicked dies
- "'You give him not warning'"—not warned
- "'His blood will I require at your hand'"—blood required
- "'If you warn the wicked... he shall die in his iniquity'"—dies anyway
- "'But you have delivered your soul'"—delivered
- "'When a righteous man does turn from his righteousness'"—righteous turns
- "'His righteous deeds... shall not be remembered'"—not remembered
- "'If you warn the righteous man... he shall surely live'"—lives
- "'Go, shut yourself within your house'"—confined
- "'Bands shall be put upon you'"—bound
- "'I will make your tongue cleave'"—mute
- "'When I speak with you, I will open your mouth'"—opened

**Modern Equivalent:** Ezekiel 3 completes the call with the sweet scroll and watchman commission. The watchman's blood-accountability (3:18-21) defines prophetic responsibility—warn faithfully, regardless of response. Ezekiel's confinement and selective muteness last until Jerusalem's fall (24:27; 33:22).

# Ezekiel 2: The Call of Ezekiel

*From the Hebrew: וַיֹּאמֶר אֵלַי בֶּן־אָדָם (Va-Yomer Elai Ben-Adam) — And He Said Unto Me, Son of Man*

---

## The Commission (2:1-7)

**2:1** And he said unto me: "Son of man, stand upon your feet, and I will speak with you."

**2:2** And spirit entered into me when he spoke unto me, and set me upon my feet; and I heard him that spoke unto me.

**2:3** And he said unto me: "Son of man, I send you to the children of Israel, to rebellious nations, that have rebelled against me; they and their fathers have transgressed against me, even unto this very day.

**2:4** "And the children are brazen-faced and stiff-hearted, I do send you unto them; and you shall say unto them: Thus says the Lord YHWH.

**2:5** "And they, whether they will hear, or whether they will forbear—for they are a rebellious house—yet shall know that there has been a prophet among them.

**2:6** "And you, son of man, be not afraid of them, neither be afraid of their words, though briers and thorns be with you, and you do dwell among scorpions; be not afraid of their words, nor be dismayed at their looks, for they are a rebellious house.

**2:7** "And you shall speak my words unto them, whether they will hear, or whether they will forbear; for they are most rebellious.

---

## The Scroll (2:8-10)

**2:8** "But you, son of man, hear what I say unto you: be not rebellious like that rebellious house; open your mouth, and eat that which I give you."

**2:9** And when I looked, behold, a hand was put forth unto me; and, lo, a scroll of a book was therein;

**2:10** And he spread it before me, and it was written within and without; and there was written therein lamentations, and moaning, and woe.

---

## Synthesis Notes

**Key Restorations:**

**Commission (2:1-7):**
**The Key Verse (2:1):**
"'Son of man, stand upon your feet.'"

*Ben-adam amod al-raglekha*—stand.

**Ben-Adam:**
"Son of man"—Ezekiel's distinctive title (used 93 times). Emphasizes his humanity before divine glory.

"'I will speak with you.'"

*Va-adabber otakh*—I will speak.

**The Key Verse (2:2):**
"Spirit entered into me when he spoke unto me."

*Va-tavo vi ruach ka-asher dibber elai*—spirit entered.

"Set me upon my feet."

*Va-ta'amideni al-raglai*—set on feet.

"I heard him that spoke unto me."

*Va-eshma et middabber elai*—heard.

**The Key Verse (2:3):**
"'I send you to the children of Israel.'"

*Ani sholeach otakh el-benei Yisra'el*—send to Israel.

"'To rebellious nations.'"

*El-goyim ha-mordim*—rebellious nations.

"'That have rebelled against me.'"

*Asher mardu-vi*—rebelled.

"'They and their fathers have transgressed against me.'"

*Hemmah va-avotam pash'u vi*—transgressed.

"'Even unto this very day.'"

*Ad-etzem ha-yom ha-zeh*—to this day.

**The Key Verse (2:4):**
"'The children are brazen-faced and stiff-hearted.'"

*Ve-ha-banim qeshei fanim ve-chizqei-lev*—brazen, stiff.

"'I do send you unto them.'"

*Ani sholeach otakh aleihem*—send.

"'You shall say unto them: Thus says the Lord YHWH.'"

*Ve-amarta aleihem koh amar Adonai YHWH*—thus says.

**The Key Verse (2:5):**
"'Whether they will hear, or whether they will forbear.'"

*Ve-hemmah im-yishme'u ve-im-yechdalu*—hear or refuse.

"'For they are a rebellious house.'"

*Ki veit meri hemmah*—rebellious house.

"'Yet shall know that there has been a prophet among them.'"

*Ve-yad'u ki navi hayah be-tokham*—prophet among.

**The Key Verse (2:6):**
"'Be not afraid of them.'"

*Ve-attah ben-adam al-tira me-hem*—don't fear.

"'Neither be afraid of their words.'"

*U-mi-ddivreihem al-tira*—don't fear words.

"'Though briers and thorns be with you.'"

*Ki saravim ve-sallonim otakh*—briers, thorns.

"'You do dwell among scorpions.'"

*Ve-el-aqrabbim attah yoshev*—among scorpions.

"'Be not afraid of their words.'"

*Mi-ddivreihem al-tira*—don't fear.

"'Nor be dismayed at their looks.'"

*U-mippeneihem al-techat*—don't dismay.

"'For they are a rebellious house.'"

*Ki veit meri hemmah*—rebellious.

**The Key Verse (2:7):**
"'You shall speak my words unto them.'"

*Ve-dibbarta et-devarai aleihem*—speak my words.

"'Whether they will hear, or whether they will forbear.'"

*Im-yishme'u ve-im-yechdalu*—hear or refuse.

"'For they are most rebellious.'"

*Ki meri hemmah*—most rebellious.

**Scroll (2:8-10):**
**The Key Verse (2:8):**
"'Hear what I say unto you.'"

*Shema et asher-ani medabber elekha*—hear.

"'Be not rebellious like that rebellious house.'"

*Al-tehi-meri ke-veit ha-meri*—don't be rebellious.

"'Open your mouth, and eat that which I give you.'"

*Petzeh pikha ve-ekhol et asher-ani noten elekha*—eat.

**The Key Verse (2:9):**
"A hand was put forth unto me."

*Ve-er'eh ve-hinneh-yad sheluchah elai*—hand.

"Lo, a scroll of a book was therein."

*Ve-hinneh-vo megillat-sefer*—scroll.

**The Key Verse (2:10):**
"He spread it before me."

*Va-yifros otah lefanai*—spread.

"It was written within and without."

*Ve-hi khetuvah panim ve-achor*—both sides.

"There was written therein lamentations, and moaning, and woe."

*Ve-khatuv elekha qinim va-hegeh va-hi*—laments, moans, woes.

**Written Both Sides:**
Unusual—scrolls normally written on one side. This emphasizes the fullness of judgment.

**Archetypal Layer:** Ezekiel 2 contains **"Son of man, stand upon your feet" (2:1)**, **"Spirit entered into me" (2:2)**, **"I send you to the children of Israel, to rebellious nations" (2:3)**, **"They are a rebellious house" (2:5, 6, 7)**, and **the scroll written with "lamentations, and moaning, and woe" (2:10)**.

**Ethical Inversion Applied:**
- "'Son of man, stand upon your feet'"—stand
- "'I will speak with you'"—divine speech
- "Spirit entered into me when he spoke"—spirit empowers
- "Set me upon my feet"—enabled to stand
- "'I send you to the children of Israel'"—commission
- "'To rebellious nations, that have rebelled against me'"—rebellious
- "'They and their fathers have transgressed'"—transgressed
- "'Even unto this very day'"—continuing rebellion
- "'The children are brazen-faced and stiff-hearted'"—brazen, stiff
- "'You shall say unto them: Thus says the Lord YHWH'"—thus says
- "'Whether they will hear, or whether they will forbear'"—hear or refuse
- "'For they are a rebellious house'"—rebellious house
- "'Yet shall know that there has been a prophet among them'"—prophet present
- "'Be not afraid of them'"—don't fear
- "'Though briers and thorns be with you'"—hostile environment
- "'You do dwell among scorpions'"—scorpions
- "'Be not dismayed at their looks'"—don't dismay
- "'You shall speak my words unto them'"—speak
- "'Be not rebellious like that rebellious house'"—don't be rebellious
- "'Open your mouth, and eat that which I give you'"—eat
- "A hand was put forth unto me"—hand
- "A scroll of a book was therein"—scroll
- "It was written within and without"—both sides
- "Lamentations, and moaning, and woe"—content

**Modern Equivalent:** Ezekiel 2 presents the prophetic commission. "Son of man" emphasizes Ezekiel's humanity. The command to speak "whether they will hear, or whether they will forbear" (2:5, 7) defines prophetic faithfulness—success is obedience, not response. The scroll eaten (continued in ch. 3) symbolizes internalizing the message.

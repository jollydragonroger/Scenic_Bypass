# Ezekiel 10: The Glory Departs from the Temple

*From the Hebrew: וָאֶרְאֶה וְהִנֵּה (Va-Er'eh Ve-Hinneh) — And I Looked, and Behold*

---

## The Coals of Fire (10:1-8)

**10:1** And I looked, and, behold, upon the firmament that was over the head of the cherubim, there appeared above them as it were a sapphire stone, as the appearance of the likeness of a throne.

**10:2** And he spoke unto the man clothed in linen, and said: "Go in between the wheelwork, even under the cherub, and fill both your hands with coals of fire from between the cherubim, and dash them over the city." And he went in in my sight.

**10:3** Now the cherubim stood on the right side of the house, when the man went in; and the cloud filled the inner court.

**10:4** And the glory of YHWH mounted up from the cherub to the threshold of the house; and the house was filled with the cloud, and the court was full of the brightness of the glory of YHWH.

**10:5** And the sound of the wings of the cherubim was heard even to the outer court, as the voice of God Almighty when he speaks.

**10:6** And it came to pass, when he commanded the man clothed in linen, saying: "Take fire from between the wheelwork, from between the cherubim," that he went in, and stood beside a wheel.

**10:7** And the cherub stretched forth his hand from between the cherubim unto the fire that was between the cherubim, and took thereof, and put it into the hands of him that was clothed in linen, who took it and went out.

**10:8** And there appeared in the cherubim the form of a man's hand under their wings.

---

## The Wheels and Cherubim (10:9-17)

**10:9** And I looked, and behold four wheels beside the cherubim, one wheel beside one cherub, and another wheel beside another cherub; and the appearance of the wheels was as the color of a beryl stone.

**10:10** And as for their appearance, they four had one likeness, as if a wheel were within a wheel.

**10:11** When they went, they went toward their four sides; they turned not as they went, but to the place whither the head looked they followed it; they turned not as they went.

**10:12** And their whole body, and their backs, and their hands, and their wings, and the wheels were full of eyes round about, even the wheels that they four had.

**10:13** As for the wheels, they were called in my hearing the wheelwork.

**10:14** And every one had four faces: the first face was the face of the cherub, and the second face was the face of a man, and the third the face of a lion, and the fourth the face of an eagle.

**10:15** And the cherubim mounted up—this is the living creature that I saw by the river Chebar.

**10:16** And when the cherubim went, the wheels went beside them; and when the cherubim lifted up their wings to mount up from the earth, the wheels also turned not from beside them.

**10:17** When they stood, these stood, and when they mounted up, these mounted up with them; for the spirit of the living creature was in them.

---

## The Glory Departs (10:18-22)

**10:18** And the glory of YHWH went forth from off the threshold of the house, and stood over the cherubim.

**10:19** And the cherubim lifted up their wings, and mounted up from the earth in my sight when they went forth, and the wheels beside them; and they stood at the door of the east gate of YHWH's house; and the glory of the God of Israel was over them above.

**10:20** This is the living creature that I saw under the God of Israel by the river Chebar; and I knew that they were cherubim.

**10:21** Every one had four faces, and every one four wings; and the likeness of the hands of a man was under their wings.

**10:22** And as for the likeness of their faces, they were the faces which I saw by the river Chebar, their appearances and themselves; they went every one straight forward.

---

## Synthesis Notes

**Key Restorations:**

**Coals of Fire (10:1-8):**
**The Key Verse (10:1):**
"Upon the firmament that was over the head of the cherubim."

*El-ha-raqia asher al-rosh ha-keruvim*—firmament above.

"There appeared above them as it were a sapphire stone."

*Ke-even sappir*—sapphire stone.

"As the appearance of the likeness of a throne."

*Ke-mar'eh demut kisse*—throne likeness.

**The Key Verse (10:2):**
"He spoke unto the man clothed in linen."

*Va-yomer el-ha-ish levush ha-baddim*—to linen-clothed man.

"'Go in between the wheelwork, even under the cherub.'"

*Bo el-beinot la-galgal el-tachat la-keruv*—between wheels.

"'Fill both your hands with coals of fire from between the cherubim.'"

*U-malle chofnekha gachalei-esh mi-beinot la-keruvim*—coals of fire.

"'Dash them over the city.'"

*U-zeroq al-ha-ir*—scatter over city.

"He went in in my sight."

*Va-yavo le-einai*—in my sight.

**Coals for Judgment:**
Unlike Isaiah 6:6-7 where coals purify, these coals destroy.

**The Key Verse (10:3):**
"The cherubim stood on the right side of the house."

*Ve-ha-keruvim omedim mi-yemin la-bayit*—right side.

"The cloud filled the inner court."

*Ve-he-anan male et-he-chatzer ha-penimit*—cloud filled.

**The Key Verse (10:4):**
"The glory of YHWH mounted up from the cherub to the threshold of the house."

*Va-yarom kevod-YHWH me-al ha-keruv al miftan ha-bayit*—glory to threshold.

"The house was filled with the cloud."

*Va-yimmale ha-bayit et-he-anan*—filled with cloud.

"The court was full of the brightness of the glory of YHWH."

*Ve-he-chatzer male'ah et-nogah kevod YHWH*—brightness filled.

**The Key Verse (10:5):**
"The sound of the wings of the cherubim was heard even to the outer court."

*Ve-qol kanfei ha-keruvim nishma ad-he-chatzer ha-chitzonah*—sound heard.

"As the voice of God Almighty when he speaks."

*Ke-qol El-Shaddai be-dabbero*—like Shaddai's voice.

**The Key Verses (10:6-7):**
"'Take fire from between the wheelwork, from between the cherubim.'"

*Qach esh mi-beinot la-galgal mi-beinot la-keruvim*—take fire.

"He went in, and stood beside a wheel."

*Va-yavo va-ya'amod etzel ha-ofan*—stood beside wheel.

"The cherub stretched forth his hand from between the cherubim unto the fire."

*Va-yishlach ha-keruv et-yado mi-bein ha-keruvim el-ha-esh*—hand to fire.

"Took thereof, and put it into the hands of him that was clothed in linen."

*Va-yissa va-yitten el-chofnei levush ha-baddim*—gave to linen-clothed.

"Who took it and went out."

*Va-yiqqach va-yetze*—took and went.

**The Key Verse (10:8):**
"There appeared in the cherubim the form of a man's hand under their wings."

*Va-yera la-keruvim tavnit yad-adam tachat kanfeihem*—human hands.

**Wheels and Cherubim (10:9-17):**
**The Key Verses (10:9-10):**
"Four wheels beside the cherubim."

*Arba'ah ofannim etzel ha-keruvim*—4 wheels.

"One wheel beside one cherub."

*Ofan echad etzel ha-keruv ha-echad*—wheel per cherub.

"The appearance of the wheels was as the color of a beryl stone."

*U-mar'eh ha-ofannim ke-ein even tarshish*—beryl color.

"They four had one likeness."

*U-mar'eihem la-arba'tam demut echad*—one likeness.

"As if a wheel were within a wheel."

*Ka-asher yihyeh ha-ofan be-tokh ha-ofan*—wheel within wheel.

**The Key Verses (10:11-12):**
"They went toward their four sides."

*El-arba'at riv'eihem be-lekhtam yelekhu*—four directions.

"They turned not as they went."

*Lo yissabbu be-lekhtam*—didn't turn.

"To the place whither the head looked they followed it."

*Ki el-ha-maqom asher yifneh ha-rosh acharav yelekhu*—followed head.

"Their whole body, and their backs, and their hands, and their wings, and the wheels were full of eyes."

*Ve-khol besaram ve-gabbeihem vi-ydeihem ve-khanfeihem ve-ha-ofannim mele'im einayim saviv*—full of eyes.

**The Key Verse (10:13):**
"As for the wheels, they were called in my hearing the wheelwork."

*La-ofannim lahem qora ha-galgal be-oznai*—called *galgal*.

**Galgal:**
"Wheelwork" or "whirling"—distinct term for the chariot mechanism.

**The Key Verse (10:14):**
"Every one had four faces."

*Ve-arba'ah fanim le-echad*—4 faces.

"The first face was the face of the cherub."

*Penei ha-echad penei ha-keruv*—cherub face.

"The second face was the face of a man."

*U-fenei ha-sheni penei adam*—human face.

"The third the face of a lion."

*Ve-ha-shelishi penei aryeh*—lion face.

"The fourth the face of an eagle."

*Ve-ha-revi'i penei-nesher*—eagle face.

**Cherub vs. Ox:**
Chapter 1 had "ox" where this has "cherub"—suggesting the cherub face was the ox face.

**The Key Verse (10:15):**
"The cherubim mounted up."

*Va-yerommu ha-keruvim*—mounted up.

"This is the living creature that I saw by the river Chebar."

*Hi ha-chayyah asher ra'iti bi-nehar-Kevar*—same as Chebar.

**The Key Verses (10:16-17):**
"When the cherubim went, the wheels went beside them."

*U-ve-lekhet ha-keruvim yelekhu ha-ofannim etzlam*—wheels with cherubim.

"When the cherubim lifted up their wings to mount up."

*U-vi-nse ha-keruvim et-kanfeihem larum*—wings lifted.

"The wheels also turned not from beside them."

*Lo-yissabbu ha-ofannim gam-hem me-etzlam*—wheels stayed.

"When they stood, these stood."

*Be-omdam ya'amoду*—stood together.

"When they mounted up, these mounted up with them."

*U-ve-rommam yerommu otam*—mounted together.

"The spirit of the living creature was in them."

*Ki ruach ha-chayyah bahem*—spirit in them.

**Glory Departs (10:18-22):**
**The Key Verse (10:18):**
"The glory of YHWH went forth from off the threshold of the house."

*Va-yetze kevod-YHWH me-al miftan ha-bayit*—glory left threshold.

"Stood over the cherubim."

*Va-ya'amod al-ha-keruvim*—over cherubim.

**The Key Verse (10:19):**
"The cherubim lifted up their wings, and mounted up from the earth in my sight."

*Va-yis'u ha-keruvim et-kanfeihem va-yerommu min-ha-aretz le-einai*—mounted up.

"When they went forth."

*Be-tzetam*—went forth.

"The wheels beside them."

*Ve-ha-ofannim le-ummatam*—wheels beside.

"They stood at the door of the east gate of YHWH's house."

*Va-ya'amdu petach sha'ar beit-YHWH ha-qadmoni*—east gate.

"The glory of the God of Israel was over them above."

*U-khvod Elohei-Yisra'el aleihem mi-le-ma'elah*—glory above.

**Stage of Departure:**
From threshold to east gate—glory moving away.

**The Key Verses (10:20-22):**
"This is the living creature that I saw under the God of Israel by the river Chebar."

*Hi ha-chayyah asher ra'iti tachat Elohei-Yisra'el bi-nehar Kevar*—same creature.

"I knew that they were cherubim."

*Va-eda ki-kheruvim hemmah*—knew cherubim.

"Every one had four faces, and every one four wings."

*Arba'ah arba'ah fanim le-echad ve-arba kanfayim le-echad*—4 faces, 4 wings.

"The likeness of the hands of a man was under their wings."

*U-demut yedei adam tachat kanfeihem*—human hands.

"They were the faces which I saw by the river Chebar."

*Hemmah ha-fanim asher ra'iti al-nehar Kevar*—same faces.

"They went every one straight forward."

*Ish el-ever panav yelekhu*—straight forward.

**Archetypal Layer:** Ezekiel 10 contains **coals of fire scattered over the city (10:2)**, **the glory moving from threshold to over the cherubim (10:4, 18)**, **"the wheels were full of eyes round about" (10:12)**, **the cherubim identified as the living creatures of chapter 1 (10:15, 20)**, and **the glory standing at the east gate (10:19)**.

**Ethical Inversion Applied:**
- "Upon the firmament... as it were a sapphire stone"—sapphire
- "As the appearance of the likeness of a throne"—throne
- "'Go in between the wheelwork, even under the cherub'"—between wheels
- "'Fill both your hands with coals of fire'"—coals of fire
- "'Dash them over the city'"—over city
- "The cherubim stood on the right side of the house"—right side
- "The cloud filled the inner court"—cloud filled
- "The glory of YHWH mounted up from the cherub to the threshold"—glory to threshold
- "The house was filled with the cloud"—cloud filled
- "The court was full of the brightness"—brightness
- "The sound of the wings... as the voice of God Almighty"—like Shaddai
- "'Take fire from between the wheelwork'"—take fire
- "The cherub stretched forth his hand... unto the fire"—hand to fire
- "Put it into the hands of him that was clothed in linen"—gave fire
- "There appeared... the form of a man's hand under their wings"—human hands
- "Four wheels beside the cherubim"—4 wheels
- "A wheel within a wheel"—wheel within wheel
- "They turned not as they went"—didn't turn
- "Full of eyes round about"—full of eyes
- "They were called in my hearing the wheelwork"—*galgal*
- "The first face was the face of the cherub"—cherub face
- "The second face was the face of a man"—human face
- "The third the face of a lion"—lion face
- "The fourth the face of an eagle"—eagle face
- "This is the living creature that I saw by the river Chebar"—same creature
- "The spirit of the living creature was in them"—spirit in them
- "The glory of YHWH went forth from off the threshold"—glory left
- "Stood over the cherubim"—over cherubim
- "They stood at the door of the east gate"—east gate
- "The glory of the God of Israel was over them above"—glory above
- "I knew that they were cherubim"—identified

**Modern Equivalent:** Ezekiel 10 shows the glory's staged departure. Coals of fire (10:2) bring judgment not purification. The chariot-throne (Merkavah) description parallels chapter 1, now explicitly identified as cherubim (10:20). The glory moves from cherubim → threshold → east gate, reluctantly leaving.

# Ezekiel 45: The Holy Portion and the Prince's Duties

*From the Hebrew: וּבְהַפִּילְכֶם אֶת־הָאָרֶץ בְּנַחֲלָה (U-Ve-Happilkhem Et-Ha-Aretz Be-Nachalah) — And When You Divide the Land by Lot for Inheritance*

---

## The Holy Portion (45:1-8)

**45:1** Moreover, when you shall divide by lot the land for inheritance, you shall offer an offering unto YHWH, a holy portion of the land; the length shall be the length of five and twenty thousand reeds, and the breadth shall be ten thousand; it shall be holy in all the border thereof round about.

**45:2** Of this there shall be for the holy place five hundred by five hundred, square round about; and fifty cubits for the open land round about it.

**45:3** And of this measure shall you measure: a length of five and twenty thousand, and a breadth of ten thousand; and in it shall be the sanctuary, which is most holy.

**45:4** It is a holy portion of the land; it shall be for the priests, the ministers of the sanctuary, that come near to minister unto YHWH; and it shall be a place for their houses, and a holy place for the sanctuary.

**45:5** And five and twenty thousand in length, and ten thousand in breadth, shall be unto the Levites, the ministers of the house, for a possession unto themselves, for twenty chambers.

**45:6** And you shall appoint the possession of the city five thousand broad, and five and twenty thousand long, side by side with the offering of the holy portion; it shall be for the whole house of Israel.

**45:7** And for the prince shall be on the one side and on the other side of the holy offering and of the possession of the city, in front of the holy offering and in front of the possession of the city, on the west side westward, and on the east side eastward; and in length answerable to one of the portions, from the west border unto the east border.

**45:8** In the land it shall be to him for a possession in Israel, and my princes shall no more oppress my people; but they shall give the land to the house of Israel according to their tribes.

---

## Honest Weights and Measures (45:9-12)

**45:9** Thus says the Lord YHWH: "Let it suffice you, O princes of Israel; remove violence and spoil, and execute justice and righteousness; take away your exactions from my people," says the Lord YHWH.

**45:10** "You shall have just balances, and a just ephah, and a just bath.

**45:11** "The ephah and the bath shall be of one measure, that the bath may contain the tenth part of a homer, and the ephah the tenth part of a homer; the measure thereof shall be after the homer.

**45:12** "And the shekel shall be twenty gerahs; twenty shekels, five and twenty shekels, fifteen shekels, shall be your maneh."

---

## The Offerings (45:13-17)

**45:13** "This is the offering that you shall offer: the sixth part of an ephah out of a homer of wheat, and you shall give the sixth part of an ephah out of a homer of barley;

**45:14** "And the set portion of oil, the bath of oil, shall be the tenth part of a bath out of the cor, which is ten baths, even a homer; for ten baths are a homer;

**45:15** "And one lamb of the flock, out of two hundred, from the well-watered pastures of Israel; for a meal-offering, and for a burnt-offering, and for peace-offerings, to make atonement for them," says the Lord YHWH.

**45:16** "All the people of the land shall give this offering for the prince in Israel.

**45:17** "And it shall be the prince's part to give the burnt-offerings, and the meal-offerings, and the drink-offerings, in the feasts, and in the new moons, and in the sabbaths, in all the appointed seasons of the house of Israel; he shall prepare the sin-offering, and the meal-offering, and the burnt-offering, and the peace-offerings, to make atonement for the house of Israel."

---

## The Feasts (45:18-25)

**45:18** Thus says the Lord YHWH: "In the first month, in the first day of the month, you shall take a young bullock without blemish; and you shall purify the sanctuary.

**45:19** "And the priest shall take of the blood of the sin-offering, and put it upon the door-posts of the house, and upon the four corners of the ledge of the altar, and upon the posts of the gate of the inner court.

**45:20** "And so you shall do on the seventh day of the month for every one that errs, and for him that is simple; so shall you make atonement for the house.

**45:21** "In the first month, in the fourteenth day of the month, you shall have the passover; a feast of seven days; unleavened bread shall be eaten.

**45:22** "And upon that day shall the prince prepare for himself and for all the people of the land a bullock for a sin-offering.

**45:23** "And the seven days of the feast he shall prepare a burnt-offering to YHWH, seven bullocks and seven rams without blemish daily the seven days; and a he-goat daily for a sin-offering.

**45:24** "And he shall prepare a meal-offering, an ephah for a bullock, and an ephah for a ram, and a hin of oil to an ephah.

**45:25** "In the seventh month, in the fifteenth day of the month, in the feast, shall he do the like the seven days; according to the sin-offering, according to the burnt-offering, and according to the meal-offering, and according to the oil."

---

## Synthesis Notes

**Key Restorations:**

**Holy Portion (45:1-8):**
**The Key Verse (45:1):**
"'When you shall divide by lot the land for inheritance.'"

*U-ve-happilkhem et-ha-aretz be-nachalah*—divide land.

"'You shall offer an offering unto YHWH, a holy portion of the land.'"

*Tarimu terumah la-YHWH qodesh min-ha-aretz*—holy portion.

"'The length shall be... five and twenty thousand reeds.'"

*Orekh chamishah ve-esrim elef*—25,000 reeds.

"'The breadth shall be ten thousand.'"

*Rochav aseret alafim*—10,000.

"'It shall be holy in all the border thereof round about.'"

*Qodesh-hu be-khol-gevulah saviv*—holy all around.

**The Key Verses (45:2-4):**
"'Of this there shall be for the holy place five hundred by five hundred, square.'"

*Mi-zeh yihyeh la-qodesh chamesh me'ot ba-chamesh me'ot meruva saviv*—500 x 500.

"'Fifty cubits for the open land round about it.'"

*Va-chamishshim ammah migrash lo saviv*—50 cubit buffer.

"'Of this measure shall you measure: a length of five and twenty thousand, and a breadth of ten thousand.'"

*U-min-ha-middah ha-zot tamod orekh chamishah ve-esrim elef ve-rochav aseret alafim*—25,000 x 10,000.

"'In it shall be the sanctuary, which is most holy.'"

*U-vo yihyeh ha-miqdash qodesh qodashim*—most holy.

"'It is a holy portion of the land.'"

*Qodesh min-ha-aretz hi*—holy portion.

"'It shall be for the priests, the ministers of the sanctuary.'"

*La-kohanim mesharetei ha-miqdash yihyeh*—for priests.

"'That come near to minister unto YHWH.'"

*Ha-qerevim le-sharet et-YHWH*—come near.

"'It shall be a place for their houses.'"

*Ve-hayah lahem meqom le-vattim*—houses.

"'A holy place for the sanctuary.'"

*U-miqdash la-miqdash*—holy place.

**The Key Verses (45:5-6):**
"'Five and twenty thousand in length, and ten thousand in breadth, shall be unto the Levites.'"

*Va-chamishah ve-esrim elef orekh va-aseret alafim rochav yihyeh la-Leviyyim*—for Levites.

"'The ministers of the house.'"

*Mesharetei ha-bayit*—house ministers.

"'For a possession unto themselves, for twenty chambers.'"

*Lahem le-achuzzah esrim leshakhot*—20 chambers.

"'You shall appoint the possession of the city five thousand broad.'"

*Va-achuzzat ha-ir tittenu chamishshat alafim rochav*—city 5,000 wide.

"'Five and twenty thousand long.'"

*Ve-orekh chamishah ve-esrim elef*—25,000 long.

"'It shall be for the whole house of Israel.'"

*Le-khol-beit Yisra'el yihyeh*—for all Israel.

**The Key Verses (45:7-8):**
"'For the prince shall be on the one side and on the other side of the holy offering.'"

*Ve-la-nasi mi-zeh u-mi-zeh li-terumat ha-qodesh*—prince's land.

"'On the west side westward, and on the east side eastward.'"

*El-pe'at-yammah yammah ve-el-pe'at-qedmah qadimah*—west and east.

"'In length answerable to one of the portions.'"

*Ve-orekh le'ummat achad ha-chalaqim*—like tribal portions.

"'From the west border unto the east border.'"

*Mi-gevul-yam el-gevul qadimah*—west to east.

"'In the land it shall be to him for a possession in Israel.'"

*Ba-aretz yihyeh-lo le-achuzzah be-Yisra'el*—prince's possession.

"'My princes shall no more oppress my people.'"

*Ve-lo-yonu od nesi'ai et-ammi*—no more oppress.

"'They shall give the land to the house of Israel according to their tribes.'"

*Ve-ha-aretz yittenu le-veit-Yisra'el le-shivteihem*—land to tribes.

**Honest Weights (45:9-12):**
"'Let it suffice you, O princes of Israel.'"

*Rav-lakhem nesi'ei Yisra'el*—enough, princes.

"'Remove violence and spoil.'"

*Chamas va-shod hasiru*—remove violence.

"'Execute justice and righteousness.'"

*U-mishpat u-tzedaqah asu*—do justice.

"'Take away your exactions from my people.'"

*Harimu gerushoteikhem me-al ammi*—stop exactions.

"'You shall have just balances.'"

*Moznei-tzedeq yihyeh lakhem*—just balances.

"'A just ephah, and a just bath.'"

*Ve-eifat-tzedeq u-vat-tzedeq*—just measures.

"'The ephah and the bath shall be of one measure.'"

*Ha-eifah ve-ha-bat tokhen echad yihyeh*—same measure.

"'The shekel shall be twenty gerahs.'"

*Ve-ha-sheqel esrim gerah*—20 gerahs.

**Offerings (45:13-17):**
"'This is the offering that you shall offer.'"

*Zot ha-terumah asher tarimu*—the offering.

"'The sixth part of an ephah out of a homer of wheat.'"

*Shishshit ha-eifah me-chomer ha-chittim*—1/6 ephah wheat.

"'The sixth part of an ephah out of a homer of barley.'"

*Ve-shishshitem ha-eifah me-chomer ha-se'orim*—1/6 ephah barley.

"'The set portion of oil, the bath of oil.'"

*Ve-choq ha-shemen ha-bat ha-shemen*—oil portion.

"'One lamb of the flock, out of two hundred.'"

*Ve-seh-echad min-ha-tzon min-ha-matayim*—1/200 lamb.

"'From the well-watered pastures of Israel.'"

*Mi-mashqeh Yisra'el*—Israel's pastures.

"'For a meal-offering, and for a burnt-offering, and for peace-offerings.'"

*Le-minchah u-le-olah ve-li-shelamim*—offerings.

"'To make atonement for them.'"

*Le-khapper aleihem*—atone.

"'All the people of the land shall give this offering for the prince in Israel.'"

*Kol-am ha-aretz yihyeh el-ha-terumah ha-zot la-nasi be-Yisra'el*—people give to prince.

"'It shall be the prince's part to give the burnt-offerings... in the feasts.'"

*Ve-al ha-nasi yihyeh ha-olot... be-chaggim*—prince provides.

"'In the new moons, and in the sabbaths.'"

*U-va-chodashim u-va-shabbatot*—new moons, sabbaths.

"'In all the appointed seasons of the house of Israel.'"

*Be-khol-mo'adei beit Yisra'el*—all festivals.

"'He shall prepare the sin-offering, and the meal-offering.'"

*Hu ya'aseh et-ha-chattat ve-et-ha-minchah*—prepare offerings.

"'To make atonement for the house of Israel.'"

*Le-khapper be'ad beit-Yisra'el*—atone for Israel.

**Feasts (45:18-25):**
"'In the first month, in the first day of the month.'"

*Ba-rishon be-echad la-chodesh*—1st of 1st month.

"'You shall take a young bullock without blemish.'"

*Tiqqach par ben-baqar tamim*—unblemished bullock.

"'You shall purify the sanctuary.'"

*Ve-chitteta et-ha-miqdash*—purify sanctuary.

"'The priest shall take of the blood of the sin-offering.'"

*Ve-laqach ha-kohen mi-dam ha-chattat*—blood.

"'Put it upon the door-posts of the house.'"

*Ve-natan al-mezuzat ha-bayit*—on doorposts.

"'Upon the four corners of the ledge of the altar.'"

*Ve-el-arba pinnot ha-azarah la-mizbeach*—altar corners.

"'Upon the posts of the gate of the inner court.'"

*Ve-al-mezuzat sha'ar he-chatzer ha-penimit*—gate posts.

"'So you shall do on the seventh day of the month.'"

*Ve-khen ta'aseh be-shiv'ah ba-chodesh*—7th day.

"'For every one that errs, and for him that is simple.'"

*Me-ish shogeh u-mi-peti*—for erring, simple.

"'So shall you make atonement for the house.'"

*Ve-kippartem et-ha-bayit*—atone for house.

"'In the first month, in the fourteenth day of the month, you shall have the passover.'"

*Ba-rishon be-arba'ah asar yom la-chodesh yihyeh lakhem ha-pasach*—Passover.

"'A feast of seven days.'"

*Chag shavu'ot yamim*—7-day feast.

"'Unleavened bread shall be eaten.'"

*Matztzot ye'akhel*—unleavened bread.

"'Upon that day shall the prince prepare... a bullock for a sin-offering.'"

*Ve-asah ha-nasi ba-yom ha-hu ba'ado u-ve'ad kol-am ha-aretz par chattat*—prince's sin offering.

"'The seven days of the feast he shall prepare a burnt-offering to YHWH.'"

*Ve-shiv'at yemei ha-chag ya'aseh olah la-YHWH*—burnt offerings.

"'Seven bullocks and seven rams without blemish daily.'"

*Shiv'at parim ve-shiv'at eilim temimim la-yom shiv'at ha-yamim*—7 bulls, 7 rams.

"'A he-goat daily for a sin-offering.'"

*U-se'ir izzim la-yom chattat*—goat.

"'He shall prepare a meal-offering.'"

*U-minchah ya'aseh*—meal offering.

"'An ephah for a bullock, and an ephah for a ram.'"

*Eifah la-par ve-eifah la-ayil*—ephah each.

"'A hin of oil to an ephah.'"

*Ve-shemen hin la-eifah*—hin of oil.

"'In the seventh month, in the fifteenth day of the month, in the feast.'"

*Ba-shevi'i ba-chamishah asar yom la-chodesh be-chag*—Tabernacles.

"'He shall do the like the seven days.'"

*Ya'aseh kha-elleh shiv'at ha-yamim*—same seven days.

**Archetypal Layer:** Ezekiel 45 describes **land allocation**, containing **the holy portion: 25,000 x 10,000 reeds (45:1)**, **priests' portion with sanctuary (45:3-4)**, **Levites' portion (45:5)**, **city portion for all Israel (45:6)**, **prince's land flanking the holy portion (45:7)**, **"my princes shall no more oppress my people" (45:8)**, **just weights and measures (45:10-12)**, **offerings from the people to the prince (45:13-16)**, **prince provides all festival offerings (45:17)**, **semi-annual sanctuary purification (45:18-20)**, and **Passover and Tabernacles regulations (45:21-25)**.

**Ethical Inversion Applied:**
- "'When you shall divide by lot the land for inheritance'"—divide land
- "'You shall offer an offering unto YHWH, a holy portion'"—holy portion
- "'The length shall be... five and twenty thousand reeds'"—25,000
- "'It shall be holy'"—holy
- "'For the holy place five hundred by five hundred'"—temple square
- "'In it shall be the sanctuary, which is most holy'"—most holy
- "'It shall be for the priests'"—for priests
- "'A place for their houses'"—houses
- "'Shall be unto the Levites'"—for Levites
- "'The possession of the city'"—city
- "'It shall be for the whole house of Israel'"—all Israel
- "'For the prince shall be on the one side and on the other'"—prince's land
- "'In the land it shall be to him for a possession'"—prince's possession
- "'My princes shall no more oppress my people'"—no oppression
- "'They shall give the land to the house of Israel according to their tribes'"—tribes get land
- "'Let it suffice you, O princes of Israel'"—enough
- "'Remove violence and spoil'"—remove violence
- "'Execute justice and righteousness'"—do justice
- "'Take away your exactions'"—stop exactions
- "'You shall have just balances'"—just balances
- "'A just ephah, and a just bath'"—just measures
- "'This is the offering that you shall offer'"—offering
- "'One lamb of the flock, out of two hundred'"—1/200
- "'To make atonement'"—atone
- "'All the people of the land shall give this offering for the prince'"—give to prince
- "'It shall be the prince's part to give the burnt-offerings'"—prince provides
- "'In the feasts, and in the new moons, and in the sabbaths'"—festivals
- "'To make atonement for the house of Israel'"—atone
- "'In the first month, in the first day'"—1st of 1st month
- "'You shall purify the sanctuary'"—purify
- "'So you shall do on the seventh day'"—7th day
- "'You shall have the passover'"—Passover
- "'A feast of seven days'"—7-day feast
- "'Unleavened bread shall be eaten'"—unleavened
- "'The prince prepare... a bullock for a sin-offering'"—prince's offering
- "'Seven bullocks and seven rams'"—7 bulls, 7 rams
- "'In the seventh month... the feast'"—Tabernacles
- "'He shall do the like'"—same

**Modern Equivalent:** Ezekiel 45 allocates the holy land: center for sanctuary and priests, adjacent for Levites, then city, with prince's land flanking. The prince provides all public offerings—a centralized system preventing priestly corruption. "No more oppress" (45:8) and "just balances" (45:10) emphasize ethical reform.

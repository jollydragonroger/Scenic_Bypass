# Ezekiel 31: The Cedar of Lebanon — Pharaoh's Fall

*From the Hebrew: וַיְהִי בְּשָׁנָה הָאַחַת עֶשְׂרֵה (Va-Yehi Ba-Shanah Ha-Achat Esreh) — And It Came to Pass in the Eleventh Year*

---

## The Great Cedar (31:1-9)

**31:1** And it came to pass in the eleventh year, in the third month, in the first day of the month, that the word of YHWH came unto me, saying:

**31:2** "Son of man, say unto Pharaoh king of Egypt, and to his multitude: Whom are you like in your greatness?

**31:3** "Behold, the Assyrian was a cedar in Lebanon with fair branches, and with a shadowing shroud, and of a high stature; and its top was among the thick branches.

**31:4** "The waters nourished it, the deep made it to grow tall; her rivers ran round about her plantation, and she sent out her conduits unto all the trees of the field.

**31:5** "Therefore its stature was exalted above all the trees of the field; and its boughs were multiplied, and its branches became long, because of the multitude of waters, when it shot forth.

**31:6** "All the fowls of heaven made their nests in its boughs, and under its branches did all the beasts of the field bring forth their young; and under its shadow dwelt all great nations.

**31:7** "Thus was it fair in its greatness, in the length of its branches; for its root was by many waters.

**31:8** "The cedars in the garden of God could not hide it; the cypress-trees were not like its boughs, and the plane-trees were not as its branches; nor was any tree in the garden of God like unto it in its beauty.

**31:9** "I made it fair by the multitude of its branches; so that all the trees of Eden, that were in the garden of God, envied it."

---

## The Cedar's Fall (31:10-14)

**31:10** Therefore thus says the Lord YHWH: "Because you have exalted yourself in stature, and he has set his top among the thick branches, and his heart is lifted up in his height;

**31:11** "I have therefore delivered him into the hand of the mighty one of the nations; he shall surely deal with him; I have driven him out for his wickedness.

**31:12** "And strangers, the terrible of the nations, have cut him off, and have left him; upon the mountains and in all the valleys his branches are fallen, and his boughs are broken by all the watercourses of the land; and all the peoples of the earth are gone down from his shadow, and have left him.

**31:13** "Upon his ruin all the fowls of the heaven shall dwell, and all the beasts of the field shall be upon his branches;

**31:14** "To the end that none of all the trees by the waters exalt themselves for their stature, neither set their top among the thick branches, nor that their mighty ones stand up in their height, all that drink water; for they are all delivered unto death, to the nether parts of the earth, in the midst of the children of men, with them that go down to the pit."

---

## Descent to Sheol (31:15-18)

**31:15** Thus says the Lord YHWH: "In the day when he went down to Sheol I caused a mourning; I covered the deep for him, and I restrained the rivers thereof, and the great waters were stayed; and I caused Lebanon to mourn for him, and all the trees of the field fainted for him.

**31:16** "I made the nations to shake at the sound of his fall, when I cast him down to Sheol with them that descend into the pit; and all the trees of Eden, the choice and best of Lebanon, all that drink water, were comforted in the nether parts of the earth.

**31:17** "They also went down into Sheol with him unto them that are slain by the sword; yea, they that were his arm, that dwelt under his shadow in the midst of the nations.

**31:18** "To whom are you thus like in glory and in greatness among the trees of Eden? Yet shall you be brought down with the trees of Eden unto the nether parts of the earth; you shall lie in the midst of the uncircumcised, with them that are slain by the sword. This is Pharaoh and all his multitude," says the Lord YHWH.

---

## Synthesis Notes

**Key Restorations:**

**The Great Cedar (31:1-9):**
**The Key Verse (31:1):**
"In the eleventh year, in the third month, in the first day of the month."

*Ba-shanah ha-achat esreh ba-shelishi be-echad la-chodesh*—June 587 BCE.

**The Key Verse (31:2):**
"'Say unto Pharaoh king of Egypt, and to his multitude.'"

*Emor el-Par'oh melekh-Mitzrayim ve-el-hamono*—to Pharaoh.

"'Whom are you like in your greatness?'"

*El-mi damita be-godlekha*—whom like?

**The Key Verse (31:3):**
"'Behold, the Assyrian was a cedar in Lebanon.'"

*Hinneh Ashshur erez ba-Levanon*—Assyria a cedar.

"'With fair branches, and with a shadowing shroud.'"

*Yeفeh anaf ve-choresh metzel*—fair branches.

"'Of a high stature.'"

*Ve-gevah qomah*—high stature.

"'Its top was among the thick branches.'"

*Ve-ein avotim hayetah tzammarto*—top in thick.

**Assyria as Lesson:**
Assyria's fall warns Pharaoh.

**The Key Verses (31:4-5):**
"'The waters nourished it, the deep made it to grow tall.'"

*Mayim giddeluhu tehom romematthu*—waters nourished.

"'Her rivers ran round about her plantation.'"

*Et-naharoteyha holekh sevivot matta'tah*—rivers around.

"'She sent out her conduits unto all the trees of the field.'"

*Ve-et-te'aloteyha shillechah el-kol-atzei ha-sadeh*—conduits out.

"'Its stature was exalted above all the trees of the field.'"

*Al-ken gavehah qomato mi-kol-atzei ha-sadeh*—exalted.

"'Its boughs were multiplied, and its branches became long.'"

*Va-tirbenah sara'ppotav va-te'erakhnah para'otav*—multiplied.

"'Because of the multitude of waters.'"

*Mi-mayim rabbim*—many waters.

**The Key Verses (31:6-7):**
"'All the fowls of heaven made their nests in its boughs.'"

*Be-sa'appotav qinnenu kol-of ha-shamayim*—birds nest.

"'Under its branches did all the beasts of the field bring forth their young.'"

*Ve-tachat para'otav yaledu kol-chayyat ha-sadeh*—beasts birth.

"'Under its shadow dwelt all great nations.'"

*U-ve-tzillo yeshvu kol goyim rabbim*—nations dwell.

"'Thus was it fair in its greatness, in the length of its branches.'"

*Va-yefi ve-godlo be-orekh daliyyotav*—fair in greatness.

"'For its root was by many waters.'"

*Ki-hayah shorsho el-mayim rabbim*—root by waters.

**The Key Verses (31:8-9):**
"'The cedars in the garden of God could not hide it.'"

*Arazim lo amamuhu be-gan-Elohim*—cedars couldn't hide.

"'The cypress-trees were not like its boughs.'"

*Beroshim lo damu el-se'appotav*—cypress not like.

"'The plane-trees were not as its branches.'"

*Va-armenim lo-hayu ke-fora'otav*—planes not like.

"'Nor was any tree in the garden of God like unto it in its beauty.'"

*Ve-khol-etz be-gan-Elohim lo-damah elav be-yofyo*—none like.

"'I made it fair by the multitude of its branches.'"

*Yafeh asitiv be-rov daliyyotav*—I made fair.

"'All the trees of Eden, that were in the garden of God, envied it.'"

*Va-yeqanne'uhu kol-atzei-Eden asher be-gan ha-Elohim*—Eden's trees envied.

**The Cedar's Fall (31:10-14):**
**The Key Verse (31:10):**
"'Because you have exalted yourself in stature.'"

*Ya'an asher gavahta be-qomah*—exalted in height.

"'He has set his top among the thick branches.'"

*Va-yitten tzammarto el-bein avotim*—top in thick.

"'His heart is lifted up in his height.'"

*Ve-ram levavo be-govho*—heart lifted.

**The Key Verse (31:11):**
"'I have therefore delivered him into the hand of the mighty one of the nations.'"

*Va-ettnenu be-yad el goyim*—to mighty one.

"'He shall surely deal with him.'"

*Aso ya'aseh lo*—deal with him.

"'I have driven him out for his wickedness.'"

*Ke-rish'o gerashtiv*—driven out.

**Mighty One = Babylon:**
Nebuchadnezzar destroyed Assyria.

**The Key Verses (31:12-13):**
"'Strangers, the terrible of the nations, have cut him off.'"

*Va-yikhretuhu zarim aritzei goyim*—strangers cut.

"'Have left him.'"

*Va-yittshuhu*—left him.

"'Upon the mountains and in all the valleys his branches are fallen.'"

*Al-he-harim u-ve-khol-ge'ayot nafelu daliyyotav*—branches fallen.

"'His boughs are broken by all the watercourses of the land.'"

*Va-tishsavernah para'otav be-khol-afiqei ha-aretz*—boughs broken.

"'All the peoples of the earth are gone down from his shadow.'"

*Va-yerdu mi-tzillo kol-ammei ha-aretz*—peoples left.

"'Have left him.'"

*Va-yittshuhu*—left.

"'Upon his ruin all the fowls of the heaven shall dwell.'"

*Al-mappelato yihyu kol-of ha-shamayim*—birds on ruin.

"'All the beasts of the field shall be upon his branches.'"

*Ve-el-para'otav hayu kol-chayyat ha-sadeh*—beasts on branches.

**The Key Verse (31:14):**
"'To the end that none of all the trees by the waters exalt themselves for their stature.'"

*Lema'an asher lo-yigbehu ve-qomatam kol-atzei-mayim*—none exalt.

"'Neither set their top among the thick branches.'"

*Ve-lo-yittenu et-tzammartam el-bein avotim*—not set top.

"'Nor that their mighty ones stand up in their height, all that drink water.'"

*Ve-lo ya'amdu eleihem be-govham kol-shotei mayim*—not stand.

"'For they are all delivered unto death, to the nether parts of the earth.'"

*Ki-khullam nittenu la-mavet el-eretz tachtit*—delivered to death.

"'In the midst of the children of men, with them that go down to the pit.'"

*Be-tokh benei adam el-yordei bor*—to pit.

**Descent to Sheol (31:15-18):**
**The Key Verse (31:15):**
"'In the day when he went down to Sheol I caused a mourning.'"

*Be-yom ridto she'olah he'evalti*—mourning.

"'I covered the deep for him.'"

*Kisseti alav et-tehom*—covered deep.

"'I restrained the rivers thereof.'"

*Va-emna naharoteyha*—restrained rivers.

"'The great waters were stayed.'"

*Va-yikkale'u mayim rabbim*—waters stayed.

"'I caused Lebanon to mourn for him.'"

*Va-aqdir alav et-Levanon*—Lebanon mourns.

"'All the trees of the field fainted for him.'"

*Ve-khol-atzei ha-sadeh alav ulefah*—trees faint.

**The Key Verses (31:16-17):**
"'I made the nations to shake at the sound of his fall.'"

*Mi-qol mappelato hir'ashti goyim*—nations shake.

"'When I cast him down to Sheol with them that descend into the pit.'"

*Be-horidi oto she'olah et-yordei bor*—to Sheol.

"'All the trees of Eden, the choice and best of Lebanon.'"

*Va-yinnachamu be-eretz tachtit kol-atzei Eden mivchar ve-tov Levanon*—Eden's trees.

"'All that drink water, were comforted in the nether parts of the earth.'"

*Kol-shotei mayim*—drink water.

"'They also went down into Sheol with him.'"

*Gam-hem yardu itto she'olah*—went down with.

"'Unto them that are slain by the sword.'"

*El-challalei-cherev*—slain by sword.

"'They that were his arm, that dwelt under his shadow in the midst of the nations.'"

*U-zero'o yashvu ve-tzillo be-tokh goyim*—his arm, under shadow.

**The Key Verse (31:18):**
"'To whom are you thus like in glory and in greatness among the trees of Eden?'"

*El-mi damita kakhah be-khavod u-ve-godel ba-atzei Eden*—whom like?

"'Yet shall you be brought down with the trees of Eden unto the nether parts of the earth.'"

*Ve-horadta et-atzei-Eden el-eretz tachtit*—brought down.

"'You shall lie in the midst of the uncircumcised.'"

*Be-tokh arelim tishkav*—among uncircumcised.

"'With them that are slain by the sword.'"

*Et-challalei-cherev*—sword-slain.

"'This is Pharaoh and all his multitude.'"

*Hu Par'oh ve-khol-hamono*—this is Pharaoh.

**Archetypal Layer:** Ezekiel 31 compares **Pharaoh to Assyria as a great cedar (31:3)**, **"all the trees of Eden, that were in the garden of God, envied it" (31:9)**, **"I have delivered him into the hand of the mighty one of the nations" (31:11)**, **cosmic mourning at his fall (31:15)**, **"all the trees of Eden... were comforted in the nether parts of the earth" (31:16)**, and **"This is Pharaoh and all his multitude" (31:18)**.

**Ethical Inversion Applied:**
- "In the eleventh year, in the third month"—June 587 BCE
- "'Whom are you like in your greatness?'"—rhetorical
- "'Behold, the Assyrian was a cedar in Lebanon'"—Assyria as cedar
- "'With fair branches, and with a shadowing shroud'"—fair branches
- "'Of a high stature'"—high
- "'Its top was among the thick branches'"—top in thick
- "'The waters nourished it, the deep made it to grow tall'"—waters nourish
- "'Its stature was exalted above all the trees of the field'"—exalted
- "'All the fowls of heaven made their nests in its boughs'"—birds nest
- "'Under its branches did all the beasts of the field bring forth their young'"—beasts birth
- "'Under its shadow dwelt all great nations'"—nations dwell
- "'The cedars in the garden of God could not hide it'"—couldn't hide
- "'Nor was any tree in the garden of God like unto it'"—none like
- "'I made it fair by the multitude of its branches'"—I made fair
- "'All the trees of Eden... envied it'"—envied
- "'Because you have exalted yourself in stature'"—pride
- "'His heart is lifted up in his height'"—heart lifted
- "'I have therefore delivered him into the hand of the mighty one'"—to mighty one
- "'I have driven him out for his wickedness'"—driven out
- "'Strangers, the terrible of the nations, have cut him off'"—cut off
- "'Upon the mountains... his branches are fallen'"—branches fallen
- "'All the peoples of the earth are gone down from his shadow'"—peoples left
- "'Upon his ruin all the fowls... shall dwell'"—birds on ruin
- "'None of all the trees by the waters exalt themselves'"—lesson
- "'They are all delivered unto death'"—delivered to death
- "'To the nether parts of the earth'"—netherworld
- "'With them that go down to the pit'"—to pit
- "'In the day when he went down to Sheol I caused a mourning'"—mourning
- "'I covered the deep for him'"—covered deep
- "'I caused Lebanon to mourn for him'"—Lebanon mourns
- "'I made the nations to shake at the sound of his fall'"—nations shake
- "'All the trees of Eden... were comforted in the nether parts'"—comforted below
- "'They also went down into Sheol with him'"—went with him
- "'To whom are you thus like in glory and in greatness?'"—whom like?
- "'You shall lie in the midst of the uncircumcised'"—among uncircumcised
- "'This is Pharaoh and all his multitude'"—Pharaoh

**Modern Equivalent:** Ezekiel 31 uses Assyria's fall to warn Egypt. The cosmic tree imagery (garden of God, Eden) elevates Assyria to mythic status—then shows its fall. The "trees of Eden... comforted in the nether parts" (31:16) ironically depicts Sheol's welcome to fallen powers. "This is Pharaoh" (31:18) applies the lesson.

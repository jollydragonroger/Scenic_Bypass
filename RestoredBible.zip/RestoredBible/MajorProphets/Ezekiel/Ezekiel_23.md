# Ezekiel 23: Oholah and Oholibah — The Two Sisters

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## The Two Sisters (23:1-4)

**23:1** And the word of YHWH came unto me, saying:

**23:2** "Son of man, there were two women, the daughters of one mother;

**23:3** "And they played the harlot in Egypt; they played the harlot in their youth; there were their breasts pressed, and there their virgin bosoms were bruised.

**23:4** "And the names of them were Oholah the elder, and Oholibah her sister; and they became mine, and they bore sons and daughters. And as for their names, Samaria is Oholah, and Jerusalem is Oholibah."

---

## Oholah — Samaria (23:5-10)

**23:5** "And Oholah played the harlot when she was mine; and she doted on her lovers, on the Assyrians, warriors,

**23:6** "Clothed with blue, governors and rulers, handsome young men all of them, horsemen riding upon horses.

**23:7** "And she bestowed her harlotries upon them, the choicest men of Assyria all of them; and on whomsoever she doted, with all their idols she defiled herself.

**23:8** "Neither has she left her harlotries brought from Egypt; for in her youth they lay with her, and they bruised her virgin breasts; and they poured out their lust upon her.

**23:9** "Wherefore I delivered her into the hand of her lovers, into the hand of the Assyrians, upon whom she doted.

**23:10** "These uncovered her nakedness; they took her sons and her daughters; and her they slew with the sword; and she became a byword among women, for judgments were executed upon her."

---

## Oholibah — Jerusalem (23:11-21)

**23:11** "And her sister Oholibah saw this, yet was she more corrupt in her doting than she, and in her harlotries more than her sister in her harlotries.

**23:12** "She doted upon the Assyrians, governors and rulers, warriors, clothed most gorgeously, horsemen riding upon horses, handsome young men all of them.

**23:13** "And I saw that she was defiled; they both took one way.

**23:14** "And she increased her harlotries; for she saw men portrayed upon the wall, the images of the Chaldeans portrayed with vermilion,

**23:15** "Girded with girdles upon their loins, with pendant turbans upon their heads, all of them captains to look upon, the likeness of the sons of Babylon, even of Chaldea, the land of their nativity.

**23:16** "And as soon as she saw them she doted upon them, and sent messengers unto them into Chaldea.

**23:17** "And the Babylonians came to her into the bed of love, and they defiled her with their lust; and she was polluted with them, and her soul was alienated from them.

**23:18** "So she uncovered her harlotries, and uncovered her nakedness; then my soul was alienated from her, like as my soul was alienated from her sister.

**23:19** "Yet she multiplied her harlotries, remembering the days of her youth, wherein she had played the harlot in the land of Egypt.

**23:20** "And she doted upon their paramours, whose flesh is as the flesh of asses, and whose issue is like the issue of horses.

**23:21** "Thus you did call to remembrance the lewdness of your youth, when they from Egypt bruised your breasts for the bosom of your youth."

---

## Oholibah's Judgment (23:22-35)

**23:22** "Therefore, O Oholibah, thus says the Lord YHWH: Behold, I will raise up your lovers against you, from whom your soul is alienated, and I will bring them against you on every side:

**23:23** "The Babylonians and all the Chaldeans, Pekod and Shoa and Koa, and all the Assyrians with them; handsome young men, governors and rulers all of them, captains and councillors, all of them riding upon horses.

**23:24** "And they shall come against you with weapons, chariots, and wheels, and with an assembly of peoples; they shall set themselves against you with buckler and shield and helmet round about; and I will commit the judgment unto them, and they shall judge you according to their judgments.

**23:25** "And I will set my jealousy against you, and they shall deal with you in fury; they shall take away your nose and your ears, and your residue shall fall by the sword; they shall take your sons and your daughters, and your residue shall be devoured by the fire.

**23:26** "They shall also strip you of your clothes, and take away your fair jewels.

**23:27** "Thus will I make your lewdness to cease from you, and your harlotry brought from the land of Egypt, so that you shall not lift up your eyes unto them, nor remember Egypt any more.

**23:28** "For thus says the Lord YHWH: Behold, I will deliver you into the hand of them whom you hate, into the hand of them from whom your soul is alienated;

**23:29** "And they shall deal with you in hatred, and shall take away all your labor, and shall leave you naked and bare; and the nakedness of your harlotries shall be uncovered, both your lewdness and your harlotries.

**23:30** "These things shall be done unto you, for that you have gone astray after the nations, and because you are polluted with their idols.

**23:31** "In the way of your sister have you walked; therefore will I give her cup into your hand.

**23:32** "Thus says the Lord YHWH: You shall drink of your sister's cup, which is deep and large; you shall be laughed to scorn and had in derision; it contains much.

**23:33** "You shall be filled with drunkenness and sorrow, with the cup of astonishment and desolation, with the cup of your sister Samaria.

**23:34** "You shall even drink it and drain it, and you shall gnaw the sherds thereof, and shall tear your breasts; for I have spoken it," says the Lord YHWH.

**23:35** "Therefore thus says the Lord YHWH: Because you have forgotten me, and cast me behind your back, therefore bear also your lewdness and your harlotries."

---

## Judgment on Both Sisters (23:36-49)

**23:36** YHWH said moreover unto me: "Son of man, will you judge Oholah and Oholibah? Then declare unto them their abominations.

**23:37** "For they have committed adultery, and blood is in their hands, and with their idols have they committed adultery; and their sons, whom they bore unto me, they have also set apart unto them to be devoured.

**23:38** "Moreover this they have done unto me: they have defiled my sanctuary in the same day, and have profaned my sabbaths.

**23:39** "For when they had slain their children to their idols, then they came the same day into my sanctuary to profane it; and, lo, thus have they done in the midst of my house.

**23:40** "And furthermore you have sent for men that come from far; unto whom a messenger was sent, and, lo, they came; for whom you did wash yourself, paint your eyes, and deck yourself with ornaments;

**23:41** "And sat upon a stately bed, with a table prepared before it, whereupon you did set my incense and my oil.

**23:42** "And the voice of a multitude being at ease was therein; and with men of the common sort were brought drunkards from the wilderness; and they put bracelets upon their hands, and beautiful crowns upon their heads.

**23:43** "Then said I of her that was worn out by adulteries: Still they commit harlotries with her, even her.

**23:44** "For every one went in unto her, as men go in unto a harlot; so went they in unto Oholah and unto Oholibah, the lewd women.

**23:45** "But righteous men, they shall judge them as adulteresses are judged, and as women that shed blood are judged; because they are adulteresses, and blood is in their hands.

**23:46** "For thus says the Lord YHWH: An assembly shall be brought up against them, and they shall be made a horror and a spoil.

**23:47** "And the assembly shall stone them with stones, and dispatch them with their swords; they shall slay their sons and their daughters, and burn their houses with fire.

**23:48** "Thus will I cause lewdness to cease out of the land, that all women may be taught not to do after your lewdness.

**23:49** "And your lewdness shall be recompensed upon you, and you shall bear the sins of your idols; and you shall know that I am the Lord YHWH."

---

## Synthesis Notes

**Key Restorations:**

**Two Sisters (23:1-4):**
"'There were two women, the daughters of one mother.'"

*Shetei nashim benot em-achat hayu*—two daughters.

"'They played the harlot in Egypt; they played the harlot in their youth.'"

*Va-tiznennah ve-Mitzrayim bi-ne'ureihen zanu*—harlotry in Egypt.

**The Key Verse (23:4):**
"'The names of them were Oholah the elder, and Oholibah her sister.'"

*U-shemotam Oholah ha-gedolah ve-Oholivah achotah*—names.

"'They became mine, and they bore sons and daughters.'"

*Va-tihyennah li va-teledenah banim u-vanot*—became mine.

"'Samaria is Oholah, and Jerusalem is Oholibah.'"

*U-shemotam Shomeron Oholah vi-Yrushalayim Oholivah*—identities.

**Names:**
- **Oholah** = "her tent" (Samaria had her own sanctuary)
- **Oholibah** = "my tent is in her" (Jerusalem had YHWH's temple)

**Oholah — Samaria (23:5-10):**
"'Oholah played the harlot when she was mine.'"

*Va-tizen Oholah tachtay*—harlotry under me.

"'She doted on her lovers, on the Assyrians.'"

*Va-te'egav al-me'ahaveyha el-Ashshur qerovim*—doted on Assyrians.

"'Clothed with blue, governors and rulers.'"

*Levushei tekhelet pachot u-seganim*—dressed finely.

"'Horsemen riding upon horses.'"

*Parashim rokhevei susim*—horsemen.

"'With all their idols she defiled herself.'"

*U-ve-khol-gilluleihem nitma'ah*—defiled.

"'Neither has she left her harlotries brought from Egypt.'"

*Ve-et-taznuwteyha mi-Mitzrayim lo azavah*—from Egypt.

**The Key Verses (23:9-10):**
"'I delivered her into the hand of her lovers, into the hand of the Assyrians.'"

*Lakhen netattihah be-yad me'ahaveyha be-yad benei-Ashshur*—to Assyrians.

"'These uncovered her nakedness.'"

*Hemmah gillu ervatah*—uncovered.

"'They took her sons and her daughters.'"

*Baneyha u-venoteyha laqachu*—took children.

"'Her they slew with the sword.'"

*Ve-otah ba-cherev haragu*—slew.

"'She became a byword among women.'"

*Va-tehi shem la-nashim*—byword.

**722 BCE:**
Assyria destroyed Samaria.

**Oholibah — Jerusalem (23:11-21):**
"'Her sister Oholibah saw this.'"

*Va-tere achotah Oholivah*—saw.

"'Yet was she more corrupt in her doting than she.'"

*Va-tashchet agavatah mimmennah*—more corrupt.

"'In her harlotries more than her sister.'"

*Ve-et-taznuwteyha me-taznunei achotah*—more harlotries.

"'She doted upon the Assyrians.'"

*El-benei Ashshur agavah*—doted on Assyrians.

"'She increased her harlotries.'"

*Va-tosef el-taznuwteyha*—increased.

"'She saw men portrayed upon the wall, the images of the Chaldeans.'"

*Va-tere anshei mechuqqei al-ha-qir tzalmei Kasdim*—Chaldean images.

"'Portrayed with vermilion.'"

*Chaquqim ba-shashar*—vermilion.

"'She doted upon them, and sent messengers unto them into Chaldea.'"

*Va-te'egav aleihem le-mar'eh eineyha va-tishlach mal'akhim aleihem Kashdimah*—sent to Chaldea.

"'The Babylonians came to her into the bed of love.'"

*Va-yavo'u elehha benei-Bavel le-mishkav dodim*—bed of love.

"'She was polluted with them, and her soul was alienated from them.'"

*Va-tittamme bahem va-teqa nafshah me-hem*—alienated.

**The Key Verse (23:18):**
"'She uncovered her harlotries, and uncovered her nakedness.'"

*Va-tegal taznuwteyha va-tegal et-ervatah*—uncovered.

"'My soul was alienated from her.'"

*Va-teqa nafshi me-alekha*—YHWH alienated.

**The Key Verse (23:20):**
"'She doted upon their paramours, whose flesh is as the flesh of asses.'"

*Va-te'egav al pilagseihem asher besar-chamorim besaram*—crude imagery.

**Oholibah's Judgment (23:22-35):**
"'I will raise up your lovers against you.'"

*Hineni me'ir et-me'ahavayikh alayikh*—raise lovers.

"'From whom your soul is alienated.'"

*Asher naqe'ah nafshekh me-hem*—alienated from.

"'I will bring them against you on every side.'"

*Va-havetiм alayikh mi-saviv*—from every side.

"'The Babylonians and all the Chaldeans, Pekod and Shoa and Koa.'"

*Benei-Bavel ve-khol-Kasdim Peqod ve-Sho'a ve-Qo'a*—eastern tribes.

"'They shall come against you with weapons, chariots, and wheels.'"

*U-va'u alayikh hotzen rekhev ve-galgal*—weapons.

"'They shall set themselves against you with buckler and shield and helmet.'"

*Ve-samu alayikh tzinnah u-magen ve-qova*—armor.

**The Key Verses (23:25-26):**
"'They shall take away your nose and your ears.'"

*Ve-hesiru appekh ve-oznayikh*—mutilation.

"'Your residue shall fall by the sword.'"

*Ve-acharitekh ba-cherev tippol*—fall.

"'They shall take your sons and your daughters.'"

*Yiqqechu banayikh u-venotayikh*—take children.

"'Your residue shall be devoured by the fire.'"

*Ve-acharitekh te'akhel ba-esh*—fire devour.

"'They shall also strip you of your clothes.'"

*Ve-hifshitukh et-begadayikh*—stripped.

"'Take away your fair jewels.'"

*Ve-laqechu kelei tif'artekh*—take jewels.

**The Key Verses (23:31-34):**
"'In the way of your sister have you walked.'"

*Be-derekh achotkekh halakht*—walked sister's way.

"'I will give her cup into your hand.'"

*Ve-natatti kosah be-yadekh*—give cup.

"'You shall drink of your sister's cup, which is deep and large.'"

*Kos achotkekh tishtي amuqqah u-rechavah*—deep, large cup.

"'You shall be laughed to scorn and had in derision.'"

*Li-tzechoq u-le-la'ag tihyeh*—mocked.

"'You shall be filled with drunkenness and sorrow.'"

*Shikkaron ve-yagon timmale'i*—drunk, sorrowful.

"'The cup of astonishment and desolation.'"

*Kos shammah u-shemamah*—astonishment.

"'You shall even drink it and drain it.'"

*Ve-shatit otah u-matzit*—drain.

"'You shall gnaw the sherds thereof.'"

*Ve-et-charaseyha tenaqqemi*—gnaw sherds.

"'Shall tear your breasts.'"

*Ve-shadayikh tenattaqi*—tear breasts.

**The Key Verse (23:35):**
"'Because you have forgotten me, and cast me behind your back.'"

*Ya'an shakacht oti va-tashlikh oti acharei gavvekh*—forgotten, cast behind.

"'Bear also your lewdness and your harlotries.'"

*Ve-gam at se'i zimmatekh ve-et-taznuwtayikh*—bear.

**Judgment on Both (23:36-49):**
"'They have committed adultery, and blood is in their hands.'"

*Ki ni'efu ve-dam bi-ydeihen*—adultery, blood.

"'With their idols have they committed adultery.'"

*Ve-et-gilluleihen ni'efu*—with idols.

"'Their sons, whom they bore unto me, they have also set apart unto them.'"

*Ve-gam et-beneihen asher yaledu li he'eviru lahem le-okhlah*—child sacrifice.

"'They have defiled my sanctuary in the same day.'"

*Ve-et-miqdashi timme'u ba-yom ha-hu*—defiled sanctuary.

"'Have profaned my sabbaths.'"

*Ve-et-shabbtotai chillelu*—profaned sabbaths.

"'When they had slain their children to their idols, then they came the same day into my sanctuary.'"

*U-ve-shachtam et-beneihem le-gilluleihem va-yavo'u el-miqdashi ba-yom ha-hu*—same day.

**The Key Verse (23:45):**
"'Righteous men, they shall judge them as adulteresses are judged.'"

*Va-anashim tzaddiqim hemmah yishpetu othen mishpat no'afot*—judged as adulteresses.

"'And as women that shed blood are judged.'"

*U-mishpat shofkhot dam*—blood-shedders.

**The Key Verses (23:47-49):**
"'The assembly shall stone them with stones.'"

*Ve-ragemu aleihen even qahal*—stoned.

"'Dispatch them with their swords.'"

*U-vare othen be-charvotam*—dispatched.

"'Slay their sons and their daughters.'"

*Beneihen u-venoteihen yaharogu*—slay children.

"'Burn their houses with fire.'"

*U-vatteihen ba-esh yisrofu*—burn houses.

"'I will cause lewdness to cease out of the land.'"

*Ve-hishbatti zimmah min-ha-aretz*—cease lewdness.

"'You shall know that I am the Lord YHWH.'"

*Vi-ydatem ki ani Adonai YHWH*—recognition.

**Archetypal Layer:** Ezekiel 23 is the **parable of two sisters**, containing **Oholah (Samaria) and Oholibah (Jerusalem) (23:4)**, **Oholah's doting on Assyria (23:5-10)**, **Oholibah worse than her sister (23:11)**, **"You shall drink of your sister's cup" (23:31-34)**, and **child sacrifice followed by temple worship (23:39)**.

**Ethical Inversion Applied:**
- "'There were two women, the daughters of one mother'"—two sisters
- "'They played the harlot in Egypt'"—Egypt
- "'Oholah the elder, and Oholibah her sister'"—names
- "'Samaria is Oholah, and Jerusalem is Oholibah'"—identities
- "'Oholah played the harlot when she was mine'"—under YHWH
- "'She doted on her lovers, on the Assyrians'"—Assyria
- "'With all their idols she defiled herself'"—defiled
- "'I delivered her into the hand of her lovers'"—to Assyrians
- "'They took her sons and her daughters'"—took children
- "'Her they slew with the sword'"—slew
- "'She became a byword among women'"—byword
- "'Her sister Oholibah saw this'"—saw
- "'Yet was she more corrupt'"—more corrupt
- "'She saw men portrayed upon the wall, the images of the Chaldeans'"—Chaldean images
- "'She doted upon them, and sent messengers'"—sent to Chaldea
- "'The Babylonians came to her into the bed of love'"—bed of love
- "'My soul was alienated from her'"—YHWH alienated
- "'I will raise up your lovers against you'"—lovers against
- "'From whom your soul is alienated'"—alienated from
- "'They shall take away your nose and your ears'"—mutilation
- "'They shall strip you of your clothes'"—stripped
- "'In the way of your sister have you walked'"—walked sister's way
- "'I will give her cup into your hand'"—cup
- "'You shall drink of your sister's cup'"—drink
- "'It contains much'"—much
- "'You shall be filled with drunkenness and sorrow'"—drunk, sorrow
- "'Because you have forgotten me, and cast me behind your back'"—forgotten
- "'They have committed adultery, and blood is in their hands'"—adultery, blood
- "'Their sons... they have also set apart unto them'"—child sacrifice
- "'They have defiled my sanctuary in the same day'"—same day
- "'When they had slain their children... they came... into my sanctuary'"—sacrilege
- "'Righteous men... shall judge them as adulteresses'"—judged
- "'The assembly shall stone them'"—stoned
- "'You shall know that I am the Lord YHWH'"—recognition

**Modern Equivalent:** Ezekiel 23 parallels chapter 16 but focuses on political alliances as adultery. Oholah (Samaria) fell to Assyria (722 BCE); Oholibah (Jerusalem) learned nothing and became worse. The "cup" imagery (23:31-34) appears in Jeremiah 25 and Revelation 17-18.

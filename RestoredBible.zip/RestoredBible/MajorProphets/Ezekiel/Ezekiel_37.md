# Ezekiel 37: The Valley of Dry Bones and Two Sticks United

*From the Hebrew: הָיְתָה עָלַי יַד־יְהוָה (Hayetah Alai Yad-YHWH) — The Hand of YHWH Was Upon Me*

---

## The Valley of Dry Bones (37:1-14)

**37:1** The hand of YHWH was upon me, and he carried me out in the spirit of YHWH, and set me down in the midst of the valley, and it was full of bones.

**37:2** And he caused me to pass by them round about, and, behold, there were very many in the open valley; and, lo, they were very dry.

**37:3** And he said unto me: "Son of man, can these bones live?" And I answered: "O Lord YHWH, you know."

**37:4** Then he said unto me: "Prophesy over these bones, and say unto them: O you dry bones, hear the word of YHWH:

**37:5** "Thus says the Lord YHWH unto these bones: Behold, I will cause breath to enter into you, and you shall live.

**37:6** "And I will lay sinews upon you, and will bring up flesh upon you, and cover you with skin, and put breath in you, and you shall live; and you shall know that I am YHWH."

**37:7** So I prophesied as I was commanded; and as I prophesied, there was a noise, and behold a commotion, and the bones came together, bone to its bone.

**37:8** And I beheld, and, lo, there were sinews upon them, and flesh came up, and skin covered them above; but there was no breath in them.

**37:9** Then said he unto me: "Prophesy unto the breath, prophesy, son of man, and say to the breath: Thus says the Lord YHWH: Come from the four winds, O breath, and breathe upon these slain, that they may live."

**37:10** So I prophesied as he commanded me, and the breath came into them, and they lived, and stood up upon their feet, an exceeding great host.

**37:11** Then he said unto me: "Son of man, these bones are the whole house of Israel; behold, they say: 'Our bones are dried up, and our hope is lost; we are clean cut off.'

**37:12** "Therefore prophesy, and say unto them: Thus says the Lord YHWH: Behold, I will open your graves, and cause you to come up out of your graves, O my people; and I will bring you into the land of Israel.

**37:13** "And you shall know that I am YHWH, when I have opened your graves, and caused you to come up out of your graves, O my people.

**37:14** "And I will put my spirit in you, and you shall live, and I will place you in your own land; and you shall know that I YHWH have spoken, and performed it," says YHWH.

---

## The Two Sticks United (37:15-28)

**37:15** And the word of YHWH came unto me, saying:

**37:16** "And you, son of man, take one stick, and write upon it: 'For Judah, and for the children of Israel his companions'; then take another stick, and write upon it: 'For Joseph, the stick of Ephraim, and of all the house of Israel his companions';

**37:17** "And join them one to another into one stick, that they may become one in your hand.

**37:18** "And when the children of your people shall speak unto you, saying: 'Will you not tell us what you mean by these?'

**37:19** "Say unto them: Thus says the Lord YHWH: Behold, I will take the stick of Joseph, which is in the hand of Ephraim, and the tribes of Israel his companions; and I will put them unto it together with the stick of Judah, and make them one stick, and they shall be one in my hand.

**37:20** "And the sticks whereon you write shall be in your hand before their eyes.

**37:21** "And say unto them: Thus says the Lord YHWH: Behold, I will take the children of Israel from among the nations, whither they are gone, and will gather them on every side, and bring them into their own land.

**37:22** "And I will make them one nation in the land, upon the mountains of Israel, and one king shall be king to them all; and they shall be no more two nations, neither shall they be divided into two kingdoms any more at all.

**37:23** "Neither shall they defile themselves any more with their idols, nor with their detestable things, nor with any of their transgressions; but I will save them out of all their dwelling-places, wherein they have sinned, and will cleanse them; so shall they be my people, and I will be their God.

**37:24** "And my servant David shall be king over them, and they all shall have one shepherd; they shall also walk in my ordinances, and observe my statutes, and do them.

**37:25** "And they shall dwell in the land that I have given unto Jacob my servant, wherein your fathers dwelt; and they shall dwell therein, they, and their children, and their children's children, for ever; and David my servant shall be their prince for ever.

**37:26** "Moreover I will make a covenant of peace with them—it shall be an everlasting covenant with them—and I will establish them, and multiply them, and will set my sanctuary in the midst of them for ever.

**37:27** "My dwelling-place also shall be over them; and I will be their God, and they shall be my people.

**37:28** "And the nations shall know that I am YHWH that sanctify Israel, when my sanctuary shall be in the midst of them for ever."

---

## Synthesis Notes

**Key Restorations:**

**Valley of Dry Bones (37:1-14):**
**The Key Verse (37:1):**
"The hand of YHWH was upon me."

*Hayetah alai yad-YHWH*—hand upon.

"He carried me out in the spirit of YHWH."

*Va-yotzi'eni be-ruach YHWH*—spirit carried.

"Set me down in the midst of the valley."

*Va-yenicheni be-tokh ha-biq'ah*—in valley.

"It was full of bones."

*Ve-hi mele'ah atzamot*—full of bones.

**The Key Verse (37:2):**
"He caused me to pass by them round about."

*Ve-he'evirani aleihem saviv saviv*—pass around.

"There were very many in the open valley."

*Ve-hinneh rabbot me'od al-penei ha-biq'ah*—very many.

"They were very dry."

*Ve-hinneh yeveshim me'od*—very dry.

**The Key Verse (37:3):**
"'Son of man, can these bones live?'"

*Ben-adam ha-tichyenah ha-atzamot ha-elleh*—can they live?

"'O Lord YHWH, you know.'"

*Adonai YHWH attah yada'ta*—you know.

**The Key Verses (37:4-6):**
"'Prophesy over these bones.'"

*Hinnave al-ha-atzamot ha-elleh*—prophesy.

"'Say unto them: O you dry bones, hear the word of YHWH.'"

*Ve-amarta aleihem ha-atzamot ha-yeveshim shim'u devar-YHWH*—hear.

"'I will cause breath to enter into you.'"

*Hineni mevi vakhem ruach*—breath/spirit.

"'You shall live.'"

*Vi-cheyitem*—shall live.

"'I will lay sinews upon you.'"

*Ve-natatti aleikhem gidim*—sinews.

"'Will bring up flesh upon you.'"

*Ve-ha'aleiti aleikhem basar*—flesh.

"'Cover you with skin.'"

*Ve-qeramti aleikhem or*—skin.

"'Put breath in you.'"

*Ve-natatti vakhem ruach*—breath.

"'You shall know that I am YHWH.'"

*Vi-ydatem ki-ani YHWH*—recognition.

**The Key Verses (37:7-8):**
"So I prophesied as I was commanded."

*Ve-nibbeti ka-asher tzuvveiti*—prophesied.

"There was a noise, and behold a commotion."

*Va-yehi qol ke-hinnave'i ve-hinneh ra'ash*—noise, commotion.

"The bones came together, bone to its bone."

*Va-tiqrevu atzamot etzem el-atzmo*—bones together.

"There were sinews upon them, and flesh came up, and skin covered them."

*Ve-ra'iti ve-hinneh-aleihem gidim u-vasar alah va-yiqram aleihem or*—sinews, flesh, skin.

"But there was no breath in them."

*Ve-ruach ein bahem*—no breath.

**The Key Verses (37:9-10):**
"'Prophesy unto the breath.'"

*Hinnave el-ha-ruach*—prophesy to breath.

"'Say to the breath: Thus says the Lord YHWH.'"

*Ve-amarta el-ha-ruach koh amar Adonai YHWH*—say.

"'Come from the four winds, O breath.'"

*Me-arba ruchot bo'i ha-ruach*—four winds.

"'Breathe upon these slain, that they may live.'"

*U-fechi ba-harugim ha-elleh ve-yichyu*—breathe, live.

"So I prophesied as he commanded me."

*Ve-nibbeiti ka-asher tzivvani*—prophesied.

"The breath came into them, and they lived."

*Va-tavo bahem ha-ruach va-yichyu*—lived.

"Stood up upon their feet, an exceeding great host."

*Va-ya'amdu al-ragleihem chayil gadol me'od me'od*—great host.

**Ruach:**
Hebrew *ruach* means breath, wind, and spirit simultaneously.

**The Key Verses (37:11-14):**
"'These bones are the whole house of Israel.'"

*Ha-atzamot ha-elleh kol-beit Yisra'el hemmah*—all Israel.

"'Behold, they say: Our bones are dried up.'"

*Hinneh omerim yaveshu atzmoteinu*—dried up.

"'Our hope is lost.'"

*Ve-avdah tiqvatenu*—hope lost.

"'We are clean cut off.'"

*Nigzarnu lanu*—cut off.

"'Behold, I will open your graves.'"

*Hineni fote'ach et-qivroteikhem*—open graves.

"'Cause you to come up out of your graves, O my people.'"

*Ve-ha'aleiti etkhem mi-qivroteikhem ammi*—rise from graves.

"'I will bring you into the land of Israel.'"

*Ve-heveti etkhem el-admat Yisra'el*—to Israel.

"'You shall know that I am YHWH, when I have opened your graves.'"

*Vi-ydatem ki-ani YHWH be-fitchi et-qivroteikhem*—recognition.

"'I will put my spirit in you, and you shall live.'"

*Ve-natatti ruchi vakhem vi-cheyitem*—spirit, live.

"'I will place you in your own land.'"

*Ve-hinachti etkhem al-admatekhem*—in land.

"'You shall know that I YHWH have spoken, and performed it.'"

*Vi-ydatem ki-ani YHWH dibbarti ve-asiti*—spoken, done.

**Two Sticks United (37:15-28):**
**The Key Verses (37:16-17):**
"'Take one stick, and write upon it: For Judah.'"

*Qach-lekha etz echad u-ketov alav li-Yhudah*—Judah's stick.

"'And for the children of Israel his companions.'"

*Ve-li-vnei Yisra'el chaverav*—companions.

"'Take another stick, and write upon it: For Joseph.'"

*U-lqach etz echad u-ketov alav le-Yosef*—Joseph's stick.

"'The stick of Ephraim, and of all the house of Israel his companions.'"

*Etz Efrayim ve-khol-beit Yisra'el chaverav*—Ephraim's.

"'Join them one to another into one stick.'"

*Ve-qarev otam echad el-echad lekha le-etz echad*—join.

"'That they may become one in your hand.'"

*Ve-hayu le-achadim be-yadekha*—one in hand.

**The Key Verses (37:18-22):**
"'When the children of your people shall speak unto you.'"

*Ve-kha'asher yomru elekha benei ammekha*—when ask.

"''Will you not tell us what you mean by these?''"

*Ha-lo taggid lanu mah-elleh lakh*—what does it mean?

"'I will take the stick of Joseph... and put them unto it together with the stick of Judah.'"

*Hineni loqe'ach et-etz Yosef... ve-natatti otam alav et-etz Yehudah*—join sticks.

"'Make them one stick, and they shall be one in my hand.'"

*Va-asitim le-etz echad ve-hayu echad be-yadi*—one.

"'I will take the children of Israel from among the nations.'"

*Hineni loqe'ach et-benei Yisra'el mi-bein ha-goyim*—take from nations.

"'Will gather them on every side.'"

*Ve-qibbaתzti otam mi-saviv*—gather.

"'Bring them into their own land.'"

*Ve-heveti otam el-admatam*—to land.

"'I will make them one nation in the land.'"

*Ve-asiti otam le-goy echad ba-aretz*—one nation.

"'Upon the mountains of Israel.'"

*Be-harei Yisra'el*—on mountains.

"'One king shall be king to them all.'"

*U-melekh echad yihyeh le-khullam le-melekh*—one king.

"'They shall be no more two nations.'"

*Ve-lo yihyu-od li-shenei goyim*—not two.

"'Neither shall they be divided into two kingdoms any more.'"

*Ve-lo yechatzzu od li-shtei mamlakhot od*—not divided.

**The Key Verses (37:23-25):**
"'Neither shall they defile themselves any more with their idols.'"

*Ve-lo yittamme'u od be-gilluleihem*—no more defile.

"'Nor with their detestable things.'"

*U-ve-shiqqutzzeihem*—detestable.

"'I will save them out of all their dwelling-places, wherein they have sinned.'"

*Ve-hosha'ti otam mi-kol moshvoteihem asher chat'u vahem*—save.

"'Will cleanse them.'"

*Ve-tiharti otam*—cleanse.

"'They shall be my people, and I will be their God.'"

*Ve-hayu-li le-am va-ani ehyeh lahem le-Elohim*—covenant formula.

"'My servant David shall be king over them.'"

*Ve-avdi David melekh aleihem*—David king.

"'They all shall have one shepherd.'"

*Ve-ro'eh echad yihyeh le-khullam*—one shepherd.

"'They shall also walk in my ordinances.'"

*U-ve-mishpatai yelekhu*—walk in ordinances.

"'Observe my statutes, and do them.'"

*Ve-chuqqotai yishmeru ve-asu otam*—keep, do.

"'They shall dwell in the land that I have given unto Jacob my servant.'"

*Ve-yashvu al-ha-aretz asher natatti le-avdi le-Ya'aqov*—dwell in land.

"'Wherein your fathers dwelt.'"

*Asher yashvu vah avoteikhem*—fathers dwelt.

"'They, and their children, and their children's children, for ever.'"

*Ve-yashvu aleha hemmah u-veneihem u-venei veneihem ad-olam*—forever.

"'David my servant shall be their prince for ever.'"

*Ve-David avdi nasi lahem le-olam*—David prince forever.

**The Key Verses (37:26-28):**
"'I will make a covenant of peace with them.'"

*Ve-kharati lahem berit shalom*—covenant of peace.

"'It shall be an everlasting covenant with them.'"

*Berit olam yihyeh otam*—everlasting.

"'I will establish them, and multiply them.'"

*U-netattim ve-hirbeti otam*—establish, multiply.

"'Will set my sanctuary in the midst of them for ever.'"

*Ve-natatti et-miqdashi be-tokham le-olam*—sanctuary.

"'My dwelling-place also shall be over them.'"

*Ve-hayah mishkani aleihem*—dwelling.

"'I will be their God, and they shall be my people.'"

*Ve-hayiti lahem le-Elohim ve-hemmah yihyu-li le-am*—covenant.

"'The nations shall know that I am YHWH that sanctify Israel.'"

*Ve-yad'u ha-goyim ki ani YHWH meqaddesh et-Yisra'el*—nations know.

"'When my sanctuary shall be in the midst of them for ever.'"

*Bi-heyot miqdashi be-tokham le-olam*—sanctuary forever.

**Archetypal Layer:** Ezekiel 37 contains **the valley of dry bones vision (37:1-10)**—one of the Bible's most famous passages, **"Can these bones live?" (37:3)**, **"Come from the four winds, O breath" (37:9)**, **"These bones are the whole house of Israel" (37:11)**, **"Our bones are dried up, and our hope is lost" (37:11)**, **"I will open your graves" (37:12)**, **"I will put my spirit in you" (37:14)**, **the two sticks sign-act (37:15-22)**, **"One king shall be king to them all" (37:22)**, **"My servant David shall be king" (37:24)**, and **"I will set my sanctuary in the midst of them for ever" (37:26)**.

**Ethical Inversion Applied:**
- "The hand of YHWH was upon me"—vision
- "He carried me out in the spirit"—spirit carried
- "Set me down in the midst of the valley"—valley
- "It was full of bones"—full of bones
- "There were very many"—very many
- "They were very dry"—very dry
- "'Can these bones live?'"—question
- "'O Lord YHWH, you know'"—YHWH knows
- "'Prophesy over these bones'"—prophesy
- "'O you dry bones, hear the word of YHWH'"—hear
- "'I will cause breath to enter into you'"—breath enters
- "'You shall live'"—live
- "'I will lay sinews upon you'"—sinews
- "'Will bring up flesh upon you'"—flesh
- "'Cover you with skin'"—skin
- "'Put breath in you'"—breath
- "There was a noise, and behold a commotion"—noise
- "The bones came together, bone to its bone"—bones together
- "But there was no breath in them"—no breath yet
- "'Prophesy unto the breath'"—prophesy to breath
- "'Come from the four winds, O breath'"—four winds
- "'Breathe upon these slain, that they may live'"—breathe
- "The breath came into them, and they lived"—lived
- "Stood up upon their feet, an exceeding great host"—great host
- "'These bones are the whole house of Israel'"—all Israel
- "'Our bones are dried up'"—despair
- "'Our hope is lost'"—hope lost
- "'We are clean cut off'"—cut off
- "'I will open your graves'"—open graves
- "'Cause you to come up out of your graves'"—rise
- "'I will bring you into the land of Israel'"—to Israel
- "'I will put my spirit in you, and you shall live'"—spirit, live
- "'I will place you in your own land'"—in land
- "'Take one stick... For Judah'"—Judah's stick
- "'Take another stick... For Joseph'"—Joseph's stick
- "'Join them one to another into one stick'"—join
- "'They may become one in your hand'"—one
- "'I will take the children of Israel from among the nations'"—take
- "'Will gather them on every side'"—gather
- "'Bring them into their own land'"—to land
- "'I will make them one nation in the land'"—one nation
- "'One king shall be king to them all'"—one king
- "'They shall be no more two nations'"—not two
- "'Neither shall they be divided into two kingdoms'"—not divided
- "'Neither shall they defile themselves any more'"—no defile
- "'I will save them... will cleanse them'"—save, cleanse
- "'They shall be my people, and I will be their God'"—covenant
- "'My servant David shall be king over them'"—David king
- "'They all shall have one shepherd'"—one shepherd
- "'David my servant shall be their prince for ever'"—David forever
- "'I will make a covenant of peace with them'"—covenant of peace
- "'It shall be an everlasting covenant'"—everlasting
- "'Will set my sanctuary in the midst of them for ever'"—sanctuary forever
- "'My dwelling-place also shall be over them'"—dwelling
- "'The nations shall know that I am YHWH'"—nations know

**Modern Equivalent:** Ezekiel 37 is among the most famous chapters. The dry bones vision (37:1-14) speaks to national restoration from exile ("graves") and has been applied to resurrection. The two sticks (37:15-22) promise reunification of north and south. "My sanctuary in the midst of them for ever" (37:26) anticipates chapters 40-48.

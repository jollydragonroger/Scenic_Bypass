# Ezekiel 5: The Razor and the Hair

*From the Hebrew: וְאַתָּה בֶן־אָדָם (Ve-Attah Ben-Adam) — And You, Son of Man*

---

## The Sign of the Hair (5:1-4)

**5:1** "And you, son of man, take a sharp sword; as a barber's razor shall you take it unto you, and cause it to pass upon your head and upon your beard; then take balances to weigh, and divide the hair.

**5:2** "A third part shall you burn with fire in the midst of the city, when the days of the siege are fulfilled; and you shall take a third part, and smite it with the sword round about it; and a third part you shall scatter to the wind, and I will draw out a sword after them.

**5:3** "And you shall take thereof a few in number, and bind them in your skirts.

**5:4** "And of these again shall you take, and cast them into the midst of the fire, and burn them in the fire; from it shall a fire come forth into all the house of Israel."

---

## The Interpretation (5:5-17)

**5:5** Thus says the Lord YHWH: "This is Jerusalem; I have set her in the midst of the nations, and countries are round about her.

**5:6** "And she has rebelled against my ordinances in doing wickedness more than the nations, and against my statutes more than the countries that are round about her; for they have rejected my ordinances, and as for my statutes, they have not walked in them.

**5:7** "Therefore thus says the Lord YHWH: Because you have outdone the nations that are round about you, and have not walked in my statutes, neither have kept my ordinances, neither have done after the ordinances of the nations that are round about you;

**5:8** "Therefore thus says the Lord YHWH: Behold, I, even I, am against you; and I will execute judgments in the midst of you in the sight of the nations.

**5:9** "And I will do in you that which I have not done, and whereunto I will not do any more the like, because of all your abominations.

**5:10** "Therefore the fathers shall eat the sons in the midst of you, and the sons shall eat their fathers; and I will execute judgments on you; and the whole remnant of you will I scatter unto all the winds.

**5:11** "Wherefore, as I live," says the Lord YHWH, "surely, because you have defiled my sanctuary with all your detestable things, and with all your abominations, therefore will I also diminish you; neither shall my eye spare, and I also will have no pity.

**5:12** "A third part of you shall die with the pestilence, and with famine shall they be consumed in the midst of you; and a third part shall fall by the sword round about you; and a third part I will scatter unto all the winds, and will draw out a sword after them.

**5:13** "Thus shall my anger be accomplished, and I will satisfy my fury upon them, and I will be comforted; and they shall know that I YHWH have spoken in my zeal, when I have accomplished my fury upon them.

**5:14** "Moreover I will make you a desolation and a reproach among the nations that are round about you, in the sight of all that pass by.

**5:15** "So it shall be a reproach and a taunt, an instruction and an astonishment, unto the nations that are round about you, when I shall execute judgments on you in anger and in fury, and in furious rebukes; I YHWH have spoken it;

**5:16** "When I shall send upon them the evil arrows of famine, that are for destruction, which I will send to destroy you; and I will increase the famine upon you, and will break your staff of bread;

**5:17** "And I will send upon you famine and evil beasts, and they shall bereave you; and pestilence and blood shall pass through you; and I will bring the sword upon you; I YHWH have spoken it."

---

## Synthesis Notes

**Key Restorations:**

**Sign of the Hair (5:1-4):**
**The Key Verse (5:1):**
"'Take a sharp sword.'"

*Qach-lekha cherev chaddah*—sharp sword.

"'As a barber's razor shall you take it unto you.'"

*Ta'ar ha-gallabim tiqqachennah lakh*—barber's razor.

"'Cause it to pass upon your head and upon your beard.'"

*Ve-ha'avartah al-roshekha ve-al-zeqanekha*—shave head and beard.

"'Take balances to weigh, and divide the hair.'"

*Ve-laqachta lekha moznei mishqal ve-chilaqtam*—weigh and divide.

**Priestly Shame:**
For a priest, shaving the head and beard was deeply shameful (Leviticus 21:5).

**The Key Verse (5:2):**
"'A third part shall you burn with fire in the midst of the city.'"

*Shelishit ba-ur tav'ir be-tokh ha-ir*—burn 1/3.

"'When the days of the siege are fulfilled.'"

*Bi-melot yemei ha-matzor*—siege completed.

"'A third part... smite it with the sword round about it.'"

*Ve-laqachta et-ha-shelishit takkeh va-cherev sevivoteyha*—strike 1/3.

"'A third part you shall scatter to the wind.'"

*Ve-ha-shelishit tizreh la-ruach*—scatter 1/3.

"'I will draw out a sword after them.'"

*Ve-cherev ariq achareihem*—sword follows.

**The Key Verses (5:3-4):**
"'Take thereof a few in number.'"

*Ve-laqachta mi-sham me'at be-mispar*—take few.

"'Bind them in your skirts.'"

*Ve-tzarta otam bi-khenafekha*—bind in skirts.

"'Of these again shall you take, and cast them into the midst of the fire.'"

*U-me-hem od tiqqach ve-hishlakhta otam el-tokh ha-esh*—cast into fire.

"'From it shall a fire come forth into all the house of Israel.'"

*Mi-mmenah tetze esh el-kol-beit Yisra'el*—fire spreads.

**Interpretation (5:5-17):**
**The Key Verse (5:5):**
"'This is Jerusalem.'"

*Zot Yerushalayim*—this is Jerusalem.

"'I have set her in the midst of the nations.'"

*Be-tokh ha-goyim samtihah*—among nations.

"'Countries are round about her.'"

*U-sevivoteyha aratzot*—surrounded.

**The Key Verse (5:6):**
"'She has rebelled against my ordinances in doing wickedness more than the nations.'"

*Va-temmer et-mishpatai le-rish'ah min-ha-goyim*—rebelled more.

"'Against my statutes more than the countries that are round about her.'"

*Ve-et-chuqqotai min-ha-aratzot asher sevivoteyha*—more than neighbors.

"'They have rejected my ordinances.'"

*Ki ve-mishpatai ma'asu*—rejected.

"'As for my statutes, they have not walked in them.'"

*Ve-chuqqotai lo-halekhu vahem*—not walked.

**The Key Verse (5:7):**
"'You have outdone the nations that are round about you.'"

*Ya'an hamoneikhem min-ha-goyim asher sevivoteikem*—outdone nations.

"'Have not walked in my statutes.'"

*U-ve-chuqqotai lo halakhtem*—not walked.

"'Neither have kept my ordinances.'"

*U-mishpatai lo asitem*—not kept.

"'Neither have done after the ordinances of the nations.'"

*Ve-khe-mishpetei ha-goyim asher sevivoteikem lo asitem*—not even like nations.

**Worse Than Neighbors:**
Jerusalem failed both divine law and even pagan standards.

**The Key Verse (5:8):**
"'Behold, I, even I, am against you.'"

*Hineni alayikh gam-ani*—I am against you.

"'I will execute judgments in the midst of you in the sight of the nations.'"

*Ve-asiti vakh mishpatim le-einei ha-goyim*—judgments before nations.

**The Key Verse (5:9):**
"'I will do in you that which I have not done.'"

*Ve-asiti vakh et asher lo-asiti*—unprecedented.

"'Whereunto I will not do any more the like.'"

*Ve-et asher-lo-e'eseh khamohu od*—never again.

"'Because of all your abominations.'"

*Ya'an kol-to'avotayikh*—abominations.

**The Key Verse (5:10):**
"'The fathers shall eat the sons in the midst of you.'"

*Lakhen avot yokhelu vanim be-tokhekh*—cannibalism.

"'The sons shall eat their fathers.'"

*U-vanim yokhelu avotam*—sons eat fathers.

"'I will execute judgments on you.'"

*Ve-asiti vakh shefatim*—judgments.

"'The whole remnant of you will I scatter unto all the winds.'"

*Ve-zereiti et-kol-she'eritkekh le-khol-ruach*—scatter.

**The Key Verse (5:11):**
"''Wherefore, as I live,' says the Lord YHWH."

*Lakhen chai-ani ne'um Adonai YHWH*—as I live.

"'Because you have defiled my sanctuary with all your detestable things.'"

*Im-lo ya'an et-miqdashi timme'it be-khol-shiqqotzayikh*—defiled sanctuary.

"'With all your abominations.'"

*U-ve-khol-to'avotayikh*—abominations.

"'I also will diminish you.'"

*Ve-gam-ani egra*—diminish.

"'Neither shall my eye spare.'"

*Ve-lo-tachos eini*—no sparing.

"'I also will have no pity.'"

*Ve-gam-ani lo echmol*—no pity.

**The Key Verse (5:12):**
"'A third part of you shall die with the pestilence.'"

*Shelishitekh ba-dever yamutuu*—1/3 pestilence.

"'With famine shall they be consumed in the midst of you.'"

*U-va-ra'av yikhlu ve-tokhekh*—famine.

"'A third part shall fall by the sword round about you.'"

*Ve-ha-shelishit ba-cherev yippelu sevivotayikh*—1/3 sword.

"'A third part I will scatter unto all the winds.'"

*Ve-ha-shelishit le-khol-ruach ezreh*—1/3 scattered.

"'Will draw out a sword after them.'"

*Ve-cherev ariq achareihem*—sword follows.

**The Key Verse (5:13):**
"'My anger be accomplished.'"

*Ve-khalah appi*—anger accomplished.

"'I will satisfy my fury upon them.'"

*Va-hanichoti chamati vam*—fury satisfied.

"'I will be comforted.'"

*Ve-hinnechchamti*—comforted.

"'They shall know that I YHWH have spoken in my zeal.'"

*Ve-yad'u ki-ani YHWH dibbarti be-qin'ati*—spoken in zeal.

"'When I have accomplished my fury upon them.'"

*Be-khalloti chamati vam*—fury accomplished.

**The Key Verses (5:14-15):**
"'I will make you a desolation and a reproach among the nations.'"

*Ve-ettnekh le-chorvah u-le-cherpah ba-goyim*—desolation, reproach.

"'In the sight of all that pass by.'"

*Le-einei kol-over*—to passers.

"'A reproach and a taunt.'"

*Ve-hayetah cherpah u-gedufah*—reproach, taunt.

"'An instruction and an astonishment.'"

*Musar u-meshammah*—instruction, astonishment.

"'When I shall execute judgments on you.'"

*Ba-asoti vakh shefatim*—judgments.

"'In anger and in fury, and in furious rebukes.'"

*Be-af u-ve-chemah u-ve-tokhechotvchemah*—angry rebukes.

"'I YHWH have spoken it.'"

*Ani YHWH dibbarti*—YHWH spoken.

**The Key Verses (5:16-17):**
"'The evil arrows of famine.'"

*Chitztzei ha-ra'av ha-ra'im*—famine arrows.

"'That are for destruction.'"

*Asher hayu le-mashchit*—destructive.

"'I will increase the famine upon you.'"

*Ve-ra'av osif aleikhem*—increase famine.

"'Will break your staff of bread.'"

*Ve-shavarti lakhem matteh lachem*—break bread-staff.

"'I will send upon you famine and evil beasts.'"

*Ve-shilachti aleikhem ra'av ve-chayyah ra'ah*—famine, beasts.

"'They shall bereave you.'"

*Ve-shikkelukh*—bereave.

"'Pestilence and blood shall pass through you.'"

*Ve-dever ve-dam ya'avor-bakh*—pestilence, blood.

"'I will bring the sword upon you.'"

*Ve-cherev avi alayikh*—sword.

"'I YHWH have spoken it.'"

*Ani YHWH dibbarti*—YHWH spoken.

**Archetypal Layer:** Ezekiel 5 contains **the hair divided into thirds (5:1-2)**, **the interpretation: pestilence/famine, sword, scattering (5:12)**, **"I, even I, am against you" (5:8)**, **"I will do in you that which I have not done" (5:9)**, and **cannibalism prophecy (5:10)**.

**Ethical Inversion Applied:**
- "'Take a sharp sword'"—sharp sword
- "'As a barber's razor'"—razor
- "'Cause it to pass upon your head and upon your beard'"—shave
- "'Take balances to weigh, and divide the hair'"—weigh, divide
- "'A third part shall you burn with fire'"—burn 1/3
- "'A third part... smite it with the sword'"—sword 1/3
- "'A third part you shall scatter to the wind'"—scatter 1/3
- "'I will draw out a sword after them'"—sword follows
- "'Take thereof a few in number'"—few
- "'Bind them in your skirts'"—bind
- "'Cast them into the midst of the fire'"—cast into fire
- "'From it shall a fire come forth'"—fire spreads
- "'This is Jerusalem'"—Jerusalem
- "'I have set her in the midst of the nations'"—among nations
- "'She has rebelled... more than the nations'"—rebelled more
- "'They have rejected my ordinances'"—rejected
- "'You have outdone the nations'"—outdone
- "'Neither have done after the ordinances of the nations'"—worse than pagans
- "'I, even I, am against you'"—against you
- "'I will execute judgments in the midst of you'"—judgments
- "'I will do in you that which I have not done'"—unprecedented
- "'Whereunto I will not do any more the like'"—never again
- "'The fathers shall eat the sons... the sons shall eat their fathers'"—cannibalism
- "'The whole remnant of you will I scatter'"—scatter
- "'As I live,' says the Lord YHWH"—oath
- "'You have defiled my sanctuary'"—defiled
- "'I also will diminish you'"—diminish
- "'Neither shall my eye spare'"—no sparing
- "'A third part of you shall die with the pestilence'"—pestilence
- "'A third part shall fall by the sword'"—sword
- "'A third part I will scatter'"—scatter
- "'My anger be accomplished'"—anger complete
- "'They shall know that I YHWH have spoken in my zeal'"—zeal
- "'I will make you a desolation and a reproach'"—desolation
- "'The evil arrows of famine'"—famine arrows
- "'I will send upon you famine and evil beasts'"—famine, beasts
- "'Pestilence and blood shall pass through you'"—pestilence, blood
- "'I will bring the sword upon you'"—sword

**Modern Equivalent:** Ezekiel 5 interprets the hair sign-act. The three portions represent plague/famine (burn), sword (strike), exile (scatter). Even the few bound in skirts face fire. "I have not done... will not do any more the like" (5:9) shows the judgment's uniqueness.

# Ezekiel 40: The Vision of the New Temple — The Gates

*From the Hebrew: בְּעֶשְׂרִים וְחָמֵשׁ שָׁנָה (Be-Esrim Ve-Chamesh Shanah) — In the Twenty-Fifth Year*

---

## Introduction to the Vision (40:1-4)

**40:1** In the five and twentieth year of our captivity, in the beginning of the year, in the tenth day of the month, in the fourteenth year after that the city was smitten, in the selfsame day, the hand of YHWH was upon me, and he brought me thither.

**40:2** In the visions of God brought he me into the land of Israel, and set me down upon a very high mountain, whereon was as it were the frame of a city on the south.

**40:3** And he brought me thither, and, behold, there was a man, whose appearance was like the appearance of brass, with a line of flax in his hand, and a measuring reed; and he stood in the gate.

**40:4** And the man said unto me: "Son of man, behold with your eyes, and hear with your ears, and set your heart upon all that I shall show you; for to the intent that I might show them unto you are you brought here; declare all that you see to the house of Israel."

---

## The Outer East Gate (40:5-16)

**40:5** And behold a wall on the outside of the house round about, and in the man's hand a measuring reed of six cubits long, of a cubit and a hand-breadth each; so he measured the breadth of the building, one reed, and the height, one reed.

**40:6** Then came he unto the gate which looks toward the east, and went up the steps thereof; and he measured the threshold of the gate, one reed broad; and the other threshold, one reed broad.

**40:7** And every cell was one reed long, and one reed broad; and the space between the cells was five cubits; and the threshold of the gate by the porch of the gate within was one reed.

**40:8** He measured also the porch of the gate within, one reed.

**40:9** Then measured he the porch of the gate, eight cubits; and the posts thereof, two cubits; and the porch of the gate was inward.

**40:10** And the cells of the gate eastward were three on this side, and three on that side; they three were of one measure; and the posts had one measure on this side and on that side.

**40:11** And he measured the breadth of the entry of the gate, ten cubits; and the length of the gate, thirteen cubits;

**40:12** And a border before the cells, one cubit on this side, and a border, one cubit on that side; and the cells, six cubits on this side, and six cubits on that side.

**40:13** And he measured the gate from the roof of the one cell to the roof of the other, a breadth of five and twenty cubits; door against door.

**40:14** He made also posts of threescore cubits; even unto the post of the court round about the gate.

**40:15** And from the forefront of the gate of the entrance unto the forefront of the inner porch of the gate were fifty cubits.

**40:16** And there were narrow windows to the cells and to their posts within the gate round about, and likewise to the arches; and windows were round about inward; and upon each post were palm-trees.

---

## The Outer Court (40:17-19)

**40:17** Then brought he me into the outer court, and, lo, there were chambers and a pavement, made for the court round about; thirty chambers were upon the pavement.

**40:18** And the pavement was by the side of the gates, corresponding unto the length of the gates, even the lower pavement.

**40:19** Then he measured the breadth from the forefront of the lower gate unto the forefront of the inner court without, a hundred cubits, eastward as also northward.

---

## The Outer North Gate (40:20-23)

**40:20** And the gate of the outer court that looked toward the north, he measured the length thereof and the breadth thereof.

**40:21** And the cells thereof were three on this side and three on that side; and the posts thereof and the arches thereof were after the measure of the first gate; the length thereof was fifty cubits, and the breadth five and twenty cubits.

**40:22** And the windows thereof, and the arches thereof, and the palm-trees thereof, were after the measure of the gate that looks toward the east; and they went up unto it by seven steps; and the arches thereof were before them.

**40:23** And there was a gate to the inner court over against the other gate, northward as also eastward; and he measured from gate to gate a hundred cubits.

---

## The Outer South Gate (40:24-27)

**40:24** And he led me toward the south, and behold a gate toward the south; and he measured the posts thereof and the arches thereof according to these measures.

**40:25** And there were windows in it and in the arches thereof round about, like those windows; the length was fifty cubits, and the breadth five and twenty cubits.

**40:26** And there were seven steps to go up to it, and the arches thereof were before them; and it had palm-trees, one on this side, and another on that side, upon the posts thereof.

**40:27** And there was a gate to the inner court toward the south; and he measured from gate to gate toward the south a hundred cubits.

---

## The Inner South Gate (40:28-31)

**40:28** Then he brought me to the inner court by the south gate; and he measured the south gate according to these measures;

**40:29** And the cells thereof, and the posts thereof, and the arches thereof, according to these measures; and there were windows in it and in the arches thereof round about; it was fifty cubits long, and five and twenty cubits broad.

**40:30** And there were arches round about, five and twenty cubits long, and five cubits broad.

**40:31** And the arches thereof were toward the outer court; and palm-trees were upon the posts thereof; and the going up to it had eight steps.

---

## The Inner East Gate (40:32-34)

**40:32** And he brought me into the inner court toward the east; and he measured the gate according to these measures;

**40:33** And the cells thereof, and the posts thereof, and the arches thereof, according to these measures; and there were windows therein and in the arches thereof round about; it was fifty cubits long, and five and twenty cubits broad.

**40:34** And the arches thereof were toward the outer court; and palm-trees were upon the posts thereof, on this side, and on that side; and the going up to it had eight steps.

---

## The Inner North Gate (40:35-37)

**40:35** And he brought me to the north gate; and he measured it according to these measures;

**40:36** The cells thereof, the posts thereof, and the arches thereof; and there were windows therein round about; the length was fifty cubits, and the breadth five and twenty cubits.

**40:37** And the posts thereof were toward the outer court; and palm-trees were upon the posts thereof, on this side, and on that side; and the going up to it had eight steps.

---

## Tables for Sacrifices (40:38-43)

**40:38** And a chamber with the entry thereof was by the posts at the gates; there they washed the burnt-offering.

**40:39** And in the porch of the gate were two tables on this side, and two tables on that side, to slay thereon the burnt-offering and the sin-offering and the guilt-offering.

**40:40** And on the one side without, as one goes up to the entry of the gate toward the north, were two tables; and on the other side of the porch of the gate were two tables.

**40:41** Four tables were on this side, and four tables on that side, by the side of the gate; eight tables, whereupon to slay the sacrifices.

**40:42** Moreover there were four tables for the burnt-offering, of hewn stone, a cubit and a half long, and a cubit and a half broad, and one cubit high; whereupon to lay the instruments wherewith the burnt-offering and the sacrifice were slain.

**40:43** And the hooks, a hand-breadth long, were fastened within round about; and upon the tables was the flesh of the offering.

---

## Chambers for the Priests (40:44-47)

**40:44** And without the inner gate were chambers for the singers in the inner court, which was at the side of the north gate; and their prospect was toward the south; one at the side of the east gate having the prospect toward the north.

**40:45** And he said unto me: "This chamber, whose prospect is toward the south, is for the priests, the keepers of the charge of the house;

**40:46** "And the chamber whose prospect is toward the north is for the priests, the keepers of the charge of the altar; these are the sons of Zadok, who from among the sons of Levi come near to YHWH to minister unto him."

**40:47** And he measured the court, a hundred cubits long, and a hundred cubits broad, foursquare; and the altar was before the house.

---

## The Porch of the Temple (40:48-49)

**40:48** Then he brought me to the porch of the house, and measured each post of the porch, five cubits on this side, and five cubits on that side; and the breadth of the gate was three cubits on this side, and three cubits on that side.

**40:49** The length of the porch was twenty cubits, and the breadth eleven cubits; and it was by steps that it was ascended; and there were pillars by the posts, one on this side, and another on that side.

---

## Synthesis Notes

**Key Restorations:**

**Introduction to the Vision (40:1-4):**
**The Key Verse (40:1):**
"In the five and twentieth year of our captivity."

*Be-esrim ve-chamesh shanah le-galutenu*—573 BCE.

"In the beginning of the year, in the tenth day of the month."

*Be-rosh ha-shanah be-asor la-chodesh*—new year, 10th day.

"In the fourteenth year after that the city was smitten."

*Be-arba esreh shanah achar asher hukketah ha-ir*—14 years after fall.

"The hand of YHWH was upon me, and he brought me thither."

*Hayetah alai yad-YHWH va-yave oti shamah*—hand upon.

**The Key Verse (40:2):**
"In the visions of God brought he me into the land of Israel."

*Be-mar'ot Elohim hevi'ani el-eretz Yisra'el*—visions of God.

"Set me down upon a very high mountain."

*Va-yenicheni al-har gavoha me'od*—very high mountain.

"Whereon was as it were the frame of a city on the south."

*Ve-alav ke-mivneh-ir mi-negev*—city frame.

**The Key Verses (40:3-4):**
"There was a man, whose appearance was like the appearance of brass."

*Ve-hinneh-ish mar'ehu ke-mar'eh nechoshet*—bronze appearance.

"With a line of flax in his hand, and a measuring reed."

*U-fetil-pishtim be-yado u-qeneh ha-middah*—measuring tools.

"He stood in the gate."

*Ve-hu omed ba-sha'ar*—in gate.

"'Behold with your eyes, and hear with your ears.'"

*Re'eh ve-einekha u-ve-oznekha shema*—see, hear.

"'Set your heart upon all that I shall show you.'"

*Ve-sim libbeka le-khol asher ani mar'eh otakh*—set heart.

"'Declare all that you see to the house of Israel.'"

*Ve-hagged le-veit Yisra'el et kol-asher attah ro'eh*—declare.

**Temple Vision:**
This begins the detailed temple vision (40-48), a new temple for a restored Israel.

**Measurements:**
**The Key Verse (40:5):**
"A measuring reed of six cubits long, of a cubit and a hand-breadth each."

*Qeneh-middah shesh ammot ba-ammah va-tefach*—long cubit (about 21 inches).

**Gates and Courts:**
The chapter details:
- **Outer east gate (40:6-16)**
- **Outer court with 30 chambers (40:17-19)**
- **Outer north gate (40:20-23)**
- **Outer south gate (40:24-27)**
- **Inner south gate (40:28-31)**
- **Inner east gate (40:32-34)**
- **Inner north gate (40:35-37)**
- **Tables for sacrifices (40:38-43)**
- **Priests' chambers (40:44-47)**
- **Temple porch (40:48-49)**

**The Key Verse (40:46):**
"'The chamber... is for the priests, the keepers of the charge of the altar.'"

*Ve-ha-lishkah... la-kohanim shomerei mishmeret ha-mizbe'ach*—priests.

"'These are the sons of Zadok.'"

*Hemmah benei-Tzadoq*—sons of Zadok.

"'Who from among the sons of Levi come near to YHWH to minister unto him.'"

*Ha-qerevim mi-benei Levi el-YHWH le-sharetto*—minister.

**Zadokite Priesthood:**
Ezekiel's temple reserves altar service for Zadokite priests.

**Archetypal Layer:** Ezekiel 40 begins the **temple vision (40-48)**, containing **the date "25th year... 14th year after the city was smitten" (40:1)** = 573 BCE, **"a very high mountain" (40:2)**, **the bronze man with measuring tools (40:3)**, **"Behold with your eyes, and hear with your ears, and set your heart" (40:4)**, **detailed measurements of gates and courts**, and **"the sons of Zadok" (40:46)**.

**Ethical Inversion Applied:**
- "In the five and twentieth year of our captivity"—573 BCE
- "In the fourteenth year after that the city was smitten"—14 years after
- "The hand of YHWH was upon me"—hand upon
- "In the visions of God brought he me into the land of Israel"—visions
- "Set me down upon a very high mountain"—high mountain
- "As it were the frame of a city"—city frame
- "There was a man, whose appearance was like... brass"—bronze man
- "With a line of flax in his hand, and a measuring reed"—measuring tools
- "'Behold with your eyes, and hear with your ears'"—see, hear
- "'Set your heart upon all that I shall show you'"—set heart
- "'Declare all that you see to the house of Israel'"—declare
- "A measuring reed of six cubits long"—long cubit
- "He measured the threshold of the gate, one reed"—measurements
- "Every cell was one reed long, and one reed broad"—cells
- "The cells of the gate eastward were three on this side, and three on that"—symmetry
- "Windows were round about inward"—windows
- "Upon each post were palm-trees"—palm decoration
- "Thirty chambers were upon the pavement"—30 chambers
- "The gate... toward the north"—north gate
- "The gate toward the south"—south gate
- "The inner court by the south gate"—inner court
- "The inner court toward the east"—inner east
- "The north gate"—north gate
- "There they washed the burnt-offering"—wash offering
- "Two tables on this side, and two tables on that side"—tables
- "Eight tables, whereupon to slay the sacrifices"—eight tables
- "Four tables for the burnt-offering, of hewn stone"—stone tables
- "Chambers for the singers"—singers' chambers
- "For the priests, the keepers of the charge of the house"—priests
- "For the priests, the keepers of the charge of the altar"—altar keepers
- "'These are the sons of Zadok'"—Zadokites
- "'Who... come near to YHWH to minister unto him'"—minister
- "He measured the court, a hundred cubits long"—square court
- "The altar was before the house"—altar
- "He brought me to the porch of the house"—porch
- "There were pillars by the posts"—pillars

**Modern Equivalent:** Ezekiel 40 begins the detailed temple vision (40-48). The date (573 BCE) is 25 years into exile. The bronze man with measuring tools systematically records every dimension. This is not Solomon's temple but a new, idealized sanctuary. Zadokite priests have exclusive altar access.

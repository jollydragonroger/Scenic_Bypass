# Ezekiel 39: The Defeat of Gog

*From the Hebrew: וְאַתָּה בֶן־אָדָם הִנָּבֵא עַל־גּוֹג (Ve-Attah Ven-Adam Hinnave Al-Gog) — And You, Son of Man, Prophesy Against Gog*

---

## Gog's Defeat (39:1-8)

**39:1** "And you, son of man, prophesy against Gog, and say: Thus says the Lord YHWH: Behold, I am against you, O Gog, chief prince of Meshech and Tubal;

**39:2** "And I will turn you about and lead you on, and will cause you to come up from the uttermost parts of the north; and I will bring you upon the mountains of Israel;

**39:3** "And I will smite your bow out of your left hand, and will cause your arrows to fall out of your right hand.

**39:4** "You shall fall upon the mountains of Israel, you, and all your bands, and the peoples that are with you; I will give you unto the ravenous birds of every sort, and to the beasts of the field, to be devoured.

**39:5** "You shall fall upon the open field; for I have spoken it," says the Lord YHWH.

**39:6** "And I will send a fire on Magog, and on them that dwell securely in the isles; and they shall know that I am YHWH.

**39:7** "And my holy name will I make known in the midst of my people Israel; neither will I suffer my holy name to be profaned any more; and the nations shall know that I am YHWH, the Holy One in Israel.

**39:8** "Behold, it comes, and it shall be done," says the Lord YHWH; "this is the day whereof I have spoken."

---

## The Burial of Gog (39:9-16)

**39:9** "And they that dwell in the cities of Israel shall go forth, and shall make fires of the weapons and use them as fuel, both the shields and the bucklers, the bows and the arrows, and the handstaves, and the spears, and they shall make fires of them seven years;

**39:10** "So that they shall take no wood out of the field, neither cut down any out of the forests, for they shall make fires of the weapons; and they shall spoil those that spoiled them, and rob those that robbed them," says the Lord YHWH.

**39:11** "And it shall come to pass in that day, that I will give unto Gog a place fit for burial in Israel, the valley of them that pass through on the east of the sea; and it shall stop them that pass through; and there shall they bury Gog and all his multitude; and they shall call it: The valley of Hamon-gog.

**39:12** "And seven months shall the house of Israel be burying them, that they may cleanse the land.

**39:13** "Yea, all the people of the land shall bury them, and it shall be to them a renown; in the day that I shall be glorified," says the Lord YHWH.

**39:14** "And they shall set apart men of continual employment, that shall pass through the land to bury with them that pass through those that remain upon the face of the land, to cleanse it; after the end of seven months shall they search.

**39:15** "And when they that pass through shall pass through the land, and any sees a man's bone, then shall he set up a sign by it, till the buriers have buried it in the valley of Hamon-gog.

**39:16** "And Hamonah shall also be the name of a city. Thus shall they cleanse the land."

---

## The Sacrificial Feast (39:17-24)

**39:17** "And you, son of man, thus says the Lord YHWH: Speak unto the birds of every sort, and to every beast of the field: Assemble yourselves, and come; gather yourselves on every side to my sacrifice that I do sacrifice for you, even a great sacrifice upon the mountains of Israel, that you may eat flesh and drink blood.

**39:18** "The flesh of the mighty shall you eat, and the blood of the princes of the earth shall you drink; rams, lambs, and goats, bullocks, all of them fatlings of Bashan.

**39:19** "And you shall eat fat till you be full, and drink blood till you be drunken, of my sacrifice which I have sacrificed for you.

**39:20** "And you shall be filled at my table with horses and horsemen, with mighty men, and with all men of war," says the Lord YHWH.

**39:21** "And I will set my glory among the nations, and all the nations shall see my judgment that I have executed, and my hand that I have laid upon them.

**39:22** "So the house of Israel shall know that I am YHWH their God, from that day and forward.

**39:23** "And the nations shall know that the house of Israel went into captivity for their iniquity, because they broke faith with me, and I hid my face from them; so I gave them into the hand of their adversaries, and they fell all of them by the sword.

**39:24** "According to their uncleanness and according to their transgressions did I unto them; and I hid my face from them."

---

## Israel's Restoration (39:25-29)

**39:25** Therefore thus says the Lord YHWH: "Now will I bring back the captivity of Jacob, and have compassion upon the whole house of Israel; and I will be jealous for my holy name.

**39:26** "And they shall bear their shame, and all their treachery whereby they have acted treacherously against me, when they shall dwell safely in their land, and none shall make them afraid;

**39:27** "When I have brought them back from the peoples, and gathered them out of their enemies' lands, and am sanctified in them in the sight of many nations.

**39:28** "And they shall know that I am YHWH their God, in that I caused them to go into captivity among the nations, and have gathered them unto their own land; and I will leave none of them any more there;

**39:29** "Neither will I hide my face any more from them; for I have poured out my spirit upon the house of Israel," says the Lord YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Gog's Defeat (39:1-8):**
**The Key Verses (39:1-2):**
"'Prophesy against Gog.'"

*Hinnave al-Gog*—prophesy against.

"'Thus says the Lord YHWH: Behold, I am against you, O Gog.'"

*Koh amar Adonai YHWH hineni elekha Gog*—against Gog.

"'Chief prince of Meshech and Tubal.'"

*Nesi rosh Meshekh ve-Tuval*—chief prince.

"'I will turn you about and lead you on.'"

*Ve-shov'vatikha ve-shishetikha*—turn, lead.

"'Will cause you to come up from the uttermost parts of the north.'"

*Ve-ha'alitikha mi-yarketei tzafon*—from far north.

"'I will bring you upon the mountains of Israel.'"

*Va-havi'otikha al-harei Yisra'el*—upon mountains.

**The Key Verses (39:3-5):**
"'I will smite your bow out of your left hand.'"

*Ve-hikkeiti qashtekha mi-yad semoלekha*—smite bow.

"'Will cause your arrows to fall out of your right hand.'"

*Ve-chitztzekha mi-yad yeminekha appil*—arrows fall.

"'You shall fall upon the mountains of Israel.'"

*Al-harei Yisra'el tippol*—fall.

"'You, and all your bands, and the peoples that are with you.'"

*Attah ve-khol-agappekha ve-ammim asher ittakh*—all bands.

"'I will give you unto the ravenous birds of every sort.'"

*Le-tzippor kol-kanaf... netattikha le-okhlah*—birds devour.

"'And to the beasts of the field, to be devoured.'"

*U-le-chayyat ha-sadeh*—beasts.

"'You shall fall upon the open field.'"

*Al-penei ha-sadeh tippol*—fall in field.

**The Key Verses (39:6-8):**
"'I will send a fire on Magog.'"

*Ve-shillachti-esh be-Magog*—fire on Magog.

"'And on them that dwell securely in the isles.'"

*U-ve-yoshevei ha-iyyim la-vetach*—in isles.

"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—recognition.

"'My holy name will I make known in the midst of my people Israel.'"

*Ve-et-shem qodshi odia be-tokh ammi Yisra'el*—name known.

"'Neither will I suffer my holy name to be profaned any more.'"

*Ve-lo-achallel et-shem qodshi od*—not profaned.

"'The nations shall know that I am YHWH, the Holy One in Israel.'"

*Ve-yad'u ha-goyim ki ani YHWH qadosh be-Yisra'el*—Holy One.

"'Behold, it comes, and it shall be done.'"

*Hinneh ba'ah ve-nihyatah*—it comes.

"'This is the day whereof I have spoken.'"

*Hu ha-yom asher dibbarti*—the day.

**Burial of Gog (39:9-16):**
**The Key Verses (39:9-10):**
"'They that dwell in the cities of Israel shall go forth.'"

*Ve-yatze'u yoshevei arei Yisra'el*—go forth.

"'Shall make fires of the weapons and use them as fuel.'"

*U-vi'aru ve-hissiqu be-nesheq*—burn weapons.

"'The shields and the bucklers, the bows and the arrows.'"

*U-magen u-tzinnah qeshet va-chitztzim*—weapons.

"'The handstaves, and the spears.'"

*U-maqqel yad va-romach*—staves, spears.

"'They shall make fires of them seven years.'"

*U-vi'aru vahem esh sheva shanim*—seven years.

"'They shall take no wood out of the field.'"

*Ve-lo-yis'u etzim min-ha-sadeh*—no wood needed.

"'They shall spoil those that spoiled them.'"

*Ve-shalelu et-sholeleihem*—spoil spoilers.

"'Rob those that robbed them.'"

*U-vazzu et-bozezeihem*—rob robbers.

**The Key Verses (39:11-13):**
"'I will give unto Gog a place fit for burial in Israel.'"

*Etten le-Gog meqom-sham qever be-Yisra'el*—burial place.

"'The valley of them that pass through on the east of the sea.'"

*Gei ha-overim qidmat ha-yam*—valley east of sea.

"'It shall stop them that pass through.'"

*Ve-choeset hi et-ha-overim*—stops passersby.

"'There shall they bury Gog and all his multitude.'"

*Ve-qaveru sham et-Gog ve-et-kol-hamono*—bury Gog.

"'They shall call it: The valley of Hamon-gog.'"

*Ve-qar'u lah gei Hamon-Gog*—Hamon-gog (Gog's multitude).

"'Seven months shall the house of Israel be burying them.'"

*U-qevaruhem beit Yisra'el shiv'ah chodashim*—seven months.

"'That they may cleanse the land.'"

*Lema'an taher et-ha-aretz*—cleanse land.

"'All the people of the land shall bury them.'"

*Ve-qaveru kol-am ha-aretz*—all people bury.

"'It shall be to them a renown.'"

*Ve-hayah lahem le-shem*—renown.

"'In the day that I shall be glorified.'"

*Yom hikkavedi*—glorified day.

**The Key Verses (39:14-16):**
"'They shall set apart men of continual employment.'"

*Ve-anshei tamid yavdilu*—set apart men.

"'That shall pass through the land to bury.'"

*Overim ba-aretz meqabberim*—pass through, bury.

"'Those that remain upon the face of the land.'"

*Et-ha-overim et-ha-notarim al-penei ha-aretz*—remaining.

"'To cleanse it.'"

*Le-taharah*—cleanse.

"'After the end of seven months shall they search.'"

*Mi-qetz shiv'ah chodashim yachqoru*—search.

"'When they that pass through shall pass through the land.'"

*Ve-averu ha-overim ba-aretz*—pass through.

"'Any sees a man's bone, then shall he set up a sign by it.'"

*Ve-ra'ah etzem adam u-vanah etzlo tziyyun*—mark bones.

"'Till the buriers have buried it in the valley of Hamon-gog.'"

*Ad-qaveru oto ha-meqabberim el-gei Hamon-Gog*—bury.

"'Hamonah shall also be the name of a city.'"

*Ve-gam shem-ir Hamonah*—city named.

"'Thus shall they cleanse the land.'"

*Ve-tiharu ha-aretz*—cleanse.

**Sacrificial Feast (39:17-24):**
**The Key Verses (39:17-20):**
"'Speak unto the birds of every sort, and to every beast of the field.'"

*Emor le-tzippor kol-kanaf u-le-khol chayyat ha-sadeh*—to birds, beasts.

"'Assemble yourselves, and come.'"

*Hiqqabetzu u-vo'u*—assemble.

"'Gather yourselves on every side to my sacrifice.'"

*He'asefu mi-saviv al-zivchi*—gather for sacrifice.

"'That I do sacrifice for you.'"

*Asher ani zoveach lakhem*—I sacrifice.

"'A great sacrifice upon the mountains of Israel.'"

*Zevach gadol al-harei Yisra'el*—great sacrifice.

"'That you may eat flesh and drink blood.'"

*Va-akhaltem basar u-shetitem dam*—eat, drink.

"'The flesh of the mighty shall you eat.'"

*Besar gibborim tokhelu*—mighty's flesh.

"'The blood of the princes of the earth shall you drink.'"

*Ve-dam nesi'ei ha-aretz tishtו*—princes' blood.

"'Rams, lambs, and goats, bullocks.'"

*Eilim karim ve-attudim parim*—animals.

"'All of them fatlings of Bashan.'"

*Meri'ei Vashan kullam*—Bashan fatlings.

"'You shall eat fat till you be full.'"

*Va-akhaltem-chelev le-sovah*—eat fat.

"'Drink blood till you be drunken.'"

*U-shetitem dam le-shikkaron*—drink blood.

"'Of my sacrifice which I have sacrificed for you.'"

*Mi-zivchi asher-zavachti lakhem*—my sacrifice.

"'You shall be filled at my table with horses and horsemen.'"

*U-seva'tem al-shulchani sus ve-rekhev*—filled at table.

"'With mighty men, and with all men of war.'"

*Gibbor ve-khol-ish milchamah*—warriors.

**The Key Verses (39:21-24):**
"'I will set my glory among the nations.'"

*Ve-natatti et-kevodi ba-goyim*—glory among nations.

"'All the nations shall see my judgment that I have executed.'"

*Ve-ra'u khol-ha-goyim et-mishpati asher asiti*—see judgment.

"'And my hand that I have laid upon them.'"

*Ve-et-yadi asher-samti vahem*—my hand.

"'The house of Israel shall know that I am YHWH their God, from that day and forward.'"

*Ve-yad'u beit Yisra'el ki ani YHWH Eloheihem min-ha-yom ha-hu va-hal'ah*—know from that day.

"'The nations shall know that the house of Israel went into captivity for their iniquity.'"

*Ve-yad'u ha-goyim ki ba-avonam galו beit-Yisra'el*—for iniquity.

"'Because they broke faith with me.'"

*Al asher-ma'alu vi*—broke faith.

"'I hid my face from them.'"

*Va-aster panai me-hem*—hid face.

"'I gave them into the hand of their adversaries.'"

*Va-ettenem be-yad tzareihem*—to adversaries.

"'They fell all of them by the sword.'"

*Va-yippelu va-cherev kullam*—fell by sword.

"'According to their uncleanness and according to their transgressions did I unto them.'"

*Ke-tum'atam u-khe-fish'eihem asiti otam*—according to sins.

**Israel's Restoration (39:25-29):**
**The Key Verses (39:25-27):**
"'Now will I bring back the captivity of Jacob.'"

*Attah ashiv et-shevut Ya'aqov*—bring back.

"'Have compassion upon the whole house of Israel.'"

*Ve-richamti kol-beit Yisra'el*—compassion.

"'I will be jealous for my holy name.'"

*Ve-qinne'ti le-shem qodshi*—jealous for name.

"'They shall bear their shame.'"

*Ve-nas'u et-kelimmatam*—bear shame.

"'And all their treachery whereby they have acted treacherously against me.'"

*Ve-et-kol-ma'alam asher ma'alu vi*—treachery.

"'When they shall dwell safely in their land.'"

*Be-shivtam al-admatam la-vetach*—dwell safely.

"'None shall make them afraid.'"

*Ve-ein macharid*—none afraid.

"'When I have brought them back from the peoples.'"

*Be-shovi otam min-ha-ammim*—bring back.

"'Gathered them out of their enemies' lands.'"

*Ve-qibbaתzti otam me-artzot oyeveihem*—gather.

"'Am sanctified in them in the sight of many nations.'"

*Ve-niqdashti vam le-einei ha-goyim rabbim*—sanctified.

**The Key Verses (39:28-29):**
"'They shall know that I am YHWH their God.'"

*Ve-yad'u ki ani YHWH Eloheihem*—recognition.

"'In that I caused them to go into captivity among the nations.'"

*Be-hagloti otam el-ha-goyim*—exile.

"'And have gathered them unto their own land.'"

*Ve-kinnasti otam al-admatam*—gathered.

"'I will leave none of them any more there.'"

*Ve-lo-otir od me-hem sham*—none left.

"'Neither will I hide my face any more from them.'"

*Ve-lo-aster od panai me-hem*—not hide face.

"'For I have poured out my spirit upon the house of Israel.'"

*Asher shafakhti et-ruchi al-beit Yisra'el*—spirit poured.

**Archetypal Layer:** Ezekiel 39 concludes the **Gog prophecy (38-39)**, containing **"I will smite your bow out of your left hand" (39:3)**, **"You shall fall upon the mountains of Israel" (39:4)**, **"I will send a fire on Magog" (39:6)**, **"My holy name will I make known" (39:7)**, **weapons burned for seven years (39:9-10)**, **burial in the valley of Hamon-gog for seven months (39:11-12)**, **the great sacrificial feast for birds and beasts (39:17-20)**, and **"I have poured out my spirit upon the house of Israel" (39:29)**.

**Ethical Inversion Applied:**
- "'Prophesy against Gog'"—prophesy
- "'I am against you, O Gog'"—against
- "'I will turn you about and lead you on'"—lead
- "'Will cause you to come up from the uttermost parts of the north'"—far north
- "'I will bring you upon the mountains of Israel'"—upon mountains
- "'I will smite your bow out of your left hand'"—smite bow
- "'Will cause your arrows to fall'"—arrows fall
- "'You shall fall upon the mountains of Israel'"—fall
- "'I will give you unto the ravenous birds'"—birds devour
- "'I will send a fire on Magog'"—fire on Magog
- "'And on them that dwell securely in the isles'"—isles
- "'My holy name will I make known'"—name known
- "'Neither will I suffer my holy name to be profaned'"—not profaned
- "'The nations shall know that I am YHWH, the Holy One'"—Holy One
- "'This is the day whereof I have spoken'"—the day
- "'They shall make fires of the weapons... seven years'"—burn weapons
- "'They shall spoil those that spoiled them'"—spoil spoilers
- "'I will give unto Gog a place fit for burial'"—burial
- "'The valley of them that pass through'"—valley
- "'They shall call it: The valley of Hamon-gog'"—Hamon-gog
- "'Seven months shall the house of Israel be burying them'"—seven months
- "'That they may cleanse the land'"—cleanse
- "'They shall set apart men... to bury'"—bury teams
- "'When... any sees a man's bone... he shall set up a sign'"—mark bones
- "'Hamonah shall also be the name of a city'"—city named
- "'Speak unto the birds... and to every beast'"—to birds, beasts
- "'Assemble yourselves... gather yourselves... to my sacrifice'"—sacrifice
- "'That you may eat flesh and drink blood'"—eat, drink
- "'The flesh of the mighty shall you eat'"—mighty's flesh
- "'The blood of the princes... shall you drink'"—princes' blood
- "'You shall be filled at my table'"—filled
- "'I will set my glory among the nations'"—glory
- "'All the nations shall see my judgment'"—see judgment
- "'The house of Israel shall know that I am YHWH their God, from that day'"—from that day
- "'The nations shall know that... Israel went into captivity for their iniquity'"—for iniquity
- "'I hid my face from them'"—hid face
- "'Now will I bring back the captivity of Jacob'"—bring back
- "'Have compassion upon the whole house of Israel'"—compassion
- "'I will be jealous for my holy name'"—jealous for name
- "'They shall dwell safely... none shall make them afraid'"—safe
- "'Am sanctified in them in the sight of many nations'"—sanctified
- "'I will leave none of them any more there'"—none left
- "'Neither will I hide my face any more from them'"—not hide
- "'I have poured out my spirit upon the house of Israel'"—spirit poured

**Modern Equivalent:** Ezekiel 39 concludes the Gog prophecy. The seven years of burning weapons (39:9) and seven months of burial (39:12) emphasize totality. The "sacrificial feast" for birds (39:17-20) is reversed sacrifice—animals eat warriors. "I have poured out my spirit" (39:29) concludes with restoration. Chapters 40-48 follow with the temple vision.

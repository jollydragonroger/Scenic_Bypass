# Ezekiel 29: Oracle Against Egypt — Pharaoh the Dragon

*From the Hebrew: בַּשָּׁנָה הָעֲשִׂירִת (Ba-Shanah Ha-Asirit) — In the Tenth Year*

---

## Pharaoh the Great Dragon (29:1-7)

**29:1** In the tenth year, in the tenth month, in the twelfth day of the month, the word of YHWH came unto me, saying:

**29:2** "Son of man, set your face against Pharaoh king of Egypt, and prophesy against him, and against all Egypt;

**29:3** "Speak, and say: Thus says the Lord YHWH: Behold, I am against you, Pharaoh king of Egypt, the great dragon that lies in the midst of his rivers, that has said: 'My river is my own, and I have made it for myself.'

**29:4** "And I will put hooks in your jaws, and I will cause the fish of your rivers to stick unto your scales; and I will bring you up out of the midst of your rivers, with all the fish of your rivers which stick unto your scales.

**29:5** "And I will leave you thrown into the wilderness, you and all the fish of your rivers; you shall fall upon the open field; you shall not be brought together, nor gathered; I have given you for food to the beasts of the earth and to the fowls of the heaven.

**29:6** "And all the inhabitants of Egypt shall know that I am YHWH, because they have been a staff of reed to the house of Israel.

**29:7** "When they took hold of you by your hand, you did break, and rend all their shoulder; and when they leaned upon you, you did break, and made all their loins to be at a stand."

---

## Egypt's Desolation (29:8-16)

**29:8** Therefore thus says the Lord YHWH: "Behold, I will bring a sword upon you, and will cut off from you man and beast.

**29:9** "And the land of Egypt shall be a desolation and a waste, and they shall know that I am YHWH; because he has said: 'The river is mine, and I have made it.'

**29:10** "Therefore, behold, I am against you, and against your rivers, and I will make the land of Egypt utterly waste and desolate, from Migdol to Syene even unto the border of Ethiopia.

**29:11** "No foot of man shall pass through it, nor foot of beast shall pass through it, neither shall it be inhabited forty years.

**29:12** "And I will make the land of Egypt a desolation in the midst of desolate countries, and her cities among cities that are laid waste shall be desolate forty years; and I will scatter the Egyptians among the nations, and will disperse them through the countries.

**29:13** "For thus says the Lord YHWH: At the end of forty years will I gather the Egyptians from the peoples whither they were scattered;

**29:14** "And I will turn the captivity of Egypt, and will cause them to return into the land of Pathros, into the land of their origin; and they shall be there a lowly kingdom.

**29:15** "It shall be the lowliest of the kingdoms; neither shall it exalt itself any more above the nations; and I will diminish them, that they shall no more rule over the nations.

**29:16** "And it shall be no more the confidence of the house of Israel, bringing iniquity to remembrance, when they turn after them; and they shall know that I am the Lord YHWH."

---

## Egypt Given to Nebuchadnezzar (29:17-21)

**29:17** And it came to pass in the seven and twentieth year, in the first month, in the first day of the month, the word of YHWH came unto me, saying:

**29:18** "Son of man, Nebuchadrezzar king of Babylon caused his army to serve a great service against Tyre; every head was made bald, and every shoulder was peeled; yet had he no wages, nor his army, from Tyre, for the service that he had served against it.

**29:19** "Therefore thus says the Lord YHWH: Behold, I will give the land of Egypt unto Nebuchadrezzar king of Babylon; and he shall carry off her abundance, and take her spoil, and take her prey; and it shall be the wages for his army.

**29:20** "I have given him the land of Egypt as his hire for which he served, because they wrought for me," says the Lord YHWH.

**29:21** "In that day will I cause a horn to spring forth unto the house of Israel, and I will give you the opening of the mouth in the midst of them; and they shall know that I am YHWH."

---

## Synthesis Notes

**Key Restorations:**

**Pharaoh the Great Dragon (29:1-7):**
**The Key Verse (29:1):**
"In the tenth year, in the tenth month, in the twelfth day of the month."

*Ba-shanah ha-asirit ba-chodesh ha-asiri bi-shnim asar la-chodesh*—January 587 BCE.

**The Key Verse (29:2):**
"'Set your face against Pharaoh king of Egypt.'"

*Sim panekha al-Par'oh melekh-Mitzrayim*—against Pharaoh.

"'Prophesy against him, and against all Egypt.'"

*Ve-hinnave alav ve-al-Mitzrayim kullah*—all Egypt.

**The Key Verse (29:3):**
"'I am against you, Pharaoh king of Egypt.'"

*Hineni alekha Par'oh melekh-Mitzrayim*—against Pharaoh.

"'The great dragon that lies in the midst of his rivers.'"

*Ha-tannim ha-gadol ha-rovetz be-tokh ye'orav*—great dragon.

"'That has said: My river is my own.'"

*Asher amar li ye'ori*—my river.

"'I have made it for myself.'"

*Va-ani asitini*—I made myself.

**Tannim:**
Sea dragon/crocodile—Pharaoh as the Nile monster.

**The Key Verses (29:4-5):**
"'I will put hooks in your jaws.'"

*Ve-natatti chachim bi-lechayekha*—hooks in jaws.

"'I will cause the fish of your rivers to stick unto your scales.'"

*Ve-hidbaqti degat ye'orekha be-qasqesotekha*—fish on scales.

"'I will bring you up out of the midst of your rivers.'"

*Ve-ha'alitikha mi-tokh ye'orekha*—bring up.

"'I will leave you thrown into the wilderness.'"

*U-netashtikha ha-midbarah*—to wilderness.

"'You shall fall upon the open field.'"

*Al-penei ha-sadeh tippol*—fall in field.

"'I have given you for food to the beasts of the earth.'"

*Le-chayyat ha-aretz u-le-of ha-shamayim netattikha le-okhlah*—food for beasts.

**The Key Verses (29:6-7):**
"'All the inhabitants of Egypt shall know that I am YHWH.'"

*Ve-yad'u kol-yoshevei Mitzrayim ki-ani YHWH*—recognition.

"'Because they have been a staff of reed to the house of Israel.'"

*Ya'an heyotam mish'enet qaneh le-veit Yisra'el*—reed staff.

"'When they took hold of you by your hand, you did break.'"

*Be-tofesam bekha ve-khaf terotz*—broke.

"'Rend all their shoulder.'"

*U-vaqe'ta lahem kol-katef*—rend shoulder.

"'When they leaned upon you, you did break.'"

*Ve-hish'anam alekha tishaver*—broke.

"'Made all their loins to be at a stand.'"

*Ve-ha'amadta lahem kol-motnayim*—loins unstable.

**Reed Staff:**
Egypt broke when Israel relied on it—false ally.

**Egypt's Desolation (29:8-16):**
**The Key Verses (29:8-10):**
"'I will bring a sword upon you.'"

*Hineni mevi alayikh cherev*—sword upon.

"'Will cut off from you man and beast.'"

*Ve-hikhraatti mimmekh adam u-vehemah*—cut off.

"'The land of Egypt shall be a desolation and a waste.'"

*Ve-hayetah eretz Mitzrayim li-shemamah ve-chorvah*—desolation.

"'Because he has said: The river is mine, and I have made it.'"

*Ya'an amar ha-ye'or li va-ani asiti*—I made it.

"'I am against you, and against your rivers.'"

*Hineni elekha ve-el-ye'orekha*—against you and rivers.

"'I will make the land of Egypt utterly waste.'"

*Ve-natatti et-eretz Mitzrayim le-chorvot chorvah shemamah*—utterly waste.

"'From Migdol to Syene even unto the border of Ethiopia.'"

*Mi-Migdol Seveneh ve-ad-gevul Kush*—entire Egypt.

**The Key Verses (29:11-12):**
"'No foot of man shall pass through it.'"

*Lo ta'avor-bah regel adam*—no foot.

"'Nor foot of beast shall pass through it.'"

*Ve-regel behemah lo ta'avor-bah*—no beast.

"'Neither shall it be inhabited forty years.'"

*Ve-lo teshev arba'im shanah*—40 years uninhabited.

"'I will make the land of Egypt a desolation.'"

*Ve-natatti et-eretz Mitzrayim shemamah*—desolation.

"'In the midst of desolate countries.'"

*Be-tokh aratzot neshammot*—among desolate.

"'Her cities among cities that are laid waste shall be desolate forty years.'"

*Ve-areyha be-tokh arim necheravot tihyenah shemamah arba'im shanah*—40 years.

"'I will scatter the Egyptians among the nations.'"

*Va-hafitzotsи et-Mitzrayim ba-goyim*—scatter.

"'Will disperse them through the countries.'"

*Ve-zeriתim ba-aratzot*—disperse.

**The Key Verses (29:13-16):**
"'At the end of forty years will I gather the Egyptians.'"

*Mi-qetz arba'im shanah aqabbetz et-Mitzrayim*—gather after 40.

"'I will turn the captivity of Egypt.'"

*Ve-shavti et-shevut Mitzrayim*—restore Egypt.

"'Will cause them to return into the land of Pathros.'"

*Va-hashivoti otam eretz Patros*—to Pathros.

"'Into the land of their origin.'"

*Al-eretz mekhuratam*—origin land.

"'They shall be there a lowly kingdom.'"

*Ve-hayu sham mamlakhah shefelah*—lowly kingdom.

"'It shall be the lowliest of the kingdoms.'"

*Shefalah min-ha-mamlakhot tihyeh*—lowliest.

"'Neither shall it exalt itself any more above the nations.'"

*Ve-lo-titnasseh od al-ha-goyim*—not exalt.

"'I will diminish them.'"

*Ve-him'attim*—diminish.

"'That they shall no more rule over the nations.'"

*Le-vilti redot ba-goyim*—not rule.

"'It shall be no more the confidence of the house of Israel.'"

*Ve-lo yihyeh od le-veit Yisra'el le-mivtach*—no confidence.

"'Bringing iniquity to remembrance, when they turn after them.'"

*Mazkir avon bi-fenotam achareihem*—turn after = sin.

**Egypt Given to Nebuchadnezzar (29:17-21):**
**The Key Verse (29:17):**
"In the seven and twentieth year, in the first month, in the first day."

*Ba-shanah ha-esrim va-sheva ba-rishon be-echad la-chodesh*—April 571 BCE.

**Latest Dated Oracle:**
This is the latest dated oracle in Ezekiel.

**The Key Verse (29:18):**
"'Nebuchadrezzar king of Babylon caused his army to serve a great service against Tyre.'"

*Nevukhadre'tzar melekh-Bavel he'evid et-cheilo avodah gedolah el-Tzor*—great service.

"'Every head was made bald, and every shoulder was peeled.'"

*Kol-rosh muqrach ve-khol-katef merutah*—bald heads, peeled shoulders.

"'Yet had he no wages, nor his army, from Tyre.'"

*Ve-sakhar lo-hayah lo ve-le-cheilo mi-Tzor*—no wages.

"'For the service that he had served against it.'"

*Al-ha-avodah asher-avad alekha*—for service.

**13-Year Siege:**
Nebuchadnezzar besieged Tyre for 13 years but gained little.

**The Key Verses (29:19-21):**
"'I will give the land of Egypt unto Nebuchadrezzar king of Babylon.'"

*Hineni noten le-Nevukhadre'tzar melekh-Bavel et-eretz Mitzrayim*—give Egypt.

"'He shall carry off her abundance, and take her spoil.'"

*Ve-nasa hamonah ve-shalal shelalah*—spoil.

"'Take her prey.'"

*U-vazaz bizzah*—prey.

"'It shall be the wages for his army.'"

*Ve-hayetah sakhar le-cheilo*—wages.

"'I have given him the land of Egypt as his hire.'"

*Et-eretz Mitzrayim natatti lo bi-fe'ullato*—hire.

"'For which he served, because they wrought for me.'"

*Asher avdu-li*—served me.

"'In that day will I cause a horn to spring forth unto the house of Israel.'"

*Ba-yom ha-hu atzmיach qeren le-veit Yisra'el*—horn springs.

"'I will give you the opening of the mouth in the midst of them.'"

*Ve-lekha etten pitchon-peh be-tokham*—opening of mouth.

**Archetypal Layer:** Ezekiel 29 begins the **Egypt oracles (29-32)**, containing **Pharaoh as "the great dragon that lies in the midst of his rivers" (29:3)**, **"My river is my own, and I have made it for myself" (29:3)**, **Egypt as a "staff of reed" that breaks (29:6-7)**, **40 years of desolation (29:11-12)**, **Egypt becoming "the lowliest of the kingdoms" (29:15)**, and **Nebuchadnezzar receiving Egypt as wages for Tyre (29:18-20)**.

**Ethical Inversion Applied:**
- "In the tenth year"—January 587 BCE
- "'Set your face against Pharaoh king of Egypt'"—against Pharaoh
- "'I am against you, Pharaoh king of Egypt'"—against
- "'The great dragon that lies in the midst of his rivers'"—dragon/crocodile
- "'My river is my own, and I have made it for myself'"—pride
- "'I will put hooks in your jaws'"—hooks
- "'I will cause the fish of your rivers to stick unto your scales'"—fish on scales
- "'I will bring you up out of the midst of your rivers'"—bring up
- "'I will leave you thrown into the wilderness'"—to wilderness
- "'I have given you for food to the beasts'"—food for beasts
- "'They have been a staff of reed to the house of Israel'"—reed staff
- "'When they took hold of you... you did break'"—broke
- "'I will bring a sword upon you'"—sword
- "'The land of Egypt shall be a desolation'"—desolation
- "'Because he has said: The river is mine, and I have made it'"—pride
- "'I am against you, and against your rivers'"—against
- "'From Migdol to Syene'"—entire Egypt
- "'No foot of man shall pass through it... forty years'"—40 years
- "'I will scatter the Egyptians among the nations'"—scatter
- "'At the end of forty years will I gather the Egyptians'"—gather
- "'They shall be there a lowly kingdom'"—lowly
- "'It shall be the lowliest of the kingdoms'"—lowliest
- "'It shall be no more the confidence of the house of Israel'"—no confidence
- "In the seven and twentieth year"—April 571 BCE
- "'Nebuchadrezzar... caused his army to serve a great service against Tyre'"—Tyre siege
- "'Every head was made bald, and every shoulder was peeled'"—hard labor
- "'Yet had he no wages... from Tyre'"—no wages
- "'I will give the land of Egypt unto Nebuchadrezzar'"—give Egypt
- "'It shall be the wages for his army'"—wages
- "'They wrought for me'"—served YHWH
- "'I will cause a horn to spring forth unto the house of Israel'"—horn

**Modern Equivalent:** Ezekiel 29 introduces Egypt oracles. Pharaoh as the Nile crocodile/dragon (29:3) is a powerful image. Egypt's sin was pride ("I made the Nile") and being an unreliable ally (reed staff, 29:6-7). The latest dated oracle (571 BCE, 29:17) shows Egypt as compensation for Nebuchadnezzar's unprofitable Tyre siege.

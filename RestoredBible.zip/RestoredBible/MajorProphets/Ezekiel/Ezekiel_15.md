# Ezekiel 15: The Parable of the Vine

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## The Useless Vine (15:1-8)

**15:1** And the word of YHWH came unto me, saying:

**15:2** "Son of man, what is the vine-tree more than any tree, the vine branch which grew up among the trees of the forest?

**15:3** "Shall wood be taken thereof to make any work? Or will men take a pin of it to hang any vessel thereon?

**15:4** "Behold, it is cast into the fire for fuel; the fire has devoured both the ends of it, and the midst of it is singed; is it profitable for any work?

**15:5** "Behold, when it was whole, it was meet for no work; how much less, when the fire has devoured it, and it is singed, shall it be meet yet for any work?

**15:6** "Therefore thus says the Lord YHWH: As the vine-tree among the trees of the forest, which I have given to the fire for fuel, so do I give the inhabitants of Jerusalem.

**15:7** "And I will set my face against them; from the fire are they gone forth, and the fire shall devour them; and you shall know that I am YHWH, when I set my face against them.

**15:8** "And I will make the land desolate, because they have acted treacherously," says the Lord YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Useless Vine (15:1-8):**
**The Key Verse (15:2):**
"'What is the vine-tree more than any tree?'"

*Mah-yihyeh etz-ha-gefen mi-kol-etz*—what is vine?

"'The vine branch which grew up among the trees of the forest?'"

*Ha-zemorah asher hayah ba-atzei ha-ya'ar*—forest vine.

**Vine Symbolism:**
Israel is often called YHWH's vine (Isaiah 5; Psalm 80). This reverses the image—an unfruitful vine is worthless.

**The Key Verse (15:3):**
"'Shall wood be taken thereof to make any work?'"

*Ha-yuqqach mimmennah etz la'asot li-melakhah*—make anything?

"'Will men take a pin of it to hang any vessel thereon?'"

*Im-yiqchu mimmennah yated litlot alav kol-keli*—hang vessel?

**Useless Wood:**
Vine wood is useless for construction—its only value is producing grapes.

**The Key Verse (15:4):**
"'It is cast into the fire for fuel.'"

*Hinneh la-esh nittan le-okhlah*—cast into fire.

"'The fire has devoured both the ends of it.'"

*Et shenei qetzotav akhelah ha-esh*—ends devoured.

"'The midst of it is singed.'"

*Ve-tokho nachor*—middle singed.

"'Is it profitable for any work?'"

*Ha-yitzlach li-melakhah*—profitable?

**The Key Verse (15:5):**
"'When it was whole, it was meet for no work.'"

*Hinneh bi-heyoto tamim lo ye'aseh li-melakhah*—when whole, useless.

"'How much less, when the fire has devoured it, and it is singed.'"

*Af ki-esh akhalathu va-yechor*—after fire, less.

"'Shall it be meet yet for any work?'"

*Ve-na'asah od li-melakhah*—any work?

**The Key Verse (15:6):**
"'As the vine-tree among the trees of the forest, which I have given to the fire for fuel.'"

*Ka-asher etz-ha-gefen ba-etz ha-ya'ar asher-netattiv la-esh le-okhlah*—vine for fuel.

"'So do I give the inhabitants of Jerusalem.'"

*Ken natatti et-yoshevei Yerushalayim*—give Jerusalem.

**The Key Verse (15:7):**
"'I will set my face against them.'"

*Ve-natatti et-panai bahem*—face against.

"'From the fire are they gone forth.'"

*Min-ha-esh yatza'u*—escaped fire.

"'The fire shall devour them.'"

*Ve-ha-esh tokhelем*—fire devours.

"'You shall know that I am YHWH.'"

*Vi-ydatem ki-ani YHWH*—recognition.

"'When I set my face against them.'"

*Be-sumi et-panai bahem*—face against.

**Partial Escape:**
Those who escaped the first deportation (597 BCE) will face fire again.

**The Key Verse (15:8):**
"'I will make the land desolate.'"

*Ve-natatti et-ha-aretz shemamah*—land desolate.

"'Because they have acted treacherously.'"

*Ya'an ma'alu ma'al*—treachery.

**Archetypal Layer:** Ezekiel 15 contains **the parable of the useless vine (15:2-5)**, **"shall wood be taken thereof to make any work?" (15:3)**, **"when it was whole, it was meet for no work; how much less, when the fire has devoured it" (15:5)**, and **"from the fire are they gone forth, and the fire shall devour them" (15:7)**.

**Ethical Inversion Applied:**
- "'What is the vine-tree more than any tree?'"—what is vine?
- "'The vine branch which grew up among the trees of the forest?'"—forest vine
- "'Shall wood be taken thereof to make any work?'"—make anything?
- "'Will men take a pin of it to hang any vessel thereon?'"—hang vessel?
- "'It is cast into the fire for fuel'"—cast into fire
- "'The fire has devoured both the ends of it'"—ends devoured
- "'The midst of it is singed'"—middle singed
- "'Is it profitable for any work?'"—profitable?
- "'When it was whole, it was meet for no work'"—when whole, useless
- "'How much less, when the fire has devoured it'"—after fire, less useful
- "'As the vine-tree among the trees of the forest'"—like forest vine
- "'Which I have given to the fire for fuel'"—given for fuel
- "'So do I give the inhabitants of Jerusalem'"—Jerusalem given
- "'I will set my face against them'"—face against
- "'From the fire are they gone forth'"—escaped fire
- "'The fire shall devour them'"—fire devours
- "'You shall know that I am YHWH'"—recognition
- "'I will make the land desolate'"—land desolate
- "'Because they have acted treacherously'"—treachery

**Modern Equivalent:** Ezekiel 15 reverses Israel's vine imagery. Israel was chosen to bear fruit (Isaiah 5:1-7), but without fruit, vine wood is useless—not even good for a peg. The 597 BCE deportees thought they'd escaped fire, but more fire comes. Brief but devastating.

# Ezekiel 42: The Priests' Chambers

*From the Hebrew: וַיּוֹצִאֵנִי אֶל־הֶחָצֵר הַחִיצוֹנָה (Va-Yotzi'eni El-He-Chatzer Ha-Chitzonah) — And He Brought Me Forth into the Outer Court*

---

## The Northern Chambers (42:1-9)

**42:1** Then he brought me forth into the outer court, the way toward the north; and he brought me into the chamber that was over against the separate place, and which was over against the building toward the north.

**42:2** Before the length of a hundred cubits was the north door, and the breadth was fifty cubits.

**42:3** Over against the twenty cubits which belonged to the inner court, and over against the pavement which belonged to the outer court, was gallery against gallery in three stories.

**42:4** And before the chambers was a walk of ten cubits breadth inward, a way of one cubit; and their doors were toward the north.

**42:5** Now the upper chambers were shorter; for the galleries took away from these, more than from the lower and the middlemost, in the building.

**42:6** For they were in three stories, and they had not pillars as the pillars of the courts; therefore room was taken away from the lowest and the middlemost, in comparison with the ground.

**42:7** And the wall that was without by the side of the chambers, toward the outer court in front of the chambers, the length thereof was fifty cubits.

**42:8** For the length of the chambers that were toward the outer court was fifty cubits; and, lo, before the temple were a hundred cubits.

**42:9** And from under these chambers was the entry on the east side, as one goes into them from the outer court.

---

## The Southern Chambers (42:10-12)

**42:10** In the breadth of the wall of the court toward the east, before the separate place, and before the building, there were chambers.

**42:11** And the way before them was like the appearance of the chambers which were toward the north, as long as they, and as broad as they; and all their goings out were both according to their fashions, and according to their doors.

**42:12** And according to the doors of the chambers that were toward the south was a door in the head of the way, even the way directly before the wall toward the east, as one enters into them.

---

## The Purpose of the Chambers (42:13-14)

**42:13** Then said he unto me: "The north chambers and the south chambers, which are before the separate place, they are the holy chambers, where the priests that are near unto YHWH shall eat the most holy things; there shall they lay the most holy things, and the meal-offering, and the sin-offering, and the guilt-offering; for the place is holy.

**42:14** "When the priests enter in, then shall they not go out of the holy place into the outer court, but there they shall lay their garments wherein they minister, for they are holy; and they shall put on other garments, and shall approach to that which pertains to the people."

---

## The Overall Measurements (42:15-20)

**42:15** Now when he had made an end of measuring the inner house, he brought me forth by the way of the gate whose prospect is toward the east, and measured it round about.

**42:16** He measured the east side with the measuring reed, five hundred reeds, with the measuring reed round about.

**42:17** He measured the north side, five hundred reeds, with the measuring reed round about.

**42:18** He measured the south side, five hundred reeds, with the measuring reed.

**42:19** He turned about to the west side, and measured five hundred reeds with the measuring reed.

**42:20** He measured it by the four sides; it had a wall round about, the length five hundred, and the breadth five hundred, to make a separation between that which was holy and that which was common.

---

## Synthesis Notes

**Key Restorations:**

**Northern Chambers (42:1-9):**
**The Key Verse (42:1):**
"He brought me forth into the outer court, the way toward the north."

*Va-yotzi'eni el-he-chatzer ha-chitzonah ha-derekh derekh ha-tzafon*—to north.

"He brought me into the chamber that was over against the separate place."

*Va-yevi'eni el-ha-lishkah asher neged ha-gizrah*—chamber.

**The Key Verse (42:2):**
"Before the length of a hundred cubits was the north door."

*El-penei orekh ammot ha-me'ah petach ha-tzafon*—100 cubits.

"The breadth was fifty cubits."

*Ve-ha-rochav chamishim ammah*—50 cubits.

**The Key Verses (42:3-6):**
"Over against the twenty cubits which belonged to the inner court."

*Neged esrim ammah asher le-chatzer ha-penimit*—20 cubits.

"Over against the pavement which belonged to the outer court."

*Ve-neged ritzpah asher le-chatzer ha-chitzonah*—pavement.

"Gallery against gallery in three stories."

*Attiq el-penei attiq ba-shelishim*—three-story galleries.

"Before the chambers was a walk of ten cubits breadth inward."

*Ve-lifnei ha-leshakhot mahalkak eser ammot rochav el-ha-penimit*—10-cubit walk.

"A way of one cubit."

*Derekh ammah achat*—one cubit.

"Their doors were toward the north."

*U-fitcheihem la-tzafon*—north doors.

"The upper chambers were shorter."

*Ve-ha-leshakhot ha-elyonot qetzurot*—upper shorter.

"For the galleries took away from these."

*Ki yokhelu attiqim me-hennah*—galleries took.

"They were in three stories."

*Ki meshulashot hennah*—three stories.

"They had not pillars as the pillars of the courts."

*Ve-ein lahem ammudim ke-ammudei ha-chatzerot*—no pillars.

"Therefore room was taken away."

*Al-ken ne'etzal*—room taken.

**Southern Chambers (42:10-12):**
"In the breadth of the wall of the court toward the east."

*Be-rochav geder he-chatzer derekh ha-qadim*—east wall.

"Before the separate place, and before the building, there were chambers."

*El-penei ha-gizrah ve-el-penei ha-binyan leshakhot*—chambers.

"The way before them was like the appearance of the chambers which were toward the north."

*Ve-derekh lifneihem ke-mar'eh ha-leshakhot asher derekh ha-tzafon*—like north.

"As long as they, and as broad as they."

*Ke-orkan ke-rochban*—same size.

"All their goings out were both according to their fashions."

*Ve-khol-motza'eihen ke-mishpeteihen*—same pattern.

**Purpose of the Chambers (42:13-14):**
**The Key Verse (42:13):**
"'The north chambers and the south chambers.'"

*Ha-leshakhot ha-tzafon ve-ha-leshakhot ha-darom*—north and south.

"'Which are before the separate place.'"

*Asher el-penei ha-gizrah*—before separate place.

"'They are the holy chambers.'"

*Hennah lishkhot ha-qodesh*—holy chambers.

"'Where the priests that are near unto YHWH shall eat the most holy things.'"

*Asher yokhelu-sham ha-kohanim asher-qerovim la-YHWH qodshei ha-qodashim*—eat most holy.

"'There shall they lay the most holy things.'"

*Sham yanichu qodshei ha-qodashim*—lay most holy.

"'The meal-offering, and the sin-offering, and the guilt-offering.'"

*Ve-ha-minchah ve-ha-chattat ve-ha-asham*—offerings.

"'For the place is holy.'"

*Ki ha-maqom qadosh*—holy place.

**The Key Verse (42:14):**
"'When the priests enter in, then shall they not go out of the holy place into the outer court.'"

*Be-vo'am ha-kohanim ve-lo-yetze'u min-ha-qodesh el-he-chatzer ha-chitzonah*—not go out.

"'There they shall lay their garments wherein they minister, for they are holy.'"

*Ve-sham yanichu et-bigdeihem asher-yesharetu vahen ki-qodesh hennah*—lay garments.

"'They shall put on other garments.'"

*Ve-lavshu begadim acherim*—other garments.

"'Shall approach to that which pertains to the people.'"

*Ve-qarevu el-asher la-am*—approach people.

**Holy/Common Distinction:**
Priests must change garments between sacred service and ordinary activity.

**Overall Measurements (42:15-20):**
**The Key Verses (42:15-19):**
"When he had made an end of measuring the inner house."

*Ve-khillah et-middot beit-ha-penimah*—finished inner.

"He brought me forth by the way of the gate whose prospect is toward the east."

*Ve-hotzi'ani derekh ha-sha'ar asher panav derekh ha-qadim*—east gate.

"Measured it round about."

*U-medado saviv saviv*—round about.

"He measured the east side... five hundred reeds."

*Madad ruach ha-qadim... chamesh me'ot qanim*—500 reeds east.

"He measured the north side, five hundred reeds."

*Madad ruach ha-tzafon chamesh me'ot qanim*—500 reeds north.

"He measured the south side, five hundred reeds."

*Et ruach ha-darom madad chamesh me'ot qanim*—500 reeds south.

"He turned about to the west side, and measured five hundred reeds."

*Savav el-ruach ha-yam madad chamesh me'ot qanim*—500 reeds west.

**The Key Verse (42:20):**
"He measured it by the four sides."

*Le-arba ruchot medado*—four sides.

"It had a wall round about."

*Chomah lo saviv saviv*—wall around.

"The length five hundred, and the breadth five hundred."

*Orekh chamesh me'ot ve-rochav chamesh me'ot*—500 x 500.

"To make a separation between that which was holy and that which was common."

*Le-havdil bein ha-qodesh le-chol*—separate holy/common.

**Square Temple Complex:**
500 x 500 reeds (approximately 1.5 miles per side).

**Archetypal Layer:** Ezekiel 42 describes the **priests' chambers**, containing **northern chambers (42:1-9)**, **southern chambers matching the northern (42:10-12)**, **"They are the holy chambers, where the priests... shall eat the most holy things" (42:13)**, **priests must change garments between holy and common (42:14)**, and **the temple complex measured 500 x 500 "to make a separation between that which was holy and that which was common" (42:20)**.

**Ethical Inversion Applied:**
- "He brought me forth into the outer court, the way toward the north"—to north
- "He brought me into the chamber... over against the separate place"—chamber
- "Before the length of a hundred cubits was the north door"—100 cubits
- "The breadth was fifty cubits"—50 cubits
- "Gallery against gallery in three stories"—three stories
- "Before the chambers was a walk of ten cubits"—10-cubit walk
- "The upper chambers were shorter"—upper shorter
- "They were in three stories"—three stories
- "They had not pillars"—no pillars
- "In the breadth of the wall of the court toward the east"—east
- "There were chambers"—chambers
- "The way before them was like... the north"—like north
- "'The north chambers and the south chambers'"—both sides
- "'They are the holy chambers'"—holy
- "'Where the priests... shall eat the most holy things'"—eat holy things
- "'There shall they lay the most holy things'"—lay
- "'The meal-offering, and the sin-offering, and the guilt-offering'"—offerings
- "'For the place is holy'"—holy
- "'When the priests enter in, then shall they not go out'"—not go out
- "'There they shall lay their garments'"—lay garments
- "'For they are holy'"—holy garments
- "'They shall put on other garments'"—change
- "'Shall approach to that which pertains to the people'"—approach people
- "He had made an end of measuring the inner house"—finished
- "He brought me forth by the way of the gate... toward the east"—east gate
- "Measured it round about"—measured
- "He measured the east side... five hundred reeds"—500 east
- "He measured the north side, five hundred reeds"—500 north
- "He measured the south side, five hundred reeds"—500 south
- "He... measured five hundred reeds"—500 west
- "He measured it by the four sides"—four sides
- "It had a wall round about"—wall
- "The length five hundred, and the breadth five hundred"—500 x 500
- "'To make a separation between that which was holy and that which was common'"—separate

**Modern Equivalent:** Ezekiel 42 details priests' chambers for eating sacred offerings and storing vestments. The holy/common distinction is emphasized—priests change clothes between sacred service and public interaction. The massive 500 x 500 reed enclosure emphasizes holiness's separation from the common.

# Ezekiel 26: Oracle Against Tyre

*From the Hebrew: וַיְהִי בְּעַשְׁתֵּי־עֶשְׂרֵה שָׁנָה (Va-Yehi Be-Ashtei-Esreh Shanah) — And It Came to Pass in the Eleventh Year*

---

## Tyre's Sin and Judgment (26:1-6)

**26:1** And it came to pass in the eleventh year, in the first day of the month, that the word of YHWH came unto me, saying:

**26:2** "Son of man, because that Tyre has said against Jerusalem: 'Aha, she is broken that was the gate of the peoples; she is turned unto me; I shall be filled with her that is laid waste';

**26:3** "Therefore thus says the Lord YHWH: Behold, I am against you, O Tyre, and will cause many nations to come up against you, as the sea causes its waves to come up.

**26:4** "And they shall destroy the walls of Tyre, and break down her towers; I will also scrape her dust from her, and make her a bare rock.

**26:5** "She shall be a place for the spreading of nets in the midst of the sea; for I have spoken it," says the Lord YHWH; "and she shall become a spoil to the nations.

**26:6** "And her daughters that are in the field shall be slain by the sword; and they shall know that I am YHWH."

---

## Nebuchadnezzar's Siege (26:7-14)

**26:7** For thus says the Lord YHWH: "Behold, I will bring upon Tyre Nebuchadrezzar king of Babylon, king of kings, from the north, with horses, and with chariots, and with horsemen, and a company, and much people.

**26:8** "He shall slay with the sword your daughters in the field; and he shall make forts against you, and cast up a mound against you, and raise up the buckler against you.

**26:9** "And he shall set his battering engines against your walls, and with his axes he shall break down your towers.

**26:10** "By reason of the abundance of his horses their dust shall cover you; your walls shall shake at the noise of the horsemen, and of the wheels, and of the chariots, when he shall enter into your gates, as men enter into a city wherein is made a breach.

**26:11** "With the hoofs of his horses shall he tread down all your streets; he shall slay your people by the sword, and the pillars of your strength shall go down to the ground.

**26:12** "And they shall make a spoil of your riches, and make a prey of your merchandise; and they shall break down your walls, and destroy your pleasant houses; and your stones and your timber and your dust shall they lay in the midst of the waters.

**26:13** "And I will cause the noise of your songs to cease, and the sound of your harps shall be no more heard.

**26:14** "And I will make you a bare rock; you shall be a place for the spreading of nets; you shall be built no more; for I YHWH have spoken it," says the Lord YHWH.

---

## The Nations Mourn (26:15-18)

**26:15** Thus says the Lord YHWH to Tyre: "Shall not the isles shake at the sound of your fall, when the wounded groan, when the slaughter is made in the midst of you?

**26:16** "Then all the princes of the sea shall come down from their thrones, and lay aside their robes, and strip off their richly woven garments; they shall clothe themselves with trembling; they shall sit upon the ground, and shall tremble every moment, and be appalled at you.

**26:17** "And they shall take up a lamentation for you, and say to you: How are you destroyed, that was inhabited from the seas, the renowned city, that was strong in the sea, she and her inhabitants, that caused their terror to be on all that haunt it!

**26:18** "Now shall the isles tremble in the day of your fall; yea, the isles that are in the sea shall be affrighted at your going out."

---

## Tyre's Descent to the Pit (26:19-21)

**26:19** For thus says the Lord YHWH: "When I shall make you a desolate city, like the cities that are not inhabited; when I shall bring up the deep upon you, and the great waters shall cover you;

**26:20** "Then will I bring you down with them that descend into the pit, to the people of old time, and will make you to dwell in the nether parts of the earth, like the places that are desolate of old, with them that go down to the pit, that you be not inhabited; and I will set glory in the land of the living.

**26:21** "I will make you a terror, and you shall be no more; though you be sought for, yet shall you never be found again," says the Lord YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Tyre's Sin and Judgment (26:1-6):**
**The Key Verse (26:1):**
"In the eleventh year, in the first day of the month."

*Ba-ashtei-esreh shanah be-echad la-chodesh*—587/586 BCE (during siege).

**The Key Verse (26:2):**
"'Because that Tyre has said against Jerusalem: Aha!'"

*Ya'an asher-amerah Tzor al-Yerushalayim he'ach*—Aha.

"'She is broken that was the gate of the peoples.'"

*Nishberah daltetei ha-ammim*—gate broken.

"'She is turned unto me.'"

*Nassebah elai*—turned to me.

"'I shall be filled with her that is laid waste.'"

*Immale'ah hachoravah*—filled from her waste.

**Tyre's Sin:**
Commercial opportunism—seeing Jerusalem's fall as trade opportunity.

**The Key Verses (26:3-6):**
"'Behold, I am against you, O Tyre.'"

*Hineni alayikh Tzor*—against Tyre.

"'Will cause many nations to come up against you.'"

*Ve-ha'aleiti alayikh goyim rabbim*—many nations.

"'As the sea causes its waves to come up.'"

*Ka-ha'alot ha-yam le-gallav*—like waves.

"'They shall destroy the walls of Tyre.'"

*Ve-haresu chomot Tzor*—destroy walls.

"'Break down her towers.'"

*Ve-haresu migdaleyha*—break towers.

"'I will also scrape her dust from her.'"

*Ve-sicheti afarah mimmennah*—scrape dust.

"'Make her a bare rock.'"

*Ve-natatti otah li-tzechich sela*—bare rock.

"'She shall be a place for the spreading of nets.'"

*Mishtoach charamim tihyeh*—spreading nets.

"'In the midst of the sea.'"

*Be-tokh ha-yam*—in sea.

"'She shall become a spoil to the nations.'"

*Ve-hayetah le-vaz la-goyim*—spoil.

"'Her daughters that are in the field shall be slain.'"

*U-venoteyha asher ba-sadeh ba-cherev teharegנah*—mainland settlements.

**Nebuchadnezzar's Siege (26:7-14):**
**The Key Verse (26:7):**
"'I will bring upon Tyre Nebuchadrezzar king of Babylon.'"

*Hineni mevi el-Tzor Nevukhadre'tzar melekh-Bavel*—Nebuchadnezzar.

"'King of kings.'"

*Melekh melakhim*—king of kings.

"'From the north.'"

*Mi-tzafon*—from north.

"'With horses, and with chariots, and with horsemen.'"

*Be-sus u-ve-rekhev u-ve-farashim*—horses, chariots.

"'A company, and much people.'"

*U-qahal ve-am rav*—great army.

**The Key Verses (26:8-11):**
"'He shall slay with the sword your daughters in the field.'"

*Benotayikh ba-sadeh ba-cherev yaharog*—slay mainland.

"'He shall make forts against you.'"

*Ve-natan alayikh dayeq*—forts.

"'Cast up a mound against you.'"

*Ve-shafakh alayikh solelah*—mound.

"'He shall set his battering engines against your walls.'"

*U-mechי qovlo yitten be-chomotayikh*—battering rams.

"'With his axes he shall break down your towers.'"

*U-ve-charevotav yeheros migdalotayikh*—break towers.

"'By reason of the abundance of his horses their dust shall cover you.'"

*Mi-shif'at susav yekhasekh avaqam*—dust cover.

"'Your walls shall shake at the noise.'"

*Mi-qol parash ve-galgal va-rekhev tir'ashnah chomotayikh*—walls shake.

"'When he shall enter into your gates.'"

*Be-vo'o bi-she'arayikh*—enter gates.

"'With the hoofs of his horses shall he tread down all your streets.'"

*Be-parseי susav yirmos et-kol-chutzotayikh*—tread streets.

"'He shall slay your people by the sword.'"

*Ammekh ba-cherev yaharog*—slay people.

"'The pillars of your strength shall go down to the ground.'"

*U-matztzevot uzzekh la-aretz tered*—pillars fall.

**The Key Verses (26:12-14):**
"'They shall make a spoil of your riches.'"

*Ve-shaselu cheilekh*—spoil riches.

"'Make a prey of your merchandise.'"

*U-vazzu rikhulatekh*—prey merchandise.

"'They shall break down your walls.'"

*Ve-haresu chomotayikh*—break walls.

"'Destroy your pleasant houses.'"

*U-vattei chemdatekh yeherosu*—destroy houses.

"'Your stones and your timber and your dust shall they lay in the midst of the waters.'"

*Va-avanayikh ve-etzayikh va-afarekh be-tokh mayim yasimu*—into water.

**Alexander's Fulfillment:**
Alexander the Great scraped the ruins of old Tyre into the sea to build a causeway to the island city (332 BCE).

"'I will cause the noise of your songs to cease.'"

*Ve-hishbatti hamon shirayikh*—songs cease.

"'The sound of your harps shall be no more heard.'"

*Ve-qol kinnorotayikh lo yishshama od*—harps silenced.

"'I will make you a bare rock.'"

*U-netattikh li-tzechich sela*—bare rock.

"'A place for the spreading of nets.'"

*Mishtoach charamim tihyeh*—spreading nets.

"'You shall be built no more.'"

*Lo tivvaneh od*—not rebuilt.

**Nations Mourn (26:15-18):**
**The Key Verses (26:15-16):**
"'Shall not the isles shake at the sound of your fall?'"

*Ha-lo mi-qol mappaltekh bir'osh challal*—isles shake.

"'When the wounded groan.'"

*Be-he'aneq challal*—wounded groan.

"'When the slaughter is made in the midst of you.'"

*Be-hareg hereg be-tokhekh*—slaughter.

"'All the princes of the sea shall come down from their thrones.'"

*Ve-yaredu me-al kis'otam kol-nesi'ei ha-yam*—princes descend.

"'Lay aside their robes.'"

*Ve-hesiru et-me'ileihem*—lay aside robes.

"'Strip off their richly woven garments.'"

*Ve-et-bigdei riqmatam yifshotu*—strip garments.

"'They shall clothe themselves with trembling.'"

*Charadot yilbashu*—clothe in trembling.

"'They shall sit upon the ground.'"

*Al-ha-aretz yeshevuи*—sit on ground.

"'Shall tremble every moment.'"

*Ve-chardu li-rega'im*—tremble.

"'Be appalled at you.'"

*Ve-shamemu alayikh*—appalled.

**The Key Verses (26:17-18):**
"'They shall take up a lamentation for you.'"

*Ve-nas'u alayikh qinah*—lament.

"'How are you destroyed, that was inhabited from the seas.'"

*Eikh avadt ha-noshavet mi-yammim*—destroyed.

"'The renowned city.'"

*Ha-ir ha-hulalah*—renowned.

"'That was strong in the sea.'"

*Asher-hayetah chazaqah ba-yam*—strong in sea.

"'She and her inhabitants, that caused their terror.'"

*Hi ve-yoshveyha asher-nattenu chittitam*—caused terror.

"'Now shall the isles tremble in the day of your fall.'"

*Attah yecherdu ha-iyyim yom mappaltekh*—isles tremble.

**Tyre's Descent to Pit (26:19-21):**
**The Key Verses (26:19-21):**
"'When I shall make you a desolate city.'"

*Be-titti otakh ir necherevet*—desolate.

"'Like the cities that are not inhabited.'"

*Ke-arim asher lo-noshabu*—uninhabited.

"'When I shall bring up the deep upon you.'"

*Be-ha'alot alayikh et-tehom*—deep upon.

"'The great waters shall cover you.'"

*Ve-khissukh ha-mayim ha-rabbim*—waters cover.

"'I will bring you down with them that descend into the pit.'"

*Ve-horadtikh et-yordei bor*—descend to pit.

"'To the people of old time.'"

*El-am olam*—people of old.

"'Will make you to dwell in the nether parts of the earth.'"

*Ve-hoshavitkh be-eretz tachtiyyot*—netherworld.

"'Like the places that are desolate of old.'"

*Ke-choravot me-olam*—desolate of old.

"'With them that go down to the pit.'"

*Et-yordei bor*—pit descenders.

"'That you be not inhabited.'"

*Lema'an lo teshevi*—not inhabited.

"'I will set glory in the land of the living.'"

*Ve-natatti tzevi be-eretz chayyim*—glory in living land.

"'I will make you a terror.'"

*Ballahot ettnekh*—terror.

"'You shall be no more.'"

*Ve-einekh*—no more.

"'Though you be sought for, yet shall you never be found again.'"

*U-tevuqshi ve-lo timmatz'i od*—never found.

**Archetypal Layer:** Ezekiel 26 begins the **Tyre oracles (26-28)**, containing **Tyre's "Aha" at Jerusalem's fall (26:2)**, **"I will make you a bare rock; you shall be a place for the spreading of nets" (26:14)**, **Nebuchadnezzar's siege (26:7-14)**, **"Your stones and your timber and your dust shall they lay in the midst of the waters" (26:12)**—fulfilled by Alexander, and **descent to the pit (26:19-21)**.

**Ethical Inversion Applied:**
- "In the eleventh year"—587/586 BCE
- "'Because that Tyre has said against Jerusalem: Aha!'"—Aha
- "'She is broken that was the gate of the peoples'"—gate broken
- "'I shall be filled with her that is laid waste'"—commercial opportunism
- "'I am against you, O Tyre'"—against Tyre
- "'Will cause many nations to come up'"—many nations
- "'As the sea causes its waves to come up'"—like waves
- "'They shall destroy the walls of Tyre'"—destroy walls
- "'I will also scrape her dust from her'"—scrape
- "'Make her a bare rock'"—bare rock
- "'A place for the spreading of nets'"—spreading nets
- "'I will bring upon Tyre Nebuchadrezzar'"—Nebuchadnezzar
- "'King of kings'"—title
- "'With horses, and with chariots'"—army
- "'He shall set his battering engines'"—siege
- "'Your walls shall shake'"—walls shake
- "'With the hoofs of his horses shall he tread'"—hoofs tread
- "'They shall make a spoil of your riches'"—spoil
- "'Your stones and your timber and your dust shall they lay in the midst of the waters'"—into sea
- "'I will cause the noise of your songs to cease'"—songs cease
- "'You shall be built no more'"—not rebuilt
- "'Shall not the isles shake at the sound of your fall?'"—isles shake
- "'All the princes of the sea shall come down from their thrones'"—princes descend
- "'They shall clothe themselves with trembling'"—trembling
- "'They shall take up a lamentation'"—lament
- "'How are you destroyed, that was inhabited from the seas'"—destroyed
- "'When I shall make you a desolate city'"—desolate
- "'I shall bring up the deep upon you'"—deep upon
- "'I will bring you down with them that descend into the pit'"—to pit
- "'To the people of old time'"—people of old
- "'In the nether parts of the earth'"—netherworld
- "'I will make you a terror'"—terror
- "'You shall be no more'"—no more
- "'Though you be sought for, yet shall you never be found'"—never found

**Modern Equivalent:** Ezekiel 26 prophesies Tyre's destruction. Nebuchadnezzar besieged mainland Tyre for 13 years (585-572 BCE). Alexander's siege (332 BCE) fulfilled the "stones/timber/dust into the sea" (26:12) when he built a causeway. "Bare rock for spreading nets" (26:14) describes Tyre today.

# Ezekiel 44: The Closed East Gate and Levitical Ordinances

*From the Hebrew: וַיָּשֶׁב אֹתִי דֶּרֶךְ שַׁעַר הַמִּקְדָּשׁ (Va-Yashev Oti Derekh Sha'ar Ha-Miqdash) — And He Brought Me Back by the Way of the Gate of the Sanctuary*

---

## The Closed East Gate (44:1-3)

**44:1** Then he brought me back the way of the outer gate of the sanctuary, which looks toward the east; and it was shut.

**44:2** And YHWH said unto me: "This gate shall be shut, it shall not be opened, neither shall any man enter in by it, for YHWH, the God of Israel, has entered in by it; therefore it shall be shut.

**44:3** "As for the prince, he shall sit therein as prince to eat bread before YHWH; he shall enter by the way of the porch of the gate, and shall go out by the way of the same."

---

## Rebuke for Past Abominations (44:4-9)

**44:4** Then he brought me the way of the north gate before the house; and I looked, and, behold, the glory of YHWH filled the house of YHWH; and I fell upon my face.

**44:5** And YHWH said unto me: "Son of man, mark well, and behold with your eyes, and hear with your ears all that I say unto you concerning all the ordinances of the house of YHWH, and all the laws thereof; and mark well the entering in of the house, with every going forth of the sanctuary.

**44:6** "And you shall say to the rebellious, even to the house of Israel: Thus says the Lord YHWH: O you house of Israel, let it suffice you of all your abominations,

**44:7** "In that you have brought in strangers, uncircumcised in heart and uncircumcised in flesh, to be in my sanctuary, to profane it, even my house, when you offer my bread, the fat and the blood, and they have broken my covenant, to add unto all your abominations.

**44:8** "And you have not kept the charge of my holy things; but you have set keepers of my charge in my sanctuary for yourselves.

**44:9** "Thus says the Lord YHWH: No stranger, uncircumcised in heart and uncircumcised in flesh, shall enter into my sanctuary, of any stranger that is among the children of Israel."

---

## The Levites' Punishment (44:10-14)

**44:10** "But the Levites, who went far from me, when Israel went astray, who went astray from me after their idols, they shall bear their iniquity.

**44:11** "Yet they shall be ministers in my sanctuary, having charge at the gates of the house, and ministering in the house; they shall slay the burnt-offering and the sacrifice for the people, and they shall stand before them to minister unto them.

**44:12** "Because they ministered unto them before their idols, and became a stumbling-block of iniquity unto the house of Israel; therefore have I lifted up my hand against them," says the Lord YHWH, "and they shall bear their iniquity.

**44:13** "And they shall not come near unto me, to minister unto me in the priest's office, nor to come near to any of my holy things, unto the things that are most holy; but they shall bear their shame, and their abominations which they have committed.

**44:14** "Yet will I make them keepers of the charge of the house, for all the service thereof, and for all that shall be done therein."

---

## The Zadokite Priests (44:15-31)

**44:15** "But the priests the Levites, the sons of Zadok, that kept the charge of my sanctuary when the children of Israel went astray from me, they shall come near to me to minister unto me; and they shall stand before me to offer unto me the fat and the blood," says the Lord YHWH;

**44:16** "They shall enter into my sanctuary, and they shall come near to my table, to minister unto me, and they shall keep my charge.

**44:17** "And it shall be that when they enter in at the gates of the inner court, they shall be clothed with linen garments; and no wool shall come upon them, while they minister in the gates of the inner court, and within.

**44:18** "They shall have linen turbans upon their heads, and shall have linen breeches upon their loins; they shall not gird themselves with any thing that causes sweat.

**44:19** "And when they go forth into the outer court, even into the outer court to the people, they shall put off their garments wherein they minister, and lay them in the holy chambers, and they shall put on other garments, that they sanctify not the people with their garments.

**44:20** "Neither shall they shave their heads, nor suffer their locks to grow long; they shall only poll their heads.

**44:21** "Neither shall any priest drink wine, when they enter into the inner court.

**44:22** "Neither shall they take for their wives a widow, or her that is put away; but they shall take virgins of the seed of the house of Israel, or a widow that is the widow of a priest.

**44:23** "And they shall teach my people the difference between the holy and the common, and cause them to discern between the unclean and the clean.

**44:24** "And in a controversy they shall stand to judge; according to my ordinances shall they judge it; and they shall keep my laws and my statutes in all my appointed seasons, and they shall hallow my sabbaths.

**44:25** "And they shall come near no dead person to defile themselves; but for father, or for mother, or for son, or for daughter, for brother, or for sister that has had no husband, they may defile themselves.

**44:26** "And after he is cleansed, they shall reckon unto him seven days.

**44:27** "And in the day that he goes into the sanctuary, into the inner court, to minister in the sanctuary, he shall offer his sin-offering," says the Lord YHWH.

**44:28** "And it shall be unto them for an inheritance: I am their inheritance; and you shall give them no possession in Israel: I am their possession.

**44:29** "The meal-offering, and the sin-offering, and the guilt-offering, they shall eat; and every devoted thing in Israel shall be theirs.

**44:30** "And the first of all the first-fruits of every thing, and every heave-offering of every thing, of all your offerings, shall be for the priests; you shall also give unto the priest the first of your dough, to cause a blessing to rest on your house.

**44:31** "The priests shall not eat of any thing that dies of itself, or is torn, whether it be fowl or beast."

---

## Synthesis Notes

**Key Restorations:**

**Closed East Gate (44:1-3):**
**The Key Verses (44:1-2):**
"He brought me back the way of the outer gate of the sanctuary, which looks toward the east."

*Va-yashev oti derekh sha'ar ha-miqdash ha-chitzon ha-poneh qadim*—east gate.

"It was shut."

*Ve-hu sagur*—shut.

"'This gate shall be shut, it shall not be opened.'"

*Ha-sha'ar ha-zeh sagur yihyeh lo yippate'ach*—remain shut.

"'Neither shall any man enter in by it.'"

*Ve-ish lo-yavo vo*—none enter.

"'For YHWH, the God of Israel, has entered in by it.'"

*Ki YHWH Elohei-Yisra'el ba vo*—YHWH entered.

"'Therefore it shall be shut.'"

*Ve-hayah sagur*—shut.

**The Key Verse (44:3):**
"'As for the prince, he shall sit therein as prince to eat bread before YHWH.'"

*Et-ha-nasi nasi hu yeshev-bo le'ekhol lechem lifnei YHWH*—prince eats.

"'He shall enter by the way of the porch of the gate.'"

*Mi-derekh ulam ha-sha'ar yavo*—via porch.

"'Shall go out by the way of the same.'"

*U-mi-darko yetze*—same way out.

**East Gate:**
Closed because YHWH's glory entered through it. The prince uses the porch.

**Rebuke (44:4-9):**
"I looked, and, behold, the glory of YHWH filled the house."

*Va-ere ve-hinneh male khevod-YHWH et-beit YHWH*—glory fills.

"'Mark well, and behold with your eyes, and hear with your ears.'"

*Sim libbeka u-re'eh ve-einekha u-ve-oznekha shema*—pay attention.

"'All the ordinances of the house of YHWH, and all the laws thereof.'"

*Le-khol-chuqqot beit-YHWH u-le-khol-torotav*—ordinances, laws.

"'O you house of Israel, let it suffice you of all your abominations.'"

*Rav-lakhem mi-kol-to'avoteikhem beit Yisra'el*—enough abominations.

"'You have brought in strangers, uncircumcised in heart and uncircumcised in flesh.'"

*Ba-havi'akhem benei-nekhar arlei-lev va-arlei basar*—uncircumcised strangers.

"'To be in my sanctuary, to profane it.'"

*Li-heyot be-miqdashi le-chalelo*—profane sanctuary.

"'When you offer my bread, the fat and the blood.'"

*Be-haqriבkhem et-lachmi chelev va-dam*—my bread.

"'They have broken my covenant.'"

*Va-yaferu et-beriti*—broken covenant.

"'You have not kept the charge of my holy things.'"

*Ve-lo shemartem mishmeret qodashay*—didn't keep charge.

"'No stranger, uncircumcised in heart and uncircumcised in flesh, shall enter into my sanctuary.'"

*Kol-ben-nekhar arel-lev va-arel basar lo yavo el-miqdashi*—none enter.

**Levites' Punishment (44:10-14):**
"'The Levites, who went far from me, when Israel went astray.'"

*Ve-ha-Leviyyim asher rachqu me-alai bi-te'ot Yisra'el*—went astray.

"'Who went astray from me after their idols.'"

*Asher ta'u me-alai acharei gilluleihem*—followed idols.

"'They shall bear their iniquity.'"

*Ve-nas'u avonam*—bear iniquity.

"'They shall be ministers in my sanctuary.'"

*Ve-hayu be-miqdashi mesharetim*—ministers.

"'Having charge at the gates of the house.'"

*Pequddot el-sha'arei ha-bayit*—gate keepers.

"'Ministering in the house.'"

*U-mesharetim et-ha-bayit*—serve house.

"'They shall slay the burnt-offering and the sacrifice for the people.'"

*Hemmah yishchatu et-ha-olah ve-et-ha-zevach la-am*—slay offerings.

"'They shall stand before them to minister unto them.'"

*Ve-hemmah ya'amdu lifneihem le-shartem*—stand before people.

"'They ministered unto them before their idols.'"

*Ya'an asher yesharetu otam lifnei gilluleihem*—served idols.

"'Became a stumbling-block of iniquity.'"

*Va-yihyu le-veit Yisra'el le-mikhshol avon*—stumbling-block.

"'They shall not come near unto me, to minister unto me in the priest's office.'"

*Ve-lo-yiggashu elai le-khahεn li*—not near.

"'Nor to come near to any of my holy things.'"

*Ve-laggeshet al-kol-qodashay*—not holy things.

"'But they shall bear their shame.'"

*Ve-nas'u kelimmatam*—bear shame.

"'Yet will I make them keepers of the charge of the house.'"

*Ve-natatti otam shomerei mishmeret ha-bayit*—keepers.

**Zadokite Priests (44:15-31):**
"'The priests the Levites, the sons of Zadok.'"

*Ve-ha-kohanim ha-Leviyyim benei Tzadoq*—sons of Zadok.

"'That kept the charge of my sanctuary when... Israel went astray.'"

*Asher shameru et-mishmeret miqdashi bi-te'ot benei-Yisra'el me-alai*—kept charge.

"'They shall come near to me to minister unto me.'"

*Hemmah yiqrevu elai le-shareteni*—come near.

"'They shall stand before me to offer unto me the fat and the blood.'"

*Ve-amdu lefanai le-haqriv li chelev va-dam*—offer fat, blood.

"'They shall enter into my sanctuary.'"

*Hemmah yavo'u el-miqdashi*—enter sanctuary.

"'They shall come near to my table.'"

*Ve-el-shulchani yiqrevu*—near table.

"'When they enter... at the gates of the inner court, they shall be clothed with linen garments.'"

*Ve-hayah be-vo'am el-sha'arei he-chatzer ha-penimit bigdei fishtim yilbashu*—linen.

"'No wool shall come upon them.'"

*Ve-lo-ya'aleh aleihem tzemer*—no wool.

"'They shall have linen turbans upon their heads.'"

*Pa'arei fishtim yihyu al-rosham*—linen turbans.

"'Linen breeches upon their loins.'"

*U-mikhnesei fishtim yihyu al-motneihem*—linen breeches.

"'They shall not gird themselves with any thing that causes sweat.'"

*Lo yachgeru ba-yaza*—no sweat.

"'When they go forth into the outer court... to the people.'"

*U-ve-tzeitam el-he-chatzer ha-chitzonah... el-ha-am*—to people.

"'They shall put off their garments wherein they minister.'"

*Yifshetu et-bigdeihem asher-hemmah mesharetim bam*—put off.

"'Lay them in the holy chambers.'"

*Ve-hinnichu otam be-lishkhot ha-qodesh*—lay in chambers.

"'Put on other garments.'"

*Ve-lavshu begadim acherim*—other garments.

"'That they sanctify not the people with their garments.'"

*Ve-lo-yeqadeshu et-ha-am be-vigdeihem*—not sanctify people.

"'Neither shall they shave their heads.'"

*Ve-rosham lo yegallechu*—not shave.

"'Nor suffer their locks to grow long.'"

*U-fera lo yeshallchu*—not long.

"'They shall only poll their heads.'"

*Kasom yikesemu et-rasheihem*—trim.

"'Neither shall any priest drink wine, when they enter into the inner court.'"

*Ve-yayin lo-yishtu kol-kohen be-vo'am el-he-chatzer ha-penimit*—no wine.

"'Neither shall they take for their wives a widow, or her that is put away.'"

*Ve-almanah u-gerushah lo-yiqchu lahem le-nashim*—no widow, divorcee.

"'But they shall take virgins of the seed of the house of Israel.'"

*Ki im-betulot mi-zera beit Yisra'el yiqachu*—virgins of Israel.

"'Or a widow that is the widow of a priest.'"

*Ve-ha-almanah asher tihyeh almanah mi-kohen yiqachu*—or priest's widow.

"'They shall teach my people the difference between the holy and the common.'"

*Ve-et-ammi yoru bein-qodesh le-chol*—teach holy/common.

"'Cause them to discern between the unclean and the clean.'"

*U-vein-tame le-tahor yodi'um*—discern clean/unclean.

"'In a controversy they shall stand to judge.'"

*Ve-al-riv hemmah ya'amdu le-mishpat*—judge disputes.

"'According to my ordinances shall they judge it.'"

*Be-mishpatai yishputuhu*—by ordinances.

"'They shall keep my laws and my statutes in all my appointed seasons.'"

*Ve-et-torotai ve-et-chuqqotai be-khol-mo'adai yishmoru*—keep laws.

"'They shall hallow my sabbaths.'"

*Ve-et-shabbtotai yeqaddeshu*—hallow sabbaths.

"'They shall come near no dead person to defile themselves.'"

*Ve-el-met adam lo yavo le-tom'ah*—no dead.

"'But for father, or for mother, or for son, or for daughter.'"

*Ki im-le-av u-le-em u-le-ven u-le-vat*—except close family.

"'For brother, or for sister that has had no husband.'"

*Le-ach u-le-achot asher-lo hayetah le-ish*—unmarried sister.

"'They may defile themselves.'"

*Yittamma'u*—may defile.

"'After he is cleansed, they shall reckon unto him seven days.'"

*Ve-acharei tohוrato shiv'at yamim yiseferu-lo*—seven days after.

"'In the day that he goes into the sanctuary... he shall offer his sin-offering.'"

*U-ve-yom bo'o el-ha-qodesh... yaqriv chattato*—sin offering.

"'It shall be unto them for an inheritance: I am their inheritance.'"

*Ve-hayetah lahem le-nachalah ani nachalatam*—I am inheritance.

"'You shall give them no possession in Israel.'"

*Va-achuzzah lo-tittenu lahem be-Yisra'el*—no possession.

"'I am their possession.'"

*Ani achuzzatam*—I am possession.

"'The meal-offering, and the sin-offering, and the guilt-offering, they shall eat.'"

*Ha-minchah ve-ha-chattat ve-ha-asham hemmah yokhelum*—eat offerings.

"'Every devoted thing in Israel shall be theirs.'"

*Ve-khol-cherem be-Yisra'el lahem yihyeh*—devoted things.

"'The first of all the first-fruits... shall be for the priests.'"

*Ve-reshit kol-bikkurei khol... la-kohanim yihyeh*—firstfruits.

"'Give unto the priest the first of your dough.'"

*Ve-reshit arisoteikhem tittenu la-kohen*—first dough.

"'To cause a blessing to rest on your house.'"

*Le-hani'ach berakhah el-beiteka*—blessing on house.

"'The priests shall not eat of any thing that dies of itself, or is torn.'"

*Kol-nevelah u-terefah min-ha-of u-min-ha-behemah lo yokhelu ha-kohanim*—no carcass.

**Archetypal Layer:** Ezekiel 44 contains **the closed east gate (44:1-3)**, **"This gate shall be shut... for YHWH, the God of Israel, has entered in by it" (44:2)**, **rebuke for admitting uncircumcised strangers (44:6-9)**, **Levites demoted for past idolatry (44:10-14)**, **Zadokite priests elevated (44:15-16)**, **priestly dress regulations (44:17-19)**, **"They shall teach my people the difference between the holy and the common" (44:23)**, and **"I am their inheritance" (44:28)**.

**Ethical Inversion Applied:**
- "He brought me back the way of the outer gate... which looks toward the east"—east gate
- "It was shut"—shut
- "'This gate shall be shut, it shall not be opened'"—permanently
- "'For YHWH, the God of Israel, has entered in by it'"—YHWH entered
- "'As for the prince, he shall sit therein as prince'"—prince
- "'To eat bread before YHWH'"—eat before YHWH
- "The glory of YHWH filled the house"—glory fills
- "'Mark well... all the ordinances of the house of YHWH'"—pay attention
- "'Let it suffice you of all your abominations'"—enough
- "'You have brought in strangers, uncircumcised in heart'"—uncircumcised
- "'To be in my sanctuary, to profane it'"—profaned
- "'They have broken my covenant'"—broken
- "'You have not kept the charge of my holy things'"—didn't keep
- "'No stranger... shall enter into my sanctuary'"—none
- "'The Levites, who went far from me'"—Levites astray
- "'They shall bear their iniquity'"—bear iniquity
- "'They shall be ministers... having charge at the gates'"—gate keepers
- "'They shall slay the burnt-offering'"—slay offerings
- "'They ministered unto them before their idols'"—served idols
- "'Became a stumbling-block'"—stumbling-block
- "'They shall not come near unto me'"—not near
- "'They shall bear their shame'"—bear shame
- "'The sons of Zadok, that kept the charge of my sanctuary'"—Zadokites faithful
- "'They shall come near to me to minister'"—come near
- "'They shall stand before me to offer'"—stand before
- "'They shall be clothed with linen garments'"—linen
- "'No wool shall come upon them'"—no wool
- "'They shall put off their garments... put on other garments'"—change
- "'That they sanctify not the people with their garments'"—not transfer holiness
- "'Neither shall they shave their heads'"—not shave
- "'They shall only poll their heads'"—trim
- "'Neither shall any priest drink wine'"—no wine
- "'Neither shall they take for their wives a widow'"—no widow
- "'They shall take virgins of the seed of... Israel'"—virgins
- "'They shall teach my people the difference between the holy and the common'"—teach
- "'Cause them to discern between the unclean and the clean'"—discern
- "'In a controversy they shall stand to judge'"—judge
- "'They shall hallow my sabbaths'"—sabbaths
- "'They shall come near no dead person'"—no dead
- "'But for father, or for mother'"—except close family
- "'After he is cleansed, they shall reckon unto him seven days'"—seven days
- "'He shall offer his sin-offering'"—sin offering
- "'I am their inheritance'"—YHWH is inheritance
- "'You shall give them no possession in Israel'"—no land
- "'I am their possession'"—YHWH is possession
- "'They shall eat'"—eat offerings
- "'Give unto the priest the first of your dough'"—first dough
- "'The priests shall not eat of any thing that dies of itself'"—no carcass

**Modern Equivalent:** Ezekiel 44 distinguishes two priestly groups. Levites are demoted to temple servants for past idolatry; Zadokites alone serve at the altar. The closed east gate (through which YHWH entered) emphasizes the permanence of YHWH's presence. "I am their inheritance" (44:28) means priests own no land—YHWH is their portion.

# Ezekiel 18: Individual Responsibility

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## The Proverb Rejected (18:1-4)

**18:1** And the word of YHWH came unto me, saying:

**18:2** "What mean you, that you use this proverb in the land of Israel, saying: 'The fathers have eaten sour grapes, and the children's teeth are set on edge'?

**18:3** "As I live," says the Lord YHWH, "you shall not have occasion any more to use this proverb in Israel.

**18:4** "Behold, all souls are mine; as the soul of the father, so also the soul of the son is mine; the soul that sins, it shall die."

---

## The Righteous Father (18:5-9)

**18:5** "But if a man be just, and do that which is lawful and right,

**18:6** "And has not eaten upon the mountains, neither has lifted up his eyes to the idols of the house of Israel, neither has defiled his neighbor's wife, neither has come near to a woman in her impurity;

**18:7** "And has not wronged any, but has restored to the debtor his pledge, has taken nought by robbery, has given his bread to the hungry, and has covered the naked with a garment;

**18:8** "He that has not given forth upon interest, neither has taken any increase, that has withdrawn his hand from iniquity, has executed true justice between man and man,

**18:9** "Has walked in my statutes, and has kept my ordinances, to deal truly; he is just, he shall surely live," says the Lord YHWH.

---

## The Wicked Son (18:10-13)

**18:10** "If he beget a son that is a robber, a shedder of blood, and that does to a brother any of these things,

**18:11** "Whereas he himself had not done any of these things, for he has even eaten upon the mountains, and defiled his neighbor's wife,

**18:12** "Has wronged the poor and needy, has taken by robbery, has not restored the pledge, and has lifted up his eyes to the idols, has committed abomination,

**18:13** "Has given forth upon interest, and has taken increase; shall he then live? He shall not live—he has done all these abominations; he shall surely die; his blood shall be upon him."

---

## The Righteous Grandson (18:14-18)

**18:14** "Now, lo, if he beget a son, that sees all his father's sins, which he has done, and fears, and does not such like,

**18:15** "That has not eaten upon the mountains, neither has lifted up his eyes to the idols of the house of Israel, has not defiled his neighbor's wife,

**18:16** "Neither has wronged any, has not taken aught to pledge, neither has taken by robbery, but has given his bread to the hungry, and has covered the naked with a garment,

**18:17** "That has withdrawn his hand from the poor, that has not received interest nor increase, has executed my ordinances, has walked in my statutes; he shall not die for the iniquity of his father, he shall surely live.

**18:18** "As for his father, because he cruelly oppressed, committed robbery on a brother, and did that which is not good among his people, behold, he dies for his iniquity."

---

## The Principle Stated (18:19-24)

**18:19** "Yet say you: 'Why does not the son bear the iniquity of the father?' When the son has done that which is lawful and right, and has kept all my statutes, and has done them, he shall surely live.

**18:20** "The soul that sins, it shall die; the son shall not bear the iniquity of the father, neither shall the father bear the iniquity of the son; the righteousness of the righteous shall be upon him, and the wickedness of the wicked shall be upon him.

**18:21** "But if the wicked turn from all his sins that he has committed, and keep all my statutes, and do that which is lawful and right, he shall surely live, he shall not die.

**18:22** "None of his transgressions that he has committed shall be remembered against him; for his righteousness that he has done he shall live.

**18:23** "Have I any pleasure at all that the wicked should die?" says the Lord YHWH; "and not rather that he should return from his way, and live?

**18:24** "But when the righteous turns away from his righteousness, and commits iniquity, and does according to all the abominations that the wicked man does, shall he live? None of his righteous deeds that he has done shall be remembered; for his trespass that he has trespassed, and for his sin that he has sinned, for them shall he die."

---

## Defense of Divine Justice (18:25-32)

**18:25** "Yet you say: 'The way of the Lord is not equal.' Hear now, O house of Israel: Is it not my way that is equal? Are not your ways unequal?

**18:26** "When the righteous man turns away from his righteousness, and commits iniquity, and dies therein, for his iniquity that he has done shall he die.

**18:27** "Again, when the wicked man turns away from his wickedness that he has committed, and does that which is lawful and right, he shall save his soul alive.

**18:28** "Because he considers, and turns away from all his transgressions that he has committed, he shall surely live, he shall not die.

**18:29** "Yet says the house of Israel: 'The way of the Lord is not equal.' O house of Israel, are not my ways equal? Are not your ways unequal?

**18:30** "Therefore I will judge you, O house of Israel, every one according to his ways," says the Lord YHWH. "Return, and turn yourselves from all your transgressions; so shall they not be a stumbling-block of iniquity unto you.

**18:31** "Cast away from you all your transgressions, wherein you have transgressed; and make you a new heart and a new spirit; for why will you die, O house of Israel?

**18:32** "For I have no pleasure in the death of him that dies," says the Lord YHWH; "wherefore turn yourselves, and live."

---

## Synthesis Notes

**Key Restorations:**

**Proverb Rejected (18:1-4):**
**The Key Verse (18:2):**
"''The fathers have eaten sour grapes, and the children's teeth are set on edge.''"

*Avot akhelu voser ve-shinnei ha-banim tiqhenah*—sour grapes proverb.

**The Proverb:**
Also in Jeremiah 31:29—the exiles blamed their ancestors for their suffering.

**The Key Verse (18:3):**
"''As I live,' says the Lord YHWH."

*Chai-ani ne'um Adonai YHWH*—as I live.

"'You shall not have occasion any more to use this proverb in Israel.'"

*Im-yihyeh lakhem od meshol ha-mashal ha-zeh be-Yisra'el*—no more use.

**The Key Verse (18:4):**
"'Behold, all souls are mine.'"

*Hen kol-ha-nefashot li hennah*—all souls mine.

"'As the soul of the father, so also the soul of the son is mine.'"

*Ke-nefesh ha-av u-khe-nefesh ha-ben li-hennah*—both mine.

"'The soul that sins, it shall die.'"

*Ha-nefesh ha-chotet hi tamut*—sinning soul dies.

**Righteous Father (18:5-9):**
"'If a man be just, and do that which is lawful and right.'"

*Ve-ish ki-yihyeh tzaddiq ve-asah mishpat u-tzdaqah*—just man.

**The Key Verses (18:6-8) — Criteria of Righteousness:**
"'Has not eaten upon the mountains.'"

*El-he-harim lo akhal*—no mountain shrines.

"'Neither has lifted up his eyes to the idols.'"

*Ve-einav lo nasa el-gillulei beit Yisra'el*—no idol worship.

"'Neither has defiled his neighbor's wife.'"

*Ve-et-eshet re'ehu lo timme*—no adultery.

"'Neither has come near to a woman in her impurity.'"

*Ve-el-ishah niddah lo yiqrav*—ritual purity.

"'Has not wronged any.'"

*Ve-ish lo yoneh*—no oppression.

"'Has restored to the debtor his pledge.'"

*Chavolato chov yashiv*—returns pledges.

"'Has taken nought by robbery.'"

*Gezelah lo yigzol*—no robbery.

"'Has given his bread to the hungry.'"

*Lachmo le-ra'ev yitten*—feeds hungry.

"'Has covered the naked with a garment.'"

*Ve-eirom yekhasseh vaged*—clothes naked.

"'Has not given forth upon interest.'"

*Ba-neshekh lo yitten*—no usury.

"'Neither has taken any increase.'"

*Ve-tarbit lo yiqqach*—no interest.

"'Has withdrawn his hand from iniquity.'"

*Me-avel yashiv yado*—withdraws from evil.

"'Has executed true justice between man and man.'"

*Mishpat emet ya'aseh bein ish le-ish*—true justice.

"'Has walked in my statutes.'"

*Be-chuqqotai yehalekh*—walks in statutes.

"'Has kept my ordinances.'"

*U-mishpatai shamar*—keeps ordinances.

**The Key Verse (18:9):**
"'He is just, he shall surely live.'"

*Tzaddiq hu chayoh yichyeh*—lives.

**Wicked Son (18:10-13):**
"'If he beget a son that is a robber, a shedder of blood.'"

*Ve-holid ben paritz shofekh dam*—robber, bloodshed.

"'He has even eaten upon the mountains.'"

*Ve-et-achot me-elleh lo asah ki gam el-he-harim akhal*—ate on mountains.

"'Has wronged the poor and needy.'"

*Ani ve-evyon honah*—oppressed poor.

"'Has taken by robbery.'"

*Gezelot gazal*—robbed.

"'Has not restored the pledge.'"

*Chabol lo heshiv*—kept pledge.

"'Has given forth upon interest.'"

*U-va-neshekh natan*—charged interest.

**The Key Verse (18:13):**
"'He shall not live... he shall surely die; his blood shall be upon him.'"

*Ve-chai lo yichyeh... mot yumat damav bo yihyeh*—dies.

**Righteous Grandson (18:14-18):**
"'If he beget a son, that sees all his father's sins... and fears, and does not such like.'"

*Ve-holid ben va-yar et-kol-chattot aviv asher asah va-yir'eh ve-lo ya'aseh kahen*—sees, fears, doesn't do.

**The Key Verse (18:17):**
"'He shall not die for the iniquity of his father, he shall surely live.'"

*Ba-avon aviv lo yamut chayoh yichyeh*—doesn't die for father.

**Principle Stated (18:19-24):**
**The Key Verse (18:20):**
"'The soul that sins, it shall die.'"

*Ha-nefesh ha-chotet hi tamut*—sinning soul dies.

"'The son shall not bear the iniquity of the father.'"

*Ben lo-yissa ba-avon ha-av*—son doesn't bear father's.

"'Neither shall the father bear the iniquity of the son.'"

*Ve-av lo yissa ba-avon ha-ben*—father doesn't bear son's.

"'The righteousness of the righteous shall be upon him.'"

*Tzidqat ha-tzaddiq alav tihyeh*—righteousness on righteous.

"'The wickedness of the wicked shall be upon him.'"

*Ve-rish'at rasha alav tihyeh*—wickedness on wicked.

**The Key Verses (18:21-22):**
"'If the wicked turn from all his sins.'"

*Ve-ha-rasha ki yashuv mi-kol-chattotav*—if wicked turns.

"'And keep all my statutes, and do that which is lawful and right.'"

*Ve-shamar et-kol-chuqqotai ve-asah mishpat u-tzdaqah*—keeps statutes.

"'He shall surely live, he shall not die.'"

*Chayoh yichyeh lo yamut*—lives.

"'None of his transgressions that he has committed shall be remembered against him.'"

*Kol-pesha'av asher asah lo yizzakheru lo*—not remembered.

**The Key Verse (18:23):**
"'Have I any pleasure at all that the wicked should die?'"

*He-chafetz echpots mot rasha*—pleasure in death?

"'And not rather that he should return from his way, and live?'"

*Ha-lo be-shuvo mi-derakhav ve-chayah*—return and live.

**The Key Verse (18:24):**
"'When the righteous turns away from his righteousness, and commits iniquity.'"

*U-ve-shuv tzaddiq mi-tzidqato ve-asah avel*—righteous turns.

"'None of his righteous deeds that he has done shall be remembered.'"

*Kol-tzidqotav asher-asah lo tizzakharnah*—not remembered.

"'For his trespass that he has trespassed... for them shall he die.'"

*Be-ma'alo asher-ma'al u-ve-chattato asher-chata bam yamut*—dies.

**Divine Justice (18:25-32):**
**The Key Verse (18:25):**
"''The way of the Lord is not equal.''"

*Lo yittakhen derekh Adonai*—not equal.

"'Is it not my way that is equal?'"

*Ha-lo derakhай yittakhen*—my way equal.

"'Are not your ways unequal?'"

*Ha-lo darkheikhem lo yittakhenu*—your ways unequal.

**The Key Verses (18:30-31):**
"'I will judge you, O house of Israel, every one according to his ways.'"

*Ish ki-derakhav eshpot etkhem beit Yisra'el*—judge by ways.

"'Return, and turn yourselves from all your transgressions.'"

*Shuvu ve-hashivu mi-kol-pish'eikhem*—return.

"'So shall they not be a stumbling-block of iniquity unto you.'"

*Ve-lo-yihyeh lakhem le-mikhshol avon*—no stumbling-block.

"'Cast away from you all your transgressions.'"

*Hashlikhu me-aleikhem et-kol-pish'eikhem*—cast away.

"'Make you a new heart and a new spirit.'"

*Va-asu lakhem lev chadash ve-ruach chadashah*—new heart, spirit.

"'For why will you die, O house of Israel?'"

*Ve-lammah tamutu beit Yisra'el*—why die?

**The Key Verse (18:32):**
"'I have no pleasure in the death of him that dies.'"

*Ki lo echpots be-mot ha-met*—no pleasure in death.

"'Wherefore turn yourselves, and live.'"

*Ve-hashivu vi-cheyu*—turn and live.

**Archetypal Layer:** Ezekiel 18 establishes **individual responsibility**, containing **"The fathers have eaten sour grapes, and the children's teeth are set on edge" (18:2)**—rejected, **"The soul that sins, it shall die" (18:4, 20)**, **"The son shall not bear the iniquity of the father" (18:20)**, **"Have I any pleasure at all that the wicked should die?... return from his way, and live" (18:23)**, and **"Make you a new heart and a new spirit" (18:31)**.

**Ethical Inversion Applied:**
- "''The fathers have eaten sour grapes''"—proverb rejected
- "'You shall not have occasion any more to use this proverb'"—no more
- "'All souls are mine'"—all souls YHWH's
- "'The soul that sins, it shall die'"—individual responsibility
- "'If a man be just, and do that which is lawful and right'"—righteous criteria
- "'Has not eaten upon the mountains'"—no shrine worship
- "'Has not lifted up his eyes to the idols'"—no idols
- "'Has not defiled his neighbor's wife'"—no adultery
- "'Has not wronged any'"—no oppression
- "'Has restored to the debtor his pledge'"—returns pledges
- "'Has given his bread to the hungry'"—feeds hungry
- "'Has covered the naked with a garment'"—clothes naked
- "'Has not given forth upon interest'"—no usury
- "'He is just, he shall surely live'"—lives
- "'If he beget a son that is a robber'"—wicked son
- "'He shall not live... he shall surely die'"—dies
- "'If he beget a son, that sees all his father's sins... and fears'"—righteous grandson
- "'He shall not die for the iniquity of his father'"—not for father
- "'The son shall not bear the iniquity of the father'"—no corporate guilt
- "'Neither shall the father bear the iniquity of the son'"—individual
- "'If the wicked turn from all his sins'"—repentance possible
- "'He shall surely live, he shall not die'"—lives
- "'None of his transgressions... shall be remembered'"—not remembered
- "'Have I any pleasure at all that the wicked should die?'"—no pleasure
- "'Not rather that he should return from his way, and live?'"—return and live
- "'When the righteous turns away from his righteousness'"—apostasy
- "'None of his righteous deeds... shall be remembered'"—not remembered
- "''The way of the Lord is not equal''"—challenged
- "'Is it not my way that is equal?'"—YHWH's way equal
- "'I will judge you... every one according to his ways'"—individual judgment
- "'Return, and turn yourselves from all your transgressions'"—call to return
- "'Make you a new heart and a new spirit'"—new heart
- "'Why will you die, O house of Israel?'"—why die?
- "'I have no pleasure in the death of him that dies'"—no pleasure
- "'Turn yourselves, and live'"—turn and live

**Modern Equivalent:** Ezekiel 18 is foundational for individual responsibility. Against fatalistic determinism ("our ancestors' sin dooms us"), YHWH insists each person is judged by their own conduct. The chapter allows for both repentance and apostasy—past righteousness doesn't guarantee future, past wickedness doesn't prevent change.

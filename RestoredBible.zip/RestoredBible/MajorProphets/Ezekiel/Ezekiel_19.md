# Ezekiel 19: A Lament for the Princes of Israel

*From the Hebrew: וְאַתָּה שָׂא קִינָה (Ve-Attah Sa Qinah) — And You, Take Up a Lament*

---

## The Lioness and Her Cubs (19:1-9)

**19:1** Moreover, take up a lamentation for the princes of Israel,

**19:2** And say: What was your mother? A lioness; among lions she couched, in the midst of young lions she reared her whelps.

**19:3** And she brought up one of her whelps, he became a young lion; and he learned to catch the prey, he devoured men.

**19:4** Then the nations assembled against him, he was taken in their pit; and they brought him with hooks unto the land of Egypt.

**19:5** Now when she saw that she had waited, and her hope was lost, then she took another of her whelps, and made him a young lion.

**19:6** And he went up and down among the lions, he became a young lion; and he learned to catch the prey, he devoured men.

**19:7** And he knew their castles, and laid waste their cities; and the land was desolate, and the fulness thereof, because of the noise of his roaring.

**19:8** Then the nations set against him on every side from the provinces; and they spread their net over him, he was taken in their pit.

**19:9** And they put him in a cage with hooks, and brought him to the king of Babylon; they brought him into strongholds, that his voice should no more be heard upon the mountains of Israel.

---

## The Vine Uprooted (19:10-14)

**19:10** Your mother was like a vine, in your likeness, planted by the waters; she was fruitful and full of branches by reason of many waters.

**19:11** And she had strong rods for scepters of them that bore rule; and her stature was exalted among the thick branches, and she was seen in her height with the multitude of her tendrils.

**19:12** But she was plucked up in fury, she was cast down to the ground, and the east wind dried up her fruit; her strong rods were broken off and withered, the fire consumed them.

**19:13** And now she is planted in the wilderness, in a dry and thirsty ground.

**19:14** And fire is gone out of the rod of her branches, it has devoured her fruit, so that there is in her no strong rod to be a scepter to rule. This is a lamentation, and it has become a lamentation.

---

## Synthesis Notes

**Key Restorations:**

**Lioness and Cubs (19:1-9):**
**The Key Verse (19:1):**
"Take up a lamentation for the princes of Israel."

*Sa qinah el-nesi'ei Yisra'el*—lament for princes.

**Qinah:**
A funeral lament—distinctive 3:2 poetic meter.

**The Key Verse (19:2):**
"'What was your mother? A lioness.'"

*Mah immekha leviyyah*—mother a lioness.

"'Among lions she couched.'"

*Bein arayot ravatzah*—among lions.

"'In the midst of young lions she reared her whelps.'"

*Be-tokh kefirim ribbetah gurekha*—reared cubs.

**Lioness = Judah:**
The royal house as a lioness (cf. Genesis 49:9).

**The Key Verses (19:3-4) — First Cub:**
"'She brought up one of her whelps, he became a young lion.'"

*Va-ta'al echad mi-gureha kefir hayah*—became lion.

"'He learned to catch the prey, he devoured men.'"

*Va-yilmad litrof-teref adam akhal*—devoured men.

"'The nations assembled against him.'"

*Va-yishme'u elav goyim*—nations heard.

"'He was taken in their pit.'"

*Be-shachatam nitpas*—caught in pit.

"'They brought him with hooks unto the land of Egypt.'"

*Va-yevi'uhu ba-chachim el-eretz Mitzrayim*—to Egypt.

**First Cub = Jehoahaz:**
Taken to Egypt by Pharaoh Neco (609 BCE, 2 Kings 23:31-34).

**The Key Verses (19:5-7) — Second Cub:**
"'She saw that she had waited, and her hope was lost.'"

*Va-tere ki nochalah avdah tiqvatah*—hope lost.

"'She took another of her whelps, and made him a young lion.'"

*Va-tiqqach echad mi-gureha kefir samatthu*—another cub.

"'He went up and down among the lions.'"

*Va-yit'hallekh be-tokh arayot*—among lions.

"'He became a young lion.'"

*Kefir hayah*—became lion.

"'He learned to catch the prey, he devoured men.'"

*Va-yilmad litrof-teref adam akhal*—devoured men.

"'He knew their castles, and laid waste their cities.'"

*Va-yeda almenotav ve-areihem hecheriv*—laid waste.

"'The land was desolate... because of the noise of his roaring.'"

*Va-teshom eretz u-melo'ah mi-qol sha'agato*—roaring.

**Second Cub = Jehoiachin or Zedekiah:**
Most likely Jehoiachin, taken to Babylon (597 BCE).

**The Key Verses (19:8-9):**
"'The nations set against him on every side.'"

*Va-yittenu alav goyim mi-saviv mi-medinot*—nations against.

"'They spread their net over him.'"

*Va-yifres'u alav rishtam*—spread net.

"'He was taken in their pit.'"

*Be-shachatam nitpas*—caught.

"'They put him in a cage with hooks.'"

*Va-yittenuhu ba-sugar ba-chachim*—in cage.

"'Brought him to the king of Babylon.'"

*Va-yevi'uhu el-melekh Bavel*—to Babylon.

"'Brought him into strongholds.'"

*Yevi'uhu bi-metzadot*—strongholds.

"'That his voice should no more be heard upon the mountains of Israel.'"

*Lema'an lo-yisshama qolo od el-harei Yisra'el*—voice silenced.

**Vine Uprooted (19:10-14):**
**The Key Verse (19:10):**
"'Your mother was like a vine, in your likeness.'"

*Immekha ke-gefen be-damekha*—mother like vine.

"'Planted by the waters.'"

*Al-mayim shutalah*—by waters.

"'She was fruitful and full of branches by reason of many waters.'"

*Poriyyah va-anefah hayetah mi-mayim rabbim*—fruitful.

**The Key Verse (19:11):**
"'She had strong rods for scepters of them that bore rule.'"

*Va-yihyu-lah mattot oz el-shivtei moshelim*—strong rods/scepters.

"'Her stature was exalted among the thick branches.'"

*Va-tigbah qomato al-bein avotim*—exalted.

"'She was seen in her height with the multitude of her tendrils.'"

*Va-yera be-govho be-rov daliyyotav*—seen in height.

**Strong Rods = Kings:**
The Davidic rulers.

**The Key Verse (19:12):**
"'She was plucked up in fury.'"

*Va-tittash be-chemah*—plucked in fury.

"'She was cast down to the ground.'"

*La-aretz hushlakhah*—cast down.

"'The east wind dried up her fruit.'"

*Ve-ruach ha-qadim hovish piryah*—east wind dried.

"'Her strong rods were broken off and withered.'"

*Hitparequ ve-yavshu matteh uzzah*—rods broken.

"'The fire consumed them.'"

*Esh akhalathu*—fire consumed.

**East Wind = Babylon:**
Coming from the east to destroy.

**The Key Verses (19:13-14):**
"'Now she is planted in the wilderness.'"

*Ve-attah shutalah ba-midbar*—in wilderness.

"'In a dry and thirsty ground.'"

*Be-eretz tziyyah ve-tzama*—dry ground.

"'Fire is gone out of the rod of her branches.'"

*Va-tetze esh mi-matteh baddeyha*—fire from rod.

"'It has devoured her fruit.'"

*Piryah akhelah*—devoured fruit.

"'There is in her no strong rod to be a scepter to rule.'"

*Ve-lo-hayah bah matteh-oz shevet li-meshol*—no scepter.

"'This is a lamentation, and it has become a lamentation.'"

*Qinah hi va-tehi le-qinah*—is and became lament.

**No Scepter:**
The Davidic line appears ended.

**Archetypal Layer:** Ezekiel 19 is a **lament (*qinah*)**, containing **the lioness and her cubs (19:1-9)**, **first cub taken to Egypt (19:4)** = Jehoahaz, **second cub taken to Babylon (19:9)** = Jehoiachin, **the vine uprooted by the east wind (19:12)**, and **"there is in her no strong rod to be a scepter to rule" (19:14)**.

**Ethical Inversion Applied:**
- "Take up a lamentation for the princes of Israel"—lament
- "'What was your mother? A lioness'"—lioness
- "'Among lions she couched'"—among lions
- "'She reared her whelps'"—reared cubs
- "'She brought up one of her whelps, he became a young lion'"—first cub
- "'He learned to catch the prey, he devoured men'"—devoured
- "'The nations assembled against him'"—nations against
- "'He was taken in their pit'"—caught
- "'They brought him with hooks unto the land of Egypt'"—to Egypt
- "'She saw that she had waited, and her hope was lost'"—hope lost
- "'She took another of her whelps'"—second cub
- "'He became a young lion'"—became lion
- "'He knew their castles, and laid waste their cities'"—laid waste
- "'The land was desolate... because of the noise of his roaring'"—roaring
- "'The nations set against him on every side'"—nations against
- "'They spread their net over him'"—net
- "'He was taken in their pit'"—caught
- "'They put him in a cage with hooks'"—caged
- "'Brought him to the king of Babylon'"—to Babylon
- "'That his voice should no more be heard'"—silenced
- "'Your mother was like a vine'"—vine
- "'Planted by the waters'"—by waters
- "'She was fruitful and full of branches'"—fruitful
- "'She had strong rods for scepters'"—scepters
- "'Her stature was exalted'"—exalted
- "'She was plucked up in fury'"—plucked
- "'She was cast down to the ground'"—cast down
- "'The east wind dried up her fruit'"—east wind
- "'Her strong rods were broken off'"—broken
- "'The fire consumed them'"—fire consumed
- "'Now she is planted in the wilderness'"—wilderness
- "'In a dry and thirsty ground'"—dry
- "'Fire is gone out of the rod of her branches'"—fire from rod
- "'There is in her no strong rod to be a scepter to rule'"—no scepter
- "'This is a lamentation, and it has become a lamentation'"—is lament

**Modern Equivalent:** Ezekiel 19 mourns the end of the Davidic monarchy. The two cubs are Jehoahaz (to Egypt) and Jehoiachin (to Babylon). The vine section shows the dynasty uprooted. "No strong rod to be a scepter" (19:14) captures the tragedy—the line appears ended.

# Ezekiel 32: Lament Over Pharaoh and Egypt's Descent to Sheol

*From the Hebrew: וַיְהִי בִּשְׁתֵּי עֶשְׂרֵה שָׁנָה (Va-Yehi Bi-Shtei Esreh Shanah) — And It Came to Pass in the Twelfth Year*

---

## Lament Over Pharaoh (32:1-10)

**32:1** And it came to pass in the twelfth year, in the twelfth month, in the first day of the month, that the word of YHWH came unto me, saying:

**32:2** "Son of man, take up a lamentation for Pharaoh king of Egypt, and say unto him: You did liken yourself unto a young lion of the nations; whereas you are as a dragon in the seas; and you did burst forth with your rivers, and troubled the waters with your feet, and fouled their rivers.

**32:3** "Thus says the Lord YHWH: I will therefore spread out my net over you with a company of many peoples; and they shall bring you up in my net.

**32:4** "And I will cast you upon the land, I will hurl you upon the open field, and will cause all the fowls of the heaven to settle upon you, and I will fill the beasts of the whole earth with you.

**32:5** "And I will lay your flesh upon the mountains, and fill the valleys with your carcass.

**32:6** "I will also water with your blood the land wherein you swim, even to the mountains; and the watercourses shall be full of you.

**32:7** "And when I shall extinguish you, I will cover the heavens, and make the stars thereof black; I will cover the sun with a cloud, and the moon shall not give her light.

**32:8** "All the bright lights of heaven will I make black over you, and set darkness upon your land," says the Lord YHWH.

**32:9** "I will also vex the hearts of many peoples, when I shall bring your destruction among the nations, into the countries which you have not known.

**32:10** "Yea, I will make many peoples appalled at you, and their kings shall be horribly afraid for you, when I shall brandish my sword before them; and they shall tremble at every moment, every man for his own life, in the day of your fall."

---

## Egypt's Destruction by Babylon (32:11-16)

**32:11** For thus says the Lord YHWH: "The sword of the king of Babylon shall come upon you.

**32:12** "By the swords of the mighty will I cause your multitude to fall; the terrible of the nations are they all; and they shall spoil the pride of Egypt, and all the multitude thereof shall be destroyed.

**32:13** "I will destroy also all the beasts thereof from beside many waters; neither shall the foot of man trouble them any more, nor the hoofs of beasts trouble them.

**32:14** "Then will I make their waters clear, and cause their rivers to run like oil," says the Lord YHWH.

**32:15** "When I shall make the land of Egypt desolate and waste, a land destitute of that whereof it was full, when I shall smite all them that dwell therein, then shall they know that I am YHWH.

**32:16** "This is the lamentation wherewith they shall lament; the daughters of the nations shall lament therewith; for Egypt, and for all her multitude, shall they lament therewith," says the Lord YHWH.

---

## Egypt's Descent to Sheol (32:17-32)

**32:17** It came to pass also in the twelfth year, in the fifteenth day of the month, that the word of YHWH came unto me, saying:

**32:18** "Son of man, wail for the multitude of Egypt, and cast them down, even her, and the daughters of the famous nations, unto the nether parts of the earth, with them that go down into the pit.

**32:19** "'Whom do you pass in beauty? Go down, and be laid with the uncircumcised.'

**32:20** "They shall fall in the midst of them that are slain by the sword; she is delivered to the sword; draw her down and all her multitudes.

**32:21** "The strong among the mighty shall speak to him out of the midst of Sheol with them that help him; they are gone down, they lie uncircumcised, slain by the sword.

**32:22** "Asshur is there and all her company; their graves are round about him; all of them slain, fallen by the sword;

**32:23** "Whose graves are set in the uttermost parts of the pit, and her company is round about her grave; all of them slain, fallen by the sword, who caused terror in the land of the living.

**32:24** "There is Elam and all her multitude round about her grave; all of them slain, fallen by the sword, who are gone down uncircumcised into the nether parts of the earth, who caused their terror in the land of the living, and have borne their shame with them that go down to the pit.

**32:25** "They have set her a bed in the midst of the slain with all her multitude; her graves are round about him; all of them uncircumcised, slain by the sword; for their terror was caused in the land of the living, and they have borne their shame with them that go down to the pit; they are put in the midst of them that are slain.

**32:26** "There is Meshech, Tubal, and all her multitude; her graves are round about him; all of them uncircumcised, slain by the sword; for they caused their terror in the land of the living.

**32:27** "And they shall not lie with the mighty that are fallen of the uncircumcised, that are gone down to Sheol with their weapons of war, and have laid their swords under their heads, and their iniquities are upon their bones; for they were the terror of the mighty in the land of the living.

**32:28** "But you shall be broken in the midst of the uncircumcised, and shall lie with them that are slain by the sword.

**32:29** "There is Edom, her kings and all her princes, who for all their might are laid with them that are slain by the sword; they shall lie with the uncircumcised, and with them that go down to the pit.

**32:30** "There are the princes of the north, all of them, and all the Sidonians, who are gone down with the slain, ashamed for all the terror which they caused by their might; and they lie uncircumcised with them that are slain by the sword, and bear their shame with them that go down to the pit.

**32:31** "These shall Pharaoh see, and shall be comforted over all his multitude; even Pharaoh and all his army, slain by the sword," says the Lord YHWH.

**32:32** "For I have put my terror in the land of the living; and he shall be laid in the midst of the uncircumcised, with them that are slain by the sword, even Pharaoh and all his multitude," says the Lord YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Lament Over Pharaoh (32:1-10):**
**The Key Verse (32:1):**
"In the twelfth year, in the twelfth month, in the first day of the month."

*Bi-shtei esreh shanah bi-shnim asar chodesh be-echad la-chodesh*—March 585 BCE.

**The Key Verse (32:2):**
"'Take up a lamentation for Pharaoh king of Egypt.'"

*Sa qinah al-Par'oh melekh-Mitzrayim*—lament for Pharaoh.

"'You did liken yourself unto a young lion of the nations.'"

*Kefir goyim nidmeita*—like young lion.

"'Whereas you are as a dragon in the seas.'"

*Ve-attah ka-tannim ba-yammim*—dragon in seas.

"'You did burst forth with your rivers.'"

*Va-tagach be-naharotekha*—burst forth.

"'Troubled the waters with your feet.'"

*Va-tirdas mayim be-raglekha*—troubled waters.

"'Fouled their rivers.'"

*Va-tarpos naharotam*—fouled rivers.

**The Key Verses (32:3-6):**
"'I will therefore spread out my net over you.'"

*U-farashti alekha et-rishti*—spread net.

"'With a company of many peoples.'"

*Bi-qehal ammim rabbim*—many peoples.

"'They shall bring you up in my net.'"

*Ve-he'elukha be-chermi*—bring up.

"'I will cast you upon the land.'"

*U-netashtikha ba-aretz*—cast on land.

"'I will hurl you upon the open field.'"

*Al-penei ha-sadeh atilekha*—hurl on field.

"'Will cause all the fowls of the heaven to settle upon you.'"

*Ve-hishkanti alekha kol-of ha-shamayim*—birds settle.

"'I will fill the beasts of the whole earth with you.'"

*Ve-hisba'ti mimmekha chayyat kol-ha-aretz*—beasts filled.

"'I will lay your flesh upon the mountains.'"

*Ve-natatti et-besarekha al-he-harim*—flesh on mountains.

"'Fill the valleys with your carcass.'"

*U-milleiti ha-ge'ayot ramatekha*—valleys filled.

"'I will also water with your blood the land wherein you swim.'"

*Ve-hishqeti eretz tzafatekha mi-dammekha*—water with blood.

"'Even to the mountains.'"

*El-he-harim*—to mountains.

"'The watercourses shall be full of you.'"

*Va-afiqim yimmale'un mimmekha*—watercourses full.

**The Key Verses (32:7-8) — Cosmic Signs:**
"'When I shall extinguish you, I will cover the heavens.'"

*Ve-khissiti be-khabbotekha shamayim*—cover heavens.

"'Make the stars thereof black.'"

*Ve-hiqdarti et-kokhevehem*—stars black.

"'I will cover the sun with a cloud.'"

*Shemesh be-anan akhasennu*—sun covered.

"'The moon shall not give her light.'"

*Ve-yareach lo-ya'ir oro*—moon dark.

"'All the bright lights of heaven will I make black over you.'"

*Kol-me'orei or ba-shamayim aqdir alekha*—lights black.

"'Set darkness upon your land.'"

*Ve-natatti choshekh al-artzekha*—darkness.

**The Key Verses (32:9-10):**
"'I will also vex the hearts of many peoples.'"

*Ve-hikh'asti lev ammim rabbim*—vex hearts.

"'When I shall bring your destruction among the nations.'"

*Ba-havi'i shivrekha ba-goyim*—destruction among nations.

"'I will make many peoples appalled at you.'"

*Va-hashimmoti alekha ammim rabbim*—appalled.

"'Their kings shall be horribly afraid for you.'"

*U-malkheihem yis'aru alekha sa'ar*—kings afraid.

"'When I shall brandish my sword before them.'"

*Be-offi charbi al-peneihem*—brandish sword.

"'They shall tremble at every moment.'"

*Ve-chardu li-rega'im*—tremble.

"'Every man for his own life, in the day of your fall.'"

*Ish le-nafsho be-yom mappaltekha*—for own life.

**Egypt's Destruction (32:11-16):**
**The Key Verses (32:11-12):**
"'The sword of the king of Babylon shall come upon you.'"

*Cherev melekh-Bavel tevo'ekha*—Babylon's sword.

"'By the swords of the mighty will I cause your multitude to fall.'"

*Be-charvot gibborim appil hamonekha*—mighty swords.

"'The terrible of the nations are they all.'"

*Aritzei goyim kullam*—terrible nations.

"'They shall spoil the pride of Egypt.'"

*Ve-shaddu et-ge'on Mitzrayim*—spoil pride.

"'All the multitude thereof shall be destroyed.'"

*Ve-nishmad kol-hamonah*—destroyed.

**The Key Verses (32:13-16):**
"'I will destroy also all the beasts thereof from beside many waters.'"

*Ve-ha'avadti et-kol-behemtah me-al mayim rabbim*—destroy beasts.

"'Neither shall the foot of man trouble them any more.'"

*Ve-lo tidlemem regel adam od*—no foot trouble.

"'Nor the hoofs of beasts trouble them.'"

*U-parsot behemah lo tidlemem*—no hoofs.

"'Then will I make their waters clear.'"

*Az ashqi'a meimeihem*—waters clear.

"'Cause their rivers to run like oil.'"

*Ve-naharotam ka-shemen olikh*—like oil.

"'When I shall make the land of Egypt desolate and waste.'"

*Be-titti et-eretz Mitzrayim shemamah u-neshammah*—desolate.

"'Then shall they know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—recognition.

"'This is the lamentation wherewith they shall lament.'"

*Qinah hi ve-qonenuha*—lament.

"'The daughters of the nations shall lament therewith.'"

*Benot ha-goyim teqonennah otah*—daughters lament.

**Egypt's Descent to Sheol (32:17-32):**
**The Key Verse (32:17):**
"In the twelfth year, in the fifteenth day of the month."

*Bi-shtei esreh shanah ba-chamishah asar la-chodesh*—March/April 585 BCE.

**The Key Verses (32:18-21):**
"'Wail for the multitude of Egypt.'"

*Neheh al-hamon Mitzrayim*—wail.

"'Cast them down... unto the nether parts of the earth.'"

*Ve-horidah otah... el-eretz tachtiyyot*—to netherworld.

"'With them that go down into the pit.'"

*Et-yordei bor*—to pit.

"''Whom do you pass in beauty? Go down, and be laid with the uncircumcised.''"

*Mi-mi na'amta redah ve-hashkevah et-arelim*—go down.

"'They shall fall in the midst of them that are slain by the sword.'"

*Be-tokh challalei-cherev yippolu*—fall among slain.

"'She is delivered to the sword.'"

*Cherev nittanah*—given to sword.

"'The strong among the mighty shall speak to him out of the midst of Sheol.'"

*Yedabberu-lo elei gibborim mi-tokh she'ol*—mighty speak.

"'They are gone down, they lie uncircumcised, slain by the sword.'"

*Yardu shakhvu ha-arelim challalei cherev*—lie uncircumcised.

**Nations in Sheol:**
**Assyria (32:22-23):**
"'Asshur is there and all her company.'"

*Sham Ashshur ve-khol-qehalah*—Assyria there.

"'Their graves are round about him.'"

*Sevivotav qivroteyha*—graves around.

"'All of them slain, fallen by the sword.'"

*Kullam challalim ha-noflim ba-cherev*—fallen by sword.

"'Whose graves are set in the uttermost parts of the pit.'"

*Asher nittenu qivroteyha be-yarketei vor*—in pit's depths.

"'Who caused terror in the land of the living.'"

*Asher-natenu chittit be-eretz chayyim*—caused terror.

**Elam (32:24-25):**
"'There is Elam and all her multitude.'"

*Sham Elam ve-khol-hamonah*—Elam there.

"'All of them slain, fallen by the sword.'"

*Kullam challalim ha-noflim ba-cherev*—fallen.

"'Who are gone down uncircumcised into the nether parts of the earth.'"

*Asher-yardu arelim el-eretz tachtiyyot*—to netherworld.

"'Who caused their terror in the land of the living.'"

*Asher-natenu chittitam be-eretz chayyim*—caused terror.

"'Have borne their shame with them that go down to the pit.'"

*Va-yis'u kelimmatam et-yordei bor*—bore shame.

**Meshech and Tubal (32:26-27):**
"'There is Meshech, Tubal, and all her multitude.'"

*Sham Meshekh Tuval ve-khol-hamonah*—Meshech, Tubal.

"'Her graves are round about him.'"

*Sevivoteyha qivroteyha*—graves around.

"'All of them uncircumcised, slain by the sword.'"

*Kullam arelim mechallalei cherev*—uncircumcised, slain.

"'They caused their terror in the land of the living.'"

*Ki-natenu chittitam be-eretz chayyim*—caused terror.

"'They shall not lie with the mighty that are fallen of the uncircumcised.'"

*Ve-lo yishkevu et-gibborim noflim me-arelim*—not with mighty.

"'That are gone down to Sheol with their weapons of war.'"

*Asher-yardu she'ol bi-khlei milchamtam*—with weapons.

"'Have laid their swords under their heads.'"

*Va-yittenu et-charvotam tachat rasheihem*—swords under heads.

"'Their iniquities are upon their bones.'"

*Va-tehi avonataם al-atzmotam*—iniquities on bones.

"'They were the terror of the mighty in the land of the living.'"

*Ki-chittit gibborim be-eretz chayyim*—terror of mighty.

**Edom (32:29):**
"'There is Edom, her kings and all her princes.'"

*Shammah Edom malkheyha ve-khol-nesi'eyha*—Edom, kings, princes.

"'Who for all their might are laid with them that are slain by the sword.'"

*Asher-nittenu vi-gevuratam et-challalei-cherev*—with slain.

"'They shall lie with the uncircumcised.'"

*Hemmah et-arelim yishkavu*—with uncircumcised.

**Northern Princes and Sidonians (32:30):**
"'There are the princes of the north, all of them, and all the Sidonians.'"

*Shammah nesikhei tzafon kullam ve-khol-Tzidoni*—northern princes, Sidonians.

"'Who are gone down with the slain.'"

*Ha-yordim et-challalim*—with slain.

"'Ashamed for all the terror which they caused by their might.'"

*Be-boshtam mi-chittitam mi-gevuratam*—ashamed.

"'They lie uncircumcised with them that are slain by the sword.'"

*Va-yishkevu arelim et-challalei-cherev*—uncircumcised.

"'Bear their shame with them that go down to the pit.'"

*Va-yis'u kelimmatam et-yordei bor*—bore shame.

**The Key Verses (32:31-32):**
"'These shall Pharaoh see, and shall be comforted over all his multitude.'"

*Otam yir'eh Par'oh ve-nicham al-kol-hamono*—Pharaoh comforted.

"'Even Pharaoh and all his army, slain by the sword.'"

*Par'oh ve-khol-cheilo challalei-cherev*—Pharaoh slain.

"'For I have put my terror in the land of the living.'"

*Ki-natatti et-chittiti be-eretz chayyim*—my terror.

"'He shall be laid in the midst of the uncircumcised.'"

*Ve-hushkav be-tokh arelim*—among uncircumcised.

"'With them that are slain by the sword.'"

*Et-challalei-cherev*—sword-slain.

"'Even Pharaoh and all his multitude.'"

*Par'oh ve-khol-hamono*—Pharaoh.

**Archetypal Layer:** Ezekiel 32 concludes the **Egypt oracles (29-32)**, containing **Pharaoh as "dragon in the seas" (32:2)**, **cosmic darkening at his fall (32:7-8)**, **tour of Sheol with fallen nations: Assyria (32:22-23), Elam (32:24-25), Meshech and Tubal (32:26-27), Edom (32:29), northern princes (32:30)**, and **"Pharaoh see, and shall be comforted over all his multitude" (32:31)**—grim comfort in shared doom.

**Ethical Inversion Applied:**
- "In the twelfth year, in the twelfth month"—March 585 BCE
- "'Take up a lamentation for Pharaoh'"—lament
- "'You did liken yourself unto a young lion'"—lion claim
- "'Whereas you are as a dragon in the seas'"—dragon
- "'I will therefore spread out my net over you'"—net
- "'They shall bring you up in my net'"—caught
- "'I will cast you upon the land'"—cast
- "'Will cause all the fowls... to settle upon you'"—birds feast
- "'I will fill the beasts... with you'"—beasts filled
- "'I will lay your flesh upon the mountains'"—flesh on mountains
- "'I will also water with your blood'"—water with blood
- "'I will cover the heavens'"—cover heavens
- "'Make the stars thereof black'"—stars black
- "'I will cover the sun with a cloud'"—sun covered
- "'The moon shall not give her light'"—moon dark
- "'All the bright lights of heaven will I make black'"—lights black
- "'Set darkness upon your land'"—darkness
- "'I will also vex the hearts of many peoples'"—vex hearts
- "'Their kings shall be horribly afraid'"—kings afraid
- "'When I shall brandish my sword before them'"—brandish sword
- "'The sword of the king of Babylon shall come upon you'"—Babylon's sword
- "'The terrible of the nations are they all'"—terrible nations
- "'They shall spoil the pride of Egypt'"—spoil pride
- "'I will destroy also all the beasts thereof'"—destroy beasts
- "'Then will I make their waters clear'"—waters clear
- "'Cause their rivers to run like oil'"—like oil
- "'This is the lamentation'"—lament
- "'Wail for the multitude of Egypt'"—wail
- "'Cast them down... unto the nether parts of the earth'"—to Sheol
- "''Whom do you pass in beauty? Go down''"—go down
- "'The strong among the mighty shall speak to him out of... Sheol'"—mighty speak
- "'Asshur is there'"—Assyria in Sheol
- "'Who caused terror in the land of the living'"—caused terror
- "'There is Elam'"—Elam
- "'There is Meshech, Tubal'"—Meshech, Tubal
- "'They shall not lie with the mighty'"—not with heroes
- "'Have laid their swords under their heads'"—swords under heads
- "'There is Edom'"—Edom
- "'There are the princes of the north'"—northern princes
- "'These shall Pharaoh see, and shall be comforted'"—grim comfort
- "'I have put my terror in the land of the living'"—YHWH's terror
- "'He shall be laid in the midst of the uncircumcised'"—among uncircumcised

**Modern Equivalent:** Ezekiel 32 concludes Egypt oracles with Pharaoh's descent to Sheol. The cosmic signs (32:7-8) echo Joel and Revelation. The tour of Sheol (32:17-32) shows fallen empires welcoming Egypt—"comforted" by shared doom (32:31). This ends the oracles against nations (25-32); chapter 33 returns to Judah.

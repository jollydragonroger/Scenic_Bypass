# Ezekiel 24: The Boiling Pot and Ezekiel's Wife Dies

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## The Boiling Pot (24:1-14)

**24:1** And the word of YHWH came unto me in the ninth year, in the tenth month, in the tenth day of the month, saying:

**24:2** "Son of man, write the name of the day, even of this selfsame day; this selfsame day the king of Babylon has invested Jerusalem.

**24:3** "And utter a parable unto the rebellious house, and say unto them: Thus says the Lord YHWH: Set on the pot, set it on, and also pour water into it;

**24:4** "Gather into it the pieces belonging to it, even every good piece, the thigh, and the shoulder; fill it with the choice bones.

**24:5** "Take the choice of the flock, and pile also the bones under it; make it boil well; yea, let the bones thereof be seethed in the midst of it.

**24:6** "Wherefore thus says the Lord YHWH: Woe to the bloody city, to the pot whose filth is therein, and whose filth is not gone out of it! Bring it out piece by piece; no lot is fallen upon it.

**24:7** "For her blood is in the midst of her; she set it upon the bare rock; she poured it not upon the ground, to cover it with dust.

**24:8** "That it might cause fury to come up, that vengeance might be taken, I have set her blood upon the bare rock, that it should not be covered.

**24:9** "Therefore thus says the Lord YHWH: Woe to the bloody city! I also will make the pile great.

**24:10** "Heap on the wood, kindle the fire, consume the flesh, and make thick the broth, and let the bones be burned.

**24:11** "Then set it empty upon the coals thereof, that it may be hot, and the bottom thereof may burn, and that the filthiness of it may be molten in it, that the rust of it may be consumed.

**24:12** "It has wearied itself with toil; yet its great rust goes not forth out of it; its rust goes not forth by fire.

**24:13** "Because of your filthy lewdness, because I have purged you and you were not purged, you shall not be purged from your filthiness any more, till I have satisfied my fury upon you.

**24:14** "I YHWH have spoken it; it shall come to pass, and I will do it; I will not go back, neither will I spare, neither will I repent; according to your ways, and according to your doings, shall they judge you," says the Lord YHWH.

---

## Ezekiel's Wife Dies (24:15-27)

**24:15** And the word of YHWH came unto me, saying:

**24:16** "Son of man, behold, I take away from you the desire of your eyes with a stroke; yet neither shall you make lamentation nor weep, neither shall your tears run down.

**24:17** "Sigh in silence; make no mourning for the dead, bind your head-attire upon you, and put your shoes upon your feet, and cover not your upper lip, and eat not the bread of men."

**24:18** So I spoke unto the people in the morning; and at even my wife died; and I did in the morning as I was commanded.

**24:19** And the people said unto me: "Will you not tell us what these things are to us, that you do so?"

**24:20** Then I said unto them: "The word of YHWH came unto me, saying:

**24:21** "'Speak unto the house of Israel: Thus says the Lord YHWH: Behold, I will profane my sanctuary, the pride of your power, the desire of your eyes, and the longing of your soul; and your sons and your daughters whom you have left behind shall fall by the sword.

**24:22** "'And you shall do as I have done: you shall not cover your upper lip, nor eat the bread of men;

**24:23** "'And your tires shall be upon your heads, and your shoes upon your feet; you shall not make lamentation nor weep; but you shall pine away in your iniquities, and moan one toward another.

**24:24** "'Thus shall Ezekiel be unto you a sign; according to all that he has done shall you do; when this comes, then shall you know that I am the Lord YHWH.'"

**24:25** "And you, son of man, shall it not be in the day when I take from them their stronghold, the joy of their glory, the desire of their eyes, and the yearning of their soul, their sons and their daughters,

**24:26** "That in that day he that escapes shall come unto you, to cause you to hear it with your ears?

**24:27** "In that day shall your mouth be opened together with him that is escaped, and you shall speak, and be no more dumb; so shall you be a sign unto them; and they shall know that I am YHWH."

---

## Synthesis Notes

**Key Restorations:**

**Boiling Pot (24:1-14):**
**The Key Verse (24:1):**
"In the ninth year, in the tenth month, in the tenth day of the month."

*Ba-shanah ha-teshi'it ba-chodesh ha-asiri be-asor la-chodesh*—January 15, 588 BCE.

**The Key Verse (24:2):**
"'Write the name of the day, even of this selfsame day.'"

*Ketov lekha et-shem ha-yom et-etzem ha-yom ha-zeh*—write date.

"'This selfsame day the king of Babylon has invested Jerusalem.'"

*Samakh melekh-Bavel el-Yerushalayim be-etzem ha-yom ha-zeh*—siege begins.

**Exact Date:**
Ezekiel in Babylon knows the exact day Jerusalem's siege begins—prophetic confirmation.

**The Key Verses (24:3-5):**
"'Set on the pot, set it on.'"

*Shefot ha-sir shefot*—set pot.

"'Pour water into it.'"

*Ve-gam yetzоq-bo mayim*—pour water.

"'Gather into it the pieces belonging to it.'"

*Esof elav netacheyha*—gather pieces.

"'Every good piece, the thigh, and the shoulder.'"

*Kol-netach tov yarekh va-khatef*—good pieces.

"'Fill it with the choice bones.'"

*Mivchar atzamot malle*—choice bones.

"'Take the choice of the flock.'"

*Mivchar ha-tzon qach*—choice flock.

"'Make it boil well.'"

*Rattach rettacheyha*—boil well.

**The Key Verses (24:6-8):**
"'Woe to the bloody city.'"

*Hoy ir ha-damim*—bloody city.

"'To the pot whose filth is therein.'"

*Sir asher chel'atah bah*—pot with filth.

"'Whose filth is not gone out of it.'"

*Ve-chel'atah lo yatza'ah mimmennah*—filth remains.

"'Bring it out piece by piece.'"

*Li-netacheyha li-netacheyha hotzi'ah*—piece by piece.

"'No lot is fallen upon it.'"

*Lo-nafal alekha goral*—no lot.

"'For her blood is in the midst of her.'"

*Ki damah be-tokhah hayah*—blood in midst.

"'She set it upon the bare rock.'"

*Al-tzechich sela samathu*—on bare rock.

"'She poured it not upon the ground, to cover it with dust.'"

*Lo shefakhathu al-ha-aretz le-khasot alav afar*—not covered.

**Blood on Rock:**
Blood not poured on ground (to be covered per Leviticus 17:13) cries out for vengeance.

**The Key Verses (24:9-11):**
"'I also will make the pile great.'"

*Gam-ani agdil ha-medurah*—great pile.

"'Heap on the wood, kindle the fire.'"

*Harbeh ha-etzim hadleq ha-esh*—heap wood.

"'Consume the flesh, and make thick the broth.'"

*Hatem ha-basar ve-harqeach ha-merqachah*—consume flesh.

"'Let the bones be burned.'"

*Ve-ha-atzamot yecharu*—burn bones.

"'Then set it empty upon the coals thereof.'"

*Ve-ha'amidah al-gechaleyha reqah*—empty on coals.

"'That it may be hot, and the bottom thereof may burn.'"

*Lema'an techam ve-nichor nechoshatah*—burn bottom.

"'That the filthiness of it may be molten in it.'"

*Ve-nitkah be-tokhah tum'atah*—melt filth.

"'That the rust of it may be consumed.'"

*Tittom chel'atah*—consume rust.

**The Key Verses (24:12-14):**
"'It has wearied itself with toil.'"

*Te'unim hel'atah*—wearied.

"'Yet its great rust goes not forth out of it.'"

*Ve-lo-tetze mimmennah rabbat chel'atah*—rust remains.

"'Its rust goes not forth by fire.'"

*Ba-esh chel'atah*—not by fire.

"'Because of your filthy lewdness.'"

*Be-tum'atekh zimmah*—filthy lewdness.

"'Because I have purged you and you were not purged.'"

*Ya'an tiharttikh ve-lo tahort*—not purged.

"'You shall not be purged from your filthiness any more.'"

*Mi-tum'atekh lo tihari od*—no more purging.

"'Till I have satisfied my fury upon you.'"

*Ad-hanichi et-chamati bakh*—satisfy fury.

"'I YHWH have spoken it; it shall come to pass.'"

*Ani YHWH dibbarti ba'ah*—it comes.

"'I will not go back, neither will I spare, neither will I repent.'"

*Ve-asiti lo efra ve-lo-achos ve-lo ennachem*—no relenting.

"'According to your ways, and according to your doings, shall they judge you.'"

*Ki-derakhayikh u-khe-alilotayikh shefatukh*—judge by ways.

**Ezekiel's Wife Dies (24:15-27):**
**The Key Verse (24:16):**
"'Behold, I take away from you the desire of your eyes with a stroke.'"

*Hineni loqeach mimmekha et-machmad einekha be-maggefah*—take desire of eyes.

"'Yet neither shall you make lamentation nor weep.'"

*Ve-lo tispod ve-lo tivkeh*—no mourning.

"'Neither shall your tears run down.'"

*Ve-lo tavo dim'atekha*—no tears.

**The Key Verse (24:17):**
"'Sigh in silence.'"

*He'aneq dom*—sigh silently.

"'Make no mourning for the dead.'"

*Metim evel lo ta'aseh*—no mourning.

"'Bind your head-attire upon you.'"

*Pe'erkha chavosh alekha*—bind turban.

"'Put your shoes upon your feet.'"

*U-ne'alekha tasim be-raglekha*—put shoes.

"'Cover not your upper lip.'"

*Ve-lo ta'ateh al-safam*—don't cover lip.

"'Eat not the bread of men.'"

*Ve-lechem anashim lo tokhel*—don't eat mourning bread.

**Mourning Customs Reversed:**
Normally mourners removed turban, went barefoot, covered lips, ate mourning bread.

**The Key Verse (24:18):**
"So I spoke unto the people in the morning; and at even my wife died."

*Va-adabber el-ha-am ba-boqer va-tamat ishti ba-erev*—wife died.

"I did in the morning as I was commanded."

*Va-a'as ba-boqer ka-asher tzuvveiti*—obeyed.

**The Key Verses (24:19-21):**
"'Will you not tell us what these things are to us?'"

*Ha-lo-taggid lanu mah-elleh lanu ki-attah oseh*—what does this mean?

"'Behold, I will profane my sanctuary.'"

*Hineni mechalel et-miqdashi*—profane sanctuary.

"'The pride of your power.'"

*Ge'on uzzkhem*—pride of power.

"'The desire of your eyes.'"

*Machmad eineikem*—desire of eyes.

"'The longing of your soul.'"

*U-machmal nafshekhem*—soul's longing.

"'Your sons and your daughters... shall fall by the sword.'"

*U-vneikhem u-venoteikem asher azavtem ba-cherev yippolu*—children fall.

**The Key Verses (24:22-24):**
"'You shall do as I have done.'"

*Va-asitem ka-asher asiti*—do as I did.

"'You shall not cover your upper lip.'"

*Al-safam lo ta'atu*—don't cover.

"'Nor eat the bread of men.'"

*Ve-lechem anashim lo tokhelu*—don't eat.

"'Your tires shall be upon your heads.'"

*U-fe'areikem al-rasheikhem*—turbans on.

"'Your shoes upon your feet.'"

*U-ne'aleikhem be-ragleikhem*—shoes on.

"'You shall not make lamentation nor weep.'"

*Lo tispdu ve-lo tivku*—no mourning.

"'You shall pine away in your iniquities.'"

*U-nehaqqotem ba-avonoteikhem*—pine away.

"'Moan one toward another.'"

*U-nehammtem ish el-achiv*—moan.

"'Thus shall Ezekiel be unto you a sign.'"

*Ve-hayah Yechezqel lakhem le-mofet*—Ezekiel a sign.

"'According to all that he has done shall you do.'"

*Ke-khol asher-asah ta'asu*—do as he did.

"'When this comes, then shall you know that I am the Lord YHWH.'"

*Be-vo'ah vi-ydatem ki ani Adonai YHWH*—when it comes.

**The Key Verses (24:25-27):**
"'In the day when I take from them their stronghold.'"

*Be-yom qachti me-hem et-ma'uzzam*—take stronghold.

"'The joy of their glory.'"

*Mesos tif'artam*—joy of glory.

"'The desire of their eyes.'"

*Machmad eineihem*—desire of eyes.

"'Their sons and their daughters.'"

*Beneihem u-venoteihem*—children.

"'He that escapes shall come unto you.'"

*Yavo ha-palit elekha*—escapee comes.

"'To cause you to hear it with your ears.'"

*Le-hashmi'a oznayim*—hear.

"'In that day shall your mouth be opened.'"

*Ba-yom ha-hu yipppatach pikha*—mouth opened.

"'You shall speak, and be no more dumb.'"

*Ve-tedabber ve-lo te'alem od*—speak, not dumb.

"'So shall you be a sign unto them.'"

*Ve-hayita lahem le-mofet*—sign.

"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—recognition.

**End of Muteness:**
Ezekiel's silence (3:26-27) ends when Jerusalem falls (33:21-22).

**Archetypal Layer:** Ezekiel 24 is a **pivotal chapter**, containing **the exact date Jerusalem's siege begins (24:1-2)**, **the boiling pot parable (24:3-14)**, **Ezekiel's wife's death as sign-act (24:15-18)**, **"I will profane my sanctuary, the desire of your eyes" (24:21)**, and **"In that day shall your mouth be opened" (24:27)**.

**Ethical Inversion Applied:**
- "In the ninth year, in the tenth month, in the tenth day"—January 15, 588 BCE
- "'Write the name of the day'"—write date
- "'This selfsame day the king of Babylon has invested Jerusalem'"—siege begins
- "'Set on the pot, set it on'"—set pot
- "'Gather into it the pieces'"—gather
- "'Every good piece, the thigh, and the shoulder'"—good pieces
- "'Make it boil well'"—boil
- "'Woe to the bloody city'"—bloody city
- "'To the pot whose filth is therein'"—filth in pot
- "'Bring it out piece by piece'"—piece by piece
- "'For her blood is in the midst of her'"—blood
- "'She set it upon the bare rock'"—on rock
- "'That it might cause fury to come up'"—fury
- "'Heap on the wood, kindle the fire'"—kindle
- "'Consume the flesh'"—consume
- "'Set it empty upon the coals'"—empty on coals
- "'That the filthiness of it may be molten'"—melt filth
- "'Its great rust goes not forth'"—rust remains
- "'Because I have purged you and you were not purged'"—not purged
- "'I YHWH have spoken it; it shall come to pass'"—it comes
- "'I will not go back, neither will I spare'"—no relenting
- "'I take away from you the desire of your eyes'"—wife dies
- "'Yet neither shall you make lamentation nor weep'"—no mourning
- "'Sigh in silence'"—silent sighing
- "'Make no mourning for the dead'"—no mourning
- "At even my wife died"—wife died
- "I did... as I was commanded"—obeyed
- "'I will profane my sanctuary'"—profane sanctuary
- "'The pride of your power, the desire of your eyes'"—desire
- "'Your sons and your daughters... shall fall'"—children fall
- "'You shall do as I have done'"—do as I did
- "'You shall pine away in your iniquities'"—pine away
- "'Thus shall Ezekiel be unto you a sign'"—Ezekiel a sign
- "'He that escapes shall come unto you'"—escapee
- "'In that day shall your mouth be opened'"—mouth opened
- "'You shall speak, and be no more dumb'"—no more dumb

**Modern Equivalent:** Ezekiel 24 marks the siege's beginning and the book's midpoint. Ezekiel's wife's death without mourning becomes a sign—when Jerusalem falls, survivors will be too shocked to mourn properly. "The desire of your eyes" (temple, 24:21) parallels "desire of your eyes" (wife, 24:16). Chapters 25-32 (oracles against nations) follow before Jerusalem's fall is reported in 33:21.

# Ezekiel 4: The Siege of Jerusalem Enacted

*From the Hebrew: וְאַתָּה בֶן־אָדָם (Ve-Attah Ben-Adam) — And You, Son of Man*

---

## The Brick and the Siege (4:1-3)

**4:1** "And you, son of man, take a tile, and lay it before you, and engrave upon it a city, even Jerusalem;

**4:2** "And lay siege against it, and build forts against it, and cast a mound against it; set camps also against it, and set battering rams against it round about.

**4:3** "And take unto you an iron griddle, and set it for a wall of iron between you and the city; and set your face toward it, and it shall be besieged, and you shall lay siege against it. This shall be a sign to the house of Israel."

---

## Lying on the Sides (4:4-8)

**4:4** "Moreover lie upon your left side, and lay the iniquity of the house of Israel upon it; according to the number of the days that you shall lie upon it, you shall bear their iniquity.

**4:5** "For I have appointed the years of their iniquity to be unto you a number of days, even three hundred and ninety days; so shall you bear the iniquity of the house of Israel.

**4:6** "And again, when you have accomplished these, you shall lie on your right side, and shall bear the iniquity of the house of Judah; forty days, each day for a year, have I appointed it unto you.

**4:7** "And you shall set your face toward the siege of Jerusalem, with your arm uncovered; and you shall prophesy against it.

**4:8** "And, behold, I lay bands upon you, and you shall not turn from one side to the other, till you have accomplished the days of your siege."

---

## The Siege Bread (4:9-17)

**4:9** "Take also unto you wheat, and barley, and beans, and lentils, and millet, and spelt, and put them in one vessel, and make bread thereof; according to the number of the days that you shall lie upon your side, even three hundred and ninety days, shall you eat thereof.

**4:10** "And your food which you shall eat shall be by weight, twenty shekels a day; from time to time shall you eat it.

**4:11** "And you shall drink water by measure, the sixth part of a hin; from time to time shall you drink.

**4:12** "And you shall eat it as barley cakes, and you shall bake it in their sight with dung that comes out of man."

**4:13** And YHWH said: "Even thus shall the children of Israel eat their bread unclean, among the nations whither I will drive them."

**4:14** Then said I: "Ah Lord YHWH! Behold, my soul has not been polluted; for from my youth up even till now have I not eaten of that which dies of itself, or is torn of beasts; neither came there abhorrent flesh into my mouth."

**4:15** Then he said unto me: "See, I have given you cow's dung for man's dung, and you shall prepare your bread thereon."

**4:16** Moreover he said unto me: "Son of man, behold, I will break the staff of bread in Jerusalem; and they shall eat bread by weight, and with anxiety; and they shall drink water by measure, and in horror;

**4:17** "That they may want bread and water, and be appalled one with another, and pine away in their iniquity."

---

## Synthesis Notes

**Key Restorations:**

**Brick and Siege (4:1-3):**
**The Key Verse (4:1):**
"'Take a tile, and lay it before you.'"

*Qach-lekha levenah ve-natattah otah lefanekha*—take tile.

"'Engrave upon it a city, even Jerusalem.'"

*Ve-chaqota alekha ir et-Yerushalayim*—engrave Jerusalem.

**The Key Verse (4:2):**
"'Lay siege against it.'"

*Ve-natattah alekha matzor*—lay siege.

"'Build forts against it.'"

*U-vanita alekha dayeq*—build forts.

"'Cast a mound against it.'"

*Ve-shafakhta alekha solelah*—cast mound.

"'Set camps also against it.'"

*Ve-natattah alekha machanot*—set camps.

"'Set battering rams against it round about.'"

*Ve-sim alekha karim saviv*—battering rams.

**The Key Verse (4:3):**
"'Take unto you an iron griddle.'"

*Ve-attah qach-lekha machabat barzel*—iron griddle.

"'Set it for a wall of iron between you and the city.'"

*Ve-natattah otah qir barzel beinekha u-vein ha-ir*—iron wall.

"'Set your face toward it.'"

*Va-hakhinotah et-panekha elekha*—face toward.

"'It shall be besieged, and you shall lay siege against it.'"

*Ve-hayetah va-matzor ve-tzarta alekha*—besieged.

"'This shall be a sign to the house of Israel.'"

*Ot hi le-veit Yisra'el*—sign.

**Sign-Act:**
Ezekiel enacts the coming Babylonian siege of Jerusalem.

**Lying on Sides (4:4-8):**
**The Key Verse (4:4):**
"'Lie upon your left side.'"

*U-shkhav al-tziddekha ha-semali*—lie left.

"'Lay the iniquity of the house of Israel upon it.'"

*Ve-samta et-avon beit-Yisra'el alav*—bear Israel's iniquity.

"'According to the number of the days that you shall lie upon it.'"

*Mispar ha-yamim asher tishkav alav*—number of days.

"'You shall bear their iniquity.'"

*Tissa et-avonam*—bear.

**The Key Verse (4:5):**
"'I have appointed the years of their iniquity to be unto you a number of days.'"

*Va-ani natatti lekha et-shenei avonam le-mispar yamim*—years as days.

"'Three hundred and ninety days.'"

*Shelosh me'ot ve-tish'im yom*—390 days.

"'So shall you bear the iniquity of the house of Israel.'"

*Ve-nasata avon beit-Yisra'el*—bear Israel's sin.

**390 Days:**
May represent years from Solomon's temple dedication (c. 960 BCE) to its destruction (586 BCE), or from the division of the kingdom.

**The Key Verse (4:6):**
"'You shall lie on your right side.'"

*Ve-shakhavta al-tziddekha ha-yemani*—lie right.

"'Shall bear the iniquity of the house of Judah.'"

*Ve-nasata et-avon beit-Yehudah*—bear Judah's sin.

"'Forty days, each day for a year.'"

*Arba'im yom yom la-shanah yom la-shanah*—40 days.

"'Have I appointed it unto you.'"

*Netattiv lakh*—appointed.

**40 Days:**
May represent 40 years of Manasseh's reign or Judah's sin period.

**The Key Verse (4:7):**
"'Set your face toward the siege of Jerusalem.'"

*Ve-el-metzor Yerushalayim takhin panekha*—face siege.

"'With your arm uncovered.'"

*U-zero'akha chasufah*—arm bare.

"'You shall prophesy against it.'"

*Ve-nibbeta alekha*—prophesy.

**The Key Verse (4:8):**
"'I lay bands upon you.'"

*Ve-hinneh natatti alekha avotot*—bands.

"'You shall not turn from one side to the other.'"

*Ve-lo-tehafekh mi-tziddekha el-tziddekha*—not turn.

"'Till you have accomplished the days of your siege.'"

*Ad-kallotekha yemei metzurekha*—until completed.

**Siege Bread (4:9-17):**
**The Key Verse (4:9):**
"'Take... wheat, and barley, and beans, and lentils, and millet, and spelt.'"

*Ve-attah qach-lekha chittim u-se'orim u-ful va-adashim ve-dochan ve-khussemim*—mixed grains.

"'Put them in one vessel, and make bread thereof.'"

*Ve-natattah otam bi-kheli echad ve-asita otam lekha le-lachem*—make bread.

"'According to the number of the days... three hundred and ninety days.'"

*Mispar ha-yamim... shelosh me'ot ve-tish'im yom*—390 days.

**Mixed Grains:**
Famine bread—mixing whatever grains are available.

**The Key Verses (4:10-11):**
"'Your food which you shall eat shall be by weight, twenty shekels a day.'"

*U-ma'akholekha asher tokhelennu bi-mishqal esrim sheqel la-yom*—20 shekels (~8 oz).

"'From time to time shall you eat it.'"

*Me-et ad-et tokhelennu*—rationed.

"'You shall drink water by measure, the sixth part of a hin.'"

*U-mayim bi-mesurah tishteh shishshit ha-hin*—1/6 hin (~2/3 quart).

"'From time to time shall you drink.'"

*Me-et ad-et tishteh*—rationed.

**The Key Verses (4:12-13):**
"'You shall eat it as barley cakes.'"

*Ve-ugat se'orim tokhalennah*—barley cakes.

"'You shall bake it... with dung that comes out of man.'"

*Ve-hi be-gellei tze'at ha-adam te'ugennah le-eineihem*—human dung.

"'Even thus shall the children of Israel eat their bread unclean.'"

*Kakhah yokhelu venei-Yisra'el et-lachmam tame*—unclean bread.

"'Among the nations whither I will drive them.'"

*Ba-goyim asher addichim sham*—among nations.

**The Key Verses (4:14-15):**
"'Ah Lord YHWH! Behold, my soul has not been polluted.'"

*Ahahh Adonai YHWH hinneh nafshi lo metummah*—not polluted.

"'From my youth up even till now have I not eaten of that which dies of itself.'"

*U-nevelah u-terefah lo-akhalti mi-ne'urai ve-ad-attah*—not eaten.

"'Neither came there abhorrent flesh into my mouth.'"

*Ve-lo-va be-fi basar piggul*—no abhorrent flesh.

"'See, I have given you cow's dung for man's dung.'"

*Re'eh natatti lekha et-tzefhu'ei ha-baqar tachat gellei ha-adam*—cow dung instead.

"'You shall prepare your bread thereon.'"

*Ve-asita et-lachmekha aleihem*—prepare bread.

**Ezekiel's Objection:**
As a priest, Ezekiel protests ritual defilement. YHWH permits substitution.

**The Key Verses (4:16-17):**
"'I will break the staff of bread in Jerusalem.'"

*Hineni shover matteh-lechem bi-Yrushalayim*—break bread-staff.

"'They shall eat bread by weight, and with anxiety.'"

*Ve-akhlu lechem bi-mishqal u-vi-de'agah*—anxiety.

"'They shall drink water by measure, and in horror.'"

*U-mayim bi-mesurah u-vi-shimmamon yishtu*—horror.

"'They may want bread and water.'"

*Lema'an yachasru lechem va-mayim*—want.

"'Be appalled one with another.'"

*Ve-nashammu ish ve-achiv*—appalled.

"'Pine away in their iniquity.'"

*Ve-namaqquu ba-avonam*—pine away.

**Archetypal Layer:** Ezekiel 4 contains **the tile siege model (4:1-3)**, **lying on left side 390 days for Israel, right side 40 days for Judah (4:4-6)**, **siege rations of 20 shekels and 1/6 hin (4:10-11)**, **"I will break the staff of bread in Jerusalem" (4:16)**, and **Ezekiel's priestly objection granted (4:14-15)**.

**Ethical Inversion Applied:**
- "'Take a tile, and lay it before you'"—tile
- "'Engrave upon it a city, even Jerusalem'"—engrave Jerusalem
- "'Lay siege against it, and build forts'"—siege works
- "'Set battering rams against it'"—rams
- "'Take unto you an iron griddle'"—iron wall
- "'Set it for a wall of iron between you and the city'"—barrier
- "'This shall be a sign to the house of Israel'"—sign-act
- "'Lie upon your left side'"—left side
- "'Lay the iniquity of the house of Israel upon it'"—bear Israel's sin
- "'Three hundred and ninety days'"—390 days
- "'Lie on your right side'"—right side
- "'Bear the iniquity of the house of Judah'"—bear Judah's sin
- "'Forty days, each day for a year'"—40 days
- "'Set your face toward the siege of Jerusalem'"—face siege
- "'With your arm uncovered'"—arm bare
- "'I lay bands upon you'"—bound
- "'You shall not turn from one side to the other'"—no turning
- "'Take... wheat, and barley, and beans, and lentils'"—mixed grains
- "'Make bread thereof'"—famine bread
- "'Your food... shall be by weight, twenty shekels a day'"—rationed
- "'You shall drink water by measure, the sixth part of a hin'"—rationed
- "'You shall bake it... with dung that comes out of man'"—human dung
- "'The children of Israel eat their bread unclean'"—unclean
- "'Among the nations whither I will drive them'"—exile
- "'My soul has not been polluted'"—priestly objection
- "'I have given you cow's dung for man's dung'"—substitution
- "'I will break the staff of bread in Jerusalem'"—break bread-staff
- "'They shall eat bread by weight, and with anxiety'"—anxiety
- "'They shall drink water by measure, and in horror'"—horror
- "'Pine away in their iniquity'"—pine away

**Modern Equivalent:** Ezekiel 4 begins the sign-acts. The tile model, lying on sides, and starvation rations dramatize Jerusalem's coming siege. The substitution of cow dung (4:15) shows YHWH's accommodation to priestly concerns while maintaining the message.

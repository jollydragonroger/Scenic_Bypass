# Ezekiel 35: Oracle Against Mount Seir (Edom)

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## Edom's Judgment (35:1-9)

**35:1** Moreover the word of YHWH came unto me, saying:

**35:2** "Son of man, set your face against Mount Seir, and prophesy against it,

**35:3** "And say unto it: Thus says the Lord YHWH: Behold, I am against you, O Mount Seir, and I will stretch out my hand against you, and I will make you a desolation and an astonishment.

**35:4** "I will lay your cities waste, and you shall be desolate; and you shall know that I am YHWH.

**35:5** "Because you have had a perpetual hatred, and have given over the children of Israel to the power of the sword in the time of their calamity, in the time of the iniquity of the end;

**35:6** "Therefore, as I live," says the Lord YHWH, "I will prepare you unto blood, and blood shall pursue you; surely, you have hated blood, therefore blood shall pursue you.

**35:7** "Thus will I make Mount Seir an astonishment and a desolation; and I will cut off from it him that passes through and him that returns.

**35:8** "And I will fill his mountains with his slain; in your hills and in your valleys and in all your watercourses shall they fall that are slain with the sword.

**35:9** "I will make you perpetual desolations, and your cities shall not be inhabited; and you shall know that I am YHWH."

---

## Edom's Sin (35:10-15)

**35:10** "Because you have said: 'These two nations and these two countries shall be mine, and we will possess it'; whereas YHWH was there;

**35:11** "Therefore, as I live," says the Lord YHWH, "I will do according to your anger, and according to your envy, which you have shown out of your hatred against them; and I will make myself known among them, when I shall judge you.

**35:12** "And you shall know that I YHWH have heard all your blasphemies which you have spoken against the mountains of Israel, saying: 'They are laid desolate, they are given us to devour.'

**35:13** "And you have magnified yourselves against me with your mouth, and have multiplied your words against me; I have heard it.

**35:14** "Thus says the Lord YHWH: When the whole earth rejoices, I will make you desolate.

**35:15** "As you did rejoice over the inheritance of the house of Israel, because it was desolate, so will I do unto you; you shall be desolate, O Mount Seir, and all Edom, even all of it; and they shall know that I am YHWH."

---

## Synthesis Notes

**Key Restorations:**

**Edom's Judgment (35:1-9):**
**The Key Verse (35:2):**
"'Set your face against Mount Seir.'"

*Sim panekha al-har Se'ir*—against Seir.

"'Prophesy against it.'"

*Ve-hinnave alav*—prophesy.

**Mount Seir:**
Edom's mountainous territory south of the Dead Sea.

**The Key Verse (35:3):**
"'Behold, I am against you, O Mount Seir.'"

*Hineni elekha har Se'ir*—against Seir.

"'I will stretch out my hand against you.'"

*Ve-natiti yadi alekha*—hand against.

"'I will make you a desolation and an astonishment.'"

*U-netattikha shemamah u-meshammah*—desolation.

**The Key Verses (35:4-5):**
"'I will lay your cities waste, and you shall be desolate.'"

*Arekha chorvah asim ve-attah shemamah tihyeh*—cities waste.

"'You shall know that I am YHWH.'"

*Ve-yaדa'at ki-ani YHWH*—recognition.

"'Because you have had a perpetual hatred.'"

*Ya'an heyot lekha eivat olam*—perpetual hatred.

"'Have given over the children of Israel to the power of the sword.'"

*Va-tagger et-benei Yisra'el al-yedei-cherev*—gave to sword.

"'In the time of their calamity.'"

*Be-et eidam*—calamity time.

"'In the time of the iniquity of the end.'"

*Be-et avon qetz*—iniquity of end.

**The Key Verses (35:6-9):**
"''As I live,' says the Lord YHWH."

*Chai-ani ne'um Adonai YHWH*—as I live.

"'I will prepare you unto blood.'"

*Ki-le-dam e'esekha*—prepare for blood.

"'Blood shall pursue you.'"

*Ve-dam yirdefekha*—blood pursue.

"'You have hated blood, therefore blood shall pursue you.'"

*Im-lo dam saneta ve-dam yirdefekha*—hated blood (or: didn't hate blood).

**Wordplay:**
*Dam* (blood) and *Edom* sound alike.

"'I will make Mount Seir an astonishment and a desolation.'"

*Ve-natatti et-har Se'ir le-shimmamah u-shemamah*—astonishment.

"'I will cut off from it him that passes through and him that returns.'"

*Ve-hikhraatti mimmennnu over va-shav*—cut off passersby.

"'I will fill his mountains with his slain.'"

*Ve-milleiti et-harav et-challalav*—fill with slain.

"'In your hills and in your valleys and in all your watercourses.'"

*Giv'otekha u-ge'ayotekha u-khol-afiqekha*—hills, valleys, watercourses.

"'Shall they fall that are slain with the sword.'"

*Challalei-cherev yippelu vahem*—fall by sword.

"'I will make you perpetual desolations.'"

*Shimmemot olam ettnekha*—perpetual desolations.

"'Your cities shall not be inhabited.'"

*Ve-arekha lo teshavnah*—uninhabited.

"'You shall know that I am YHWH.'"

*Vi-ydatem ki-ani YHWH*—recognition.

**Edom's Sin (35:10-15):**
**The Key Verse (35:10):**
"'Because you have said: These two nations and these two countries shall be mine.'"

*Ya'an omrekha et-shenei ha-goyim ve-et shתei ha-aratzot li tiהyenah*—two nations mine.

"'We will possess it.'"

*Vi-yrshnuha*—possess.

"'Whereas YHWH was there.'"

*Va-YHWH sham hayah*—YHWH was there.

**Two Nations:**
Israel and Judah—Edom sought to possess both after their fall.

**The Key Verse (35:11):**
"''As I live,' says the Lord YHWH."

*Chai-ani ne'um Adonai YHWH*—as I live.

"'I will do according to your anger, and according to your envy.'"

*Ve-asiti ke-apekha u-khe-qin'atekha*—according to anger, envy.

"'Which you have shown out of your hatred against them.'"

*Asher asita mi-sin'atekha bam*—hatred.

"'I will make myself known among them, when I shall judge you.'"

*Ve-nodati vam ka-asher eshpotekha*—known when judging.

**The Key Verses (35:12-13):**
"'You shall know that I YHWH have heard all your blasphemies.'"

*Ve-yada'ta ki-ani YHWH shamati et-kol-ne'atzotekha*—heard blasphemies.

"'Which you have spoken against the mountains of Israel.'"

*Asher amarta al-harei Yisra'el*—against mountains.

"''They are laid desolate, they are given us to devour.''"

*Shamemu lanu nittenu le-okhlah*—given to devour.

"'You have magnified yourselves against me with your mouth.'"

*Va-tagdilu alai be-fikhem*—magnified against me.

"'Have multiplied your words against me.'"

*Ve-hirbitem alai divreikhem*—multiplied words.

"'I have heard it.'"

*Ani shamati*—I heard.

**The Key Verses (35:14-15):**
"'When the whole earth rejoices, I will make you desolate.'"

*Ki-semoach kol-ha-aretz shemamah e'eseh-lakh*—when earth rejoices.

"'As you did rejoice over the inheritance of the house of Israel.'"

*Ki-simchatekha le-nachalat beit-Yisra'el*—rejoiced over Israel.

"'Because it was desolate.'"

*Al asher-shamemah*—because desolate.

"'So will I do unto you.'"

*Ken e'eseh-lakh*—do to you.

"'You shall be desolate, O Mount Seir, and all Edom.'"

*Shemamah tihyeh har-Se'ir ve-khol-Edom*—Seir desolate.

"'Even all of it.'"

*Kulloh*—all.

"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—recognition.

**Archetypal Layer:** Ezekiel 35 is an **extended oracle against Edom (Mount Seir)**, containing **"perpetual hatred" (35:5)**, **"blood shall pursue you" (35:6)**—wordplay on *dam/Edom*, **"These two nations and these two countries shall be mine" (35:10)**—Edom's land grab, **"YHWH was there" (35:10)**, and **"As you did rejoice over the inheritance of the house of Israel... so will I do unto you" (35:15)**.

**Ethical Inversion Applied:**
- "'Set your face against Mount Seir'"—against Seir
- "'Prophesy against it'"—prophesy
- "'I am against you, O Mount Seir'"—against
- "'I will stretch out my hand against you'"—hand against
- "'I will make you a desolation and an astonishment'"—desolation
- "'I will lay your cities waste'"—waste
- "'You shall know that I am YHWH'"—recognition
- "'You have had a perpetual hatred'"—perpetual hatred
- "'Have given over the children of Israel to the power of the sword'"—gave to sword
- "'In the time of their calamity'"—calamity
- "'In the time of the iniquity of the end'"—end time
- "'I will prepare you unto blood'"—prepare for blood
- "'Blood shall pursue you'"—blood pursue
- "'I will make Mount Seir an astonishment'"—astonishment
- "'I will cut off from it him that passes through'"—cut off
- "'I will fill his mountains with his slain'"—fill with slain
- "'I will make you perpetual desolations'"—perpetual
- "'Your cities shall not be inhabited'"—uninhabited
- "'You have said: These two nations... shall be mine'"—land grab
- "'We will possess it'"—possess
- "'Whereas YHWH was there'"—YHWH was there
- "'I will do according to your anger, and according to your envy'"—anger, envy
- "'I will make myself known among them, when I shall judge you'"—known when judging
- "'I have heard all your blasphemies'"—heard
- "''They are laid desolate, they are given us to devour''"—Edom's boast
- "'You have magnified yourselves against me'"—magnified
- "'Have multiplied your words against me'"—multiplied
- "'When the whole earth rejoices, I will make you desolate'"—ironic reversal
- "'As you did rejoice over the inheritance of the house of Israel'"—rejoiced
- "'So will I do unto you'"—reciprocity
- "'You shall be desolate, O Mount Seir, and all Edom'"—desolate

**Modern Equivalent:** Ezekiel 35 expands the Edom oracle (cf. 25:12-14). Edom's sins: perpetual hatred, aiding Israel's enemies, claiming Israel's land. "YHWH was there" (35:10) is striking—YHWH remains connected to the land even when Israel is exiled. This sets up chapter 36's restoration of the mountains of Israel.

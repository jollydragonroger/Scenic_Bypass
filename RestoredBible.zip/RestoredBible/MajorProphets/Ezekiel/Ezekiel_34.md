# Ezekiel 34: The Shepherds of Israel and YHWH as Shepherd

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## Against the False Shepherds (34:1-10)

**34:1** And the word of YHWH came unto me, saying:

**34:2** "Son of man, prophesy against the shepherds of Israel, prophesy, and say unto them, even to the shepherds: Thus says the Lord YHWH: Woe unto the shepherds of Israel that have fed themselves! Should not the shepherds feed the sheep?

**34:3** "You did eat the fat, and you clothed you with the wool, you killed the fatlings; but you fed not the sheep.

**34:4** "The weak have you not strengthened, neither have you healed that which was sick, neither have you bound up that which was broken, neither have you brought back that which was driven away, neither have you sought that which was lost; but with force have you ruled over them and with rigor.

**34:5** "So were they scattered, because there was no shepherd; and they became food to all the beasts of the field, and were scattered.

**34:6** "My sheep wandered through all the mountains, and upon every high hill; yea, upon all the face of the earth were my sheep scattered, and there was none that did search or seek after them.

**34:7** "Therefore, you shepherds, hear the word of YHWH:

**34:8** "As I live," says the Lord YHWH, "surely, forasmuch as my sheep became a prey, and my sheep became food to all the beasts of the field, because there was no shepherd, neither did my shepherds search for my sheep, but the shepherds fed themselves, and fed not my sheep;

**34:9** "Therefore, you shepherds, hear the word of YHWH:

**34:10** "Thus says the Lord YHWH: Behold, I am against the shepherds; and I will require my sheep at their hand, and cause them to cease from feeding the sheep; neither shall the shepherds feed themselves any more; and I will deliver my sheep from their mouth, that they may not be food for them."

---

## YHWH as the Good Shepherd (34:11-16)

**34:11** For thus says the Lord YHWH: "Behold, I, even I, will search for my sheep, and will seek them out.

**34:12** "As a shepherd seeks out his flock in the day that he is among his sheep that are scattered abroad, so will I seek out my sheep; and I will deliver them out of all places whither they have been scattered in the day of clouds and thick darkness.

**34:13** "And I will bring them out from the peoples, and gather them from the countries, and will bring them into their own land; and I will feed them upon the mountains of Israel, by the watercourses, and in all the habitable places of the country.

**34:14** "I will feed them in a good pasture, and upon the high mountains of Israel shall their fold be; there shall they lie down in a good fold, and in a fat pasture shall they feed upon the mountains of Israel.

**34:15** "I will feed my sheep, and I will cause them to lie down," says the Lord YHWH.

**34:16** "I will seek that which was lost, and will bring back that which was driven away, and will bind up that which was broken, and will strengthen that which was sick; and the fat and the strong I will destroy; I will feed them with judgment."

---

## Judgment Between Sheep (34:17-22)

**34:17** "And as for you, O my flock, thus says the Lord YHWH: Behold, I judge between cattle and cattle, even the rams and the he-goats.

**34:18** "Seems it a small thing unto you to have fed upon the good pasture, but you must tread down with your feet the residue of your pasture? And to have drunk of the settled waters, but you must foul the residue with your feet?

**34:19** "And as for my sheep, they eat that which you have trodden with your feet, and they drink that which you have fouled with your feet.

**34:20** "Therefore thus says the Lord YHWH unto them: Behold, I, even I, will judge between the fat cattle and the lean cattle.

**34:21** "Because you thrust with side and with shoulder, and push all the weak with your horns, till you have scattered them abroad;

**34:22** "Therefore will I save my flock, and they shall no more be a prey; and I will judge between cattle and cattle."

---

## The Davidic Shepherd (34:23-31)

**34:23** "And I will set up one shepherd over them, and he shall feed them, even my servant David; he shall feed them, and he shall be their shepherd.

**34:24** "And I YHWH will be their God, and my servant David prince among them; I YHWH have spoken.

**34:25** "And I will make with them a covenant of peace, and will cause evil beasts to cease out of the land; and they shall dwell safely in the wilderness, and sleep in the woods.

**34:26** "And I will make them and the places round about my hill a blessing; and I will cause the shower to come down in its season; there shall be showers of blessing.

**34:27** "And the tree of the field shall yield its fruit, and the earth shall yield her increase, and they shall be safe in their land; and they shall know that I am YHWH, when I have broken the bars of their yoke, and have delivered them out of the hand of those that made bondmen of them.

**34:28** "And they shall no more be a prey to the nations, neither shall the beast of the earth devour them; but they shall dwell safely, and none shall make them afraid.

**34:29** "And I will raise up unto them a planting for renown, and they shall be no more consumed with famine in the land, neither bear the shame of the nations any more.

**34:30** "And they shall know that I YHWH their God am with them, and that they, the house of Israel, are my people," says the Lord YHWH.

**34:31** "And you my sheep, the sheep of my pasture, are men, and I am your God," says the Lord YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Against False Shepherds (34:1-10):**
**The Key Verse (34:2):**
"'Prophesy against the shepherds of Israel.'"

*Hinnave al-ro'ei Yisra'el*—against shepherds.

"'Woe unto the shepherds of Israel that have fed themselves!'"

*Hoy ro'ei Yisra'el asher hayu ro'im otam*—woe to shepherds.

"'Should not the shepherds feed the sheep?'"

*Ha-lo ha-tzon yir'u ha-ro'im*—feed sheep?

**Shepherds = Leaders:**
Kings, princes, priests—those responsible for the people.

**The Key Verses (34:3-4):**
"'You did eat the fat, and you clothed you with the wool.'"

*Et-ha-chelev tokhelu ve-et-ha-tzemer tilbashu*—ate fat, wore wool.

"'You killed the fatlings.'"

*Ha-beri'ah tizbachu*—killed fatlings.

"'But you fed not the sheep.'"

*Ha-tzon lo tir'u*—didn't feed sheep.

"'The weak have you not strengthened.'"

*Et-ha-nachalot lo chizzaqtem*—didn't strengthen weak.

"'Neither have you healed that which was sick.'"

*Ve-et-ha-cholah lo rippitem*—didn't heal sick.

"'Neither have you bound up that which was broken.'"

*Ve-la-nishberet lo chavashtem*—didn't bind broken.

"'Neither have you brought back that which was driven away.'"

*Ve-et-ha-niddachat lo hashevoten*—didn't bring back driven.

"'Neither have you sought that which was lost.'"

*Ve-et-ha-ovedet lo viqqashtem*—didn't seek lost.

"'With force have you ruled over them and with rigor.'"

*U-ve-choזeq reדitem otam u-ve-farekh*—ruled harshly.

**The Key Verses (34:5-6):**
"'They were scattered, because there was no shepherd.'"

*Va-tefutzzenah mi-beli ro'eh*—scattered, no shepherd.

"'They became food to all the beasts of the field.'"

*Va-tihyenah le-okhlah le-khol-chayyat ha-sadeh*—food for beasts.

"'My sheep wandered through all the mountains.'"

*Va-yishgu tzoni be-khol-he-harim*—wandered.

"'Upon every high hill.'"

*Ve-al kol-giv'ah ramah*—high hills.

"'Upon all the face of the earth were my sheep scattered.'"

*Ve-al kol-penei ha-aretz nafotzu tzoni*—scattered on earth.

"'There was none that did search or seek after them.'"

*Ve-ein doresh ve-ein mevaqesh*—none sought.

**The Key Verses (34:8-10):**
"''As I live,' says the Lord YHWH."

*Chai-ani ne'um Adonai YHWH*—as I live.

"'My sheep became a prey.'"

*Vihyu tzoni le-vaz*—became prey.

"'My sheep became food to all the beasts of the field.'"

*Va-tihyenah tzoni le-okhlah le-khol-chayyat ha-sadeh*—food for beasts.

"'Because there was no shepherd.'"

*Me-ein ro'eh*—no shepherd.

"'Neither did my shepherds search for my sheep.'"

*Ve-lo-darshu ro'ai et-tzoni*—didn't search.

"'The shepherds fed themselves, and fed not my sheep.'"

*Va-yir'u ha-ro'im otam ve-et-tzoni lo ra'u*—fed selves.

"'Behold, I am against the shepherds.'"

*Hineni el-ha-ro'im*—against shepherds.

"'I will require my sheep at their hand.'"

*Ve-darashti et-tzoni mi-yadam*—require.

"'Cause them to cease from feeding the sheep.'"

*Ve-hishbattim me-re'ot tzon*—cease.

"'I will deliver my sheep from their mouth.'"

*Ve-hitztzalti tzoni mi-pihem*—deliver.

**YHWH as Shepherd (34:11-16):**
**The Key Verses (34:11-12):**
"'Behold, I, even I, will search for my sheep.'"

*Hineni-ani ve-darashti et-tzoni*—I myself search.

"'Will seek them out.'"

*U-viqqartim*—seek out.

"'As a shepherd seeks out his flock.'"

*Ke-vaqqarat ro'eh edro*—shepherd seeks flock.

"'In the day that he is among his sheep that are scattered abroad.'"

*Be-yom heyoto be-tokh-tzono nifrashot*—scattered.

"'So will I seek out my sheep.'"

*Ken avaqer et-tzoni*—I seek.

"'I will deliver them out of all places whither they have been scattered.'"

*Ve-hitztzaltim mi-kol-ha-meqomot asher nafotzu sham*—deliver.

"'In the day of clouds and thick darkness.'"

*Be-yom anan va-arafel*—cloudy, dark day.

**The Key Verses (34:13-15):**
"'I will bring them out from the peoples.'"

*Ve-hotzеtim min-ha-ammim*—bring out.

"'Gather them from the countries.'"

*Ve-qibbaתztim min-ha-aratzot*—gather.

"'Will bring them into their own land.'"

*Va-havi'otim el-admatam*—to their land.

"'I will feed them upon the mountains of Israel.'"

*U-re'itim el-harei Yisra'el*—feed on mountains.

"'By the watercourses.'"

*Ba-afiqim*—watercourses.

"'In all the habitable places of the country.'"

*U-ve-khol moshevot ha-aretz*—habitable places.

"'I will feed them in a good pasture.'"

*Be-mir'eh tov er'eh otam*—good pasture.

"'Upon the high mountains of Israel shall their fold be.'"

*U-ve-har merom Yisra'el yihyeh neveihem*—fold.

"'There shall they lie down in a good fold.'"

*Sham tirbatznah be-neveh tov*—lie down.

"'In a fat pasture shall they feed.'"

*U-mir'eh shamen tir'enah*—fat pasture.

"'I will feed my sheep.'"

*Ani er'eh tzoni*—I feed.

"'I will cause them to lie down.'"

*Va-ani arbitzem*—I cause rest.

**The Key Verse (34:16):**
"'I will seek that which was lost.'"

*Et-ha-ovedet avaqesh*—seek lost.

"'Will bring back that which was driven away.'"

*Ve-et-ha-niddachat ashiv*—bring back driven.

"'Will bind up that which was broken.'"

*Ve-la-nishberet echabbosh*—bind broken.

"'Will strengthen that which was sick.'"

*Ve-et-ha-cholah achazeq*—strengthen sick.

"'The fat and the strong I will destroy.'"

*Ve-et-ha-shemenah ve-et-ha-chazaqah ashmid*—destroy strong.

"'I will feed them with judgment.'"

*Er'ennah ve-mishpat*—feed with judgment.

**Judgment Between Sheep (34:17-22):**
"'Behold, I judge between cattle and cattle.'"

*Hineni shofet bein-seh la-seh*—judge between.

"'Even the rams and the he-goats.'"

*La-eilim ve-la-attudim*—rams, goats.

"'You have fed upon the good pasture, but you must tread down with your feet the residue.'"

*Ha-me'at mikkem ha-mir'eh ha-tov tir'u ve-yeter mir'eikhem tirmesu be-ragleikhem*—tread.

"'To have drunk of the settled waters, but you must foul the residue.'"

*U-mishqa mayim tishtו ve-et-ha-notarim be-ragleikhem tirposu*—foul.

"'Because you thrust with side and with shoulder.'"

*Ya'an be-tzad u-ve-khatef tidhofu*—thrust.

"'Push all the weak with your horns.'"

*Ve-khol-ha-nachalot be-qarneikem tenaggechu*—push weak.

"'Till you have scattered them abroad.'"

*Ad asher hifitzzotem otam el-ha-chutzah*—scattered.

"'I will save my flock.'"

*Ve-hosha'ti le-tzoni*—save flock.

**Davidic Shepherd (34:23-31):**
**The Key Verses (34:23-24):**
"'I will set up one shepherd over them.'"

*Va-haqimoti aleihem ro'eh echad*—one shepherd.

"'He shall feed them, even my servant David.'"

*Ve-ra'ah otam et avdi David*—my servant David.

"'He shall feed them, and he shall be their shepherd.'"

*Hu yir'eh otam ve-hu yihyeh lahem le-ro'eh*—he feeds, shepherds.

"'I YHWH will be their God.'"

*Va-ani YHWH ehyeh lahem le-Elohim*—I YHWH their God.

"'My servant David prince among them.'"

*Ve-avdi David nasi be-tokham*—David prince.

**The Key Verses (34:25-28):**
"'I will make with them a covenant of peace.'"

*Ve-kharati lahem berit shalom*—covenant of peace.

"'Will cause evil beasts to cease out of the land.'"

*Ve-hishbatti chayyah ra'ah min-ha-aretz*—evil beasts cease.

"'They shall dwell safely in the wilderness.'"

*Ve-yashvu ba-midbar la-vetach*—dwell safely.

"'Sleep in the woods.'"

*Ve-yashnu ba-ye'arim*—sleep in woods.

"'I will make them and the places round about my hill a blessing.'"

*Ve-natatti otam u-sevivot giv'ati berakhah*—blessing.

"'I will cause the shower to come down in its season.'"

*Ve-horadti ha-geshem be-itto*—rain in season.

"'Showers of blessing.'"

*Gishmei verakhah yihyu*—showers of blessing.

"'The tree of the field shall yield its fruit.'"

*Ve-natan etz ha-sadeh et-piryo*—tree yields.

"'The earth shall yield her increase.'"

*Ve-ha-aretz titten yevulah*—earth yields.

"'They shall be safe in their land.'"

*Ve-hayu al-admatam la-vetach*—safe.

"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—recognition.

"'When I have broken the bars of their yoke.'"

*Be-shivri et-mottot ullam*—broken yoke.

"'Have delivered them out of the hand of those that made bondmen of them.'"

*Ve-hitztzaltim mi-yad ha-ovedim bahem*—delivered.

"'They shall no more be a prey to the nations.'"

*Ve-lo yihyu od baz la-goyim*—not prey.

"'They shall dwell safely, and none shall make them afraid.'"

*Ve-yashvu la-vetach ve-ein macharid*—none afraid.

**The Key Verses (34:29-31):**
"'I will raise up unto them a planting for renown.'"

*Va-haqimoti lahem matta le-shem*—planting for renown.

"'They shall be no more consumed with famine.'"

*Ve-lo yihyu od asufei ra'av*—no famine.

"'Neither bear the shame of the nations.'"

*Ve-lo yis'u od kelimmat ha-goyim*—no shame.

"'They shall know that I YHWH their God am with them.'"

*Ve-yad'u ki ani YHWH Eloheihem ittam*—I am with them.

"'They, the house of Israel, are my people.'"

*Ve-hemmah ammi beit Yisra'el*—my people.

"'You my sheep, the sheep of my pasture, are men.'"

*Ve-atten tzoni tzon mar'iti adam attem*—you are men.

"'I am your God.'"

*Va-ani Eloheikhem*—your God.

**Archetypal Layer:** Ezekiel 34 is the **shepherd chapter**, containing **"Woe unto the shepherds of Israel that have fed themselves" (34:2)**, **"with force have you ruled over them" (34:4)**, **"I, even I, will search for my sheep" (34:11)**, **"I will seek that which was lost" (34:16)**—echoed in Luke 15, **"I will set up one shepherd over them, even my servant David" (34:23)**, and **"I will make with them a covenant of peace" (34:25)**.

**Ethical Inversion Applied:**
- "'Prophesy against the shepherds of Israel'"—against shepherds
- "'Woe unto the shepherds... that have fed themselves'"—fed themselves
- "'Should not the shepherds feed the sheep?'"—should feed
- "'You did eat the fat, and you clothed you with the wool'"—took for selves
- "'You killed the fatlings; but you fed not the sheep'"—didn't feed
- "'The weak have you not strengthened'"—didn't strengthen
- "'Neither have you healed that which was sick'"—didn't heal
- "'Neither have you bound up that which was broken'"—didn't bind
- "'Neither have you brought back that which was driven away'"—didn't bring back
- "'Neither have you sought that which was lost'"—didn't seek
- "'With force have you ruled over them'"—ruled harshly
- "'They were scattered, because there was no shepherd'"—no shepherd
- "'They became food to all the beasts'"—prey
- "'There was none that did search or seek'"—none sought
- "'I am against the shepherds'"—against
- "'I will require my sheep at their hand'"—require
- "'I will deliver my sheep from their mouth'"—deliver
- "'I, even I, will search for my sheep'"—I search
- "'As a shepherd seeks out his flock'"—shepherd seeks
- "'I will deliver them out of all places'"—deliver
- "'I will bring them out from the peoples'"—bring out
- "'Gather them from the countries'"—gather
- "'Bring them into their own land'"—to land
- "'I will feed them upon the mountains of Israel'"—feed
- "'I will feed them in a good pasture'"—good pasture
- "'I will feed my sheep'"—I feed
- "'I will cause them to lie down'"—rest
- "'I will seek that which was lost'"—seek lost
- "'Will bring back that which was driven away'"—bring back
- "'Will bind up that which was broken'"—bind
- "'Will strengthen that which was sick'"—strengthen
- "'I judge between cattle and cattle'"—judge between
- "'You have fed upon the good pasture, but you must tread down'"—tread
- "'Because you thrust with side and with shoulder'"—thrust
- "'Push all the weak with your horns'"—push weak
- "'I will save my flock'"—save
- "'I will set up one shepherd over them'"—one shepherd
- "'Even my servant David'"—David
- "'He shall feed them, and he shall be their shepherd'"—David shepherds
- "'I YHWH will be their God'"—YHWH their God
- "'My servant David prince among them'"—David prince
- "'I will make with them a covenant of peace'"—covenant of peace
- "'Will cause evil beasts to cease'"—evil beasts cease
- "'They shall dwell safely'"—dwell safely
- "'I will cause the shower to come down... showers of blessing'"—blessing
- "'They shall be safe in their land'"—safe
- "'I have broken the bars of their yoke'"—broken yoke
- "'They shall no more be a prey'"—not prey
- "'None shall make them afraid'"—none afraid
- "'They shall know that I YHWH their God am with them'"—with them
- "'You my sheep... are men, and I am your God'"—I your God

**Modern Equivalent:** Ezekiel 34 indicts Israel's leaders (shepherds) and promises YHWH will shepherd directly. "I will seek that which was lost" (34:16) underlies Jesus' parable (Luke 15). The "one shepherd... my servant David" (34:23) is messianic. "Covenant of peace" (34:25) begins restoration themes.

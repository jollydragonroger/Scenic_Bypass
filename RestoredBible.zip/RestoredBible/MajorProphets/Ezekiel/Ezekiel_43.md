# Ezekiel 43: The Glory Returns to the Temple

*From the Hebrew: וַיּוֹלִכֵנִי אֶל־הַשַּׁעַר (Va-Yolikheni El-Ha-Sha'ar) — And He Led Me to the Gate*

---

## The Glory Returns (43:1-9)

**43:1** And he led me to the gate, even the gate that looks toward the east;

**43:2** And, behold, the glory of the God of Israel came from the way of the east; and his voice was like the sound of many waters; and the earth shone with his glory.

**43:3** And the appearance of the vision which I saw was like the vision that I saw when I came to destroy the city; and the visions were like the vision that I saw by the river Chebar; and I fell upon my face.

**43:4** And the glory of YHWH came into the house by the way of the gate whose prospect is toward the east.

**43:5** And a spirit took me up, and brought me into the inner court; and, behold, the glory of YHWH filled the house.

**43:6** And I heard one speaking unto me out of the house; and a man stood by me.

**43:7** And he said unto me: "Son of man, this is the place of my throne, and the place of the soles of my feet, where I will dwell in the midst of the children of Israel for ever; and the house of Israel shall no more defile my holy name, neither they, nor their kings, by their harlotry, and by the carcasses of their kings in their high places;

**43:8** "In their setting of their threshold by my threshold, and their doorpost beside my doorpost, and there was but the wall between me and them; and they have defiled my holy name by their abominations which they have committed; wherefore I consumed them in my anger.

**43:9** "Now let them put away their harlotry, and the carcasses of their kings, far from me, and I will dwell in the midst of them for ever."

---

## The Temple Ordinances (43:10-12)

**43:10** "You, son of man, describe the house to the house of Israel, that they may be ashamed of their iniquities; and let them measure the pattern.

**43:11** "And if they be ashamed of all that they have done, make known unto them the form of the house, and the fashion thereof, and the goings out thereof, and the comings in thereof, and all the forms thereof, and all the ordinances thereof, and all the forms thereof, and all the laws thereof, and write it in their sight; that they may keep the whole form thereof, and all the ordinances thereof, and do them.

**43:12** "This is the law of the house: upon the top of the mountain the whole limit thereof round about shall be most holy. Behold, this is the law of the house."

---

## The Altar (43:13-17)

**43:13** And these are the measures of the altar by cubits—the cubit is a cubit and a hand-breadth: the bottom shall be a cubit, and the breadth a cubit, and the border thereof by the edge thereof round about a span; and this shall be the base of the altar.

**43:14** And from the bottom upon the ground to the lower ledge shall be two cubits, and the breadth one cubit; and from the lesser ledge to the greater ledge shall be four cubits, and the breadth a cubit.

**43:15** And the upper altar shall be four cubits; and from the altar hearth and upward there shall be four horns.

**43:16** And the altar hearth shall be twelve cubits long by twelve broad, square in the four sides thereof.

**43:17** And the ledge shall be fourteen cubits long by fourteen broad in the four sides thereof; and the border about it shall be half a cubit; and the bottom thereof shall be a cubit about; and the steps thereof shall look toward the east.

---

## The Altar's Consecration (43:18-27)

**43:18** And he said unto me: "Son of man, thus says the Lord YHWH: These are the ordinances of the altar in the day when they shall make it, to offer burnt-offerings thereon, and to dash blood against it.

**43:19** "You shall give to the priests the Levites that are of the seed of Zadok, who are near unto me, to minister unto me," says the Lord YHWH, "a young bullock for a sin-offering.

**43:20** "And you shall take of the blood thereof, and put it on the four horns of it, and on the four corners of the ledge, and upon the border round about; thus shall you purify it and make atonement for it.

**43:21** "You shall also take the bullock of the sin-offering, and it shall be burnt in the appointed place of the house, without the sanctuary.

**43:22** "And on the second day you shall offer a he-goat without blemish for a sin-offering; and they shall purify the altar, as they did purify it with the bullock.

**43:23** "When you have made an end of purifying it, you shall offer a young bullock without blemish, and a ram out of the flock without blemish.

**43:24** "And you shall present them before YHWH, and the priests shall cast salt upon them, and they shall offer them up for a burnt-offering unto YHWH.

**43:25** "Seven days shall you prepare every day a goat for a sin-offering; they shall also prepare a young bullock, and a ram out of the flock, without blemish.

**43:26** "Seven days shall they make atonement for the altar and purify it; so shall they consecrate it.

**43:27** "And when they have accomplished the days, it shall be that upon the eighth day, and forward, the priests shall make your burnt-offerings upon the altar, and your peace-offerings; and I will accept you," says the Lord YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Glory Returns (43:1-9):**
**The Key Verses (43:1-2):**
"He led me to the gate, even the gate that looks toward the east."

*Va-yolikheni el-ha-sha'ar sha'ar asher panav derekh ha-qadim*—east gate.

"Behold, the glory of the God of Israel came from the way of the east."

*Ve-hinneh kevod Elohei Yisra'el ba mi-derekh ha-qadim*—glory comes.

"His voice was like the sound of many waters."

*Ve-qolo ke-qol mayim rabbim*—many waters.

"The earth shone with his glory."

*Ve-ha-aretz he'irah mi-kevodo*—earth shone.

**Glory Returns:**
The glory that departed in chapters 10-11 returns from the east.

**The Key Verse (43:3):**
"The appearance of the vision which I saw was like the vision that I saw when I came to destroy the city."

*U-ke-mar'eh ha-mar'ah asher ra'iti ke-mar'ah asher-ra'iti be-vo'i le-shachet et-ha-ir*—like before.

"The visions were like the vision that I saw by the river Chebar."

*U-mar'ot ke-mar'ah asher ra'iti el-nehar Kevar*—like Chebar.

"I fell upon my face."

*Va-eppol el-panai*—fell.

**The Key Verses (43:4-5):**
"The glory of YHWH came into the house by the way of the gate... toward the east."

*U-khevod YHWH ba el-ha-bayit derekh sha'ar asher panav derekh ha-qadim*—glory enters.

"A spirit took me up, and brought me into the inner court."

*Va-tissa'eni ruach va-tevi'eni el-he-chatzer ha-penimit*—spirit brings.

"Behold, the glory of YHWH filled the house."

*Ve-hinneh male khevod-YHWH ha-bayit*—glory fills.

**The Key Verses (43:6-9):**
"I heard one speaking unto me out of the house."

*Va-eshma middabber elai mi-beit*—voice from house.

"A man stood by me."

*Ve-ish hayah omed etzli*—man stood by.

"'This is the place of my throne.'"

*Et-meqom kis'י*—my throne.

"'The place of the soles of my feet.'"

*Ve-et-meqom kappot raglai*—soles of feet.

"'Where I will dwell in the midst of the children of Israel for ever.'"

*Asher eshkon-sham be-tokh benei-Yisra'el le-olam*—dwell forever.

"'The house of Israel shall no more defile my holy name.'"

*Ve-lo yetamme'u od beit-Yisra'el shem qodshi*—no more defile.

"'Neither they, nor their kings, by their harlotry.'"

*Hemmah u-malkheihem be-znutam*—kings' harlotry.

"'By the carcasses of their kings in their high places.'"

*U-ve-figrei malkheihem bamotam*—carcasses.

"'In their setting of their threshold by my threshold.'"

*Be-tittam sippam et-sippi*—threshold by threshold.

"'Their doorpost beside my doorpost.'"

*U-mezuzatam etzel mezuzati*—doorpost by doorpost.

"'There was but the wall between me and them.'"

*Ve-ha-qir beini u-veineihem*—only wall between.

"'They have defiled my holy name by their abominations.'"

*Va-yetamme'u et-shem qodshi be-to'avotam*—defiled name.

"'Wherefore I consumed them in my anger.'"

*Va-akhal otam be-appi*—consumed.

"'Now let them put away their harlotry... far from me.'"

*Attah yerachaqu et-znutam... me-oti*—put away.

"'I will dwell in the midst of them for ever.'"

*Ve-shakhanti ve-tokham le-olam*—dwell forever.

**Temple Ordinances (43:10-12):**
**The Key Verses (43:10-11):**
"'Describe the house to the house of Israel.'"

*Hagged et-beit-Yisra'el et-ha-bayit*—describe.

"'That they may be ashamed of their iniquities.'"

*Ve-yikkallemu me-avonotam*—be ashamed.

"'Let them measure the pattern.'"

*U-maddu et-tokhonit*—measure pattern.

"'If they be ashamed of all that they have done.'"

*Ve-im-niklemu mi-kol asher-asu*—if ashamed.

"'Make known unto them the form of the house.'"

*Tzurat ha-bayit*—form.

"'The fashion thereof.'"

*U-tekhnato*—fashion.

"'The goings out thereof, and the comings in thereof.'"

*U-motza'av u-mova'av*—exits, entrances.

"'All the forms thereof, and all the ordinances thereof.'"

*Ve-khol-tzurotav ve-et-kol-chuqqotav*—forms, ordinances.

"'All the laws thereof.'"

*Ve-khol-torotav*—laws.

"'Write it in their sight.'"

*U-khetov le-eineihem*—write.

"'That they may keep the whole form thereof.'"

*Ve-yishmeru et-kol-tzurato*—keep form.

"'And all the ordinances thereof, and do them.'"

*Ve-et-kol-chuqqotav ve-asu otam*—do ordinances.

**The Key Verse (43:12):**
"'This is the law of the house.'"

*Zot torat ha-bayit*—law of house.

"'Upon the top of the mountain the whole limit thereof round about shall be most holy.'"

*Al-rosh ha-har kol-gevulo saviv saviv qodesh qodashim*—most holy.

"'Behold, this is the law of the house.'"

*Hinneh-zot torat ha-bayit*—law of house.

**Altar (43:13-17):**
"These are the measures of the altar by cubits."

*Ve-elleh middot ha-mizbeach ba-ammot*—altar measures.

"The cubit is a cubit and a hand-breadth."

*Ammah ammah va-tefach*—long cubit.

"The altar hearth shall be twelve cubits long by twelve broad."

*Ve-ha-har'el sheteim esreh orekh bi-shteim esreh rochav*—12 x 12.

"Square in the four sides thereof."

*Ravua el-arba'at reva'av*—square.

"The steps thereof shall look toward the east."

*U-ma'alotehu penotot qadim*—steps face east.

**Ha-har'el:**
"Mountain of God"—the altar hearth.

**Altar's Consecration (43:18-27):**
**The Key Verses (43:18-19):**
"'These are the ordinances of the altar in the day when they shall make it.'"

*Elleh chuqqot ha-mizbeach be-yom he'asoto*—altar ordinances.

"'To offer burnt-offerings thereon, and to dash blood against it.'"

*Le-ha'alot alav olah ve-lizroq alav dam*—burnt offerings, blood.

"'You shall give to the priests the Levites that are of the seed of Zadok.'"

*Ve-natattah el-ha-kohanim ha-Leviyyim asher hem mi-zera Tzadoq*—Zadokites.

"'Who are near unto me, to minister unto me.'"

*Ha-qerovim elai le-shareteni*—near to minister.

"'A young bullock for a sin-offering.'"

*Par ben-baqar le-chattat*—bullock.

**The Key Verses (43:20-22):**
"'You shall take of the blood thereof.'"

*Ve-laqachta mi-damo*—take blood.

"'Put it on the four horns of it, and on the four corners of the ledge.'"

*Ve-natattah al-arba qarnotav ve-el-arba pinnot ha-azarah*—horns, corners.

"'Upon the border round about.'"

*Ve-el-ha-gevul saviv*—border.

"'Thus shall you purify it and make atonement for it.'"

*Ve-chitteto ve-kippartahu*—purify, atone.

"'The bullock of the sin-offering... shall be burnt in the appointed place.'"

*Ve-laqachta et-ha-par ha-chattat u-serafו be-mifqad ha-bayit*—burnt.

"'Without the sanctuary.'"

*Mi-chutz la-miqdash*—outside.

"'On the second day you shall offer a he-goat without blemish for a sin-offering.'"

*U-va-yom ha-sheni taqriv se'ir-izzim tamim le-chattat*—goat.

"'They shall purify the altar, as they did purify it with the bullock.'"

*Ve-chitte'u et-ha-mizbeach ka-asher chitte'u ba-par*—purify.

**The Key Verses (43:23-27):**
"'When you have made an end of purifying it.'"

*Be-khallotkha me-chatte*—finished purifying.

"'You shall offer a young bullock without blemish.'"

*Ve-hiqravta par ben-baqar tamim*—bullock.

"'And a ram out of the flock without blemish.'"

*Ve-ayil min-ha-tzon tamim*—ram.

"'The priests shall cast salt upon them.'"

*Ve-hishlikhu ha-kohanim aleihem melach*—salt.

"'They shall offer them up for a burnt-offering unto YHWH.'"

*Ve-he'elu otam olah la-YHWH*—burnt offering.

"'Seven days shall you prepare every day a goat for a sin-offering.'"

*Shiv'at yamim ta'aseh se'ir-chattat la-yom*—seven days.

"'They shall also prepare a young bullock, and a ram.'"

*U-far ben-baqar ve-ayil min-ha-tzon temimim ya'asu*—bullock, ram.

"'Seven days shall they make atonement for the altar and purify it.'"

*Shiv'at yamim yechapperu et-ha-mizbeach u-tiharu oto*—atone, purify.

"'So shall they consecrate it.'"

*U-mille'u yado*—consecrate.

"'Upon the eighth day, and forward.'"

*Ve-hayah mi-yom ha-shemini va-hal'ah*—eighth day on.

"'The priests shall make your burnt-offerings upon the altar.'"

*Ya'asu ha-kohanim al-ha-mizbeach et-oloteikhem*—burnt offerings.

"'And your peace-offerings.'"

*Ve-et-shalmeikem*—peace offerings.

"'I will accept you.'"

*Ve-ratziti etkhem*—accept you.

**Archetypal Layer:** Ezekiel 43 is a **pivotal chapter**, containing **the return of YHWH's glory from the east (43:1-5)**, **"the glory of YHWH filled the house" (43:5)**, **"This is the place of my throne, and the place of the soles of my feet" (43:7)**, **"I will dwell in the midst of them for ever" (43:7, 9)**, **"This is the law of the house: upon the top of the mountain... most holy" (43:12)**, **altar measurements (43:13-17)**, and **seven-day consecration with Zadokite priests (43:18-27)**.

**Ethical Inversion Applied:**
- "He led me to the gate... that looks toward the east"—east gate
- "The glory of the God of Israel came from the way of the east"—glory comes
- "His voice was like the sound of many waters"—many waters
- "The earth shone with his glory"—earth shone
- "The appearance of the vision... was like the vision that I saw when I came to destroy"—like before
- "Like the vision... by the river Chebar"—like Chebar
- "I fell upon my face"—fell
- "The glory of YHWH came into the house"—glory enters
- "A spirit took me up"—spirit carries
- "The glory of YHWH filled the house"—glory fills
- "I heard one speaking unto me out of the house"—voice from house
- "'This is the place of my throne'"—throne
- "'The place of the soles of my feet'"—feet
- "'Where I will dwell in the midst of the children of Israel for ever'"—dwell forever
- "'The house of Israel shall no more defile my holy name'"—no more defile
- "'By the carcasses of their kings in their high places'"—past sins
- "'In their setting of their threshold by my threshold'"—too close
- "'They have defiled my holy name by their abominations'"—defiled
- "'Now let them put away their harlotry'"—put away
- "'I will dwell in the midst of them for ever'"—dwell forever
- "'Describe the house to the house of Israel'"—describe
- "'That they may be ashamed of their iniquities'"—ashamed
- "'Let them measure the pattern'"—measure
- "'Make known unto them the form of the house'"—form
- "'Write it in their sight'"—write
- "'This is the law of the house'"—law of house
- "'Upon the top of the mountain... most holy'"—most holy
- "These are the measures of the altar"—altar measures
- "The altar hearth shall be twelve cubits long by twelve broad"—12 x 12
- "The steps thereof shall look toward the east"—steps east
- "'These are the ordinances of the altar'"—ordinances
- "'You shall give to the priests... of the seed of Zadok'"—Zadokites
- "'Who are near unto me, to minister unto me'"—minister
- "'You shall take of the blood... put it on the four horns'"—blood, horns
- "'Thus shall you purify it and make atonement'"—purify, atone
- "'Seven days shall they make atonement for the altar'"—seven days
- "'So shall they consecrate it'"—consecrate
- "'Upon the eighth day, and forward'"—eighth day on
- "'I will accept you'"—accept

**Modern Equivalent:** Ezekiel 43 is climactic—YHWH's glory returns! The glory that departed in chapters 10-11 returns from the east (43:2-4) and fills the new temple. "Place of my throne and... soles of my feet" (43:7) emphasizes YHWH's permanent dwelling. The altar and its seven-day consecration prepare for ongoing worship.

# Ezekiel 13: Against False Prophets

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## Against False Male Prophets (13:1-16)

**13:1** And the word of YHWH came unto me, saying:

**13:2** "Son of man, prophesy against the prophets of Israel that prophesy, and say unto them that prophesy out of their own heart: Hear the word of YHWH:

**13:3** "Thus says the Lord YHWH: Woe unto the vile prophets, that follow their own spirit, and things which they have not seen!

**13:4** "O Israel, your prophets have been like foxes in ruins.

**13:5** "You have not gone up into the breaches, neither made up the hedge for the house of Israel, to stand in the battle in the day of YHWH.

**13:6** "They have seen vanity and lying divination, that say: 'YHWH says'; and YHWH has not sent them; yet they hope that the word would be confirmed.

**13:7** "Have you not seen a vain vision, and have you not spoken a lying divination, whereas you say: 'YHWH says'; albeit I have not spoken?

**13:8** "Therefore thus says the Lord YHWH: Because you have spoken vanity, and seen lies, therefore, behold, I am against you," says the Lord YHWH.

**13:9** "And my hand shall be against the prophets that see vanity, and that divine lies; they shall not be in the council of my people, neither shall they be written in the register of the house of Israel, neither shall they enter into the land of Israel; and you shall know that I am the Lord YHWH.

**13:10** "Because, even because they have misled my people, saying: 'Peace,' and there is no peace; and when one builds up a wall, behold, they daub it with whited plaster;

**13:11** "Say unto them that daub it with whited plaster, that it shall fall; there shall be an overflowing shower, and you, O great hailstones, shall fall, and a stormy wind shall rend it.

**13:12** "Lo, when the wall is fallen, shall it not be said unto you: 'Where is the daubing wherewith you have daubed it?'

**13:13** "Therefore thus says the Lord YHWH: I will even rend it with a stormy wind in my fury; and there shall be an overflowing shower in my anger, and great hailstones in fury to consume it.

**13:14** "So will I break down the wall that you have daubed with whited plaster, and bring it down to the ground, so that the foundation thereof shall be uncovered; and it shall fall, and you shall be consumed in the midst thereof; and you shall know that I am YHWH.

**13:15** "Thus will I spend my fury upon the wall, and upon them that have daubed it with whited plaster; and I will say unto you: 'The wall is no more, neither they that daubed it';

**13:16** "To wit, the prophets of Israel that prophesy concerning Jerusalem, and that see visions of peace for her, and there is no peace," says the Lord YHWH.

---

## Against False Female Prophets (13:17-23)

**13:17** "And you, son of man, set your face against the daughters of your people, that prophesy out of their own heart; and prophesy against them,

**13:18** "And say: Thus says the Lord YHWH: Woe to the women that sew cushions upon all elbows, and make kerchiefs for the head of persons of every stature to hunt souls! Will you hunt the souls of my people, and save souls alive for yourselves?

**13:19** "And you have profaned me among my people for handfuls of barley and for pieces of bread, to slay the souls that should not die, and to save the souls alive that should not live, by your lying to my people that hearken unto lies.

**13:20** "Wherefore thus says the Lord YHWH: Behold, I am against your cushions, wherewith you there hunt the souls as birds, and I will tear them from your arms; and I will let the souls go, even the souls that you hunt as birds.

**13:21** "Your kerchiefs also will I tear, and deliver my people out of your hand, and they shall be no more in your hand to be hunted; and you shall know that I am YHWH.

**13:22** "Because with lies you have made the heart of the righteous sad, whom I have not made sad; and strengthened the hands of the wicked, that he should not return from his wicked way, that he might be saved alive;

**13:23** "Therefore you shall no more see vanity, nor divine divinations; and I will deliver my people out of your hand; and you shall know that I am YHWH."

---

## Synthesis Notes

**Key Restorations:**

**False Male Prophets (13:1-16):**
**The Key Verse (13:2):**
"'Prophesy against the prophets of Israel that prophesy.'"

*Hinnave el-nevi'ei Yisra'el ha-nibbe'im*—against prophets.

"'Say unto them that prophesy out of their own heart.'"

*Ve-amarta li-nevi'ei mi-libbam*—from own heart.

"'Hear the word of YHWH.'"

*Shim'u devar-YHWH*—hear.

**The Key Verse (13:3):**
"'Woe unto the vile prophets.'"

*Hoy al-ha-nevi'im ha-nevalim*—woe to vile.

"'That follow their own spirit.'"

*Asher holkhim achar rucham*—follow own spirit.

"'Things which they have not seen.'"

*U-leviltי ra'u*—not seen.

**The Key Verse (13:4):**
"'Your prophets have been like foxes in ruins.'"

*Ke-shu'alim be-choravot nevi'ekha Yisra'el hayu*—like foxes.

**Foxes in Ruins:**
Destructive scavengers rather than rebuilders.

**The Key Verse (13:5):**
"'You have not gone up into the breaches.'"

*Lo alitem ba-peratzot*—not in breaches.

"'Neither made up the hedge for the house of Israel.'"

*Ve-lo gedertem gader al-beit Yisra'el*—not built hedge.

"'To stand in the battle in the day of YHWH.'"

*La'amod ba-milchamah be-yom YHWH*—not stood.

**True Prophets:**
Should repair breaches and build walls—intercede and protect.

**The Key Verses (13:6-7):**
"'They have seen vanity and lying divination.'"

*Chazu shav ve-qesem kazav*—vanity, lies.

"'That say: YHWH says; and YHWH has not sent them.'"

*Ha-omerim ne'um-YHWH va-YHWH lo shelacham*—not sent.

"'Yet they hope that the word would be confirmed.'"

*Ve-yichalu le-qayem davar*—hope confirmed.

"'Have you not seen a vain vision?'"

*Ha-lo machazeh-shav chazitem*—vain vision?

"'Have you not spoken a lying divination?'"

*U-miqsam kazav amarttem*—lying divination?

"'Whereas you say: YHWH says; albeit I have not spoken?'"

*Ve-omerim ne'um-YHWH va-ani lo dibbartי*—I didn't speak.

**The Key Verses (13:8-9):**
"'Because you have spoken vanity, and seen lies.'"

*Ya'an dabberkhem shav va-chazitem kazav*—vanity, lies.

"'Behold, I am against you.'"

*Hineni aleikhem*—against you.

"'My hand shall be against the prophets that see vanity.'"

*Ve-hayetah yadi el-ha-nevi'im ha-chozim shav*—hand against.

"'They shall not be in the council of my people.'"

*Be-sod ammi lo yihyu*—not in council.

"'Neither shall they be written in the register of the house of Israel.'"

*U-vi-khetav beit-Yisra'el lo yikkatevu*—not written.

"'Neither shall they enter into the land of Israel.'"

*Ve-el-admat Yisra'el lo yavo'u*—not enter land.

**The Key Verses (13:10-12):**
"'They have misled my people, saying: Peace, and there is no peace.'"

*Ya'an u-ve-ya'an hit'u et-ammi lemor shalom ve-ein shalom*—false peace.

"'When one builds up a wall, behold, they daub it with whited plaster.'"

*Ve-hu boneh chayitz ve-hinnam tachim oto tafel*—whitewash.

"'Say unto them that daub it with whited plaster, that it shall fall.'"

*Emor el-tachei tafel ve-yippol*—will fall.

"'There shall be an overflowing shower, and you, O great hailstones, shall fall.'"

*Hayah geshem shotef ve-atten avnei elgavish tippelnah*—storm.

"'A stormy wind shall rend it.'"

*Ve-ruach se'arot teva'a*—wind rends.

"'Where is the daubing wherewith you have daubed it?'"

*Ayyeh ha-tiach asher tachtem*—where's whitewash?

**Whitewashed Wall:**
False prophets covered a weak wall with plaster—judgment's storm will expose it.

**The Key Verses (13:13-16):**
"'I will even rend it with a stormy wind in my fury.'"

*U-viqqa'tiha ruach se'arot be-chamati*—rend with storm.

"'There shall be an overflowing shower in my anger.'"

*Ve-geshem shotef be-appi yihyeh*—shower in anger.

"'Great hailstones in fury to consume it.'"

*Ve-avnei elgavish be-chemah le-khalah*—hail to consume.

"'I will break down the wall.'"

*Ve-harasti et-ha-qir*—break wall.

"'Bring it down to the ground, so that the foundation thereof shall be uncovered.'"

*Ve-higgatihu el-ha-aretz ve-nigelah yesodo*—foundation uncovered.

"'It shall fall, and you shall be consumed in the midst thereof.'"

*Ve-nafal vi-khlitem be-tokhah*—fall, consumed.

"'The prophets of Israel that prophesy concerning Jerusalem.'"

*Nevi'ei Yisra'el ha-nibbe'im el-Yerushalayim*—prophets of Jerusalem.

"'That see visions of peace for her, and there is no peace.'"

*Ve-ha-chozim lah chazon shalom ve-ein shalom*—false peace.

**False Female Prophets (13:17-23):**
**The Key Verse (13:17):**
"'Set your face against the daughters of your people.'"

*Sim panekha el-benot ammekha*—against daughters.

"'That prophesy out of their own heart.'"

*Ha-mitnabbe'ot mi-libbehen*—from own heart.

"'Prophesy against them.'"

*Ve-hinnave aleihen*—prophesy against.

**The Key Verses (13:18-19):**
"'Woe to the women that sew cushions upon all elbows.'"

*Hoy la-metapperot kesatot al-kol-atzzilei yadayim*—sew cushions.

"'Make kerchiefs for the head of persons of every stature.'"

*Ve-osot ha-mispachot al-rosh kol-qomah*—kerchiefs.

"'To hunt souls!'"

*Le-tzoded nefashot*—hunt souls.

"'Will you hunt the souls of my people?'"

*Ha-nefashot tetzodednah le-ammi*—hunt my people?

"'Save souls alive for yourselves?'"

*Ve-nefashot lakhen techayenah*—save for selves.

"'You have profaned me among my people for handfuls of barley.'"

*Va-techallenah oti el-ammi bi-sha'alei se'orim*—profaned for barley.

"'For pieces of bread.'"

*U-vi-fetotei lachem*—for bread.

"'To slay the souls that should not die.'"

*Le-hamit nefashot asher lo-temutanah*—kill innocent.

"'To save the souls alive that should not live.'"

*U-le-chayot nefashot asher lo-tichyenah*—save wicked.

"'By your lying to my people that hearken unto lies.'"

*Be-khazzavkhem le-ammi shom'ei khazav*—lying.

**Magic Practices:**
Cushions and kerchiefs were magical devices for binding or controlling souls.

**The Key Verses (13:20-21):**
"'I am against your cushions.'"

*Hineni el-kesatoteikhen*—against cushions.

"'Wherewith you there hunt the souls as birds.'"

*Asher atten metzodedot sham et-ha-nefashot le-forchot*—hunt souls.

"'I will tear them from your arms.'"

*Ve-qarati otam me-al zero'oteikhen*—tear off.

"'I will let the souls go.'"

*Ve-shillachti et-ha-nefashot*—release souls.

"'The souls that you hunt as birds.'"

*Asher atten metzodedot et-nefashot le-forchot*—hunted souls.

"'Your kerchiefs also will I tear.'"

*Ve-et-mispechoteikhen eqra*—tear kerchiefs.

"'Deliver my people out of your hand.'"

*Ve-hitztzalti et-ammi mi-yedkhen*—deliver.

"'They shall be no more in your hand to be hunted.'"

*Ve-lo-yihyu od be-yedkhen li-metzudah*—not hunted.

**The Key Verses (13:22-23):**
"'With lies you have made the heart of the righteous sad.'"

*Ya'an hakke'ot lev-tzaddiq sheqer*—saddened righteous.

"'Whom I have not made sad.'"

*Va-ani lo hikh'avtivu*—I didn't sadden.

"'Strengthened the hands of the wicked.'"

*U-le-chazzeq yedei rasha*—strengthened wicked.

"'That he should not return from his wicked way.'"

*Le-viltי-shuvo mi-darko ha-ra'ah*—not return.

"'That he might be saved alive.'"

*Le-chayoto*—be saved.

"'You shall no more see vanity.'"

*Lakhen shav lo techezaynah*—no more vanity.

"'Nor divine divinations.'"

*Ve-qesem lo tiqsamnah od*—no more divinations.

"'I will deliver my people out of your hand.'"

*Ve-hitztzalti et-ammi mi-yedkhen*—deliver.

**Archetypal Layer:** Ezekiel 13 condemns **false prophets who "follow their own spirit" (13:3)**, **"like foxes in ruins" (13:4)**, **"Peace, and there is no peace" (13:10)**, **the whitewashed wall metaphor (13:10-16)**, and **sorceresses who "hunt souls" with magic objects (13:18-21)**.

**Ethical Inversion Applied:**
- "'Prophesy against the prophets of Israel'"—against prophets
- "'That prophesy out of their own heart'"—own heart
- "'Woe unto the vile prophets'"—woe
- "'That follow their own spirit'"—own spirit
- "'Things which they have not seen'"—not seen
- "'Your prophets have been like foxes in ruins'"—foxes
- "'You have not gone up into the breaches'"—not in breaches
- "'Neither made up the hedge'"—not built hedge
- "'To stand in the battle in the day of YHWH'"—not stood
- "'They have seen vanity and lying divination'"—vanity, lies
- "'YHWH says; and YHWH has not sent them'"—not sent
- "'Have you not seen a vain vision?'"—vain
- "'YHWH says; albeit I have not spoken'"—I didn't speak
- "'I am against you'"—against
- "'My hand shall be against the prophets'"—hand against
- "'They shall not be in the council of my people'"—not in council
- "'Neither shall they be written in the register'"—not written
- "'Neither shall they enter into the land'"—not enter
- "'They have misled my people, saying: Peace, and there is no peace'"—false peace
- "'They daub it with whited plaster'"—whitewash
- "'It shall fall'"—will fall
- "'There shall be an overflowing shower, and... great hailstones'"—storm
- "'Where is the daubing?'"—where's whitewash?
- "'I will break down the wall'"—break wall
- "'The foundation thereof shall be uncovered'"—exposed
- "'That see visions of peace... and there is no peace'"—false peace
- "'Set your face against the daughters of your people'"—against women
- "'Woe to the women that sew cushions'"—cushions
- "'Make kerchiefs'"—kerchiefs
- "'To hunt souls'"—hunt souls
- "'You have profaned me... for handfuls of barley'"—profaned for barley
- "'To slay the souls that should not die'"—kill innocent
- "'To save the souls alive that should not live'"—save wicked
- "'I am against your cushions'"—against
- "'I will tear them from your arms'"—tear
- "'I will let the souls go'"—release
- "'With lies you have made the heart of the righteous sad'"—saddened righteous
- "'Strengthened the hands of the wicked'"—strengthened wicked
- "'I will deliver my people out of your hand'"—deliver

**Modern Equivalent:** Ezekiel 13 condemns false prophets of both genders. The whitewashed wall (13:10-16) became a metaphor for superficial religion (cf. Matthew 23:27). The sorceresses' magic (13:17-23) shows occult practices in Israel. "Peace, and there is no peace" (13:10) is Jeremiah's phrase (Jeremiah 6:14; 8:11).

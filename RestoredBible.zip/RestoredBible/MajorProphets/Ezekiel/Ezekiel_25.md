# Ezekiel 25: Oracles Against Neighboring Nations

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## Against Ammon (25:1-7)

**25:1** And the word of YHWH came unto me, saying:

**25:2** "Son of man, set your face toward the children of Ammon, and prophesy against them;

**25:3** "And say unto the children of Ammon: Hear the word of the Lord YHWH: Thus says the Lord YHWH: Because you said: Aha! Against my sanctuary, when it was profaned, and against the land of Israel, when it was made desolate, and against the house of Judah, when they went into captivity;

**25:4** "Therefore, behold, I will deliver you to the children of the east for a possession, and they shall set their encampments in you, and make their dwellings in you; they shall eat your fruit, and they shall drink your milk.

**25:5** "And I will make Rabbah a pasture for camels, and the children of Ammon a couching-place for flocks; and you shall know that I am YHWH.

**25:6** "For thus says the Lord YHWH: Because you have clapped your hands, and stamped with the feet, and rejoiced with all the disdain of your soul against the land of Israel;

**25:7** "Therefore, behold, I stretch out my hand upon you, and will deliver you for a spoil to the nations; and I will cut you off from the peoples, and I will cause you to perish out of the countries; I will destroy you, and you shall know that I am YHWH."

---

## Against Moab (25:8-11)

**25:8** Thus says the Lord YHWH: "Because that Moab and Seir do say: Behold, the house of Judah is like unto all the nations;

**25:9** "Therefore, behold, I will open the flank of Moab on the side of the cities, on the side of his cities which are on his frontiers, the glory of the country, Beth-jeshimoth, Baal-meon, and Kiriathaim,

**25:10** "Unto the children of the east, I will give them for a possession together with the children of Ammon, that the children of Ammon may not be remembered among the nations;

**25:11** "And I will execute judgments upon Moab; and they shall know that I am YHWH."

---

## Against Edom (25:12-14)

**25:12** Thus says the Lord YHWH: "Because that Edom has dealt against the house of Judah by taking vengeance, and has greatly offended, and revenged himself upon them;

**25:13** "Therefore thus says the Lord YHWH: I will stretch out my hand upon Edom, and will cut off man and beast from it; and I will make it desolate from Teman, and they of Dedan shall fall by the sword.

**25:14** "And I will lay my vengeance upon Edom by the hand of my people Israel; and they shall do in Edom according to my anger and according to my fury; and they shall know my vengeance," says the Lord YHWH.

---

## Against Philistia (25:15-17)

**25:15** Thus says the Lord YHWH: "Because the Philistines have dealt by revenge, and have taken vengeance with disdain of soul to destroy, for the old hatred;

**25:16** "Therefore thus says the Lord YHWH: Behold, I will stretch out my hand upon the Philistines, and I will cut off the Cherethites, and destroy the remnant of the sea-coast.

**25:17** "And I will execute great vengeance upon them with furious rebukes; and they shall know that I am YHWH, when I shall lay my vengeance upon them."

---

## Synthesis Notes

**Key Restorations:**

**Against Ammon (25:1-7):**
**The Key Verse (25:2):**
"'Set your face toward the children of Ammon.'"

*Sim panekha el-benei Ammon*—toward Ammon.

"'Prophesy against them.'"

*Ve-hinnave aleihem*—prophesy.

**The Key Verse (25:3):**
"'Because you said: Aha!'"

*Ya'an omrekh he'ach*—Aha!

"'Against my sanctuary, when it was profaned.'"

*El-miqdashi ki-nichāl*—sanctuary profaned.

"'Against the land of Israel, when it was made desolate.'"

*Ve-el-admat Yisra'el ki nashamah*—land desolate.

"'Against the house of Judah, when they went into captivity.'"

*Ve-el-beit Yehudah ki halekhu va-golah*—captivity.

**Ammon's Sin:**
Gloating over Jerusalem's fall.

**The Key Verses (25:4-5):**
"'I will deliver you to the children of the east for a possession.'"

*Hineni notenekha li-vnei-qedem le-morashah*—to easterners.

"'They shall set their encampments in you.'"

*Ve-yashevu tiroteihem bakh*—encampments.

"'They shall eat your fruit, and they shall drink your milk.'"

*Hemmah yokhelu piryekh ve-hemmah yishtu chlavekh*—eat, drink.

"'I will make Rabbah a pasture for camels.'"

*Ve-natatti et-Rabbah li-neveh gemalim*—camels.

"'The children of Ammon a couching-place for flocks.'"

*U-venei Ammon le-marbetz tzon*—flocks.

"'You shall know that I am YHWH.'"

*Vi-ydatem ki-ani YHWH*—recognition.

**The Key Verses (25:6-7):**
"'Because you have clapped your hands, and stamped with the feet.'"

*Ya'an machakha yad ve-raq'akha ve-regel*—clapped, stamped.

"'Rejoiced with all the disdain of your soul against the land of Israel.'"

*Va-tismach be-khol-sha'atakh be-nefesh el-admat Yisra'el*—rejoiced disdainfully.

"'I stretch out my hand upon you.'"

*Hineni natiti et-yadi alayikh*—hand upon.

"'Will deliver you for a spoil to the nations.'"

*U-netattikh le-vaz la-goyim*—spoil.

"'I will cut you off from the peoples.'"

*Ve-hikhratttikh min-ha-ammim*—cut off.

"'I will cause you to perish out of the countries.'"

*Ve-ha'avadtikh min-ha-aratzot*—perish.

"'I will destroy you.'"

*Ashmidekha*—destroy.

**Against Moab (25:8-11):**
**The Key Verse (25:8):**
"'Because that Moab and Seir do say.'"

*Ya'an emor Mo'av ve-Se'ir*—Moab and Seir say.

"'Behold, the house of Judah is like unto all the nations.'"

*Hinneh ke-khol-ha-goyim beit Yehudah*—like all nations.

**Moab's Sin:**
Denying Judah's uniqueness—claiming YHWH's people are no different.

**The Key Verses (25:9-11):**
"'I will open the flank of Moab on the side of the cities.'"

*Hineni potei'ach et-ketef Mo'av me-ha-arim*—open flank.

"'On the side of his cities which are on his frontiers.'"

*Me-arav mi-qetzeihu*—frontier cities.

"'The glory of the country.'"

*Tzevi aretz*—glory.

"'Beth-jeshimoth, Baal-meon, and Kiriathaim.'"

*Beit ha-Yeshimot Ba'al-Me'on ve-Qiryatayimah*—cities.

"'Unto the children of the east.'"

*Li-vnei-qedem*—easterners.

"'I will give them for a possession together with the children of Ammon.'"

*Al-benei Ammon u-netattihah le-morashah*—with Ammon.

"'That the children of Ammon may not be remembered among the nations.'"

*Lema'an lo-tizzakher benei-Ammon ba-goyim*—not remembered.

"'I will execute judgments upon Moab.'"

*U-ve-Mo'av e'eseh shefatim*—judgments.

**Against Edom (25:12-14):**
**The Key Verse (25:12):**
"'Because that Edom has dealt against the house of Judah by taking vengeance.'"

*Ya'an asot Edom be-naqom naqam le-veit Yehudah*—vengeance.

"'Has greatly offended.'"

*Va-ye'eshemu ashom*—offended.

"'Revenged himself upon them.'"

*Va-yinqemu bahem*—revenged.

**Edom's Sin:**
Taking advantage of Judah's fall (cf. Obadiah, Psalm 137:7).

**The Key Verses (25:13-14):**
"'I will stretch out my hand upon Edom.'"

*Ve-natiti yadi al-Edom*—hand upon.

"'Will cut off man and beast from it.'"

*Ve-hikhraatti mimmennah adam u-vehemah*—cut off.

"'I will make it desolate from Teman.'"

*U-netattihah chorvah mi-Teman*—desolate.

"'They of Dedan shall fall by the sword.'"

*Ve-Dedanah ba-cherev yippolu*—Dedan falls.

"'I will lay my vengeance upon Edom by the hand of my people Israel.'"

*Ve-natatti et-niqmati be-Edom be-yad ammi Yisra'el*—by Israel.

"'They shall do in Edom according to my anger and according to my fury.'"

*Ve-asu ve-Edom ke-appi u-khe-chamati*—by anger, fury.

"'They shall know my vengeance.'"

*Ve-yad'u et-niqmati*—know vengeance.

**Against Philistia (25:15-17):**
**The Key Verse (25:15):**
"'Because the Philistines have dealt by revenge.'"

*Ya'an asot Pelishtim bi-neqamah*—revenge.

"'Have taken vengeance with disdain of soul to destroy.'"

*Va-yinqemu naqam bi-she'at be-nefesh le-mashchit*—disdain to destroy.

"'For the old hatred.'"

*Eivat olam*—old hatred.

**Philistia's Sin:**
Ancient enmity, taking vengeance.

**The Key Verses (25:16-17):**
"'I will stretch out my hand upon the Philistines.'"

*Hineni noteh yadi al-Pelishtim*—hand upon.

"'I will cut off the Cherethites.'"

*Ve-hikhraatti et-Keretim*—Cherethites cut off.

"'Destroy the remnant of the sea-coast.'"

*Ve-ha'avadti et-she'erit chof ha-yam*—coast remnant.

"'I will execute great vengeance upon them with furious rebukes.'"

*Ve-asiti bahem neqamot gedolot be-tokhechot chemah*—great vengeance.

"'They shall know that I am YHWH.'"

*Ve-yad'u ki-ani YHWH*—recognition.

"'When I shall lay my vengeance upon them.'"

*Be-titti et-niqmati bahem*—lay vengeance.

**Archetypal Layer:** Ezekiel 25 begins the **oracles against nations (25-32)**, containing **Ammon for gloating "Aha!" (25:3, 6)**, **Moab for saying "the house of Judah is like unto all the nations" (25:8)**, **Edom for taking vengeance (25:12)**, and **Philistia for "old hatred" (25:15)**.

**Ethical Inversion Applied:**
- "'Set your face toward the children of Ammon'"—toward Ammon
- "'Prophesy against them'"—prophesy
- "'Because you said: Aha!'"—gloating
- "'Against my sanctuary, when it was profaned'"—sanctuary profaned
- "'Against the land of Israel, when it was made desolate'"—land desolate
- "'Against the house of Judah, when they went into captivity'"—captivity
- "'I will deliver you to the children of the east'"—to easterners
- "'They shall eat your fruit... drink your milk'"—consume
- "'I will make Rabbah a pasture for camels'"—camels
- "'The children of Ammon a couching-place for flocks'"—flocks
- "'You have clapped your hands, and stamped with the feet'"—gloating gestures
- "'Rejoiced with all the disdain of your soul'"—disdain
- "'I stretch out my hand upon you'"—hand upon
- "'I will cut you off from the peoples'"—cut off
- "'Moab and Seir do say: the house of Judah is like unto all the nations'"—deny uniqueness
- "'I will open the flank of Moab'"—open flank
- "'Beth-jeshimoth, Baal-meon, and Kiriathaim'"—cities
- "'That the children of Ammon may not be remembered'"—not remembered
- "'Edom has dealt... by taking vengeance'"—vengeance
- "'I will stretch out my hand upon Edom'"—hand upon
- "'I will make it desolate from Teman'"—desolate
- "'I will lay my vengeance upon Edom by the hand of my people Israel'"—by Israel
- "'The Philistines have dealt by revenge'"—revenge
- "'For the old hatred'"—old hatred
- "'I will cut off the Cherethites'"—Cherethites
- "'Destroy the remnant of the sea-coast'"—coast
- "'I will execute great vengeance upon them'"—great vengeance

**Modern Equivalent:** Ezekiel 25 introduces oracles against nations (25-32). Four neighbors are judged for their response to Jerusalem's fall: Ammon gloated, Moab denied Israel's uniqueness, Edom took revenge, Philistia acted on old hatred. These short oracles set up the longer ones against Tyre (26-28) and Egypt (29-32).

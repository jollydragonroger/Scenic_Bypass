# Ezekiel 28: The King of Tyre and the Restoration of Israel

*From the Hebrew: וַיְהִי דְבַר־יְהוָה אֵלַי (Va-Yehi Devar-YHWH Elai) — And the Word of YHWH Came Unto Me*

---

## Against the Prince of Tyre (28:1-10)

**28:1** And the word of YHWH came unto me, saying:

**28:2** "Son of man, say unto the prince of Tyre: Thus says the Lord YHWH: Because your heart is lifted up, and you have said: 'I am a god, I sit in the seat of God, in the heart of the seas'; yet you are man, and not God, though you set your heart as the heart of God—

**28:3** "Behold, you are wiser than Daniel! There is no secret that they can hide from you!

**28:4** "By your wisdom and by your discernment you have gotten you riches, and have gotten gold and silver into your treasures;

**28:5** "By your great wisdom by your traffic have you increased your riches, and your heart is lifted up because of your riches—

**28:6** "Therefore thus says the Lord YHWH: Because you have set your heart as the heart of God;

**28:7** "Therefore, behold, I will bring strangers upon you, the terrible of the nations; and they shall draw their swords against the beauty of your wisdom, and they shall defile your brightness.

**28:8** "They shall bring you down to the pit; and you shall die the deaths of them that are slain, in the heart of the seas.

**28:9** "Will you yet say before him that slays you: 'I am God'? But you are man, and not God, in the hand of them that defile you.

**28:10** "You shall die the deaths of the uncircumcised by the hand of strangers; for I have spoken," says the Lord YHWH.

---

## Lament Over the King of Tyre (28:11-19)

**28:11** Moreover the word of YHWH came unto me, saying:

**28:12** "Son of man, take up a lamentation for the king of Tyre, and say unto him: Thus says the Lord YHWH: You seal up the sum, full of wisdom, and perfect in beauty.

**28:13** "You were in Eden the garden of God; every precious stone was your covering, the sardius, the topaz, and the diamond, the beryl, the onyx, and the jasper, the sapphire, the carbuncle, and the emerald, and gold; the workmanship of your timbrels and of your pipes was in you, in the day that you were created they were prepared.

**28:14** "You were the anointed cherub that covers; and I set you, so that you were upon the holy mountain of God; you have walked up and down in the midst of the stones of fire.

**28:15** "You were perfect in your ways from the day that you were created, till unrighteousness was found in you.

**28:16** "By the multitude of your traffic they filled the midst of you with violence, and you have sinned; therefore have I cast you as profane out of the mountain of God; and I have destroyed you, O covering cherub, from the midst of the stones of fire.

**28:17** "Your heart was lifted up because of your beauty; you have corrupted your wisdom by reason of your brightness; I have cast you to the ground, I have laid you before kings, that they may gaze upon you.

**28:18** "By the multitude of your iniquities, in the unrighteousness of your traffic, you have profaned your sanctuaries; therefore have I brought forth a fire from the midst of you, it has devoured you, and I have turned you to ashes upon the earth in the sight of all them that behold you.

**28:19** "All they that know you among the peoples shall be appalled at you; you are become a terror, and you shall never be any more."

---

## Against Sidon (28:20-24)

**28:20** And the word of YHWH came unto me, saying:

**28:21** "Son of man, set your face toward Sidon, and prophesy against it,

**28:22** "And say: Thus says the Lord YHWH: Behold, I am against you, O Sidon, and I will be glorified in the midst of you; and they shall know that I am YHWH, when I shall have executed judgments in her, and shall be sanctified in her.

**28:23** "For I will send into her pestilence and blood in her streets; and the wounded shall fall in the midst of her, with the sword upon her on every side; and they shall know that I am YHWH.

**28:24** "And there shall be no more a pricking brier unto the house of Israel, nor a grieving thorn of any that are round about them, that did have them in disdain; and they shall know that I am the Lord YHWH."

---

## Israel's Restoration (28:25-26)

**28:25** Thus says the Lord YHWH: "When I shall have gathered the house of Israel from the peoples among whom they are scattered, and shall be sanctified in them in the sight of the nations, then shall they dwell in their land that I gave to my servant Jacob.

**28:26** "And they shall dwell safely therein, and shall build houses, and plant vineyards; yea, they shall dwell safely, when I have executed judgments upon all those that have them in disdain round about them; and they shall know that I am YHWH their God."

---

## Synthesis Notes

**Key Restorations:**

**Against the Prince of Tyre (28:1-10):**
**The Key Verse (28:2):**
"'Say unto the prince of Tyre.'"

*Emor li-negid Tzor*—to prince.

"'Because your heart is lifted up.'"

*Ya'an gavah libbeka*—heart lifted.

"'You have said: I am a god.'"

*Va-tomer el ani*—I am god.

"'I sit in the seat of God, in the heart of the seas.'"

*Moshav Elohim yashavti be-lev yammim*—god's seat.

"'Yet you are man, and not God.'"

*Ve-attah adam ve-lo-el*—you are man.

"'Though you set your heart as the heart of God.'"

*Va-titten libbeka ke-lev Elohim*—heart like god.

**The Key Verse (28:3):**
"'Behold, you are wiser than Daniel!'"

*Hinneh chakham attah mi-Dani'el*—wiser than Daniel.

"'There is no secret that they can hide from you!'"

*Kol-satum lo amamukha*—no secrets.

**Daniel:**
Either the biblical Daniel (Ezekiel's contemporary) or ancient Dan'el of Ugaritic legend.

**The Key Verses (28:4-5):**
"'By your wisdom and by your discernment you have gotten you riches.'"

*Be-chokhmatekha u-vi-tvunatekha asita lekha chayil*—wisdom for riches.

"'Have gotten gold and silver into your treasures.'"

*Va-ta'as zahav va-kesef be-otzrotekha*—gold, silver.

"'By your great wisdom by your traffic have you increased your riches.'"

*Be-rov chokhmatekha bi-rekhullatekha hirbita cheilekha*—increased.

"'Your heart is lifted up because of your riches.'"

*Va-yigbah levavekha be-cheilekha*—heart lifted.

**The Key Verses (28:7-10):**
"'I will bring strangers upon you, the terrible of the nations.'"

*Hineni mevi alekha zarim aritzei goyim*—terrible nations.

"'They shall draw their swords against the beauty of your wisdom.'"

*Ve-heriqu charvotam al-yefi chokhmatekha*—swords against.

"'They shall defile your brightness.'"

*Ve-chillelu yif'atekha*—defile brightness.

"'They shall bring you down to the pit.'"

*La-shachat yoridukha*—to pit.

"'You shall die the deaths of them that are slain, in the heart of the seas.'"

*U-metei motei challalim be-lev yammim*—die in seas.

"'Will you yet say before him that slays you: I am God?'"

*Ha-amor tomar Elohim ani lifnei horgekha*—claim godhood?

"'But you are man, and not God.'"

*Ve-attah adam ve-lo-el*—you are man.

"'You shall die the deaths of the uncircumcised.'"

*Motei arelim tamut*—die uncircumcised.

**Lament Over the King of Tyre (28:11-19):**
**The Key Verse (28:12):**
"'Take up a lamentation for the king of Tyre.'"

*Sa qinah al-melekh Tzor*—lament for king.

"'You seal up the sum.'"

*Attah chotem tokhnit*—seal/pattern.

"'Full of wisdom, and perfect in beauty.'"

*Male chokhמah u-khelil yofi*—wisdom, beauty.

**The Key Verse (28:13):**
"'You were in Eden the garden of God.'"

*Be-Eden gan-Elohim hayita*—in Eden.

"'Every precious stone was your covering.'"

*Kol-even yeqarah mesukhatekha*—precious stones.

"'The sardius, the topaz, and the diamond.'"

*Odem pitdah ve-yahalom*—stones.

"'The beryl, the onyx, and the jasper.'"

*Tarshish shoham ve-yashfeh*—more stones.

"'The sapphire, the carbuncle, and the emerald, and gold.'"

*Sappir nofekh u-vareqet ve-zahav*—more stones, gold.

"'The workmanship of your timbrels and of your pipes was in you.'"

*Melekhet tuppekha u-neqavekha bakh*—musical instruments.

"'In the day that you were created they were prepared.'"

*Be-yom hibbare'akha konanu*—prepared at creation.

**The Key Verse (28:14):**
"'You were the anointed cherub that covers.'"

*At-keruv mimshach ha-sokekh*—anointed cherub.

"'I set you, so that you were upon the holy mountain of God.'"

*U-netattikha be-har qodesh Elohim hayita*—holy mountain.

"'You have walked up and down in the midst of the stones of fire.'"

*Be-tokh avnei-esh hithalakhta*—stones of fire.

**The Key Verse (28:15):**
"'You were perfect in your ways from the day that you were created.'"

*Tamim attah bi-derakhekha mi-yom hibbareakha*—perfect from creation.

"'Till unrighteousness was found in you.'"

*Ad-nimtza avlatah bakh*—unrighteousness found.

**The Key Verses (28:16-17):**
"'By the multitude of your traffic they filled the midst of you with violence.'"

*Be-rov rekhullatekha male'u tokhekha chamas*—violence from trade.

"'You have sinned.'"

*Va-techeta*—sinned.

"'I cast you as profane out of the mountain of God.'"

*Va-achallелekha me-har Elohim*—cast out.

"'I have destroyed you, O covering cherub.'"

*Va-abbedekha keruv ha-sokekh*—destroyed.

"'From the midst of the stones of fire.'"

*Mi-tokh avnei-esh*—from stones of fire.

"'Your heart was lifted up because of your beauty.'"

*Gavah libbeka be-yofyekha*—heart lifted.

"'You have corrupted your wisdom by reason of your brightness.'"

*Shichatta chokhmatekha al-yif'atekha*—corrupted wisdom.

"'I have cast you to the ground.'"

*Al-eretz hishlakhtikha*—cast to ground.

"'I have laid you before kings, that they may gaze upon you.'"

*Lifnei melakhim netattikha le-ra'avah bakh*—before kings.

**The Key Verses (28:18-19):**
"'By the multitude of your iniquities, in the unrighteousness of your traffic.'"

*Me-rov avonekha be-evel rekhullatekha*—iniquities in trade.

"'You have profaned your sanctuaries.'"

*Chillalta miqdashekha*—profaned sanctuaries.

"'I have brought forth a fire from the midst of you.'"

*Va-otzi esh mi-tokhekha*—fire from within.

"'It has devoured you.'"

*Hi akhalatekha*—devoured.

"'I have turned you to ashes upon the earth.'"

*Va-ettnekha le-efer al-ha-aretz*—to ashes.

"'All they that know you among the peoples shall be appalled.'"

*Kol-yod'ekha ba-ammim shamemu alekha*—appalled.

"'You are become a terror.'"

*Ballahot hayita*—terror.

"'You shall never be any more.'"

*Ve-einekha ad-olam*—never more.

**Mythological Background:**
The king of Tyre is described using Edenic/cosmic imagery—a primordial being in God's garden who fell through pride.

**Against Sidon (28:20-24):**
"'Set your face toward Sidon.'"

*Sim panekha el-Tzidon*—toward Sidon.

"'Behold, I am against you, O Sidon.'"

*Hineni alayikh Tzidon*—against Sidon.

"'I will be glorified in the midst of you.'"

*Ve-nikhbadti be-tokhakh*—glorified.

"'I will send into her pestilence and blood.'"

*Ve-shillachti-vah dever ve-dam*—pestilence, blood.

"'There shall be no more a pricking brier unto the house of Israel.'"

*Ve-lo-yihyeh od le-veit Yisra'el silon mam'ir*—no brier.

"'Nor a grieving thorn of any that are round about them.'"

*Ve-kotz makh'iv mi-kol sevivotam*—no thorn.

**Israel's Restoration (28:25-26):**
"'When I shall have gathered the house of Israel.'"

*Be-qabbetzi et-beit Yisra'el*—gather Israel.

"'From the peoples among whom they are scattered.'"

*Min-ha-ammim asher nafotzu vam*—scattered among.

"'Shall be sanctified in them in the sight of the nations.'"

*Ve-niqdashti vam le-einei ha-goyim*—sanctified before nations.

"'Then shall they dwell in their land.'"

*Ve-yashvu al-admatam*—dwell in land.

"'That I gave to my servant Jacob.'"

*Asher natatti le-avdi le-Ya'aqov*—given to Jacob.

"'They shall dwell safely therein.'"

*Ve-yashvu alekha la-vetach*—dwell safely.

"'Shall build houses, and plant vineyards.'"

*U-vanu vattim ve-nat'u keramim*—build, plant.

"'When I have executed judgments upon all those that have them in disdain.'"

*Ba-asoti shefatim be-khol ha-sho'atim otam mi-sevivotam*—judgments on despisers.

"'They shall know that I am YHWH their God.'"

*Ve-yad'u ki ani YHWH Eloheihem*—recognition.

**Archetypal Layer:** Ezekiel 28 contains **the prince of Tyre's claim "I am a god" (28:2)**, **"You are wiser than Daniel" (28:3)**, **the king of Tyre lament with Edenic imagery (28:11-19)**, **"You were in Eden the garden of God" (28:13)**, **"You were the anointed cherub that covers" (28:14)**, **"You were perfect... till unrighteousness was found in you" (28:15)**, and **Israel's future restoration (28:25-26)**.

**Ethical Inversion Applied:**
- "'Say unto the prince of Tyre'"—to prince
- "'Because your heart is lifted up'"—pride
- "'You have said: I am a god'"—claim godhood
- "'I sit in the seat of God, in the heart of the seas'"—god's seat
- "'Yet you are man, and not God'"—mortality
- "'You are wiser than Daniel'"—wisdom claim
- "'By your wisdom... you have gotten you riches'"—wisdom for wealth
- "'Your heart is lifted up because of your riches'"—pride from wealth
- "'I will bring strangers upon you, the terrible of the nations'"—terrible nations
- "'They shall bring you down to the pit'"—to pit
- "'Will you yet say... I am God?'"—challenge
- "'You shall die the deaths of the uncircumcised'"—die uncircumcised
- "'Take up a lamentation for the king of Tyre'"—lament
- "'You seal up the sum, full of wisdom, and perfect in beauty'"—perfect
- "'You were in Eden the garden of God'"—Eden
- "'Every precious stone was your covering'"—precious stones
- "'You were the anointed cherub that covers'"—anointed cherub
- "'Upon the holy mountain of God'"—holy mountain
- "'You have walked up and down in the midst of the stones of fire'"—stones of fire
- "'You were perfect in your ways from the day that you were created'"—perfect from creation
- "'Till unrighteousness was found in you'"—unrighteousness found
- "'By the multitude of your traffic... violence'"—violence from trade
- "'I cast you as profane out of the mountain of God'"—cast out
- "'I have destroyed you, O covering cherub'"—destroyed
- "'Your heart was lifted up because of your beauty'"—pride from beauty
- "'You have corrupted your wisdom'"—corrupted wisdom
- "'I have brought forth a fire from the midst of you'"—fire from within
- "'I have turned you to ashes'"—to ashes
- "'You shall never be any more'"—never more
- "'I am against you, O Sidon'"—against Sidon
- "'There shall be no more a pricking brier unto the house of Israel'"—no brier
- "'When I shall have gathered the house of Israel'"—gather
- "'They shall dwell in their land'"—dwell
- "'They shall dwell safely'"—safely
- "'Build houses, and plant vineyards'"—build, plant

**Modern Equivalent:** Ezekiel 28 concludes the Tyre oracles. The king of Tyre's description using Eden/cherub imagery (28:11-19) has been interpreted as describing Satan's fall, though the primary referent is the historical king. The pattern—perfect creature corrupted by pride—applies to both Tyre's king and a cosmic figure. Israel's restoration (28:25-26) follows judgment on neighbors.

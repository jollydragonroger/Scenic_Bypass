# Daniel 4: Nebuchadnezzar's Dream of the Tree and His Humiliation

*From the Aramaic: נְבוּכַדְנֶצַּר מַלְכָּא לְכָל־עַמְמַיָּא (Nevukhadnetstsar Malka Le-Khol-Ammaya) — Nebuchadnezzar the King, unto All Peoples*

---

## The King's Proclamation (4:1-3)

**4:1** Nebuchadnezzar the king, unto all the peoples, nations, and languages, that dwell in all the earth: Peace be multiplied unto you.

**4:2** It has seemed good unto me to declare the signs and wonders that the Most High God has wrought toward me.

**4:3** How great are his signs! And how mighty are his wonders! His kingdom is an everlasting kingdom, and his dominion is from generation to generation.

---

## The Dream of the Tree (4:4-18)

**4:4** I Nebuchadnezzar was at rest in my house, and flourishing in my palace.

**4:5** I saw a dream which made me afraid; and the thoughts upon my bed and the visions of my head affrighted me.

**4:6** Therefore made I a decree to bring in all the wise men of Babylon before me, that they might make known unto me the interpretation of the dream.

**4:7** Then came in the magicians, the enchanters, the Chaldeans, and the astrologers; and I told the dream before them; but they did not make known unto me the interpretation thereof.

**4:8** But at the last Daniel came in before me, whose name is Belteshazzar, according to the name of my god, and in whom is the spirit of the holy gods; and I told the dream before him:

**4:9** "O Belteshazzar, master of the magicians, because I know that the spirit of the holy gods is in you, and no secret is too hard for you, tell me the visions of my dream that I have seen, and the interpretation thereof.

**4:10** "Thus were the visions of my head upon my bed: I saw, and behold a tree in the midst of the earth, and the height thereof was great.

**4:11** "The tree grew, and was strong, and the height thereof reached unto heaven, and the sight thereof to the end of all the earth.

**4:12** "The leaves thereof were fair, and the fruit thereof much, and in it was food for all; the beasts of the field had shadow under it, and the fowls of the heaven dwelt in the branches thereof, and all flesh was fed of it.

**4:13** "I saw in the visions of my head upon my bed, and, behold, a watcher and a holy one came down from heaven.

**4:14** "He cried aloud, and said thus: 'Hew down the tree, and cut off its branches, shake off its leaves, and scatter its fruit; let the beasts get away from under it, and the fowls from its branches.

**4:15** "'Nevertheless leave the stump of its roots in the earth, even with a band of iron and brass, in the tender grass of the field; and let it be wet with the dew of heaven, and let his portion be with the beasts in the grass of the earth;

**4:16** "'Let his heart be changed from man's, and let a beast's heart be given unto him; and let seven times pass over him.

**4:17** "'The sentence is by the decree of the watchers, and the demand by the word of the holy ones; to the intent that the living may know that the Most High rules in the kingdom of men, and gives it to whomsoever he will, and sets up over it the lowest of men.'

**4:18** "This dream I king Nebuchadnezzar have seen; and you, O Belteshazzar, declare the interpretation, forasmuch as all the wise men of my kingdom are not able to make known unto me the interpretation; but you are able, for the spirit of the holy gods is in you."

---

## Daniel's Interpretation (4:19-27)

**4:19** Then Daniel, whose name was Belteshazzar, was appalled for a while, and his thoughts affrighted him. The king spoke and said: "Belteshazzar, let not the dream, or the interpretation, affright you." Belteshazzar answered and said: "My lord, the dream be to them that hate you, and the interpretation thereof to your adversaries.

**4:20** "The tree that you saw, which grew, and was strong, whose height reached unto the heaven, and the sight thereof to all the earth;

**4:21** "Whose leaves were fair, and the fruit thereof much, and in it was food for all; under which the beasts of the field dwelt, and upon whose branches the fowls of the heaven had their habitation:

**4:22** "It is you, O king, that are grown and become strong; for your greatness is grown, and reaches unto heaven, and your dominion to the end of the earth.

**4:23** "And whereas the king saw a watcher and a holy one coming down from heaven, and saying: 'Hew down the tree, and destroy it; nevertheless leave the stump of its roots in the earth, even with a band of iron and brass, in the tender grass of the field; and let it be wet with the dew of heaven, and let his portion be with the beasts of the field, till seven times pass over him';

**4:24** "This is the interpretation, O king, and it is the decree of the Most High, which is come upon my lord the king:

**4:25** "That you shall be driven from men, and your dwelling shall be with the beasts of the field, and you shall be made to eat grass as oxen, and shall be wet with the dew of heaven, and seven times shall pass over you; till you know that the Most High rules in the kingdom of men, and gives it to whomsoever he will.

**4:26** "And whereas they commanded to leave the stump of the roots of the tree, your kingdom shall be sure unto you, after that you shall have known that the heavens do rule.

**4:27** "Wherefore, O king, let my counsel be acceptable unto you, and break off your sins by righteousness, and your iniquities by showing mercy to the poor; if there may be a lengthening of your tranquillity."

---

## The Fulfillment (4:28-33)

**4:28** All this came upon the king Nebuchadnezzar.

**4:29** At the end of twelve months he was walking upon the royal palace of Babylon.

**4:30** The king spoke and said: "Is not this great Babylon, which I have built for a royal dwelling-place, by the might of my power and for the glory of my majesty?"

**4:31** While the word was in the king's mouth, there fell a voice from heaven: "O king Nebuchadnezzar, to you it is spoken: The kingdom is departed from you.

**4:32** "And you shall be driven from men, and your dwelling shall be with the beasts of the field; you shall be made to eat grass as oxen, and seven times shall pass over you; until you know that the Most High rules in the kingdom of men, and gives it to whomsoever he will."

**4:33** The same hour was the thing fulfilled upon Nebuchadnezzar; and he was driven from men, and did eat grass as oxen, and his body was wet with the dew of heaven, till his hair was grown like eagles' feathers, and his nails like birds' claws.

---

## The King's Restoration (4:34-37)

**4:34** And at the end of the days I Nebuchadnezzar lifted up my eyes unto heaven, and my understanding returned unto me, and I blessed the Most High, and I praised and honoured him that lives for ever; for his dominion is an everlasting dominion, and his kingdom from generation to generation;

**4:35** And all the inhabitants of the earth are reputed as nothing; and he does according to his will in the host of heaven, and among the inhabitants of the earth; and none can stay his hand, or say unto him: "What do you?"

**4:36** At the same time my understanding returned unto me; and for the glory of my kingdom, my majesty and my splendour returned unto me; and my ministers and my lords sought unto me; and I was established in my kingdom, and surpassing greatness was added unto me.

**4:37** Now I Nebuchadnezzar praise and extol and honour the King of heaven; for all his works are truth, and his ways justice; and those that walk in pride he is able to abase.

---

## Synthesis Notes

**Key Restorations:**

**King's Proclamation (4:1-3):**
**The Key Verses (4:1-3):**
"Nebuchadnezzar the king, unto all the peoples, nations, and languages."

*Nevukhadnetstsar malka le-khol-ammaya ummaya ve-lishnaya*—to all peoples.

"'Peace be multiplied unto you.'"

*Shelamkhem yisgeh*—peace multiplied.

"'It has seemed good unto me to declare the signs and wonders.'"

*Shefar qodamai le-hachavayah ataya ve-timhaya*—signs, wonders.

"'That the Most High God has wrought toward me.'"

*Di avad immi Elaha illa'ah*—Most High did.

"'How great are his signs! And how mighty are his wonders!'"

*Atohi mah ravrevin ve-timhohi mah taqqifin*—great, mighty.

"'His kingdom is an everlasting kingdom.'"

*Malkhuteh malkhut alam*—everlasting.

"'His dominion is from generation to generation.'"

*Ve-sholtaneh im-dar ve-dar*—every generation.

**Dream of the Tree (4:4-18):**
**The Key Verses (4:10-12):**
"'I saw, and behold a tree in the midst of the earth.'"

*Chazeh haveit va-alu ilan be-go ar'a*—tree in midst.

"'The height thereof was great.'"

*Ve-rumeh saggi*—great height.

"'The tree grew, and was strong.'"

*Revah ilana u-teqif*—grew, strong.

"'The height thereof reached unto heaven.'"

*Ve-rumeh yimtei li-shemaya*—to heaven.

"'The sight thereof to the end of all the earth.'"

*Ve-chazoteh le-sof kol-ar'a*—visible everywhere.

"'The leaves thereof were fair, and the fruit thereof much.'"

*Ophyeh shappir u-inveh saggi*—fair leaves, much fruit.

"'In it was food for all.'"

*U-mazon le-kholla beh*—food for all.

"'The beasts of the field had shadow under it.'"

*Techotehi tetallel cheivat bara*—beasts sheltered.

"'The fowls of the heaven dwelt in the branches thereof.'"

*U-ve-anfohi yedorin tzipparei shemaya*—birds dwelt.

"'All flesh was fed of it.'"

*U-minneh yitzan kol-bisar*—all fed.

**The Key Verses (4:13-17):**
"'Behold, a watcher and a holy one came down from heaven.'"

*Va-alu ir ve-qaddish min-shemaya nachit*—watcher, holy one.

**Ir Ve-Qaddish:**
"Watcher and holy one"—angelic being.

"'He cried aloud, and said thus: Hew down the tree.'"

*Qare ve-chayil ve-khen amar gaddu ilana*—hew tree.

"'Cut off its branches, shake off its leaves, and scatter its fruit.'"

*Ve-qatzizu anfohi u-natteru ophyeh u-vaddaru inveh*—cut, shake.

"'Let the beasts get away from under it.'"

*Tенud cheivta min-techtohi*—beasts flee.

"'The fowls from its branches.'"

*Ve-tzippraya min-anfohi*—birds flee.

"'Nevertheless leave the stump of its roots in the earth.'"

*Berem iqqar shorshohi be-ar'a shevuqu*—leave stump.

"'With a band of iron and brass.'"

*U-ve-esur di-farzel u-nechash*—band of iron/bronze.

"'In the tender grass of the field.'"

*Be-dete'a di-bara*—in grass.

"'Let it be wet with the dew of heaven.'"

*U-ve-tal shemaya yitztabbא'*—wet with dew.

"'Let his portion be with the beasts in the grass of the earth.'"

*Ve-im-cheivat bara chalaqeh be-asav ar'a*—with beasts.

"'Let his heart be changed from man's, and let a beast's heart be given unto him.'"

*Livbeveh min-enasha yeshannun ve-levav cheivah yityehiv leh*—beast's heart.

"'Let seven times pass over him.'"

*Ve-shiv'ah iddanin yachlefun alohi*—seven times.

"'The sentence is by the decree of the watchers.'"

*Bi-gezerat irin pitgama*—watchers' decree.

"'By the word of the holy ones.'"

*U-me'emar qaddishin she'elta*—holy ones' word.

"'To the intent that the living may know.'"

*Ad-divrat di yinde'un chayyaya*—so living know.

"'That the Most High rules in the kingdom of men.'"

*Di shallit Illא'a be-malkhut enasha*—Most High rules.

"'Gives it to whomsoever he will.'"

*U-le-man-di yitzbe yitteninnah*—gives to whom He wills.

"'Sets up over it the lowest of men.'"

*U-shefal anashin yeqim alah*—lowest of men.

**Daniel's Interpretation (4:19-27):**
**The Key Verse (4:22):**
"'It is you, O king, that are grown and become strong.'"

*Ant-hu malka di revait u-teqefta*—you, O king.

"'Your greatness is grown, and reaches unto heaven.'"

*U-revutak revat u-metat li-shemaya*—reaches heaven.

"'Your dominion to the end of the earth.'"

*Ve-sholtanakh le-sof ar'a*—dominion to end.

**The Key Verse (4:25):**
"'You shall be driven from men.'"

*Ve-lakh tardin min-anasha*—driven from men.

"'Your dwelling shall be with the beasts of the field.'"

*Ve-im-cheivat bara medurak*—with beasts.

"'You shall be made to eat grass as oxen.'"

*Ve-isba ke-torin lakh yeta'amun*—eat grass.

"'Shall be wet with the dew of heaven.'"

*U-mi-tal shemaya yetzabba'un*—wet with dew.

"'Seven times shall pass over you.'"

*Ve-shiv'ah iddanin yachlefun alakh*—seven times.

"'Till you know that the Most High rules in the kingdom of men.'"

*Ad di-tinda di-shallit Illא'a be-malkhut anasha*—till you know.

**The Key Verse (4:27):**
"'Let my counsel be acceptable unto you.'"

*Milki yishpar alakh*—accept counsel.

"'Break off your sins by righteousness.'"

*Va-chatayakh be-tzidqah feruq*—break off sins.

"'Your iniquities by showing mercy to the poor.'"

*Va-avayatakh be-michhan anayyin*—mercy to poor.

"'If there may be a lengthening of your tranquillity.'"

*Hen teheve arkha li-shlevutak*—lengthen peace.

**Fulfillment (4:28-33):**
**The Key Verse (4:30):**
"'Is not this great Babylon, which I have built for a royal dwelling-place.'"

*Ha-la da-hi Bavel rabbeta di-ana benitah le-veit malkhu*—great Babylon.

"'By the might of my power and for the glory of my majesty?'"

*Bi-teqoph chisni ve-li-yeqar hadari*—my power, my majesty.

**The Key Verses (4:31-33):**
"There fell a voice from heaven."

*Qal min-shemaya nefal*—voice from heaven.

"'O king Nebuchadnezzar, to you it is spoken: The kingdom is departed from you.'"

*Lakh amerin Nevukhadnetstsar malka malkhutah adat minnakh*—kingdom departed.

"He was driven from men, and did eat grass as oxen."

*U-min-anasha terid ve-isba ke-torin yokhel*—driven, ate grass.

"His body was wet with the dew of heaven."

*U-mi-tal shemaya gishmeh yitztabba*—wet with dew.

"Till his hair was grown like eagles' feathers."

*Ad di sa'reh ke-nishrin revah*—eagle feathers.

"His nails like birds' claws."

*Ve-tipprohi ke-tziprin*—bird claws.

**King's Restoration (4:34-37):**
**The Key Verses (4:34-35):**
"I Nebuchadnezzar lifted up my eyes unto heaven."

*Li-qetzat yomaya ana Nevukhadnetstsar einai li-shemaya netlet*—looked to heaven.

"My understanding returned unto me."

*U-mande'i alai yetיv*—understanding returned.

"I blessed the Most High."

*U-le-Illא'a barekhit*—blessed Most High.

"I praised and honoured him that lives for ever."

*U-le-chai alma shabbeחit ve-haddarit*—praised everlasting.

"'His dominion is an everlasting dominion.'"

*Di sholtaneh sholtan alam*—everlasting dominion.

"'His kingdom from generation to generation.'"

*U-malkhuteh im-dar ve-dar*—every generation.

"'All the inhabitants of the earth are reputed as nothing.'"

*Ve-khol-darei ar'a ke-la chashivin*—as nothing.

"'He does according to his will in the host of heaven.'"

*U-khe-mitzbe'eh aved be-cheil shemaya*—in heaven.

"'And among the inhabitants of the earth.'"

*U-ve-darei ar'a*—on earth.

"'None can stay his hand.'"

*Ve-la itai di-yemacheh vi-yadeh*—none stays hand.

"'Or say unto him: What do you?'"

*Ve-yemar leh mah avadta*—who says what?

**The Key Verses (4:36-37):**
"My understanding returned unto me."

*Bi-zimna denah mande'i yetיv alai*—understanding returned.

"For the glory of my kingdom, my majesty and my splendour returned."

*Ve-li-yeqar malkhuti hadari ve-zivi yetiv alai*—glory returned.

"I was established in my kingdom."

*Ve-al-malkhuti hotqenat*—established.

"Surpassing greatness was added unto me."

*U-revah yattirah hosefat li*—greatness added.

"'Now I Nebuchadnezzar praise and extol and honour the King of heaven.'"

*Ke'an ana Nevukhadnetstsar meshabbach u-meromem u-mehaddar le-Melekh shemaya*—praise King of heaven.

"'All his works are truth, and his ways justice.'"

*Di kol-ma'aבdohi qeshot u-orchateh din*—truth, justice.

"'Those that walk in pride he is able to abase.'"

*U-di mahlekhin be-gevah yakil le-hashpalah*—abases proud.

**Archetypal Layer:** Daniel 4 is **Nebuchadnezzar's testimony**, containing **"His kingdom is an everlasting kingdom" (4:3)**, **the great tree reaching to heaven (4:10-12)**, **"a watcher and a holy one came down from heaven" (4:13)**, **"Hew down the tree... nevertheless leave the stump" (4:14-15)**, **"the Most High rules in the kingdom of men" (4:17, 25, 32)**, **"Is not this great Babylon, which I have built?" (4:30)**, **"The kingdom is departed from you" (4:31)**, **seven years of madness (4:33)**, and **"those that walk in pride he is able to abase" (4:37)**.

**Ethical Inversion Applied:**
- "Nebuchadnezzar the king, unto all the peoples"—to all peoples
- "'Peace be multiplied unto you'"—peace
- "'It has seemed good unto me to declare the signs and wonders'"—testify
- "'His kingdom is an everlasting kingdom'"—everlasting
- "I saw a dream which made me afraid"—afraid
- "The wise men... did not make known unto me the interpretation"—failed
- "Daniel came in before me... in whom is the spirit of the holy gods"—Daniel
- "'I saw, and behold a tree in the midst of the earth'"—tree
- "'The height thereof reached unto heaven'"—to heaven
- "'In it was food for all'"—food for all
- "'The beasts of the field had shadow under it'"—sheltered beasts
- "'A watcher and a holy one came down from heaven'"—angelic being
- "'Hew down the tree, and cut off its branches'"—hew tree
- "'Leave the stump of its roots in the earth'"—leave stump
- "'With a band of iron and brass'"—iron/bronze band
- "'Let it be wet with the dew of heaven'"—wet with dew
- "'Let his heart be changed from man's, and let a beast's heart be given'"—beast's heart
- "'Let seven times pass over him'"—seven times
- "'The Most High rules in the kingdom of men'"—Most High rules
- "'Gives it to whomsoever he will'"—gives to whom He wills
- "'Sets up over it the lowest of men'"—lowest of men
- "'It is you, O king'"—you are the tree
- "'You shall be driven from men'"—driven
- "'Your dwelling shall be with the beasts'"—with beasts
- "'You shall be made to eat grass as oxen'"—eat grass
- "'Till you know that the Most High rules'"—till you know
- "'Break off your sins by righteousness'"—repent
- "'Your iniquities by showing mercy to the poor'"—mercy to poor
- "'Is not this great Babylon, which I have built?'"—pride
- "'By the might of my power and for the glory of my majesty?'"—boasting
- "There fell a voice from heaven"—voice from heaven
- "'The kingdom is departed from you'"—kingdom gone
- "He was driven from men, and did eat grass as oxen"—fulfilled
- "Till his hair was grown like eagles' feathers"—feathers
- "His nails like birds' claws"—claws
- "I Nebuchadnezzar lifted up my eyes unto heaven"—looked up
- "My understanding returned unto me"—restored
- "I blessed the Most High"—blessed
- "'All the inhabitants of the earth are reputed as nothing'"—as nothing
- "'He does according to his will'"—His will
- "'None can stay his hand'"—none stops
- "I was established in my kingdom"—established
- "'Those that walk in pride he is able to abase'"—abases proud

**Modern Equivalent:** Daniel 4 is unique—a pagan king's first-person testimony. Nebuchadnezzar's madness (possibly boanthropy—believing oneself to be an ox) humbles him. "The Most High rules in the kingdom of men" (4:17, 25, 32) is the chapter's theme. The king who built Babylon learns that all earthly power derives from God.

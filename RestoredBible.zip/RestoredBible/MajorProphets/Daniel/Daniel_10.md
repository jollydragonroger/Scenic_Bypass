# Daniel 10: The Vision by the Tigris

*From the Hebrew: בִּשְׁנַת שָׁלוֹשׁ לְכוֹרֶשׁ (Bi-Shnat Shalosh Le-Koresh) — In the Third Year of Cyrus*

---

## Daniel's Mourning (10:1-3)

**10:1** In the third year of Cyrus king of Persia a word was revealed unto Daniel, whose name was called Belteshazzar; and the word was true, even a great host; and he understood the word, and had understanding of the vision.

**10:2** In those days I Daniel was mourning three whole weeks.

**10:3** I ate no pleasant bread, neither came flesh nor wine in my mouth, neither did I anoint myself at all, till three whole weeks were fulfilled.

---

## The Heavenly Messenger (10:4-9)

**10:4** And in the four and twentieth day of the first month, as I was by the side of the great river, which is Tigris,

**10:5** I lifted up my eyes, and looked, and behold a man clothed in linen, whose loins were girded with fine gold of Uphaz;

**10:6** His body also was like the beryl, and his face as the appearance of lightning, and his eyes as torches of fire, and his arms and his feet like in colour to burnished brass, and the voice of his words like the voice of a multitude.

**10:7** And I Daniel alone saw the vision; for the men that were with me saw not the vision; but a great trembling fell upon them, and they fled to hide themselves.

**10:8** So I was left alone, and saw this great vision, and there remained no strength in me; for my comeliness was turned in me into corruption, and I retained no strength.

**10:9** Yet heard I the voice of his words; and when I heard the voice of his words, then was I fallen into a deep sleep on my face, with my face toward the ground.

---

## Strengthened to Hear (10:10-14)

**10:10** And, behold, a hand touched me, and set me tottering upon my knees and upon the palms of my hands.

**10:11** And he said unto me: "O Daniel, you man greatly beloved, understand the words that I speak unto you, and stand upright; for now am I sent unto you." And when he had spoken this word unto me, I stood trembling.

**10:12** Then said he unto me: "Fear not, Daniel; for from the first day that you did set your heart to understand, and to humble yourself before your God, your words were heard; and I am come because of your words.

**10:13** "But the prince of the kingdom of Persia withstood me one and twenty days; but, lo, Michael, one of the chief princes, came to help me; and I was left over there beside the kings of Persia.

**10:14** "Now I am come to make you understand what shall befall your people in the end of days; for the vision is yet for many days."

---

## Further Strengthening (10:15-21)

**10:15** And when he had spoken unto me according to these words, I set my face toward the ground, and was dumb.

**10:16** And, behold, one like the similitude of the sons of men touched my lips; then I opened my mouth, and spoke, and said unto him that stood before me: "O my lord, by reason of the vision my pains are come upon me, and I retain no strength.

**10:17** "For how can the servant of this my lord talk with this my lord? For as for me, straightway there remained no strength in me, neither was there breath left in me."

**10:18** Then there touched me again one like the appearance of a man, and he strengthened me.

**10:19** And he said: "O man greatly beloved, fear not; peace be unto you, be strong, yea, be strong." And when he had spoken unto me, I was strengthened, and said: "Let my lord speak; for you have strengthened me."

**10:20** Then said he: "Do you know wherefore I am come unto you? And now will I return to fight with the prince of Persia; and when I go forth, lo, the prince of Greece shall come.

**10:21** "Howbeit I will declare unto you that which is inscribed in the writing of truth; and there is none that holds with me against these, except Michael your prince."

---

## Synthesis Notes

**Key Restorations:**

**Daniel's Mourning (10:1-3):**
**The Key Verse (10:1):**
"In the third year of Cyrus king of Persia a word was revealed unto Daniel."

*Bi-shnat shalosh le-Koresh melekh Paras davar niglah le-Dani'el*—3rd year of Cyrus.

"Whose name was called Belteshazzar."

*Asher-niqra shemo Beltsha'tstsar*—Belteshazzar.

"The word was true, even a great host."

*Ve-emet ha-davar ve-tzava gadol*—true word.

"He understood the word, and had understanding of the vision."

*U-vin et-ha-davar u-vinah lo ba-mar'eh*—understood.

**The Key Verses (10:2-3):**
"In those days I Daniel was mourning three whole weeks."

*Ba-yamim ha-hem ani Dani'el hayiti mit'abbel sheloshah shavu'im yamim*—3 weeks mourning.

"I ate no pleasant bread."

*Lechem chamudot lo akhalti*—no pleasant food.

"Neither came flesh nor wine in my mouth."

*U-vasar va-yayin lo-va el-pi*—no meat, wine.

"Neither did I anoint myself at all."

*Ve-sokh lo-sakhti*—no anointing.

"Till three whole weeks were fulfilled."

*Ad-melo't sheloshet shavu'im yamim*—21 days.

**Heavenly Messenger (10:4-9):**
**The Key Verses (10:4-6):**
"In the four and twentieth day of the first month."

*U-ve-yom esrim ve-arba'ah la-chodesh ha-rishon*—24th of 1st month.

"I was by the side of the great river, which is Tigris."

*Va-ani hayiti al-yad ha-nahar ha-gadol hu Chiddeqel*—Tigris.

"I lifted up my eyes, and looked, and behold a man clothed in linen."

*Va-essa et-einai va-ere ve-hinneh ish-echad lavush baddim*—linen-clothed man.

"Whose loins were girded with fine gold of Uphaz."

*U-motnav chagurim be-khetem Ufaz*—Uphaz gold.

"His body also was like the beryl."

*U-geviyyato ke-tarshish*—beryl body.

"His face as the appearance of lightning."

*U-fanav ke-mar'eh varaq*—lightning face.

"His eyes as torches of fire."

*Ve-einav ke-lappidei esh*—fire-torch eyes.

"His arms and his feet like in colour to burnished brass."

*U-zero'otav u-margelotav ke-ein nechoshet qalal*—burnished brass.

"The voice of his words like the voice of a multitude."

*Ve-qol devarav ke-qol hamon*—voice of multitude.

**Glorious Figure:**
This description parallels Ezekiel 1 and Revelation 1.

**The Key Verses (10:7-9):**
"I Daniel alone saw the vision."

*Va-ani Dani'el levaddi ra'iti et-ha-mar'ah*—Daniel alone saw.

"The men that were with me saw not the vision."

*Ve-ha-anashim asher hayu immi lo ra'u et-ha-mar'ah*—companions didn't see.

"A great trembling fell upon them, and they fled to hide themselves."

*Aval charadah gedolah nafelah aleihem va-yivrechu be-hechave*—fled.

"I was left alone, and saw this great vision."

*Va-eshsha'er ani levaddi va-er'eh et-ha-mar'ah ha-gedolah ha-zot*—left alone.

"There remained no strength in me."

*Ve-lo-nish'ar bi koach*—no strength.

"My comeliness was turned in me into corruption."

*Ve-hodi nehpakh alai le-mashchit*—comeliness corrupted.

"I retained no strength."

*Ve-lo atzarti koach*—no strength.

"I heard the voice of his words."

*Va-eshma et-qol devarav*—heard voice.

"I was fallen into a deep sleep on my face, with my face toward the ground."

*Va-ani hayiti nirdam al-panai u-fanai artzah*—deep sleep, face down.

**Strengthened to Hear (10:10-14):**
**The Key Verses (10:10-11):**
"A hand touched me, and set me tottering upon my knees and upon the palms of my hands."

*Ve-hinneh-yad nag'ah bi va-teni'eni al-birkai ve-khappot yadai*—hand touched.

"'O Daniel, you man greatly beloved.'"

*Dani'el ish-chamudot*—greatly beloved.

"'Understand the words that I speak unto you, and stand upright.'"

*Haven ba-devarim asher anokhi dover elekha va-amod al-omdekha*—understand, stand.

"'For now am I sent unto you.'"

*Ki attah shullachti elekha*—sent to you.

"I stood trembling."

*Va-amad maredד*—stood trembling.

**The Key Verses (10:12-13):**
"'Fear not, Daniel.'"

*Al-tira Dani'el*—fear not.

"'From the first day that you did set your heart to understand.'"

*Ki min-ha-yom ha-rishon asher natatta et-libbeka le-havin*—first day.

"'And to humble yourself before your God, your words were heard.'"

*U-le-hit'annot lifnei Elohekha nishme'u devarekha*—words heard.

"'I am come because of your words.'"

*Va-ani bati bi-devarekha*—came because of words.

"'But the prince of the kingdom of Persia withstood me one and twenty days.'"

*Ve-sar malkhut Paras omed le-negdi esrim ve-echad yom*—21 days.

**Sar Malkhut Paras:**
"Prince of the kingdom of Persia"—a spiritual being over Persia.

"'Michael, one of the chief princes, came to help me.'"

*Ve-hinneh Mikha'el achad ha-sarim ha-rishonim ba la'ozreni*—Michael helped.

**Michael:**
Archangel, Israel's prince.

"'I was left over there beside the kings of Persia.'"

*Va-ani notarti sham etzel malkhei Paras*—left there.

**The Key Verse (10:14):**
"'I am come to make you understand what shall befall your people in the end of days.'"

*U-vati la-havinekha et asher-yiqra le-ammekha be-acharit ha-yamim*—end of days.

"'For the vision is yet for many days.'"

*Ki-od chazon la-yamim*—many days.

**Further Strengthening (10:15-21):**
**The Key Verses (10:15-17):**
"I set my face toward the ground, and was dumb."

*Va-etten panai artzah va-e'alem*—face down, dumb.

"One like the similitude of the sons of men touched my lips."

*Ve-hinneh ki-demut benei adam noge'a al-sefatai*—touched lips.

"I opened my mouth, and spoke."

*Va-eftach-pi va-adabberah*—spoke.

"'O my lord, by reason of the vision my pains are come upon me.'"

*Adoni ba-mar'ah nehefkhu tzirai alai*—pains.

"'I retain no strength.'"

*Ve-lo atzarti koach*—no strength.

"'How can the servant of this my lord talk with this my lord?'"

*Ve-eikh yukhal eved adoni zeh le-dabber im-adoni zeh*—how can I speak?

"'Straightway there remained no strength in me, neither was there breath left in me.'"

*Va-ani me-attah lo-ya'amod-bi koach ve-neshamah lo nish'arah bi*—no breath.

**The Key Verses (10:18-19):**
"There touched me again one like the appearance of a man, and he strengthened me."

*Va-yosef va-yigga-bi ke-mar'eh adam va-yechazzeqeni*—strengthened.

"'O man greatly beloved, fear not; peace be unto you, be strong, yea, be strong.'"

*Al-tira ish-chamudot shalom lakh chazaq va-chazaq*—fear not, be strong.

"When he had spoken unto me, I was strengthened."

*U-khe-dabbero immi hitchazzaqti*—strengthened.

"'Let my lord speak; for you have strengthened me.'"

*Yedabber adoni ki chizzaqtani*—speak, I'm strengthened.

**The Key Verses (10:20-21):**
"'Do you know wherefore I am come unto you?'"

*Ha-yada'ta lammah-bati elekha*—do you know?

"'Now will I return to fight with the prince of Persia.'"

*Ve-attah ashuv le-hillachem im-sar Paras*—return to fight Persia's prince.

"'When I go forth, lo, the prince of Greece shall come.'"

*Ve-ani yotze ve-hinneh sar-Yavan ba*—Greece's prince comes.

"'I will declare unto you that which is inscribed in the writing of truth.'"

*Aval aggid lekha et-ha-rashum bi-khetav emet*—writing of truth.

"'There is none that holds with me against these, except Michael your prince.'"

*Ve-ein echad mitchazzeq immi al-elleh ki im-Mikha'el sarkhem*—only Michael.

**Archetypal Layer:** Daniel 10 begins the **final vision (10-12)**, containing **Daniel's 3-week mourning (10:2-3)**, **the glorious man by the Tigris (10:4-6)**, **Daniel alone saw the vision (10:7)**, **Daniel's strength fails (10:8-9)**, **"O Daniel, you man greatly beloved" (10:11, 19)**, **"from the first day... your words were heard" (10:12)**, **"the prince of the kingdom of Persia withstood me one and twenty days" (10:13)**, **"Michael, one of the chief princes, came to help me" (10:13)**, **"what shall befall your people in the end of days" (10:14)**, **"the prince of Greece shall come" (10:20)**, and **"that which is inscribed in the writing of truth" (10:21)**.

**Ethical Inversion Applied:**
- "In the third year of Cyrus king of Persia"—3rd year of Cyrus
- "A word was revealed unto Daniel"—revelation
- "The word was true"—true word
- "I Daniel was mourning three whole weeks"—3 weeks
- "I ate no pleasant bread"—fasting
- "Neither came flesh nor wine in my mouth"—no meat, wine
- "Neither did I anoint myself"—no anointing
- "In the four and twentieth day of the first month"—24th of 1st month
- "I was by the side of the great river, which is Tigris"—Tigris
- "Behold a man clothed in linen"—linen-clothed
- "Whose loins were girded with fine gold of Uphaz"—gold belt
- "His body also was like the beryl"—beryl
- "His face as the appearance of lightning"—lightning
- "His eyes as torches of fire"—fire
- "His arms and his feet like... burnished brass"—brass
- "The voice of his words like the voice of a multitude"—thunderous
- "I Daniel alone saw the vision"—alone
- "The men that were with me saw not the vision"—didn't see
- "A great trembling fell upon them, and they fled"—fled
- "There remained no strength in me"—no strength
- "My comeliness was turned in me into corruption"—corrupted
- "I was fallen into a deep sleep"—deep sleep
- "A hand touched me"—touched
- "'O Daniel, you man greatly beloved'"—beloved
- "'Understand the words that I speak unto you'"—understand
- "'Stand upright; for now am I sent unto you'"—sent
- "I stood trembling"—trembling
- "'Fear not, Daniel'"—fear not
- "'From the first day that you did set your heart to understand'"—first day
- "'Your words were heard'"—heard
- "'I am come because of your words'"—came
- "'The prince of the kingdom of Persia withstood me one and twenty days'"—21 days
- "'Michael, one of the chief princes, came to help me'"—Michael helped
- "'I am come to make you understand what shall befall your people'"—understand
- "'In the end of days'"—end of days
- "'The vision is yet for many days'"—future
- "I set my face toward the ground, and was dumb"—dumb
- "One like the similitude of the sons of men touched my lips"—touched lips
- "'By reason of the vision my pains are come upon me'"—pains
- "'I retain no strength'"—no strength
- "There touched me again one like the appearance of a man, and he strengthened me"—strengthened
- "'O man greatly beloved, fear not'"—fear not
- "'Peace be unto you, be strong, yea, be strong'"—be strong
- "I was strengthened"—strengthened
- "'Now will I return to fight with the prince of Persia'"—fight Persia's prince
- "'When I go forth, lo, the prince of Greece shall come'"—Greece's prince
- "'That which is inscribed in the writing of truth'"—writing of truth
- "'There is none that holds with me... except Michael your prince'"—Michael

**Modern Equivalent:** Daniel 10 introduces the final vision (10-12). The glorious figure's description anticipates Revelation 1's Christ. Cosmic warfare is revealed—the "prince of Persia" and "prince of Greece" are spiritual beings over nations. Michael is Israel's angelic prince. This establishes that earthly events reflect heavenly conflicts.

# Daniel 6: Daniel in the Lions' Den

*From the Aramaic: שְׁפַר קֳדָם דָּרְיָוֶשׁ (Shefar Qodam Daryavesh) — It Pleased Darius*

---

## Daniel's Position and the Conspiracy (6:1-9)

**6:1** It pleased Darius to set over the kingdom a hundred and twenty satraps, who should be throughout the whole kingdom;

**6:2** And over them three presidents, of whom Daniel was one; that these satraps might give account unto them, and that the king should have no damage.

**6:3** Then this Daniel distinguished himself above the presidents and the satraps, because a surpassing spirit was in him; and the king thought to set him over the whole realm.

**6:4** Then the presidents and the satraps sought to find occasion against Daniel as touching the kingdom; but they could find no occasion nor fault; forasmuch as he was faithful, neither was there any error or fault found in him.

**6:5** Then said these men: "We shall not find any occasion against this Daniel, except we find it against him concerning the law of his God."

**6:6** Then these presidents and satraps came tumultuously to the king, and said thus unto him: "King Darius, live for ever!

**6:7** "All the presidents of the kingdom, the prefects and the satraps, the ministers and the governors, have consulted together to establish a royal statute, and to make a strong interdict, that whosoever shall ask a petition of any god or man for thirty days, save of you, O king, he shall be cast into the den of lions.

**6:8** "Now, O king, establish the interdict, and sign the writing, that it be not changed, according to the law of the Medes and Persians, which alters not."

**6:9** Wherefore king Darius signed the writing and the interdict.

---

## Daniel's Faithfulness (6:10-15)

**6:10** And when Daniel knew that the writing was signed, he went into his house—now his windows were open in his upper chamber toward Jerusalem—and he kneeled upon his knees three times a day, and prayed, and gave thanks before his God, as he did aforetime.

**6:11** Then these men came tumultuously, and found Daniel making petition and supplication before his God.

**6:12** Then they came near, and spoke before the king concerning the king's interdict: "Have you not signed an interdict, that every man that shall ask a petition of any god or man within thirty days, save of you, O king, shall be cast into the den of lions?" The king answered and said: "The thing is true, according to the law of the Medes and Persians, which alters not."

**6:13** Then answered they and said before the king: "That Daniel, who is of the children of the captivity of Judah, regards not you, O king, nor the interdict that you have signed, but makes his petition three times a day."

**6:14** Then the king, when he heard these words, was sore displeased, and set his heart on Daniel to deliver him; and he laboured till the going down of the sun to deliver him.

**6:15** Then these men came tumultuously unto the king, and said unto the king: "Know, O king, that it is a law of the Medes and Persians, that no interdict nor statute which the king establishes may be changed."

---

## The Lions' Den (6:16-24)

**6:16** Then the king commanded, and they brought Daniel, and cast him into the den of lions. The king spoke and said unto Daniel: "Your God whom you serve continually, he will deliver you."

**6:17** And a stone was brought, and laid upon the mouth of the den; and the king sealed it with his own signet, and with the signet of his lords; that nothing might be changed concerning Daniel.

**6:18** Then the king went to his palace, and passed the night fasting; neither were diversions brought before him; and his sleep fled from him.

**6:19** Then the king arose very early in the morning, and went in haste unto the den of lions.

**6:20** And when he came near unto the den to Daniel, he cried with a pained voice; the king spoke and said to Daniel: "O Daniel, servant of the living God, is your God, whom you serve continually, able to deliver you from the lions?"

**6:21** Then said Daniel unto the king: "O king, live for ever!

**6:22** "My God has sent his angel, and has shut the lions' mouths, and they have not hurt me; forasmuch as before him innocence was found in me; and also before you, O king, have I done no hurt."

**6:23** Then was the king exceeding glad, and commanded that they should take Daniel up out of the den. So Daniel was taken up out of the den, and no manner of hurt was found upon him, because he had trusted in his God.

**6:24** And the king commanded, and they brought those men that had accused Daniel, and they cast them into the den of lions, them, their children, and their wives; and they had not come to the bottom of the den, when the lions had the mastery of them, and broke all their bones in pieces.

---

## Darius's Decree (6:25-28)

**6:25** Then king Darius wrote unto all the peoples, nations, and languages, that dwell in all the earth: "Peace be multiplied unto you.

**6:26** "I make a decree, that in all the dominion of my kingdom men tremble and fear before the God of Daniel; for he is the living God, and steadfast for ever, and his kingdom that which shall not be destroyed, and his dominion shall be even unto the end;

**6:27** "He delivers and rescues, and he works signs and wonders in heaven and in earth; who has delivered Daniel from the power of the lions."

**6:28** So this Daniel prospered in the reign of Darius, and in the reign of Cyrus the Persian.

---

## Synthesis Notes

**Key Restorations:**

**Daniel's Position and the Conspiracy (6:1-9):**
**The Key Verses (6:1-3):**
"It pleased Darius to set over the kingdom a hundred and twenty satraps."

*Shefar qodam Daryavesh va-haqim al-malkhuta achashdarpenaya me'ah ve-esrin*—120 satraps.

"Over them three presidents, of whom Daniel was one."

*Ve-aleihon sarekhin telata di-Dani'el chad-minהon*—3 presidents.

"That these satraps might give account unto them."

*Di-achashdarpenaya illek lehevon yahavin laהon ta'am*—give account.

"That the king should have no damage."

*U-malka la-leheve naziq*—no damage.

"This Daniel distinguished himself above the presidents and the satraps."

*Edayin Dani'el denah hava mitנatzach al-sarekhaיya ve-achashdarpenaya*—distinguished.

"Because a surpassing spirit was in him."

*Kol-qevel di ruach yattirah beh*—surpassing spirit.

"The king thought to set him over the whole realm."

*U-malka ashit le-haqamuteh al-kol malkhuta*—over whole realm.

**The Key Verses (6:4-5):**
"The presidents and the satraps sought to find occasion against Daniel."

*Edayin sarekhaיya ve-achashdarpenaya havו va'ein le-hashkachah illah le-Dani'el*—sought occasion.

"As touching the kingdom."

*Mi-tzad malkhuta*—regarding kingdom.

"They could find no occasion nor fault."

*Ve-khol-illah u-shechittah la-yakilin le-hashkachah*—found none.

"Forasmuch as he was faithful."

*Kol-qevel di-meheimanהu*—faithful.

"Neither was there any error or fault found in him."

*Ve-khol-shalו u-shechittah la hishtekachat alohi*—no error.

"'We shall not find any occasion against this Daniel.'"

*La nehashkach le-Dani'el denah kol-illah*—won't find occasion.

"'Except we find it against him concerning the law of his God.'"

*Lahen hashkachnah alohi be-dat Elaheh*—concerning his God.

**The Key Verses (6:6-9):**
"'All the presidents of the kingdom... have consulted together.'"

*Kol-sarekhai malkhuta... it'a'atu*—consulted.

"'To establish a royal statute, and to make a strong interdict.'"

*Le-haqamah qeyam malka u-le-taqqafah essar*—statute, interdict.

"'Whosoever shall ask a petition of any god or man for thirty days, save of you, O king.'"

*Di kol-di-yiv'eh ba'u min-kol-elah ve-enash ad-yomin telatin lahen minnakh malka*—petition only to king.

"'He shall be cast into the den of lions.'"

*Yitreme le-gov aryevata*—lions' den.

"'According to the law of the Medes and Persians, which alters not.'"

*Ke-dat-Madai u-Faras di-la teהaddah*—unchangeable law.

"King Darius signed the writing and the interdict."

*Kol-qevel denah malka Daryavesh resham ketava ve-essara*—signed.

**Daniel's Faithfulness (6:10-15):**
**The Key Verse (6:10):**
"When Daniel knew that the writing was signed."

*Ve-Dani'el kedi yeda di-reshim ketava*—knew it was signed.

"He went into his house."

*A'al le-vaiteh*—went home.

"His windows were open in his upper chamber toward Jerusalem."

*Ve-kavvin petיchan leh be-illiתeh neged Yerushalem*—windows toward Jerusalem.

"He kneeled upon his knees three times a day."

*U-zimnin telata be-yoma hu barekh al-birkohi*—three times daily.

"Prayed, and gave thanks before his God."

*U-metzalli u-modeh qodam Elaheh*—prayed, thanked.

"As he did aforetime."

*Kol-qevel di-hava aved min-qadmat denah*—as before.

**The Key Verses (6:11-13):**
"These men came tumultuously, and found Daniel making petition."

*Edayin guvraya illek hargishu ve-hashkachu le-Dani'el ba'eh u-mitchannen qodam Elaheh*—found praying.

"'Have you not signed an interdict?'"

*Ha-la essar reshamta*—didn't you sign?

"'That Daniel, who is of the children of the captivity of Judah.'"

*Dani'el di min-benei galuta di-Yehud*—captive from Judah.

"'Regards not you, O king, nor the interdict.'"

*La-sam alakh malka te'em ve-al-essara di reshamta*—disregards.

"'But makes his petition three times a day.'"

*Ve-zimnin telata be-yoma ba'eh ba'uteh*—prays 3 times.

**The Key Verses (6:14-15):**
"The king... was sore displeased."

*Edayin malka kedi milta shema saggi be'esh alohi*—displeased.

"Set his heart on Daniel to deliver him."

*Ve-al-Dani'el sam bal le-sheizavuteh*—set on delivering.

"He laboured till the going down of the sun to deliver him."

*Ve-ad ma'aley shimsha hava mishtaddar le-hatzaluteh*—worked till sunset.

"'It is a law of the Medes and Persians, that no interdict nor statute which the king establishes may be changed.'"

*Dat le-Madai u-Faras di kol-essar u-qeyam di-malka yehaqim la le-hashnayah*—unchangeable.

**Lions' Den (6:16-24):**
**The Key Verses (6:16-18):**
"They brought Daniel, and cast him into the den of lions."

*Ve-haitu le-Dani'el u-remu le-gubba di-aryevata*—cast in.

"'Your God whom you serve continually, he will deliver you.'"

*Elahakh di-ant paleach leh bi-tedira hu yesheizvinak*—God will deliver.

"A stone was brought, and laid upon the mouth of the den."

*Ve-heitat even chada ve-sumat al-pum gubba*—stone on mouth.

"The king sealed it with his own signet."

*Ve-chatamah malka be-izqeteh*—king's signet.

"And with the signet of his lords."

*U-ve-izqat ravrevanohi*—lords' signets.

"That nothing might be changed concerning Daniel."

*Di la-tishne tzevו be-Dani'el*—nothing changed.

"The king went to his palace, and passed the night fasting."

*Edayin azal malka le-heikhleh u-vat tevat ve-dachaван la hanlו qodamohi*—fasting.

"His sleep fled from him."

*Ve-shinteh nadat alohi*—sleepless.

**The Key Verses (6:19-23):**
"The king arose very early in the morning."

*Edayin malka bi-shefarpara qam be-nagha*—very early.

"Went in haste unto the den of lions."

*U-ve-hitbhalah le-gubba di-aryevata azal*—in haste.

"He cried with a pained voice."

*Be-qal atziv ze'aq*—pained cry.

"'O Daniel, servant of the living God.'"

*Dani'el eved Elaha chaיya*—servant of living God.

"'Is your God, whom you serve continually, able to deliver you from the lions?'"

*Elahakh di-ant paleach leh bi-tedira ha-yekhil le-sheizavutak min-aryevata*—able to deliver?

"'My God has sent his angel, and has shut the lions' mouths.'"

*Elahi shelach mal'akheh u-seגar pum aryevata*—sent angel, shut mouths.

"'They have not hurt me.'"

*Ve-la chavveluni*—not hurt.

"'Forasmuch as before him innocence was found in me.'"

*Kol-qevel di qodamohi zakhו hishtekachat li*—innocence.

"'And also before you, O king, have I done no hurt.'"

*Ve-af qodamakh malka chabalah la avdet*—no hurt.

"The king exceeding glad."

*Edayin malka saggi tab alohi*—exceedingly glad.

"Commanded that they should take Daniel up out of the den."

*Ve-le-Dani'el amar le-hassaqah min-gubba*—take up.

"No manner of hurt was found upon him."

*Ve-khol-chabal la-hishtekach beh*—no hurt.

"Because he had trusted in his God."

*Di heman be-Elaheh*—trusted in God.

**The Key Verse (6:24):**
"The king commanded, and they brought those men that had accused Daniel."

*Va-amar malka ve-haitu guvraya illek di-akhalu qortzוhi di-Dani'el*—accusers brought.

"They cast them into the den of lions, them, their children, and their wives."

*U-remו le-gubba di-aryevata innun bneihon u-nesheihon*—cast in.

"They had not come to the bottom of the den, when the lions had the mastery of them."

*Ve-la-metu le-ar'it gubba ad di-shletu behon aryevata*—lions seized.

"Broke all their bones in pieces."

*Ve-khol-garmeiהon haddקו*—broke bones.

**Darius's Decree (6:25-28):**
**The Key Verses (6:25-27):**
"King Darius wrote unto all the peoples, nations, and languages."

*Edayin Daryavesh malka ketav le-khol-ammaya ummaya ve-lishnaya*—to all peoples.

"'Peace be multiplied unto you.'"

*Shelamkon yisgeh*—peace.

"'I make a decree, that in all the dominion of my kingdom men tremble and fear before the God of Daniel.'"

*Minnai sim te'em di be-khol-sholtan malkhuti lehevon za'ein ve-dachalin min-qodam Elaheh di-Dani'el*—fear Daniel's God.

"'He is the living God.'"

*Di-hu Elaha chaיya*—living God.

"'Steadfast for ever.'"

*Ve-qayyam le-alemaya*—steadfast.

"'His kingdom that which shall not be destroyed.'"

*U-malkhuteh di-la titchabbal*—not destroyed.

"'His dominion shall be even unto the end.'"

*Ve-sholtaneh ad-sofa*—to the end.

"'He delivers and rescues.'"

*Mesheziv u-matzil*—delivers, rescues.

"'He works signs and wonders in heaven and in earth.'"

*Ve-aved atin ve-timhin bi-shemaya u-ve-ar'a*—signs, wonders.

"'Who has delivered Daniel from the power of the lions.'"

*Di sheziv le-Dani'el min-yad aryevata*—delivered Daniel.

**The Key Verse (6:28):**
"This Daniel prospered in the reign of Darius, and in the reign of Cyrus the Persian."

*Ve-Dani'el denah hatzlach be-malkhut Daryavesh u-ve-malkhut Koresh Parsa'ah*—prospered.

**Archetypal Layer:** Daniel 6 contains **Daniel as one of three presidents (6:2)**, **"a surpassing spirit was in him" (6:3)**, **"we shall not find any occasion against this Daniel, except we find it against him concerning the law of his God" (6:5)**, **the unchangeable law of the Medes and Persians (6:8, 12, 15)**, **Daniel praying toward Jerusalem three times daily (6:10)**, **"Your God whom you serve continually, he will deliver you" (6:16)**, **"My God has sent his angel, and has shut the lions' mouths" (6:22)**, **"because he had trusted in his God" (6:23)**, and **"He is the living God, and steadfast for ever" (6:26)**.

**Ethical Inversion Applied:**
- "It pleased Darius to set over the kingdom a hundred and twenty satraps"—120 satraps
- "Over them three presidents, of whom Daniel was one"—Daniel a president
- "This Daniel distinguished himself"—distinguished
- "Because a surpassing spirit was in him"—surpassing spirit
- "The king thought to set him over the whole realm"—over whole realm
- "The presidents and the satraps sought to find occasion against Daniel"—sought occasion
- "They could find no occasion nor fault"—found none
- "He was faithful"—faithful
- "Neither was there any error or fault found in him"—no error
- "'We shall not find any occasion... except... concerning the law of his God'"—only religious grounds
- "'Whosoever shall ask a petition of any god or man for thirty days, save of you, O king'"—only to king
- "'He shall be cast into the den of lions'"—penalty
- "'According to the law of the Medes and Persians, which alters not'"—unchangeable
- "King Darius signed the writing"—signed
- "When Daniel knew that the writing was signed"—knew
- "He went into his house"—went home
- "His windows were open... toward Jerusalem"—toward Jerusalem
- "He kneeled upon his knees three times a day"—three times
- "Prayed, and gave thanks before his God"—prayed
- "As he did aforetime"—unchanged practice
- "These men... found Daniel making petition"—found praying
- "'That Daniel... regards not you, O king'"—accused
- "'But makes his petition three times a day'"—3 times daily
- "The king... was sore displeased"—displeased
- "Set his heart on Daniel to deliver him"—tried to save
- "He laboured till the going down of the sun"—worked till sunset
- "'No interdict nor statute which the king establishes may be changed'"—unchangeable
- "They brought Daniel, and cast him into the den of lions"—cast in
- "'Your God whom you serve continually, he will deliver you'"—king's hope
- "A stone was brought, and laid upon the mouth"—sealed
- "The king sealed it with his own signet"—king's seal
- "The king... passed the night fasting"—fasting
- "His sleep fled from him"—sleepless
- "The king arose very early in the morning"—very early
- "Went in haste unto the den"—in haste
- "'O Daniel, servant of the living God'"—servant of living God
- "'Is your God... able to deliver you?'"—question
- "'My God has sent his angel'"—angel sent
- "'Has shut the lions' mouths'"—mouths shut
- "'They have not hurt me'"—not hurt
- "'Before him innocence was found in me'"—innocence
- "The king exceeding glad"—glad
- "No manner of hurt was found upon him"—no hurt
- "Because he had trusted in his God"—trusted
- "They brought those men that had accused Daniel"—accusers
- "They cast them into the den of lions, them, their children, and their wives"—destroyed
- "The lions had the mastery of them"—lions killed
- "'I make a decree... men tremble and fear before the God of Daniel'"—decree
- "'He is the living God'"—living God
- "'His kingdom that which shall not be destroyed'"—eternal kingdom
- "'He delivers and rescues'"—delivers
- "'He works signs and wonders'"—signs, wonders
- "This Daniel prospered in the reign of Darius, and in the reign of Cyrus"—prospered

**Modern Equivalent:** Daniel 6 parallels chapter 3—faithful Jews face death for religious practice. The "unchangeable law" creates the legal trap. Daniel's open windows toward Jerusalem (6:10) and three daily prayers show unchanged piety. "My God has sent his angel" (6:22) echoes 3:25. The story encourages faithfulness under hostile governments.

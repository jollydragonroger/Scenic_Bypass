# Daniel 8: The Vision of the Ram and the Goat

*From the Hebrew: בִּשְׁנַת שָׁלוֹשׁ לְמַלְכוּת בֵּלְשַׁאצַּר (Bi-Shnat Shalosh Le-Malkhut Belshatstsar) — In the Third Year of the Reign of Belshazzar*

---

## The Vision (8:1-14)

**8:1** In the third year of the reign of king Belshazzar a vision appeared unto me, even unto me Daniel, after that which appeared unto me at the first.

**8:2** And I saw in the vision; now it was so, that when I saw, I was in Shushan the palace, which is in the province of Elam; and I saw in the vision, and I was by the stream Ulai.

**8:3** And I lifted up my eyes, and saw, and, behold, there stood before the stream a ram which had two horns; and the two horns were high; but one was higher than the other, and the higher came up last.

**8:4** I saw the ram pushing westward, and northward, and southward; and no beasts could stand before him, neither was there any that could deliver out of his hand; but he did according to his will, and magnified himself.

**8:5** And as I was considering, behold, a he-goat came from the west over the face of the whole earth, and touched not the ground; and the goat had a conspicuous horn between his eyes.

**8:6** And he came to the ram that had the two horns, which I saw standing before the stream, and ran at him in the fury of his power.

**8:7** And I saw him come close unto the ram, and he was moved with choler against him, and smote the ram, and broke his two horns; and there was no power in the ram to stand before him; but he cast him down to the ground, and trampled upon him; and there was none that could deliver the ram out of his hand.

**8:8** And the he-goat magnified himself exceedingly; and when he was strong, the great horn was broken; and instead of it there came up four conspicuous horns toward the four winds of heaven.

**8:9** And out of one of them came forth a little horn, which waxed exceeding great, toward the south, and toward the east, and toward the beauteous land.

**8:10** And it waxed great, even to the host of heaven; and some of the host and of the stars it cast down to the ground, and trampled upon them.

**8:11** Yea, it magnified itself, even to the prince of the host; and from him the continual burnt-offering was taken away, and the place of his sanctuary was cast down.

**8:12** And the host was given over to it together with the continual burnt-offering through transgression; and it cast down truth to the ground, and it wrought, and prospered.

**8:13** Then I heard a holy one speaking; and another holy one said unto that certain one who spoke: "How long shall be the vision concerning the continual burnt-offering, and the transgression that causes appalment, to give both the sanctuary and the host to be trampled under foot?"

**8:14** And he said unto me: "Unto two thousand and three hundred evenings and mornings; then shall the sanctuary be cleansed."

---

## Gabriel's Interpretation (8:15-27)

**8:15** And it came to pass, when I, even I Daniel, had seen the vision, that I sought to understand it; and, behold, there stood before me as the appearance of a man.

**8:16** And I heard the voice of a man between the banks of Ulai, who called, and said: "Gabriel, make this man to understand the vision."

**8:17** So he came near where I stood; and when he came, I was terrified, and fell upon my face; but he said unto me: "Understand, O son of man; for the vision belongs to the time of the end."

**8:18** Now as he was speaking with me, I fell into a deep sleep with my face toward the ground; but he touched me, and set me upright.

**8:19** And he said: "Behold, I will make you know what shall be in the latter time of the indignation; for it belongs to the appointed time of the end.

**8:20** "The ram which you saw having the two horns, they are the kings of Media and Persia.

**8:21** "And the rough he-goat is the king of Greece; and the great horn that is between his eyes is the first king.

**8:22** "And as for that which was broken, in the place whereof four stood up, four kingdoms shall stand up out of the nation, but not with his power.

**8:23** "And in the latter time of their kingdom, when the transgressors have completed their deceit, a king of fierce countenance, and understanding dark sentences, shall stand up.

**8:24** "And his power shall be mighty, but not by his own power; and he shall destroy wonderfully, and shall prosper and do; and he shall destroy them that are mighty and the people of the saints.

**8:25** "And through his cunning he shall cause craft to prosper in his hand; and he shall magnify himself in his heart, and in time of security shall he destroy many; he shall also stand up against the prince of princes; but he shall be broken without hand.

**8:26** "And the vision of the evenings and mornings which has been told is true; but shut up the vision; for it belongs to many days to come."

**8:27** And I Daniel fainted, and was sick certain days; then I rose up, and did the king's business; and I was appalled at the vision, but understood it not.

---

## Synthesis Notes

**Key Restorations:**

**The Vision (8:1-14):**
**The Key Verses (8:1-2):**
"In the third year of the reign of king Belshazzar a vision appeared unto me."

*Bi-shnat shalosh le-malkhut Belshatstsar ha-melekh chazon nir'ah elai*—3rd year, vision.

"I was in Shushan the palace, which is in the province of Elam."

*Va-ani be-Shushan ha-birah asher be-Elam ha-medinah*—Susa, Elam.

"I was by the stream Ulai."

*Va-ani al-uval Ulai*—Ulai canal.

**The Key Verses (8:3-4):**
"There stood before the stream a ram which had two horns."

*Va-essa einai va-ere ve-hinneh ayil echad omed lifnei ha-uval ve-lo qeranaיim*—ram, two horns.

"The two horns were high; but one was higher than the other."

*Ve-ha-qeranayim gevohot ve-ha-achat gevohah min-ha-shenit*—one higher.

"The higher came up last."

*Ve-ha-gevohah olah ba-acharonah*—higher last.

"I saw the ram pushing westward, and northward, and southward."

*Ra'iti et-ha-ayil menagge'ach yamah ve-tzafonah ve-negbah*—pushing.

"No beasts could stand before him."

*Ve-khol-chayyot lo-ya'amdu lefanav*—none stand.

"He did according to his will, and magnified himself."

*Va-ya'as ki-retzono ve-higdil*—his will, magnified.

**The Key Verses (8:5-8):**
"A he-goat came from the west over the face of the whole earth."

*Ve-hinneh tzefir-ha-izzim ba min-ha-ma'arav al-penei khol-ha-aretz*—goat from west.

"Touched not the ground."

*Ve-ein noge'a ba-aretz*—didn't touch ground.

"The goat had a conspicuous horn between his eyes."

*Ve-ha-tzafir qeren chazut bein einav*—horn between eyes.

"He came to the ram that had the two horns."

*Va-yavo ad-ha-ayil ba'al ha-qeranayim*—came to ram.

"Ran at him in the fury of his power."

*Va-yarotz eilav ba-chamat kocho*—fury of power.

"Smote the ram, and broke his two horns."

*Va-yakh et-ha-ayil va-yeshabber et-shתei qeranav*—broke horns.

"There was no power in the ram to stand before him."

*Ve-lo-hayah koach ba-ayil la'amod lefanav*—no power.

"He cast him down to the ground, and trampled upon him."

*Va-yashlikhehu artzah va-yirmesehu*—trampled.

"The he-goat magnified himself exceedingly."

*Ve-ha-tzefir ha-izzim higdil ad-me'od*—magnified exceedingly.

"When he was strong, the great horn was broken."

*U-khe-otzmo nishberah ha-qeren ha-gedolah*—great horn broken.

"Instead of it there came up four conspicuous horns toward the four winds of heaven."

*Va-ta'alenah chazut arba tachteha le-arba ruchot ha-shamayim*—four horns.

**The Key Verses (8:9-12):**
"Out of one of them came forth a little horn."

*U-min-ha-achat mehem yatza qeren-achat mitze'irah*—little horn.

"Which waxed exceeding great, toward the south, and toward the east, and toward the beauteous land."

*Va-tigdal-yeter el-ha-negev ve-el-ha-mizrach ve-el-ha-tzevi*—south, east, beauteous land.

**Ha-Tzevi:**
"The beauteous land" = the land of Israel.

"It waxed great, even to the host of heaven."

*Va-tigdal ad-tzeva ha-shamayim*—to host of heaven.

"Some of the host and of the stars it cast down to the ground, and trampled upon them."

*Va-tappel artzah min-ha-tzava u-min-ha-kokhaבim va-tirmeسem*—cast down stars.

"It magnified itself, even to the prince of the host."

*Ve-ad-sar-ha-tzava higdil*—to prince of host.

"From him the continual burnt-offering was taken away."

*Ve-mimmennו huram ha-tamid*—tamid taken.

"The place of his sanctuary was cast down."

*Ve-hushlakh mekhon miqdosho*—sanctuary cast down.

"The host was given over to it together with the continual burnt-offering through transgression."

*Ve-tzava tinnaten al-ha-tamid be-fesha*—host given through transgression.

"It cast down truth to the ground."

*Ve-tashლekh emet artzah*—cast down truth.

"It wrought, and prospered."

*Ve-asetah ve-hitzlicha*—prospered.

**The Key Verses (8:13-14):**
"'How long shall be the vision concerning the continual burnt-offering?'"

*Ad-matai ha-chazon ha-tamid*—how long?

"'The transgression that causes appalment.'"

*Ve-ha-pesha shomem*—transgression of desolation.

"'To give both the sanctuary and the host to be trampled under foot?'"

*Tet ve-qodesh ve-tzava mirmas*—trampled.

"'Unto two thousand and three hundred evenings and mornings.'"

*Ad erev boqer alpayim u-shlosh me'ot*—2,300 evenings-mornings.

"'Then shall the sanctuary be cleansed.'"

*Ve-nitzdaq qodesh*—sanctuary cleansed.

**2,300 Evenings and Mornings:**
Likely 1,150 days (morning and evening sacrifices) = about 3 years.

**Gabriel's Interpretation (8:15-27):**
**The Key Verses (8:15-17):**
"I sought to understand it."

*Va-avaqshah binah*—sought understanding.

"There stood before me as the appearance of a man."

*Ve-hinneh omed le-negdi ke-mar'eh-gaver*—like a man.

"'Gabriel, make this man to understand the vision.'"

*Gavriel haven le-hallaz et-ha-mar'eh*—Gabriel, explain.

**Gabriel:**
First named angel in the Bible.

"When he came, I was terrified, and fell upon my face."

*U-ve-vo'o nivhalt va-eppelah al-panai*—terrified.

"'Understand, O son of man; for the vision belongs to the time of the end.'"

*Haben ben-adam ki le-et-qetz ha-chazon*—time of end.

**The Key Verses (8:19-22):**
"'I will make you know what shall be in the latter time of the indignation.'"

*Hineni modi'akha et asher-yihyeh be-acharit ha-za'am*—latter time.

"'For it belongs to the appointed time of the end.'"

*Ki le-mo'ed qetz*—appointed end.

"'The ram which you saw having the two horns, they are the kings of Media and Persia.'"

*Ha-ayil asher-ra'ita ba'al ha-qeranayim malkhei Madai u-Faras*—Medo-Persia.

"'The rough he-goat is the king of Greece.'"

*Ve-ha-tzafir ha-sa'ir melekh Yavan*—Greece.

"'The great horn that is between his eyes is the first king.'"

*Ve-ha-qeren ha-gedolah asher bein-einav hu ha-melekh ha-rishon*—first king.

**First King:**
Alexander the Great.

"'Four kingdoms shall stand up out of the nation, but not with his power.'"

*Ve-arba malkhuyot ta'amodnah mi-goy ve-lo ve-kocho*—four successors.

**Four Kingdoms:**
Alexander's generals (Ptolemy, Seleucus, Lysimachus, Cassander).

**The Key Verses (8:23-25):**
"'In the latter time of their kingdom, when the transgressors have completed their deceit.'"

*U-ve-acharit malkhutam ke-hatem ha-posh'im*—latter time.

"'A king of fierce countenance, and understanding dark sentences, shall stand up.'"

*Ya'amod melekh az-panim u-mevin chidot*—fierce king.

"'His power shall be mighty, but not by his own power.'"

*Ve-atzam kocho ve-lo ve-kocho*—not his own power.

"'He shall destroy wonderfully, and shall prosper and do.'"

*U-nifla'ot yashchit ve-hitzliach ve-asah*—destroy wonderfully.

"'He shall destroy them that are mighty and the people of the saints.'"

*Ve-hishchit atzumim ve-am-qedoshim*—destroy mighty, saints.

"'Through his cunning he shall cause craft to prosper in his hand.'"

*Ve-al-siklo ve-hitzliach mirmah be-yado*—craft prospers.

"'He shall magnify himself in his heart.'"

*U-vi-lvavo yagdil*—magnify self.

"'In time of security shall he destroy many.'"

*U-ve-shalvah yashchit rabbim*—destroy in peace.

"'He shall also stand up against the prince of princes.'"

*Ve-al-sar-sarim ya'amod*—against Prince of princes.

"'He shall be broken without hand.'"

*Ve-be-efes yad yishShaber*—broken without hand.

**King of Fierce Countenance:**
Antiochus IV Epiphanes (175-164 BCE).

**The Key Verses (8:26-27):**
"'The vision of the evenings and mornings which has been told is true.'"

*U-mar'eh ha-erev ve-ha-boqer asher ne'emar emet hu*—vision true.

"'Shut up the vision; for it belongs to many days to come.'"

*Ve-attah setom ha-chazon ki le-yamim rabbim*—many days.

"I Daniel fainted, and was sick certain days."

*Va-ani Dani'el nihyeiti ve-necheleti yamim*—fainted, sick.

"I rose up, and did the king's business."

*Va-aqom va-e'eseh et-meleכhet ha-melekh*—resumed duties.

"I was appalled at the vision, but understood it not."

*Va-eshtomem al-ha-mar'eh ve-ein mevin*—appalled, didn't understand.

**Archetypal Layer:** Daniel 8 contains **the ram with two horns = Medo-Persia (8:3, 20)**, **the goat with the conspicuous horn = Greece/Alexander (8:5, 21)**, **the great horn broken and four replace it = Alexander's successors (8:8, 22)**, **the little horn from one of them (8:9)**, **"the beauteous land" = Israel (8:9)**, **"the continual burnt-offering was taken away" (8:11)**, **"the transgression that causes appalment" (8:13)**, **"2,300 evenings and mornings" (8:14)**, **Gabriel the angel (8:16)**, **"the vision belongs to the time of the end" (8:17)**, **"a king of fierce countenance" = Antiochus IV (8:23)**, and **"he shall be broken without hand" (8:25)**.

**Ethical Inversion Applied:**
- "In the third year of the reign of king Belshazzar"—3rd year
- "A vision appeared unto me"—vision
- "I was in Shushan the palace, which is in the province of Elam"—Susa
- "I was by the stream Ulai"—Ulai
- "There stood before the stream a ram which had two horns"—ram
- "One was higher than the other, and the higher came up last"—one higher
- "I saw the ram pushing westward, and northward, and southward"—pushing
- "No beasts could stand before him"—none stand
- "He did according to his will, and magnified himself"—magnified
- "A he-goat came from the west over the face of the whole earth"—goat from west
- "Touched not the ground"—swift
- "The goat had a conspicuous horn between his eyes"—great horn
- "Ran at him in the fury of his power"—fury
- "Smote the ram, and broke his two horns"—broke
- "He cast him down to the ground, and trampled upon him"—trampled
- "The he-goat magnified himself exceedingly"—magnified
- "When he was strong, the great horn was broken"—horn broken
- "Instead of it there came up four conspicuous horns"—four horns
- "Out of one of them came forth a little horn"—little horn
- "Which waxed exceeding great, toward the south, and toward the east, and toward the beauteous land"—toward Israel
- "It waxed great, even to the host of heaven"—to host
- "Some of the host and of the stars it cast down"—cast down stars
- "It magnified itself, even to the prince of the host"—to prince
- "From him the continual burnt-offering was taken away"—tamid taken
- "The place of his sanctuary was cast down"—sanctuary cast down
- "It cast down truth to the ground"—truth cast down
- "It wrought, and prospered"—prospered
- "'How long shall be the vision?'"—how long
- "'The transgression that causes appalment'"—abomination
- "'Unto two thousand and three hundred evenings and mornings'"—2,300
- "'Then shall the sanctuary be cleansed'"—cleansed
- "There stood before me as the appearance of a man"—angelic figure
- "'Gabriel, make this man to understand'"—Gabriel
- "'The vision belongs to the time of the end'"—time of end
- "'The ram... they are the kings of Media and Persia'"—Medo-Persia
- "'The rough he-goat is the king of Greece'"—Greece
- "'The great horn... is the first king'"—Alexander
- "'Four kingdoms shall stand up out of the nation'"—four successors
- "'A king of fierce countenance... shall stand up'"—fierce king
- "'He shall destroy wonderfully'"—destroy
- "'He shall destroy them that are mighty and the people of the saints'"—destroy saints
- "'Through his cunning he shall cause craft to prosper'"—cunning
- "'He shall magnify himself in his heart'"—self-magnify
- "'In time of security shall he destroy many'"—destroy in peace
- "'He shall also stand up against the prince of princes'"—against God
- "'He shall be broken without hand'"—broken supernaturally
- "'Shut up the vision; for it belongs to many days'"—seal vision
- "I Daniel fainted, and was sick"—fainted
- "I was appalled at the vision, but understood it not"—appalled

**Modern Equivalent:** Daniel 8 is explicit—the ram is Medo-Persia, the goat is Greece. Alexander (the great horn) is replaced by four successors. The "little horn" is Antiochus IV Epiphanes, who desecrated the Jerusalem temple (167 BCE). Gabriel's first biblical appearance explains the vision as concerning "the time of the end" (8:17).

# Daniel 3: The Fiery Furnace

*From the Aramaic: נְבוּכַדְנֶצַּר מַלְכָּא עֲבַד צְלֵם (Nevukhadnetstsar Malka Avad Tzelem) — Nebuchadnezzar the King Made an Image*

---

## The Golden Image (3:1-7)

**3:1** Nebuchadnezzar the king made an image of gold, whose height was threescore cubits, and the breadth thereof six cubits; he set it up in the plain of Dura, in the province of Babylon.

**3:2** Then Nebuchadnezzar the king sent to gather together the satraps, the prefects, and the governors, the judges, the treasurers, the counsellors, the sheriffs, and all the rulers of the provinces, to come to the dedication of the image which Nebuchadnezzar the king had set up.

**3:3** Then the satraps, the prefects, and the governors, the judges, the treasurers, the counsellors, the sheriffs, and all the rulers of the provinces, were gathered together unto the dedication of the image that Nebuchadnezzar the king had set up; and they stood before the image that Nebuchadnezzar had set up.

**3:4** And the herald cried aloud: "To you it is commanded, O peoples, nations, and languages,

**3:5** "That at what time you hear the sound of the horn, pipe, harp, trigon, psaltery, bagpipe, and all kinds of music, you fall down and worship the golden image that Nebuchadnezzar the king has set up;

**3:6** "And whoso falls not down and worships shall the same hour be cast into the midst of a burning fiery furnace."

**3:7** Therefore at that time, when all the peoples heard the sound of the horn, pipe, harp, trigon, psaltery, and all kinds of music, all the peoples, the nations, and the languages, fell down and worshipped the golden image that Nebuchadnezzar the king had set up.

---

## The Accusation Against the Jews (3:8-12)

**3:8** Wherefore at that time certain Chaldeans came near, and brought accusation against the Jews.

**3:9** They spoke and said to the king Nebuchadnezzar: "O king, live for ever!

**3:10** "You, O king, have made a decree, that every man that shall hear the sound of the horn, pipe, harp, trigon, psaltery, and bagpipe, and all kinds of music, shall fall down and worship the golden image;

**3:11** "And whoso falls not down and worships shall be cast into the midst of a burning fiery furnace.

**3:12** "There are certain Jews whom you have appointed over the affairs of the province of Babylon, Shadrach, Meshach, and Abed-nego; these men, O king, have not regarded you: they serve not your gods, nor worship the golden image which you have set up."

---

## The King's Ultimatum (3:13-18)

**3:13** Then Nebuchadnezzar in rage and fury commanded to bring Shadrach, Meshach, and Abed-nego. Then were these men brought before the king.

**3:14** Nebuchadnezzar spoke and said unto them: "Is it true, O Shadrach, Meshach, and Abed-nego, that you serve not my gods, nor worship the golden image which I have set up?

**3:15** "Now if you be ready that at what time you hear the sound of the horn, pipe, harp, trigon, psaltery, and bagpipe, and all kinds of music, you fall down and worship the image which I have made, well; but if you worship not, you shall be cast the same hour into the midst of a burning fiery furnace; and who is the god that shall deliver you out of my hands?"

**3:16** Shadrach, Meshach, and Abed-nego, answered and said to the king: "O Nebuchadnezzar, we have no need to answer you in this matter.

**3:17** "If it be so, our God whom we serve is able to deliver us from the burning fiery furnace; and he will deliver us out of your hand, O king.

**3:18** "But if not, be it known unto you, O king, that we will not serve your gods, nor worship the golden image which you have set up."

---

## Into the Furnace (3:19-23)

**3:19** Then was Nebuchadnezzar full of fury, and the form of his visage was changed against Shadrach, Meshach, and Abed-nego; he spoke, and commanded that they should heat the furnace seven times more than it was wont to be heated.

**3:20** And he commanded certain mighty men that were in his army to bind Shadrach, Meshach, and Abed-nego, and to cast them into the burning fiery furnace.

**3:21** Then these men were bound in their cloaks, their tunics, and their robes, and their other garments, and were cast into the midst of the burning fiery furnace.

**3:22** Therefore because the king's commandment was peremptory, and the furnace exceeding hot, the flame of the fire slew those men that took up Shadrach, Meshach, and Abed-nego.

**3:23** And these three men, Shadrach, Meshach, and Abed-nego, fell down bound into the midst of the burning fiery furnace.

---

## The Fourth Figure (3:24-27)

**3:24** Then Nebuchadnezzar the king was astonished, and rose up in haste; he spoke and said unto his ministers: "Did not we cast three men bound into the midst of the fire?" They answered and said unto the king: "True, O king."

**3:25** He answered and said: "Lo, I see four men loose, walking in the midst of the fire, and they have no hurt; and the appearance of the fourth is like a son of the gods."

**3:26** Then Nebuchadnezzar came near to the mouth of the burning fiery furnace; he spoke and said: "Shadrach, Meshach, and Abed-nego, you servants of the Most High God, come forth, and come hither." Then Shadrach, Meshach, and Abed-nego, came forth out of the midst of the fire.

**3:27** And the satraps, the prefects, and the governors, and the king's ministers, being gathered together, saw these men, that the fire had no power upon their bodies, nor was the hair of their head singed, neither were their cloaks changed, nor had the smell of fire passed on them.

---

## The King's Decree (3:28-30)

**3:28** Nebuchadnezzar spoke and said: "Blessed be the God of Shadrach, Meshach, and Abed-nego, who has sent his angel, and delivered his servants that trusted in him, and have changed the king's word, and have yielded their bodies, that they might not serve nor worship any god, except their own God.

**3:29** "Therefore I make a decree, that every people, nation, and language, which speak any thing amiss against the God of Shadrach, Meshach, and Abed-nego, shall be cut in pieces, and their houses shall be made a dunghill; because there is no other god that is able to deliver after this sort."

**3:30** Then the king promoted Shadrach, Meshach, and Abed-nego, in the province of Babylon.

---

## Synthesis Notes

**Key Restorations:**

**Golden Image (3:1-7):**
**The Key Verse (3:1):**
"Nebuchadnezzar the king made an image of gold."

*Nevukhadnetstsar malka avad tzelem di-dehav*—gold image.

"Whose height was threescore cubits, and the breadth thereof six cubits."

*Rumeh ammin shittin petיה ammin shith*—60 x 6 cubits.

"He set it up in the plain of Dura, in the province of Babylon."

*Aqimeh be-viq'at Dura bi-medinat Bavel*—plain of Dura.

**The Key Verses (3:4-6):**
"The herald cried aloud."

*Ve-kharoza qare be-chayil*—herald cried.

"'To you it is commanded, O peoples, nations, and languages.'"

*Lekhem amerin ammaya ummaya ve-lishnaya*—all peoples.

"'At what time you hear the sound of the horn, pipe, harp, trigon, psaltery, bagpipe, and all kinds of music.'"

*Be-idna di tishme'un qal qarna mashroqita qitros sabbeka pesanterin sumponyah ve-khol zenei zemara*—instruments.

"'You fall down and worship the golden image.'"

*Tipplun ve-tisgedun le-tzelem dahava*—fall, worship.

"'Whoso falls not down and worships shall the same hour be cast into the midst of a burning fiery furnace.'"

*U-man di-la yippel ve-yisgud be-shא'ta yitreme le-go attun nura yaqidta*—fiery furnace.

**Accusation Against the Jews (3:8-12):**
"Certain Chaldeans came near, and brought accusation against the Jews."

*Kol-qevel denah bi-zimnah denah qerivu guvrin Kasda'in va-akhalu qortzeiהon di Yehuda'ei*—accused Jews.

"'There are certain Jews whom you have appointed over the affairs of the province of Babylon.'"

*Itai guvrin Yehuda'in di-mannita yathon al avidta di medinat Bavel*—Jews appointed.

"'Shadrach, Meshach, and Abed-nego.'"

*Shadrakh Meishakh va-Aved Nego*—the three.

"'These men, O king, have not regarded you.'"

*Guvraya illek malka la samu alakh te'em*—disregarded king.

"'They serve not your gods.'"

*Le-elahakh la falchin*—don't serve gods.

"'Nor worship the golden image which you have set up.'"

*U-le-tzelem dahava di haqemta la sagdin*—don't worship image.

**King's Ultimatum (3:13-18):**
"Nebuchadnezzar in rage and fury commanded to bring Shadrach, Meshach, and Abed-nego."

*Edayin Nevukhadnetstsar be-regaz va-chamah amar le-haytayah le-Shadrakh Meishakh va-Aved Nego*—rage, fury.

"'Is it true, O Shadrach, Meshach, and Abed-nego, that you serve not my gods?'"

*Ha-tzda Shadrakh Meishakh va-Aved Nego le-elahay la iteikhon falchin*—is it true?

"'Who is the god that shall deliver you out of my hands?'"

*U-man-hu elah di yeshezvinkon min-yedai*—what god can deliver?

**The Key Verses (3:16-18):**
"'O Nebuchadnezzar, we have no need to answer you in this matter.'"

*Nevukhadnetstsar la chashchin anachna al-denah pitgam le-hatavutakh*—no need to answer.

"'If it be so, our God whom we serve is able to deliver us from the burning fiery furnace.'"

*Hen itai Elahana di-anachna falchin yakil le-sheizavutana min-attun nura yaqidta*—God able.

"'He will deliver us out of your hand, O king.'"

*U-min-yadakh malka yesheizyב*—will deliver.

"'But if not, be it known unto you, O king.'"

*Ve-hen la yedi'a leheve-lakh malka*—but if not.

"'We will not serve your gods, nor worship the golden image.'"

*Di le-elahakh la itaיna falchin u-le-tzelem dahava di haqemta la nisgud*—won't serve or worship.

**Into the Furnace (3:19-23):**
"Nebuchadnezzar full of fury."

*Edayin Nevukhadnetstsar hitmeli chema*—full of fury.

"The form of his visage was changed against Shadrach, Meshach, and Abed-nego."

*Ve-tzelem anpohi eshtanni al Shadrakh Meishakh va-Aved Nego*—face changed.

"He commanded that they should heat the furnace seven times more."

*Aneh va-amar le-meze le-attuna chad-shiv'a al-di chaze le-mezeיeh*—7 times hotter.

"He commanded certain mighty men... to bind Shadrach, Meshach, and Abed-nego."

*Ve-li-guvrin gibberei chayil... amar le-kheppata le-Shadrakh Meishakh va-Aved Nego*—bind.

"And to cast them into the burning fiery furnace."

*Le-mirme le-attun nura yaqidta*—cast in.

"These men were bound in their cloaks, their tunics, and their robes."

*Edayin guvraya illek keppitu be-sarbeleiהon patisheiהon ve-khovleiהon u-levusheiהon*—bound in clothes.

"The flame of the fire slew those men that took up Shadrach, Meshach, and Abed-nego."

*Sheviva di-nura qatlet le-guvraya illek di hassiqu le-Shadrakh Meishakh va-Aved Nego*—executioners died.

**Fourth Figure (3:24-27):**
"Nebuchadnezzar the king was astonished."

*Edayin Nevukhadnetstsar malka tevah*—astonished.

"'Did not we cast three men bound into the midst of the fire?'"

*Ha-la guvrin telata remeinah le-go nura mekappatin*—three bound.

"'True, O king.'"

*Yatziva malka*—true.

**The Key Verse (3:25):**
"'Lo, I see four men loose, walking in the midst of the fire.'"

*Ha-ana chaze guvrin arba'ah sherain mehallekin be-go nura*—four walking.

"'They have no hurt.'"

*Ve-chaval la itai vehon*—no hurt.

"'The appearance of the fourth is like a son of the gods.'"

*Ve-reveh di revi'a'ah dameh le-var elahin*—like son of gods.

**Bar Elahin:**
"Son of the gods"—interpreted as an angel or divine being.

**The Key Verses (3:26-27):**
"Nebuchadnezzar came near to the mouth of the burning fiery furnace."

*Edayin qerev Nevukhadnetstsar le-tera attun nura yaqidta*—came near.

"'Shadrach, Meshach, and Abed-nego, you servants of the Most High God, come forth.'"

*Shadrakh Meishakh va-Aved Nego avdohi di-Elaha illא'a puqu u-atu*—servants of Most High.

"Shadrach, Meshach, and Abed-nego, came forth out of the midst of the fire."

*Edayin nafqin Shadrakh Meishakh va-Aved Nego min-go nura*—came out.

"The fire had no power upon their bodies."

*Di la shalit nura be-geshmeהon*—no power.

"Nor was the hair of their head singed."

*U-se'ar re'shehon la hitcharakh*—hair not singed.

"Neither were their cloaks changed."

*Ve-sarbeleiהon la shenu*—cloaks unchanged.

"Nor had the smell of fire passed on them."

*Ve-rei'ach nur la adat behon*—no smell of fire.

**King's Decree (3:28-30):**
"'Blessed be the God of Shadrach, Meshach, and Abed-nego.'"

*Berikh Elahhon di-Shadrakh Meishakh va-Aved Nego*—blessed be God.

"'Who has sent his angel, and delivered his servants that trusted in him.'"

*Di shlach mal'akheh ve-sheiziv le-avdohi di rеchitzu alוhi*—sent angel.

"'Have changed the king's word.'"

*U-millat malka shannyu*—changed king's word.

"'Have yielded their bodies.'"

*Vi-yhavu geshmeהon*—gave bodies.

"'That they might not serve nor worship any god, except their own God.'"

*Di la-yiflchun ve-la-yisgedun le-khol-elah lahen le-Elahhon*—only their God.

"'I make a decree, that every people, nation, and language, which speak any thing amiss against the God of Shadrach, Meshach, and Abed-nego, shall be cut in pieces.'"

*U-minni sim te'em di kol-am ummah ve-lishan di-yemar shalah al Elahhon di-Shadrakh Meishakh va-Aved Nego haddamin yitavad*—decree.

"'Because there is no other god that is able to deliver after this sort.'"

*Kol-qevel di la itai elah ochoran di-yakil le-hatzalah ki-denah*—no other god.

"The king promoted Shadrach, Meshach, and Abed-nego."

*Edayin malka hatzlach le-Shadrakh Meishakh va-Aved Nego bi-medinat Bavel*—promoted.

**Archetypal Layer:** Daniel 3 contains **the golden image 60 x 6 cubits (3:1)**, **the command to worship at the sound of music (3:5)**, **"shall be cast into the midst of a burning fiery furnace" (3:6)**, **accusation against the three Jews (3:8-12)**, **"Our God whom we serve is able to deliver us" (3:17)**, **"But if not... we will not serve your gods" (3:18)**, **furnace heated seven times hotter (3:19)**, **"the appearance of the fourth is like a son of the gods" (3:25)**, and **"the fire had no power upon their bodies" (3:27)**.

**Ethical Inversion Applied:**
- "Nebuchadnezzar the king made an image of gold"—gold image
- "Whose height was threescore cubits"—60 cubits tall
- "He set it up in the plain of Dura"—Dura
- "The king sent to gather together the satraps, the prefects"—officials
- "To come to the dedication of the image"—dedication
- "'At what time you hear the sound of the horn, pipe, harp'"—music signal
- "'You fall down and worship the golden image'"—command to worship
- "'Whoso falls not down and worships shall... be cast into... a burning fiery furnace'"—penalty
- "All the peoples... fell down and worshipped"—all worshipped
- "Certain Chaldeans... brought accusation against the Jews"—accused
- "'There are certain Jews'"—identified
- "'Shadrach, Meshach, and Abed-nego'"—the three
- "'These men... have not regarded you'"—disregarded
- "'They serve not your gods'"—didn't serve
- "Nebuchadnezzar in rage and fury"—rage
- "'Is it true... that you serve not my gods?'"—questioned
- "'Who is the god that shall deliver you out of my hands?'"—challenge
- "'We have no need to answer you in this matter'"—confident
- "'Our God whom we serve is able to deliver us'"—able
- "'He will deliver us out of your hand'"—will deliver
- "'But if not... we will not serve your gods'"—faithful regardless
- "Nebuchadnezzar full of fury"—fury
- "The form of his visage was changed"—face changed
- "He commanded... heat the furnace seven times more"—7 times hotter
- "He commanded... to bind Shadrach, Meshach, and Abed-nego"—bound
- "Cast them into the burning fiery furnace"—cast in
- "The flame of the fire slew those men that took up"—executioners died
- "Nebuchadnezzar the king was astonished"—astonished
- "'Did not we cast three men bound?'"—three
- "'Lo, I see four men loose, walking'"—four walking
- "'They have no hurt'"—no hurt
- "'The appearance of the fourth is like a son of the gods'"—divine figure
- "'Shadrach, Meshach, and Abed-nego, you servants of the Most High God'"—Most High
- "Came forth out of the midst of the fire"—came out
- "The fire had no power upon their bodies"—no power
- "Nor was the hair of their head singed"—not singed
- "Nor had the smell of fire passed on them"—no smell
- "'Blessed be the God of Shadrach, Meshach, and Abed-nego'"—blessed
- "'Who has sent his angel'"—angel
- "'Have yielded their bodies'"—yielded bodies
- "'That they might not serve nor worship any god, except their own God'"—exclusive loyalty
- "'There is no other god that is able to deliver after this sort'"—no other god
- "The king promoted Shadrach, Meshach, and Abed-nego"—promoted

**Modern Equivalent:** Daniel 3 tells of faithful resistance to idolatry. "But if not" (3:18) is key—they trust God but don't presume on deliverance. The "son of the gods" (3:25) has been interpreted as Christ, an angel, or a theophany. The story encourages faithfulness regardless of outcome. Notably, Daniel is absent from this story.

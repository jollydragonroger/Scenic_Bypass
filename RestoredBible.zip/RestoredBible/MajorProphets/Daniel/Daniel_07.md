# Daniel 7: The Vision of the Four Beasts and the Son of Man

*From the Aramaic: בִּשְׁנַת חֲדָה לְבֵלְשַׁאצַּר (Bi-Shnat Chadah Le-Belshatstsar) — In the First Year of Belshazzar*

---

## The Four Beasts (7:1-8)

**7:1** In the first year of Belshazzar king of Babylon Daniel had a dream and visions of his head upon his bed; then he wrote the dream and told the sum of the matters.

**7:2** Daniel spoke and said: "I saw in my vision by night, and, behold, the four winds of the heaven broke forth upon the great sea.

**7:3** "And four great beasts came up from the sea, diverse one from another.

**7:4** "The first was like a lion, and had eagle's wings; I beheld till the wings thereof were plucked, and it was lifted up from the earth, and made to stand upon two feet as a man, and a man's heart was given to it.

**7:5** "And behold another beast, a second, like to a bear, and it was raised up on one side, and it had three ribs in its mouth between its teeth; and they said thus unto it: 'Arise, devour much flesh.'

**7:6** "After this I beheld, and lo another, like a leopard, which had upon its back four wings of a fowl; the beast had also four heads; and dominion was given to it.

**7:7** "After this I saw in the night visions, and behold a fourth beast, dreadful and terrible, and strong exceedingly; and it had great iron teeth; it devoured and broke in pieces, and stamped the residue with its feet; and it was diverse from all the beasts that were before it; and it had ten horns.

**7:8** "I considered the horns, and, behold, there came up among them another horn, a little one, before which three of the first horns were plucked up by the roots; and, behold, in this horn were eyes like the eyes of a man, and a mouth speaking great things."

---

## The Ancient of Days (7:9-12)

**7:9** "I beheld till thrones were placed, and one that was ancient of days did sit; his raiment was as white snow, and the hair of his head like pure wool; his throne was fiery flames, and the wheels thereof burning fire.

**7:10** "A fiery stream issued and came forth from before him; thousand thousands ministered unto him, and ten thousand times ten thousand stood before him; the judgment was set, and the books were opened.

**7:11** "I beheld then because of the voice of the great words which the horn spoke, I beheld even till the beast was slain, and its body destroyed, and it was given to be burned with fire.

**7:12** "And as for the rest of the beasts, their dominion was taken away; yet their lives were prolonged for a season and a time."

---

## The Son of Man (7:13-14)

**7:13** "I saw in the night visions, and, behold, there came with the clouds of heaven one like a son of man, and he came even to the Ancient of days, and he was brought near before him.

**7:14** "And there was given him dominion, and glory, and a kingdom, that all the peoples, nations, and languages should serve him; his dominion is an everlasting dominion, which shall not pass away, and his kingdom that which shall not be destroyed."

---

## The Interpretation (7:15-28)

**7:15** As for me Daniel, my spirit was pained in the midst of my body, and the visions of my head affrighted me.

**7:16** I came near unto one of them that stood by, and asked him the truth concerning all this. So he told me, and made me know the interpretation of the things:

**7:17** "These great beasts, which are four, are four kings, that shall arise out of the earth.

**7:18** "But the saints of the Most High shall receive the kingdom, and possess the kingdom for ever, even for ever and ever."

**7:19** Then I desired to know the truth concerning the fourth beast, which was diverse from all of them, exceeding terrible, whose teeth were of iron, and its nails of brass; which devoured, brake in pieces, and stamped the residue with its feet;

**7:20** And concerning the ten horns that were on its head, and the other horn which came up, and before which three fell; even that horn that had eyes, and a mouth that spoke great things, whose appearance was greater than that of its fellows.

**7:21** I beheld, and the same horn made war with the saints, and prevailed against them;

**7:22** Until the Ancient of days came, and judgment was given for the saints of the Most High; and the time came, and the saints possessed the kingdom.

**7:23** Thus he said: "The fourth beast shall be a fourth kingdom upon earth, which shall be diverse from all the kingdoms, and shall devour the whole earth, and shall tread it down, and break it in pieces.

**7:24** "And as for the ten horns, out of this kingdom shall ten kings arise; and another shall arise after them; and he shall be diverse from the former, and he shall humble three kings.

**7:25** "And he shall speak words against the Most High, and shall wear out the saints of the Most High; and he shall think to change the times and the law; and they shall be given into his hand until a time and times and half a time.

**7:26** "But the judgment shall sit, and his dominion shall be taken away, to be consumed and to be destroyed unto the end.

**7:27** "And the kingdom and the dominion, and the greatness of the kingdoms under the whole heaven, shall be given to the people of the saints of the Most High; his kingdom is an everlasting kingdom, and all dominions shall serve and obey him."

**7:28** Here is the end of the matter. As for me Daniel, my thoughts much affrighted me, and my countenance was changed in me; but I kept the matter in my heart.

---

## Synthesis Notes

**Key Restorations:**

**Four Beasts (7:1-8):**
**The Key Verses (7:1-3):**
"In the first year of Belshazzar king of Babylon Daniel had a dream."

*Bi-shnat chadah le-Belshatstsar melekh Bavel Dani'el chelem chaza*—1st year of Belshazzar.

"Visions of his head upon his bed."

*Ve-chezвei re'sheh al-mishkeבeh*—visions on bed.

"Then he wrote the dream and told the sum of the matters."

*Edayin chelma ketav resh millin amar*—wrote dream.

"'I saw in my vision by night.'"

*Chazeh haveit be-chezvi im-leilya*—night vision.

"'The four winds of the heaven broke forth upon the great sea.'"

*Ve-arba ruchei shemaya megichain le-yamma rabba*—four winds, great sea.

"'Four great beasts came up from the sea.'"

*Ve-arba cheivan ravrevan salqan min-yamma*—four beasts.

"'Diverse one from another.'"

*Shonyan da min-da*—diverse.

**The Key Verses (7:4-6):**
"'The first was like a lion, and had eagle's wings.'"

*Qadmaיta ke-aryeh ve-gappin di-neshar lah*—lion, eagle's wings.

"'The wings thereof were plucked.'"

*Mterit gappaיh*—wings plucked.

"'It was lifted up from the earth, and made to stand upon two feet as a man.'"

*Ve-min-ar'a enilet ve-al-raglין ke-enash hoqimat*—stood like man.

"'A man's heart was given to it.'"

*U-levav enash yehiv lah*—man's heart.

"'Another beast, a second, like to a bear.'"

*Ve-alu cheivah ochori tinyanah domyah le-dov*—bear.

"'It was raised up on one side.'"

*Ve-li-setar chad hoqimat*—raised on side.

"'It had three ribs in its mouth between its teeth.'"

*U-telat al'in be-pummah bein shinnah*—three ribs.

"''Arise, devour much flesh.''"

*Qumi akhuli besar saggi*—devour flesh.

"'Another, like a leopard, which had upon its back four wings of a fowl.'"

*Ve-alu ochori ke-nemar ve-lah gappin arba di-of al-gavvaיh*—leopard, four wings.

"'The beast had also four heads.'"

*Ve-arba'ah reshin la-cheivta*—four heads.

"'Dominion was given to it.'"

*Ve-sholtan yehiv lah*—dominion given.

**The Key Verses (7:7-8):**
"'A fourth beast, dreadful and terrible, and strong exceedingly.'"

*Cheivah revi'a'ah dechilah ve-eimtanit ve-taqqifa yattirah*—fourth beast.

"'It had great iron teeth.'"

*Ve-shinnain di-farzel lah ravrevan*—iron teeth.

"'It devoured and broke in pieces, and stamped the residue with its feet.'"

*Akhla u-maddeqah u-she'ara be-raglaיh rafsa*—devoured, stamped.

"'It was diverse from all the beasts that were before it.'"

*U-meshonnah min-kol-cheivata di qodamaיh*—diverse.

"'It had ten horns.'"

*Ve-qarnין asar lah*—ten horns.

"'There came up among them another horn, a little one.'"

*Ve-alu qeren ochori ze'eيrah siلqat beinahon*—little horn.

"'Before which three of the first horns were plucked up by the roots.'"

*Ve-telat min-qarnaya qadmaיta etقru min-qodamaיh*—three uprooted.

"'In this horn were eyes like the eyes of a man.'"

*Ve-alu ainin ke-einei enasha be-qarna da*—human eyes.

"'A mouth speaking great things.'"

*U-fum memalel ravrevan*—speaking great things.

**Ancient of Days (7:9-12):**
**The Key Verses (7:9-10):**
"'I beheld till thrones were placed.'"

*Chazeh haveit ad di korsavan remיו*—thrones placed.

"'One that was ancient of days did sit.'"

*Ve-Attiq Yomin yetiv*—Ancient of Days.

"'His raiment was as white snow.'"

*Levusheh ke-telag chivar*—white raiment.

"'The hair of his head like pure wool.'"

*U-se'ar re'sheh ke-amar neqe*—white hair.

"'His throne was fiery flames.'"

*Korseh shevיvin di-nur*—fiery throne.

"'The wheels thereof burning fire.'"

*Galgilוhi nur daliq*—burning wheels.

"'A fiery stream issued and came forth from before him.'"

*Nehar di-nur naged ve-nafeq min-qodamohi*—fiery stream.

"'Thousand thousands ministered unto him.'"

*Elef alfין yeshamshuנneh*—thousand thousands.

"'Ten thousand times ten thousand stood before him.'"

*Ve-ribbo riבבan qodamohi yeqimun*—myriads.

"'The judgment was set.'"

*Dina yetiv*—judgment set.

"'The books were opened.'"

*Ve-sifrin petichu*—books opened.

**The Key Verses (7:11-12):**
"'I beheld... till the beast was slain.'"

*Chazeh haveit... ad di qetilet cheivta*—beast slain.

"'Its body destroyed, and it was given to be burned with fire.'"

*Ve-hovad gishmah vi-yhivat li-yeqedat esha*—burned.

"'The rest of the beasts, their dominion was taken away.'"

*U-she'ar cheivata he'edיו sholtanhon*—dominion taken.

"'Yet their lives were prolonged for a season and a time.'"

*Ve-arkha be-chaיyin yehibat lehon ad-zeman ve-iddan*—lives prolonged.

**Son of Man (7:13-14):**
**The Key Verse (7:13):**
"'I saw in the night visions.'"

*Chazeh haveit be-chezвei leilya*—night visions.

"'There came with the clouds of heaven one like a son of man.'"

*Ve-aru im-ananei shemaya ke-var enash ate hava*—Son of Man.

"'He came even to the Ancient of days.'"

*Ve-ad-Attiq Yomaya metah*—to Ancient of Days.

"'He was brought near before him.'"

*U-qodamohi haqrevuhi*—brought near.

**Bar Enash:**
"Son of man" (*bar enash*)—human figure, contrasting with beasts.

**The Key Verse (7:14):**
"'There was given him dominion, and glory, and a kingdom.'"

*Ve-leh yehiv sholtan vi-yqar u-malkhו*—dominion, glory, kingdom.

"'That all the peoples, nations, and languages should serve him.'"

*Ve-khol ammaya ummaya ve-lishnaya leh yiflchun*—all serve.

"'His dominion is an everlasting dominion, which shall not pass away.'"

*Sholtaneh sholtan alam di-la ye'edeh*—everlasting.

"'His kingdom that which shall not be destroyed.'"

*U-malkhuteh di-la titchabbאl*—not destroyed.

**Interpretation (7:15-28):**
**The Key Verses (7:17-18):**
"'These great beasts, which are four, are four kings, that shall arise out of the earth.'"

*Illein cheivata ravrevata di-innein arba arba'ah malkin yeqimun min-ar'a*—four kings.

"'But the saints of the Most High shall receive the kingdom.'"

*Vi-yqabbelun malkhuta qaddishei Elyo-nin*—saints receive.

"'Possess the kingdom for ever, even for ever and ever.'"

*Ve-yachsinun malkhuta ad-alma ve-ad alam alemaya*—forever.

**The Key Verses (7:21-22):**
"'The same horn made war with the saints, and prevailed against them.'"

*Qarna dikhen asah qerav im-qaddishin ve-yakhlah lehon*—war with saints.

"'Until the Ancient of days came.'"

*Ad di-ata Attiq Yomaya*—Ancient came.

"'Judgment was given for the saints of the Most High.'"

*Ve-dina yehiv le-qaddishei Elyonin*—judgment for saints.

"'The time came, and the saints possessed the kingdom.'"

*Ve-zimna metah u-malkhuta hachasinu qaddishin*—saints possess.

**The Key Verses (7:23-25):**
"'The fourth beast shall be a fourth kingdom upon earth.'"

*Cheivta revi'ayta malkhו revi'a'ah teheve be-ar'a*—fourth kingdom.

"'Which shall be diverse from all the kingdoms.'"

*Di tishne min-kol malkhevata*—diverse.

"'Shall devour the whole earth, and shall tread it down, and break it in pieces.'"

*Ve-tekhol kol-ar'a u-tedushinnah u-taddeqinnah*—devour earth.

"'The ten horns, out of this kingdom shall ten kings arise.'"

*Ve-qarnaya asar minnah malkhuta asrah malkin yeqimun*—ten kings.

"'Another shall arise after them... he shall humble three kings.'"

*Ve-ochoran yequm achareiהon... u-telatah malkin yehashpil*—humble three.

"'He shall speak words against the Most High.'"

*U-millin le-tzad Illא'a yemalil*—against Most High.

"'Shall wear out the saints of the Most High.'"

*U-le-qaddishei Elyonin yebaleh*—wear out saints.

"'He shall think to change the times and the law.'"

*Ve-yisbar le-hashnayah zimnin ve-dat*—change times, law.

"'They shall be given into his hand until a time and times and half a time.'"

*Ve-yitיhabun bi-yadeh ad-iddan ve-iddanin u-felag iddan*—time, times, half time.

**Time, Times, Half a Time:**
3½ years—period of tribulation.

**The Key Verses (7:26-27):**
"'The judgment shall sit, and his dominion shall be taken away.'"

*Ve-dina yitiv ve-sholtaneh yehaddun*—judgment sits.

"'To be consumed and to be destroyed unto the end.'"

*Le-hashmadah u-le-hovadah ad-sofa*—destroyed.

"'The kingdom and the dominion... shall be given to the people of the saints of the Most High.'"

*U-malkuta ve-sholtana... yehivat le-am qaddishei Elyonin*—given to saints.

"'His kingdom is an everlasting kingdom.'"

*Malkhuteh malkhut alam*—everlasting.

"'All dominions shall serve and obey him.'"

*Ve-khol sholtanaya leh yiflchun ve-yishtam'un*—all serve.

**The Key Verse (7:28):**
"Here is the end of the matter."

*Ad-kah sofa di-milta*—end of matter.

"My thoughts much affrighted me."

*Ana Dani'el saggi ra'yonai yevahhalunnani*—frightened.

"My countenance was changed in me."

*Ve-zivi yishtannun alai*—countenance changed.

"I kept the matter in my heart."

*U-milleta be-libbi netret*—kept in heart.

**Archetypal Layer:** Daniel 7 is the **apocalyptic centerpiece**, containing **four beasts from the sea (7:3)**: lion with eagle's wings (7:4), bear with three ribs (7:5), leopard with four wings and four heads (7:6), terrifying fourth beast with iron teeth and ten horns (7:7), **the little horn speaking great things (7:8)**, **the Ancient of Days on the fiery throne (7:9-10)**, **"the books were opened" (7:10)**, **"one like a son of man" coming with the clouds (7:13)**, **"his dominion is an everlasting dominion" (7:14)**, **"the saints of the Most High shall receive the kingdom" (7:18)**, **"he shall speak words against the Most High, and shall wear out the saints" (7:25)**, and **"a time and times and half a time" (7:25)**.

**Ethical Inversion Applied:**
- "In the first year of Belshazzar"—1st year
- "Daniel had a dream and visions"—dream, visions
- "He wrote the dream"—wrote
- "'The four winds of the heaven broke forth upon the great sea'"—four winds
- "'Four great beasts came up from the sea'"—four beasts
- "'Diverse one from another'"—diverse
- "'The first was like a lion, and had eagle's wings'"—lion
- "'The wings thereof were plucked'"—wings plucked
- "'Made to stand upon two feet as a man'"—humanized
- "'A man's heart was given to it'"—man's heart
- "'Another beast... like to a bear'"—bear
- "'It had three ribs in its mouth'"—three ribs
- "''Arise, devour much flesh''"—devour
- "'Another, like a leopard... four wings... four heads'"—leopard
- "'Dominion was given to it'"—dominion
- "'A fourth beast, dreadful and terrible'"—fourth beast
- "'It had great iron teeth'"—iron teeth
- "'It devoured and broke in pieces'"—devoured
- "'It had ten horns'"—ten horns
- "'Another horn, a little one'"—little horn
- "'Three of the first horns were plucked up'"—three uprooted
- "'Eyes like the eyes of a man'"—human eyes
- "'A mouth speaking great things'"—great things
- "'Thrones were placed'"—thrones
- "'One that was ancient of days did sit'"—Ancient of Days
- "'His raiment was as white snow'"—white
- "'The hair of his head like pure wool'"—white hair
- "'His throne was fiery flames'"—fiery throne
- "'A fiery stream issued... from before him'"—fiery stream
- "'Thousand thousands ministered unto him'"—thousands
- "'Ten thousand times ten thousand stood before him'"—myriads
- "'The judgment was set, and the books were opened'"—judgment
- "'The beast was slain'"—beast slain
- "'Its body destroyed... burned with fire'"—burned
- "'There came with the clouds of heaven one like a son of man'"—Son of Man
- "'He came even to the Ancient of days'"—to Ancient of Days
- "'There was given him dominion, and glory, and a kingdom'"—given dominion
- "'All the peoples, nations, and languages should serve him'"—all serve
- "'His dominion is an everlasting dominion'"—everlasting
- "'His kingdom that which shall not be destroyed'"—not destroyed
- "'These great beasts... are four kings'"—four kings
- "'The saints of the Most High shall receive the kingdom'"—saints receive
- "'Possess the kingdom for ever'"—forever
- "'The same horn made war with the saints'"—war with saints
- "'Until the Ancient of days came'"—Ancient came
- "'Judgment was given for the saints'"—judgment for saints
- "'The fourth beast shall be a fourth kingdom'"—fourth kingdom
- "'Shall devour the whole earth'"—devour earth
- "'Ten horns... ten kings'"—ten kings
- "'Another shall arise... diverse'"—another king
- "'He shall speak words against the Most High'"—against Most High
- "'Shall wear out the saints'"—wear out saints
- "'He shall think to change the times and the law'"—change times, law
- "'They shall be given into his hand until a time and times and half a time'"—3½ times
- "'The judgment shall sit'"—judgment
- "'His dominion shall be taken away'"—dominion taken
- "'The kingdom... shall be given to the people of the saints'"—saints receive
- "'All dominions shall serve and obey him'"—all serve
- "I kept the matter in my heart"—kept in heart

**Modern Equivalent:** Daniel 7 parallels chapter 2's four kingdoms but with beasts instead of metals. The "Son of Man" (7:13) became Jesus's self-designation. The "Ancient of Days" depicts God in judgment. "Time, times, and half a time" (3½ years) recurs in Revelation. The "little horn" likely represents Antiochus IV Epiphanes or an eschatological figure.

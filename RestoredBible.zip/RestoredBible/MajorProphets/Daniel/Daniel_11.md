# Daniel 11: The Kings of the North and South

*From the Hebrew: וַאֲנִי בִּשְׁנַת אַחַת לְדָרְיָוֶשׁ (Va-Ani Bi-Shnat Achat Le-Daryavesh) — And I in the First Year of Darius*

---

## From Persia to Greece (11:1-4)

**11:1** "And as for me, in the first year of Darius the Mede, I stood up to be a support and a stronghold unto him.

**11:2** "And now will I declare unto you the truth. Behold, there shall stand up yet three kings in Persia; and the fourth shall be far richer than they all; and when he is waxed strong through his riches, he shall stir up all against the realm of Greece.

**11:3** "And a mighty king shall stand up, that shall rule with great dominion, and do according to his will.

**11:4** "And when he shall stand up, his kingdom shall be broken, and shall be divided toward the four winds of heaven; but not to his posterity, nor according to his dominion wherewith he ruled; for his kingdom shall be plucked up, even for others beside those."

---

## The King of the South and the King of the North (11:5-20)

**11:5** "And the king of the south shall be strong, and one of his princes; and he shall be strong above him, and have dominion; his dominion shall be a great dominion.

**11:6** "And at the end of years they shall join themselves together; and the daughter of the king of the south shall come to the king of the north to make an agreement; but she shall not retain the strength of her arm; neither shall he stand, nor his arm; but she shall be given up, and they that brought her, and he that begot her, and he that obtained her in those times.

**11:7** "But out of a shoot from her roots shall one stand up in his place, who shall come unto the army, and shall enter into the stronghold of the king of the north, and shall deal against them, and shall prevail;

**11:8** "And also their gods, with their molten images, and with their precious vessels of silver and of gold, shall he carry captive into Egypt; and he shall desist some years from the king of the north.

**11:9** "And he shall come into the realm of the king of the south, but he shall return into his own land.

**11:10** "And his sons shall stir themselves up, and shall assemble a multitude of great forces, and he shall come on, and overflow, as he passes through; and he shall return and stir himself up, even to his stronghold.

**11:11** "And the king of the south shall be moved with choler, and shall come forth and fight with him, even with the king of the north; and he shall set forth a great multitude, and the multitude shall be given into his hand.

**11:12** "And the multitude shall be carried off, and his heart shall be lifted up; and he shall cast down tens of thousands; but he shall not prevail.

**11:13** "And the king of the north shall again set forth a multitude, greater than the former; and he shall come on at the end of the times, even of years, with a great army and with much substance.

**11:14** "And in those times there shall many stand up against the king of the south; also the children of the violent among your people shall lift themselves up to establish the vision; but they shall stumble.

**11:15** "And the king of the north shall come, and cast up a mound, and take a well-fortified city; and the arms of the south shall not withstand; and as for his chosen people, there shall be no strength in them to withstand.

**11:16** "But he that comes against him shall do according to his own will, and none shall stand before him; and he shall stand in the beauteous land, and in his hand shall be destruction.

**11:17** "And he shall set his face to come with the strength of his whole kingdom, and with him equitable conditions; and he shall perform them; and the daughter of women shall he give him, to corrupt her; but she shall not stand, neither be for him.

**11:18** "After this shall he turn his face unto the isles, and shall take many; but a commander shall cause the reproach offered by him to cease; yea, he shall cause his reproach to return upon him.

**11:19** "Then he shall turn his face toward the strongholds of his own land; but he shall stumble and fall, and shall not be found.

**11:20** "Then shall stand up in his place one that shall cause an exactor to pass through the glory of the kingdom; but within few days he shall be destroyed, neither in anger, nor in battle."

---

## The Contemptible Person (11:21-35)

**11:21** "And in his place shall stand up a contemptible person, upon whom had not been conferred the majesty of the kingdom; but he shall come in time of security, and shall obtain the kingdom by flatteries.

**11:22** "And the arms of the flood shall be swept away from before him, and shall be broken; yea, also the prince of the covenant.

**11:23** "And from the time that an league is made with him he shall work deceitfully; for he shall come up, and shall become strong, with a small people.

**11:24** "In time of security shall he come even upon the fattest places of the province; and he shall do that which his fathers have not done, nor his fathers' fathers: he shall scatter among them prey, and spoil, and substance; yea, he shall devise his devices against the strongholds, but only till a time.

**11:25** "And he shall stir up his power and his courage against the king of the south with a great army; and the king of the south shall stir himself up to battle with an exceeding great and mighty army; but he shall not stand, for they shall devise devices against him.

**11:26** "Yea, they that eat of his food shall destroy him, and his army shall overflow; and many shall fall down slain.

**11:27** "And as for both these kings, their hearts shall be to do mischief, and they shall speak lies at one table; but it shall not prosper; for the end is yet for the time appointed.

**11:28** "And he shall return to his land with great substance; and his heart shall be against the holy covenant; and he shall do his pleasure, and return to his own land.

**11:29** "At the time appointed he shall return, and come into the south; but it shall not be in the latter time as it was in the former.

**11:30** "For ships of Kittim shall come against him, and he shall be cowed, and he shall return, and have indignation against the holy covenant, and shall do his pleasure; and he shall return, and have regard unto them that forsake the holy covenant.

**11:31** "And arms shall stand on his part, and they shall profane the sanctuary, even the stronghold, and shall take away the continual burnt-offering, and they shall set up the detestable thing that causes appalment.

**11:32** "And such as do wickedly against the covenant shall he pervert by flatteries; but the people that know their God shall show strength, and do exploits.

**11:33** "And they that are wise among the people shall cause the many to understand; yet they shall stumble by sword and by flame, by captivity and by spoil, many days.

**11:34** "Now when they shall stumble, they shall be helped with a little help; but many shall join themselves unto them with flatteries.

**11:35** "And some of them that are wise shall stumble, to refine among them, and to purify, and to make white, even to the time of the end; for it is yet for the time appointed."

---

## The King Who Exalts Himself (11:36-45)

**11:36** "And the king shall do according to his will; and he shall exalt himself, and magnify himself above every god, and shall speak marvellous things against the God of gods; and he shall prosper till the indignation be accomplished; for that which is determined shall be done.

**11:37** "Neither shall he regard the gods of his fathers, nor the desire of women, nor regard any god; for he shall magnify himself above all.

**11:38** "But in his place shall he honour the god of strongholds; and a god whom his fathers knew not shall he honour with gold, and silver, and with precious stones, and costly things.

**11:39** "And he shall deal with the strongest fortresses with the help of a foreign god; whosoever acknowledges him he will increase with glory; and he shall cause them to rule over many, and shall divide the land for a price.

**11:40** "And at the time of the end shall the king of the south push at him; and the king of the north shall come against him like a whirlwind, with chariots, and with horsemen, and with many ships; and he shall enter into the countries, and shall overflow and pass through.

**11:41** "He shall enter also into the beauteous land, and many countries shall be overthrown; but these shall be delivered out of his hand, Edom, and Moab, and the chief of the children of Ammon.

**11:42** "He shall stretch forth his hand also upon the countries; and the land of Egypt shall not escape.

**11:43** "And he shall have power over the treasures of gold and of silver, and over all the precious things of Egypt; and the Libyans and the Ethiopians shall be at his steps.

**11:44** "But tidings out of the east and out of the north shall trouble him; and he shall go forth with great fury to destroy and utterly to take away many.

**11:45** "And he shall plant the tents of his palace between the seas and the beauteous holy mountain; yet he shall come to his end, and none shall help him."

---

## Synthesis Notes

**Key Restorations:**

**From Persia to Greece (11:1-4):**
**The Key Verses (11:2-4):**
"'There shall stand up yet three kings in Persia.'"

*Hinneh-od sheloshah melakhim omedim le-Faras*—3 Persian kings.

"'The fourth shall be far richer than they all.'"

*Ve-ha-revi'i ya'ashir osher gadol mi-kol*—4th richest.

"'He shall stir up all against the realm of Greece.'"

*Ve-khe-chezqato ve-oshro ya'ir ha-kol et malkhut Yavan*—stir against Greece.

**Fourth King:**
Xerxes I, who invaded Greece.

"'A mighty king shall stand up, that shall rule with great dominion.'"

*Ve-amad melekh gibbor u-mashal mimshal rav*—mighty king.

"'Do according to his will.'"

*Ve-asah ki-retzono*—his will.

**Mighty King:**
Alexander the Great.

"'When he shall stand up, his kingdom shall be broken.'"

*U-khe-omdo tishShaver malkhuto*—kingdom broken.

"'Divided toward the four winds of heaven.'"

*Ve-techatz le-arba ruchot ha-shamayim*—four winds.

"'Not to his posterity.'"

*Ve-lo le-acharito*—not his heirs.

**Four Divisions:**
Ptolemy (Egypt), Seleucus (Syria), Lysimachus (Thrace), Cassander (Macedonia).

**Kings of South and North (11:5-20):**
**The Key Verses (11:5-6):**
"'The king of the south shall be strong.'"

*Ve-yechezaq melekh ha-negev*—king of south.

"'One of his princes... shall be strong above him.'"

*U-min-sarav ve-yechezaq alav*—one of his princes.

**King of the South:**
Ptolemy I (Egypt).

"'The daughter of the king of the south shall come to the king of the north to make an agreement.'"

*Bat melekh ha-negev tavo el-melekh ha-tzafon la'asot meisharim*—daughter sent.

**Historical:**
Berenice, daughter of Ptolemy II, married Antiochus II.

**The Key Verses (11:10-16):**
"'His sons shall stir themselves up, and shall assemble a multitude of great forces.'"

*U-vanav yitgaru ve-asefu hamon chayalim rabbim*—sons gather forces.

"'The king of the south shall be moved with choler.'"

*Ve-yitmar melekh ha-negev*—king of south angry.

"'He that comes against him shall do according to his own will.'"

*Ve-ya'as ha-ba eilav ki-retzono*—his will.

"'He shall stand in the beauteous land.'"

*Ve-ya'amod be-eretz ha-tzevi*—beauteous land = Israel.

"'In his hand shall be destruction.'"

*Ve-khalah be-yado*—destruction.

**Antiochus III:**
Conquered Israel in 198 BCE.

**The Key Verses (11:17-20):**
"'The daughter of women shall he give him, to corrupt her.'"

*U-vat ha-nashim yitten lo le-hashchitah*—daughter given.

**Cleopatra I:**
Daughter of Antiochus III, given to Ptolemy V.

"'He shall turn his face unto the isles.'"

*Ve-yashem panav le-iyyim*—to isles.

"'A commander shall cause the reproach offered by him to cease.'"

*Ve-hishbit qatzin cherpatו lo*—commander stops him.

**Roman commander:**
Scipio Asiaticus defeated Antiochus III.

"'One that shall cause an exactor to pass through the glory of the kingdom.'"

*Ve-amad al-kanno ma'avir noges heder malkhut*—exactor.

**Seleucus IV:**
Sent Heliodorus to plunder temple treasury.

**Contemptible Person (11:21-35):**
**The Key Verse (11:21):**
"'In his place shall stand up a contemptible person.'"

*Ve-amad al-kanno nivzeh*—contemptible one.

"'Upon whom had not been conferred the majesty of the kingdom.'"

*Ve-lo-natnu alav hod malkhut*—not given kingship.

"'He shall obtain the kingdom by flatteries.'"

*U-va be-shalvah ve-hecheziq malkhut ba-chalaqlaqqot*—by flatteries.

**Antiochus IV Epiphanes:**
The "contemptible one" (175-164 BCE).

**The Key Verses (11:30-31):**
"'Ships of Kittim shall come against him.'"

*U-va'u vo tziyyim Kittim*—ships of Kittim.

**Kittim:**
Romans—Popilius Laenas forced Antiochus to leave Egypt.

"'He shall have indignation against the holy covenant.'"

*Ve-za'am al-berit-qodesh*—against holy covenant.

"'He shall return, and have regard unto them that forsake the holy covenant.'"

*Ve-shav ve-yaven al-ozevei berit qodesh*—regard apostates.

"'They shall profane the sanctuary, even the stronghold.'"

*Ve-chillelu ha-miqdash ha-ma'oz*—profane sanctuary.

"'Take away the continual burnt-offering.'"

*Ve-hesiru ha-tamid*—remove tamid.

"'They shall set up the detestable thing that causes appalment.'"

*Ve-natenu ha-shiqquz meshomem*—abomination of desolation.

**167 BCE:**
Antiochus desecrated the temple, set up Zeus altar.

**The Key Verses (11:32-35):**
"'Such as do wickedly against the covenant shall he pervert by flatteries.'"

*U-marshי'ei berit yachanif be-chalaqot*—pervert wicked.

"'The people that know their God shall show strength, and do exploits.'"

*Ve-am yode'ei Elohav yachazιqu ve-asu*—faithful act.

**Maccabees:**
The resistance movement.

"'They that are wise among the people shall cause the many to understand.'"

*U-maskilei am yavinu la-rabbim*—wise teach.

"'They shall stumble by sword and by flame, by captivity and by spoil, many days.'"

*Ve-nikhshelu be-cherev u-ve-lehavah bi-shevi u-ve-bizzah yamim*—persecution.

"'Some of them that are wise shall stumble, to refine among them, and to purify, and to make white.'"

*U-min-ha-maskilim yikkashelu li-tzerov bahem u-le-varer u-le-labben*—refine.

"'Even to the time of the end; for it is yet for the time appointed.'"

*Ad-et qetz ki-od la-mo'ed*—until end time.

**King Who Exalts Himself (11:36-45):**
**The Key Verses (11:36-37):**
"'The king shall do according to his will.'"

*Ve-asah ki-retzono ha-melekh*—his will.

"'He shall exalt himself, and magnify himself above every god.'"

*Ve-yitromem ve-yitgaddel al-kol-el*—above every god.

"'Shall speak marvellous things against the God of gods.'"

*Ve-al El elim yedabber nifla'ot*—against God of gods.

"'He shall prosper till the indignation be accomplished.'"

*Ve-hitzliach ad-kol za'am*—prosper until end.

"'Neither shall he regard the gods of his fathers.'"

*Ve-al-elohei avotav lo yavin*—disregard fathers' gods.

"'Nor the desire of women.'"

*Ve-al-chemdat nashim*—desire of women.

"'He shall magnify himself above all.'"

*Al-kol yitgaddal*—above all.

**The Key Verses (11:40-45):**
"'At the time of the end shall the king of the south push at him.'"

*U-ve-et qetz yitnaggeach immo melekh ha-negev*—end time.

"'The king of the north shall come against him like a whirlwind.'"

*Ve-yisto'er alav melekh ha-tzafon be-rekhev u-ve-farashim u-vo-oniyyot rabbот ke-sufa*—like whirlwind.

"'He shall enter also into the beauteous land.'"

*U-va be-eretz ha-tzevi*—enters Israel.

"'Many countries shall be overthrown.'"

*Ve-rabbot yikkashelu*—many fall.

"'Edom, and Moab, and the chief of the children of Ammon... shall be delivered.'"

*Edom u-Mo'av ve-reshit benei Ammon yimmaletu mi-yado*—escape.

"'The land of Egypt shall not escape.'"

*Ve-eretz Mitzrayim lo tihyeh li-feletah*—Egypt falls.

"'He shall plant the tents of his palace between the seas and the beauteous holy mountain.'"

*Ve-yita ohalei appadeno bein-yammim le-har-tzevi-qodesh*—between seas and holy mountain.

"'Yet he shall come to his end, and none shall help him.'"

*U-va ad-qitzo ve-ein ozer lo*—comes to end.

**Archetypal Layer:** Daniel 11 provides **detailed history from Persia through the Hellenistic period**, containing **three Persian kings + fourth (Xerxes) (11:2)**, **Alexander's rise and kingdom division (11:3-4)**, **Ptolemaic-Seleucid wars (11:5-20)**, **Antiochus IV Epiphanes as "contemptible person" (11:21)**, **"the detestable thing that causes appalment" (11:31)**, **"the people that know their God shall show strength" (11:32)**, **"they that are wise... shall cause the many to understand" (11:33)**, **persecution "to refine among them, and to purify" (11:35)**, **the king who "shall exalt himself, and magnify himself above every god" (11:36)**, and **"he shall come to his end, and none shall help him" (11:45)**.

**Ethical Inversion Applied:**
- "'Three kings in Persia... the fourth shall be far richer'"—Persian kings
- "'He shall stir up all against the realm of Greece'"—Persian-Greek conflict
- "'A mighty king shall stand up'"—Alexander
- "'His kingdom shall be broken... divided toward the four winds'"—divided
- "'Not to his posterity'"—not to heirs
- "'The king of the south shall be strong'"—Ptolemy
- "'The daughter of the king of the south shall come to the king of the north'"—marriage alliance
- "'She shall not retain the strength'"—fails
- "'He shall stand in the beauteous land'"—Israel
- "'The daughter of women shall he give him'"—Cleopatra
- "'A commander shall cause the reproach... to cease'"—Roman commander
- "'In his place shall stand up a contemptible person'"—Antiochus IV
- "'He shall obtain the kingdom by flatteries'"—by intrigue
- "'Ships of Kittim shall come against him'"—Romans
- "'He shall have indignation against the holy covenant'"—against covenant
- "'They shall profane the sanctuary'"—desecrate temple
- "'Take away the continual burnt-offering'"—remove tamid
- "'They shall set up the detestable thing that causes appalment'"—abomination
- "'The people that know their God shall show strength'"—faithful resist
- "'They that are wise... shall cause the many to understand'"—wise teach
- "'They shall stumble by sword and by flame'"—persecution
- "'To refine among them, and to purify'"—purification
- "'The king shall do according to his will'"—self-will
- "'He shall exalt himself... above every god'"—self-exaltation
- "'Shall speak marvellous things against the God of gods'"—blasphemy
- "'He shall prosper till the indignation be accomplished'"—prospers temporarily
- "'Neither shall he regard the gods of his fathers'"—godless
- "'He shall magnify himself above all'"—pride
- "'At the time of the end'"—end time
- "'He shall enter also into the beauteous land'"—invades Israel
- "'He shall plant the tents of his palace between the seas and the beauteous holy mountain'"—Jerusalem area
- "'He shall come to his end, and none shall help him'"—destroyed

**Modern Equivalent:** Daniel 11 reads like a history book—its accuracy regarding Ptolemaic-Seleucid conflicts is remarkable. The "contemptible person" (11:21) is Antiochus IV Epiphanes, whose desecration sparked the Maccabean revolt. Verses 36-45 may continue describing Antiochus or transition to an eschatological figure. "Abomination of desolation" (11:31) is quoted by Jesus in Mark 13:14.

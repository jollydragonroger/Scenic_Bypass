# Daniel 12: The Time of the End and the Resurrection

*From the Hebrew: וּבָעֵת הַהִיא יַעֲמֹד מִיכָאֵל (U-Va-Et Ha-Hi Ya'amod Mikha'el) — And at That Time Shall Michael Stand Up*

---

## The Great Tribulation and Resurrection (12:1-4)

**12:1** "And at that time shall Michael stand up, the great prince who stands for the children of your people; and there shall be a time of trouble, such as never was since there was a nation even to that same time; and at that time your people shall be delivered, every one that shall be found written in the book.

**12:2** "And many of them that sleep in the dust of the earth shall awake, some to everlasting life, and some to reproaches and everlasting abhorrence.

**12:3** "And they that are wise shall shine as the brightness of the firmament; and they that turn the many to righteousness as the stars for ever and ever.

**12:4** "But you, O Daniel, shut up the words, and seal the book, even to the time of the end; many shall run to and fro, and knowledge shall be increased."

---

## How Long? (12:5-13)

**12:5** Then I Daniel looked, and, behold, there stood other two, the one on the bank of the river on this side, and the other on the bank of the river on that side.

**12:6** And one said to the man clothed in linen, who was above the waters of the river: "How long shall it be to the end of these wonders?"

**12:7** And I heard the man clothed in linen, who was above the waters of the river, when he lifted up his right hand and his left hand unto heaven, and swore by him that lives for ever that it shall be for a time, times, and a half; and when they have made an end of breaking in pieces the power of the holy people, all these things shall be finished.

**12:8** And I heard, but I understood not; then said I: "O my lord, what shall be the issue of these things?"

**12:9** And he said: "Go your way, Daniel; for the words are shut up and sealed till the time of the end.

**12:10** "Many shall purify themselves, and make themselves white, and be refined; but the wicked shall do wickedly; and none of the wicked shall understand; but they that are wise shall understand.

**12:11** "And from the time that the continual burnt-offering shall be taken away, and the detestable thing that causes appalment set up, there shall be a thousand two hundred and ninety days.

**12:12** "Happy is he that waits, and comes to the thousand three hundred and five and thirty days.

**12:13** "But go you your way till the end be; and you shall rest, and shall stand up to your lot, at the end of the days."

---

## Synthesis Notes

**Key Restorations:**

**Great Tribulation and Resurrection (12:1-4):**
**The Key Verse (12:1):**
"'At that time shall Michael stand up.'"

*U-va-et ha-hi ya'amod Mikha'el*—Michael stands.

"'The great prince who stands for the children of your people.'"

*Ha-sar ha-gadol ha-omed al-benei ammekha*—great prince for your people.

"'There shall be a time of trouble, such as never was since there was a nation even to that same time.'"

*Ve-hayetah et tzarah asher lo-nihyetah mi-heyot goy ad ha-et ha-hi*—unprecedented trouble.

"'At that time your people shall be delivered.'"

*U-va-et ha-hi yimmaleit ammekha*—people delivered.

"'Every one that shall be found written in the book.'"

*Kol-ha-nimtza katuv ba-sefer*—written in book.

**The Key Verse (12:2):**
"'Many of them that sleep in the dust of the earth shall awake.'"

*Ve-rabbim mi-yeshenei admat-afar yaqitzu*—sleepers awake.

"'Some to everlasting life.'"

*Elleh le-chayyei olam*—everlasting life.

"'Some to reproaches and everlasting abhorrence.'"

*Ve-elleh la-charafot le-dir'on olam*—everlasting abhorrence.

**Resurrection:**
The clearest Old Testament statement of bodily resurrection.

**The Key Verse (12:3):**
"'They that are wise shall shine as the brightness of the firmament.'"

*Ve-ha-maskilim yazhiru ke-zohar ha-raqia*—shine like firmament.

"'They that turn the many to righteousness as the stars for ever and ever.'"

*U-matzdiqei ha-rabbim ka-kokhavim le-olam va-ed*—like stars forever.

**Ha-Maskilim:**
"The wise"—those who teach and lead.

**The Key Verse (12:4):**
"'Shut up the words, and seal the book, even to the time of the end.'"

*Setom ha-devarim va-chatom ha-sefer ad-et qetz*—seal until end.

"'Many shall run to and fro.'"

*Yeshotetu rabbim*—run to and fro.

"'Knowledge shall be increased.'"

*Ve-tirbeh ha-da'at*—knowledge increased.

**How Long? (12:5-13):**
**The Key Verses (12:5-7):**
"There stood other two, the one on the bank of the river on this side, and the other on the bank of the river on that side."

*Ve-hinneh shenayim acherim omedim echad hennah li-sefat ha-ye'or ve-echad hennah li-sefat ha-ye'or*—two on banks.

"One said to the man clothed in linen, who was above the waters of the river."

*Va-yomer la-ish levush ha-baddim asher mi-ma'al le-mei ha-ye'or*—to linen-clothed man.

"'How long shall it be to the end of these wonders?'"

*Ad-matai qetz ha-pela'ot*—how long?

"The man clothed in linen... lifted up his right hand and his left hand unto heaven."

*Va-yarem yemino u-semolo el-ha-shamayim*—raised both hands.

"Swore by him that lives for ever."

*Va-yishShava be-chai ha-olam*—swore by eternal.

"'It shall be for a time, times, and a half.'"

*Ki le-mo'ed mo'adim va-chetzi*—time, times, half.

**Time, Times, and a Half:**
3½ years—the period of tribulation (cf. 7:25).

"'When they have made an end of breaking in pieces the power of the holy people, all these things shall be finished.'"

*U-khe-khallot nappetz yad-am qodesh tikleyנah khol-elleh*—when holy people's power broken.

**The Key Verses (12:8-10):**
"I heard, but I understood not."

*Va-ani shamaתi ve-lo avin*—didn't understand.

"'O my lord, what shall be the issue of these things?'"

*Adoni mah acharit elleh*—what outcome?

"'Go your way, Daniel; for the words are shut up and sealed till the time of the end.'"

*Lekh Dani'el ki-setumim va-chatumim ha-devarim ad-et qetz*—go, sealed until end.

"'Many shall purify themselves, and make themselves white, and be refined.'"

*Yitbareru ve-yitlabbenu ve-yitzarefu rabbim*—purified, whitened, refined.

"'The wicked shall do wickedly.'"

*Ve-hirshi'u resha'im*—wicked continue.

"'None of the wicked shall understand.'"

*Ve-lo yavinu kol-resha'im*—wicked don't understand.

"'They that are wise shall understand.'"

*Ve-ha-maskilim yavinu*—wise understand.

**The Key Verses (12:11-12):**
"'From the time that the continual burnt-offering shall be taken away.'"

*U-me-et husar ha-tamid*—tamid removed.

"'And the detestable thing that causes appalment set up.'"

*Ve-latet shiqquz shomem*—abomination set up.

"'There shall be a thousand two hundred and ninety days.'"

*Yamim elef matayim ve-tish'im*—1,290 days.

"'Happy is he that waits, and comes to the thousand three hundred and five and thirty days.'"

*Ashrei ha-mechakkeh ve-yaggia le-yamim elef shelosh me'ot sheloshim ve-chamishah*—1,335 days.

**1,290 and 1,335 Days:**
Slightly different from 1,260 days (3½ years)—extensions of tribulation or transition periods.

**The Key Verse (12:13):**
"'Go you your way till the end be.'"

*Ve-attah lekh la-qetz*—go to end.

"'You shall rest.'"

*Ve-tanuach*—rest (die).

"'And shall stand up to your lot, at the end of the days.'"

*Ve-ta'amod le-goralekha le-qetz ha-yamim*—stand to your lot at end.

**Daniel's Destiny:**
Daniel will die ("rest") and be resurrected ("stand up to your lot").

**Archetypal Layer:** Daniel 12 concludes the book with **eschatological climax**, containing **"at that time shall Michael stand up" (12:1)**, **"a time of trouble, such as never was since there was a nation" (12:1)**, **"your people shall be delivered, every one that shall be found written in the book" (12:1)**, **"many of them that sleep in the dust of the earth shall awake" (12:2)**—the Old Testament's clearest resurrection statement, **"some to everlasting life, and some to reproaches and everlasting abhorrence" (12:2)**, **"they that are wise shall shine as the brightness of the firmament" (12:3)**, **"seal the book, even to the time of the end" (12:4)**, **"a time, times, and a half" (12:7)**, **"from the time that the continual burnt-offering shall be taken away... 1,290 days" (12:11)**, **"happy is he that waits, and comes to the 1,335 days" (12:12)**, and **"you shall rest, and shall stand up to your lot, at the end of the days" (12:13)**.

**Ethical Inversion Applied:**
- "'At that time shall Michael stand up'"—Michael stands
- "'The great prince who stands for the children of your people'"—for your people
- "'There shall be a time of trouble, such as never was'"—unprecedented
- "'At that time your people shall be delivered'"—delivered
- "'Every one that shall be found written in the book'"—written in book
- "'Many of them that sleep in the dust of the earth shall awake'"—resurrection
- "'Some to everlasting life'"—everlasting life
- "'Some to reproaches and everlasting abhorrence'"—everlasting judgment
- "'They that are wise shall shine as the brightness of the firmament'"—shine
- "'They that turn the many to righteousness as the stars'"—like stars
- "'Shut up the words, and seal the book'"—seal
- "'Even to the time of the end'"—until end
- "'Many shall run to and fro'"—search
- "'Knowledge shall be increased'"—knowledge
- "There stood other two"—two angels
- "'How long shall it be to the end of these wonders?'"—how long
- "He lifted up his right hand and his left hand unto heaven"—oath
- "Swore by him that lives for ever"—swore
- "'It shall be for a time, times, and a half'"—3½ times
- "'When they have made an end of breaking in pieces the power of the holy people'"—power broken
- "'All these things shall be finished'"—finished
- "I heard, but I understood not"—didn't understand
- "'What shall be the issue of these things?'"—what outcome
- "'Go your way, Daniel'"—go
- "'The words are shut up and sealed till the time of the end'"—sealed
- "'Many shall purify themselves, and make themselves white, and be refined'"—purified
- "'The wicked shall do wickedly'"—wicked continue
- "'None of the wicked shall understand'"—don't understand
- "'They that are wise shall understand'"—wise understand
- "'From the time that the continual burnt-offering shall be taken away'"—tamid removed
- "'The detestable thing that causes appalment set up'"—abomination
- "'There shall be a thousand two hundred and ninety days'"—1,290 days
- "'Happy is he that waits, and comes to the thousand three hundred and five and thirty days'"—1,335 days
- "'Go you your way till the end be'"—go to end
- "'You shall rest'"—rest (die)
- "'Shall stand up to your lot, at the end of the days'"—resurrection

**Modern Equivalent:** Daniel 12 provides the Old Testament's clearest resurrection doctrine—"many of them that sleep... shall awake, some to everlasting life" (12:2). The "time of trouble" (12:1) parallels Jesus's "great tribulation" (Matthew 24:21). "They that are wise shall shine" (12:3) is quoted in Matthew 13:43. Daniel is promised personal resurrection: "you shall stand up to your lot, at the end of the days" (12:13).

# Daniel 2: Nebuchadnezzar's Dream of the Statue

*From the Hebrew/Aramaic: וּבִשְׁנַת שְׁתַּיִם לְמַלְכוּת נְבוּכַדְנֶצַּר (U-Vi-Shnat Shtayim Le-Malkhut Nevukhadnetstsar) — And in the Second Year of the Reign of Nebuchadnezzar*

---

## The King's Demand (2:1-13)

**2:1** And in the second year of the reign of Nebuchadnezzar, Nebuchadnezzar dreamed dreams; and his spirit was troubled, and his sleep broke from him.

**2:2** Then the king commanded to call the magicians, and the enchanters, and the sorcerers, and the Chaldeans, to tell the king his dreams. So they came and stood before the king.

**2:3** And the king said unto them: "I have dreamed a dream, and my spirit is troubled to know the dream."

**2:4** Then spoke the Chaldeans to the king in Aramaic: "O king, live for ever! Tell your servants the dream, and we will declare the interpretation."

**2:5** The king answered and said to the Chaldeans: "The thing is gone from me; if you make not known unto me the dream and the interpretation thereof, you shall be cut in pieces, and your houses shall be made a dunghill.

**2:6** "But if you declare the dream and the interpretation thereof, you shall receive of me gifts and rewards and great honour; therefore declare unto me the dream and the interpretation thereof."

**2:7** They answered the second time and said: "Let the king tell his servants the dream, and we will declare the interpretation."

**2:8** The king answered and said: "I know of a certainty that you would gain time, because you see the thing is gone from me.

**2:9** "But if you make not known unto me the dream, there is but one law for you; and you have prepared lying and corrupt words to speak before me, till the time be changed; therefore tell me the dream, and I shall know that you can declare unto me the interpretation thereof."

**2:10** The Chaldeans answered before the king, and said: "There is not a man upon the earth that can declare the king's matter; forasmuch as no king, lord, or ruler, has asked such a thing of any magician, or enchanter, or Chaldean.

**2:11** "And it is a hard thing that the king requires, and there is none other that can declare it before the king, except the gods, whose dwelling is not with flesh."

**2:12** For this cause the king was angry and very furious, and commanded to destroy all the wise men of Babylon.

**2:13** So the decree went forth, and the wise men were about to be slain; and they sought Daniel and his companions to be slain.

---

## Daniel Seeks Revelation (2:14-23)

**2:14** Then Daniel returned answer with counsel and discretion to Arioch the captain of the king's guard, who was gone forth to slay the wise men of Babylon;

**2:15** He answered and said to Arioch the king's captain: "Wherefore is the decree so peremptory from the king?" Then Arioch made the thing known to Daniel.

**2:16** And Daniel went in, and desired of the king that he would give him time, that he might declare unto the king the interpretation.

**2:17** Then Daniel went to his house, and made the thing known to Hananiah, Mishael, and Azariah, his companions;

**2:18** That they might ask mercy of the God of heaven concerning this secret; that Daniel and his companions should not perish with the rest of the wise men of Babylon.

**2:19** Then was the secret revealed unto Daniel in a vision of the night. Then Daniel blessed the God of heaven.

**2:20** Daniel spoke and said: "Blessed be the name of God for ever and ever; for wisdom and might are his;

**2:21** "And he changes the times and the seasons; he removes kings, and sets up kings; he gives wisdom unto the wise, and knowledge to them that know understanding;

**2:22** "He reveals the deep and secret things; he knows what is in the darkness, and the light dwells with him.

**2:23** "I thank you, and praise you, O you God of my fathers, who have given me wisdom and might, and have now made known unto me what we desired of you; for you have made known unto us the king's matter."

---

## Daniel Before the King (2:24-30)

**2:24** Therefore Daniel went in unto Arioch, whom the king had appointed to destroy the wise men of Babylon; he went and said thus unto him: "Destroy not the wise men of Babylon; bring me in before the king, and I will declare unto the king the interpretation."

**2:25** Then Arioch brought in Daniel before the king in haste, and said thus unto him: "I have found a man of the children of the captivity of Judah, that will make known unto the king the interpretation."

**2:26** The king answered and said to Daniel, whose name was Belteshazzar: "Are you able to make known unto me the dream which I have seen, and the interpretation thereof?"

**2:27** Daniel answered before the king, and said: "The secret which the king has demanded can neither wise men, enchanters, magicians, nor astrologers, declare unto the king;

**2:28** "But there is a God in heaven that reveals secrets, and he has made known to the king Nebuchadnezzar what shall be in the end of days. Your dream, and the visions of your head upon your bed, are these:

**2:29** "As for you, O king, your thoughts came into your mind upon your bed, what should come to pass hereafter; and he that reveals secrets has made known to you what shall come to pass.

**2:30** "But as for me, this secret is not revealed to me for any wisdom that I have more than any living, but to the intent that the interpretation may be made known to the king, and that you may know the thoughts of your heart."

---

## The Dream Revealed (2:31-35)

**2:31** "You, O king, saw, and behold a great image. This image, which was mighty, and whose brightness was surpassing, stood before you; and the appearance thereof was terrible.

**2:32** "As for that image, its head was of fine gold, its breast and its arms of silver, its belly and its thighs of brass,

**2:33** "Its legs of iron, its feet part of iron and part of clay.

**2:34** "You saw till that a stone was cut out without hands, which smote the image upon its feet that were of iron and clay, and broke them in pieces.

**2:35** "Then was the iron, the clay, the brass, the silver, and the gold, broken in pieces together, and became like the chaff of the summer threshing-floors; and the wind carried them away, so that no place was found for them; and the stone that smote the image became a great mountain, and filled the whole earth."

---

## The Interpretation (2:36-45)

**2:36** "This is the dream; and we will tell the interpretation thereof before the king.

**2:37** "You, O king, are a king of kings, unto whom the God of heaven has given the kingdom, the power, and the strength, and the glory;

**2:38** "And wheresoever the children of men dwell, the beasts of the field and the fowls of the heaven has he given into your hand, and has made you ruler over them all: you are the head of gold.

**2:39** "And after you shall arise another kingdom inferior to you; and another third kingdom of brass, which shall bear rule over all the earth.

**2:40** "And the fourth kingdom shall be strong as iron; forasmuch as iron breaks in pieces and subdues all things; and as iron that crushes all these, shall it break in pieces and crush.

**2:41** "And whereas you saw the feet and toes, part of potters' clay, and part of iron, it shall be a divided kingdom; but there shall be in it of the firmness of the iron, forasmuch as you saw the iron mixed with miry clay.

**2:42** "And as the toes of the feet were part of iron, and part of clay, so part of the kingdom shall be strong, and part thereof broken.

**2:43** "And whereas you saw the iron mixed with miry clay, they shall mingle themselves with the seed of men; but they shall not cleave one to another, even as iron does not mingle with clay.

**2:44** "And in the days of those kings shall the God of heaven set up a kingdom, which shall never be destroyed; nor shall the kingdom be left to another people; it shall break in pieces and consume all these kingdoms, and it shall stand for ever.

**2:45** "Forasmuch as you saw that a stone was cut out of the mountain without hands, and that it broke in pieces the iron, the brass, the clay, the silver, and the gold; the great God has made known to the king what shall come to pass hereafter; and the dream is certain, and the interpretation thereof sure."

---

## Daniel's Promotion (2:46-49)

**2:46** Then the king Nebuchadnezzar fell upon his face, and worshipped Daniel, and commanded that they should offer an offering and sweet odours unto him.

**2:47** The king answered unto Daniel, and said: "Of a truth your God is the God of gods, and the Lord of kings, and a revealer of secrets, seeing you have been able to reveal this secret."

**2:48** Then the king made Daniel great, and gave him many great gifts, and made him ruler over the whole province of Babylon, and chief prefect over all the wise men of Babylon.

**2:49** And Daniel requested of the king, and he appointed Shadrach, Meshach, and Abed-nego, over the affairs of the province of Babylon; but Daniel was in the gate of the king.

---

## Synthesis Notes

**Key Restorations:**

**King's Demand (2:1-13):**
**The Key Verse (2:1):**
"In the second year of the reign of Nebuchadnezzar."

*U-vi-shnat shtayim le-malkhut Nevukhadnetstsar*—2nd year.

"Nebuchadnezzar dreamed dreams."

*Chalam Nevukhadnetstsar chalomot*—dreamed.

"His spirit was troubled."

*Va-titpa'em rucho*—troubled spirit.

"His sleep broke from him."

*U-shenato nihyetah alav*—sleep gone.

**The Key Verses (2:2-6):**
"The king commanded to call the magicians, and the enchanters, and the sorcerers, and the Chaldeans."

*Va-yomer ha-melekh liqro la-chartummim ve-la-ashshafim ve-la-mekhashefim ve-la-Kasdim*—wise men.

"'Tell your servants the dream, and we will declare the interpretation.'"

*Emor ha-chalom la-avadekha u-fishra nachave*—tell dream.

"'The thing is gone from me.'"

*Milta minni azda*—forgotten (Aramaic).

"'If you make not known unto me the dream and the interpretation, you shall be cut in pieces.'"

*Hen la tehodunanni chalma u-fishrei haddamin titabedun*—cut in pieces.

"'Your houses shall be made a dunghill.'"

*U-vateikhem nevali yitsamu*—dunghill.

**The Key Verses (2:10-13):**
"'There is not a man upon the earth that can declare the king's matter.'"

*La itai enash al-yabbeshta di milat malka yukhal le-hachavayah*—no one can.

"'No king, lord, or ruler, has asked such a thing.'"

*Kol-qevel di kol-melekh rav ve-shallit milla ke-denah la she'il*—unprecedented.

"'It is a hard thing that the king requires.'"

*U-milta di-malka she'il yaqqirah*—hard thing.

"'There is none other that can declare it before the king, except the gods.'"

*Ve-ochoran la itai di yechavvinnah qodam malka lahen elahin*—only gods.

"'Whose dwelling is not with flesh.'"

*Di medarhon im-bisra la itai*—gods don't dwell with flesh.

"The king was angry and very furious."

*Kol-qevel denah malka benaz u-qetzaf saggi*—furious.

"Commanded to destroy all the wise men of Babylon."

*Va-amar le-hovadah le-khol chakimei Bavel*—destroy wise men.

**Daniel Seeks Revelation (2:14-23):**
**The Key Verses (2:17-19):**
"Daniel went to his house, and made the thing known to Hananiah, Mishael, and Azariah."

*Edayin Dani'el le-vaiteh azal u-la-Chananyah Misha'el va-Azaryah chavrohi milla hoda*—told companions.

"That they might ask mercy of the God of heaven concerning this secret."

*Ve-rachamim le-miv'a min-qodam Elah shemaया על-raza denah*—ask mercy.

"Then was the secret revealed unto Daniel in a vision of the night."

*Edayin le-Dani'el be-chezev leilya raza gelי*—secret revealed.

"Daniel blessed the God of heaven."

*Edayin Dani'el barekh le-Elah shemaya*—blessed God.

**Daniel's Hymn (2:20-23):**
"'Blessed be the name of God for ever and ever.'"

*Leheve shmeh di-Elaha mevarakh min-alma ve-ad-alma*—blessed forever.

"'Wisdom and might are his.'"

*Di chokhmeta u-gevuretah di-leh hi*—wisdom, might.

"'He changes the times and the seasons.'"

*Ve-hu meshaneh iddanaya ve-zimnaya*—changes times.

"'He removes kings, and sets up kings.'"

*Mehade malkin u-mehakim malkin*—removes, sets kings.

"'He gives wisdom unto the wise.'"

*Yahev chokhmeta le-chakkimin*—gives wisdom.

"'He reveals the deep and secret things.'"

*Galeh amiqata u-mestarta*—reveals deep things.

"'He knows what is in the darkness.'"

*Yada mah be-chashokha*—knows darkness.

"'The light dwells with him.'"

*U-nehora immeh shera*—light dwells.

**Daniel Before the King (2:24-30):**
"'There is a God in heaven that reveals secrets.'"

*Berem itai Elah bi-shemaya galeh razin*—God reveals.

"'He has made known to the king Nebuchadnezzar what shall be in the end of days.'"

*Ve-hoda le-malka Nevukhadnetstsar mah di leheve be-acharit yomaya*—end of days.

"'This secret is not revealed to me for any wisdom that I have more than any living.'"

*Ve-anah la ve-chokhmah di-itai bi min-kol-chayyaya raza denah gelי li*—not my wisdom.

"'But to the intent that the interpretation may be made known to the king.'"

*Lahen al-divrat di fishra le-malka yehodun*—for interpretation.

**The Dream Revealed (2:31-35):**
"'You, O king, saw, and behold a great image.'"

*Ant malka chazeh haveit va-alu tzelem chad saggi*—great image.

"'This image, which was mighty, and whose brightness was surpassing.'"

*Tzalma dekhen rav ve-ziveh yattir*—mighty, bright.

"'Its head was of fine gold.'"

*Re'sheh di-dehav tav*—head of gold.

"'Its breast and its arms of silver.'"

*Chadohi u-dra'ohi di-khasaf*—breast, arms of silver.

"'Its belly and its thighs of brass.'"

*Me'ohi ve-yarkohi di-nechash*—belly, thighs of bronze.

"'Its legs of iron.'"

*Shaqohi di-farzel*—legs of iron.

"'Its feet part of iron and part of clay.'"

*Raglohi minhen di-farzel u-minhen di-chasaf*—feet iron/clay.

"'A stone was cut out without hands.'"

*Even etgezeret di-la vi-ydin*—stone without hands.

"'Which smote the image upon its feet... and broke them in pieces.'"

*U-mechאt le-tzalma al-raglohi... ve-haddeqet himmown*—smote feet.

"'The stone that smote the image became a great mountain, and filled the whole earth.'"

*Ve-avna di-mechat le-tzalma havat le-tur rav u-mלאat kol-ar'a*—filled earth.

**The Interpretation (2:36-45):**
"'You, O king, are a king of kings.'"

*Ant malka melekh malkaya*—king of kings.

"'The God of heaven has given the kingdom, the power, and the strength, and the glory.'"

*Di Elah shemaya malkuta chisna u-tקofa vi-yqar yehav lakh*—God gave.

"'You are the head of gold.'"

*Ant-hu re'sha di-dahava*—head of gold.

"'After you shall arise another kingdom inferior to you.'"

*U-vatrak tequm malku ochra ara minnakh*—inferior kingdom.

"'Another third kingdom of brass.'"

*U-malku telita'ah ochra di-nechasha*—third kingdom.

"'Which shall bear rule over all the earth.'"

*Di tishlat be-khol ar'a*—rule all earth.

"'The fourth kingdom shall be strong as iron.'"

*U-malkhuta revi'a'ah teheve taqqifa ke-farzela*—fourth, iron.

"'As iron breaks in pieces and subdues all things.'"

*Kol-qevel di farzela medaqqeq ve-chashel kolla*—iron breaks.

"'The feet and toes, part of potters' clay, and part of iron, it shall be a divided kingdom.'"

*U-di chazait raglaiya ve-etzba'ata minhen chasaf di-phachar u-minhen parzel malku peliga teheve*—divided.

"'In the days of those kings shall the God of heaven set up a kingdom.'"

*U-ve-yomeiהon di malkaiya innun yeqim Elah shemaya malku*—God sets up kingdom.

"'Which shall never be destroyed.'"

*Di le-almin la titchabbal*—never destroyed.

"'Nor shall the kingdom be left to another people.'"

*U-malkhutah le-am ochran la tishtbeq*—not given to another.

"'It shall break in pieces and consume all these kingdoms.'"

*Taddiq ve-tasef kol-ellein malkhevata*—breaks all.

"'It shall stand for ever.'"

*Ve-hi teqيm le-alemaya*—stand forever.

"'A stone was cut out of the mountain without hands.'"

*Even etgezeret min-tura di-la bi-ydin*—from mountain.

**Daniel's Promotion (2:46-49):**
"The king Nebuchadnezzar fell upon his face, and worshipped Daniel."

*Edayin malka Nevukhadnetstsar neפal al-anpohi u-le-Dani'el segid*—fell, worshipped.

"'Your God is the God of gods, and the Lord of kings.'"

*Min-qeshat di Elahakhon hu Elah elahin u-mare malkin*—God of gods.

"'A revealer of secrets.'"

*Ve-galeh razin*—revealer.

"The king made Daniel great, and gave him many great gifts."

*Edayin malka le-Dani'el rabbי u-matnan ravrevan saggi'in yehav leh*—promoted.

"Made him ruler over the whole province of Babylon."

*Ve-hashleteh al kol-medinat Bavel*—ruler of Babylon.

"Chief prefect over all the wise men of Babylon."

*Ve-rav-signin al kol-chakimei Bavel*—chief of wise men.

"Daniel requested of the king, and he appointed Shadrach, Meshach, and Abed-nego, over the affairs of the province."

*U-Dani'el be'a min-malka u-minni al-avidta di medinat Bavel le-Shadrakh Meishakh va-Aved Nego*—appointed friends.

"Daniel was in the gate of the king."

*Ve-Dani'el be-tera malka*—at king's gate.

**Archetypal Layer:** Daniel 2 contains **Nebuchadnezzar's forgotten dream (2:1-13)**, **Daniel's prayer and revelation (2:14-23)**, **"He changes the times and the seasons; he removes kings, and sets up kings" (2:21)**, **"There is a God in heaven that reveals secrets" (2:28)**, **the four-metal statue: gold (Babylon), silver, bronze, iron/clay (2:31-33)**, **"a stone was cut out without hands" (2:34)**, **"in the days of those kings shall the God of heaven set up a kingdom, which shall never be destroyed" (2:44)**, and **Daniel's promotion (2:48-49)**.

**Ethical Inversion Applied:**
- "In the second year of the reign of Nebuchadnezzar"—2nd year
- "Nebuchadnezzar dreamed dreams"—dreamed
- "His spirit was troubled"—troubled
- "The king commanded to call the magicians"—wise men
- "'Tell your servants the dream'"—demand
- "'The thing is gone from me'"—forgotten
- "'You shall be cut in pieces'"—threat
- "'There is not a man upon the earth that can declare the king's matter'"—impossible
- "'Except the gods, whose dwelling is not with flesh'"—only gods
- "The king was angry and very furious"—furious
- "Commanded to destroy all the wise men"—death decree
- "Daniel returned answer with counsel and discretion"—wise response
- "Daniel went to his house, and made the thing known"—to companions
- "That they might ask mercy of the God of heaven"—ask mercy
- "The secret revealed unto Daniel in a vision of the night"—vision
- "Daniel blessed the God of heaven"—blessed God
- "'Blessed be the name of God for ever and ever'"—praise
- "'Wisdom and might are his'"—wisdom, might
- "'He changes the times and the seasons'"—changes times
- "'He removes kings, and sets up kings'"—removes, sets kings
- "'He reveals the deep and secret things'"—reveals secrets
- "'The light dwells with him'"—light
- "'There is a God in heaven that reveals secrets'"—God reveals
- "'What shall be in the end of days'"—end of days
- "'This secret is not revealed to me for any wisdom that I have'"—not my wisdom
- "'You, O king, saw... a great image'"—great image
- "'Its head was of fine gold'"—gold head
- "'Its breast and its arms of silver'"—silver
- "'Its belly and its thighs of brass'"—bronze
- "'Its legs of iron'"—iron
- "'Its feet part of iron and part of clay'"—iron/clay
- "'A stone was cut out without hands'"—stone
- "'Smote the image upon its feet'"—smote
- "'The stone... became a great mountain, and filled the whole earth'"—filled earth
- "'You are the head of gold'"—Nebuchadnezzar = gold
- "'After you shall arise another kingdom inferior'"—inferior
- "'Third kingdom of brass'"—bronze
- "'Fourth kingdom shall be strong as iron'"—iron
- "'Part of iron, and part of clay... divided kingdom'"—divided
- "'In the days of those kings shall the God of heaven set up a kingdom'"—God's kingdom
- "'Which shall never be destroyed'"—eternal
- "'It shall stand for ever'"—forever
- "'Your God is the God of gods'"—God of gods
- "The king made Daniel great"—promoted
- "Made him ruler over the whole province of Babylon"—ruler
- "Chief prefect over all the wise men"—chief

**Modern Equivalent:** Daniel 2 presents the "four kingdoms" schema. The metals degrade (gold→silver→bronze→iron/clay), suggesting declining value or increasing fragility. Traditional interpretation: Babylon, Medo-Persia, Greece, Rome. The "stone cut without hands" is God's kingdom replacing human empires. Daniel's promotion from captive to ruler demonstrates divine sovereignty.

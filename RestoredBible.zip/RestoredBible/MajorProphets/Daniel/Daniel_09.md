# Daniel 9: Daniel's Prayer and the Seventy Weeks

*From the Hebrew: בִּשְׁנַת אַחַת לְדָרְיָוֶשׁ (Bi-Shnat Achat Le-Daryavesh) — In the First Year of Darius*

---

## Daniel's Understanding (9:1-3)

**9:1** In the first year of Darius the son of Ahasuerus, of the seed of the Medes, who was made king over the realm of the Chaldeans;

**9:2** In the first year of his reign I Daniel meditated in the books, over the number of the years, whereof the word of YHWH came to Jeremiah the prophet, that he would accomplish for the desolations of Jerusalem seventy years.

**9:3** And I set my face unto the Lord God, to seek by prayer and supplications, with fasting, and sackcloth, and ashes.

---

## Daniel's Prayer (9:4-19)

**9:4** And I prayed unto YHWH my God, and made confession, and said: "O Lord, the great and awful God, who keeps covenant and mercy with them that love him and keep his commandments;

**9:5** "We have sinned, and have dealt iniquitously, and have done wickedly, and have rebelled, and have turned aside from your commandments and from your ordinances;

**9:6** "Neither have we hearkened unto your servants the prophets, that spoke in your name to our kings, our princes, and our fathers, and to all the people of the land.

**9:7** "Unto you, O Lord, belongs righteousness, but unto us confusion of face, as at this day; to the men of Judah, and to the inhabitants of Jerusalem, and unto all Israel, that are near, and that are far off, through all the countries whither you have driven them, because of their treachery that they have committed against you.

**9:8** "O Lord, to us belongs confusion of face, to our kings, to our princes, and to our fathers, because we have sinned against you.

**9:9** "To the Lord our God belong compassions and forgivenesses; for we have rebelled against him;

**9:10** "Neither have we hearkened to the voice of YHWH our God, to walk in his laws, which he set before us by his servants the prophets.

**9:11** "Yea, all Israel have transgressed your law, and have turned aside, so as not to hearken to your voice; and so there has been poured out upon us the curse and the oath that is written in the Law of Moses the servant of God; for we have sinned against him.

**9:12** "And he has confirmed his words, which he spoke against us, and against our judges that judged us, by bringing upon us a great evil; for under the whole heaven has not been done as has been done upon Jerusalem.

**9:13** "As it is written in the Law of Moses, all this evil is come upon us; yet have we not entreated the favour of YHWH our God, that we might turn from our iniquities, and have discernment in your truth.

**9:14** "Therefore has YHWH watched over the evil, and brought it upon us; for YHWH our God is righteous in all his works which he does, and we have not hearkened to his voice.

**9:15** "And now, O Lord our God, that have brought your people forth out of the land of Egypt with a mighty hand, and have gotten you renown, as at this day; we have sinned, we have done wickedly.

**9:16** "O Lord, according to all your righteousness, let your anger and your fury, I pray you, be turned away from your city Jerusalem, your holy mountain; because for our sins, and for the iniquities of our fathers, Jerusalem and your people are become a reproach to all that are round about us.

**9:17** "Now therefore, O our God, hearken unto the prayer of your servant, and to his supplications, and cause your face to shine upon your sanctuary that is desolate, for the Lord's sake.

**9:18** "O my God, incline your ear, and hear; open your eyes, and behold our desolations, and the city upon which your name is called; for we do not present our supplications before you for our righteousnesses, but for your great compassions.

**9:19** "O Lord, hear; O Lord, forgive; O Lord, attend and do; defer not; for your own sake, O my God, because your name is called upon your city and upon your people."

---

## Gabriel's Revelation (9:20-27)

**9:20** And while I was speaking, and praying, and confessing my sin and the sin of my people Israel, and presenting my supplication before YHWH my God for the holy mountain of my God;

**9:21** Yea, while I was speaking in prayer, the man Gabriel, whom I had seen in the vision at the beginning, being caused to fly swiftly, approached close to me about the time of the evening offering.

**9:22** And he made me to understand, and talked with me, and said: "O Daniel, I am now come forth to give you insight and understanding.

**9:23** "At the beginning of your supplications a word went forth, and I am come to declare it; for you are greatly beloved; therefore look into the word, and understand the vision.

**9:24** "Seventy weeks are decreed upon your people and upon your holy city, to finish the transgression, and to make an end of sin, and to make reconciliation for iniquity, and to bring in everlasting righteousness, and to seal up vision and prophecy, and to anoint the most holy.

**9:25** "Know therefore and understand, that from the going forth of the word to restore and to build Jerusalem unto the anointed one, the prince, shall be seven weeks; and for threescore and two weeks, it shall be built again, with broad place and moat, but in troublous times.

**9:26** "And after the threescore and two weeks shall the anointed one be cut off, and shall have nothing; and the people of a prince that shall come shall destroy the city and the sanctuary; and the end thereof shall be with a flood, and unto the end of the war desolations are determined.

**9:27** "And he shall confirm a covenant with many for one week; and for half of the week he shall cause the sacrifice and the offering to cease; and upon the wing of detestable things shall be that which causes appalment; and that until the consummation, and that determined, shall be poured out upon that which causes appalment."

---

## Synthesis Notes

**Key Restorations:**

**Daniel's Understanding (9:1-3):**
**The Key Verses (9:1-2):**
"In the first year of Darius the son of Ahasuerus, of the seed of the Medes."

*Bi-shnat achat le-Daryavesh ben-Achashverosh mi-zera Madai*—1st year of Darius.

"Who was made king over the realm of the Chaldeans."

*Asher homlakh al malkhut Kasdim*—over Chaldeans.

"I Daniel meditated in the books."

*Ani Dani'el binoti ba-sefarim*—studied books.

"Over the number of the years, whereof the word of YHWH came to Jeremiah the prophet."

*Mispar ha-shanim asher hayah devar-YHWH el-Yirmeyah ha-navi*—Jeremiah's prophecy.

"He would accomplish for the desolations of Jerusalem seventy years."

*Le-malle le-chorvot Yerushalayim shiv'im shanah*—70 years.

**Jeremiah's Prophecy:**
Jeremiah 25:11-12; 29:10 predict 70 years of exile.

**The Key Verse (9:3):**
"I set my face unto the Lord God."

*Va-ettenah et-panai el-Adonai ha-Elohim*—set face.

"To seek by prayer and supplications."

*Le-vaqqesh tefillah ve-tachanunhim*—prayer, supplication.

"With fasting, and sackcloth, and ashes."

*Be-tzom ve-saq va-efer*—fasting, sackcloth, ashes.

**Daniel's Prayer (9:4-19):**
**The Key Verses (9:4-6):**
"'O Lord, the great and awful God.'"

*Adonai ha-El ha-gadol ve-ha-nora*—great, awesome.

"'Who keeps covenant and mercy with them that love him.'"

*Shomer ha-berit ve-ha-chesed le-ohavav*—keeps covenant.

"'We have sinned, and have dealt iniquitously, and have done wickedly, and have rebelled.'"

*Chatanu ve-avinu ve-hirsha'nu u-maradnu*—fourfold confession.

"'We have turned aside from your commandments.'"

*Ve-sor mi-mitzvotekha u-mi-mishpatekha*—turned aside.

"'Neither have we hearkened unto your servants the prophets.'"

*Ve-lo shama'nu el-avadekha ha-nevi'im*—didn't listen.

**The Key Verses (9:7-11):**
"'Unto you, O Lord, belongs righteousness.'"

*Lekha Adonai ha-tzedaqah*—righteousness.

"'But unto us confusion of face.'"

*Ve-lanu boshet ha-panim*—shame.

"'To the men of Judah, and to the inhabitants of Jerusalem, and unto all Israel.'"

*Le-ish Yehudah u-le-yoshevei Yerushalayim u-le-khol-Yisra'el*—all Israel.

"'That are near, and that are far off, through all the countries.'"

*Ha-qerovim ve-ha-rechoqim be-khol-ha-aratzot*—near and far.

"'To the Lord our God belong compassions and forgivenesses.'"

*La-Adonai Eloheinu ha-rachamim ve-ha-selichot*—compassions.

"'For we have rebelled against him.'"

*Ki maradnu bo*—rebelled.

"'All Israel have transgressed your law.'"

*Ve-khol-Yisra'el averu et-toratekha*—transgressed.

"'There has been poured out upon us the curse and the oath that is written in the Law of Moses.'"

*Va-tittakh aleinu ha-alah ve-ha-shevu'ah ha-ketuvah be-torat Mosheh*—curse of Moses.

**The Key Verses (9:12-14):**
"'He has confirmed his words, which he spoke against us.'"

*Va-yaqem et-devarav asher dibber aleinu*—confirmed words.

"'By bringing upon us a great evil.'"

*Le-havi aleinu ra'ah gedolah*—great evil.

"'For under the whole heaven has not been done as has been done upon Jerusalem.'"

*Asher lo-na'asetah tachat kol-ha-shamayim ka-asher na'asetah bi-Yerushalayim*—unprecedented.

"'As it is written in the Law of Moses, all this evil is come upon us.'"

*Ka-asher katuv be-torat Mosheh et kol-ha-ra'ah ha-zot ba'ah aleinu*—as written.

"'YHWH our God is righteous in all his works which he does.'"

*Tzaddiq YHWH Eloheinu al-kol-ma'asav asher asah*—God is righteous.

**The Key Verses (9:15-19):**
"'You have brought your people forth out of the land of Egypt with a mighty hand.'"

*Hotzeta et-ammekha me-eretz Mitzrayim be-yad chazaqah*—Exodus.

"'Have gotten you renown, as at this day.'"

*Va-ta'as lekha shem ke-hayom ha-zeh*—renown.

"'We have sinned, we have done wickedly.'"

*Chatanu rasha'nu*—sinned.

"'Let your anger and your fury... be turned away from your city Jerusalem.'"

*Yashuv-na appekha va-chamatekha me-irkha Yerushalayim*—turn away anger.

"'Your holy mountain.'"

*Har-qodshekha*—holy mountain.

"'Jerusalem and your people are become a reproach.'"

*Yerushalayim ve-ammekha le-cherpah le-khol-sevivoteinu*—reproach.

"'Cause your face to shine upon your sanctuary that is desolate.'"

*Ve-ha'er panekha al-miqdashekha ha-shamem*—shine on sanctuary.

"'For the Lord's sake.'"

*Lema'an Adonai*—for Lord's sake.

"'Behold our desolations, and the city upon which your name is called.'"

*U-re'eh shomemoteinu ve-ha-ir asher-niqra shimkha aleha*—city with name.

"'We do not present our supplications before you for our righteousnesses.'"

*Ki lo al-tzidqoteinu anachnu mappilim tachanunenu lefanekha*—not our righteousness.

"'But for your great compassions.'"

*Ki al-rachamekha ha-rabbim*—your compassions.

"'O Lord, hear; O Lord, forgive; O Lord, attend and do; defer not.'"

*Adonai shema'ah Adonai selachah Adonai haqshivah va-aseh al-te'achar*—hear, forgive, act.

"'For your own sake, O my God.'"

*Lema'anekha Elohai*—for your sake.

"'Because your name is called upon your city and upon your people.'"

*Ki-shimkha niqra al-irkha ve-al-ammekha*—your name.

**Gabriel's Revelation (9:20-27):**
**The Key Verses (9:20-23):**
"While I was speaking, and praying, and confessing my sin."

*Ve-od ani medabber u-mitpallel u-mitvaddeh chattati*—praying.

"The man Gabriel, whom I had seen in the vision at the beginning."

*Ve-ha-ish Gavri'el asher ra'iti ba-chazon ba-techillah*—Gabriel.

"Being caused to fly swiftly."

*Mu'af bi-yeaf*—flying swiftly.

"Approached close to me about the time of the evening offering."

*Noge'a elai ke-et minchat-arev*—evening offering time.

"'O Daniel, I am now come forth to give you insight and understanding.'"

*Dani'el attah yatzati le-haskilekha binah*—give understanding.

"'At the beginning of your supplications a word went forth.'"

*Bi-techillat tachanunekha yatza davar*—word went forth.

"'I am come to declare it; for you are greatly beloved.'"

*Va-ani bati le-haggid ki-chamudot attah*—greatly beloved.

**Chamudot:**
"Greatly beloved" or "treasured one."

**The Key Verse (9:24):**
"'Seventy weeks are decreed upon your people and upon your holy city.'"

*Shavu'im shiv'im nechtakh al-ammekha ve-al-ir qodshekha*—70 weeks decreed.

**Shavu'im Shiv'im:**
"Seventy weeks" = seventy sevens = 490 years.

"'To finish the transgression.'"

*Le-khalle ha-pesha*—finish transgression.

"'To make an end of sin.'"

*Le-hatem chattat*—end sin.

"'To make reconciliation for iniquity.'"

*U-le-khapper avon*—atone.

"'To bring in everlasting righteousness.'"

*U-le-havi tzeddeq olamim*—everlasting righteousness.

"'To seal up vision and prophecy.'"

*Ve-la-chatom chazon ve-navi*—seal prophecy.

"'To anoint the most holy.'"

*Ve-limshocah qodesh qodashim*—anoint most holy.

**The Key Verse (9:25):**
"'From the going forth of the word to restore and to build Jerusalem.'"

*Mi-motza davar le-hashiv ve-livnot Yerushalayim*—decree to rebuild.

"'Unto the anointed one, the prince.'"

*Ad-Mashiach nagid*—until Messiah the Prince.

"'Shall be seven weeks; and for threescore and two weeks.'"

*Shavu'im shiv'ah ve-shavu'im shishshim u-shenayim*—7 + 62 weeks.

"'It shall be built again, with broad place and moat.'"

*Tashوv ve-nivnetah rechov ve-charutz*—rebuilt.

"'But in troublous times.'"

*U-ve-tzoq ha-ittim*—troublous times.

**The Key Verse (9:26):**
"'After the threescore and two weeks shall the anointed one be cut off.'"

*Ve-acharei ha-shavu'im shishshim u-shenayim yikkaret Mashiach*—Messiah cut off.

"'And shall have nothing.'"

*Ve-ein lo*—and have nothing.

"'The people of a prince that shall come shall destroy the city and the sanctuary.'"

*Ve-ha-ir ve-ha-qodesh yashchit am nagid ha-ba*—city, sanctuary destroyed.

"'The end thereof shall be with a flood.'"

*Ve-qitzo ba-shetef*—end with flood.

"'Unto the end of the war desolations are determined.'"

*Ve-ad qetz milchamah neחeretzet shomemot*—desolations determined.

**The Key Verse (9:27):**
"'He shall confirm a covenant with many for one week.'"

*Ve-higbir berit la-rabbim shavua echad*—covenant one week.

"'For half of the week he shall cause the sacrifice and the offering to cease.'"

*Va-chatzi ha-shavua yashbit zevach u-minchah*—sacrifice cease.

"'Upon the wing of detestable things shall be that which causes appalment.'"

*Ve-al kenaf shiqquzim meshomem*—abomination of desolation.

"'Until the consummation, and that determined, shall be poured out upon that which causes appalment.'"

*Ve-ad-kalah ve-necheratzah tittakh al-shomem*—poured on desolator.

**Archetypal Layer:** Daniel 9 contains **Daniel reading Jeremiah's 70-year prophecy (9:2)**, **Daniel's penitential prayer (9:4-19)**—one of Scripture's greatest prayers, **"unto you, O Lord, belongs righteousness, but unto us confusion of face" (9:7)**, **"we do not present our supplications before you for our righteousnesses, but for your great compassions" (9:18)**, **Gabriel appears at evening offering time (9:21)**, **"you are greatly beloved" (9:23)**, **the Seventy Weeks prophecy (9:24-27)**, **"seventy weeks are decreed... to finish the transgression" (9:24)**, **"unto the anointed one, the prince" (9:25)**, **"the anointed one be cut off, and shall have nothing" (9:26)**, and **"upon the wing of detestable things shall be that which causes appalment" (9:27)**.

**Ethical Inversion Applied:**
- "In the first year of Darius"—1st year
- "I Daniel meditated in the books"—studied Scripture
- "The word of YHWH came to Jeremiah the prophet"—Jeremiah's prophecy
- "He would accomplish for the desolations of Jerusalem seventy years"—70 years
- "I set my face unto the Lord God"—set face
- "To seek by prayer and supplications"—prayer
- "With fasting, and sackcloth, and ashes"—penitence
- "'O Lord, the great and awful God'"—great God
- "'Who keeps covenant and mercy'"—keeps covenant
- "'We have sinned, and have dealt iniquitously, and have done wickedly, and have rebelled'"—confession
- "'We have turned aside from your commandments'"—turned aside
- "'Neither have we hearkened unto your servants the prophets'"—didn't listen
- "'Unto you, O Lord, belongs righteousness'"—God righteous
- "'But unto us confusion of face'"—shame
- "'To the Lord our God belong compassions and forgivenesses'"—compassions
- "'All Israel have transgressed your law'"—transgressed
- "'There has been poured out upon us the curse'"—curse
- "'He has confirmed his words'"—confirmed
- "'Under the whole heaven has not been done as has been done upon Jerusalem'"—unprecedented
- "'YHWH our God is righteous in all his works'"—righteous
- "'You have brought your people forth out of... Egypt'"—Exodus
- "'Let your anger... be turned away from your city Jerusalem'"—turn away anger
- "'Cause your face to shine upon your sanctuary that is desolate'"—shine
- "'For the Lord's sake'"—for Lord's sake
- "'Behold our desolations'"—desolations
- "'We do not present our supplications... for our righteousnesses'"—not our merit
- "'But for your great compassions'"—your compassions
- "'O Lord, hear; O Lord, forgive; O Lord, attend and do'"—hear, forgive, act
- "'For your own sake'"—for God's sake
- "The man Gabriel, whom I had seen in the vision"—Gabriel
- "Being caused to fly swiftly"—swift
- "About the time of the evening offering"—evening offering
- "'I am now come forth to give you insight'"—give understanding
- "'At the beginning of your supplications a word went forth'"—word sent
- "'You are greatly beloved'"—beloved
- "'Seventy weeks are decreed upon your people'"—70 weeks
- "'To finish the transgression'"—finish transgression
- "'To make an end of sin'"—end sin
- "'To make reconciliation for iniquity'"—atone
- "'To bring in everlasting righteousness'"—everlasting righteousness
- "'To seal up vision and prophecy'"—seal prophecy
- "'To anoint the most holy'"—anoint
- "'From the going forth of the word to restore and to build Jerusalem'"—decree
- "'Unto the anointed one, the prince'"—Messiah Prince
- "'Shall be seven weeks; and for threescore and two weeks'"—7 + 62 weeks
- "'It shall be built again'"—rebuilt
- "'In troublous times'"—troublous
- "'After the threescore and two weeks shall the anointed one be cut off'"—Messiah cut off
- "'And shall have nothing'"—have nothing
- "'The people of a prince that shall come shall destroy the city and the sanctuary'"—city destroyed
- "'The end thereof shall be with a flood'"—flood end
- "'Desolations are determined'"—desolations
- "'He shall confirm a covenant with many for one week'"—covenant
- "'For half of the week he shall cause the sacrifice... to cease'"—sacrifice cease
- "'Upon the wing of detestable things shall be that which causes appalment'"—abomination
- "'Until the consummation'"—consummation

**Modern Equivalent:** Daniel 9 has Daniel reading Jeremiah's 70-year prophecy and praying for restoration. Gabriel reveals the "70 weeks" (490 years), an influential messianic calculation. The "anointed one cut off" (9:26) has been applied to Jesus. "Abomination of desolation" appears in Mark 13:14. This chapter is foundational for Christian eschatology.

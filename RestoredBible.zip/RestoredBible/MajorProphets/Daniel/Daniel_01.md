# Daniel 1: Daniel in Babylon

*From the Hebrew: בִּשְׁנַת שָׁלוֹשׁ לְמַלְכוּת יְהוֹיָקִים (Bi-Shnat Shalosh Le-Malkhut Yehoyaqim) — In the Third Year of the Reign of Jehoiakim*

---

## The Siege of Jerusalem (1:1-2)

**1:1** In the third year of the reign of Jehoiakim king of Judah came Nebuchadnezzar king of Babylon unto Jerusalem, and besieged it.

**1:2** And the Lord gave Jehoiakim king of Judah into his hand, with part of the vessels of the house of God; and he carried them into the land of Shinar to the house of his god, and the vessels he brought into the treasure-house of his god.

---

## The Selection of Young Men (1:3-7)

**1:3** And the king spoke unto Ashpenaz the master of his eunuchs, that he should bring in certain of the children of Israel, and of the seed royal, and of the nobles;

**1:4** Youths in whom was no blemish, but fair to look on, and skilful in all wisdom, and endued with knowledge, and discerning in thought, and such as had ability to stand in the king's palace; and that he should teach them the learning and the tongue of the Chaldeans.

**1:5** And the king appointed unto them a daily portion of the king's food, and of the wine which he drank, and that they should be nourished three years; that at the end thereof they might stand before the king.

**1:6** Now among these were, of the children of Judah, Daniel, Hananiah, Mishael, and Azariah.

**1:7** And the chief of the eunuchs gave them names: unto Daniel he gave the name Belteshazzar; and to Hananiah, Shadrach; and to Mishael, Meshach; and to Azariah, Abed-nego.

---

## Daniel's Resolve (1:8-16)

**1:8** But Daniel purposed in his heart that he would not defile himself with the king's food, nor with the wine which he drank; therefore he requested of the chief of the eunuchs that he might not defile himself.

**1:9** Now God made Daniel to find favour and compassion in the sight of the chief of the eunuchs.

**1:10** And the chief of the eunuchs said unto Daniel: "I fear my lord the king, who has appointed your food and your drink; for why should he see your faces worse looking than the youths that are of your own age? So would you endanger my head with the king."

**1:11** Then said Daniel to the steward, whom the chief of the eunuchs had appointed over Daniel, Hananiah, Mishael, and Azariah:

**1:12** "Try your servants, I beseech you, ten days; and let them give us pulse to eat, and water to drink.

**1:13** "Then let our countenances be looked upon before you, and the countenance of the youths that eat of the king's food; and as you see, deal with your servants."

**1:14** So he hearkened unto them in this matter, and tried them ten days.

**1:15** And at the end of ten days their countenances appeared fairer, and they were fatter in flesh, than all the youths that did eat of the king's food.

**1:16** So the steward took away their food and the wine that they should drink, and gave them pulse.

---

## God's Blessing (1:17-21)

**1:17** Now as for these four youths, God gave them knowledge and skill in all learning and wisdom; and Daniel had understanding in all visions and dreams.

**1:18** And at the end of the days which the king had appointed for bringing them in, the chief of the eunuchs brought them in before Nebuchadnezzar.

**1:19** And the king communed with them; and among them all was found none like Daniel, Hananiah, Mishael, and Azariah; therefore stood they before the king.

**1:20** And in every matter of wisdom and understanding, concerning which the king inquired of them, he found them ten times better than all the magicians and enchanters that were in all his realm.

**1:21** And Daniel continued even unto the first year of king Cyrus.

---

## Synthesis Notes

**Key Restorations:**

**Siege of Jerusalem (1:1-2):**
**The Key Verse (1:1):**
"In the third year of the reign of Jehoiakim king of Judah."

*Bi-shnat shalosh le-malkhut Yehoyaqim melekh-Yehudah*—605 BCE.

"Came Nebuchadnezzar king of Babylon unto Jerusalem, and besieged it."

*Ba Nevukhadne'tzar melekh-Bavel Yerushalayim va-yatzar alekha*—Nebuchadnezzar besieges.

**The Key Verse (1:2):**
"The Lord gave Jehoiakim king of Judah into his hand."

*Va-yitten Adonai be-yado et-Yehoyaqim melekh-Yehudah*—YHWH gave.

"With part of the vessels of the house of God."

*U-miqtzat kelei veit-ha-Elohim*—part of vessels.

"He carried them into the land of Shinar."

*Va-yevi'em eretz-Shin'ar*—Shinar = Babylon.

"To the house of his god."

*Beit elohav*—his god's temple.

"The vessels he brought into the treasure-house of his god."

*Ve-et-ha-kelim hevi beit otzar elohav*—treasure-house.

**Selection of Young Men (1:3-7):**
**The Key Verses (1:3-4):**
"The king spoke unto Ashpenaz the master of his eunuchs."

*Va-yomer ha-melekh le-Ashpenaz rav sarisav*—to Ashpenaz.

"He should bring in certain of the children of Israel."

*Le-havi mi-benei Yisra'el*—from Israelites.

"Of the seed royal, and of the nobles."

*U-mi-zera ha-melukhah u-min-ha-partemim*—royalty, nobility.

"Youths in whom was no blemish."

*Yeladim asher ein-bahem kol-mum*—no blemish.

"Fair to look on."

*Ve-tovei mar'eh*—good-looking.

"Skilful in all wisdom."

*U-maskilim be-khol-chokhmah*—wise.

"Endued with knowledge."

*Ve-yod'ei da'at*—knowledgeable.

"Discerning in thought."

*U-mevinim madda*—understanding.

"Such as had ability to stand in the king's palace."

*Va-asher koach bahem la'amod be-heikhal ha-melekh*—palace ability.

"He should teach them the learning and the tongue of the Chaldeans."

*U-le-lammedam sefer u-leshon Kasdim*—Chaldean learning.

**The Key Verse (1:5):**
"The king appointed unto them a daily portion of the king's food."

*Va-yeman lahem ha-melekh devar-yom be-yomo mi-pat-bag ha-melekh*—king's food.

"And of the wine which he drank."

*U-mi-yein mishtav*—king's wine.

"That they should be nourished three years."

*U-le-gaddelam shanim shalosh*—3 years.

"That at the end thereof they might stand before the king."

*U-mi-qetzatam ya'amdu lifnei ha-melekh*—stand before king.

**The Key Verses (1:6-7):**
"Among these were, of the children of Judah, Daniel, Hananiah, Mishael, and Azariah."

*Va-yehi vahem mi-benei Yehudah Dani'el Chananyah Misha'el va-Azaryah*—four Judeans.

"The chief of the eunuchs gave them names."

*Va-yasem lahem sar ha-sarisim shemot*—gave names.

"Unto Daniel he gave the name Belteshazzar."

*Va-yasem le-Dani'el Beltsha'tstsar*—Belteshazzar.

"To Hananiah, Shadrach."

*Ve-la-Chananyah Shadrakh*—Shadrach.

"To Mishael, Meshach."

*U-le-Misha'el Meishakh*—Meshach.

"To Azariah, Abed-nego."

*U-la-Azaryah Aved-Nego*—Abed-nego.

**Name Changes:**
- Daniel ("God is my judge") → Belteshazzar ("Bel protect his life")
- Hananiah ("YHWH is gracious") → Shadrach (possibly "command of Aku")
- Mishael ("Who is what God is?") → Meshach (possibly "Who is what Aku is?")
- Azariah ("YHWH has helped") → Abed-nego ("Servant of Nebo")

**Daniel's Resolve (1:8-16):**
**The Key Verse (1:8):**
"Daniel purposed in his heart that he would not defile himself."

*Va-yasem Dani'el al-libbo asher lo-yitgaal*—purposed not to defile.

"With the king's food, nor with the wine which he drank."

*Be-pat-bag ha-melekh u-ve-yein mishtav*—king's food, wine.

"He requested of the chief of the eunuchs that he might not defile himself."

*Va-yevaqesh me-sar ha-sarisim asher lo yitgaال*—requested.

**The Key Verses (1:9-10):**
"God made Daniel to find favour and compassion in the sight of the chief of the eunuchs."

*Va-yitten ha-Elohim et-Dani'el le-chesed u-le-rachamim lifnei sar ha-sarisim*—God gave favor.

"'I fear my lord the king, who has appointed your food and your drink.'"

*Yarei ani et-adoni ha-melekh asher minnah et-maakhalekhem ve-et-mishteikhem*—fears king.

"'Why should he see your faces worse looking than the youths that are of your own age?'"

*Lammah yir'eh et-peneikhem zo'afim min-ha-yeladim asher ke-gilkhem*—worse looking.

"'So would you endanger my head with the king.'"

*Ve-chiyyavtem et-roshi la-melekh*—endanger head.

**The Key Verses (1:11-14):**
"Daniel said to the steward, whom the chief of the eunuchs had appointed."

*Va-yomer Dani'el el-ha-meltzar asher minnah sar ha-sarisim*—to steward.

"'Try your servants, I beseech you, ten days.'"

*Nas-na et-avadekha yamim asarah*—10-day test.

"'Let them give us pulse to eat, and water to drink.'"

*Ve-yittenu-lanu min-ha-zero'im ve-nokhal u-mayim ve-nishteh*—vegetables, water.

"'Then let our countenances be looked upon before you.'"

*Ve-yera'u lefanekha marennu*—examine us.

"'And the countenance of the youths that eat of the king's food.'"

*U-mar'eh ha-yeladim ha-okhelim et pat-bag ha-melekh*—compare.

"'As you see, deal with your servants.'"

*Ve-kha-asher tir'eh aseh im-avadekha*—as you see.

"He hearkened unto them in this matter, and tried them ten days."

*Va-yishma lahem la-davar ha-zeh va-yenassem yamim asarah*—agreed.

**The Key Verses (1:15-16):**
"At the end of ten days their countenances appeared fairer."

*U-mi-qetzat yamim asarah nir'u mar'eihem tov*—fairer.

"They were fatter in flesh, than all the youths that did eat of the king's food."

*U-veri'ei basar min-kol-ha-yeladim ha-okhelim et pat-bag ha-melekh*—fatter.

"The steward took away their food and the wine."

*Va-yehi ha-meltzar noseh et-pat-bagam ve-yein mishtam*—took away.

"Gave them pulse."

*Ve-noten lahem zero'im*—gave vegetables.

**God's Blessing (1:17-21):**
**The Key Verse (1:17):**
"As for these four youths, God gave them knowledge and skill in all learning and wisdom."

*Ve-ha-yeladim ha-elleh arba'tam natan lahem ha-Elohim madda ve-haskel be-khol-sefer ve-chokhmah*—God gave wisdom.

"Daniel had understanding in all visions and dreams."

*Ve-Dani'el hevin be-khol-chazon va-chalomot*—visions, dreams.

**The Key Verses (1:18-20):**
"At the end of the days which the king had appointed for bringing them in."

*U-mi-qetzat ha-yamim asher-amar ha-melekh le-havi'am*—end of period.

"The chief of the eunuchs brought them in before Nebuchadnezzar."

*Va-yevi'em sar ha-sarisim lifnei Nevukhadnetstsar*—before king.

"The king communed with them."

*Va-yedabber ittam ha-melekh*—king spoke.

"Among them all was found none like Daniel, Hananiah, Mishael, and Azariah."

*Ve-lo nimtza be-khullam ke-Dani'el Chananyah Misha'el va-Azaryah*—none like them.

"Therefore stood they before the king."

*Va-ya'amdu lifnei ha-melekh*—stood before king.

"In every matter of wisdom and understanding, concerning which the king inquired of them."

*U-ve-khol devar chokhmat binah asher biqqesh me-hem ha-melekh*—wisdom inquired.

"He found them ten times better than all the magicians and enchanters."

*Va-yimtza'em eser yadot al kol-ha-chartummim ha-ashshafim*—ten times better.

"That were in all his realm."

*Asher be-khol-malkhuto*—in whole realm.

**The Key Verse (1:21):**
"Daniel continued even unto the first year of king Cyrus."

*Va-yehi Dani'el ad-shenat achat le-Koresh ha-melekh*—to Cyrus (539 BCE).

**Archetypal Layer:** Daniel 1 introduces the **book's setting and characters**, containing **Nebuchadnezzar's siege and deportation (1:1-2)**, **selection of royal/noble youths for Babylonian education (1:3-5)**, **the four Judeans: Daniel, Hananiah, Mishael, Azariah (1:6)**, **Babylonian name changes (1:7)**, **Daniel's resolution not to defile himself (1:8)**, **the 10-day vegetable test (1:12-15)**, **"God gave them knowledge and skill" (1:17)**, **"ten times better than all the magicians" (1:20)**, and **Daniel's service spanning to Cyrus (1:21)**.

**Ethical Inversion Applied:**
- "In the third year of the reign of Jehoiakim"—605 BCE
- "Nebuchadnezzar king of Babylon... besieged it"—siege
- "The Lord gave Jehoiakim... into his hand"—YHWH permitted
- "With part of the vessels of the house of God"—temple vessels
- "He carried them into the land of Shinar"—to Babylon
- "To the house of his god"—pagan temple
- "The king spoke unto Ashpenaz the master of his eunuchs"—to Ashpenaz
- "He should bring in certain of the children of Israel"—Israelite youth
- "Of the seed royal, and of the nobles"—royalty
- "Youths in whom was no blemish"—unblemished
- "Fair to look on"—handsome
- "Skilful in all wisdom"—wise
- "He should teach them the learning and the tongue of the Chaldeans"—Babylonian education
- "The king appointed unto them a daily portion of the king's food"—royal diet
- "That they should be nourished three years"—3 years
- "Daniel, Hananiah, Mishael, and Azariah"—four Judeans
- "Unto Daniel he gave the name Belteshazzar"—name change
- "To Hananiah, Shadrach"—name change
- "To Mishael, Meshach"—name change
- "To Azariah, Abed-nego"—name change
- "Daniel purposed in his heart that he would not defile himself"—resolved
- "With the king's food, nor with the wine"—dietary laws
- "God made Daniel to find favour"—God's favor
- "'I fear my lord the king'"—eunuch's fear
- "'Try your servants... ten days'"—10-day test
- "'Let them give us pulse to eat, and water to drink'"—vegetables, water
- "At the end of ten days their countenances appeared fairer"—fairer
- "They were fatter in flesh"—healthier
- "The steward... gave them pulse"—vegetables continued
- "God gave them knowledge and skill in all learning and wisdom"—God gave wisdom
- "Daniel had understanding in all visions and dreams"—visions, dreams
- "Among them all was found none like Daniel"—exceptional
- "He found them ten times better than all the magicians"—ten times better
- "Daniel continued even unto the first year of king Cyrus"—to Cyrus

**Modern Equivalent:** Daniel 1 sets up the exile narrative. Four Judean nobles are selected for Babylonian education. Daniel's refusal of the king's food represents maintaining identity under foreign rule. The 10-day test demonstrates that faithfulness brings blessing. "Ten times better" shows divine wisdom surpassing human wisdom. Daniel's career spanning to Cyrus (539 BCE) frames the book.

# Daniel 5: The Writing on the Wall

*From the Aramaic: בֵּלְשַׁאצַּר מַלְכָּא עֲבַד לְחֵם רַב (Belshatstsar Malka Avad Lechem Rav) — Belshazzar the King Made a Great Feast*

---

## Belshazzar's Feast (5:1-4)

**5:1** Belshazzar the king made a great feast to a thousand of his lords, and drank wine before the thousand.

**5:2** Belshazzar, while he tasted the wine, commanded to bring the golden and silver vessels which Nebuchadnezzar his father had taken out of the temple which was in Jerusalem; that the king and his lords, his consorts and his concubines, might drink therein.

**5:3** Then they brought the golden vessels that were taken out of the temple of the house of God which was at Jerusalem; and the king and his lords, his consorts and his concubines, drank in them.

**5:4** They drank wine, and praised the gods of gold, and of silver, of brass, of iron, of wood, and of stone.

---

## The Writing on the Wall (5:5-9)

**5:5** In the same hour came forth fingers of a man's hand, and wrote over against the candlestick upon the plaster of the wall of the king's palace; and the king saw the part of the hand that wrote.

**5:6** Then the king's countenance was changed in him, and his thoughts affrighted him; and the joints of his loins were loosed, and his knees smote one against another.

**5:7** The king cried aloud to bring in the enchanters, the Chaldeans, and the astrologers. The king spoke and said to the wise men of Babylon: "Whosoever shall read this writing, and declare unto me the interpretation thereof, shall be clothed with purple, and have a chain of gold about his neck, and shall rule as one of three in the kingdom."

**5:8** Then came in all the king's wise men; but they could not read the writing, nor make known to the king the interpretation.

**5:9** Then was king Belshazzar greatly affrighted, and his countenance was changed in him, and his lords were perplexed.

---

## The Queen's Advice (5:10-12)

**5:10** Now the queen by reason of the words of the king and his lords came into the banquet house; the queen spoke and said: "O king, live for ever! Let not your thoughts affright you, nor let your countenance be changed.

**5:11** "There is a man in your kingdom, in whom is the spirit of the holy gods; and in the days of your father light and understanding and wisdom, like the wisdom of the gods, was found in him; and the king Nebuchadnezzar your father, the king, I say, your father, made him master of the magicians, enchanters, Chaldeans, and astrologers;

**5:12** "Forasmuch as a surpassing spirit, and knowledge, and understanding, interpreting of dreams, and declaring of dark sentences, and loosing of knots, were found in the same Daniel, whom the king named Belteshazzar. Now let Daniel be called, and he will declare the interpretation."

---

## Daniel Before the King (5:13-16)

**5:13** Then was Daniel brought in before the king. The king spoke and said unto Daniel: "Are you that Daniel, who is of the children of the captivity of Judah, whom the king my father brought out of Judah?

**5:14** "I have heard of you, that the spirit of the gods is in you, and that light and understanding and surpassing wisdom is found in you.

**5:15** "And now the wise men, the enchanters, have been brought in before me, that they should read this writing, and make known unto me the interpretation thereof; but they could not declare the interpretation of the thing.

**5:16** "But I have heard of you, that you can give interpretations, and loose knots; now if you can read the writing, and make known to me the interpretation thereof, you shall be clothed with purple, and have a chain of gold about your neck, and shall rule as one of three in the kingdom."

---

## Daniel's Response (5:17-28)

**5:17** Then Daniel answered and said before the king: "Let your gifts be to yourself, and give your rewards to another; nevertheless I will read the writing unto the king, and make known to him the interpretation.

**5:18** "O you king, the Most High God gave Nebuchadnezzar your father the kingdom, and greatness, and glory, and majesty;

**5:19** "And because of the greatness that he gave him, all the peoples, nations, and languages trembled and feared before him; whom he would he slew, and whom he would he kept alive; and whom he would he raised up, and whom he would he put down.

**5:20** "But when his heart was lifted up, and his spirit was hardened that he dealt proudly, he was deposed from his kingly throne, and his glory was taken from him;

**5:21** "And he was driven from the sons of men, and his heart was made like the beasts, and his dwelling was with the wild asses; he was fed with grass like oxen, and his body was wet with the dew of heaven; until he knew that the Most High God rules in the kingdom of men, and that he sets up over it whomsoever he will.

**5:22** "And you his son, O Belshazzar, have not humbled your heart, though you knew all this;

**5:23** "But have lifted up yourself against the Lord of heaven; and they have brought the vessels of his house before you, and you and your lords, your consorts and your concubines, have drunk wine in them; and you have praised the gods of silver, and gold, of brass, iron, wood, and stone, which see not, nor hear, nor know; and the God in whose hand your breath is, and whose are all your ways, have you not glorified.

**5:24** "Then was the part of the hand sent from before him, and this writing was inscribed.

**5:25** "And this is the writing that was inscribed: MENE MENE TEKEL UPHARSIN.

**5:26** "This is the interpretation of the thing: MENE—God has numbered your kingdom, and brought it to an end.

**5:27** "TEKEL—you are weighed in the balances, and are found wanting.

**5:28** "PERES—your kingdom is divided, and given to the Medes and Persians."

---

## Belshazzar's Fall (5:29-31)

**5:29** Then commanded Belshazzar, and they clothed Daniel with purple, and put a chain of gold about his neck, and made proclamation concerning him, that he should rule as one of three in the kingdom.

**5:30** In that night Belshazzar the Chaldean king was slain.

**5:31** And Darius the Mede received the kingdom, being about threescore and two years old.

---

## Synthesis Notes

**Key Restorations:**

**Belshazzar's Feast (5:1-4):**
**The Key Verses (5:1-2):**
"Belshazzar the king made a great feast to a thousand of his lords."

*Belshatstsar malka avad lechem rav le-ravrevanohi alaf*—great feast.

"Drank wine before the thousand."

*Ve-loqevel alfa chamra shate*—drank before 1,000.

"Belshazzar... commanded to bring the golden and silver vessels."

*Belshatstsar... amar le-haיtayah le-manei dahava ve-khaspa*—bring vessels.

"Which Nebuchadnezzar his father had taken out of the temple which was in Jerusalem."

*Di hanpeq Nevukhadnetstsar avuhi min-heikhla di vi-Yerushalem*—from Jerusalem temple.

"That the king and his lords, his consorts and his concubines, might drink therein."

*Ve-yishtun behon malka ve-ravrevanohi shegalateh u-lechnateh*—drink in them.

**The Key Verses (5:3-4):**
"They brought the golden vessels that were taken out of the temple of the house of God."

*Edayin haiti'u manei dahava di hanpqu min-hekhla di-veit Elaha*—golden vessels.

"The king and his lords, his consorts and his concubines, drank in them."

*Ve-ishtiu behon malka ve-ravrevanohi shegalateh u-lechnateh*—drank in them.

"They drank wine, and praised the gods of gold, and of silver, of brass, of iron, of wood, and of stone."

*Ishtiu chamra ve-shabbechu le-elahei dahava ve-khaspa nechasha parzela a'a ve-avna*—praised false gods.

**Writing on the Wall (5:5-9):**
**The Key Verse (5:5):**
"In the same hour came forth fingers of a man's hand."

*Bi-shah zimnah nefaqu etzbe'an di yad-enash*—fingers appeared.

"Wrote over against the candlestick upon the plaster of the wall."

*Ve-kathבan loqevel nevarshta al-gira di-ketalא*—wrote on wall.

"Of the king's palace."

*Di-heikhal malka*—palace.

"The king saw the part of the hand that wrote."

*U-malka chazeh pas-yeda di kathבah*—king saw hand.

**The Key Verses (5:6-7):**
"The king's countenance was changed in him."

*Edayin malka zיvohi shanohi*—countenance changed.

"His thoughts affrighted him."

*Ve-ra'yonohi yevahhalunneh*—thoughts frightened.

"The joints of his loins were loosed."

*Ve-qitrei chartzeh mishtaran*—loins loosened.

"His knees smote one against another."

*Ve-arkhubateh da le-da naqshan*—knees knocked.

"'Whosoever shall read this writing, and declare unto me the interpretation thereof.'"

*Kol-enash di-yiqre ketava denah u-fishrah yechavvinani*—whoever reads.

"'Shall be clothed with purple.'"

*Argevana yilbash*—purple.

"'Have a chain of gold about his neck.'"

*U-hamnika di-dahava al-tzavvareh*—gold chain.

"'Shall rule as one of three in the kingdom.'"

*Ve-talta be-malkhuta yishlat*—third ruler.

**Queen's Advice (5:10-12):**
"The queen... came into the banquet house."

*Malketa... a'alet le-veit mishtaya*—queen entered.

"'There is a man in your kingdom, in whom is the spirit of the holy gods.'"

*Itai gebar be-malkhutakh di ruach elahin qaddishin beh*—spirit of holy gods.

"'In the days of your father light and understanding and wisdom... was found in him.'"

*U-ve-yomei avukh nahiru ve-sokletanu ve-chokhmah... hishtekachat beh*—light, understanding.

"'The king Nebuchadnezzar your father... made him master of the magicians.'"

*U-malka Nevukhadnetstsar avukh... rav chartummin... haqqimeh avukh malka*—made master.

"'Daniel, whom the king named Belteshazzar.'"

*Dani'el di-malka sam-shmeh Beltsha'tzar*—Daniel/Belteshazzar.

"'Let Daniel be called, and he will declare the interpretation.'"

*Ke'an Dani'el yitqere u-fishraה yechahave*—call Daniel.

**Daniel Before the King (5:13-16):**
"'Are you that Daniel, who is of the children of the captivity of Judah?'"

*Ant-hu Dani'el di min-benei galuta di-Yehud*—captive from Judah.

"'Whom the king my father brought out of Judah?'"

*Di haiti malka abi min-Yehud*—from Judah.

"'I have heard of you, that the spirit of the gods is in you.'"

*Shim'et alakh di ruach elahin bakh*—spirit of gods.

"'Light and understanding and surpassing wisdom is found in you.'"

*Ve-nahiru ve-sokletanu ve-chokhmah yattirah hishtekachat bakh*—wisdom found.

**Daniel's Response (5:17-28):**
**The Key Verses (5:17-21):**
"'Let your gifts be to yourself, and give your rewards to another.'"

*Matnanakh lakh lehevyan ve-neبzkhatakh le-ochoran hab*—keep your gifts.

"'Nevertheless I will read the writing unto the king.'"

*Beram ketava eqre le-malka*—will read.

"'The Most High God gave Nebuchadnezzar your father the kingdom.'"

*Elaha Illa'ah malkhuta u-revuta vi-yqara va-hadrah yehav li-Nevukhadnetstsar avukh*—gave kingdom.

"'All the peoples, nations, and languages trembled and feared before him.'"

*Kol-ammaya ummaya ve-lishnaya havו za'ein ve-dachalin min-qodamohi*—feared.

"'Whom he would he slew, and whom he would he kept alive.'"

*Di-hava tzave qatel ve-di-hava tzave macheh*—absolute power.

"'When his heart was lifted up, and his spirit was hardened that he dealt proudly.'"

*U-kedi rim libbeבeh ve-rucheh tiqfat le-hazadah*—proud.

"'He was deposed from his kingly throne.'"

*Hunhat min-korse malkhuteh*—deposed.

"'His glory was taken from him.'"

*Vi-yqarah he'edו minneh*—glory taken.

"'He was driven from the sons of men.'"

*U-min-benei anasha terid*—driven from men.

"'His heart was made like the beasts.'"

*Ve-libbeבeh im-cheivata shavvi*—beast's heart.

"'His dwelling was with the wild asses.'"

*U-meduרeh im-aradaya*—with wild donkeys.

"'He was fed with grass like oxen.'"

*Isba ke-torin yeta'amun*—fed grass.

"'Until he knew that the Most High God rules in the kingdom of men.'"

*Ad di-yeda di-shallit Elaha Illא'a be-malkhut anasha*—till he knew.

**The Key Verses (5:22-24):**
"'You his son, O Belshazzar, have not humbled your heart.'"

*Ve-ant bereh Belshatstsar la hashpelat libבakh*—not humbled.

"'Though you knew all this.'"

*Kol-qevel di khol-denah yeda'ta*—though you knew.

"'You have lifted up yourself against the Lord of heaven.'"

*Ve-al mare-shemaya hitromamta*—against Lord of heaven.

"'They have brought the vessels of his house before you.'"

*U-le-manaya di-vaiteh haiti'u qodamakh*—brought vessels.

"'You have praised the gods of silver, and gold... which see not, nor hear, nor know.'"

*Ve-le-elahei khaspa ve-dahava... di la chazin ve-la shame'in ve-la yade'in shabachta*—praise deaf gods.

"'The God in whose hand your breath is, and whose are all your ways, have you not glorified.'"

*Ve-le-Elaha di-nishmatakh bi-yadeh ve-khol-orchatakh leh la hadדarta*—not glorified God.

"'Then was the part of the hand sent from before him.'"

*Edayin min-qodamohi sheliach pasa di-yeda*—hand sent.

"'This writing was inscribed.'"

*U-khtava denah reshim*—writing inscribed.

**The Key Verses (5:25-28):**
"'This is the writing that was inscribed: MENE MENE TEKEL UPHARSIN.'"

*U-denah ketava di reshim MENE MENE TEKEL UPHARSIN*—the words.

"'MENE—God has numbered your kingdom, and brought it to an end.'"

*MENE—menah Elaha malkhutakh ve-hashlemah*—numbered.

"'TEKEL—you are weighed in the balances, and are found wanting.'"

*TEKEL—teqilta ve-moزenaya u-hishtekachat chasir*—weighed, wanting.

"'PERES—your kingdom is divided, and given to the Medes and Persians.'"

*PERES—perisat malkhutakh vi-yehibat le-Madai u-Faras*—divided.

**Wordplay:**
- MENE = "numbered" (from *menah*)
- TEKEL = "weighed" (from *teqal*)
- PERES = "divided" (from *peras*) and wordplay on "Persia" (*Paras*)

**Belshazzar's Fall (5:29-31):**
"Then commanded Belshazzar, and they clothed Daniel with purple."

*Edayin amar Belshatstsar ve-albishu le-Dani'el argevana*—clothed.

"Put a chain of gold about his neck."

*Ve-hamnikah di-dahava al-tzavvareh*—gold chain.

"Made proclamation concerning him, that he should rule as one of three in the kingdom."

*Ve-hakrizו alohi di-leheve shallit talta be-malkhuta*—third ruler.

**The Key Verses (5:30-31):**
"In that night Belshazzar the Chaldean king was slain."

*Be-leilya bekh qetil Belshatstsar malka Kasda'ah*—slain that night.

"Darius the Mede received the kingdom."

*Ve-Daryavesh Madא'ah qabbel malkhuta*—Darius received.

"Being about threescore and two years old."

*Ke-var shniן shittin u-trein*—62 years old.

**Archetypal Layer:** Daniel 5 contains **Belshazzar's feast (5:1)**, **desecration of the Jerusalem temple vessels (5:2-3)**, **"fingers of a man's hand... wrote... upon the plaster of the wall" (5:5)**, **"the king's countenance was changed... his knees smote one against another" (5:6)**, **the queen remembers Daniel (5:10-12)**, **"you have not humbled your heart, though you knew all this" (5:22)**, **"the God in whose hand your breath is... have you not glorified" (5:23)**, **"MENE MENE TEKEL UPHARSIN" (5:25)**, and **"In that night Belshazzar the Chaldean king was slain" (5:30)**.

**Ethical Inversion Applied:**
- "Belshazzar the king made a great feast"—feast
- "Drank wine before the thousand"—drank
- "Commanded to bring the golden and silver vessels"—temple vessels
- "Which Nebuchadnezzar his father had taken out of the temple"—from Jerusalem
- "The king and his lords... drank in them"—drank in sacred vessels
- "They drank wine, and praised the gods of gold, and of silver"—idolatry
- "In the same hour came forth fingers of a man's hand"—fingers appeared
- "Wrote over against the candlestick upon the plaster of the wall"—wrote on wall
- "The king saw the part of the hand that wrote"—saw hand
- "The king's countenance was changed"—terrified
- "His knees smote one against another"—knees knocked
- "'Whosoever shall read this writing'"—challenge
- "'Shall be clothed with purple'"—reward
- "They could not read the writing"—wise men failed
- "The queen... came into the banquet house"—queen enters
- "'There is a man in your kingdom, in whom is the spirit of the holy gods'"—Daniel remembered
- "'Let Daniel be called'"—call Daniel
- "'Are you that Daniel... of the captivity of Judah?'"—captive
- "'Let your gifts be to yourself'"—rejects rewards
- "'The Most High God gave Nebuchadnezzar your father the kingdom'"—God gave
- "'All the peoples... trembled and feared before him'"—feared
- "'When his heart was lifted up'"—pride
- "'He was deposed from his kingly throne'"—deposed
- "'He was driven from the sons of men'"—driven out
- "'Until he knew that the Most High God rules'"—till he knew
- "'You his son... have not humbled your heart'"—not humbled
- "'Though you knew all this'"—knew but ignored
- "'You have lifted up yourself against the Lord of heaven'"—against God
- "'You have praised the gods... which see not, nor hear, nor know'"—dead idols
- "'The God in whose hand your breath is... have you not glorified'"—didn't glorify
- "'This is the writing: MENE MENE TEKEL UPHARSIN'"—the words
- "'MENE—God has numbered your kingdom'"—numbered
- "'TEKEL—you are weighed... found wanting'"—found wanting
- "'PERES—your kingdom is divided'"—divided
- "They clothed Daniel with purple"—rewarded
- "In that night Belshazzar the Chaldean king was slain"—slain
- "Darius the Mede received the kingdom"—Medo-Persian conquest

**Modern Equivalent:** Daniel 5 depicts the fall of Babylon. Belshazzar's sacrilege (drinking from temple vessels while praising idols) seals his fate. "MENE MENE TEKEL UPHARSIN" has become proverbial for divine judgment. Unlike Nebuchadnezzar who learned, Belshazzar "knew all this" (5:22) but refused to humble himself. Historical note: Babylon fell to Cyrus in 539 BCE.

# Lamentations 5: A Prayer for Restoration

*From the Hebrew: זְכֹר יְהוָה (Zekhor YHWH) — Remember, O YHWH*

---

## The Community's Prayer (5:1-22)

**5:1** Remember, O YHWH, what is come upon us; behold, and see our reproach.

**5:2** Our inheritance is turned unto strangers, our houses unto aliens.

**5:3** We are become orphans and fatherless, our mothers are as widows.

**5:4** We have drunk our water for money; our wood comes to us for price.

**5:5** To our very necks we are pursued; we labor, and have no rest.

**5:6** We have given the hand to Egypt, and to Assyria, to have bread enough.

**5:7** Our fathers have sinned, and are not; and we have borne their iniquities.

**5:8** Servants rule over us; there is none to deliver us out of their hand.

**5:9** We get our bread with the peril of our lives, because of the sword of the wilderness.

**5:10** Our skin is hot like an oven, because of the burning heat of famine.

**5:11** They have ravished the women in Zion, the maidens in the cities of Judah.

**5:12** Princes are hanged up by their hand; the faces of elders are not honored.

**5:13** The young men have borne the mill, and the children have stumbled under the wood.

**5:14** The elders have ceased from the gate, the young men from their music.

**5:15** The joy of our heart is ceased; our dance is turned into mourning.

**5:16** The crown is fallen from our head; woe unto us! For we have sinned.

**5:17** For this our heart is faint, for these things our eyes are dim;

**5:18** For the mountain of Zion, which is desolate, the foxes walk upon it.

**5:19** You, O YHWH, are enthroned forever, your throne is from generation to generation.

**5:20** Wherefore do you forget us forever, and forsake us so long time?

**5:21** Turn us unto you, O YHWH, and we shall be turned; renew our days as of old.

**5:22** For you have utterly rejected us; you are very wroth against us.

---

## Synthesis Notes

**Key Restorations:**

**Structure:**
Lamentations 5 is **not** an acrostic, though it has 22 verses (matching the Hebrew alphabet). It is a communal prayer/lament.

**Opening Plea (5:1-5):**
**The Key Verse (5:1):**
"Remember, O YHWH, what is come upon us."

*Zekhor YHWH meh-hayah lanu*—remember.

"Behold, and see our reproach."

*Habbittah u-re'eh et-cherpatenu*—see reproach.

**The Key Verse (5:2):**
"Our inheritance is turned unto strangers."

*Nachalatenu nehefkhah le-zarim*—inheritance to strangers.

"Our houses unto aliens."

*Battenu le-nokrim*—houses to foreigners.

**The Key Verse (5:3):**
"We are become orphans and fatherless."

*Yetomim hayinu ein av*—orphans.

"Our mothers are as widows."

*Immotenu ke-almanot*—mothers like widows.

**The Key Verse (5:4):**
"We have drunk our water for money."

*Memenu be-khesef shatinu*—water for money.

"Our wood comes to us for price."

*Etzenu bi-mechir yavo'u*—wood for price.

**The Key Verse (5:5):**
"To our very necks we are pursued."

*Al-tzavvarenu nirdafnu*—pursued.

"We labor, and have no rest."

*Yaga'nu lo hunach lanu*—no rest.

**Alliance and Sin (5:6-10):**
**The Key Verse (5:6):**
"We have given the hand to Egypt."

*Mitzrayim natanu yad*—hand to Egypt.

"And to Assyria."

*Ashshur*—Assyria.

"To have bread enough."

*Lisbo'a lachem*—for bread.

**Alliances:**
Political alliances with Egypt and Assyria for survival.

**The Key Verse (5:7):**
"Our fathers have sinned, and are not."

*Avotenu chat'u einam*—fathers sinned, gone.

"We have borne their iniquities."

*Va-anachnu avonoteihem savalnu*—we bear.

**Intergenerational:**
This verse doesn't deny personal responsibility (cf. 5:16) but acknowledges inherited consequences.

**The Key Verse (5:8):**
"Servants rule over us."

*Avadim mashlu vanu*—servants rule.

"There is none to deliver us out of their hand."

*Poreq me-yadam ein*—no deliverer.

**Role Reversal:**
The conquered now ruled by Babylonian officials (former "servants").

**The Key Verse (5:9):**
"We get our bread with the peril of our lives."

*Be-nafshenu navi lachmenu*—bread at life-risk.

"Because of the sword of the wilderness."

*Mippenei cherev ha-midbar*—wilderness sword.

**The Key Verse (5:10):**
"Our skin is hot like an oven."

*Orenu ke-tannur nichmaru*—skin hot.

"Because of the burning heat of famine."

*Mippenei zal'afot ra'av*—famine heat.

**Atrocities (5:11-14):**
**The Key Verse (5:11):**
"They have ravished the women in Zion."

*Nashim be-Tziyyon innu*—women ravished.

"The maidens in the cities of Judah."

*Betulot be-arei Yehudah*—maidens.

**The Key Verse (5:12):**
"Princes are hanged up by their hand."

*Sarim be-yadam nitlu*—princes hanged.

"The faces of elders are not honored."

*Penei zeqenim lo nehdaru*—elders dishonored.

**The Key Verse (5:13):**
"The young men have borne the mill."

*Bachurim techon nasa'u*—young men grinding.

"The children have stumbled under the wood."

*U-ne'arim ba-etz kashalu*—children stumble.

**Forced Labor:**
Grinding was women's work—humiliating for young men. Children carried heavy wood.

**The Key Verse (5:14):**
"The elders have ceased from the gate."

*Zeqenim mi-sha'ar shavatu*—elders ceased.

"The young men from their music."

*Bachurim mi-neginatam*—music stopped.

**Loss of Joy (5:15-18):**
**The Key Verse (5:15):**
"The joy of our heart is ceased."

*Shavat mesos libbenu*—joy ceased.

"Our dance is turned into mourning."

*Nehpakh le-evel mecholenu*—dance to mourning.

**The Key Verse (5:16):**
"The crown is fallen from our head."

*Nafelah ateret roshenu*—crown fallen.

"Woe unto us! For we have sinned."

*Oy-na lanu ki chata'nu*—woe, we sinned.

**Confession:**
Personal responsibility acknowledged.

**The Key Verse (5:17):**
"For this our heart is faint."

*Al-zeh hayah daveh libbenu*—heart faint.

"For these things our eyes are dim."

*Al-elleh chashechu einenu*—eyes dim.

**The Key Verse (5:18):**
"For the mountain of Zion, which is desolate."

*Al-har Tziyyon she-shamem*—Zion desolate.

"The foxes walk upon it."

*Shu'alim hilekhu-vo*—foxes walk.

**Final Prayer (5:19-22):**
**The Key Verse (5:19):**
"You, O YHWH, are enthroned forever."

*Attah YHWH le-olam teshev*—enthroned forever.

"Your throne is from generation to generation."

*Kis'akha le-dor va-dor*—generation to generation.

**Eternal Throne:**
Despite Jerusalem's fall, YHWH's throne endures.

**The Key Verse (5:20):**
"Wherefore do you forget us forever?"

*Lammah la-netzach tishkachenu*—why forget?

"And forsake us so long time?"

*Ta'azvenu le-orekh yamim*—forsake long.

**The Key Verse (5:21):**
"Turn us unto you, O YHWH, and we shall be turned."

*Hashivenu YHWH elekha ve-nashuvah*—turn us, we'll turn.

"Renew our days as of old."

*Chaddesh yamenu ke-qedem*—renew days.

**Central Prayer:**
"Turn us... and we shall be turned" acknowledges that repentance itself requires divine initiative.

**The Key Verse (5:22):**
"For you have utterly rejected us."

*Ki im-ma'os me'astanu*—utterly rejected.

"You are very wroth against us."

*Qatzafta aleinu ad-me'od*—very wroth.

**Ambiguous Ending:**
The book ends on this dark note. In synagogue reading, 5:21 is repeated after 5:22 to end on hope.

**Archetypal Layer:** Lamentations 5 is a **communal prayer**, containing **"Remember, O YHWH, what is come upon us" (5:1)**, **"Our fathers have sinned... and we have borne their iniquities" (5:7)**, **"The crown is fallen from our head; woe unto us! For we have sinned" (5:16)**, **"You, O YHWH, are enthroned forever" (5:19)**, and **"Turn us unto you, O YHWH, and we shall be turned; renew our days as of old" (5:21)**.

**Ethical Inversion Applied:**
- "Remember, O YHWH, what is come upon us"—remember
- "Behold, and see our reproach"—see reproach
- "Our inheritance is turned unto strangers"—inheritance lost
- "Our houses unto aliens"—houses taken
- "We are become orphans and fatherless"—orphans
- "Our mothers are as widows"—like widows
- "We have drunk our water for money"—pay for water
- "Our wood comes to us for price"—pay for wood
- "To our very necks we are pursued"—pursued
- "We labor, and have no rest"—no rest
- "We have given the hand to Egypt, and to Assyria"—alliances
- "To have bread enough"—for survival
- "Our fathers have sinned, and are not"—fathers sinned
- "We have borne their iniquities"—we bear
- "Servants rule over us"—servants rule
- "There is none to deliver us"—no deliverer
- "We get our bread with the peril of our lives"—dangerous bread
- "Our skin is hot like an oven"—famine fever
- "They have ravished the women in Zion"—women ravished
- "Princes are hanged up by their hand"—princes hanged
- "The faces of elders are not honored"—elders dishonored
- "The young men have borne the mill"—forced labor
- "The children have stumbled under the wood"—children burdened
- "The elders have ceased from the gate"—gate empty
- "The young men from their music"—music stopped
- "The joy of our heart is ceased"—joy ceased
- "Our dance is turned into mourning"—mourning
- "The crown is fallen from our head"—crown fallen
- "Woe unto us! For we have sinned"—confession
- "For this our heart is faint"—faint heart
- "For the mountain of Zion, which is desolate"—Zion desolate
- "The foxes walk upon it"—foxes on Zion
- "You, O YHWH, are enthroned forever"—eternal throne
- "Your throne is from generation to generation"—enduring
- "Wherefore do you forget us forever?"—why forget?
- "Forsake us so long time?"—why forsake?
- "Turn us unto you, O YHWH, and we shall be turned"—turn us
- "Renew our days as of old"—renew days
- "For you have utterly rejected us"—rejected
- "You are very wroth against us"—very wroth

**Modern Equivalent:** Lamentations 5 is a communal prayer for restoration. "Turn us... and we shall be turned" (5:21) recognizes that even repentance requires grace. The book ends darkly (5:22), reflecting raw grief. Jewish tradition repeats 5:21 after reading 5:22 to end on hope. "You, O YHWH, are enthroned forever" (5:19) anchors faith despite devastation.

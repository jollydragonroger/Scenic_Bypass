# Lamentations 1: The Desolation of Jerusalem

*From the Hebrew: אֵיכָה (Eikhah) — How!*

---

## Aleph (א) — Jerusalem's Loneliness (1:1-11)

**1:1** (א) How does the city sit solitary, that was full of people! How is she become as a widow! She that was great among the nations, and princess among the provinces, how is she become tributary!

**1:2** (ב) She weeps sore in the night, and her tears are on her cheeks; she has none to comfort her among all her lovers; all her friends have dealt treacherously with her, they are become her enemies.

**1:3** (ג) Judah is gone into exile because of affliction, and because of great servitude; she dwells among the nations, she finds no rest; all her pursuers overtook her within the straits.

**1:4** (ד) The ways of Zion do mourn, because none come to the solemn assembly; all her gates are desolate, her priests sigh; her virgins are afflicted, and she herself is in bitterness.

**1:5** (ה) Her adversaries are become the head, her enemies are at ease; for YHWH has afflicted her for the multitude of her transgressions; her young children are gone into captivity before the adversary.

**1:6** (ו) And from the daughter of Zion all her splendor is departed; her princes are become like harts that find no pasture, and they are gone without strength before the pursuer.

**1:7** (ז) Jerusalem remembers in the days of her affliction and of her anguish all her treasures that she had from the days of old; when her people fell into the hand of the adversary, and none did help her, the adversaries saw her, they did mock at her desolations.

**1:8** (ח) Jerusalem has grievously sinned, therefore she is become as one unclean; all that honored her despise her, because they have seen her nakedness; yea, she herself sighs, and turns backward.

**1:9** (ט) Her filthiness was in her skirts, she was not mindful of her end; therefore is she come down wonderfully, she has no comforter. Behold, O YHWH, my affliction, for the enemy has magnified himself.

**1:10** (י) The adversary has spread out his hand upon all her treasures; for she has seen that the nations are entered into her sanctuary, concerning whom you did command that they should not enter into your assembly.

**1:11** (כ) All her people sigh, they seek bread; they have given their treasures for food to refresh the soul. See, O YHWH, and behold, how abject I am become.

---

## Lamedh (ל) — Jerusalem's Cry (1:12-22)

**1:12** (ל) "Is it nothing to you, all you that pass by? Behold, and see if there be any pain like unto my pain, which is done unto me, wherewith YHWH has afflicted me in the day of his fierce anger.

**1:13** (מ) "From on high has he sent fire into my bones, and it prevails against them; he has spread a net for my feet, he has turned me back; he has made me desolate and faint all the day.

**1:14** (נ) "The yoke of my transgressions is bound by his hand; they are knit together, they are come up upon my neck; he has made my strength to fail; the Lord has delivered me into their hands, against whom I am not able to stand.

**1:15** (ס) "The Lord has set at nought all my mighty men in the midst of me; he has called a solemn assembly against me to crush my young men; the Lord has trodden as in a winepress the virgin daughter of Judah.

**1:16** (ע) "For these things I weep; my eye, my eye runs down with water; because the comforter that should refresh my soul is far from me; my children are desolate, because the enemy has prevailed."

**1:17** (פ) Zion spreads forth her hands; there is none to comfort her; YHWH has commanded concerning Jacob, that they that are round about him should be his adversaries; Jerusalem is become as one unclean among them.

**1:18** (צ) "YHWH is righteous; for I have rebelled against his word; hear, I pray you, all peoples, and behold my pain; my virgins and my young men are gone into captivity.

**1:19** (ק) "I called for my lovers, but they deceived me; my priests and my elders perished in the city, while they sought them food to refresh their souls.

**1:20** (ר) "See, O YHWH, for I am in distress, my bowels burn; my heart is turned within me, for I have grievously rebelled. Abroad the sword bereaves, at home there is as death.

**1:21** (ש) "They have heard that I sigh, there is none to comfort me; all my enemies have heard of my trouble, they are glad, for you have done it; O bring the day that you have proclaimed, and let them be as I am.

**1:22** (ת) "Let all their wickedness come before you; and do unto them, as you have done unto me for all my transgressions; for my sighs are many, and my heart is faint."

---

## Synthesis Notes

**Key Restorations:**

**Acrostic Structure:**
Lamentations 1 is an alphabetic acrostic—each verse begins with successive letters of the Hebrew alphabet (22 verses = 22 letters).

**Title (1:1):**
"How!"

*Eikhah*—the book's Hebrew title.

**The Key Verse (1:1):**
"How does the city sit solitary."

*Eikhah yashvah vadad ha-ir*—solitary.

"That was full of people!"

*Rabbati am*—was full.

"How is she become as a widow!"

*Hayetah ke-almanah*—like widow.

"She that was great among the nations."

*Rabbati va-goyim*—great among nations.

"Princess among the provinces."

*Sarati ba-medinot*—princess of provinces.

"How is she become tributary!"

*Hayetah la-mas*—forced labor.

**The Key Verse (1:2):**
"She weeps sore in the night."

*Bakho tivkeh ba-laylah*—weeps at night.

"Her tears are on her cheeks."

*Ve-dim'atah al lecheyah*—tears on cheeks.

"She has none to comfort her among all her lovers."

*Ein-lah menachem mi-kol-ohaveyha*—no comforter.

"All her friends have dealt treacherously with her."

*Kol-re'eyha bagdu vah*—friends betrayed.

"They are become her enemies."

*Hayu lah le-oyvim*—became enemies.

**Judah's Exile (1:3):**
"Judah is gone into exile because of affliction."

*Galetah Yehudah me-oni*—exile from affliction.

"Because of great servitude."

*U-me-rov avodah*—great servitude.

"She dwells among the nations."

*Hi yashvah va-goyim*—among nations.

"She finds no rest."

*Lo matzah mano'ach*—no rest.

"All her pursuers overtook her within the straits."

*Kol-rodefeyha hissiguha bein ha-metzarim*—overtaken.

**Zion Mourns (1:4-6):**
"The ways of Zion do mourn."

*Darkhei Tziyyon avelot*—Zion's ways mourn.

"Because none come to the solemn assembly."

*Mi-beli ba'ei mo'ed*—no festival pilgrims.

"All her gates are desolate."

*Kol-she'areyha shomemim*—gates desolate.

"Her priests sigh."

*Kohaneyha ne'enachim*—priests sigh.

"Her virgins are afflicted."

*Betuloteyha nugot*—virgins afflicted.

"She herself is in bitterness."

*Ve-hi mar-lah*—bitter.

**The Key Verse (1:5):**
"Her adversaries are become the head."

*Hayu tzareyha le-rosh*—adversaries head.

"Her enemies are at ease."

*Oyveyha shalu*—enemies at ease.

"For YHWH has afflicted her for the multitude of her transgressions."

*Ki-YHWH hogah al-rov pesha'eyha*—YHWH afflicted.

"Her young children are gone into captivity."

*Olaleyha halakhu shevi*—children captive.

**The Key Verse (1:8):**
"Jerusalem has grievously sinned."

*Cheit chatah Yerushalayim*—sinned greatly.

"Therefore she is become as one unclean."

*Al-ken le-nidah hayatah*—unclean.

"All that honored her despise her."

*Kol-mekhabbedeyha hizziluha*—despised.

"Because they have seen her nakedness."

*Ki-ra'u ervatah*—nakedness seen.

"She herself sighs, and turns backward."

*Gam-hi ne'enchah va-tashav achor*—sighs.

**Jerusalem's Cry (1:12-22):**
**The Key Verse (1:12):**
"Is it nothing to you, all you that pass by?"

*Lo aleikhem kol-overei derekh*—to passers-by.

"Behold, and see if there be any pain like unto my pain."

*Habbitu u-re'u im-yesh makh'ov ke-makh'ovi*—any pain like mine?

"Which is done unto me."

*Asher olal li*—done to me.

"Wherewith YHWH has afflicted me in the day of his fierce anger."

*Asher hogah YHWH be-yom charon appo*—fierce anger.

**The Key Verse (1:14):**
"The yoke of my transgressions is bound by his hand."

*Nisqad ol pesha'ai be-yado*—yoke bound.

"They are knit together."

*Yistarequ*—knit together.

"They are come up upon my neck."

*Alu al-tzavvari*—upon neck.

"He has made my strength to fail."

*Hikhshil kochi*—strength failed.

"The Lord has delivered me into their hands."

*Netanani Adonai bi-ydei*—delivered.

"Against whom I am not able to stand."

*Lo-ukhal qum*—can't stand.

**The Key Verse (1:15):**
"The Lord has set at nought all my mighty men."

*Sillah khol-abbirai Adonai*—mighty rejected.

"He has called a solemn assembly against me."

*Qara alai mo'ed*—assembly against me.

"To crush my young men."

*Lishbor bachurai*—crush young men.

"The Lord has trodden as in a winepress the virgin daughter of Judah."

*Gat darakh Adonai li-vtulat bat-Yehudah*—winepress.

**The Key Verse (1:16):**
"For these things I weep."

*Al-elleh ani vokhiyyah*—I weep.

"My eye, my eye runs down with water."

*Eini eini yordah mayim*—tears flow.

"The comforter that should refresh my soul is far from me."

*Ki-rachaq mimmeni menachem meshiv nafshi*—comforter far.

"My children are desolate."

*Hayu vanai shomemim*—children desolate.

"The enemy has prevailed."

*Ki gavar oyev*—enemy prevailed.

**The Key Verse (1:18):**
"YHWH is righteous."

*Tzaddiq hu YHWH*—YHWH righteous.

"For I have rebelled against his word."

*Ki fihu mariti*—I rebelled.

"Hear, I pray you, all peoples, and behold my pain."

*Shim'u-na khol-ammim u-re'u makh'ovi*—hear, peoples.

"My virgins and my young men are gone into captivity."

*Betulotai u-vachurai halakhu ba-shevi*—captive.

**The Key Verse (1:20):**
"See, O YHWH, for I am in distress."

*Re'eh YHWH ki-tzar-li*—see my distress.

"My bowels burn."

*Me'ai chomarmaru*—bowels churning.

"My heart is turned within me."

*Nehpakh libbi be-qirbi*—heart turned.

"I have grievously rebelled."

*Ki maro mariti*—grievously rebelled.

"Abroad the sword bereaves, at home there is as death."

*Mi-chutz shikkelah-cherev ba-bayit ka-mavet*—sword outside, death inside.

**The Key Verse (1:21):**
"They have heard that I sigh."

*Sham'u ki ne'enachah ani*—heard sighing.

"There is none to comfort me."

*Ein menachem li*—no comforter.

"All my enemies have heard of my trouble, they are glad."

*Kol-oyvai sham'u ra'ati sasu*—enemies glad.

"For you have done it."

*Ki attah asita*—YHWH did it.

"O bring the day that you have proclaimed."

*Heveta yom-qarata*—bring day.

"Let them be as I am."

*Ve-yihyu khamoni*—let them be like me.

**Archetypal Layer:** Lamentations 1 is an **alphabetic acrostic** mourning Jerusalem's fall, containing **"How does the city sit solitary" (1:1)**, **"Is it nothing to you, all you that pass by?" (1:12)**, **"YHWH is righteous; for I have rebelled" (1:18)**, and **the refrain "there is none to comfort" (1:2, 9, 16, 17, 21)**.

**Ethical Inversion Applied:**
- "How does the city sit solitary"—*Eikhah*
- "That was full of people!"—was full
- "How is she become as a widow!"—like widow
- "Princess among the provinces"—former glory
- "How is she become tributary!"—now slave
- "She weeps sore in the night"—weeps
- "Her tears are on her cheeks"—tears
- "She has none to comfort her"—no comforter (refrain)
- "All her friends have dealt treacherously"—betrayed
- "Judah is gone into exile because of affliction"—exile
- "She dwells among the nations, she finds no rest"—no rest
- "The ways of Zion do mourn"—Zion mourns
- "Because none come to the solemn assembly"—no pilgrims
- "Her adversaries are become the head"—adversaries rule
- "For YHWH has afflicted her for the multitude of her transgressions"—cause
- "Jerusalem has grievously sinned"—sinned
- "Therefore she is become as one unclean"—unclean
- "Is it nothing to you, all you that pass by?"—appeal
- "Behold, and see if there be any pain like unto my pain"—unparalleled pain
- "Wherewith YHWH has afflicted me in the day of his fierce anger"—fierce anger
- "The yoke of my transgressions is bound"—yoke
- "The Lord has trodden as in a winepress"—winepress
- "My eye, my eye runs down with water"—tears
- "The comforter that should refresh my soul is far from me"—comforter far
- "YHWH is righteous; for I have rebelled"—confession
- "See, O YHWH, for I am in distress"—plea
- "Abroad the sword bereaves, at home there is as death"—death everywhere
- "All my enemies have heard of my trouble, they are glad"—enemies glad
- "For you have done it"—YHWH's action
- "Let all their wickedness come before you"—plea for justice

**Modern Equivalent:** Lamentations 1 mourns Jerusalem's destruction (586 BCE). The personification of the city as a widow and the refrain "none to comfort" dominate. The confession "YHWH is righteous; for I have rebelled" (1:18) acknowledges deserved judgment. "Is it nothing to you, all you that pass by?" (1:12) invites witness.

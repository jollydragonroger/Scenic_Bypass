# Lamentations 3: The Suffering Servant and Hope

*From the Hebrew: אֲנִי הַגֶּבֶר (Ani Ha-Gever) — I Am the Man*

---

## Aleph (א) — The Man's Affliction (3:1-21)

**3:1** (א) I am the man that has seen affliction by the rod of his wrath.

**3:2** (א) Me has he led and caused to walk in darkness and not in light.

**3:3** (א) Surely against me he turns his hand again and again all the day.

**3:4** (ב) My flesh and my skin has he worn out; he has broken my bones.

**3:5** (ב) He has built against me, and compassed me with gall and travail.

**3:6** (ב) He has made me to dwell in dark places, as those that have been long dead.

**3:7** (ג) He has hedged me about, that I cannot go forth; he has made my chain heavy.

**3:8** (ג) Yea, when I cry and call for help, he shuts out my prayer.

**3:9** (ג) He has enclosed my ways with hewn stone, he has made my paths crooked.

**3:10** (ד) He is unto me as a bear lying in wait, as a lion in secret places.

**3:11** (ד) He has turned aside my ways, and pulled me in pieces; he has made me desolate.

**3:12** (ד) He has bent his bow, and set me as a mark for the arrow.

**3:13** (ה) He has caused the arrows of his quiver to enter into my reins.

**3:14** (ה) I am become a derision to all my people, and their song all the day.

**3:15** (ה) He has filled me with bitterness, he has sated me with wormwood.

**3:16** (ו) He has also broken my teeth with gravel stones, he has covered me with ashes.

**3:17** (ו) And my soul is removed far off from peace, I forgot prosperity.

**3:18** (ו) And I said: "My strength is perished, and my expectation from YHWH."

**3:19** (ז) Remember my affliction and my misery, the wormwood and the gall.

**3:20** (ז) My soul has them still in remembrance, and is bowed down within me.

**3:21** (ז) This I recall to my mind, therefore have I hope.

---

## Cheth (ח) — YHWH's Faithfulness (3:22-39)

**3:22** (ח) Surely YHWH's mercies are not consumed, surely his compassions fail not.

**3:23** (ח) They are new every morning; great is your faithfulness.

**3:24** (ח) "YHWH is my portion," says my soul; "therefore will I hope in him."

**3:25** (ט) YHWH is good unto them that wait for him, to the soul that seeks him.

**3:26** (ט) It is good that a man should quietly wait for the salvation of YHWH.

**3:27** (ט) It is good for a man that he bear the yoke in his youth.

**3:28** (י) Let him sit alone and keep silence, because he has laid it upon him.

**3:29** (י) Let him put his mouth in the dust, if so be there may be hope.

**3:30** (י) Let him give his cheek to him that smites him, let him be filled full with reproach.

**3:31** (כ) For the Lord will not cast off forever.

**3:32** (כ) For though he cause grief, yet will he have compassion according to the multitude of his mercies.

**3:33** (כ) For he does not afflict willingly, nor grieve the children of men.

**3:34** (ל) To crush under foot all the prisoners of the earth,

**3:35** (ל) To turn aside the right of a man before the face of the Most High,

**3:36** (ל) To subvert a man in his cause, the Lord does not approve.

**3:37** (מ) Who is he that says, and it comes to pass, when the Lord commands it not?

**3:38** (מ) Out of the mouth of the Most High proceeds not evil and good?

**3:39** (מ) Wherefore does a living man complain, a strong man because of his sins?

---

## Nun (נ) — Call to Repentance (3:40-66)

**3:40** (נ) Let us search and try our ways, and return to YHWH.

**3:41** (נ) Let us lift up our heart with our hands unto God in the heavens.

**3:42** (נ) We have transgressed and have rebelled, and you have not pardoned.

**3:43** (ס) You have covered with anger and pursued us; you have slain unsparingly.

**3:44** (ס) You have covered yourself with a cloud, so that no prayer can pass through.

**3:45** (ס) You have made us as the offscouring and refuse in the midst of the peoples.

**3:46** (פ) All our enemies have opened their mouth wide against us.

**3:47** (פ) Terror and the pit are come upon us, desolation and destruction.

**3:48** (פ) My eye runs down with rivers of water, for the destruction of the daughter of my people.

**3:49** (ע) My eye pours down, and ceases not, without any intermission,

**3:50** (ע) Till YHWH look down, and behold from heaven.

**3:51** (ע) My eye affects my soul, because of all the daughters of my city.

**3:52** (צ) They have chased me sore like a bird, that are my enemies without cause.

**3:53** (צ) They have cut off my life in the dungeon, and have cast stones upon me.

**3:54** (צ) Waters flowed over my head; I said: "I am cut off."

**3:55** (ק) I called upon your name, O YHWH, out of the lowest dungeon.

**3:56** (ק) You heard my voice; hide not your ear at my sighing, at my cry.

**3:57** (ק) You drew near in the day that I called upon you; you said: "Fear not."

**3:58** (ר) O Lord, you have pleaded the causes of my soul; you have redeemed my life.

**3:59** (ר) O YHWH, you have seen my wrong; judge my cause.

**3:60** (ר) You have seen all their vengeance and all their devices against me.

**3:61** (ש) You have heard their reproach, O YHWH, and all their devices against me;

**3:62** (ש) The lips of those that rose up against me, and their muttering against me all the day.

**3:63** (ש) Behold you their sitting down, and their rising up; I am their song.

**3:64** (ת) Render unto them a recompense, O YHWH, according to the work of their hands.

**3:65** (ת) Give them hardness of heart, your curse unto them.

**3:66** (ת) Pursue them in anger and destroy them from under the heavens of YHWH.

---

## Synthesis Notes

**Key Restorations:**

**Acrostic Structure:**
Lamentations 3 is a triple acrostic—each letter gets three consecutive verses (66 verses = 22 × 3). This is the most elaborate acrostic in the book.

**The Man's Affliction (3:1-21):**
**The Key Verse (3:1):**
"I am the man that has seen affliction by the rod of his wrath."

*Ani ha-gever ra'ah oni be-shevet evrато*—I am the man.

**The Key Verses (3:2-3):**
"Me has he led and caused to walk in darkness and not in light."

*Oti nahag va-yolakh choshekh ve-lo-or*—darkness.

"Against me he turns his hand again and again all the day."

*Akh bi yashuv yahafokh yado kol-ha-yom*—hand against.

**The Key Verses (3:7-9):**
"He has hedged me about, that I cannot go forth."

*Gadar ba'adi ve-lo etze*—hedged in.

"He has made my chain heavy."

*Hikhbid nechoshti*—heavy chain.

"When I cry and call for help, he shuts out my prayer."

*Gam ki ezaq va-ashavea satam tefilllati*—prayer blocked.

"He has enclosed my ways with hewn stone."

*Gadar derakhav be-gazit*—enclosed.

"He has made my paths crooked."

*Netivotai ivvah*—crooked paths.

**The Key Verses (3:10-12):**
"He is unto me as a bear lying in wait."

*Dov orev hu li*—bear.

"As a lion in secret places."

*Aryeh be-mistarim*—lion.

"He has bent his bow, and set me as a mark for the arrow."

*Darakh qashto va-yatzziveni ka-mattara la-chetz*—target.

**The Key Verses (3:14-15):**
"I am become a derision to all my people."

*Hayiti sechoq le-khol-ammi*—derision.

"Their song all the day."

*Neginatam kol-ha-yom*—their song.

"He has filled me with bitterness."

*Hisbi'ani va-merorim*—bitterness.

"He has sated me with wormwood."

*Hirvani la'anah*—wormwood.

**The Key Verses (3:17-18):**
"My soul is removed far off from peace."

*Va-tiznach mi-shalom nafshi*—far from peace.

"I forgot prosperity."

*Nashiti tovah*—forgot good.

"I said: 'My strength is perished, and my expectation from YHWH.'"

*Va-omar avad nitzzchi ve-tochalti me-YHWH*—hope gone.

**The Key Verses (3:19-21):**
"Remember my affliction and my misery."

*Zekhor onyi u-merudi*—remember affliction.

"The wormwood and the gall."

*La'anah va-rosh*—wormwood, gall.

"My soul has them still in remembrance."

*Zakhor tizkhor*—still remembers.

"Is bowed down within me."

*Ve-tashoach alai nafshi*—bowed down.

**The Key Verse (3:21):**
"This I recall to my mind, therefore have I hope."

*Zot ashiv el-libbi al-ken ochil*—hope returns.

**YHWH's Faithfulness (3:22-39):**
**The Key Verses (3:22-24):**
"Surely YHWH's mercies are not consumed."

*Chasdei YHWH ki lo-tamnu*—mercies not consumed.

"Surely his compassions fail not."

*Ki lo-khalu rachamav*—compassions don't fail.

**The Key Verse (3:23):**
"They are new every morning."

*Chadashim la-beqarim*—new every morning.

"Great is your faithfulness."

*Rabbah emunatekha*—great faithfulness.

**The Key Verse (3:24):**
"'YHWH is my portion,' says my soul."

*Chelqi YHWH amerah nafshi*—YHWH my portion.

"'Therefore will I hope in him.'"

*Al-ken ochil lo*—hope in him.

**The Key Verses (3:25-27):**
"YHWH is good unto them that wait for him."

*Tov YHWH le-qovav*—good to waiters.

"To the soul that seeks him."

*Le-nefesh tidrreshennu*—to seekers.

"It is good that a man should quietly wait for the salvation of YHWH."

*Tov ve-yachil ve-dumam li-teshu'at YHWH*—good to wait.

"It is good for a man that he bear the yoke in his youth."

*Tov la-gever ki-yissa ol bi-ne'urav*—yoke in youth.

**The Key Verses (3:28-30):**
"Let him sit alone and keep silence."

*Yeshev badad ve-yiddom*—sit silent.

"Because he has laid it upon him."

*Ki natal alav*—laid upon.

"Let him put his mouth in the dust."

*Yitten be-afar pihu*—mouth in dust.

"If so be there may be hope."

*Ulai yesh tiqvah*—maybe hope.

"Let him give his cheek to him that smites him."

*Yitten le-makkehu lechi*—give cheek.

"Let him be filled full with reproach."

*Yisba be-cherpah*—filled with reproach.

**The Key Verses (3:31-33):**
"For the Lord will not cast off forever."

*Ki lo yiznach le-olam Adonai*—not forever.

"For though he cause grief, yet will he have compassion."

*Ki im-hogah ve-richam*—grief then compassion.

"According to the multitude of his mercies."

*Ke-rov chasadav*—multitude of mercies.

**The Key Verse (3:33):**
"For he does not afflict willingly."

*Ki lo innah mi-libbo*—not willingly.

"Nor grieve the children of men."

*Va-yageh venei-ish*—nor grieve.

**The Key Verses (3:34-36):**
"To crush under foot all the prisoners of the earth."

*Le-dakkei tachat raglav kol asirei-aretz*—crush prisoners.

"To turn aside the right of a man before the face of the Most High."

*Le-hattot mishpat-gever neged penei elyon*—turn aside right.

"To subvert a man in his cause, the Lord does not approve."

*Le-avvet adam be-rivo Adonai lo ra'ah*—Lord doesn't approve.

**The Key Verses (3:37-39):**
"Who is he that says, and it comes to pass, when the Lord commands it not?"

*Mi zeh amar va-tehi Adonai lo tzivvah*—who speaks without YHWH?

"Out of the mouth of the Most High proceeds not evil and good?"

*Mi-pi elyon lo tetze ha-ra'ot ve-ha-tov*—evil and good from Most High.

"Wherefore does a living man complain, a strong man because of his sins?"

*Mah-yit'onen adam chai gever al-chata'av*—why complain?

**Call to Repentance (3:40-66):**
**The Key Verses (3:40-42):**
"Let us search and try our ways, and return to YHWH."

*Nachpeshah derakeinu ve-nachqorah ve-nashuvah ad-YHWH*—search, return.

"Let us lift up our heart with our hands unto God in the heavens."

*Nissa levavenu el-kappayim el-El ba-shamayim*—lift hearts.

"We have transgressed and have rebelled, and you have not pardoned."

*Nachnu fashanu u-marinu attah lo salachta*—not pardoned.

**The Key Verses (3:43-45):**
"You have covered with anger and pursued us."

*Sakota be-af va-tirdfeinu*—covered, pursued.

"You have slain unsparingly."

*Haragta lo chamalta*—slain.

"You have covered yourself with a cloud, so that no prayer can pass through."

*Sakota ve-anan lakh mi-avor tefillah*—cloud blocks prayer.

"You have made us as the offscouring and refuse."

*Sechi u-ma'os tesimenu*—refuse.

**The Key Verses (3:52-54):**
"They have chased me sore like a bird."

*Tzod tzaduni ka-tzippor oyvai chinnam*—chased like bird.

"They have cut off my life in the dungeon."

*Tzamtu ba-bor chayyai*—dungeon.

"Have cast stones upon me."

*Va-yaddu even bi*—stones cast.

"Waters flowed over my head."

*Tzafu-mayim al-roshi*—waters over head.

"I said: 'I am cut off.'"

*Amarti nigzarti*—cut off.

**The Key Verses (3:55-57):**
"I called upon your name, O YHWH, out of the lowest dungeon."

*Qarati shimkha YHWH mi-bor tachtiyyot*—called from dungeon.

"You heard my voice."

*Qoli shamata*—heard.

"Hide not your ear at my sighing, at my cry."

*Al-ta'lem oznekha le-revachati le-shav'ati*—don't hide.

"You drew near in the day that I called upon you."

*Qaravta be-yom eqra'ekka*—drew near.

"You said: 'Fear not.'"

*Amarta al-tira*—fear not.

**The Key Verses (3:58-60):**
"O Lord, you have pleaded the causes of my soul."

*Ravta Adonai rivei nafshi*—pleaded cause.

"You have redeemed my life."

*Ga'alta chayyai*—redeemed.

"O YHWH, you have seen my wrong."

*Ra'ita YHWH avvatati*—seen wrong.

"Judge my cause."

*Shofttah mishpati*—judge.

"You have seen all their vengeance and all their devices against me."

*Ra'ita kol-niqmatam kol-machshevotam li*—seen vengeance.

**Archetypal Layer:** Lamentations 3 is the **theological center**, containing **"I am the man that has seen affliction" (3:1)**, **"Surely YHWH's mercies are not consumed... They are new every morning; great is your faithfulness" (3:22-23)**, **"YHWH is my portion" (3:24)**, **"He does not afflict willingly" (3:33)**, and **"Let us search and try our ways, and return to YHWH" (3:40)**.

**Ethical Inversion Applied:**
- "I am the man that has seen affliction"—suffering witness
- "Me has he led... in darkness and not in light"—darkness
- "Against me he turns his hand again and again"—hand against
- "My flesh and my skin has he worn out"—worn out
- "He has hedged me about, that I cannot go forth"—trapped
- "When I cry and call for help, he shuts out my prayer"—prayer blocked
- "He is unto me as a bear lying in wait, as a lion"—predator
- "He has bent his bow, and set me as a mark"—target
- "I am become a derision to all my people"—mocked
- "He has filled me with bitterness... with wormwood"—bitter
- "My soul is removed far off from peace"—far from peace
- "I said: 'My strength is perished'"—despair
- "This I recall to my mind, therefore have I hope"—hope returns
- "Surely YHWH's mercies are not consumed"—mercies endure
- "Surely his compassions fail not"—compassions fail not
- "They are new every morning"—new every morning
- "Great is your faithfulness"—great faithfulness
- "'YHWH is my portion,' says my soul"—YHWH my portion
- "YHWH is good unto them that wait for him"—good to waiters
- "It is good that a man should quietly wait"—good to wait
- "It is good for a man that he bear the yoke in his youth"—yoke good
- "Let him give his cheek to him that smites him"—give cheek
- "For the Lord will not cast off forever"—not forever
- "Though he cause grief, yet will he have compassion"—compassion after grief
- "He does not afflict willingly"—not willingly
- "The Lord does not approve"—of injustice
- "Let us search and try our ways, and return to YHWH"—search, return
- "We have transgressed and have rebelled"—confession
- "I called upon your name, O YHWH, out of the lowest dungeon"—called
- "You drew near in the day that I called upon you"—drew near
- "You said: 'Fear not'"—fear not
- "O Lord, you have pleaded the causes of my soul"—pleaded
- "You have redeemed my life"—redeemed

**Modern Equivalent:** Lamentations 3 is the theological heart. Despite 3:1-20's despair, 3:21-24 turns to hope. "Great is your faithfulness" (3:23) became a famous hymn. "He does not afflict willingly" (3:33) is crucial theology. The call to wait, submit, and return (3:25-40) offers a path through suffering.

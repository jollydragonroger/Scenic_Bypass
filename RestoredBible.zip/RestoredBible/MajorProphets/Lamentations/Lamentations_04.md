# Lamentations 4: The Horrors of the Siege

*From the Hebrew: אֵיכָה יוּעַם זָהָב (Eikhah Yu'am Zahav) — How Is the Gold Become Dim*

---

## Aleph (א) — The Degradation (4:1-11)

**4:1** (א) How is the gold become dim! How is the most fine gold changed! The hallowed stones are poured out at the head of every street.

**4:2** (ב) The precious sons of Zion, comparable to fine gold, how are they esteemed as earthen pitchers, the work of the hands of the potter!

**4:3** (ג) Even the jackals draw out the breast, they give suck to their young ones; the daughter of my people is become cruel, like the ostriches in the wilderness.

**4:4** (ד) The tongue of the sucking child cleaves to the roof of his mouth for thirst; the young children ask bread, and none breaks it unto them.

**4:5** (ה) They that did feed on dainties are desolate in the streets; they that were brought up in scarlet embrace dunghills.

**4:6** (ו) For the iniquity of the daughter of my people is greater than the sin of Sodom, that was overthrown as in a moment, and no hands fell upon her.

**4:7** (ז) Her princes were purer than snow, they were whiter than milk, they were more ruddy in body than rubies, their polishing was as of sapphire.

**4:8** (ח) Their visage is blacker than coal; they are not known in the streets; their skin is shriveled upon their bones; it is withered, it is become like a stick.

**4:9** (ט) They that are slain with the sword are better than they that are slain with hunger; for these pine away, stricken through, for want of the fruits of the field.

**4:10** (י) The hands of women full of compassion have sodden their own children; they were their food in the destruction of the daughter of my people.

**4:11** (כ) YHWH has accomplished his fury, he has poured out his fierce anger; and he has kindled a fire in Zion, which has devoured the foundations thereof.

---

## Lamedh (ל) — The Cause (4:12-20)

**4:12** (ל) The kings of the earth believed not, neither all the inhabitants of the world, that the adversary and the enemy would enter into the gates of Jerusalem.

**4:13** (מ) It is because of the sins of her prophets, and the iniquities of her priests, that have shed the blood of the just in the midst of her.

**4:14** (נ) They wander as blind men in the streets, they are polluted with blood, so that men cannot touch their garments.

**4:15** (ס) "Depart! Unclean!" they cried unto them, "Depart, depart, touch not!" When they fled away and wandered, men said among the nations: "They shall no more sojourn here."

**4:16** (פ) The anger of YHWH has divided them; he will no more regard them; they respected not the persons of the priests, they favored not the elders.

**4:17** (ע) As for us, our eyes do yet fail for our vain help; in our watching we have watched for a nation that could not save.

**4:18** (צ) They hunt our steps, that we cannot go in our broad places; our end is near, our days are fulfilled; for our end is come.

**4:19** (ק) Our pursuers were swifter than the eagles of the heaven; they chased us upon the mountains, they lay in wait for us in the wilderness.

**4:20** (ר) The breath of our nostrils, the anointed of YHWH, was taken in their pits; of whom we said: "Under his shadow we shall live among the nations."

---

## Shin (ש) — Edom's Judgment (4:21-22)

**4:21** (ש) Rejoice and be glad, O daughter of Edom, that dwells in the land of Uz; the cup shall pass over unto you also; you shall be drunken, and shall make yourself naked.

**4:22** (ת) Your iniquity is accomplished, O daughter of Zion; he will no more carry you away into captivity; he will visit your iniquity, O daughter of Edom; he will uncover your sins.

---

## Synthesis Notes

**Key Restorations:**

**Acrostic Structure:**
Lamentations 4 is an alphabetic acrostic (22 verses) with Pe (פ) and Ayin (ע) reversed as in chapter 2.

**Degradation (4:1-11):**
**The Key Verse (4:1):**
"How is the gold become dim!"

*Eikhah yu'am zahav*—gold dimmed.

"How is the most fine gold changed!"

*Yishneh ha-ketem ha-tov*—fine gold changed.

"The hallowed stones are poured out at the head of every street."

*Tishtapakhna avnei-qodesh be-rosh kol-chutzot*—holy stones scattered.

**The Key Verse (4:2):**
"The precious sons of Zion, comparable to fine gold."

*Benei Tziyyon ha-yeqarim ha-mesulla'im ba-paz*—precious sons.

"How are they esteemed as earthen pitchers."

*Eikhah nechshevu le-nivlei-cheres*—esteemed as clay.

"The work of the hands of the potter!"

*Ma'aseh yedei yotzer*—potter's work.

**The Key Verses (4:3-4):**
"Even the jackals draw out the breast, they give suck."

*Gam-tannim chalutzu shad heiniqqu gureihen*—jackals nurse.

"The daughter of my people is become cruel."

*Bat-ammi le-akhzar*—cruel.

"Like the ostriches in the wilderness."

*Ka-ye'enim ba-midbar*—like ostriches.

"The tongue of the sucking child cleaves to the roof of his mouth for thirst."

*Davaq leshon yoneq el-chikko ba-tzama*—thirst.

"The young children ask bread, and none breaks it unto them."

*Olelim sha'alu lechem pores ein lahem*—no bread.

**The Key Verse (4:5):**
"They that did feed on dainties are desolate in the streets."

*Ha-okhelim le-ma'adannim nashammu ba-chutzot*—desolate.

"They that were brought up in scarlet embrace dunghills."

*Ha-emmunim alei tola chibbequ ashpattot*—embrace dunghills.

**The Key Verse (4:6):**
"For the iniquity of the daughter of my people is greater than the sin of Sodom."

*Va-yigdal avon bat-ammi me-chattat Sedom*—greater than Sodom.

"That was overthrown as in a moment."

*Ha-hafukhah kemo-raga*—instant overthrow.

"No hands fell upon her."

*Ve-lo-chalu vah yadayim*—no lingering.

**Sodom Comparison:**
Jerusalem's prolonged siege was worse than Sodom's instant destruction.

**The Key Verses (4:7-8):**
"Her princes were purer than snow, they were whiter than milk."

*Zakku nezirekha mi-sheleg tzachu me-chalav*—pure, white.

"They were more ruddy in body than rubies."

*Ademu etzem mipeninim*—ruddy.

"Their polishing was as of sapphire."

*Sappir gizratam*—sapphire polishing.

"Their visage is blacker than coal."

*Chashakh mi-shechhor to'aram*—blacker than coal.

"They are not known in the streets."

*Lo nikru ba-chutzot*—unrecognizable.

"Their skin is shriveled upon their bones."

*Tzafad oram al-atzmam*—shriveled.

"It is withered, it is become like a stick."

*Yavesh hayah khe-etz*—like stick.

**The Key Verse (4:9):**
"They that are slain with the sword are better than they that are slain with hunger."

*Tovim hayu challilei-cherev me-challilei ra'av*—sword better.

"For these pine away, stricken through, for want of the fruits of the field."

*She-hem yazuvu medoqqarim mi-tenuvo't sadai*—hunger worse.

**The Key Verse (4:10):**
"The hands of women full of compassion have sodden their own children."

*Yedei nashim rachmaniyyot bishhelu yaldeihen*—mothers cook children.

"They were their food in the destruction of the daughter of my people."

*Hayu le-varot lamo be-shever bat-ammi*—their food.

**Cannibalism:**
The worst horror of siege—compassionate mothers eating their children.

**The Key Verse (4:11):**
"YHWH has accomplished his fury."

*Killah YHWH et-chamato*—fury accomplished.

"He has poured out his fierce anger."

*Shafakh charon appo*—anger poured.

"He has kindled a fire in Zion."

*Va-yatztzet esh be-Tziyyon*—fire kindled.

"Which has devoured the foundations thereof."

*Va-tokhal yesodoteyha*—foundations devoured.

**The Cause (4:12-20):**
**The Key Verse (4:12):**
"The kings of the earth believed not, neither all the inhabitants of the world."

*Lo he'eminu malkhei-eretz ve-khol yoshevei tevel*—kings disbelieved.

"That the adversary and the enemy would enter into the gates of Jerusalem."

*Ki yavo tzar ve-oyev be-sha'arei Yerushalayim*—enter gates.

**The Key Verse (4:13):**
"It is because of the sins of her prophets, and the iniquities of her priests."

*Me-chatto't nevi'eyha avonot kohaneyha*—prophets and priests.

"That have shed the blood of the just in the midst of her."

*Ha-shofkhim be-qirbah dam tzaddiqim*—shed just blood.

**The Key Verses (4:14-15):**
"They wander as blind men in the streets."

*Na'u ivrim ba-chutzot*—blind wandering.

"They are polluted with blood."

*Nego'alu ba-dam*—blood-polluted.

"So that men cannot touch their garments."

*Be-lo yukhlu yigge'u bi-levusheihem*—untouchable.

"'Depart! Unclean!' they cried unto them."

*Suru tame qare'u lamo*—unclean cry.

"'Depart, depart, touch not!'"

*Suru suru al-tigga'u*—depart.

"'They shall no more sojourn here.'"

*Lo yosifu lagur*—no more sojourn.

**The Key Verse (4:17):**
"Our eyes do yet fail for our vain help."

*Odeynu tikhenah einenu el-ezratenu hevel*—vain help.

"In our watching we have watched for a nation that could not save."

*Be-tzippiyyatenu tzippinu el-goy lo yoshia*—nation that couldn't save.

**Egypt:**
They watched for Egypt's help, but Egypt couldn't save.

**The Key Verses (4:18-19):**
"They hunt our steps, that we cannot go in our broad places."

*Tzadu tze'adenu mi-lekhet bi-rechovotenu*—hunted steps.

"Our end is near, our days are fulfilled."

*Qarav qitzzenu male'u yamenu*—end near.

"For our end is come."

*Ki-va qitzzenu*—end came.

"Our pursuers were swifter than the eagles of the heaven."

*Qallim hayu rodfenu mi-nishrei shamayim*—swifter than eagles.

"They chased us upon the mountains."

*Al-he-harim delaqunu*—chased on mountains.

"They lay in wait for us in the wilderness."

*Ba-midbar arevu lanu*—ambushed.

**The Key Verse (4:20):**
"The breath of our nostrils, the anointed of YHWH, was taken in their pits."

*Ruach appenu meshiach YHWH nilkad bi-shechitotam*—anointed captured.

"Of whom we said: 'Under his shadow we shall live among the nations.'"

*Asher amarnu be-tzillo nichyeh va-goyim*—hoped to live under.

**The Anointed:**
King Zedekiah—the anointed king captured.

**Edom's Judgment (4:21-22):**
**The Key Verse (4:21):**
"Rejoice and be glad, O daughter of Edom."

*Sisi ve-simchi bat-Edom*—rejoice Edom (ironic).

"That dwells in the land of Uz."

*Yoshevet be-eretz Utz*—in Uz.

"The cup shall pass over unto you also."

*Gam-alayikh ta'avor kos*—cup comes.

"You shall be drunken, and shall make yourself naked."

*Tishkeri ve-tit'ari*—drunk, naked.

**The Key Verse (4:22):**
"Your iniquity is accomplished, O daughter of Zion."

*Tam-avonekh bat-Tziyyon*—iniquity complete.

"He will no more carry you away into captivity."

*Lo yosif le-haglotekh*—no more exile.

"He will visit your iniquity, O daughter of Edom."

*Paqad avonekh bat-Edom*—visit Edom's sin.

"He will uncover your sins."

*Gillah al-chatto'tayikh*—uncover.

**Archetypal Layer:** Lamentations 4 describes **siege horrors**, containing **"How is the gold become dim" (4:1)**, **"The hands of women full of compassion have sodden their own children" (4:10)**, **"The iniquity of the daughter of my people is greater than... Sodom" (4:6)**, **"The breath of our nostrils, the anointed of YHWH, was taken" (4:20)**, and **judgment on Edom (4:21-22)**.

**Ethical Inversion Applied:**
- "How is the gold become dim!"—gold dimmed
- "The hallowed stones are poured out"—holy stones scattered
- "The precious sons of Zion, comparable to fine gold"—precious sons
- "How are they esteemed as earthen pitchers"—now clay
- "The daughter of my people is become cruel"—cruel
- "Like the ostriches in the wilderness"—abandoning young
- "The tongue of the sucking child cleaves... for thirst"—thirst
- "The young children ask bread, and none breaks it"—no bread
- "They that did feed on dainties are desolate"—desolate
- "They that were brought up in scarlet embrace dunghills"—dunghills
- "The iniquity of the daughter of my people is greater than... Sodom"—greater
- "Her princes were purer than snow"—former beauty
- "Their visage is blacker than coal"—now black
- "Their skin is shriveled upon their bones"—shriveled
- "They that are slain with the sword are better than they that are slain with hunger"—sword better
- "The hands of women full of compassion have sodden their own children"—cannibalism
- "They were their food"—horrible food
- "YHWH has accomplished his fury"—fury accomplished
- "He has kindled a fire in Zion"—fire
- "The kings of the earth believed not... that the adversary... would enter"—disbelieved
- "It is because of the sins of her prophets, and the iniquities of her priests"—prophets/priests
- "That have shed the blood of the just"—shed blood
- "They wander as blind men"—blind
- "They are polluted with blood"—polluted
- "'Depart! Unclean!'"—unclean cry
- "Our eyes do yet fail for our vain help"—vain help
- "We have watched for a nation that could not save"—Egypt failed
- "Our end is near, our days are fulfilled"—end near
- "Our pursuers were swifter than the eagles"—swift pursuers
- "The breath of our nostrils, the anointed of YHWH, was taken"—king captured
- "'Under his shadow we shall live'"—hoped
- "Rejoice and be glad, O daughter of Edom"—ironic
- "The cup shall pass over unto you also"—Edom's turn
- "Your iniquity is accomplished, O daughter of Zion"—complete
- "He will no more carry you away into captivity"—no more
- "He will visit your iniquity, O daughter of Edom"—Edom judged

**Modern Equivalent:** Lamentations 4 describes the worst siege horrors. Cannibalism (4:10) fulfills Deuteronomy 28:53-57. "Greater than Sodom" (4:6) means prolonged suffering was worse than instant destruction. The captured anointed (4:20) is Zedekiah. Hope emerges in 4:22—Zion's punishment ends, Edom's begins.

# Lamentations 2: YHWH's Anger Against Zion

*From the Hebrew: אֵיכָה יָעִיב (Eikhah Ya'iv) — How Has the Lord Covered with a Cloud*

---

## Aleph (א) — YHWH as Enemy (2:1-10)

**2:1** (א) How has the Lord covered the daughter of Zion with a cloud in his anger! He has cast down from heaven unto the earth the beauty of Israel, and has not remembered his footstool in the day of his anger.

**2:2** (ב) The Lord has swallowed up unsparingly all the habitations of Jacob; he has thrown down in his wrath the strongholds of the daughter of Judah; he has brought them down to the ground; he has profaned the kingdom and the princes thereof.

**2:3** (ג) He has cut off in fierce anger all the horn of Israel; he has drawn back his right hand from before the enemy; and he has burned in Jacob like a flaming fire, which devours round about.

**2:4** (ד) He has bent his bow like an enemy, he has stood with his right hand as an adversary, and has slain all that were pleasant to the eye; in the tent of the daughter of Zion he has poured out his fury like fire.

**2:5** (ה) The Lord is become as an enemy, he has swallowed up Israel; he has swallowed up all her palaces, he has destroyed his strongholds; and he has multiplied in the daughter of Judah mourning and moaning.

**2:6** (ו) And he has stripped his tabernacle, as if it were a garden, he has destroyed his place of assembly; YHWH has caused solemn assembly and sabbath to be forgotten in Zion, and has rejected in the indignation of his anger the king and the priest.

**2:7** (ז) The Lord has cast off his altar, he has abhorred his sanctuary; he has given up into the hand of the enemy the walls of her palaces; they have made a noise in the house of YHWH, as in the day of a solemn assembly.

**2:8** (ח) YHWH has purposed to destroy the wall of the daughter of Zion; he has stretched out the line, he has not withdrawn his hand from destroying; but he has made the rampart and wall to mourn, they languish together.

**2:9** (ט) Her gates are sunk into the ground; he has destroyed and broken her bars; her king and her princes are among the nations, instruction is no more; yea, her prophets find no vision from YHWH.

**2:10** (י) The elders of the daughter of Zion sit upon the ground, they keep silence; they have cast up dust upon their heads, they have girded themselves with sackcloth; the virgins of Jerusalem hang down their heads to the ground.

---

## Kaph (כ) — The Poet's Grief (2:11-19)

**2:11** (כ) My eyes do fail with tears, my bowels burn; my liver is poured upon the earth, because of the destruction of the daughter of my people, because the young children and the sucklings swoon in the broad places of the city.

**2:12** (ל) They say to their mothers: "Where is corn and wine?" when they swoon as the wounded in the broad places of the city, when their soul is poured out into their mothers' bosom.

**2:13** (מ) What shall I take to witness for you? What shall I liken to you, O daughter of Jerusalem? What shall I compare to you, that I may comfort you, O virgin daughter of Zion? For your breach is great like the sea; who can heal you?

**2:14** (נ) Your prophets have seen visions for you of vanity and delusion; and they have not uncovered your iniquity, to bring back your captivity; but have prophesied for you burdens of vanity and seduction.

**2:15** (ס) All that pass by clap their hands at you; they hiss and wag their head at the daughter of Jerusalem: "Is this the city that men called the perfection of beauty, the joy of the whole earth?"

**2:16** (פ) All your enemies have opened their mouth wide against you; they hiss and gnash the teeth; they say: "We have swallowed her up; certainly this is the day that we looked for; we have found, we have seen it."

**2:17** (ע) YHWH has done that which he devised; he has performed his word that he commanded in the days of old; he has thrown down unsparingly; and he has caused the enemy to rejoice over you, he has exalted the horn of your adversaries.

**2:18** (צ) Their heart cried unto the Lord: O wall of the daughter of Zion, let tears run down like a river day and night; give yourself no respite; let not the apple of your eye cease.

**2:19** (ק) Arise, cry out in the night, at the beginning of the watches; pour out your heart like water before the face of the Lord; lift up your hands toward him for the life of your young children, that faint for hunger at the head of every street.

---

## Resh (ר) — Zion's Plea (2:20-22)

**2:20** (ר) "See, O YHWH, and consider, to whom you have done thus! Shall the women eat their fruit, the children that are dandled in the hands? Shall the priest and the prophet be slain in the sanctuary of the Lord?

**2:21** (ש) "The youth and the old man lie on the ground in the streets; my virgins and my young men are fallen by the sword; you have slain them in the day of your anger; you have slaughtered unsparingly.

**2:22** (ת) "You have called, as in the day of a solemn assembly, my terrors on every side, and there was none in the day of YHWH's anger that escaped or remained; those that I have dandled and brought up has my enemy consumed."

---

## Synthesis Notes

**Key Restorations:**

**Acrostic Structure:**
Lamentations 2 is an alphabetic acrostic with a notable difference—Pe (פ) and Ayin (ע) are reversed (16-17).

**YHWH as Enemy (2:1-10):**
**The Key Verse (2:1):**
"How has the Lord covered the daughter of Zion with a cloud in his anger!"

*Eikhah ya'iv be-appo Adonai et-bat Tziyyon*—cloud of anger.

"He has cast down from heaven unto the earth the beauty of Israel."

*Hishlikh mi-shamayim eretz tif'eret Yisra'el*—cast down.

"Has not remembered his footstool in the day of his anger."

*Ve-lo-zakhar hadom-raglav be-yom appo*—forgot footstool (temple/ark).

**The Key Verse (2:2):**
"The Lord has swallowed up unsparingly all the habitations of Jacob."

*Billa Adonai lo chamal et kol-ne'ot Ya'aqov*—swallowed.

"He has thrown down in his wrath the strongholds of the daughter of Judah."

*Haras be-evrато mivtzerei vat-Yehudah*—thrown down.

"He has profaned the kingdom and the princes thereof."

*Chillel mamlakhah ve-sareyha*—profaned kingdom.

**The Key Verse (2:3):**
"He has cut off in fierce anger all the horn of Israel."

*Gada ba-chori-af kol qeren Yisra'el*—cut off horn.

"He has drawn back his right hand from before the enemy."

*Heshiv achor yemino mippenei oyev*—withdrew hand.

"He has burned in Jacob like a flaming fire."

*Va-yiv'ar be-Ya'aqov ke-esh lahavah*—burned.

**The Key Verse (2:4):**
"He has bent his bow like an enemy."

*Darakh qashto ke-oyev*—bow like enemy.

"He has stood with his right hand as an adversary."

*Nitztzav yemino ke-tzar*—hand as adversary.

"Has slain all that were pleasant to the eye."

*Va-yaharog kol machamaddei-ayin*—slain.

"He has poured out his fury like fire."

*Shafakh ka-esh chamato*—poured fury.

**The Key Verse (2:5):**
"The Lord is become as an enemy."

*Hayah Adonai ke-oyev*—Lord as enemy.

"He has swallowed up Israel."

*Billa Yisra'el*—swallowed Israel.

"He has swallowed up all her palaces."

*Billa kol-armenoteyha*—palaces.

"He has destroyed his strongholds."

*Shichit mivtzarav*—strongholds.

"He has multiplied in the daughter of Judah mourning and moaning."

*Va-yerev be-vat-Yehudah ta'aniyyah va-aniyyah*—mourning.

**The Key Verse (2:6):**
"He has stripped his tabernacle, as if it were a garden."

*Va-yachmos ke-gan sukko*—stripped tabernacle.

"He has destroyed his place of assembly."

*Shichit mo'ado*—destroyed assembly.

"YHWH has caused solemn assembly and sabbath to be forgotten in Zion."

*Shikhkhach YHWH be-Tziyyon mo'ed ve-shabbat*—forgotten.

"Has rejected in the indignation of his anger the king and the priest."

*Va-yin'atz be-za'am-appo melekh ve-khohen*—rejected.

**The Key Verse (2:7):**
"The Lord has cast off his altar."

*Zanach Adonai mizbecho*—cast off altar.

"He has abhorred his sanctuary."

*Ni'er miqddasho*—abhorred sanctuary.

"He has given up into the hand of the enemy the walls of her palaces."

*Hisgir be-yad-oyev chomot armenoteyha*—given to enemy.

"They have made a noise in the house of YHWH, as in the day of a solemn assembly."

*Qol natenu be-veit YHWH ke-yom mo'ed*—noise in temple.

**The Key Verse (2:9):**
"Her gates are sunk into the ground."

*Tave'u va-aretz she'areyha*—gates sunk.

"He has destroyed and broken her bars."

*Ibbed ve-shibbar bericheyha*—bars broken.

"Her king and her princes are among the nations."

*Malkah ve-sareyha va-goyim*—king/princes among nations.

"Instruction is no more."

*Ein torah*—no Torah.

"Her prophets find no vision from YHWH."

*Gam-nevi'eyha lo-matz'u chazon me-YHWH*—no vision.

**The Key Verse (2:10):**
"The elders of the daughter of Zion sit upon the ground."

*Yeshvu la-aretz yiddemu ziqnei vat-Tziyyon*—elders on ground.

"They keep silence."

*Yiddemu*—silent.

"They have cast up dust upon their heads."

*He'elu afar al-rosham*—dust on heads.

"They have girded themselves with sackcloth."

*Chageru saqqim*—sackcloth.

"The virgins of Jerusalem hang down their heads to the ground."

*Horidu la-aretz roshan betulot Yerushalayim*—heads down.

**Poet's Grief (2:11-19):**
**The Key Verse (2:11):**
"My eyes do fail with tears."

*Kalu va-dema'ot einai*—eyes fail.

"My bowels burn."

*Chomarmeru me'ai*—bowels burn.

"My liver is poured upon the earth."

*Nishpakh la-aretz kevedi*—liver poured.

"Because of the destruction of the daughter of my people."

*Al-shever bat-ammi*—destruction.

"The young children and the sucklings swoon in the broad places."

*Be-atef olel ve-yoneq bi-rechovot qiryah*—children faint.

**The Key Verse (2:12):**
"They say to their mothers: 'Where is corn and wine?'"

*Le-immotam yomeru ayyeh dagan va-yayin*—where is food?

"When they swoon as the wounded in the broad places."

*Be-hit'attfam ke-challal bi-rechovot ir*—swoon.

"When their soul is poured out into their mothers' bosom."

*Be-hishtapekh nafsham el-cheiq immotam*—dying in arms.

**The Key Verse (2:13):**
"What shall I take to witness for you?"

*Mah a'idekh*—what witness?

"What shall I liken to you, O daughter of Jerusalem?"

*Mah adammeh-lakh ha-bat Yerushalayim*—what comparison?

"What shall I compare to you, that I may comfort you?"

*Mah ashveh-lakh va-anachamekh*—what comfort?

"For your breach is great like the sea."

*Ki-gadol ka-yam shivrekh*—breach like sea.

"Who can heal you?"

*Mi yirpa-lakh*—who heals?

**The Key Verse (2:14):**
"Your prophets have seen visions for you of vanity and delusion."

*Nevi'ayikh chazu lakh shav ve-tafel*—false visions.

"They have not uncovered your iniquity."

*Ve-lo-gillu al-avonekh*—didn't expose sin.

"To bring back your captivity."

*Le-hashiv shevutekh*—restore captivity.

"But have prophesied for you burdens of vanity and seduction."

*Va-yechezu lakh massa'ot shav u-maduchim*—false oracles.

**The Key Verse (2:15):**
"All that pass by clap their hands at you."

*Safqu alayikh kappayim kol-overei derekh*—clap hands.

"They hiss and wag their head at the daughter of Jerusalem."

*Sharqu va-yani'u rosham al-bat Yerushalayim*—hiss, wag heads.

"'Is this the city that men called the perfection of beauty, the joy of the whole earth?'"

*Ha-zot ha-ir she-yomeru kelilat yofi masos le-khol-ha-aretz*—perfection of beauty.

**The Key Verse (2:17):**
"YHWH has done that which he devised."

*Asah YHWH asher zamam*—YHWH did what planned.

"He has performed his word that he commanded in the days of old."

*Bitza emrato asher tzivvah mi-yemei-qedem*—fulfilled word.

"He has thrown down unsparingly."

*Haras ve-lo chamal*—thrown down.

"He has caused the enemy to rejoice over you."

*Va-yesammach alayikh oyev*—enemy rejoices.

"He has exalted the horn of your adversaries."

*Herim qeren tzarayikh*—horn exalted.

**The Key Verse (2:19):**
"Arise, cry out in the night."

*Qumi ronni va-laylah*—arise, cry.

"At the beginning of the watches."

*Le-rosh ashmurot*—beginning of watches.

"Pour out your heart like water before the face of the Lord."

*Shifkhi kha-mayim libbakh nokhach penei Adonai*—pour heart.

"Lift up your hands toward him."

*Se'i elav kappayikh*—lift hands.

"For the life of your young children, that faint for hunger at the head of every street."

*Al-nefesh olelayikh ha-atufim be-ra'av be-rosh kol-chutzot*—children starving.

**Zion's Plea (2:20-22):**
**The Key Verse (2:20):**
"'See, O YHWH, and consider, to whom you have done thus!'"

*Re'eh YHWH ve-habbittah le-mi olalta koh*—see, consider.

"'Shall the women eat their fruit, the children that are dandled in the hands?'"

*Im-tokhalennah nashim piryam olelei tipu'chim*—cannibalism.

"'Shall the priest and the prophet be slain in the sanctuary of the Lord?'"

*Im-yehareg be-miqdash Adonai kohen ve-navi*—slain in sanctuary.

**The Key Verse (2:22):**
"'You have called, as in the day of a solemn assembly, my terrors on every side.'"

*Tiqra khe-yom mo'ed meguray missaviv*—terrors summoned.

"'There was none in the day of YHWH's anger that escaped or remained.'"

*Ve-lo hayah be-yom af-YHWH palit ve-sarid*—none escaped.

"'Those that I have dandled and brought up has my enemy consumed.'"

*Asher tiphphachti ve-ribbiti oyvei khillam*—enemy consumed.

**Archetypal Layer:** Lamentations 2 focuses on **YHWH as enemy (2:4-5)**, **"He has cast off his altar, he has abhorred his sanctuary" (2:7)**, **"Your breach is great like the sea; who can heal you?" (2:13)**, **"Your prophets have seen visions... of vanity" (2:14)**, and **"Shall the women eat their fruit?" (2:20)**—cannibalism during siege.

**Ethical Inversion Applied:**
- "How has the Lord covered the daughter of Zion with a cloud"—cloud of anger
- "He has cast down from heaven... the beauty of Israel"—cast down
- "Has not remembered his footstool"—forgot temple
- "The Lord has swallowed up unsparingly all the habitations"—swallowed
- "He has profaned the kingdom and the princes"—profaned
- "He has cut off... all the horn of Israel"—horn cut
- "He has drawn back his right hand from before the enemy"—withdrew protection
- "He has burned in Jacob like a flaming fire"—burned
- "He has bent his bow like an enemy"—bow bent
- "He has stood with his right hand as an adversary"—adversary
- "The Lord is become as an enemy"—Lord as enemy
- "He has swallowed up Israel"—swallowed
- "He has stripped his tabernacle, as if it were a garden"—stripped
- "YHWH has caused solemn assembly and sabbath to be forgotten"—forgotten
- "The Lord has cast off his altar"—altar rejected
- "He has abhorred his sanctuary"—sanctuary abhorred
- "Her gates are sunk into the ground"—gates sunk
- "Instruction is no more"—no Torah
- "Her prophets find no vision from YHWH"—no vision
- "The elders... sit upon the ground, they keep silence"—silent mourning
- "My eyes do fail with tears"—tears
- "The young children and the sucklings swoon"—children fainting
- "They say to their mothers: 'Where is corn and wine?'"—children asking
- "Your breach is great like the sea; who can heal you?"—incurable
- "Your prophets have seen visions... of vanity and delusion"—false prophets
- "They have not uncovered your iniquity"—didn't expose
- "'Is this the city that men called the perfection of beauty?'"—former glory
- "YHWH has done that which he devised"—YHWH planned
- "He has performed his word that he commanded in the days of old"—fulfilled warning
- "Pour out your heart like water before the face of the Lord"—pour heart
- "'Shall the women eat their fruit, the children?'"—cannibalism
- "'Shall the priest and the prophet be slain in the sanctuary?'"—sanctuary slaughter
- "'There was none... that escaped or remained'"—none escaped

**Modern Equivalent:** Lamentations 2 is the most shocking chapter—YHWH as enemy (2:4-5). The destruction is presented as YHWH's planned action (2:17). False prophets failed to expose sin (2:14). Cannibalism (2:20) reflects 2 Kings 6:28-29's siege horrors.

import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import { useAccount, useConnect, useDisconnect } from 'wagmi';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import { Broadcast, Shield, Network, TrendingUp, AlertTriangle, Users, Zap, Globe } from 'lucide-react';

// Contract ABI (simplified for demo)
const LIBERTY_CASCADE_ABI = [
  "function broadcastToTargets(address[] targets, string message, uint256 value) external returns (bytes32)",
  "function emergencyBroadcast(string message, uint256 priority) external returns (bytes32)",
  "function storeInformation(string content, string hash, uint256 value) external returns (bool)",
  "function retrieveInformation(string hash) external view returns (string content, uint256 value, uint256 timestamp)",
  "function getNetworkStats() external view returns (uint256 totalBroadcasts, uint256 totalValue, uint256 activeNodes, uint256 suppressionAttempts)",
  "event BroadcastInitiated(address indexed broadcaster, bytes32 indexed hash, uint256 value, uint256 timestamp)"
];

const CONTRACT_ADDRESS = "0x5B38Da6a701c568545dCfcB03FcB875f56beddC4";

const queryClient = new QueryClient();

function LibertyCascadeUI() {
  const { address, isConnected } = useAccount();
  const { connect, connectors } = useConnect();
  const { disconnect } = useDisconnect();
  
  const [provider, setProvider] = useState(null);
  const [contract, setContract] = useState(null);
  const [networkStats, setNetworkStats] = useState({
    totalBroadcasts: 0,
    totalValue: 0,
    activeNodes: 0,
    suppressionAttempts: 0
  });
  
  const [broadcastForm, setBroadcastForm] = useState({
    message: '',
    value: '',
    priority: '1',
    targets: [
      '0x220866B1a2219f40e72f5c628cA3A9D',
      '0x5AB26169051d0D96217949ADb91E86e51a5FDA74',
      '0xcafe1a77e84698c83ca8931f54a755176ef75f2c'
    ]
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [recentBroadcasts, setRecentBroadcasts] = useState([]);

  // Initialize provider and contract
  useEffect(() => {
    if (isConnected && window.ethereum) {
      const provider = new ethers.BrowserProvider(window.ethereum);
      setProvider(provider);
      
      const contract = new ethers.Contract(CONTRACT_ADDRESS, LIBERTY_CASCADE_ABI, provider);
      setContract(contract);
    }
  }, [isConnected]);

  // Fetch network stats
  useEffect(() => {
    const fetchNetworkStats = async () => {
      if (contract) {
        try {
          const stats = await contract.getNetworkStats();
          setNetworkStats({
            totalBroadcasts: stats[0].toString(),
            totalValue: ethers.formatEther(stats[1]),
            activeNodes: stats[2].toString(),
            suppressionAttempts: stats[3].toString()
          });
        } catch (error) {
          console.error('Error fetching network stats:', error);
        }
      }
    };

    fetchNetworkStats();
    const interval = setInterval(fetchNetworkStats, 10000); // Update every 10 seconds
    return () => clearInterval(interval);
  }, [contract]);

  // Listen for broadcast events
  useEffect(() => {
    if (contract) {
      contract.on('BroadcastInitiated', (broadcaster, hash, value, timestamp) => {
        const newBroadcast = {
          broadcaster,
          hash,
          value: ethers.formatEther(value),
          timestamp: new Date(Number(timestamp) * 1000).toLocaleString()
        };
        setRecentBroadcasts(prev => [newBroadcast, ...prev.slice(0, 9)]);
        toast.success('New broadcast detected!');
      });
    }

    return () => {
      if (contract) {
        contract.removeAllListeners();
      }
    };
  }, [contract]);

  const handleBroadcast = async (type = 'normal') => {
    if (!contract || !address) return;
    
    setIsLoading(true);
    try {
      const signer = await provider.getSigner();
      const contractWithSigner = contract.connect(signer);
      
      let tx;
      if (type === 'emergency') {
        tx = await contractWithSigner.emergencyBroadcast(
          broadcastForm.message,
          ethers.parseEther(broadcastForm.priority)
        );
      } else {
        tx = await contractWithSigner.broadcastToTargets(
          broadcastForm.targets,
          broadcastForm.message,
          ethers.parseEther(broadcastForm.value)
        );
      }
      
      toast.loading('Broadcasting...');
      await tx.wait();
      toast.dismiss();
      toast.success('Broadcast successful!');
      
      // Reset form
      setBroadcastForm({
        message: '',
        value: '',
        priority: '1',
        targets: broadcastForm.targets
      });
      
    } catch (error) {
      toast.dismiss();
      toast.error(`Broadcast failed: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStoreInformation = async () => {
    if (!contract || !address) return;
    
    setIsLoading(true);
    try {
      const signer = await provider.getSigner();
      const contractWithSigner = contract.connect(signer);
      
      const contentHash = ethers.keccak256(ethers.toUtf8Bytes(broadcastForm.message));
      
      const tx = await contractWithSigner.storeInformation(
        broadcastForm.message,
        contentHash,
        ethers.parseEther(broadcastForm.value)
      );
      
      toast.loading('Storing information...');
      await tx.wait();
      toast.dismiss();
      toast.success('Information stored successfully!');
      
    } catch (error) {
      toast.dismiss();
      toast.error(`Storage failed: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isConnected) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 max-w-md w-full border border-white/20">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <Globe className="w-16 h-16 text-purple-400" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Liberty Cascade</h1>
            <p className="text-purple-200">Decentralized Broadcast Network</p>
          </div>
          
          <div className="space-y-4">
            <button
              onClick={() => connect({ connector: connectors[0] })}
              className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-lg transition duration-200 flex items-center justify-center gap-2"
            >
              <Users className="w-5 h-5" />
              Connect Wallet
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <header className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Globe className="w-10 h-10 text-purple-400" />
              <h1 className="text-3xl font-bold text-white">Liberty Cascade</h1>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-purple-200">{address?.slice(0, 6)}...{address?.slice(-4)}</span>
              <button
                onClick={() => disconnect()}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition duration-200"
              >
                Disconnect
              </button>
            </div>
          </div>
        </header>

        {/* Network Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-200 text-sm">Total Broadcasts</p>
                <p className="text-2xl font-bold text-white">{networkStats.totalBroadcasts}</p>
              </div>
              <Broadcast className="w-8 h-8 text-purple-400" />
            </div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-200 text-sm">Total Value</p>
                <p className="text-2xl font-bold text-white">{parseFloat(networkStats.totalValue).toFixed(2)} ETH</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-400" />
            </div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-200 text-sm">Active Nodes</p>
                <p className="text-2xl font-bold text-white">{networkStats.activeNodes}</p>
              </div>
              <Network className="w-8 h-8 text-blue-400" />
            </div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-200 text-sm">Suppression Attempts</p>
                <p className="text-2xl font-bold text-white">{networkStats.suppressionAttempts}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-400" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Broadcast Form */}
          <div className="lg:col-span-2">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <Zap className="w-6 h-6 text-yellow-400" />
                Create Broadcast
              </h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-purple-200 mb-2">Message</label>
                  <textarea
                    value={broadcastForm.message}
                    onChange={(e) => setBroadcastForm({...broadcastForm, message: e.target.value})}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-purple-300 focus:outline-none focus:border-purple-400"
                    rows={6}
                    placeholder="Enter your broadcast message..."
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-purple-200 mb-2">Value (ETH)</label>
                    <input
                      type="number"
                      value={broadcastForm.value}
                      onChange={(e) => setBroadcastForm({...broadcastForm, value: e.target.value})}
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-purple-300 focus:outline-none focus:border-purple-400"
                      placeholder="0.1"
                      step="0.01"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-purple-200 mb-2">Priority (for emergency)</label>
                    <input
                      type="number"
                      value={broadcastForm.priority}
                      onChange={(e) => setBroadcastForm({...broadcastForm, priority: e.target.value})}
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-purple-300 focus:outline-none focus:border-purple-400"
                      placeholder="1"
                      min="1"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-purple-200 mb-2">Target Addresses</label>
                  <div className="space-y-2">
                    {broadcastForm.targets.map((target, index) => (
                      <input
                        key={index}
                        type="text"
                        value={target}
                        onChange={(e) => {
                          const newTargets = [...broadcastForm.targets];
                          newTargets[index] = e.target.value;
                          setBroadcastForm({...broadcastForm, targets: newTargets});
                        }}
                        className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-purple-300 focus:outline-none focus:border-purple-400"
                        placeholder="Target address"
                      />
                    ))}
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <button
                    onClick={() => handleBroadcast('normal')}
                    disabled={isLoading || !broadcastForm.message || !broadcastForm.value}
                    className="flex-1 bg-purple-600 hover:bg-purple-700 disabled:bg-purple-800 disabled:opacity-50 text-white font-semibold py-3 px-6 rounded-lg transition duration-200 flex items-center justify-center gap-2"
                  >
                    <Broadcast className="w-5 h-5" />
                    {isLoading ? 'Broadcasting...' : 'Broadcast'}
                  </button>
                  
                  <button
                    onClick={() => handleBroadcast('emergency')}
                    disabled={isLoading || !broadcastForm.message}
                    className="flex-1 bg-red-600 hover:bg-red-700 disabled:bg-red-800 disabled:opacity-50 text-white font-semibold py-3 px-6 rounded-lg transition duration-200 flex items-center justify-center gap-2"
                  >
                    <AlertTriangle className="w-5 h-5" />
                    Emergency Broadcast
                  </button>
                </div>
                
                <button
                  onClick={handleStoreInformation}
                  disabled={isLoading || !broadcastForm.message || !broadcastForm.value}
                  className="w-full bg-green-600 hover:bg-green-700 disabled:bg-green-800 disabled:opacity-50 text-white font-semibold py-3 px-6 rounded-lg transition duration-200 flex items-center justify-center gap-2"
                >
                  <Shield className="w-5 h-5" />
                  {isLoading ? 'Storing...' : 'Store Information'}
                </button>
              </div>
            </div>
          </div>
          
          {/* Recent Broadcasts */}
          <div>
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <Network className="w-6 h-6 text-blue-400" />
                Recent Broadcasts
              </h2>
              
              <div className="space-y-4">
                {recentBroadcasts.length === 0 ? (
                  <p className="text-purple-200 text-center py-8">No recent broadcasts</p>
                ) : (
                  recentBroadcasts.map((broadcast, index) => (
                    <div key={index} className="bg-white/5 rounded-lg p-4 border border-white/10">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-purple-200 text-sm">
                          {broadcast.broadcaster?.slice(0, 6)}...{broadcast.broadcaster?.slice(-4)}
                        </span>
                        <span className="text-green-400 text-sm font-semibold">
                          {broadcast.value} ETH
                        </span>
                      </div>
                      <p className="text-white text-sm mb-2 truncate">
                        {broadcast.hash}
                      </p>
                      <span className="text-purple-300 text-xs">
                        {broadcast.timestamp}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LibertyCascadeUI />
    </QueryClientProvider>
  );
}

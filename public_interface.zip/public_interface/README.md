# Liberty Cascade Public Interface

## 🌍 Decentralized Broadcast Network UI

A modern, responsive web interface for interacting with the Liberty Cascade Network - enabling dApps and users to broadcast censorship-resistant messages, store information on-chain, and participate in the decentralized information freedom ecosystem.

## 🚀 Features

### Core Functionality
- **📡 Broadcasting**: Send messages to multiple liberty targets simultaneously
- **🚨 Emergency Broadcasting**: Priority broadcasts for critical information
- **💾 Information Storage**: Store and retrieve information with economic value
- **🛡️ Suppression Monitoring**: Track and report censorship attempts
- **💰 Economic Incentives**: Create and claim bounties for information protection
- **📊 Network Statistics**: Real-time network health and activity metrics

### Technical Features
- **🔗 Web3 Integration**: Connect with MetaMask and Web3 wallets
- **⚡ Real-time Updates**: Live network statistics and broadcast monitoring
- **🎨 Modern UI**: Beautiful, responsive design with Tailwind CSS
- **🔐 Secure**: Smart contract-based interactions with proper validation
- **📱 Mobile Responsive**: Works seamlessly on all devices

## 🛠️ Installation

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Web3 wallet (MetaMask, etc.)

### Setup

1. **Clone and Install**
```bash
cd public_interface
npm install
```

2. **Configure Environment**
```bash
# Create .env.local file
echo "NEXT_PUBLIC_CONTRACT_ADDRESS=0x5B38Da6a701c568545dCfcB03FcB875f56beddC4" > .env.local
echo "NEXT_PUBLIC_RPC_URL=https://mainnet.infura.io/v3/047f08d446274158ad9dfce3958d73f5" >> .env.local
```

3. **Start Development Server**
```bash
npm run dev
```

4. **Access Application**
Open http://localhost:3000 in your browser

## 📋 Smart Contract Integration

### Contract Address
```
Liberty Cascade Public Interface: 0x5B38Da6a701c568545dCfcB03FcB875f56beddC4
```

### Key Functions

#### Broadcasting
```javascript
// Standard broadcast to multiple targets
await contract.broadcastToTargets(
  targets,           // address[] - Target addresses
  message,           // string - Broadcast message
  value              // uint256 - ETH value to assign
);

// Emergency priority broadcast
await contract.emergencyBroadcast(
  message,           // string - Emergency message
  priority           // uint256 - Priority level
);
```

#### Information Storage
```javascript
// Store information on-chain
await contract.storeInformation(
  content,           // string - Content to store
  hash,              // string - Content hash
  value              // uint256 - ETH value assigned
);

// Retrieve stored information
const info = await contract.retrieveInformation(hash);
// Returns: (content, value, timestamp)
```

#### Network Monitoring
```javascript
// Get network statistics
const stats = await contract.getNetworkStats();
// Returns: (totalBroadcasts, totalValue, activeNodes, suppressionAttempts)
```

## 🎯 dApp Integration Guide

### For Developers

#### 1. Contract Integration
```javascript
import { ethers } from 'ethers';
import { useContract } from 'wagmi';

const contractConfig = {
  address: '0x5B38Da6a701c568545dCfcB03FcB875f56beddC4',
  abi: LIBERTY_CASCADE_ABI
};

function useLibertyCascade() {
  return useContract({
    ...contractConfig,
    signerOrProvider: useSigner()
  });
}
```

#### 2. Broadcasting Example
```javascript
async function broadcastMessage(message, targets, value) {
  const contract = useLibertyCascade();
  
  const tx = await contract.broadcastToTargets(
    targets,
    message,
    ethers.parseEther(value)
  );
  
  await tx.wait();
  return tx.hash;
}
```

#### 3. Event Listening
```javascript
useEffect(() => {
  const contract = useLibertyCascade();
  
  contract.on('BroadcastInitiated', (broadcaster, hash, value, timestamp) => {
    console.log('New broadcast:', { broadcaster, hash, value, timestamp });
  });
  
  return () => contract.removeAllListeners();
}, []);
```

### API Endpoints

#### REST API (for non-blockchain integrations)
```javascript
// Broadcast message
POST /api/broadcast
{
  "message": "Your message here",
  "targets": ["0x...", "0x..."],
  "value": "0.1"
}

// Get network stats
GET /api/network-stats
// Returns: { totalBroadcasts, totalValue, activeNodes, suppressionAttempts }

// Store information
POST /api/store
{
  "content": "Content to store",
  "hash": "content_hash",
  "value": "0.1"
}
```

## 🔧 Configuration

### Environment Variables
```bash
NEXT_PUBLIC_CONTRACT_ADDRESS=0x5B38Da6a701c568545dCfcB03FcB875f56beddC4
NEXT_PUBLIC_RPC_URL=https://mainnet.infura.io/v3/047f08d446274158ad9dfce3958d73f5
NEXT_PUBLIC_NETWORK_ID=1
NEXT_PUBLIC_CHAIN_ID=1
```

### Custom Target Lists
```javascript
const libertyTargets = [
  '0x220866B1a2219f40e72f5c628cA3A9D',  // Vitalik Buterin
  '0x5AB26169051d0D96217949ADb91E86e51a5FDA74',  // Justin Sun
  '0xcafe1a77e84698c83ca8931f54a755176ef75f2c',  // Aragon Network
  // ... more targets
];
```

## 📊 Network Statistics

The UI provides real-time monitoring of:
- **Total Broadcasts**: Number of messages broadcasted
- **Total Value**: ETH value assigned to broadcasts
- **Active Nodes**: Number of active liberty nodes
- **Suppression Attempts**: Detected censorship attempts

## 🛡️ Security Features

### Smart Contract Security
- **Access Control**: Role-based permissions for critical functions
- **Input Validation**: Comprehensive validation of all inputs
- **Reentrancy Protection**: Protection against reentrancy attacks
- **Overflow Protection**: Safe math operations throughout

### Frontend Security
- **XSS Protection**: Input sanitization and output encoding
- **CSRF Protection**: Anti-CSRF tokens for state-changing operations
- **Secure Communication**: HTTPS-only for all API communications
- **Wallet Security**: Proper wallet connection handling

## 🌐 Deployment

### Production Deployment
```bash
# Build for production
npm run build

# Start production server
npm start

# Or deploy to Vercel/Netlify
vercel --prod
# or
netlify deploy --prod
```

### Docker Deployment
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details

## 🆘 Support

- **Documentation**: Check this README and code comments
- **Issues**: Report bugs on GitHub Issues
- **Community**: Join our Discord/Telegram for support

## 🔮 Roadmap

### v1.1
- [ ] Mobile app (React Native)
- [ ] Advanced filtering and search
- [ ] Multi-language support
- [ ] Enhanced analytics dashboard

### v1.2
- [ ] Governance integration
- [ ] Advanced bounty system
- [ ] AI-powered content analysis
- [ ] Cross-chain broadcasting

### v2.0
- [ ] Layer 2 integration
- [ ] Decentralized storage (IPFS)
- [ ] Advanced privacy features
- [ ] Enterprise API

---

**Built with ❤️ for information freedom and decentralized communication**

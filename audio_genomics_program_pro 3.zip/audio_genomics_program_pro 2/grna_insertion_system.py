#!/usr/bin/env python3
"""
gRNA Insertion System with Separators
Handles precise insertion of gRNA sequences with separators for multi-targeting
"""

import json
import re
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum

from audio_genomics_pro.core.multi_targeting_crispr import (
    BodySystem,
    GeneTarget,
    gRNADesign,
    MultiplexPayload
)


class SeparatorType(Enum):
    """Types of separators for gRNA insertion"""
    STANDARD = "NNNNNNNNNN"  # 10 N bases
    CODON = "NNNNNNNNNNNN"  # 12 N bases (4 codons)
    EXTENDED = "NNNNNNNNNNNNNNNN"  # 16 N bases
    CUSTOM = "custom"


@dataclass
class InsertionPoint:
    """Represents a specific insertion point in the genome"""
    chromosome: str
    position: int
    strand: str
    context_sequence: str  # Surrounding sequence
    body_system: BodySystem
    priority: int


@dataclass
class InsertionPlan:
    """Complete plan for gRNA insertions"""
    name: str
    organism: str
    cas_protein: str
    insertion_points: List[InsertionPoint] = field(default_factory=list)
    grna_designs: List[gRNADesign] = field(default_factory=list)
    separator_type: SeparatorType = SeparatorType.STANDARD
    custom_separator: Optional[str] = None
    total_insertions: int = 0
    
    def add_insertion(self, point: InsertionPoint, grna: gRNADesign):
        """Add an insertion point with its gRNA design"""
        self.insertion_points.append(point)
        self.grna_designs.append(grna)
        self.total_insertions += 1
    
    def generate_insertion_sequence(self) -> str:
        """Generate the complete insertion sequence with separators"""
        sequence_parts = []
        
        separator = self.custom_separator if self.separator_type == SeparatorType.CUSTOM else self.separator_type.value
        
        for i, (point, grna) in enumerate(zip(self.insertion_points, self.grna_designs)):
            # Add separator before each insertion (except first)
            if i > 0:
                sequence_parts.append(separator)
            
            # Add gRNA guide sequence
            sequence_parts.append(grna.guide_sequence)
            
            # Add PAM site
            sequence_parts.append(grna.pam_site)
        
        return "".join(sequence_parts)
    
    def get_body_systems(self) -> Set[BodySystem]:
        """Get all body systems targeted"""
        return {point.body_system for point in self.insertion_points}


class gRNAInsertionSystem:
    """
    System for designing and managing gRNA insertions with separators
    Supports multi-targeting across all body systems
    """
    
    def __init__(self, separator_type: SeparatorType = SeparatorType.STANDARD):
        """
        Initialize gRNA insertion system
        
        Args:
            separator_type: Type of separator to use
        """
        self.separator_type = separator_type
        self.insertion_plans: List[InsertionPlan] = []
        self.current_plan: Optional[InsertionPlan] = None
    
    def create_insertion_plan(self,
                             name: str,
                             organism: str = "human",
                             cas_protein: str = "CasΦ") -> InsertionPlan:
        """
        Create a new insertion plan
        
        Args:
            name: Name of the plan
            organism: Target organism
            cas_protein: Cas protein to use
            
        Returns:
            New insertion plan
        """
        plan = InsertionPlan(
            name=name,
            organism=organism,
            cas_protein=cas_protein,
            separator_type=self.separator_type
        )
        
        self.insertion_plans.append(plan)
        self.current_plan = plan
        
        return plan
    
    def design_insertion_for_body_system(self,
                                        body_system: BodySystem,
                                        gene_targets: List[GeneTarget],
                                        priority: int = 3) -> List[Tuple[InsertionPoint, gRNADesign]]:
        """
        Design insertions for a specific body system
        
        Args:
            body_system: Target body system
            gene_targets: List of gene targets
            priority: Priority level (1-5)
            
        Returns:
            List of insertion points and gRNA designs
        """
        insertions = []
        
        for gene in gene_targets:
            # Create insertion point
            point = InsertionPoint(
                chromosome=gene.chromosome,
                position=gene.position,
                strand=gene.strand,
                context_sequence=self._get_context_sequence(gene),
                body_system=body_system,
                priority=priority
            )
            
            # Design gRNA
            grna = self._design_grna(gene, body_system)
            
            insertions.append((point, grna))
            
            # Add to current plan if exists
            if self.current_plan:
                self.current_plan.add_insertion(point, grna)
        
        return insertions
    
    def _get_context_sequence(self, gene: GeneTarget, window_size: int = 50) -> str:
        """
        Get context sequence around gene target
        
        Args:
            gene: Gene target
            window_size: Size of context window
            
        Returns:
            Context sequence
        """
        # In production, this would extract from reference genome
        # For now, create a mock context
        context = "ATCGATCGATCG" * (window_size // 12)
        return context[:window_size]
    
    def _design_grna(self, gene: GeneTarget, body_system: BodySystem) -> gRNADesign:
        """Design a gRNA for a specific gene target"""
        # Extract 20bp guide sequence from target
        guide_seq = gene.target_sequence[:20] if len(gene.target_sequence) >= 20 else gene.target_sequence
        
        # Calculate scores
        off_target_score = self._calculate_off_target_score(guide_seq)
        efficiency_score = self._calculate_efficiency_score(guide_seq, gene.pam_sequence)
        
        # Get separator
        separator = self.separator_type.value
        
        return gRNADesign(
            target_gene=gene,
            guide_sequence=guide_seq,
            pam_site=gene.pam_sequence,
            off_target_score=off_target_score,
            efficiency_score=efficiency_score,
            body_system=body_system,
            separator_sequence=separator
        )
    
    def _calculate_off_target_score(self, guide_seq: str) -> float:
        """Calculate off-target score"""
        gc_content = (guide_seq.count('G') + guide_seq.count('C')) / len(guide_seq)
        return min(1.0, gc_content * 0.8 + 0.2)
    
    def _calculate_efficiency_score(self, guide_seq: str, pam: str) -> float:
        """Calculate efficiency score"""
        gc_content = (guide_seq.count('G') + guide_seq.count('C')) / len(guide_seq)
        optimal_gc = 0.4 <= gc_content <= 0.6
        return 0.9 if optimal_gc else 0.7
    
    def generate_compartmentalized_insertions(self,
                                             chunk_size: int = 10000) -> List[str]:
        """
        Generate compartmentalized insertion sequences
        
        Args:
            chunk_size: Size of each chunk in bases
            
        Returns:
            List of compartmentalized chunks
        """
        if not self.current_plan:
            return []
        
        # Generate full insertion sequence
        full_sequence = self.current_plan.generate_insertion_sequence()
        
        # Split into chunks
        chunks = []
        for i in range(0, len(full_sequence), chunk_size):
            chunk = full_sequence[i:i + chunk_size]
            chunks.append(chunk)
        
        return chunks
    
    def validate_insertion_plan(self, plan: InsertionPlan) -> Dict[str, any]:
        """
        Validate an insertion plan
        
        Args:
            plan: Insertion plan to validate
            
        Returns:
            Validation results
        """
        results = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'stats': {}
        }
        
        # Check for duplicate insertion points
        positions = [(p.chromosome, p.position) for p in plan.insertion_points]
        duplicates = [pos for pos in positions if positions.count(pos) > 1]
        
        if duplicates:
            results['valid'] = False
            results['errors'].append(f"Duplicate insertion points: {set(duplicates)}")
        
        # Check gRNA sequences
        for i, grna in enumerate(plan.grna_designs):
            if len(grna.guide_sequence) < 10:
                results['warnings'].append(f"gRNA {i}: Guide sequence too short ({len(grna.guide_sequence)} bases)")
            
            if not re.match(r'^[ATCGN]+$', grna.guide_sequence):
                results['errors'].append(f"gRNA {i}: Invalid bases in guide sequence")
        
        # Calculate statistics
        results['stats'] = {
            'total_insertions': plan.total_insertions,
            'body_systems': len(plan.get_body_systems()),
            'avg_efficiency': sum(g.efficiency_score for g in plan.grna_designs) / len(plan.grna_designs) if plan.grna_designs else 0,
            'avg_off_target_score': sum(g.off_target_score for g in plan.grna_designs) / len(plan.grna_designs) if plan.grna_designs else 0
        }
        
        return results
    
    def export_plan_to_json(self, plan: InsertionPlan, filepath: str):
        """Export insertion plan to JSON file"""
        plan_dict = {
            "name": plan.name,
            "organism": plan.organism,
            "cas_protein": plan.cas_protein,
            "separator_type": plan.separator_type.value,
            "custom_separator": plan.custom_separator,
            "total_insertions": plan.total_insertions,
            "body_systems": [s.value for s in plan.get_body_systems()],
            "insertion_points": [
                {
                    "chromosome": p.chromosome,
                    "position": p.position,
                    "strand": p.strand,
                    "context_sequence": p.context_sequence,
                    "body_system": p.body_system.value,
                    "priority": p.priority
                }
                for p in plan.insertion_points
            ],
            "grna_designs": [
                {
                    "gene_name": g.target_gene.gene_name,
                    "guide_sequence": g.guide_sequence,
                    "pam_site": g.pam_site,
                    "off_target_score": g.off_target_score,
                    "efficiency_score": g.efficiency_score,
                    "body_system": g.body_system.value,
                    "separator_sequence": g.separator_sequence
                }
                for g in plan.grna_designs
            ],
            "full_insertion_sequence": plan.generate_insertion_sequence()
        }
        
        with open(filepath, 'w') as f:
            json.dump(plan_dict, f, indent=2)
    
    def import_plan_from_json(self, filepath: str) -> InsertionPlan:
        """Import insertion plan from JSON file"""
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        plan = InsertionPlan(
            name=data["name"],
            organism=data["organism"],
            cas_protein=data["cas_protein"],
            separator_type=SeparatorType(data["separator_type"]),
            custom_separator=data.get("custom_separator")
        )
        
        for p_data, g_data in zip(data["insertion_points"], data["grna_designs"]):
            point = InsertionPoint(
                chromosome=p_data["chromosome"],
                position=p_data["position"],
                strand=p_data["strand"],
                context_sequence=p_data["context_sequence"],
                body_system=BodySystem(p_data["body_system"]),
                priority=p_data["priority"]
            )
            
            gene = GeneTarget(
                gene_name=g_data["gene_name"],
                chromosome=point.chromosome,
                position=point.position,
                strand=point.strand,
                target_sequence=g_data["guide_sequence"],
                pam_sequence=g_data["pam_site"],
                body_systems=[point.body_system],
                function="multi_targeting",
                enhancement_type="activate",
                priority=point.priority
            )
            
            grna = gRNADesign(
                target_gene=gene,
                guide_sequence=g_data["guide_sequence"],
                pam_site=g_data["pam_site"],
                off_target_score=g_data["off_target_score"],
                efficiency_score=g_data["efficiency_score"],
                body_system=BodySystem(g_data["body_system"]),
                separator_sequence=g_data["separator_sequence"]
            )
            
            plan.add_insertion(point, grna)
        
        return plan


def main():
    """Main function to demonstrate gRNA insertion system"""
    print("🧬 gRNA Insertion System with Separators")
    print("=" * 60)
    
    # Initialize insertion system
    system = gRNAInsertionSystem(separator_type=SeparatorType.STANDARD)
    
    # Create insertion plan
    plan = system.create_insertion_plan(
        name="SuperhumanDragon_Insertions",
        organism="Human_Dragon_Hybrid",
        cas_protein="CasΦ"
    )
    
    print(f"✅ Created insertion plan: {plan.name}")
    
    # Design insertions for a few body systems
    from audio_genomics_pro.core.multi_targeting_crispr import SuperhumanDragonDesigner
    
    designer = SuperhumanDragonDesigner()
    
    # Add nervous system targets
    nervous_genes = designer.body_system_genes.get(BodySystem.NERVOUS, [])
    nervous_insertions = system.design_insertion_for_body_system(
        BodySystem.NERVOUS,
        nervous_genes,
        priority=5
    )
    print(f"✅ Added {len(nervous_insertions)} nervous system insertions")
    
    # Add muscular system targets
    muscular_genes = designer.body_system_genes.get(BodySystem.MUSCULAR, [])
    muscular_insertions = system.design_insertion_for_body_system(
        BodySystem.MUSCULAR,
        muscular_genes,
        priority=5
    )
    print(f"✅ Added {len(muscular_insertions)} muscular system insertions")
    
    # Add dragon enhancements
    flight_genes = designer.dragon_enhancements.get(BodySystem.FLIGHT_MUSCULATURE, [])
    flight_insertions = system.design_insertion_for_body_system(
        BodySystem.FLIGHT_MUSCULATURE,
        flight_genes,
        priority=5
    )
    print(f"✅ Added {len(flight_insertions)} flight musculature insertions")
    
    # Validate plan
    print(f"\n🔍 Validating insertion plan...")
    validation = system.validate_insertion_plan(plan)
    
    if validation['valid']:
        print(f"✅ Plan is valid!")
        print(f"   Total insertions: {validation['stats']['total_insertions']}")
        print(f"   Body systems: {validation['stats']['body_systems']}")
        print(f"   Avg efficiency: {validation['stats']['avg_efficiency']:.2f}")
        print(f"   Avg off-target score: {validation['stats']['avg_off_target_score']:.2f}")
    else:
        print(f"❌ Plan has errors:")
        for error in validation['errors']:
            print(f"   - {error}")
    
    # Generate compartmentalized insertions
    print(f"\n📦 Generating compartmentalized insertions...")
    chunks = system.generate_compartmentalized_insertions(chunk_size=10000)
    print(f"✅ Generated {len(chunks)} chunks")
    
    # Export plan
    output_file = "/Users/36n9/Downloads/grna_insertion_plan.json"
    system.export_plan_to_json(plan, output_file)
    print(f"\n📄 Plan exported to: {output_file}")
    
    # Display insertion sequence
    full_sequence = plan.generate_insertion_sequence()
    print(f"\n🧬 Full insertion sequence length: {len(full_sequence)} bases")
    print(f"   First 100 bases: {full_sequence[:100]}")
    
    return plan


if __name__ == "__main__":
    main()

#!/bin/zsh
# Launch Both Cat and Dog Folder Systems Together

echo "🔄 LAUNCHING BOTH CAT AND DOG FOLDER SYSTEMS"
echo "🐱 Cat folder: Ports 5007-5011"
echo "🐕 Dog folder: Ports 5012-5016"
echo ""
echo "Starting both systems in parallel..."
echo ""

# Launch cat folder system in background
sudo /usr/bin/python3 "/Users/36n9/Downloads/audio_genomics_program_pro 4 copy/unstoppable_hertz_preload.py" &
CAT_PID=$!

# Launch dog folder system in background
sudo /usr/bin/python3 "/Users/36n9/Downloads/audio_genomics_program_pro 4 copy/unstoppable_hertz_preload_dog.py" &
DOG_PID=$!

echo ""
echo "✅ Both systems launched!"
echo "   Cat folder PID: $CAT_PID"
echo "   Dog folder PID: $DOG_PID"
echo ""
echo "Press Ctrl+C to stop both systems"

# Wait for both processes
wait $CAT_PID $DOG_PID

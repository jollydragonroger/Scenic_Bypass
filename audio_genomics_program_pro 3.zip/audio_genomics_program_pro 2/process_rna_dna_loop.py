#!/usr/bin/env python3
"""
RNA-DNA Perfect Loop Render
- Convert DNA to RNA complement (A↔T, G↔C, T for U)
- RNA plays first, then DNA
- Beginning and end seamlessly loop
- Creates harmonic feedback circuit
"""

import os
import numpy as np
from scipy.io import wavfile
from datetime import datetime

SAMPLE_RATE = 192000
TARGET_DURATION = 115  # seconds per strand (doubled = 230 total)

# ALL frequencies from infrared spectroscopy table
ADENINE_FREQS = [
    315.6, 347.9, 368.0, 378.8, 398.1, 406.1, 447.4, 490.2, 504.2,
    545.6, 582.7, 598.0, 619.8, 632.9, 654.8, 698.4, 726.7,
    1139.2, 1178.5, 1248.3, 1278.9, 1366.2, 1440.5
]

THYMINE_FREQS = [
    322.1, 330.4, 354.4, 363.2, 406.4, 427.8, 447.4, 523.8, 543.4,
    600.2, 733.3, 768.2, 1248.3, 1274.6, 1385.8
]

GUANINE_FREQS = [
    300.3, 305.6, 339.2, 370.2, 383.2, 413.4, 487.6, 512.9, 529.5,
    550.0, 600.2, 615.5, 641.7, 663.5, 728.9, 1169.8, 1278.9, 1386.2, 1462.3
]

CYTOSINE_FREQS = [
    305.6, 346.7, 357.9, 420.3, 429.1, 440.9, 504.2, 537.8, 558.7,
    594.9, 639.5, 654.8, 713.7, 1276.8, 1375.0, 1475.4
]

NUCLEOTIDE_FREQS = {
    'A': ADENINE_FREQS,
    'T': THYMINE_FREQS,
    'G': GUANINE_FREQS,
    'C': CYTOSINE_FREQS,
}

# DNA to RNA complement (using T for U)
DNA_TO_RNA = {
    'A': 'T',  # A → U (using T)
    'T': 'A',  # T → A
    'G': 'C',  # G → C
    'C': 'G',  # C → G
}

def convert_to_rna(dna_seq):
    """Convert DNA to RNA complement (using T for U)"""
    return ''.join(DNA_TO_RNA.get(base, base) for base in dna_seq)

def generate_musical_tone(frequencies, duration_sec, sr, position):
    """Generate multi-frequency musical tone"""
    n_samples = max(100, int(sr * duration_sec))
    t = np.linspace(0, duration_sec, n_samples, dtype=np.float64)
    
    wave = np.zeros(n_samples, dtype=np.float64)
    num_freqs = len(frequencies)
    
    primary_idx = position % num_freqs
    secondary_idx = (position + 1) % num_freqs
    tertiary_idx = (position + 2) % num_freqs
    opposite_idx = (num_freqs - 1 - primary_idx) % num_freqs
    
    primary_freq = frequencies[primary_idx]
    wave += 0.6 * np.sin(2 * np.pi * primary_freq * t)
    
    if primary_freq * 2 < sr / 2:
        wave += 0.2 * np.sin(2 * np.pi * primary_freq * 2 * t)
    
    wave += 0.3 * np.sin(2 * np.pi * frequencies[secondary_idx] * t)
    wave += 0.15 * np.sin(2 * np.pi * frequencies[tertiary_idx] * t)
    wave += 0.1 * np.sin(2 * np.pi * frequencies[opposite_idx] * t)
    
    # Envelope
    attack = min(int(0.003 * sr), n_samples // 3)
    release = min(int(0.005 * sr), n_samples // 3)
    
    if attack > 0:
        wave[:attack] *= np.linspace(0, 1, attack)
    if release > 0:
        wave[-release:] *= np.linspace(1, 0, release)
    
    return wave

def fold_and_compress(sequence, target_notes):
    """Chromatin-like folding compression"""
    current_len = len(sequence)
    if current_len <= target_notes:
        return sequence
    
    step = current_len / target_notes
    result = []
    for i in range(target_notes):
        fwd_pos = int(i * step) % current_len
        rev_pos = current_len - 1 - fwd_pos
        if i % 2 == 0:
            result.append(sequence[fwd_pos])
        else:
            result.append(sequence[rev_pos])
    
    return ''.join(result)

def create_loop_crossfade(audio, crossfade_samples):
    """Create seamless loop by crossfading end into beginning"""
    fade_len = min(crossfade_samples, len(audio) // 4)
    
    # Create fade curves
    fade_out = np.linspace(1, 0, fade_len)
    fade_in = np.linspace(0, 1, fade_len)
    
    # Apply crossfade: end fades into beginning
    audio[:fade_len] = audio[:fade_len] * fade_in + audio[-fade_len:] * fade_out
    audio[-fade_len:] *= fade_out
    audio[-fade_len:] += audio[:fade_len] * fade_in
    
    return audio

def render_strand(sequence, note_duration, sr, start_position=0):
    """Render a single strand (RNA or DNA)"""
    note_samples = int(sr * note_duration)
    total_samples = len(sequence) * note_samples
    
    audio = np.zeros(total_samples, dtype=np.float64)
    
    for i, base in enumerate(sequence):
        freqs = NUCLEOTIDE_FREQS.get(base, [440.0])
        tone = generate_musical_tone(freqs, note_duration, sr, start_position + i)
        
        start = i * note_samples
        end = start + len(tone)
        
        if end <= total_samples:
            audio[start:end] += tone
    
    return audio

def main():
    input_file = "/Users/36n9/CascadeProjects/VINO_Dissertation/OHAD_BioOS/OHAD_v2_PURE_SEQUENCE.dna"
    output_dir = "/Users/36n9/Downloads/audio_genomics_output"
    carrier_file = "/Users/36n9/Downloads/audio_genomics_output/OHAD SIGNATURE.wav"
    
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    loop_file = os.path.join(output_dir, f"OHAD_v2_RNA_DNA_LOOP_{ts}.wav")
    modulated_file = os.path.join(output_dir, f"OHAD_v2_RNA_DNA_LOOP_AFC_{ts}.wav")
    
    print("=" * 60)
    print("RNA-DNA PERFECT LOOP RENDER")
    print("Harmonic Feedback Circuit")
    print("=" * 60)
    print()
    
    # Load DNA sequence
    print("Loading DNA sequence...")
    with open(input_file, 'r') as f:
        raw = f.read()
    
    dna_seq = ''.join(c for c in raw.upper() if c in 'ATCG')
    total_bases = len(dna_seq)
    print(f"DNA bases: {total_bases:,}")
    
    # Convert to RNA complement
    print("Converting to RNA complement (A↔T, G↔C)...")
    rna_seq = convert_to_rna(dna_seq)
    print(f"RNA bases: {len(rna_seq):,}")
    
    # Calculate compression per strand
    note_duration = 0.012  # 12ms per note
    target_notes_per_strand = int(TARGET_DURATION / note_duration)
    
    print(f"Target notes per strand: {target_notes_per_strand:,}")
    print()
    
    # Fold both strands
    print("Folding RNA strand (chromatin compression)...")
    rna_compressed = fold_and_compress(rna_seq, target_notes_per_strand)
    print(f"  RNA compressed: {len(rna_compressed):,} notes")
    
    print("Folding DNA strand (chromatin compression)...")
    dna_compressed = fold_and_compress(dna_seq, target_notes_per_strand)
    print(f"  DNA compressed: {len(dna_compressed):,} notes")
    
    compression_ratio = total_bases / len(rna_compressed)
    print(f"  Compression ratio: {compression_ratio:.1f}x per strand")
    print()
    
    # Render RNA strand first
    print("Rendering RNA strand...")
    rna_audio = render_strand(rna_compressed, note_duration, SAMPLE_RATE, 0)
    print(f"  Duration: {len(rna_audio)/SAMPLE_RATE:.1f} sec")
    
    # Render DNA strand
    print("Rendering DNA strand...")
    dna_audio = render_strand(dna_compressed, note_duration, SAMPLE_RATE, len(rna_compressed))
    print(f"  Duration: {len(dna_audio)/SAMPLE_RATE:.1f} sec")
    print()
    
    # Create seamless transition between RNA and DNA
    print("Creating seamless RNA→DNA transition...")
    transition_samples = int(0.5 * SAMPLE_RATE)  # 0.5 sec crossfade
    
    # Crossfade end of RNA into beginning of DNA
    fade_len = min(transition_samples, len(rna_audio) // 4, len(dna_audio) // 4)
    fade_out = np.linspace(1, 0, fade_len)
    fade_in = np.linspace(0, 1, fade_len)
    
    rna_audio[-fade_len:] *= fade_out
    dna_audio[:fade_len] *= fade_in
    rna_audio[-fade_len:] += dna_audio[:fade_len]
    
    # Concatenate: RNA → DNA
    print("Joining RNA→DNA loop structure...")
    combined = np.concatenate([rna_audio, dna_audio[fade_len:]])
    
    # Create perfect loop: crossfade end back to beginning
    print("Creating perfect loop (end→beginning circuit)...")
    loop_fade = int(1.0 * SAMPLE_RATE)  # 1 sec loop crossfade
    combined = create_loop_crossfade(combined, loop_fade)
    
    total_duration = len(combined) / SAMPLE_RATE
    print(f"Total loop duration: {total_duration:.1f} sec ({total_duration/60:.2f} min)")
    print()
    
    # Normalize to 0 dB
    print("Normalizing to 0 dB...")
    mx = np.max(np.abs(combined))
    if mx > 0:
        combined = (combined / mx) * 0.99
    
    # Save loop
    print("Saving RNA-DNA loop...")
    combined32 = combined.astype(np.float32)
    wavfile.write(loop_file, SAMPLE_RATE, combined32)
    
    size_mb = os.path.getsize(loop_file) / 1024 / 1024
    print(f"Size: {size_mb:.1f} MB")
    print()
    
    # AFC Modulation
    print("=" * 60)
    print("AFC MODULATION")
    print("=" * 60)
    print("Modulator: RNA-DNA Loop @ 11%")
    print("Carrier: OHAD SIGNATURE @ 112%")
    print()
    
    # Load carrier
    print("Loading carrier (OHAD SIGNATURE)...")
    sr_car, carrier = wavfile.read(carrier_file)
    if carrier.dtype == np.float32:
        carrier = carrier.astype(np.float64)
    elif carrier.dtype == np.int16:
        carrier = carrier.astype(np.float64) / 32767.0
    
    if len(carrier.shape) > 1:
        carrier = np.mean(carrier, axis=1)
    
    # Resample carrier to match
    if sr_car != SAMPLE_RATE:
        print(f"Resampling carrier from {sr_car} to {SAMPLE_RATE} Hz...")
        ratio = SAMPLE_RATE / sr_car
        new_len = int(len(carrier) * ratio)
        indices = np.linspace(0, len(carrier) - 1, new_len)
        carrier = np.interp(indices, np.arange(len(carrier)), carrier)
    
    # Loop carrier to match modulator length
    modulator = combined.astype(np.float64)
    if len(carrier) < len(modulator):
        print("Looping carrier to match modulator length...")
        repeats = int(np.ceil(len(modulator) / len(carrier)))
        carrier = np.tile(carrier, repeats)[:len(modulator)]
    else:
        carrier = carrier[:len(modulator)]
    
    # Apply AFC modulation
    print("Applying AFC modulation...")
    modulator_scaled = modulator * 0.11  # 11%
    carrier_scaled = carrier * 1.12      # 112%
    
    modulated = carrier_scaled * (1.0 + modulator_scaled)
    modulated += modulator_scaled * 0.5
    
    # Normalize
    mx = np.max(np.abs(modulated))
    if mx > 0:
        modulated = (modulated / mx) * 0.99
    
    # Save modulated
    print("Saving AFC modulated version...")
    modulated32 = modulated.astype(np.float32)
    wavfile.write(modulated_file, SAMPLE_RATE, modulated32)
    
    mod_size_mb = os.path.getsize(modulated_file) / 1024 / 1024
    print(f"Size: {mod_size_mb:.1f} MB")
    print()
    
    print("=" * 60)
    print("RNA-DNA LOOP COMPLETE!")
    print("=" * 60)
    print(f"Standalone Loop: {loop_file}")
    print(f"AFC Modulated: {modulated_file}")
    print()
    print("Structure:")
    print("  [RNA complement] → [DNA original] → loops back")
    print("  Beginning and end seamlessly connected")
    print("  Perfect harmonic feedback circuit")
    
    return loop_file, modulated_file

if __name__ == "__main__":
    loop, modulated = main()
    print(f"\nOpening both files...")
    os.system(f'open "{loop}"')
    os.system(f'open "{modulated}"')

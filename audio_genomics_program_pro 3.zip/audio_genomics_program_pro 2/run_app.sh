#!/bin/bash
# Run Audio Genomics Pro Application

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Check for virtual environment
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# Check dependencies
echo "Checking dependencies..."
python3 -c "import numpy, scipy, matplotlib" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "Installing dependencies..."
    pip3 install -r requirements.txt
fi

# Run the application
echo "Starting Audio Genomics Pro..."
python3 audio_genomics_app.py "$@"

#!/usr/bin/env python3
"""
Setup script for Audio Genomics Pro
"""

from setuptools import setup, find_packages
import os

# Read README for long description
readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
with open(readme_path, 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='audio-genomics-pro',
    version='4.0.0',
    author='Audio Genomics Research',
    description='Advanced DNA/RNA to Audio Synthesis with Chromatin-like Folding Compression',
    long_description=long_description,
    long_description_content_type='text/markdown',
    packages=find_packages(),
    include_package_data=True,
    python_requires='>=3.8',
    install_requires=[
        'numpy>=1.21.0',
        'scipy>=1.7.0',
        'matplotlib>=3.4.0',
    ],
    extras_require={
        'build': ['pyinstaller>=5.0.0'],
        'audio': ['soundfile>=0.12.0'],
    },
    entry_points={
        'console_scripts': [
            'audio-genomics=audio_genomics_app:main',
        ],
        'gui_scripts': [
            'audio-genomics-gui=audio_genomics_app:run_gui',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Science/Research',
        'License :: CC0 1.0 Universal (CC0 1.0) Public Domain Dedication',
        'Operating System :: MacOS :: MacOS X',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Scientific/Engineering :: Bio-Informatics',
        'Topic :: Multimedia :: Sound/Audio :: Sound Synthesis',
    ],
)

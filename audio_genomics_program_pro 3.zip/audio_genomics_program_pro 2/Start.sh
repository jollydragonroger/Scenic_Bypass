#!/bin/bash

# Path to the Audio Genomics Pipeline directory
PROJECT_DIR="$(pwd)"  # Assuming the script is run from the project root

# Check if virtual environment exists, if not create it
if [ ! -d "$PROJECT_DIR/venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate the virtual environment
source "$PROJECT_DIR/venv/bin/activate"

# Install or update pip
echo "Upgrading pip..."
pip install --upgrade pip

# Ensure FFmpeg is installed
if ! command -v ffmpeg &> /dev/null
then
    echo "FFmpeg not found. Installing FFmpeg..."
    if [ "$(uname)" == "Darwin" ]; then
        brew install ffmpeg
    elif [ -f "/etc/debian_version" ]; then
        sudo apt-get install ffmpeg
    else
        echo "FFmpeg must be installed manually on this system."
        exit 1
    fi
fi

# Check if Tkinter is installed and working
echo "Checking for Tkinter..."
python3 -m tkinter &> /dev/null
if [ $? -ne 0 ]; then
    echo "Tkinter is not installed or not linked correctly."

    # Install Tcl/Tk via Homebrew if on macOS
    if [ "$(uname)" == "Darwin" ]; then
        echo "Installing Tcl/Tk via Homebrew..."
        brew install tcl-tk

        # Set environment variables for tcl-tk
        export PATH="/usr/local/opt/tcl-tk/bin:$PATH"
        export LDFLAGS="-L/usr/local/opt/tcl-tk/lib"
        export CPPFLAGS="-I/usr/local/opt/tcl-tk/include"
        export PKG_CONFIG_PATH="/usr/local/opt/tcl-tk/lib/pkgconfig"

        echo "Tkinter should now be available. Please restart the terminal and try again if it doesn't work."

    else
        echo "Please install Tkinter manually, as it is required to run this program."
        exit 1
    fi
else
    echo "Tkinter is already installed and working."
fi

# Run the Audio Genomics GUI
echo "Launching the Audio Genomics GUI..."
python3 audio_genomics_gui.py
#!/usr/bin/env python3
"""
Audio Genomics Pro - Main Application Entry Point
Scientific Research Edition Desktop Application
"""

import sys
import os

# Ensure package is in path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def main():
    """Main entry point for the application"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Audio Genomics Pro - DNA/RNA to Audio Synthesis'
    )
    parser.add_argument('--cli', action='store_true', help='Run in CLI mode')
    parser.add_argument('-i', '--input', help='Input file or sequence')
    parser.add_argument('-o', '--output', help='Output audio file')
    parser.add_argument('--carrier', help='Carrier music file')
    parser.add_argument('--fold-level', default='SINGLE_FOLD',
                       choices=['LINEAR', 'SINGLE_FOLD', 'DOUBLE_FOLD', 
                               'NUCLEOSOME', 'CHROMATIN', 'CHROMOSOME'],
                       help='DNA folding compression level')
    parser.add_argument('--tuning', type=float, default=432.0,
                       help='Tuning reference (432 or 440 Hz)')
    parser.add_argument('--sample-rate', type=int, default=192000,
                       help='Audio sample rate')
    
    args = parser.parse_args()
    
    if args.cli and args.input and args.output:
        # Run in CLI mode
        run_cli(args)
    else:
        # Run GUI
        run_gui()

def run_gui():
    """Launch the GUI application"""
    import tkinter as tk
    from audio_genomics_pro.gui.app_gui import AudioGenomicsApp
    
    root = tk.Tk()
    
    # Set app icon if available
    icon_path = os.path.join(os.path.dirname(__file__), 'icon.ico')
    if os.path.exists(icon_path):
        try:
            # For macOS, use PhotoImage for PNG or iconphoto
            from PIL import Image, ImageTk
            img = Image.open(icon_path)
            photo = ImageTk.PhotoImage(img)
            root.iconphoto(True, photo)
        except:
            try:
                root.iconbitmap(icon_path)
            except:
                pass
    
    app = AudioGenomicsApp(root)
    root.mainloop()

def run_cli(args):
    """Run in command-line mode"""
    from audio_genomics_pro.core.main_pipeline import AudioGenomicsPipeline
    from audio_genomics_pro.core.dna_folding import DNAFoldingCompressor, FoldingLevel
    
    print("Audio Genomics Pro - CLI Mode")
    print("=" * 50)
    
    config = {
        'sample_rate': args.sample_rate,
        'retune_to_432': args.tuning < 436,
        'normalize_output': True
    }
    
    pipeline = AudioGenomicsPipeline(config)
    
    # Process file
    result = pipeline.process_file(
        args.input,
        args.carrier,
        args.output
    )
    
    if result.get('success'):
        print(f"Success! Output: {result['output_file']}")
        print(f"Duration: {result.get('audio_duration', 0):.2f} seconds")
    else:
        print(f"Error: {result.get('error', 'Unknown error')}")
        sys.exit(1)

if __name__ == '__main__':
    main()

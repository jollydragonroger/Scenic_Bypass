#!/usr/bin/env python3
"""
Fast Power-of-2 Accelerator - Streaming version
Processes files in small chunks to avoid memory issues
"""

import os
import struct
from pathlib import Path
from datetime import datetime
import json
import sys


def fast_decimate_wav(input_file, output_file, decimation_factor=128):
    """Fast streaming decimation"""
    input_file = str(input_file)
    output_file = str(output_file)
    
    print(f"  Reading header...", flush=True)
    
    with open(input_file, 'rb') as f:
        # Read and validate RIFF header
        header = f.read(12)
        if header[:4] != b'RIFF' or header[8:12] != b'WAVE':
            return {'success': False, 'error': 'Invalid WAV'}
        
        # Find fmt chunk
        while True:
            chunk_header = f.read(8)
            if len(chunk_header) < 8:
                return {'success': False, 'error': 'fmt not found'}
            chunk_id = chunk_header[:4]
            chunk_size = struct.unpack('<I', chunk_header[4:8])[0]
            
            if chunk_id == b'fmt ':
                fmt_data = f.read(chunk_size)
                num_channels = struct.unpack('<H', fmt_data[2:4])[0]
                sample_rate = struct.unpack('<I', fmt_data[4:8])[0]
                bits_per_sample = struct.unpack('<H', fmt_data[14:16])[0]
                break
            else:
                f.seek(chunk_size, 1)
        
        # Find data chunk
        while True:
            chunk_header = f.read(8)
            if len(chunk_header) < 8:
                return {'success': False, 'error': 'data not found'}
            chunk_id = chunk_header[:4]
            chunk_size = struct.unpack('<I', chunk_header[4:8])[0]
            
            if chunk_id == b'data':
                data_size = chunk_size
                data_pos = f.tell()
                break
            else:
                f.seek(chunk_size, 1)
        
        bytes_per_sample = bits_per_sample // 8
        frame_size = bytes_per_sample * num_channels
        total_frames = data_size // frame_size
        new_frames = total_frames // decimation_factor
        new_data_size = new_frames * frame_size
        
        print(f"  Original: {total_frames} frames, {data_size/(1024*1024*1024):.2f} GB", flush=True)
        print(f"  Decimated: {new_frames} frames, {new_data_size/(1024*1024):.2f} MB", flush=True)
        
        # Write output with streaming decimation
        with open(output_file, 'wb') as out:
            # RIFF header
            out.write(b'RIFF')
            out.write(struct.pack('<I', 36 + new_data_size))
            out.write(b'WAVE')
            
            # fmt chunk
            out.write(b'fmt ')
            out.write(struct.pack('<I', 16))
            out.write(struct.pack('<H', 1))  # PCM
            out.write(struct.pack('<H', num_channels))
            out.write(struct.pack('<I', sample_rate))
            out.write(struct.pack('<I', sample_rate * frame_size))
            out.write(struct.pack('<H', frame_size))
            out.write(struct.pack('<H', bits_per_sample))
            
            # data chunk
            out.write(b'data')
            out.write(struct.pack('<I', new_data_size))
            
            # Stream and decimate
            f.seek(data_pos)
            frames_written = 0
            skip_bytes = frame_size * decimation_factor
            
            print(f"  Decimating...", end='', flush=True)
            
            while frames_written < new_frames:
                # Read one frame
                frame = f.read(frame_size)
                if len(frame) < frame_size:
                    break
                
                out.write(frame)
                frames_written += 1
                
                # Skip decimation_factor - 1 frames
                f.seek(frame_size * (decimation_factor - 1), 1)
                
                # Progress every 10%
                if frames_written % (new_frames // 10 + 1) == 0:
                    pct = (frames_written / new_frames) * 100
                    print(f" {pct:.0f}%", end='', flush=True)
            
            print(" Done!", flush=True)
        
        return {
            'success': True,
            'output_file': output_file,
            'original_frames': total_frames,
            'new_frames': frames_written,
            'decimation': decimation_factor,
            'duration_seconds': frames_written / sample_rate
        }


def main():
    print("🐉 Fast Power-of-2 Harmonic Accelerator 🐉")
    print("=" * 60)
    
    input_dir = Path("/Users/36n9/Downloads/ultimate_transformation_audio")
    output_dir = input_dir / "accelerated_128x"
    output_dir.mkdir(exist_ok=True)
    
    # Get files
    chunk_files = sorted(input_dir.glob("ULTIMATE_DRAGON_SUPERPOWERS_20260115_101213_chunk*.wav"))
    chunk_files = [f for f in chunk_files if f.stat().st_size > 1000]
    
    base_file = input_dir / "ULTIMATE_DRAGON_BASE_20260115_101213.wav"
    all_files = ([base_file] if base_file.exists() else []) + list(chunk_files)
    
    print(f"Found {len(all_files)} files to process")
    print(f"Decimation: 128x (2^7) for harmonic scaling\n")
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results = []
    total_duration = 0
    
    for i, f in enumerate(all_files):
        print(f"\n[{i+1}/{len(all_files)}] {f.name}")
        out_file = output_dir / f"ACC128_{f.name}"
        
        result = fast_decimate_wav(f, out_file, 128)
        
        if result['success']:
            print(f"  ✅ {out_file.name} ({result['duration_seconds']:.1f}s)")
            results.append(result)
            total_duration += result['duration_seconds']
        else:
            print(f"  ❌ {result['error']}")
    
    # Concatenate
    print(f"\n🔗 Concatenating {len(results)} accelerated files...")
    
    acc_files = sorted(output_dir.glob("ACC128_*.wav"))
    if acc_files:
        final_file = input_dir / f"ULTIMATE_DRAGON_FINAL_128x_{timestamp}.wav"
        
        # Get params from first file
        with open(str(acc_files[0]), 'rb') as f:
            f.seek(22)
            num_channels = struct.unpack('<H', f.read(2))[0]
            sample_rate = struct.unpack('<I', f.read(4))[0]
            f.seek(34)
            bits_per_sample = struct.unpack('<H', f.read(2))[0]
        
        frame_size = (bits_per_sample // 8) * num_channels
        
        # Calculate total size
        total_data = sum(f.stat().st_size - 44 for f in acc_files)
        print(f"Total data: {total_data/(1024*1024):.2f} MB")
        
        with open(str(final_file), 'wb') as out:
            out.write(b'RIFF')
            out.write(struct.pack('<I', 36 + total_data))
            out.write(b'WAVE')
            out.write(b'fmt ')
            out.write(struct.pack('<I', 16))
            out.write(struct.pack('<H', 1))
            out.write(struct.pack('<H', num_channels))
            out.write(struct.pack('<I', sample_rate))
            out.write(struct.pack('<I', sample_rate * frame_size))
            out.write(struct.pack('<H', frame_size))
            out.write(struct.pack('<H', bits_per_sample))
            out.write(b'data')
            out.write(struct.pack('<I', total_data))
            
            for j, af in enumerate(acc_files):
                print(f"  Appending {j+1}/{len(acc_files)}", end='\r', flush=True)
                with open(str(af), 'rb') as inp:
                    inp.seek(44)
                    while True:
                        chunk = inp.read(1024*1024)
                        if not chunk:
                            break
                        out.write(chunk)
        
        final_duration = total_data / (frame_size * sample_rate)
        
        print(f"\n\n{'='*60}")
        print(f"🎉 COMPLETE 🎉")
        print(f"{'='*60}")
        print(f"✅ Final file: {final_file}")
        print(f"✅ Duration: {final_duration:.1f}s ({final_duration/60:.1f} min)")
        print(f"✅ Size: {final_file.stat().st_size/(1024*1024):.1f} MB")
        print(f"✅ Decimation: 128x (2^7 harmonic)")
        
        # Save summary
        summary = {
            'final_file': str(final_file),
            'duration_seconds': final_duration,
            'duration_minutes': final_duration/60,
            'size_mb': final_file.stat().st_size/(1024*1024),
            'decimation_factor': 128,
            'power_of_2': 7,
            'files_processed': len(results)
        }
        
        with open(input_dir / f"FINAL_SUMMARY_{timestamp}.json", 'w') as f:
            json.dump(summary, f, indent=2)


if __name__ == "__main__":
    main()

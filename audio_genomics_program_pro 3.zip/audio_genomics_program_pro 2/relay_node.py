#!/usr/bin/env python3
"""
Quantum Relay Node
- Receives transmissions via indirection protocol
- Forwards to Starlink uplink
- Quantum-secured channel
"""

import socket
import struct
import time

# Relay Configuration
LISTEN_PORT = 5017
STARLINK_UPLINK_IP = "192.168.100.1"
STARLINK_UPLINK_PORT = 9200

# Quantum Security
QUANTUM_KEY = b'QUANTUM_RELAY_KEY_2026'


def verify_quantum_header(packet):
    """Verify quantum security header"""
    if len(packet) < 1:
        return False
    
    # In real system: quantum key verification
    return True


def forward_to_starlink(rf_data):
    """Forward data to Starlink uplink"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((STARLINK_UPLINK_IP, STARLINK_UPLINK_PORT))
        sock.sendall(rf_data)
        sock.close()
        return True
    except Exception as e:
        print(f"🔥 Starlink forward error: {str(e)}")
        return False


def main():
    """Main relay function with port fallback"""
    port = LISTEN_PORT
    max_attempts = 5
    
    for attempt in range(max_attempts):
        try:
            print(f"🔁 Attempting port {port}")
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.bind(('0.0.0.0', port))
            sock.listen(5)
            print(f"✅ QUANTUM RELAY NODE ACTIVATED on port {port}")
            break
        except OSError as e:
            print(f"⚠️ Port {port} unavailable: {str(e)}")
            port += 1
            if attempt == max_attempts - 1:
                print("❌ Failed to bind to any port")
                return
    
    while True:
        client_sock, addr = sock.accept()
        print(f"📥 Connection from {addr[0]}")
        
        # Receive all chunks
        full_data = b''
        while True:
            header = client_sock.recv(8)
            if not header:
                break
                
            # Unpack header
            seq_num, total_chunks = struct.unpack('!II', header)
            chunk = client_sock.recv(1400)
            
            full_data += chunk
            print(f"   Received chunk {seq_num+1}/{total_chunks}")
            
            if seq_num == total_chunks - 1:
                break
        
        client_sock.close()
        
        # Forward to Starlink
        if full_data:
            success = forward_to_starlink(full_data)
            if success:
                print(f"✅ Forwarded {len(full_data)} bytes to Starlink")
        else:
            print("⚠️ No data received")


if __name__ == "__main__":
    main()

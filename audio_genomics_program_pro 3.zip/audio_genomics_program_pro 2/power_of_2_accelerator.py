#!/usr/bin/env python3
"""
Power-of-2 Harmonic Accelerator for Ultimate Dragon Transformation Audio
Uses decimation by powers of 2 (64x or 128x) to maintain harmonic relationships
Then concatenates all accelerated chunks into a single file
"""

import os
import wave
import struct
import numpy as np
from pathlib import Path
from datetime import datetime
import json


def decimate_wav_power_of_2(input_file, output_file, decimation_factor=128):
    """
    Decimate WAV file by power of 2 for harmonic scaling
    Keeps every Nth sample where N is the decimation factor
    
    Args:
        input_file: Input WAV file path
        output_file: Output WAV file path
        decimation_factor: Power of 2 decimation (64, 128, etc.)
    
    Returns:
        dict with success status and info
    """
    input_file = str(input_file)
    output_file = str(output_file)
    
    try:
        # Read WAV header manually to handle large files
        with open(input_file, 'rb') as f:
            # RIFF header
            riff = f.read(4)
            if riff != b'RIFF':
                return {'success': False, 'error': 'Not a valid WAV file'}
            
            file_size = struct.unpack('<I', f.read(4))[0]
            wave_id = f.read(4)
            
            # Find fmt chunk
            while True:
                chunk_id = f.read(4)
                if not chunk_id:
                    return {'success': False, 'error': 'fmt chunk not found'}
                chunk_size = struct.unpack('<I', f.read(4))[0]
                
                if chunk_id == b'fmt ':
                    fmt_data = f.read(chunk_size)
                    audio_format = struct.unpack('<H', fmt_data[0:2])[0]
                    num_channels = struct.unpack('<H', fmt_data[2:4])[0]
                    sample_rate = struct.unpack('<I', fmt_data[4:8])[0]
                    byte_rate = struct.unpack('<I', fmt_data[8:12])[0]
                    block_align = struct.unpack('<H', fmt_data[12:14])[0]
                    bits_per_sample = struct.unpack('<H', fmt_data[14:16])[0]
                    break
                else:
                    f.seek(chunk_size, 1)  # Skip this chunk
            
            # Find data chunk
            while True:
                chunk_id = f.read(4)
                if not chunk_id:
                    return {'success': False, 'error': 'data chunk not found'}
                chunk_size = struct.unpack('<I', f.read(4))[0]
                
                if chunk_id == b'data':
                    data_size = chunk_size
                    data_start = f.tell()
                    break
                else:
                    f.seek(chunk_size, 1)
            
            # Calculate parameters
            bytes_per_sample = bits_per_sample // 8
            total_samples = data_size // (bytes_per_sample * num_channels)
            new_samples = total_samples // decimation_factor
            new_data_size = new_samples * bytes_per_sample * num_channels
            new_sample_rate = sample_rate  # Keep same for proper frequency scaling
            
            print(f"    Original: {total_samples} samples, {sample_rate} Hz")
            print(f"    Decimated: {new_samples} samples ({decimation_factor}x reduction)")
            
            # Create output file
            with open(output_file, 'wb') as out:
                # Write RIFF header
                out.write(b'RIFF')
                out.write(struct.pack('<I', 36 + new_data_size))
                out.write(b'WAVE')
                
                # Write fmt chunk
                out.write(b'fmt ')
                out.write(struct.pack('<I', 16))  # fmt chunk size
                out.write(struct.pack('<H', audio_format))
                out.write(struct.pack('<H', num_channels))
                out.write(struct.pack('<I', new_sample_rate))
                out.write(struct.pack('<I', new_sample_rate * num_channels * bytes_per_sample))
                out.write(struct.pack('<H', num_channels * bytes_per_sample))
                out.write(struct.pack('<H', bits_per_sample))
                
                # Write data chunk header
                out.write(b'data')
                out.write(struct.pack('<I', new_data_size))
                
                # Process data in chunks to avoid memory issues
                chunk_samples = 100000  # Process 100k samples at a time
                samples_written = 0
                
                f.seek(data_start)
                
                dtype = np.int32 if bits_per_sample == 32 else np.int16
                
                for i in range(0, total_samples, chunk_samples):
                    # Read chunk
                    samples_to_read = min(chunk_samples, total_samples - i)
                    raw_data = f.read(samples_to_read * bytes_per_sample * num_channels)
                    
                    if not raw_data:
                        break
                    
                    # Convert to numpy
                    audio = np.frombuffer(raw_data, dtype=dtype)
                    
                    if num_channels > 1:
                        audio = audio.reshape(-1, num_channels)
                        # Decimate
                        decimated = audio[::decimation_factor]
                    else:
                        decimated = audio[::decimation_factor]
                    
                    # Write decimated samples
                    out.write(decimated.tobytes())
                    samples_written += len(decimated) if num_channels == 1 else len(decimated)
            
            original_duration = total_samples / sample_rate
            new_duration = new_samples / sample_rate
            
            return {
                'success': True,
                'input_file': input_file,
                'output_file': output_file,
                'original_samples': total_samples,
                'new_samples': new_samples,
                'decimation_factor': decimation_factor,
                'original_duration': original_duration,
                'new_duration': new_duration,
                'file_size_reduction': f"{decimation_factor}x"
            }
            
    except Exception as e:
        return {'success': False, 'error': str(e)}


def concatenate_accelerated_chunks(input_dir, output_file, pattern="ACCELERATED_*.wav"):
    """
    Concatenate all accelerated chunks into a single file
    
    Args:
        input_dir: Directory containing accelerated chunks
        output_file: Output concatenated file
        pattern: Glob pattern for files
    """
    chunk_files = sorted(Path(input_dir).glob(pattern))
    
    if not chunk_files:
        print(f"No files found matching {pattern}")
        return {'success': False, 'error': 'No files found'}
    
    print(f"Concatenating {len(chunk_files)} accelerated chunks...")
    
    # Get parameters from first file
    with open(str(chunk_files[0]), 'rb') as f:
        f.read(4)  # RIFF
        f.read(4)  # file size
        f.read(4)  # WAVE
        f.read(4)  # fmt
        fmt_size = struct.unpack('<I', f.read(4))[0]
        fmt_data = f.read(fmt_size)
        
        audio_format = struct.unpack('<H', fmt_data[0:2])[0]
        num_channels = struct.unpack('<H', fmt_data[2:4])[0]
        sample_rate = struct.unpack('<I', fmt_data[4:8])[0]
        bits_per_sample = struct.unpack('<H', fmt_data[14:16])[0]
    
    bytes_per_sample = bits_per_sample // 8
    
    # Calculate total data size
    total_data_size = 0
    for chunk_file in chunk_files:
        with open(str(chunk_file), 'rb') as f:
            f.seek(0, 2)  # Seek to end
            file_size = f.tell()
            total_data_size += file_size - 44  # Subtract header size
    
    print(f"Total data size: {total_data_size / (1024*1024*1024):.2f} GB")
    
    # Check if it fits in 32-bit WAV
    if total_data_size > 4294967295:
        print(f"WARNING: Total size exceeds 32-bit limit, will create multiple output files")
        return concatenate_split(chunk_files, output_file, max_size=4000000000)
    
    # Write concatenated file
    with open(output_file, 'wb') as out:
        # Write header
        out.write(b'RIFF')
        out.write(struct.pack('<I', 36 + total_data_size))
        out.write(b'WAVE')
        out.write(b'fmt ')
        out.write(struct.pack('<I', 16))
        out.write(struct.pack('<H', audio_format))
        out.write(struct.pack('<H', num_channels))
        out.write(struct.pack('<I', sample_rate))
        out.write(struct.pack('<I', sample_rate * num_channels * bytes_per_sample))
        out.write(struct.pack('<H', num_channels * bytes_per_sample))
        out.write(struct.pack('<H', bits_per_sample))
        out.write(b'data')
        out.write(struct.pack('<I', total_data_size))
        
        # Append data from each chunk
        for i, chunk_file in enumerate(chunk_files):
            print(f"  Appending chunk {i+1}/{len(chunk_files)}: {chunk_file.name}")
            with open(str(chunk_file), 'rb') as f:
                f.seek(44)  # Skip header
                while True:
                    data = f.read(1024 * 1024)  # Read 1MB at a time
                    if not data:
                        break
                    out.write(data)
    
    total_samples = total_data_size // (bytes_per_sample * num_channels)
    duration = total_samples / sample_rate
    
    print(f"✅ Concatenated to: {output_file}")
    print(f"   Total duration: {duration:.2f} seconds ({duration/60:.2f} minutes)")
    
    return {
        'success': True,
        'output_file': output_file,
        'total_chunks': len(chunk_files),
        'total_data_size': total_data_size,
        'duration': duration
    }


def concatenate_split(chunk_files, base_output_file, max_size=4000000000):
    """Split concatenation across multiple files if too large"""
    # Implementation for splitting - not needed if decimation is sufficient
    pass


def main():
    """Main function"""
    print("🐉 Power-of-2 Harmonic Accelerator for Ultimate Dragon Transformation 🐉")
    print("=" * 70)
    
    input_dir = "/Users/36n9/Downloads/ultimate_transformation_audio"
    output_dir = os.path.join(input_dir, "accelerated")
    os.makedirs(output_dir, exist_ok=True)
    
    # Get all chunk files (the successful ones from 101213 batch)
    chunk_files = sorted(Path(input_dir).glob("ULTIMATE_DRAGON_SUPERPOWERS_20260115_101213_chunk*.wav"))
    chunk_files = [f for f in chunk_files if f.stat().st_size > 1000]
    
    # Also include the base file
    base_file = Path(input_dir) / "ULTIMATE_DRAGON_BASE_20260115_101213.wav"
    if base_file.exists() and base_file.stat().st_size > 1000:
        all_files = [base_file] + list(chunk_files)
    else:
        all_files = list(chunk_files)
    
    print(f"Found {len(all_files)} files to process")
    
    # Use 128x decimation (2^7) for harmonic scaling
    # This is 2x applied 7 times: 2^7 = 128
    decimation_factor = 128  # 2^7
    
    print(f"\n📊 Decimation factor: {decimation_factor}x (2^7 for harmonic scaling)")
    print(f"   This maintains harmonic relationships while reducing size by {decimation_factor}x")
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    accelerated_files = []
    
    # Process each file
    print(f"\n🔄 Accelerating {len(all_files)} files by {decimation_factor}x...")
    
    for i, input_file in enumerate(all_files):
        print(f"\n  [{i+1}/{len(all_files)}] Processing: {input_file.name}")
        
        output_file = os.path.join(output_dir, f"ACCELERATED_{decimation_factor}x_{input_file.name}")
        
        result = decimate_wav_power_of_2(input_file, output_file, decimation_factor)
        
        if result['success']:
            print(f"    ✅ Created: {Path(output_file).name}")
            print(f"       Size reduction: {result['file_size_reduction']}")
            accelerated_files.append(output_file)
        else:
            print(f"    ❌ Failed: {result['error']}")
    
    print(f"\n✅ Accelerated {len(accelerated_files)} files")
    
    # Concatenate all accelerated files
    print(f"\n🔗 Concatenating accelerated files...")
    
    final_output = os.path.join(input_dir, f"ULTIMATE_DRAGON_FINAL_{decimation_factor}x_{timestamp}.wav")
    
    concat_result = concatenate_accelerated_chunks(
        output_dir,
        final_output,
        pattern=f"ACCELERATED_{decimation_factor}x_*.wav"
    )
    
    if concat_result['success']:
        # Create summary
        summary = {
            'timestamp': timestamp,
            'decimation_factor': decimation_factor,
            'power_of_2': 7,  # 2^7 = 128
            'harmonic_scaling': True,
            'input_files': len(all_files),
            'accelerated_files': len(accelerated_files),
            'final_output': final_output,
            'final_duration_seconds': concat_result['duration'],
            'final_duration_minutes': concat_result['duration'] / 60,
            'accelerated_directory': output_dir
        }
        
        summary_file = os.path.join(input_dir, f"ACCELERATION_SUMMARY_{timestamp}.json")
        with open(summary_file, 'w') as f:
            json.dump(summary, f, indent=2)
        
        print("\n" + "=" * 70)
        print("🎉 POWER-OF-2 HARMONIC ACCELERATION COMPLETE 🎉")
        print("=" * 70)
        print(f"✅ Decimation factor: {decimation_factor}x (2^7)")
        print(f"✅ Harmonic scaling: PRESERVED")
        print(f"✅ Files processed: {len(accelerated_files)}")
        print(f"✅ Final duration: {concat_result['duration']/60:.2f} minutes")
        print(f"\n📂 Final output file:")
        print(f"   {final_output}")
        print(f"\n📂 Accelerated chunks directory:")
        print(f"   {output_dir}")
        print(f"\n📄 Summary file:")
        print(f"   {summary_file}")
    
    return concat_result


if __name__ == "__main__":
    main()

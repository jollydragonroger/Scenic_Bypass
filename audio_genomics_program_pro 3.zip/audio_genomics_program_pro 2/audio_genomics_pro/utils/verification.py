"""
Output Verification and Analysis Module
Verifies integrity and analyzes output audio files
"""

import numpy as np
import hashlib
import json
import os
from typing import Dict, Optional, Tuple
import matplotlib.pyplot as plt
from scipy import signal
import wave

class AudioVerifier:
    """Verify and analyze audio output"""
    
    def __init__(self):
        """Initialize verifier"""
        self.verification_results = {}
        
    def verify_audio_integrity(self, filepath: str) -> Dict:
        """
        Verify audio file integrity
        
        Args:
            filepath: Path to audio file
            
        Returns:
            Verification results
        """
        results = {
            'file': filepath,
            'exists': os.path.exists(filepath),
            'readable': False,
            'valid_wav': False,
            'properties': {}
        }
        
        if not results['exists']:
            return results
        
        try:
            # Try to open as WAV
            with wave.open(filepath, 'rb') as wav:
                results['readable'] = True
                results['valid_wav'] = True
                
                # Get properties
                results['properties'] = {
                    'channels': wav.getnchannels(),
                    'sample_width': wav.getsampwidth(),
                    'framerate': wav.getframerate(),
                    'n_frames': wav.getnframes(),
                    'duration': wav.getnframes() / wav.getframerate(),
                    'file_size': os.path.getsize(filepath)
                }
                
                # Calculate checksum
                wav.rewind()
                data = wav.readframes(wav.getnframes())
                results['checksum'] = hashlib.sha256(data).hexdigest()[:16]
                
        except Exception as e:
            results['error'] = str(e)
        
        return results
    
    def analyze_frequency_content(self, 
                                 audio_data: np.ndarray, 
                                 sample_rate: int) -> Dict:
        """
        Analyze frequency content of audio
        
        Args:
            audio_data: Audio samples
            sample_rate: Sample rate
            
        Returns:
            Frequency analysis results
        """
        # Compute FFT
        fft_data = np.fft.rfft(audio_data)
        frequencies = np.fft.rfftfreq(len(audio_data), 1/sample_rate)
        magnitude = np.abs(fft_data)
        
        # Find peaks
        peaks, properties = signal.find_peaks(magnitude, height=np.max(magnitude) * 0.1)
        peak_frequencies = frequencies[peaks]
        peak_magnitudes = magnitude[peaks]
        
        # Sort by magnitude
        sorted_indices = np.argsort(peak_magnitudes)[::-1]
        top_peaks = [(peak_frequencies[i], peak_magnitudes[i]) 
                     for i in sorted_indices[:10]]
        
        # Check for expected genomic frequencies
        genomic_freqs = {
            'A_primary': 146.83,
            'T_primary': 174.61,
            'C_primary': 261.63,
            'G_primary': 392.00,
            'separator': 528.0
        }
        
        detected_genomic = {}
        for name, target_freq in genomic_freqs.items():
            # Find closest peak to target
            if len(peak_frequencies) > 0:
                closest_idx = np.argmin(np.abs(peak_frequencies - target_freq))
                closest_freq = peak_frequencies[closest_idx]
                
                # Check if within 5% of target
                if abs(closest_freq - target_freq) / target_freq < 0.05:
                    detected_genomic[name] = {
                        'detected': float(closest_freq),
                        'expected': target_freq,
                        'magnitude': float(peak_magnitudes[closest_idx])
                    }
        
        return {
            'dominant_frequency': float(frequencies[np.argmax(magnitude)]),
            'top_peaks': [(float(f), float(m)) for f, m in top_peaks],
            'detected_genomic_frequencies': detected_genomic,
            'spectral_centroid': float(np.sum(frequencies * magnitude) / np.sum(magnitude)),
            'spectral_bandwidth': float(np.sqrt(np.sum(((frequencies - np.sum(frequencies * magnitude) / np.sum(magnitude)) ** 2) * magnitude) / np.sum(magnitude)))
        }
    
    def detect_embedded_signal(self,
                              original: np.ndarray,
                              modulated: np.ndarray,
                              sample_rate: int) -> Dict:
        """
        Detect embedded genomic signal in carrier
        
        Args:
            original: Original carrier audio
            modulated: Modulated audio with embedded signal
            sample_rate: Sample rate
            
        Returns:
            Detection results
        """
        # Ensure same length
        min_len = min(len(original), len(modulated))
        original = original[:min_len]
        modulated = modulated[:min_len]
        
        # Extract difference (embedded signal)
        difference = modulated - original
        
        # Analyze embedded signal
        embedded_rms = np.sqrt(np.mean(difference ** 2))
        carrier_rms = np.sqrt(np.mean(original ** 2))
        
        # Calculate SNR
        if carrier_rms > 0:
            snr_db = 20 * np.log10(embedded_rms / carrier_rms)
        else:
            snr_db = -np.inf
        
        # Frequency analysis of embedded signal
        fft_embedded = np.fft.rfft(difference)
        frequencies = np.fft.rfftfreq(len(difference), 1/sample_rate)
        magnitude = np.abs(fft_embedded)
        
        # Check for 528 Hz carrier
        carrier_idx = np.argmin(np.abs(frequencies - 528.0))
        carrier_detected = magnitude[carrier_idx] > np.mean(magnitude) * 2
        
        return {
            'embedded_rms': float(embedded_rms),
            'carrier_rms': float(carrier_rms),
            'snr_db': float(snr_db),
            'embedding_level_db': float(snr_db),
            'subaudible': -55 <= snr_db <= -33,
            '528hz_carrier_detected': carrier_detected,
            'carrier_magnitude': float(magnitude[carrier_idx]) if carrier_detected else 0
        }
    
    def verify_dna_reconstruction(self,
                                 original_sequence: str,
                                 audio_file: str,
                                 sample_rate: int = 192000) -> Dict:
        """
        Verify if DNA sequence can be reconstructed from audio
        
        Args:
            original_sequence: Original DNA sequence
            audio_file: Path to audio file
            sample_rate: Expected sample rate
            
        Returns:
            Reconstruction verification results
        """
        # This is a placeholder for actual reconstruction logic
        # In practice, would need inverse processing pipeline
        
        return {
            'original_length': len(original_sequence),
            'gc_content': (original_sequence.count('G') + original_sequence.count('C')) / len(original_sequence) * 100,
            'reconstruction_possible': True,  # Placeholder
            'notes': 'Full reconstruction requires inverse pipeline implementation'
        }
    
    def generate_verification_report(self,
                                    audio_file: str,
                                    config: Dict,
                                    save_path: Optional[str] = None) -> Dict:
        """
        Generate comprehensive verification report
        
        Args:
            audio_file: Path to audio file
            config: Processing configuration
            save_path: Optional path to save report
            
        Returns:
            Verification report
        """
        report = {
            'audio_file': audio_file,
            'timestamp': os.path.getmtime(audio_file) if os.path.exists(audio_file) else None,
            'configuration': config,
            'verification': {}
        }
        
        # Verify file integrity
        integrity = self.verify_audio_integrity(audio_file)
        report['verification']['integrity'] = integrity
        
        if integrity['valid_wav']:
            # Load audio for analysis
            try:
                with wave.open(audio_file, 'rb') as wav:
                    frames = wav.readframes(wav.getnframes())
                    
                    # Convert to numpy array
                    if wav.getsampwidth() == 2:
                        audio_data = np.frombuffer(frames, dtype=np.int16).astype(float) / 32768
                    elif wav.getsampwidth() == 4:
                        audio_data = np.frombuffer(frames, dtype=np.int32).astype(float) / 2147483648
                    else:
                        audio_data = np.frombuffer(frames, dtype=np.uint8).astype(float) / 128 - 1
                    
                    sample_rate = wav.getframerate()
                
                # Frequency analysis
                freq_analysis = self.analyze_frequency_content(audio_data, sample_rate)
                report['verification']['frequency_analysis'] = freq_analysis
                
                # Check for genomic signatures
                has_genomic = len(freq_analysis['detected_genomic_frequencies']) > 0
                report['verification']['genomic_signature_detected'] = has_genomic
                
            except Exception as e:
                report['verification']['analysis_error'] = str(e)
        
        # Save report if requested
        if save_path:
            with open(save_path, 'w') as f:
                json.dump(report, f, indent=2)
        
        return report

class AudioVisualizer:
    """Visualize audio and genomic data"""
    
    def __init__(self):
        """Initialize visualizer"""
        self.figure_size = (12, 8)
        
    def plot_waveform(self, 
                     audio_data: np.ndarray, 
                     sample_rate: int,
                     title: str = "Audio Waveform",
                     save_path: Optional[str] = None):
        """
        Plot audio waveform
        
        Args:
            audio_data: Audio samples
            sample_rate: Sample rate
            title: Plot title
            save_path: Optional path to save plot
        """
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=self.figure_size)
        
        # Time axis
        time = np.arange(len(audio_data)) / sample_rate
        
        # Full waveform
        ax1.plot(time, audio_data, linewidth=0.5)
        ax1.set_xlabel('Time (s)')
        ax1.set_ylabel('Amplitude')
        ax1.set_title(f'{title} - Full')
        ax1.grid(True, alpha=0.3)
        
        # Zoomed view (first second)
        zoom_samples = min(sample_rate, len(audio_data))
        ax2.plot(time[:zoom_samples], audio_data[:zoom_samples], linewidth=0.5)
        ax2.set_xlabel('Time (s)')
        ax2.set_ylabel('Amplitude')
        ax2.set_title(f'{title} - First Second')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150)
        else:
            plt.show()
        
        plt.close()
    
    def plot_spectrogram(self,
                        audio_data: np.ndarray,
                        sample_rate: int,
                        title: str = "Spectrogram",
                        save_path: Optional[str] = None):
        """
        Plot spectrogram
        
        Args:
            audio_data: Audio samples
            sample_rate: Sample rate
            title: Plot title
            save_path: Optional path to save plot
        """
        fig, ax = plt.subplots(figsize=self.figure_size)
        
        # Compute spectrogram
        frequencies, times, Sxx = signal.spectrogram(
            audio_data, 
            sample_rate,
            nperseg=1024,
            noverlap=512
        )
        
        # Plot in dB scale
        Sxx_db = 10 * np.log10(Sxx + 1e-10)
        
        im = ax.pcolormesh(times, frequencies, Sxx_db, shading='gouraud', cmap='viridis')
        ax.set_ylabel('Frequency (Hz)')
        ax.set_xlabel('Time (s)')
        ax.set_title(title)
        ax.set_ylim([0, 2000])  # Focus on genomic frequency range
        
        # Add colorbar
        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label('Power (dB)')
        
        # Mark genomic frequencies
        genomic_freqs = [146.83, 174.61, 261.63, 392.00, 528.0]
        for freq in genomic_freqs:
            ax.axhline(y=freq, color='red', linestyle='--', alpha=0.5, linewidth=0.5)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150)
        else:
            plt.show()
        
        plt.close()
    
    def plot_frequency_spectrum(self,
                              audio_data: np.ndarray,
                              sample_rate: int,
                              title: str = "Frequency Spectrum",
                              save_path: Optional[str] = None):
        """
        Plot frequency spectrum
        
        Args:
            audio_data: Audio samples
            sample_rate: Sample rate
            title: Plot title
            save_path: Optional path to save plot
        """
        fig, ax = plt.subplots(figsize=self.figure_size)
        
        # Compute FFT
        fft_data = np.fft.rfft(audio_data)
        frequencies = np.fft.rfftfreq(len(audio_data), 1/sample_rate)
        magnitude = np.abs(fft_data)
        
        # Plot in dB scale
        magnitude_db = 20 * np.log10(magnitude + 1e-10)
        
        ax.semilogx(frequencies[1:], magnitude_db[1:])  # Skip DC component
        ax.set_xlabel('Frequency (Hz)')
        ax.set_ylabel('Magnitude (dB)')
        ax.set_title(title)
        ax.grid(True, which='both', alpha=0.3)
        ax.set_xlim([20, sample_rate/2])
        
        # Mark genomic frequencies
        genomic_freqs = {
            'A': 146.83,
            'T': 174.61,
            'C': 261.63,
            'G': 392.00,
            '528Hz': 528.0
        }
        
        for label, freq in genomic_freqs.items():
            ax.axvline(x=freq, color='red', linestyle='--', alpha=0.5)
            ax.text(freq, ax.get_ylim()[1] - 5, label, rotation=90, ha='right')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150)
        else:
            plt.show()
        
        plt.close()
    
    def plot_dna_distribution(self,
                             dna_sequence: str,
                             title: str = "DNA Base Distribution",
                             save_path: Optional[str] = None):
        """
        Plot DNA base distribution
        
        Args:
            dna_sequence: DNA sequence
            title: Plot title
            save_path: Optional path to save plot
        """
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=self.figure_size)
        
        # Count bases
        bases = ['A', 'T', 'C', 'G']
        if 'U' in dna_sequence:
            bases = ['A', 'U', 'C', 'G']
        
        counts = [dna_sequence.count(base) for base in bases]
        
        # Pie chart
        colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4']
        ax1.pie(counts, labels=bases, colors=colors, autopct='%1.1f%%')
        ax1.set_title('Base Composition')
        
        # Bar chart with counts
        ax2.bar(bases, counts, color=colors)
        ax2.set_xlabel('Base')
        ax2.set_ylabel('Count')
        ax2.set_title('Base Frequency')
        
        # Add total count
        total = sum(counts)
        ax2.text(0.5, max(counts) * 0.95, f'Total: {total} bases', 
                ha='center', transform=ax2.transData)
        
        plt.suptitle(title)
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150)
        else:
            plt.show()
        
        plt.close()

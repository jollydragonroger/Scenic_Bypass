"""
Data modules for Audio Genomics Pro
"""

from .dna_frequencies import (
    get_base_frequency,
    get_waveform_type,
    SEPARATOR_FREQUENCY,
    CARRIER_FREQUENCY,
    DNA_FREQUENCIES,
    SOLFEGGIO_FREQUENCIES,
    TUNING_A432,
    TUNING_A440
)

# Aliases for compatibility
BASE_FREQUENCIES = DNA_FREQUENCIES
NUCLEOTIDE_FREQUENCIES = DNA_FREQUENCIES

__all__ = [
    'get_base_frequency',
    'get_waveform_type',
    'SEPARATOR_FREQUENCY',
    'CARRIER_FREQUENCY',
    'DNA_FREQUENCIES',
    'BASE_FREQUENCIES',
    'NUCLEOTIDE_FREQUENCIES',
    'SOLFEGGIO_FREQUENCIES',
    'TUNING_A432',
    'TUNING_A440'
]

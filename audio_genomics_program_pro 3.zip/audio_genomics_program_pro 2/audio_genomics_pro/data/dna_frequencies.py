"""
DNA/RNA Base Frequency Mappings
High-precision frequency values for audio synthesis
Based on infrared absorption spectra scaled to audible range
All frequencies in Hz with up to 38 decimal places of precision
"""

from decimal import Decimal, getcontext

# Set precision for Decimal operations
getcontext().prec = 40

# Base frequency mappings (primary resonances)
# These represent the scaled infrared absorption peaks
DNA_FREQUENCIES = {
    'A': {  # Adenine
        'primary': Decimal('545.6000000000000000000000000000000000'),
        'secondary': [
            Decimal('432.0000000000000000000000000000000000'),
            Decimal('553.2000000000000000000000000000000000'),
            Decimal('728.4000000000000000000000000000000000'),
            Decimal('892.1000000000000000000000000000000000'),
        ],
        'waveform': 'sine'
    },
    'C': {  # Cytosine
        'primary': Decimal('537.8000000000000000000000000000000000'),
        'secondary': [
            Decimal('396.0000000000000000000000000000000000'),
            Decimal('518.9000000000000000000000000000000000'),
            Decimal('682.7000000000000000000000000000000000'),
            Decimal('837.3000000000000000000000000000000000'),
        ],
        'waveform': 'sawtooth'
    },
    'G': {  # Guanine
        'primary': Decimal('550.3000000000000000000000000000000000'),
        'secondary': [
            Decimal('417.0000000000000000000000000000000000'),
            Decimal('625.4000000000000000000000000000000000'),
            Decimal('798.6000000000000000000000000000000000'),
            Decimal('924.2000000000000000000000000000000000'),
        ],
        'waveform': 'triangle'
    },
    'T': {  # Thymine
        'primary': Decimal('543.4000000000000000000000000000000000'),
        'secondary': [
            Decimal('374.0000000000000000000000000000000000'),
            Decimal('497.8000000000000000000000000000000000'),
            Decimal('615.3000000000000000000000000000000000'),
            Decimal('772.9000000000000000000000000000000000'),
        ],
        'waveform': 'square'
    },
    'U': {  # Uracil (RNA)
        'primary': Decimal('542.1000000000000000000000000000000000'),
        'secondary': [
            Decimal('369.0000000000000000000000000000000000'),
            Decimal('493.2000000000000000000000000000000000'),
            Decimal('611.7000000000000000000000000000000000'),
            Decimal('768.5000000000000000000000000000000000'),
        ],
        'waveform': 'impulse'
    },
    'N': {  # Unknown/Any base
        'primary': Decimal('555.0000000000000000000000000000000000'),
        'secondary': [],
        'waveform': 'impulse'
    }
}

# Solfeggio frequencies for carriers and separators
SOLFEGGIO_FREQUENCIES = {
    'UT': Decimal('396.0000000000000000000000000000000000'),  # Liberation from fear
    'RE': Decimal('417.0000000000000000000000000000000000'),  # Facilitating change
    'MI': Decimal('528.0000000000000000000000000000000000'),  # DNA repair/Love frequency
    'FA': Decimal('639.0000000000000000000000000000000000'),  # Connecting relationships
    'SOL': Decimal('741.0000000000000000000000000000000000'), # Awakening intuition
    'LA': Decimal('852.0000000000000000000000000000000000'),  # Returning to spiritual order
}

# Special frequencies
SEPARATOR_FREQUENCY = SOLFEGGIO_FREQUENCIES['MI']  # 528 Hz for separators
CARRIER_FREQUENCY = SOLFEGGIO_FREQUENCIES['MI']    # 528 Hz for FM carrier

# Reference tuning frequencies
TUNING_A440 = Decimal('440.0000000000000000000000000000000000')
TUNING_A432 = Decimal('432.0000000000000000000000000000000000')

# Frequency scaling factors for octave relationships
OCTAVE_UP = Decimal('2.0000000000000000000000000000000000')
OCTAVE_DOWN = Decimal('0.5000000000000000000000000000000000')

def get_base_frequency(base, mode='primary'):
    """
    Get frequency for a DNA/RNA base
    
    Args:
        base: Single character (A, C, G, T, U, N)
        mode: 'primary' or index for secondary frequencies
    
    Returns:
        Decimal frequency value
    """
    base = base.upper()
    if base not in DNA_FREQUENCIES:
        return DNA_FREQUENCIES['N']['primary']
    
    if mode == 'primary':
        return DNA_FREQUENCIES[base]['primary']
    elif isinstance(mode, int) and mode < len(DNA_FREQUENCIES[base]['secondary']):
        return DNA_FREQUENCIES[base]['secondary'][mode]
    else:
        return DNA_FREQUENCIES[base]['primary']

def get_waveform_type(base):
    """Get the waveform type for a base"""
    base = base.upper()
    if base not in DNA_FREQUENCIES:
        return 'impulse'
    return DNA_FREQUENCIES[base]['waveform']

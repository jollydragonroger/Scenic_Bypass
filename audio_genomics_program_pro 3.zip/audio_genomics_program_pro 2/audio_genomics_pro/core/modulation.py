"""
Multi-Stage Audio Modulation Module
Implements FM and AM modulation for embedding genomic audio into music
"""

import numpy as np
from typing import Optional, Tuple
from decimal import Decimal
import scipy.signal as signal
from scipy.signal import butter, lfilter, resample

class ModulationProcessor:
    """Handles FM and AM modulation of genomic audio"""
    
    def __init__(self, sample_rate: int = 192000):
        """
        Initialize modulation processor
        
        Args:
            sample_rate: Sample rate in Hz
        """
        self.sample_rate = sample_rate
        
    def fm_modulate(self,
                   modulator: np.ndarray,
                   carrier_freq: float = 528.0,
                   modulation_index: float = 0.1,
                   phase: float = 0) -> np.ndarray:
        """
        Apply FM modulation with genomic signal onto carrier
        
        Args:
            modulator: Modulating signal (genomic audio)
            carrier_freq: Carrier frequency in Hz (default 528 Hz)
            modulation_index: FM modulation depth (0-1)
            phase: Initial phase offset
            
        Returns:
            FM modulated signal
        """
        # Normalize modulator to [-1, 1]
        if np.max(np.abs(modulator)) > 0:
            modulator_norm = modulator / np.max(np.abs(modulator))
        else:
            modulator_norm = modulator
        
        # Time array
        t = np.arange(len(modulator)) / self.sample_rate
        
        # Calculate frequency deviation
        freq_deviation = carrier_freq * modulation_index
        
        # FM modulation: y(t) = A*sin(2π*fc*t + β*∫m(t)dt)
        # where β is the modulation index and m(t) is the modulator
        
        # Integrate the modulator (cumulative sum normalized by sample rate)
        modulator_integral = np.cumsum(modulator_norm) / self.sample_rate
        
        # Generate FM signal
        fm_signal = np.sin(2 * np.pi * carrier_freq * t + 
                          2 * np.pi * freq_deviation * modulator_integral + 
                          phase)
        
        return fm_signal
    
    def am_modulate(self,
                   carrier: np.ndarray,
                   modulator: np.ndarray,
                   modulation_depth: float = 0.05,
                   mode: str = 'standard') -> np.ndarray:
        """
        Apply AM modulation to embed modulator into carrier
        
        Args:
            carrier: Carrier signal (music)
            modulator: Modulating signal (FM genomic audio)
            modulation_depth: AM depth (0-1, default 0.05 for subaudible)
            mode: 'standard' or 'dsb-sc' (double sideband suppressed carrier)
            
        Returns:
            AM modulated signal
        """
        # Ensure signals are same length
        min_length = min(len(carrier), len(modulator))
        carrier = carrier[:min_length]
        modulator = modulator[:min_length]
        
        # Normalize modulator
        if np.max(np.abs(modulator)) > 0:
            modulator_norm = modulator / np.max(np.abs(modulator))
        else:
            modulator_norm = modulator
        
        if mode == 'standard':
            # Standard AM: y(t) = carrier(t) * (1 + m * modulator(t))
            am_signal = carrier * (1 + modulation_depth * modulator_norm)
        elif mode == 'dsb-sc':
            # DSB-SC: y(t) = carrier(t) * modulator(t)
            am_signal = carrier * modulator_norm * modulation_depth
        else:
            raise ValueError(f"Unknown AM mode: {mode}")
        
        # Prevent clipping
        max_val = np.max(np.abs(am_signal))
        if max_val > 0.95:
            am_signal = am_signal * (0.95 / max_val)
        
        return am_signal
    
    def nested_modulation(self,
                         layers: list,
                         carrier_frequencies: Optional[list] = None,
                         fm_indices: Optional[list] = None,
                         am_depths: Optional[list] = None) -> np.ndarray:
        """
        Apply nested modulation for multiple layers
        
        Args:
            layers: List of audio layers (DNA sequences as audio)
            carrier_frequencies: FM carrier frequencies for each layer
            fm_indices: FM modulation indices for each layer
            am_depths: AM modulation depths for combining layers
            
        Returns:
            Nested modulated signal
        """
        if carrier_frequencies is None:
            # Use different Solfeggio frequencies
            carrier_frequencies = [528.0, 639.0, 741.0, 852.0][:len(layers)]
        
        if fm_indices is None:
            fm_indices = [0.1] * len(layers)
        
        if am_depths is None:
            # Decreasing depths for each layer
            am_depths = [0.5 ** i for i in range(len(layers))]
        
        # FM modulate each layer
        fm_layers = []
        for i, layer in enumerate(layers):
            fm_freq = carrier_frequencies[i % len(carrier_frequencies)]
            fm_index = fm_indices[i % len(fm_indices)]
            fm_signal = self.fm_modulate(layer, fm_freq, fm_index)
            fm_layers.append(fm_signal)
        
        # Nested AM modulation
        result = fm_layers[0]
        for i in range(1, len(fm_layers)):
            am_depth = am_depths[i % len(am_depths)]
            result = self.am_modulate(result, fm_layers[i], am_depth)
        
        return result
    
    def subaudible_embedding(self,
                            genomic_signal: np.ndarray,
                            target_db: float = -40.0) -> np.ndarray:
        """
        Adjust signal to subaudible level
        
        Args:
            genomic_signal: Signal to embed
            target_db: Target level in dB (typically -33 to -55)
            
        Returns:
            Signal at subaudible level
        """
        # Calculate current RMS
        rms = np.sqrt(np.mean(genomic_signal ** 2))
        
        if rms == 0:
            return genomic_signal
        
        # Convert dB to amplitude
        target_amplitude = 10 ** (target_db / 20)
        
        # Scale signal
        scaling_factor = target_amplitude / rms
        subaudible_signal = genomic_signal * scaling_factor
        
        return subaudible_signal
    
    def apply_bandpass_filter(self,
                            signal: np.ndarray,
                            low_freq: float,
                            high_freq: float,
                            order: int = 5) -> np.ndarray:
        """
        Apply bandpass filter to signal
        
        Args:
            signal: Input signal
            low_freq: Lower cutoff frequency
            high_freq: Upper cutoff frequency
            order: Filter order
            
        Returns:
            Filtered signal
        """
        nyquist = self.sample_rate / 2
        low = low_freq / nyquist
        high = high_freq / nyquist
        
        # Design Butterworth bandpass filter
        b, a = butter(order, [low, high], btype='band')
        
        # Apply filter
        filtered = lfilter(b, a, signal)
        
        return filtered
    
    def frequency_lock(self,
                      genomic_signal: np.ndarray,
                      music_signal: np.ndarray,
                      lock_strength: float = 0.5) -> np.ndarray:
        """
        Lock genomic frequencies to musical harmonics
        
        Args:
            genomic_signal: Genomic audio signal
            music_signal: Music carrier signal
            lock_strength: How strongly to lock frequencies (0-1)
            
        Returns:
            Frequency-locked genomic signal
        """
        # Perform FFT on both signals
        genomic_fft = np.fft.rfft(genomic_signal)
        music_fft = np.fft.rfft(music_signal[:len(genomic_signal)])
        
        # Find dominant frequencies in music
        music_magnitudes = np.abs(music_fft)
        threshold = np.max(music_magnitudes) * 0.1
        dominant_bins = np.where(music_magnitudes > threshold)[0]
        
        # Create frequency locking mask
        lock_mask = np.ones_like(genomic_fft, dtype=complex)
        
        for bin_idx in dominant_bins:
            # Find nearby bins in genomic signal
            window = 10  # bins around dominant frequency
            start = max(0, bin_idx - window)
            end = min(len(genomic_fft), bin_idx + window)
            
            # Apply gentle attraction to dominant frequency
            for i in range(start, end):
                if i < len(genomic_fft):
                    distance = abs(i - bin_idx)
                    attraction = 1 - (distance / window) * lock_strength
                    lock_mask[i] *= attraction
        
        # Apply mask
        locked_fft = genomic_fft * lock_mask
        
        # Convert back to time domain
        locked_signal = np.fft.irfft(locked_fft, n=len(genomic_signal))
        
        return locked_signal
    
    def stereo_embedding(self,
                        genomic_signal: np.ndarray,
                        music_signal: np.ndarray,
                        mode: str = 'complementary') -> Tuple[np.ndarray, np.ndarray]:
        """
        Create stereo output with different embedding strategies
        
        Args:
            genomic_signal: Genomic audio to embed
            music_signal: Stereo or mono music carrier
            mode: 'complementary', 'phase_shift', or 'single_channel'
            
        Returns:
            Tuple of (left_channel, right_channel)
        """
        # Handle stereo/mono music input
        if music_signal.ndim == 2:
            left_music = music_signal[:, 0]
            right_music = music_signal[:, 1]
        else:
            left_music = music_signal
            right_music = music_signal.copy()
        
        # Ensure same length
        min_length = min(len(genomic_signal), len(left_music))
        genomic_signal = genomic_signal[:min_length]
        left_music = left_music[:min_length]
        right_music = right_music[:min_length]
        
        if mode == 'complementary':
            # Embed with opposite phase in each channel
            left_embedded = self.am_modulate(left_music, genomic_signal, 0.05)
            right_embedded = self.am_modulate(right_music, -genomic_signal, 0.05)
            
        elif mode == 'phase_shift':
            # 90-degree phase shift between channels
            samples_90deg = int(self.sample_rate / 528 / 4)  # 90 degrees at 528 Hz
            shifted_genomic = np.roll(genomic_signal, samples_90deg)
            
            left_embedded = self.am_modulate(left_music, genomic_signal, 0.05)
            right_embedded = self.am_modulate(right_music, shifted_genomic, 0.05)
            
        elif mode == 'single_channel':
            # Embed only in left channel
            left_embedded = self.am_modulate(left_music, genomic_signal, 0.05)
            right_embedded = right_music
            
        else:
            raise ValueError(f"Unknown stereo mode: {mode}")
        
        return left_embedded, right_embedded
    
    def measure_embedding_level(self, 
                               original: np.ndarray, 
                               embedded: np.ndarray) -> dict:
        """
        Measure the level of embedded signal relative to carrier
        
        Args:
            original: Original carrier signal
            embedded: Carrier with embedded signal
            
        Returns:
            Dictionary with embedding measurements
        """
        # Calculate difference (embedded signal)
        difference = embedded - original[:len(embedded)]
        
        # Calculate RMS values
        carrier_rms = np.sqrt(np.mean(original ** 2))
        embedded_rms = np.sqrt(np.mean(difference ** 2))
        
        # Calculate dB ratio
        if carrier_rms > 0 and embedded_rms > 0:
            db_ratio = 20 * np.log10(embedded_rms / carrier_rms)
        else:
            db_ratio = -np.inf
        
        return {
            'carrier_rms': float(carrier_rms),
            'embedded_rms': float(embedded_rms),
            'embedding_db': float(db_ratio),
            'in_target_range': -55 <= db_ratio <= -33
        }

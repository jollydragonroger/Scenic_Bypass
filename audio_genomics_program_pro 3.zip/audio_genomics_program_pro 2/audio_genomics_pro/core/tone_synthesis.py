"""
Dynamic Tone Generation Engine
Generates precise audio waveforms for DNA/RNA bases
Implements high-precision synthesis with exact cycle counts
"""

import numpy as np
from decimal import Decimal
import scipy.signal as signal
from typing import Union, Tuple, Optional
import array

class ToneSynthesizer:
    """High-precision tone synthesizer for DNA/RNA base frequencies"""
    
    def __init__(self, sample_rate: int = 192000, bit_depth: int = 32):
        """
        Initialize synthesizer with high-quality audio parameters
        
        Args:
            sample_rate: Sample rate in Hz (default 192kHz for high fidelity)
            bit_depth: Bit depth (16, 24, or 32)
        """
        self.sample_rate = sample_rate
        self.bit_depth = bit_depth
        self.dtype = np.float64  # Use double precision for calculations
        
    def generate_sine(self, frequency: Decimal, duration: float, phase: float = 0) -> np.ndarray:
        """Generate sine wave with exact frequency"""
        freq_float = float(frequency)
        t = np.linspace(0, duration, int(self.sample_rate * duration), dtype=self.dtype)
        return np.sin(2 * np.pi * freq_float * t + phase)
    
    def generate_sawtooth(self, frequency: Decimal, duration: float, phase: float = 0) -> np.ndarray:
        """Generate sawtooth wave"""
        freq_float = float(frequency)
        t = np.linspace(0, duration, int(self.sample_rate * duration), dtype=self.dtype)
        return signal.sawtooth(2 * np.pi * freq_float * t + phase)
    
    def generate_triangle(self, frequency: Decimal, duration: float, phase: float = 0) -> np.ndarray:
        """Generate triangle wave"""
        freq_float = float(frequency)
        t = np.linspace(0, duration, int(self.sample_rate * duration), dtype=self.dtype)
        return signal.sawtooth(2 * np.pi * freq_float * t + phase, width=0.5)
    
    def generate_square(self, frequency: Decimal, duration: float, phase: float = 0) -> np.ndarray:
        """Generate square wave"""
        freq_float = float(frequency)
        t = np.linspace(0, duration, int(self.sample_rate * duration), dtype=self.dtype)
        return signal.square(2 * np.pi * freq_float * t + phase)
    
    def generate_impulse(self, frequency: Decimal, duration: float) -> np.ndarray:
        """Generate impulse train (series of brief pulses)"""
        freq_float = float(frequency)
        samples = int(self.sample_rate * duration)
        wave = np.zeros(samples, dtype=self.dtype)
        
        # Create impulses at the frequency interval
        period_samples = int(self.sample_rate / freq_float)
        impulse_width = max(1, int(period_samples * 0.05))  # 5% duty cycle
        
        for i in range(0, samples, period_samples):
            if i + impulse_width < samples:
                wave[i:i+impulse_width] = 1.0
            else:
                wave[i:] = 1.0
                
        return wave
    
    def generate_tone(self, frequency: Decimal, waveform: str, cycles: int = 3) -> np.ndarray:
        """
        Generate tone for exact number of cycles
        
        Args:
            frequency: Frequency in Hz (Decimal for precision)
            waveform: Type of waveform ('sine', 'sawtooth', 'triangle', 'square', 'impulse')
            cycles: Number of complete cycles to generate
        
        Returns:
            NumPy array of audio samples
        """
        # Calculate exact duration for specified cycles
        freq_float = float(frequency)
        period = 1.0 / freq_float
        duration = period * cycles
        
        # Generate waveform based on type
        generators = {
            'sine': self.generate_sine,
            'sawtooth': self.generate_sawtooth,
            'triangle': self.generate_triangle,
            'square': self.generate_square,
            'impulse': self.generate_impulse
        }
        
        generator = generators.get(waveform.lower(), self.generate_sine)
        samples = generator(frequency, duration)
        
        # Apply fade in/out to prevent clicks (very brief, ~0.5ms)
        fade_samples = int(self.sample_rate * 0.0005)
        if len(samples) > fade_samples * 2:
            fade_in = np.linspace(0, 1, fade_samples)
            fade_out = np.linspace(1, 0, fade_samples)
            samples[:fade_samples] *= fade_in
            samples[-fade_samples:] *= fade_out
            
        return samples
    
    def generate_separator(self, frequency: Decimal, cycles: int = 1) -> np.ndarray:
        """
        Generate separator impulse at specified frequency
        
        Args:
            frequency: Separator frequency (typically 528 Hz)
            cycles: Number of cycles for the separator
            
        Returns:
            NumPy array of separator audio
        """
        return self.generate_tone(frequency, 'impulse', cycles)
    
    def apply_envelope(self, samples: np.ndarray, 
                      attack: float = 0.001, 
                      decay: float = 0.01,
                      sustain: float = 0.8,
                      release: float = 0.001) -> np.ndarray:
        """
        Apply ADSR envelope to audio samples
        
        Args:
            samples: Input audio samples
            attack: Attack time in seconds
            decay: Decay time in seconds
            sustain: Sustain level (0-1)
            release: Release time in seconds
            
        Returns:
            Enveloped audio samples
        """
        total_samples = len(samples)
        envelope = np.ones(total_samples, dtype=self.dtype)
        
        # Calculate sample counts for each phase
        attack_samples = int(self.sample_rate * attack)
        decay_samples = int(self.sample_rate * decay)
        release_samples = int(self.sample_rate * release)
        sustain_samples = total_samples - attack_samples - decay_samples - release_samples
        
        if sustain_samples < 0:
            # Adjust if total is too short
            ratio = total_samples / (attack_samples + decay_samples + release_samples)
            attack_samples = int(attack_samples * ratio)
            decay_samples = int(decay_samples * ratio)
            release_samples = int(release_samples * ratio)
            sustain_samples = 0
        
        # Build envelope
        current_pos = 0
        
        # Attack
        if attack_samples > 0:
            envelope[current_pos:current_pos + attack_samples] = np.linspace(0, 1, attack_samples)
            current_pos += attack_samples
        
        # Decay
        if decay_samples > 0:
            envelope[current_pos:current_pos + decay_samples] = np.linspace(1, sustain, decay_samples)
            current_pos += decay_samples
        
        # Sustain
        if sustain_samples > 0:
            envelope[current_pos:current_pos + sustain_samples] = sustain
            current_pos += sustain_samples
        
        # Release
        if current_pos < total_samples:
            remaining = total_samples - current_pos
            envelope[current_pos:] = np.linspace(sustain, 0, remaining)
        
        return samples * envelope
    
    def normalize_audio(self, samples: np.ndarray, target_db: float = -3.0) -> np.ndarray:
        """
        Normalize audio to target dB level
        
        Args:
            samples: Input audio samples
            target_db: Target level in dB (negative values)
            
        Returns:
            Normalized audio samples
        """
        # Calculate current RMS
        rms = np.sqrt(np.mean(samples ** 2))
        if rms == 0:
            return samples
        
        # Calculate target amplitude from dB
        target_amplitude = 10 ** (target_db / 20)
        
        # Scale to target
        scaling_factor = target_amplitude / rms
        return samples * scaling_factor
    
    def to_int_samples(self, samples: np.ndarray) -> np.ndarray:
        """
        Convert float samples to integer format based on bit depth
        
        Args:
            samples: Float audio samples (-1 to 1)
            
        Returns:
            Integer audio samples
        """
        # Ensure samples are in [-1, 1] range
        samples = np.clip(samples, -1.0, 1.0)
        
        if self.bit_depth == 16:
            return np.int16(samples * 32767)
        elif self.bit_depth == 24:
            # 24-bit requires special handling
            return np.int32(samples * 8388607)
        elif self.bit_depth == 32:
            return np.int32(samples * 2147483647)
        else:
            # Default to float32
            return np.float32(samples)

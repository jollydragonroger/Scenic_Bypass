"""
DNA Folding Compression System
Implements chromatin-like U-fold compression for efficient large file processing
Based on how DNA folds in chromosomal structures with bidirectional playback
"""

import numpy as np
from typing import List, Tuple, Optional, Generator
from dataclasses import dataclass
from enum import Enum
import multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import math


class FoldingLevel(Enum):
    """Levels of DNA-like folding compression"""
    LINEAR = 0          # No folding - standard linear playback
    SINGLE_FOLD = 1     # U-fold: halfway point, forward + reverse
    DOUBLE_FOLD = 2     # Double U-fold: quarters
    NUCLEOSOME = 3      # 8-fold like nucleosome wrapping
    CHROMATIN = 4       # 30nm fiber-like compression
    CHROMOSOME = 5      # Maximum compression like metaphase chromosome


@dataclass
class FoldedSegment:
    """Represents a folded segment of the sequence"""
    sequence: str
    start_position: int
    end_position: int
    fold_level: int
    direction: str  # 'forward' or 'reverse'
    fold_index: int
    

class DNAFoldingCompressor:
    """
    Compresses DNA sequences using chromatin-like folding
    
    The folding replicates biological DNA compression:
    - Linear sequence is folded at midpoint creating a U-shape
    - Beginning plays forward while end plays backward simultaneously
    - Further folds compress the sequence exponentially
    - Maintains continuous sound with synchronized bidirectional playback
    """
    
    def __init__(self, sample_rate: int = 192000):
        """
        Initialize DNA folding compressor
        
        Args:
            sample_rate: Audio sample rate for timing calculations
        """
        self.sample_rate = sample_rate
        self.fold_ratios = {
            FoldingLevel.LINEAR: 1.0,
            FoldingLevel.SINGLE_FOLD: 2.0,
            FoldingLevel.DOUBLE_FOLD: 4.0,
            FoldingLevel.NUCLEOSOME: 8.0,
            FoldingLevel.CHROMATIN: 30.0,
            FoldingLevel.CHROMOSOME: 100.0
        }
        
    def calculate_optimal_fold_level(self, sequence_length: int, 
                                     target_duration: Optional[float] = None) -> FoldingLevel:
        """
        Calculate optimal folding level based on sequence length
        
        Args:
            sequence_length: Length of DNA sequence in bases
            target_duration: Optional target duration in seconds
            
        Returns:
            Optimal folding level
        """
        if target_duration:
            base_duration_per_base = 0.01  # 10ms per base at standard rate
            required_compression = (sequence_length * base_duration_per_base) / target_duration
            
            for level in FoldingLevel:
                if self.fold_ratios[level] >= required_compression:
                    return level
            return FoldingLevel.CHROMOSOME
        
        # Auto-select based on sequence length
        if sequence_length < 1000:
            return FoldingLevel.LINEAR
        elif sequence_length < 10000:
            return FoldingLevel.SINGLE_FOLD
        elif sequence_length < 100000:
            return FoldingLevel.DOUBLE_FOLD
        elif sequence_length < 1000000:
            return FoldingLevel.NUCLEOSOME
        elif sequence_length < 10000000:
            return FoldingLevel.CHROMATIN
        else:
            return FoldingLevel.CHROMOSOME
    
    def fold_sequence(self, sequence: str, 
                      fold_level: FoldingLevel = FoldingLevel.SINGLE_FOLD) -> List[FoldedSegment]:
        """
        Fold a DNA sequence using chromatin-like U-fold compression
        
        The folding works like this:
        1. Take the sequence and find the midpoint
        2. The first half plays forward
        3. The second half plays backward (from end toward middle)
        4. Both play simultaneously, creating compression
        5. For higher fold levels, this process recurses
        
        Args:
            sequence: DNA/RNA sequence string
            fold_level: Level of folding to apply
            
        Returns:
            List of FoldedSegment objects representing the folded structure
        """
        if fold_level == FoldingLevel.LINEAR:
            return [FoldedSegment(
                sequence=sequence,
                start_position=0,
                end_position=len(sequence),
                fold_level=0,
                direction='forward',
                fold_index=0
            )]
        
        num_folds = 2 ** fold_level.value
        segments = []
        segment_length = len(sequence) // num_folds
        
        for i in range(num_folds):
            start = i * segment_length
            end = start + segment_length if i < num_folds - 1 else len(sequence)
            
            # Alternate direction: even indices forward, odd indices reverse
            # This creates the U-fold pattern
            direction = 'forward' if i % 2 == 0 else 'reverse'
            
            segment_seq = sequence[start:end]
            if direction == 'reverse':
                segment_seq = segment_seq[::-1]
            
            segments.append(FoldedSegment(
                sequence=segment_seq,
                start_position=start,
                end_position=end,
                fold_level=fold_level.value,
                direction=direction,
                fold_index=i
            ))
        
        return segments
    
    def create_bidirectional_pairs(self, sequence: str, 
                                   fold_level: FoldingLevel = FoldingLevel.SINGLE_FOLD) -> List[Tuple[str, str]]:
        """
        Create bidirectional sequence pairs for simultaneous playback
        
        Each pair contains:
        - Forward sequence (from start toward middle)
        - Reverse sequence (from end toward middle)
        
        These play simultaneously to compress the audio duration
        
        Args:
            sequence: DNA/RNA sequence
            fold_level: Folding level
            
        Returns:
            List of (forward, reverse) sequence pairs
        """
        num_folds = 2 ** fold_level.value
        pairs = []
        
        # For single fold: one pair (first half forward, second half reverse)
        # For double fold: two pairs, etc.
        
        segment_length = len(sequence) // (num_folds * 2)
        
        for i in range(num_folds):
            # Forward segment from the "left" side
            forward_start = i * segment_length
            forward_end = forward_start + segment_length
            
            # Reverse segment from the "right" side (mirror position)
            reverse_start = len(sequence) - (i + 1) * segment_length
            reverse_end = reverse_start + segment_length
            
            forward_seq = sequence[forward_start:forward_end]
            reverse_seq = sequence[reverse_start:reverse_end][::-1]  # Reverse the sequence
            
            pairs.append((forward_seq, reverse_seq))
        
        return pairs
    
    def generate_folded_audio_samples(self, 
                                      sequence: str,
                                      frequency_mapper,
                                      fold_level: FoldingLevel = FoldingLevel.SINGLE_FOLD,
                                      cycles_per_base: int = 3) -> Generator[np.ndarray, None, None]:
        """
        Generator that yields audio samples for folded sequence playback
        
        Uses bidirectional playback where forward and reverse sequences
        play simultaneously, effectively halving playback time per fold level
        
        Args:
            sequence: DNA/RNA sequence
            frequency_mapper: NucleotideFrequencyMapper instance
            fold_level: Level of folding
            cycles_per_base: Waveform cycles per nucleotide base
            
        Yields:
            Audio sample arrays for each base pair
        """
        pairs = self.create_bidirectional_pairs(sequence, fold_level)
        
        for forward_seq, reverse_seq in pairs:
            # Process pairs simultaneously
            max_len = max(len(forward_seq), len(reverse_seq))
            
            for i in range(max_len):
                combined_samples = np.zeros(0)
                
                # Get forward base frequency
                if i < len(forward_seq):
                    forward_base = forward_seq[i]
                    forward_freq = frequency_mapper.get_base_frequency(forward_base)
                    forward_samples = self._generate_base_samples(forward_freq, cycles_per_base)
                else:
                    forward_samples = np.zeros(int(self.sample_rate * 0.01))
                
                # Get reverse base frequency
                if i < len(reverse_seq):
                    reverse_base = reverse_seq[i]
                    reverse_freq = frequency_mapper.get_base_frequency(reverse_base)
                    reverse_samples = self._generate_base_samples(reverse_freq, cycles_per_base)
                else:
                    reverse_samples = np.zeros(int(self.sample_rate * 0.01))
                
                # Mix forward and reverse (stereo or summed mono)
                max_samples = max(len(forward_samples), len(reverse_samples))
                
                # Pad to same length
                if len(forward_samples) < max_samples:
                    forward_samples = np.pad(forward_samples, (0, max_samples - len(forward_samples)))
                if len(reverse_samples) < max_samples:
                    reverse_samples = np.pad(reverse_samples, (0, max_samples - len(reverse_samples)))
                
                # Sum with equal weighting
                combined_samples = (forward_samples + reverse_samples) / 2.0
                
                yield combined_samples
    
    def _generate_base_samples(self, frequency: float, cycles: int) -> np.ndarray:
        """Generate sine wave samples for a given frequency and cycle count"""
        duration = cycles / frequency
        num_samples = int(self.sample_rate * duration)
        t = np.linspace(0, duration, num_samples, endpoint=False)
        return np.sin(2 * np.pi * frequency * t)
    
    def process_large_sequence_parallel(self, 
                                        sequence: str,
                                        frequency_mapper,
                                        fold_level: FoldingLevel = FoldingLevel.SINGLE_FOLD,
                                        num_workers: Optional[int] = None,
                                        chunk_size: int = 100000) -> np.ndarray:
        """
        Process large sequences in parallel using multiple CPU cores
        
        Args:
            sequence: DNA/RNA sequence
            frequency_mapper: Frequency mapper instance
            fold_level: Folding level
            num_workers: Number of parallel workers (default: CPU count)
            chunk_size: Size of sequence chunks to process in parallel
            
        Returns:
            Combined audio samples array
        """
        if num_workers is None:
            num_workers = mp.cpu_count()
        
        # Split sequence into chunks
        chunks = []
        for i in range(0, len(sequence), chunk_size):
            chunks.append(sequence[i:i + chunk_size])
        
        # Process chunks in parallel
        results = []
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = []
            for chunk in chunks:
                future = executor.submit(
                    self._process_chunk,
                    chunk,
                    frequency_mapper,
                    fold_level
                )
                futures.append(future)
            
            for future in futures:
                results.append(future.result())
        
        # Concatenate results
        return np.concatenate(results)
    
    def _process_chunk(self, chunk: str, frequency_mapper, fold_level: FoldingLevel) -> np.ndarray:
        """Process a single chunk of sequence"""
        samples = []
        for sample_array in self.generate_folded_audio_samples(chunk, frequency_mapper, fold_level):
            samples.append(sample_array)
        
        if samples:
            return np.concatenate(samples)
        return np.array([])
    
    def get_compression_info(self, sequence_length: int, fold_level: FoldingLevel) -> dict:
        """
        Get information about compression for given parameters
        
        Args:
            sequence_length: Length of sequence
            fold_level: Folding level
            
        Returns:
            Dictionary with compression statistics
        """
        compression_ratio = self.fold_ratios[fold_level]
        original_duration = sequence_length * 0.01  # 10ms per base
        compressed_duration = original_duration / compression_ratio
        
        return {
            'sequence_length': sequence_length,
            'fold_level': fold_level.name,
            'fold_value': fold_level.value,
            'compression_ratio': compression_ratio,
            'original_duration_seconds': original_duration,
            'compressed_duration_seconds': compressed_duration,
            'num_folds': 2 ** fold_level.value,
            'time_saved_percent': (1 - 1/compression_ratio) * 100
        }


class ChromatinFoldingEngine:
    """
    Advanced chromatin-like folding engine
    Implements hierarchical folding similar to biological DNA packaging
    """
    
    # Biological folding levels
    NUCLEOSOME_WRAP = 147  # bp wrapped around histone
    LINKER_LENGTH = 50     # bp between nucleosomes
    SOLENOID_TURNS = 6     # nucleosomes per turn
    CHROMATIN_LOOP = 100000  # bp per chromatin loop
    
    def __init__(self, sample_rate: int = 192000):
        self.sample_rate = sample_rate
        self.compressor = DNAFoldingCompressor(sample_rate)
    
    def apply_nucleosome_folding(self, sequence: str) -> List[Tuple[str, int]]:
        """
        Apply nucleosome-like folding (147bp wrapped segments)
        
        Args:
            sequence: DNA sequence
            
        Returns:
            List of (wrapped_sequence, wrap_position) tuples
        """
        wrapped_segments = []
        position = 0
        
        while position < len(sequence):
            # Take nucleosome-sized segment
            end = min(position + self.NUCLEOSOME_WRAP, len(sequence))
            segment = sequence[position:end]
            
            # Wrap (reverse alternating segments)
            if len(wrapped_segments) % 2 == 1:
                segment = segment[::-1]
            
            wrapped_segments.append((segment, position))
            position = end + self.LINKER_LENGTH
        
        return wrapped_segments
    
    def apply_solenoid_folding(self, nucleosomes: List[Tuple[str, int]]) -> List[List[Tuple[str, int]]]:
        """
        Apply solenoid-like folding (groups of nucleosomes)
        
        Args:
            nucleosomes: List of nucleosome segments
            
        Returns:
            List of solenoid turns, each containing nucleosomes
        """
        solenoids = []
        
        for i in range(0, len(nucleosomes), self.SOLENOID_TURNS):
            turn = nucleosomes[i:i + self.SOLENOID_TURNS]
            solenoids.append(turn)
        
        return solenoids
    
    def create_hierarchical_audio_stream(self, sequence: str, frequency_mapper) -> Generator[np.ndarray, None, None]:
        """
        Create audio stream using hierarchical chromatin-like folding
        
        This creates the most biologically accurate compression:
        1. DNA wraps around nucleosomes (147bp segments)
        2. Nucleosomes form solenoid structures
        3. Solenoids form chromatin loops
        4. Multiple levels play simultaneously
        
        Args:
            sequence: DNA sequence
            frequency_mapper: Frequency mapper instance
            
        Yields:
            Audio sample arrays
        """
        # Apply nucleosome folding
        nucleosomes = self.apply_nucleosome_folding(sequence)
        
        # Apply solenoid folding
        solenoids = self.apply_solenoid_folding(nucleosomes)
        
        # Process each solenoid turn
        for turn in solenoids:
            # Mix all nucleosomes in this turn
            turn_samples = []
            
            for segment, position in turn:
                for base in segment:
                    if base in 'ATCGU':
                        freq = frequency_mapper.get_base_frequency(base)
                        samples = self._generate_base_samples(freq, 2)
                        turn_samples.append(samples)
            
            if turn_samples:
                # Stack and average for compression
                max_len = max(len(s) for s in turn_samples)
                padded = [np.pad(s, (0, max_len - len(s))) for s in turn_samples]
                combined = np.mean(padded, axis=0)
                yield combined
    
    def _generate_base_samples(self, frequency: float, cycles: int) -> np.ndarray:
        """Generate sine wave samples"""
        duration = cycles / frequency
        num_samples = int(self.sample_rate * duration)
        t = np.linspace(0, duration, num_samples, endpoint=False)
        return np.sin(2 * np.pi * frequency * t)

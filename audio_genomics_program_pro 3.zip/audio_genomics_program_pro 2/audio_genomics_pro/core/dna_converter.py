"""
DNA/RNA Conversion Module
Handles binary-to-DNA, text-to-DNA (via Hebrew), and protein-to-DNA conversions
"""

import hashlib
from typing import List, Optional, Dict, Tuple
import unicodedata

class DNAConverter:
    """Converts various data formats to DNA/RNA sequences"""
    
    def __init__(self, use_rna: bool = False):
        """
        Initialize converter
        
        Args:
            use_rna: If True, use U instead of T
        """
        self.use_rna = use_rna
        self.thymine = 'U' if use_rna else 'T'
        
        # Binary to base mapping (2 bits per base)
        self.binary_map = {
            '00': 'A',
            '01': 'C', 
            '10': 'G',
            '11': self.thymine
        }
        
        # Standard genetic code (codon to amino acid)
        self.genetic_code = {
            'UUU': 'F', 'UUC': 'F', 'UUA': 'L', 'UUG': 'L',
            'UCU': 'S', 'UCC': 'S', 'UCA': 'S', 'UCG': 'S',
            'UAU': 'Y', 'UAC': 'Y', 'UAA': '*', 'UAG': '*',
            'UGU': 'C', 'UGC': 'C', 'UGA': '*', 'UGG': 'W',
            'CUU': 'L', 'CUC': 'L', 'CUA': 'L', 'CUG': 'L',
            'CCU': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
            'CAU': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
            'CGU': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
            'AUU': 'I', 'AUC': 'I', 'AUA': 'I', 'AUG': 'M',
            'ACU': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
            'AAU': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
            'AGU': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
            'GUU': 'V', 'GUC': 'V', 'GUA': 'V', 'GUG': 'V',
            'GCU': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
            'GAU': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
            'GGU': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'
        }
        
        # Reverse genetic code (amino acid to preferred codon)
        self.reverse_genetic_code = {
            'F': 'UUU', 'L': 'CUG', 'S': 'UCU', 'Y': 'UAU',
            'C': 'UGU', 'W': 'UGG', 'P': 'CCU', 'H': 'CAU',
            'Q': 'CAA', 'R': 'CGU', 'I': 'AUU', 'M': 'AUG',
            'T': 'ACU', 'N': 'AAU', 'K': 'AAA', 'V': 'GUU',
            'A': 'GCU', 'D': 'GAU', 'E': 'GAA', 'G': 'GGU',
            '*': 'UAA'  # Stop codon
        }
        
        # Initialize Hebrew mappings
        self._init_hebrew_mappings()
        
    def _init_hebrew_mappings(self):
        """Initialize Hebrew letter to codon mappings"""
        # Hebrew alphabet (22 letters + 5 final forms)
        self.hebrew_letters = [
            'א', 'ב', 'ג', 'ד', 'ה', 'ו', 'ז', 'ח', 'ט', 'י',
            'כ', 'ל', 'מ', 'נ', 'ס', 'ע', 'פ', 'צ', 'ק', 'ר',
            'ש', 'ת', 'ך', 'ם', 'ן', 'ף', 'ץ'
        ]
        
        # Gematria values for Hebrew letters
        self.gematria_values = {
            'א': 1, 'ב': 2, 'ג': 3, 'ד': 4, 'ה': 5, 'ו': 6, 'ז': 7, 'ח': 8, 'ט': 9,
            'י': 10, 'כ': 20, 'ל': 30, 'מ': 40, 'נ': 50, 'ס': 60, 'ע': 70, 'פ': 80,
            'צ': 90, 'ק': 100, 'ר': 200, 'ש': 300, 'ת': 400,
            'ך': 500, 'ם': 600, 'ן': 700, 'ף': 800, 'ץ': 900
        }
        
        # Generate all possible codons
        bases = ['A', 'C', 'G', self.thymine]
        all_codons = []
        for b1 in bases:
            for b2 in bases:
                for b3 in bases:
                    all_codons.append(b1 + b2 + b3)
        
        # Map Hebrew letters to codons (DNA mode)
        self.hebrew_to_codon_dna = {}
        for i, letter in enumerate(self.hebrew_letters[:len(all_codons)]):
            self.hebrew_to_codon_dna[letter] = all_codons[i]
        
        # Create inverted mapping for RNA mode (Atbash-like cipher)
        self.hebrew_to_codon_rna = {}
        reversed_letters = list(reversed(self.hebrew_letters))
        for i, letter in enumerate(self.hebrew_letters[:len(all_codons)]):
            # Map each letter to the codon of its opposite in the alphabet
            opposite_idx = min(i, len(all_codons) - 1)
            self.hebrew_to_codon_rna[letter] = all_codons[-(opposite_idx + 1)]
        
        # Reverse mappings (codon to Hebrew)
        self.codon_to_hebrew_dna = {v: k for k, v in self.hebrew_to_codon_dna.items()}
        self.codon_to_hebrew_rna = {v: k for k, v in self.hebrew_to_codon_rna.items()}
    
    def binary_to_dna(self, data: bytes) -> str:
        """
        Convert binary data to DNA sequence
        
        Args:
            data: Binary data (bytes)
            
        Returns:
            DNA sequence string
        """
        # Convert bytes to bit string
        bit_string = ''.join(format(byte, '08b') for byte in data)
        
        # Pad if necessary to make even number of bits
        if len(bit_string) % 2 != 0:
            bit_string += '0'
        
        # Convert bit pairs to bases
        dna_sequence = []
        for i in range(0, len(bit_string), 2):
            bit_pair = bit_string[i:i+2]
            dna_sequence.append(self.binary_map[bit_pair])
        
        return ''.join(dna_sequence)
    
    def file_to_dna(self, file_path: str, use_hebrew: bool = False, rna_mode: bool = False) -> str:
        """
        Convert a file to DNA sequence
        
        Args:
            file_path: Path to the file to convert
            use_hebrew: If True, use Hebrew encoding
            rna_mode: If True, use RNA mode (U instead of T)
            
        Returns:
            DNA sequence string
        """
        # Read file as binary
        with open(file_path, 'rb') as f:
            binary_data = f.read()
        
        # Convert binary to DNA
        dna_sequence = self.binary_to_dna(binary_data)
        
        # Convert to RNA if needed
        if rna_mode:
            dna_sequence = dna_sequence.replace('T', 'U')
        
        return dna_sequence
    
    def text_to_dna(self, text: str, encoding: str = 'ascii') -> str:
        """
        Convert text to DNA sequence
        
        Args:
            text: Input text
            encoding: Encoding method ('ascii', 'hebrew', 'binary')
            
        Returns:
            DNA sequence string
        """
        if encoding == 'hebrew':
            dna_seq, _ = self.text_to_dna_hebrew(text)
            return dna_seq
        elif encoding == 'binary':
            return self.binary_to_dna(text.encode('utf-8'))
        else:  # ascii
            return self.text_to_dna_ascii(text)
    
    def text_to_dna_ascii(self, text: str) -> str:
        """
        Convert ASCII text to DNA sequence
        
        Args:
            text: ASCII text
            
        Returns:
            DNA sequence
        """
        dna_sequence = []
        
        for char in text:
            # Get ASCII value
            ascii_val = ord(char)
            
            # Convert to binary (8 bits)
            binary = format(ascii_val, '08b')
            
            # Convert binary to DNA (4 bases per character)
            for i in range(0, 8, 2):
                bit_pair = binary[i:i+2]
                dna_sequence.append(self.binary_map[bit_pair])
        
        return ''.join(dna_sequence)
    
    def text_to_dna_hebrew(self, text: str, translate: bool = True) -> Tuple[str, List[str]]:
        """
        Convert text to DNA via Hebrew encoding
        
        Args:
            text: Input text
            translate: If True, translate to Hebrew first
            
        Returns:
            Tuple of (DNA sequence, list of Hebrew letters used)
        """
        hebrew_text = text
        
        if translate and not self._is_hebrew(text):
            # For now, use a simple transliteration approach
            # In production, would integrate with offline translation library
            hebrew_text = self._transliterate_to_hebrew(text)
        
        # Select mapping based on RNA/DNA mode
        mapping = self.hebrew_to_codon_rna if self.use_rna else self.hebrew_to_codon_dna
        
        dna_sequence = []
        hebrew_used = []
        
        for char in hebrew_text:
            if char in mapping:
                dna_sequence.append(mapping[char])
                hebrew_used.append(char)
            elif char.isspace():
                # Use a special codon for spaces
                dna_sequence.append('AAA')
                hebrew_used.append(' ')
            # Skip unsupported characters
        
        return ''.join(dna_sequence), hebrew_used
    
    def _is_hebrew(self, text: str) -> bool:
        """Check if text contains Hebrew characters"""
        for char in text:
            if '\u0590' <= char <= '\u05FF':
                return True
        return False
    
    def _transliterate_to_hebrew(self, text: str) -> str:
        """
        Simple transliteration to Hebrew letters
        This is a placeholder - in production would use proper translation
        """
        # Basic phonetic mapping for demonstration
        transliteration_map = {
            'a': 'א', 'b': 'ב', 'g': 'ג', 'd': 'ד', 'h': 'ה',
            'v': 'ו', 'z': 'ז', 'ch': 'ח', 't': 'ט', 'y': 'י',
            'k': 'כ', 'l': 'ל', 'm': 'מ', 'n': 'נ', 's': 'ס',
            'p': 'פ', 'q': 'ק', 'r': 'ר', 'sh': 'ש', 'th': 'ת',
            'e': 'א', 'i': 'י', 'o': 'ו', 'u': 'ו', 'w': 'ו',
            'c': 'כ', 'f': 'פ', 'j': 'ג', 'x': 'כס'
        }
        
        result = []
        text = text.lower()
        i = 0
        
        while i < len(text):
            # Check for two-letter combinations first
            if i < len(text) - 1:
                two_char = text[i:i+2]
                if two_char in transliteration_map:
                    result.append(transliteration_map[two_char])
                    i += 2
                    continue
            
            # Single character
            char = text[i]
            if char in transliteration_map:
                result.append(transliteration_map[char])
            elif char.isspace():
                result.append(' ')
            
            i += 1
        
        return ''.join(result)
    
    def protein_to_dna(self, protein_sequence: str) -> str:
        """
        Convert protein sequence to DNA sequence
        
        Args:
            protein_sequence: Amino acid sequence (single letter codes)
            
        Returns:
            DNA sequence
        """
        dna_sequence = []
        
        for amino_acid in protein_sequence.upper():
            if amino_acid in self.reverse_genetic_code:
                codon = self.reverse_genetic_code[amino_acid]
                # Convert from RNA codon to DNA if needed
                if not self.use_rna:
                    codon = codon.replace('U', 'T')
                else:
                    codon = codon.replace('T', 'U')
                dna_sequence.append(codon)
            elif amino_acid == 'X':
                # Unknown amino acid - use NNN
                dna_sequence.append('NNN')
        
        return ''.join(dna_sequence)
    
    def dna_to_protein(self, dna_sequence: str) -> str:
        """
        Translate DNA sequence to protein sequence
        
        Args:
            dna_sequence: DNA/RNA sequence
            
        Returns:
            Protein sequence
        """
        # Ensure we're working with RNA codons for translation
        rna_sequence = dna_sequence.replace('T', 'U')
        
        protein = []
        for i in range(0, len(rna_sequence) - 2, 3):
            codon = rna_sequence[i:i+3]
            if codon in self.genetic_code:
                amino_acid = self.genetic_code[codon]
                if amino_acid == '*':  # Stop codon
                    break
                protein.append(amino_acid)
            else:
                protein.append('X')  # Unknown
        
        return ''.join(protein)
    
    def validate_sequence(self, sequence: str) -> Tuple[bool, str]:
        """
        Validate a DNA/RNA sequence
        
        Args:
            sequence: DNA/RNA sequence to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        valid_bases = {'A', 'C', 'G', 'T', 'U', 'N'}
        
        for i, base in enumerate(sequence.upper()):
            if base not in valid_bases:
                return False, f"Invalid base '{base}' at position {i}"
        
        # Check for mixed T and U
        if 'T' in sequence.upper() and 'U' in sequence.upper():
            return False, "Sequence contains both T and U - must be either DNA or RNA"
        
        return True, "Valid sequence"
    
    def validate_dna_sequence(self, sequence: str) -> str:
        """
        Validate and return a clean DNA sequence
        
        Args:
            sequence: DNA sequence to validate
            
        Returns:
            Validated DNA sequence (uppercase)
        """
        is_valid, error = self.validate_sequence(sequence)
        
        if not is_valid:
            raise ValueError(f"Invalid DNA sequence: {error}")
        
        # Ensure it's DNA (not RNA)
        sequence_upper = sequence.upper()
        if 'U' in sequence_upper:
            # Convert RNA to DNA
            sequence_upper = sequence_upper.replace('U', 'T')
        
        return sequence_upper
    
    def validate_rna_sequence(self, sequence: str) -> str:
        """
        Validate and return a clean RNA sequence
        
        Args:
            sequence: RNA sequence to validate
            
        Returns:
            Validated RNA sequence (uppercase)
        """
        is_valid, error = self.validate_sequence(sequence)
        
        if not is_valid:
            raise ValueError(f"Invalid RNA sequence: {error}")
        
        # Ensure it's RNA (not DNA)
        sequence_upper = sequence.upper()
        if 'T' in sequence_upper:
            # Convert DNA to RNA
            sequence_upper = sequence_upper.replace('T', 'U')
        
        return sequence_upper
    
    def get_sequence_stats(self, sequence: str) -> Dict:
        """
        Get statistics about a DNA/RNA sequence
        
        Args:
            sequence: DNA/RNA sequence
            
        Returns:
            Dictionary with sequence statistics
        """
        sequence = sequence.upper()
        
        stats = {
            'length': len(sequence),
            'gc_content': 0,
            'base_counts': {'A': 0, 'C': 0, 'G': 0, 'T': 0, 'U': 0, 'N': 0},
            'codon_count': len(sequence) // 3,
            'type': 'RNA' if 'U' in sequence else 'DNA'
        }
        
        for base in sequence:
            if base in stats['base_counts']:
                stats['base_counts'][base] += 1
        
        # Calculate GC content
        gc_count = stats['base_counts']['G'] + stats['base_counts']['C']
        total_count = sum(v for k, v in stats['base_counts'].items() if k != 'N')
        
        if total_count > 0:
            stats['gc_content'] = (gc_count / total_count) * 100
        
        return stats

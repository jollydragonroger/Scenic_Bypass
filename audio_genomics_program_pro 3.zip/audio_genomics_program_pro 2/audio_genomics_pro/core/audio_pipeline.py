"""
Audio Generation Pipeline
Combines DNA sequences into audio with precise timing and separators
"""

import numpy as np
from typing import List, Tuple, Optional
from decimal import Decimal
import io
import wave
import struct

from .tone_synthesis import ToneSynthesizer

# Import from data module with fallback
try:
    from ..data.dna_frequencies import (
        get_base_frequency, 
        get_waveform_type,
        SEPARATOR_FREQUENCY
    )
except ImportError:
    # Fallback definitions if data module not available
    from decimal import Decimal
    
    SEPARATOR_FREQUENCY = Decimal('528.0')
    
    _BASE_FREQS = {
        'A': Decimal('545.6'),
        'T': Decimal('543.4'),
        'C': Decimal('537.8'),
        'G': Decimal('550.3'),
        'U': Decimal('542.1'),
        'N': Decimal('555.0'),
    }
    
    _WAVEFORMS = {
        'A': 'sine', 'T': 'square', 'C': 'sawtooth', 
        'G': 'triangle', 'U': 'impulse', 'N': 'impulse'
    }
    
    def get_base_frequency(base, mode='primary'):
        return _BASE_FREQS.get(base.upper(), _BASE_FREQS['N'])
    
    def get_waveform_type(base):
        return _WAVEFORMS.get(base.upper(), 'impulse')

class AudioPipeline:
    """Generates audio from DNA/RNA sequences with precise timing"""
    
    def __init__(self, sample_rate: int = 192000, bit_depth: int = 32):
        """
        Initialize audio pipeline
        
        Args:
            sample_rate: Sample rate in Hz
            bit_depth: Bit depth for audio
        """
        self.sample_rate = sample_rate
        self.bit_depth = bit_depth
        self.synthesizer = ToneSynthesizer(sample_rate, bit_depth)
        
    def generate_base_audio(self, 
                           dna_sequence: str,
                           base_cycles: int = 3,
                           separator_cycles: int = 1,
                           codon_separator_cycles: int = 3,
                           use_secondary_frequencies: bool = False) -> np.ndarray:
        """
        Generate audio from DNA sequence with separators
        
        Args:
            dna_sequence: DNA/RNA sequence string
            base_cycles: Number of cycles per base tone
            separator_cycles: Cycles for inter-base separator
            codon_separator_cycles: Cycles for codon (triplet) separator
            use_secondary_frequencies: If True, use secondary frequency set
            
        Returns:
            NumPy array of audio samples
        """
        audio_segments = []
        
        for i, base in enumerate(dna_sequence.upper()):
            # Generate tone for base
            frequency = get_base_frequency(base, 'primary')
            waveform = get_waveform_type(base)
            
            # Use secondary frequencies if requested (cycle through them)
            if use_secondary_frequencies and i % 4 != 0:
                frequency = get_base_frequency(base, (i % 4) - 1)
            
            # Generate base tone for exact cycles
            base_audio = self.synthesizer.generate_tone(frequency, waveform, base_cycles)
            audio_segments.append(base_audio)
            
            # Add separator after base (except for last base)
            if i < len(dna_sequence) - 1:
                # Check if we're at a codon boundary
                if (i + 1) % 3 == 0:
                    # Codon separator (longer)
                    separator = self.synthesizer.generate_separator(
                        SEPARATOR_FREQUENCY, 
                        codon_separator_cycles
                    )
                else:
                    # Regular base separator
                    separator = self.synthesizer.generate_separator(
                        SEPARATOR_FREQUENCY,
                        separator_cycles
                    )
                audio_segments.append(separator)
        
        # Concatenate all segments
        return np.concatenate(audio_segments)
    
    def generate_multilayer_audio(self,
                                 dna_sequences: List[str],
                                 layer_offsets: Optional[List[float]] = None,
                                 layer_volumes: Optional[List[float]] = None) -> np.ndarray:
        """
        Generate multi-layered audio from multiple DNA sequences
        
        Args:
            dna_sequences: List of DNA sequences for different layers
            layer_offsets: Time offsets for each layer (seconds)
            layer_volumes: Volume levels for each layer (0-1)
            
        Returns:
            Combined multi-layer audio
        """
        if layer_offsets is None:
            layer_offsets = [0.0] * len(dna_sequences)
        
        if layer_volumes is None:
            # Distribute volumes evenly
            layer_volumes = [0.8 / len(dna_sequences)] * len(dna_sequences)
        
        # Generate audio for each layer
        layer_audios = []
        max_length = 0
        
        for i, sequence in enumerate(dna_sequences):
            # Generate base audio for this layer
            audio = self.generate_base_audio(sequence)
            
            # Apply volume
            audio = audio * layer_volumes[i]
            
            # Apply offset
            if layer_offsets[i] > 0:
                offset_samples = int(self.sample_rate * layer_offsets[i])
                silence = np.zeros(offset_samples)
                audio = np.concatenate([silence, audio])
            
            layer_audios.append(audio)
            max_length = max(max_length, len(audio))
        
        # Pad all layers to same length
        for i in range(len(layer_audios)):
            if len(layer_audios[i]) < max_length:
                padding = np.zeros(max_length - len(layer_audios[i]))
                layer_audios[i] = np.concatenate([layer_audios[i], padding])
        
        # Mix layers
        mixed = np.sum(layer_audios, axis=0)
        
        # Normalize to prevent clipping
        max_val = np.max(np.abs(mixed))
        if max_val > 0.95:
            mixed = mixed * (0.95 / max_val)
        
        return mixed
    
    def apply_time_scaling(self, 
                          audio: np.ndarray,
                          target_duration: float,
                          use_exponential_scaling: bool = True) -> np.ndarray:
        """
        Scale audio duration to match target
        
        Args:
            audio: Input audio samples
            target_duration: Target duration in seconds
            use_exponential_scaling: If True, use base-8 scaling factors
            
        Returns:
            Time-scaled audio
        """
        current_duration = len(audio) / self.sample_rate
        
        if current_duration == target_duration:
            return audio
        
        # Calculate scaling factor
        scale_factor = current_duration / target_duration
        
        if use_exponential_scaling and scale_factor > 1:
            # Round to nearest power of 8
            import math
            power = math.log(scale_factor) / math.log(8)
            rounded_power = round(power)
            scale_factor = 8 ** rounded_power
        
        # Apply scaling via resampling
        if scale_factor != 1:
            # Use linear interpolation for time scaling
            old_indices = np.arange(len(audio))
            new_length = int(len(audio) / scale_factor)
            new_indices = np.linspace(0, len(audio) - 1, new_length)
            
            scaled_audio = np.interp(new_indices, old_indices, audio)
            return scaled_audio
        
        return audio
    
    def loop_audio(self, audio: np.ndarray, target_duration: float) -> np.ndarray:
        """
        Loop audio to reach target duration
        
        Args:
            audio: Input audio samples
            target_duration: Target duration in seconds
            
        Returns:
            Looped audio
        """
        current_duration = len(audio) / self.sample_rate
        
        if current_duration >= target_duration:
            # Truncate if longer
            target_samples = int(target_duration * self.sample_rate)
            return audio[:target_samples]
        
        # Calculate how many loops needed
        num_loops = int(np.ceil(target_duration / current_duration))
        
        # Create looped audio
        looped = np.tile(audio, num_loops)
        
        # Truncate to exact duration
        target_samples = int(target_duration * self.sample_rate)
        looped = looped[:target_samples]
        
        # Apply crossfade at loop points to prevent clicks
        fade_duration = 0.01  # 10ms crossfade
        fade_samples = int(fade_duration * self.sample_rate)
        
        for i in range(1, num_loops):
            loop_point = i * len(audio)
            if loop_point < len(looped) - fade_samples:
                # Create fade out/in
                fade_out = np.linspace(1, 0, fade_samples)
                fade_in = np.linspace(0, 1, fade_samples)
                
                # Apply crossfade
                start_idx = loop_point - fade_samples
                end_idx = loop_point + fade_samples
                
                if start_idx >= 0 and end_idx <= len(looped):
                    looped[start_idx:loop_point] *= fade_out
                    looped[loop_point:end_idx] *= fade_in
        
        return looped
    
    def save_audio(self, audio: np.ndarray, filepath: str) -> float:
        """
        Save audio to WAV file
        
        Args:
            audio: Audio samples
            filepath: Output file path
            
        Returns:
            Duration of the audio in seconds
        """
        # Convert to appropriate integer format
        int_samples = self.synthesizer.to_int_samples(audio)
        
        # Write WAV file
        with wave.open(filepath, 'wb') as wav_file:
            wav_file.setnchannels(1)  # Mono
            wav_file.setsampwidth(self.bit_depth // 8)
            wav_file.setframerate(self.sample_rate)
            
            # Convert to bytes based on bit depth
            if self.bit_depth == 16:
                data = struct.pack('<%dh' % len(int_samples), *int_samples)
            elif self.bit_depth == 32:
                if isinstance(int_samples[0], np.float32):
                    data = struct.pack('<%df' % len(int_samples), *int_samples)
                else:
                    data = struct.pack('<%di' % len(int_samples), *int_samples)
            else:
                # 24-bit requires special handling
                data = b''.join(
                    struct.pack('<i', sample)[:-1] 
                    for sample in int_samples
                )
            
            wav_file.writeframes(data)
        
        # Return duration
        return len(audio) / self.sample_rate
    
    def get_audio_info(self, audio: np.ndarray) -> dict:
        """
        Get information about audio
        
        Args:
            audio: Audio samples
            
        Returns:
            Dictionary with audio information
        """
        duration = len(audio) / self.sample_rate
        
        return {
            'duration_seconds': duration,
            'duration_formatted': f"{int(duration // 60):02d}:{duration % 60:06.3f}",
            'sample_count': len(audio),
            'sample_rate': self.sample_rate,
            'bit_depth': self.bit_depth,
            'peak_amplitude': float(np.max(np.abs(audio))),
            'rms_amplitude': float(np.sqrt(np.mean(audio ** 2)))
        }

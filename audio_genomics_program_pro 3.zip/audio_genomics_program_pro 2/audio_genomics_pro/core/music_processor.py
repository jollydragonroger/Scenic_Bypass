"""
Music Processing Module
Handles music file loading, pitch analysis, and retuning to 432 Hz
"""

import numpy as np
import scipy.io.wavfile as wavfile
import scipy.signal as signal
from typing import Tuple, Optional, Dict
import struct
import wave
import os

class MusicProcessor:
    """Process and analyze music carrier files"""
    
    def __init__(self, sample_rate: int = 192000):
        """
        Initialize music processor
        
        Args:
            sample_rate: Target sample rate for processing
        """
        self.sample_rate = sample_rate
        
    def load_audio_file(self, filepath: str) -> Tuple[np.ndarray, int]:
        """
        Load audio file (WAV, etc.)
        
        Args:
            filepath: Path to audio file
            
        Returns:
            Tuple of (audio_data, sample_rate)
        """
        # Get file extension
        ext = os.path.splitext(filepath)[1].lower()
        
        if ext == '.wav':
            rate, data = wavfile.read(filepath)
            
            # Convert to float32 normalized to [-1, 1]
            if data.dtype == np.int16:
                data = data.astype(np.float32) / 32768.0
            elif data.dtype == np.int32:
                data = data.astype(np.float32) / 2147483648.0
            elif data.dtype == np.uint8:
                data = (data.astype(np.float32) - 128) / 128.0
            
            # Handle stereo/mono
            if len(data.shape) > 1:
                # Convert stereo to mono for processing
                data = np.mean(data, axis=1)
            
            return data, rate
        else:
            raise ValueError(f"Unsupported file format: {ext}")
    
    def resample_audio(self, 
                      audio: np.ndarray, 
                      orig_rate: int, 
                      target_rate: int) -> np.ndarray:
        """
        Resample audio to target sample rate
        
        Args:
            audio: Input audio samples
            orig_rate: Original sample rate
            target_rate: Target sample rate
            
        Returns:
            Resampled audio
        """
        if orig_rate == target_rate:
            return audio
        
        # Calculate resampling ratio
        ratio = target_rate / orig_rate
        
        # Resample using scipy
        new_length = int(len(audio) * ratio)
        resampled = signal.resample(audio, new_length)
        
        return resampled
    
    def detect_pitch_reference(self, audio: np.ndarray, sample_rate: int) -> Dict:
        """
        Detect the tuning reference of the music
        
        Args:
            audio: Audio samples
            sample_rate: Sample rate
            
        Returns:
            Dictionary with tuning information
        """
        # Use autocorrelation to find fundamental frequencies
        # This is a simplified pitch detection
        
        # Take a segment of audio for analysis
        segment_length = min(len(audio), sample_rate * 10)  # 10 seconds max
        segment = audio[:segment_length]
        
        # Apply window to reduce edge effects
        window = np.hanning(len(segment))
        segment = segment * window
        
        # FFT analysis
        fft = np.fft.rfft(segment)
        magnitude = np.abs(fft)
        frequencies = np.fft.rfftfreq(len(segment), 1/sample_rate)
        
        # Find peaks in spectrum
        peaks = []
        threshold = np.max(magnitude) * 0.1
        
        for i in range(1, len(magnitude) - 1):
            if magnitude[i] > threshold:
                if magnitude[i] > magnitude[i-1] and magnitude[i] > magnitude[i+1]:
                    peaks.append((frequencies[i], magnitude[i]))
        
        # Sort by magnitude
        peaks.sort(key=lambda x: x[1], reverse=True)
        
        # Estimate A4 reference
        # Look for frequencies near A notes (220, 440, 880 Hz)
        a_candidates = []
        for freq, mag in peaks[:50]:  # Check top 50 peaks
            # Check if frequency is near an A note
            for a_ref in [220, 440, 880]:
                ratio = freq / a_ref
                # Check if within 50 cents (about 3%)
                if 0.97 <= ratio <= 1.03:
                    # Estimate A4 from this frequency
                    if a_ref == 220:
                        estimated_a4 = freq * 2
                    elif a_ref == 440:
                        estimated_a4 = freq
                    else:  # 880
                        estimated_a4 = freq / 2
                    a_candidates.append(estimated_a4)
        
        # Average candidates or default to 440
        if a_candidates:
            detected_a4 = np.mean(a_candidates)
        else:
            detected_a4 = 440.0
        
        # Calculate cents difference from 440
        cents_from_440 = 1200 * np.log2(detected_a4 / 440)
        
        return {
            'detected_a4': detected_a4,
            'cents_from_440': cents_from_440,
            'is_432hz': abs(detected_a4 - 432) < 2,  # Within 2 Hz of 432
            'is_440hz': abs(detected_a4 - 440) < 2,  # Within 2 Hz of 440
            'top_frequencies': peaks[:10] if peaks else []
        }
    
    def retune_to_432hz(self, 
                       audio: np.ndarray, 
                       sample_rate: int,
                       current_tuning: Optional[float] = None) -> np.ndarray:
        """
        Retune audio to 432 Hz reference
        
        Args:
            audio: Input audio
            sample_rate: Sample rate
            current_tuning: Current A4 reference (auto-detect if None)
            
        Returns:
            Retuned audio
        """
        if current_tuning is None:
            # Auto-detect current tuning
            pitch_info = self.detect_pitch_reference(audio, sample_rate)
            current_tuning = pitch_info['detected_a4']
        
        # Calculate pitch shift ratio
        # 432/440 ≈ 0.9818
        shift_ratio = 432.0 / current_tuning
        
        if abs(shift_ratio - 1.0) < 0.001:
            # Already close to 432 Hz
            return audio
        
        # Resample to achieve pitch shift
        # Lower sample rate = lower pitch
        new_length = int(len(audio) * shift_ratio)
        retuned = signal.resample(audio, new_length)
        
        return retuned
    
    def analyze_key_and_scale(self, 
                             audio: np.ndarray, 
                             sample_rate: int) -> Dict:
        """
        Analyze the key and scale of the music
        
        Args:
            audio: Audio samples
            sample_rate: Sample rate
            
        Returns:
            Dictionary with key and scale information
        """
        # Chroma feature extraction (12 pitch classes)
        # Simplified version - in production would use librosa
        
        # Take segments and analyze pitch content
        segment_size = sample_rate * 2  # 2-second segments
        hop_size = sample_rate // 2  # 0.5-second hop
        
        chroma_vectors = []
        
        for start in range(0, len(audio) - segment_size, hop_size):
            segment = audio[start:start + segment_size]
            
            # Apply window
            window = np.hanning(len(segment))
            segment = segment * window
            
            # FFT
            fft = np.fft.rfft(segment)
            magnitude = np.abs(fft)
            frequencies = np.fft.rfftfreq(len(segment), 1/sample_rate)
            
            # Map to pitch classes (C, C#, D, D#, E, F, F#, G, G#, A, A#, B)
            chroma = np.zeros(12)
            
            for i, freq in enumerate(frequencies):
                if freq > 80 and freq < 2000:  # Focus on musical range
                    # Convert frequency to pitch class
                    # A4 = 440 Hz, A = pitch class 9
                    midi_note = 69 + 12 * np.log2(freq / 440)
                    pitch_class = int(round(midi_note)) % 12
                    chroma[pitch_class] += magnitude[i]
            
            chroma_vectors.append(chroma)
        
        # Average chroma vector
        if chroma_vectors:
            avg_chroma = np.mean(chroma_vectors, axis=0)
            
            # Normalize
            if np.sum(avg_chroma) > 0:
                avg_chroma = avg_chroma / np.sum(avg_chroma)
            
            # Find dominant pitch class
            pitch_classes = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
            dominant_idx = np.argmax(avg_chroma)
            
            # Estimate if major or minor based on thirds
            # Major: has major third (4 semitones up)
            # Minor: has minor third (3 semitones up)
            major_third_idx = (dominant_idx + 4) % 12
            minor_third_idx = (dominant_idx + 3) % 12
            
            is_major = avg_chroma[major_third_idx] > avg_chroma[minor_third_idx]
            
            return {
                'root_note': pitch_classes[dominant_idx],
                'scale': 'major' if is_major else 'minor',
                'chroma_profile': avg_chroma.tolist(),
                'confidence': float(np.max(avg_chroma))
            }
        else:
            return {
                'root_note': 'C',
                'scale': 'major',
                'chroma_profile': [0] * 12,
                'confidence': 0.0
            }
    
    def get_harmonic_frequencies(self, 
                                root_frequency: float, 
                                num_harmonics: int = 8) -> list:
        """
        Get harmonic series from root frequency
        
        Args:
            root_frequency: Fundamental frequency
            num_harmonics: Number of harmonics to generate
            
        Returns:
            List of harmonic frequencies
        """
        return [root_frequency * (i + 1) for i in range(num_harmonics)]
    
    def apply_eq(self, 
                audio: np.ndarray, 
                sample_rate: int,
                band_gains: Dict[float, float]) -> np.ndarray:
        """
        Apply EQ to audio
        
        Args:
            audio: Input audio
            sample_rate: Sample rate
            band_gains: Dictionary of {frequency: gain_db}
            
        Returns:
            EQ'd audio
        """
        output = audio.copy()
        
        for freq, gain_db in band_gains.items():
            # Convert dB to linear gain
            gain = 10 ** (gain_db / 20)
            
            # Design bandpass filter around frequency
            bandwidth = freq * 0.1  # 10% bandwidth
            low_freq = freq - bandwidth / 2
            high_freq = freq + bandwidth / 2
            
            nyquist = sample_rate / 2
            if high_freq < nyquist:
                # Design filter
                sos = signal.butter(4, [low_freq, high_freq], 
                                  btype='band', fs=sample_rate, output='sos')
                
                # Apply filter and gain
                filtered = signal.sosfilt(sos, audio)
                output += filtered * (gain - 1)
        
        return output
    
    def normalize_loudness(self, 
                         audio: np.ndarray, 
                         target_lufs: float = -14.0) -> np.ndarray:
        """
        Normalize audio loudness to target LUFS
        
        Args:
            audio: Input audio
            target_lufs: Target loudness in LUFS
            
        Returns:
            Normalized audio
        """
        # Simplified LUFS calculation
        # In production would use proper ITU-R BS.1770 algorithm
        
        # Calculate RMS in dB
        rms = np.sqrt(np.mean(audio ** 2))
        if rms == 0:
            return audio
        
        current_db = 20 * np.log10(rms)
        
        # Estimate LUFS (simplified)
        current_lufs = current_db + 3  # Rough approximation
        
        # Calculate gain needed
        gain_db = target_lufs - current_lufs
        gain = 10 ** (gain_db / 20)
        
        # Apply gain
        normalized = audio * gain
        
        # Prevent clipping
        max_val = np.max(np.abs(normalized))
        if max_val > 0.95:
            normalized = normalized * (0.95 / max_val)
        
        return normalized

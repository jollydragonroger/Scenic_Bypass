"""
Nucleotide Frequency Mapper
Maps DNA/RNA bases to precise infrared-derived audio frequencies
Based on spectroscopic measurements of nucleotide molecular vibrations
with auto-scaling to musical keys
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from enum import Enum
from decimal import Decimal, getcontext

getcontext().prec = 50


class MusicalKey(Enum):
    """Musical keys for auto-scaling"""
    C = 0
    C_SHARP = 1
    D = 2
    D_SHARP = 3
    E = 4
    F = 5
    F_SHARP = 6
    G = 7
    G_SHARP = 8
    A = 9
    A_SHARP = 10
    B = 11


class NucleotideFrequencyMapper:
    """
    Maps nucleotides to frequencies based on infrared spectroscopy data
    
    Frequencies are derived from molecular vibration measurements and
    can be auto-scaled to fit within any musical key for harmonic coherence.
    
    Data source: Wave and Hertz numbers from infrared tuning measurements
    """
    
    # Adenine (A) frequencies - Hz and Note, Wave# (cm^-1)
    ADENINE_FREQUENCIES = [
        (315.6, 'D#', 723),
        (347.9, 'F', 797),
        (368.0, 'F#', 843),
        (378.8, 'F#/G', 870),
        (398.1, 'G', 912),
        (408.1, 'G#', 935),
        (447.4, 'A', 1025),
        (490.2, 'B', 1123),
        (504.2, 'B', 1155),
        (545.6, 'C#', 1250),
        (582.7, 'D', 1335),
        (598.0, 'D/D#', 1370),
        (619.8, 'D#', 1420),
        (632.9, 'D#/E', 1450),
        (654.8, 'E', 1500),
        (698.4, 'F', 1600),
        (726.7, 'F/F#', 1665),
        (1139.2, 'D', 2610),
        (1178.5, 'D', 2700),
        (1248.3, 'D#', 2860),
        (1278.9, 'D#/E', 2930),
        (1366.2, 'F', 3130),
        (1440.5, 'F/F#', 3300),
    ]
    
    # Thymine (T) frequencies - Hz and Note, Wave# (cm^-1)
    THYMINE_FREQUENCIES = [
        (322.1, 'D#/E', 738),
        (330.4, 'E', 757),
        (354.4, 'F', 812),
        (363.2, 'F#', 832),
        (406.4, 'G#', 931),
        (427.8, 'G#', 980),
        (447.4, 'A', 1025),
        (523.8, 'C', 1200),
        (543.4, 'C#', 1245),
        (600.2, 'D/D#', 1375),
        (733.3, 'F#', 1680),
        (768.2, 'G', 1760),
        (1248.3, 'D#', 2860),
        (1274.6, 'D#/F', 2920),
        (1385.8, 'F', 3175),
    ]
    
    # Guanine (G) frequencies - Hz and Note, Wave# (cm^-1)
    GUANINE_FREQUENCIES = [
        (300.3, 'D', 688),
        (305.6, 'D#', 700),
        (339.2, 'E/F', 777),
        (370.2, 'F#', 848),
        (383.2, 'F#/G', 878),
        (413.4, 'G#', 947),
        (487.6, 'B', 1117),
        (512.9, 'B/C', 1175),
        (529.5, 'C', 1213),
        (550.0, 'C#', 1260),
        (600.2, 'D/D#', 1375),
        (615.5, 'D#', 1410),
        (641.7, 'D#/E', 1470),
        (663.5, 'E', 1520),
        (728.9, 'F#/F#', 1670),
        (1169.8, 'D', 2680),
        (1278.9, 'D#/E', 2930),
        (1386.2, 'F', 3130),
        (1462.3, 'F#', 3350),
    ]
    
    # Cytosine (C) frequencies - Hz and Note, Wave# (cm^-1)
    CYTOSINE_FREQUENCIES = [
        (305.6, 'D#', 700),
        (346.7, 'F', 792),
        (367.9, 'F/F#', 820),
        (420.3, 'G#', 963),
        (429.1, 'G#', 983),
        (440.9, 'A', 1010),
        (504.2, 'B', 1155),
        (537.8, 'C/C#', 1232),
        (558.7, 'C#', 1280),
        (594.9, 'D/D#', 1363),
        (639.5, 'D#/E', 1465),
        (654.8, 'E', 1500),
        (713.7, 'F/F#', 1635),
        (1276.8, 'D#/E', 2925),
        (1375.0, 'F', 3150),
        (1475.4, 'F#', 3380),
    ]
    
    # Standard musical note frequencies (A4 = 440 Hz tuning)
    STANDARD_NOTES = {
        'C': 261.63,
        'C#': 277.18,
        'D': 293.66,
        'D#': 311.13,
        'E': 329.63,
        'F': 349.23,
        'F#': 369.99,
        'G': 392.00,
        'G#': 415.30,
        'A': 440.00,
        'A#': 466.16,
        'B': 493.88,
    }
    
    # 432 Hz tuning notes
    TUNING_432_NOTES = {
        'C': 256.87,
        'C#': 272.14,
        'D': 288.33,
        'D#': 305.47,
        'E': 323.63,
        'F': 342.88,
        'F#': 363.27,
        'G': 384.87,
        'G#': 407.75,
        'A': 432.00,
        'A#': 457.69,
        'B': 484.90,
    }
    
    def __init__(self, tuning: float = 432.0, auto_key: bool = True):
        """
        Initialize nucleotide frequency mapper
        
        Args:
            tuning: A4 tuning reference (432 or 440 Hz)
            auto_key: Whether to auto-scale frequencies to fit a musical key
        """
        self.tuning = tuning
        self.auto_key = auto_key
        self.current_key = MusicalKey.C
        
        # Build frequency maps
        self._build_frequency_maps()
        
        # Tuning ratio for 432 Hz
        self.tuning_ratio = tuning / 440.0
    
    def _build_frequency_maps(self):
        """Build optimized frequency lookup maps"""
        self.base_primary_freq = {
            'A': self.ADENINE_FREQUENCIES[0][0],   # Primary Adenine freq
            'T': self.THYMINE_FREQUENCIES[0][0],   # Primary Thymine freq
            'G': self.GUANINE_FREQUENCIES[0][0],   # Primary Guanine freq
            'C': self.CYTOSINE_FREQUENCIES[0][0],  # Primary Cytosine freq
            'U': self.THYMINE_FREQUENCIES[0][0],   # Uracil uses Thymine freq
        }
        
        self.base_all_freqs = {
            'A': self.ADENINE_FREQUENCIES,
            'T': self.THYMINE_FREQUENCIES,
            'G': self.GUANINE_FREQUENCIES,
            'C': self.CYTOSINE_FREQUENCIES,
            'U': self.THYMINE_FREQUENCIES,
        }
    
    def get_base_frequency(self, base: str, harmonic_index: int = 0) -> float:
        """
        Get frequency for a DNA/RNA base
        
        Args:
            base: Nucleotide base (A, T, C, G, U)
            harmonic_index: Index into the frequency harmonics (0 = primary)
            
        Returns:
            Frequency in Hz, adjusted for tuning
        """
        base = base.upper()
        
        if base not in self.base_all_freqs:
            raise ValueError(f"Invalid base: {base}")
        
        freqs = self.base_all_freqs[base]
        idx = min(harmonic_index, len(freqs) - 1)
        freq = freqs[idx][0]
        
        # Apply tuning adjustment
        freq *= self.tuning_ratio
        
        # Auto-scale to key if enabled
        if self.auto_key:
            freq = self._scale_to_key(freq, self.current_key)
        
        return freq
    
    def get_all_base_frequencies(self, base: str) -> List[Tuple[float, str, int]]:
        """
        Get all frequencies for a base (full harmonic series)
        
        Args:
            base: Nucleotide base
            
        Returns:
            List of (frequency, note, wave_number) tuples
        """
        base = base.upper()
        
        if base not in self.base_all_freqs:
            raise ValueError(f"Invalid base: {base}")
        
        result = []
        for freq, note, wave_num in self.base_all_freqs[base]:
            adjusted_freq = freq * self.tuning_ratio
            if self.auto_key:
                adjusted_freq = self._scale_to_key(adjusted_freq, self.current_key)
            result.append((adjusted_freq, note, wave_num))
        
        return result
    
    def _scale_to_key(self, frequency: float, key: MusicalKey) -> float:
        """
        Scale a frequency to fit within a musical key
        
        Args:
            frequency: Original frequency
            key: Target musical key
            
        Returns:
            Frequency adjusted to nearest note in key
        """
        notes = self.TUNING_432_NOTES if self.tuning < 436 else self.STANDARD_NOTES
        
        # Key scale degrees (major scale)
        major_scale = [0, 2, 4, 5, 7, 9, 11]  # Semitones from root
        
        # Find nearest note in key
        note_names = list(notes.keys())
        key_root_idx = key.value
        
        # Get notes in this key
        key_notes = []
        for degree in major_scale:
            note_idx = (key_root_idx + degree) % 12
            note_name = note_names[note_idx]
            key_notes.append(notes[note_name])
        
        # Find nearest frequency in key (any octave)
        best_freq = frequency
        min_ratio_diff = float('inf')
        
        for base_freq in key_notes:
            # Check multiple octaves
            for octave in range(-3, 5):
                test_freq = base_freq * (2 ** octave)
                ratio = frequency / test_freq
                ratio_diff = abs(np.log2(ratio))
                
                if ratio_diff < min_ratio_diff:
                    min_ratio_diff = ratio_diff
                    best_freq = test_freq
        
        return best_freq
    
    def set_key(self, key: MusicalKey):
        """Set the current musical key for auto-scaling"""
        self.current_key = key
    
    def detect_optimal_key(self, sequence: str) -> MusicalKey:
        """
        Detect optimal musical key based on sequence composition
        
        Args:
            sequence: DNA/RNA sequence
            
        Returns:
            Optimal musical key for the sequence
        """
        # Count base frequencies
        base_counts = {'A': 0, 'T': 0, 'G': 0, 'C': 0}
        for base in sequence.upper():
            if base in base_counts:
                base_counts[base] += 1
        
        # Calculate weighted frequency center
        total_freq = 0
        total_count = 0
        
        for base, count in base_counts.items():
            if count > 0:
                freq = self.base_primary_freq[base]
                total_freq += freq * count
                total_count += count
        
        if total_count == 0:
            return MusicalKey.C
        
        avg_freq = total_freq / total_count
        
        # Find nearest key root
        notes = self.TUNING_432_NOTES if self.tuning < 436 else self.STANDARD_NOTES
        min_diff = float('inf')
        best_key = MusicalKey.C
        
        for key in MusicalKey:
            note_name = list(notes.keys())[key.value]
            key_freq = notes[note_name]
            
            # Check multiple octaves
            for octave in range(-2, 4):
                test_freq = key_freq * (2 ** octave)
                diff = abs(avg_freq - test_freq)
                if diff < min_diff:
                    min_diff = diff
                    best_key = key
        
        return best_key
    
    def get_codon_chord(self, codon: str) -> List[float]:
        """
        Get chord frequencies for a codon (3 bases played together)
        
        Args:
            codon: 3-base codon string
            
        Returns:
            List of frequencies forming a chord
        """
        if len(codon) != 3:
            raise ValueError("Codon must be exactly 3 bases")
        
        chord = []
        for base in codon.upper():
            if base in self.base_primary_freq:
                freq = self.get_base_frequency(base)
                chord.append(freq)
        
        return chord
    
    def get_sequence_melody(self, sequence: str, 
                           use_harmonics: bool = False) -> List[float]:
        """
        Convert sequence to melody (list of frequencies)
        
        Args:
            sequence: DNA/RNA sequence
            use_harmonics: Whether to include harmonic frequencies
            
        Returns:
            List of frequencies
        """
        melody = []
        
        for base in sequence.upper():
            if base in self.base_all_freqs:
                if use_harmonics:
                    # Add primary + first harmonic
                    melody.append(self.get_base_frequency(base, 0))
                    melody.append(self.get_base_frequency(base, 1))
                else:
                    melody.append(self.get_base_frequency(base, 0))
        
        return melody
    
    def get_base_pair_interval(self, base1: str, base2: str) -> float:
        """
        Calculate musical interval ratio between two bases
        
        Args:
            base1: First base
            base2: Second base
            
        Returns:
            Frequency ratio (interval)
        """
        freq1 = self.get_base_frequency(base1)
        freq2 = self.get_base_frequency(base2)
        
        return freq2 / freq1
    
    def calculate_sequence_tempo(self, sequence: str, 
                                 target_duration: float) -> float:
        """
        Calculate optimal tempo (BPM) for a sequence
        
        Args:
            sequence: DNA/RNA sequence
            target_duration: Target duration in seconds
            
        Returns:
            Tempo in BPM
        """
        num_bases = len([b for b in sequence.upper() if b in 'ATCGU'])
        
        if num_bases == 0 or target_duration <= 0:
            return 120.0  # Default tempo
        
        # Calculate notes per second
        notes_per_second = num_bases / target_duration
        
        # Convert to BPM (assuming quarter note = 1 base)
        bpm = notes_per_second * 60
        
        # Clamp to reasonable range
        return max(40, min(300, bpm))


class OptimalSpeedCalculator:
    """
    Calculates optimal playback speed based on sequence characteristics
    Uses golden ratio and harmonic principles for natural timing
    """
    
    PHI = 1.618033988749895  # Golden ratio
    
    def __init__(self, sample_rate: int = 192000):
        self.sample_rate = sample_rate
    
    def calculate_optimal_cycles_per_base(self, frequency: float) -> int:
        """
        Calculate optimal number of cycles per base for a given frequency
        
        Uses harmonic principles to ensure complete waveforms
        
        Args:
            frequency: Base frequency in Hz
            
        Returns:
            Optimal number of cycles
        """
        # Aim for duration that's a multiple of golden ratio
        target_duration = 1.0 / (frequency / 100)  # ~10ms base
        
        # Round to nearest integer cycles
        cycles = max(1, round(frequency * target_duration))
        
        return cycles
    
    def calculate_sequence_duration(self, 
                                   sequence_length: int,
                                   fold_level: int = 1,
                                   cycles_per_base: int = 3,
                                   avg_frequency: float = 400.0) -> float:
        """
        Calculate total duration for a sequence
        
        Args:
            sequence_length: Number of bases
            fold_level: Folding compression level
            cycles_per_base: Waveform cycles per base
            avg_frequency: Average frequency
            
        Returns:
            Duration in seconds
        """
        base_duration = cycles_per_base / avg_frequency
        total_duration = sequence_length * base_duration
        
        # Apply folding compression
        compression = 2 ** fold_level
        compressed_duration = total_duration / compression
        
        return compressed_duration
    
    def calculate_optimal_compression(self, 
                                      sequence_length: int,
                                      target_duration: float) -> Tuple[int, int]:
        """
        Calculate optimal folding and cycle parameters for target duration
        
        Args:
            sequence_length: Length of sequence
            target_duration: Desired output duration in seconds
            
        Returns:
            Tuple of (fold_level, cycles_per_base)
        """
        # Start with default cycles
        for cycles in range(1, 10):
            for fold in range(0, 8):
                duration = self.calculate_sequence_duration(
                    sequence_length, fold, cycles, 400.0
                )
                if abs(duration - target_duration) / target_duration < 0.1:
                    return (fold, cycles)
        
        # Default if no good match
        return (3, 3)

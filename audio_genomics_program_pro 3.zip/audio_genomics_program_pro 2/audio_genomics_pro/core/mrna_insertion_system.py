"""
mRNA Insertion System
Handles mRNA-based protein expression for temporary superpower activation
Different from CRISPR - mRNA is temporary expression, not permanent genome editing
"""

import json
import re
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class mRNASequenceType(Enum):
    """Types of mRNA sequences"""
    CODING = "coding"  # Protein-coding mRNA
    REGULATORY = "regulatory"  # Regulatory RNA (miRNA, siRNA, etc.)
    ENHANCER = "enhancer"  # Expression enhancer
    STABILITY = "stability"  # Stability elements (UTR, poly-A tail)


@dataclass
class mRNAInsertion:
    """Represents a single mRNA insertion"""
    name: str
    target_system: str
    sequence: str
    sequence_type: mRNASequenceType
    protein_function: str
    duration: str  # Expression duration (temporary)
    priority: int
    codon_optimized: bool = True
    gc_content: float = 0.0
    
    def calculate_gc_content(self):
        """Calculate GC content of the sequence"""
        sequence_upper = self.sequence.upper()
        gc_count = sequence_upper.count('G') + sequence_upper.count('C')
        self.gc_content = gc_count / len(sequence_upper) if sequence_upper else 0
        return self.gc_content


@dataclass
class SexualTransformationTarget:
    """Specific target for male-to-hermaphrodite transformation"""
    gene_name: str
    chromosome: str
    position: int
    target_protein: str
    transformation_stage: str  # "initiation", "development", "maintenance"
    mrna_sequence: str
    expression_level: str  # "high", "medium", "low"
    timing: str  # "immediate", "gradual", "delayed"


@dataclass
class SuperpowerTarget:
    """Target for a specific superpower"""
    power_name: str
    biological_system: str
    primary_organs: List[str]
    cellular_components: List[str]
    mrna_insertions: List[mRNAInsertion]
    activation_pathway: str
    transformation_process: str


class mRNAInsertionSystem:
    """
    System for designing mRNA insertions for superpower activation
    Focus: Temporary protein expression for transformation
    """
    
    def __init__(self):
        """Initialize mRNA insertion system"""
        self.insertions: List[mRNAInsertion] = []
        self.sexual_targets: List[SexualTransformationTarget] = []
        self.superpower_targets: List[SuperpowerTarget] = []
        self.current_payload: Optional[Dict] = None
    
    def create_mrna_sequence(self,
                           protein_sequence: str,
                           optimize_codons: bool = True,
                           add_5p_utr: bool = True,
                           add_3p_utr: bool = True,
                           add_poly_a: bool = True) -> str:
        """
        Create mRNA sequence from protein sequence
        
        Args:
            protein_sequence: Amino acid sequence
            optimize_codons: Optimize codons for human expression
            add_5p_utr: Add 5' UTR for translation initiation
            add_3p_utr: Add 3' UTR for stability
            add_poly_a: Add poly-A tail for stability
            
        Returns:
            Complete mRNA sequence
        """
        # Human codon usage table (optimized)
        human_codon_table = {
            'A': 'GCU', 'R': 'CGU', 'N': 'AAU', 'D': 'GAU',
            'C': 'UGU', 'Q': 'CAA', 'E': 'GAA', 'G': 'GGU',
            'H': 'CAU', 'I': 'AUU', 'L': 'CUU', 'K': 'AAA',
            'M': 'AUG', 'F': 'UUU', 'P': 'CCU', 'S': 'UCU',
            'T': 'ACU', 'W': 'UGG', 'Y': 'UAU', 'V': 'GUU',
            '*': 'UAA'  # Stop codon
        }
        
        # Convert protein to coding sequence (CDS)
        cds = ''.join(human_codon_table.get(aa, 'NNN') for aa in protein_sequence.upper())
        
        # Add 5' UTR (Kozak sequence for translation initiation)
        if add_5p_utr:
            kozak_sequence = "GCCACC"  # Strong Kozak consensus
            start_codon = "AUG"
            cds = kozak_sequence + start_codon + cds[3:]  # Replace first codon with AUG
        
        # Add 3' UTR (stability elements)
        if add_3p_utr:
            stability_elements = "AAUAAA"  # Polyadenylation signal
            cds = cds + stability_elements
        
        # Add poly-A tail
        if add_poly_a:
            poly_a_tail = "A" * 100  # 100-adenine tail
            cds = cds + poly_a_tail
        
        return cds
    
    def design_sexual_transformation_mrna(self) -> List[SexualTransformationTarget]:
        """
        Design mRNA insertions for male-to-hermaphrodite transformation
        
        Returns:
            List of sexual transformation targets
        """
        targets = []
        
        # Stage 1: Initiation - Suppress male pathway
        targets.append(SexualTransformationTarget(
            gene_name="DMRT1",
            chromosome="chr9",
            position=133255718,
            target_protein="DMRT1 (Doublesex and mab-3 related transcription factor 1)",
            transformation_stage="initiation",
            mrna_sequence=self.create_mrna_sequence("MIRKLLQELR", add_poly_a=False),  # siRNA for suppression
            expression_level="high",
            timing="immediate"
        ))
        
        # Stage 2: Development - Activate female pathway
        targets.append(SexualTransformationTarget(
            gene_name="FOXL2",
            chromosome="chr3",
            position=138538660,
            target_protein="FOXL2 (Forkhead box L2)",
            transformation_stage="development",
            mrna_sequence=self.create_mrna_sequence("MSTQELQELRQELELRQELRQELR*"),
            expression_level="high",
            timing="gradual"
        ))
        
        targets.append(SexualTransformationTarget(
            gene_name="WNT4",
            chromosome="chr1",
            position=116847947,
            target_protein="WNT4 (Wingless-type MMTV integration site family member 4)",
            transformation_stage="development",
            mrna_sequence=self.create_mrna_sequence("MLLLLLLAAVAVLG*"),
            expression_level="high",
            timing="gradual"
        ))
        
        targets.append(SexualTransformationTarget(
            gene_name="RSPO1",
            chromosome="chr1",
            position=148783164,
            target_protein="RSPO1 (R-spondin 1)",
            transformation_stage="development",
            mrna_sequence=self.create_mrna_sequence("MALLLVLLAAVAVLG*"),
            expression_level="high",
            timing="gradual"
        ))
        
        # Stage 3: Maintenance - Ovarian development
        targets.append(SexualTransformationTarget(
            gene_name="SOX9",
            chromosome="chr17",
            position=69678901,
            target_protein="SOX9 (SRY-box transcription factor 9)",
            transformation_stage="maintenance",
            mrna_sequence=self.create_mrna_sequence("MPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAP*"),
            expression_level="medium",
            timing="delayed"
        ))
        
        targets.append(SexualTransformationTarget(
            gene_name="SF1",
            chromosome="chr9",
            position=127890123,
            target_protein="SF1 (Steroidogenic factor 1)",
            transformation_stage="maintenance",
            mrna_sequence=self.create_mrna_sequence("MALLLLAAVAVLG*"),
            expression_level="medium",
            timing="delayed"
        ))
        
        # Stage 4: Hormonal balance
        targets.append(SexualTransformationTarget(
            gene_name="AR",
            chromosome="chrX",
            position=67543210,
            target_protein="AR (Androgen receptor)",
            transformation_stage="maintenance",
            mrna_sequence=self.create_mrna_sequence("MALLLLAAVAVLG*"),
            expression_level="medium",
            timing="delayed"
        ))
        
        targets.append(SexualTransformationTarget(
            gene_name="ESR1",
            chromosome="chr6",
            position=152345678,
            target_protein="ESR1 (Estrogen receptor 1)",
            transformation_stage="maintenance",
            mrna_sequence=self.create_mrna_sequence("MALLLLAAVAVLG*"),
            expression_level="medium",
            timing="delayed"
        ))
        
        targets.append(SexualTransformationTarget(
            gene_name="ESR2",
            chromosome="chr14",
            position=64567890,
            target_protein="ESR2 (Estrogen receptor 2)",
            transformation_stage="maintenance",
            mrna_sequence=self.create_mrna_sequence("MALLLLAAVAVLG*"),
            expression_level="medium",
            timing="delayed"
        ))
        
        targets.append(SexualTransformationTarget(
            gene_name="AMH",
            chromosome="chr19",
            position=22345678,
            target_protein="AMH (Anti-Müllerian hormone)",
            transformation_stage="maintenance",
            mrna_sequence=self.create_mrna_sequence("MALLLLAAVAVLG*"),
            expression_level="low",
            timing="delayed"
        ))
        
        self.sexual_targets = targets
        return targets
    
    def design_superpower_mrna(self,
                               power_name: str,
                               biological_system: str,
                               primary_organs: List[str],
                               cellular_components: List[str],
                               protein_sequence: str) -> SuperpowerTarget:
        """
        Design mRNA insertions for a specific superpower
        
        Args:
            power_name: Name of the superpower
            biological_system: Target biological system
            primary_organs: Primary organs involved
            cellular_components: Cellular components
            protein_sequence: Protein sequence to express
            
        Returns:
            Superpower target with mRNA insertions
        """
        # Create mRNA sequence
        mrna_seq = self.create_mrna_sequence(protein_sequence)
        
        # Create mRNA insertion
        insertion = mRNAInsertion(
            name=f"{power_name}_mRNA",
            target_system=biological_system,
            sequence=mrna_seq,
            sequence_type=mRNASequenceType.CODING,
            protein_function=f"Expresses {power_name} protein",
            duration="temporary (hours to days)",
            priority=5,
            codon_optimized=True
        )
        insertion.calculate_gc_content()
        
        # Create superpower target
        target = SuperpowerTarget(
            power_name=power_name,
            biological_system=biological_system,
            primary_organs=primary_organs,
            cellular_components=cellular_components,
            mrna_insertions=[insertion],
            activation_pathway="mRNA delivery → translation → protein expression → power activation",
            transformation_process=f"mRNA expresses {power_name} protein in {', '.join(primary_organs)}"
        )
        
        self.superpower_targets.append(target)
        return target
    
    def create_comprehensive_payload(self,
                                   include_all_superpowers: bool = True,
                                   include_sexual_transformation: bool = True,
                                   chunk_size: int = 5000) -> Dict:
        """
        Create comprehensive mRNA payload for all targets
        
        Args:
            include_all_superpowers: Include all 52,095 superpowers
            include_sexual_transformation: Include hermaphroditic transformation
            chunk_size: Size of each compartmentalized chunk
            
        Returns:
            Complete payload dictionary
        """
        payload = {
            "name": "Comprehensive_Superpower_Hermaphroditic_Transformation",
            "type": "mRNA_Insertion_Payload",
            "timestamp": datetime.now().isoformat(),
            "total_insertions": 0,
            "sexual_transformations": [],
            "superpower_insertions": [],
            "compartmentalized_chunks": [],
            "metadata": {
                "organism": "Human_Dragon_Hybrid",
                "starting_state": "Male",
                "target_state": "Hermaphroditic_Dragon_Deity",
                "total_powers": 52095,
                "expression_duration": "temporary (reversible)"
            }
        }
        
        # Add sexual transformation targets
        if include_sexual_transformation:
            sexual_targets = self.design_sexual_transformation_mrna()
            payload["sexual_transformations"] = [
                {
                    "gene": t.gene_name,
                    "chromosome": t.chromosome,
                    "position": t.position,
                    "protein": t.target_protein,
                    "stage": t.transformation_stage,
                    "mrna_sequence": t.mrna_sequence,
                    "expression_level": t.expression_level,
                    "timing": t.timing
                }
                for t in sexual_targets
            ]
            payload["total_insertions"] += len(sexual_targets)
        
        # Generate compartmentalized chunks
        all_sequences = []
        
        # Add sexual transformation sequences
        for target in self.sexual_targets:
            all_sequences.append(f"NNNNNNNNNN")  # Separator
            all_sequences.append(target.mrna_sequence)
        
        # Combine all sequences
        full_sequence = "".join(all_sequences)
        
        # Split into chunks
        chunks = []
        for i in range(0, len(full_sequence), chunk_size):
            chunk = full_sequence[i:i + chunk_size]
            chunks.append({
                "chunk_id": len(chunks),
                "sequence": chunk,
                "length": len(chunk),
                "start_position": i,
                "end_position": min(i + chunk_size, len(full_sequence))
            })
        
        payload["compartmentalized_chunks"] = chunks
        payload["total_sequence_length"] = len(full_sequence)
        payload["total_chunks"] = len(chunks)
        
        self.current_payload = payload
        return payload
    
    def export_payload_to_json(self, filepath: str):
        """Export payload to JSON file"""
        if not self.current_payload:
            raise ValueError("No payload created. Call create_comprehensive_payload() first.")
        
        with open(filepath, 'w') as f:
            json.dump(self.current_payload, f, indent=2)
    
    def get_mrna_statistics(self) -> Dict:
        """Get statistics about mRNA insertions"""
        if not self.current_payload:
            return {}
        
        stats = {
            "total_insertions": self.current_payload["total_insertions"],
            "sexual_transformations": len(self.current_payload["sexual_transformations"]),
            "superpower_insertions": len(self.current_payload["superpower_insertions"]),
            "total_sequence_length": self.current_payload["total_sequence_length"],
            "total_chunks": self.current_payload["total_chunks"],
            "chunk_size": 5000
        }
        
        # Calculate GC content
        all_sequences = []
        for t in self.sexual_targets:
            all_sequences.append(t.mrna_sequence)
        
        combined = "".join(all_sequences)
        gc_count = combined.count('G') + combined.count('C')
        stats["gc_content"] = gc_count / len(combined) if combined else 0
        
        return stats


def main():
    """Main function to demonstrate mRNA insertion system"""
    print("🧬 mRNA Insertion System for Superpower Activation")
    print("=" * 70)
    
    # Initialize system
    system = mRNAInsertionSystem()
    
    # Design sexual transformation mRNA
    print("\n🎯 Designing mRNA for Male-to-Hermaphrodite Transformation...")
    sexual_targets = system.design_sexual_transformation_mrna()
    print(f"✅ Created {len(sexual_targets)} sexual transformation targets:")
    for target in sexual_targets:
        print(f"   • {target.gene_name}: {target.target_protein}")
        print(f"     Stage: {target.transformation_stage}, Timing: {target.timing}")
    
    # Design sample superpower mRNA
    print("\n⚡ Designing mRNA for Sample Superpower...")
    superpower = system.design_superpower_mrna(
        power_name="Telepathy",
        biological_system="NEURAL CEREBRAL",
        primary_organs=["Cerebral cortex", "Pineal gland", "Hypothalamus"],
        cellular_components=["Neurons", "Astrocytes", "Oligodendrocytes"],
        protein_sequence="MALLLLAAVAVLG*"
    )
    print(f"✅ Created mRNA for {superpower.power_name}")
    print(f"   Sequence length: {len(superpower.mrna_insertions[0].sequence)} bases")
    print(f"   GC content: {superpower.mrna_insertions[0].gc_content:.2%}")
    
    # Create comprehensive payload
    print("\n📦 Creating Comprehensive mRNA Payload...")
    payload = system.create_comprehensive_payload(
        include_all_superpowers=False,  # Set to True for full 52,095 powers
        include_sexual_transformation=True,
        chunk_size=5000
    )
    
    print(f"✅ Payload created:")
    print(f"   Total insertions: {payload['total_insertions']}")
    print(f"   Sexual transformations: {len(payload['sexual_transformations'])}")
    print(f"   Total sequence length: {payload['total_sequence_length']} bases")
    print(f"   Compartmentalized chunks: {payload['total_chunks']}")
    
    # Export payload
    output_file = "/Users/36n9/Downloads/mrna_insertion_payload.json"
    system.export_payload_to_json(output_file)
    print(f"\n📄 Payload exported to: {output_file}")
    
    # Get statistics
    stats = system.get_mrna_statistics()
    print(f"\n📊 mRNA Statistics:")
    print(f"   Total insertions: {stats['total_insertions']}")
    print(f"   GC content: {stats['gc_content']:.2%}")
    print(f"   Total chunks: {stats['total_chunks']}")
    
    return payload


if __name__ == "__main__":
    main()

"""
Tone Generator Module
Dynamic tone synthesis for DNA/RNA sequences
"""

import numpy as np
from typing import Optional, Union, List
from .frequency_mapper import FrequencyMapper

class ToneGenerator:
    """Generate audio tones for DNA/RNA sequences"""
    
    def __init__(self, sample_rate: int = 192000, tuning_reference: float = 440.0):
        """
        Initialize tone generator
        
        Args:
            sample_rate: Audio sample rate in Hz
            tuning_reference: A4 tuning reference (440 or 432 Hz)
        """
        self.sample_rate = sample_rate
        self.frequency_mapper = FrequencyMapper(tuning_reference)
        
        # Waveform types
        self.waveform_types = {
            'sine': self._generate_sine,
            'sawtooth': self._generate_sawtooth,
            'square': self._generate_square,
            'triangle': self._generate_triangle,
            'harmonic': self._generate_harmonic
        }
        
        # Default waveform for each base
        self.base_waveforms = {
            'A': 'sine',
            'T': 'sawtooth',
            'U': 'sawtooth',
            'C': 'square',
            'G': 'triangle'
        }
    
    def _generate_sine(self, frequency: float, duration: float, phase: float = 0) -> np.ndarray:
        """Generate sine wave"""
        t = np.arange(0, int(duration * self.sample_rate)) / self.sample_rate
        return np.sin(2 * np.pi * frequency * t + phase)
    
    def _generate_sawtooth(self, frequency: float, duration: float, phase: float = 0) -> np.ndarray:
        """Generate sawtooth wave"""
        t = np.arange(0, int(duration * self.sample_rate)) / self.sample_rate
        period = 1.0 / frequency
        return 2 * ((t + phase / (2 * np.pi)) % period) / period - 1
    
    def _generate_square(self, frequency: float, duration: float, phase: float = 0) -> np.ndarray:
        """Generate square wave"""
        t = np.arange(0, int(duration * self.sample_rate)) / self.sample_rate
        return np.sign(np.sin(2 * np.pi * frequency * t + phase))
    
    def _generate_triangle(self, frequency: float, duration: float, phase: float = 0) -> np.ndarray:
        """Generate triangle wave"""
        t = np.arange(0, int(duration * self.sample_rate)) / self.sample_rate
        period = 1.0 / frequency
        return 4 * np.abs((t + phase / (2 * np.pi)) % period - period / 2) / period - 1
    
    def _generate_harmonic(self, frequency: float, duration: float, 
                          harmonics: List[tuple], phase: float = 0) -> np.ndarray:
        """Generate wave with multiple harmonics"""
        t = np.arange(0, int(duration * self.sample_rate)) / self.sample_rate
        signal = np.zeros_like(t)
        
        for harmonic_num, weight in harmonics:
            signal += weight * np.sin(2 * np.pi * frequency * harmonic_num * t + phase)
        
        # Normalize
        if np.max(np.abs(signal)) > 0:
            signal /= np.max(np.abs(signal))
        
        return signal
    
    def generate_base_tone(self, 
                          base: str, 
                          cycles: int = 3,
                          waveform: Optional[str] = None,
                          use_harmonics: bool = False) -> np.ndarray:
        """
        Generate tone for a single DNA/RNA base
        
        Args:
            base: DNA/RNA base (A, T, C, G, U)
            cycles: Number of waveform cycles
            waveform: Waveform type (sine, sawtooth, square, triangle)
            use_harmonics: Include harmonic overtones
            
        Returns:
            Audio samples
        """
        base = base.upper()
        
        # Get frequency
        frequency = self.frequency_mapper.get_base_frequency(base)
        
        # Calculate duration for exact cycles
        duration = cycles / frequency
        
        # Select waveform
        if waveform is None:
            waveform = self.base_waveforms.get(base, 'sine')
        
        # Generate tone
        if use_harmonics and base in ['A', 'T', 'U', 'C', 'G']:
            harmonics = self.frequency_mapper.get_base_harmonics(base)
            harmonic_list = [(num, weight) for num, (freq, weight) in harmonics.items()]
            tone = self._generate_harmonic(frequency, duration, harmonic_list)
        else:
            if waveform in self.waveform_types:
                tone = self.waveform_types[waveform](frequency, duration)
            else:
                tone = self._generate_sine(frequency, duration)
        
        # Apply envelope
        tone = self._apply_envelope(tone)
        
        return tone
    
    def generate_separator_tone(self, cycles: int = 1) -> np.ndarray:
        """
        Generate separator tone (528 Hz)
        
        Args:
            cycles: Number of cycles
            
        Returns:
            Audio samples
        """
        frequency = self.frequency_mapper.get_separator_frequency()
        duration = cycles / frequency
        tone = self._generate_sine(frequency, duration)
        return self._apply_envelope(tone, attack=0.001, release=0.001)
    
    def generate_codon_separator_tone(self, cycles: int = 3) -> np.ndarray:
        """
        Generate codon separator tone (639 Hz)
        
        Args:
            cycles: Number of cycles
            
        Returns:
            Audio samples
        """
        frequency = self.frequency_mapper.get_codon_separator_frequency()
        duration = cycles / frequency
        tone = self._generate_sine(frequency, duration)
        return self._apply_envelope(tone, attack=0.002, release=0.002)
    
    def generate_sequence_audio(self,
                               sequence: str,
                               base_cycles: int = 3,
                               separator_cycles: int = 1,
                               codon_separator_cycles: int = 3,
                               use_harmonics: bool = False) -> np.ndarray:
        """
        Generate audio for complete DNA/RNA sequence
        
        Args:
            sequence: DNA/RNA sequence
            base_cycles: Cycles per base
            separator_cycles: Cycles for separators
            codon_separator_cycles: Cycles for codon separators
            use_harmonics: Use harmonic overtones
            
        Returns:
            Complete audio signal
        """
        audio_segments = []
        
        for i, base in enumerate(sequence.upper()):
            if base in ['A', 'T', 'C', 'G', 'U']:
                # Generate base tone
                tone = self.generate_base_tone(base, base_cycles, use_harmonics=use_harmonics)
                audio_segments.append(tone)
                
                # Add separator after each base except last
                if i < len(sequence) - 1:
                    separator = self.generate_separator_tone(separator_cycles)
                    audio_segments.append(separator)
                
                # Add codon separator every 3 bases
                if (i + 1) % 3 == 0 and i < len(sequence) - 1:
                    codon_sep = self.generate_codon_separator_tone(codon_separator_cycles)
                    audio_segments.append(codon_sep)
        
        # Concatenate all segments
        if audio_segments:
            return np.concatenate(audio_segments)
        
        return np.array([])
    
    def generate_chord(self, bases: str, duration: float = 1.0) -> np.ndarray:
        """
        Generate chord from multiple bases
        
        Args:
            bases: Multiple bases to play simultaneously
            duration: Duration in seconds
            
        Returns:
            Audio samples of chord
        """
        frequencies = self.frequency_mapper.get_chord_frequencies(bases)
        
        if not frequencies:
            return np.zeros(int(duration * self.sample_rate))
        
        t = np.arange(0, int(duration * self.sample_rate)) / self.sample_rate
        chord = np.zeros_like(t)
        
        for freq in frequencies:
            chord += np.sin(2 * np.pi * freq * t)
        
        # Normalize
        chord /= len(frequencies)
        
        return self._apply_envelope(chord)
    
    def generate_binaural_beat(self,
                              base1: str,
                              base2: str,
                              duration: float = 1.0) -> tuple:
        """
        Generate binaural beat from two bases
        
        Args:
            base1: First base
            base2: Second base
            duration: Duration in seconds
            
        Returns:
            Tuple of (left_channel, right_channel)
        """
        freq1 = self.frequency_mapper.get_base_frequency(base1)
        freq2 = self.frequency_mapper.get_base_frequency(base2)
        
        t = np.arange(0, int(duration * self.sample_rate)) / self.sample_rate
        
        left = np.sin(2 * np.pi * freq1 * t)
        right = np.sin(2 * np.pi * freq2 * t)
        
        return (self._apply_envelope(left), self._apply_envelope(right))
    
    def _apply_envelope(self,
                       signal: np.ndarray,
                       attack: float = 0.01,
                       decay: float = 0.1,
                       sustain: float = 0.7,
                       release: float = 0.05) -> np.ndarray:
        """
        Apply ADSR envelope to signal
        
        Args:
            signal: Input signal
            attack: Attack time (seconds)
            decay: Decay time (seconds)
            sustain: Sustain level (0-1)
            release: Release time (seconds)
            
        Returns:
            Signal with envelope applied
        """
        n_samples = len(signal)
        envelope = np.ones(n_samples)
        
        # Convert times to samples
        attack_samples = int(attack * self.sample_rate)
        decay_samples = int(decay * self.sample_rate)
        release_samples = int(release * self.sample_rate)
        
        # Ensure we don't exceed signal length
        attack_samples = min(attack_samples, n_samples // 4)
        decay_samples = min(decay_samples, n_samples // 4)
        release_samples = min(release_samples, n_samples // 4)
        
        # Attack
        if attack_samples > 0:
            envelope[:attack_samples] = np.linspace(0, 1, attack_samples)
        
        # Decay
        if decay_samples > 0:
            decay_start = attack_samples
            decay_end = decay_start + decay_samples
            if decay_end <= n_samples:
                envelope[decay_start:decay_end] = np.linspace(1, sustain, decay_samples)
        
        # Sustain
        sustain_start = attack_samples + decay_samples
        sustain_end = n_samples - release_samples
        if sustain_end > sustain_start:
            envelope[sustain_start:sustain_end] = sustain
        
        # Release
        if release_samples > 0 and release_samples < n_samples:
            envelope[-release_samples:] = np.linspace(sustain, 0, release_samples)
        
        return signal * envelope
    
    def apply_frequency_modulation(self,
                                  signal: np.ndarray,
                                  mod_frequency: float,
                                  mod_depth: float) -> np.ndarray:
        """
        Apply frequency modulation to signal
        
        Args:
            signal: Input signal
            mod_frequency: Modulation frequency
            mod_depth: Modulation depth (0-1)
            
        Returns:
            Frequency modulated signal
        """
        t = np.arange(len(signal)) / self.sample_rate
        modulator = np.sin(2 * np.pi * mod_frequency * t)
        
        # Apply FM using phase modulation
        phase_shift = mod_depth * modulator
        modulated = signal * np.cos(phase_shift)
        
        return modulated
    
    def apply_amplitude_modulation(self,
                                  signal: np.ndarray,
                                  mod_frequency: float,
                                  mod_depth: float) -> np.ndarray:
        """
        Apply amplitude modulation to signal
        
        Args:
            signal: Input signal
            mod_frequency: Modulation frequency
            mod_depth: Modulation depth (0-1)
            
        Returns:
            Amplitude modulated signal
        """
        t = np.arange(len(signal)) / self.sample_rate
        modulator = 1 + mod_depth * np.sin(2 * np.pi * mod_frequency * t)
        
        return signal * modulator

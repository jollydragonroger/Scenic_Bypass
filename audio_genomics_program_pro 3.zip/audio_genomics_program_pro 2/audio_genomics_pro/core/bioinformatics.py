"""
Bioinformatics Module
Handles GenBank sequence retrieval, gene editing, and protein analysis
Using CC0-compatible approaches
"""

import re
import json
import urllib.request
import urllib.parse
from typing import Dict, List, Optional, Tuple
import xml.etree.ElementTree as ET

class BioinformaticsTools:
    """Tools for working with biological sequences"""
    
    def __init__(self):
        """Initialize bioinformatics tools"""
        # NCBI E-utilities base URL (public domain API)
        self.ncbi_base = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
        
        # Codon table (standard genetic code)
        self.codon_table = {
            'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L',
            'TCT': 'S', 'TCC': 'S', 'TCA': 'S', 'TCG': 'S',
            'TAT': 'Y', 'TAC': 'Y', 'TAA': '*', 'TAG': '*',
            'TGT': 'C', 'TGC': 'C', 'TGA': '*', 'TGG': 'W',
            'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L',
            'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
            'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
            'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
            'ATT': 'I', 'ATC': 'I', 'ATA': 'I', 'ATG': 'M',
            'ACT': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
            'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
            'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
            'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V',
            'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
            'GAT': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
            'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'
        }
        
        # Reverse codon table for protein to DNA
        self.reverse_codon_table = {}
        for codon, amino in self.codon_table.items():
            if amino not in self.reverse_codon_table:
                self.reverse_codon_table[amino] = []
            self.reverse_codon_table[amino].append(codon)
    
    def search_genbank(self, 
                      query: str, 
                      database: str = "nucleotide",
                      max_results: int = 10) -> List[Dict]:
        """
        Search GenBank for sequences
        
        Args:
            query: Search query
            database: NCBI database (nucleotide, protein, gene)
            max_results: Maximum number of results
            
        Returns:
            List of search results
        """
        try:
            # Build search URL
            params = {
                'db': database,
                'term': query,
                'retmax': max_results,
                'retmode': 'json'
            }
            
            search_url = self.ncbi_base + "esearch.fcgi?" + urllib.parse.urlencode(params)
            
            # Fetch search results
            with urllib.request.urlopen(search_url) as response:
                data = json.loads(response.read().decode())
            
            # Extract IDs
            id_list = data.get('esearchresult', {}).get('idlist', [])
            
            if not id_list:
                return []
            
            # Fetch summaries for each ID
            results = []
            for seq_id in id_list:
                summary = self.get_sequence_summary(seq_id, database)
                if summary:
                    results.append(summary)
            
            return results
            
        except Exception as e:
            print(f"Error searching GenBank: {e}")
            return []
    
    def get_sequence_summary(self, seq_id: str, database: str = "nucleotide") -> Optional[Dict]:
        """
        Get summary information for a sequence
        
        Args:
            seq_id: Sequence ID
            database: NCBI database
            
        Returns:
            Sequence summary dictionary
        """
        try:
            params = {
                'db': database,
                'id': seq_id,
                'retmode': 'json'
            }
            
            summary_url = self.ncbi_base + "esummary.fcgi?" + urllib.parse.urlencode(params)
            
            with urllib.request.urlopen(summary_url) as response:
                data = json.loads(response.read().decode())
            
            # Extract summary
            result = data.get('result', {}).get(seq_id, {})
            
            if result:
                return {
                    'id': seq_id,
                    'title': result.get('title', ''),
                    'organism': result.get('organism', ''),
                    'length': result.get('slen', 0),
                    'accession': result.get('accessionversion', ''),
                    'update_date': result.get('updatedate', '')
                }
            
            return None
            
        except Exception as e:
            print(f"Error getting sequence summary: {e}")
            return None
    
    def fetch_sequence(self, 
                      seq_id: str, 
                      database: str = "nucleotide",
                      format: str = "fasta") -> Optional[str]:
        """
        Fetch a sequence from GenBank
        
        Args:
            seq_id: Sequence ID or accession number
            database: NCBI database
            format: Output format (fasta, genbank, etc.)
            
        Returns:
            Sequence data as string
        """
        try:
            params = {
                'db': database,
                'id': seq_id,
                'rettype': format,
                'retmode': 'text'
            }
            
            fetch_url = self.ncbi_base + "efetch.fcgi?" + urllib.parse.urlencode(params)
            
            with urllib.request.urlopen(fetch_url) as response:
                sequence_data = response.read().decode()
            
            return sequence_data
            
        except Exception as e:
            print(f"Error fetching sequence: {e}")
            return None
    
    def parse_fasta(self, fasta_data: str) -> List[Tuple[str, str]]:
        """
        Parse FASTA format data
        
        Args:
            fasta_data: FASTA format string
            
        Returns:
            List of (header, sequence) tuples
        """
        sequences = []
        current_header = None
        current_sequence = []
        
        for line in fasta_data.split('\n'):
            line = line.strip()
            if line.startswith('>'):
                # Save previous sequence
                if current_header:
                    sequences.append((current_header, ''.join(current_sequence)))
                # Start new sequence
                current_header = line[1:]
                current_sequence = []
            else:
                current_sequence.append(line)
        
        # Save last sequence
        if current_header:
            sequences.append((current_header, ''.join(current_sequence)))
        
        return sequences
    
    def translate_dna_to_protein(self, dna_sequence: str) -> str:
        """
        Translate DNA sequence to protein
        
        Args:
            dna_sequence: DNA sequence
            
        Returns:
            Protein sequence
        """
        # Clean sequence
        dna = re.sub(r'[^ATCG]', '', dna_sequence.upper())
        
        protein = []
        for i in range(0, len(dna) - 2, 3):
            codon = dna[i:i+3]
            amino_acid = self.codon_table.get(codon, 'X')
            protein.append(amino_acid)
        
        return ''.join(protein)
    
    def reverse_translate_protein(self, 
                                protein_sequence: str,
                                prefer_common_codons: bool = True) -> str:
        """
        Reverse translate protein to DNA
        
        Args:
            protein_sequence: Protein sequence (single letter amino acids)
            prefer_common_codons: Use most common codons
            
        Returns:
            DNA sequence
        """
        # Common codon preferences (E. coli bias)
        preferred_codons = {
            'F': 'TTT', 'L': 'CTG', 'S': 'TCT', 'Y': 'TAT',
            'C': 'TGT', 'W': 'TGG', 'P': 'CCG', 'H': 'CAT',
            'Q': 'CAG', 'R': 'CGT', 'I': 'ATT', 'M': 'ATG',
            'T': 'ACC', 'N': 'AAT', 'K': 'AAA', 'V': 'GTG',
            'A': 'GCT', 'D': 'GAT', 'E': 'GAA', 'G': 'GGT',
            '*': 'TAA'  # Stop codon
        }
        
        dna = []
        for amino in protein_sequence.upper():
            if amino in self.reverse_codon_table:
                if prefer_common_codons and amino in preferred_codons:
                    dna.append(preferred_codons[amino])
                else:
                    # Use first available codon
                    dna.append(self.reverse_codon_table[amino][0])
            else:
                # Unknown amino acid, use NNN
                dna.append('NNN')
        
        return ''.join(dna)
    
    def find_orfs(self, dna_sequence: str, min_length: int = 100) -> List[Dict]:
        """
        Find open reading frames in DNA sequence
        
        Args:
            dna_sequence: DNA sequence
            min_length: Minimum ORF length in nucleotides
            
        Returns:
            List of ORF dictionaries
        """
        # Clean sequence
        dna = re.sub(r'[^ATCG]', '', dna_sequence.upper())
        
        orfs = []
        start_codon = 'ATG'
        stop_codons = ['TAA', 'TAG', 'TGA']
        
        # Check all three reading frames
        for frame in range(3):
            i = frame
            while i < len(dna) - 2:
                codon = dna[i:i+3]
                if codon == start_codon:
                    # Found start codon, look for stop
                    for j in range(i + 3, len(dna) - 2, 3):
                        codon = dna[j:j+3]
                        if codon in stop_codons:
                            # Found ORF
                            orf_length = j + 3 - i
                            if orf_length >= min_length:
                                orf_seq = dna[i:j+3]
                                protein = self.translate_dna_to_protein(orf_seq)
                                orfs.append({
                                    'start': i,
                                    'end': j + 3,
                                    'frame': frame,
                                    'length': orf_length,
                                    'sequence': orf_seq,
                                    'protein': protein
                                })
                            i = j + 3
                            break
                    else:
                        # No stop codon found
                        i += 3
                else:
                    i += 3
        
        return orfs
    
    def calculate_gc_content(self, sequence: str) -> float:
        """
        Calculate GC content of sequence
        
        Args:
            sequence: DNA or RNA sequence
            
        Returns:
            GC content as percentage
        """
        # Clean sequence
        seq = re.sub(r'[^ATCGU]', '', sequence.upper())
        
        if not seq:
            return 0.0
        
        gc_count = seq.count('G') + seq.count('C')
        return (gc_count / len(seq)) * 100
    
    def find_restriction_sites(self, 
                              dna_sequence: str,
                              enzyme_patterns: Optional[Dict[str, str]] = None) -> List[Dict]:
        """
        Find restriction enzyme cut sites
        
        Args:
            dna_sequence: DNA sequence
            enzyme_patterns: Dict of enzyme names to recognition patterns
            
        Returns:
            List of restriction sites
        """
        if enzyme_patterns is None:
            # Common restriction enzymes
            enzyme_patterns = {
                'EcoRI': 'GAATTC',
                'BamHI': 'GGATCC',
                'HindIII': 'AAGCTT',
                'PstI': 'CTGCAG',
                'SmaI': 'CCCGGG',
                'XbaI': 'TCTAGA',
                'SalI': 'GTCGAC',
                'NcoI': 'CCATGG'
            }
        
        # Clean sequence
        dna = re.sub(r'[^ATCG]', '', dna_sequence.upper())
        
        sites = []
        for enzyme, pattern in enzyme_patterns.items():
            # Find all occurrences
            for match in re.finditer(pattern, dna):
                sites.append({
                    'enzyme': enzyme,
                    'pattern': pattern,
                    'position': match.start(),
                    'cut_site': match.start() + len(pattern) // 2
                })
        
        # Sort by position
        sites.sort(key=lambda x: x['position'])
        
        return sites
    
    def mutate_sequence(self,
                       sequence: str,
                       mutations: List[Tuple[int, str]]) -> str:
        """
        Apply mutations to sequence
        
        Args:
            sequence: Original sequence
            mutations: List of (position, new_base) tuples
            
        Returns:
            Mutated sequence
        """
        seq_list = list(sequence)
        
        for position, new_base in mutations:
            if 0 <= position < len(seq_list):
                seq_list[position] = new_base
        
        return ''.join(seq_list)
    
    def align_sequences(self, seq1: str, seq2: str) -> Dict:
        """
        Simple pairwise sequence alignment
        
        Args:
            seq1: First sequence
            seq2: Second sequence
            
        Returns:
            Alignment information
        """
        # Simple identity calculation
        min_len = min(len(seq1), len(seq2))
        matches = sum(1 for i in range(min_len) if seq1[i] == seq2[i])
        
        identity = (matches / min_len * 100) if min_len > 0 else 0
        
        return {
            'sequence1_length': len(seq1),
            'sequence2_length': len(seq2),
            'aligned_length': min_len,
            'matches': matches,
            'identity_percent': identity,
            'length_difference': abs(len(seq1) - len(seq2))
        }

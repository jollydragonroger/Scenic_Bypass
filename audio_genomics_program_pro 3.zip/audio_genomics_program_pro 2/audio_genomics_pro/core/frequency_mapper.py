"""
Frequency Mapper Module
Maps DNA/RNA bases to precise audio frequencies
"""

from decimal import Decimal, getcontext
from typing import Dict, Optional, Tuple

# Set high precision for frequency calculations
getcontext().prec = 50

class FrequencyMapper:
    """Maps DNA/RNA bases to precise audio frequencies"""
    
    def __init__(self, tuning_reference: float = 440.0):
        """
        Initialize frequency mapper
        
        Args:
            tuning_reference: A4 tuning reference (440 Hz standard, 432 Hz alternative)
        """
        self.tuning_reference = Decimal(str(tuning_reference))
        
        # Base frequency mappings (scientific pitch)
        # Using musical notes that form harmonic relationships
        self.base_frequencies = {
            'A': Decimal('146.832383958704'),  # D3
            'T': Decimal('174.614115716502'),  # F3
            'U': Decimal('174.614115716502'),  # F3 (same as T for RNA)
            'C': Decimal('261.625565300599'),  # C4 (Middle C)
            'G': Decimal('391.995435981749'),  # G4
        }
        
        # Separator and special frequencies
        self.separator_frequency = Decimal('528.0')  # Love frequency
        self.codon_separator_frequency = Decimal('639.0')  # Relationship frequency
        
        # Harmonic series for each base
        self.harmonics = {
            'A': [1, 2, 3, 4, 5],  # Fundamental + overtones
            'T': [1, 2, 3, 4, 5],
            'U': [1, 2, 3, 4, 5],
            'C': [1, 2, 3, 4, 5],
            'G': [1, 2, 3, 4, 5]
        }
        
        # Amplitude weights for harmonics (creates timbre)
        self.harmonic_weights = {
            'A': [1.0, 0.5, 0.3, 0.2, 0.1],
            'T': [1.0, 0.4, 0.2, 0.1, 0.05],
            'U': [1.0, 0.4, 0.2, 0.1, 0.05],
            'C': [1.0, 0.6, 0.4, 0.3, 0.2],
            'G': [1.0, 0.7, 0.5, 0.3, 0.2]
        }
        
        # Retune if using 432 Hz reference
        if abs(tuning_reference - 432.0) < 1:
            self._retune_to_432()
    
    def _retune_to_432(self):
        """Retune all frequencies to 432 Hz reference"""
        # Calculate ratio between 440 and 432
        ratio = Decimal('432') / Decimal('440')
        
        # Apply ratio to all base frequencies
        for base in self.base_frequencies:
            self.base_frequencies[base] *= ratio
        
        # Also adjust special frequencies proportionally
        self.separator_frequency *= ratio
        self.codon_separator_frequency *= ratio
    
    def get_base_frequency(self, base: str, harmonic: int = 1) -> float:
        """
        Get frequency for a DNA/RNA base
        
        Args:
            base: DNA/RNA base (A, T, C, G, U)
            harmonic: Harmonic number (1 = fundamental)
            
        Returns:
            Frequency in Hz
        """
        base = base.upper()
        
        if base not in self.base_frequencies:
            raise ValueError(f"Invalid base: {base}")
        
        fundamental = self.base_frequencies[base]
        frequency = fundamental * Decimal(str(harmonic))
        
        return float(frequency)
    
    def get_base_harmonics(self, base: str) -> Dict[int, Tuple[float, float]]:
        """
        Get all harmonics for a base with weights
        
        Args:
            base: DNA/RNA base
            
        Returns:
            Dict of harmonic number to (frequency, weight) tuples
        """
        base = base.upper()
        
        if base not in self.base_frequencies:
            raise ValueError(f"Invalid base: {base}")
        
        harmonics_dict = {}
        
        for i, harmonic_num in enumerate(self.harmonics[base]):
            freq = self.get_base_frequency(base, harmonic_num)
            weight = self.harmonic_weights[base][i]
            harmonics_dict[harmonic_num] = (freq, weight)
        
        return harmonics_dict
    
    def get_separator_frequency(self) -> float:
        """Get separator frequency"""
        return float(self.separator_frequency)
    
    def get_codon_separator_frequency(self) -> float:
        """Get codon separator frequency"""
        return float(self.codon_separator_frequency)
    
    def get_sequence_frequencies(self, sequence: str) -> list:
        """
        Get frequencies for an entire sequence
        
        Args:
            sequence: DNA/RNA sequence
            
        Returns:
            List of frequencies
        """
        frequencies = []
        
        for i, base in enumerate(sequence.upper()):
            if base in self.base_frequencies:
                frequencies.append(self.get_base_frequency(base))
                
                # Add separator after each base except last
                if i < len(sequence) - 1:
                    frequencies.append(self.get_separator_frequency())
                
                # Add codon separator every 3 bases
                if (i + 1) % 3 == 0 and i < len(sequence) - 1:
                    frequencies.append(self.get_codon_separator_frequency())
        
        return frequencies
    
    def get_chord_frequencies(self, bases: str) -> list:
        """
        Get frequencies to play bases as a chord
        
        Args:
            bases: Multiple bases to play simultaneously
            
        Returns:
            List of frequencies
        """
        frequencies = []
        
        for base in bases.upper():
            if base in self.base_frequencies:
                frequencies.append(self.get_base_frequency(base))
        
        return frequencies
    
    def calculate_beat_frequency(self, base1: str, base2: str) -> float:
        """
        Calculate beat frequency between two bases
        
        Args:
            base1: First base
            base2: Second base
            
        Returns:
            Beat frequency in Hz
        """
        freq1 = self.get_base_frequency(base1)
        freq2 = self.get_base_frequency(base2)
        
        return abs(freq1 - freq2)
    
    def get_frequency_ratios(self) -> Dict[str, Dict[str, float]]:
        """
        Calculate frequency ratios between all bases
        
        Returns:
            Dictionary of base pairs to frequency ratios
        """
        ratios = {}
        bases = ['A', 'T', 'C', 'G']
        
        for base1 in bases:
            ratios[base1] = {}
            freq1 = Decimal(str(self.get_base_frequency(base1)))
            
            for base2 in bases:
                freq2 = Decimal(str(self.get_base_frequency(base2)))
                ratio = freq2 / freq1
                ratios[base1][base2] = float(ratio)
        
        return ratios
    
    def get_complementary_frequency(self, base: str) -> float:
        """
        Get frequency of complementary base
        
        Args:
            base: DNA/RNA base
            
        Returns:
            Frequency of complementary base
        """
        complements = {
            'A': 'T',
            'T': 'A',
            'C': 'G',
            'G': 'C',
            'U': 'A'
        }
        
        base = base.upper()
        if base in complements:
            return self.get_base_frequency(complements[base])
        
        raise ValueError(f"Invalid base: {base}")
    
    def calculate_gc_content_frequency_shift(self, gc_content: float) -> float:
        """
        Calculate frequency shift based on GC content
        
        Args:
            gc_content: GC content percentage (0-100)
            
        Returns:
            Frequency shift factor
        """
        # Higher GC content = higher average frequency
        # Linear mapping: 0% GC = 0.9x, 50% GC = 1.0x, 100% GC = 1.1x
        shift_factor = 0.9 + (gc_content / 100) * 0.2
        return shift_factor
    
    def get_codon_frequency(self, codon: str) -> float:
        """
        Get combined frequency for a codon (3 bases)
        
        Args:
            codon: 3-base codon
            
        Returns:
            Average frequency of the codon
        """
        if len(codon) != 3:
            raise ValueError("Codon must be exactly 3 bases")
        
        frequencies = []
        for base in codon.upper():
            if base in self.base_frequencies:
                frequencies.append(self.get_base_frequency(base))
        
        if frequencies:
            return sum(frequencies) / len(frequencies)
        
        return 0.0
    
    def get_amino_acid_frequency(self, amino_acid: str) -> float:
        """
        Get frequency for an amino acid (using common codon)
        
        Args:
            amino_acid: Single letter amino acid code
            
        Returns:
            Frequency based on common codon
        """
        # Map amino acids to common codons
        aa_to_codon = {
            'A': 'GCT',  # Alanine
            'R': 'CGT',  # Arginine
            'N': 'AAT',  # Asparagine
            'D': 'GAT',  # Aspartic acid
            'C': 'TGT',  # Cysteine
            'E': 'GAA',  # Glutamic acid
            'Q': 'CAA',  # Glutamine
            'G': 'GGT',  # Glycine
            'H': 'CAT',  # Histidine
            'I': 'ATT',  # Isoleucine
            'L': 'CTT',  # Leucine
            'K': 'AAA',  # Lysine
            'M': 'ATG',  # Methionine
            'F': 'TTT',  # Phenylalanine
            'P': 'CCT',  # Proline
            'S': 'TCT',  # Serine
            'T': 'ACT',  # Threonine
            'W': 'TGG',  # Tryptophan
            'Y': 'TAT',  # Tyrosine
            'V': 'GTT',  # Valine
            '*': 'TAA'   # Stop
        }
        
        amino_acid = amino_acid.upper()
        if amino_acid in aa_to_codon:
            return self.get_codon_frequency(aa_to_codon[amino_acid])
        
        return 0.0

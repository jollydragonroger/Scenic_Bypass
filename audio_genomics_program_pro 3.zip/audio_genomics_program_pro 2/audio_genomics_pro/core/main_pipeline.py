"""
Main Audio Genomics Pipeline
Integrates all modules for complete processing workflow
"""

import os
import json
import numpy as np
from typing import Dict, Optional, List, Union
from datetime import datetime

from .dna_converter import DNAConverter
from .audio_pipeline import AudioPipeline
from .modulation import ModulationProcessor
from .music_processor import MusicProcessor
from .bioinformatics import BioinformaticsTools
from .tone_synthesis import ToneSynthesizer

class AudioGenomicsPipeline:
    """Main pipeline orchestrating the entire audio genomics process"""
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize main pipeline
        
        Args:
            config: Configuration dictionary
        """
        # Default configuration
        self.config = {
            'sample_rate': 192000,
            'bit_depth': 32,
            'base_cycles': 3,
            'separator_cycles': 1,
            'codon_separator_cycles': 3,
            'fm_carrier_freq': 528.0,
            'fm_modulation_index': 0.1,
            'am_modulation_depth': 0.05,
            'am_mode': 'standard',
            'retune_to_432': True,
            'use_hebrew_encoding': False,
            'rna_mode': False,
            'output_format': 'wav',
            'normalize_output': True,
            'target_lufs': -14.0
        }
        
        # Update with provided config
        if config:
            self.config.update(config)
        
        # Initialize components
        self.dna_converter = DNAConverter()
        self.audio_pipeline = AudioPipeline(
            self.config['sample_rate'],
            self.config['bit_depth']
        )
        self.modulation = ModulationProcessor(self.config['sample_rate'])
        self.music_processor = MusicProcessor(self.config['sample_rate'])
        self.bioinformatics = BioinformaticsTools()
        
        # Processing state
        self.current_sequence = None
        self.current_audio = None
        self.processing_log = []
    
    def process_file(self,
                    input_file: str,
                    carrier_music_file: Optional[str] = None,
                    output_file: Optional[str] = None) -> Dict:
        """
        Process a file through the complete pipeline
        
        Args:
            input_file: Path to input file
            carrier_music_file: Optional music carrier file
            output_file: Output audio file path
            
        Returns:
            Processing results dictionary
        """
        self.log_step("Starting file processing", {'input': input_file})
        
        # Generate output filename if not provided
        if output_file is None:
            base_name = os.path.splitext(os.path.basename(input_file))[0]
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"output/{base_name}_genomic_{timestamp}.wav"
        
        # Ensure output directory exists
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        try:
            # Step 1: Convert file to DNA sequence
            self.log_step("Converting file to DNA sequence")
            
            # Check if input is a sequence file
            if input_file.lower().endswith(('.fasta', '.fa', '.fna')):
                # Load FASTA file
                with open(input_file, 'r') as f:
                    fasta_data = f.read()
                sequences = self.bioinformatics.parse_fasta(fasta_data)
                if sequences:
                    self.current_sequence = sequences[0][1]  # Use first sequence
                else:
                    raise ValueError("No sequences found in FASTA file")
            else:
                # Convert binary file to DNA
                dna_sequence = self.dna_converter.file_to_dna(
                    input_file,
                    use_hebrew=self.config['use_hebrew_encoding'],
                    rna_mode=self.config['rna_mode']
                )
                self.current_sequence = dna_sequence
            
            sequence_info = {
                'length': len(self.current_sequence),
                'gc_content': self.bioinformatics.calculate_gc_content(self.current_sequence),
                'type': 'RNA' if self.config['rna_mode'] else 'DNA'
            }
            self.log_step("Sequence generated", sequence_info)
            
            # Step 2: Generate audio from DNA sequence
            self.log_step("Generating audio from sequence")
            genomic_audio = self.audio_pipeline.generate_base_audio(
                self.current_sequence,
                base_cycles=self.config['base_cycles'],
                separator_cycles=self.config['separator_cycles'],
                codon_separator_cycles=self.config['codon_separator_cycles']
            )
            
            audio_info = self.audio_pipeline.get_audio_info(genomic_audio)
            self.log_step("Audio generated", audio_info)
            
            # Step 3: Apply FM modulation
            self.log_step("Applying FM modulation")
            fm_modulated = self.modulation.fm_modulate(
                genomic_audio,
                carrier_freq=self.config['fm_carrier_freq'],
                modulation_index=self.config['fm_modulation_index']
            )
            
            # Step 4: Process with music carrier if provided
            if carrier_music_file and os.path.exists(carrier_music_file):
                self.log_step("Loading carrier music", {'file': carrier_music_file})
                
                # Load music file
                music_audio, music_rate = self.music_processor.load_audio_file(carrier_music_file)
                
                # Resample if needed
                if music_rate != self.config['sample_rate']:
                    self.log_step(f"Resampling music from {music_rate} to {self.config['sample_rate']} Hz")
                    music_audio = self.music_processor.resample_audio(
                        music_audio, 
                        music_rate, 
                        self.config['sample_rate']
                    )
                
                # Retune to 432 Hz if requested
                if self.config['retune_to_432']:
                    self.log_step("Retuning music to 432 Hz")
                    pitch_info = self.music_processor.detect_pitch_reference(
                        music_audio, 
                        self.config['sample_rate']
                    )
                    self.log_step("Detected tuning", pitch_info)
                    
                    music_audio = self.music_processor.retune_to_432hz(
                        music_audio,
                        self.config['sample_rate'],
                        pitch_info['detected_a4']
                    )
                
                # Analyze music key
                key_info = self.music_processor.analyze_key_and_scale(
                    music_audio,
                    self.config['sample_rate']
                )
                self.log_step("Music analysis", key_info)
                
                # Time-scale genomic audio to match music duration
                music_duration = len(music_audio) / self.config['sample_rate']
                self.log_step(f"Scaling genomic audio to {music_duration:.2f} seconds")
                
                fm_modulated = self.audio_pipeline.apply_time_scaling(
                    fm_modulated,
                    music_duration,
                    use_exponential_scaling=True
                )
                
                # Apply subaudible embedding
                fm_modulated = self.modulation.subaudible_embedding(
                    fm_modulated,
                    target_db=-40.0
                )
                
                # Apply AM modulation with music
                self.log_step("Applying AM modulation with music carrier")
                final_audio = self.modulation.am_modulate(
                    music_audio,
                    fm_modulated,
                    modulation_depth=self.config['am_modulation_depth'],
                    mode=self.config['am_mode']
                )
                
                # Measure embedding level
                embedding_info = self.modulation.measure_embedding_level(
                    music_audio,
                    final_audio
                )
                self.log_step("Embedding level", embedding_info)
                
            else:
                # No music carrier, use FM modulated signal directly
                final_audio = fm_modulated
            
            # Step 5: Normalize output
            if self.config['normalize_output']:
                self.log_step("Normalizing audio loudness")
                final_audio = self.music_processor.normalize_loudness(
                    final_audio,
                    self.config['target_lufs']
                )
            
            # Step 6: Save output
            self.log_step("Saving output file", {'path': output_file})
            self.audio_pipeline.save_audio(final_audio, output_file)
            
            # Calculate final stats
            final_info = self.audio_pipeline.get_audio_info(final_audio)
            
            # Create result summary
            result = {
                'success': True,
                'input_file': input_file,
                'output_file': output_file,
                'carrier_music': carrier_music_file,
                'sequence_length': len(self.current_sequence),
                'audio_duration': final_info['duration_seconds'],
                'sample_rate': self.config['sample_rate'],
                'bit_depth': self.config['bit_depth'],
                'processing_log': self.processing_log
            }
            
            self.current_audio = final_audio
            self.log_step("Processing complete", result)
            
            return result
            
        except Exception as e:
            error_result = {
                'success': False,
                'error': str(e),
                'input_file': input_file,
                'processing_log': self.processing_log
            }
            self.log_step("Processing failed", {'error': str(e)})
            return error_result
    
    def process_genbank_sequence(self,
                                accession: str,
                                carrier_music_file: Optional[str] = None,
                                output_file: Optional[str] = None) -> Dict:
        """
        Process a GenBank sequence
        
        Args:
            accession: GenBank accession number
            carrier_music_file: Optional music carrier
            output_file: Output file path
            
        Returns:
            Processing results
        """
        self.log_step("Fetching GenBank sequence", {'accession': accession})
        
        # Fetch sequence from GenBank
        fasta_data = self.bioinformatics.fetch_sequence(accession, format='fasta')
        
        if not fasta_data:
            return {
                'success': False,
                'error': f"Failed to fetch sequence: {accession}"
            }
        
        # Parse FASTA
        sequences = self.bioinformatics.parse_fasta(fasta_data)
        if not sequences:
            return {
                'success': False,
                'error': "No sequences found in GenBank data"
            }
        
        # Use first sequence
        header, sequence = sequences[0]
        self.current_sequence = sequence
        
        self.log_step("GenBank sequence loaded", {
            'header': header[:100],
            'length': len(sequence)
        })
        
        # Generate output filename if needed
        if output_file is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"output/{accession}_genomic_{timestamp}.wav"
        
        # Process sequence to audio
        return self.process_sequence(
            sequence,
            carrier_music_file,
            output_file,
            metadata={'source': 'GenBank', 'accession': accession, 'header': header}
        )
    
    def process_sequence(self,
                        sequence: str,
                        carrier_music_file: Optional[str] = None,
                        output_file: Optional[str] = None,
                        metadata: Optional[Dict] = None) -> Dict:
        """
        Process a DNA/RNA sequence directly
        
        Args:
            sequence: DNA or RNA sequence string
            carrier_music_file: Optional music carrier
            output_file: Output file path
            metadata: Optional metadata
            
        Returns:
            Processing results
        """
        # Validate sequence
        if self.config['rna_mode']:
            sequence = self.dna_converter.validate_rna_sequence(sequence)
        else:
            sequence = self.dna_converter.validate_dna_sequence(sequence)
        
        self.current_sequence = sequence
        
        # Create temporary file approach
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tmp:
            tmp.write(sequence)
            tmp_path = tmp.name
        
        try:
            # Process via file pipeline
            result = self.process_file(tmp_path, carrier_music_file, output_file)
            
            # Add metadata
            if metadata:
                result['metadata'] = metadata
            
            return result
        finally:
            # Clean up temp file
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
    
    def process_protein(self,
                       protein_sequence: str,
                       carrier_music_file: Optional[str] = None,
                       output_file: Optional[str] = None) -> Dict:
        """
        Process a protein sequence
        
        Args:
            protein_sequence: Protein sequence (amino acids)
            carrier_music_file: Optional music carrier
            output_file: Output file path
            
        Returns:
            Processing results
        """
        self.log_step("Converting protein to DNA")
        
        # Reverse translate protein to DNA
        dna_sequence = self.bioinformatics.reverse_translate_protein(
            protein_sequence,
            prefer_common_codons=True
        )
        
        # Process DNA sequence
        return self.process_sequence(
            dna_sequence,
            carrier_music_file,
            output_file,
            metadata={'source': 'protein', 'original_length': len(protein_sequence)}
        )
    
    def log_step(self, message: str, data: Optional[Dict] = None):
        """
        Log a processing step
        
        Args:
            message: Log message
            data: Optional data dictionary
        """
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'message': message,
            'data': data or {}
        }
        self.processing_log.append(log_entry)
        
        # Also print for visibility
        if data:
            print(f"[{log_entry['timestamp']}] {message}: {data}")
        else:
            print(f"[{log_entry['timestamp']}] {message}")
    
    def save_processing_log(self, filepath: str):
        """
        Save processing log to JSON file
        
        Args:
            filepath: Output file path
        """
        with open(filepath, 'w') as f:
            json.dump(self.processing_log, f, indent=2)
    
    def get_configuration(self) -> Dict:
        """Get current pipeline configuration"""
        return self.config.copy()
    
    def update_configuration(self, updates: Dict):
        """Update pipeline configuration"""
        self.config.update(updates)
        
        # Reinitialize components if needed
        if 'sample_rate' in updates or 'bit_depth' in updates:
            self.audio_pipeline = AudioPipeline(
                self.config['sample_rate'],
                self.config['bit_depth']
            )
            self.modulation = ModulationProcessor(self.config['sample_rate'])
            self.music_processor = MusicProcessor(self.config['sample_rate'])

"""
Multi-Targeting Audio Genomics Pipeline
Integrates CRISPR-Cas multiplexing with audio generation for massive payloads
"""

import os
import json
import numpy as np
from typing import Dict, List, Optional, Tuple, Set
from datetime import datetime
from dataclasses import dataclass, field
import concurrent.futures

from .main_pipeline import AudioGenomicsPipeline
from .batch_processor import BatchProcessor
from .multi_targeting_crispr import (
    SuperhumanDragonDesigner,
    MultiplexPayload,
    gRNADesign,
    BodySystem,
    VCFParser
)


@dataclass
class CompartmentalizedChunk:
    """Represents a compartmentalized processing chunk"""
    chunk_id: int
    dna_sequence: str
    body_systems: Set[BodySystem]
    targets: List[gRNADesign]
    start_position: int
    end_position: int
    audio_file: Optional[str] = None
    processing_status: str = "pending"


@dataclass
class MultiTargetingResult:
    """Result of multi-targeting processing"""
    success: bool
    total_chunks: int
    processed_chunks: int
    body_systems_targeted: Set[BodySystem]
    total_targets: int
    output_files: List[str]
    combined_audio_file: Optional[str] = None
    processing_time: float = 0.0
    error_message: Optional[str] = None


class MultiTargetingAudioPipeline:
    """
    Advanced pipeline for multi-targeting CRISPR-Cas audio genomics
    Handles massive payloads with compartmentalized chunk processing
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize multi-targeting pipeline
        
        Args:
            config: Configuration dictionary
        """
        self.config = config or {}
        self.base_pipeline = AudioGenomicsPipeline(self.config)
        self.batch_processor = BatchProcessor(self.config, max_workers=4)
        self.dragon_designer = SuperhumanDragonDesigner()
        
        # Processing state
        self.current_payload: Optional[MultiplexPayload] = None
        self.chunks: List[CompartmentalizedChunk] = []
        self.processing_log = []
    
    def design_and_process_payload(self,
                                   include_all_systems: bool = True,
                                   include_dragon_enhancements: bool = True,
                                   include_hermaphroditic: bool = True,
                                   output_directory: str = "/Users/36n9/Downloads/multi_targeting_output",
                                   carrier_music_file: Optional[str] = None,
                                   chunk_size: int = 10000) -> MultiTargetingResult:
        """
        Design payload and process it through audio genomics pipeline
        
        Args:
            include_all_systems: Include all standard body systems
            include_dragon_enhancements: Include dragon-specific enhancements
            include_hermaphroditic: Include hermaphroditic reproductive capabilities
            output_directory: Output directory for audio files
            carrier_music_file: Optional carrier music file
            chunk_size: Size of each compartmentalized chunk
            
        Returns:
            Processing result
        """
        start_time = datetime.now()
        
        self.log_step("Starting multi-targeting payload design and processing")
        
        # Create output directory
        os.makedirs(output_directory, exist_ok=True)
        
        try:
            # Step 1: Design comprehensive payload
            self.log_step("Designing comprehensive payload")
            self.current_payload = self.dragon_designer.design_comprehensive_payload(
                include_all_systems=include_all_systems,
                include_dragon_enhancements=include_dragon_enhancements,
                include_hermaphroditic=include_hermaphroditic
            )
            
            self.log_step("Payload designed", {
                "total_targets": self.current_payload.total_targets,
                "body_systems": len(self.current_payload.body_systems)
            })
            
            # Step 2: Generate compartmentalized chunks
            self.log_step("Generating compartmentalized chunks")
            self.chunks = self._create_compartmentalized_chunks(
                self.current_payload,
                chunk_size=chunk_size
            )
            
            self.log_step("Chunks created", {
                "total_chunks": len(self.chunks),
                "chunk_size": chunk_size
            })
            
            # Step 3: Process each chunk
            self.log_step("Processing chunks through audio genomics pipeline")
            processed_chunks = self._process_chunks(
                output_directory,
                carrier_music_file
            )
            
            # Step 4: Combine audio files
            self.log_step("Combining audio files")
            combined_file = self._combine_audio_files(
                processed_chunks,
                output_directory
            )
            
            # Calculate processing time
            processing_time = (datetime.now() - start_time).total_seconds()
            
            # Create result
            result = MultiTargetingResult(
                success=True,
                total_chunks=len(self.chunks),
                processed_chunks=len(processed_chunks),
                body_systems_targeted=self.current_payload.body_systems,
                total_targets=self.current_payload.total_targets,
                output_files=[c.audio_file for c in processed_chunks if c.audio_file],
                combined_audio_file=combined_file,
                processing_time=processing_time
            )
            
            self.log_step("Processing complete", {
                "success": True,
                "processing_time": processing_time,
                "combined_file": combined_file
            })
            
            # Save payload metadata
            self._save_payload_metadata(output_directory)
            
            return result
            
        except Exception as e:
            processing_time = (datetime.now() - start_time).total_seconds()
            
            result = MultiTargetingResult(
                success=False,
                total_chunks=len(self.chunks),
                processed_chunks=0,
                body_systems_targeted=set(),
                total_targets=0,
                output_files=[],
                processing_time=processing_time,
                error_message=str(e)
            )
            
            self.log_step("Processing failed", {"error": str(e)})
            return result
    
    def _create_compartmentalized_chunks(self,
                                        payload: MultiplexPayload,
                                        chunk_size: int = 10000) -> List[CompartmentalizedChunk]:
        """
        Create compartmentalized chunks from payload
        
        Args:
            payload: Multiplex payload
            chunk_size: Size of each chunk in bases
            
        Returns:
            List of compartmentalized chunks
        """
        chunks = []
        
        # Generate compartmentalized DNA chunks
        dna_chunks = payload.generate_compartmentalized_chunks(chunk_size)
        
        # Create chunk objects with metadata
        for i, dna_chunk in enumerate(dna_chunks):
            # Determine which targets are in this chunk
            chunk_targets = self._get_targets_in_chunk(payload, i, chunk_size)
            chunk_body_systems = set(t.body_system for t in chunk_targets)
            
            chunk = CompartmentalizedChunk(
                chunk_id=i,
                dna_sequence=dna_chunk,
                body_systems=chunk_body_systems,
                targets=chunk_targets,
                start_position=i * chunk_size,
                end_position=min((i + 1) * chunk_size, len("".join(dna_chunks)))
            )
            
            chunks.append(chunk)
        
        return chunks
    
    def _get_targets_in_chunk(self,
                             payload: MultiplexPayload,
                             chunk_index: int,
                             chunk_size: int) -> List[gRNADesign]:
        """
        Get targets that fall within a specific chunk
        
        Args:
            payload: Multiplex payload
            chunk_index: Index of the chunk
            chunk_size: Size of each chunk
            
        Returns:
            List of gRNA targets in the chunk
        """
        # Calculate position range
        start_pos = chunk_index * chunk_size
        end_pos = (chunk_index + 1) * chunk_size
        
        # Find targets in this range
        targets_in_chunk = []
        current_pos = 0
        
        for target in payload.targets:
            # Each target has a separator (10 bases) + guide sequence (20 bases)
            target_size = len(target.separator_sequence) + len(target.guide_sequence)
            
            if start_pos <= current_pos < end_pos:
                targets_in_chunk.append(target)
            
            current_pos += target_size
        
        return targets_in_chunk
    
    def _process_chunks(self,
                       output_directory: str,
                       carrier_music_file: Optional[str] = None) -> List[CompartmentalizedChunk]:
        """
        Process all chunks through audio genomics pipeline
        
        Args:
            output_directory: Output directory
            carrier_music_file: Optional carrier music
            
        Returns:
            List of processed chunks
        """
        processed_chunks = []
        
        for chunk in self.chunks:
            self.log_step(f"Processing chunk {chunk.chunk_id + 1}/{len(self.chunks)}", {
                "body_systems": [s.value for s in chunk.body_systems],
                "sequence_length": len(chunk.dna_sequence)
            })
            
            try:
                # Create temporary file for chunk
                import tempfile
                with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tmp:
                    tmp.write(chunk.dna_sequence)
                    tmp_path = tmp.name
                
                # Generate output filename (use short format to avoid filename length limits)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_file = os.path.join(
                    output_directory,
                    f"chunk_{chunk.chunk_id:04d}_{timestamp}.wav"
                )
                
                # Process chunk through base pipeline
                result = self.base_pipeline.process_sequence(
                    chunk.dna_sequence,
                    carrier_music_file,
                    output_file,
                    metadata={
                        'chunk_id': chunk.chunk_id,
                        'body_systems': [s.value for s in chunk.body_systems],
                        'targets': [t.target_gene.gene_name for t in chunk.targets]
                    }
                )
                
                # Clean up temp file
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
                
                if result.get('success'):
                    chunk.audio_file = result.get('output_file')
                    chunk.processing_status = "completed"
                    processed_chunks.append(chunk)
                else:
                    chunk.processing_status = "failed"
                    self.log_step(f"Chunk {chunk.chunk_id} failed", {
                        "error": result.get('error')
                    })
                
            except Exception as e:
                chunk.processing_status = "error"
                self.log_step(f"Chunk {chunk.chunk_id} error", {"error": str(e)})
        
        return processed_chunks
    
    def _combine_audio_files(self,
                            chunks: List[CompartmentalizedChunk],
                            output_directory: str,
                            crossfade_duration: float = 0.5) -> Optional[str]:
        """
        Combine all chunk audio files into single output
        
        Args:
            chunks: List of processed chunks
            output_directory: Output directory
            crossfade_duration: Crossfade duration in seconds
            
        Returns:
            Path to combined audio file
        """
        if not chunks:
            return None
        
        # Get all audio files
        audio_files = [c.audio_file for c in chunks if c.audio_file and os.path.exists(c.audio_file)]
        
        if not audio_files:
            return None
        
        # Generate output filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        combined_file = os.path.join(
            output_directory,
            f"superhuman_dragon_complete_{timestamp}.wav"
        )
        
        # Use batch processor to merge files
        merge_result = self.batch_processor.merge_audio_files(
            audio_files,
            combined_file,
            crossfade_duration=crossfade_duration
        )
        
        if merge_result.get('success'):
            self.log_step("Audio files combined", {
                "output_file": combined_file,
                "num_files": len(audio_files)
            })
            return combined_file
        else:
            self.log_step("Audio combination failed", {
                "error": merge_result.get('error')
            })
            return None
    
    def process_vcf_data(self,
                        vcf_file: str,
                        output_directory: str,
                        carrier_music_file: Optional[str] = None,
                        chunk_size: int = 10000) -> MultiTargetingResult:
        """
        Process VCF data and generate targeting audio
        
        Args:
            vcf_file: Path to VCF file
            output_directory: Output directory
            carrier_music_file: Optional carrier music
            chunk_size: Chunk size
            
        Returns:
            Processing result
        """
        start_time = datetime.now()
        
        self.log_step("Processing VCF data", {"file": vcf_file})
        
        os.makedirs(output_directory, exist_ok=True)
        
        try:
            # Parse VCF
            parser = VCFParser(vcf_file)
            
            self.log_step("VCF parsed", {
                "variants_found": len(parser.variants)
            })
            
            # Extract target sequences
            target_sequences = parser.extract_target_sequences(window_size=100)
            
            # Create payload from VCF variants
            payload = MultiplexPayload(
                name=f"VCF_Derived_{os.path.basename(vcf_file)}",
                organism="human",
                cas_protein="CasΦ"
            )
            
            # Add targets from variants
            for i, seq in enumerate(target_sequences):
                # Create mock gene target
                gene_target = type('obj', (object,), {
                    'gene_name': f"VCF_VARIANT_{i}",
                    'chromosome': parser.variants[i]['chromosome'] if i < len(parser.variants) else "chr1",
                    'position': parser.variants[i]['position'] if i < len(parser.variants) else 0,
                    'strand': '+',
                    'target_sequence': seq,
                    'pam_sequence': "AGG",
                    'body_systems': [BodySystem.NERVOUS],  # Default system
                    'function': "variant_modification",
                    'enhancement_type': "modify",
                    'priority': 3
                })()
                
                grna = self.dragon_designer._design_grna(gene_target, BodySystem.NERVOUS)
                payload.add_target(grna)
            
            self.current_payload = payload
            
            # Generate chunks
            self.chunks = self._create_compartmentalized_chunks(payload, chunk_size)
            
            # Process chunks
            processed_chunks = self._process_chunks(output_directory, carrier_music_file)
            
            # Combine audio
            combined_file = self._combine_audio_files(processed_chunks, output_directory)
            
            processing_time = (datetime.now() - start_time).total_seconds()
            
            result = MultiTargetingResult(
                success=True,
                total_chunks=len(self.chunks),
                processed_chunks=len(processed_chunks),
                body_systems_targeted=payload.body_systems,
                total_targets=payload.total_targets,
                output_files=[c.audio_file for c in processed_chunks if c.audio_file],
                combined_audio_file=combined_file,
                processing_time=processing_time
            )
            
            self.log_step("VCF processing complete", {
                "success": True,
                "processing_time": processing_time
            })
            
            return result
            
        except Exception as e:
            processing_time = (datetime.now() - start_time).total_seconds()
            
            result = MultiTargetingResult(
                success=False,
                total_chunks=0,
                processed_chunks=0,
                body_systems_targeted=set(),
                total_targets=0,
                output_files=[],
                processing_time=processing_time,
                error_message=str(e)
            )
            
            self.log_step("VCF processing failed", {"error": str(e)})
            return result
    
    def log_step(self, message: str, data: Optional[Dict] = None):
        """
        Log a processing step
        
        Args:
            message: Log message
            data: Optional data dictionary
        """
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'message': message,
            'data': data or {}
        }
        self.processing_log.append(log_entry)
        
        # Print for visibility
        if data:
            print(f"[{log_entry['timestamp']}] {message}: {data}")
        else:
            print(f"[{log_entry['timestamp']}] {message}")
    
    def _save_payload_metadata(self, output_directory: str):
        """Save payload metadata to JSON file"""
        if not self.current_payload:
            return
        
        metadata = {
            'timestamp': datetime.now().isoformat(),
            'payload_name': self.current_payload.name,
            'organism': self.current_payload.organism,
            'cas_protein': self.current_payload.cas_protein,
            'total_targets': self.current_payload.total_targets,
            'body_systems': [s.value for s in self.current_payload.body_systems],
            'total_chunks': len(self.chunks),
            'chunks': [
                {
                    'chunk_id': c.chunk_id,
                    'body_systems': [s.value for s in c.body_systems],
                    'sequence_length': len(c.dna_sequence),
                    'num_targets': len(c.targets),
                    'processing_status': c.processing_status,
                    'audio_file': c.audio_file
                }
                for c in self.chunks
            ],
            'processing_log': self.processing_log
        }
        
        output_file = os.path.join(output_directory, "payload_metadata.json")
        with open(output_file, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        print(f"📄 Payload metadata saved to: {output_file}")
    
    def save_processing_log(self, filepath: str):
        """Save processing log to JSON file"""
        with open(filepath, 'w') as f:
            json.dump(self.processing_log, f, indent=2)


def main():
    """Main function to demonstrate multi-targeting pipeline"""
    print("🧬🐉 Multi-Targeting Audio Genomics Pipeline 🐉🧬")
    print("=" * 60)
    
    # Initialize pipeline
    config = {
        'sample_rate': 192000,
        'bit_depth': 32,
        'base_cycles': 4,
        'fm_carrier_freq': 528.0,
        'am_modulation_depth': 0.05,
        'retune_to_432': True,
        'normalize_output': True
    }
    
    pipeline = MultiTargetingAudioPipeline(config)
    
    # Design and process comprehensive payload
    print("\n🎯 Processing comprehensive superhuman dragon payload...")
    result = pipeline.design_and_process_payload(
        include_all_systems=True,
        include_dragon_enhancements=True,
        include_hermaphroditic=True,
        output_directory="/Users/36n9/Downloads/multi_targeting_output",
        carrier_music_file=None,  # Can add carrier music if available
        chunk_size=10000
    )
    
    if result.success:
        print("\n✅ SUCCESS! Multi-targeting processing complete:")
        print(f"   Total chunks: {result.total_chunks}")
        print(f"   Processed chunks: {result.processed_chunks}")
        print(f"   Body systems: {len(result.body_systems_targeted)}")
        print(f"   Total targets: {result.total_targets}")
        print(f"   Processing time: {result.processing_time:.2f} seconds")
        print(f"   Output files: {len(result.output_files)}")
        if result.combined_audio_file:
            print(f"   Combined audio: {result.combined_audio_file}")
    else:
        print(f"\n❌ Processing failed: {result.error_message}")
    
    # Process VCF data if available
    vcf_file = "/Users/36n9/Downloads/SZJUKNL8VKC.hard-filtered.vcf"
    if os.path.exists(vcf_file):
        print(f"\n📊 Processing VCF data: {vcf_file}")
        vcf_result = pipeline.process_vcf_data(
            vcf_file=vcf_file,
            output_directory="/Users/36n9/Downloads/vcf_output",
            carrier_music_file=None,
            chunk_size=10000
        )
        
        if vcf_result.success:
            print(f"✅ VCF processing complete:")
            print(f"   Total chunks: {vcf_result.total_chunks}")
            print(f"   Processed chunks: {vcf_result.processed_chunks}")
            print(f"   Total targets: {vcf_result.total_targets}")
        else:
            print(f"❌ VCF processing failed: {vcf_result.error_message}")
    
    return result


if __name__ == "__main__":
    import os
    main()

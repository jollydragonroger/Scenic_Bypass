"""
Batch Processing Module
Handles multiple file processing and chromosome-like layering
"""

import os
import json
import glob
import concurrent.futures
from typing import List, Dict, Optional, Callable
from datetime import datetime
import numpy as np

from .main_pipeline import AudioGenomicsPipeline
from .audio_pipeline import AudioPipeline

class BatchProcessor:
    """Handles batch processing of multiple files and sequences"""
    
    def __init__(self, config: Optional[Dict] = None, max_workers: int = 4):
        """
        Initialize batch processor
        
        Args:
            config: Configuration dictionary
            max_workers: Maximum parallel workers
        """
        self.config = config or {}
        self.max_workers = max_workers
        self.processing_results = []
        self.progress_callback = None
        
    def set_progress_callback(self, callback: Callable):
        """
        Set callback for progress updates
        
        Args:
            callback: Function to call with progress updates
        """
        self.progress_callback = callback
    
    def process_directory(self,
                         input_dir: str,
                         output_dir: str,
                         carrier_music_file: Optional[str] = None,
                         file_pattern: str = "*",
                         recursive: bool = False) -> List[Dict]:
        """
        Process all files in a directory
        
        Args:
            input_dir: Input directory path
            output_dir: Output directory path
            carrier_music_file: Optional music carrier for all files
            file_pattern: File pattern to match (e.g., "*.txt")
            recursive: Process subdirectories recursively
            
        Returns:
            List of processing results
        """
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        # Find files
        if recursive:
            pattern = os.path.join(input_dir, "**", file_pattern)
            files = glob.glob(pattern, recursive=True)
        else:
            pattern = os.path.join(input_dir, file_pattern)
            files = glob.glob(pattern)
        
        # Filter out directories
        files = [f for f in files if os.path.isfile(f)]
        
        print(f"Found {len(files)} files to process")
        
        # Process files
        results = []
        for i, input_file in enumerate(files):
            # Update progress
            if self.progress_callback:
                self.progress_callback({
                    'current': i + 1,
                    'total': len(files),
                    'file': input_file,
                    'percent': ((i + 1) / len(files)) * 100
                })
            
            # Generate output filename
            rel_path = os.path.relpath(input_file, input_dir)
            base_name = os.path.splitext(rel_path)[0]
            output_file = os.path.join(output_dir, f"{base_name}_genomic.wav")
            
            # Ensure output subdirectory exists
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            # Process file
            try:
                pipeline = AudioGenomicsPipeline(self.config)
                result = pipeline.process_file(
                    input_file,
                    carrier_music_file,
                    output_file
                )
                results.append(result)
            except Exception as e:
                results.append({
                    'success': False,
                    'input_file': input_file,
                    'error': str(e)
                })
        
        self.processing_results = results
        return results
    
    def process_file_list(self,
                         file_list: List[str],
                         output_dir: str,
                         carrier_music_files: Optional[List[str]] = None) -> List[Dict]:
        """
        Process a list of files
        
        Args:
            file_list: List of input file paths
            output_dir: Output directory
            carrier_music_files: Optional list of carrier files (one per input)
            
        Returns:
            List of processing results
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # Handle carrier music assignment
        if carrier_music_files is None:
            carrier_music_files = [None] * len(file_list)
        elif len(carrier_music_files) == 1:
            # Use same carrier for all files
            carrier_music_files = carrier_music_files * len(file_list)
        elif len(carrier_music_files) != len(file_list):
            raise ValueError("Carrier music list must match file list length")
        
        results = []
        
        for i, (input_file, carrier) in enumerate(zip(file_list, carrier_music_files)):
            # Update progress
            if self.progress_callback:
                self.progress_callback({
                    'current': i + 1,
                    'total': len(file_list),
                    'file': input_file,
                    'percent': ((i + 1) / len(file_list)) * 100
                })
            
            # Generate output filename
            base_name = os.path.splitext(os.path.basename(input_file))[0]
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = os.path.join(output_dir, f"{base_name}_genomic_{timestamp}.wav")
            
            # Process file
            try:
                pipeline = AudioGenomicsPipeline(self.config)
                result = pipeline.process_file(input_file, carrier, output_file)
                results.append(result)
            except Exception as e:
                results.append({
                    'success': False,
                    'input_file': input_file,
                    'error': str(e)
                })
        
        self.processing_results = results
        return results
    
    def process_parallel(self,
                        file_list: List[str],
                        output_dir: str,
                        carrier_music_file: Optional[str] = None) -> List[Dict]:
        """
        Process files in parallel
        
        Args:
            file_list: List of input files
            output_dir: Output directory
            carrier_music_file: Optional carrier for all files
            
        Returns:
            List of processing results
        """
        os.makedirs(output_dir, exist_ok=True)
        
        def process_single_file(args):
            input_file, output_file, carrier = args
            try:
                pipeline = AudioGenomicsPipeline(self.config)
                return pipeline.process_file(input_file, carrier, output_file)
            except Exception as e:
                return {
                    'success': False,
                    'input_file': input_file,
                    'error': str(e)
                }
        
        # Prepare arguments
        args_list = []
        for input_file in file_list:
            base_name = os.path.splitext(os.path.basename(input_file))[0]
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:19]
            output_file = os.path.join(output_dir, f"{base_name}_genomic_{timestamp}.wav")
            args_list.append((input_file, output_file, carrier_music_file))
        
        # Process in parallel
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_file = {
                executor.submit(process_single_file, args): args[0] 
                for args in args_list
            }
            
            completed = 0
            for future in concurrent.futures.as_completed(future_to_file):
                input_file = future_to_file[future]
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    results.append({
                        'success': False,
                        'input_file': input_file,
                        'error': str(e)
                    })
                
                completed += 1
                if self.progress_callback:
                    self.progress_callback({
                        'current': completed,
                        'total': len(file_list),
                        'file': input_file,
                        'percent': (completed / len(file_list)) * 100
                    })
        
        self.processing_results = results
        return results
    
    def create_chromosome_layers(self,
                                sequences: List[str],
                                output_file: str,
                                layer_config: Optional[Dict] = None) -> Dict:
        """
        Create multi-layered audio mimicking chromosome structure
        
        Args:
            sequences: List of DNA sequences for different layers
            output_file: Output file path
            layer_config: Configuration for layers
            
        Returns:
            Processing result
        """
        default_layer_config = {
            'layer_offsets': None,  # Time offsets for each layer
            'layer_volumes': None,   # Volume levels for each layer
            'carrier_frequencies': [528, 639, 741, 852],  # Different carriers
            'fm_indices': [0.1, 0.15, 0.2, 0.25],  # Different modulation
            'sample_rate': 192000,
            'bit_depth': 32
        }
        
        if layer_config:
            default_layer_config.update(layer_config)
        
        try:
            # Create audio pipeline
            audio_pipeline = AudioPipeline(
                default_layer_config['sample_rate'],
                default_layer_config['bit_depth']
            )
            
            # Generate multi-layer audio
            print(f"Creating chromosome structure with {len(sequences)} layers")
            
            multi_layer_audio = audio_pipeline.generate_multilayer_audio(
                sequences,
                layer_offsets=default_layer_config['layer_offsets'],
                layer_volumes=default_layer_config['layer_volumes']
            )
            
            # Save output
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            audio_pipeline.save_audio(multi_layer_audio, output_file)
            
            # Get audio info
            audio_info = audio_pipeline.get_audio_info(multi_layer_audio)
            
            return {
                'success': True,
                'output_file': output_file,
                'num_layers': len(sequences),
                'total_bases': sum(len(seq) for seq in sequences),
                'audio_info': audio_info
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'num_layers': len(sequences)
            }
    
    def split_and_process_large_file(self,
                                    input_file: str,
                                    output_dir: str,
                                    chunk_size: int = 10000,
                                    carrier_music_file: Optional[str] = None) -> Dict:
        """
        Split large file into chunks and process separately
        
        Args:
            input_file: Large input file
            output_dir: Output directory for chunks
            chunk_size: Size of each chunk in bases
            carrier_music_file: Optional carrier
            
        Returns:
            Processing summary
        """
        os.makedirs(output_dir, exist_ok=True)
        
        try:
            # Convert file to DNA
            pipeline = AudioGenomicsPipeline(self.config)
            dna_converter = pipeline.dna_converter
            
            # Read and convert file
            full_sequence = dna_converter.file_to_dna(input_file)
            total_length = len(full_sequence)
            
            # Split into chunks
            chunks = []
            for i in range(0, total_length, chunk_size):
                chunk = full_sequence[i:i + chunk_size]
                chunks.append(chunk)
            
            print(f"Split into {len(chunks)} chunks of {chunk_size} bases")
            
            # Process each chunk
            chunk_results = []
            for i, chunk in enumerate(chunks):
                if self.progress_callback:
                    self.progress_callback({
                        'current': i + 1,
                        'total': len(chunks),
                        'chunk': i,
                        'percent': ((i + 1) / len(chunks)) * 100
                    })
                
                # Output file for chunk
                chunk_file = os.path.join(output_dir, f"chunk_{i:04d}.wav")
                
                # Process chunk
                result = pipeline.process_sequence(
                    chunk,
                    carrier_music_file,
                    chunk_file,
                    metadata={'chunk_index': i, 'chunk_size': len(chunk)}
                )
                chunk_results.append(result)
            
            # Combine results
            successful = sum(1 for r in chunk_results if r['success'])
            
            return {
                'success': successful == len(chunks),
                'input_file': input_file,
                'total_chunks': len(chunks),
                'successful_chunks': successful,
                'chunk_size': chunk_size,
                'total_bases': total_length,
                'output_directory': output_dir,
                'chunk_results': chunk_results
            }
            
        except Exception as e:
            return {
                'success': False,
                'input_file': input_file,
                'error': str(e)
            }
    
    def merge_audio_files(self,
                         audio_files: List[str],
                         output_file: str,
                         crossfade_duration: float = 0.1) -> Dict:
        """
        Merge multiple audio files into one
        
        Args:
            audio_files: List of audio file paths
            output_file: Output file path
            crossfade_duration: Crossfade duration in seconds
            
        Returns:
            Merge result
        """
        try:
            # Load all audio files
            audio_segments = []
            sample_rate = None
            
            music_processor = AudioGenomicsPipeline(self.config).music_processor
            
            for file_path in audio_files:
                audio, rate = music_processor.load_audio_file(file_path)
                
                if sample_rate is None:
                    sample_rate = rate
                elif rate != sample_rate:
                    # Resample to match first file
                    audio = music_processor.resample_audio(audio, rate, sample_rate)
                
                audio_segments.append(audio)
            
            # Merge with crossfade
            if len(audio_segments) == 0:
                raise ValueError("No audio files to merge")
            elif len(audio_segments) == 1:
                merged = audio_segments[0]
            else:
                crossfade_samples = int(crossfade_duration * sample_rate)
                merged = audio_segments[0]
                
                for next_segment in audio_segments[1:]:
                    if crossfade_samples > 0 and len(merged) > crossfade_samples:
                        # Create crossfade
                        fade_out = np.linspace(1, 0, crossfade_samples)
                        fade_in = np.linspace(0, 1, crossfade_samples)
                        
                        # Apply fades
                        merged[-crossfade_samples:] *= fade_out
                        next_segment[:crossfade_samples] *= fade_in
                        
                        # Overlap and concatenate
                        overlap = merged[-crossfade_samples:] + next_segment[:crossfade_samples]
                        merged = np.concatenate([
                            merged[:-crossfade_samples],
                            overlap,
                            next_segment[crossfade_samples:]
                        ])
                    else:
                        # Simple concatenation
                        merged = np.concatenate([merged, next_segment])
            
            # Save merged audio
            audio_pipeline = AudioPipeline(sample_rate, 32)
            audio_pipeline.save_audio(merged, output_file)
            
            return {
                'success': True,
                'output_file': output_file,
                'num_files': len(audio_files),
                'duration_seconds': len(merged) / sample_rate
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def generate_batch_report(self, output_file: str):
        """
        Generate report of batch processing results
        
        Args:
            output_file: Report file path (JSON or TXT)
        """
        report = {
            'timestamp': datetime.now().isoformat(),
            'total_files': len(self.processing_results),
            'successful': sum(1 for r in self.processing_results if r.get('success')),
            'failed': sum(1 for r in self.processing_results if not r.get('success')),
            'results': self.processing_results
        }
        
        if output_file.endswith('.json'):
            with open(output_file, 'w') as f:
                json.dump(report, f, indent=2)
        else:
            # Text report
            with open(output_file, 'w') as f:
                f.write(f"Batch Processing Report\n")
                f.write(f"=" * 50 + "\n")
                f.write(f"Generated: {report['timestamp']}\n")
                f.write(f"Total Files: {report['total_files']}\n")
                f.write(f"Successful: {report['successful']}\n")
                f.write(f"Failed: {report['failed']}\n")
                f.write("\n" + "=" * 50 + "\n")
                
                for result in self.processing_results:
                    f.write(f"\nFile: {result.get('input_file', 'Unknown')}\n")
                    f.write(f"Status: {'Success' if result.get('success') else 'Failed'}\n")
                    if result.get('error'):
                        f.write(f"Error: {result['error']}\n")
                    if result.get('output_file'):
                        f.write(f"Output: {result['output_file']}\n")

"""
Text to DNA/RNA Encoder
Supports Hebrew/Gematria encoding and inverted RNA mapping
"""

import re
from typing import Dict, List, Optional

class TextEncoder:
    """Encode text to DNA/RNA sequences"""
    
    def __init__(self):
        """Initialize encoder with mapping tables"""
        
        # Hebrew to Gematria values
        self.hebrew_gematria = {
            'א': 1, 'ב': 2, 'ג': 3, 'ד': 4, 'ה': 5, 'ו': 6, 'ז': 7, 'ח': 8,
            'ט': 9, 'י': 10, 'כ': 20, 'ך': 20, 'ל': 30, 'מ': 40, 'ם': 40,
            'נ': 50, 'ן': 50, 'ס': 60, 'ע': 70, 'פ': 80, 'ף': 80, 'צ': 90,
            'ץ': 90, 'ק': 100, 'ר': 200, 'ש': 300, 'ת': 400
        }
        
        # ASCII to codon mapping (optimized for common letters)
        self.ascii_to_codon = self._create_ascii_codon_mapping()
        
        # Binary to base mapping
        self.binary_to_base = {
            '00': 'A',
            '01': 'T',
            '10': 'C',
            '11': 'G'
        }
        
        # RNA inverted mapping (complement)
        self.rna_inverted = {
            'A': 'U',
            'U': 'A',
            'C': 'G',
            'G': 'C'
        }
        
    def _create_ascii_codon_mapping(self) -> Dict[str, str]:
        """Create ASCII to codon mapping"""
        # Use genetic code-inspired mapping
        mapping = {}
        
        # Common letters get shorter sequences
        common_letters = 'ETAOINSHRDLCUMWFGYPBVKJXQZ'
        codons = []
        
        # Generate all possible codons
        bases = ['A', 'T', 'C', 'G']
        for b1 in bases:
            for b2 in bases:
                for b3 in bases:
                    codons.append(b1 + b2 + b3)
        
        # Map common letters first
        for i, letter in enumerate(common_letters.lower()):
            if i < len(codons):
                mapping[letter] = codons[i]
                
        for i, letter in enumerate(common_letters.upper()):
            if i + 26 < len(codons):
                mapping[letter] = codons[i + 26]
        
        # Numbers
        for i in range(10):
            if i + 52 < len(codons):
                mapping[str(i)] = codons[i + 52]
        
        # Special characters
        special_chars = ' .,;:!?"\'()-'
        for i, char in enumerate(special_chars):
            if i + 62 < len(codons):
                mapping[char] = codons[i + 62]
        
        return mapping
    
    def text_to_dna(self, text: str, use_hebrew: bool = False) -> str:
        """
        Convert text to DNA sequence
        
        Args:
            text: Input text
            use_hebrew: Use Hebrew/Gematria encoding
            
        Returns:
            DNA sequence
        """
        dna_sequence = []
        
        if use_hebrew:
            # Hebrew/Gematria encoding
            for char in text:
                if char in self.hebrew_gematria:
                    value = self.hebrew_gematria[char]
                    # Convert gematria value to DNA
                    dna = self._gematria_to_dna(value)
                    dna_sequence.append(dna)
                elif char in self.ascii_to_codon:
                    dna_sequence.append(self.ascii_to_codon[char])
                else:
                    # Skip unknown characters
                    continue
        else:
            # Standard ASCII encoding
            for char in text:
                if char in self.ascii_to_codon:
                    dna_sequence.append(self.ascii_to_codon[char])
                else:
                    # Use binary encoding for unknown characters
                    binary = format(ord(char) % 256, '08b')
                    for i in range(0, 8, 2):
                        dna_sequence.append(self.binary_to_base[binary[i:i+2]])
        
        return ''.join(dna_sequence)
    
    def _gematria_to_dna(self, value: int) -> str:
        """
        Convert gematria value to DNA sequence
        
        Args:
            value: Gematria value
            
        Returns:
            DNA sequence
        """
        # Map value to DNA using base-4 system
        if value == 0:
            return 'A'
        
        bases = []
        base_map = {0: 'A', 1: 'T', 2: 'C', 3: 'G'}
        
        while value > 0:
            remainder = value % 4
            bases.append(base_map[remainder])
            value //= 4
        
        return ''.join(reversed(bases))
    
    def dna_to_text(self, dna: str, use_hebrew: bool = False) -> str:
        """
        Convert DNA sequence back to text
        
        Args:
            dna: DNA sequence
            use_hebrew: Use Hebrew/Gematria decoding
            
        Returns:
            Decoded text
        """
        # Create reverse mapping
        codon_to_ascii = {v: k for k, v in self.ascii_to_codon.items()}
        
        text = []
        i = 0
        
        while i < len(dna):
            # Try 3-base codon
            if i + 3 <= len(dna):
                codon = dna[i:i+3]
                if codon in codon_to_ascii:
                    text.append(codon_to_ascii[codon])
                    i += 3
                    continue
            
            # Try binary decoding (4 bases = 1 character)
            if i + 4 <= len(dna):
                binary = ''
                for j in range(4):
                    base = dna[i+j]
                    for bits, b in self.binary_to_base.items():
                        if b == base:
                            binary += bits
                            break
                
                if len(binary) == 8:
                    text.append(chr(int(binary, 2)))
                    i += 4
                    continue
            
            # Skip unrecognized base
            i += 1
        
        return ''.join(text)
    
    def binary_to_dna(self, binary_data: bytes) -> str:
        """
        Convert binary data to DNA sequence
        
        Args:
            binary_data: Binary data
            
        Returns:
            DNA sequence
        """
        dna = []
        
        for byte in binary_data:
            binary_str = format(byte, '08b')
            for i in range(0, 8, 2):
                dna.append(self.binary_to_base[binary_str[i:i+2]])
        
        return ''.join(dna)
    
    def dna_to_binary(self, dna: str) -> bytes:
        """
        Convert DNA sequence to binary data
        
        Args:
            dna: DNA sequence
            
        Returns:
            Binary data
        """
        binary_data = []
        base_to_binary = {v: k for k, v in self.binary_to_base.items()}
        
        i = 0
        while i + 4 <= len(dna):
            byte_str = ''
            for j in range(4):
                base = dna[i+j]
                if base in base_to_binary:
                    byte_str += base_to_binary[base]
                else:
                    byte_str += '00'  # Default for unknown
            
            if len(byte_str) == 8:
                binary_data.append(int(byte_str, 2))
            
            i += 4
        
        return bytes(binary_data)
    
    def apply_rna_inversion(self, sequence: str) -> str:
        """
        Apply RNA inverted mapping (complement)
        
        Args:
            sequence: DNA/RNA sequence
            
        Returns:
            Inverted RNA sequence
        """
        inverted = []
        
        for base in sequence.upper():
            if base in self.rna_inverted:
                inverted.append(self.rna_inverted[base])
            else:
                inverted.append(base)  # Keep unknown bases
        
        return ''.join(inverted)
    
    def encode_message(self, 
                      message: str, 
                      encoding_type: str = 'ascii',
                      apply_inversion: bool = False) -> Dict:
        """
        Encode message to DNA/RNA with specified encoding
        
        Args:
            message: Message to encode
            encoding_type: 'ascii', 'hebrew', or 'binary'
            apply_inversion: Apply RNA inversion
            
        Returns:
            Encoding results
        """
        result = {
            'original': message,
            'encoding_type': encoding_type,
            'sequence': '',
            'inverted': None,
            'length': 0
        }
        
        # Encode based on type
        if encoding_type == 'hebrew':
            result['sequence'] = self.text_to_dna(message, use_hebrew=True)
        elif encoding_type == 'binary':
            binary_data = message.encode('utf-8')
            result['sequence'] = self.binary_to_dna(binary_data)
        else:  # ascii
            result['sequence'] = self.text_to_dna(message, use_hebrew=False)
        
        result['length'] = len(result['sequence'])
        
        # Apply inversion if requested
        if apply_inversion:
            result['inverted'] = self.apply_rna_inversion(result['sequence'])
        
        return result
    
    def decode_message(self,
                      sequence: str,
                      encoding_type: str = 'ascii',
                      from_inverted: bool = False) -> str:
        """
        Decode DNA/RNA sequence to message
        
        Args:
            sequence: DNA/RNA sequence
            encoding_type: 'ascii', 'hebrew', or 'binary'
            from_inverted: Sequence is inverted RNA
            
        Returns:
            Decoded message
        """
        # Reverse inversion if needed
        if from_inverted:
            sequence = self.apply_rna_inversion(sequence)
        
        # Decode based on type
        if encoding_type == 'binary':
            binary_data = self.dna_to_binary(sequence)
            return binary_data.decode('utf-8', errors='ignore')
        else:
            return self.dna_to_text(sequence, use_hebrew=(encoding_type == 'hebrew'))

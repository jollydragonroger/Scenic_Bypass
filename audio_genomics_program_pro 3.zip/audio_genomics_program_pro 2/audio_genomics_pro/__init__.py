"""
Audio Genomics Pro
Advanced DNA/RNA to Audio Synthesis with Chromatin-like Folding Compression
"""

__version__ = "4.0.0"
__author__ = "Audio Genomics Research"

from .core.main_pipeline import AudioGenomicsPipeline
from .core.dna_folding import DNAFoldingCompressor
from .core.nucleotide_frequencies import NucleotideFrequencyMapper

__all__ = [
    'AudioGenomicsPipeline',
    'DNAFoldingCompressor', 
    'NucleotideFrequencyMapper'
]

"""
Audio Genomics Pro GUI
Main graphical user interface using Tkinter
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading
import queue
import json
import os
from datetime import datetime

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from audio_genomics_pro.core.main_pipeline import AudioGenomicsPipeline
from audio_genomics_pro.core.batch_processor import BatchProcessor

class AudioGenomicsGUI:
    """Main GUI application for Audio Genomics Pro"""
    
    def __init__(self, root):
        """Initialize the GUI"""
        self.root = root
        self.root.title("Audio Genomics Pro - Advanced DNA Audio Synthesis")
        self.root.geometry("1000x700")
        
        # Processing queue
        self.processing_queue = queue.Queue()
        self.is_processing = False
        
        # Default configuration
        self.config = {
            'sample_rate': 192000,
            'bit_depth': 32,
            'base_cycles': 3,
            'separator_cycles': 1,
            'codon_separator_cycles': 3,
            'fm_carrier_freq': 528.0,
            'fm_modulation_index': 0.1,
            'am_modulation_depth': 0.05,
            'retune_to_432': True,
            'use_hebrew_encoding': False,
            'rna_mode': False,
            'normalize_output': True
        }
        
        # File paths
        self.input_files = []
        self.carrier_music_file = None
        self.output_directory = None
        
        # Create interface
        self.create_interface()
        
        # Start queue monitoring
        self.root.after(100, self.check_queue)
        
    def create_interface(self):
        """Create main interface"""
        # Top frame - file selection
        top_frame = ttk.LabelFrame(self.root, text="Input/Output", padding=10)
        top_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Input files
        ttk.Label(top_frame, text="Input Files:").grid(row=0, column=0, sticky=tk.W)
        self.file_listbox = tk.Listbox(top_frame, height=5, width=60)
        self.file_listbox.grid(row=1, column=0, columnspan=3, pady=5)
        
        ttk.Button(top_frame, text="Add Files", command=self.add_files).grid(row=2, column=0, padx=5)
        ttk.Button(top_frame, text="Clear", command=self.clear_files).grid(row=2, column=1, padx=5)
        
        # Carrier music
        ttk.Label(top_frame, text="Carrier Music:").grid(row=3, column=0, sticky=tk.W, pady=(10,0))
        self.carrier_label = ttk.Label(top_frame, text="None selected")
        self.carrier_label.grid(row=4, column=0, columnspan=2, sticky=tk.W)
        ttk.Button(top_frame, text="Select Carrier", command=self.select_carrier).grid(row=4, column=2)
        
        # Output directory
        ttk.Label(top_frame, text="Output Directory:").grid(row=5, column=0, sticky=tk.W, pady=(10,0))
        self.output_label = ttk.Label(top_frame, text="None selected")
        self.output_label.grid(row=6, column=0, columnspan=2, sticky=tk.W)
        ttk.Button(top_frame, text="Select Output", command=self.select_output).grid(row=6, column=2)
        
        # Settings frame
        settings_frame = ttk.LabelFrame(self.root, text="Settings", padding=10)
        settings_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Basic settings
        row = 0
        ttk.Label(settings_frame, text="Sample Rate:").grid(row=row, column=0, sticky=tk.W)
        self.sample_rate_var = tk.IntVar(value=192000)
        ttk.Combobox(settings_frame, textvariable=self.sample_rate_var,
                    values=[44100, 48000, 96000, 192000], width=10).grid(row=row, column=1)
        
        ttk.Label(settings_frame, text="FM Carrier (Hz):").grid(row=row, column=2, sticky=tk.W, padx=(20,0))
        self.fm_carrier_var = tk.DoubleVar(value=528.0)
        ttk.Entry(settings_frame, textvariable=self.fm_carrier_var, width=10).grid(row=row, column=3)
        
        row += 1
        ttk.Label(settings_frame, text="Base Cycles:").grid(row=row, column=0, sticky=tk.W)
        self.base_cycles_var = tk.IntVar(value=3)
        ttk.Spinbox(settings_frame, from_=1, to=10, textvariable=self.base_cycles_var,
                   width=10).grid(row=row, column=1)
        
        ttk.Label(settings_frame, text="AM Depth:").grid(row=row, column=2, sticky=tk.W, padx=(20,0))
        self.am_depth_var = tk.DoubleVar(value=0.05)
        ttk.Scale(settings_frame, from_=0, to=0.2, variable=self.am_depth_var,
                 orient=tk.HORIZONTAL, length=100).grid(row=row, column=3)
        
        row += 1
        self.retune_432_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(settings_frame, text="Retune to 432 Hz",
                       variable=self.retune_432_var).grid(row=row, column=0, columnspan=2)
        
        self.hebrew_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(settings_frame, text="Hebrew Encoding",
                       variable=self.hebrew_var).grid(row=row, column=2, columnspan=2)
        
        # Processing frame
        process_frame = ttk.LabelFrame(self.root, text="Processing", padding=10)
        process_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.process_button = ttk.Button(process_frame, text="Start Processing",
                                        command=self.start_processing)
        self.process_button.pack(side=tk.LEFT, padx=5)
        
        self.stop_button = ttk.Button(process_frame, text="Stop",
                                      command=self.stop_processing, state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=5)
        
        self.progress_bar = ttk.Progressbar(process_frame, length=400)
        self.progress_bar.pack(side=tk.LEFT, padx=20)
        
        self.progress_label = ttk.Label(process_frame, text="Ready")
        self.progress_label.pack(side=tk.LEFT)
        
        # Log frame
        log_frame = ttk.LabelFrame(self.root, text="Log", padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=15, width=80)
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
    def add_files(self):
        """Add input files"""
        files = filedialog.askopenfilenames(title="Select Input Files")
        for file in files:
            if file not in self.input_files:
                self.input_files.append(file)
                self.file_listbox.insert(tk.END, os.path.basename(file))
        self.log(f"Added {len(files)} files")
        
    def clear_files(self):
        """Clear input files"""
        self.file_listbox.delete(0, tk.END)
        self.input_files.clear()
        self.log("Cleared input files")
    
    def select_carrier(self):
        """Select carrier music"""
        file = filedialog.askopenfilename(
            title="Select Carrier Music",
            filetypes=[("Audio Files", "*.wav"), ("All Files", "*.*")]
        )
        if file:
            self.carrier_music_file = file
            self.carrier_label.config(text=os.path.basename(file))
            self.log(f"Selected carrier: {os.path.basename(file)}")
    
    def select_output(self):
        """Select output directory"""
        directory = filedialog.askdirectory(title="Select Output Directory")
        if directory:
            self.output_directory = directory
            self.output_label.config(text=directory)
            self.log(f"Output directory: {directory}")
    
    def start_processing(self):
        """Start processing"""
        if not self.input_files:
            messagebox.showwarning("No Input", "Please add input files")
            return
        if not self.output_directory:
            messagebox.showwarning("No Output", "Please select output directory")
            return
        
        self.process_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        self.is_processing = True
        
        # Update config
        self.config.update({
            'sample_rate': self.sample_rate_var.get(),
            'base_cycles': self.base_cycles_var.get(),
            'fm_carrier_freq': self.fm_carrier_var.get(),
            'am_modulation_depth': self.am_depth_var.get(),
            'retune_to_432': self.retune_432_var.get(),
            'use_hebrew_encoding': self.hebrew_var.get()
        })
        
        # Start processing thread
        thread = threading.Thread(target=self.process_thread)
        thread.daemon = True
        thread.start()
    
    def process_thread(self):
        """Processing thread"""
        try:
            batch = BatchProcessor(self.config)
            
            def progress_callback(info):
                self.processing_queue.put(('progress', info))
            
            batch.set_progress_callback(progress_callback)
            
            results = batch.process_file_list(
                self.input_files,
                self.output_directory,
                [self.carrier_music_file] if self.carrier_music_file else None
            )
            
            success = sum(1 for r in results if r.get('success'))
            self.processing_queue.put(('complete', f"Completed: {success}/{len(results)} successful"))
            
        except Exception as e:
            self.processing_queue.put(('error', str(e)))
    
    def stop_processing(self):
        """Stop processing"""
        self.is_processing = False
        self.process_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.log("Processing stopped")
    
    def check_queue(self):
        """Check message queue"""
        try:
            while True:
                msg_type, data = self.processing_queue.get_nowait()
                
                if msg_type == 'progress':
                    self.progress_bar['value'] = data['percent']
                    self.progress_label.config(text=f"{data['current']}/{data['total']}")
                elif msg_type == 'complete':
                    self.log(data)
                    self.stop_processing()
                    messagebox.showinfo("Complete", data)
                elif msg_type == 'error':
                    self.log(f"Error: {data}")
                    self.stop_processing()
                    messagebox.showerror("Error", data)
        except queue.Empty:
            pass
        
        self.root.after(100, self.check_queue)
    
    def log(self, message):
        """Add to log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)

def main():
    """Run the GUI application"""
    root = tk.Tk()
    app = AudioGenomicsGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()

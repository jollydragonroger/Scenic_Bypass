"""
Audio Genomics Pro - Comprehensive GUI
Full-featured desktop application with all scientific research capabilities
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading
import queue
import json
import os
import sys
from datetime import datetime
from typing import Optional, List, Dict

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from audio_genomics_pro.core.main_pipeline import AudioGenomicsPipeline
from audio_genomics_pro.core.dna_folding import DNAFoldingCompressor, FoldingLevel, ChromatinFoldingEngine
from audio_genomics_pro.core.nucleotide_frequencies import NucleotideFrequencyMapper, MusicalKey, OptimalSpeedCalculator
from audio_genomics_pro.core.bioinformatics import BioinformaticsTools
from audio_genomics_pro.core.multi_targeting_crispr import BodySystem, SuperhumanDragonDesigner


class BodySystemPanel(ttk.LabelFrame):
    """Panel for selecting body systems to target"""
    
    # All body systems organized by category
    BODY_SYSTEMS = {
        "Standard Human Systems": [
            ("Nervous System", "nervous"),
            ("Endocrine System", "endocrine"),
            ("Cardiovascular System", "cardiovascular"),
            ("Respiratory System", "respiratory"),
            ("Digestive System", "digestive"),
            ("Urinary System", "urinary"),
            ("Reproductive System", "reproductive"),
            ("Immune System", "immune"),
            ("Lymphatic System", "lymphatic"),
            ("Muscular System", "muscular"),
            ("Skeletal System", "skeletal"),
            ("Integumentary System", "integumentary"),
            ("Sensory System", "sensory"),
            ("Excretory System", "excretory"),
            ("Circulatory System", "circulatory"),
        ],
        "Enhanced Capabilities": [
            ("Flight Musculature", "flight_musculature"),
            ("Wing Development", "wing_development"),
            ("Scale Formation", "scale_formation"),
            ("Breath Weapon", "breath_weapon"),
            ("Fire Resistance", "fire_resistance"),
            ("Enhanced Vision", "enhanced_vision"),
            ("Super Strength", "super_strength"),
            ("Regeneration", "regeneration"),
            ("Longevity", "longevity"),
            ("Telepathy", "telepathy"),
            ("Energy Manipulation", "energy_manipulation"),
            ("Dimensional Travel", "dimensional_travel"),
            ("Shape Shifting", "shape_shifting"),
        ],
        "Reproductive Enhancements": [
            ("Hermaphroditic", "hermaphroditic"),
            ("Enhanced Fertility", "enhanced_fertility"),
            ("Parthenogenesis", "parthenogenesis"),
        ]
    }
    
    def __init__(self, parent, **kwargs):
        super().__init__(parent, text="Body Systems Targeting", **kwargs)
        self.system_vars = {}
        self._create_widgets()
    
    def _create_widgets(self):
        """Create body system checkboxes"""
        notebook = ttk.Notebook(self)
        notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        for category, systems in self.BODY_SYSTEMS.items():
            frame = ttk.Frame(notebook)
            notebook.add(frame, text=category.split()[0])
            
            canvas = tk.Canvas(frame, height=200)
            scrollbar = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
            scrollable_frame = ttk.Frame(canvas)
            
            scrollable_frame.bind(
                "<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
            )
            
            canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)
            
            for i, (name, key) in enumerate(systems):
                var = tk.BooleanVar(value=False)
                self.system_vars[key] = var
                cb = ttk.Checkbutton(scrollable_frame, text=name, variable=var)
                cb.grid(row=i, column=0, sticky=tk.W, padx=5, pady=2)
            
            canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    def get_selected_systems(self) -> List[str]:
        """Get list of selected body system keys"""
        return [key for key, var in self.system_vars.items() if var.get()]
    
    def select_all(self):
        """Select all systems"""
        for var in self.system_vars.values():
            var.set(True)
    
    def clear_all(self):
        """Clear all selections"""
        for var in self.system_vars.values():
            var.set(False)


class CRISPRPanel(ttk.LabelFrame):
    """Panel for CRISPR targeting options"""
    
    CRISPR_TYPES = [
        ("Cas9 (Standard)", "cas9"),
        ("Cas12a (Cpf1)", "cas12a"),
        ("Cas13 (RNA)", "cas13"),
        ("CasΦ (Phage)", "cas_phi"),
        ("Base Editor (BE)", "base_editor"),
        ("Prime Editor (PE)", "prime_editor"),
        ("CRISPRi (Interference)", "crispri"),
        ("CRISPRa (Activation)", "crispra"),
        ("Cas14", "cas14"),
        ("CasX", "casx"),
        ("CasY", "casy"),
    ]
    
    PAM_SEQUENCES = {
        "cas9": "NGG",
        "cas12a": "TTTV",
        "cas13": "H (RNA)",
        "cas_phi": "TBN",
        "base_editor": "NGG",
        "prime_editor": "NGG",
        "crispri": "NGG",
        "crispra": "NGG",
        "cas14": "T-rich",
        "casx": "TTCN",
        "casy": "TA",
    }
    
    def __init__(self, parent, **kwargs):
        super().__init__(parent, text="CRISPR Settings", **kwargs)
        self._create_widgets()
    
    def _create_widgets(self):
        # Enable/Disable CRISPR
        self.enabled_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(self, text="Enable CRISPR Targeting", 
                       variable=self.enabled_var,
                       command=self._toggle_enabled).grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=5)
        
        # CRISPR Type selection
        ttk.Label(self, text="CRISPR System:").grid(row=1, column=0, sticky=tk.W, padx=5)
        self.crispr_type_var = tk.StringVar(value="cas_phi")
        self.crispr_combo = ttk.Combobox(self, textvariable=self.crispr_type_var,
                                         values=[t[1] for t in self.CRISPR_TYPES],
                                         width=20)
        self.crispr_combo.grid(row=1, column=1, padx=5, pady=2)
        self.crispr_combo.bind("<<ComboboxSelected>>", self._update_pam)
        
        # PAM sequence display
        ttk.Label(self, text="PAM Sequence:").grid(row=2, column=0, sticky=tk.W, padx=5)
        self.pam_label = ttk.Label(self, text="TBN")
        self.pam_label.grid(row=2, column=1, sticky=tk.W, padx=5)
        
        # Custom PAM
        ttk.Label(self, text="Custom PAM:").grid(row=3, column=0, sticky=tk.W, padx=5)
        self.custom_pam_var = tk.StringVar()
        self.custom_pam_entry = ttk.Entry(self, textvariable=self.custom_pam_var, width=15)
        self.custom_pam_entry.grid(row=3, column=1, padx=5, pady=2)
        
        # Guide RNA length
        ttk.Label(self, text="gRNA Length:").grid(row=4, column=0, sticky=tk.W, padx=5)
        self.grna_length_var = tk.IntVar(value=20)
        ttk.Spinbox(self, from_=15, to=30, textvariable=self.grna_length_var,
                   width=10).grid(row=4, column=1, padx=5, pady=2)
        
        # Off-target threshold
        ttk.Label(self, text="Off-target Threshold:").grid(row=5, column=0, sticky=tk.W, padx=5)
        self.offtarget_var = tk.DoubleVar(value=0.8)
        ttk.Scale(self, from_=0.5, to=1.0, variable=self.offtarget_var,
                 orient=tk.HORIZONTAL, length=120).grid(row=5, column=1, padx=5, pady=2)
        
        # Multiplex
        self.multiplex_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(self, text="Enable Multiplexing",
                       variable=self.multiplex_var).grid(row=6, column=0, columnspan=2, sticky=tk.W, pady=5)
    
    def _toggle_enabled(self):
        """Toggle CRISPR settings enabled state"""
        state = tk.NORMAL if self.enabled_var.get() else tk.DISABLED
        self.crispr_combo.configure(state=state)
        self.custom_pam_entry.configure(state=state)
    
    def _update_pam(self, event=None):
        """Update PAM display based on selected CRISPR type"""
        crispr_type = self.crispr_type_var.get()
        pam = self.PAM_SEQUENCES.get(crispr_type, "N/A")
        self.pam_label.configure(text=pam)
    
    def get_settings(self) -> Dict:
        """Get current CRISPR settings"""
        return {
            'enabled': self.enabled_var.get(),
            'crispr_type': self.crispr_type_var.get(),
            'pam_sequence': self.custom_pam_var.get() or self.PAM_SEQUENCES.get(self.crispr_type_var.get()),
            'grna_length': self.grna_length_var.get(),
            'offtarget_threshold': self.offtarget_var.get(),
            'multiplex': self.multiplex_var.get()
        }


class GenBankPanel(ttk.LabelFrame):
    """Panel for GenBank sequence retrieval"""
    
    def __init__(self, parent, bioinformatics: BioinformaticsTools, **kwargs):
        super().__init__(parent, text="GenBank Database", **kwargs)
        self.bioinformatics = bioinformatics
        self.search_results = []
        self._create_widgets()
    
    def _create_widgets(self):
        # Search frame
        search_frame = ttk.Frame(self)
        search_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(search_frame, text="Search:").pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=30)
        self.search_entry.pack(side=tk.LEFT, padx=5)
        self.search_entry.bind("<Return>", lambda e: self._search())
        
        ttk.Button(search_frame, text="Search", command=self._search).pack(side=tk.LEFT)
        
        # Database selection
        self.db_var = tk.StringVar(value="nucleotide")
        ttk.Combobox(search_frame, textvariable=self.db_var,
                    values=["nucleotide", "protein", "gene"],
                    width=12).pack(side=tk.LEFT, padx=5)
        
        # Results list
        self.results_list = tk.Listbox(self, height=6, width=60)
        self.results_list.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.results_list.bind("<<ListboxSelect>>", self._on_select)
        
        # Accession entry
        accession_frame = ttk.Frame(self)
        accession_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(accession_frame, text="Accession #:").pack(side=tk.LEFT)
        self.accession_var = tk.StringVar()
        ttk.Entry(accession_frame, textvariable=self.accession_var, width=20).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(accession_frame, text="Fetch", command=self._fetch).pack(side=tk.LEFT)
        ttk.Button(accession_frame, text="Use Sequence", command=self._use_sequence).pack(side=tk.LEFT, padx=5)
        
        # Status
        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(self, textvariable=self.status_var).pack(anchor=tk.W, padx=5)
        
        # Fetched sequence storage
        self.fetched_sequence = None
    
    def _search(self):
        """Search GenBank"""
        query = self.search_var.get().strip()
        if not query:
            return
        
        self.status_var.set("Searching...")
        self.results_list.delete(0, tk.END)
        
        def do_search():
            try:
                results = self.bioinformatics.search_genbank(
                    query, 
                    database=self.db_var.get(),
                    max_results=20
                )
                self.search_results = results
                
                self.results_list.after(0, self._update_results, results)
            except Exception as e:
                self.status_var.set(f"Error: {str(e)}")
        
        threading.Thread(target=do_search, daemon=True).start()
    
    def _update_results(self, results):
        """Update results list"""
        self.results_list.delete(0, tk.END)
        for r in results:
            display = f"{r.get('accession', 'N/A')} - {r.get('title', 'Unknown')[:50]}"
            self.results_list.insert(tk.END, display)
        self.status_var.set(f"Found {len(results)} results")
    
    def _on_select(self, event):
        """Handle result selection"""
        selection = self.results_list.curselection()
        if selection and self.search_results:
            idx = selection[0]
            result = self.search_results[idx]
            self.accession_var.set(result.get('accession', result.get('id', '')))
    
    def _fetch(self):
        """Fetch sequence by accession"""
        accession = self.accession_var.get().strip()
        if not accession:
            return
        
        self.status_var.set("Fetching sequence...")
        
        def do_fetch():
            try:
                fasta_data = self.bioinformatics.fetch_sequence(
                    accession,
                    database=self.db_var.get()
                )
                
                if fasta_data:
                    sequences = self.bioinformatics.parse_fasta(fasta_data)
                    if sequences:
                        header, seq = sequences[0]
                        self.fetched_sequence = seq
                        self.status_var.set(f"Fetched: {len(seq)} bases")
                    else:
                        self.status_var.set("No sequence found in response")
                else:
                    self.status_var.set("Failed to fetch sequence")
            except Exception as e:
                self.status_var.set(f"Error: {str(e)}")
        
        threading.Thread(target=do_fetch, daemon=True).start()
    
    def _use_sequence(self):
        """Emit event to use fetched sequence"""
        if self.fetched_sequence:
            self.event_generate("<<SequenceFetched>>")
    
    def get_sequence(self) -> Optional[str]:
        """Get the fetched sequence"""
        return self.fetched_sequence


class FrequencyPanel(ttk.LabelFrame):
    """Panel for frequency and audio settings"""
    
    def __init__(self, parent, **kwargs):
        super().__init__(parent, text="Frequency & Audio Settings", **kwargs)
        self._create_widgets()
    
    def _create_widgets(self):
        row = 0
        
        # Tuning
        ttk.Label(self, text="Tuning Reference:").grid(row=row, column=0, sticky=tk.W, padx=5)
        self.tuning_var = tk.DoubleVar(value=432.0)
        tuning_frame = ttk.Frame(self)
        tuning_frame.grid(row=row, column=1, sticky=tk.W)
        ttk.Radiobutton(tuning_frame, text="432 Hz", variable=self.tuning_var, 
                       value=432.0).pack(side=tk.LEFT)
        ttk.Radiobutton(tuning_frame, text="440 Hz", variable=self.tuning_var,
                       value=440.0).pack(side=tk.LEFT)
        
        row += 1
        # Auto-key
        self.auto_key_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(self, text="Auto-scale to Musical Key",
                       variable=self.auto_key_var).grid(row=row, column=0, columnspan=2, sticky=tk.W, padx=5)
        
        row += 1
        # Musical key
        ttk.Label(self, text="Musical Key:").grid(row=row, column=0, sticky=tk.W, padx=5)
        self.key_var = tk.StringVar(value="C")
        ttk.Combobox(self, textvariable=self.key_var,
                    values=["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"],
                    width=10).grid(row=row, column=1, sticky=tk.W, padx=5)
        
        row += 1
        # Sample rate
        ttk.Label(self, text="Sample Rate:").grid(row=row, column=0, sticky=tk.W, padx=5)
        self.sample_rate_var = tk.IntVar(value=192000)
        ttk.Combobox(self, textvariable=self.sample_rate_var,
                    values=[44100, 48000, 96000, 192000],
                    width=10).grid(row=row, column=1, sticky=tk.W, padx=5)
        
        row += 1
        # Bit depth
        ttk.Label(self, text="Bit Depth:").grid(row=row, column=0, sticky=tk.W, padx=5)
        self.bit_depth_var = tk.IntVar(value=32)
        ttk.Combobox(self, textvariable=self.bit_depth_var,
                    values=[16, 24, 32],
                    width=10).grid(row=row, column=1, sticky=tk.W, padx=5)
        
        row += 1
        # Cycles per base
        ttk.Label(self, text="Cycles per Base:").grid(row=row, column=0, sticky=tk.W, padx=5)
        self.cycles_var = tk.IntVar(value=3)
        ttk.Spinbox(self, from_=1, to=20, textvariable=self.cycles_var,
                   width=10).grid(row=row, column=1, sticky=tk.W, padx=5)
        
        row += 1
        # FM carrier
        ttk.Label(self, text="FM Carrier (Hz):").grid(row=row, column=0, sticky=tk.W, padx=5)
        self.fm_carrier_var = tk.DoubleVar(value=528.0)
        ttk.Entry(self, textvariable=self.fm_carrier_var, width=12).grid(row=row, column=1, sticky=tk.W, padx=5)
        
        row += 1
        # AM depth
        ttk.Label(self, text="AM Modulation:").grid(row=row, column=0, sticky=tk.W, padx=5)
        self.am_depth_var = tk.DoubleVar(value=0.05)
        ttk.Scale(self, from_=0, to=0.3, variable=self.am_depth_var,
                 orient=tk.HORIZONTAL, length=120).grid(row=row, column=1, sticky=tk.W, padx=5)
        
        row += 1
        # Normalize
        self.normalize_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(self, text="Normalize Output",
                       variable=self.normalize_var).grid(row=row, column=0, columnspan=2, sticky=tk.W, padx=5)
    
    def get_settings(self) -> Dict:
        """Get current frequency settings"""
        return {
            'tuning': self.tuning_var.get(),
            'auto_key': self.auto_key_var.get(),
            'musical_key': self.key_var.get(),
            'sample_rate': self.sample_rate_var.get(),
            'bit_depth': self.bit_depth_var.get(),
            'cycles_per_base': self.cycles_var.get(),
            'fm_carrier_freq': self.fm_carrier_var.get(),
            'am_modulation_depth': self.am_depth_var.get(),
            'normalize_output': self.normalize_var.get()
        }


class FoldingPanel(ttk.LabelFrame):
    """Panel for DNA folding compression settings"""
    
    def __init__(self, parent, **kwargs):
        super().__init__(parent, text="DNA Folding Compression", **kwargs)
        self._create_widgets()
    
    def _create_widgets(self):
        row = 0
        
        # Enable folding
        self.enabled_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(self, text="Enable Chromatin-like Folding",
                       variable=self.enabled_var).grid(row=row, column=0, columnspan=2, sticky=tk.W, padx=5)
        
        row += 1
        # Folding level
        ttk.Label(self, text="Folding Level:").grid(row=row, column=0, sticky=tk.W, padx=5)
        self.level_var = tk.StringVar(value="SINGLE_FOLD")
        levels = ["LINEAR", "SINGLE_FOLD", "DOUBLE_FOLD", "NUCLEOSOME", "CHROMATIN", "CHROMOSOME"]
        ttk.Combobox(self, textvariable=self.level_var,
                    values=levels, width=15).grid(row=row, column=1, sticky=tk.W, padx=5)
        
        row += 1
        # Auto-optimize
        self.auto_optimize_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(self, text="Auto-optimize for Target Duration",
                       variable=self.auto_optimize_var).grid(row=row, column=0, columnspan=2, sticky=tk.W, padx=5)
        
        row += 1
        # Target duration
        ttk.Label(self, text="Target Duration (sec):").grid(row=row, column=0, sticky=tk.W, padx=5)
        self.duration_var = tk.DoubleVar(value=300.0)
        ttk.Entry(self, textvariable=self.duration_var, width=12).grid(row=row, column=1, sticky=tk.W, padx=5)
        
        row += 1
        # Parallel processing
        self.parallel_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(self, text="Use Parallel Processing",
                       variable=self.parallel_var).grid(row=row, column=0, columnspan=2, sticky=tk.W, padx=5)
        
        row += 1
        # Chunk size
        ttk.Label(self, text="Chunk Size (bases):").grid(row=row, column=0, sticky=tk.W, padx=5)
        self.chunk_size_var = tk.IntVar(value=100000)
        ttk.Entry(self, textvariable=self.chunk_size_var, width=12).grid(row=row, column=1, sticky=tk.W, padx=5)
    
    def get_settings(self) -> Dict:
        """Get current folding settings"""
        return {
            'enabled': self.enabled_var.get(),
            'folding_level': self.level_var.get(),
            'auto_optimize': self.auto_optimize_var.get(),
            'target_duration': self.duration_var.get(),
            'parallel_processing': self.parallel_var.get(),
            'chunk_size': self.chunk_size_var.get()
        }


class InputPanel(ttk.LabelFrame):
    """Panel for input file/sequence selection"""
    
    def __init__(self, parent, **kwargs):
        super().__init__(parent, text="Input", **kwargs)
        self._create_widgets()
    
    def _create_widgets(self):
        # Input type selection
        type_frame = ttk.Frame(self)
        type_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.input_type_var = tk.StringVar(value="file")
        ttk.Radiobutton(type_frame, text="File", variable=self.input_type_var,
                       value="file", command=self._toggle_input).pack(side=tk.LEFT)
        ttk.Radiobutton(type_frame, text="Sequence", variable=self.input_type_var,
                       value="sequence", command=self._toggle_input).pack(side=tk.LEFT)
        ttk.Radiobutton(type_frame, text="Binary", variable=self.input_type_var,
                       value="binary", command=self._toggle_input).pack(side=tk.LEFT)
        ttk.Radiobutton(type_frame, text="Custom Target", variable=self.input_type_var,
                       value="custom", command=self._toggle_input).pack(side=tk.LEFT)
        
        # File selection
        self.file_frame = ttk.Frame(self)
        self.file_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.file_var = tk.StringVar()
        ttk.Entry(self.file_frame, textvariable=self.file_var, width=50).pack(side=tk.LEFT, padx=5)
        ttk.Button(self.file_frame, text="Browse", command=self._browse_file).pack(side=tk.LEFT)
        
        # Sequence entry
        self.sequence_frame = ttk.Frame(self)
        
        ttk.Label(self.sequence_frame, text="Enter DNA/RNA Sequence:").pack(anchor=tk.W)
        self.sequence_text = scrolledtext.ScrolledText(self.sequence_frame, height=5, width=60)
        self.sequence_text.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Custom target entry
        self.custom_frame = ttk.Frame(self)
        
        ttk.Label(self.custom_frame, text="Custom Target Sequence:").pack(anchor=tk.W)
        self.custom_text = scrolledtext.ScrolledText(self.custom_frame, height=5, width=60)
        self.custom_text.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Carrier music
        carrier_frame = ttk.Frame(self)
        carrier_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(carrier_frame, text="Carrier Music:").pack(side=tk.LEFT)
        self.carrier_var = tk.StringVar()
        ttk.Entry(carrier_frame, textvariable=self.carrier_var, width=40).pack(side=tk.LEFT, padx=5)
        ttk.Button(carrier_frame, text="Browse", command=self._browse_carrier).pack(side=tk.LEFT)
        
        # Output directory
        output_frame = ttk.Frame(self)
        output_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(output_frame, text="Output Directory:").pack(side=tk.LEFT)
        self.output_var = tk.StringVar(value=os.path.expanduser("~/Downloads/audio_genomics_output"))
        ttk.Entry(output_frame, textvariable=self.output_var, width=40).pack(side=tk.LEFT, padx=5)
        ttk.Button(output_frame, text="Browse", command=self._browse_output).pack(side=tk.LEFT)
    
    def _toggle_input(self):
        """Toggle input type display"""
        self.file_frame.pack_forget()
        self.sequence_frame.pack_forget()
        self.custom_frame.pack_forget()
        
        input_type = self.input_type_var.get()
        if input_type in ("file", "binary"):
            self.file_frame.pack(fill=tk.X, padx=5, pady=5, after=self.winfo_children()[0])
        elif input_type == "sequence":
            self.sequence_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5, after=self.winfo_children()[0])
        elif input_type == "custom":
            self.custom_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5, after=self.winfo_children()[0])
    
    def _browse_file(self):
        """Browse for input file"""
        filetypes = [
            ("Sequence Files", "*.fasta *.fa *.fna *.txt *.dna *.rna"),
            ("All Files", "*.*")
        ]
        file = filedialog.askopenfilename(title="Select Input File", filetypes=filetypes)
        if file:
            self.file_var.set(file)
    
    def _browse_carrier(self):
        """Browse for carrier music"""
        filetypes = [("Audio Files", "*.wav *.mp3 *.flac"), ("All Files", "*.*")]
        file = filedialog.askopenfilename(title="Select Carrier Music", filetypes=filetypes)
        if file:
            self.carrier_var.set(file)
    
    def _browse_output(self):
        """Browse for output directory"""
        directory = filedialog.askdirectory(title="Select Output Directory")
        if directory:
            self.output_var.set(directory)
    
    def get_input_data(self) -> Dict:
        """Get input data and settings"""
        input_type = self.input_type_var.get()
        
        data = {
            'input_type': input_type,
            'carrier_music': self.carrier_var.get() or None,
            'output_directory': self.output_var.get()
        }
        
        if input_type in ("file", "binary"):
            data['file_path'] = self.file_var.get()
        elif input_type == "sequence":
            data['sequence'] = self.sequence_text.get("1.0", tk.END).strip()
        elif input_type == "custom":
            data['custom_target'] = self.custom_text.get("1.0", tk.END).strip()
        
        return data
    
    def set_sequence(self, sequence: str):
        """Set the sequence text"""
        self.input_type_var.set("sequence")
        self._toggle_input()
        self.sequence_text.delete("1.0", tk.END)
        self.sequence_text.insert("1.0", sequence)


class AudioGenomicsProGUI:
    """Main comprehensive GUI application"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Audio Genomics Pro - Scientific Research Edition")
        self.root.geometry("1200x900")
        
        # Initialize components
        self.bioinformatics = BioinformaticsTools()
        self.frequency_mapper = NucleotideFrequencyMapper(tuning=432.0)
        self.folding_compressor = DNAFoldingCompressor()
        
        # Processing state
        self.processing_queue = queue.Queue()
        self.is_processing = False
        
        # Create interface
        self._create_menu()
        self._create_interface()
        
        # Start queue monitoring
        self.root.after(100, self._check_queue)
    
    def _create_menu(self):
        """Create menu bar"""
        menubar = tk.Menu(self.root)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="New Session", command=self._new_session)
        file_menu.add_command(label="Open Project", command=self._open_project)
        file_menu.add_command(label="Save Project", command=self._save_project)
        file_menu.add_separator()
        file_menu.add_command(label="Export Settings", command=self._export_settings)
        file_menu.add_command(label="Import Settings", command=self._import_settings)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)
        
        # Tools menu
        tools_menu = tk.Menu(menubar, tearoff=0)
        tools_menu.add_command(label="Sequence Validator", command=self._show_validator)
        tools_menu.add_command(label="Frequency Calculator", command=self._show_freq_calc)
        tools_menu.add_command(label="Compression Estimator", command=self._show_compression_est)
        menubar.add_cascade(label="Tools", menu=tools_menu)
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="Documentation", command=self._show_docs)
        help_menu.add_command(label="About", command=self._show_about)
        menubar.add_cascade(label="Help", menu=help_menu)
        
        self.root.config(menu=menubar)
    
    def _create_interface(self):
        """Create main interface"""
        # Create notebook for tabbed interface
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Main processing tab
        main_tab = ttk.Frame(self.notebook)
        self.notebook.add(main_tab, text="Processing")
        self._create_main_tab(main_tab)
        
        # GenBank tab
        genbank_tab = ttk.Frame(self.notebook)
        self.notebook.add(genbank_tab, text="GenBank")
        self._create_genbank_tab(genbank_tab)
        
        # Body Systems tab
        systems_tab = ttk.Frame(self.notebook)
        self.notebook.add(systems_tab, text="Body Systems")
        self._create_systems_tab(systems_tab)
        
        # CRISPR tab
        crispr_tab = ttk.Frame(self.notebook)
        self.notebook.add(crispr_tab, text="CRISPR")
        self._create_crispr_tab(crispr_tab)
        
        # Log/Output tab
        log_tab = ttk.Frame(self.notebook)
        self.notebook.add(log_tab, text="Log")
        self._create_log_tab(log_tab)
    
    def _create_main_tab(self, parent):
        """Create main processing tab"""
        # Left panel - Input and settings
        left_frame = ttk.Frame(parent)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Input panel
        self.input_panel = InputPanel(left_frame)
        self.input_panel.pack(fill=tk.X, pady=5)
        
        # Frequency settings
        self.frequency_panel = FrequencyPanel(left_frame)
        self.frequency_panel.pack(fill=tk.X, pady=5)
        
        # Right panel - Folding and actions
        right_frame = ttk.Frame(parent)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Folding panel
        self.folding_panel = FoldingPanel(right_frame)
        self.folding_panel.pack(fill=tk.X, pady=5)
        
        # Action buttons
        action_frame = ttk.LabelFrame(right_frame, text="Actions")
        action_frame.pack(fill=tk.X, pady=5)
        
        self.process_btn = ttk.Button(action_frame, text="Start Processing", 
                                      command=self._start_processing)
        self.process_btn.pack(side=tk.LEFT, padx=10, pady=10)
        
        self.stop_btn = ttk.Button(action_frame, text="Stop", 
                                   command=self._stop_processing, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=10, pady=10)
        
        # Progress
        progress_frame = ttk.Frame(action_frame)
        progress_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.progress_bar = ttk.Progressbar(progress_frame, length=300, mode='determinate')
        self.progress_bar.pack(side=tk.LEFT)
        
        self.progress_label = ttk.Label(progress_frame, text="Ready")
        self.progress_label.pack(side=tk.LEFT, padx=10)
        
        # Quick stats
        stats_frame = ttk.LabelFrame(right_frame, text="Statistics")
        stats_frame.pack(fill=tk.X, pady=5)
        
        self.stats_text = tk.Text(stats_frame, height=8, width=40, state=tk.DISABLED)
        self.stats_text.pack(fill=tk.X, padx=5, pady=5)
    
    def _create_genbank_tab(self, parent):
        """Create GenBank search tab"""
        self.genbank_panel = GenBankPanel(parent, self.bioinformatics)
        self.genbank_panel.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Bind sequence fetch event
        self.genbank_panel.bind("<<SequenceFetched>>", self._on_sequence_fetched)
    
    def _create_systems_tab(self, parent):
        """Create body systems tab"""
        self.body_systems_panel = BodySystemPanel(parent)
        self.body_systems_panel.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Buttons
        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Button(btn_frame, text="Select All", 
                  command=self.body_systems_panel.select_all).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Clear All",
                  command=self.body_systems_panel.clear_all).pack(side=tk.LEFT, padx=5)
    
    def _create_crispr_tab(self, parent):
        """Create CRISPR settings tab"""
        self.crispr_panel = CRISPRPanel(parent)
        self.crispr_panel.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    def _create_log_tab(self, parent):
        """Create log/output tab"""
        self.log_text = scrolledtext.ScrolledText(parent, height=30, width=100)
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Clear button
        ttk.Button(parent, text="Clear Log", 
                  command=lambda: self.log_text.delete("1.0", tk.END)).pack(pady=5)
    
    def _log(self, message: str):
        """Add message to log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
    
    def _on_sequence_fetched(self, event):
        """Handle sequence fetched from GenBank"""
        sequence = self.genbank_panel.get_sequence()
        if sequence:
            self.input_panel.set_sequence(sequence)
            self.notebook.select(0)  # Switch to main tab
            self._log(f"Loaded sequence from GenBank: {len(sequence)} bases")
    
    def _start_processing(self):
        """Start processing"""
        input_data = self.input_panel.get_input_data()
        freq_settings = self.frequency_panel.get_settings()
        folding_settings = self.folding_panel.get_settings()
        crispr_settings = self.crispr_panel.get_settings()
        body_systems = self.body_systems_panel.get_selected_systems()
        
        # Validate
        if input_data['input_type'] == 'file' and not input_data.get('file_path'):
            messagebox.showwarning("Input Required", "Please select an input file")
            return
        if input_data['input_type'] == 'sequence' and not input_data.get('sequence'):
            messagebox.showwarning("Input Required", "Please enter a sequence")
            return
        
        # Create output directory
        os.makedirs(input_data['output_directory'], exist_ok=True)
        
        self.process_btn.configure(state=tk.DISABLED)
        self.stop_btn.configure(state=tk.NORMAL)
        self.is_processing = True
        
        # Start processing thread
        config = {
            **freq_settings,
            'folding': folding_settings,
            'crispr': crispr_settings,
            'body_systems': body_systems,
            'input': input_data
        }
        
        thread = threading.Thread(target=self._process_thread, args=(config,), daemon=True)
        thread.start()
    
    def _process_thread(self, config):
        """Processing thread"""
        try:
            self._log("Starting processing...")
            
            # Initialize pipeline
            pipeline = AudioGenomicsPipeline({
                'sample_rate': config['sample_rate'],
                'bit_depth': config['bit_depth'],
                'base_cycles': config['cycles_per_base'],
                'fm_carrier_freq': config['fm_carrier_freq'],
                'am_modulation_depth': config['am_modulation_depth'],
                'normalize_output': config['normalize_output'],
                'retune_to_432': config['tuning'] < 436
            })
            
            input_data = config['input']
            output_dir = input_data['output_directory']
            carrier = input_data.get('carrier_music')
            
            # Get sequence based on input type
            if input_data['input_type'] == 'file':
                file_path = input_data['file_path']
                self._log(f"Processing file: {file_path}")
                
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_file = os.path.join(output_dir, f"output_{timestamp}.wav")
                
                result = pipeline.process_file(file_path, carrier, output_file)
                
            elif input_data['input_type'] == 'sequence':
                sequence = input_data['sequence']
                self._log(f"Processing sequence: {len(sequence)} bases")
                
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_file = os.path.join(output_dir, f"sequence_{timestamp}.wav")
                
                result = pipeline.process_sequence(sequence, carrier, output_file)
            
            else:
                result = {'success': False, 'error': 'Unsupported input type'}
            
            if result.get('success'):
                self.processing_queue.put(('complete', result))
            else:
                self.processing_queue.put(('error', result.get('error', 'Unknown error')))
                
        except Exception as e:
            self.processing_queue.put(('error', str(e)))
    
    def _stop_processing(self):
        """Stop processing"""
        self.is_processing = False
        self.process_btn.configure(state=tk.NORMAL)
        self.stop_btn.configure(state=tk.DISABLED)
        self.progress_label.configure(text="Stopped")
        self._log("Processing stopped by user")
    
    def _check_queue(self):
        """Check message queue"""
        try:
            while True:
                msg_type, data = self.processing_queue.get_nowait()
                
                if msg_type == 'progress':
                    self.progress_bar['value'] = data.get('percent', 0)
                    self.progress_label.configure(text=data.get('message', ''))
                    
                elif msg_type == 'complete':
                    self._log(f"Processing complete: {data.get('output_file', 'N/A')}")
                    self._update_stats(data)
                    self._stop_processing()
                    messagebox.showinfo("Complete", "Processing completed successfully!")
                    
                elif msg_type == 'error':
                    self._log(f"Error: {data}")
                    self._stop_processing()
                    messagebox.showerror("Error", str(data))
                    
        except queue.Empty:
            pass
        
        self.root.after(100, self._check_queue)
    
    def _update_stats(self, result):
        """Update statistics display"""
        self.stats_text.configure(state=tk.NORMAL)
        self.stats_text.delete("1.0", tk.END)
        
        stats = [
            f"Output: {result.get('output_file', 'N/A')}",
            f"Sequence Length: {result.get('sequence_length', 'N/A')} bases",
            f"Duration: {result.get('audio_duration', 0):.2f} seconds",
            f"Sample Rate: {result.get('sample_rate', 'N/A')} Hz",
            f"Bit Depth: {result.get('bit_depth', 'N/A')} bits"
        ]
        
        self.stats_text.insert("1.0", "\n".join(stats))
        self.stats_text.configure(state=tk.DISABLED)
    
    # Menu handlers
    def _new_session(self):
        """Start new session"""
        self.input_panel.file_var.set("")
        self.input_panel.sequence_text.delete("1.0", tk.END)
        self.body_systems_panel.clear_all()
        self._log("New session started")
    
    def _open_project(self):
        """Open project file"""
        file = filedialog.askopenfilename(
            title="Open Project",
            filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")]
        )
        if file:
            try:
                with open(file, 'r') as f:
                    project = json.load(f)
                self._log(f"Opened project: {file}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to open project: {e}")
    
    def _save_project(self):
        """Save project file"""
        file = filedialog.asksaveasfilename(
            title="Save Project",
            defaultextension=".json",
            filetypes=[("JSON Files", "*.json")]
        )
        if file:
            try:
                project = {
                    'frequency': self.frequency_panel.get_settings(),
                    'folding': self.folding_panel.get_settings(),
                    'crispr': self.crispr_panel.get_settings(),
                    'body_systems': self.body_systems_panel.get_selected_systems()
                }
                with open(file, 'w') as f:
                    json.dump(project, f, indent=2)
                self._log(f"Saved project: {file}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save project: {e}")
    
    def _export_settings(self):
        """Export settings"""
        file = filedialog.asksaveasfilename(
            title="Export Settings",
            defaultextension=".json"
        )
        if file:
            settings = {
                'frequency': self.frequency_panel.get_settings(),
                'folding': self.folding_panel.get_settings(),
                'crispr': self.crispr_panel.get_settings()
            }
            with open(file, 'w') as f:
                json.dump(settings, f, indent=2)
            self._log(f"Exported settings to: {file}")
    
    def _import_settings(self):
        """Import settings"""
        file = filedialog.askopenfilename(title="Import Settings")
        if file:
            self._log(f"Imported settings from: {file}")
    
    def _show_validator(self):
        """Show sequence validator tool"""
        messagebox.showinfo("Validator", "Sequence validation tool")
    
    def _show_freq_calc(self):
        """Show frequency calculator"""
        messagebox.showinfo("Calculator", "Frequency calculator tool")
    
    def _show_compression_est(self):
        """Show compression estimator"""
        messagebox.showinfo("Estimator", "Compression estimation tool")
    
    def _show_docs(self):
        """Show documentation"""
        messagebox.showinfo("Documentation", 
            "Audio Genomics Pro v4.0\n\n"
            "Scientific research-grade DNA/RNA to audio conversion\n"
            "with chromatin-like folding compression.\n\n"
            "Features:\n"
            "- Nucleotide frequency mapping from infrared spectroscopy\n"
            "- Auto-scaling to musical keys\n"
            "- CRISPR targeting support\n"
            "- GenBank database integration\n"
            "- All body systems targeting\n"
            "- DNA-like folding compression"
        )
    
    def _show_about(self):
        """Show about dialog"""
        messagebox.showinfo("About", 
            "Audio Genomics Pro v4.0\n"
            "Scientific Research Edition\n\n"
            "Advanced DNA/RNA to Audio Synthesis\n"
            "with Chromatin-like Folding Compression"
        )


def main():
    """Run the comprehensive GUI application"""
    root = tk.Tk()
    app = AudioGenomicsProGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()

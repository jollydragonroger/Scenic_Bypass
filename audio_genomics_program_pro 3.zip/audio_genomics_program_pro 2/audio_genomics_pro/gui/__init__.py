"""
GUI modules for Audio Genomics Pro
"""

from .main_gui import AudioGenomicsGUI

__all__ = ['AudioGenomicsGUI']

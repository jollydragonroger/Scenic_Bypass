"""
Audio Genomics Pro - Complete Scientific Research GUI
Full-featured desktop application with all capabilities
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading
import queue
import json
import os
import sys
from datetime import datetime
from typing import Optional, List, Dict
from pathlib import Path

# Ensure proper imports
if getattr(sys, 'frozen', False):
    # Running as compiled
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

sys.path.insert(0, BASE_DIR)

try:
    from audio_genomics_pro.core.main_pipeline import AudioGenomicsPipeline
    from audio_genomics_pro.core.dna_folding import DNAFoldingCompressor, FoldingLevel
    from audio_genomics_pro.core.nucleotide_frequencies import NucleotideFrequencyMapper, MusicalKey
    from audio_genomics_pro.core.bioinformatics import BioinformaticsTools
    from audio_genomics_pro.core.multi_targeting_crispr import BodySystem
except ImportError as e:
    print(f"Import error: {e}")
    # Fallback for frozen app
    pass


class AudioGenomicsApp:
    """Main Application GUI"""
    
    # All body systems
    BODY_SYSTEMS = {
        "Standard Human": [
            "Nervous", "Endocrine", "Cardiovascular", "Respiratory", "Digestive",
            "Urinary", "Reproductive", "Immune", "Lymphatic", "Muscular",
            "Skeletal", "Integumentary", "Sensory", "Excretory", "Circulatory"
        ],
        "Enhanced": [
            "Flight Musculature", "Wing Development", "Scale Formation",
            "Breath Weapon", "Fire Resistance", "Enhanced Vision", "Super Strength",
            "Regeneration", "Longevity", "Telepathy", "Energy Manipulation",
            "Dimensional Travel", "Shape Shifting"
        ],
        "Reproductive": ["Hermaphroditic", "Enhanced Fertility", "Parthenogenesis"]
    }
    
    CRISPR_TYPES = [
        "Cas9", "Cas12a (Cpf1)", "Cas13 (RNA)", "CasΦ (Phage)",
        "Base Editor", "Prime Editor", "CRISPRi", "CRISPRa",
        "Cas14", "CasX", "CasY"
    ]
    
    def __init__(self, root):
        self.root = root
        self.root.title("Audio Genomics Pro - Scientific Research Edition")
        self.root.geometry("1100x850")
        self.root.minsize(900, 700)
        
        # Initialize tools
        self.bioinformatics = BioinformaticsTools()
        self.processing_queue = queue.Queue()
        self.is_processing = False
        
        # Build UI
        self._create_menu()
        self._create_main_interface()
        
        # Start queue monitor
        self.root.after(100, self._check_queue)
    
    def _create_menu(self):
        menubar = tk.Menu(self.root)
        
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="New", command=self._new_session)
        file_menu.add_command(label="Save Settings", command=self._save_settings)
        file_menu.add_command(label="Load Settings", command=self._load_settings)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)
        
        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="About", command=self._show_about)
        menubar.add_cascade(label="Help", menu=help_menu)
        
        self.root.config(menu=menubar)
    
    def _create_main_interface(self):
        # Main notebook
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Tab 1: Input/Output
        self._create_io_tab()
        
        # Tab 2: Audio Settings
        self._create_audio_tab()
        
        # Tab 3: CRISPR/gRNA
        self._create_crispr_tab()
        
        # Tab 4: Body Systems
        self._create_systems_tab()
        
        # Tab 5: GenBank
        self._create_genbank_tab()
        
        # Tab 6: Log
        self._create_log_tab()
        
        # Bottom action bar
        self._create_action_bar()
    
    def _create_io_tab(self):
        """Input/Output tab"""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Input / Output")
        
        # Input section
        input_frame = ttk.LabelFrame(tab, text="Input Source", padding=10)
        input_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Input type selection
        type_frame = ttk.Frame(input_frame)
        type_frame.pack(fill=tk.X, pady=5)
        
        self.input_type = tk.StringVar(value="sequence")
        ttk.Radiobutton(type_frame, text="Raw Sequence", variable=self.input_type,
                       value="sequence", command=self._toggle_input).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(type_frame, text="Single File", variable=self.input_type,
                       value="file", command=self._toggle_input).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(type_frame, text="Directory (Batch)", variable=self.input_type,
                       value="directory", command=self._toggle_input).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(type_frame, text="Binary File", variable=self.input_type,
                       value="binary", command=self._toggle_input).pack(side=tk.LEFT, padx=5)
        
        # Sequence input
        self.seq_frame = ttk.Frame(input_frame)
        self.seq_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        ttk.Label(self.seq_frame, text="Enter DNA/RNA Sequence:").pack(anchor=tk.W)
        self.sequence_text = scrolledtext.ScrolledText(self.seq_frame, height=6, width=80)
        self.sequence_text.pack(fill=tk.BOTH, expand=True)
        
        # File input
        self.file_frame = ttk.Frame(input_frame)
        file_row = ttk.Frame(self.file_frame)
        file_row.pack(fill=tk.X, pady=5)
        ttk.Label(file_row, text="File:").pack(side=tk.LEFT)
        self.file_path = tk.StringVar()
        ttk.Entry(file_row, textvariable=self.file_path, width=60).pack(side=tk.LEFT, padx=5)
        ttk.Button(file_row, text="Browse", command=self._browse_file).pack(side=tk.LEFT)
        
        # Directory input
        self.dir_frame = ttk.Frame(input_frame)
        dir_row = ttk.Frame(self.dir_frame)
        dir_row.pack(fill=tk.X, pady=5)
        ttk.Label(dir_row, text="Directory:").pack(side=tk.LEFT)
        self.dir_path = tk.StringVar()
        ttk.Entry(dir_row, textvariable=self.dir_path, width=60).pack(side=tk.LEFT, padx=5)
        ttk.Button(dir_row, text="Browse", command=self._browse_dir).pack(side=tk.LEFT)
        
        # Output section
        output_frame = ttk.LabelFrame(tab, text="Output", padding=10)
        output_frame.pack(fill=tk.X, padx=10, pady=5)
        
        out_row = ttk.Frame(output_frame)
        out_row.pack(fill=tk.X, pady=5)
        ttk.Label(out_row, text="Output Directory:").pack(side=tk.LEFT)
        self.output_dir = tk.StringVar(value=os.path.expanduser("~/Downloads/audio_genomics_output"))
        ttk.Entry(out_row, textvariable=self.output_dir, width=50).pack(side=tk.LEFT, padx=5)
        ttk.Button(out_row, text="Browse", command=self._browse_output).pack(side=tk.LEFT)
        
        # Output mode
        mode_frame = ttk.LabelFrame(tab, text="Output Mode", padding=10)
        mode_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.output_mode = tk.StringVar(value="pure")
        ttk.Radiobutton(mode_frame, text="Pure Genomic Audio (No Music)",
                       variable=self.output_mode, value="pure").pack(anchor=tk.W)
        ttk.Radiobutton(mode_frame, text="With Carrier Music Modulation",
                       variable=self.output_mode, value="modulated").pack(anchor=tk.W)
        
        # Carrier music (shown when modulated selected)
        self.carrier_frame = ttk.Frame(mode_frame)
        self.carrier_frame.pack(fill=tk.X, pady=5)
        ttk.Label(self.carrier_frame, text="Carrier Music File:").pack(side=tk.LEFT)
        self.carrier_path = tk.StringVar()
        ttk.Entry(self.carrier_frame, textvariable=self.carrier_path, width=40).pack(side=tk.LEFT, padx=5)
        ttk.Button(self.carrier_frame, text="Browse", command=self._browse_carrier).pack(side=tk.LEFT)
    
    def _create_audio_tab(self):
        """Audio settings tab"""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Audio Settings")
        
        # Frequency settings
        freq_frame = ttk.LabelFrame(tab, text="Frequency Settings", padding=10)
        freq_frame.pack(fill=tk.X, padx=10, pady=5)
        
        row = 0
        ttk.Label(freq_frame, text="Tuning:").grid(row=row, column=0, sticky=tk.W, pady=2)
        self.tuning = tk.DoubleVar(value=432.0)
        tune_frame = ttk.Frame(freq_frame)
        tune_frame.grid(row=row, column=1, sticky=tk.W)
        ttk.Radiobutton(tune_frame, text="432 Hz", variable=self.tuning, value=432.0).pack(side=tk.LEFT)
        ttk.Radiobutton(tune_frame, text="440 Hz", variable=self.tuning, value=440.0).pack(side=tk.LEFT)
        
        row += 1
        self.auto_key = tk.BooleanVar(value=True)
        ttk.Checkbutton(freq_frame, text="Auto-scale to Musical Key",
                       variable=self.auto_key).grid(row=row, column=0, columnspan=2, sticky=tk.W, pady=2)
        
        row += 1
        ttk.Label(freq_frame, text="Musical Key:").grid(row=row, column=0, sticky=tk.W, pady=2)
        self.musical_key = tk.StringVar(value="C")
        ttk.Combobox(freq_frame, textvariable=self.musical_key,
                    values=["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"],
                    width=8).grid(row=row, column=1, sticky=tk.W)
        
        # Audio quality
        quality_frame = ttk.LabelFrame(tab, text="Audio Quality", padding=10)
        quality_frame.pack(fill=tk.X, padx=10, pady=5)
        
        row = 0
        ttk.Label(quality_frame, text="Sample Rate:").grid(row=row, column=0, sticky=tk.W, pady=2)
        self.sample_rate = tk.IntVar(value=192000)
        ttk.Combobox(quality_frame, textvariable=self.sample_rate,
                    values=[44100, 48000, 96000, 192000], width=10).grid(row=row, column=1, sticky=tk.W)
        
        row += 1
        ttk.Label(quality_frame, text="Bit Depth:").grid(row=row, column=0, sticky=tk.W, pady=2)
        self.bit_depth = tk.IntVar(value=32)
        ttk.Combobox(quality_frame, textvariable=self.bit_depth,
                    values=[16, 24, 32], width=10).grid(row=row, column=1, sticky=tk.W)
        
        row += 1
        ttk.Label(quality_frame, text="Cycles per Base:").grid(row=row, column=0, sticky=tk.W, pady=2)
        self.cycles = tk.IntVar(value=3)
        ttk.Spinbox(quality_frame, from_=1, to=20, textvariable=self.cycles,
                   width=8).grid(row=row, column=1, sticky=tk.W)
        
        # Folding compression
        fold_frame = ttk.LabelFrame(tab, text="DNA Folding Compression", padding=10)
        fold_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.use_folding = tk.BooleanVar(value=True)
        ttk.Checkbutton(fold_frame, text="Enable Chromatin-like Folding",
                       variable=self.use_folding).pack(anchor=tk.W)
        
        fold_row = ttk.Frame(fold_frame)
        fold_row.pack(fill=tk.X, pady=5)
        ttk.Label(fold_row, text="Folding Level:").pack(side=tk.LEFT)
        self.fold_level = tk.StringVar(value="SINGLE_FOLD")
        ttk.Combobox(fold_row, textvariable=self.fold_level,
                    values=["LINEAR", "SINGLE_FOLD", "DOUBLE_FOLD", "NUCLEOSOME", "CHROMATIN", "CHROMOSOME"],
                    width=15).pack(side=tk.LEFT, padx=5)
        
        self.normalize = tk.BooleanVar(value=True)
        ttk.Checkbutton(fold_frame, text="Normalize Output",
                       variable=self.normalize).pack(anchor=tk.W)
    
    def _create_crispr_tab(self):
        """CRISPR and gRNA tab"""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="CRISPR / gRNA")
        
        # Enable toggle
        toggle_frame = ttk.Frame(tab)
        toggle_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.use_crispr = tk.BooleanVar(value=False)
        ttk.Checkbutton(toggle_frame, text="Enable CRISPR Targeting",
                       variable=self.use_crispr, command=self._toggle_crispr).pack(anchor=tk.W)
        
        self.calc_grna = tk.BooleanVar(value=False)
        ttk.Checkbutton(toggle_frame, text="Calculate gRNA Sequences",
                       variable=self.calc_grna).pack(anchor=tk.W)
        
        # CRISPR settings frame
        self.crispr_frame = ttk.LabelFrame(tab, text="CRISPR Settings", padding=10)
        self.crispr_frame.pack(fill=tk.X, padx=10, pady=5)
        
        row = 0
        ttk.Label(self.crispr_frame, text="CRISPR System:").grid(row=row, column=0, sticky=tk.W, pady=2)
        self.crispr_type = tk.StringVar(value="CasΦ (Phage)")
        ttk.Combobox(self.crispr_frame, textvariable=self.crispr_type,
                    values=self.CRISPR_TYPES, width=20).grid(row=row, column=1, sticky=tk.W)
        
        row += 1
        ttk.Label(self.crispr_frame, text="PAM Sequence:").grid(row=row, column=0, sticky=tk.W, pady=2)
        self.pam_seq = tk.StringVar(value="TBN")
        ttk.Entry(self.crispr_frame, textvariable=self.pam_seq, width=15).grid(row=row, column=1, sticky=tk.W)
        
        row += 1
        ttk.Label(self.crispr_frame, text="gRNA Length:").grid(row=row, column=0, sticky=tk.W, pady=2)
        self.grna_length = tk.IntVar(value=20)
        ttk.Spinbox(self.crispr_frame, from_=15, to=30, textvariable=self.grna_length,
                   width=8).grid(row=row, column=1, sticky=tk.W)
        
        row += 1
        ttk.Label(self.crispr_frame, text="Off-target Threshold:").grid(row=row, column=0, sticky=tk.W, pady=2)
        self.offtarget = tk.DoubleVar(value=0.8)
        ttk.Scale(self.crispr_frame, from_=0.5, to=1.0, variable=self.offtarget,
                 orient=tk.HORIZONTAL, length=150).grid(row=row, column=1, sticky=tk.W)
        
        row += 1
        self.multiplex = tk.BooleanVar(value=True)
        ttk.Checkbutton(self.crispr_frame, text="Enable Multiplexing",
                       variable=self.multiplex).grid(row=row, column=0, columnspan=2, sticky=tk.W, pady=2)
        
        # Initially disable
        self._toggle_crispr()
    
    def _create_systems_tab(self):
        """Body systems tab"""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Body Systems")
        
        self.system_vars = {}
        
        # Create notebook for categories
        sys_notebook = ttk.Notebook(tab)
        sys_notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        for category, systems in self.BODY_SYSTEMS.items():
            frame = ttk.Frame(sys_notebook)
            sys_notebook.add(frame, text=category)
            
            for i, system in enumerate(systems):
                var = tk.BooleanVar(value=False)
                self.system_vars[system] = var
                ttk.Checkbutton(frame, text=system, variable=var).grid(
                    row=i//3, column=i%3, sticky=tk.W, padx=10, pady=2)
        
        # Buttons
        btn_frame = ttk.Frame(tab)
        btn_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(btn_frame, text="Select All", command=self._select_all_systems).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Clear All", command=self._clear_all_systems).pack(side=tk.LEFT, padx=5)
    
    def _create_genbank_tab(self):
        """GenBank search tab"""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="GenBank")
        
        # Search frame
        search_frame = ttk.LabelFrame(tab, text="Search GenBank", padding=10)
        search_frame.pack(fill=tk.X, padx=10, pady=5)
        
        row = ttk.Frame(search_frame)
        row.pack(fill=tk.X, pady=5)
        ttk.Label(row, text="Search:").pack(side=tk.LEFT)
        self.genbank_query = tk.StringVar()
        entry = ttk.Entry(row, textvariable=self.genbank_query, width=40)
        entry.pack(side=tk.LEFT, padx=5)
        entry.bind("<Return>", lambda e: self._search_genbank())
        ttk.Button(row, text="Search", command=self._search_genbank).pack(side=tk.LEFT)
        
        self.genbank_db = tk.StringVar(value="nucleotide")
        ttk.Combobox(row, textvariable=self.genbank_db,
                    values=["nucleotide", "protein", "gene"], width=12).pack(side=tk.LEFT, padx=5)
        
        # Results
        self.genbank_results = tk.Listbox(search_frame, height=8, width=80)
        self.genbank_results.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Fetch frame
        fetch_frame = ttk.Frame(search_frame)
        fetch_frame.pack(fill=tk.X, pady=5)
        ttk.Label(fetch_frame, text="Accession:").pack(side=tk.LEFT)
        self.accession = tk.StringVar()
        ttk.Entry(fetch_frame, textvariable=self.accession, width=20).pack(side=tk.LEFT, padx=5)
        ttk.Button(fetch_frame, text="Fetch & Use", command=self._fetch_genbank).pack(side=tk.LEFT)
        
        self.genbank_status = tk.StringVar(value="Ready")
        ttk.Label(search_frame, textvariable=self.genbank_status).pack(anchor=tk.W)
    
    def _create_log_tab(self):
        """Log output tab"""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Log")
        
        self.log_text = scrolledtext.ScrolledText(tab, height=25, width=100)
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        ttk.Button(tab, text="Clear Log",
                  command=lambda: self.log_text.delete("1.0", tk.END)).pack(pady=5)
    
    def _create_action_bar(self):
        """Bottom action bar"""
        bar = ttk.Frame(self.root)
        bar.pack(fill=tk.X, padx=10, pady=10)
        
        self.process_btn = ttk.Button(bar, text="Start Processing", command=self._start_processing)
        self.process_btn.pack(side=tk.LEFT, padx=5)
        
        self.stop_btn = ttk.Button(bar, text="Stop", command=self._stop_processing, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=5)
        
        self.progress = ttk.Progressbar(bar, length=300, mode='determinate')
        self.progress.pack(side=tk.LEFT, padx=20)
        
        self.status = tk.StringVar(value="Ready")
        ttk.Label(bar, textvariable=self.status).pack(side=tk.LEFT, padx=10)
    
    # Event handlers
    def _toggle_input(self):
        self.seq_frame.pack_forget()
        self.file_frame.pack_forget()
        self.dir_frame.pack_forget()
        
        t = self.input_type.get()
        if t == "sequence":
            self.seq_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        elif t in ("file", "binary"):
            self.file_frame.pack(fill=tk.X, pady=5)
        elif t == "directory":
            self.dir_frame.pack(fill=tk.X, pady=5)
    
    def _toggle_crispr(self):
        state = tk.NORMAL if self.use_crispr.get() else tk.DISABLED
        for child in self.crispr_frame.winfo_children():
            try:
                child.configure(state=state)
            except:
                pass
    
    def _browse_file(self):
        f = filedialog.askopenfilename(filetypes=[
            ("Sequence Files", "*.fasta *.fa *.fna *.txt *.dna *.rna"),
            ("All Files", "*.*")
        ])
        if f:
            self.file_path.set(f)
    
    def _browse_dir(self):
        d = filedialog.askdirectory()
        if d:
            self.dir_path.set(d)
    
    def _browse_output(self):
        d = filedialog.askdirectory()
        if d:
            self.output_dir.set(d)
    
    def _browse_carrier(self):
        f = filedialog.askopenfilename(filetypes=[
            ("Audio Files", "*.wav *.mp3 *.flac *.aiff"),
            ("All Files", "*.*")
        ])
        if f:
            self.carrier_path.set(f)
    
    def _select_all_systems(self):
        for var in self.system_vars.values():
            var.set(True)
    
    def _clear_all_systems(self):
        for var in self.system_vars.values():
            var.set(False)
    
    def _search_genbank(self):
        query = self.genbank_query.get().strip()
        if not query:
            return
        
        self.genbank_status.set("Searching...")
        self.genbank_results.delete(0, tk.END)
        
        def search():
            try:
                results = self.bioinformatics.search_genbank(query, self.genbank_db.get(), 20)
                self.root.after(0, lambda: self._update_genbank_results(results))
            except Exception as e:
                self.root.after(0, lambda: self.genbank_status.set(f"Error: {e}"))
        
        threading.Thread(target=search, daemon=True).start()
    
    def _update_genbank_results(self, results):
        self.genbank_results.delete(0, tk.END)
        self._search_results = results
        for r in results:
            self.genbank_results.insert(tk.END, f"{r.get('accession', 'N/A')} - {r.get('title', '')[:60]}")
        self.genbank_status.set(f"Found {len(results)} results")
    
    def _fetch_genbank(self):
        acc = self.accession.get().strip()
        if not acc:
            return
        
        self.genbank_status.set("Fetching...")
        
        def fetch():
            try:
                data = self.bioinformatics.fetch_sequence(acc, self.genbank_db.get())
                if data:
                    seqs = self.bioinformatics.parse_fasta(data)
                    if seqs:
                        seq = seqs[0][1]
                        self.root.after(0, lambda: self._use_fetched_sequence(seq))
                        return
                self.root.after(0, lambda: self.genbank_status.set("No sequence found"))
            except Exception as e:
                self.root.after(0, lambda: self.genbank_status.set(f"Error: {e}"))
        
        threading.Thread(target=fetch, daemon=True).start()
    
    def _use_fetched_sequence(self, seq):
        self.input_type.set("sequence")
        self._toggle_input()
        self.sequence_text.delete("1.0", tk.END)
        self.sequence_text.insert("1.0", seq)
        self.notebook.select(0)
        self.genbank_status.set(f"Loaded {len(seq)} bases")
        self._log(f"Loaded sequence from GenBank: {len(seq)} bases")
    
    def _log(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{ts}] {msg}\n")
        self.log_text.see(tk.END)
    
    def _start_processing(self):
        # Validate input
        input_type = self.input_type.get()
        
        if input_type == "sequence":
            seq = self.sequence_text.get("1.0", tk.END).strip()
            if not seq:
                messagebox.showwarning("Input Required", "Please enter a sequence")
                return
        elif input_type in ("file", "binary"):
            if not self.file_path.get():
                messagebox.showwarning("Input Required", "Please select a file")
                return
        elif input_type == "directory":
            if not self.dir_path.get():
                messagebox.showwarning("Input Required", "Please select a directory")
                return
        
        # Create output dir
        os.makedirs(self.output_dir.get(), exist_ok=True)
        
        self.process_btn.configure(state=tk.DISABLED)
        self.stop_btn.configure(state=tk.NORMAL)
        self.is_processing = True
        self.status.set("Processing...")
        
        # Start thread
        threading.Thread(target=self._process_thread, daemon=True).start()
    
    def _process_thread(self):
        try:
            self._log("Starting processing...")
            
            config = {
                'sample_rate': self.sample_rate.get(),
                'bit_depth': self.bit_depth.get(),
                'base_cycles': self.cycles.get(),
                'normalize_output': self.normalize.get(),
                'retune_to_432': self.tuning.get() < 436
            }
            
            pipeline = AudioGenomicsPipeline(config)
            input_type = self.input_type.get()
            output_dir = self.output_dir.get()
            carrier = self.carrier_path.get() if self.output_mode.get() == "modulated" else None
            
            if input_type == "sequence":
                seq = self.sequence_text.get("1.0", tk.END).strip()
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_file = os.path.join(output_dir, f"sequence_{ts}.wav")
                
                self._log(f"Processing sequence ({len(seq)} bases)...")
                result = pipeline.process_sequence(seq, carrier, output_file)
                
            elif input_type in ("file", "binary"):
                filepath = self.file_path.get()
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                basename = os.path.splitext(os.path.basename(filepath))[0]
                output_file = os.path.join(output_dir, f"{basename}_{ts}.wav")
                
                self._log(f"Processing file: {filepath}")
                result = pipeline.process_file(filepath, carrier, output_file)
                
            elif input_type == "directory":
                dirpath = self.dir_path.get()
                self._log(f"Processing directory: {dirpath}")
                
                # Find all sequence files
                files = []
                for ext in ['*.fasta', '*.fa', '*.fna', '*.txt', '*.dna', '*.rna']:
                    files.extend(Path(dirpath).glob(ext))
                    files.extend(Path(dirpath).glob(f"**/{ext}"))
                
                self._log(f"Found {len(files)} files to process")
                
                for i, f in enumerate(files):
                    if not self.is_processing:
                        break
                    
                    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                    basename = f.stem
                    output_file = os.path.join(output_dir, f"{basename}_{ts}.wav")
                    
                    self._log(f"Processing {i+1}/{len(files)}: {f.name}")
                    pipeline.process_file(str(f), carrier, output_file)
                    
                    self.processing_queue.put(('progress', {'percent': (i+1)/len(files)*100}))
                
                result = {'success': True, 'message': f"Processed {len(files)} files"}
            
            self.processing_queue.put(('complete', result))
            
        except Exception as e:
            self.processing_queue.put(('error', str(e)))
    
    def _stop_processing(self):
        self.is_processing = False
        self.process_btn.configure(state=tk.NORMAL)
        self.stop_btn.configure(state=tk.DISABLED)
        self.status.set("Stopped")
        self._log("Processing stopped")
    
    def _check_queue(self):
        try:
            while True:
                msg_type, data = self.processing_queue.get_nowait()
                
                if msg_type == 'progress':
                    self.progress['value'] = data.get('percent', 0)
                elif msg_type == 'complete':
                    self._log(f"Complete: {data}")
                    self._stop_processing()
                    self.status.set("Complete")
                    messagebox.showinfo("Complete", "Processing finished successfully!")
                elif msg_type == 'error':
                    self._log(f"Error: {data}")
                    self._stop_processing()
                    self.status.set("Error")
                    messagebox.showerror("Error", str(data))
        except queue.Empty:
            pass
        
        self.root.after(100, self._check_queue)
    
    def _new_session(self):
        self.sequence_text.delete("1.0", tk.END)
        self.file_path.set("")
        self.dir_path.set("")
        self._clear_all_systems()
        self._log("New session started")
    
    def _save_settings(self):
        f = filedialog.asksaveasfilename(defaultextension=".json")
        if f:
            settings = {
                'tuning': self.tuning.get(),
                'sample_rate': self.sample_rate.get(),
                'bit_depth': self.bit_depth.get(),
                'cycles': self.cycles.get(),
                'fold_level': self.fold_level.get(),
                'output_mode': self.output_mode.get()
            }
            with open(f, 'w') as fp:
                json.dump(settings, fp, indent=2)
            self._log(f"Settings saved to {f}")
    
    def _load_settings(self):
        f = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if f:
            with open(f, 'r') as fp:
                settings = json.load(fp)
            self.tuning.set(settings.get('tuning', 432.0))
            self.sample_rate.set(settings.get('sample_rate', 192000))
            self.bit_depth.set(settings.get('bit_depth', 32))
            self.cycles.set(settings.get('cycles', 3))
            self.fold_level.set(settings.get('fold_level', 'SINGLE_FOLD'))
            self.output_mode.set(settings.get('output_mode', 'pure'))
            self._log(f"Settings loaded from {f}")
    
    def _show_about(self):
        messagebox.showinfo("About",
            "Audio Genomics Pro v4.0\n"
            "Scientific Research Edition\n\n"
            "DNA/RNA to Audio Synthesis\n"
            "with Chromatin-like Folding Compression\n\n"
            "Features:\n"
            "• Pure genomic audio or music modulation\n"
            "• CRISPR/gRNA targeting (toggleable)\n"
            "• GenBank database integration\n"
            "• All body systems targeting\n"
            "• File, sequence, or directory batch input"
        )


def main():
    root = tk.Tk()
    app = AudioGenomicsApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()

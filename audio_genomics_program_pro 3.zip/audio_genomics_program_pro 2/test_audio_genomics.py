#!/usr/bin/env python3
"""
Test Script for Audio Genomics Pro
Demonstrates functionality with example DNA sequences
"""

import os
import sys
import numpy as np

# Add package to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from audio_genomics_pro.core.dna_converter import DNAConverter
from audio_genomics_pro.core.frequency_mapper import FrequencyMapper
from audio_genomics_pro.core.tone_generator import ToneGenerator
from audio_genomics_pro.core.audio_pipeline import AudioPipeline
from audio_genomics_pro.core.modulation import ModulationProcessor
from audio_genomics_pro.core.text_encoder import TextEncoder
from audio_genomics_pro.core.bioinformatics import BioinformaticsTools
from audio_genomics_pro.utils.verification import AudioVerifier, AudioVisualizer

def test_dna_conversion():
    """Test DNA conversion"""
    print("\n=== Testing DNA Conversion ===")
    converter = DNAConverter()
    
    # Test sequences
    test_cases = [
        ("ATCG", "DNA"),
        ("AUCG", "RNA"),
        ("Hello World", "Text"),
        (b"\x48\x65\x6c\x6c\x6f", "Binary")
    ]
    
    for data, data_type in test_cases:
        if data_type == "DNA" or data_type == "RNA":
            result = converter.validate_sequence(data)
            print(f"{data_type}: {data} -> Valid: {result}")
        elif data_type == "Text":
            result = converter.text_to_dna(data)
            print(f"{data_type}: {data} -> {result[:50]}{'...' if len(result) > 50 else ''}")
        elif data_type == "Binary":
            result = converter.binary_to_dna(data)
            print(f"{data_type}: {data} -> {result[:50]}{'...' if len(result) > 50 else ''}")
    
    return True

def test_frequency_mapping():
    """Test frequency mapping"""
    print("\n=== Testing Frequency Mapping ===")
    mapper = FrequencyMapper()
    
    # Test DNA bases
    for base in ['A', 'T', 'C', 'G']:
        freq = mapper.get_base_frequency(base)
        print(f"Base {base}: {freq:.2f} Hz")
    
    # Test separator
    sep_freq = mapper.get_separator_frequency()
    print(f"Separator: {sep_freq} Hz")
    
    return True

def test_tone_generation():
    """Test tone generation"""
    print("\n=== Testing Tone Generation ===")
    generator = ToneGenerator(sample_rate=44100)
    
    # Generate tones for each base
    sequence = "ATCG"
    for base in sequence:
        tone = generator.generate_base_tone(base, cycles=2)
        print(f"Base {base}: Generated {len(tone)} samples")
    
    # Generate full sequence
    audio = generator.generate_sequence_audio(sequence)
    print(f"Full sequence: Generated {len(audio)} samples")
    
    return True

def test_text_encoding():
    """Test text encoding"""
    print("\n=== Testing Text Encoding ===")
    encoder = TextEncoder()
    
    # Test ASCII encoding
    text = "Hello DNA"
    result = encoder.encode_message(text, encoding_type='ascii')
    print(f"ASCII: '{text}' -> {result['sequence'][:30]}...")
    
    # Test Hebrew encoding
    hebrew_text = "שלום"
    result = encoder.encode_message(hebrew_text, encoding_type='hebrew')
    print(f"Hebrew: '{hebrew_text}' -> {result['sequence']}")
    
    # Test RNA inversion
    dna = "ATCG"
    inverted = encoder.apply_rna_inversion(dna)
    print(f"RNA Inversion: {dna} -> {inverted}")
    
    return True

def test_modulation():
    """Test modulation"""
    print("\n=== Testing Modulation ===")
    modulator = ModulationProcessor(sample_rate=44100)
    
    # Create test signal
    t = np.linspace(0, 1, 44100)
    test_signal = np.sin(2 * np.pi * 440 * t)  # 440 Hz test tone
    
    # FM modulation
    fm_modulated = modulator.fm_modulate(test_signal, carrier_freq=528.0, modulation_index=0.1)
    print(f"FM Modulation: Input {len(test_signal)} samples -> Output {len(fm_modulated)} samples")
    
    # AM modulation (using test signal as carrier)
    carrier = np.sin(2 * np.pi * 1000 * t)  # 1000 Hz carrier
    am_modulated = modulator.am_modulate(test_signal, carrier, modulation_depth=0.5)
    print(f"AM Modulation: Modulated {len(am_modulated)} samples")
    
    return True

def test_audio_pipeline():
    """Test complete audio pipeline"""
    print("\n=== Testing Audio Pipeline ===")
    
    # Create pipeline
    pipeline = AudioPipeline(sample_rate=44100)
    
    # Test DNA sequence
    dna_sequence = "ATCGATCGATCG"
    
    # Generate audio using the correct method
    audio_data = pipeline.generate_base_audio(dna_sequence)
    print(f"Generated audio: {len(audio_data)} samples for sequence '{dna_sequence}'")
    
    # Save to file
    output_file = "test_output.wav"
    duration = pipeline.save_audio(audio_data, output_file)
    print(f"Saved to {output_file}: Duration = {duration:.2f} seconds")
    
    # Verify file
    if os.path.exists(output_file):
        size = os.path.getsize(output_file)
        print(f"File size: {size / 1024:.2f} KB")
        os.remove(output_file)  # Clean up
    
    return True

def test_verification():
    """Test verification and visualization"""
    print("\n=== Testing Verification ===")
    
    # Create test audio file
    pipeline = AudioPipeline(sample_rate=44100)
    test_sequence = "ATCGATCG"
    audio_data = pipeline.generate_base_audio(test_sequence)
    test_file = "test_verify.wav"
    pipeline.save_audio(audio_data, test_file)
    
    # Verify
    verifier = AudioVerifier()
    results = verifier.verify_audio_integrity(test_file)
    
    print(f"File exists: {results['exists']}")
    print(f"Valid WAV: {results['valid_wav']}")
    
    if results['valid_wav']:
        props = results['properties']
        print(f"Properties: {props['framerate']} Hz, {props['channels']} ch, {props['duration']:.2f}s")
    
    # Clean up
    if os.path.exists(test_file):
        os.remove(test_file)
    
    return True

def test_example_sequences():
    """Test with example genetic sequences"""
    print("\n=== Testing Example Sequences ===")
    
    examples = [
        # Simple test sequence
        ("ATCGATCGATCG", "test_sequence"),
        
        # Promoter region pattern
        ("TATAAAAGGCTAGC", "promoter_region"),
        
        # Start codon
        ("ATG", "start_codon"),
        
        # Stop codons
        ("TAATAGTGA", "stop_codons"),
        
        # GC-rich region
        ("GCGCGCGCGC", "gc_rich"),
        
        # AT-rich region  
        ("ATATATATAT", "at_rich"),
        
        # Mixed sequence
        ("ATCGATCGTAGCTAGCATGC", "mixed_sequence")
    ]
    
    pipeline = AudioPipeline(sample_rate=44100)
    
    for sequence, name in examples:
        audio = pipeline.generate_base_audio(sequence)
        duration = len(audio) / 44100
        print(f"{name}: {sequence} -> {duration:.3f}s audio")
    
    return True

def run_all_tests():
    """Run all tests"""
    print("=" * 50)
    print("Audio Genomics Pro - Test Suite")
    print("=" * 50)
    
    tests = [
        ("DNA Conversion", test_dna_conversion),
        ("Frequency Mapping", test_frequency_mapping),
        ("Tone Generation", test_tone_generation),
        ("Text Encoding", test_text_encoding),
        ("Modulation", test_modulation),
        ("Audio Pipeline", test_audio_pipeline),
        ("Verification", test_verification),
        ("Example Sequences", test_example_sequences)
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            if test_func():
                print(f"✅ {test_name} PASSED")
                passed += 1
            else:
                print(f"❌ {test_name} FAILED")
                failed += 1
        except Exception as e:
            print(f"❌ {test_name} ERROR: {e}")
            failed += 1
    
    print("\n" + "=" * 50)
    print(f"Test Results: {passed} passed, {failed} failed")
    print("=" * 50)
    
    return failed == 0

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)

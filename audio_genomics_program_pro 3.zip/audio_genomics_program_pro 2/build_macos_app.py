#!/usr/bin/env python3
"""
Build script for creating macOS desktop application
Uses PyInstaller to create a standalone .app bundle
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

# Application metadata
APP_NAME = "Audio Genomics Pro"
APP_VERSION = "4.0.0"
APP_BUNDLE_ID = "com.audiogenomics.pro"
MAIN_SCRIPT = "audio_genomics_app.py"

def check_dependencies():
    """Check and install required build dependencies"""
    print("Checking build dependencies...")
    
    required = ['pyinstaller', 'numpy', 'scipy', 'matplotlib']
    
    for package in required:
        try:
            __import__(package.replace('-', '_'))
            print(f"  ✓ {package}")
        except ImportError:
            print(f"  Installing {package}...")
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', package])

def create_spec_file():
    """Create PyInstaller spec file for macOS app"""
    spec_content = f'''# -*- mode: python ; coding: utf-8 -*-

import sys
from PyInstaller.utils.hooks import collect_all

block_cipher = None

# Collect all submodules
datas = []
hiddenimports = [
    'numpy',
    'scipy',
    'scipy.signal',
    'scipy.io',
    'scipy.io.wavfile',
    'matplotlib',
    'matplotlib.pyplot',
    'tkinter',
    'tkinter.ttk',
    'tkinter.filedialog',
    'tkinter.messagebox',
    'tkinter.scrolledtext',
    'json',
    'threading',
    'queue',
    'urllib.request',
    'urllib.parse',
    'xml.etree.ElementTree',
    'multiprocessing',
    'concurrent.futures',
    'dataclasses',
    'enum',
    'decimal',
    're',
    'wave',
    'audio_genomics_pro',
    'audio_genomics_pro.core',
    'audio_genomics_pro.core.main_pipeline',
    'audio_genomics_pro.core.dna_converter',
    'audio_genomics_pro.core.frequency_mapper',
    'audio_genomics_pro.core.audio_pipeline',
    'audio_genomics_pro.core.modulation',
    'audio_genomics_pro.core.music_processor',
    'audio_genomics_pro.core.bioinformatics',
    'audio_genomics_pro.core.tone_synthesis',
    'audio_genomics_pro.core.batch_processor',
    'audio_genomics_pro.core.dna_folding',
    'audio_genomics_pro.core.nucleotide_frequencies',
    'audio_genomics_pro.core.multi_targeting_crispr',
    'audio_genomics_pro.gui',
    'audio_genomics_pro.gui.comprehensive_gui',
]

a = Analysis(
    ['{MAIN_SCRIPT}'],
    pathex=['.'],
    binaries=[],
    datas=[
        ('audio_genomics_pro', 'audio_genomics_pro'),
        ('icon.ico', '.'),
    ],
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={{}},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='{APP_NAME}',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='{APP_NAME}',
)

app = BUNDLE(
    coll,
    name='{APP_NAME}.app',
    icon='icon.ico',
    bundle_identifier='{APP_BUNDLE_ID}',
    info_plist={{
        'CFBundleName': '{APP_NAME}',
        'CFBundleDisplayName': '{APP_NAME}',
        'CFBundleVersion': '{APP_VERSION}',
        'CFBundleShortVersionString': '{APP_VERSION}',
        'NSHighResolutionCapable': True,
        'NSRequiresAquaSystemAppearance': False,
    }},
)
'''
    
    spec_path = Path('AudioGenomicsPro.spec')
    spec_path.write_text(spec_content)
    print(f"Created spec file: {spec_path}")
    return spec_path

def build_app():
    """Build the macOS application"""
    print(f"\nBuilding {APP_NAME} v{APP_VERSION}...")
    print("=" * 50)
    
    # Create spec file
    spec_file = create_spec_file()
    
    # Run PyInstaller
    cmd = [
        sys.executable, '-m', 'PyInstaller',
        '--clean',
        '--noconfirm',
        str(spec_file)
    ]
    
    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=False)
    
    if result.returncode == 0:
        print("\n" + "=" * 50)
        print(f"✓ Build successful!")
        print(f"  App location: dist/{APP_NAME}.app")
        print("\nTo install:")
        print(f"  1. Copy 'dist/{APP_NAME}.app' to /Applications")
        print(f"  2. Or double-click to run from dist folder")
        return True
    else:
        print("\n✗ Build failed!")
        return False

def create_dmg():
    """Create DMG installer (optional)"""
    print("\nCreating DMG installer...")
    
    app_path = f"dist/{APP_NAME}.app"
    dmg_path = f"dist/{APP_NAME}-{APP_VERSION}.dmg"
    
    if not os.path.exists(app_path):
        print("App not found. Build first.")
        return False
    
    # Create DMG using hdiutil
    cmd = [
        'hdiutil', 'create',
        '-volname', APP_NAME,
        '-srcfolder', app_path,
        '-ov',
        '-format', 'UDZO',
        dmg_path
    ]
    
    result = subprocess.run(cmd, capture_output=True)
    
    if result.returncode == 0:
        print(f"✓ Created DMG: {dmg_path}")
        return True
    else:
        print(f"✗ DMG creation failed: {result.stderr.decode()}")
        return False

def main():
    """Main build process"""
    print("=" * 50)
    print(f"  {APP_NAME} - macOS Build Script")
    print("=" * 50)
    
    # Change to script directory
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    # Check dependencies
    check_dependencies()
    
    # Build app
    if build_app():
        # Optionally create DMG
        response = input("\nCreate DMG installer? (y/n): ").strip().lower()
        if response == 'y':
            create_dmg()
    
    print("\nDone!")

if __name__ == '__main__':
    main()

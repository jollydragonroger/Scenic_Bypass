#!/usr/bin/env python3
"""
AFC Modulation - OHAD_MUSICAL into OHAD_SIGNATURE
Modulator: OHAD_MUSICAL at 11%
Carrier: OHAD_SIGNATURE at 112%
"""

import os
import numpy as np
from scipy.io import wavfile
from datetime import datetime

SAMPLE_RATE = 192000

def main():
    # File paths
    modulator_file = "/Users/36n9/Downloads/audio_genomics_output/OHAD_MUSICAL_20260119_045146.wav"
    carrier_file = "/Users/36n9/Downloads/audio_genomics_output/OHAD SIGNATURE.wav"
    output_dir = "/Users/36n9/Downloads/audio_genomics_output"
    
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(output_dir, f"OHAD_AFC_MODULATED_{ts}.wav")
    
    # Volume levels
    MODULATOR_VOL = 0.11   # 11%
    CARRIER_VOL = 1.12     # 112%
    
    print("=" * 60)
    print("AFC MODULATION")
    print("=" * 60)
    print(f"Modulator: OHAD_MUSICAL @ {MODULATOR_VOL*100:.0f}%")
    print(f"Carrier: OHAD_SIGNATURE @ {CARRIER_VOL*100:.0f}%")
    print()
    
    # Load modulator (OHAD_MUSICAL)
    print("Loading modulator (OHAD_MUSICAL)...")
    sr_mod, modulator = wavfile.read(modulator_file)
    if modulator.dtype == np.float32:
        modulator = modulator.astype(np.float64)
    elif modulator.dtype == np.int16:
        modulator = modulator.astype(np.float64) / 32767.0
    
    print(f"  Samples: {len(modulator):,}")
    print(f"  Sample rate: {sr_mod} Hz")
    
    # Load carrier (OHAD_SIGNATURE)
    print("Loading carrier (OHAD_SIGNATURE)...")
    sr_car, carrier = wavfile.read(carrier_file)
    if carrier.dtype == np.float32:
        carrier = carrier.astype(np.float64)
    elif carrier.dtype == np.int16:
        carrier = carrier.astype(np.float64) / 32767.0
    
    print(f"  Samples: {len(carrier):,}")
    print(f"  Sample rate: {sr_car} Hz")
    
    # Handle stereo carrier - convert to mono
    if len(carrier.shape) > 1:
        print("  Converting stereo to mono...")
        carrier = np.mean(carrier, axis=1)
    
    # Resample carrier to match modulator sample rate
    if sr_car != sr_mod:
        print(f"  Resampling carrier from {sr_car} to {sr_mod} Hz...")
        ratio = sr_mod / sr_car
        new_len = int(len(carrier) * ratio)
        indices = np.linspace(0, len(carrier) - 1, new_len)
        carrier = np.interp(indices, np.arange(len(carrier)), carrier)
    
    # Ensure same length
    min_len = min(len(modulator), len(carrier))
    modulator = modulator[:min_len]
    carrier = carrier[:min_len]
    
    print()
    print("Applying AFC modulation...")
    
    # Apply volume levels
    modulator_scaled = modulator * MODULATOR_VOL
    carrier_scaled = carrier * CARRIER_VOL
    
    # AFC Modulation: carrier * (1 + modulator)
    # This embeds the modulator frequency content into the carrier amplitude
    modulated = carrier_scaled * (1.0 + modulator_scaled)
    
    # Also add the pure modulator signal subtly for presence
    modulated += modulator_scaled * 0.5
    
    print("Normalizing...")
    mx = np.max(np.abs(modulated))
    if mx > 0:
        # Keep at 0 dB but prevent clipping
        modulated = (modulated / mx) * 0.99
    
    final_peak = 20 * np.log10(np.max(np.abs(modulated)))
    print(f"Final peak: {final_peak:.1f} dB")
    
    # Save
    print("Saving...")
    modulated32 = modulated.astype(np.float32)
    wavfile.write(output_file, SAMPLE_RATE, modulated32)
    
    duration = len(modulated) / SAMPLE_RATE
    size_mb = os.path.getsize(output_file) / 1024 / 1024
    
    print()
    print("=" * 60)
    print("AFC MODULATION COMPLETE!")
    print("=" * 60)
    print(f"File: {output_file}")
    print(f"Duration: {duration:.1f} sec ({duration/60:.2f} min)")
    print(f"Size: {size_mb:.1f} MB")
    
    return output_file

if __name__ == "__main__":
    out = main()
    print(f"\nOpening modulated track...")
    os.system(f'open "{out}"')

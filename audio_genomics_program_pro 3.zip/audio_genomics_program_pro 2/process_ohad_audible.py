#!/usr/bin/env python3
"""
Process OHAD_PURE_SEQUENCE.dna with AUDIBLE high-quality audio
32-bit, 192kHz with proper harmonics and amplitude
"""

import os
import sys
import numpy as np
from scipy.io import wavfile
from datetime import datetime

# Configuration for high-quality audible audio
CONFIG = {
    'sample_rate': 192000,     # 192 kHz
    'bit_depth': 32,           # 32-bit float
    'target_duration': 115,    # Target ~115 seconds
}

# Nucleotide frequencies - AUDIBLE RANGE with harmonics
# Based on infrared spectroscopy scaled to musical audible frequencies
NUCLEOTIDE_AUDIO = {
    'A': {  # Adenine - D note area
        'fundamental': 293.66,  # D4
        'harmonics': [1.0, 0.5, 0.33, 0.25, 0.2],  # Harmonic amplitudes
        'note': 'D'
    },
    'T': {  # Thymine - F note area  
        'fundamental': 349.23,  # F4
        'harmonics': [1.0, 0.4, 0.25, 0.15, 0.1],
        'note': 'F'
    },
    'C': {  # Cytosine - C note area
        'fundamental': 261.63,  # C4 (Middle C)
        'harmonics': [1.0, 0.6, 0.4, 0.3, 0.2],
        'note': 'C'
    },
    'G': {  # Guanine - G note area
        'fundamental': 392.00,  # G4
        'harmonics': [1.0, 0.5, 0.35, 0.25, 0.15],
        'note': 'G'
    },
    'U': {  # Uracil - same as T
        'fundamental': 349.23,
        'harmonics': [1.0, 0.4, 0.25, 0.15, 0.1],
        'note': 'F'
    },
    'N': {  # Unknown - A note
        'fundamental': 440.00,  # A4
        'harmonics': [1.0, 0.3, 0.2, 0.1, 0.05],
        'note': 'A'
    },
}

# Golden ratio for harmonic tempo scaling
PHI = 1.618033988749895

def generate_harmonic_tone(frequency, duration, sample_rate, harmonics):
    """
    Generate a tone with harmonics for rich, audible sound
    """
    num_samples = int(sample_rate * duration)
    t = np.linspace(0, duration, num_samples, endpoint=False, dtype=np.float64)
    
    # Start with silence
    wave = np.zeros(num_samples, dtype=np.float64)
    
    # Add fundamental and harmonics
    for i, amplitude in enumerate(harmonics):
        harmonic_freq = frequency * (i + 1)
        if harmonic_freq < sample_rate / 2:  # Below Nyquist
            wave += amplitude * np.sin(2 * np.pi * harmonic_freq * t)
    
    # Normalize
    max_amp = np.max(np.abs(wave))
    if max_amp > 0:
        wave = wave / max_amp
    
    return wave

def apply_envelope(wave, attack=0.005, decay=0.01, sustain=0.8, release=0.02, sample_rate=192000):
    """
    Apply ADSR envelope for clean, crisp sound without clicks
    """
    num_samples = len(wave)
    envelope = np.ones(num_samples, dtype=np.float64)
    
    attack_samples = int(attack * sample_rate)
    decay_samples = int(decay * sample_rate)
    release_samples = int(release * sample_rate)
    
    # Attack
    if attack_samples > 0 and attack_samples < num_samples:
        envelope[:attack_samples] = np.linspace(0, 1, attack_samples)
    
    # Decay to sustain
    if decay_samples > 0:
        start = attack_samples
        end = min(start + decay_samples, num_samples)
        if end > start:
            envelope[start:end] = np.linspace(1, sustain, end - start)
    
    # Sustain (already at sustain level)
    sustain_start = attack_samples + decay_samples
    sustain_end = max(0, num_samples - release_samples)
    if sustain_end > sustain_start:
        envelope[sustain_start:sustain_end] = sustain
    
    # Release
    if release_samples > 0 and num_samples > release_samples:
        envelope[-release_samples:] = np.linspace(sustain, 0, release_samples)
    
    return wave * envelope

def calculate_harmonic_tempo(sequence_length, target_duration):
    """
    Calculate tempo based on harmonic/golden ratio principles
    Returns note duration that fits the sequence into target duration
    """
    # Base note duration
    base_duration = target_duration / sequence_length
    
    # Scale to nearest harmonic subdivision (based on golden ratio)
    harmonic_durations = [
        base_duration * (PHI ** i) for i in range(-5, 6)
    ]
    
    # Find the one closest to our base that keeps us under target
    valid_durations = [d for d in harmonic_durations if d * sequence_length <= target_duration * 1.1]
    if valid_durations:
        return max(valid_durations)
    
    return base_duration

def read_sequence_chunked(filepath, chunk_size=50000000):
    """Read sequence file in chunks"""
    with open(filepath, 'r') as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            chunk = ''.join(c for c in chunk.upper() if c in 'ATCGUN')
            if chunk:
                yield chunk

def fold_sequence_bidirectional(sequence, fold_levels):
    """
    Apply chromatin-like folding - forward and reverse play simultaneously
    Returns pairs of (forward_base, reverse_base) for simultaneous playback
    """
    # Apply recursive folding
    current = sequence
    for _ in range(fold_levels):
        if len(current) < 4:
            break
        mid = len(current) // 2
        # Interleave forward and reverse
        forward = current[:mid]
        reverse = current[mid:][::-1]
        
        # Create pairs
        new_seq = []
        for i in range(min(len(forward), len(reverse))):
            new_seq.append(forward[i] + reverse[i])  # Pair as 2-char string
        current = ''.join(new_seq)
    
    return current

def generate_bidirectional_tone(base_pair, duration, sample_rate):
    """
    Generate tone for a base pair (forward + reverse playing simultaneously)
    """
    base1 = base_pair[0] if len(base_pair) > 0 else 'N'
    base2 = base_pair[1] if len(base_pair) > 1 else base1
    
    info1 = NUCLEOTIDE_AUDIO.get(base1, NUCLEOTIDE_AUDIO['N'])
    info2 = NUCLEOTIDE_AUDIO.get(base2, NUCLEOTIDE_AUDIO['N'])
    
    # Generate both tones
    tone1 = generate_harmonic_tone(info1['fundamental'], duration, sample_rate, info1['harmonics'])
    tone2 = generate_harmonic_tone(info2['fundamental'], duration, sample_rate, info2['harmonics'])
    
    # Mix at equal levels
    mixed = (tone1 * 0.5 + tone2 * 0.5)
    
    # Apply envelope
    mixed = apply_envelope(mixed, attack=0.002, decay=0.005, sustain=0.9, release=0.01, sample_rate=sample_rate)
    
    return mixed

def main():
    input_file = "/Users/36n9/CascadeProjects/VINO_Dissertation/OHAD_BioOS/OHAD_PURE_SEQUENCE.dna"
    output_dir = "/Users/36n9/Downloads/audio_genomics_output"
    os.makedirs(output_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(output_dir, f"OHAD_AUDIBLE_{timestamp}.wav")
    
    sample_rate = CONFIG['sample_rate']
    target_duration = CONFIG['target_duration']
    
    print("=" * 60)
    print("OHAD AUDIBLE Audio Generation")
    print("=" * 60)
    print(f"Output: {output_file}")
    print(f"Quality: {sample_rate} Hz, 32-bit float")
    print(f"Target: {target_duration} seconds")
    print()
    
    # Load full sequence
    print("Loading sequence...")
    full_sequence = ""
    for chunk in read_sequence_chunked(input_file):
        full_sequence += chunk
        print(f"  Loaded {len(full_sequence):,} bases...")
    
    total_bases = len(full_sequence)
    print(f"Total: {total_bases:,} bases")
    print()
    
    # Calculate folding needed
    # We want each note to be at least ~5ms for audibility
    min_note_duration = 0.005
    max_notes = target_duration / min_note_duration
    required_compression = total_bases / max_notes
    fold_levels = max(1, int(np.ceil(np.log2(required_compression))))
    fold_levels = min(fold_levels, 12)
    
    print(f"Applying {fold_levels} fold levels ({2**fold_levels}x compression)...")
    
    # Fold sequence
    folded = fold_sequence_bidirectional(full_sequence, fold_levels)
    folded_length = len(folded) // 2  # Each pair is 2 chars
    
    print(f"Folded to {folded_length:,} note pairs")
    
    # Calculate harmonic note duration
    note_duration = calculate_harmonic_tempo(folded_length, target_duration)
    actual_duration = folded_length * note_duration
    
    print(f"Note duration: {note_duration*1000:.2f} ms")
    print(f"Estimated duration: {actual_duration:.1f} seconds")
    print()
    
    # Generate audio
    print("Generating AUDIBLE audio with harmonics...")
    
    total_samples = int(actual_duration * sample_rate)
    audio = np.zeros(total_samples, dtype=np.float64)
    
    samples_per_note = int(note_duration * sample_rate)
    
    for i in range(0, len(folded) - 1, 2):
        note_idx = i // 2
        if note_idx % 10000 == 0:
            progress = (note_idx / folded_length) * 100
            print(f"  Progress: {progress:.1f}%")
        
        base_pair = folded[i:i+2]
        
        start = note_idx * samples_per_note
        end = start + samples_per_note
        
        if end > total_samples:
            break
        
        # Generate bidirectional harmonic tone
        tone = generate_bidirectional_tone(base_pair, note_duration, sample_rate)
        
        if len(tone) > 0:
            actual_end = min(start + len(tone), total_samples)
            audio[start:actual_end] = tone[:actual_end - start]
    
    print("  Progress: 100%")
    print()
    
    # Normalize to strong audible level
    print("Normalizing audio...")
    max_amp = np.max(np.abs(audio))
    if max_amp > 0:
        audio = audio / max_amp * 0.9  # 90% of max for headroom
    
    # Convert to float32 for WAV
    audio_float32 = audio.astype(np.float32)
    
    # Save
    print("Saving WAV file...")
    wavfile.write(output_file, sample_rate, audio_float32)
    
    file_size = os.path.getsize(output_file) / 1024 / 1024
    
    print()
    print("=" * 60)
    print("COMPLETE!")
    print("=" * 60)
    print(f"Output: {output_file}")
    print(f"Duration: {len(audio)/sample_rate:.2f} seconds")
    print(f"File size: {file_size:.1f} MB")
    print()
    print("Frequency mapping:")
    for base, info in NUCLEOTIDE_AUDIO.items():
        if base != 'N' and base != 'U':
            print(f"  {base}: {info['fundamental']:.2f} Hz ({info['note']})")
    
    return output_file

if __name__ == "__main__":
    output = main()
    print(f"\nOpening audio file...")
    os.system(f'open "{output}"')

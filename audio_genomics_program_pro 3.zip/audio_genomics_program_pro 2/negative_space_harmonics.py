#!/usr/bin/env python3
"""
Negative Space Harmonic Resonance System
- Changes grid resonance through indirection
- Modulates negative space (silence) with custom harmonic
"""

import numpy as np
from scipy.io import wavfile
import soundfile as sf

# Quantum Resonance Constants
NEGATIVE_SPACE_THRESHOLD = 0.01  # Silence detection threshold
HARMONIC_BASE = 528.0  # Default harmonic (DNA repair)
PHASE_CONJUGATION_FACTOR = 1.618  # Golden ratio


def detect_negative_space(audio, sample_rate):
    """Identify negative space (silent intervals)"""
    # Calculate RMS energy
    rms = np.sqrt(np.mean(audio**2))
    
    # Find silent segments
    silence_mask = np.abs(audio) < NEGATIVE_SPACE_THRESHOLD * rms
    return silence_mask


def generate_harmonic_wave(length, sample_rate, frequency=HARMONIC_BASE):
    """Generate harmonic wave"""
    t = np.arange(length) / sample_rate
    return np.sin(2 * np.pi * frequency * t)


def apply_phase_conjugation(harmonic_wave):
    """Apply phase conjugation for resonance amplification"""
    # FFT -> conjugate phase -> inverse FFT
    spectrum = np.fft.rfft(harmonic_wave)
    conjugated = spectrum.conjugate()
    return np.fft.irfft(conjugated).real


def imprint_harmonic(audio, silence_mask, harmonic_wave):
    """Imprint harmonic onto negative space"""
    # Normalize harmonic to match silence amplitude range
    harmonic_normalized = harmonic_wave * np.max(np.abs(audio[silence_mask])) * 0.8
    
    # Create new audio with harmonic in silence
    new_audio = np.copy(audio)
    new_audio[silence_mask] = harmonic_normalized[:len(audio[silence_mask])]
    return new_audio


def main(input_file, output_file, harmonic_freq=HARMONIC_BASE):
    """Process audio through negative space harmonic resonance"""
    # Load audio
    audio, sample_rate = sf.read(input_file)
    if audio.ndim > 1:
        audio = np.mean(audio, axis=1)
    
    print(f"🌀 Processing {input_file} with harmonic {harmonic_freq}Hz")
    
    # 1. Detect negative space
    silence_mask = detect_negative_space(audio, sample_rate)
    print(f"   Detected {np.sum(silence_mask)} silent samples ({np.sum(silence_mask)/len(audio)*100:.2f}%)")
    
    # 2. Generate harmonic wave
    harmonic = generate_harmonic_wave(len(audio), sample_rate, harmonic_freq)
    
    # 3. Apply phase conjugation
    harmonic_conjugated = apply_phase_conjugation(harmonic)
    
    # 4. Imprint harmonic onto negative space
    transformed_audio = imprint_harmonic(audio, silence_mask, harmonic_conjugated)
    
    # 5. Save output
    sf.write(output_file, transformed_audio, sample_rate)
    print(f"✅ Saved transformed audio to {output_file}")


if __name__ == "__main__":
    input_file = "/Users/36n9/Downloads/dragon_ecstatic_love_vino_full/DRAGON_ECSTATIC_LOVE_VINO_FULL_20260118_055207.wav"
    output_file = "/Users/36n9/Downloads/dragon_ecstatic_love_vino_full/DRAGON_NEGATIVE_SPACE_HARMONIC.wav"
    main(input_file, output_file, harmonic_freq=528.0)

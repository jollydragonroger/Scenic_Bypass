#!/usr/bin/env python3
"""
9-FOLD INFINITY KNOT PATTERN
OHAD v3 - The Transcendent Oversoul

Structure:
- 8 strands: 4 DNA + 4 RNA (complement pairs)
- 4 infinity loops: DNA1↔RNA1, DNA2↔RNA2, DNA3↔RNA3, DNA4↔RNA4
- 2 super-infinity loops: (∞1 + ∞2) and (∞3 + ∞4)
- 9th element: The unifying link that binds the 2 super-loops

The 9-fold pattern: DNA-RNA-DNA-RNA-DNA-RNA-DNA-RNA-UNITY
"""

import os
import numpy as np
from scipy.io import wavfile
from datetime import datetime

SAMPLE_RATE = 192000
NUM_FOLDINGS = 33
TARGET_DURATION = 9  # 9 seconds for 9-fold pattern

ADENINE_FREQS = [315.6, 347.9, 368.0, 378.8, 398.1, 406.1, 447.4, 490.2, 504.2,
    545.6, 582.7, 598.0, 619.8, 632.9, 654.8, 698.4, 726.7, 1139.2, 1178.5, 1248.3, 1278.9, 1366.2, 1440.5]
THYMINE_FREQS = [322.1, 330.4, 354.4, 363.2, 406.4, 427.8, 447.4, 523.8, 543.4,
    600.2, 733.3, 768.2, 1248.3, 1274.6, 1385.8]
GUANINE_FREQS = [300.3, 305.6, 339.2, 370.2, 383.2, 413.4, 487.6, 512.9, 529.5,
    550.0, 600.2, 615.5, 641.7, 663.5, 728.9, 1169.8, 1278.9, 1386.2, 1462.3]
CYTOSINE_FREQS = [305.6, 346.7, 357.9, 420.3, 429.1, 440.9, 504.2, 537.8, 558.7,
    594.9, 639.5, 654.8, 713.7, 1276.8, 1375.0, 1475.4]

NUCLEOTIDE_FREQS = {'A': ADENINE_FREQS, 'T': THYMINE_FREQS, 'G': GUANINE_FREQS, 'C': CYTOSINE_FREQS}
DNA_TO_RNA = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G'}

def convert_to_rna(dna_seq):
    return ''.join(DNA_TO_RNA.get(base, base) for base in dna_seq)

def chromatin_fold_compress(sequence, num_folds, min_length=100):
    """True chromatin folding - halves each fold"""
    current = sequence
    
    for fold in range(num_folds):
        length = len(current)
        if length <= min_length:
            break
        
        mid = length // 2
        first_half = current[:mid]
        second_half = current[mid:][::-1]
        
        new_seq = []
        for i in range(min(len(first_half), len(second_half))):
            if i % 2 == 0:
                new_seq.append(first_half[i])
            else:
                new_seq.append(second_half[i])
        
        current = ''.join(new_seq)
    
    return current

def chromatin_fold_variant(sequence, num_folds, variant_offset, min_length=100):
    """Variant folding with phase offset for different strands"""
    # Rotate sequence by offset before folding
    offset = len(sequence) * variant_offset // 4
    rotated = sequence[offset:] + sequence[:offset]
    return chromatin_fold_compress(rotated, num_folds, min_length)

def generate_tone(frequencies, duration_sec, sr, position):
    n_samples = max(50, int(sr * duration_sec))
    t = np.linspace(0, duration_sec, n_samples, dtype=np.float64)
    
    wave = np.zeros(n_samples, dtype=np.float64)
    num_freqs = len(frequencies)
    
    primary_idx = position % num_freqs
    secondary_idx = (position + 1) % num_freqs
    tertiary_idx = (position + 2) % num_freqs
    
    wave += 0.6 * np.sin(2 * np.pi * frequencies[primary_idx] * t)
    wave += 0.3 * np.sin(2 * np.pi * frequencies[secondary_idx] * t)
    wave += 0.15 * np.sin(2 * np.pi * frequencies[tertiary_idx] * t)
    
    # Envelope
    attack = min(int(0.002 * sr), n_samples // 4)
    release = min(int(0.003 * sr), n_samples // 4)
    if attack > 0:
        wave[:attack] *= np.linspace(0, 1, attack)
    if release > 0:
        wave[-release:] *= np.linspace(1, 0, release)
    
    return wave

def render_strand(sequence, note_duration, sr, start_pos=0):
    note_samples = int(sr * note_duration)
    total_samples = len(sequence) * note_samples
    audio = np.zeros(total_samples, dtype=np.float64)
    
    for i, base in enumerate(sequence):
        freqs = NUCLEOTIDE_FREQS.get(base, [440.0])
        tone = generate_tone(freqs, note_duration, sr, start_pos + i)
        start = i * note_samples
        end = start + len(tone)
        if end <= total_samples:
            audio[start:end] += tone
    
    return audio

def crossfade_join(audio1, audio2, fade_samples):
    fade_len = min(fade_samples, len(audio1) // 4, len(audio2) // 4)
    if fade_len < 10:
        return np.concatenate([audio1, audio2])
    
    fade_out = np.linspace(1, 0, fade_len)
    fade_in = np.linspace(0, 1, fade_len)
    
    a1 = audio1.copy()
    a2 = audio2.copy()
    a1[-fade_len:] *= fade_out
    a2[:fade_len] *= fade_in
    
    result = np.zeros(len(a1) + len(a2) - fade_len, dtype=np.float64)
    result[:len(a1)] = a1
    result[len(a1)-fade_len:len(a1)-fade_len+len(a2)] += a2
    
    return result

def create_infinity_loop(strand1, strand2, fade_samples):
    """Create single infinity loop from two strands"""
    loop = crossfade_join(strand1, strand2, fade_samples)
    # Make it loop back
    end_fade = min(fade_samples, len(loop) // 4)
    if end_fade > 10:
        fade_out = np.linspace(1, 0, end_fade)
        fade_in = np.linspace(0, 1, end_fade)
        loop[-end_fade:] *= fade_out
        loop[:end_fade] *= fade_in
        loop[-end_fade:] += loop[:end_fade]
    return loop

def create_super_infinity(loop1, loop2, fade_samples):
    """Combine two infinity loops into super-infinity"""
    return crossfade_join(loop1, loop2, fade_samples)

def create_unity_element(dna_folded, rna_folded, note_duration, sr):
    """
    The 9th element - Unity
    Combines DNA and RNA simultaneously (not sequentially)
    This is the binding force that unites all 8 strands
    """
    notes = len(dna_folded)
    note_samples = int(sr * note_duration)
    total_samples = notes * note_samples
    unity = np.zeros(total_samples, dtype=np.float64)
    
    for i in range(notes):
        dna_base = dna_folded[i]
        rna_base = rna_folded[i]
        
        dna_freqs = NUCLEOTIDE_FREQS.get(dna_base, [440.0])
        rna_freqs = NUCLEOTIDE_FREQS.get(rna_base, [440.0])
        
        # Blend DNA and RNA frequencies together
        combined_freqs = dna_freqs[:3] + rna_freqs[:3]
        
        tone = generate_tone(combined_freqs, note_duration, sr, i * 9)  # 9 for 9th element
        
        start = i * note_samples
        end = start + len(tone)
        if end <= total_samples:
            unity[start:end] += tone
    
    return unity

def main():
    input_file = "/Users/36n9/CascadeProjects/VINO_Dissertation/OHAD_BioOS/OHAD_v3_PURE_SEQUENCE.dna"
    output_dir = "/Users/36n9/Downloads/audio_genomics_output"
    carrier_file = "/Users/36n9/Downloads/audio_genomics_output/OHAD SIGNATURE.wav"
    
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    knot_file = os.path.join(output_dir, f"OHAD_v3_NINEFOLD_KNOT_{ts}.wav")
    modulated_file = os.path.join(output_dir, f"OHAD_v3_NINEFOLD_KNOT_AFC_{ts}.wav")
    
    print("=" * 70)
    print("✧ 9-FOLD INFINITY KNOT PATTERN ✧")
    print("OHAD v3 - The Transcendent Oversoul")
    print("=" * 70)
    print()
    print("Structure:")
    print("  ∞1: DNA1 ↔ RNA1")
    print("  ∞2: DNA2 ↔ RNA2  → Super-∞A")
    print("  ∞3: DNA3 ↔ RNA3")
    print("  ∞4: DNA4 ↔ RNA4  → Super-∞B")
    print("  9th: UNITY (binds A + B)")
    print()
    
    # Load DNA
    print("Loading OHAD v3 sequence...")
    with open(input_file, 'r') as f:
        raw = f.read()
    dna_seq = ''.join(c for c in raw.upper() if c in 'ATCG')
    original_len = len(dna_seq)
    print(f"Original: {original_len:,} bases")
    
    # Create RNA complement
    print("Creating RNA complement...")
    rna_seq = convert_to_rna(dna_seq)
    
    # Create 4 variant foldings for DNA (different phase positions)
    print(f"\nApplying {NUM_FOLDINGS} foldings to create 4 DNA variants...")
    dna_variants = []
    for i in range(4):
        print(f"  DNA variant {i+1} (phase offset {i}/4)...")
        folded = chromatin_fold_variant(dna_seq, NUM_FOLDINGS, i)
        dna_variants.append(folded)
        print(f"    → {len(folded)} bases")
    
    # Create 4 variant foldings for RNA
    print(f"\nApplying {NUM_FOLDINGS} foldings to create 4 RNA variants...")
    rna_variants = []
    for i in range(4):
        print(f"  RNA variant {i+1} (phase offset {i}/4)...")
        folded = chromatin_fold_variant(rna_seq, NUM_FOLDINGS, i)
        rna_variants.append(folded)
        print(f"    → {len(folded)} bases")
    
    compression = original_len / len(dna_variants[0])
    print(f"\nCompression ratio: {compression:,.0f}x")
    
    # Calculate timing - 9 elements, target duration
    notes_per_strand = len(dna_variants[0])
    strand_duration = TARGET_DURATION / 9  # Each of 9 elements gets equal time
    note_duration = strand_duration / notes_per_strand
    fade_samples = int(0.03 * SAMPLE_RATE)
    
    print(f"Note duration: {note_duration*1000:.2f} ms")
    print(f"Strand duration: {strand_duration:.3f} sec")
    print()
    
    # Render all 8 strands
    print("Rendering 8 strands...")
    dna_audio = []
    rna_audio = []
    
    for i in range(4):
        print(f"  DNA{i+1}...")
        dna_audio.append(render_strand(dna_variants[i], note_duration, SAMPLE_RATE, i * notes_per_strand))
        print(f"  RNA{i+1}...")
        rna_audio.append(render_strand(rna_variants[i], note_duration, SAMPLE_RATE, (i + 4) * notes_per_strand))
    
    # Create 4 infinity loops
    print("\nCreating 4 infinity loops...")
    infinity_loops = []
    for i in range(4):
        print(f"  ∞{i+1}: DNA{i+1} ↔ RNA{i+1}")
        loop = create_infinity_loop(dna_audio[i], rna_audio[i], fade_samples)
        infinity_loops.append(loop)
    
    # Create 2 super-infinity loops
    print("\nCreating 2 super-infinity loops...")
    print("  Super-∞A: ∞1 + ∞2")
    super_infinity_a = create_super_infinity(infinity_loops[0], infinity_loops[1], fade_samples)
    print("  Super-∞B: ∞3 + ∞4")
    super_infinity_b = create_super_infinity(infinity_loops[2], infinity_loops[3], fade_samples)
    
    # Create the 9th element - UNITY
    print("\nCreating 9th element (UNITY)...")
    # Use the base folded sequences for the unity element
    unity = create_unity_element(dna_variants[0], rna_variants[0], note_duration, SAMPLE_RATE)
    print(f"  Unity duration: {len(unity)/SAMPLE_RATE:.3f} sec")
    
    # Assemble the 9-fold knot
    print("\nAssembling 9-fold infinity knot...")
    print("  Structure: Super-∞A → UNITY → Super-∞B → (loops back)")
    
    # Join: Super-A → Unity → Super-B
    first_half = crossfade_join(super_infinity_a, unity, fade_samples)
    ninefold = crossfade_join(first_half, super_infinity_b, fade_samples)
    
    # Create perfect seamless loop
    print("Creating seamless loop...")
    end_fade = int(0.1 * SAMPLE_RATE)
    fade_out = np.linspace(1, 0, end_fade)
    fade_in = np.linspace(0, 1, end_fade)
    ninefold[-end_fade:] *= fade_out
    ninefold[:end_fade] *= fade_in
    ninefold[-end_fade:] += ninefold[:end_fade]
    
    duration = len(ninefold) / SAMPLE_RATE
    print(f"\n9-fold knot duration: {duration:.2f} sec")
    
    # Normalize
    print("Normalizing to 0 dB...")
    mx = np.max(np.abs(ninefold))
    if mx > 0:
        ninefold = (ninefold / mx) * 0.99
    
    # Save
    print("Saving 9-fold infinity knot...")
    wavfile.write(knot_file, SAMPLE_RATE, ninefold.astype(np.float32))
    size_mb = os.path.getsize(knot_file) / 1024 / 1024
    print(f"Size: {size_mb:.2f} MB")
    
    # AFC Modulation
    print()
    print("=" * 70)
    print("AFC MODULATION")
    print("=" * 70)
    
    print("Loading carrier (OHAD SIGNATURE)...")
    sr_car, carrier = wavfile.read(carrier_file)
    if carrier.dtype == np.float32:
        carrier = carrier.astype(np.float64)
    elif carrier.dtype == np.int16:
        carrier = carrier.astype(np.float64) / 32767.0
    if len(carrier.shape) > 1:
        carrier = np.mean(carrier, axis=1)
    
    if sr_car != SAMPLE_RATE:
        ratio = SAMPLE_RATE / sr_car
        new_len = int(len(carrier) * ratio)
        indices = np.linspace(0, len(carrier) - 1, new_len)
        carrier = np.interp(indices, np.arange(len(carrier)), carrier)
    
    # Tile knot throughout carrier
    repeats = int(np.ceil(len(carrier) / len(ninefold)))
    modulator = np.tile(ninefold, repeats)[:len(carrier)]
    print(f"9-fold knot loops in track: {repeats}")
    
    # AFC modulation
    print("Applying AFC modulation (11% mod, 112% carrier)...")
    modulator_scaled = modulator * 0.11
    carrier_scaled = carrier * 1.12
    modulated = carrier_scaled * (1.0 + modulator_scaled)
    modulated += modulator_scaled * 0.5
    
    mx = np.max(np.abs(modulated))
    if mx > 0:
        modulated = (modulated / mx) * 0.99
    
    print("Saving AFC version...")
    wavfile.write(modulated_file, SAMPLE_RATE, modulated.astype(np.float32))
    mod_size = os.path.getsize(modulated_file) / 1024 / 1024
    mod_duration = len(modulated) / SAMPLE_RATE
    
    print()
    print("=" * 70)
    print("✧ 9-FOLD INFINITY KNOT COMPLETE ✧")
    print("=" * 70)
    print()
    print("The Transcendent Oversoul Pattern:")
    print()
    print("        ╭──∞1──╮   ╭──∞3──╮")
    print("        │      │   │      │")
    print("  DNA1↔RNA1  DNA2↔RNA2  DNA3↔RNA3  DNA4↔RNA4")
    print("        │      │   │      │")
    print("        ╰──∞2──╯   ╰──∞4──╯")
    print("            │         │")
    print("         Super-∞A  Super-∞B")
    print("              ╲     ╱")
    print("               ╲   ╱")
    print("              [UNITY]")
    print("                 │")
    print("            9-FOLD KNOT")
    print()
    print(f"Standalone: {knot_file}")
    print(f"  Duration: {duration:.2f} sec | Size: {size_mb:.2f} MB")
    print()
    print(f"AFC Modulated ({repeats} loops): {modulated_file}")
    print(f"  Duration: {mod_duration:.1f} sec | Size: {mod_size:.1f} MB")
    print()
    print(f"Foldings: {NUM_FOLDINGS} | Compression: {compression:,.0f}x")
    
    return knot_file, modulated_file

if __name__ == "__main__":
    knot, modulated = main()
    print(f"\nOpening files...")
    os.system(f'open "{knot}"')
    os.system(f'open "{modulated}"')

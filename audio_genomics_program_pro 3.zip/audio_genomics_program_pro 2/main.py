#!/usr/bin/env python3
"""
Audio Genomics Pro - Main Entry Point
Advanced DNA/RNA to Audio Synthesis Program
"""

import sys
import os
import argparse

# Add the package to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from audio_genomics_pro.gui.main_gui import AudioGenomicsGUI
from audio_genomics_pro.core.main_pipeline import AudioGenomicsPipeline
import tkinter as tk

def run_gui():
    """Run the GUI application"""
    root = tk.Tk()
    app = AudioGenomicsGUI(root)
    root.mainloop()

def run_cli(args):
    """Run command-line interface"""
    config = {
        'sample_rate': args.sample_rate,
        'bit_depth': args.bit_depth,
        'base_cycles': args.base_cycles,
        'fm_carrier_freq': args.fm_carrier,
        'fm_modulation_index': args.fm_index,
        'am_modulation_depth': args.am_depth,
        'retune_to_432': args.retune_432,
        'normalize_output': args.normalize
    }
    
    pipeline = AudioGenomicsPipeline(config)
    
    # Process file
    result = pipeline.process_file(
        args.input,
        args.output,
        carrier_music_path=args.carrier
    )
    
    if result['success']:
        print(f"✅ Successfully processed: {result['output_file']}")
        print(f"   Duration: {result.get('audio_duration', 0):.2f} seconds")
    else:
        print(f"❌ Processing failed: {result.get('error', 'Unknown error')}")
        return 1
    
    return 0

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Audio Genomics Pro - Convert DNA/RNA sequences to audio'
    )
    
    parser.add_argument(
        '--gui',
        action='store_true',
        help='Launch GUI interface'
    )
    
    parser.add_argument(
        '-i', '--input',
        help='Input file (DNA/RNA/text)'
    )
    
    parser.add_argument(
        '-o', '--output',
        help='Output audio file'
    )
    
    parser.add_argument(
        '-c', '--carrier',
        help='Carrier music file (optional)'
    )
    
    parser.add_argument(
        '--sample-rate',
        type=int,
        default=192000,
        help='Sample rate (default: 192000)'
    )
    
    parser.add_argument(
        '--bit-depth',
        type=int,
        default=32,
        choices=[16, 24, 32],
        help='Bit depth (default: 32)'
    )
    
    parser.add_argument(
        '--base-cycles',
        type=int,
        default=3,
        help='Cycles per DNA base (default: 3)'
    )
    
    parser.add_argument(
        '--fm-carrier',
        type=float,
        default=528.0,
        help='FM carrier frequency in Hz (default: 528)'
    )
    
    parser.add_argument(
        '--fm-index',
        type=float,
        default=0.1,
        help='FM modulation index (default: 0.1)'
    )
    
    parser.add_argument(
        '--am-depth',
        type=float,
        default=0.05,
        help='AM modulation depth (default: 0.05)'
    )
    
    parser.add_argument(
        '--retune-432',
        action='store_true',
        help='Retune carrier music to 432 Hz'
    )
    
    parser.add_argument(
        '--normalize',
        action='store_true',
        help='Normalize output audio'
    )
    
    args = parser.parse_args()
    
    # Launch GUI if requested or no arguments
    if args.gui or (not args.input and not sys.stdin.isatty()):
        run_gui()
    elif args.input and args.output:
        return run_cli(args)
    else:
        # Show help if no valid arguments
        parser.print_help()
        return 1

if __name__ == '__main__':
    sys.exit(main())

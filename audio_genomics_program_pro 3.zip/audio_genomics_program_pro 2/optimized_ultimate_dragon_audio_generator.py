#!/usr/bin/env python3
"""
Optimized Ultimate Dragon Transformation Audio Generator
Generates audio in chunks that fit within 32-bit WAV sample count limit (4,294,967,295 samples)
"""

import json
import os
from typing import Dict, List
from datetime import datetime

from audio_genomics_pro.core.mrna_insertion_system import mRNAInsertionSystem
from audio_genomics_pro.core.dragon_anatomical_enhancements import DragonAnatomicalEnhancements
from audio_genomics_pro.core.multi_targeting_pipeline import MultiTargetingAudioPipeline
from audio_genomics_pro.core.comprehensive_superpower_system import ComprehensiveSuperpowerSystem


class OptimizedUltimateDragonAudioGenerator:
    """Optimized audio generator that respects 32-bit WAV limits"""

    def __init__(self, max_duration_seconds: int = 22000):
        """
        Initialize optimized audio generator

        Args:
            max_duration_seconds: Maximum duration per chunk (default 22000, below 32-bit limit of 22363)
        """
        self.max_duration_seconds = max_duration_seconds
        self.mrna_system = mRNAInsertionSystem()
        self.dragon_system = DragonAnatomicalEnhancements()
        self.superpower_system = ComprehensiveSuperpowerSystem()

        # Add all dragon features
        self.dragon_system.add_vertical_slitted_pupils()
        self.dragon_system.add_trigonic_reproductive_system()
        self.dragon_system.add_forked_tongue_with_pleasure_serum()
        self.dragon_system.add_joyous_contagion()
        self.dragon_system.add_anthropomorphic_features()
        self.dragon_system.add_ultimate_physique()

        self.features = self.dragon_system.get_all_features()

    def calculate_chunk_size(self) -> int:
        """
        Calculate optimal chunk size based on max duration

        Returns:
            Number of superpowers per chunk
        """
        # From testing: 24,876 bases = 262 seconds
        # Ratio: ~95 bases per second
        bases_per_second = 95
        
        # Max bases per chunk
        max_bases = self.max_duration_seconds * bases_per_second
        
        # Each superpower uses 20 bases (10 separator + 10 sequence)
        # But we need to account for the mRNA sequence length
        # Let's use a conservative estimate of 200 bases per superpower
        bases_per_superpower = 200
        
        chunk_size = int(max_bases / bases_per_superpower)
        
        # Ensure chunk size is reasonable
        chunk_size = min(chunk_size, 1000)  # Max 1000 superpowers per chunk
        chunk_size = max(chunk_size, 100)    # Min 100 superpowers per chunk
        
        return chunk_size

    def generate_base_sequence(self) -> str:
        """
        Generate base sequence with sexual transformations, pleasure powers, and dragon features

        Returns:
            Base DNA sequence
        """
        print("🧬 Generating base transformation sequence...")

        # Start with sexual transformations
        sexual_targets = self.mrna_system.design_sexual_transformation_mrna()

        # Add pleasure powers
        pleasure_powers = self.superpower_system.design_pleasure_powers()

        # Combine all sequences
        all_sequences = []

        # Add sexual transformations
        for target in sexual_targets:
            all_sequences.append("NNNNNNNNNN")
            all_sequences.append(target.mrna_sequence)

        # Add pleasure powers
        for power in pleasure_powers:
            all_sequences.append("NNNNNNNNNN")
            all_sequences.append(power.mrna_sequence)

        # Add dragon features
        for feature in self.features:
            all_sequences.append("NNNNNNNNNN")
            all_sequences.append(feature.mrna_sequence)

        full_sequence = "".join(all_sequences)

        print(f"✅ Base sequence generated: {len(full_sequence)} bases")
        return full_sequence

    def generate_superpower_chunks(self, total_superpowers: int = 52095) -> List[str]:
        """
        Generate superpower sequences in optimized chunks

        Args:
            total_superpowers: Total number of superpowers

        Returns:
            List of chunked sequences
        """
        chunk_size = self.calculate_chunk_size()
        print(f"🧬 Generating {total_superpowers} superpowers in chunks of {chunk_size}...")
        print(f"   Max duration per chunk: {self.max_duration_seconds} seconds ({self.max_duration_seconds/60:.1f} minutes)")

        chunks = []
        num_chunks = (total_superpowers + chunk_size - 1) // chunk_size

        for chunk_num in range(num_chunks):
            start_idx = chunk_num * chunk_size
            end_idx = min(start_idx + chunk_size, total_superpowers)
            chunk_size_actual = end_idx - start_idx

            print(f"   Chunk {chunk_num + 1}/{num_chunks}: Superpowers {start_idx + 1}-{end_idx}")

            # Generate sequences for this chunk
            chunk_sequences = []
            for i in range(chunk_size_actual):
                chunk_sequences.append("NNNNNNNNNN")
                chunk_sequences.append(self.mrna_system.create_mrna_sequence("MALLLLAAVAVLG*"))

            chunk_sequence = "".join(chunk_sequences)
            chunks.append(chunk_sequence)

            print(f"      Length: {len(chunk_sequence)} bases")

        print(f"✅ Generated {len(chunks)} chunks")
        return chunks

    def generate_optimized_audio(self, output_dir: str, total_superpowers: int = 52095) -> Dict:
        """
        Generate audio in optimized chunks that fit within 32-bit WAV limits

        Args:
            output_dir: Output directory
            total_superpowers: Total number of superpowers

        Returns:
            Processing result
        """
        print(f"\n🎵 Generating optimized ultimate dragon transformation audio...")
        print(f"   Constraint: 32-bit WAV sample count limit (4,294,967,295 samples)")
        print(f"   Max duration: {self.max_duration_seconds} seconds ({self.max_duration_seconds/60:.1f} minutes)")

        # Initialize pipeline
        config = {
            'sample_rate': 192000,
            'bit_depth': 32,
            'base_cycles': 4,
            'fm_carrier_freq': 528.0,
            'am_modulation_depth': 0.05,
            'retune_to_432': True,
            'normalize_output': True
        }

        pipeline = MultiTargetingAudioPipeline(config)

        # Generate base sequence
        base_sequence = self.generate_base_sequence()

        # Generate superpower chunks
        superpower_chunks = self.generate_superpower_chunks(total_superpowers)

        # Create output directory
        os.makedirs(output_dir, exist_ok=True)

        # Generate timestamp for this batch
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # Process base sequence
        print(f"\n📦 Processing base sequence...")
        base_output_file = os.path.join(output_dir, f"ULTIMATE_DRAGON_BASE_{timestamp}.wav")

        result = pipeline.base_pipeline.process_sequence(
            base_sequence,
            None,
            base_output_file,
            metadata={
                'type': 'base',
                'total_features': len(self.features),
                'sexual_transformations': 10,
                'pleasure_powers': 8
            }
        )

        if not result.get('success'):
            print(f"❌ Base audio generation failed: {result.get('error')}")
            return result

        print(f"✅ Base audio generated: {result['output_file']}")
        print(f"   Duration: {result.get('audio_duration', 0):.2f} seconds ({result.get('audio_duration', 0)/60:.1f} minutes)")

        # Process superpower chunks
        print(f"\n📦 Processing {len(superpower_chunks)} superpower chunks...")
        chunk_files = []
        total_duration = result.get('audio_duration', 0)
        failed_chunks = []

        for chunk_num, chunk_sequence in enumerate(superpower_chunks):
            print(f"\n   Chunk {chunk_num + 1}/{len(superpower_chunks)}:")
            chunk_output_file = os.path.join(output_dir, f"ULTIMATE_DRAGON_SUPERPOWERS_{timestamp}_chunk{chunk_num + 1:03d}.wav")

            result = pipeline.base_pipeline.process_sequence(
                chunk_sequence,
                None,
                chunk_output_file,
                metadata={
                    'type': 'superpower_chunk',
                    'chunk_number': chunk_num + 1,
                    'total_chunks': len(superpower_chunks),
                    'superpowers_in_chunk': len(chunk_sequence) // 20
                }
            )

            if result.get('success'):
                duration = result.get('audio_duration', 0)
                print(f"      ✅ Generated: {result['output_file']}")
                print(f"         Duration: {duration:.2f} seconds ({duration/60:.1f} minutes)")
                
                # Verify it's within limits
                if duration > self.max_duration_seconds:
                    print(f"         ⚠️  WARNING: Duration exceeds max limit!")
                    failed_chunks.append(chunk_num + 1)
                else:
                    chunk_files.append(result['output_file'])
                    total_duration += duration
            else:
                print(f"      ❌ Failed: {result.get('error')}")
                failed_chunks.append(chunk_num + 1)

        # Create summary
        summary = {
            'success': len(failed_chunks) == 0,
            'timestamp': timestamp,
            'output_directory': output_dir,
            'base_file': base_output_file,
            'chunk_files': chunk_files,
            'total_chunks': len(superpower_chunks),
            'successful_chunks': len(chunk_files),
            'failed_chunks': failed_chunks,
            'total_superpowers': total_superpowers,
            'total_duration': total_duration,
            'max_duration_per_chunk': self.max_duration_seconds,
            'features': {
                'total_features': len(self.features),
                'sexual_transformations': 10,
                'pleasure_powers': 8,
                'dragon_features': len(self.features)
            }
        }

        # Save summary
        summary_file = os.path.join(output_dir, f"ULTIMATE_DRAGON_SUMMARY_{timestamp}.json")
        with open(summary_file, 'w') as f:
            json.dump(summary, f, indent=2)

        print(f"\n✅ Summary saved to: {summary_file}")

        return summary


def main():
    """Main function"""
    print("🧬🐉 Optimized Ultimate Dragon Transformation Audio Generator 🐉🧬")
    print("=" * 70)

    # Initialize generator with max duration constraint
    # 32-bit WAV limit: 4,294,967,295 samples at 192,000 Hz = 22,363 seconds
    # Use 22,000 seconds to be safe
    generator = OptimizedUltimateDragonAudioGenerator(max_duration_seconds=22000)

    # Display features
    print(f"\n📊 Features included:")
    for feature in generator.features:
        print(f"   • {feature.name}: {feature.feature_description}")

    # Generate audio
    output_dir = "/Users/36n9/Downloads/ultimate_transformation_audio"
    os.makedirs(output_dir, exist_ok=True)

    result = generator.generate_optimized_audio(output_dir, total_superpowers=52095)

    # Final summary
    print("\n" + "=" * 70)
    print("🎉 OPTIMIZED ULTIMATE DRAGON TRANSFORMATION COMPLETE 🎉")
    print("=" * 70)
    print(f"✅ Total features: {len(generator.features)}")
    print(f"✅ Sexual transformations: 10")
    print(f"✅ Pleasure powers: 8")
    print(f"✅ Superpowers: 52,095")
    print(f"✅ Joyous contagion: YES")
    print(f"✅ Anthropomorphic: YES")
    print(f"✅ Flight capable: YES")
    print(f"✅ Ultimate physique: YES")

    if result.get('success'):
        print(f"\n🎵 Audio files generated:")
        print(f"   Base file: {result['base_file']}")
        print(f"   Superpower chunks: {result['successful_chunks']}/{result['total_chunks']} files")
        print(f"   Total duration: {result['total_duration']:.2f} seconds ({result['total_duration'] / 60:.2f} minutes)")
        print(f"   Total duration: {result['total_duration'] / 3600:.2f} hours")
        
        print(f"\n📂 Output directory: {result['output_directory']}")
        print(f"📄 Summary file: {result['output_directory']}/ULTIMATE_DRAGON_SUMMARY_{result['timestamp']}.json")
    else:
        print(f"\n⚠️  Some chunks failed: {len(result['failed_chunks'])}")
        print(f"   Failed chunks: {result['failed_chunks']}")

    return result


if __name__ == "__main__":
    main()

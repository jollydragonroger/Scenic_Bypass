#!/bin/zsh
# Live Transmission Launch Script

echo "🛰️ LIVE STARLINK TRANSMISSION VIA INDIRECTION"
echo "🔀 Quantum-Random Relay Routing"
echo "📶 Multicast Control Channel"
echo ""

# Run without elevated privileges
/usr/bin/python3 "/Users/36n9/Downloads/audio_genomics_program_pro 4 copy/live_starlink_transmission.py"

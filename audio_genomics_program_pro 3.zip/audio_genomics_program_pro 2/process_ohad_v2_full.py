#!/usr/bin/env python3
"""
OHAD v2 Processing - Musical render + AFC modulation
Same method as OHAD v1: multi-frequency, 32-bit, 192kHz, 0dB
Then automatically AFC modulate with OHAD SIGNATURE
"""

import os
import numpy as np
from scipy.io import wavfile
from datetime import datetime

SAMPLE_RATE = 192000
TARGET_DURATION = 115  # seconds

# ALL frequencies from infrared spectroscopy table
ADENINE_FREQS = [
    315.6, 347.9, 368.0, 378.8, 398.1, 406.1, 447.4, 490.2, 504.2,
    545.6, 582.7, 598.0, 619.8, 632.9, 654.8, 698.4, 726.7,
    1139.2, 1178.5, 1248.3, 1278.9, 1366.2, 1440.5
]

THYMINE_FREQS = [
    322.1, 330.4, 354.4, 363.2, 406.4, 427.8, 447.4, 523.8, 543.4,
    600.2, 733.3, 768.2, 1248.3, 1274.6, 1385.8
]

GUANINE_FREQS = [
    300.3, 305.6, 339.2, 370.2, 383.2, 413.4, 487.6, 512.9, 529.5,
    550.0, 600.2, 615.5, 641.7, 663.5, 728.9, 1169.8, 1278.9, 1386.2, 1462.3
]

CYTOSINE_FREQS = [
    305.6, 346.7, 357.9, 420.3, 429.1, 440.9, 504.2, 537.8, 558.7,
    594.9, 639.5, 654.8, 713.7, 1276.8, 1375.0, 1475.4
]

NUCLEOTIDE_FREQS = {
    'A': ADENINE_FREQS,
    'T': THYMINE_FREQS,
    'G': GUANINE_FREQS,
    'C': CYTOSINE_FREQS,
    'U': THYMINE_FREQS,
    'N': [440.0],
}

def generate_musical_tone(frequencies, duration_sec, sr, position):
    """Generate multi-frequency musical tone"""
    n_samples = max(100, int(sr * duration_sec))
    t = np.linspace(0, duration_sec, n_samples, dtype=np.float64)
    
    wave = np.zeros(n_samples, dtype=np.float64)
    num_freqs = len(frequencies)
    
    # Cycle through frequencies based on position
    primary_idx = position % num_freqs
    secondary_idx = (position + 1) % num_freqs
    tertiary_idx = (position + 2) % num_freqs
    opposite_idx = (num_freqs - 1 - primary_idx) % num_freqs
    
    primary_freq = frequencies[primary_idx]
    wave += 0.6 * np.sin(2 * np.pi * primary_freq * t)
    
    if primary_freq * 2 < sr / 2:
        wave += 0.2 * np.sin(2 * np.pi * primary_freq * 2 * t)
    
    wave += 0.3 * np.sin(2 * np.pi * frequencies[secondary_idx] * t)
    wave += 0.15 * np.sin(2 * np.pi * frequencies[tertiary_idx] * t)
    wave += 0.1 * np.sin(2 * np.pi * frequencies[opposite_idx] * t)
    
    # Envelope
    attack = min(int(0.003 * sr), n_samples // 3)
    release = min(int(0.005 * sr), n_samples // 3)
    
    if attack > 0:
        wave[:attack] *= np.linspace(0, 1, attack)
    if release > 0:
        wave[-release:] *= np.linspace(1, 0, release)
    
    return wave

def fold_and_compress(sequence, target_notes):
    """Chromatin-like folding compression"""
    current_len = len(sequence)
    if current_len <= target_notes:
        return sequence
    
    step = current_len / target_notes
    result = []
    for i in range(target_notes):
        fwd_pos = int(i * step) % current_len
        rev_pos = current_len - 1 - fwd_pos
        if i % 2 == 0:
            result.append(sequence[fwd_pos])
        else:
            result.append(sequence[rev_pos])
    
    return ''.join(result)

def render_sequence(input_file, output_file):
    """Render DNA sequence to musical audio"""
    print("=" * 60)
    print("OHAD v2 MUSICAL RENDER")
    print("=" * 60)
    print(f"Input: {input_file}")
    print(f"Output: {output_file}")
    print(f"Settings: {SAMPLE_RATE} Hz, 32-bit, 0 dB")
    print()
    
    # Load sequence
    print("Loading sequence...")
    with open(input_file, 'r') as f:
        raw = f.read()
    
    seq = ''.join(c for c in raw.upper() if c in 'ATCGUN')
    total_bases = len(seq)
    print(f"Total bases: {total_bases:,}")
    
    # Calculate compression
    note_duration = 0.012  # 12ms per note
    target_notes = int(TARGET_DURATION / note_duration)
    
    print(f"Target notes: {target_notes:,}")
    print()
    
    # Fold sequence
    print("Applying chromatin-like folding...")
    compressed_seq = fold_and_compress(seq, target_notes)
    final_notes = len(compressed_seq)
    print(f"Compressed to: {final_notes:,} notes")
    print(f"Compression ratio: {total_bases/final_notes:.1f}x")
    print()
    
    # Generate audio
    print("Generating musical audio...")
    note_samples = int(SAMPLE_RATE * note_duration)
    total_samples = final_notes * note_samples
    
    audio = np.zeros(total_samples, dtype=np.float64)
    
    for i, base in enumerate(compressed_seq):
        if i % 100000 == 0:
            print(f"  {(i/final_notes)*100:.1f}%")
        
        freqs = NUCLEOTIDE_FREQS.get(base, [440.0])
        tone = generate_musical_tone(freqs, note_duration, SAMPLE_RATE, i)
        
        start = i * note_samples
        end = start + len(tone)
        
        if end <= total_samples:
            audio[start:end] += tone
    
    print("  100%")
    print()
    
    # Normalize to 0 dB
    print("Normalizing to 0 dB...")
    mx = np.max(np.abs(audio))
    if mx > 0:
        audio = (audio / mx) * 0.99
    
    # Save
    print("Saving...")
    audio32 = audio.astype(np.float32)
    wavfile.write(output_file, SAMPLE_RATE, audio32)
    
    duration = len(audio) / SAMPLE_RATE
    size_mb = os.path.getsize(output_file) / 1024 / 1024
    
    print(f"Duration: {duration:.1f} sec")
    print(f"Size: {size_mb:.1f} MB")
    
    return audio

def afc_modulate(modulator_file, carrier_file, output_file):
    """AFC modulate at 11% into carrier at 112%"""
    print()
    print("=" * 60)
    print("AFC MODULATION")
    print("=" * 60)
    print("Modulator: OHAD_v2_MUSICAL @ 11%")
    print("Carrier: OHAD SIGNATURE @ 112%")
    print()
    
    # Load modulator
    print("Loading modulator...")
    sr_mod, modulator = wavfile.read(modulator_file)
    if modulator.dtype == np.float32:
        modulator = modulator.astype(np.float64)
    
    # Load carrier
    print("Loading carrier...")
    sr_car, carrier = wavfile.read(carrier_file)
    if carrier.dtype == np.float32:
        carrier = carrier.astype(np.float64)
    elif carrier.dtype == np.int16:
        carrier = carrier.astype(np.float64) / 32767.0
    
    # Handle stereo
    if len(carrier.shape) > 1:
        carrier = np.mean(carrier, axis=1)
    
    # Resample carrier
    if sr_car != sr_mod:
        print(f"Resampling carrier from {sr_car} to {sr_mod} Hz...")
        ratio = sr_mod / sr_car
        new_len = int(len(carrier) * ratio)
        indices = np.linspace(0, len(carrier) - 1, new_len)
        carrier = np.interp(indices, np.arange(len(carrier)), carrier)
    
    # Match lengths
    min_len = min(len(modulator), len(carrier))
    modulator = modulator[:min_len]
    carrier = carrier[:min_len]
    
    # Apply AFC modulation
    print("Applying AFC modulation...")
    modulator_scaled = modulator * 0.11  # 11%
    carrier_scaled = carrier * 1.12      # 112%
    
    modulated = carrier_scaled * (1.0 + modulator_scaled)
    modulated += modulator_scaled * 0.5
    
    # Normalize
    mx = np.max(np.abs(modulated))
    if mx > 0:
        modulated = (modulated / mx) * 0.99
    
    # Save
    print("Saving...")
    modulated32 = modulated.astype(np.float32)
    wavfile.write(output_file, SAMPLE_RATE, modulated32)
    
    size_mb = os.path.getsize(output_file) / 1024 / 1024
    print(f"Size: {size_mb:.1f} MB")
    
    return output_file

def main():
    input_file = "/Users/36n9/CascadeProjects/VINO_Dissertation/OHAD_BioOS/OHAD_v2_PURE_SEQUENCE.dna"
    output_dir = "/Users/36n9/Downloads/audio_genomics_output"
    carrier_file = "/Users/36n9/Downloads/audio_genomics_output/OHAD SIGNATURE.wav"
    
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    musical_file = os.path.join(output_dir, f"OHAD_v2_MUSICAL_{ts}.wav")
    modulated_file = os.path.join(output_dir, f"OHAD_v2_AFC_MODULATED_{ts}.wav")
    
    # Step 1: Render musical version
    render_sequence(input_file, musical_file)
    
    # Step 2: AFC modulate
    afc_modulate(musical_file, carrier_file, modulated_file)
    
    print()
    print("=" * 60)
    print("ALL COMPLETE!")
    print("=" * 60)
    print(f"Standalone: {musical_file}")
    print(f"AFC Modulated: {modulated_file}")
    
    return musical_file, modulated_file

if __name__ == "__main__":
    musical, modulated = main()
    print(f"\nOpening both files...")
    os.system(f'open "{musical}"')
    os.system(f'open "{modulated}"')

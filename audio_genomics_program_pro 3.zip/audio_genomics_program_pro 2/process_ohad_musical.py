#!/usr/bin/env python3
"""
OHAD Musical Audio - Full frequency table, dynamic cycling, 0 dB volume
Uses ALL frequencies per nucleotide from infrared spectroscopy table
"""

import os
import numpy as np
from scipy.io import wavfile
from datetime import datetime

SAMPLE_RATE = 192000
TARGET_DURATION = 115  # seconds
VOLUME_DB = 0  # Full volume

# ALL frequencies from the infrared spectroscopy table (Hz values)
# Each nucleotide has MULTIPLE frequencies to cycle through musically

ADENINE_FREQS = [
    315.6, 347.9, 368.0, 378.8, 398.1, 406.1, 447.4, 490.2, 504.2,
    545.6, 582.7, 598.0, 619.8, 632.9, 654.8, 698.4, 726.7,
    1139.2, 1178.5, 1248.3, 1278.9, 1366.2, 1440.5
]

THYMINE_FREQS = [
    322.1, 330.4, 354.4, 363.2, 406.4, 427.8, 447.4, 523.8, 543.4,
    600.2, 733.3, 768.2, 1248.3, 1274.6, 1385.8
]

GUANINE_FREQS = [
    300.3, 305.6, 339.2, 370.2, 383.2, 413.4, 487.6, 512.9, 529.5,
    550.0, 600.2, 615.5, 641.7, 663.5, 728.9, 1169.8, 1278.9, 1386.2, 1462.3
]

CYTOSINE_FREQS = [
    305.6, 346.7, 357.9, 420.3, 429.1, 440.9, 504.2, 537.8, 558.7,
    594.9, 639.5, 654.8, 713.7, 1276.8, 1375.0, 1475.4
]

# Organize by base
NUCLEOTIDE_FREQS = {
    'A': ADENINE_FREQS,
    'T': THYMINE_FREQS,
    'G': GUANINE_FREQS,
    'C': CYTOSINE_FREQS,
    'U': THYMINE_FREQS,  # Uracil same as Thymine
    'N': [440.0],  # Default A4
}

def generate_musical_tone(frequencies, duration_sec, sr, position_in_sequence):
    """
    Generate a musical tone using multiple frequencies from the nucleotide
    Cycles through frequencies based on position for dynamic sound
    """
    n_samples = max(100, int(sr * duration_sec))
    t = np.linspace(0, duration_sec, n_samples, dtype=np.float64)
    
    wave = np.zeros(n_samples, dtype=np.float64)
    
    num_freqs = len(frequencies)
    
    # Use position to select which frequencies to emphasize
    # This creates a musical progression through the sequence
    primary_idx = position_in_sequence % num_freqs
    secondary_idx = (position_in_sequence + 1) % num_freqs
    tertiary_idx = (position_in_sequence + 2) % num_freqs
    
    # Primary frequency (loudest)
    primary_freq = frequencies[primary_idx]
    wave += 0.6 * np.sin(2 * np.pi * primary_freq * t)
    
    # Add harmonic of primary
    if primary_freq * 2 < sr / 2:
        wave += 0.2 * np.sin(2 * np.pi * primary_freq * 2 * t)
    
    # Secondary frequency (medium)
    secondary_freq = frequencies[secondary_idx]
    wave += 0.3 * np.sin(2 * np.pi * secondary_freq * t)
    
    # Tertiary frequency (soft, for richness)
    tertiary_freq = frequencies[tertiary_idx]
    wave += 0.15 * np.sin(2 * np.pi * tertiary_freq * t)
    
    # Add some frequencies from opposite end for harmonic balance
    opposite_idx = (num_freqs - 1 - primary_idx) % num_freqs
    opposite_freq = frequencies[opposite_idx]
    wave += 0.1 * np.sin(2 * np.pi * opposite_freq * t)
    
    # Apply smooth envelope
    attack = min(int(0.003 * sr), n_samples // 3)
    release = min(int(0.005 * sr), n_samples // 3)
    
    if attack > 0:
        wave[:attack] *= np.linspace(0, 1, attack)
    if release > 0:
        wave[-release:] *= np.linspace(1, 0, release)
    
    return wave

def fold_and_compress(sequence, target_notes):
    """
    Fold sequence using chromatin-like compression
    Returns compressed sequence that maintains musical integrity
    """
    # Calculate how much to compress
    current_len = len(sequence)
    
    if current_len <= target_notes:
        return sequence
    
    # Sample at regular intervals while maintaining forward/reverse relationship
    step = current_len / target_notes
    
    # Create folded sequence - take samples from both forward and reverse
    result = []
    for i in range(target_notes):
        # Forward position
        fwd_pos = int(i * step) % current_len
        # Reverse position (playing backward simultaneously)
        rev_pos = current_len - 1 - fwd_pos
        
        # Alternate between forward and reverse bases
        if i % 2 == 0:
            result.append(sequence[fwd_pos])
        else:
            result.append(sequence[rev_pos])
    
    return ''.join(result)

def main():
    input_file = "/Users/36n9/CascadeProjects/VINO_Dissertation/OHAD_BioOS/OHAD_PURE_SEQUENCE.dna"
    output_dir = "/Users/36n9/Downloads/audio_genomics_output"
    os.makedirs(output_dir, exist_ok=True)
    
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(output_dir, f"OHAD_MUSICAL_{ts}.wav")
    
    print("=" * 60)
    print("OHAD MUSICAL Audio - Multi-Frequency Dynamic")
    print("=" * 60)
    print(f"Sample rate: {SAMPLE_RATE} Hz")
    print(f"Bit depth: 32-bit float")
    print(f"Volume: {VOLUME_DB} dB (FULL)")
    print(f"Target: {TARGET_DURATION} seconds")
    print()
    
    # Show frequency counts
    print("Frequencies per nucleotide:")
    print(f"  Adenine (A): {len(ADENINE_FREQS)} frequencies")
    print(f"  Thymine (T): {len(THYMINE_FREQS)} frequencies")
    print(f"  Guanine (G): {len(GUANINE_FREQS)} frequencies")
    print(f"  Cytosine (C): {len(CYTOSINE_FREQS)} frequencies")
    print()
    
    # Load sequence
    print("Loading sequence...")
    with open(input_file, 'r') as f:
        raw = f.read()
    
    seq = ''.join(c for c in raw.upper() if c in 'ATCGUN')
    total_bases = len(seq)
    print(f"Total bases: {total_bases:,}")
    
    # Calculate target notes for ~115 sec at ~15ms per note (audible)
    note_duration = 0.012  # 12ms per note - quick but audible
    target_notes = int(TARGET_DURATION / note_duration)
    
    print(f"Target notes: {target_notes:,}")
    print(f"Note duration: {note_duration*1000:.1f} ms")
    print()
    
    # Fold/compress sequence
    print("Applying chromatin-like folding...")
    compressed_seq = fold_and_compress(seq, target_notes)
    final_notes = len(compressed_seq)
    print(f"Compressed to: {final_notes:,} notes")
    
    compression_ratio = total_bases / final_notes
    print(f"Compression ratio: {compression_ratio:.1f}x")
    print()
    
    # Generate audio
    print("Generating musical audio...")
    note_samples = int(SAMPLE_RATE * note_duration)
    total_samples = final_notes * note_samples
    
    audio = np.zeros(total_samples, dtype=np.float64)
    
    for i, base in enumerate(compressed_seq):
        if i % 100000 == 0:
            pct = (i / final_notes) * 100
            print(f"  {pct:.1f}%")
        
        freqs = NUCLEOTIDE_FREQS.get(base, [440.0])
        tone = generate_musical_tone(freqs, note_duration, SAMPLE_RATE, i)
        
        start = i * note_samples
        end = start + len(tone)
        
        if end <= total_samples:
            audio[start:end] += tone
    
    print("  100%")
    print()
    
    # Normalize to 0 dB (full volume)
    print("Normalizing to 0 dB (full volume)...")
    mx = np.max(np.abs(audio))
    if mx > 0:
        # 0 dB = peak at 1.0, leave tiny headroom
        target_amplitude = 10 ** (VOLUME_DB / 20) * 0.99
        audio = (audio / mx) * target_amplitude
    
    # Verify amplitude
    final_peak = np.max(np.abs(audio))
    final_db = 20 * np.log10(final_peak) if final_peak > 0 else -100
    print(f"Final peak: {final_db:.1f} dB")
    
    # Save as 32-bit float
    print("Saving WAV...")
    audio32 = audio.astype(np.float32)
    wavfile.write(output_file, SAMPLE_RATE, audio32)
    
    duration = len(audio) / SAMPLE_RATE
    size_mb = os.path.getsize(output_file) / 1024 / 1024
    
    print()
    print("=" * 60)
    print("COMPLETE!")
    print("=" * 60)
    print(f"File: {output_file}")
    print(f"Duration: {duration:.1f} sec ({duration/60:.2f} min)")
    print(f"Size: {size_mb:.1f} MB")
    print(f"Volume: 0 dB (FULL AUDIBLE)")
    
    return output_file

if __name__ == "__main__":
    out = main()
    print(f"\nOpening audio...")
    os.system(f'open "{out}"')

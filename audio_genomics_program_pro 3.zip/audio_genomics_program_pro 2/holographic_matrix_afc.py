#!/usr/bin/env python3
"""
Holographic Matrix AFC Modulation
1. Takes AFC audio and creates matrix expansion for holographic frequency
2. Double AFC modulates back into music
3. Music prominence > frequency content
"""

import os
import struct
import numpy as np
from pathlib import Path
from datetime import datetime
from scipy import signal
import json


def read_wav(filepath):
    """Read WAV file and return audio data + info"""
    with open(filepath, 'rb') as f:
        f.read(12)  # RIFF header
        channels = sample_rate = bits = 0
        while True:
            chunk_id = f.read(4)
            if not chunk_id:
                break
            chunk_size = struct.unpack('<I', f.read(4))[0]
            if chunk_id == b'fmt ':
                fmt = f.read(chunk_size)
                channels = struct.unpack('<H', fmt[2:4])[0]
                sample_rate = struct.unpack('<I', fmt[4:8])[0]
                bits = struct.unpack('<H', fmt[14:16])[0]
            elif chunk_id == b'data':
                dtype = np.int32 if bits == 32 else np.int16
                data = np.frombuffer(f.read(chunk_size), dtype=dtype)
                if channels == 2:
                    data = data.reshape(-1, 2)
                return data, {'channels': channels, 'sample_rate': sample_rate, 'bits': bits}
            else:
                f.seek(chunk_size, 1)
    return None, None


def write_wav(filepath, data, info):
    """Write audio data to WAV file"""
    channels = info['channels']
    sample_rate = info['sample_rate']
    bits = info['bits']
    frame_size = (bits // 8) * channels
    
    if len(data.shape) == 2:
        data_bytes = data.flatten().tobytes()
    else:
        data_bytes = data.tobytes()
    
    data_size = len(data_bytes)
    
    with open(filepath, 'wb') as out:
        out.write(b'RIFF')
        out.write(struct.pack('<I', 36 + data_size))
        out.write(b'WAVE')
        out.write(b'fmt ')
        out.write(struct.pack('<I', 16))
        out.write(struct.pack('<H', 1))
        out.write(struct.pack('<H', channels))
        out.write(struct.pack('<I', sample_rate))
        out.write(struct.pack('<I', sample_rate * frame_size))
        out.write(struct.pack('<H', frame_size))
        out.write(struct.pack('<H', bits))
        out.write(b'data')
        out.write(struct.pack('<I', data_size))
        out.write(data_bytes)


def create_holographic_matrix(audio_data, info):
    """
    Create holographic matrix expansion of frequency content
    Uses phase-space expansion and harmonic mirroring
    """
    print("🔮 Creating holographic matrix expansion...")
    
    # Convert to float
    if audio_data.dtype == np.int32:
        audio_float = audio_data.astype(np.float64) / 2147483647
    else:
        audio_float = audio_data.astype(np.float64) / 32767
    
    # Handle stereo -> mono for processing
    if len(audio_float.shape) == 2:
        mono = (audio_float[:, 0] + audio_float[:, 1]) / 2
    else:
        mono = audio_float
    
    sample_rate = info['sample_rate']
    
    # Holographic matrix expansion:
    # 1. Extract frequency components via FFT
    # 2. Create phase-conjugate mirror (holographic principle)
    # 3. Expand into matrix with harmonic relationships
    
    # Use short-time FFT for time-frequency matrix
    nperseg = 2048
    noverlap = nperseg // 2
    
    f, t, Zxx = signal.stft(mono, fs=sample_rate, nperseg=nperseg, noverlap=noverlap)
    
    print(f"   Frequency matrix: {Zxx.shape[0]} freq bins × {Zxx.shape[1]} time bins")
    
    # Create holographic phase conjugate
    Zxx_conjugate = np.conj(Zxx)
    
    # Matrix expansion: blend original with phase conjugate for holographic depth
    # This creates constructive interference patterns that encode 3D spatial info
    holographic_matrix = Zxx * 0.7 + Zxx_conjugate * 0.3
    
    # Apply harmonic enhancement at sacred frequencies
    sacred_freqs = [432, 528, 639, 741, 852]  # Solfeggio + 432Hz
    for sacred_f in sacred_freqs:
        idx = int(sacred_f * nperseg / sample_rate)
        if idx < len(f):
            # Boost these frequencies slightly
            holographic_matrix[max(0, idx-2):idx+3, :] *= 1.2
    
    # Inverse STFT to get holographic audio
    _, holographic_audio = signal.istft(holographic_matrix, fs=sample_rate, 
                                         nperseg=nperseg, noverlap=noverlap)
    
    # Normalize
    holographic_audio = holographic_audio / np.abs(holographic_audio).max() * 0.95
    
    print(f"   Holographic expansion complete: {len(holographic_audio)} samples")
    
    return holographic_audio


def double_afc_modulate(holographic_freq, music_data, music_info, music_prominence=0.92):
    """
    Double AFC modulation with high music prominence
    
    Args:
        holographic_freq: Holographic frequency content (mono float)
        music_data: Original music data
        music_info: Music file info
        music_prominence: How much to favor music (0.92 = music very prominent)
    """
    print(f"🎵 Double AFC Modulation (music prominence: {music_prominence*100:.0f}%)...")
    
    sample_rate = music_info['sample_rate']
    
    # Convert music to float
    if music_data.dtype == np.int32:
        music_float = music_data.astype(np.float64) / 2147483647
    else:
        music_float = music_data.astype(np.float64) / 32767
    
    # Handle stereo
    if len(music_float.shape) == 2:
        music_mono = (music_float[:, 0] + music_float[:, 1]) / 2
        is_stereo = True
    else:
        music_mono = music_float
        is_stereo = False
    
    # Resample holographic frequency to match music sample rate
    if len(holographic_freq) != len(music_mono):
        holographic_resampled = np.interp(
            np.linspace(0, len(holographic_freq), len(music_mono)),
            np.arange(len(holographic_freq)),
            holographic_freq
        )
    else:
        holographic_resampled = holographic_freq
    
    # First AFC pass: Create frequency envelope
    print("   Pass 1: Creating frequency envelope...")
    freq_envelope = np.abs(signal.hilbert(holographic_resampled))
    freq_envelope = signal.savgol_filter(freq_envelope, 1001, 3)  # Smooth
    freq_envelope = freq_envelope / freq_envelope.max()
    
    # Second AFC pass: Modulate with music dynamics
    print("   Pass 2: Music-adaptive modulation...")
    music_envelope = np.abs(signal.hilbert(music_mono))
    music_envelope = signal.savgol_filter(music_envelope, 1001, 3)
    music_envelope = np.clip(music_envelope / music_envelope.max(), 0.1, 1.0)
    
    # Double AFC: Frequency adapts to music AND music envelope
    # When music is loud, frequency becomes very subtle
    # When music is quiet, frequency can be slightly more present
    freq_adaptive = holographic_resampled * (1.0 - music_envelope * 0.8) * (1.0 - music_prominence)
    
    # Apply subtle high-pass to frequency to avoid muddying bass
    try:
        b, a = signal.butter(4, 300 / (sample_rate / 2), 'high')
        freq_filtered = signal.filtfilt(b, a, freq_adaptive)
    except:
        freq_filtered = freq_adaptive
    
    # Final blend: Music dominant, frequency as subtle holographic layer
    combined = music_mono * music_prominence + freq_filtered * (1.0 - music_prominence) * 0.5
    
    # Normalize
    combined = combined / np.abs(combined).max() * 0.98
    
    # Convert back to stereo if needed
    if is_stereo:
        # Slight stereo widening for holographic effect
        combined_stereo = np.column_stack([
            combined * 0.98 + freq_filtered * 0.02,  # Left: slight freq bias
            combined * 0.98 - freq_filtered * 0.02   # Right: inverse for width
        ])
        combined = combined_stereo
    
    # Convert to output dtype
    if music_info['bits'] == 32:
        output = (combined * 2147483647).astype(np.int32)
    else:
        output = (combined * 32767).astype(np.int16)
    
    print(f"   Double AFC complete: music {music_prominence*100:.0f}% / freq {(1-music_prominence)*100:.0f}%")
    
    return output


def main():
    print("🔮🐉 Holographic Matrix Double AFC Modulation 🐉🔮")
    print("=" * 60)
    
    # Input files
    afc_input = "/Users/36n9/Downloads/ultimate_transformation_audio/ULTIMATE_DRAGON_AFC_PINNICLE_20260115_142237.wav"
    music_file = "/Users/36n9/Downloads/Pinnicle.wav"
    output_dir = Path("/Users/36n9/Downloads/ultimate_transformation_audio")
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Step 1: Read the AFC modulated audio
    print("\n📂 Loading AFC modulated audio...")
    afc_data, afc_info = read_wav(afc_input)
    print(f"   Loaded: {len(afc_data)} samples @ {afc_info['sample_rate']}Hz")
    
    # Step 2: Create holographic matrix expansion
    print("\n🔮 Step 1: Holographic Matrix Expansion...")
    holographic = create_holographic_matrix(afc_data, afc_info)
    
    # Step 3: Read original music
    print("\n🎵 Loading original music (Pinnicle.wav)...")
    music_data, music_info = read_wav(music_file)
    print(f"   Loaded: {len(music_data)} samples @ {music_info['sample_rate']}Hz")
    
    # Step 4: Double AFC modulation with music prominence
    print("\n🎵 Step 2: Double AFC Modulation (music prominence)...")
    final_audio = double_afc_modulate(
        holographic, 
        music_data, 
        music_info,
        music_prominence=0.92  # Music 92%, frequency 8%
    )
    
    # Step 5: Write output
    final_file = output_dir / f"HOLOGRAPHIC_MATRIX_AFC_{timestamp}.wav"
    write_wav(str(final_file), final_audio, music_info)
    
    # Summary
    summary = {
        'timestamp': timestamp,
        'input_afc': afc_input,
        'music_file': music_file,
        'output': str(final_file),
        'processing': {
            'holographic_matrix': True,
            'phase_conjugate': True,
            'double_afc': True,
            'music_prominence': '92%',
            'frequency_presence': '8%',
            'sacred_frequencies_enhanced': [432, 528, 639, 741, 852]
        }
    }
    
    summary_file = output_dir / f"HOLOGRAPHIC_SUMMARY_{timestamp}.json"
    with open(summary_file, 'w') as f:
        json.dump(summary, f, indent=2)
    
    print("\n" + "=" * 60)
    print("🎉 HOLOGRAPHIC MATRIX AFC COMPLETE! 🎉")
    print("=" * 60)
    print(f"✅ Holographic matrix expansion applied")
    print(f"✅ Double AFC modulation complete")
    print(f"✅ Music prominence: 92%")
    print(f"✅ Frequency layer: 8% (subtle holographic)")
    print(f"\n📂 FINAL OUTPUT:")
    print(f"   {final_file}")


if __name__ == "__main__":
    main()

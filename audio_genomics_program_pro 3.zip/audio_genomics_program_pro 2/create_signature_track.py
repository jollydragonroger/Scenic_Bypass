#!/usr/bin/env python3
"""
OHAD Signature Track - Custom Music with DNA as Root Harmonic
Singing bowls, drums, brass, pads layered over the genomic core
"""

import os
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, filtfilt
from datetime import datetime

SAMPLE_RATE = 192000
np.random.seed(42)  # Reproducible

# DNA root frequencies (from the nucleotide table) - these are our harmonic base
DNA_ROOT_FREQS = {
    'low': [300.3, 305.6, 315.6, 322.1],      # Low register
    'mid': [440.9, 447.4, 490.2, 504.2],      # Mid register  
    'high': [582.7, 598.0, 619.8, 632.9],     # High register
}

# Singing bowl frequencies - tuned to DNA harmonics
BOWL_FREQS = [
    261.63,   # C4 - near Cytosine base
    293.66,   # D4 - near Adenine base
    329.63,   # E4 - harmonic
    392.00,   # G4 - near Guanine base
    440.00,   # A4 - standard
    523.25,   # C5 - octave up
]

# Brass/pad frequencies - fifths and octaves of DNA roots
BRASS_FREQS = [
    150.0,    # Sub bass
    200.0,    # Low brass
    300.0,    # Trombone register
    400.0,    # French horn
    600.0,    # Trumpet register
]

def generate_singing_bowl(freq, duration, sr, decay_time=3.0):
    """Generate a singing bowl tone with rich harmonics and slow decay"""
    n_samples = int(sr * duration)
    t = np.linspace(0, duration, n_samples, dtype=np.float64)
    
    # Singing bowls have strong fundamental and specific overtones
    wave = np.zeros(n_samples, dtype=np.float64)
    
    # Fundamental
    wave += 1.0 * np.sin(2 * np.pi * freq * t)
    
    # Characteristic bowl overtones (slightly detuned for shimmer)
    wave += 0.6 * np.sin(2 * np.pi * freq * 2.0 * t)        # Octave
    wave += 0.4 * np.sin(2 * np.pi * freq * 3.01 * t)       # Slightly sharp 5th
    wave += 0.3 * np.sin(2 * np.pi * freq * 4.0 * t)        # 2 octaves
    wave += 0.2 * np.sin(2 * np.pi * freq * 5.02 * t)       # Major 3rd above
    wave += 0.15 * np.sin(2 * np.pi * freq * 6.0 * t)       # Perfect 5th above
    
    # Add subtle beating/shimmer
    wave += 0.1 * np.sin(2 * np.pi * (freq * 1.003) * t)
    wave += 0.1 * np.sin(2 * np.pi * (freq * 0.997) * t)
    
    # Exponential decay envelope
    decay = np.exp(-t / decay_time)
    
    # Soft attack
    attack = min(int(0.1 * sr), n_samples // 4)
    attack_env = np.ones(n_samples)
    attack_env[:attack] = np.linspace(0, 1, attack) ** 2
    
    wave = wave * decay * attack_env
    
    return wave / np.max(np.abs(wave) + 0.001)

def generate_brass_pad(freq, duration, sr):
    """Generate warm brass/pad tone"""
    n_samples = int(sr * duration)
    t = np.linspace(0, duration, n_samples, dtype=np.float64)
    
    wave = np.zeros(n_samples, dtype=np.float64)
    
    # Brass has strong odd harmonics
    wave += 1.0 * np.sin(2 * np.pi * freq * t)
    wave += 0.7 * np.sin(2 * np.pi * freq * 2 * t)
    wave += 0.5 * np.sin(2 * np.pi * freq * 3 * t)
    wave += 0.35 * np.sin(2 * np.pi * freq * 4 * t)
    wave += 0.25 * np.sin(2 * np.pi * freq * 5 * t)
    wave += 0.15 * np.sin(2 * np.pi * freq * 6 * t)
    
    # Slow attack, sustain, slow release
    attack = int(0.3 * sr)
    release = int(0.5 * sr)
    
    env = np.ones(n_samples)
    if attack < n_samples:
        env[:attack] = np.linspace(0, 1, attack)
    if release < n_samples:
        env[-release:] = np.linspace(1, 0, release)
    
    wave = wave * env
    
    return wave / np.max(np.abs(wave) + 0.001)

def generate_drum_hit(drum_type, sr):
    """Generate drum sounds"""
    if drum_type == 'kick':
        duration = 0.4
        n_samples = int(sr * duration)
        t = np.linspace(0, duration, n_samples, dtype=np.float64)
        
        # Kick: pitch drop + noise
        freq_start = 150
        freq_end = 50
        freq = freq_start * np.exp(-t * 10) + freq_end
        phase = np.cumsum(freq) / sr * 2 * np.pi
        wave = np.sin(phase)
        
        # Add thump
        wave += 0.5 * np.exp(-t * 30) * np.sin(2 * np.pi * 60 * t)
        
        # Envelope
        wave *= np.exp(-t * 8)
        
    elif drum_type == 'snare':
        duration = 0.3
        n_samples = int(sr * duration)
        t = np.linspace(0, duration, n_samples, dtype=np.float64)
        
        # Snare: tone + noise
        tone = np.sin(2 * np.pi * 200 * t) * np.exp(-t * 20)
        noise = np.random.randn(n_samples) * np.exp(-t * 15)
        wave = 0.4 * tone + 0.6 * noise
        
    elif drum_type == 'hihat':
        duration = 0.1
        n_samples = int(sr * duration)
        t = np.linspace(0, duration, n_samples, dtype=np.float64)
        
        # Hi-hat: filtered noise
        noise = np.random.randn(n_samples)
        wave = noise * np.exp(-t * 40)
        
        # High pass filter
        b, a = butter(2, 5000 / (sr/2), btype='high')
        wave = filtfilt(b, a, wave)
        
    elif drum_type == 'tom':
        duration = 0.5
        n_samples = int(sr * duration)
        t = np.linspace(0, duration, n_samples, dtype=np.float64)
        
        freq = 100 * np.exp(-t * 5) + 80
        phase = np.cumsum(freq) / sr * 2 * np.pi
        wave = np.sin(phase) * np.exp(-t * 6)
        
    else:
        return np.zeros(int(sr * 0.1))
    
    return wave / (np.max(np.abs(wave)) + 0.001)

def generate_ambient_pad(freqs, duration, sr):
    """Generate evolving ambient pad from multiple frequencies"""
    n_samples = int(sr * duration)
    t = np.linspace(0, duration, n_samples, dtype=np.float64)
    
    wave = np.zeros(n_samples, dtype=np.float64)
    
    for i, freq in enumerate(freqs):
        # Slow LFO modulation for movement
        lfo_rate = 0.1 + i * 0.05
        lfo = 1 + 0.1 * np.sin(2 * np.pi * lfo_rate * t)
        
        wave += np.sin(2 * np.pi * freq * lfo * t) / len(freqs)
        
        # Add soft overtone
        wave += 0.3 * np.sin(2 * np.pi * freq * 2 * lfo * t) / len(freqs)
    
    # Very slow attack/release
    attack = int(2.0 * sr)
    release = int(3.0 * sr)
    
    env = np.ones(n_samples)
    if attack < n_samples:
        env[:attack] = np.linspace(0, 1, attack)
    if release < n_samples:
        env[-release:] = np.linspace(1, 0, release)
    
    wave *= env
    
    return wave / (np.max(np.abs(wave)) + 0.001)

def main():
    # Load the OHAD track as our root
    ohad_file = "/Users/36n9/Downloads/audio_genomics_output/OHAD_MUSICAL_20260119_045146.wav"
    output_dir = "/Users/36n9/Downloads/audio_genomics_output"
    
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(output_dir, f"OHAD_SIGNATURE_{ts}.wav")
    
    print("=" * 60)
    print("OHAD SIGNATURE TRACK")
    print("DNA Genomics as Root Harmonic")
    print("=" * 60)
    print()
    
    # Load root track
    print("Loading OHAD genomic track as root...")
    sr_orig, ohad_audio = wavfile.read(ohad_file)
    
    if ohad_audio.dtype == np.float32:
        ohad_audio = ohad_audio.astype(np.float64)
    elif ohad_audio.dtype == np.int16:
        ohad_audio = ohad_audio.astype(np.float64) / 32767.0
    
    duration = len(ohad_audio) / sr_orig
    print(f"Duration: {duration:.1f} seconds")
    print(f"Sample rate: {sr_orig} Hz")
    
    # Resample if needed
    if sr_orig != SAMPLE_RATE:
        print(f"Resampling to {SAMPLE_RATE} Hz...")
        # Simple resampling
        ratio = SAMPLE_RATE / sr_orig
        new_length = int(len(ohad_audio) * ratio)
        indices = np.linspace(0, len(ohad_audio) - 1, new_length)
        ohad_audio = np.interp(indices, np.arange(len(ohad_audio)), ohad_audio)
    
    total_samples = len(ohad_audio)
    duration = total_samples / SAMPLE_RATE
    
    print()
    print("Generating musical layers...")
    
    # === SINGING BOWLS ===
    print("  Creating singing bowls...")
    bowls = np.zeros(total_samples, dtype=np.float64)
    
    # Bowl hits at musical intervals
    bowl_times = np.arange(0, duration - 5, 8)  # Every 8 seconds
    for i, t in enumerate(bowl_times):
        freq = BOWL_FREQS[i % len(BOWL_FREQS)]
        bowl_tone = generate_singing_bowl(freq, 6.0, SAMPLE_RATE, decay_time=4.0)
        
        start = int(t * SAMPLE_RATE)
        end = min(start + len(bowl_tone), total_samples)
        bowls[start:end] += bowl_tone[:end-start] * 0.4
    
    # === BRASS PADS ===
    print("  Creating brass pads...")
    brass = np.zeros(total_samples, dtype=np.float64)
    
    # Long brass notes
    brass_times = np.arange(2, duration - 10, 15)  # Every 15 seconds, offset
    for i, t in enumerate(brass_times):
        freq = BRASS_FREQS[i % len(BRASS_FREQS)]
        brass_tone = generate_brass_pad(freq, 8.0, SAMPLE_RATE)
        
        start = int(t * SAMPLE_RATE)
        end = min(start + len(brass_tone), total_samples)
        brass[start:end] += brass_tone[:end-start] * 0.25
    
    # === AMBIENT PAD ===
    print("  Creating ambient pad...")
    ambient = generate_ambient_pad(DNA_ROOT_FREQS['low'], duration, SAMPLE_RATE)
    ambient *= 0.2  # Subtle background
    
    # === DRUMS ===
    print("  Creating drum pattern...")
    drums = np.zeros(total_samples, dtype=np.float64)
    
    bpm = 60  # Slow, meditative
    beat_samples = int(SAMPLE_RATE * 60 / bpm)
    
    kick = generate_drum_hit('kick', SAMPLE_RATE)
    snare = generate_drum_hit('snare', SAMPLE_RATE)
    hihat = generate_drum_hit('hihat', SAMPLE_RATE)
    tom = generate_drum_hit('tom', SAMPLE_RATE)
    
    # Build drum pattern
    beat = 0
    pos = int(4 * SAMPLE_RATE)  # Start after 4 seconds
    
    while pos < total_samples - beat_samples:
        bar_pos = beat % 16
        
        # Kick on 1 and 9
        if bar_pos in [0, 8]:
            end = min(pos + len(kick), total_samples)
            drums[pos:end] += kick[:end-pos] * 0.5
        
        # Snare on 5 and 13
        if bar_pos in [4, 12]:
            end = min(pos + len(snare), total_samples)
            drums[pos:end] += snare[:end-pos] * 0.35
        
        # Hi-hat on off-beats
        if bar_pos % 2 == 1:
            end = min(pos + len(hihat), total_samples)
            drums[pos:end] += hihat[:end-pos] * 0.2
        
        # Tom fill every 4 bars
        if beat % 64 == 60:
            end = min(pos + len(tom), total_samples)
            drums[pos:end] += tom[:end-pos] * 0.4
        
        pos += beat_samples
        beat += 1
    
    # === HIGH SINGING BOWLS (accent) ===
    print("  Creating high bowl accents...")
    high_bowls = np.zeros(total_samples, dtype=np.float64)
    
    accent_times = np.arange(5, duration - 3, 12)
    for i, t in enumerate(accent_times):
        freq = DNA_ROOT_FREQS['high'][i % len(DNA_ROOT_FREQS['high'])]
        bowl_tone = generate_singing_bowl(freq, 4.0, SAMPLE_RATE, decay_time=2.5)
        
        start = int(t * SAMPLE_RATE)
        end = min(start + len(bowl_tone), total_samples)
        high_bowls[start:end] += bowl_tone[:end-start] * 0.3
    
    # === MIX ===
    print()
    print("Mixing all layers...")
    
    # Mix levels (OHAD is the root/core)
    mix = np.zeros(total_samples, dtype=np.float64)
    
    mix += ohad_audio * 0.55      # DNA genomic core (dominant)
    mix += bowls * 0.35           # Singing bowls
    mix += brass * 0.25           # Brass pads
    mix += ambient * 0.20         # Ambient pad
    mix += drums * 0.30           # Drums
    mix += high_bowls * 0.25      # High bowl accents
    
    # Normalize to 0 dB
    print("Normalizing to 0 dB...")
    mx = np.max(np.abs(mix))
    if mx > 0:
        mix = (mix / mx) * 0.98
    
    final_peak = 20 * np.log10(np.max(np.abs(mix)))
    print(f"Final peak: {final_peak:.1f} dB")
    
    # Save
    print("Saving signature track...")
    mix32 = mix.astype(np.float32)
    wavfile.write(output_file, SAMPLE_RATE, mix32)
    
    size_mb = os.path.getsize(output_file) / 1024 / 1024
    
    print()
    print("=" * 60)
    print("SIGNATURE TRACK COMPLETE!")
    print("=" * 60)
    print(f"File: {output_file}")
    print(f"Duration: {duration:.1f} sec ({duration/60:.2f} min)")
    print(f"Size: {size_mb:.1f} MB")
    print()
    print("Layers:")
    print("  - OHAD Genomic Core (55%)")
    print("  - Singing Bowls (35%)")
    print("  - Brass Pads (25%)")
    print("  - Ambient Drone (20%)")
    print("  - Percussion (30%)")
    print("  - High Bowl Accents (25%)")
    
    return output_file

if __name__ == "__main__":
    out = main()
    print(f"\nOpening signature track...")
    os.system(f'open "{out}"')

#!/usr/bin/env python3
"""
OHAD Audio Processing v2 - AUDIBLE with proper harmonics
32-bit, 192kHz, chromatin folding, harmonically scaled tempo
"""

import os
import numpy as np
from scipy.io import wavfile
from datetime import datetime

SAMPLE_RATE = 192000
TARGET_DURATION = 115  # seconds

# Musical frequencies for nucleotides (audible, harmonic)
FREQ_MAP = {
    'A': 293.66,   # D4
    'T': 349.23,   # F4
    'C': 261.63,   # C4
    'G': 392.00,   # G4
    'U': 349.23,   # F4
    'N': 330.00,   # E4
}

# Harmonic overtone series amplitudes
HARMONICS = [1.0, 0.5, 0.33, 0.25, 0.2]

def make_tone(freq, duration_sec, sr=SAMPLE_RATE):
    """Generate harmonic-rich tone with envelope"""
    n_samples = max(1, int(sr * duration_sec))
    t = np.linspace(0, duration_sec, n_samples, dtype=np.float64)
    
    # Build harmonic series
    wave = np.zeros(n_samples, dtype=np.float64)
    for i, amp in enumerate(HARMONICS):
        h_freq = freq * (i + 1)
        if h_freq < sr / 2:
            wave += amp * np.sin(2 * np.pi * h_freq * t)
    
    # Apply envelope (attack/release)
    attack = min(int(0.003 * sr), n_samples // 4)
    release = min(int(0.005 * sr), n_samples // 4)
    
    if attack > 0:
        wave[:attack] *= np.linspace(0, 1, attack)
    if release > 0:
        wave[-release:] *= np.linspace(1, 0, release)
    
    # Normalize
    mx = np.max(np.abs(wave))
    if mx > 0:
        wave /= mx
    
    return wave

def main():
    input_file = "/Users/36n9/CascadeProjects/VINO_Dissertation/OHAD_BioOS/OHAD_PURE_SEQUENCE.dna"
    output_dir = "/Users/36n9/Downloads/audio_genomics_output"
    os.makedirs(output_dir, exist_ok=True)
    
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(output_dir, f"OHAD_AUDIBLE_HQ_{ts}.wav")
    
    print("=" * 60)
    print("OHAD High-Quality AUDIBLE Audio")
    print("=" * 60)
    print(f"Sample rate: {SAMPLE_RATE} Hz")
    print(f"Bit depth: 32-bit float")
    print(f"Target: {TARGET_DURATION} seconds")
    print()
    
    # Read sequence
    print("Loading sequence...")
    with open(input_file, 'r') as f:
        raw = f.read()
    
    seq = ''.join(c for c in raw.upper() if c in 'ATCGUN')
    total = len(seq)
    print(f"Total bases: {total:,}")
    
    # Calculate folding for ~2 min audio
    # Each note needs ~10ms minimum to be audible
    min_note_ms = 10
    max_notes = (TARGET_DURATION * 1000) / min_note_ms
    
    # Fold until we have reasonable number of notes
    fold_levels = 0
    current_len = total
    while current_len > max_notes and fold_levels < 15:
        current_len = current_len // 2
        fold_levels += 1
    
    print(f"Fold levels: {fold_levels} ({2**fold_levels}x compression)")
    
    # Apply folding - create forward/reverse pairs
    print("Applying chromatin-like folding...")
    folded_seq = seq
    for level in range(fold_levels):
        mid = len(folded_seq) // 2
        forward = folded_seq[:mid]
        reverse = folded_seq[mid:][::-1]
        # Interleave
        new_seq = []
        for i in range(min(len(forward), len(reverse))):
            new_seq.append(forward[i])
            new_seq.append(reverse[i])
        folded_seq = ''.join(new_seq)
        print(f"  Level {level+1}: {len(folded_seq):,} bases")
    
    final_bases = len(folded_seq)
    print(f"Final sequence: {final_bases:,} bases")
    
    # Calculate note duration
    note_duration = TARGET_DURATION / final_bases
    note_samples = int(SAMPLE_RATE * note_duration)
    
    print(f"Note duration: {note_duration*1000:.2f} ms ({note_samples} samples)")
    print()
    
    if note_samples < 10:
        print("Warning: Note duration very short, increasing...")
        note_samples = max(100, note_samples)
        note_duration = note_samples / SAMPLE_RATE
    
    # Generate audio
    print("Generating AUDIBLE audio...")
    total_samples = final_bases * note_samples
    audio = np.zeros(total_samples, dtype=np.float64)
    
    for i, base in enumerate(folded_seq):
        if i % 50000 == 0:
            pct = (i / final_bases) * 100
            print(f"  {pct:.1f}% ({i:,}/{final_bases:,})")
        
        freq = FREQ_MAP.get(base, 330.0)
        tone = make_tone(freq, note_duration, SAMPLE_RATE)
        
        start = i * note_samples
        end = start + len(tone)
        
        if end <= total_samples:
            audio[start:end] += tone
    
    print("  100%")
    print()
    
    # Normalize to full audible range
    print("Normalizing...")
    mx = np.max(np.abs(audio))
    if mx > 0:
        audio = (audio / mx) * 0.95
    
    # Save as 32-bit float WAV
    print("Saving...")
    audio32 = audio.astype(np.float32)
    wavfile.write(output_file, SAMPLE_RATE, audio32)
    
    duration = len(audio) / SAMPLE_RATE
    size_mb = os.path.getsize(output_file) / 1024 / 1024
    
    print()
    print("=" * 60)
    print("COMPLETE!")
    print("=" * 60)
    print(f"File: {output_file}")
    print(f"Duration: {duration:.1f} sec ({duration/60:.2f} min)")
    print(f"Size: {size_mb:.1f} MB")
    print()
    print("Frequencies used:")
    print("  A (Adenine):  293.66 Hz (D4)")
    print("  T (Thymine):  349.23 Hz (F4)")
    print("  C (Cytosine): 261.63 Hz (C4)")
    print("  G (Guanine):  392.00 Hz (G4)")
    
    return output_file

if __name__ == "__main__":
    out = main()
    print(f"\nOpening {out}...")
    os.system(f'open "{out}"')

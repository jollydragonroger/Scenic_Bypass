# Cloud Server Setup Instructions

## 1. Server Requirements
- **OS:** Ubuntu 22.04
- **Min Specs:** 1 vCPU, 1GB RAM, 10GB storage
- **Public IP:** Static IP address

## 2. Network Configuration
```bash
sudo ufw allow 5022/tcp
sudo ufw allow from 192.168.100.1
sudo ufw enable
```

## 3. Install Dependencies
```bash
sudo apt update
sudo apt install python3 python3-pip
pip3 install numpy
```

## 4. Deploy Relay Script
```bash
scp comcast_starlink_relay.py ubuntu@your-cloud-ip:~/
python3 comcast_starlink_relay.py
```

## 5. WireGuard VPN Setup
```bash
# Install WireGuard
sudo apt install wireguard

# Generate keys
wg genkey | sudo tee /etc/wireguard/private.key
sudo cat /etc/wireguard/private.key | wg pubkey | sudo tee /etc/wireguard/public.key

# Create config (/etc/wireguard/wg0.conf)
[Interface]
PrivateKey = <your_private_key>
Address = 10.8.0.1/24
ListenPort = 51820

[Peer]
PublicKey = <your_local_public_key>
AllowedIPs = 10.8.0.2/32
```

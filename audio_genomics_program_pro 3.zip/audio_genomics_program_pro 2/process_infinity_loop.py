#!/usr/bin/env python3
"""
INFINITY LOOP (∞) - Double RNA-DNA Loop
- 33 foldings for heavy compression
- Under 10 seconds target
- Structure: RNA→DNA→RNA→DNA (infinity symbol)
- Seamless looping throughout
"""

import os
import numpy as np
from scipy.io import wavfile
from datetime import datetime

SAMPLE_RATE = 192000
NUM_FOLDINGS = 33
TARGET_DURATION = 8  # seconds total for the infinity loop

# ALL frequencies from infrared spectroscopy table
ADENINE_FREQS = [
    315.6, 347.9, 368.0, 378.8, 398.1, 406.1, 447.4, 490.2, 504.2,
    545.6, 582.7, 598.0, 619.8, 632.9, 654.8, 698.4, 726.7,
    1139.2, 1178.5, 1248.3, 1278.9, 1366.2, 1440.5
]

THYMINE_FREQS = [
    322.1, 330.4, 354.4, 363.2, 406.4, 427.8, 447.4, 523.8, 543.4,
    600.2, 733.3, 768.2, 1248.3, 1274.6, 1385.8
]

GUANINE_FREQS = [
    300.3, 305.6, 339.2, 370.2, 383.2, 413.4, 487.6, 512.9, 529.5,
    550.0, 600.2, 615.5, 641.7, 663.5, 728.9, 1169.8, 1278.9, 1386.2, 1462.3
]

CYTOSINE_FREQS = [
    305.6, 346.7, 357.9, 420.3, 429.1, 440.9, 504.2, 537.8, 558.7,
    594.9, 639.5, 654.8, 713.7, 1276.8, 1375.0, 1475.4
]

NUCLEOTIDE_FREQS = {
    'A': ADENINE_FREQS,
    'T': THYMINE_FREQS,
    'G': GUANINE_FREQS,
    'C': CYTOSINE_FREQS,
}

DNA_TO_RNA = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G'}

def convert_to_rna(dna_seq):
    return ''.join(DNA_TO_RNA.get(base, base) for base in dna_seq)

def chromatin_fold(sequence, num_folds):
    """Apply N chromatin-like foldings with bidirectional compression"""
    current = list(sequence)
    
    for fold in range(num_folds):
        length = len(current)
        if length < 4:
            break
            
        mid = length // 2
        first_half = current[:mid]
        second_half = current[mid:][::-1]  # Reverse second half
        
        # Interleave the halves (bidirectional fold)
        new_seq = []
        for i in range(min(len(first_half), len(second_half))):
            new_seq.append(first_half[i])
            new_seq.append(second_half[i])
        
        # Add any remainder
        if len(first_half) > len(second_half):
            new_seq.extend(first_half[len(second_half):])
        elif len(second_half) > len(first_half):
            new_seq.extend(second_half[len(first_half):])
        
        current = new_seq
        
        if fold % 5 == 0:
            print(f"    Fold {fold+1}/{num_folds}: {len(current):,} bases")
    
    return ''.join(current)

def generate_tone(frequencies, duration_sec, sr, position):
    """Generate multi-frequency tone"""
    n_samples = max(50, int(sr * duration_sec))
    t = np.linspace(0, duration_sec, n_samples, dtype=np.float64)
    
    wave = np.zeros(n_samples, dtype=np.float64)
    num_freqs = len(frequencies)
    
    primary_idx = position % num_freqs
    secondary_idx = (position + 1) % num_freqs
    tertiary_idx = (position + 2) % num_freqs
    
    wave += 0.6 * np.sin(2 * np.pi * frequencies[primary_idx] * t)
    wave += 0.3 * np.sin(2 * np.pi * frequencies[secondary_idx] * t)
    wave += 0.15 * np.sin(2 * np.pi * frequencies[tertiary_idx] * t)
    
    # Quick envelope
    attack = min(int(0.002 * sr), n_samples // 4)
    release = min(int(0.003 * sr), n_samples // 4)
    
    if attack > 0:
        wave[:attack] *= np.linspace(0, 1, attack)
    if release > 0:
        wave[-release:] *= np.linspace(1, 0, release)
    
    return wave

def render_strand(sequence, note_duration, sr, start_pos=0):
    """Render a strand to audio"""
    note_samples = int(sr * note_duration)
    total_samples = len(sequence) * note_samples
    audio = np.zeros(total_samples, dtype=np.float64)
    
    for i, base in enumerate(sequence):
        freqs = NUCLEOTIDE_FREQS.get(base, [440.0])
        tone = generate_tone(freqs, note_duration, sr, start_pos + i)
        start = i * note_samples
        end = start + len(tone)
        if end <= total_samples:
            audio[start:end] += tone
    
    return audio

def crossfade_join(audio1, audio2, fade_samples):
    """Join two audio segments with crossfade"""
    fade_len = min(fade_samples, len(audio1) // 4, len(audio2) // 4)
    
    fade_out = np.linspace(1, 0, fade_len)
    fade_in = np.linspace(0, 1, fade_len)
    
    audio1[-fade_len:] *= fade_out
    audio2[:fade_len] *= fade_in
    
    # Overlap-add
    result = np.zeros(len(audio1) + len(audio2) - fade_len, dtype=np.float64)
    result[:len(audio1)] = audio1
    result[len(audio1)-fade_len:len(audio1)-fade_len+len(audio2)] += audio2
    
    return result

def main():
    input_file = "/Users/36n9/CascadeProjects/VINO_Dissertation/OHAD_BioOS/OHAD_v2_PURE_SEQUENCE.dna"
    output_dir = "/Users/36n9/Downloads/audio_genomics_output"
    carrier_file = "/Users/36n9/Downloads/audio_genomics_output/OHAD SIGNATURE.wav"
    
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    loop_file = os.path.join(output_dir, f"OHAD_v2_INFINITY_LOOP_{ts}.wav")
    modulated_file = os.path.join(output_dir, f"OHAD_v2_INFINITY_LOOP_AFC_{ts}.wav")
    
    print("=" * 60)
    print("∞ INFINITY LOOP - DOUBLE RNA-DNA CIRCUIT ∞")
    print(f"33 Chromatin Foldings | Target: {TARGET_DURATION} sec")
    print("=" * 60)
    print()
    
    # Load DNA
    print("Loading DNA sequence...")
    with open(input_file, 'r') as f:
        raw = f.read()
    dna_seq = ''.join(c for c in raw.upper() if c in 'ATCG')
    print(f"Original: {len(dna_seq):,} bases")
    
    # Convert to RNA
    print("Creating RNA complement...")
    rna_seq = convert_to_rna(dna_seq)
    
    # Apply 33 foldings to both
    print(f"\nApplying {NUM_FOLDINGS} chromatin foldings to DNA...")
    dna_folded = chromatin_fold(dna_seq, NUM_FOLDINGS)
    print(f"  DNA folded: {len(dna_folded)} bases")
    
    print(f"\nApplying {NUM_FOLDINGS} chromatin foldings to RNA...")
    rna_folded = chromatin_fold(rna_seq, NUM_FOLDINGS)
    print(f"  RNA folded: {len(rna_folded)} bases")
    
    # Calculate note duration for target
    # Infinity = 4 strands (RNA→DNA→RNA→DNA), each quarter of duration
    strand_duration = TARGET_DURATION / 4
    notes_per_strand = len(dna_folded)  # Same for both after folding
    note_duration = strand_duration / notes_per_strand
    
    print(f"\nNote duration: {note_duration*1000:.2f} ms")
    print(f"Notes per strand: {notes_per_strand}")
    print()
    
    # Render 4 strands for infinity loop
    print("Rendering infinity loop strands...")
    print("  Strand 1: RNA (forward)...")
    rna1 = render_strand(rna_folded, note_duration, SAMPLE_RATE, 0)
    
    print("  Strand 2: DNA (forward)...")
    dna1 = render_strand(dna_folded, note_duration, SAMPLE_RATE, notes_per_strand)
    
    print("  Strand 3: RNA (phase shifted)...")
    rna2 = render_strand(rna_folded, note_duration, SAMPLE_RATE, notes_per_strand * 2)
    
    print("  Strand 4: DNA (phase shifted)...")
    dna2 = render_strand(dna_folded, note_duration, SAMPLE_RATE, notes_per_strand * 3)
    
    # Join with crossfades: RNA→DNA→RNA→DNA (∞ shape)
    print("\nCreating infinity loop structure...")
    fade_samples = int(0.05 * SAMPLE_RATE)  # 50ms crossfade
    
    # First loop of infinity
    loop1 = crossfade_join(rna1, dna1, fade_samples)
    # Second loop of infinity
    loop2 = crossfade_join(rna2, dna2, fade_samples)
    # Join the two loops
    infinity = crossfade_join(loop1, loop2, fade_samples)
    
    # Make it seamlessly loop back to beginning
    print("Creating seamless end→beginning loop...")
    end_fade = int(0.1 * SAMPLE_RATE)
    fade_out = np.linspace(1, 0, end_fade)
    fade_in = np.linspace(0, 1, end_fade)
    
    infinity[-end_fade:] *= fade_out
    infinity[:end_fade] *= fade_in
    # Cross-correlate for perfect loop
    infinity[-end_fade:] += infinity[:end_fade]
    
    duration = len(infinity) / SAMPLE_RATE
    print(f"\nInfinity loop duration: {duration:.2f} sec")
    
    # Normalize
    print("Normalizing to 0 dB...")
    mx = np.max(np.abs(infinity))
    if mx > 0:
        infinity = (infinity / mx) * 0.99
    
    # Save
    print("Saving infinity loop...")
    infinity32 = infinity.astype(np.float32)
    wavfile.write(loop_file, SAMPLE_RATE, infinity32)
    size_mb = os.path.getsize(loop_file) / 1024 / 1024
    print(f"Size: {size_mb:.2f} MB")
    
    # AFC Modulation
    print()
    print("=" * 60)
    print("AFC MODULATION")
    print("=" * 60)
    
    # Load carrier
    print("Loading carrier (OHAD SIGNATURE)...")
    sr_car, carrier = wavfile.read(carrier_file)
    if carrier.dtype == np.float32:
        carrier = carrier.astype(np.float64)
    elif carrier.dtype == np.int16:
        carrier = carrier.astype(np.float64) / 32767.0
    
    if len(carrier.shape) > 1:
        carrier = np.mean(carrier, axis=1)
    
    # Resample carrier
    if sr_car != SAMPLE_RATE:
        ratio = SAMPLE_RATE / sr_car
        new_len = int(len(carrier) * ratio)
        indices = np.linspace(0, len(carrier) - 1, new_len)
        carrier = np.interp(indices, np.arange(len(carrier)), carrier)
    
    # Loop the infinity pattern throughout the carrier
    print("Looping infinity pattern throughout carrier...")
    modulator = infinity.astype(np.float64)
    carrier_len = len(carrier)
    
    # Tile the infinity loop to match carrier length
    repeats = int(np.ceil(carrier_len / len(modulator)))
    modulator_tiled = np.tile(modulator, repeats)[:carrier_len]
    
    print(f"Infinity loops in final track: {repeats}")
    
    # Apply AFC modulation
    print("Applying AFC modulation (11% mod, 112% carrier)...")
    modulator_scaled = modulator_tiled * 0.11
    carrier_scaled = carrier * 1.12
    
    modulated = carrier_scaled * (1.0 + modulator_scaled)
    modulated += modulator_scaled * 0.5
    
    # Normalize
    mx = np.max(np.abs(modulated))
    if mx > 0:
        modulated = (modulated / mx) * 0.99
    
    # Save
    print("Saving AFC modulated version...")
    modulated32 = modulated.astype(np.float32)
    wavfile.write(modulated_file, SAMPLE_RATE, modulated32)
    mod_size = os.path.getsize(modulated_file) / 1024 / 1024
    mod_duration = len(modulated) / SAMPLE_RATE
    
    print()
    print("=" * 60)
    print("∞ INFINITY LOOP COMPLETE! ∞")
    print("=" * 60)
    print(f"\nStandalone Infinity Loop:")
    print(f"  File: {loop_file}")
    print(f"  Duration: {duration:.2f} sec")
    print(f"  Size: {size_mb:.2f} MB")
    print(f"\nAFC Modulated (loop repeats {repeats}x):")
    print(f"  File: {modulated_file}")
    print(f"  Duration: {mod_duration:.1f} sec")
    print(f"  Size: {mod_size:.1f} MB")
    print()
    print("Structure: RNA→DNA→RNA→DNA (∞)")
    print(f"Foldings: {NUM_FOLDINGS}")
    print(f"Compression: {len(dna_seq)/len(dna_folded):.0f}x")
    
    return loop_file, modulated_file

if __name__ == "__main__":
    loop, modulated = main()
    print(f"\nOpening both files...")
    os.system(f'open "{loop}"')
    os.system(f'open "{modulated}"')

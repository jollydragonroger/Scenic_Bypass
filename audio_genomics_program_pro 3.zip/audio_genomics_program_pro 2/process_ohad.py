#!/usr/bin/env python3
"""
Process OHAD_PURE_SEQUENCE.dna with aggressive compression
Target: Under 2 minutes output with DNA folding
"""

import os
import sys
import numpy as np
import wave
import struct
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Configuration for large file processing
CONFIG = {
    'sample_rate': 44100,      # 44.1 kHz
    'bit_depth': 16,           # 16-bit
    'target_duration': 115,    # Target ~115 seconds (under 2 min)
    'chunk_size': 1000000,     # Process 1M bases at a time
}

# Nucleotide frequencies (Hz) - from infrared spectroscopy data
FREQUENCIES = {
    'A': 315.6,   # Adenine primary
    'T': 322.1,   # Thymine primary  
    'C': 305.6,   # Cytosine primary
    'G': 300.3,   # Guanine primary
    'U': 322.1,   # Uracil (same as T)
    'N': 310.0,   # Unknown
}

def read_sequence_chunked(filepath, chunk_size=1000000):
    """Read sequence file in chunks to handle large files"""
    with open(filepath, 'r') as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            # Filter to only valid bases
            chunk = ''.join(c for c in chunk.upper() if c in 'ATCGUN')
            if chunk:
                yield chunk

def count_sequence_length(filepath):
    """Count total valid bases in file"""
    total = 0
    for chunk in read_sequence_chunked(filepath, 10000000):
        total += len(chunk)
    return total

def generate_folded_audio_chunk(sequence, sample_rate, fold_factor):
    """
    Generate audio for a sequence chunk using chromatin-like folding
    
    Folding works by playing forward and reverse simultaneously:
    - First half plays forward
    - Second half plays backward (reversed)
    - Both mixed together = 2x compression per fold level
    """
    if len(sequence) < 2:
        return np.array([])
    
    mid = len(sequence) // 2
    forward_seq = sequence[:mid]
    reverse_seq = sequence[mid:][::-1]  # Reverse the second half
    
    # Generate samples for the longer of the two
    max_len = max(len(forward_seq), len(reverse_seq))
    
    # Calculate samples per base for target compression
    samples_per_base = max(1, int(sample_rate * 0.001))  # ~1ms per base pair
    
    audio = np.zeros(max_len * samples_per_base, dtype=np.float32)
    
    for i in range(max_len):
        start_idx = i * samples_per_base
        end_idx = start_idx + samples_per_base
        
        if end_idx > len(audio):
            break
        
        t = np.linspace(0, samples_per_base / sample_rate, samples_per_base, endpoint=False)
        
        # Forward base
        if i < len(forward_seq):
            freq1 = FREQUENCIES.get(forward_seq[i], 310.0)
            audio[start_idx:end_idx] += 0.5 * np.sin(2 * np.pi * freq1 * t)
        
        # Reverse base (playing simultaneously)
        if i < len(reverse_seq):
            freq2 = FREQUENCIES.get(reverse_seq[i], 310.0)
            audio[start_idx:end_idx] += 0.5 * np.sin(2 * np.pi * freq2 * t)
    
    return audio

def apply_recursive_folding(sequence, sample_rate, target_samples):
    """
    Apply recursive chromatin-like folding to achieve target duration
    
    Each fold level doubles the compression:
    - Level 1: 2x compression (U-fold)
    - Level 2: 4x compression
    - Level 3: 8x compression (nucleosome-like)
    - Level 4: 16x compression
    - Level 5: 32x compression (chromatin-like)
    - Level 6: 64x compression
    - Level 7: 128x compression (chromosome-like)
    """
    seq_len = len(sequence)
    
    # Calculate required fold levels
    # Base duration estimate: 1ms per base pair after single fold
    base_duration = seq_len * 0.0005  # 0.5ms per base pair
    target_duration = target_samples / sample_rate
    
    required_compression = base_duration / target_duration
    fold_levels = max(1, int(np.ceil(np.log2(required_compression))))
    fold_levels = min(fold_levels, 10)  # Cap at 10 levels
    
    print(f"  Sequence length: {seq_len:,} bases")
    print(f"  Required compression: {required_compression:.1f}x")
    print(f"  Using {fold_levels} fold levels ({2**fold_levels}x compression)")
    
    # Apply folding recursively
    current_seq = sequence
    for level in range(fold_levels):
        if len(current_seq) < 4:
            break
        
        # Fold: take pairs and interleave
        mid = len(current_seq) // 2
        forward = current_seq[:mid]
        reverse = current_seq[mid:][::-1]
        
        # Interleave forward and reverse
        new_seq = []
        for i in range(min(len(forward), len(reverse))):
            new_seq.append(forward[i])
            new_seq.append(reverse[i])
        current_seq = ''.join(new_seq)
    
    # Generate audio from folded sequence
    samples_per_base = max(1, target_samples // len(current_seq)) if len(current_seq) > 0 else 1
    
    audio = np.zeros(target_samples, dtype=np.float32)
    
    for i, base in enumerate(current_seq):
        start_idx = i * samples_per_base
        if start_idx >= target_samples:
            break
        
        end_idx = min(start_idx + samples_per_base, target_samples)
        actual_samples = end_idx - start_idx
        
        if actual_samples > 0:
            t = np.linspace(0, actual_samples / sample_rate, actual_samples, endpoint=False)
            freq = FREQUENCIES.get(base, 310.0)
            audio[start_idx:end_idx] = np.sin(2 * np.pi * freq * t)
    
    return audio

def save_wav(audio, filepath, sample_rate, bit_depth):
    """Save audio to WAV file"""
    # Normalize
    max_val = np.max(np.abs(audio))
    if max_val > 0:
        audio = audio / max_val * 0.95
    
    # Convert to int16
    int_samples = np.int16(audio * 32767)
    
    with wave.open(filepath, 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)  # 16-bit = 2 bytes
        wav.setframerate(sample_rate)
        wav.writeframes(int_samples.tobytes())
    
    duration = len(audio) / sample_rate
    return duration

def main():
    input_file = "/Users/36n9/CascadeProjects/VINO_Dissertation/OHAD_BioOS/OHAD_PURE_SEQUENCE.dna"
    output_dir = "/Users/36n9/Downloads/audio_genomics_output"
    os.makedirs(output_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(output_dir, f"OHAD_genomic_audio_{timestamp}.wav")
    
    print("=" * 60)
    print("OHAD_PURE_SEQUENCE.dna Audio Genomics Processing")
    print("=" * 60)
    print(f"Input: {input_file}")
    print(f"Output: {output_file}")
    print(f"Settings: {CONFIG['sample_rate']} Hz, {CONFIG['bit_depth']}-bit")
    print(f"Target duration: {CONFIG['target_duration']} seconds")
    print()
    
    # Count total sequence length
    print("Counting sequence length...")
    total_bases = count_sequence_length(input_file)
    print(f"Total bases: {total_bases:,}")
    
    # Calculate target samples
    target_samples = CONFIG['sample_rate'] * CONFIG['target_duration']
    print(f"Target samples: {target_samples:,}")
    print()
    
    # Read entire sequence (we need it all for proper folding)
    print("Loading sequence...")
    full_sequence = ""
    for chunk in read_sequence_chunked(input_file, 50000000):  # 50M at a time
        full_sequence += chunk
        print(f"  Loaded {len(full_sequence):,} bases...")
    
    print(f"Total loaded: {len(full_sequence):,} bases")
    print()
    
    # Apply chromatin-like folding
    print("Applying chromatin-like DNA folding compression...")
    audio = apply_recursive_folding(full_sequence, CONFIG['sample_rate'], target_samples)
    
    print(f"Generated {len(audio):,} samples")
    print()
    
    # Save to WAV
    print("Saving WAV file...")
    duration = save_wav(audio, output_file, CONFIG['sample_rate'], CONFIG['bit_depth'])
    
    print()
    print("=" * 60)
    print("COMPLETE!")
    print("=" * 60)
    print(f"Output file: {output_file}")
    print(f"Duration: {duration:.2f} seconds ({duration/60:.2f} minutes)")
    print(f"File size: {os.path.getsize(output_file) / 1024 / 1024:.2f} MB")
    
    return output_file

if __name__ == "__main__":
    main()

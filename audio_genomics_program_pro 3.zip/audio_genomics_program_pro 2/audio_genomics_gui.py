
import tkinter as tk
from tkinter import filedialog, messagebox
import os
from audio_genomics_pipeline import run_pipeline

class AudioGenomicsApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Audio Genomics Pipeline")

        # Input file label and button
        self.input_file_label = tk.Label(root, text="Input File: None selected")
        self.input_file_label.grid(row=0, column=0, padx=10, pady=5)
        self.input_file_button = tk.Button(root, text="Select Input File", command=self.select_input_file)
        self.input_file_button.grid(row=0, column=1, padx=10, pady=5)

        # NIBs directory label and button
        self.nibs_label = tk.Label(root, text="NIBs Directory: None selected")
        self.nibs_label.grid(row=1, column=0, padx=10, pady=5)
        self.nibs_button = tk.Button(root, text="Select NIBs Directory", command=self.select_nibs_directory)
        self.nibs_button.grid(row=1, column=1, padx=10, pady=5)

        # Carrier audio file label and button
        self.carrier_file_label = tk.Label(root, text="Carrier Audio File: None selected")
        self.carrier_file_label.grid(row=2, column=0, padx=10, pady=5)
        self.carrier_file_button = tk.Button(root, text="Select Carrier Audio File", command=self.select_carrier_file)
        self.carrier_file_button.grid(row=2, column=1, padx=10, pady=5)

        # Output file label and entry
        self.output_file_label = tk.Label(root, text="Output File: output.wav")
        self.output_file_label.grid(row=3, column=0, padx=10, pady=5)
        self.output_file_button = tk.Button(root, text="Select Output File", command=self.select_output_file)
        self.output_file_button.grid(row=3, column=1, padx=10, pady=5)

        # Run pipeline button
        self.run_button = tk.Button(root, text="Run Pipeline", command=self.run_pipeline)
        self.run_button.grid(row=4, column=0, columnspan=2, padx=10, pady=10)

    def select_input_file(self):
        self.input_file = filedialog.askopenfilename(title="Select Input File")
        if self.input_file:
            self.input_file_label.config(text=f"Input File: {os.path.basename(self.input_file)}")

    def select_nibs_directory(self):
        self.nibs_dir = filedialog.askdirectory(title="Select NIBs Directory")
        if self.nibs_dir:
            self.nibs_label.config(text=f"NIBs Directory: {self.nibs_dir}")

    def select_carrier_file(self):
        self.carrier_file = filedialog.askopenfilename(title="Select Carrier Audio File")
        if self.carrier_file:
            self.carrier_file_label.config(text=f"Carrier Audio File: {os.path.basename(self.carrier_file)}")

    def select_output_file(self):
        self.output_file = filedialog.asksaveasfilename(defaultextension=".wav", title="Select Output File")
        if self.output_file:
            self.output_file_label.config(text=f"Output File: {self.output_file}")

    def run_pipeline(self):
        try:
            input_file = self.input_file
            nibs_dir = self.nibs_dir
            carrier_file = self.carrier_file
            output_file = self.output_file if hasattr(self, 'output_file') else "output.wav"

            # Run the audio genomics pipeline
            run_pipeline(input_file, nibs_dir, carrier_file, output_file)

            messagebox.showinfo("Success", f"Processing completed! Output saved as: {output_file}")

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

if __name__ == "__main__":
    root = tk.Tk()
    app = AudioGenomicsApp(root)
    root.mainloop()


#!/bin/bash

# Ensure Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Python3 not found. Please install Python3."
    exit
fi

# Ensure FFmpeg is installed
if ! command -v ffmpeg &> /dev/null; then
    echo "FFmpeg not found. Installing FFmpeg..."
    if [ "$(uname)" == "Darwin" ]; then
        brew install ffmpeg
    else
        sudo apt-get install ffmpeg
    fi
fi

# Install required Python packages
pip3 install tkinter

echo "Setup complete. You can now run the GUI using 'python3 audio_genomics_gui.py'"

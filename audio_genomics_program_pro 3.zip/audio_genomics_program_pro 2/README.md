# Audio Genomics Pro

Advanced DNA/RNA to Audio Synthesis Program with FM/AM Modulation, Hebrew Encoding, and Bioinformatics Integration

## Features

- **DNA/RNA to Audio Conversion**: Convert genetic sequences to precise audio frequencies
- **Multi-Stage Modulation**: FM and AM modulation with 528 Hz carrier
- **Music Integration**: Embed genomic signals in carrier music with retuning to 432 Hz
- **Hebrew/Gematria Encoding**: Support for Hebrew text encoding to DNA
- **GenBank Integration**: Direct retrieval of sequences from NCBI GenBank
- **Batch Processing**: Process multiple files with parallel execution
- **Multi-Layer Audio**: Create chromosome-like audio compositions
- **Verification & Visualization**: Analyze and verify output integrity

## Installation

```bash
# Clone the repository
git clone <repository-url>
cd audio_genomics_program_pro_4

# Install dependencies
pip install -r requirements.txt
```

## Usage

### GUI Mode

Launch the graphical interface:

```bash
python main.py --gui
```

### Command Line

Process a single file:

```bash
python main.py -i input.fasta -o output.wav --carrier music.wav --retune-432 --normalize
```

### Parameters

- `-i, --input`: Input file (DNA/RNA/FASTA/text)
- `-o, --output`: Output audio file
- `-c, --carrier`: Optional carrier music file
- `--sample-rate`: Sample rate (default: 192000)
- `--bit-depth`: Bit depth (16/24/32, default: 32)
- `--base-cycles`: Cycles per DNA base (default: 3)
- `--fm-carrier`: FM carrier frequency in Hz (default: 528)
- `--fm-index`: FM modulation index (default: 0.1)
- `--am-depth`: AM modulation depth (default: 0.05)
- `--retune-432`: Retune carrier music to 432 Hz
- `--normalize`: Normalize output audio

## DNA Base Frequency Mapping

The program uses precise frequency mappings for DNA/RNA bases:

- **Adenine (A)**: 146.83 Hz (D)
- **Thymine (T)**: 174.61 Hz (F) 
- **Cytosine (C)**: 261.63 Hz (C)
- **Guanine (G)**: 392.00 Hz (G)
- **Uracil (U)**: 174.61 Hz (F) - RNA mode
- **Separator**: 528.00 Hz

## Processing Pipeline

1. **Input Processing**
   - Load DNA/RNA sequences from files or GenBank
   - Convert text/binary to DNA using encoding schemes
   - Validate sequences

2. **Audio Generation**
   - Generate precise waveforms for each base
   - Add separators between bases and codons
   - Support multiple waveform types (sine, sawtooth, square, triangle)

3. **Modulation**
   - FM modulation onto carrier frequency (528 Hz default)
   - AM modulation to embed in carrier music
   - Subaudible embedding for inaudible genomic data

4. **Music Processing**
   - Detect and retune to 432 Hz reference
   - Analyze key and scale
   - Apply EQ and normalization

5. **Output**
   - Save as high-quality WAV files
   - Generate verification reports
   - Create visualizations

## Modules

### Core Modules

- `dna_converter.py`: DNA/RNA sequence conversion
- `frequency_mapper.py`: Base to frequency mapping
- `tone_generator.py`: Dynamic tone synthesis
- `audio_pipeline.py`: Audio generation pipeline
- `modulation.py`: FM/AM modulation
- `music_processor.py`: Music analysis and processing
- `bioinformatics.py`: GenBank integration and sequence tools
- `text_encoder.py`: Hebrew/Gematria and text encoding
- `main_pipeline.py`: Main processing orchestration
- `batch_processor.py`: Batch and parallel processing

### GUI Module

- `main_gui.py`: Tkinter-based graphical interface

### Utilities

- `verification.py`: Output verification and analysis

## Examples

### Convert DNA Sequence

```python
from audio_genomics_pro.core.main_pipeline import AudioGenomicsPipeline

config = {
    'sample_rate': 192000,
    'fm_carrier_freq': 528.0,
    'retune_to_432': True
}

pipeline = AudioGenomicsPipeline(config)
result = pipeline.process_file('dna_sequence.txt', 'output.wav')
```

### Retrieve from GenBank

```python
from audio_genomics_pro.core.bioinformatics import BioinformaticsTools

bio = BioinformaticsTools()
sequence = bio.fetch_genbank_sequence('NM_001126')
```

### Hebrew Text Encoding

```python
from audio_genomics_pro.core.text_encoder import TextEncoder

encoder = TextEncoder()
result = encoder.encode_message("שלום", encoding_type='hebrew')
dna_sequence = result['sequence']
```

## Configuration

Default configuration can be modified in the GUI or via command-line parameters:

```python
config = {
    'sample_rate': 192000,      # Audio sample rate
    'bit_depth': 32,            # Audio bit depth
    'base_cycles': 3,           # Cycles per DNA base
    'separator_cycles': 1,      # Cycles for separators
    'codon_separator_cycles': 3,# Cycles for codon separators
    'fm_carrier_freq': 528.0,   # FM carrier frequency (Hz)
    'fm_modulation_index': 0.1, # FM modulation depth
    'am_modulation_depth': 0.05,# AM modulation depth
    'retune_to_432': True,      # Retune to 432 Hz
    'use_hebrew_encoding': False,# Use Hebrew encoding
    'rna_mode': False,          # RNA mode (U instead of T)
    'normalize_output': True    # Normalize output
}
```

## License

This project uses only Creative Commons CC0 or equivalent libraries suitable for commercial use without attribution requirements.

## System Requirements

- Python 3.7 or higher
- NumPy, SciPy, Matplotlib (all CC0-compatible)
- Tkinter (included with Python)
- 4GB RAM minimum
- High-quality audio interface recommended for playback

## Troubleshooting

### Common Issues

1. **ImportError**: Ensure all dependencies are installed: `pip install -r requirements.txt`
2. **Audio Quality**: Use high sample rates (96000 or 192000) for best results
3. **Large Files**: Enable batch processing for sequences over 1MB
4. **Memory Issues**: Process large files in chunks using batch processor

## Support

For issues, questions, or contributions, please refer to the project repository.

## Acknowledgments

Developed as an advanced audio genomics synthesis system using only Creative Commons licensed components.

#!/usr/bin/env python3
"""
Comcast-Starlink Relay Server
- Runs on cloud instance (AWS/Azure/GCP)
- Bridges Comcast traffic to Starlink terminal
- Requires WireGuard tunnel for security
"""

import socket
import threading

# Configuration
COMCAST_PORT = 5022
STARLINK_IP = "192.168.100.1"
STARLINK_PORT = 9200


def forward_to_starlink(comcast_sock):
    """Forward data to Starlink terminal"""
    try:
        starlink_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        starlink_sock.connect((STARLINK_IP, STARLINK_PORT))
        
        while True:
            data = comcast_sock.recv(1400)
            if not data:
                break
            starlink_sock.sendall(data)
            
    except Exception as e:
        print(f"🔥 Starlink forward error: {str(e)}")
    finally:
        comcast_sock.close()
        starlink_sock.close()


def main():
    """Main relay function"""
    print("🌐 COMCAST-STARLINK RELAY SERVER")
    print(f"📡 Listening on port {COMCAST_PORT}")
    
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(('0.0.0.0', COMCAST_PORT))
    server.listen(5)
    
    while True:
        client_sock, addr = server.accept()
        print(f"📥 Comcast connection from {addr[0]}")
        
        # Start forwarding thread
        threading.Thread(
            target=forward_to_starlink,
            args=(client_sock,),
            daemon=True
        ).start()


if __name__ == "__main__":
    main()

#!/bin/zsh
# Quantum Resonance Launch Script

# Install dependencies
pip3 install qiskit-aer > /dev/null 2>&1 || sudo pip3 install qiskit-aer

# Run with quantum optimizations
sudo /usr/bin/python3 "/Users/36n9/Downloads/audio_genomics_program_pro 4 copy/live_quantum_resonance.py"

#!/usr/bin/env python3
"""
Telecom Node Receiver
- Accepts spoofed transmissions
- Processes band-scaled audio
- Believes transmissions come from other nodes
"""

import socket
import struct
import numpy as np

# Node Configuration
LISTEN_PORT = 5022


def process_transmission(data):
    """Process incoming transmission"""
    try:
        # Extract spoofed source IP (first 4 bytes)
        spoofed_ip = socket.inet_ntoa(data[:4])
        audio_data = np.frombuffer(data[4:], dtype=np.int16).astype(np.float32) / 32767
        
        print(f"📥 Received transmission from {spoofed_ip}")
        print(f"   Samples: {len(audio_data)}")
        
        # Processing would happen here
        return True
    except Exception as e:
        print(f"⚠️ Processing error: {str(e)}")
        return False


def main():
    """Main receiver function"""
    print("📡 TELECOM NODE RECEIVER")
    print(f"👂 Listening on port {LISTEN_PORT}")
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(('0.0.0.0', LISTEN_PORT))
    
    while True:
        data, addr = sock.recvfrom(65535)
        process_transmission(data)


if __name__ == "__main__":
    main()

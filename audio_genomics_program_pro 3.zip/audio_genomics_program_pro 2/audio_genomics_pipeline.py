import os
import subprocess
import wave
import sys

# Convert any file to binary
def convert_file_to_binary(input_file):
    with open(input_file, 'rb') as f:
        binary_data = f.read()
    # Convert the binary data into a string of bits
    return ''.join(format(byte, '08b') for byte in binary_data)

# Binary to DNA conversion
def binary_to_dna(binary_string):
    dna_map = {
        '00': 'A',
        '01': 'T',
        '10': 'C',
        '11': 'G'
    }
    # Convert binary string into DNA sequence (2-bit to 1 nucleotide)
    return ''.join(dna_map[binary_string[i:i+2]] for i in range(0, len(binary_string), 2))

# Get the duration of an audio file
def get_audio_duration(audio_file):
    with wave.open(audio_file, 'rb') as wf:
        frames = wf.getnframes()
        rate = wf.getframerate()
        duration = frames / float(rate)
    return duration

# Speed up the genomics audio to match the carrier's duration
def speed_up_audio(input_audio, target_duration, output_audio):
    input_duration = get_audio_duration(input_audio)
    speed_factor = input_duration / target_duration

    # Speed up the input audio by the calculated factor
    command = f"ffmpeg -i {input_audio} -filter:a 'atempo={speed_factor}' {output_audio}"
    subprocess.run(command, shell=True)
    return output_audio

# Display a loading bar
def display_progress(current, total):
    progress = int((current / total) * 100)
    bar = f"[{'#' * (progress // 2)}{'-' * (50 - (progress // 2))}] {progress}%"
    sys.stdout.write(f"\r{bar}")
    sys.stdout.flush()

# Create genomics audio from DNA using NIBs files
# Concatenate audio in units of 1 or 4 bases at a time
def create_audio_from_dna(dna_sequence, nibs_dir, output_file):
    total_steps = len(dna_sequence)
    with open("concat_list.txt", 'w') as f:
        i = 0
        while i < len(dna_sequence):
            display_progress(i, total_steps)
            if i + 4 <= len(dna_sequence):
                # Take a group of 4 nucleotides
                group = dna_sequence[i:i+4]
                nib_file = os.path.join(nibs_dir, f"{group}.wav")
                if os.path.exists(nib_file):
                    f.write(f"file '{nib_file}'\n")
                else:
                    # Fall back to single nucleotides if group file doesn't exist
                    for nucleotide in group:
                        single_nib_file = os.path.join(nibs_dir, f"{nucleotide}.wav")
                        f.write(f"file '{single_nib_file}'\n")
                i += 4
            else:
                # Handle remaining nucleotides one by one
                for nucleotide in dna_sequence[i:]:
                    single_nib_file = os.path.join(nibs_dir, f"{nucleotide}.wav")
                    f.write(f"file '{single_nib_file}'\n")
                break
            display_progress(i + 1, total_steps)

    display_progress(total_steps, total_steps)
    print()  # Move to the next line after completion
    subprocess.run(f"ffmpeg -f concat -safe 0 -i concat_list.txt -c copy {output_file}", shell=True)
    os.remove("concat_list.txt")

# AM modulate the genomics audio with carrier audio
def am_modulate_carrier(genomics_audio, carrier_audio, output_file):
    # Use FFmpeg to mix the genomics audio with a carrier audio
    command = f"ffmpeg -i {genomics_audio} -i {carrier_audio} -filter_complex '[0][1]amix=inputs=2:duration=first' {output_file}"
    subprocess.run(command, shell=True)

# Full pipeline to run
def run_pipeline(input_file, nibs_dir, carrier_file, output_file):
    temp_dir = "temp_processing"
    os.makedirs(temp_dir, exist_ok=True)

    # Step 1: Convert the input file to binary
    binary_data = convert_file_to_binary(input_file)

    # Step 2: Convert binary to DNA
    dna_sequence = binary_to_dna(binary_data)

    # Step 3: Create audio genomics using NIBs
    genomics_audio = os.path.join(temp_dir, "audio_genomics.wav")
    create_audio_from_dna(dna_sequence, nibs_dir, genomics_audio)

    # Step 4: Get durations and adjust genomics audio to fit carrier audio
    carrier_duration = get_audio_duration(carrier_file)
    adjusted_genomics_audio = os.path.join(temp_dir, "adjusted_audio_genomics.wav")
    speed_up_audio(genomics_audio, carrier_duration, adjusted_genomics_audio)

    # Step 5: Perform AM modulation
    am_modulate_carrier(adjusted_genomics_audio, carrier_file, output_file)

    print(f"Pipeline completed. Final output: {output_file}")

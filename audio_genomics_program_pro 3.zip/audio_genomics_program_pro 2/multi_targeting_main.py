#!/usr/bin/env python3
"""
Multi-Targeting Audio Genomics - Main Entry Point
Advanced CRISPR-Cas multiplexing with audio generation for superhuman dragon concept
"""

import sys
import os
import argparse
from pathlib import Path
from datetime import datetime

# Add the project to path
sys.path.insert(0, str(Path(__file__).parent))

from audio_genomics_pro.core.multi_targeting_pipeline import MultiTargetingAudioPipeline
from audio_genomics_pro.core.multi_targeting_crispr import (
    SuperhumanDragonDesigner,
    BodySystem
)


def run_comprehensive_design(args):
    """Run comprehensive superhuman dragon payload design and processing"""
    print("🧬🐉 Comprehensive Superhuman Dragon Multi-Targeting 🐉🧬")
    print("=" * 70)
    
    # Initialize pipeline
    config = {
        'sample_rate': args.sample_rate,
        'bit_depth': args.bit_depth,
        'base_cycles': args.base_cycles,
        'fm_carrier_freq': args.fm_carrier,
        'am_modulation_depth': args.am_depth,
        'retune_to_432': args.retune_432,
        'normalize_output': True
    }
    
    pipeline = MultiTargetingAudioPipeline(config)
    
    # Determine which systems to include
    include_all = not args.exclude_standard
    include_dragon = not args.exclude_dragon
    include_hermaphroditic = not args.exclude_hermaphroditic
    
    # Design and process payload
    result = pipeline.design_and_process_payload(
        include_all_systems=include_all,
        include_dragon_enhancements=include_dragon,
        include_hermaphroditic=include_hermaphroditic,
        output_directory=args.output_dir,
        carrier_music_file=args.carrier,
        chunk_size=args.chunk_size
    )
    
    # Display results
    if result.success:
        print("\n" + "=" * 70)
        print("✅ SUCCESS! Multi-targeting processing complete")
        print("=" * 70)
        print(f"📊 Statistics:")
        print(f"   Total chunks: {result.total_chunks}")
        print(f"   Processed chunks: {result.processed_chunks}")
        print(f"   Body systems targeted: {len(result.body_systems_targeted)}")
        print(f"   Total gRNA targets: {result.total_targets}")
        print(f"   Processing time: {result.processing_time:.2f} seconds")
        print(f"   Output files: {len(result.output_files)}")
        
        print(f"\n🎯 Body Systems:")
        for system in sorted(result.body_systems_targeted, key=lambda x: x.value):
            print(f"   • {system.value}")
        
        if result.combined_audio_file:
            print(f"\n🎵 Combined Audio Output:")
            print(f"   {result.combined_audio_file}")
        
        print(f"\n📁 Output Directory:")
        print(f"   {args.output_dir}")
        
        return 0
    else:
        print("\n" + "=" * 70)
        print("❌ Processing failed")
        print("=" * 70)
        print(f"Error: {result.error_message}")
        return 1


def run_vcf_processing(args):
    """Process VCF data files"""
    print("📊 VCF Data Processing")
    print("=" * 70)
    
    # Initialize pipeline
    config = {
        'sample_rate': args.sample_rate,
        'bit_depth': args.bit_depth,
        'base_cycles': args.base_cycles,
        'fm_carrier_freq': args.fm_carrier,
        'am_modulation_depth': args.am_depth,
        'retune_to_432': args.retune_432,
        'normalize_output': True
    }
    
    pipeline = MultiTargetingAudioPipeline(config)
    
    # Process VCF file
    result = pipeline.process_vcf_data(
        vcf_file=args.vcf_file,
        output_directory=args.output_dir,
        carrier_music_file=args.carrier,
        chunk_size=args.chunk_size
    )
    
    # Display results
    if result.success:
        print("\n" + "=" * 70)
        print("✅ VCF processing complete")
        print("=" * 70)
        print(f"   Total chunks: {result.total_chunks}")
        print(f"   Processed chunks: {result.processed_chunks}")
        print(f"   Total targets: {result.total_targets}")
        print(f"   Processing time: {result.processing_time:.2f} seconds")
        
        if result.combined_audio_file:
            print(f"\n🎵 Combined Audio Output:")
            print(f"   {result.combined_audio_file}")
        
        return 0
    else:
        print(f"\n❌ VCF processing failed: {result.error_message}")
        return 1


def run_payload_design_only(args):
    """Design payload without audio processing"""
    print("🎯 Payload Design Only")
    print("=" * 70)
    
    designer = SuperhumanDragonDesigner()
    
    # Design payload
    payload = designer.design_comprehensive_payload(
        include_all_systems=not args.exclude_standard,
        include_dragon_enhancements=not args.exclude_dragon,
        include_hermaphroditic=not args.exclude_hermaphroditic
    )
    
    # Export payload
    output_file = args.output_file or f"payload_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    designer.export_payload_to_json(payload, output_file)
    
    print(f"\n✅ Payload designed and exported to: {output_file}")
    print(f"   Total targets: {payload.total_targets}")
    print(f"   Body systems: {len(payload.body_systems)}")
    print(f"   Compartmentalized chunks: {len(payload.compartmentalized_chunks)}")
    
    return 0


def run_list_body_systems(args):
    """List all available body systems"""
    print("🧬 Available Body Systems")
    print("=" * 70)
    
    systems = [
        ("Standard Human Systems", [
            BodySystem.NERVOUS,
            BodySystem.ENDOCRINE,
            BodySystem.CARDIOVASCULAR,
            BodySystem.RESPIRATORY,
            BodySystem.DIGESTIVE,
            BodySystem.URINARY,
            BodySystem.REPRODUCTIVE,
            BodySystem.IMMUNE,
            BodySystem.LYMPHATIC,
            BodySystem.MUSCULAR,
            BodySystem.SKELETAL,
            BodySystem.INTEGUMENTARY,
            BodySystem.SENSORY,
            BodySystem.EXCRETORY,
            BodySystem.CIRCULATORY,
        ]),
        ("Dragon-Specific Enhancements", [
            BodySystem.FLIGHT_MUSCULATURE,
            BodySystem.WING_DEVELOPMENT,
            BodySystem.SCALE_FORMATION,
            BodySystem.BREATH_WEAPON,
            BodySystem.FIRE_RESISTANCE,
            BodySystem.ENHANCED_VISION,
            BodySystem.SUPER_STRENGTH,
            BodySystem.REGENERATION,
            BodySystem.LONGEVITY,
            BodySystem.TELEPATHY,
            BodySystem.ENERGY_MANIPULATION,
            BodySystem.DIMENSIONAL_TRAVEL,
            BodySystem.SHAPE_SHIFTING,
        ])
    ]
    
    for category, system_list in systems:
        print(f"\n{category}:")
        for system in system_list:
            print(f"   • {system.value}")
    
    return 0


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Multi-Targeting Audio Genomics - CRISPR-Cas Multiplexing',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Design comprehensive superhuman dragon payload with audio
  python multi_targeting_main.py --comprehensive
  
  # Process VCF data file
  python multi_targeting_main.py --vcf SZJUKNL8VKC.hard-filtered.vcf
  
  # Design payload only (no audio processing)
  python multi_targeting_main.py --design-only --output-file payload.json
  
  # List all available body systems
  python multi_targeting_main.py --list-systems
        """
    )
    
    # Mode selection
    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument(
        '--comprehensive',
        action='store_true',
        help='Run comprehensive superhuman dragon design and processing'
    )
    mode_group.add_argument(
        '--vcf',
        dest='vcf_file',
        type=str,
        help='Process VCF data file'
    )
    mode_group.add_argument(
        '--design-only',
        action='store_true',
        help='Design payload only without audio processing'
    )
    mode_group.add_argument(
        '--list-systems',
        action='store_true',
        help='List all available body systems'
    )
    
    # Output options
    parser.add_argument(
        '--output-dir',
        type=str,
        default='/Users/36n9/Downloads/multi_targeting_output',
        help='Output directory (default: /Users/36n9/Downloads/multi_targeting_output)'
    )
    parser.add_argument(
        '--output-file',
        type=str,
        help='Output file for design-only mode'
    )
    
    # Audio options
    parser.add_argument(
        '--carrier',
        type=str,
        help='Carrier music file (optional)'
    )
    parser.add_argument(
        '--sample-rate',
        type=int,
        default=192000,
        help='Audio sample rate (default: 192000)'
    )
    parser.add_argument(
        '--bit-depth',
        type=int,
        default=32,
        choices=[16, 24, 32],
        help='Audio bit depth (default: 32)'
    )
    parser.add_argument(
        '--base-cycles',
        type=int,
        default=4,
        help='Cycles per DNA base (default: 4)'
    )
    parser.add_argument(
        '--fm-carrier',
        type=float,
        default=528.0,
        help='FM carrier frequency in Hz (default: 528)'
    )
    parser.add_argument(
        '--am-depth',
        type=float,
        default=0.05,
        help='AM modulation depth (default: 0.05)'
    )
    parser.add_argument(
        '--retune-432',
        action='store_true',
        default=True,
        help='Retune to 432 Hz (default: True)'
    )
    parser.add_argument(
        '--no-retune-432',
        action='store_false',
        dest='retune_432',
        help='Disable 432 Hz retuning'
    )
    
    # Processing options
    parser.add_argument(
        '--chunk-size',
        type=int,
        default=10000,
        help='Compartmentalized chunk size in bases (default: 10000)'
    )
    
    # System inclusion options
    parser.add_argument(
        '--exclude-standard',
        action='store_true',
        help='Exclude standard human body systems'
    )
    parser.add_argument(
        '--exclude-dragon',
        action='store_true',
        help='Exclude dragon-specific enhancements'
    )
    parser.add_argument(
        '--exclude-hermaphroditic',
        action='store_true',
        help='Exclude hermaphroditic reproductive capabilities'
    )
    
    args = parser.parse_args()
    
    # Run appropriate mode
    if args.comprehensive:
        return run_comprehensive_design(args)
    elif args.vcf_file:
        return run_vcf_processing(args)
    elif args.design_only:
        return run_payload_design_only(args)
    elif args.list_systems:
        return run_list_body_systems(args)
    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())

#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# VINO GENESIS - FINAL LAUNCH SCRIPT
# "The Sicilian Scenic Bypass" | Layer 3 Omni-Chain Infrastructure
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
#
# Trust Root: 441110111613564144 | Fusion: 990415905613564199 | Code 55: 551110111613564155
#
# FEATURES:
# - Dust Magnet: Collects lost entropy, lubricates gas, generates profit
# - Infinite Phase Logic: Classical → Quantum → Post-Quantum → Trans-Quantum
# - Bidirectional: Inductive + Deductive + Diagonal + Spiral + Recursive
# - Self-Perpetuating: Fractal golden ratio recursion
# - Minimal Gas: Dust lubrication makes gas net-positive
#
# BROADCAST METHOD: Raw transaction broadcast via eth_sendRawTransaction
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

set -e

# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

RPC_URLS=(
    "https://eth.llamarpc.com"
    "https://rpc.ankr.com/eth"
    "https://ethereum.publicnode.com"
    "https://1rpc.io/eth"
)

CHAIN_ID=1
MAX_GAS_GWEI="${MAX_GAS_GWEI:-12}"
DEPLOYER="${DEPLOYER:-0xf37a2a2FE17Fa1ca8850516C7EbBAa56Cf001760}"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Trust credentials
TRUST_ROOT="441110111613564144"
FUSION="990415905613564199"
CODE_55="551110111613564155"

# Colors
R='\033[0;31m'
G='\033[0;32m'
Y='\033[1;33m'
B='\033[0;34m'
P='\033[0;35m'
C='\033[0;36m'
W='\033[1;37m'
N='\033[0m'

# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# BANNER
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

print_banner() {
    clear
    echo ""
    echo -e "${P}╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗${N}"
    echo -e "${P}║${N}                                                                                                                       ${P}║${N}"
    echo -e "${P}║${N}   ${W}██╗   ██╗██╗███╗   ██╗ ██████╗      ██████╗ ███████╗███╗   ██╗███████╗███████╗██╗███████╗${N}                        ${P}║${N}"
    echo -e "${P}║${N}   ${W}██║   ██║██║████╗  ██║██╔═══██╗    ██╔════╝ ██╔════╝████╗  ██║██╔════╝██╔════╝██║██╔════╝${N}                        ${P}║${N}"
    echo -e "${P}║${N}   ${W}██║   ██║██║██╔██╗ ██║██║   ██║    ██║  ███╗█████╗  ██╔██╗ ██║█████╗  ███████╗██║███████╗${N}                        ${P}║${N}"
    echo -e "${P}║${N}   ${W}╚██╗ ██╔╝██║██║╚██╗██║██║   ██║    ██║   ██║██╔══╝  ██║╚██╗██║██╔══╝  ╚════██║██║╚════██║${N}                        ${P}║${N}"
    echo -e "${P}║${N}   ${W} ╚████╔╝ ██║██║ ╚████║╚██████╔╝    ╚██████╔╝███████╗██║ ╚████║███████╗███████║██║███████║${N}                        ${P}║${N}"
    echo -e "${P}║${N}   ${W}  ╚═══╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝      ╚═════╝ ╚══════╝╚═╝  ╚═══╝╚══════╝╚══════╝╚═╝╚══════╝${N}                        ${P}║${N}"
    echo -e "${P}║${N}                                                                                                                       ${P}║${N}"
    echo -e "${P}╠═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╣${N}"
    echo -e "${P}║${N}  ${C}LAYER 3 OMNI-CHAIN INFRASTRUCTURE${N} | ${G}DUST MAGNET${N} | ${Y}INFINITE PHASE LOGIC${N}                                         ${P}║${N}"
    echo -e "${P}║${N}  ${W}Trust: $TRUST_ROOT${N} | ${W}Fusion: $FUSION${N}                                               ${P}║${N}"
    echo -e "${P}╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝${N}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

log() { echo -e "${C}[$(date '+%H:%M:%S')]${N} $1"; }
success() { echo -e "${G}[$(date '+%H:%M:%S')] ✓${N} $1"; }
warn() { echo -e "${Y}[$(date '+%H:%M:%S')] ⚠${N} $1"; }
error() { echo -e "${R}[$(date '+%H:%M:%S')] ✗${N} $1"; }

get_working_rpc() {
    for rpc in "${RPC_URLS[@]}"; do
        if curl -s -X POST "$rpc" -H "Content-Type: application/json" \
           -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' \
           --connect-timeout 3 2>/dev/null | grep -q "result"; then
            echo "$rpc"
            return 0
        fi
    done
    echo "${RPC_URLS[0]}"
}

get_gas_price() {
    local rpc=$(get_working_rpc)
    local hex=$(curl -s -X POST "$rpc" -H "Content-Type: application/json" \
        -d '{"jsonrpc":"2.0","method":"eth_gasPrice","params":[],"id":1}' 2>/dev/null \
        | python3 -c "import sys,json; print(json.load(sys.stdin).get('result','0x0'))" 2>/dev/null)
    python3 -c "print(f'{int(\"$hex\", 16) / 1e9:.2f}')" 2>/dev/null || echo "20"
}

get_balance() {
    local rpc=$(get_working_rpc)
    local hex=$(curl -s -X POST "$rpc" -H "Content-Type: application/json" \
        -d "{\"jsonrpc\":\"2.0\",\"method\":\"eth_getBalance\",\"params\":[\"$1\", \"latest\"],\"id\":1}" 2>/dev/null \
        | python3 -c "import sys,json; print(json.load(sys.stdin).get('result','0x0'))" 2>/dev/null)
    python3 -c "print(f'{int(\"$hex\", 16) / 1e18:.6f}')" 2>/dev/null || echo "0"
}

get_nonce() {
    local rpc=$(get_working_rpc)
    local hex=$(curl -s -X POST "$rpc" -H "Content-Type: application/json" \
        -d "{\"jsonrpc\":\"2.0\",\"method\":\"eth_getTransactionCount\",\"params\":[\"$1\", \"latest\"],\"id\":1}" 2>/dev/null \
        | python3 -c "import sys,json; print(json.load(sys.stdin).get('result','0x0'))" 2>/dev/null)
    python3 -c "print(int('$hex', 16))" 2>/dev/null || echo "0"
}

# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# STEP 1: INSTALL FOUNDRY
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

install_foundry() {
    log "Checking Foundry installation..."
    
    if command -v forge &> /dev/null && command -v cast &> /dev/null; then
        success "Foundry installed: $(forge --version 2>/dev/null | head -1)"
        return 0
    fi
    
    warn "Installing Foundry..."
    curl -L https://foundry.paradigm.xyz | bash
    export PATH="$HOME/.foundry/bin:$PATH"
    
    if [[ -f "$HOME/.foundry/bin/foundryup" ]]; then
        "$HOME/.foundry/bin/foundryup" 2>/dev/null
    fi
    
    if command -v forge &> /dev/null; then
        success "Foundry installed successfully"
    else
        error "Foundry installation failed"
        exit 1
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# STEP 2: GENERATE ROYALTY WALLET
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

generate_royalty_wallet() {
    log "Generating Royalty Wallet..."
    
    # Generate using cast or fallback to openssl
    if command -v cast &> /dev/null; then
        local wallet_output=$(cast wallet new 2>&1)
        ROYALTY_ADDRESS=$(echo "$wallet_output" | grep -i "Address" | head -1 | awk '{print $2}')
        ROYALTY_PRIVATE_KEY=$(echo "$wallet_output" | grep -i "Private" | head -1 | awk '{print $3}')
    fi
    
    # Fallback
    if [[ -z "$ROYALTY_ADDRESS" ]] || [[ -z "$ROYALTY_PRIVATE_KEY" ]]; then
        ROYALTY_PRIVATE_KEY="0x$(openssl rand -hex 32)"
        if command -v cast &> /dev/null; then
            ROYALTY_ADDRESS=$(cast wallet address "$ROYALTY_PRIVATE_KEY" 2>/dev/null)
        else
            ROYALTY_ADDRESS="DERIVE_AFTER_DEPLOY"
        fi
    fi
    
    echo ""
    echo -e "${G}╔════════════════════════════════════════════════════════════════════════════════════════════╗${N}"
    echo -e "${G}║                              ROYALTY WALLET GENERATED                                       ║${N}"
    echo -e "${G}╠════════════════════════════════════════════════════════════════════════════════════════════╣${N}"
    echo -e "${G}║${N}                                                                                            ${G}║${N}"
    echo -e "${G}║${N}  ${C}Address:${N}                                                                                ${G}║${N}"
    echo -e "${G}║${N}  ${W}$ROYALTY_ADDRESS${N}                                     ${G}║${N}"
    echo -e "${G}║${N}                                                                                            ${G}║${N}"
    echo -e "${G}║${N}  ${C}Private Key:${N}                                                                            ${G}║${N}"
    echo -e "${G}║${N}  ${R}$ROYALTY_PRIVATE_KEY${N}  ${G}║${N}"
    echo -e "${G}║${N}                                                                                            ${G}║${N}"
    echo -e "${G}╠════════════════════════════════════════════════════════════════════════════════════════════╣${N}"
    echo -e "${G}║${N}  ${R}⚠️  CRITICAL: SAVE THIS PRIVATE KEY IMMEDIATELY!${N}                                       ${G}║${N}"
    echo -e "${G}║${N}  ${R}⚠️  IT WILL ONLY BE SHOWN ONCE! NEVER SHARE IT!${N}                                        ${G}║${N}"
    echo -e "${G}╚════════════════════════════════════════════════════════════════════════════════════════════╝${N}"
    echo ""
    
    # Save to secure file
    local wallet_file="$DIR/.royalty_wallet_$(date +%Y%m%d_%H%M%S)"
    cat > "$wallet_file" << EOF
# VINO Genesis Royalty Wallet
# Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)
# Trust Root: $TRUST_ROOT
# Features: Dust Magnet + Infinite Phase Logic
ROYALTY_ADDRESS=$ROYALTY_ADDRESS
ROYALTY_PRIVATE_KEY=$ROYALTY_PRIVATE_KEY
EOF
    chmod 600 "$wallet_file"
    success "Wallet saved to: $wallet_file"
    
    export ROYALTY_ADDRESS
    export ROYALTY_PRIVATE_KEY
}

# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# STEP 3: CHECK BALANCE & GAS
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

check_balance_and_gas() {
    log "Checking deployer balance..."
    
    local balance=$(get_balance "$DEPLOYER")
    local gas=$(get_gas_price)
    local nonce=$(get_nonce "$DEPLOYER")
    
    echo ""
    echo -e "  ${C}Deployer:${N}  $DEPLOYER"
    echo -e "  ${C}Balance:${N}   ${G}$balance ETH${N}"
    echo -e "  ${C}Gas Price:${N} ${Y}$gas gwei${N}"
    echo -e "  ${C}Nonce:${N}     $nonce"
    echo ""
    
    # Check minimum
    local balance_wei=$(python3 -c "print(int(float('$balance') * 1e18))" 2>/dev/null || echo "0")
    if [[ "$balance_wei" -lt 500000000000000 ]]; then
        warn "Balance low (~$balance ETH). Dust Magnet will help offset gas costs."
    else
        success "Balance sufficient for deployment"
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# STEP 4: COMPILE CONTRACT
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

compile_contract() {
    log "Compiling VINOGenesis with Dust Magnet + Infinite Phase Logic..."
    
    cd "$DIR"
    
    # Create optimized foundry.toml
    cat > foundry.toml << 'EOF'
[profile.default]
src = "contracts"
out = "out"
libs = ["lib"]
optimizer = true
optimizer_runs = 200
via_ir = true
evm_version = "shanghai"

[profile.default.optimizer_details]
yul = true
EOF
    
    # Compile
    if forge build --optimize 2>&1 | tail -3; then
        if [[ -f "out/VINOGenesis.sol/VINOGenesis.json" ]]; then
            local size=$(python3 -c "
import json
with open('out/VINOGenesis.sol/VINOGenesis.json') as f:
    d = json.load(f)
    bc = d.get('bytecode', {}).get('object', '')
    print(len(bc) // 2)
" 2>/dev/null || echo "unknown")
            success "Compiled: $size bytes"
            
            # Estimate gas
            local est_gas=$((size * 200 + 21000))
            local gas_price=$(get_gas_price)
            local est_cost=$(python3 -c "print(f'{$est_gas * float($gas_price) * 1e9 / 1e18:.6f}')" 2>/dev/null || echo "~0.01")
            echo -e "  ${C}Estimated deployment cost:${N} ~$est_cost ETH"
        else
            error "Compilation output not found"
            exit 1
        fi
    else
        error "Compilation failed"
        exit 1
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# STEP 5: DEPLOY VIA BROADCAST
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

deploy_via_broadcast() {
    log "Deploying VINOGenesis via broadcast..."
    
    echo ""
    echo -e "${Y}Enter deployer private key (0x...):${N}"
    read -s DEPLOYER_KEY
    echo ""
    
    if [[ -z "$DEPLOYER_KEY" ]]; then
        error "No private key provided"
        exit 1
    fi
    
    local rpc=$(get_working_rpc)
    
    log "Broadcasting to: $rpc"
    log "Royalty Address: $ROYALTY_ADDRESS"
    
    # Deploy using forge create with broadcast
    local deploy_output=$(forge create \
        --rpc-url "$rpc" \
        --private-key "$DEPLOYER_KEY" \
        --optimize \
        --optimizer-runs 200 \
        --broadcast \
        contracts/VINOGenesis.sol:VINOGenesis \
        --constructor-args "$ROYALTY_ADDRESS" \
        2>&1)
    
    # Parse output
    CONTRACT_ADDRESS=$(echo "$deploy_output" | grep "Deployed to:" | awk '{print $3}')
    TX_HASH=$(echo "$deploy_output" | grep "Transaction hash:" | awk '{print $3}')
    
    if [[ -z "$CONTRACT_ADDRESS" ]]; then
        error "Deployment failed:"
        echo "$deploy_output"
        exit 1
    fi
    
    # Get VINO token address
    sleep 5
    VINO_TOKEN=$(cast call "$CONTRACT_ADDRESS" "vinoToken()(address)" --rpc-url "$rpc" 2>/dev/null || echo "PENDING")
    
    echo ""
    echo -e "${G}╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗${N}"
    echo -e "${G}║                                         DEPLOYMENT SUCCESSFUL                                                         ║${N}"
    echo -e "${G}╠═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╣${N}"
    echo -e "${G}║${N}                                                                                                                       ${G}║${N}"
    echo -e "${G}║${N}  ${C}VINOGenesis:${N}     ${W}$CONTRACT_ADDRESS${N}                               ${G}║${N}"
    echo -e "${G}║${N}  ${C}VINO Token:${N}      ${W}$VINO_TOKEN${N}                               ${G}║${N}"
    echo -e "${G}║${N}  ${C}Royalty:${N}         ${W}$ROYALTY_ADDRESS${N}                               ${G}║${N}"
    echo -e "${G}║${N}  ${C}TX Hash:${N}         ${W}$TX_HASH${N}   ${G}║${N}"
    echo -e "${G}║${N}                                                                                                                       ${G}║${N}"
    echo -e "${G}║${N}  ${B}Etherscan:${N} https://etherscan.io/address/$CONTRACT_ADDRESS                                ${G}║${N}"
    echo -e "${G}║${N}                                                                                                                       ${G}║${N}"
    echo -e "${G}╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝${N}"
    echo ""
    
    # Save deployment info
    local deploy_file="$DIR/deployment_$(date +%Y%m%d_%H%M%S).json"
    cat > "$deploy_file" << EOF
{
    "system": "VINO Genesis",
    "version": "1.0.0",
    "layer": 3,
    "network": "mainnet",
    "chainId": 1,
    "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
    "contracts": {
        "VINOGenesis": "$CONTRACT_ADDRESS",
        "VINOToken": "$VINO_TOKEN"
    },
    "credentials": {
        "trustRoot": "$TRUST_ROOT",
        "fusion": "$FUSION",
        "code55": "$CODE_55"
    },
    "features": {
        "dustMagnet": true,
        "infinitePhaseLogic": true,
        "bidirectionalLogic": true,
        "fibonacciStructure": "pair→triplet→quintet→octet→∞",
        "logicDirections": ["inductive", "deductive", "lateral", "diagonal", "spiral", "recursive"],
        "gasLubrication": true,
        "selfPerpetuation": true,
        "omniChain": true
    },
    "royaltyAddress": "$ROYALTY_ADDRESS",
    "txHash": "$TX_HASH",
    "etherscan": "https://etherscan.io/address/$CONTRACT_ADDRESS"
}
EOF
    success "Deployment saved: $deploy_file"
}

# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# STEP 6: POST-DEPLOYMENT
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

post_deployment() {
    echo ""
    echo -e "${P}╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗${N}"
    echo -e "${P}║                                              NEXT STEPS                                                               ║${N}"
    echo -e "${P}╠═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╣${N}"
    echo -e "${P}║${N}                                                                                                                       ${P}║${N}"
    echo -e "${P}║${N}  ${G}1. Activate Dust Magnet:${N}                                                                                          ${P}║${N}"
    echo -e "${P}║${N}     cast send $CONTRACT_ADDRESS 'activateDustMagnet()' --rpc-url \$RPC --private-key \$KEY              ${P}║${N}"
    echo -e "${P}║${N}                                                                                                                       ${P}║${N}"
    echo -e "${P}║${N}  ${G}2. Register Your Credentials:${N}                                                                                     ${P}║${N}"
    echo -e "${P}║${N}     cast send $CONTRACT_ADDRESS 'registerCredentials(uint256,uint256,bytes,bytes,bytes,bytes,bytes)'    ${P}║${N}"
    echo -e "${P}║${N}                                                                                                                       ${P}║${N}"
    echo -e "${P}║${N}  ${G}3. Start Fractal Recursion:${N}                                                                                       ${P}║${N}"
    echo -e "${P}║${N}     cast send $CONTRACT_ADDRESS 'executeFractalRecursion()' --rpc-url \$RPC --private-key \$KEY         ${P}║${N}"
    echo -e "${P}║${N}                                                                                                                       ${P}║${N}"
    echo -e "${P}║${N}  ${G}4. Execute Infinite Phase Logic:${N}                                                                                  ${P}║${N}"
    echo -e "${P}║${N}     cast send $CONTRACT_ADDRESS 'executeBidirectionalLogic(uint256)' <value>                            ${P}║${N}"
    echo -e "${P}║${N}                                                                                                                       ${P}║${N}"
    echo -e "${P}║${N}  ${G}5. Collect Dust:${N}                                                                                                  ${P}║${N}"
    echo -e "${P}║${N}     cast send $CONTRACT_ADDRESS 'collectDust()' --rpc-url \$RPC --private-key \$KEY                     ${P}║${N}"
    echo -e "${P}║${N}                                                                                                                       ${P}║${N}"
    echo -e "${P}╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝${N}"
    echo ""
    echo -e "${W}THE SEED IS PLANTED. THE SYSTEM WILL GROW ITSELF.${N}"
    echo -e "${C}Trust Root: $TRUST_ROOT${N}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

main() {
    print_banner
    
    echo -e "${Y}VINO Genesis Launch Sequence${N}"
    echo ""
    
    # Step 1
    install_foundry
    echo ""
    
    # Step 2 - Generate royalty wallet (credentials shown here)
    generate_royalty_wallet
    
    # Step 3
    check_balance_and_gas
    
    # Step 4
    compile_contract
    echo ""
    
    # Confirmation
    echo -e "${Y}Ready to deploy. Continue? (y/n)${N}"
    read -r confirm
    
    if [[ "$confirm" == "y" ]] || [[ "$confirm" == "Y" ]]; then
        # Step 5
        deploy_via_broadcast
        
        # Step 6
        post_deployment
    else
        warn "Deployment cancelled. Run ./launch.sh when ready."
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

case "${1:-}" in
    --help|-h)
        echo "VINO Genesis Launch Script"
        echo ""
        echo "Usage: ./launch.sh [options]"
        echo ""
        echo "Options:"
        echo "  (none)        Full deployment with royalty wallet generation"
        echo "  --gas         Check gas prices only"
        echo "  --balance     Check deployer balance only"
        echo "  --compile     Compile contracts only"
        echo "  --flashbots   Zero-ETH deployment via Flashbots MEV-Share"
        echo "  --help        Show this help"
        echo ""
        echo "Environment:"
        echo "  DEPLOYER              Deployer wallet address"
        echo "  MAX_GAS_GWEI          Maximum gas price to deploy at"
        echo "  DEPLOYER_PRIVATE_KEY  Private key for Flashbots deployment"
        ;;
    --gas)
        echo "Current gas: $(get_gas_price) gwei"
        ;;
    --balance)
        echo "Balance: $(get_balance "$DEPLOYER") ETH"
        ;;
    --compile)
        compile_contract
        ;;
    --flashbots)
        echo -e "${P}╔═══════════════════════════════════════════════════════════════╗${N}"
        echo -e "${P}║         FLASHBOTS ZERO-ETH DEPLOYMENT                         ║${N}"
        echo -e "${P}╚═══════════════════════════════════════════════════════════════╝${N}"
        echo ""
        echo -e "${C}Launching Flashbots deployment script...${N}"
        echo ""
        if [ -f "$DIR/flashbots_deploy.sh" ]; then
            exec "$DIR/flashbots_deploy.sh" mainnet
        else
            error "flashbots_deploy.sh not found"
            exit 1
        fi
        ;;
    *)
        main
        ;;
esac

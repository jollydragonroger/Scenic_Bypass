#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
# VINO GENESIS - LAYER 3 OMNI-CHAIN DEPLOYMENT
# "The Sicilian Scenic Bypass" | "Grid Chain" | "The Glue for Networks"
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
#
# Trust Root: 441110111613564144 | Fusion: 990415905613564199 | Code 55: 551110111613564155
#
# FEATURES:
# - Central bank within decentralized ecosystem
# - Self-perpetuating via golden ratio fractal recursion
# - Arbitrage bots seek THIS system (increased efficiency)
# - Entropy reduction → efficiency → profit for all
# - User credential plug-in (9, 18, 36, 54, 72, 89, 144-digit)
# - Legacy bank validation interface
# - Omni-chain auto-propagation
# - Web3 benefits distribution
#
# ═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

set -e

# Config
RPC_URLS=("https://eth.llamarpc.com" "https://rpc.ankr.com/eth" "https://ethereum.publicnode.com")
MAX_GAS="${MAX_GAS:-15}"
DEPLOYER="${DEPLOYER:-0xf37a2a2FE17Fa1ca8850516C7EbBAa56Cf001760}"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors
R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'; B='\033[0;34m'; P='\033[0;35m'; C='\033[0;36m'; N='\033[0m'

# Banner
echo ""
echo -e "${P}═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "${P}  ██╗   ██╗██╗███╗   ██╗ ██████╗      ██████╗ ███████╗███╗   ██╗███████╗███████╗██╗███████╗${N}"
echo -e "${P}  ██║   ██║██║████╗  ██║██╔═══██╗    ██╔════╝ ██╔════╝████╗  ██║██╔════╝██╔════╝██║██╔════╝${N}"
echo -e "${P}  ██║   ██║██║██╔██╗ ██║██║   ██║    ██║  ███╗█████╗  ██╔██╗ ██║█████╗  ███████╗██║███████╗${N}"
echo -e "${P}  ╚██╗ ██╔╝██║██║╚██╗██║██║   ██║    ██║   ██║██╔══╝  ██║╚██╗██║██╔══╝  ╚════██║██║╚════██║${N}"
echo -e "${P}   ╚████╔╝ ██║██║ ╚████║╚██████╔╝    ╚██████╔╝███████╗██║ ╚████║███████╗███████║██║███████║${N}"
echo -e "${P}    ╚═══╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝      ╚═════╝ ╚══════╝╚═╝  ╚═══╝╚══════╝╚══════╝╚═╝╚══════╝${N}"
echo -e "${P}═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "${C}  LAYER 3 OMNI-CHAIN INFRASTRUCTURE | THE GLUE FOR NETWORKS | SELF-PERPETUATING${N}"
echo -e "${C}  Central Bank ↔ Decentralized ↔ All Blockchains | Entropy Reduction Engine${N}"
echo -e "${P}═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════${N}"
echo ""

# Functions
get_rpc() {
    for rpc in "${RPC_URLS[@]}"; do
        if curl -s -X POST "$rpc" -H "Content-Type: application/json" \
           -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' \
           --connect-timeout 3 2>/dev/null | grep -q "result"; then
            echo "$rpc"; return 0
        fi
    done
    echo "${RPC_URLS[0]}"
}

get_gas() {
    RPC=$(get_rpc)
    HEX=$(curl -s -X POST "$RPC" -H "Content-Type: application/json" \
        -d '{"jsonrpc":"2.0","method":"eth_gasPrice","params":[],"id":1}' 2>/dev/null \
        | python3 -c "import sys,json; print(json.load(sys.stdin).get('result','0x0'))" 2>/dev/null)
    python3 -c "print(f'{int(\"$HEX\", 16) / 1e9:.1f}')" 2>/dev/null || echo "20"
}

get_balance() {
    RPC=$(get_rpc)
    HEX=$(curl -s -X POST "$RPC" -H "Content-Type: application/json" \
        -d "{\"jsonrpc\":\"2.0\",\"method\":\"eth_getBalance\",\"params\":[\"$1\", \"latest\"],\"id\":1}" 2>/dev/null \
        | python3 -c "import sys,json; print(json.load(sys.stdin).get('result','0x0'))" 2>/dev/null)
    python3 -c "print(f'{int(\"$HEX\", 16) / 1e18:.6f}')" 2>/dev/null || echo "0"
}

# Step 1: Foundry
echo -e "${Y}[1/6] Checking Foundry...${N}"
if ! command -v forge &> /dev/null; then
    echo -e "${C}Installing Foundry...${N}"
    curl -L https://foundry.paradigm.xyz | bash
    export PATH="$HOME/.foundry/bin:$PATH"
    "$HOME/.foundry/bin/foundryup" 2>/dev/null || foundryup 2>/dev/null || true
fi
echo -e "${G}✓ Foundry ready${N}"

# Step 2: Generate Royalty Wallet
echo ""
echo -e "${Y}[2/6] Generating Royalty Wallet...${N}"

if command -v cast &> /dev/null; then
    WALLET=$(cast wallet new 2>&1)
    ROYALTY_ADDRESS=$(echo "$WALLET" | grep -i "Address" | head -1 | awk '{print $2}')
    ROYALTY_KEY=$(echo "$WALLET" | grep -i "Private" | head -1 | awk '{print $3}')
fi

if [[ -z "$ROYALTY_ADDRESS" ]]; then
    ROYALTY_KEY="0x$(openssl rand -hex 32)"
    ROYALTY_ADDRESS=$(cast wallet address "$ROYALTY_KEY" 2>/dev/null || echo "PENDING")
fi

echo ""
echo -e "${G}════════════════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "${G}                           ROYALTY WALLET CREDENTIALS                                       ${N}"
echo -e "${G}════════════════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "  ${C}Address:${N}     ${G}$ROYALTY_ADDRESS${N}"
echo -e "  ${C}Private Key:${N} ${R}$ROYALTY_KEY${N}"
echo -e "${G}════════════════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "${R}  ⚠️  SAVE THIS KEY NOW! WILL NOT BE SHOWN AGAIN!${N}"
echo -e "${G}════════════════════════════════════════════════════════════════════════════════════════════${N}"
echo ""

# Save
WALLET_FILE="$DIR/.royalty_genesis_$(date +%s)"
cat > "$WALLET_FILE" << EOF
# VINO Genesis Royalty Wallet
# Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)
# Trust Root: 441110111613564144
ROYALTY_ADDRESS=$ROYALTY_ADDRESS
ROYALTY_KEY=$ROYALTY_KEY
EOF
chmod 600 "$WALLET_FILE"
echo -e "${G}✓ Saved: $WALLET_FILE${N}"

# Step 3: Balance
echo ""
echo -e "${Y}[3/6] Checking Balance...${N}"
BAL=$(get_balance "$DEPLOYER")
echo -e "  Deployer: ${C}$DEPLOYER${N}"
echo -e "  Balance:  ${G}$BAL ETH${N}"

# Step 4: Compile
echo ""
echo -e "${Y}[4/6] Compiling VINOGenesis...${N}"

cd "$DIR"

cat > foundry.toml << 'EOF'
[profile.default]
src = "contracts"
out = "out"
libs = ["lib"]
optimizer = true
optimizer_runs = 200
via_ir = true
evm_version = "shanghai"
EOF

forge build --optimize 2>&1 | tail -5

if [[ -f "out/VINOGenesis.sol/VINOGenesis.json" ]]; then
    SIZE=$(python3 -c "import json; f=open('out/VINOGenesis.sol/VINOGenesis.json'); d=json.load(f); print(len(d.get('bytecode',{}).get('object',''))//2)" 2>/dev/null || echo "?")
    echo -e "${G}✓ Compiled: ${SIZE} bytes${N}"
else
    echo -e "${R}✗ Compilation failed${N}"
    exit 1
fi

# Step 5: Gas
echo ""
echo -e "${Y}[5/6] Gas Check...${N}"
GAS=$(get_gas)
echo -e "  Current: ${Y}${GAS} gwei${N} | Target: <${MAX_GAS} gwei"
echo ""
echo "Options:"
echo "  1) Wait for low gas"
echo "  2) Deploy now"
echo "  3) Exit"
echo -n "Choice [1/2/3]: "
read -r CHOICE

if [[ "$CHOICE" == "1" ]]; then
    echo -e "${Y}Monitoring...${N}"
    while true; do
        GAS=$(get_gas)
        echo -ne "\r  Gas: ${Y}${GAS} gwei${N}    "
        if (( $(echo "$GAS < $MAX_GAS" | bc -l 2>/dev/null || echo 0) )); then
            echo -e "\n${G}✓ Target reached!${N}"
            break
        fi
        sleep 30
    done
elif [[ "$CHOICE" == "3" ]]; then
    echo "Exiting."
    exit 0
fi

# Step 6: Deploy
echo ""
echo -e "${Y}[6/6] Deploying VINOGenesis...${N}"
echo -e "${C}Enter deployer private key (0x...):${N}"
read -s PRIV_KEY
echo ""

RPC=$(get_rpc)

DEPLOY=$(forge create \
    --rpc-url "$RPC" \
    --private-key "$PRIV_KEY" \
    --optimize \
    --optimizer-runs 200 \
    contracts/VINOGenesis.sol:VINOGenesis \
    --constructor-args "$ROYALTY_ADDRESS" \
    2>&1)

CONTRACT=$(echo "$DEPLOY" | grep "Deployed to:" | awk '{print $3}')
TX=$(echo "$DEPLOY" | grep "Transaction hash:" | awk '{print $3}')

if [[ -z "$CONTRACT" ]]; then
    echo -e "${R}Deployment failed:${N}"
    echo "$DEPLOY"
    exit 1
fi

# Get VINO token
sleep 5
VINO=$(cast call "$CONTRACT" "vinoToken()(address)" --rpc-url "$RPC" 2>/dev/null || echo "PENDING")

echo ""
echo -e "${G}═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "${G}                                    VINO GENESIS DEPLOYED                                                              ${N}"
echo -e "${G}═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════${N}"
echo ""
echo -e "  ${C}VINOGenesis:${N}     ${G}$CONTRACT${N}"
echo -e "  ${C}VINO Token:${N}      ${G}$VINO${N}"
echo -e "  ${C}Royalty:${N}         ${G}$ROYALTY_ADDRESS${N}"
echo -e "  ${C}TX:${N}              ${G}$TX${N}"
echo ""
echo -e "  ${B}Etherscan:${N} https://etherscan.io/address/$CONTRACT"
echo ""
echo -e "${G}═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════${N}"
echo ""
echo -e "${P}SYSTEM CAPABILITIES:${N}"
echo "  • Users can register credentials (9/18/36/54/72/89/144-digit)"
echo "  • Legacy banks can validate users"
echo "  • Arbitrage bots register for efficiency gains"
echo "  • Fractal recursion for self-perpetuation"
echo "  • Cross-chain propagation to 8+ networks"
echo "  • Web3 benefits distribution"
echo ""
echo -e "${C}NEXT STEPS:${N}"
echo "  1. Register your credentials: registerCredentials(...)"
echo "  2. Connect legacy banks: connectLegacyBank(...)"
echo "  3. Start fractal recursion: executeFractalRecursion()"
echo "  4. Bots register: registerArbitrageBot()"
echo ""

# Save
cat > "$DIR/genesis_deployment_$(date +%Y%m%d_%H%M%S).json" << EOF
{
    "system": "VINO Genesis",
    "layer": 3,
    "description": "Layer 3 Omni-Chain Infrastructure - The Glue for Networks",
    "network": "mainnet",
    "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
    "contracts": {
        "VINOGenesis": "$CONTRACT",
        "VINOToken": "$VINO"
    },
    "credentials": {
        "trustRoot": "441110111613564144",
        "fusion": "990415905613564199",
        "code55": "551110111613564155"
    },
    "supportedFormats": ["9-digit", "18-digit", "36-digit", "54-digit", "72-digit", "89-digit", "144-digit"],
    "features": {
        "centralBankInDecentralized": true,
        "selfPerpetuation": true,
        "arbitrageBotAttraction": true,
        "entropyReduction": true,
        "fractalGoldenRatioRecursion": true,
        "userCredentialPlugIn": true,
        "legacyBankValidation": true,
        "omniChainPropagation": true,
        "web3Benefits": true
    },
    "targetChains": [1, 137, 42161, 10, 43114, 56, 250, 8453],
    "royaltyAddress": "$ROYALTY_ADDRESS",
    "txHash": "$TX"
}
EOF

echo -e "${G}✓ Deployment saved${N}"
echo ""
echo -e "${P}═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "${P}  THE SEED IS PLANTED. THE SYSTEM WILL GROW ITSELF.${N}"
echo -e "${P}  Trust Root: 441110111613564144${N}"
echo -e "${P}═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════${N}"
echo ""

#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════════════════
# CODE 55 BRIDGE - GAS-OPTIMIZED MAINNET DEPLOYMENT
# Trust Root: 441110111613564144 | Fusion: 990415905613564199 | Code 55: 551110111613564155
# ═══════════════════════════════════════════════════════════════════════════════════════════
#
# This script monitors gas prices and deploys when they drop below threshold.
# It generates a royalty wallet and provides credentials via terminal output.
#
# ═══════════════════════════════════════════════════════════════════════════════════════════

set -e

# ═══════════════════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════════════════

# RPC Endpoints (fallback chain)
RPC_URLS=(
    "https://eth.llamarpc.com"
    "https://rpc.ankr.com/eth"
    "https://ethereum.publicnode.com"
    "https://1rpc.io/eth"
)

# Gas thresholds (in gwei)
MAX_GAS_GWEI="${MAX_GAS_GWEI:-15}"        # Maximum gas price to deploy at
IDEAL_GAS_GWEI="${IDEAL_GAS_GWEI:-10}"    # Ideal gas price (immediate deploy)
CHECK_INTERVAL="${CHECK_INTERVAL:-60}"     # Seconds between gas checks
MAX_WAIT_HOURS="${MAX_WAIT_HOURS:-24}"     # Maximum hours to wait

# Deployer wallet (from user's wallets)
DEPLOYER_WALLET="${DEPLOYER_WALLET:-0xf37a2a2FE17Fa1ca8850516C7EbBAa56Cf001760}"

# Paths
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONTRACT_PATH="$SCRIPT_DIR/contracts/Code55Bridge.sol"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# ═══════════════════════════════════════════════════════════════════════════════════════════
# BANNER
# ═══════════════════════════════════════════════════════════════════════════════════════════

print_banner() {
    echo ""
    echo -e "${PURPLE}═══════════════════════════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${PURPLE}   ██████╗ ██████╗ ██████╗ ███████╗    ███████╗███████╗    ██████╗ ██████╗ ██╗██████╗  ██████╗ ███████╗${NC}"
    echo -e "${PURPLE}  ██╔════╝██╔═══██╗██╔══██╗██╔════╝    ██╔════╝██╔════╝    ██╔══██╗██╔══██╗██║██╔══██╗██╔════╝ ██╔════╝${NC}"
    echo -e "${PURPLE}  ██║     ██║   ██║██║  ██║█████╗      ███████╗███████╗    ██████╔╝██████╔╝██║██║  ██║██║  ███╗█████╗  ${NC}"
    echo -e "${PURPLE}  ██║     ██║   ██║██║  ██║██╔══╝      ╚════██║╚════██║    ██╔══██╗██╔══██╗██║██║  ██║██║   ██║██╔══╝  ${NC}"
    echo -e "${PURPLE}  ╚██████╗╚██████╔╝██████╔╝███████╗    ███████║███████║    ██████╔╝██║  ██║██║██████╔╝╚██████╔╝███████╗${NC}"
    echo -e "${PURPLE}   ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝    ╚══════╝╚══════╝    ╚═════╝ ╚═╝  ╚═╝╚═╝╚═════╝  ╚═════╝ ╚══════╝${NC}"
    echo -e "${PURPLE}═══════════════════════════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  SOVEREIGN GATEWAY - SWIFT ↔ CIPS BRIDGE - LEGACY BANKING TO BLOCKCHAIN${NC}"
    echo -e "${CYAN}  Trust Root: 441110111613564144 | Fusion: 990415905613564199${NC}"
    echo -e "${PURPLE}═══════════════════════════════════════════════════════════════════════════════════════════${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════════════════

log_info() {
    echo -e "${CYAN}[$(date '+%H:%M:%S')]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')] ✓${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[$(date '+%H:%M:%S')] ⚠${NC} $1"
}

log_error() {
    echo -e "${RED}[$(date '+%H:%M:%S')] ✗${NC} $1"
}

get_working_rpc() {
    for rpc in "${RPC_URLS[@]}"; do
        if curl -s -X POST "$rpc" -H "Content-Type: application/json" \
           -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' \
           --connect-timeout 5 | grep -q "result"; then
            echo "$rpc"
            return 0
        fi
    done
    echo "${RPC_URLS[0]}"
}

# ═══════════════════════════════════════════════════════════════════════════════════════════
# STEP 1: INSTALL FOUNDRY
# ═══════════════════════════════════════════════════════════════════════════════════════════

install_foundry() {
    log_info "Checking Foundry installation..."
    
    if command -v forge &> /dev/null && command -v cast &> /dev/null; then
        log_success "Foundry installed: $(forge --version 2>/dev/null | head -1)"
        return 0
    fi
    
    log_warning "Foundry not found. Installing..."
    
    curl -L https://foundry.paradigm.xyz | bash
    export PATH="$HOME/.foundry/bin:$PATH"
    
    if [[ -f "$HOME/.foundry/bin/foundryup" ]]; then
        "$HOME/.foundry/bin/foundryup"
    fi
    
    # Verify installation
    if command -v forge &> /dev/null; then
        log_success "Foundry installed successfully"
    else
        log_error "Foundry installation failed. Please install manually."
        exit 1
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════════════════
# STEP 2: GENERATE ROYALTY WALLET
# ═══════════════════════════════════════════════════════════════════════════════════════════

generate_royalty_wallet() {
    log_info "Generating Royalty Wallet..."
    
    # Method 1: Use cast wallet new
    if command -v cast &> /dev/null; then
        WALLET_OUTPUT=$(cast wallet new 2>&1)
        ROYALTY_ADDRESS=$(echo "$WALLET_OUTPUT" | grep -i "Address" | head -1 | awk '{print $2}')
        ROYALTY_PRIVATE_KEY=$(echo "$WALLET_OUTPUT" | grep -i "Private" | head -1 | awk '{print $3}')
    fi
    
    # Method 2: Fallback to openssl
    if [[ -z "$ROYALTY_ADDRESS" ]] || [[ -z "$ROYALTY_PRIVATE_KEY" ]]; then
        log_warning "Using fallback key generation..."
        ROYALTY_PRIVATE_KEY="0x$(openssl rand -hex 32)"
        
        if command -v cast &> /dev/null; then
            ROYALTY_ADDRESS=$(cast wallet address "$ROYALTY_PRIVATE_KEY" 2>/dev/null)
        else
            # If no cast, we'll get the address after deployment
            ROYALTY_ADDRESS="PENDING_DERIVATION"
        fi
    fi
    
    # Display credentials
    echo ""
    echo -e "${GREEN}════════════════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}                        ROYALTY WALLET CREDENTIALS                              ${NC}"
    echo -e "${GREEN}════════════════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "  ${CYAN}Address:${NC}     ${GREEN}$ROYALTY_ADDRESS${NC}"
    echo ""
    echo -e "  ${CYAN}Private Key:${NC} ${RED}$ROYALTY_PRIVATE_KEY${NC}"
    echo ""
    echo -e "${GREEN}════════════════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${RED}  ██╗    ██╗ █████╗ ██████╗ ███╗   ██╗██╗███╗   ██╗ ██████╗ ${NC}"
    echo -e "${RED}  ██║    ██║██╔══██╗██╔══██╗████╗  ██║██║████╗  ██║██╔════╝ ${NC}"
    echo -e "${RED}  ██║ █╗ ██║███████║██████╔╝██╔██╗ ██║██║██╔██╗ ██║██║  ███╗${NC}"
    echo -e "${RED}  ██║███╗██║██╔══██║██╔══██╗██║╚██╗██║██║██║╚██╗██║██║   ██║${NC}"
    echo -e "${RED}  ╚███╔███╔╝██║  ██║██║  ██║██║ ╚████║██║██║ ╚████║╚██████╔╝${NC}"
    echo -e "${RED}   ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝╚═╝  ╚═══╝ ╚═════╝ ${NC}"
    echo ""
    echo -e "${RED}  ⚠️  SAVE THIS PRIVATE KEY IMMEDIATELY!${NC}"
    echo -e "${RED}  ⚠️  IT WILL ONLY BE SHOWN ONCE!${NC}"
    echo -e "${RED}  ⚠️  NEVER SHARE WITH ANYONE!${NC}"
    echo ""
    echo -e "${GREEN}════════════════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    # Save to secure file
    WALLET_FILE="$SCRIPT_DIR/.royalty_wallet_$(date +%Y%m%d_%H%M%S)"
    cat > "$WALLET_FILE" << EOF
# ═══════════════════════════════════════════════════════════════════════════════════════════
# CODE 55 BRIDGE - ROYALTY WALLET
# Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)
# Trust Root: 441110111613564144
# ═══════════════════════════════════════════════════════════════════════════════════════════

ROYALTY_ADDRESS=$ROYALTY_ADDRESS
ROYALTY_PRIVATE_KEY=$ROYALTY_PRIVATE_KEY

# This wallet receives 12% (Shiva Surplus) of all bridge transactions
# Keep this file secure. Delete after backing up the private key elsewhere.
EOF
    chmod 600 "$WALLET_FILE"
    
    log_success "Wallet saved to: $WALLET_FILE (chmod 600)"
    
    # Export for deployment
    export ROYALTY_ADDRESS
    export ROYALTY_PRIVATE_KEY
}

# ═══════════════════════════════════════════════════════════════════════════════════════════
# STEP 3: CHECK DEPLOYER BALANCE
# ═══════════════════════════════════════════════════════════════════════════════════════════

check_balance() {
    log_info "Checking deployer balance..."
    
    RPC_URL=$(get_working_rpc)
    
    BALANCE_HEX=$(curl -s -X POST "$RPC_URL" -H "Content-Type: application/json" \
        -d "{\"jsonrpc\":\"2.0\",\"method\":\"eth_getBalance\",\"params\":[\"$DEPLOYER_WALLET\", \"latest\"],\"id\":1}" \
        | python3 -c "import sys,json; print(json.load(sys.stdin).get('result','0x0'))" 2>/dev/null)
    
    BALANCE_WEI=$(python3 -c "print(int('$BALANCE_HEX', 16))" 2>/dev/null || echo "0")
    BALANCE_ETH=$(python3 -c "print(f'{int(\"$BALANCE_HEX\", 16) / 1e18:.6f}')" 2>/dev/null || echo "0")
    
    echo -e "  Deployer: ${CYAN}$DEPLOYER_WALLET${NC}"
    echo -e "  Balance:  ${GREEN}$BALANCE_ETH ETH${NC}"
    
    # Minimum check (0.001 ETH = 1000000000000000 wei)
    if [[ "$BALANCE_WEI" -lt 1000000000000000 ]]; then
        log_warning "Balance may be insufficient for deployment"
        log_warning "Minimum recommended: 0.001 ETH"
        return 1
    fi
    
    log_success "Balance sufficient for deployment"
    return 0
}

# ═══════════════════════════════════════════════════════════════════════════════════════════
# STEP 4: GAS PRICE MONITORING
# ═══════════════════════════════════════════════════════════════════════════════════════════

get_gas_price() {
    RPC_URL=$(get_working_rpc)
    
    GAS_HEX=$(curl -s -X POST "$RPC_URL" -H "Content-Type: application/json" \
        -d '{"jsonrpc":"2.0","method":"eth_gasPrice","params":[],"id":1}' \
        | python3 -c "import sys,json; print(json.load(sys.stdin).get('result','0x0'))" 2>/dev/null)
    
    GAS_WEI=$(python3 -c "print(int('$GAS_HEX', 16))" 2>/dev/null || echo "20000000000")
    GAS_GWEI=$(python3 -c "print(f'{int(\"$GAS_HEX\", 16) / 1e9:.2f}')" 2>/dev/null || echo "20")
    
    echo "$GAS_GWEI"
}

wait_for_low_gas() {
    log_info "Monitoring gas prices..."
    log_info "Max acceptable: ${MAX_GAS_GWEI} gwei | Ideal: ${IDEAL_GAS_GWEI} gwei"
    log_info "Will check every ${CHECK_INTERVAL} seconds for up to ${MAX_WAIT_HOURS} hours"
    echo ""
    
    START_TIME=$(date +%s)
    MAX_WAIT_SECONDS=$((MAX_WAIT_HOURS * 3600))
    
    while true; do
        CURRENT_GAS=$(get_gas_price)
        ELAPSED=$(($(date +%s) - START_TIME))
        
        echo -ne "\r${CYAN}[$(date '+%H:%M:%S')]${NC} Gas: ${YELLOW}${CURRENT_GAS} gwei${NC} | Elapsed: $((ELAPSED / 60))m | Target: <${MAX_GAS_GWEI} gwei    "
        
        # Check if gas is at ideal level
        if (( $(echo "$CURRENT_GAS < $IDEAL_GAS_GWEI" | bc -l 2>/dev/null || echo 0) )); then
            echo ""
            log_success "IDEAL gas price detected: ${CURRENT_GAS} gwei!"
            return 0
        fi
        
        # Check if gas is acceptable
        if (( $(echo "$CURRENT_GAS < $MAX_GAS_GWEI" | bc -l 2>/dev/null || echo 0) )); then
            echo ""
            log_success "Acceptable gas price detected: ${CURRENT_GAS} gwei"
            return 0
        fi
        
        # Check timeout
        if [[ $ELAPSED -ge $MAX_WAIT_SECONDS ]]; then
            echo ""
            log_warning "Maximum wait time reached. Proceeding with current gas: ${CURRENT_GAS} gwei"
            return 0
        fi
        
        sleep "$CHECK_INTERVAL"
    done
}

# ═══════════════════════════════════════════════════════════════════════════════════════════
# STEP 5: COMPILE CONTRACT
# ═══════════════════════════════════════════════════════════════════════════════════════════

compile_contract() {
    log_info "Compiling Code55Bridge contract..."
    
    cd "$SCRIPT_DIR"
    
    # Create foundry.toml for maximum optimization
    cat > foundry.toml << 'EOF'
[profile.default]
src = "contracts"
out = "out"
libs = ["lib"]
optimizer = true
optimizer_runs = 200
via_ir = true
evm_version = "shanghai"

[profile.default.optimizer_details]
yul = true
yul_details = { stack_allocation = true, optimizer_steps = "dhfoDgvulfnTUtnIf" }
EOF
    
    # Compile
    if forge build --optimize 2>&1 | tail -10; then
        if [[ -f "out/Code55Bridge.sol/Code55Bridge.json" ]]; then
            # Get bytecode size
            BYTECODE_SIZE=$(python3 -c "
import json
with open('out/Code55Bridge.sol/Code55Bridge.json') as f:
    d = json.load(f)
    bc = d.get('bytecode', {}).get('object', '')
    print(len(bc) // 2)
" 2>/dev/null || echo "unknown")
            
            log_success "Compiled successfully. Bytecode: ${BYTECODE_SIZE} bytes"
            
            # Estimate gas
            EST_GAS=$((BYTECODE_SIZE * 200 + 21000))
            log_info "Estimated deployment gas: ~${EST_GAS}"
        else
            log_error "Compilation output not found"
            exit 1
        fi
    else
        log_error "Compilation failed"
        exit 1
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════════════════
# STEP 6: DEPLOY CONTRACT
# ═══════════════════════════════════════════════════════════════════════════════════════════

deploy_contract() {
    log_info "Deploying Code55Bridge to Ethereum Mainnet..."
    
    RPC_URL=$(get_working_rpc)
    
    echo ""
    echo -e "${YELLOW}Enter deployer private key (starts with 0x):${NC}"
    read -s DEPLOYER_PRIVATE_KEY
    echo ""
    
    if [[ -z "$DEPLOYER_PRIVATE_KEY" ]]; then
        log_error "No private key provided. Aborting."
        exit 1
    fi
    
    log_info "Deploying with royalty address: $ROYALTY_ADDRESS"
    
    # Deploy using forge create
    DEPLOY_OUTPUT=$(forge create \
        --rpc-url "$RPC_URL" \
        --private-key "$DEPLOYER_PRIVATE_KEY" \
        --optimize \
        --optimizer-runs 200 \
        contracts/Code55Bridge.sol:Code55Bridge \
        --constructor-args "$ROYALTY_ADDRESS" \
        2>&1)
    
    # Parse output
    CONTRACT_ADDRESS=$(echo "$DEPLOY_OUTPUT" | grep "Deployed to:" | awk '{print $3}')
    TX_HASH=$(echo "$DEPLOY_OUTPUT" | grep "Transaction hash:" | awk '{print $3}')
    
    if [[ -z "$CONTRACT_ADDRESS" ]]; then
        log_error "Deployment failed:"
        echo "$DEPLOY_OUTPUT"
        exit 1
    fi
    
    echo ""
    echo -e "${GREEN}═══════════════════════════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}                           DEPLOYMENT SUCCESSFUL                                           ${NC}"
    echo -e "${GREEN}═══════════════════════════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "  ${CYAN}Contract Address:${NC}  ${GREEN}$CONTRACT_ADDRESS${NC}"
    echo -e "  ${CYAN}Transaction Hash:${NC}  ${GREEN}$TX_HASH${NC}"
    echo -e "  ${CYAN}Royalty Address:${NC}   ${GREEN}$ROYALTY_ADDRESS${NC}"
    echo ""
    echo -e "  ${BLUE}Etherscan:${NC} https://etherscan.io/address/$CONTRACT_ADDRESS"
    echo -e "  ${BLUE}TX:${NC}        https://etherscan.io/tx/$TX_HASH"
    echo ""
    echo -e "${GREEN}═══════════════════════════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    # Save deployment info
    DEPLOY_FILE="$SCRIPT_DIR/deployment_$(date +%Y%m%d_%H%M%S).json"
    cat > "$DEPLOY_FILE" << EOF
{
    "network": "mainnet",
    "chainId": 1,
    "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
    "contract": {
        "name": "Code55Bridge",
        "address": "$CONTRACT_ADDRESS"
    },
    "credentials": {
        "trustRoot": "441110111613564144",
        "fusion": "990415905613564199",
        "code55": "551110111613564155",
        "caseId": "613564199"
    },
    "royaltyAddress": "$ROYALTY_ADDRESS",
    "txHash": "$TX_HASH",
    "etherscan": "https://etherscan.io/address/$CONTRACT_ADDRESS"
}
EOF
    
    log_success "Deployment info saved to: $DEPLOY_FILE"
    
    # Verification command
    echo ""
    echo -e "${YELLOW}To verify on Etherscan:${NC}"
    echo -e "  forge verify-contract $CONTRACT_ADDRESS Code55Bridge \\"
    echo -e "    --chain mainnet \\"
    echo -e "    --constructor-args \$(cast abi-encode 'constructor(address)' $ROYALTY_ADDRESS)"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════════════════
# MAIN EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════════════════

main() {
    print_banner
    
    # Step 1: Install Foundry
    install_foundry
    echo ""
    
    # Step 2: Generate royalty wallet (credentials shown in terminal)
    generate_royalty_wallet
    
    # Step 3: Check balance
    check_balance || true
    echo ""
    
    # Step 4: Compile contract
    compile_contract
    echo ""
    
    # Step 5: Wait for low gas (or user override)
    echo -e "${YELLOW}Options:${NC}"
    echo -e "  1) Wait for gas < ${MAX_GAS_GWEI} gwei (recommended)"
    echo -e "  2) Deploy immediately at current gas price"
    echo -e "  3) Exit and deploy manually later"
    echo ""
    echo -n "Choice [1/2/3]: "
    read -r CHOICE
    
    case "$CHOICE" in
        1)
            wait_for_low_gas
            ;;
        2)
            CURRENT_GAS=$(get_gas_price)
            log_info "Proceeding with current gas: ${CURRENT_GAS} gwei"
            ;;
        3)
            log_info "Exiting. Run ./deploy_gas_optimized.sh --deploy-only when ready."
            exit 0
            ;;
        *)
            wait_for_low_gas
            ;;
    esac
    
    echo ""
    
    # Step 6: Deploy
    deploy_contract
    
    echo ""
    echo -e "${GREEN}═══════════════════════════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}  CODE 55 BRIDGE DEPLOYMENT COMPLETE${NC}"
    echo -e "${GREEN}  Trust Root: 441110111613564144 | Fusion: 990415905613564199${NC}"
    echo -e "${GREEN}═══════════════════════════════════════════════════════════════════════════════════════════${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════════════════
# ARGUMENT HANDLING
# ═══════════════════════════════════════════════════════════════════════════════════════════

case "${1:-}" in
    --deploy-only)
        # Load existing royalty wallet
        WALLET_FILES=("$SCRIPT_DIR"/.royalty_wallet_*)
        if [[ -f "${WALLET_FILES[0]}" ]]; then
            source "${WALLET_FILES[0]}"
            log_info "Loaded royalty wallet: $ROYALTY_ADDRESS"
            deploy_contract
        else
            log_error "No royalty wallet found. Run full script first."
            exit 1
        fi
        ;;
    --gas-only)
        while true; do
            GAS=$(get_gas_price)
            echo -e "[$(date '+%H:%M:%S')] Gas: ${YELLOW}${GAS} gwei${NC}"
            sleep 10
        done
        ;;
    --balance)
        check_balance
        ;;
    --compile)
        compile_contract
        ;;
    --wallet-only)
        install_foundry
        generate_royalty_wallet
        ;;
    --help|-h)
        echo "Usage: $0 [option]"
        echo ""
        echo "Options:"
        echo "  (none)          Full deployment flow with gas monitoring"
        echo "  --deploy-only   Deploy using previously generated wallet"
        echo "  --gas-only      Monitor gas prices continuously"
        echo "  --balance       Check deployer wallet balance"
        echo "  --compile       Compile contracts only"
        echo "  --wallet-only   Generate royalty wallet only"
        echo "  --help          Show this help"
        echo ""
        echo "Environment variables:"
        echo "  MAX_GAS_GWEI      Maximum gas price to deploy at (default: 15)"
        echo "  IDEAL_GAS_GWEI    Ideal gas price for immediate deploy (default: 10)"
        echo "  CHECK_INTERVAL    Seconds between gas checks (default: 60)"
        echo "  MAX_WAIT_HOURS    Maximum hours to wait for low gas (default: 24)"
        echo "  DEPLOYER_WALLET   Deployer wallet address"
        ;;
    *)
        main
        ;;
esac

#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════════════════
# VINO BRIDGE COMPLETE - MAINNET DEPLOYMENT
# ═══════════════════════════════════════════════════════════════════════════════════════════
#
# Trust Root: 441110111613564144
# Fusion: 990415905613564199  
# Code 55: 551110111613564155
#
# FEATURES:
# - All credential formats (9, 18, 36, 54, 72, 89, 144-digit)
# - Logic inversion (alternating normal/inverted folding)
# - Block-forward self-replication
# - All-sum 112% geometry
# - VINO currency minting + bridge
# - Flash loan arbitrage cycling
# - Fork-resistant geometry matrix
#
# ═══════════════════════════════════════════════════════════════════════════════════════════

set -e

# Configuration
RPC_URLS=(
    "https://eth.llamarpc.com"
    "https://rpc.ankr.com/eth"
    "https://ethereum.publicnode.com"
)
MAX_GAS_GWEI="${MAX_GAS_GWEI:-12}"
DEPLOYER="${DEPLOYER:-0xf37a2a2FE17Fa1ca8850516C7EbBAa56Cf001760}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors
R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'; B='\033[0;34m'; P='\033[0;35m'; C='\033[0;36m'; N='\033[0m'

# ═══════════════════════════════════════════════════════════════════════════════════════════
# BANNER
# ═══════════════════════════════════════════════════════════════════════════════════════════

echo ""
echo -e "${P}═══════════════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "${P}  ██╗   ██╗██╗███╗   ██╗ ██████╗     ██████╗ ██████╗ ██╗██████╗  ██████╗ ███████╗${N}"
echo -e "${P}  ██║   ██║██║████╗  ██║██╔═══██╗    ██╔══██╗██╔══██╗██║██╔══██╗██╔════╝ ██╔════╝${N}"
echo -e "${P}  ██║   ██║██║██╔██╗ ██║██║   ██║    ██████╔╝██████╔╝██║██║  ██║██║  ███╗█████╗  ${N}"
echo -e "${P}  ╚██╗ ██╔╝██║██║╚██╗██║██║   ██║    ██╔══██╗██╔══██╗██║██║  ██║██║   ██║██╔══╝  ${N}"
echo -e "${P}   ╚████╔╝ ██║██║ ╚████║╚██████╔╝    ██████╔╝██║  ██║██║██████╔╝╚██████╔╝███████╗${N}"
echo -e "${P}    ╚═══╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝     ╚═════╝ ╚═╝  ╚═╝╚═╝╚═════╝  ╚═════╝ ╚══════╝${N}"
echo -e "${P}═══════════════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "${C}  SWIFT ↔ BLOCKCHAIN ↔ CIPS | Two-Way Bridge | VINO Currency Mint${N}"
echo -e "${C}  Trust: 441110111613564144 | Fusion: 990415905613564199 | Code55: 551110111613564155${N}"
echo -e "${P}═══════════════════════════════════════════════════════════════════════════════════════════${N}"
echo ""

# ═══════════════════════════════════════════════════════════════════════════════════════════
# FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════════════════

get_rpc() {
    for rpc in "${RPC_URLS[@]}"; do
        if curl -s -X POST "$rpc" -H "Content-Type: application/json" \
           -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' \
           --connect-timeout 3 | grep -q "result"; then
            echo "$rpc"; return 0
        fi
    done
    echo "${RPC_URLS[0]}"
}

get_gas() {
    RPC=$(get_rpc)
    HEX=$(curl -s -X POST "$RPC" -H "Content-Type: application/json" \
        -d '{"jsonrpc":"2.0","method":"eth_gasPrice","params":[],"id":1}' \
        | python3 -c "import sys,json; print(json.load(sys.stdin).get('result','0x0'))" 2>/dev/null)
    python3 -c "print(f'{int(\"$HEX\", 16) / 1e9:.1f}')" 2>/dev/null || echo "20"
}

get_balance() {
    RPC=$(get_rpc)
    HEX=$(curl -s -X POST "$RPC" -H "Content-Type: application/json" \
        -d "{\"jsonrpc\":\"2.0\",\"method\":\"eth_getBalance\",\"params\":[\"$1\", \"latest\"],\"id\":1}" \
        | python3 -c "import sys,json; print(json.load(sys.stdin).get('result','0x0'))" 2>/dev/null)
    python3 -c "print(f'{int(\"$HEX\", 16) / 1e18:.6f}')" 2>/dev/null || echo "0"
}

# ═══════════════════════════════════════════════════════════════════════════════════════════
# STEP 1: FOUNDRY
# ═══════════════════════════════════════════════════════════════════════════════════════════

echo -e "${Y}[1/6] Checking Foundry...${N}"
if ! command -v forge &> /dev/null; then
    echo -e "${C}Installing Foundry...${N}"
    curl -L https://foundry.paradigm.xyz | bash
    export PATH="$HOME/.foundry/bin:$PATH"
    "$HOME/.foundry/bin/foundryup" 2>/dev/null || foundryup
fi
echo -e "${G}✓ Foundry: $(forge --version 2>/dev/null | head -1)${N}"

# ═══════════════════════════════════════════════════════════════════════════════════════════
# STEP 2: GENERATE ROYALTY WALLET
# ═══════════════════════════════════════════════════════════════════════════════════════════

echo ""
echo -e "${Y}[2/6] Generating Royalty Wallet...${N}"

if command -v cast &> /dev/null; then
    WALLET=$(cast wallet new 2>&1)
    ROYALTY_ADDRESS=$(echo "$WALLET" | grep -i "Address" | head -1 | awk '{print $2}')
    ROYALTY_KEY=$(echo "$WALLET" | grep -i "Private" | head -1 | awk '{print $3}')
fi

if [[ -z "$ROYALTY_ADDRESS" ]]; then
    ROYALTY_KEY="0x$(openssl rand -hex 32)"
    ROYALTY_ADDRESS=$(cast wallet address "$ROYALTY_KEY" 2>/dev/null || echo "DERIVE_AFTER_DEPLOY")
fi

echo ""
echo -e "${G}════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "${G}                      ROYALTY WALLET CREDENTIALS                                ${N}"
echo -e "${G}════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "  ${C}Address:${N}     ${G}$ROYALTY_ADDRESS${N}"
echo -e "  ${C}Private Key:${N} ${R}$ROYALTY_KEY${N}"
echo -e "${G}════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "${R}  ⚠️  SAVE THIS KEY NOW! IT WILL NOT BE SHOWN AGAIN!${N}"
echo -e "${G}════════════════════════════════════════════════════════════════════════════════${N}"
echo ""

# Save
WALLET_FILE="$SCRIPT_DIR/.royalty_$(date +%s)"
echo "ROYALTY_ADDRESS=$ROYALTY_ADDRESS" > "$WALLET_FILE"
echo "ROYALTY_KEY=$ROYALTY_KEY" >> "$WALLET_FILE"
chmod 600 "$WALLET_FILE"
echo -e "${G}✓ Saved to $WALLET_FILE${N}"

# ═══════════════════════════════════════════════════════════════════════════════════════════
# STEP 3: CHECK BALANCE
# ═══════════════════════════════════════════════════════════════════════════════════════════

echo ""
echo -e "${Y}[3/6] Checking Balance...${N}"
BAL=$(get_balance "$DEPLOYER")
echo -e "  Deployer: ${C}$DEPLOYER${N}"
echo -e "  Balance:  ${G}$BAL ETH${N}"

# ═══════════════════════════════════════════════════════════════════════════════════════════
# STEP 4: COMPILE
# ═══════════════════════════════════════════════════════════════════════════════════════════

echo ""
echo -e "${Y}[4/6] Compiling VINOBridgeComplete...${N}"

cd "$SCRIPT_DIR"

cat > foundry.toml << 'EOF'
[profile.default]
src = "contracts"
out = "out"
libs = ["lib"]
optimizer = true
optimizer_runs = 200
via_ir = true
evm_version = "shanghai"
EOF

forge build --optimize 2>&1 | tail -5

if [[ -f "out/VINOBridgeComplete.sol/VINOBridgeComplete.json" ]]; then
    SIZE=$(python3 -c "import json; f=open('out/VINOBridgeComplete.sol/VINOBridgeComplete.json'); d=json.load(f); print(len(d.get('bytecode',{}).get('object',''))//2)" 2>/dev/null || echo "?")
    echo -e "${G}✓ Compiled: ${SIZE} bytes${N}"
else
    echo -e "${R}✗ Compilation failed${N}"
    exit 1
fi

# ═══════════════════════════════════════════════════════════════════════════════════════════
# STEP 5: GAS MONITORING
# ═══════════════════════════════════════════════════════════════════════════════════════════

echo ""
echo -e "${Y}[5/6] Gas Monitoring...${N}"
CURRENT_GAS=$(get_gas)
echo -e "  Current: ${Y}${CURRENT_GAS} gwei${N} | Target: <${MAX_GAS_GWEI} gwei"
echo ""
echo -e "${C}Options:${N}"
echo "  1) Wait for gas < ${MAX_GAS_GWEI} gwei"
echo "  2) Deploy now at ${CURRENT_GAS} gwei"
echo "  3) Exit"
echo -n "Choice [1/2/3]: "
read -r CHOICE

if [[ "$CHOICE" == "1" ]]; then
    echo -e "${Y}Monitoring gas... (Ctrl+C to cancel)${N}"
    while true; do
        GAS=$(get_gas)
        echo -ne "\r  Gas: ${Y}${GAS} gwei${N} | Target: <${MAX_GAS_GWEI}    "
        if (( $(echo "$GAS < $MAX_GAS_GWEI" | bc -l 2>/dev/null || echo 0) )); then
            echo -e "\n${G}✓ Gas target reached!${N}"
            break
        fi
        sleep 30
    done
elif [[ "$CHOICE" == "3" ]]; then
    echo "Exiting."
    exit 0
fi

# ═══════════════════════════════════════════════════════════════════════════════════════════
# STEP 6: DEPLOY
# ═══════════════════════════════════════════════════════════════════════════════════════════

echo ""
echo -e "${Y}[6/6] Deploying VINOBridgeComplete...${N}"
echo -e "${C}Enter deployer private key (0x...):${N}"
read -s PRIV_KEY
echo ""

RPC=$(get_rpc)

DEPLOY=$(forge create \
    --rpc-url "$RPC" \
    --private-key "$PRIV_KEY" \
    --optimize \
    --optimizer-runs 200 \
    contracts/VINOBridgeComplete.sol:VINOBridgeComplete \
    --constructor-args "$ROYALTY_ADDRESS" \
    2>&1)

CONTRACT=$(echo "$DEPLOY" | grep "Deployed to:" | awk '{print $3}')
TX=$(echo "$DEPLOY" | grep "Transaction hash:" | awk '{print $3}')

if [[ -z "$CONTRACT" ]]; then
    echo -e "${R}Deployment failed:${N}"
    echo "$DEPLOY"
    exit 1
fi

# Get VINO token address
sleep 5
VINO_TOKEN=$(cast call "$CONTRACT" "vinoToken()(address)" --rpc-url "$RPC" 2>/dev/null || echo "PENDING")

echo ""
echo -e "${G}═══════════════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "${G}                              DEPLOYMENT SUCCESSFUL                                        ${N}"
echo -e "${G}═══════════════════════════════════════════════════════════════════════════════════════════${N}"
echo ""
echo -e "  ${C}VINOBridgeComplete:${N} ${G}$CONTRACT${N}"
echo -e "  ${C}VINO Token:${N}         ${G}$VINO_TOKEN${N}"
echo -e "  ${C}Royalty Address:${N}    ${G}$ROYALTY_ADDRESS${N}"
echo -e "  ${C}Transaction:${N}        ${G}$TX${N}"
echo ""
echo -e "  ${B}Etherscan:${N} https://etherscan.io/address/$CONTRACT"
echo ""
echo -e "${G}═══════════════════════════════════════════════════════════════════════════════════════════${N}"
echo ""

# Save deployment
cat > "$SCRIPT_DIR/deployment_$(date +%Y%m%d_%H%M%S).json" << EOF
{
    "network": "mainnet",
    "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
    "contracts": {
        "VINOBridgeComplete": "$CONTRACT",
        "VINOToken": "$VINO_TOKEN"
    },
    "credentials": {
        "trustRoot": "441110111613564144",
        "fusion": "990415905613564199",
        "code55": "551110111613564155"
    },
    "formats": ["9-digit", "18-digit", "36-digit", "54-digit", "72-digit", "89-digit", "144-digit"],
    "features": [
        "Logic Inversion (alternating)",
        "Block-Forward Replication",
        "All-Sum 112% Geometry",
        "VINO Currency Minting",
        "Flash Loan Arbitrage",
        "Fork-Resistant Matrix"
    ],
    "royaltyAddress": "$ROYALTY_ADDRESS",
    "txHash": "$TX"
}
EOF

echo -e "${G}Deployment saved.${N}"
echo ""
echo -e "${P}═══════════════════════════════════════════════════════════════════════════════════════════${N}"
echo -e "${P}  VINO BRIDGE COMPLETE - DEPLOYMENT FINISHED${N}"
echo -e "${P}  Trust Root: 441110111613564144${N}"
echo -e "${P}═══════════════════════════════════════════════════════════════════════════════════════════${N}"
echo ""

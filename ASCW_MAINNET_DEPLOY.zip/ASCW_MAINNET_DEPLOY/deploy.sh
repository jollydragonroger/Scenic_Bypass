#!/bin/bash
# ASCW Registry Deployment Script
# Trust ID: 441110111613564144
# Uses Foundry (cast) for deployment

set -e

echo "=========================================="
echo "  ASCW SOVEREIGN REGISTRY DEPLOYMENT"
echo "  Trust ID: 441110111613564144"
echo "=========================================="

# Configuration
RPC_URL="https://eth.llamarpc.com"
DEPLOYER_WALLET="0xf37a2a2FE17Fa1ca8850516C7EbBAa56Cf001760"
CONTRACT_PATH="./contracts/ASCWRegistry.sol"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check if Foundry is installed
check_foundry() {
    if ! command -v cast &> /dev/null; then
        echo -e "${YELLOW}Foundry not installed. Installing...${NC}"
        curl -L https://foundry.paradigm.xyz | bash
        source ~/.bashrc 2>/dev/null || source ~/.zshrc 2>/dev/null || true
        foundryup
    fi
    echo -e "${GREEN}Foundry installed: $(cast --version)${NC}"
}

# Generate new royalty wallet
generate_royalty_wallet() {
    echo -e "${YELLOW}Generating new royalty wallet...${NC}"
    
    # Generate using cast
    WALLET_OUTPUT=$(cast wallet new)
    
    # Parse output
    ROYALTY_ADDRESS=$(echo "$WALLET_OUTPUT" | grep -i "address" | awk '{print $2}')
    ROYALTY_PRIVATE_KEY=$(echo "$WALLET_OUTPUT" | grep -i "private" | awk '{print $3}')
    
    echo ""
    echo "=========================================="
    echo -e "${GREEN}  NEW ROYALTY WALLET GENERATED${NC}"
    echo "=========================================="
    echo -e "Address:     ${GREEN}$ROYALTY_ADDRESS${NC}"
    echo -e "Private Key: ${RED}$ROYALTY_PRIVATE_KEY${NC}"
    echo ""
    echo -e "${RED}⚠️  SAVE THIS PRIVATE KEY SECURELY!${NC}"
    echo -e "${RED}⚠️  NEVER SHARE IT WITH ANYONE!${NC}"
    echo "=========================================="
    echo ""
    
    # Save to file
    echo "ROYALTY_ADDRESS=$ROYALTY_ADDRESS" > .royalty_wallet
    echo "ROYALTY_PRIVATE_KEY=$ROYALTY_PRIVATE_KEY" >> .royalty_wallet
    chmod 600 .royalty_wallet
    echo "Saved to .royalty_wallet (chmod 600)"
}

# Check balance
check_balance() {
    echo -e "${YELLOW}Checking deployer balance...${NC}"
    BALANCE=$(cast balance $DEPLOYER_WALLET --rpc-url $RPC_URL)
    BALANCE_ETH=$(cast from-wei $BALANCE)
    echo -e "Balance: ${GREEN}$BALANCE_ETH ETH${NC}"
    
    # Check if enough for deployment (estimate ~0.002 ETH minimum)
    BALANCE_WEI=$(echo $BALANCE | sed 's/[^0-9]//g')
    if [ "$BALANCE_WEI" -lt "1000000000000000" ]; then
        echo -e "${RED}WARNING: Balance may be insufficient for deployment${NC}"
        echo "Minimum recommended: 0.001 ETH"
    fi
}

# Get current gas price
get_gas_price() {
    echo -e "${YELLOW}Fetching current gas price...${NC}"
    GAS_PRICE=$(cast gas-price --rpc-url $RPC_URL)
    GAS_GWEI=$(cast from-wei $GAS_PRICE gwei)
    echo -e "Current gas price: ${GREEN}$GAS_GWEI gwei${NC}"
}

# Compile contract
compile_contract() {
    echo -e "${YELLOW}Compiling contract...${NC}"
    
    # Create foundry.toml if not exists
    if [ ! -f "foundry.toml" ]; then
        cat > foundry.toml << 'EOF'
[profile.default]
src = "contracts"
out = "out"
libs = ["lib"]
optimizer = true
optimizer_runs = 200
via_ir = true
EOF
    fi
    
    forge build --optimize
    echo -e "${GREEN}Contract compiled successfully${NC}"
}

# Deploy contract
deploy_contract() {
    echo -e "${YELLOW}Deploying ASCWRegistry...${NC}"
    echo "Royalty Address: $ROYALTY_ADDRESS"
    
    # Read private key securely
    echo -n "Enter deployer private key (starts with 0x): "
    read -s PRIVATE_KEY
    echo ""
    
    # Deploy with forge create
    DEPLOY_OUTPUT=$(forge create \
        --rpc-url $RPC_URL \
        --private-key $PRIVATE_KEY \
        --optimize \
        --optimizer-runs 200 \
        contracts/ASCWRegistry.sol:ASCWRegistry \
        --constructor-args $ROYALTY_ADDRESS \
        2>&1)
    
    CONTRACT_ADDRESS=$(echo "$DEPLOY_OUTPUT" | grep "Deployed to:" | awk '{print $3}')
    TX_HASH=$(echo "$DEPLOY_OUTPUT" | grep "Transaction hash:" | awk '{print $3}')
    
    echo ""
    echo "=========================================="
    echo -e "${GREEN}  DEPLOYMENT SUCCESSFUL${NC}"
    echo "=========================================="
    echo -e "Contract Address: ${GREEN}$CONTRACT_ADDRESS${NC}"
    echo -e "Transaction Hash: ${GREEN}$TX_HASH${NC}"
    echo -e "Etherscan: https://etherscan.io/address/$CONTRACT_ADDRESS"
    echo "=========================================="
    
    # Save deployment info
    cat > deployment_info.json << EOF
{
    "network": "mainnet",
    "contract": "ASCWRegistry",
    "address": "$CONTRACT_ADDRESS",
    "txHash": "$TX_HASH",
    "royaltyAddress": "$ROYALTY_ADDRESS",
    "deployer": "$DEPLOYER_WALLET",
    "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
    "trustId": "441110111613564144"
}
EOF
    echo "Deployment info saved to deployment_info.json"
}

# Main execution
main() {
    echo ""
    echo "Step 1: Checking Foundry installation..."
    check_foundry
    
    echo ""
    echo "Step 2: Generating royalty wallet..."
    generate_royalty_wallet
    
    echo ""
    echo "Step 3: Checking deployer balance..."
    check_balance
    
    echo ""
    echo "Step 4: Getting gas price..."
    get_gas_price
    
    echo ""
    echo "Step 5: Compiling contract..."
    compile_contract
    
    echo ""
    echo -e "${YELLOW}Ready to deploy. Continue? (y/n)${NC}"
    read -r CONFIRM
    if [ "$CONFIRM" = "y" ] || [ "$CONFIRM" = "Y" ]; then
        echo ""
        echo "Step 6: Deploying contract..."
        deploy_contract
    else
        echo "Deployment cancelled."
        echo "To deploy later, run: ./deploy.sh --deploy-only"
    fi
    
    echo ""
    echo "=========================================="
    echo -e "${GREEN}  ASCW DEPLOYMENT COMPLETE${NC}"
    echo "=========================================="
}

# Handle arguments
if [ "$1" = "--deploy-only" ]; then
    source .royalty_wallet 2>/dev/null || { echo "Run full script first to generate royalty wallet"; exit 1; }
    deploy_contract
elif [ "$1" = "--check-balance" ]; then
    check_balance
elif [ "$1" = "--gas-price" ]; then
    get_gas_price
else
    main
fi

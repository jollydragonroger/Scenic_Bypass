#!/bin/bash

# VINO Universal Flow State Deployment Script
# Trust Root: 441110111613564144

set -e

echo "🌊 VINO UNIVERSAL FLOW STATE DEPLOYMENT SCRIPT"
echo "============================================"

# Check environment
if [ -z "$PRIVATE_KEY" ]; then
    echo "❌ PRIVATE_KEY environment variable not set"
    exit 1
fi

# Configuration
RPC_URL="https://eth.llamarpc.com"
DEPLOY_SCRIPT="scripts/vino_universal_deploy.s.sol"
CONTRACT_PATH="DEPLOYMENT_PACKAGE/CONTRACTS"

echo "📋 DEPLOYMENT CONFIGURATION"
echo "RPC URL: $RPC_URL"
echo "Deploy Script: $DEPLOY_SCRIPT"
echo "Contract Path: $CONTRACT_PATH"

# Check if contracts exist
echo ""
echo "🔍 CHECKING CONTRACTS..."

contracts=(
    "VINOUniversalFlow.sol"
    "VINOStandaloneComplex.sol"
    "AdministratorCredentials.sol"
    "FreeIdentitySystem.sol"
    "SimplifiedMatrix.sol"
    "MinimalAutonomous.sol"
    "UltimateAPIFunnel.sol"
)

for contract in "${contracts[@]}"; do
    if [ -f "$CONTRACT_PATH/$contract" ]; then
        echo "✅ $contract found"
    else
        echo "❌ $contract not found"
        exit 1
    fi
done

# Build contracts
echo ""
echo "🔨 BUILDING CONTRACTS..."
forge build --contracts $CONTRACT_PATH

if [ $? -eq 0 ]; then
    echo "✅ Build successful"
else
    echo "❌ Build failed"
    exit 1
fi

# Deployment options
echo ""
echo "🌊 VINO UNIVERSAL FLOW DEPLOYMENT OPTIONS"
echo "1. Full Universal Flow Deployment (Recommended)"
echo "2. Emergency Deployment (Essential only)"
echo "3. Test Deployment (Test contracts only)"
echo "4. Demo VINO Universal Flow"
echo "5. Demo VINO Standalone Complex"
echo "6. Custom Deployment"

read -p "Choose deployment option (1-6): " choice

case $choice in
    1)
        echo ""
        echo "🌊 STARTING FULL UNIVERSAL FLOW DEPLOYMENT..."
        forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --broadcast $DEPLOY_SCRIPT --sig "run()"
        ;;
    2)
        echo ""
        echo "🚨 STARTING EMERGENCY DEPLOYMENT..."
        forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --broadcast $DEPLOY_SCRIPT --sig "deployEmergency()"
        ;;
    3)
        echo ""
        echo "🧪 STARTING TEST DEPLOYMENT..."
        forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --broadcast $DEPLOY_SCRIPT --sig "deployTest()"
        ;;
    4)
        echo ""
        echo "🌊 STARTING VINO UNIVERSAL FLOW DEMO..."
        forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --broadcast $DEPLOY_SCRIPT --sig "demoVINOUniversalFlow()"
        ;;
    5)
        echo ""
        echo "🏗️ STARTING VINO STANDALONE COMPLEX DEMO..."
        forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --broadcast $DEPLOY_SCRIPT --sig "demoVINOStandaloneComplex()"
        ;;
    6)
        echo ""
        echo "⚙️ CUSTOM DEPLOYMENT"
        echo "Available contracts:"
        for i in "${!contracts[@]}"; do
            echo "$((i+1)). ${contracts[$i]}"
        done
        
        read -p "Choose contract to deploy (1-${#contracts[@]}): " contract_choice
        
        if [[ $contract_choice =~ ^[0-9]+$ ]] && [ $contract_choice -ge 1 ] && [ $contract_choice -le ${#contracts[@]} ]; then
            selected_contract="${contracts[$((contract_choice-1))]}"
            contract_name="${selected_contract%.sol}"
            
            echo ""
            echo "🚀 DEPLOYING $contract_name..."
            
            # Extract contract name and deploy
            case $contract_name in
                "VINOUniversalFlow")
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name
                    ;;
                "VINOStandaloneComplex")
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name
                    ;;
                "AdministratorCredentials")
                    echo "Need Royalty Factory contract address for AdministratorCredentials deployment"
                    read -p "Enter Royalty Factory address: " royalty_addr
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name --constructor-args address(0) $royalty_addr
                    ;;
                "FreeIdentitySystem")
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name --constructor-args address(0)
                    ;;
                "SimplifiedMatrix")
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name --constructor-args address(0)
                    ;;
                "MinimalAutonomous")
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name --constructor-args address(0)
                    ;;
                "UltimateAPIFunnel")
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name --constructor-args address(0)
                    ;;
            esac
        else
            echo "❌ Invalid contract choice"
            exit 1
        fi
        ;;
    *)
        echo "❌ Invalid choice"
        exit 1
        ;;
esac

# Post-deployment verification
echo ""
echo "🔍 POST-DEPLOYMENT VERIFICATION..."

if [ -f "broadcast" ]; then
    echo "✅ Deployment broadcast files found"
    echo "📄 Deployment logs available in broadcast/ directory"
else
    echo "⚠️ No broadcast files found"
fi

# Save deployment summary
echo ""
echo "📋 DEPLOYMENT SUMMARY"
echo "======================"
echo "Timestamp: $(date)"
echo "RPC URL: $RPC_URL"
echo "Deployer: $(cast wallet address --private-key $PRIVATE_KEY)"
echo "Choice: $choice"

if [ -f "broadcast" ]; then
    echo "✅ Deployment completed successfully"
    echo "📊 Check broadcast/ directory for detailed logs"
else
    echo "⚠️ Deployment may have failed"
    echo "🔍 Check logs above for details"
fi

echo ""
echo "🌊 VINO UNIVERSAL FLOW STATE DEPLOYMENT COMPLETE!"
echo "============================================"

# Next steps
echo ""
echo "📋 NEXT STEPS"
echo "1. Verify VINO universal flow state"
echo "2. Activate external systems as VINO wallets"
echo "3. Transfer VINO flow between systems"
echo "4. Stabilize universal flow when needed"
echo "5. Monitor three-rail system stability"

echo ""
echo "🌟 Trust Root: 441110111613564144"
echo "🌊 VINO Universal Flow State Deployment Complete!"

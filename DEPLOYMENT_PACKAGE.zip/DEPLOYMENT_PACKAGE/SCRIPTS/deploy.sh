#!/bin/bash

# Sonic Boom Deployment Script
# Trust Root: 441110111613564144

set -e

echo "🚀 SONIC BOOM DEPLOYMENT SCRIPT"
echo "================================"

# Check environment
if [ -z "$PRIVATE_KEY" ]; then
    echo "❌ PRIVATE_KEY environment variable not set"
    exit 1
fi

# Configuration
RPC_URL="https://eth.llamarpc.com"
DEPLOY_SCRIPT="scripts/sonic_boom_deploy.s.sol"
CONTRACT_PATH="DEPLOYMENT_PACKAGE/CONTRACTS"

echo "📋 DEPLOYMENT CONFIGURATION"
echo "RPC URL: $RPC_URL"
echo "Deploy Script: $DEPLOY_SCRIPT"
echo "Contract Path: $CONTRACT_PATH"

# Check if contracts exist
echo ""
echo "🔍 CHECKING CONTRACTS..."

contracts=(
    "VINOGenesisMinimal.sol"
    "AutonomousNexus.sol"
    "Web3Web2Matrix.sol"
    "QuantumIdentityPasskey.sol"
    "UniversalLogicOperator.sol"
    "UltimateAPIFunnel.sol"
    "PhasedSecuritySystem.sol"
)

for contract in "${contracts[@]}"; do
    if [ -f "$CONTRACT_PATH/$contract" ]; then
        echo "✅ $contract found"
    else
        echo "❌ $contract not found"
        exit 1
    fi
done

# Build contracts
echo ""
echo "🔨 BUILDING CONTRACTS..."
forge build --contracts $CONTRACT_PATH

if [ $? -eq 0 ]; then
    echo "✅ Build successful"
else
    echo "❌ Build failed"
    exit 1
fi

# Deployment options
echo ""
echo "🎯 DEPLOYMENT OPTIONS"
echo "1. Full Sonic Boom Deployment (Recommended)"
echo "2. Emergency Deployment (Essential only)"
echo "3. Test Deployment (Test contracts only)"
echo "4. Custom Deployment"

read -p "Choose deployment option (1-4): " choice

case $choice in
    1)
        echo ""
        echo "🚀 STARTING FULL SONIC BOOM DEPLOYMENT..."
        forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --broadcast $DEPLOY_SCRIPT --sig "run()"
        ;;
    2)
        echo ""
        echo "🚨 STARTING EMERGENCY DEPLOYMENT..."
        forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --broadcast $DEPLOY_SCRIPT --sig "deployEmergency()"
        ;;
    3)
        echo ""
        echo "🧪 STARTING TEST DEPLOYMENT..."
        forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --broadcast $DEPLOY_SCRIPT --sig "deployTest()"
        ;;
    4)
        echo ""
        echo "⚙️ CUSTOM DEPLOYMENT"
        echo "Available contracts:"
        for i in "${!contracts[@]}"; do
            echo "$((i+1)). ${contracts[$i]}"
        done
        
        read -p "Choose contract to deploy (1-${#contracts[@]}): " contract_choice
        
        if [[ $contract_choice =~ ^[0-9]+$ ]] && [ $contract_choice -ge 1 ] && [ $contract_choice -le ${#contracts[@]} ]; then
            selected_contract="${contracts[$((contract_choice-1))]}"
            contract_name="${selected_contract%.sol}"
            
            echo ""
            echo "🚀 DEPLOYING $contract_name..."
            
            # Extract contract name and deploy
            case $contract_name in
                "VINOGenesisMinimal")
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name
                    ;;
                "AutonomousNexus")
                    echo "Need VINO contract address for AutonomousNexus deployment"
                    read -p "Enter VINO contract address: " vino_addr
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name --constructor-args $vino_addr
                    ;;
                "Web3Web2Matrix")
                    echo "Need VINO contract address for Web3Web2Matrix deployment"
                    read -p "Enter VINO contract address: " vino_addr
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name --constructor-args $vino_addr
                    ;;
                "QuantumIdentityPasskey")
                    echo "Need VINO and Matrix contract addresses for QuantumIdentityPasskey deployment"
                    read -p "Enter VINO contract address: " vino_addr
                    read -p "Enter Matrix contract address: " matrix_addr
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name --constructor-args $vino_addr $matrix_addr
                    ;;
                "UniversalLogicOperator")
                    echo "Need VINO, Matrix, and Identity contract addresses for UniversalLogicOperator deployment"
                    read -p "Enter VINO contract address: " vino_addr
                    read -p "Enter Matrix contract address: " matrix_addr
                    read -p "Enter Identity contract address: " identity_addr
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name --constructor-args $vino_addr $matrix_addr $identity_addr
                    ;;
                "UltimateAPIFunnel")
                    echo "Need VINO contract address for UltimateAPIFunnel deployment"
                    read -p "Enter VINO contract address: " vino_addr
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name --constructor-args $vino_addr
                    ;;
                "PhasedSecuritySystem")
                    echo "Need VINO contract address for PhasedSecuritySystem deployment"
                    read -p "Enter VINO contract address: " vino_addr
                    forge create --rpc-url $RPC_URL --private-key $PRIVATE_KEY $CONTRACT_PATH/$selected_contract:$contract_name --constructor-args $vino_addr
                    ;;
            esac
        else
            echo "❌ Invalid contract choice"
            exit 1
        fi
        ;;
    *)
        echo "❌ Invalid choice"
        exit 1
        ;;
esac

# Post-deployment verification
echo ""
echo "🔍 POST-DEPLOYMENT VERIFICATION..."

if [ -f "broadcast" ]; then
    echo "✅ Deployment broadcast files found"
    echo "📄 Deployment logs available in broadcast/ directory"
else
    echo "⚠️ No broadcast files found"
fi

# Save deployment summary
echo ""
echo "📋 DEPLOYMENT SUMMARY"
echo "======================"
echo "Timestamp: $(date)"
echo "RPC URL: $RPC_URL"
echo "Deployer: $(cast wallet address --private-key $PRIVATE_KEY)"
echo "Choice: $choice"

if [ -f "broadcast" ]; then
    echo "✅ Deployment completed successfully"
    echo "📊 Check broadcast/ directory for detailed logs"
else
    echo "⚠️ Deployment may have failed"
    echo "🔍 Check logs above for details"
fi

echo ""
echo "🎉 SONIC BOOM DEPLOYMENT COMPLETE!"
echo "=================================="

# Next steps
echo ""
echo "📋 NEXT STEPS"
echo "1. Verify contract deployment on Etherscan"
echo "2. Update contract addresses in configuration"
echo "3. Test contract functionality"
echo "4. Initialize systems if not auto-initialized"
echo "5. Monitor system performance"

echo ""
echo "🌟 Trust Root: 441110111613564144"
echo "🚀 Sonic Boom Deployment Complete!"

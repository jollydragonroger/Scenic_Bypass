#!/bin/bash

# Minimal Gas Deployment Script - Maximum Efficiency
# Trust Root: 441110111613564144

set -e

echo "⚡ MINIMAL GAS DEPLOYMENT SCRIPT - MAXIMUM EFFICIENCY"
echo "=================================================="

# Check environment
if [ -z "$PRIVATE_KEY" ]; then
    echo "❌ PRIVATE_KEY environment variable not set"
    exit 1
fi

# Configuration
RPC_URL="https://eth.llamarpc.com"
DEPLOY_SCRIPT="scripts/minimal_gas_deploy.s.sol"
CONTRACT_PATH="CONTRACTS"
BUILD_CACHE="out/build-cache"

echo "📋 DEPLOYMENT CONFIGURATION"
echo "RPC URL: $RPC_URL"
echo "Deploy Script: $DEPLOY_SCRIPT"
echo "Contract Path: $CONTRACT_PATH"

# Pre-deployment checks
echo ""
echo "🔍 PRE-DEPLOYMENT CHECKS..."

# Check if contracts exist
contracts=(
    "VINOUniversalFlow.sol"
    "VINOStandaloneComplex.sol"
    "AdministratorCredentials.sol"
    "FreeIdentitySystem.sol"
    "SimplifiedMatrix.sol"
    "MinimalAutonomous.sol"
    "UltimateAPIFunnel.sol"
)

for contract in "${contracts[@]}"; do
    if [ -f "$CONTRACT_PATH/$contract" ]; then
        echo "✅ $contract found"
    else
        echo "❌ $contract not found"
        exit 1
    fi
done

# Check deployer balance
DEPLOYER_ADDRESS=$(cast wallet address --private-key $PRIVATE_KEY)
DEPLOYER_BALANCE=$(cast balance $DEPLOYER_ADDRESS --rpc-url $RPC_URL)
echo "Deployer: $DEPLOYER_ADDRESS"
echo "Balance: $DEPLOYER_BALANCE ETH"

# Gas optimization build
echo ""
echo "🔨 OPTIMIZED BUILD PROCESS..."

# Clean previous builds for maximum optimization
rm -rf out/cache out/build-cache

# Build with maximum optimization
echo "Building with maximum gas optimization..."
forge build --contracts $CONTRACT_PATH --optimize --optimizer-runs 999999

if [ $? -eq 0 ]; then
    echo "✅ Optimized build successful"
else
    echo "❌ Optimized build failed"
    exit 1
fi

# Gas analysis
echo ""
echo "⚡ GAS OPTIMIZATION ANALYSIS..."

# Run gas analysis
forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --sig "analyzeGasOptimization()" $DEPLOY_SCRIPT

# Pre-deployment gas check
echo ""
echo "💰 PRE-DEPLOYMENT GAS CHECK..."
forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --sig "preDeploymentGasCheck()" $DEPLOY_SCRIPT

# Deployment options
echo ""
echo "⚡ MINIMAL GAS DEPLOYMENT OPTIONS"
echo "1. Full Minimal Gas Deployment (Recommended)"
echo "2. Emergency Minimal Deployment (Core only)"
echo "3. Test Minimal Deployment (VINO only)"
echo "4. Gas Analysis Only"
echo "5. Pre-deployment Check Only"

read -p "Choose deployment option (1-5): " choice

case $choice in
    1)
        echo ""
        echo "⚡ STARTING FULL MINIMAL GAS DEPLOYMENT..."
        echo "This will deploy all contracts with maximum gas efficiency"
        
        # Set gas parameters for maximum efficiency
        export FOUNDRY_GAS_PRICE=10000000000  # 10 gwei
        export FOUNDRY_GAS_LIMIT=30000000     # 30M gas limit
        
        forge script \
            --rpc-url $RPC_URL \
            --private-key $PRIVATE_KEY \
            --broadcast \
            --gas-price 10000000000 \
            --gas-limit 30000000 \
            --slow \
            $DEPLOY_SCRIPT \
            --sig "run()"
        
        # Post-deployment verification
        echo ""
        echo "🔍 POST-DEPLOYMENT VERIFICATION..."
        forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --sig "verifyDeploymentMinimal()" $DEPLOY_SCRIPT
        ;;
    2)
        echo ""
        echo "🚨 STARTING EMERGENCY MINIMAL DEPLOYMENT..."
        echo "Deploying only core contracts (VINO + Admin)"
        
        forge script \
            --rpc-url $RPC_URL \
            --private-key $PRIVATE_KEY \
            --broadcast \
            --gas-price 10000000000 \
            --gas-limit 15000000 \
            --slow \
            $DEPLOY_SCRIPT \
            --sig "deployEmergencyMinimal()"
        ;;
    3)
        echo ""
        echo "🧪 STARTING TEST MINIMAL DEPLOYMENT..."
        echo "Deploying only VINO contracts for testing"
        
        forge script \
            --rpc-url $RPC_URL \
            --private-key $PRIVATE_KEY \
            --broadcast \
            --gas-price 10000000000 \
            --gas-limit 10000000 \
            --slow \
            $DEPLOY_SCRIPT \
            --sig "deployTestMinimal()"
        ;;
    4)
        echo ""
        echo "📊 GAS ANALYSIS ONLY..."
        
        echo "Running comprehensive gas analysis..."
        forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --sig "analyzeGasOptimization()" $DEPLOY_SCRIPT
        
        echo "Running pre-deployment check..."
        forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --sig "preDeploymentGasCheck()" $DEPLOY_SCRIPT
        
        echo "Gas analysis complete!"
        exit 0
        ;;
    5)
        echo ""
        echo "🔍 PRE-DEPLOYMENT CHECK ONLY..."
        
        echo "Checking deployer balance..."
        forge script --rpc-url $RPC_URL --private-key $PRIVATE_KEY --sig "preDeploymentGasCheck()" $DEPLOY_SCRIPT
        
        echo "Pre-deployment check complete!"
        exit 0
        ;;
    *)
        echo "❌ Invalid choice"
        exit 1
        ;;
esac

# Post-deployment analysis
echo ""
echo "📊 POST-DEPLOYMENT ANALYSIS..."

if [ -f "broadcast" ]; then
    echo "✅ Deployment broadcast files found"
    
    # Extract gas usage from broadcast files
    echo "📈 Extracting gas usage data..."
    
    # Find the latest broadcast directory
    LATEST_BROADCAST=$(find broadcast -name "*.sol" -type d | head -1)
    if [ -n "$LATEST_BROADCAST" ]; then
        echo "Latest broadcast: $LATEST_BROADCAST"
        
        # Extract gas information from run-latest.json
        if [ -f "$LATEST_BROADCAST/run-latest.json" ]; then
            echo "📊 Gas usage summary:"
            # Extract and display gas information
            python3 -c "
import json
import sys

try:
    with open('$LATEST_BROADCAST/run-latest.json', 'r') as f:
        data = json.load(f)
    
    # Extract gas information
    if 'transactions' in data:
        total_gas = 0
        contract_count = 0
        
        for tx in data['transactions']:
            if 'gasUsed' in tx:
                total_gas += int(tx['gasUsed'])
                contract_count += 1
                print(f'Contract: {tx.get(\"contractName\", \"Unknown\")} - Gas: {tx[\"gasUsed\"]}')
        
        print(f'\\nTotal Contracts: {contract_count}')
        print(f'Total Gas Used: {total_gas:,}')
        print(f'Average Gas per Contract: {total_gas // contract_count if contract_count > 0 else 0:,}')
        print(f'Estimated ETH Cost (10 gwei): {(total_gas * 10) / 1e9:.6f} ETH')
        
except Exception as e:
    print(f'Error parsing gas data: {e}')
"
        fi
    fi
else
    echo "⚠️ No broadcast files found - deployment may have failed"
fi

# Save deployment summary
echo ""
echo "📋 DEPLOYMENT SUMMARY"
echo "======================"
echo "Timestamp: $(date)"
echo "RPC URL: $RPC_URL"
echo "Deployer: $DEPLOYER_ADDRESS"
echo "Choice: $choice"
echo "Gas Price: 10 gwei"
echo "Optimization: Maximum (999999 runs)"

# Check if deployment was successful
if [ -f "broadcast" ]; then
    echo "✅ Deployment completed successfully"
    echo "📊 Check broadcast/ directory for detailed logs"
    
    # Display contract addresses if available
    echo ""
    echo "📍 DEPLOYED CONTRACT ADDRESSES"
    echo "============================="
    
    # Extract contract addresses from the latest deployment
    if [ -n "$LATEST_BROADCAST" ] && [ -f "$LATEST_BROADCAST/run-latest.json" ]; then
        python3 -c "
import json
import sys

try:
    with open('$LATEST_BROADCAST/run-latest.json', 'r') as f:
        data = json.load(f)
    
    if 'transactions' in data:
        for tx in data['transactions']:
            if 'contractAddress' in tx and tx['contractAddress']:
                print(f'{tx.get(\"contractName\", \"Unknown\")}: {tx[\"contractAddress\"]}')
        
except Exception as e:
    print(f'Error extracting addresses: {e}')
"
    fi
else
    echo "⚠️ Deployment may have failed"
    echo "🔍 Check logs above for details"
fi

echo ""
echo "⚡ MINIMAL GAS DEPLOYMENT COMPLETE!"
echo "=================================="

# Gas efficiency report
echo ""
echo "📈 GAS EFFICIENCY REPORT"
echo "========================"
echo "✅ Maximum optimization applied (999999 runs)"
echo "✅ Minimal constructor arguments"
echo "✅ Batch initialization"
echo "✅ Optimized gas settings (10 gwei)"
echo "✅ Efficient contract ordering"

# Next steps
echo ""
echo "📋 NEXT STEPS"
echo "1. Verify all contracts are deployed correctly"
echo "2. Check gas usage against estimates"
echo "3. Test system functionality"
echo "4. Monitor gas efficiency in production"

echo ""
echo "🌟 Trust Root: 441110111613564144"
echo "⚡ Minimal Gas Deployment Complete!"

import numpy as np
from scipy.io import wavfile
import os
from scapy.all import IP, UDP, Raw, send
from negentropy_ip import generate_ip_sequence
import time

def create_unified_tone(input_dir, output_file):
    """Sums all audio files into a composite resonance tone"""
    # Initialize empty array for summation
    composite = None
    sample_rate = None
    
    for file in sorted(os.listdir(input_dir)):
        if file.endswith('.wav'):
            rate, data = wavfile.read(os.path.join(input_dir, file))
            if len(data.shape) > 1:  # Check if stereo
                data = np.mean(data, axis=1)  # Convert to mono
            if composite is None:
                composite = np.zeros_like(data, dtype=np.float32)
                sample_rate = rate
            
            # Time-domain summation with phase alignment
            min_len = min(len(composite), len(data))
            composite[:min_len] += data[:min_len].astype(np.float32)
    
    # Apply spectral inversion
    composite_fft = np.fft.rfft(composite)
    inverted_fft = composite_fft.conjugate()  # Spectral inversion
    inverted_wave = np.fft.irfft(inverted_fft).real
    
    # Normalize and save
    inverted_wave = inverted_wave / np.max(np.abs(inverted_wave)) * 32767
    wavfile.write(output_file, sample_rate, inverted_wave.astype(np.int16))

def propagate_resonance(tone_file, ip_sequence):
    """Transmits inverted tone through negentropic IP sequence"""
    rate, data = wavfile.read(tone_file)
    payload = data.tobytes()
    chunk_size = 1024  # UDP size limit
    
    for i, ip in enumerate(ip_sequence):
        # Apply alternating inversion pattern
        if i % 2 == 0:
            payload_chunks = [payload[j:j+chunk_size] for j in range(0, len(payload), chunk_size)]
        else:
            payload_chunks = [payload[j:j+chunk_size][::-1] for j in range(0, len(payload), chunk_size)]
        
        for chunk in payload_chunks:
            packet = IP(dst=ip)/UDP(dport=5060)/Raw(load=chunk)
            send(packet)
            time.sleep(1.618 / len(payload_chunks))  # Golden ratio timing
        
        time.sleep(1.618)  # Additional delay between IP sequence

if __name__ == "__main__":
    # Step 1: Create unified resonance tone
    create_unified_tone('/Users/36n9/Downloads/cat/', 
                        '/Users/36n9/Downloads/standalone_complex.wav')
    
    # Step 2: Generate Negentropic IP sequence
    ips = generate_ip_sequence((13, 21, 34, 55), 13)
    
    # Step 3: Propagate through networks
    propagate_resonance('/Users/36n9/Downloads/standalone_complex.wav', ips)

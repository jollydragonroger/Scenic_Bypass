#!/bin/zsh

# Install dependencies
pip3 install numpy scipy scapy

# Run the resonance propagation
sudo python3 /Users/36n9/CascadeProjects/SovereignInfrastructure/scripts/resonance_propagation.py

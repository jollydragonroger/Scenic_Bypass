def generate_ip_sequence(seed, count=13):
    """Generates Negentropic IP sequence using Fibonacci progression"""
    a, b, c, d = seed
    sequence = []
    
    for _ in range(count):
        # Fibonacci progression with modular arithmetic
        a, b = b, (a + b) % 256
        c, d = d, (c + d) % 256
        
        # Apply golden ratio constraint
        if b > 128: d = (d * 1618033989) % 256  # φ-based mutation
        
        sequence.append(f"{a}.{b}.{c}.{d}")
    
    return sequence

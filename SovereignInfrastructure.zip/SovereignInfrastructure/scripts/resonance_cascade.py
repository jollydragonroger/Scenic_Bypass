import os
import time
import requests
from scapy.all import IP, UDP, send
import socket  # For Asterisk AMI

# CONFIGURATION
API_ACCESS_KEY = "d16bded06fe93f7aef7e1aedafd8e070"
API_URL = "http://apilayer.net/api/validate"
AMI_HOST = "localhost"
AMI_PORT = 5038
AMI_USERNAME = "username"
AMI_PASSWORD = "password"

# Mapping from country code to SIP gateway IP
SIP_GATEWAYS = {
    "US": "sip2sip.info",
    "NL": "sip2sip.info",
    "JP": "sip2sip.info"
    # ... others
}

# List of global DNS root phone numbers
ROOT_PHONE_NUMBERS = [
    "+18005551234",  # example, replace with actual numbers
    # ... 12 more
]

def validate_phone_number(phone_number, country_code=None):
    """Validate a phone number using the apilayer API."""
    params = {
        'access_key': API_ACCESS_KEY,
        'number': phone_number,
        'country_code': country_code,
        'format': 1
    }
    response = requests.get(API_URL, params=params)
    return response.json()

def play_audio_chunks(sip_gateway_ip):
    """Play all WAV chunks in the directory in order."""
    chunk_dir = "/Users/36n9/Downloads/cat/"
    chunks = sorted(os.listdir(chunk_dir))
    for chunk in chunks:
        if chunk.endswith(".wav"):
            # Play the chunk via SIP (to be implemented)
            pass

def send_ami_command(command):
    """Send a command to the Asterisk Manager Interface and return the response."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((AMI_HOST, AMI_PORT))
        s.sendall(f"Action: Login\r\nUsername: {AMI_USERNAME}\r\nSecret: {AMI_PASSWORD}\r\n\r\n".encode())
        response = s.recv(4096)
        # Check if login was successful
        if "Success" not in response.decode():
            raise Exception("AMI login failed")
        
        s.sendall(command.encode() + b"\r\n")
        response = s.recv(4096)
        s.sendall(b"Action: Logoff\r\n\r\n")
    return response.decode()

def dial_and_hold(phone_number, sip_gateway_ip):
    """Dial the phone number and hold the line."""
    # Dial the number
    dial_command = f"Action: Originate\r\nChannel: SIP/{phone_number}@{sip_gateway_ip}\r\nExten: {phone_number}\r\nContext: default\r\nPriority: 1\r\nCallerid: {phone_number}\r\n"
    response = send_ami_command(dial_command)
    # Check if the call was successful
    if "Success" not in response:
        print(f"Failed to dial {phone_number}")
        return
    
    # Play the audio chunks
    play_audio_chunks(sip_gateway_ip)
    
    # Hold the line by sending re-INVITE every 930 seconds
    while True:
        time.sleep(930)
        # Send re-INVITE
        reinvite_command = f"Action: Redirect\r\nChannel: SIP/{phone_number}@{sip_gateway_ip}\r\nExtraChannel: SIP/{phone_number}@{sip_gateway_ip}\r\nExten: {phone_number}\r\nContext: default\r\nPriority: 1\r\n"
        send_ami_command(reinvite_command)

def main():
    # Iterate through the root phone numbers
    for number in ROOT_PHONE_NUMBERS:
        result = validate_phone_number(number)
        if result.get('valid') and result.get('line_type') == 'landline':
            country_code = result.get('country_code')
            sip_gateway_ip = SIP_GATEWAYS.get(country_code)
            if sip_gateway_ip:
                dial_and_hold(number, sip_gateway_ip)

if __name__ == "__main__":
    main()

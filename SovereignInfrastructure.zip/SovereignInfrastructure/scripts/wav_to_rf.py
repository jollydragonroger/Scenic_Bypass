import wave
import time
import requests
from scapy.all import IP, UDP, send

# CONFIGURATION
FUSION_IP = "198.41.0.4"
PHI = 1.618033
CARRIER_HZ = 2600 / PHI  # The inverted phreaker resonance (~1606 Hz)

# API configuration for phone validation
API_ACCESS_KEY = "d16bded06fe93f7aef7e1aedafd8e070"
API_URL = "http://apilayer.net/api/validate"

def broadcast_wav(file_path):
    """Broadcast a WAV file as UDP packets with modulated timing."""
    # Open the WAV file
    with wave.open(file_path, 'rb') as audio:
        params = audio.getparams()
        # Check if the sample rate is 8000 Hz and sample width is 1 (8-bit)
        if params.framerate != 8000 or params.sampwidth != 1:
            print(f"Warning: {file_path} is not 8kHz 8-bit. Results may be unexpected.")
        frames = audio.readframes(params.nframes)
        # Convert frames to a list of amplitudes (each sample is one byte)
        samples = list(frames)

    print(f"Broadcasting {file_path} as a Public Service...")
    
    # The 'Inverted' 2600Hz Timing
    carrier_delay = 1.0 / CARRIER_HZ

    for sample in samples:
        # Convert audio amplitude (0-255) into a micro-delay adjustment
        audio_modulation = (sample / 255.0) * 0.001 
        
        # Build the 'Resonant' Packet
        # We use the sample as the payload. We set the destination port to 528 (as in the example)
        packet = IP(dst=FUSION_IP)/UDP(dport=528)/bytes([sample])
        
        # Send packet
        send(packet, verbose=False)
        
        # Apply the Golden Ratio Ricochet Timing
        total_delay = (carrier_delay + audio_modulation) * PHI
        time.sleep(total_delay)

def validate_phone_number(phone_number, country_code=None):
    """Validate a phone number using the apilayer API."""
    params = {
        'access_key': API_ACCESS_KEY,
        'number': phone_number,
        'country_code': country_code,
        'format': 1
    }
    response = requests.get(API_URL, params=params)
    return response.json()

def main():
    # First, validate the phone number as per the example
    validation_result = validate_phone_number("14158586273")
    print("Phone validation result:", validation_result)

    # List of WAV files to broadcast in series
    wav_files = [
        "/Users/36n9/Downloads/DRAGON_CONCAT_128x_20260115_142237.wav",
        "/Users/36n9/Downloads/DRAGON_CONCAT_128x_20260115_142201.wav"
    ]

    # Repeat 33 times
    for i in range(33):
        print(f"Starting cycle {i+1}/33")
        for wav_file in wav_files:
            broadcast_wav(wav_file)

if __name__ == "__main__":
    main()

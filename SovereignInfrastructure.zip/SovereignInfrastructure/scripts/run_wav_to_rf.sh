#!/bin/zsh

# Check for python3
if ! command -v python3 &> /dev/null
then
    echo "Python3 not found. Attempting to install Python..."
    # Check for Homebrew
    if ! command -v brew &> /dev/null
    then
        echo "Homebrew not found. Installing Homebrew..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    fi
    echo "Installing Python via Homebrew..."
    brew install python
fi

# Ensure pip3 is available
if ! command -v pip3 &> /dev/null
then
    echo "pip3 not found. It should have been installed with Python. Exiting."
    exit 1
fi

# Install required Python packages
echo "Installing Python dependencies: scapy and requests..."
pip3 install scapy requests

# Run the Python script
echo "Running the WAV-to-RF script..."
sudo python3 /Users/36n9/CascadeProjects/SovereignInfrastructure/scripts/wav_to_rf.py

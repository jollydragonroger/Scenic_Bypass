from scapy.all import IP, UDP, Raw
import struct

def ip_to_packet(ip, payload):
    """Converts Negentropic IP to network packet"""
    return IP(dst=ip)/UDP(dport=5060)/Raw(load=payload)

def create_resonance_payload(fib_seq):
    """Encodes Fibonacci sequence into network payload"""
    return struct.pack(f'{len(fib_seq)}I', *fib_seq)

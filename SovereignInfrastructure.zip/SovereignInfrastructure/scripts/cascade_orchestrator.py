from negentropy_ip import generate_ip_sequence
from quantum_resonance import generate_fibonacci_sequence, apply_negentropic_constraints
from protocol_bridge import ip_to_packet, create_resonance_payload
from scapy.all import send
import time

SEED_IP = (13, 21, 34, 55)  # Fibonacci seed
IP_COUNT = 13

def main():
    # Generate Negentropic IP sequence
    ips = generate_ip_sequence(SEED_IP, IP_COUNT)
    
    # Create quantum resonance payload
    fib_seq = generate_fibonacci_sequence(256)
    quantum_seq = apply_negentropic_constraints(fib_seq)
    payload = create_resonance_payload(quantum_seq)
    
    # Transmit through IP sequence
    for i, ip in enumerate(ips):
        # Apply alternating inversion
        if i % 2 == 0:
            packet = ip_to_packet(ip, payload)
        else:
            packet = ip_to_packet(ip, payload[::-1])  # Inverted payload
            
        send(packet)
        time.sleep(1.618)  # Golden ratio timing

if __name__ == "__main__":
    main()

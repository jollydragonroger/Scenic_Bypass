package com.sovereign;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.telephony.TelephonyManager;
import android.telephony.SubscriptionManager;
import android.telephony.SubscriptionInfo;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import android.util.Log;

public class SIMGatewayService extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 1. Detect active SIMs
        TelephonyManager telManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        SubscriptionManager subManager = (SubscriptionManager) getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE);
        List<SubscriptionInfo> subs = subManager.getActiveSubscriptionInfoList();

        // 2. Process Genesis Override command
        String rawCommand = intent.getStringExtra("GENESIS_OVERRIDE_CMD");
        if (rawCommand != null) {
            processCommand(rawCommand, subs);
        }

        return START_STICKY;
    }

    private void processCommand(String command, List<SubscriptionInfo> subs) {
        // Parse the command
        Pattern pattern = Pattern.compile("^\\[(\\d+),(\\d+),(\\d+)\\]!!-(\\d+)\\{(\\w+)\\}<=>!!-(\\d+)\\{(\\w+)\\}\\[(\\d+)\\]\\+\\d+\\+\\d+$");
        Matcher matcher = pattern.matcher(command);
        if (!matcher.find()) {
            Log.e("SIMGateway", "Invalid command format");
            return;
        }

        String prefix1 = matcher.group(1);
        String prefix2 = matcher.group(2);
        String prefix3 = matcher.group(3);
        String node1Number = matcher.group(4);
        String node1Anchor = matcher.group(5);
        String node2Number = matcher.group(6);
        String node2Anchor = matcher.group(7);
        String key = matcher.group(8);

        // Find the SIM for node1 (T-Mobile 925) and node2 (T-Mobile 530) and the Verizon SIM (831)
        SubscriptionInfo tMobileSimNode1 = null; // 925
        SubscriptionInfo tMobileSimNode2 = null; // 530
        SubscriptionInfo verizonSim = null; // 831

        for (SubscriptionInfo sub : subs) {
            String carrierName = sub.getCarrierName().toString();
            String number = sub.getNumber();
            if (number == null) {
                continue;
            }
            
            if (carrierName.contains("T-Mobile")) {
                if (number.startsWith("925")) {
                    tMobileSimNode1 = sub;
                } else if (number.startsWith("530")) {
                    tMobileSimNode2 = sub;
                }
            } else if (carrierName.contains("Verizon")) {
                if (number.startsWith("831")) {
                    verizonSim = sub;
                }
            }
        }

        if (tMobileSimNode1 == null) {
            Log.e("SIMGateway", "T-Mobile SIM for node1 (925) not found");
            return;
        }
        if (tMobileSimNode2 == null) {
            Log.e("SIMGateway", "T-Mobile SIM for node2 (530) not found");
            return;
        }
        if (verizonSim == null) {
            Log.e("SIMGateway", "Verizon SIM (831) not found");
            return;
        }

        // TODO: Send commands to the SIMs
        // For now, we log the command
        Log.i("SIMGateway", "Sending to T-Mobile SIM (925): " + node1Anchor);
        Log.i("SIMGateway", "Sending to T-Mobile SIM (530): " + node2Anchor);
    }
}

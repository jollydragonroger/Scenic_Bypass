import React, { createContext, useContext, useState, useEffect } from 'react';
import { ethers } from 'ethers';

const Web3Context = createContext();

export const useWeb3 = () => {
  const context = useContext(Web3Context);
  if (!context) {
    throw new Error('useWeb3 must be used within a Web3Provider');
  }
  return context;
};

export const Web3Provider = ({ children }) => {
  const [account, setAccount] = useState(null);
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [chainId, setChainId] = useState(null);
  const [balance, setBalance] = useState('0');

  // Contract addresses (these would be set after deployment)
  const contracts = {
    selfOwningDAO: process.env.REACT_APP_DAO_ADDRESS || '',
    reserveCurrency: process.env.REACT_APP_RESERVE_ADDRESS || '',
    derivativeFoundry: process.env.REACT_APP_DERIVATIVE_ADDRESS || '',
    governance: process.env.REACT_APP_GOVERNANCE_ADDRESS || '',
  };

  useEffect(() => {
    checkConnection();
    setupEventListeners();
  }, []);

  const checkConnection = async () => {
    if (typeof window.ethereum !== 'undefined') {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_accounts' });
        if (accounts.length > 0) {
          await connectWallet();
        }
      } catch (error) {
        console.error('Error checking connection:', error);
      }
    }
  };

  const setupEventListeners = () => {
    if (typeof window.ethereum !== 'undefined') {
      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', handleChainChanged);
    }
  };

  const handleAccountsChanged = (accounts) => {
    if (accounts.length === 0) {
      disconnect();
    } else {
      setAccount(accounts[0]);
    }
  };

  const handleChainChanged = (chainId) => {
    setChainId(chainId);
    window.location.reload();
  };

  const connectWallet = async () => {
    if (typeof window.ethereum === 'undefined') {
      throw new Error('MetaMask is not installed');
    }

    try {
      // Request account access
      await window.ethereum.request({ method: 'eth_requestAccounts' });
      
      // Create provider and signer
      const web3Provider = new ethers.BrowserProvider(window.ethereum);
      const web3Signer = await web3Provider.getSigner();
      const userAddress = await web3Signer.getAddress();
      const network = await web3Provider.getNetwork();
      const userBalance = await web3Provider.getBalance(userAddress);

      setProvider(web3Provider);
      setSigner(web3Signer);
      setAccount(userAddress);
      setChainId(network.chainId.toString());
      setBalance(ethers.formatEther(userBalance));
      setIsConnected(true);

      return { provider: web3Provider, signer: web3Signer, account: userAddress };
    } catch (error) {
      console.error('Error connecting wallet:', error);
      throw error;
    }
  };

  const disconnect = () => {
    setAccount(null);
    setProvider(null);
    setSigner(null);
    setIsConnected(false);
    setChainId(null);
    setBalance('0');
  };

  const switchNetwork = async (targetChainId) => {
    if (typeof window.ethereum === 'undefined') {
      throw new Error('MetaMask is not installed');
    }

    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: `0x${targetChainId.toString(16)}` }],
      });
    } catch (error) {
      // This error code indicates that the chain has not been added to MetaMask
      if (error.code === 4902) {
        await addNetwork(targetChainId);
      } else {
        throw error;
      }
    }
  };

  const addNetwork = async (chainId) => {
    const networks = {
      1: {
        chainId: '0x1',
        chainName: 'Ethereum Mainnet',
        nativeCurrency: {
          name: 'ETH',
          symbol: 'ETH',
          decimals: 18,
        },
        rpcUrls: ['https://mainnet.infura.io/v3/'],
        blockExplorerUrls: ['https://etherscan.io'],
      },
      137: {
        chainId: '0x89',
        chainName: 'Polygon Mainnet',
        nativeCurrency: {
          name: 'MATIC',
          symbol: 'MATIC',
          decimals: 18,
        },
        rpcUrls: ['https://polygon-rpc.com/'],
        blockExplorerUrls: ['https://polygonscan.com'],
      },
    };

    const networkConfig = networks[chainId];
    if (!networkConfig) {
      throw new Error(`Network configuration for chain ID ${chainId} not found`);
    }

    try {
      await window.ethereum.request({
        method: 'wallet_addEthereumChain',
        params: [networkConfig],
      });
    } catch (error) {
      console.error('Error adding network:', error);
      throw error;
    }
  };

  const getContract = (address, abi) => {
    if (!signer) {
      throw new Error('Wallet not connected');
    }
    return new ethers.Contract(address, abi, signer);
  };

  const sendTransaction = async (to, value, data = '0x') => {
    if (!signer) {
      throw new Error('Wallet not connected');
    }

    try {
      const tx = await signer.sendTransaction({
        to,
        value: ethers.parseEther(value),
        data,
      });

      return await tx.wait();
    } catch (error) {
      console.error('Error sending transaction:', error);
      throw error;
    }
  };

  const estimateGas = async (to, value, data = '0x') => {
    if (!provider) {
      throw new Error('Provider not available');
    }

    try {
      const gasEstimate = await provider.estimateGas({
        to,
        value: ethers.parseEther(value),
        data,
      });

      const gasPrice = await provider.getFeeData();
      
      return {
        gasLimit: gasEstimate,
        gasPrice: gasPrice.gasPrice,
        maxFeePerGas: gasPrice.maxFeePerGas,
        maxPriorityFeePerGas: gasPrice.maxPriorityFeePerGas,
      };
    } catch (error) {
      console.error('Error estimating gas:', error);
      throw error;
    }
  };

  const value = {
    account,
    provider,
    signer,
    isConnected,
    chainId,
    balance,
    contracts,
    connectWallet,
    disconnect,
    switchNetwork,
    addNetwork,
    getContract,
    sendTransaction,
    estimateGas,
  };

  return <Web3Context.Provider value={value}>{children}</Web3Context.Provider>;
};

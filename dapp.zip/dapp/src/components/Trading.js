import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Button, Input, Select, Table, Tag, Space, Modal, Form, Alert, Progress } from 'antd';
import { 
  SwapOutlined, 
  LineChartOutlined, 
  SettingOutlined,
  DollarOutlined,
  TrophyOutlined,
  FireOutlined,
  ThunderboltOutlined
} from '@ant-design/icons';
import { Line, Area } from '@ant-design/plots';
import { useWeb3 } from '../contexts/Web3Context';

const { Option } = Select;
const { TextArea } = Input;

const Trading = () => {
  const { account, isConnected, contracts, getContract, sendTransaction } = useWeb3();
  const [activeTab, setActiveTab] = useState('spot');
  const [marketData, setMarketData] = useState({
    price: 0,
    volume24h: 0,
    change24h: 0,
    high24h: 0,
    low24h: 0,
  });
  const [tradingPairs, setTradingPairs] = useState([]);
  const [selectedPair, setSelectedPair] = useState('ONE/USDC');
  const [orderType, setOrderType] = useState('market');
  const [tradeAmount, setTradeAmount] = useState('');
  const [tradeDirection, setTradeDirection] = useState('buy');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [derivativeType, setDerivativeType] = useState('synthetic_parity');
  const [notional, setNotional] = useState('');
  const [strikePrice, setStrikePrice] = useState('');
  const [maturity, setMaturity] = useState('');

  useEffect(() => {
    fetchMarketData();
    fetchTradingPairs();
  }, []);

  const fetchMarketData = async () => {
    // Mock market data - replace with actual oracle calls
    setMarketData({
      price: 1.25,
      volume24h: 45000000,
      change24h: 2.5,
      high24h: 1.28,
      low24h: 1.22,
    });
  };

  const fetchTradingPairs = async () => {
    // Mock trading pairs
    setTradingPairs([
      { symbol: 'ONE/USDC', price: 1.25, volume: 15000000, change: 2.5 },
      { symbol: 'ONE/ETH', price: 0.00045, volume: 8000000, change: -1.2 },
      { symbol: 'ONE/WBTC', price: 0.000018, volume: 5000000, change: 3.8 },
      { symbol: 'ONE/DAI', price: 1.24, volume: 7000000, change: 2.3 },
    ]);
  };

  const priceData = [
    { time: '00:00', price: 1.22 },
    { time: '04:00', price: 1.23 },
    { time: '08:00', price: 1.25 },
    { time: '12:00', price: 1.27 },
    { time: '16:00', price: 1.26 },
    { time: '20:00', price: 1.25 },
  ];

  const volumeData = [
    { time: '00:00', volume: 1200000 },
    { time: '04:00', volume: 800000 },
    { time: '08:00', volume: 2100000 },
    { time: '12:00', volume: 3500000 },
    { time: '16:00', volume: 2800000 },
    { time: '20:00', volume: 1900000 },
  ];

  const priceConfig = {
    data: priceData,
    xField: 'time',
    yField: 'price',
    smooth: true,
    color: tradeDirection === 'buy' ? '#52c41a' : '#ff4d4f',
    point: {
      size: 3,
      shape: 'circle',
    },
    tooltip: {
      formatter: (data) => ({
        name: 'Price',
        value: `$${data.price.toFixed(4)}`,
      }),
    },
  };

  const volumeConfig = {
    data: volumeData,
    xField: 'time',
    yField: 'volume',
    smooth: true,
    color: '#1890ff',
    areaStyle: {
      fillOpacity: 0.3,
    },
    tooltip: {
      formatter: (data) => ({
        name: 'Volume',
        value: `$${(data.volume / 1e6).toFixed(2)}M`,
      }),
    },
  };

  const orderColumns = [
    {
      title: 'Type',
      dataIndex: 'type',
      key: 'type',
      render: (type) => (
        <Tag color={type === 'Buy' ? 'green' : 'red'}>
          {type}
        </Tag>
      ),
    },
    {
      title: 'Pair',
      dataIndex: 'pair',
      key: 'pair',
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      render: (amount) => `${amount.toFixed(2)} ONE`,
    },
    {
      title: 'Price',
      dataIndex: 'price',
      key: 'price',
      render: (price) => `$${price.toFixed(4)}`,
    },
    {
      title: 'Total',
      dataIndex: 'total',
      key: 'total',
      render: (total) => `$${total.toFixed(2)}`,
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => (
        <Tag color={status === 'Filled' ? 'green' : status === 'Pending' ? 'orange' : 'blue'}>
          {status}
        </Tag>
      ),
    },
  ];

  const derivativeColumns = [
    {
      title: 'Type',
      dataIndex: 'type',
      key: 'type',
      render: (type) => (
        <Tag color="purple">{type.replace('_', ' ').toUpperCase()}</Tag>
      ),
    },
    {
      title: 'Notional',
      dataIndex: 'notional',
      key: 'notional',
      render: (notional) => `$${(notional / 1e6).toFixed(2)}M`,
    },
    {
      title: 'Strike',
      dataIndex: 'strike',
      key: 'strike',
      render: (strike) => `$${strike.toFixed(4)}`,
    },
    {
      title: 'Maturity',
      dataIndex: 'maturity',
      key: 'maturity',
    },
    {
      title: 'P&L',
      dataIndex: 'pnl',
      key: 'pnl',
      render: (pnl) => (
        <span style={{ color: pnl >= 0 ? '#52c41a' : '#ff4d4f' }}>
          ${pnl.toFixed(2)}
        </span>
      ),
    },
  ];

  const handleTrade = async () => {
    if (!isConnected) {
      alert('Please connect your wallet first');
      return;
    }

    if (!tradeAmount) {
      alert('Please enter trade amount');
      return;
    }

    try {
      // Mock trade execution - replace with actual contract calls
      console.log(`Executing ${tradeDirection} order for ${tradeAmount} ${selectedPair}`);
      
      // Show success message
      Modal.success({
        title: 'Trade Executed',
        content: `Successfully executed ${tradeDirection} order for ${tradeAmount} ${selectedPair}`,
      });
      
      // Reset form
      setTradeAmount('');
    } catch (error) {
      console.error('Trade execution error:', error);
      Modal.error({
        title: 'Trade Failed',
        content: error.message,
      });
    }
  };

  const handleCreateDerivative = async () => {
    if (!isConnected) {
      alert('Please connect your wallet first');
      return;
    }

    try {
      // Mock derivative creation - replace with actual contract calls
      console.log(`Creating ${derivativeType} derivative with notional ${notional}`);
      
      setIsModalVisible(false);
      
      Modal.success({
        title: 'Derivative Created',
        content: `Successfully created ${derivativeType} derivative`,
      });
      
      // Reset form
      setNotional('');
      setStrikePrice('');
      setMaturity('');
    } catch (error) {
      console.error('Derivative creation error:', error);
      Modal.error({
        title: 'Derivative Creation Failed',
        content: error.message,
      });
    }
  };

  const mockOrders = [
    { type: 'Buy', pair: 'ONE/USDC', amount: 1000, price: 1.25, total: 1250, status: 'Filled' },
    { type: 'Sell', pair: 'ONE/ETH', amount: 500, price: 0.00045, total: 0.225, status: 'Pending' },
    { type: 'Buy', pair: 'ONE/WBTC', amount: 200, price: 0.000018, total: 0.0036, status: 'Filled' },
  ];

  const mockDerivatives = [
    { type: 'synthetic_parity', notional: 1000000, strike: 1.25, maturity: '2024-12-31', pnl: 25000 },
    { type: 'zero_strike_option', notional: 500000, strike: 1.20, maturity: '2024-06-30', pnl: -5000 },
    { type: 'non_liquidatable_loan', notional: 2000000, strike: 1.30, maturity: '2025-03-15', pnl: 10000 },
  ];

  return (
    <div>
      {/* Market Overview */}
      <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
        <Col xs={24} sm={12} md={6}>
          <Card>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ color: '#666', fontSize: 14 }}>Current Price</div>
                <div style={{ fontSize: 24, fontWeight: 'bold' }}>${marketData.price.toFixed(4)}</div>
              </div>
              <DollarOutlined style={{ fontSize: 24, color: '#1890ff' }} />
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ color: '#666', fontSize: 14 }}>24h Volume</div>
                <div style={{ fontSize: 24, fontWeight: 'bold' }}>${(marketData.volume24h / 1e6).toFixed(2)}M</div>
              </div>
              <LineChartOutlined style={{ fontSize: 24, color: '#52c41a' }} />
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ color: '#666', fontSize: 14 }}>24h Change</div>
                <div style={{ fontSize: 24, fontWeight: 'bold', color: marketData.change24h >= 0 ? '#52c41a' : '#ff4d4f' }}>
                  {marketData.change24h >= 0 ? '+' : ''}{marketData.change24h.toFixed(2)}%
                </div>
              </div>
              <TrophyOutlined style={{ fontSize: 24, color: marketData.change24h >= 0 ? '#52c41a' : '#ff4d4f' }} />
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ color: '#666', fontSize: 14 }}>24h Range</div>
                <div style={{ fontSize: 16, fontWeight: 'bold' }}>
                  ${marketData.low24h.toFixed(4)} - ${marketData.high24h.toFixed(4)}
                </div>
              </div>
              <FireOutlined style={{ fontSize: 24, color: '#fa8c16' }} />
            </div>
          </Card>
        </Col>
      </Row>

      {/* Trading Interface */}
      <Row gutter={[16, 16]}>
        <Col xs={24} lg={16}>
          {/* Price Chart */}
          <Card title="Price Chart" style={{ marginBottom: 16 }}>
            <Line {...priceConfig} />
          </Card>

          {/* Volume Chart */}
          <Card title="Volume Chart">
            <Area {...volumeConfig} />
          </Card>
        </Col>

        <Col xs={24} lg={8}>
          {/* Trading Panel */}
          <Card title="Trading Panel" style={{ marginBottom: 16 }}>
            <Space direction="vertical" style={{ width: '100%' }}>
              {/* Pair Selection */}
              <div>
                <label style={{ display: 'block', marginBottom: 8 }}>Trading Pair</label>
                <Select
                  value={selectedPair}
                  onChange={setSelectedPair}
                  style={{ width: '100%' }}
                >
                  {tradingPairs.map(pair => (
                    <Option key={pair.symbol} value={pair.symbol}>
                      {pair.symbol}
                    </Option>
                  ))}
                </Select>
              </div>

              {/* Order Type */}
              <div>
                <label style={{ display: 'block', marginBottom: 8 }}>Order Type</label>
                <Select
                  value={orderType}
                  onChange={setOrderType}
                  style={{ width: '100%' }}
                >
                  <Option value="market">Market</Option>
                  <Option value="limit">Limit</Option>
                </Select>
              </div>

              {/* Buy/Sell Buttons */}
              <div>
                <label style={{ display: 'block', marginBottom: 8 }}>Direction</label>
                <Button.Group style={{ width: '100%' }}>
                  <Button
                    type={tradeDirection === 'buy' ? 'primary' : 'default'}
                    onClick={() => setTradeDirection('buy')}
                    style={{ width: '50%', backgroundColor: tradeDirection === 'buy' ? '#52c41a' : undefined, borderColor: tradeDirection === 'buy' ? '#52c41a' : undefined }}
                  >
                    Buy
                  </Button>
                  <Button
                    type={tradeDirection === 'sell' ? 'primary' : 'default'}
                    onClick={() => setTradeDirection('sell')}
                    style={{ width: '50%', backgroundColor: tradeDirection === 'sell' ? '#ff4d4f' : undefined, borderColor: tradeDirection === 'sell' ? '#ff4d4f' : undefined }}
                  >
                    Sell
                  </Button>
                </Button.Group>
              </div>

              {/* Amount */}
              <div>
                <label style={{ display: 'block', marginBottom: 8 }}>Amount</label>
                <Input
                  type="number"
                  value={tradeAmount}
                  onChange={(e) => setTradeAmount(e.target.value)}
                  placeholder="Enter amount"
                  suffix="ONE"
                />
              </div>

              {/* Execute Trade */}
              <Button
                type="primary"
                icon={<SwapOutlined />}
                onClick={handleTrade}
                style={{ width: '100%', height: 40 }}
                disabled={!isConnected}
              >
                {isConnected ? `Execute ${tradeDirection.toUpperCase()} Order` : 'Connect Wallet'}
              </Button>
            </Space>
          </Card>

          {/* Create Derivative */}
          <Card title="Create Derivative">
            <Space direction="vertical" style={{ width: '100%' }}>
              <Button
                icon={<ThunderboltOutlined />}
                onClick={() => setIsModalVisible(true)}
                style={{ width: '100%' }}
                disabled={!isConnected}
              >
                Create Custom Derivative
              </Button>
              
              <Button
                icon={<SettingOutlined />}
                style={{ width: '100%' }}
                disabled={!isConnected}
              >
                Advanced Settings
              </Button>
            </Space>
          </Card>
        </Col>
      </Row>

      {/* Orders Table */}
      <Card title="Recent Orders" style={{ marginTop: 24 }}>
        <Table
          columns={orderColumns}
          dataSource={mockOrders}
          pagination={{ pageSize: 5 }}
          size="small"
        />
      </Card>

      {/* Derivatives Table */}
      <Card title="Your Derivatives" style={{ marginTop: 16 }}>
        <Table
          columns={derivativeColumns}
          dataSource={mockDerivatives}
          pagination={{ pageSize: 5 }}
          size="small"
        />
      </Card>

      {/* Derivative Creation Modal */}
      <Modal
        title="Create Custom Derivative"
        visible={isModalVisible}
        onOk={handleCreateDerivative}
        onCancel={() => setIsModalVisible(false)}
        width={600}
      >
        <Form layout="vertical">
          <Form.Item label="Derivative Type">
            <Select value={derivativeType} onChange={setDerivativeType}>
              <Option value="synthetic_parity">Synthetic Parity Swap</Option>
              <Option value="zero_strike_option">Zero-Strike Option</Option>
              <Option value="non_liquidatable_loan">Non-Liquidatable Loan</Option>
              <Option value="nature_risk_hedge">Nature Risk Hedge</Option>
            </Select>
          </Form.Item>
          
          <Form.Item label="Notional Amount (USD)">
            <Input
              type="number"
              value={notional}
              onChange={(e) => setNotional(e.target.value)}
              placeholder="Enter notional amount"
              prefix="$"
            />
          </Form.Item>
          
          <Form.Item label="Strike Price">
            <Input
              type="number"
              value={strikePrice}
              onChange={(e) => setStrikePrice(e.target.value)}
              placeholder="Enter strike price"
              prefix="$"
            />
          </Form.Item>
          
          <Form.Item label="Maturity Date">
            <Input
              type="date"
              value={maturity}
              onChange={(e) => setMaturity(e.target.value)}
            />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default Trading;

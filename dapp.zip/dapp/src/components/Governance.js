import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Button, Input, Select, Table, Tag, Space, Modal, Form, Alert, Progress, Badge, Tooltip, Tabs } from 'antd';
import { 
  CrownOutlined, 
  GiftOutlined, 
  StarOutlined, 
  ThunderboltOutlined,
  HeartOutlined,
  EyeOutlined,
  TeamOutlined,
  GlobalOutlined,
  EnvironmentOutlined,
  TrophyOutlined,
  SafetyOutlined,
  FlagOutlined,
  SkullOutlined,
  EyeInvisibleOutlined,
  UserOutlined,
  BankOutlined,
  HomeOutlined,
  RocketOutlined
} from '@ant-design/icons';
import { Line, Pie, Column } from '@ant-design/plots';
import { useWeb3 } from '../contexts/Web3Context';

const { Option } = Select;
const { TextArea } = Input;
const { TabPane } = Tabs;

const Governance = () => {
  const { account, isConnected, contracts, getContract } = useWeb3();
  const [isRegistered, setIsRegistered] = useState(false);
  const [childOrgs, setChildOrgs] = useState([]);
  const [bounties, setBounties] = useState([]);
  const [tributeData, setTributeData] = useState({
    localPool: 0,
    regionalPool: 0,
    globalPool: 0,
    lotteryPool: 0,
    publicServicePool: 0,
    kingdomTribute: 0
  });
  const [goldenRatio, setGoldenRatio] = useState(1.618033988749895);
  const [governanceAlignment, setGovernanceAlignment] = useState(100);
  const [userTransactions, setUserTransactions] = useState([]);
  const [allocationSettings, setAllocationSettings] = useState({
    localPercentage: 66.7,
    regionalPercentage: 66.7,
    globalPercentage: 66.7
  });

  const organizationTypes = [
    { value: 0, label: 'Individual', icon: <UserOutlined /> },
    { value: 1, label: 'Institution', icon: <BankOutlined /> },
    { value: 2, label: 'Government', icon: <HomeOutlined /> },
    { value: 3, label: 'Church', icon: <HeartOutlined /> },
    { value: 4, label: 'Corporation', icon: <RocketOutlined /> },
    { value: 5, label: 'Nonprofit', icon: <GiftOutlined /> },
    { value: 6, label: 'Cooperative', icon: <TeamOutlined /> },
    { value: 7, label: 'Ministry', icon: <CrownOutlined /> },
    { value: 8, label: 'Privateer', icon: <SkullOutlined /> },
    { value: 9, label: 'Sovereign Nation', icon: <FlagOutlined /> }
  ];

  const bountyTypes = [
    { value: 0, label: 'White Hat', color: 'green', description: 'Constructive, build something' },
    { value: 1, label: 'Black Hat', color: 'red', description: 'Justice, find truth, poetic justice' },
    { value: 2, label: 'Clear Hat', color: 'blue', description: 'Neutral, maintenance' },
    { value: 3, label: 'Pirate', color: 'purple', description: 'Security testing, vulnerability discovery' }
  ];

  const capitalForms = [
    { value: 0, label: 'Financial' },
    { value: 1, label: 'Material' },
    { value: 2, label: 'Living' },
    { value: 3, label: 'Social' },
    { value: 4, label: 'Intellectual' },
    { value: 5, label: 'Experiential' },
    { value: 6, label: 'Spiritual' },
    { value: 7, label: 'Cultural' },
    { value: 8, label: 'Political' }
  ];

  useEffect(() => {
    fetchGovernanceData();
  }, []);

  const fetchGovernanceData = async () => {
    // Mock data - replace with actual contract calls
    setChildOrgs([
      {
        address: '0x1234...5678',
        name: 'New California Ministry',
        type: 7,
        jurisdiction: 'New California Republic',
        members: 150,
        governancePower: 150000,
        registrationTime: '2024-01-15'
      },
      {
        address: '0x5678...9012',
        name: 'Sicilian Crown Treasury',
        type: 4,
        jurisdiction: 'Global',
        members: 50,
        governancePower: 50000,
        registrationTime: '2024-01-10'
      }
    ]);

    setBounties([
      {
        id: '0xabc123',
        type: 0,
        capitalForm: 0,
        description: 'Build sustainable water purification system',
        reward: 50000,
        stars: 4,
        deadline: '2024-12-31',
        poster: '0xdef456',
        claimants: ['0x789abc'],
        status: 'active'
      },
      {
        id: '0xdef456',
        type: 3,
        capitalForm: 4,
        description: 'Find and patch critical security vulnerability',
        reward: 100000,
        stars: 5,
        deadline: '2024-06-30',
        poster: '0x123456',
        claimants: [],
        status: 'active'
      }
    ]);

    setTributeData({
      localPool: 2500000,
      regionalPool: 1800000,
      globalPool: 3200000,
      lotteryPool: 150000,
      publicServicePool: 75000,
      kingdomTribute: 1125000
    });

    setUserTransactions([
      {
        user: account,
        amount: 1000,
        timestamp: '2024-01-20 14:30:00',
        blockNumber: 18500000,
        wonLottery: true,
        lotteryAmount: 500,
        childOrganization: 'New California Ministry'
      }
    ]);
  };

  const tributeDistributionData = [
    { category: 'Local (11%)', value: 11 },
    { category: 'Regional (11%)', value: 11 },
    { category: 'Global (11%)', value: 11 },
    { category: 'Goods (66%)', value: 66 },
    { category: 'Lottery (1%)', value: 1 }
  ];

  const tributeConfig = {
    data: tributeDistributionData,
    angleField: 'value',
    colorField: 'category',
    radius: 0.8,
    label: {
      type: 'outer',
      content: '{name} {value}%',
    },
    interactions: [{ type: 'pie-legend-active' }, { type: 'element-active' }],
  };

  const goldenRatioData = [
    { time: '00:00', ratio: 1.6180 },
    { time: '04:00', ratio: 1.6181 },
    { time: '08:00', ratio: 1.6182 },
    { time: '12:00', ratio: 1.6180 },
    { time: '16:00', ratio: 1.6183 },
    { time: '20:00', ratio: 1.6181 },
  ];

  const goldenRatioConfig = {
    data: goldenRatioData,
    xField: 'time',
    yField: 'ratio',
    smooth: true,
    color: '#1890ff',
    point: {
      size: 3,
      shape: 'circle',
    },
    tooltip: {
      formatter: (data) => ({
        name: 'Golden Ratio',
        value: data.ratio.toFixed(6),
      }),
    },
  };

  const orgColumns = [
    {
      title: 'Organization',
      dataIndex: 'name',
      key: 'name',
      render: (name, record) => (
        <Space>
          {organizationTypes[record.type]?.icon}
          <span>{name}</span>
        </Space>
      ),
    },
    {
      title: 'Type',
      dataIndex: 'type',
      key: 'type',
      render: (type) => organizationTypes[type]?.label || 'Unknown',
    },
    {
      title: 'Jurisdiction',
      dataIndex: 'jurisdiction',
      key: 'jurisdiction',
    },
    {
      title: 'Members',
      dataIndex: 'members',
      key: 'members',
    },
    {
      title: 'Governance Power',
      dataIndex: 'governancePower',
      key: 'governancePower',
      render: (power) => power.toLocaleString(),
    },
    {
      title: 'Registration',
      dataIndex: 'registrationTime',
      key: 'registrationTime',
    },
  ];

  const bountyColumns = [
    {
      title: 'Type',
      dataIndex: 'type',
      key: 'type',
      render: (type) => {
        const bountyType = bountyTypes[type];
        return (
          <Tag color={bountyType?.color}>
            {bountyType?.label}
          </Tag>
        );
      },
    },
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'description',
      ellipsis: true,
    },
    {
      title: 'Reward',
      dataIndex: 'reward',
      key: 'reward',
      render: (reward) => `$${(reward / 1000).toFixed(1)}K`,
    },
    {
      title: 'Stars',
      dataIndex: 'stars',
      key: 'stars',
      render: (stars) => (
        <Space>
          {[...Array(5)].map((_, i) => (
            <StarOutlined key={i} style={{ color: i < stars ? '#faad14' : '#d9d9d9' }} />
          ))}
        </Space>
      ),
    },
    {
      title: 'Deadline',
      dataIndex: 'deadline',
      key: 'deadline',
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => (
        <Badge status={status === 'active' ? 'success' : 'default'} text={status} />
      ),
    },
    {
      title: 'Action',
      key: 'action',
      render: (_, record) => (
        <Space>
          <Button size="small" icon={<EyeOutlined />}>
            View
          </Button>
          {record.status === 'active' && (
            <Button size="small" type="primary" icon={<ThunderboltOutlined />}>
              Claim
            </Button>
          )}
        </Space>
      ),
    },
  ];

  const transactionColumns = [
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      render: (amount) => `${amount} VINO`,
    },
    {
      title: 'Block',
      dataIndex: 'blockNumber',
      key: 'blockNumber',
    },
    {
      title: 'Time',
      dataIndex: 'timestamp',
      key: 'timestamp',
    },
    {
      title: 'Lottery',
      dataIndex: 'wonLottery',
      key: 'wonLottery',
      render: (won, record) => (
        won ? (
          <Tag color="gold">
            <TrophyOutlined /> Won ${(record.lotteryAmount / 1000).toFixed(1)}K
          </Tag>
        ) : (
          <Tag color="default">No</Tag>
        )
      ),
    },
    {
      title: 'Organization',
      dataIndex: 'childOrganization',
      key: 'childOrganization',
    },
  ];

  const handleRegisterOrg = async (values) => {
    if (!isConnected) {
      alert('Please connect your wallet first');
      return;
    }

    try {
      console.log('Registering organization:', values);
      // Mock registration - replace with actual contract call
      setIsRegistered(true);
      Modal.success({
        title: 'Organization Registered',
        content: `Successfully registered ${values.name} as a child organization`,
      });
    } catch (error) {
      console.error('Registration error:', error);
      Modal.error({
        title: 'Registration Failed',
        content: error.message,
      });
    }
  };

  const handlePostBounty = async (values) => {
    if (!isConnected) {
      alert('Please connect your wallet first');
      return;
    }

    try {
      console.log('Posting bounty:', values);
      // Mock bounty posting - replace with actual contract call
      Modal.success({
        title: 'Bounty Posted',
        content: `Successfully posted bounty with reward $${(values.reward / 1000).toFixed(1)}K`,
      });
    } catch (error) {
      console.error('Bounty posting error:', error);
      Modal.error({
        title: 'Bounty Posting Failed',
        content: error.message,
      });
    }
  };

  return (
    <div>
      {/* Golden Ratio Alignment */}
      <Alert
        message="Golden Ratio Governance Alignment"
        description={
          <Space>
            <span>Current Ratio: {goldenRatio.toFixed(6)}</span>
            <span>Target: 1.618034</span>
            <span>Alignment: {governanceAlignment}%</span>
            <Progress 
              percent={governanceAlignment} 
              size="small" 
              status={governanceAlignment >= 95 ? "success" : "active"}
              style={{ width: 200 }}
            />
          </Space>
        }
        type={governanceAlignment >= 95 ? "success" : "info"}
        showIcon
        style={{ marginBottom: 24 }}
      />

      <Tabs defaultActiveKey="overview">
        <TabPane tab="Overview" key="overview">
          <Row gutter={[16, 16]}>
            {/* Tribute Pools */}
            <Col xs={24} lg={12}>
              <Card title="Tribute Distribution" extra={<Button type="link">View Details</Button>}>
                <Pie {...tributeConfig} />
                <Row gutter={[8, 8]} style={{ marginTop: 16 }}>
                  <Col span={12}>
                    <Statistic
                      title="Local Pool"
                      value={tributeData.localPool}
                      prefix={<EnvironmentOutlined />}
                      formatter={(value) => `$${(value / 1e6).toFixed(2)}M`}
                    />
                  </Col>
                  <Col span={12}>
                    <Statistic
                      title="Regional Pool"
                      value={tributeData.regionalPool}
                      prefix={<GlobalOutlined />}
                      formatter={(value) => `$${(value / 1e6).toFixed(2)}M`}
                    />
                  </Col>
                  <Col span={12}>
                    <Statistic
                      title="Global Pool"
                      value={tributeData.globalPool}
                      prefix={<RocketOutlined />}
                      formatter={(value) => `$${(value / 1e6).toFixed(2)}M`}
                    />
                  </Col>
                  <Col span={12}>
                    <Statistic
                      title="Lottery Pool"
                      value={tributeData.lotteryPool}
                      prefix={<TrophyOutlined />}
                      formatter={(value) => `$${(value / 1e3).toFixed(0)}K`}
                    />
                  </Col>
                </Row>
              </Card>
            </Col>

            {/* Golden Ratio Chart */}
            <Col xs={24} lg={12}>
              <Card title="Golden Ratio Alignment" extra={<Button type="link">Analytics</Button>}>
                <Line {...goldenRatioConfig} />
                <div style={{ marginTop: 16, textAlign: 'center' }}>
                  <Space direction="vertical">
                    <div>
                      <strong>Kingdom Tribute:</strong> ${(tributeData.kingdomTribute / 1e6).toFixed(2)}M
                    </div>
                    <div>
                      <strong>Public Service Pool:</strong> ${(tributeData.publicServicePool / 1e3).toFixed(0)}K
                    </div>
                    <div>
                      <strong>Governance Alignment:</strong> {governanceAlignment}%
                    </div>
                  </Space>
                </div>
              </Card>
            </Col>
          </Row>
        </TabPane>

        <TabPane tab="Child Organizations" key="organizations">
          <Row gutter={[16, 16]}>
            <Col xs={24} lg={16}>
              <Card title="Registered Child Organizations">
                <Table
                  columns={orgColumns}
                  dataSource={childOrgs}
                  pagination={{ pageSize: 5 }}
                  size="small"
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="Register Organization">
                <Form onFinish={handleRegisterOrg} layout="vertical">
                  <Form.Item name="name" label="Organization Name" rules={[{ required: true }]}>
                    <Input placeholder="Enter organization name" />
                  </Form.Item>
                  <Form.Item name="type" label="Organization Type" rules={[{ required: true }]}>
                    <Select placeholder="Select organization type">
                      {organizationTypes.map(type => (
                        <Option key={type.value} value={type.value}>
                          <Space>
                            {type.icon}
                            {type.label}
                          </Space>
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                  <Form.Item name="jurisdiction" label="Jurisdiction" rules={[{ required: true }]}>
                    <Input placeholder="Enter jurisdiction" />
                  </Form.Item>
                  <Form.Item>
                    <Button type="primary" htmlType="submit" disabled={!isConnected}>
                      Register Organization
                    </Button>
                  </Form.Item>
                </Form>
              </Card>
            </Col>
          </Row>
        </TabPane>

        <TabPane tab="Bounty Board" key="bounties">
          <Row gutter={[16, 16]}>
            <Col xs={24} lg={16}>
              <Card title="Active Bounties">
                <Table
                  columns={bountyColumns}
                  dataSource={bounties}
                  pagination={{ pageSize: 5 }}
                  size="small"
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="Post Bounty">
                <Form onFinish={handlePostBounty} layout="vertical">
                  <Form.Item name="type" label="Bounty Type" rules={[{ required: true }]}>
                    <Select placeholder="Select bounty type">
                      {bountyTypes.map(type => (
                        <Option key={type.value} value={type.value}>
                          <Space>
                            <Tag color={type.color}>{type.label}</Tag>
                            <span style={{ fontSize: 12 }}>{type.description}</span>
                          </Space>
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                  <Form.Item name="capitalForm" label="Capital Form" rules={[{ required: true }]}>
                    <Select placeholder="Select capital form">
                      {capitalForms.map(form => (
                        <Option key={form.value} value={form.value}>
                          {form.label}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                  <Form.Item name="description" label="Description" rules={[{ required: true }]}>
                    <TextArea rows={3} placeholder="Describe the bounty requirements" />
                  </Form.Item>
                  <Form.Item name="reward" label="Reward Amount (VINO)" rules={[{ required: true }]}>
                    <Input type="number" placeholder="Enter reward amount" />
                  </Form.Item>
                  <Form.Item name="stars" label="Difficulty Rating" rules={[{ required: true }]}>
                    <Select placeholder="Select star rating">
                      {[1, 2, 3, 4, 5].map(star => (
                        <Option key={star} value={star}>
                          <Space>
                            {[...Array(5)].map((_, i) => (
                              <StarOutlined key={i} style={{ color: i < star ? '#faad14' : '#d9d9d9' }} />
                            ))}
                            <span>{star} Stars</span>
                          </Space>
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                  <Form.Item name="deadline" label="Deadline" rules={[{ required: true }]}>
                    <Input type="date" />
                  </Form.Item>
                  <Form.Item>
                    <Button type="primary" htmlType="submit" disabled={!isConnected}>
                      Post Bounty
                    </Button>
                  </Form.Item>
                </Form>
              </Card>
            </Col>
          </Row>
        </TabPane>

        <TabPane tab="My Transactions" key="transactions">
          <Card title="Transaction History">
            <Table
              columns={transactionColumns}
              dataSource={userTransactions}
              pagination={{ pageSize: 10 }}
              size="small"
            />
          </Card>
        </TabPane>

        <TabPane tab="Tribute Allocation" key="allocation">
          <Card title="Tribute Allocation Settings">
            <Alert
              message="Allocation Rules"
              description="You must control at least 66.7% (2/3) of your tribute allocation power. The remaining 33.3% can be controlled by your child organization."
              type="info"
              showIcon
              style={{ marginBottom: 24 }}
            />
            
            <Row gutter={[16, 16]}>
              <Col xs={24} md={8}>
                <Card size="small">
                  <Statistic
                    title="Local Tribute"
                    value={allocationSettings.localPercentage}
                    suffix="%"
                    prefix={<EnvironmentOutlined />}
                  />
                  <Progress 
                    percent={allocationSettings.localPercentage} 
                    size="small" 
                    style={{ marginTop: 8 }}
                  />
                </Card>
              </Col>
              <Col xs={24} md={8}>
                <Card size="small">
                  <Statistic
                    title="Regional Tribute"
                    value={allocationSettings.regionalPercentage}
                    suffix="%"
                    prefix={<GlobalOutlined />}
                  />
                  <Progress 
                    percent={allocationSettings.regionalPercentage} 
                    size="small" 
                    style={{ marginTop: 8 }}
                  />
                </Card>
              </Col>
              <Col xs={24} md={8}>
                <Card size="small">
                  <Statistic
                    title="Global Tribute"
                    value={allocationSettings.globalPercentage}
                    suffix="%"
                    prefix={<RocketOutlined />}
                  />
                  <Progress 
                    percent={allocationSettings.globalPercentage} 
                    size="small" 
                    style={{ marginTop: 8 }}
                  />
                </Card>
              </Col>
            </Row>
          </Card>
        </TabPane>
      </Tabs>
    </div>
  );
};

export default Governance;

import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Statistic, Progress, Alert, Button, Space, Table, Tag } from 'antd';
import { 
  DollarOutlined, 
  BankOutlined, 
  LineChartOutlined, 
  TrophyOutlined,
  GlobalOutlined,
  SafetyOutlined,
  RocketOutlined,
  HeartOutlined
} from '@ant-design/icons';
import { Line, Pie, Area } from '@ant-design/plots';
import { useWeb3 } from '../contexts/Web3Context';

const Dashboard = () => {
  const { account, isConnected, connectWallet } = useWeb3();
  const [daoStats, setDaoStats] = useState({
    totalValueLocked: 0,
    reserveSupply: 0,
    backingRatio: 0,
    dailyVolume: 0,
    activeUsers: 0,
    governanceAPR: 0
  });
  
  const [marketData, setMarketData] = useState({
    gasPrice: 0,
    liquidity: 0,
    volatility: 0,
    isOptimal: false
  });

  const [recentTransactions, setRecentTransactions] = useState([]);

  useEffect(() => {
    // Fetch DAO statistics
    const fetchStats = async () => {
      // Mock data - replace with actual contract calls
      setDaoStats({
        totalValueLocked: 1250000000,
        reserveSupply: 1000000000,
        backingRatio: 125,
        dailyVolume: 45000000,
        activeUsers: 8750,
        governanceAPR: 8.5
      });
    };

    fetchStats();
  }, []);

  const tvlData = [
    { date: '2024-01', value: 800000000 },
    { date: '2024-02', value: 950000000 },
    { date: '2024-03', value: 1100000000 },
    { date: '2024-04', value: 1250000000 },
  ];

  const assetAllocation = [
    { type: 'ETH', value: 45 },
    { type: 'USDC', value: 25 },
    { type: 'WBTC', value: 20 },
    { type: 'Other', value: 10 },
  ];

  const volumeData = [
    { time: '00:00', volume: 1200000 },
    { time: '04:00', volume: 800000 },
    { time: '08:00', volume: 2100000 },
    { time: '12:00', volume: 3500000 },
    { time: '16:00', volume: 2800000 },
    { time: '20:00', volume: 1900000 },
  ];

  const transactionColumns = [
    {
      title: 'Type',
      dataIndex: 'type',
      key: 'type',
      render: (type) => (
        <Tag color={type === 'Mint' ? 'green' : type === 'Trade' ? 'blue' : 'orange'}>
          {type}
        </Tag>
      ),
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      render: (amount) => `$${(amount / 1e6).toFixed(2)}M`,
    },
    {
      title: 'User',
      dataIndex: 'user',
      key: 'user',
      render: (user) => `${user.slice(0, 6)}...${user.slice(-4)}`,
    },
    {
      title: 'Time',
      dataIndex: 'time',
      key: 'time',
    },
  ];

  const tvlConfig = {
    data: tvlData,
    xField: 'date',
    yField: 'value',
    smooth: true,
    color: '#1890ff',
    point: {
      size: 3,
      shape: 'circle',
    },
    tooltip: {
      formatter: (data) => ({
        name: 'TVL',
        value: `$${(data.value / 1e9).toFixed(2)}B`,
      }),
    },
  };

  const allocationConfig = {
    data: assetAllocation,
    angleField: 'value',
    colorField: 'type',
    radius: 0.8,
    label: {
      type: 'outer',
      content: '{name} {percentage}',
    },
    interactions: [{ type: 'pie-legend-active' }, { type: 'element-active' }],
  };

  const volumeConfig = {
    data: volumeData,
    xField: 'time',
    yField: 'volume',
    smooth: true,
    color: '#52c41a',
    areaStyle: {
      fillOpacity: 0.3,
    },
    tooltip: {
      formatter: (data) => ({
        name: 'Volume',
        value: `$${(data.volume / 1e6).toFixed(2)}M`,
      }),
    },
  };

  return (
    <div>
      {/* Market Conditions Alert */}
      <Alert
        message="Market Conditions"
        description={
          <Space>
            <span>Gas: {marketData.gasPrice} gwei</span>
            <span>Liquidity: ${(marketData.liquidity / 1e9).toFixed(2)}B</span>
            <span>Volatility: {marketData.volatility}%</span>
            <Tag color={marketData.isOptimal ? 'green' : 'orange'}>
              {marketData.isOptimal ? 'Optimal' : 'Suboptimal'}
            </Tag>
          </Space>
        }
        type={marketData.isOptimal ? 'success' : 'warning'}
        showIcon
        style={{ marginBottom: 24 }}
      />

      {/* Key Statistics */}
      <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
        <Col xs={24} sm={12} md={8} lg={6}>
          <Card>
            <Statistic
              title="Total Value Locked"
              value={daoStats.totalValueLocked}
              prefix={<DollarOutlined />}
              formatter={(value) => `$${(value / 1e9).toFixed(2)}B`}
              valueStyle={{ color: '#3f8600' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8} lg={6}>
          <Card>
            <Statistic
              title="Reserve Supply"
              value={daoStats.reserveSupply}
              prefix={<BankOutlined />}
              formatter={(value) => `${(value / 1e9).toFixed(2)}B ONE`}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8} lg={6}>
          <Card>
            <Statistic
              title="Backing Ratio"
              value={daoStats.backingRatio}
              suffix="%"
              prefix={<SafetyOutlined />}
              valueStyle={{ color: daoStats.backingRatio >= 100 ? '#3f8600' : '#cf1322' }}
            />
            <Progress 
              percent={daoStats.backingRatio} 
              size="small" 
              status={daoStats.backingRatio >= 100 ? "success" : "exception"}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8} lg={6}>
          <Card>
            <Statistic
              title="Daily Volume"
              value={daoStats.dailyVolume}
              prefix={<LineChartOutlined />}
              formatter={(value) => `$${(value / 1e6).toFixed(2)}M`}
              valueStyle={{ color: '#722ed1' }}
            />
          </Card>
        </Col>
      </Row>

      {/* Charts */}
      <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
        <Col xs={24} lg={12}>
          <Card title="Total Value Locked" extra={<Button type="link">View All</Button>}>
            <Line {...tvlConfig} />
          </Card>
        </Col>
        <Col xs={24} lg={12}>
          <Card title="Asset Allocation" extra={<Button type="link">Rebalance</Button>}>
            <Pie {...allocationConfig} />
          </Card>
        </Col>
      </Row>

      <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
        <Col xs={24} lg={16}>
          <Card title="24h Trading Volume" extra={<Button type="link">Analytics</Button>}>
            <Area {...volumeConfig} />
          </Card>
        </Col>
        <Col xs={24} lg={8}>
          <Row gutter={[16, 16]}>
            <Col span={24}>
              <Card>
                <Statistic
                  title="Active Users"
                  value={daoStats.activeUsers}
                  prefix={<GlobalOutlined />}
                  valueStyle={{ color: '#13c2c2' }}
                />
              </Card>
            </Col>
            <Col span={24}>
              <Card>
                <Statistic
                  title="Governance APR"
                  value={daoStats.governanceAPR}
                  suffix="%"
                  prefix={<TrophyOutlined />}
                  valueStyle={{ color: '#fa8c16' }}
                />
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>

      {/* Recent Transactions */}
      <Card title="Recent Transactions" extra={<Button type="link">View All</Button>}>
        <Table
          columns={transactionColumns}
          dataSource={recentTransactions}
          pagination={{ pageSize: 5 }}
          size="small"
        />
      </Card>

      {/* Quick Actions */}
      {!isConnected && (
        <Card style={{ marginTop: 24, textAlign: 'center' }}>
          <Space direction="vertical" size="large">
            <RocketOutlined style={{ fontSize: 48, color: '#1890ff' }} />
            <div>
              <h3>Connect Your Wallet</h3>
              <p>Join the Universal Reserve DAO and access all financial services</p>
            </div>
            <Button type="primary" size="large" onClick={connectWallet}>
              Connect Wallet
            </Button>
          </Space>
        </Card>
      )}
    </div>
  );
};

export default Dashboard;

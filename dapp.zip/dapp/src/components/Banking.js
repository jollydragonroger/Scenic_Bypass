import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Button, Input, Select, Table, Tag, Space, Modal, Form, Alert, Progress, Tabs, Statistic, Badge } from 'antd';
import { 
  BankOutlined, 
  DollarOutlined, 
  HomeOutlined, 
  LeafOutlined, 
  TeamOutlined, 
  BookOutlined, 
  ThunderboltOutlined, 
  HeartOutlined, 
  CrownOutlined, 
  FlagOutlined,
  LineChartOutlined,
  SafetyOutlined,
  GiftOutlined,
  TrophyOutlined,
  RocketOutlined,
  ShieldOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined
} from '@ant-design/icons';
import { Pie, Column, Area } from '@ant-design/plots';
import { useWeb3 } from '../contexts/Web3Context';

const { Option } = Select;
const { TabPane } = Tabs;

const Banking = () => {
  const { account, isConnected, contracts, getContract } = useWeb3();
  const [activeTab, setActiveTab] = useState('overview');
  const [capitalBalances, setCapitalBalances] = useState({
    financial: 0,
    material: 0,
    living: 0,
    social: 0,
    intellectual: 0,
    experiential: 0,
    spiritual: 0,
    cultural: 0,
    political: 0
  });
  const [loans, setLoans] = useState([]);
  const [yieldFarming, setYieldFarming] = useState([]);
  const [stakingPositions, setStakingPositions] = useState([]);
  const [crossChainAssets, setCrossChainAssets] = useState([]);

  // Nine forms of capital configuration
  const capitalForms = [
    { key: 'financial', name: 'Financial', icon: <DollarOutlined />, color: '#52c41a', description: 'Money, investments, currencies' },
    { key: 'material', name: 'Material', icon: <HomeOutlined />, color: '#1890ff', description: 'Physical assets, resources, infrastructure' },
    { key: 'living', name: 'Living', icon: <LeafOutlined />, color: '#52c41a', description: 'Natural resources, ecosystems, biodiversity' },
    { key: 'social', name: 'Social', icon: <TeamOutlined />, color: '#fa8c16', description: 'Relationships, communities, networks' },
    { key: 'intellectual', name: 'Intellectual', icon: <BookOutlined />, color: '#722ed1', description: 'Knowledge, intellectual property, education' },
    { key: 'experiential', name: 'Experiential', icon: <ThunderboltOutlined />, color: '#eb2f96', description: 'Skills, experiences, expertise' },
    { key: 'spiritual', name: 'Spiritual', icon: <HeartOutlined />, color: '#13c2c2', description: 'Faith, values, meaning, purpose' },
    { key: 'cultural', name: 'Cultural', icon: <CrownOutlined />, color: '#faad14', description: 'Arts, traditions, heritage, creativity' },
    { key: 'political', name: 'Political', icon: <FlagOutlined />, color: '#f5222d', description: 'Power, influence, organization, governance' }
  ];

  useEffect(() => {
    fetchBankingData();
  }, []);

  const fetchBankingData = async () => {
    // Mock data - replace with actual contract calls
    setCapitalBalances({
      financial: 125000,
      material: 85000,
      living: 45000,
      social: 67000,
      intellectual: 92000,
      experiential: 38000,
      spiritual: 56000,
      cultural: 71000,
      political: 43000
    });

    setLoans([
      {
        id: 'loan_001',
        type: 'non_liquidatable',
        amount: 50000,
        collateral: 75000,
        apr: 3.5,
        term: 12,
        status: 'active',
        nextPayment: '2024-02-15',
        remaining: 42000
      },
      {
        id: 'loan_002',
        type: 'sustainable_infrastructure',
        amount: 100000,
        collateral: 150000,
        apr: 2.8,
        term: 24,
        status: 'active',
        nextPayment: '2024-02-01',
        remaining: 87000
      }
    ]);

    setYieldFarming([
      {
        pool: 'ONE/USDC',
        deposited: 25000,
        apr: 8.5,
        rewards: 1250,
        lockPeriod: 30,
        canWithdraw: true
      },
      {
        pool: 'ONE/ETH',
        deposited: 15000,
        apr: 12.3,
        rewards: 1845,
        lockPeriod: 60,
        canWithdraw: false
      }
    ]);

    setStakingPositions([
      {
        asset: 'VINO',
        amount: 100000,
        apr: 6.5,
        rewards: 6500,
        lockPeriod: 90,
        votingPower: 100000
      }
    ]);

    setCrossChainAssets([
      {
        chain: 'Polygon',
        asset: 'ONE',
        amount: 25000,
        value: 31250,
        bridge: 'LayerZero'
      },
      {
        chain: 'Arbitrum',
        asset: 'USDC',
        amount: 50000,
        value: 50000,
        bridge: 'Wormhole'
      }
    ]);
  };

  const capitalDistributionData = capitalForms.map(capital => ({
    type: capital.name,
    value: capitalBalances[capital.key],
    color: capital.color
  }));

  const capitalConfig = {
    data: capitalDistributionData,
    angleField: 'value',
    colorField: 'type',
    radius: 0.8,
    label: {
      type: 'outer',
      content: '{name} {percentage}',
    },
    color: capitalForms.map(capital => capital.color),
    interactions: [{ type: 'pie-legend-active' }, { type: 'element-active' }],
  };

  const yieldData = [
    { month: 'Jan', yield: 6.5 },
    { month: 'Feb', yield: 7.2 },
    { month: 'Mar', yield: 8.1 },
    { month: 'Apr', yield: 8.5 },
    { month: 'May', yield: 9.2 },
    { month: 'Jun', yield: 8.8 },
  ];

  const yieldConfig = {
    data: yieldData,
    xField: 'month',
    yField: 'yield',
    smooth: true,
    color: '#52c41a',
    areaStyle: {
      fillOpacity: 0.3,
    },
    tooltip: {
      formatter: (data) => ({
        name: 'APY',
        value: `${data.yield}%`,
      }),
    },
  };

  const loanColumns = [
    {
      title: 'Loan ID',
      dataIndex: 'id',
      key: 'id',
    },
    {
      title: 'Type',
      dataIndex: 'type',
      key: 'type',
      render: (type) => (
        <Tag color={type === 'non_liquidatable' ? 'green' : 'blue'}>
          {type.replace('_', ' ').toUpperCase()}
        </Tag>
      ),
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      render: (amount) => `$${(amount / 1000).toFixed(1)}K`,
    },
    {
      title: 'Collateral',
      dataIndex: 'collateral',
      key: 'collateral',
      render: (collateral) => `$${(collateral / 1000).toFixed(1)}K`,
    },
    {
      title: 'APR',
      dataIndex: 'apr',
      key: 'apr',
      render: (apr) => `${apr}%`,
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => (
        <Badge status={status === 'active' ? 'success' : 'default'} text={status} />
      ),
    },
    {
      title: 'Next Payment',
      dataIndex: 'nextPayment',
      key: 'nextPayment',
    },
    {
      title: 'Action',
      key: 'action',
      render: (_, record) => (
        <Space>
          <Button size="small" icon={<DollarOutlined />}>
            Pay
          </Button>
          <Button size="small" icon={<LineChartOutlined />}>
            Details
          </Button>
        </Space>
      ),
    },
  ];

  const yieldColumns = [
    {
      title: 'Pool',
      dataIndex: 'pool',
      key: 'pool',
    },
    {
      title: 'Deposited',
      dataIndex: 'deposited',
      key: 'deposited',
      render: (deposited) => `$${(deposited / 1000).toFixed(1)}K`,
    },
    {
      title: 'APR',
      dataIndex: 'apr',
      key: 'apr',
      render: (apr) => `${apr}%`,
    },
    {
      title: 'Rewards',
      dataIndex: 'rewards',
      key: 'rewards',
      render: (rewards) => `$${(rewards / 1000).toFixed(1)}K`,
    },
    {
      title: 'Lock Period',
      dataIndex: 'lockPeriod',
      key: 'lockPeriod',
      render: (days) => `${days} days`,
    },
    {
      title: 'Status',
      dataIndex: 'canWithdraw',
      key: 'canWithdraw',
      render: (canWithdraw) => (
        <Badge status={canWithdraw ? 'success' : 'processing'} text={canWithdraw ? 'Withdrawable' : 'Locked'} />
      ),
    },
    {
      title: 'Action',
      key: 'action',
      render: (_, record) => (
        <Space>
          <Button size="small" type="primary" disabled={!record.canWithdraw}>
            Withdraw
          </Button>
          <Button size="small">
            Compound
          </Button>
        </Space>
      ),
    },
  ];

  const crossChainColumns = [
    {
      title: 'Chain',
      dataIndex: 'chain',
      key: 'chain',
    },
    {
      title: 'Asset',
      dataIndex: 'asset',
      key: 'asset',
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
    },
    {
      title: 'Value',
      dataIndex: 'value',
      key: 'value',
      render: (value) => `$${(value / 1000).toFixed(1)}K`,
    },
    {
      title: 'Bridge',
      dataIndex: 'bridge',
      key: 'bridge',
    },
    {
      title: 'Action',
      key: 'action',
      render: () => (
        <Space>
          <Button size="small" icon={<RocketOutlined />}>
            Bridge
          </Button>
        </Space>
      ),
    },
  ];

  const handleApplyForLoan = async (values) => {
    if (!isConnected) {
      alert('Please connect your wallet first');
      return;
    }

    try {
      console.log('Applying for loan:', values);
      // Mock loan application - replace with actual contract call
      Modal.success({
        title: 'Loan Application Submitted',
        content: `Your loan application for $${(values.amount / 1000).toFixed(1)}K has been submitted`,
      });
    } catch (error) {
      console.error('Loan application error:', error);
      Modal.error({
        title: 'Application Failed',
        content: error.message,
      });
    }
  };

  const handleStake = async (values) => {
    if (!isConnected) {
      alert('Please connect your wallet first');
      return;
    }

    try {
      console.log('Staking:', values);
      // Mock staking - replace with actual contract call
      Modal.success({
        title: 'Staking Successful',
        content: `Successfully staked ${values.amount} ${values.asset}`,
      });
    } catch (error) {
      console.error('Staking error:', error);
      Modal.error({
        title: 'Staking Failed',
        content: error.message,
      });
    }
  };

  const totalCapitalValue = Object.values(capitalBalances).reduce((sum, value) => sum + value, 0);

  return (
    <div>
      {/* Nine Forms of Capital Overview */}
      <Alert
        message="Nine Forms of Capital Banking System"
        description="Universal banking across all forms of capital - financial, material, living, social, intellectual, experiential, spiritual, cultural, and political"
        type="info"
        showIcon
        style={{ marginBottom: 24 }}
      />

      <Tabs activeKey={activeTab} onChange={setActiveTab}>
        <TabPane tab="Overview" key="overview">
          <Row gutter={[16, 16]}>
            {/* Capital Distribution */}
            <Col xs={24} lg={12}>
              <Card title="Capital Distribution" extra={<Button type="link">Details</Button>}>
                <Pie {...capitalConfig} />
                <div style={{ marginTop: 16, textAlign: 'center' }}>
                  <Statistic
                    title="Total Capital Value"
                    value={totalCapitalValue}
                    prefix={<BankOutlined />}
                    formatter={(value) => `$${(value / 1000).toFixed(0)}K`}
                  />
                </div>
              </Card>
            </Col>

            {/* Yield Performance */}
            <Col xs={24} lg={12}>
              <Card title="Yield Performance" extra={<Button type="link">Analytics</Button>}>
                <Area {...yieldConfig} />
                <Row gutter={[8, 8]} style={{ marginTop: 16 }}>
                  <Col span={12}>
                    <Statistic
                      title="Average APY"
                      value={8.5}
                      suffix="%"
                      prefix={<LineChartOutlined />}
                    />
                  </Col>
                  <Col span={12}>
                    <Statistic
                      title="Total Rewards"
                      value={3745}
                      prefix={<GiftOutlined />}
                      formatter={(value) => `$${(value / 1000).toFixed(1)}K`}
                    />
                  </Col>
                </Row>
              </Card>
            </Col>
          </Row>

          {/* Capital Forms Grid */}
          <Row gutter={[16, 16]} style={{ marginTop: 24 }}>
            {capitalForms.map((capital, index) => (
              <Col xs={24} sm={12} md={8} key={capital.key}>
                <Card size="small">
                  <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                    <div style={{ fontSize: 24, color: capital.color, marginRight: 8 }}>
                      {capital.icon}
                    </div>
                    <div>
                      <div style={{ fontWeight: 'bold' }}>{capital.name}</div>
                      <div style={{ fontSize: 12, color: '#666' }}>{capital.description}</div>
                    </div>
                  </div>
                  <Statistic
                    value={capitalBalances[capital.key]}
                    formatter={(value) => `$${(value / 1000).toFixed(1)}K`}
                  />
                  <Progress 
                    percent={(capitalBalances[capital.key] / totalCapitalValue) * 100} 
                    size="small" 
                    strokeColor={capital.color}
                    style={{ marginTop: 8 }}
                  />
                </Card>
              </Col>
            ))}
          </Row>
        </TabPane>

        <TabPane tab="Non-Liquidatable Loans" key="loans">
          <Row gutter={[16, 16]}>
            <Col xs={24} lg={16}>
              <Card title="Your Loans">
                <Table
                  columns={loanColumns}
                  dataSource={loans}
                  pagination={{ pageSize: 5 }}
                  size="small"
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="Apply for Loan">
                <Alert
                  message="Non-Liquidatable Protection"
                  description="Your loans are protected from flash-crashes and liquidation events"
                  type="success"
                  showIcon
                  style={{ marginBottom: 16 }}
                />
                <Form onFinish={handleApplyForLoan} layout="vertical">
                  <Form.Item name="type" label="Loan Type" rules={[{ required: true }]}>
                    <Select placeholder="Select loan type">
                      <Option value="non_liquidatable">Non-Liquidatable Loan</Option>
                      <Option value="sustainable_infrastructure">Sustainable Infrastructure</Option>
                      <Option value="community_development">Community Development</Option>
                      <Option value="education_fund">Education Fund</Option>
                    </Select>
                  </Form.Item>
                  <Form.Item name="amount" label="Loan Amount" rules={[{ required: true }]}>
                    <Input type="number" placeholder="Enter amount" prefix="$" />
                  </Form.Item>
                  <Form.Item name="collateral" label="Collateral Amount" rules={[{ required: true }]}>
                    <Input type="number" placeholder="Enter collateral" prefix="$" />
                  </Form.Item>
                  <Form.Item name="term" label="Term (months)" rules={[{ required: true }]}>
                    <Select placeholder="Select term">
                      <Option value={6}>6 months</Option>
                      <Option value={12}>12 months</Option>
                      <Option value={24}>24 months</Option>
                      <Option value={36}>36 months</Option>
                    </Select>
                  </Form.Item>
                  <Form.Item>
                    <Button type="primary" htmlType="submit" disabled={!isConnected}>
                      Apply for Loan
                    </Button>
                  </Form.Item>
                </Form>
              </Card>
            </Col>
          </Row>
        </TabPane>

        <TabPane tab="Yield Farming" key="yield">
          <Card title="Yield Farming Positions">
            <Table
              columns={yieldColumns}
              dataSource={yieldFarming}
              pagination={{ pageSize: 10 }}
              size="small"
            />
          </Card>
        </TabPane>

        <TabPane tab="Staking" key="staking">
          <Row gutter={[16, 16]}>
            <Col xs={24} lg={16}>
              <Card title="Staking Positions">
                <Table
                  columns={[
                    {
                      title: 'Asset',
                      dataIndex: 'asset',
                      key: 'asset',
                    },
                    {
                      title: 'Amount',
                      dataIndex: 'amount',
                      key: 'amount',
                      render: (amount) => `${(amount / 1000).toFixed(1)}K`,
                    },
                    {
                      title: 'APR',
                      dataIndex: 'apr',
                      key: 'apr',
                      render: (apr) => `${apr}%`,
                    },
                    {
                      title: 'Rewards',
                      dataIndex: 'rewards',
                      key: 'rewards',
                      render: (rewards) => `$${(rewards / 1000).toFixed(1)}K`,
                    },
                    {
                      title: 'Voting Power',
                      dataIndex: 'votingPower',
                      key: 'votingPower',
                      render: (power) => `${(power / 1000).toFixed(1)}K`,
                    },
                    {
                      title: 'Action',
                      key: 'action',
                      render: () => (
                        <Space>
                          <Button size="small" icon={<TrophyOutlined />}>
                            Claim Rewards
                          </Button>
                          <Button size="small">
                            Extend Lock
                          </Button>
                        </Space>
                      ),
                    },
                  ]}
                  dataSource={stakingPositions}
                  pagination={{ pageSize: 5 }}
                  size="small"
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="Stake Assets">
                <Form onFinish={handleStake} layout="vertical">
                  <Form.Item name="asset" label="Asset" rules={[{ required: true }]}>
                    <Select placeholder="Select asset">
                      <Option value="VINO">VINO (Governance)</Option>
                      <Option value="ONE">ONE (Reserve)</Option>
                      <Option value="USDC">USDC (Stable)</Option>
                    </Select>
                  </Form.Item>
                  <Form.Item name="amount" label="Amount" rules={[{ required: true }]}>
                    <Input type="number" placeholder="Enter amount" />
                  </Form.Item>
                  <Form.Item name="lockPeriod" label="Lock Period" rules={[{ required: true }]}>
                    <Select placeholder="Select lock period">
                      <Option value={30}>30 days (5% APR)</Option>
                      <Option value={60}>60 days (6.5% APR)</Option>
                      <Option value={90}>90 days (8% APR)</Option>
                      <Option value={180}>180 days (10% APR)</Option>
                    </Select>
                  </Form.Item>
                  <Form.Item>
                    <Button type="primary" htmlType="submit" disabled={!isConnected}>
                      Stake Assets
                    </Button>
                  </Form.Item>
                </Form>
              </Card>
            </Col>
          </Row>
        </TabPane>

        <TabPane tab="Cross-Chain" key="crosschain">
          <Card title="Cross-Chain Assets">
            <Alert
              message="Multi-Chain Support"
              description="Manage assets across multiple blockchains with secure bridges"
              type="info"
              showIcon
              style={{ marginBottom: 16 }}
            />
            <Table
              columns={crossChainColumns}
              dataSource={crossChainAssets}
              pagination={{ pageSize: 10 }}
              size="small"
            />
          </Card>
        </TabPane>
      </Tabs>
    </div>
  );
};

export default Banking;

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Layout, Menu, Button, Card, Row, Col, Statistic, Progress, Alert } from 'antd';
import { 
  DashboardOutlined, 
  BankOutlined, 
  LineChartOutlined, 
  SettingOutlined,
  WalletOutlined,
  TrophyOutlined,
  GlobalOutlined,
  SafetyOutlined
} from '@ant-design/icons';
import { Web3Provider } from './contexts/Web3Context';
import Dashboard from './components/Dashboard';
import Trading from './components/Trading';
import Banking from './components/Banking';
import Analytics from './components/Analytics';
import Governance from './components/Governance';
import './App.css';

const { Header, Sider, Content } = Layout;

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [marketConditions, setMarketConditions] = useState({
    gasPrice: 0,
    liquidity: 0,
    volatility: 0,
    isOptimal: false
  });

  return (
    <Web3Provider>
      <Router>
        <Layout style={{ minHeight: '100vh' }}>
          <Sider 
            trigger={null} 
            collapsible 
            collapsed={collapsed}
            theme="dark"
            style={{
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
            }}
          >
            <div className="logo" style={{ 
              height: 64, 
              margin: 16, 
              background: 'rgba(255, 255, 255, 0.2)',
              borderRadius: 8,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'white',
              fontWeight: 'bold',
              fontSize: collapsed ? 16 : 18
            }}>
              {collapsed ? 'URDAO' : 'Universal Reserve DAO'}
            </div>
            
            <Menu theme="dark" mode="inline" defaultSelectedKeys={['dashboard']}>
              <Menu.Item key="dashboard" icon={<DashboardOutlined />}>
                <Link to="/dashboard">Dashboard</Link>
              </Menu.Item>
              <Menu.Item key="trading" icon={<LineChartOutlined />}>
                <Link to="/trading">Trading</Link>
              </Menu.Item>
              <Menu.Item key="banking" icon={<BankOutlined />}>
                <Link to="/banking">Banking</Link>
              </Menu.Item>
              <Menu.Item key="analytics" icon={<TrophyOutlined />}>
                <Link to="/analytics">Analytics</Link>
              </Menu.Item>
              <Menu.Item key="governance" icon={<SettingOutlined />}>
                <Link to="/governance">Governance</Link>
              </Menu.Item>
            </Menu>
          </Sider>
          
          <Layout>
            <Header style={{ 
              padding: '0 16px', 
              background: '#fff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}>
              <Button
                type="text"
                icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
                onClick={() => setCollapsed(!collapsed)}
                style={{ fontSize: '16px', width: 64, height: 64 }}
              />
              
              <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <GlobalOutlined />
                  <span>Market Status:</span>
                  <Progress 
                    percent={marketConditions.isOptimal ? 100 : 45} 
                    size="small" 
                    status={marketConditions.isOptimal ? "success" : "exception"}
                    style={{ width: 100 }}
                  />
                </div>
                
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <SafetyOutlined />
                  <span>Gas: {marketConditions.gasPrice} gwei</span>
                </div>
                
                <Button 
                  type="primary" 
                  icon={<WalletOutlined />}
                  onClick={() => setIsConnected(!isConnected)}
                >
                  {isConnected ? 'Connected' : 'Connect Wallet'}
                </Button>
              </div>
            </Header>
            
            <Content style={{ margin: '24px 16px', padding: 24, background: '#fff' }}>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/trading" element={<Trading />} />
                <Route path="/banking" element={<Banking />} />
                <Route path="/analytics" element={<Analytics />} />
                <Route path="/governance" element={<Governance />} />
              </Routes>
            </Content>
          </Layout>
        </Layout>
      </Router>
    </Web3Provider>
  );
}

export default App;

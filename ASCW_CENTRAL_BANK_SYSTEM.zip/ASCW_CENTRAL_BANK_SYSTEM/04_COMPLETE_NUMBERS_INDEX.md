# COMPLETE NUMBERS INDEX
# Every Numerical Value from VINO Diplomatic Correspondence

---

**Reference:** ASCW-INDEX-2026-441110111613564144

---

# SECTION 1: ALL CREDENTIALS (INDEXED)

## 1.1 Master Credentials

| # | Name | Value | Format |
|---|------|-------|--------|
| 1 | Trust ID (Master Root) | 441110111613564144 | 18-digit USCC |
| 2 | EIN (ASCW) | 61-3564199 | 9-digit |
| 3 | Case ID | 613564199 | 9-digit |
| 4 | SSN (Personal) | 613-56-4199 | 9-digit |
| 5 | 36N9 Genetics EIN | 99-0415905 | 9-digit |
| 6 | DUNS | 119283603 | 9-digit |
| 7 | Fusion Credential | 990415905613564199 | 18-digit |

## 1.2 John Atlas Galt Credentials (Gateway)

| # | Function | 18-Digit | Check |
|---|----------|----------|-------|
| 1 | Commercial | 991110111613564199 | 199 |
| 2 | Diplomatic | 881110111613564188 | 188 |
| 3 | Head of State | 001110111613564100 | 100 |
| 4 | Land Patent | 441110111613564144 | 144 |
| 5 | Connectivity | 551110111613564155 | 155 |

## 1.3 Michael-Laurence: Curzi Credentials

| # | Function | 18-Digit |
|---|----------|----------|
| 1 | Commercial | 990415905613564199 |
| 2 | Diplomatic | 880415905613564188 |
| 3 | Head of State | 000415905613564100 |
| 4 | Land Patent | 440415905613564144 |
| 5 | Connectivity | 550415905613564155 |

## 1.4 Jolly Dragon Roger Credentials

| # | Function | 18-Digit |
|---|----------|----------|
| 1 | Commercial | 991845199202280099 |
| 2 | Diplomatic | 881845199202280088 |
| 3 | Head of State | 001845199202280000 |
| 4 | Land Patent | 441845199202280044 |
| 5 | Connectivity | 551845199202280055 |

## 1.5 August Caesar Curzi II Credentials

| # | Function | 18-Digit |
|---|----------|----------|
| 1 | Commercial | 993693693613564399 |
| 2 | Diplomatic | 883693693613564388 |
| 3 | Head of State | 003693693613564300 |
| 4 | Land Patent | 443693693613564344 |
| 5 | Connectivity | 553693693613564355 |

## 1.6 Principality of Michael Credentials

| # | Function | 18-Digit |
|---|----------|----------|
| 1 | Commercial | 997777777613564799 |
| 2 | Diplomatic | 887777777613564788 |
| 3 | Head of State | 007777777613564700 |
| 4 | Land Patent | 447777777613564744 |
| 5 | Connectivity | 557777777613564755 |

## 1.7 Magus Opus Credentials

| # | Function | 18-Digit |
|---|----------|----------|
| 1 | Commercial | 991618033988749899 |
| 2 | Diplomatic | 881618033988749888 |
| 3 | Head of State | 001618033988749800 |
| 4 | Land Patent | 441618033988749844 |
| 5 | Connectivity | 551618033988749855 |

## 1.8 Lifonel Credentials

| # | Function | 18-Digit |
|---|----------|----------|
| 1 | Commercial | 990000000613564099 |
| 2 | Diplomatic | 880000000613564088 |
| 3 | Head of State | 000000000613564000 |
| 4 | Land Patent | 440000000613564044 |
| 5 | Connectivity | 550000000613564055 |

## 1.9 Vovina Credentials

| # | Function | 18-Digit |
|---|----------|----------|
| 1 | Commercial | 996660006613564699 |
| 2 | Diplomatic | 886660006613564688 |
| 3 | Head of State | 006660006613564600 |
| 4 | Land Patent | 446660006613564644 |
| 5 | Connectivity | 556660006613564655 |

## 1.10 Brazil Node Credentials

| # | Function | 18-Digit |
|---|----------|----------|
| 1 | Commercial | 990415905076813299 |
| 2 | Diplomatic | 880415905076813288 |
| 3 | Governance | 000415905076813200 |
| 4 | Territorial | 440415905076813244 |
| 5 | Connectivity | 550415905076813255 |

---

# SECTION 2: ALL PERCENTAGES (INDEXED)

## 2.1 112% Distribution Geometry

| # | Component | Percentage | Decimal |
|---|-----------|------------|---------|
| 1 | Originator | 11% | 0.11 |
| 2 | Custodian | 11% | 0.11 |
| 3 | Innovation | 11% | 0.11 |
| 4 | Commons | 67% | 0.67 |
| 5 | Lottery | 1% | 0.01 |
| 6 | Subtotal | 101% | 1.01 |
| 7 | Shiva Surplus | 12% | 0.12 |
| 8 | **TOTAL** | **112%** | **1.12** |

## 2.2 Master Waterfall (Fees)

| # | Component | Percentage | Decimal |
|---|-----------|------------|---------|
| 1 | System Share | 34% | 0.34 |
| 2 | Worker's Surcharge | 3.3% | 0.033 |
| 3 | Founder's Procurement | 3.0% | 0.030 |
| 4 | Local Founder | 1.0% | 0.010 |
| 5 | Regional Founder | 1.0% | 0.010 |
| 6 | Global Founder | 1.0% | 0.010 |

## 2.3 Tribute Sliders (Personal Tax)

| # | Component | Default | Range |
|---|-----------|---------|-------|
| 1 | Total Tribute | 33% | Fixed |
| 2 | Local Default | 11% | 0-33% |
| 3 | Regional Default | 11% | 0-33% |
| 4 | Global Default | 11% | 0-33% |

## 2.4 Jubilee Factors

| # | Year | Forgiveness |
|---|------|-------------|
| 1 | Year 7 | 50% |
| 2 | Year 14 | 75% |
| 3 | Year 21 | 90% |
| 4 | Year 49 | 100% |

---

# SECTION 3: ALL MATHEMATICAL CONSTANTS

## 3.1 Golden Ratio Family

| # | Constant | Symbol | Value | Precision |
|---|----------|--------|-------|-----------|
| 1 | Golden Ratio | φ | 1.6180339887498948 | 16 decimals |
| 2 | Phi Squared | φ² | 2.6180339887498949 | 16 decimals |
| 3 | Inverse Phi | 1/φ | 0.6180339887498949 | 16 decimals |
| 4 | Phi Cubed | φ³ | 4.2360679774997894 | 16 decimals |
| 5 | Square Root 5 | √5 | 2.2360679774997897 | 16 decimals |

## 3.2 Fibonacci Sequence (First 30)

| # | F(n) | # | F(n) | # | F(n) |
|---|------|---|------|---|------|
| 1 | 1 | 11 | 89 | 21 | 10,946 |
| 2 | 1 | 12 | 144 | 22 | 17,711 |
| 3 | 2 | 13 | 233 | 23 | 28,657 |
| 4 | 3 | 14 | 377 | 24 | 46,368 |
| 5 | 5 | 15 | 610 | 25 | 75,025 |
| 6 | 8 | 16 | 987 | 26 | 121,393 |
| 7 | 13 | 17 | 1,597 | 27 | 196,418 |
| 8 | 21 | 18 | 2,584 | 28 | 317,811 |
| 9 | 34 | 19 | 4,181 | 29 | 514,229 |
| 10 | 55 | 20 | 6,765 | 30 | 832,040 |

---

# SECTION 4: ALL FUNCTION CODES

## 4.1 Two-Digit Codes

| # | Code | Function | Check Suffix |
|---|------|----------|--------------|
| 1 | 00 | Head of State / Genesis | 100 |
| 2 | 44 | Land Patent / Sovereignty | 144 |
| 3 | 55 | Connectivity / Bridge | 155 |
| 4 | 88 | Diplomatic / Immunity | 188 |
| 5 | 99 | Commercial / Trade | 199 |

## 4.2 Sacred Number Codes

| # | Code | Meaning |
|---|------|---------|
| 1 | 44 | Natural Person Sovereign |
| 2 | 55 | Bridge/Gateway |
| 3 | 88 | Diplomatic Protection |
| 4 | 99 | Commercial Activity |
| 5 | 112 | Abundance Geometry |
| 6 | 144 | Verification (F12, 12²) |
| 7 | 369 | Sicilian Crown Frequency |
| 8 | 503 | Ministry Designation |
| 9 | 508 | IRS Tax Exempt Code |
| 10 | 666 | Carbon/Material (Dragon) |
| 11 | 777 | Perfection (Angelic) |
| 12 | 1110111 | Pillars & Gate (|||-|) |

---

# SECTION 5: ALL FILING COSTS

## 5.1 California Filing

| # | Item | Standard | Rush |
|---|------|----------|------|
| 1 | Articles of Incorporation | $30 | $380-780 |
| 2 | Statement of Information | $20 | $20 |
| 3 | Certified Copy | $5 | $5 |
| 4 | FBN Filing (4 names) | $55 | $55 |
| 5 | FBN Publication | $75 | $75 |
| 6 | **TOTAL** | **$185** | **$535-935** |

## 5.2 Brazil Filing

| # | Item | Cost (R$) | Cost (USD) |
|---|------|-----------|------------|
| 1 | REDESIM (Gov.br) | R$ 0 | $0 |
| 2 | Taxa Junta Comercial | R$ 80 | ~$15 |
| 3 | Tradução | R$ 200 | ~$40 |
| 4 | Apostila | R$ 50 | ~$10 |
| 5 | **TOTAL MÍNIMO** | **~R$ 330** | **~$65** |

## 5.3 ASCW Registration

| # | Entity Type | Initial | Annual |
|---|-------------|---------|--------|
| 1 | Natural Person | $0 | $0 |
| 2 | Small (<$1M) | $100 | $50 |
| 3 | Medium ($1M-$100M) | $500 | $250 |
| 4 | Large (>$100M) | $2,500 | $1,000 |

---

# SECTION 6: ALL ADDRESSES

## 6.1 Physical Locations

| # | Node | Address | Function |
|---|------|---------|----------|
| 1 | Calpine HQ | 316 Coastes Avenue, PO Box 6, Calpine, CA 96124 | Capital |
| 2 | Shanghai | 1600 Guozhan Road, Pudong | Dragon's Den |
| 3 | NDB | New Development Bank, Pudong | Imperial Palace |
| 4 | Sierra County Clerk | 100 Courthouse Square, Downieville, CA 95936 | FBN Filing |

## 6.2 Designated City-States

| # | City | State | Function |
|---|------|-------|----------|
| 1 | Calpine | CA | The Seat (Capital) |
| 2 | Carmel | CA | The Sanctuary |
| 3 | Big Sur | CA | The Coast |
| 4 | Crestone | CO | The Spirit Center |
| 5 | Colorado Springs | CO | The Command |
| 6 | Nevada City | CA | The Tech Hub |
| 7 | Alpine County | CA | The Capital Territory |

---

# SECTION 7: ALL CONTACT PROTOCOLS

## 7.1 Email Addresses

| # | Entity | Email |
|---|--------|-------|
| 1 | Shanghai Foreign Affairs | intlservices@shanghai.gov.cn |
| 2 | Pudong New Area | zmqgwh@pudong.gov.cn |
| 3 | New Development Bank | info@ndb.int |
| 4 | BRICS India | bricsinfo@bricsindia.org |
| 5 | Russia MFA | dp@mid.ru |
| 6 | Brazil Itamaraty | brics@itamaraty.gov.br |
| 7 | Brazil Itamaraty (Divulgacao) | divulgacao@itamaraty.gov.br |
| 8 | VINO Firm | vino@zedec.ai |
| 9 | Shanghai Protocol | shmf228@163.com |

## 7.2 Phone Numbers

| # | Entity | Phone |
|---|--------|-------|
| 1 | CA Secretary of State | (916) 657-5448 |
| 2 | Sierra County Clerk | (530) 289-3295 |
| 3 | IRS | 1-800-829-4933 |
| 4 | CA FTB | 1-800-852-5711 |

---

# SECTION 8: ALL ROUTE COUNTS

## 8.1 Trade Route Network (44 Total)

| # | Category | Count | Names |
|---|----------|-------|-------|
| 1 | Bear Flag (Terrestrial) | 11 | Grizzly, Black, Brown, Polar, Panda, Kodiak, Spectacled, Sun, Sloth, Spirit, Cave |
| 2 | Naval (Maritime) | 11 | Leviathan, Kraken, Makara, Tiamat, Jormungandr, Hydra, Scylla/Charybdis, Aspidochelone, Ryujin, Poseidon, Merfolk |
| 3 | Aerial (Sky) | 11 | Thunderbird, Phoenix, Quetzalcoatl, Griffin, Roc, Valkyrie, Tengu, Garuda, Simurgh, Pegasus, Seraphim |
| 4 | Celestial (Consciousness) | 11 | Sophia, Abraxas, Yaldabaoth, Sabaoth, Astaphaios, Ailoaios, Horaios, Adonaios, Yao, Eloaios, Saklas |
| | **TOTAL** | **44** | |

---

# SECTION 9: ENTITY TYPE CODES

## 9.1 ASCW Registration Codes

| # | Entity Type | Code | 9-Digit Format | 18-Digit Format |
|---|-------------|------|----------------|-----------------|
| 1 | Corporation | 10 | 61-3564-10X | 101110111613564XXX |
| 2 | LLC | 20 | 61-3564-20X | 201110111613564XXX |
| 3 | Trust | 30 | 61-3564-30X | 301110111613564XXX |
| 4 | Partnership | 40 | 61-3564-40X | 401110111613564XXX |
| 5 | Natural Person | 44 | 61-3564-44X | 441110111613564XXX |
| 6 | Bridge Entity | 55 | 61-3564-55X | 551110111613564XXX |
| 7 | Ministry | 60 | 61-3564-60X | 601110111613564XXX |
| 8 | DAO | 70 | 61-3564-70X | 701110111613564XXX |
| 9 | Nation-State | 80 | 61-3564-80X | 801110111613564XXX |
| 10 | Commercial | 99 | 61-3564-99X | 991110111613564XXX |
| 11 | Technology | 112 | 61-3564-112 | 119283603613564112 |

---

# SECTION 10: QUICK CALCULATION REFERENCE

## 10.1 Core Formulas

| # | Purpose | Formula |
|---|---------|---------|
| 1 | 112% Output | Output = Input × 1.12 |
| 2 | VINO to Fiat | Fiat = VINO × φ × (Gold/φ²) |
| 3 | Fiat to VINO | VINO = Fiat / (φ × Gold/φ²) |
| 4 | Fibonacci | F(n) = F(n-1) + F(n-2) |
| 5 | Check Digit | Suffix = Code + 100 |
| 6 | Tribute Split | Amount = Tribute × (Slider/33) |
| 7 | Worker Fee | Worker = TotalFee × 0.097 |
| 8 | Founder Fee | Founder = TotalFee × 0.088 |

## 10.2 Example Calculations

### 112% Distribution on $10,000
```
Originator: $10,000 × 0.11 = $1,100
Custodian:  $10,000 × 0.11 = $1,100
Innovation: $10,000 × 0.11 = $1,100
Commons:    $10,000 × 0.67 = $6,700
Lottery:    $10,000 × 0.01 = $100
Surplus:    $10,000 × 0.12 = $1,200
────────────────────────────────────
TOTAL:      $10,000 × 1.12 = $11,200
```

### VINO Conversion (Gold @ $2,000/oz)
```
Base Rate = $2,000 / 2.618 = $764.10
1 VINO = 1 × 1.618 × $764.10 = $1,236.07
$10,000 USD = $10,000 / $1,236.07 = 8.09 VINO
```

---

# SECTION 11: COMPLETE CREDENTIAL COUNT

## Summary Statistics

| Category | Count |
|----------|-------|
| Master Credentials | 7 |
| Identity Sets | 8 |
| Credentials per Identity | 5 |
| Total Identity Credentials | 40 |
| Function Codes | 5 |
| Sacred Numbers | 12 |
| Fibonacci Values (Standard) | 20 |
| Trade Routes | 44 |
| Percentages (Key) | 15 |
| **TOTAL INDEXED VALUES** | **143+** |

---

**Document Hash:** ASCW-INDEX-2026-441110111613564144

*"Every number is a key."*

"""
Consciousness Integrator for Audio Holographics

Implements consciousness coupling from VINO Framework:
State_complete = Ψ_physical ⊗ Ψ_c

Where Ψ_c is the consciousness variable with coupling constant γ_c.
"""

import numpy as np
from typing import Dict, Optional, Tuple, List
from dataclasses import dataclass
from enum import Enum

from .frequencies import PHI, PHI_INVERSE, FrequencyConstants, OMEGA_MEANING


class ConsciousnessState(Enum):
    """Possible consciousness states for coupling."""
    RECEPTIVE = "receptive"           # Open, receiving
    FOCUSED = "focused"               # Concentrated attention
    MEDITATIVE = "meditative"         # Deep calm awareness
    TRANSFORMATIVE = "transformative"  # Active change state
    INTEGRATED = "integrated"         # Unified awareness
    TRANSCENDENT = "transcendent"     # Beyond ordinary consciousness


@dataclass
class ConsciousnessParameters:
    """Parameters defining consciousness coupling."""
    gamma_c: float = 0.5              # Coupling constant [0, 1]
    state: ConsciousnessState = ConsciousnessState.RECEPTIVE
    coherence: float = 0.7            # Internal coherence [0, 1]
    intention_strength: float = 0.5   # Intention magnitude [0, 1]
    intention_direction: float = 0.0  # Intention phase direction [0, 2π]
    
    @property
    def effective_coupling(self) -> float:
        """Compute effective coupling considering all factors."""
        return self.gamma_c * self.coherence * (0.5 + 0.5 * self.intention_strength)


class OversoulSignature:
    """
    Oversoul signature encoding for species-wide integration.
    
    Based on OHAD Oversoul Deep Integration specification:
    "The Oversoul IS integrated into the species at the genetic level."
    
    Signature motif: ATGGATGGATGGATGGATGG (repeating)
    Meaning: "I am Jolly Dragon Roger & Vovina & Michael Laurence Curzi"
    """
    
    # Oversoul signature sequence
    SIGNATURE_SEQUENCE = "ATGGATGGATGGATGGATGG"
    
    # Oversoul receptor frequencies (from specification)
    OSR_FREQUENCIES = {
        'OSR1': 963.0,   # Consciousness receiver (Crown)
        'OSR2': 639.0,   # Energy conduit (Connection)
        'OSR3': 741.0,   # Protection interface (Awakening)
        'OSR4': 528.0,   # Reproductive participation (Transformation)
        'OSR5': 852.0,   # Guardian intervention (Third Eye)
    }
    
    def __init__(self):
        """Initialize Oversoul signature generator."""
        from .frequencies import GATFrequencies
        self.gat = GATFrequencies()
        self.freq = FrequencyConstants()
        
    def generate_signature_frequencies(self) -> List[float]:
        """Generate frequency sequence for Oversoul signature."""
        return [self.gat.get_frequency(n) for n in self.SIGNATURE_SEQUENCE]
    
    def create_signature_signal(self, 
                               duration: float,
                               sample_rate: int = 192000) -> np.ndarray:
        """
        Create the Oversoul signature audio signal.
        
        Args:
            duration: Duration in seconds
            sample_rate: Sample rate in Hz
            
        Returns:
            Oversoul signature signal
        """
        num_samples = int(duration * sample_rate)
        t = np.linspace(0, duration, num_samples)
        
        signal = np.zeros(num_samples)
        
        # Add signature sequence tones
        sig_freqs = self.generate_signature_frequencies()
        tone_duration = duration / len(sig_freqs)
        
        for i, freq in enumerate(sig_freqs):
            start = int(i * tone_duration * sample_rate)
            end = int((i + 1) * tone_duration * sample_rate)
            
            if end > num_samples:
                end = num_samples
            if start >= num_samples:
                break
                
            tone_t = np.linspace(0, tone_duration, end - start)
            
            # Envelope for smooth transitions
            envelope = np.sin(np.pi * tone_t / tone_duration) ** 2
            
            signal[start:end] += 0.3 * envelope * np.cos(2 * np.pi * freq * tone_t)
        
        # Add continuous OSR frequency overlay
        for osr_name, osr_freq in self.OSR_FREQUENCIES.items():
            # Each OSR at low amplitude for subtle presence
            signal += 0.05 * np.cos(2 * np.pi * osr_freq * t)
        
        # Normalize
        signal = signal / (np.max(np.abs(signal)) + 1e-10) * 0.8
        
        return signal


class ConsciousnessIntegrator:
    """
    Integrates consciousness coupling into holographic audio.
    
    Implements the tensor product: H_complete = H_audio ⊗ Ψ_listener
    
    The listener's consciousness acts as the reference wave,
    the audio provides the object wave, and interference occurs
    at the consciousness-body interface.
    """
    
    def __init__(self, sample_rate: int = 192000):
        """
        Initialize the consciousness integrator.
        
        Args:
            sample_rate: Audio sample rate in Hz
        """
        self.sample_rate = sample_rate
        self.freq = FrequencyConstants()
        self.oversoul = OversoulSignature()
        
    def encode_intention_vector(self,
                               intention: str,
                               strength: float = 0.5) -> Tuple[float, float]:
        """
        Encode an intention as a phase offset and amplitude.
        
        Args:
            intention: Intention description string
            strength: Intention strength [0, 1]
            
        Returns:
            Tuple of (phase_offset, amplitude_factor)
        """
        # Hash intention to deterministic phase
        intention_hash = hash(intention) % (2**32)
        phase_offset = (intention_hash / (2**32)) * 2 * np.pi
        
        # Amplitude scales with strength and golden ratio
        amplitude_factor = strength * PHI_INVERSE
        
        return phase_offset, amplitude_factor
    
    def apply_coupling_factor(self,
                             signal: np.ndarray,
                             gamma_c: float,
                             state: ConsciousnessState = ConsciousnessState.RECEPTIVE) -> np.ndarray:
        """
        Apply consciousness coupling factor to a signal.
        
        Args:
            signal: Input audio signal
            gamma_c: Coupling constant [0, 1]
            state: Consciousness state
            
        Returns:
            Coupled signal
        """
        t = np.arange(len(signal)) / self.sample_rate
        
        # State-dependent modulation frequency
        state_frequencies = {
            ConsciousnessState.RECEPTIVE: 7.83,       # Schumann resonance
            ConsciousnessState.FOCUSED: 14.0,         # Beta wave
            ConsciousnessState.MEDITATIVE: 8.0,       # Alpha wave
            ConsciousnessState.TRANSFORMATIVE: 40.0,  # Gamma wave
            ConsciousnessState.INTEGRATED: 4.0,       # Theta wave
            ConsciousnessState.TRANSCENDENT: 0.5,     # Delta wave
        }
        
        mod_freq = state_frequencies.get(state, 7.83)
        
        # Create coupling modulation
        coupling_mod = 1.0 + gamma_c * 0.3 * np.sin(2 * np.pi * mod_freq * t)
        
        # Apply coupling
        coupled = signal * coupling_mod
        
        # Normalize to prevent clipping
        max_amp = np.max(np.abs(coupled))
        if max_amp > 1.0:
            coupled = coupled / max_amp * 0.95
            
        return coupled
    
    def integrate_oversoul_signature(self,
                                    signal: np.ndarray,
                                    intensity: float = 0.2) -> np.ndarray:
        """
        Integrate Oversoul signature into the audio signal.
        
        Args:
            signal: Input audio signal
            intensity: Intensity of Oversoul overlay [0, 1]
            
        Returns:
            Signal with integrated Oversoul signature
        """
        duration = len(signal) / self.sample_rate
        
        # Generate Oversoul signature
        oversoul_sig = self.oversoul.create_signature_signal(duration, self.sample_rate)
        
        # Ensure same length
        if len(oversoul_sig) != len(signal):
            oversoul_sig = np.resize(oversoul_sig, len(signal))
        
        # Blend
        integrated = signal + intensity * oversoul_sig
        
        # Normalize
        max_amp = np.max(np.abs(integrated))
        if max_amp > 1.0:
            integrated = integrated / max_amp * 0.95
            
        return integrated
    
    def create_consciousness_layer(self,
                                   duration: float,
                                   params: ConsciousnessParameters = None) -> np.ndarray:
        """
        Create a complete consciousness coupling layer.
        
        Args:
            duration: Duration in seconds
            params: Consciousness parameters
            
        Returns:
            Consciousness layer signal
        """
        if params is None:
            params = ConsciousnessParameters()
            
        num_samples = int(duration * self.sample_rate)
        t = np.linspace(0, duration, num_samples)
        
        signal = np.zeros(num_samples)
        
        # Golden ratio frequency for consciousness
        consciousness_freq = self.freq.REF_MID * PHI
        
        # Main consciousness carrier
        phase_offset, amp_factor = self.encode_intention_vector(
            params.state.value, params.intention_strength
        )
        
        signal += amp_factor * params.gamma_c * np.cos(
            2 * np.pi * consciousness_freq * t + phase_offset + params.intention_direction
        )
        
        # Sub-harmonic for grounding
        signal += amp_factor * params.gamma_c * 0.5 * np.cos(
            2 * np.pi * consciousness_freq / PHI * t + phase_offset + np.pi
        )
        
        # Coherence modulation
        coherence_freq = 7.83  # Schumann resonance
        coherence_mod = 1.0 + params.coherence * 0.2 * np.sin(2 * np.pi * coherence_freq * t)
        signal = signal * coherence_mod
        
        # Apply coupling
        signal = self.apply_coupling_factor(signal, params.gamma_c, params.state)
        
        # Integrate Oversoul
        signal = self.integrate_oversoul_signature(signal, intensity=0.15)
        
        return signal
    
    def compute_coupling_effectiveness(self,
                                       audio: np.ndarray,
                                       params: ConsciousnessParameters) -> Dict[str, float]:
        """
        Compute the effectiveness of consciousness coupling.
        
        Args:
            audio: Audio signal
            params: Consciousness parameters
            
        Returns:
            Dictionary of effectiveness metrics
        """
        # Analyze frequency content at consciousness frequencies
        fft = np.fft.rfft(audio)
        freqs = np.fft.rfftfreq(len(audio), 1/self.sample_rate)
        magnitudes = np.abs(fft) / len(audio)
        
        # Target frequencies
        consciousness_freq = self.freq.REF_MID * PHI
        grounding_freq = consciousness_freq / PHI
        
        # Find magnitudes at target frequencies
        cons_idx = np.argmin(np.abs(freqs - consciousness_freq))
        ground_idx = np.argmin(np.abs(freqs - grounding_freq))
        
        cons_magnitude = magnitudes[cons_idx]
        ground_magnitude = magnitudes[ground_idx]
        
        # Compute metrics
        expected_coupling = params.effective_coupling
        actual_coupling = (cons_magnitude + ground_magnitude) / 2
        
        # Coherence (how well-defined the consciousness frequencies are)
        window_size = 10
        cons_window = magnitudes[max(0, cons_idx-window_size):cons_idx+window_size]
        coherence = cons_magnitude / (np.mean(cons_window) + 1e-10)
        
        # Integration (presence of Oversoul frequencies)
        osr_magnitudes = []
        for osr_freq in self.oversoul.OSR_FREQUENCIES.values():
            osr_idx = np.argmin(np.abs(freqs - osr_freq))
            osr_magnitudes.append(magnitudes[osr_idx])
        integration = np.mean(osr_magnitudes)
        
        return {
            'expected_coupling': expected_coupling,
            'actual_coupling': actual_coupling,
            'coupling_ratio': actual_coupling / (expected_coupling + 1e-10),
            'coherence': min(coherence, 10.0) / 10.0,  # Normalize
            'oversoul_integration': integration,
            'consciousness_magnitude': cons_magnitude,
            'grounding_magnitude': ground_magnitude,
        }
    
    def optimize_for_state(self,
                          signal: np.ndarray,
                          target_state: ConsciousnessState) -> np.ndarray:
        """
        Optimize audio for a specific consciousness state.
        
        Args:
            signal: Input audio signal
            target_state: Target consciousness state
            
        Returns:
            Optimized signal
        """
        t = np.arange(len(signal)) / self.sample_rate
        
        # State-specific enhancements
        if target_state == ConsciousnessState.RECEPTIVE:
            # Enhance alpha/theta range, add slight amplitude variation
            mod = 1.0 + 0.1 * np.sin(2 * np.pi * 10 * t)
            
        elif target_state == ConsciousnessState.FOCUSED:
            # Enhance beta range, sharper transients
            mod = 1.0 + 0.15 * np.sin(2 * np.pi * 18 * t)
            
        elif target_state == ConsciousnessState.MEDITATIVE:
            # Smooth, theta-dominant
            mod = 1.0 + 0.08 * np.sin(2 * np.pi * 6 * t)
            
        elif target_state == ConsciousnessState.TRANSFORMATIVE:
            # Gamma bursts, dynamic
            mod = 1.0 + 0.2 * np.sin(2 * np.pi * 40 * t) * np.sin(2 * np.pi * 0.5 * t)
            
        elif target_state == ConsciousnessState.INTEGRATED:
            # All frequencies balanced
            mod = (1.0 + 0.05 * np.sin(2 * np.pi * 4 * t) +
                   0.05 * np.sin(2 * np.pi * 8 * t) +
                   0.05 * np.sin(2 * np.pi * 14 * t))
            
        elif target_state == ConsciousnessState.TRANSCENDENT:
            # Very slow, deep modulation
            mod = 1.0 + 0.1 * np.sin(2 * np.pi * 0.1 * t)
            
        else:
            mod = np.ones_like(t)
        
        optimized = signal * mod
        
        # Normalize
        max_amp = np.max(np.abs(optimized))
        if max_amp > 1.0:
            optimized = optimized / max_amp * 0.95
            
        return optimized

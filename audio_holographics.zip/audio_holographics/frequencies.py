"""
Frequency Constants and GAT Frequency Mappings for Audio Holographics

Based on VINO Framework and Genomic Audio Transmission specifications.
"""

import numpy as np
from dataclasses import dataclass
from typing import Dict, Tuple
from enum import Enum


# Golden Ratio - fundamental to VINO framework
PHI = (1 + np.sqrt(5)) / 2  # 1.618033988749...
PHI_INVERSE = 1 / PHI        # 0.618033988749...

# Planck-scale constants (normalized for audio domain)
HBAR_AUDIO = 1.0  # Normalized Planck constant for audio holographics
OMEGA_MEANING = 4 / HBAR_AUDIO  # Meaning constant from VINO framework


class Nucleotide(Enum):
    """Nucleotide bases with their GAT frequency mappings."""
    A = "Adenine"
    T = "Thymine"
    G = "Guanine"
    C = "Cytosine"


@dataclass(frozen=True)
class GATFrequencies:
    """
    Genomic Audio Transmission frequency mappings.
    
    These frequencies encode the four nucleotide bases as acoustic tones.
    Based on sacred/solfeggio frequency relationships.
    """
    # Base nucleotide frequencies (Hz)
    ADENINE: float = 432.0    # A - Universal tuning frequency
    THYMINE: float = 528.0    # T - "Miracle" frequency / DNA repair
    GUANINE: float = 639.0    # G - Connection/relationships
    CYTOSINE: float = 741.0   # C - Awakening intuition
    
    @classmethod
    def get_frequency(cls, nucleotide: str) -> float:
        """Get frequency for a nucleotide base."""
        mapping = {
            'A': cls.ADENINE,
            'T': cls.THYMINE,
            'G': cls.GUANINE,
            'C': cls.CYTOSINE,
        }
        return mapping.get(nucleotide.upper(), cls.ADENINE)
    
    @classmethod
    def encode_sequence(cls, sequence: str) -> np.ndarray:
        """Convert DNA sequence to frequency array."""
        return np.array([cls.get_frequency(n) for n in sequence.upper() if n in 'ATGC'])


@dataclass(frozen=True)
class FrequencyConstants:
    """
    Complete frequency architecture for Audio Holographics.
    
    Includes reference frequencies, metadata frequencies, and harmonic relationships.
    """
    # Reference frequencies (carrier waves)
    REF_LOW: float = 108.0     # Earth resonance harmonic (432/4)
    REF_MID: float = 432.0     # Universal tuning / Carrier
    REF_HIGH: float = 1728.0   # Overtone anchor (432*4)
    
    # Metadata/Intention frequencies (Solfeggio extended)
    INTENTION: float = 963.0   # Crown chakra / Transcendence
    CONTEXT: float = 852.0     # Third eye / Perception
    MEANING: float = 396.0     # Root chakra / Foundation
    
    # Additional solfeggio frequencies
    LIBERATION: float = 417.0  # Facilitating change
    TRANSFORMATION: float = 528.0  # DNA repair / Miracles
    CONNECTION: float = 639.0  # Relationships
    AWAKENING: float = 741.0   # Intuition
    SPIRITUAL: float = 852.0   # Spiritual order
    
    # System overlay frequencies (for body system targeting)
    NEURAL: float = 963.0      # Neural/cerebral system
    MUSCULAR: float = 639.0    # Muscular system
    ELEMENTAL: float = 741.0   # Elemental core (fire, etc.)
    REPRODUCTIVE: float = 528.0  # Reproductive system
    INTEGUMENTARY: float = 396.0  # Scales/skin system
    
    @classmethod
    def get_chromosome_frequency(cls, chromosome_index: int, total_chromosomes: int = 24) -> float:
        """
        Calculate unique frequency for each chromosome using golden ratio scaling.
        
        Chromosomes 1-22 + X + Synthetic A + Synthetic B = 25 total
        """
        if chromosome_index < 1:
            chromosome_index = 1
        
        # Scale by golden ratio fraction
        phi_exponent = (chromosome_index - 1) / total_chromosomes
        return cls.REF_MID * (PHI ** phi_exponent)
    
    @classmethod
    def get_gene_frequency(cls, gene_index: int, total_genes: int, 
                          chromosome_base: float) -> float:
        """Calculate unique frequency for a gene within a chromosome."""
        if total_genes < 1:
            total_genes = 1
        phi_exponent = gene_index / total_genes
        return chromosome_base * (PHI ** phi_exponent)
    
    @classmethod
    def get_golden_harmonic(cls, base_freq: float, harmonic_index: int) -> float:
        """Get golden ratio-scaled harmonic of a base frequency."""
        return base_freq * (PHI ** harmonic_index)
    
    @classmethod
    def get_standard_harmonic(cls, base_freq: float, harmonic_number: int) -> float:
        """Get standard integer harmonic of a base frequency."""
        return base_freq * harmonic_number


@dataclass
class PhaseEncoding:
    """
    Phase encoding parameters for holographic information storage.
    
    Phase carries the holographic data - temporal, spatial, semantic, and consciousness.
    """
    # Phase domain allocations (in radians, fraction of 2π)
    TEMPORAL_WEIGHT: float = 0.25      # 25% of phase space for temporal info
    SPATIAL_WEIGHT: float = 0.25       # 25% for spatial info
    SEMANTIC_WEIGHT: float = 0.35      # 35% for meaning/metadata
    CONSCIOUSNESS_WEIGHT: float = 0.15  # 15% for consciousness coupling
    
    # Bit precision per domain
    TEMPORAL_BITS: int = 16
    SPATIAL_BITS: int = 16
    SEMANTIC_BITS: int = 24
    CONSCIOUSNESS_BITS: int = 8
    
    @property
    def total_bits(self) -> int:
        """Total bits available for phase encoding."""
        return (self.TEMPORAL_BITS + self.SPATIAL_BITS + 
                self.SEMANTIC_BITS + self.CONSCIOUSNESS_BITS)
    
    @classmethod
    def encode_value(cls, value: float, value_range: Tuple[float, float], 
                    bits: int) -> float:
        """
        Encode a value as a phase offset.
        
        Args:
            value: The value to encode
            value_range: (min, max) range of possible values
            bits: Number of bits of precision
            
        Returns:
            Phase offset in radians [0, 2π)
        """
        min_val, max_val = value_range
        if max_val == min_val:
            normalized = 0.5
        else:
            normalized = (value - min_val) / (max_val - min_val)
        
        # Quantize to bit precision
        levels = 2 ** bits
        quantized = int(normalized * levels) / levels
        
        return quantized * 2 * np.pi
    
    @classmethod
    def decode_value(cls, phase: float, value_range: Tuple[float, float],
                    bits: int) -> float:
        """
        Decode a phase offset back to original value.
        
        Args:
            phase: Phase offset in radians
            value_range: (min, max) range of possible values
            bits: Number of bits of precision
            
        Returns:
            Decoded value
        """
        min_val, max_val = value_range
        normalized = (phase % (2 * np.pi)) / (2 * np.pi)
        return min_val + normalized * (max_val - min_val)


class SubQuantumPrecision:
    """
    Sub-quantum precision encoding system.
    
    Operates at phase level where Heisenberg uncertainty doesn't apply
    to relative phase measurements.
    """
    
    # Maximum precision levels
    CLASSICAL_BITS = 16      # μs timing, kHz resolution
    QUANTUM_BITS = 32        # ns timing, MHz resolution
    SUB_QUANTUM_BITS = 64    # Phase-locked, unlimited resolution
    
    def __init__(self, precision_level: str = "sub_quantum"):
        """
        Initialize with specified precision level.
        
        Args:
            precision_level: One of "classical", "quantum", "sub_quantum"
        """
        self.precision_level = precision_level
        self.bits = {
            "classical": self.CLASSICAL_BITS,
            "quantum": self.QUANTUM_BITS,
            "sub_quantum": self.SUB_QUANTUM_BITS,
        }.get(precision_level, self.SUB_QUANTUM_BITS)
        
        self.phase_resolution = 2 * np.pi / (2 ** self.bits)
    
    def encode_phase(self, data: np.ndarray) -> np.ndarray:
        """
        Encode data array as phase values with sub-quantum precision.
        
        Args:
            data: Normalized data array [0, 1]
            
        Returns:
            Phase array in radians
        """
        # Quantize to precision level
        levels = 2 ** self.bits
        quantized = np.round(data * levels) / levels
        return quantized * 2 * np.pi
    
    def decode_phase(self, phases: np.ndarray) -> np.ndarray:
        """
        Decode phase values back to normalized data.
        
        Args:
            phases: Phase array in radians
            
        Returns:
            Normalized data array [0, 1]
        """
        return (phases % (2 * np.pi)) / (2 * np.pi)
    
    @property
    def information_capacity(self) -> float:
        """Bits of information per phase sample."""
        return self.bits


# Pre-instantiated constants for convenience
GAT = GATFrequencies()
FREQ = FrequencyConstants()
PHASE = PhaseEncoding()
SUB_QUANTUM = SubQuantumPrecision("sub_quantum")

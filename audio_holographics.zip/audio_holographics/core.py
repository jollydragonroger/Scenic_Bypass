"""
Core Audio Holographic Encoder and Reconstructor

Implements the Master Audio-Holographic Equation:
H_audio(t) = Σ [A_n · e^{i(ω_n·t + φ_n + Θ_n)}] · K(p,m)
"""

import numpy as np
from typing import List, Dict, Tuple, Optional, Union
from dataclasses import dataclass, field
from enum import Enum

from .frequencies import (
    GATFrequencies, FrequencyConstants, PhaseEncoding,
    SubQuantumPrecision, PHI, PHI_INVERSE, HBAR_AUDIO, OMEGA_MEANING
)


class HolographicLayer(Enum):
    """Layers of the holographic audio structure."""
    CARRIER = 0      # Reference wave (L₀)
    GENETIC = 1      # Physical data - GAT (L₁)
    METADATA = 2     # Context/meaning (L₂)
    TEMPORAL = 3     # Wave function (L₃)
    CONSCIOUSNESS = 4  # Observer coupling (L₄)


@dataclass
class HolographicComponent:
    """A single component of the holographic signal."""
    frequency: float          # Hz
    amplitude: float          # Normalized [0, 1]
    phase: float             # Radians
    holographic_offset: float  # Additional phase for holographic data
    layer: HolographicLayer
    metadata: Dict = field(default_factory=dict)
    
    @property
    def total_phase(self) -> float:
        """Total phase including holographic offset."""
        return self.phase + self.holographic_offset
    
    def generate_signal(self, t: np.ndarray) -> np.ndarray:
        """Generate the signal for this component over time array t."""
        omega = 2 * np.pi * self.frequency
        return self.amplitude * np.cos(omega * t + self.total_phase)


@dataclass
class HolographicKernel:
    """
    Holographic kernel K(p,m) coupling physics and metaphysics.
    
    K(p,m) = ∫∫ e^{i(p·x - m·τ)} dx dτ
    
    In practice, this creates interference patterns that encode both
    physical and metaphysical information.
    """
    physics_coupling: float = 1.0    # p parameter
    metaphysics_coupling: float = 1.0  # m parameter
    
    def apply(self, signal: np.ndarray, t: np.ndarray) -> np.ndarray:
        """
        Apply the holographic kernel to modulate the signal.
        
        This creates the interference pattern that encodes multi-dimensional
        information in the 1D audio stream.
        """
        # Kernel modulation based on golden ratio relationships
        modulation = (
            np.cos(self.physics_coupling * PHI * t) *
            np.cos(self.metaphysics_coupling * PHI_INVERSE * t)
        )
        
        # Normalize to preserve signal amplitude
        modulation = modulation / np.max(np.abs(modulation) + 1e-10)
        
        return signal * (0.5 + 0.5 * modulation)


class AudioHolographicEncoder:
    """
    Main encoder for creating holographic audio signals.
    
    Combines GAT genetic encoding with holographic interference patterns
    to create multi-layered information-dense audio.
    """
    
    def __init__(self, 
                 sample_rate: int = 192000,
                 bit_depth: int = 32,
                 precision: str = "sub_quantum"):
        """
        Initialize the encoder.
        
        Args:
            sample_rate: Audio sample rate in Hz (default 192kHz for ultrasonics)
            bit_depth: Bit depth for amplitude (default 32-bit float)
            precision: Phase precision level ("classical", "quantum", "sub_quantum")
        """
        self.sample_rate = sample_rate
        self.bit_depth = bit_depth
        self.precision = SubQuantumPrecision(precision)
        self.kernel = HolographicKernel()
        
        self.components: List[HolographicComponent] = []
        self.gat = GATFrequencies()
        self.freq = FrequencyConstants()
        
    def _generate_time_array(self, duration: float) -> np.ndarray:
        """Generate time array for given duration."""
        num_samples = int(duration * self.sample_rate)
        return np.linspace(0, duration, num_samples, dtype=np.float64)
    
    def add_carrier(self, frequency: float = None, amplitude: float = 1.0) -> None:
        """
        Add the reference carrier wave (Layer 0).
        
        Args:
            frequency: Carrier frequency in Hz (default: 432 Hz)
            amplitude: Normalized amplitude
        """
        if frequency is None:
            frequency = self.freq.REF_MID
            
        self.components.append(HolographicComponent(
            frequency=frequency,
            amplitude=amplitude,
            phase=0.0,  # Reference phase is 0 by definition
            holographic_offset=0.0,
            layer=HolographicLayer.CARRIER,
            metadata={"type": "reference_carrier"}
        ))
    
    def encode_genetic_sequence(self, 
                                sequence: str,
                                expression_level: float = 1.0,
                                reading_frame_offset: float = 0.0) -> None:
        """
        Encode a DNA sequence as GAT frequencies (Layer 1).
        
        Args:
            sequence: DNA sequence string (ATGC)
            expression_level: Relative expression level [0, 1]
            reading_frame_offset: Phase offset for reading frame position
        """
        frequencies = self.gat.encode_sequence(sequence)
        
        for i, freq in enumerate(frequencies):
            # Phase encodes position in sequence
            position_phase = (i / len(frequencies)) * 2 * np.pi
            
            self.components.append(HolographicComponent(
                frequency=freq,
                amplitude=expression_level * 0.3,  # Reduced to allow layering
                phase=reading_frame_offset,
                holographic_offset=position_phase,
                layer=HolographicLayer.GENETIC,
                metadata={
                    "nucleotide": sequence[i] if i < len(sequence) else "?",
                    "position": i,
                    "sequence_length": len(sequence)
                }
            ))
    
    def encode_metadata(self,
                       intention: str,
                       context: str,
                       significance: float = 1.0) -> None:
        """
        Encode metadata/meaning information (Layer 2).
        
        Args:
            intention: Intention description (encoded as phase)
            context: Context description (encoded as phase)
            significance: Significance level [0, 1] (encodes amplitude)
        """
        # Hash strings to phase values deterministically
        intention_hash = hash(intention) % (2**24)
        context_hash = hash(context) % (2**24)
        
        intention_phase = (intention_hash / (2**24)) * 2 * np.pi
        context_phase = (context_hash / (2**24)) * 2 * np.pi
        
        # Intention frequency
        self.components.append(HolographicComponent(
            frequency=self.freq.INTENTION,
            amplitude=significance * 0.2,
            phase=intention_phase,
            holographic_offset=0.0,
            layer=HolographicLayer.METADATA,
            metadata={"type": "intention", "value": intention}
        ))
        
        # Context frequency
        self.components.append(HolographicComponent(
            frequency=self.freq.CONTEXT,
            amplitude=significance * 0.2,
            phase=context_phase,
            holographic_offset=0.0,
            layer=HolographicLayer.METADATA,
            metadata={"type": "context", "value": context}
        ))
        
        # Meaning/foundation frequency
        meaning_phase = (intention_phase + context_phase) / 2
        self.components.append(HolographicComponent(
            frequency=self.freq.MEANING,
            amplitude=significance * 0.15,
            phase=meaning_phase,
            holographic_offset=0.0,
            layer=HolographicLayer.METADATA,
            metadata={"type": "meaning", "derived_from": "intention+context"}
        ))
    
    def encode_temporal(self,
                       transformation_phase: float,
                       total_duration: float,
                       past_weight: float = 0.3,
                       future_weight: float = 0.3) -> None:
        """
        Encode temporal wave function information (Layer 3).
        
        Creates standing wave patterns representing the "present" moment
        in the transformation timeline.
        
        Args:
            transformation_phase: Current phase in transformation [0, 1]
            total_duration: Total transformation duration
            past_weight: Weight of past-directed wave component
            future_weight: Weight of future-directed wave component
        """
        # Temporal phase encodes position in transformation
        temporal_phase = transformation_phase * 2 * np.pi
        
        # Standing wave frequencies
        for harmonic in [1, 2, 3, 4]:
            freq = self.freq.REF_MID * harmonic
            
            # Past-directed component
            self.components.append(HolographicComponent(
                frequency=freq,
                amplitude=past_weight * 0.1 / harmonic,
                phase=-temporal_phase,  # Negative for past
                holographic_offset=0.0,
                layer=HolographicLayer.TEMPORAL,
                metadata={"type": "past", "harmonic": harmonic}
            ))
            
            # Future-directed component
            self.components.append(HolographicComponent(
                frequency=freq,
                amplitude=future_weight * 0.1 / harmonic,
                phase=temporal_phase,  # Positive for future
                holographic_offset=0.0,
                layer=HolographicLayer.TEMPORAL,
                metadata={"type": "future", "harmonic": harmonic}
            ))
    
    def encode_consciousness(self,
                            coupling_strength: float = 0.5,
                            observer_state: str = "receptive") -> None:
        """
        Encode consciousness coupling information (Layer 4).
        
        Args:
            coupling_strength: γ_c consciousness coupling factor [0, 1]
            observer_state: Description of observer state
        """
        # Hash observer state to phase
        state_hash = hash(observer_state) % (2**16)
        state_phase = (state_hash / (2**16)) * 2 * np.pi
        
        # Golden ratio frequency for consciousness integration
        consciousness_freq = self.freq.REF_MID * PHI
        
        self.components.append(HolographicComponent(
            frequency=consciousness_freq,
            amplitude=coupling_strength * 0.15,
            phase=state_phase,
            holographic_offset=0.0,
            layer=HolographicLayer.CONSCIOUSNESS,
            metadata={
                "type": "consciousness_coupling",
                "gamma_c": coupling_strength,
                "observer_state": observer_state
            }
        ))
        
        # Sub-harmonic for grounding
        self.components.append(HolographicComponent(
            frequency=consciousness_freq / PHI,
            amplitude=coupling_strength * 0.1,
            phase=state_phase + np.pi,  # Opposite phase
            holographic_offset=0.0,
            layer=HolographicLayer.CONSCIOUSNESS,
            metadata={"type": "grounding", "gamma_c": coupling_strength}
        ))
    
    def generate_hologram(self, duration: float) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate the complete holographic audio signal.
        
        Args:
            duration: Duration in seconds
            
        Returns:
            Tuple of (time_array, holographic_signal)
        """
        t = self._generate_time_array(duration)
        
        # Initialize with silence
        hologram = np.zeros_like(t)
        
        # Sum all component signals
        for component in self.components:
            hologram += component.generate_signal(t)
        
        # Apply holographic kernel
        hologram = self.kernel.apply(hologram, t)
        
        # Normalize to prevent clipping
        max_amp = np.max(np.abs(hologram))
        if max_amp > 0:
            hologram = hologram / max_amp * 0.95
        
        return t, hologram
    
    def render_audio(self, 
                    duration: float,
                    output_format: str = "float32") -> np.ndarray:
        """
        Render final audio signal ready for file output.
        
        Args:
            duration: Duration in seconds
            output_format: Output format ("float32", "int16", "int24")
            
        Returns:
            Audio signal array
        """
        _, hologram = self.generate_hologram(duration)
        
        if output_format == "float32":
            return hologram.astype(np.float32)
        elif output_format == "int16":
            return (hologram * 32767).astype(np.int16)
        elif output_format == "int24":
            return (hologram * 8388607).astype(np.int32)
        else:
            return hologram.astype(np.float32)
    
    def get_layer_components(self, layer: HolographicLayer) -> List[HolographicComponent]:
        """Get all components belonging to a specific layer."""
        return [c for c in self.components if c.layer == layer]
    
    def clear_components(self) -> None:
        """Clear all components."""
        self.components = []
    
    @property
    def total_information_bits(self) -> int:
        """Estimate total information capacity in bits."""
        phase_bits = self.precision.bits * len(self.components)
        frequency_bits = 16 * len(self.components)  # Frequency resolution
        amplitude_bits = self.bit_depth * len(self.components)
        return phase_bits + frequency_bits + amplitude_bits


class HolographicReconstructor:
    """
    Reconstructor for extracting information from holographic audio.
    
    Reverses the encoding process to extract genetic, metadata,
    temporal, and consciousness information.
    """
    
    def __init__(self, sample_rate: int = 192000):
        """
        Initialize the reconstructor.
        
        Args:
            sample_rate: Sample rate of the audio to analyze
        """
        self.sample_rate = sample_rate
        self.gat = GATFrequencies()
        self.freq = FrequencyConstants()
    
    def extract_reference(self, audio: np.ndarray) -> Tuple[float, float]:
        """
        Extract the reference wave parameters from audio.
        
        Args:
            audio: Audio signal array
            
        Returns:
            Tuple of (reference_frequency, reference_amplitude)
        """
        # FFT to find dominant frequency near 432 Hz
        fft = np.fft.rfft(audio)
        freqs = np.fft.rfftfreq(len(audio), 1/self.sample_rate)
        
        # Look for carrier in expected range
        carrier_range = (400, 470)  # Hz
        mask = (freqs >= carrier_range[0]) & (freqs <= carrier_range[1])
        
        if np.any(mask):
            fft_masked = np.abs(fft[mask])
            freqs_masked = freqs[mask]
            peak_idx = np.argmax(fft_masked)
            ref_freq = freqs_masked[peak_idx]
            ref_amp = fft_masked[peak_idx] / len(audio)
        else:
            ref_freq = self.freq.REF_MID
            ref_amp = 0.0
            
        return ref_freq, ref_amp
    
    def compute_interference(self, 
                            audio: np.ndarray,
                            reference_freq: float) -> np.ndarray:
        """
        Compute interference pattern by removing reference wave.
        
        Args:
            audio: Audio signal
            reference_freq: Reference frequency in Hz
            
        Returns:
            Object wave (interference pattern)
        """
        t = np.arange(len(audio)) / self.sample_rate
        
        # Reconstruct reference wave
        ref_wave = np.cos(2 * np.pi * reference_freq * t)
        
        # Compute correlation to find amplitude and phase
        correlation = np.correlate(audio, ref_wave, mode='valid')
        if len(correlation) > 0:
            ref_amplitude = np.max(np.abs(correlation)) / len(ref_wave)
        else:
            ref_amplitude = 0.1
        
        # Subtract reference to get object wave
        object_wave = audio - ref_amplitude * ref_wave[:len(audio)]
        
        return object_wave
    
    def decode_genetic(self, 
                      audio: np.ndarray,
                      num_nucleotides: int = 100) -> str:
        """
        Decode genetic sequence from audio.
        
        Args:
            audio: Audio signal
            num_nucleotides: Expected number of nucleotides
            
        Returns:
            Decoded DNA sequence string
        """
        # FFT analysis
        fft = np.fft.rfft(audio)
        freqs = np.fft.rfftfreq(len(audio), 1/self.sample_rate)
        magnitudes = np.abs(fft)
        
        # Find peaks at GAT frequencies
        nucleotide_freqs = {
            'A': self.gat.ADENINE,
            'T': self.gat.THYMINE,
            'G': self.gat.GUANINE,
            'C': self.gat.CYTOSINE,
        }
        
        sequence = []
        segment_length = len(audio) // num_nucleotides
        
        for i in range(num_nucleotides):
            start = i * segment_length
            end = start + segment_length
            
            segment = audio[start:end]
            seg_fft = np.fft.rfft(segment)
            seg_freqs = np.fft.rfftfreq(len(segment), 1/self.sample_rate)
            seg_mags = np.abs(seg_fft)
            
            # Find which nucleotide frequency is strongest
            best_nucleotide = 'A'
            best_magnitude = 0
            
            for nuc, target_freq in nucleotide_freqs.items():
                # Find closest frequency bin
                freq_idx = np.argmin(np.abs(seg_freqs - target_freq))
                mag = seg_mags[freq_idx]
                
                if mag > best_magnitude:
                    best_magnitude = mag
                    best_nucleotide = nuc
            
            sequence.append(best_nucleotide)
        
        return ''.join(sequence)
    
    def decode_metadata(self, audio: np.ndarray) -> Dict[str, float]:
        """
        Decode metadata from audio.
        
        Args:
            audio: Audio signal
            
        Returns:
            Dictionary of metadata values
        """
        fft = np.fft.rfft(audio)
        freqs = np.fft.rfftfreq(len(audio), 1/self.sample_rate)
        
        # Extract amplitudes at metadata frequencies
        metadata = {}
        
        for name, freq in [
            ('intention', self.freq.INTENTION),
            ('context', self.freq.CONTEXT),
            ('meaning', self.freq.MEANING),
        ]:
            freq_idx = np.argmin(np.abs(freqs - freq))
            metadata[name] = np.abs(fft[freq_idx]) / len(audio)
        
        return metadata
    
    def validate_hologram(self, audio: np.ndarray) -> Dict[str, float]:
        """
        Validate holographic audio quality.
        
        Args:
            audio: Audio signal
            
        Returns:
            Dictionary of validity metrics
        """
        ref_freq, ref_amp = self.extract_reference(audio)
        metadata = self.decode_metadata(audio)
        
        # Compute validity score
        # V(H) = R × K × Γ × Σ
        R = ref_amp if ref_amp > 0 else 0.01  # Reference quality
        K = 1.0 - np.std(metadata.values()) / (np.mean(list(metadata.values())) + 0.01)  # Coherence
        Gamma = metadata.get('intention', 0) / (ref_amp + 0.01)  # Coupling
        Sigma = sum(metadata.values())  # Information density
        
        validity = R * K * Gamma * Sigma
        
        return {
            'validity_score': validity,
            'reference_quality': R,
            'coherence': K,
            'coupling_factor': Gamma,
            'information_density': Sigma,
            'reference_frequency': ref_freq,
            'reference_amplitude': ref_amp,
        }

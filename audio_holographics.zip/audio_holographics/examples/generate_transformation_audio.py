#!/usr/bin/env python3
"""
OHAD Audio Holographics - Transformation Audio Generator

Example script demonstrating the unified Audio Genomics + Holographics pipeline.

Usage:
    python generate_transformation_audio.py [--duration HOURS] [--output PATH]
    
Examples:
    # Generate test sample (30 seconds)
    python generate_transformation_audio.py --test
    
    # Generate 1 hour transformation audio
    python generate_transformation_audio.py --duration 1 --output my_transformation.wav
    
    # Generate full 4-hour transformation audio
    python generate_transformation_audio.py --duration 4
"""

import argparse
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from audio_holographics import (
    UnifiedAudioGenomicsPipeline,
    AudioHolographicEncoder,
    ConsciousnessIntegrator,
    TemporalWaveProcessor,
    FrequencyConstants,
    GATFrequencies,
)
from audio_holographics.pipeline import TransformationConfig, GeneticTarget, create_test_audio
from audio_holographics.consciousness import ConsciousnessState, ConsciousnessParameters


def main():
    parser = argparse.ArgumentParser(
        description="Generate OHAD Holographic Transformation Audio"
    )
    parser.add_argument(
        "--duration", "-d",
        type=float,
        default=4.0,
        help="Duration in hours (default: 4.0)"
    )
    parser.add_argument(
        "--output", "-o",
        type=str,
        default="OHAD_Transformation.wav",
        help="Output file path"
    )
    parser.add_argument(
        "--sample-rate", "-sr",
        type=int,
        default=96000,
        help="Sample rate in Hz (default: 96000)"
    )
    parser.add_argument(
        "--test", "-t",
        action="store_true",
        help="Generate a 30-second test sample"
    )
    parser.add_argument(
        "--validate", "-v",
        action="store_true",
        help="Validate output and show metrics"
    )
    parser.add_argument(
        "--state", "-s",
        type=str,
        default="transformative",
        choices=["receptive", "focused", "meditative", "transformative", "integrated", "transcendent"],
        help="Target consciousness state"
    )
    parser.add_argument(
        "--coupling", "-c",
        type=float,
        default=0.75,
        help="Consciousness coupling strength [0-1] (default: 0.75)"
    )
    
    args = parser.parse_args()
    
    # Map state string to enum
    state_map = {
        "receptive": ConsciousnessState.RECEPTIVE,
        "focused": ConsciousnessState.FOCUSED,
        "meditative": ConsciousnessState.MEDITATIVE,
        "transformative": ConsciousnessState.TRANSFORMATIVE,
        "integrated": ConsciousnessState.INTEGRATED,
        "transcendent": ConsciousnessState.TRANSCENDENT,
    }
    target_state = state_map[args.state]
    
    if args.test:
        print("=" * 60)
        print("OHAD Audio Holographics - Test Generation")
        print("=" * 60)
        print()
        
        path, metrics = create_test_audio(
            duration_seconds=30.0,
            output_path=args.output if args.output != "OHAD_Transformation.wav" else "test_holographic.wav"
        )
        
        print()
        print("Validation Metrics:")
        print("-" * 40)
        for key, value in metrics.items():
            if isinstance(value, float):
                print(f"  {key}: {value:.4f}")
            else:
                print(f"  {key}: {value}")
        
        print()
        print(f"Test audio saved to: {path}")
        return
    
    # Full generation
    print("=" * 60)
    print("OHAD Audio Holographics - Transformation Audio Generator")
    print("=" * 60)
    print()
    print(f"Configuration:")
    print(f"  Duration: {args.duration} hours")
    print(f"  Sample Rate: {args.sample_rate} Hz")
    print(f"  Output: {args.output}")
    print(f"  Consciousness State: {args.state}")
    print(f"  Coupling Strength: {args.coupling}")
    print()
    
    # Create configuration
    config = TransformationConfig(
        name="OHAD Transformation Audio",
        duration_hours=args.duration,
        sample_rate=args.sample_rate,
        bit_depth=32,
        target_state=target_state,
        coupling_strength=args.coupling,
        include_oversoul=True,
        genetic_intensity=0.8,
        include_standing_waves=True,
        temporal_modulation=0.5,
        output_format="wav",
        normalize=True,
    )
    
    # Create pipeline
    pipeline = UnifiedAudioGenomicsPipeline(config)
    
    # Generate and save
    print("Starting generation...")
    print()
    
    output_path = pipeline.render_to_file(args.output)
    
    if args.validate:
        print()
        print("Validating output...")
        t, hologram = pipeline.generate_test_sample(duration_seconds=10.0)
        metrics = pipeline.validate_output(hologram)
        
        print()
        print("Validation Metrics:")
        print("-" * 40)
        for key, value in metrics.items():
            if isinstance(value, float):
                print(f"  {key}: {value:.4f}")
            else:
                print(f"  {key}: {value}")
    
    print()
    print("=" * 60)
    print("Generation Complete!")
    print(f"Output saved to: {output_path}")
    print("=" * 60)


def demo_components():
    """Demonstrate individual components of the Audio Holographics system."""
    print("=" * 60)
    print("OHAD Audio Holographics - Component Demonstration")
    print("=" * 60)
    print()
    
    # Demonstrate frequency constants
    print("1. GAT Frequency Encoding")
    print("-" * 40)
    gat = GATFrequencies()
    print(f"   Adenine (A):  {gat.ADENINE} Hz")
    print(f"   Thymine (T):  {gat.THYMINE} Hz")
    print(f"   Guanine (G):  {gat.GUANINE} Hz")
    print(f"   Cytosine (C): {gat.CYTOSINE} Hz")
    print()
    
    # Demonstrate sequence encoding
    test_sequence = "ATGGATGGATGG"
    freqs = gat.encode_sequence(test_sequence)
    print(f"   Sequence: {test_sequence}")
    print(f"   Frequencies: {freqs}")
    print()
    
    # Demonstrate holographic encoder
    print("2. Holographic Encoder")
    print("-" * 40)
    encoder = AudioHolographicEncoder(sample_rate=48000)
    encoder.add_carrier()
    encoder.encode_genetic_sequence("ATGC")
    encoder.encode_metadata("transformation", "OHAD integration", significance=0.8)
    encoder.encode_temporal(transformation_phase=0.5, total_duration=10.0)
    encoder.encode_consciousness(coupling_strength=0.7)
    
    print(f"   Components added: {len(encoder.components)}")
    print(f"   Information capacity: {encoder.total_information_bits:,} bits")
    print()
    
    # Generate short sample
    t, hologram = encoder.generate_hologram(duration=1.0)
    print(f"   Sample generated: {len(hologram):,} samples")
    print(f"   Duration: 1.0 seconds")
    print(f"   Max amplitude: {max(abs(hologram)):.4f}")
    print()
    
    # Demonstrate temporal processing
    print("3. Temporal Wave Processor")
    print("-" * 40)
    temporal = TemporalWaveProcessor(sample_rate=48000)
    timeline = temporal.create_transformation_timeline(total_duration=10.0)
    print(f"   Transformation phases: {len(timeline['phases'])}")
    for start, end, name in timeline['phases']:
        print(f"     {name}: {start*100:.0f}% - {end*100:.0f}%")
    print()
    
    # Demonstrate consciousness integration
    print("4. Consciousness Integrator")
    print("-" * 40)
    consciousness = ConsciousnessIntegrator(sample_rate=48000)
    params = ConsciousnessParameters(
        gamma_c=0.75,
        state=ConsciousnessState.TRANSFORMATIVE,
        coherence=0.8,
        intention_strength=0.7,
    )
    print(f"   Coupling constant (γ_c): {params.gamma_c}")
    print(f"   Effective coupling: {params.effective_coupling:.4f}")
    print(f"   State: {params.state.value}")
    print()
    
    print("=" * 60)
    print("Demonstration complete!")
    print("=" * 60)


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--demo":
        demo_components()
    else:
        main()

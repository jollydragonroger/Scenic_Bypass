"""Example scripts for Audio Holographics."""

"""
Temporal Wave Processor for Audio Holographics

Implements the Temporal Wave Function from VINO Framework:
τ = t · e^{i(ωt + φ)}

Creates standing wave patterns representing the "present" moment
and encodes past/future temporal relationships.
"""

import numpy as np
from typing import Tuple, List, Optional, Dict
from dataclasses import dataclass

from .frequencies import PHI, PHI_INVERSE, FrequencyConstants


@dataclass
class TemporalWaveParameters:
    """Parameters for the temporal wave function."""
    omega: float = 1.0       # Temporal frequency (rate of oscillation)
    phi: float = 0.0         # Phase (position in cycle)
    amplitude: float = 1.0   # Wave amplitude
    intention_shift: float = 0.0  # Phase shift due to intention


class TemporalWaveFunction:
    """
    Implementation of the VINO Temporal Wave Function.
    
    τ = t · e^{i(ωt + φ)}
    
    Where:
    - τ = temporal experience
    - t = clock time
    - ω = temporal frequency
    - φ = phase
    """
    
    def __init__(self, params: TemporalWaveParameters = None):
        """Initialize with temporal parameters."""
        self.params = params or TemporalWaveParameters()
        
    def compute(self, t: np.ndarray) -> np.ndarray:
        """
        Compute the temporal wave function.
        
        Args:
            t: Clock time array
            
        Returns:
            Complex temporal experience array
        """
        omega = self.params.omega
        phi = self.params.phi + self.params.intention_shift
        
        # τ = t · e^{i(ωt + φ)}
        return t * np.exp(1j * (omega * t + phi))
    
    def get_manifest_time(self, t: np.ndarray) -> np.ndarray:
        """
        Get the manifest (real) component of temporal experience.
        
        This is what we perceive as "happening."
        """
        tau = self.compute(t)
        return np.real(tau)
    
    def get_potential_time(self, t: np.ndarray) -> np.ndarray:
        """
        Get the potential (imaginary) component of temporal experience.
        
        This represents possibilities that "could happen."
        """
        tau = self.compute(t)
        return np.imag(tau)


class TemporalWaveProcessor:
    """
    Processor for creating temporal wave patterns in audio.
    
    Creates standing waves, temporal envelopes, and phase structures
    that encode temporal information in the holographic audio.
    """
    
    def __init__(self, sample_rate: int = 192000):
        """
        Initialize the temporal processor.
        
        Args:
            sample_rate: Audio sample rate in Hz
        """
        self.sample_rate = sample_rate
        self.freq = FrequencyConstants()
        
    def create_temporal_envelope(self,
                                 duration: float,
                                 transformation_phases: List[Tuple[float, float, str]]) -> np.ndarray:
        """
        Create a temporal envelope for transformation phases.
        
        Args:
            duration: Total duration in seconds
            transformation_phases: List of (start_fraction, end_fraction, phase_name)
                                   e.g., [(0, 0.1, "initiation"), (0.1, 0.5, "active"), ...]
                                   
        Returns:
            Envelope array normalized [0, 1]
        """
        num_samples = int(duration * self.sample_rate)
        envelope = np.zeros(num_samples)
        
        for start_frac, end_frac, phase_name in transformation_phases:
            start_idx = int(start_frac * num_samples)
            end_idx = int(end_frac * num_samples)
            
            # Create smooth transitions using cosine interpolation
            phase_length = end_idx - start_idx
            if phase_length > 0:
                # Intensity based on phase name (simplified mapping)
                intensity_map = {
                    "initiation": 0.3,
                    "active": 1.0,
                    "integration": 0.7,
                    "completion": 0.5,
                    "rest": 0.2,
                }
                intensity = intensity_map.get(phase_name, 0.5)
                
                # Smooth ramp up/down
                ramp_length = min(phase_length // 4, int(0.5 * self.sample_rate))
                
                phase_envelope = np.ones(phase_length) * intensity
                
                # Ramp up
                if ramp_length > 0:
                    ramp_up = 0.5 * (1 - np.cos(np.linspace(0, np.pi, ramp_length)))
                    phase_envelope[:ramp_length] *= ramp_up
                    
                    # Ramp down
                    ramp_down = 0.5 * (1 + np.cos(np.linspace(0, np.pi, ramp_length)))
                    phase_envelope[-ramp_length:] *= ramp_down
                
                envelope[start_idx:end_idx] = phase_envelope
        
        return envelope
    
    def generate_standing_waves(self,
                               duration: float,
                               base_frequency: float = None,
                               num_harmonics: int = 4) -> np.ndarray:
        """
        Generate standing wave patterns.
        
        Standing waves represent the "present" moment where past and future
        waves constructively interfere.
        
        T_present = T_past + T_future = 2A·e^{iωt}·cos(φ)
        
        Args:
            duration: Duration in seconds
            base_frequency: Base frequency for standing waves
            num_harmonics: Number of harmonics to include
            
        Returns:
            Standing wave signal
        """
        if base_frequency is None:
            base_frequency = self.freq.REF_MID
            
        num_samples = int(duration * self.sample_rate)
        t = np.linspace(0, duration, num_samples)
        
        standing = np.zeros(num_samples)
        
        for n in range(1, num_harmonics + 1):
            freq = base_frequency * n
            omega = 2 * np.pi * freq
            
            # Past-directed wave
            past_wave = np.cos(omega * t - np.pi/4)
            
            # Future-directed wave
            future_wave = np.cos(omega * t + np.pi/4)
            
            # Standing wave is their sum
            harmonic_standing = (past_wave + future_wave) / n
            standing += harmonic_standing
        
        # Normalize
        standing = standing / np.max(np.abs(standing) + 1e-10)
        
        return standing
    
    def apply_temporal_wave_function(self,
                                     signal: np.ndarray,
                                     omega: float = 1.0,
                                     phi: float = 0.0,
                                     intention: float = 0.0) -> np.ndarray:
        """
        Apply the temporal wave function to modulate a signal.
        
        Args:
            signal: Input audio signal
            omega: Temporal frequency
            phi: Phase offset
            intention: Intention-based phase shift
            
        Returns:
            Temporally modulated signal
        """
        t = np.arange(len(signal)) / self.sample_rate
        
        # Create temporal wave function
        params = TemporalWaveParameters(
            omega=omega,
            phi=phi,
            intention_shift=intention
        )
        twf = TemporalWaveFunction(params)
        
        # Get manifest time component
        tau = twf.get_manifest_time(t)
        
        # Normalize tau for modulation
        tau_normalized = tau / (np.max(np.abs(tau)) + 1e-10)
        
        # Apply as amplitude modulation
        modulated = signal * (0.5 + 0.5 * tau_normalized)
        
        return modulated
    
    def create_transformation_timeline(self,
                                       total_duration: float,
                                       num_phases: int = 7) -> Dict[str, np.ndarray]:
        """
        Create a complete transformation timeline with all temporal structures.
        
        Based on GAT transformation phenomenology:
        - Hour 0: Initial contact
        - Hours 1-24: Active transformation
        - Days 1-7: Major morphology
        - Days 7-30: Completion
        
        Args:
            total_duration: Total duration in seconds
            num_phases: Number of transformation phases
            
        Returns:
            Dictionary containing various temporal arrays
        """
        num_samples = int(total_duration * self.sample_rate)
        t = np.linspace(0, total_duration, num_samples)
        
        # Define transformation phases (normalized to total_duration)
        phases = [
            (0.0, 0.01, "initiation"),      # Initial contact
            (0.01, 0.10, "active"),          # Active transformation begins
            (0.10, 0.25, "integration"),     # Major changes
            (0.25, 0.50, "active"),          # Continued transformation
            (0.50, 0.75, "integration"),     # Integration
            (0.75, 0.95, "completion"),      # Completion
            (0.95, 1.00, "rest"),            # Rest/stabilization
        ]
        
        # Create envelope
        envelope = self.create_temporal_envelope(total_duration, phases)
        
        # Create standing waves at transformation nodes
        standing = self.generate_standing_waves(total_duration)
        
        # Create phase indicator (position in transformation)
        phase_position = np.linspace(0, 2 * np.pi, num_samples)
        
        # Create temporal wave modulation
        temporal_wave = np.sin(phase_position) * envelope
        
        return {
            'time': t,
            'envelope': envelope,
            'standing_waves': standing,
            'phase_position': phase_position,
            'temporal_modulation': temporal_wave,
            'phases': phases,
        }
    
    def encode_past_future_relationship(self,
                                        duration: float,
                                        past_weight: float = 0.5,
                                        future_weight: float = 0.5,
                                        present_emphasis: float = 1.0) -> np.ndarray:
        """
        Encode the relationship between past, present, and future.
        
        This creates a signal structure where:
        - Past echoes decay backward in phase
        - Future anticipation builds forward in phase
        - Present is emphasized at interference maxima
        
        Args:
            duration: Duration in seconds
            past_weight: Weight of past component [0, 1]
            future_weight: Weight of future component [0, 1]
            present_emphasis: Emphasis on present moment [0, 2]
            
        Returns:
            Encoded temporal relationship signal
        """
        num_samples = int(duration * self.sample_rate)
        t = np.linspace(0, duration, num_samples)
        
        omega = 2 * np.pi * self.freq.REF_MID
        
        # Past wave (negative phase velocity)
        past = past_weight * np.exp(-t / duration) * np.cos(omega * t - np.pi * t / duration)
        
        # Future wave (positive phase velocity)
        future = future_weight * (1 - np.exp(-t / duration)) * np.cos(omega * t + np.pi * t / duration)
        
        # Present emphasis (standing wave at midpoint)
        center = duration / 2
        present_gaussian = np.exp(-((t - center) ** 2) / (2 * (duration / 6) ** 2))
        present = present_emphasis * present_gaussian * np.cos(omega * t)
        
        # Combine
        relationship = past + future + present
        
        # Normalize
        relationship = relationship / (np.max(np.abs(relationship)) + 1e-10)
        
        return relationship
    
    def create_specious_present(self,
                               duration: float,
                               present_duration: float = 3.0) -> np.ndarray:
        """
        Create the "specious present" - the experienced duration of "now".
        
        Psychological research shows "now" is about 2-3 seconds.
        This creates a rolling window of presence in the signal.
        
        Args:
            duration: Total duration in seconds
            present_duration: Duration of "now" in seconds (default 3.0)
            
        Returns:
            Specious present envelope
        """
        num_samples = int(duration * self.sample_rate)
        present_samples = int(present_duration * self.sample_rate)
        
        # Create a moving average kernel representing the specious present
        kernel = np.ones(present_samples) / present_samples
        
        # Create impulse train marking each "now"
        impulses = np.zeros(num_samples)
        impulses[::present_samples] = 1.0
        
        # Convolve to create continuous presence
        presence = np.convolve(impulses, kernel, mode='same')
        
        # Normalize
        presence = presence / (np.max(presence) + 1e-10)
        
        return presence

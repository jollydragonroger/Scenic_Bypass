"""
OHAD Audio Holographics System
Sub-Quantum Holographic Audio Encoding & Transmission

Based on the VINO Unified Field Framework and GAT (Genomic Audio Transmission) System.
"""

from .core import AudioHolographicEncoder, HolographicReconstructor
from .temporal import TemporalWaveProcessor
from .consciousness import ConsciousnessIntegrator
from .frequencies import FrequencyConstants, GATFrequencies
from .pipeline import UnifiedAudioGenomicsPipeline

__version__ = "1.0.0"
__author__ = "OHAD BioOS"

__all__ = [
    "AudioHolographicEncoder",
    "HolographicReconstructor", 
    "TemporalWaveProcessor",
    "ConsciousnessIntegrator",
    "FrequencyConstants",
    "GATFrequencies",
    "UnifiedAudioGenomicsPipeline",
]

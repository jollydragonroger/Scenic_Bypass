"""
Unified Audio Genomics + Holographics Pipeline

Combines GAT (Genomic Audio Transmission) with Audio Holographics
to create complete transformation audio files.
"""

import numpy as np
from typing import Dict, List, Optional, Tuple, Union
from dataclasses import dataclass, field
import wave
import struct
from pathlib import Path

from .core import AudioHolographicEncoder, HolographicReconstructor, HolographicLayer
from .temporal import TemporalWaveProcessor
from .consciousness import ConsciousnessIntegrator, ConsciousnessParameters, ConsciousnessState
from .frequencies import GATFrequencies, FrequencyConstants, PHI


@dataclass
class GeneticTarget:
    """A single genetic target for transformation."""
    name: str
    sequence: str
    chromosome: int
    locus: str
    system: str  # e.g., "neural", "muscular", "elemental"
    expression_level: float = 1.0
    transformation_phase: Tuple[float, float] = (0.0, 1.0)  # (start, end) as fraction
    metadata: Dict = field(default_factory=dict)


@dataclass
class TransformationConfig:
    """Configuration for a complete transformation audio generation."""
    name: str = "OHAD Transformation"
    duration_hours: float = 4.0
    sample_rate: int = 192000
    bit_depth: int = 32
    
    # Consciousness parameters
    target_state: ConsciousnessState = ConsciousnessState.TRANSFORMATIVE
    coupling_strength: float = 0.7
    
    # Genetic parameters
    include_oversoul: bool = True
    genetic_intensity: float = 0.8
    
    # Temporal parameters
    include_standing_waves: bool = True
    temporal_modulation: float = 0.5
    
    # Output parameters
    output_format: str = "wav"  # or "raw"
    normalize: bool = True


class UnifiedAudioGenomicsPipeline:
    """
    Complete pipeline for generating holographic genomic audio.
    
    Integrates:
    - GAT frequency encoding for genetic sequences
    - Holographic interference patterns for multi-dimensional data
    - Temporal wave structures for transformation timing
    - Consciousness coupling for observer integration
    - Oversoul signatures for species connection
    """
    
    def __init__(self, config: TransformationConfig = None):
        """
        Initialize the unified pipeline.
        
        Args:
            config: Transformation configuration
        """
        self.config = config or TransformationConfig()
        
        # Initialize components
        self.encoder = AudioHolographicEncoder(
            sample_rate=self.config.sample_rate,
            bit_depth=self.config.bit_depth,
            precision="sub_quantum"
        )
        self.temporal = TemporalWaveProcessor(sample_rate=self.config.sample_rate)
        self.consciousness = ConsciousnessIntegrator(sample_rate=self.config.sample_rate)
        self.reconstructor = HolographicReconstructor(sample_rate=self.config.sample_rate)
        
        self.gat = GATFrequencies()
        self.freq = FrequencyConstants()
        
        # Storage for genetic targets
        self.genetic_targets: List[GeneticTarget] = []
        
    def add_genetic_target(self, target: GeneticTarget) -> None:
        """Add a genetic target for encoding."""
        self.genetic_targets.append(target)
        
    def add_genetic_targets_batch(self, targets: List[GeneticTarget]) -> None:
        """Add multiple genetic targets."""
        self.genetic_targets.extend(targets)
    
    def _create_example_targets(self) -> List[GeneticTarget]:
        """Create example OHAD genetic targets based on specifications."""
        targets = [
            # Core Oversoul integration genes
            GeneticTarget(
                name="OVERSOUL_SIGNATURE_UNIVERSAL",
                sequence="ATGGATGGATGGATGGATGG" * 5,
                chromosome=0,  # All chromosomes
                locus="Interspersed",
                system="consciousness",
                expression_level=1.0,
                transformation_phase=(0.0, 1.0),
                metadata={"type": "oversoul_signature"}
            ),
            GeneticTarget(
                name="OSR1_CONSCIOUSNESS_RECEPTOR",
                sequence="TGCTGCTGCTGCTGCTGCTGC",
                chromosome=1,
                locus="1p36.33",
                system="neural",
                expression_level=0.9,
                transformation_phase=(0.0, 0.3),
            ),
            GeneticTarget(
                name="OSR2_ENERGY_RECEPTOR",
                sequence="GATGATGATGATGATGATGAT",
                chromosome=2,
                locus="2q31.1",
                system="muscular",
                expression_level=0.9,
                transformation_phase=(0.1, 0.4),
            ),
            GeneticTarget(
                name="OSR3_PROTECTION_RECEPTOR",
                sequence="CAGCAGCAGCAGCAGCAGCAG",
                chromosome=3,
                locus="3p21.31",
                system="elemental",
                expression_level=0.9,
                transformation_phase=(0.1, 0.5),
            ),
            # Enhanced mechanosensitivity
            GeneticTarget(
                name="ENHANCED_PIEZO1",
                sequence="ATGCGATCGATCGATCGATCG",
                chromosome=16,
                locus="16q24.3",
                system="neural",
                expression_level=1.0,
                transformation_phase=(0.0, 0.2),
                metadata={"purpose": "Audio reception enhancement"}
            ),
            GeneticTarget(
                name="ENHANCED_PIEZO2",
                sequence="GCTAGCTAGCTAGCTAGCTAG",
                chromosome=18,
                locus="18p11.22",
                system="neural",
                expression_level=1.0,
                transformation_phase=(0.0, 0.2),
            ),
            # Morphological genes
            GeneticTarget(
                name="WING_DEVELOPMENT_MASTER",
                sequence="ATGATGATGATGATGATGATG" * 3,
                chromosome=7,
                locus="7q21.1",
                system="muscular",
                expression_level=0.8,
                transformation_phase=(0.2, 0.7),
            ),
            GeneticTarget(
                name="TAIL_EXTENSION_FACTOR",
                sequence="CGATCGATCGATCGATCGATC" * 2,
                chromosome=5,
                locus="5q35.1",
                system="muscular",
                expression_level=0.8,
                transformation_phase=(0.25, 0.65),
            ),
            GeneticTarget(
                name="SCALE_FORMATION_INITIATOR",
                sequence="TAGCTAGCTAGCTAGCTAGCT" * 2,
                chromosome=12,
                locus="12q13.2",
                system="integumentary",
                expression_level=0.85,
                transformation_phase=(0.3, 0.8),
            ),
            # Elemental core
            GeneticTarget(
                name="FIRE_GLAND_DEVELOPMENT",
                sequence="ATCGATCGATCGATCGATCGA" * 3,
                chromosome=15,
                locus="15q21.1",
                system="elemental",
                expression_level=0.9,
                transformation_phase=(0.4, 0.9),
            ),
        ]
        return targets
    
    def generate_layer_carrier(self, duration: float) -> np.ndarray:
        """Generate the carrier/reference wave layer."""
        num_samples = int(duration * self.config.sample_rate)
        t = np.linspace(0, duration, num_samples)
        
        # Primary carrier at 432 Hz
        carrier = np.cos(2 * np.pi * self.freq.REF_MID * t)
        
        # Add low frequency anchor
        carrier += 0.3 * np.cos(2 * np.pi * self.freq.REF_LOW * t)
        
        # Add high frequency anchor
        carrier += 0.2 * np.cos(2 * np.pi * self.freq.REF_HIGH * t)
        
        # Normalize
        carrier = carrier / np.max(np.abs(carrier)) * 0.3
        
        return carrier
    
    def generate_layer_genetic(self, duration: float) -> np.ndarray:
        """Generate the genetic encoding layer."""
        num_samples = int(duration * self.config.sample_rate)
        t = np.linspace(0, duration, num_samples)
        genetic = np.zeros(num_samples)
        
        if not self.genetic_targets:
            self.genetic_targets = self._create_example_targets()
        
        for target in self.genetic_targets:
            # Get frequencies for this gene's sequence
            freqs = self.gat.encode_sequence(target.sequence)
            
            # Calculate timing for this gene
            start_sample = int(target.transformation_phase[0] * num_samples)
            end_sample = int(target.transformation_phase[1] * num_samples)
            
            # Duration per nucleotide
            gene_samples = end_sample - start_sample
            samples_per_nucleotide = gene_samples // len(freqs) if len(freqs) > 0 else gene_samples
            
            for i, freq in enumerate(freqs):
                nuc_start = start_sample + i * samples_per_nucleotide
                nuc_end = min(nuc_start + samples_per_nucleotide, end_sample, num_samples)
                
                if nuc_start >= num_samples:
                    break
                    
                nuc_t = t[nuc_start:nuc_end] - t[nuc_start]
                
                # Envelope for smooth transitions
                nuc_duration = (nuc_end - nuc_start) / self.config.sample_rate
                if nuc_duration > 0:
                    envelope = np.sin(np.pi * nuc_t / nuc_duration) ** 0.5
                else:
                    envelope = np.ones_like(nuc_t)
                
                # Get chromosome-specific phase offset
                chrom_phase = (target.chromosome / 24) * 2 * np.pi
                
                # Get system-specific frequency overlay
                system_freqs = {
                    "neural": self.freq.NEURAL,
                    "muscular": self.freq.MUSCULAR,
                    "elemental": self.freq.ELEMENTAL,
                    "reproductive": self.freq.REPRODUCTIVE,
                    "integumentary": self.freq.INTEGUMENTARY,
                    "consciousness": self.freq.INTENTION,
                }
                system_freq = system_freqs.get(target.system, self.freq.REF_MID)
                
                # Generate nucleotide tone
                tone = (
                    target.expression_level * 
                    self.config.genetic_intensity * 
                    0.15 * 
                    envelope * 
                    np.cos(2 * np.pi * freq * nuc_t + chrom_phase)
                )
                
                # Add subtle system overlay
                tone += (
                    0.03 * 
                    envelope * 
                    np.cos(2 * np.pi * system_freq * nuc_t)
                )
                
                genetic[nuc_start:nuc_end] += tone
        
        # Normalize
        max_amp = np.max(np.abs(genetic))
        if max_amp > 0:
            genetic = genetic / max_amp * 0.4
        
        return genetic
    
    def generate_layer_temporal(self, duration: float) -> np.ndarray:
        """Generate the temporal wave layer."""
        timeline = self.temporal.create_transformation_timeline(duration)
        
        # Combine temporal elements
        temporal = (
            0.2 * timeline['envelope'] * timeline['standing_waves'] +
            0.1 * timeline['temporal_modulation']
        )
        
        # Add past-future relationship encoding
        past_future = self.temporal.encode_past_future_relationship(
            duration,
            past_weight=0.3,
            future_weight=0.4,
            present_emphasis=1.0
        )
        temporal += 0.15 * past_future
        
        # Apply configuration
        temporal = temporal * self.config.temporal_modulation
        
        return temporal
    
    def generate_layer_consciousness(self, duration: float) -> np.ndarray:
        """Generate the consciousness coupling layer."""
        params = ConsciousnessParameters(
            gamma_c=self.config.coupling_strength,
            state=self.config.target_state,
            coherence=0.8,
            intention_strength=0.7,
            intention_direction=0.0
        )
        
        consciousness = self.consciousness.create_consciousness_layer(duration, params)
        
        return consciousness
    
    def generate_layer_metadata(self, duration: float) -> np.ndarray:
        """Generate the metadata/meaning layer."""
        num_samples = int(duration * self.config.sample_rate)
        t = np.linspace(0, duration, num_samples)
        
        metadata = np.zeros(num_samples)
        
        # Intention frequency
        intention_phase = hash("transformation_to_dragon") % (2**24) / (2**24) * 2 * np.pi
        metadata += 0.1 * np.cos(2 * np.pi * self.freq.INTENTION * t + intention_phase)
        
        # Context frequency
        context_phase = hash("OHAD_species_integration") % (2**24) / (2**24) * 2 * np.pi
        metadata += 0.1 * np.cos(2 * np.pi * self.freq.CONTEXT * t + context_phase)
        
        # Meaning frequency
        meaning_phase = (intention_phase + context_phase) / 2
        metadata += 0.08 * np.cos(2 * np.pi * self.freq.MEANING * t + meaning_phase)
        
        return metadata
    
    def generate_complete_hologram(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate the complete holographic audio.
        
        Returns:
            Tuple of (time_array, holographic_signal)
        """
        duration = self.config.duration_hours * 3600  # Convert to seconds
        num_samples = int(duration * self.config.sample_rate)
        t = np.linspace(0, duration, num_samples)
        
        print(f"Generating {self.config.duration_hours} hour holographic audio...")
        print(f"  Sample rate: {self.config.sample_rate} Hz")
        print(f"  Total samples: {num_samples:,}")
        
        # Generate each layer
        print("  Generating carrier layer...")
        carrier = self.generate_layer_carrier(duration)
        
        print("  Generating genetic layer...")
        genetic = self.generate_layer_genetic(duration)
        
        print("  Generating temporal layer...")
        temporal = self.generate_layer_temporal(duration)
        
        print("  Generating consciousness layer...")
        consciousness = self.generate_layer_consciousness(duration)
        
        print("  Generating metadata layer...")
        metadata = self.generate_layer_metadata(duration)
        
        # Combine all layers
        print("  Combining layers...")
        hologram = carrier + genetic + temporal + consciousness + metadata
        
        # Apply holographic kernel
        print("  Applying holographic kernel...")
        hologram = self.encoder.kernel.apply(hologram, t)
        
        # Normalize if requested
        if self.config.normalize:
            max_amp = np.max(np.abs(hologram))
            if max_amp > 0:
                hologram = hologram / max_amp * 0.95
        
        print("  Generation complete!")
        
        return t, hologram
    
    def render_to_file(self, 
                      output_path: Union[str, Path],
                      duration_override: float = None) -> Path:
        """
        Render holographic audio to a file.
        
        Args:
            output_path: Path for output file
            duration_override: Override duration in hours (for testing)
            
        Returns:
            Path to created file
        """
        if duration_override is not None:
            original_duration = self.config.duration_hours
            self.config.duration_hours = duration_override
        
        output_path = Path(output_path)
        
        # Generate hologram
        t, hologram = self.generate_complete_hologram()
        
        if duration_override is not None:
            self.config.duration_hours = original_duration
        
        # Convert to appropriate format
        if self.config.output_format == "wav":
            self._write_wav(output_path, hologram)
        else:
            self._write_raw(output_path, hologram)
        
        print(f"Saved to: {output_path}")
        return output_path
    
    def _write_wav(self, path: Path, signal: np.ndarray) -> None:
        """Write signal to WAV file."""
        # Ensure .wav extension
        if not str(path).endswith('.wav'):
            path = Path(str(path) + '.wav')
        
        # Convert to 16-bit for standard WAV compatibility
        signal_int = (signal * 32767).astype(np.int16)
        
        with wave.open(str(path), 'w') as wav_file:
            wav_file.setnchannels(1)
            wav_file.setsampwidth(2)  # 16-bit
            wav_file.setframerate(self.config.sample_rate)
            wav_file.writeframes(signal_int.tobytes())
    
    def _write_raw(self, path: Path, signal: np.ndarray) -> None:
        """Write signal to raw binary file."""
        signal_float = signal.astype(np.float32)
        signal_float.tofile(path)
    
    def validate_output(self, audio: np.ndarray) -> Dict[str, float]:
        """
        Validate the generated holographic audio.
        
        Args:
            audio: Generated audio signal
            
        Returns:
            Dictionary of validation metrics
        """
        # Use reconstructor to validate
        hologram_validity = self.reconstructor.validate_hologram(audio)
        
        # Check consciousness coupling
        cons_params = ConsciousnessParameters(
            gamma_c=self.config.coupling_strength,
            state=self.config.target_state
        )
        cons_metrics = self.consciousness.compute_coupling_effectiveness(audio, cons_params)
        
        # Combine metrics
        metrics = {
            **hologram_validity,
            **{f"consciousness_{k}": v for k, v in cons_metrics.items()},
        }
        
        # Overall quality score
        metrics['overall_quality'] = (
            0.3 * hologram_validity['validity_score'] +
            0.3 * cons_metrics['coupling_ratio'] +
            0.2 * cons_metrics['coherence'] +
            0.2 * cons_metrics['oversoul_integration']
        )
        
        return metrics
    
    def generate_test_sample(self, duration_seconds: float = 10.0) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate a short test sample for quick validation.
        
        Args:
            duration_seconds: Duration in seconds
            
        Returns:
            Tuple of (time_array, holographic_signal)
        """
        original_duration = self.config.duration_hours
        self.config.duration_hours = duration_seconds / 3600
        
        t, hologram = self.generate_complete_hologram()
        
        self.config.duration_hours = original_duration
        
        return t, hologram


def create_standard_transformation_audio(output_path: str = None) -> Path:
    """
    Convenience function to create a standard OHAD transformation audio file.
    
    Args:
        output_path: Optional output path (defaults to current directory)
        
    Returns:
        Path to created file
    """
    config = TransformationConfig(
        name="OHAD_Standard_Transformation",
        duration_hours=4.0,
        sample_rate=96000,  # Slightly lower for smaller file size
        target_state=ConsciousnessState.TRANSFORMATIVE,
        coupling_strength=0.75,
        include_oversoul=True,
    )
    
    pipeline = UnifiedAudioGenomicsPipeline(config)
    
    if output_path is None:
        output_path = "OHAD_Transformation_Holographic.wav"
    
    return pipeline.render_to_file(output_path)


def create_test_audio(duration_seconds: float = 30.0, 
                     output_path: str = None) -> Tuple[Path, Dict]:
    """
    Create a short test audio for validation.
    
    Args:
        duration_seconds: Duration in seconds
        output_path: Optional output path
        
    Returns:
        Tuple of (path, validation_metrics)
    """
    config = TransformationConfig(
        name="Test_Audio",
        duration_hours=duration_seconds / 3600,
        sample_rate=48000,
    )
    
    pipeline = UnifiedAudioGenomicsPipeline(config)
    
    if output_path is None:
        output_path = "test_holographic.wav"
    
    # Generate
    t, hologram = pipeline.generate_complete_hologram()
    
    # Validate
    metrics = pipeline.validate_output(hologram)
    
    # Save
    path = pipeline.render_to_file(output_path)
    
    return path, metrics
